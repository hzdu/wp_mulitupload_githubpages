<?php return array('dependencies' => array(), 'version' => '21570c78e841702da7b0');
