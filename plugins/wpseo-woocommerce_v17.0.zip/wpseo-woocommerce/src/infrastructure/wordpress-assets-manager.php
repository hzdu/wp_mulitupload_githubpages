<?php

namespace Yoast\WP\SEO\WooCommerce\Infrastructure;

use WPSEO_Admin_Asset_Manager;
use Yoast\WP\SEO\WooCommerce\Application\Assets_Manager;

/**
 * Registers and enqueues the assets of this plugin with WordPress.
 *
 * This plugin owns its own handles: registering them through Yoast SEO's asset manager would resolve them
 * against the Yoast SEO plugin directory, prefix them as if they were Yoast SEO's, and bind their
 * translations to the "wordpress-seo" text domain.
 */
class WordPress_Assets_Manager implements Assets_Manager {

	/**
	 * The prefix of the handles this plugin registers its assets under.
	 *
	 * @var string
	 */
	public const PREFIX = 'yoast-woo-seo-';

	/**
	 * The admin asset manager of Yoast SEO.
	 *
	 * Used for its version flattening only, to keep the file names of this plugin in line with the convention
	 * the Yoast plugins share, rather than to register anything.
	 *
	 * @var WPSEO_Admin_Asset_Manager
	 */
	private $asset_manager;

	/**
	 * The plugin URL provider.
	 *
	 * @var Plugin_URL_Provider
	 */
	private $plugin_url_provider;

	/**
	 * Constructs the assets.
	 *
	 * @param WPSEO_Admin_Asset_Manager $asset_manager       The admin asset manager of Yoast SEO.
	 * @param Plugin_URL_Provider       $plugin_url_provider The plugin URL provider.
	 */
	public function __construct( WPSEO_Admin_Asset_Manager $asset_manager, Plugin_URL_Provider $plugin_url_provider ) {
		$this->asset_manager       = $asset_manager;
		$this->plugin_url_provider = $plugin_url_provider;
	}

	/**
	 * Registers the assets of this plugin, so that they can be enqueued by name afterwards.
	 *
	 * @return void
	 */
	public function register_assets(): void {
		$version = $this->asset_manager->flatten_version( \WPSEO_WOO_VERSION );

		foreach ( $this->get_scripts( $version ) as $script ) {
			\wp_register_script(
				$script['name'],
				$this->plugin_url_provider->get() . '/' . $script['path'] . $script['filename'],
				$script['dependencies'],
				\WPSEO_WOO_VERSION,
				true,
			);
		}

		foreach ( $this->get_styles() as $style ) {
			\wp_register_style(
				$style['name'],
				$this->plugin_url_provider->get() . '/' . $style['source'],
				$style['dependencies'],
				\WPSEO_WOO_VERSION,
			);
		}
	}

	/**
	 * Returns the scripts of this plugin to register, keyed by the name they are enqueued by.
	 *
	 * The dependencies are the ones webpack reports for the entry in src/generated/assets/plugin.php, plus the
	 * ones that are used through their globals and so are invisible to the build.
	 *
	 * @param string $version The flattened plugin version, used in every script's file name.
	 *
	 * @return array<string, array<string, string|array<string>>> The scripts, per the name they are enqueued by.
	 */
	private function get_scripts( string $version ): array {
		return [
			'alt-text-generator'         => [
				'name'         => self::PREFIX . 'alt-text-generator',
				'path'         => 'js/dist/',
				'filename'     => 'yoastseo-woo-product-images-' . $version . '.js',
				'dependencies' => [
					// Used through their globals, and so invisible to the build.
					'jquery',
					'media-models',
					'lodash',
					'react',
					'wp-api-fetch',
					'wp-components',
					'wp-data',
					'wp-element',
					'wp-hooks',
					'wp-i18n',
					'wp-polyfill',
					WPSEO_Admin_Asset_Manager::PREFIX . 'ai-frontend-package',
					WPSEO_Admin_Asset_Manager::PREFIX . 'redux-js-toolkit-package',
					WPSEO_Admin_Asset_Manager::PREFIX . 'ui-library-package',
				],
			],
			'bulk-editor-image-alt-text' => [
				'name'         => self::PREFIX . 'bulk-editor-image-alt-text',
				'path'         => 'js/dist/',
				'filename'     => 'yoastseo-woo-bulk-editor-image-alt-text-' . $version . '.js',
				'dependencies' => [
					'lodash',
					'react',
					'wp-components',
					'wp-data',
					'wp-dom-ready',
					'wp-element',
					'wp-i18n',
					'wp-plugins',
					'wp-polyfill',
					WPSEO_Admin_Asset_Manager::PREFIX . 'ai-frontend-package',
					WPSEO_Admin_Asset_Manager::PREFIX . 'ui-library-package',
				],
			],
		];
	}

	/**
	 * Returns the stylesheets of this plugin to register, keyed by the name they are enqueued by.
	 *
	 * @return array<string, array<string, string|array<string>>> The stylesheets, per the name they are enqueued by.
	 */
	private function get_styles(): array {
		return [
			'tailwind'    => [
				'name'         => self::PREFIX . 'tailwind',
				'source'       => 'css/dist/woo-seo-tailwind.css',
				'dependencies' => [],
			],
			'bulk-editor' => [
				'name'         => self::PREFIX . 'bulk-editor',
				'source'       => 'css/dist/woo-seo-bulk-editor.css',
				'dependencies' => [ 'yoast-seo-tailwind', 'yoast-seo-ai-frontend', self::PREFIX . 'tailwind' ],
			],
		];
	}

	/**
	 * Enqueues the given script, exposing the given data on the given global object.
	 *
	 * @param string                                                             $name        The name of the script to enqueue.
	 * @param string                                                             $object_name The name of the global object to expose the data on.
	 * @param array<string, array<int|string, array<string, int|string>|string>> $data        The data to expose on the global object.
	 *
	 * @return void
	 */
	public function enqueue_script( string $name, string $object_name, array $data ): void {
		$handle = self::PREFIX . $name;

		\wp_enqueue_script( $handle );
		\wp_localize_script( $handle, $object_name, $data );
	}

	/**
	 * Enqueues the given stylesheet.
	 *
	 * @param string $name The name of the stylesheet to enqueue.
	 *
	 * @return void
	 */
	public function enqueue_style( string $name ): void {
		\wp_enqueue_style( self::PREFIX . $name );
	}
}
