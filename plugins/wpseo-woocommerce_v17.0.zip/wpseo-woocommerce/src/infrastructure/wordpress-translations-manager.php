<?php

namespace Yoast\WP\SEO\WooCommerce\Infrastructure;

/**
 * Localizes a script with the JS translations of this plugin.
 *
 * Mirrors WPSEO_Premium_Asset_JS_L10n: a standalone collaborator, unrelated to WordPress_Assets_Manager, that
 * each integration calls for itself for the one script it enqueues on its own screen. The JS translation files
 * are shipped as one bundle per locale rather than as the per-handle files wp_set_script_translations() looks
 * for, so this reads that bundle and attaches it as its own localized global, separate from the script's own
 * data.
 */
class WordPress_Translations_Manager {

	/**
	 * The name of the global object the translations are exposed on.
	 *
	 * @var string
	 */
	public const OBJECT_NAME = 'wpseoWooJSL10n';

	/**
	 * The text domain the strings in the scripts of this plugin are translated under.
	 *
	 * @var string
	 */
	private const TEXT_DOMAIN = 'yoast-woo-seo';

	/**
	 * The name of the file the JS translations of this plugin are shipped in, without the locale and extension.
	 *
	 * @var string
	 */
	private const TRANSLATIONS_FILE = 'yoast-woo-seojs';

	/**
	 * Localizes the given script with the JS translations of this plugin.
	 *
	 * @param string $script_handle The script handle to localize for.
	 *
	 * @return void
	 */
	public function localize_script( string $script_handle ): void {
		$translations = [ self::TEXT_DOMAIN => $this->get_translations() ];

		\wp_localize_script( $script_handle, self::OBJECT_NAME, $translations );
	}

	/**
	 * Returns the JS translations of this plugin for the locale of the current user.
	 *
	 * @return array<string, string|array<string, array<string, array<string>|array<string, string>>>>|null The translations in JED format, or null if there is no file for the locale.
	 */
	private function get_translations() {
		$file = \WPSEO_WOO_PLUGIN_PATH . 'languages/' . self::TRANSLATIONS_FILE . '-' . \get_user_locale() . '.json';

		if ( ! \file_exists( $file ) ) {
			return null;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- This is a local file.
		$contents = \file_get_contents( $file );
		if ( ! \is_string( $contents ) || $contents === '' ) {
			return null;
		}

		return \json_decode( $contents, true );
	}
}
