<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application;

/**
 * Persists the alt text of an image.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
interface Alt_Text_Repository_Interface {

	/**
	 * Saves the alt text of the given attachment.
	 *
	 * @param int    $attachment_id The attachment ID of the image.
	 * @param string $alt_text      The unslashed alt text to save.
	 *
	 * @return bool Whether the image has the given alt text afterwards.
	 */
	public function save( int $attachment_id, string $alt_text ): bool;
}
