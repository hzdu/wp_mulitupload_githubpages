<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application;

use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image_Collection;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Variation_Image;

/**
 * Assembles the images to possibly generate alt text for.
 */
class Product_Images_Repository {

	/**
	 * The image data provider.
	 *
	 * @var Image_Data_Provider_Interface
	 */
	private $image_data_provider;

	/**
	 * Constructs the repository.
	 *
	 * @param Image_Data_Provider_Interface $image_data_provider The image data provider.
	 */
	public function __construct( Image_Data_Provider_Interface $image_data_provider ) {
		$this->image_data_provider = $image_data_provider;
	}

	/**
	 * Retrieves the images of a product: the product image, the product gallery images and the
	 * per-variation images, in that order, each typed by that role.
	 *
	 * Every role an attachment plays gets its own entry: one per variation image using it — a
	 * variation holds its own featured image plus its gallery — so consumers can reconcile
	 * per-variation changes, and one per main role, also when the product image is in the gallery
	 * too. Deduplicating the assessed set by attachment is the consumer's job.
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return Image_Collection The images.
	 */
	public function get_images( int $product_id ): Image_Collection {
		$images = new Image_Collection();

		$featured_id   = $this->image_data_provider->get_featured_image_id( $product_id );
		$gallery_ids   = $this->image_data_provider->get_gallery_image_ids( $product_id );
		$variation_map = $this->image_data_provider->get_variation_image_map( $product_id );

		$all_ids           = ( $featured_id === 0 ) ? [] : [ $featured_id ];
		$variation_id_sets = \array_values( $variation_map );
		$all_ids           = \array_unique( \array_merge( $all_ids, $gallery_ids, ...$variation_id_sets ) );
		if ( $all_ids === [] ) {
			return $images;
		}

		$attachment_data = $this->image_data_provider->get_attachment_data( $all_ids );

		if ( $featured_id !== 0 ) {
			$images->add( $this->create_image( $featured_id, $attachment_data[ $featured_id ], Image::TYPE_FEATURED ) );
		}

		foreach ( $gallery_ids as $attachment_id ) {
			$images->add( $this->create_image( $attachment_id, $attachment_data[ $attachment_id ], Image::TYPE_GALLERY ) );
		}

		foreach ( $variation_map as $variation_id => $variation_image_ids ) {
			foreach ( $variation_image_ids as $attachment_id ) {
				$images->add(
					new Variation_Image(
						$variation_id,
						$attachment_id,
						$attachment_data[ $attachment_id ]['src'],
						$attachment_data[ $attachment_id ]['alt'],
					),
				);
			}
		}

		return $images;
	}

	/**
	 * Creates an image from the resolved attachment data.
	 *
	 * @param int                   $attachment_id   The attachment ID.
	 * @param array<string, string> $attachment_data The src and alt of the attachment.
	 * @param string                $type            The role the image plays for the product.
	 *
	 * @return Image The image.
	 */
	private function create_image( int $attachment_id, array $attachment_data, string $type ): Image {
		return new Image(
			$attachment_id,
			$attachment_data['src'],
			$attachment_data['alt'],
			$type,
		);
	}
}
