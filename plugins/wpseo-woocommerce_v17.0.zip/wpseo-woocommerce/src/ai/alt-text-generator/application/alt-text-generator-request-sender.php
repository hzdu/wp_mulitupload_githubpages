<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application;

use RuntimeException;
use WP_User;
use Yoast\WP\SEO\AI\Authentication\Application\AI_Request_Sender_Factory;
use Yoast\WP\SEO\AI\Consent\Application\Consent_Handler;
use Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions\Forbidden_Exception;
use Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions\Insufficient_Scope_Exception;
use Yoast\WP\SEO\AI\HTTP_Request\Domain\Request;

/**
 * Sends the alt text generation request to the AI API and returns its decoded response.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Alt_Text_Generator_Request_Sender {

	/**
	 * The auth strategy factory.
	 *
	 * @var AI_Request_Sender_Factory
	 */
	private $ai_request_sender_factory;

	/**
	 * The consent handler.
	 *
	 * @var Consent_Handler
	 */
	private $consent_handler;

	/**
	 * The constructor.
	 *
	 * @param AI_Request_Sender_Factory $ai_request_sender_factory The auth strategy factory.
	 * @param Consent_Handler           $consent_handler           The consent handler.
	 */
	public function __construct(
		AI_Request_Sender_Factory $ai_request_sender_factory,
		Consent_Handler $consent_handler
	) {
		$this->ai_request_sender_factory = $ai_request_sender_factory;
		$this->consent_handler           = $consent_handler;
	}

	// phpcs:disable Squiz.Commenting.FunctionCommentThrowTag.WrongNumber -- PHPCS doesn't track exceptions thrown by called services.

	/**
	 * Sends the given subjects to the AI API and returns the decoded response envelope.
	 *
	 * @param WP_User                                 $user     The user requesting the generation.
	 * @param array<int, array<string, string|array>> $subjects The subjects to generate alt text for.
	 *
	 * @throws Insufficient_Scope_Exception When the OAuth path's token is missing the required scope.
	 * @throws Forbidden_Exception          When consent has been revoked.
	 * @throws RuntimeException             When the AI service response is malformed.
	 *
	 * @return array<string, array|null> The decoded response envelope.
	 */
	public function send( WP_User $user, array $subjects ): array {
		$body = [];
		foreach ( $subjects as $subject ) {
			$body[] = $subject->to_array();
		}

		$request = new Request( '/alt-text-generator/generate', [ 'subjects' => $body ] );

		try {
			$sender   = $this->ai_request_sender_factory->create( $user );
			$response = $sender->send( $request, $user );
		} catch ( Insufficient_Scope_Exception $exception ) {
			throw $exception;
		} catch ( Forbidden_Exception $exception ) {
			$this->consent_handler->revoke_consent( $user->ID );
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive.
			throw new Forbidden_Exception( 'CONSENT_REVOKED', $exception->getCode() );
		}

		return $this->decode( $response->get_body(), \count( $subjects ) );
	}

	/**
	 * Decodes the response body and asserts it holds a result for every subject that was sent.
	 *
	 * @param string $body          The response body.
	 * @param int    $subject_count The number of subjects that were sent.
	 *
	 * @throws RuntimeException When the AI service response is malformed.
	 *
	 * @return array<string, array|null> The decoded response envelope.
	 */
	private function decode( string $body, int $subject_count ): array {
		$envelope = \json_decode( $body, true );

		if ( ! \is_array( $envelope ) || ! isset( $envelope['results'] ) || ! \is_array( $envelope['results'] ) ) {
			throw new RuntimeException( 'Malformed response from the AI service' );
		}

		if ( \count( $envelope['results'] ) !== $subject_count ) {
			throw new RuntimeException( 'Malformed response from the AI service' );
		}

		return $envelope;
	}
}
