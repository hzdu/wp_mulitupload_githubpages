<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain;

/**
 * Represents the attributes of the product an image belongs to.
 *
 * The collection never holds more than Attribute_Limit::MAX_ATTRIBUTES attributes: anything beyond
 * that is dropped when added, so the limit cannot be exceeded by whoever builds the collection.
 */
class Product_Attributes {

	/**
	 * The attributes of the product.
	 *
	 * @var array<string>
	 */
	private $attributes = [];

	/**
	 * Adds an attribute to the collection, unless the limit has been reached.
	 *
	 * @param string $attribute The attribute to add.
	 *
	 * @return void
	 */
	public function add( string $attribute ): void {
		if ( ! Attribute_Limit::is_within_limit( ( \count( $this->attributes ) + 1 ) ) ) {
			return;
		}

		$this->attributes[] = $attribute;
	}

	/**
	 * Returns the attributes, as the AI API payload expects them.
	 *
	 * @return array<string> The attributes of the product.
	 */
	public function to_array(): array {
		return $this->attributes;
	}
}
