<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain;

use RuntimeException;

/**
 * Exception thrown when an image cannot be validated for alt text generation.
 */
class Image_Validation_Exception extends RuntimeException {

	public const IMAGE_NOT_FOUND = 'IMAGE_NOT_FOUND';

	public const NOT_ALLOWED_TO_EDIT = 'NOT_ALLOWED_TO_EDIT';

	public const NOT_AN_IMAGE = 'NOT_AN_IMAGE';

	public const UNSUPPORTED_FORMAT = 'UNSUPPORTED_FORMAT';

	/**
	 * The error code identifying why the image could not be validated.
	 *
	 * @var string
	 */
	private $error_code;

	/**
	 * Image_Validation_Exception constructor.
	 *
	 * The arguments are optional so the exception stays autowirable when discovered by the dependency
	 * injection container, mirroring the Free remote-request exceptions.
	 *
	 * @param string $error_code The error code identifying why the image could not be validated.
	 * @param string $message    The human-readable message.
	 */
	public function __construct( string $error_code = '', string $message = '' ) {
		parent::__construct( $message );

		$this->error_code = $error_code;
	}

	/**
	 * Returns the error code identifying why the image could not be validated.
	 *
	 * @return string The error code.
	 */
	public function get_error_code(): string {
		return $this->error_code;
	}
}
