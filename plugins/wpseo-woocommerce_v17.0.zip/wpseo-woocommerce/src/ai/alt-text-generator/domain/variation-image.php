<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain;

/**
 * Represents the image a single product variation uses.
 */
class Variation_Image extends Image {

	/**
	 * The variation ID.
	 *
	 * @var int
	 */
	private $variation_id;

	/**
	 * Constructs the variation image.
	 *
	 * @param int    $variation_id The variation ID.
	 * @param int    $id           The attachment ID.
	 * @param string $url          The URL of the image.
	 * @param string $alt_text     The current alt text of the image.
	 */
	public function __construct( int $variation_id, int $id, string $url, string $alt_text ) {
		parent::__construct( $id, $url, $alt_text, self::TYPE_VARIATION );

		$this->variation_id = $variation_id;
	}

	/**
	 * Returns the variation image as an array, keyed as the script data payload expects.
	 *
	 * @return array<string, int|string> The variation image data.
	 */
	public function to_array(): array {
		return \array_merge(
			parent::to_array(),
			[ 'variationId' => $this->variation_id ],
		);
	}
}
