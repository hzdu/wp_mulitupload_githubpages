<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain;

use JsonSerializable;

/**
 * Represents a collection of images the alt text generator can generate alt text for.
 */
class Image_Collection implements JsonSerializable {

	/**
	 * The images.
	 *
	 * @var array<Image>
	 */
	private $images = [];

	/**
	 * Adds an image to the collection.
	 *
	 * @param Image $image The image to add.
	 *
	 * @return void
	 */
	public function add( Image $image ): void {
		$this->images[] = $image;
	}

	/**
	 * Returns the images as arrays, keyed as the script data payload expects.
	 *
	 * @return array<array<string, int|string>> The data of the images.
	 */
	public function to_array(): array {
		$data = [];
		foreach ( $this->images as $image ) {
			$data[] = $image->to_array();
		}

		return $data;
	}

	/**
	 * Returns the images in array format for Json encoding.
	 *
	 * @return array<array<string, int|string>> The data of the images.
	 */
	public function jsonSerialize(): array {
		return $this->to_array();
	}
}
