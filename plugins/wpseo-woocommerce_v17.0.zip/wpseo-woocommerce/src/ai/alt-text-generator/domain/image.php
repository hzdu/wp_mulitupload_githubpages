<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain;

use JsonSerializable;

/**
 * Represents an image the alt text generator can generate alt text for.
 */
class Image implements JsonSerializable {

	public const TYPE_FEATURED = 'featured';

	public const TYPE_GALLERY = 'gallery';

	public const TYPE_VARIATION = 'variation';

	/**
	 * The MIME types the AI service accepts for alt text generation.
	 *
	 * The list is kept here rather than reusing Yoast SEO's Image_Helper: that one describes what the plugin
	 * can present as a social image, which is free to diverge from what the AI service can read.
	 *
	 * @var array<string>
	 */
	public const AI_SUPPORTED_MIME_TYPES = [ 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ];

	/**
	 * The attachment ID.
	 *
	 * @var int
	 */
	private $id;

	/**
	 * The URL of the image.
	 *
	 * @var string
	 */
	private $url;

	/**
	 * The current alt text of the image.
	 *
	 * @var string
	 */
	private $alt_text;

	/**
	 * The role the image plays for the product: one of the TYPE_* constants.
	 *
	 * @var string
	 */
	private $type;

	/**
	 * Constructs the image.
	 *
	 * @param int    $id       The attachment ID.
	 * @param string $url      The URL of the image.
	 * @param string $alt_text The current alt text of the image.
	 * @param string $type     The role the image plays for the product: one of the TYPE_* constants.
	 */
	public function __construct( int $id, string $url, string $alt_text, string $type ) {
		$this->id       = $id;
		$this->url      = $url;
		$this->alt_text = $alt_text;
		$this->type     = $type;
	}

	/**
	 * Whether the given MIME type is an image's, whatever the platform stores it as.
	 *
	 * @param string $mime_type The MIME type.
	 *
	 * @return bool Whether the type is an image type.
	 */
	public static function is_image_mime_type( string $mime_type ): bool {
		return \strpos( $mime_type, 'image/' ) === 0;
	}

	/**
	 * Whether the AI API can read images of the given MIME type.
	 *
	 * @param string $mime_type The MIME type.
	 *
	 * @return bool Whether alt text can be generated for images of this type.
	 */
	public static function is_ai_supported_mime_type( string $mime_type ): bool {
		return \in_array( $mime_type, self::AI_SUPPORTED_MIME_TYPES, true );
	}

	/**
	 * Returns the image as an array, keyed as the script data payload expects.
	 *
	 * @return array<string, int|string> The image data.
	 */
	public function to_array(): array {
		return [
			'id'   => $this->id,
			'src'  => $this->url,
			'alt'  => $this->alt_text,
			'type' => $this->type,
		];
	}

	/**
	 * Returns the image in array format for Json encoding.
	 *
	 * @return array<string, int|string> The image data.
	 */
	public function jsonSerialize(): array {
		return $this->to_array();
	}
}
