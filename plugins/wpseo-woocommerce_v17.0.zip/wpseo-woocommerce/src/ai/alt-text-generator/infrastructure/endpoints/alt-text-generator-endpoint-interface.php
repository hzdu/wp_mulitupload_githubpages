<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Infrastructure\Endpoints;

use Yoast\WP\SEO\Routes\Endpoint\Endpoint_Interface;

/**
 * Interface for the alt text generator endpoint.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
interface Alt_Text_Generator_Endpoint_Interface extends Endpoint_Interface {}
