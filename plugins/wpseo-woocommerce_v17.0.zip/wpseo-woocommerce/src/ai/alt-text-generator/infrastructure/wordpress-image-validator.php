<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Infrastructure;

use WP_User;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Image_Validator_Interface;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image_Validation_Exception;

/**
 * Validates an image attachment for alt text editing and generation using WordPress.
 */
class WordPress_Image_Validator implements Image_Validator_Interface {

	/**
	 * Validates that the given attachment is an image and that the user may edit it.
	 *
	 * @param WP_User $user          The user editing the image.
	 * @param int     $attachment_id The attachment ID of the image.
	 *
	 * @return void
	 *
	 * @throws Image_Validation_Exception When the attachment does not exist, is not an image or the user is not
	 *                                   allowed to edit it.
	 */
	public function validate( WP_User $user, int $attachment_id ): void {
		$this->validate_attachment( $user, $attachment_id );
	}

	/**
	 * Validates the given attachment for alt text generation.
	 *
	 * @param WP_User $user          The user requesting the generation.
	 * @param int     $attachment_id The attachment ID of the image.
	 *
	 * @return void
	 *
	 * @throws Image_Validation_Exception When the attachment does not exist, is not an image, the user is not allowed
	 *                                   to edit it or its format is not one the AI API can read.
	 */
	public function validate_for_generation( WP_User $user, int $attachment_id ): void {
		$attachment = $this->validate_attachment( $user, $attachment_id );

		if ( ! Image::is_ai_supported_mime_type( (string) $attachment->post_mime_type ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Error code and static message, returned as JSON, never output.
			throw new Image_Validation_Exception( Image_Validation_Exception::UNSUPPORTED_FORMAT, 'The format of this image is not supported' );
		}
	}

	/**
	 * Resolves the attachment and checks that it is an image and that the user may edit it.
	 *
	 * @param WP_User $user          The user editing the image.
	 * @param int     $attachment_id The attachment ID of the image.
	 *
	 * @return object The attachment post.
	 *
	 * @throws Image_Validation_Exception When the attachment does not exist, is not an image or the user is not
	 *                                   allowed to edit it.
	 */
	private function validate_attachment( WP_User $user, int $attachment_id ): object {
		$attachment = \get_post( $attachment_id );
		if ( $attachment === null || $attachment->post_type !== 'attachment' || $attachment->post_status === 'trash' ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Error code and static message, returned as JSON, never output.
			throw new Image_Validation_Exception( Image_Validation_Exception::IMAGE_NOT_FOUND, 'The image could not be found' );
		}

		if ( ! \user_can( $user, 'edit_post', $attachment_id ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Error code and static message, returned as JSON, never output.
			throw new Image_Validation_Exception( Image_Validation_Exception::NOT_ALLOWED_TO_EDIT, 'You are not allowed to edit this image' );
		}

		// Alt text is image metadata: any image qualifies, whatever the AI can read.
		if ( ! Image::is_image_mime_type( (string) $attachment->post_mime_type ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Error code and static message, returned as JSON, never output.
			throw new Image_Validation_Exception( Image_Validation_Exception::NOT_AN_IMAGE, 'This file is not an image' );
		}

		return $attachment;
	}
}
