<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\User_Interface;

use WP_REST_Request;
use WP_REST_Response;
use Yoast\WP\SEO\Main;
use Yoast\WP\SEO\Routes\Route_Interface;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Alt_Text_Repository_Interface;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Image_Validator_Interface;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image_Validation_Exception;
use Yoast\WP\SEO\WooCommerce\Conditionals\WooCommerce_Conditional;

/**
 * Registers a route to save the alt text of one or more product images.
 *
 * @internal This route persists the alt text accepted in the product editor. It is not part of the plugin's public REST API surface, requires the capability to edit products (see {@see self::check_permissions()}), and may change at any time without notice.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Save_Alt_Text_Route implements Route_Interface {

	/**
	 * The namespace for this route.
	 *
	 * @var string
	 */
	public const ROUTE_NAMESPACE = Main::API_V1_NAMESPACE;

	/**
	 * The prefix for this route.
	 *
	 * @var string
	 */
	public const ROUTE_PREFIX = '/alt_text_generator/save';

	/**
	 * The maximum length of an alt text this route accepts.
	 *
	 * @var int
	 */
	public const MAX_ALT_TEXT_LENGTH = 1000;

	/**
	 * The image validator.
	 *
	 * @var Image_Validator_Interface
	 */
	private $image_validator;

	/**
	 * The alt text repository.
	 *
	 * @var Alt_Text_Repository_Interface
	 */
	private $alt_text_repository;

	/**
	 * Returns the conditionals based on which this loadable should be active.
	 *
	 * @return array<string> The conditionals.
	 */
	public static function get_conditionals(): array {
		return [ WooCommerce_Conditional::class ];
	}

	/**
	 * Class constructor.
	 *
	 * @param Image_Validator_Interface     $image_validator     The image validator.
	 * @param Alt_Text_Repository_Interface $alt_text_repository The alt text repository.
	 */
	public function __construct( Image_Validator_Interface $image_validator, Alt_Text_Repository_Interface $alt_text_repository ) {
		$this->image_validator     = $image_validator;
		$this->alt_text_repository = $alt_text_repository;
	}

	/**
	 * Registers routes with WordPress.
	 *
	 * @return void
	 */
	public function register_routes() {
		\register_rest_route(
			self::ROUTE_NAMESPACE,
			self::ROUTE_PREFIX,
			[
				'methods'             => 'POST',
				'args'                => [
					'images' => [
						'required'    => true,
						'type'        => 'array',
						'minItems'    => 1,
						'description' => 'The images to save alt text for.',
						'items'       => [
							'type'       => 'object',
							'properties' => [
								'image_id' => [
									'required'          => true,
									'type'              => 'integer',
									'minimum'           => 1,
									'description'       => 'The attachment ID of the image to update the alt text for.',
									'validate_callback' => 'rest_validate_request_arg',
									'sanitize_callback' => 'absint',
								],
								'alt_text' => [
									'required'          => true,
									'type'              => 'string',
									'maxLength'         => self::MAX_ALT_TEXT_LENGTH,
									'description'       => 'The alt text to save for the image.',
									'validate_callback' => 'rest_validate_request_arg',
									'sanitize_callback' => 'sanitize_text_field',
								],
							],
						],
					],
				],
				'callback'            => [ $this, 'save_alt_text' ],
				'permission_callback' => [ $this, 'check_permissions' ],
			],
		);
	}

	/**
	 * Saves the passed alt texts for the passed images.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response of the save action.
	 */
	public function save_alt_text( WP_REST_Request $request ): WP_REST_Response {
		$user   = \wp_get_current_user();
		$images = $request->get_param( 'images' );
		$result = [];

		foreach ( $images as $image ) {
			$image_id = $image['image_id'];
			$alt_text = \sanitize_text_field( $image['alt_text'] );

			try {
				$this->image_validator->validate( $user, $image_id );
			} catch ( Image_Validation_Exception $exception ) {
				$result[] = $this->image_error_result( $image_id, $exception->get_error_code(), $exception->getMessage() );
				continue;
			}

			if ( ! $this->alt_text_repository->save( $image_id, $alt_text ) ) {
				$result[] = $this->image_error_result( $image_id, 'SAVE_FAILED', 'The alt text could not be saved' );
				continue;
			}

			$result[] = $this->image_success_result( $image_id, $alt_text );
		}

		return new WP_REST_Response(
			(object) [
				'success' => true,
				'status'  => 200,
				'images'  => $result,
			],
			200,
		);
	}

	/**
	 * Performs the permission check.
	 *
	 * @return bool Whether the current user may edit products.
	 */
	public function check_permissions(): bool {
		$user = \wp_get_current_user();
		if ( $user === null || $user->ID < 1 ) {
			return false;
		}

		$post_type_object = \get_post_type_object( 'product' );
		if ( $post_type_object === null ) {
			return false;
		}

		return \user_can( $user, $post_type_object->cap->edit_posts );
	}

	/**
	 * Builds a per-image result for a successfully saved alt text.
	 *
	 * The result carries the alt text as saved, after sanitization, so the caller can show what is actually stored.
	 *
	 * @param int    $image_id The attachment ID of the image.
	 * @param string $alt_text The saved alt text.
	 *
	 * @return array<string, bool|int|string> The per-image result.
	 */
	private function image_success_result( int $image_id, string $alt_text ): array {
		return [
			'image_id' => $image_id,
			'success'  => true,
			'alt_text' => $alt_text,
		];
	}

	/**
	 * Builds a per-image result for an alt text that was not saved.
	 *
	 * @param int    $image_id   The attachment ID of the image.
	 * @param string $error_code The error code identifying why the alt text was not saved.
	 * @param string $message    The human-readable message.
	 *
	 * @return array<string, bool|int|string> The per-image result.
	 */
	private function image_error_result( int $image_id, string $error_code, string $message ): array {
		return [
			'image_id'   => $image_id,
			'success'    => false,
			'error_code' => $error_code,
			'message'    => $message,
		];
	}
}
