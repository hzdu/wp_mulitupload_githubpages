<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\User_Interface;

use RuntimeException;
use WP_REST_Request;
use WP_REST_Response;
use Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions\Payment_Required_Exception;
use Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions\Remote_Request_Exception;
use Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions\Too_Many_Requests_Exception;
use Yoast\WP\SEO\Conditionals\AI_Conditional;
use Yoast\WP\SEO\Main;
use Yoast\WP\SEO\Routes\Route_Interface;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Alt_Text_Generator_Command;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Alt_Text_Generator_Command_Handler;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Attribute_Limit;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Product_Attributes;
use Yoast\WP\SEO\WooCommerce\Conditionals\WooCommerce_Conditional;

/**
 * Registers a route to generate alt text for product images through the AI API.
 *
 * @internal This route powers the AI alt text generation feature in the product editor. It is not part of the plugin's public REST API surface, requires the capability to edit products (see {@see self::check_permissions()}), and may change at any time without notice.
 *
 * @makePublic
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Alt_Text_Generator_Route implements Route_Interface {

	/**
	 * The namespace for this route.
	 *
	 * @var string
	 */
	public const ROUTE_NAMESPACE = Main::API_V1_NAMESPACE;

	/**
	 * The prefix for this route.
	 *
	 * @var string
	 */
	public const ROUTE_PREFIX = '/alt_text_generator/generate';

	/**
	 * The command handler instance.
	 *
	 * @var Alt_Text_Generator_Command_Handler
	 */
	private $command_handler;

	/**
	 * Returns the conditionals based on which this loadable should be active.
	 *
	 * @return array<string> The conditionals.
	 */
	public static function get_conditionals(): array {
		return [ WooCommerce_Conditional::class, AI_Conditional::class ];
	}

	/**
	 * Class constructor.
	 *
	 * @param Alt_Text_Generator_Command_Handler $command_handler The command handler instance.
	 */
	public function __construct( Alt_Text_Generator_Command_Handler $command_handler ) {
		$this->command_handler = $command_handler;
	}

	/**
	 * Registers routes with WordPress.
	 *
	 * @return void
	 */
	public function register_routes() {
		\register_rest_route(
			self::ROUTE_NAMESPACE,
			self::ROUTE_PREFIX,
			[
				'methods'             => 'POST',
				'args'                => [
					'images'                    => [
						'required'    => true,
						'type'        => 'array',
						'minItems'    => 1,
						'maxItems'    => 20,
						'description' => 'The images to generate alt text for.',
						'items'       => [
							'type'       => 'object',
							'required'   => [ 'id', 'url', 'image_types' ],
							'properties' => [
								'id' => [
									'type'        => 'integer',
									'minimum'     => 1,
									'description' => 'The attachment ID of the image.',
								],
								'url' => [
									'type'        => 'string',
									'format'      => 'uri',
									'description' => 'The URL of the image.',
								],
								'image_types' => [
									'type'        => 'array',
									'minItems'    => 1,
									'uniqueItems' => true,
									'items'       => [
										'type' => 'string',
										'enum' => [
											Image::TYPE_FEATURED,
											Image::TYPE_GALLERY,
											Image::TYPE_VARIATION,
										],
									],
									'description' => 'All the places the image is used: as the main product image, in the product gallery and/or as a variation image.',
								],
								'alt_text' => [
									'type'        => 'string',
									'default'     => '',
									'description' => 'The existing alt text of the image.',
								],
								'attributes_per_variation' => [
									'type'        => 'array',
									'default'     => [],
									'items'       => [
										'type' => 'object',
										'additionalProperties' => [
											'type' => 'string',
										],
									],
									'description' => 'The attributes of each variation this image is used for, one entry per variation. Only the attributes shared across all of them are sent to the AI API, so an image used for "Color: Red, Size: S" and "Color: Red, Size: M" is described as "Color: Red".',
								],
							],
						],
					],
					'focus_keyphrase'           => [
						'required'    => true,
						'type'        => 'string',
						'description' => 'The focus keyphrase associated to the product.',
					],
					'product_title'             => [
						'required'    => false,
						'type'        => 'string',
						'default'     => '',
						'description' => 'The title of the product the image belongs to.',
					],
					'product_short_description' => [
						'required'    => false,
						'type'        => 'string',
						'default'     => '',
						'description' => 'The short description of the product, if it exists.',
					],
					'attributes'                => [
						'required'    => false,
						'type'        => 'array',
						'items'       => [
							'type' => 'string',
						],
						'maxItems'    => Attribute_Limit::MAX_ATTRIBUTES,
						'default'     => [],
						'description' => 'The attributes of the product, limited to 10.',
					],
					'language'                  => [
						'required'    => true,
						'type'        => 'string',
						'description' => 'The language the product description is written in.',
					],
				],
				'callback'            => [ $this, 'generate_alt_text' ],
				'permission_callback' => [ $this, 'check_permissions' ],
			],
		);
	}

	/**
	 * Runs the callback to get an AI-generated alt text for a product image.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response of the generate_alt_text action.
	 */
	public function generate_alt_text( WP_REST_Request $request ): WP_REST_Response {
		try {
			$user = \wp_get_current_user();

			$command = new Alt_Text_Generator_Command(
				$user,
				$request->get_param( 'images' ),
				$request->get_param( 'focus_keyphrase' ),
				$request->get_param( 'product_title' ),
				$request->get_param( 'product_short_description' ),
				$this->build_attributes( $request->get_param( 'attributes' ) ),
				$request->get_param( 'language' ),
			);
			$data    = $this->command_handler->handle( $command );
		} catch ( Remote_Request_Exception $e ) {
			$message = [
				'message'         => $e->getMessage(),
				'errorIdentifier' => $e->get_error_identifier(),
			];
			if ( $e instanceof Payment_Required_Exception || $e instanceof Too_Many_Requests_Exception ) {
				$message['missingLicenses'] = $e->get_missing_licenses();
			}
			return new WP_REST_Response(
				$message,
				$e->getCode(),
			);
		} catch ( RuntimeException $e ) {
			return new WP_REST_Response( 'Failed to generate alt text.', 500 );
		}

		return new WP_REST_Response( $data );
	}

	/**
	 * Checks if the user is logged in and can edit products.
	 *
	 * @return bool Whether the user can edit products.
	 */
	public function check_permissions(): bool {
		$user = \wp_get_current_user();
		if ( $user === null || $user->ID < 1 ) {
			return false;
		}

		$post_type_object = \get_post_type_object( 'product' );
		if ( $post_type_object === null ) {
			return false;
		}

		return \user_can( $user, $post_type_object->cap->edit_posts );
	}

	/**
	 * Builds the product attributes from the request's attributes.
	 *
	 * @param array<string> $attributes The attributes of the product.
	 *
	 * @return Product_Attributes The attributes of the product.
	 */
	private function build_attributes( array $attributes ): Product_Attributes {
		$product_attributes = new Product_Attributes();
		foreach ( $attributes as $attribute ) {
			$product_attributes->add( $attribute );
		}

		return $product_attributes;
	}
}
