<?php

namespace Yoast\WP\SEO\WooCommerce\Conditionals;

use Yoast\WP\SEO\Conditionals\Admin\Post_Conditional;
use Yoast\WP\SEO\Conditionals\Conditional;
use Yoast\WP\SEO\Helpers\Current_Page_Helper;

/**
 * Conditional that is only met when on a product edit or new product page.
 */
class Product_Editor_Conditional implements Conditional {

	/**
	 * The post conditional.
	 *
	 * @var Post_Conditional
	 */
	private $post_conditional;

	/**
	 * The current page helper.
	 *
	 * @var Current_Page_Helper
	 */
	private $current_page_helper;

	/**
	 * Constructs the conditional.
	 *
	 * @param Post_Conditional    $post_conditional    The post conditional.
	 * @param Current_Page_Helper $current_page_helper The current page helper.
	 */
	public function __construct( Post_Conditional $post_conditional, Current_Page_Helper $current_page_helper ) {
		$this->post_conditional    = $post_conditional;
		$this->current_page_helper = $current_page_helper;
	}

	/**
	 * Returns whether or not this conditional is met.
	 *
	 * @return bool Whether or not the conditional is met.
	 */
	public function is_met() {
		return $this->post_conditional->is_met()
			&& $this->current_page_helper->get_current_post_type() === 'product';
	}
}
