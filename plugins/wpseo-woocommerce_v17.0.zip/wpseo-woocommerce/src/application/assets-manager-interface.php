<?php

namespace Yoast\WP\SEO\WooCommerce\Application;

/**
 * Makes the assets of this plugin available on the current page.
 *
 * Assets are addressed by name. Which names exist, and how a name maps onto a file, a handle and a set of
 * dependencies, is left to the implementation, so that nothing outside the infrastructure layer has to know
 * where the built files live or which handles the surrounding plugins happen to use.
 */
interface Assets_Manager {

	/**
	 * Registers the assets of this plugin, so that they can be enqueued by name afterwards.
	 *
	 * @return void
	 */
	public function register_assets(): void;

	/**
	 * Enqueues the given script, exposing the given data on the given global object.
	 *
	 * @param string                                                             $name        The name of the script to enqueue.
	 * @param string                                                             $object_name The name of the global object to expose the data on.
	 * @param array<string, array<int|string, array<string, int|string>|string>> $data        The data to expose on the global object.
	 *
	 * @return void
	 */
	public function enqueue_script( string $name, string $object_name, array $data ): void;

	/**
	 * Enqueues the given stylesheet.
	 *
	 * @param string $name The name of the stylesheet to enqueue.
	 *
	 * @return void
	 */
	public function enqueue_style( string $name ): void;
}
