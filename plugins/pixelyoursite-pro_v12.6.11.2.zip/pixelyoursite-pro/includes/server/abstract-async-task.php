<?php
/**
 * Abstract Async Task Class
 *
 * Base class for all async task implementations (Facebook, TikTok, Pinterest)
 *
 * @package PixelYourSite
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Abstract class for async task handling
 */
abstract class AbstractAsyncTask extends \WP_Async_Task {

    /**
     * Get the server instance for this platform
     *
     * @return mixed Server instance (FacebookServer, TikTokServer, etc.)
     */
    abstract protected function getServerInstance();

    /**
     * Get allowed classes for unserialization
     *
     * @return array Array of allowed class names
     */
    protected function getAllowedClasses() {
        return [ 'stdClass' ];
    }

    /**
     * Prepare data for async processing
     *
     * Runs once per do_action() in the request. The payload is always
     * array( 'events' => array( $serverEvent, ... ) ), however many batches
     * were handed over.
     *
     * @param array $data Arguments of the action: array( $serverEvents )
     * @return array
     */
    protected function prepare_data( $data ) {
        $previous = isset( $this->_body_data['data'] ) ? [ 'data' => $this->_body_data['data'] ] : [];

        try {
            if ( empty( $data[0] ) || ! is_array( $data[0] ) ) {
                return $previous;
            }

            $events = array_merge( $this->decodeEvents( $previous['data'] ?? '' ), array_values( $data[0] ) );

            return [ 'data' => base64_encode( serialize( [ 'events' => $events ] ) ) ];
        } catch ( \Throwable $ex ) {
            error_log( $ex );
        }

        return $previous;
    }

    /**
     * Run the async action
     */
    protected function run_action() {
        try {
            $events = $this->decodeEvents( $_POST['data'] ?? '' );

            if ( empty( $events ) ) {
                return;
            }

            $server = $this->getServerInstance();
            foreach ( $events as $event ) {
                $server->sendAsyncTaskEvent( $event );
            }
        } catch ( \Throwable $ex ) {
            error_log( $ex );
        }
    }

    /**
     * Events of a payload built by prepare_data().
     *
     * @param mixed $payload base64 of a serialized array
     * @return array List of array( 'pixelIds' => ..., 'event' => ... )
     */
    private function decodeEvents( $payload ) {
        if ( ! is_string( $payload ) || '' === $payload ) {
            return [];
        }

        $data = @unserialize(
            (string) base64_decode( $payload ),
            [ 'allowed_classes' => $this->getAllowedClasses() ]
        );
        if ( ! is_array( $data ) ) {
            return [];
        }

        if ( array_key_exists( 'events', $data ) ) {
            return is_array( $data['events'] ) ? $data['events'] : [];
        }

        return self::legacyEvents( $data );
    }

    /**
     * Events of a payload posted by a version without the 'events' envelope:
     * one batch was array( $events ), two were a flat list of events, three
     * or more were the first event's fields mixed with later events.
     *
     * @param array $node
     * @return array
     */
    private static function legacyEvents( array $node ) {
        $events = [];

        if ( isset( $node['event'] ) ) {
            $events[] = array_filter( $node, 'is_string', ARRAY_FILTER_USE_KEY );
        }

        foreach ( $node as $key => $child ) {
            if ( is_int( $key ) && is_array( $child ) ) {
                $events = array_merge( $events, self::legacyEvents( $child ) );
            }
        }

        return $events;
    }
}

