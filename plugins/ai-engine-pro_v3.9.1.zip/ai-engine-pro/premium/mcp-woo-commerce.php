<?php

class MeowPro_MWAI_MCP_WooCommerce {
  private $core = null;

  #region Initialize
  public function __construct( $core ) {
    $this->core = $core;
    add_action( 'rest_api_init', [ $this, 'rest_api_init' ] );
  }

  public function rest_api_init() {
    add_filter( 'mwai_mcp_tools', [ $this, 'register_rest_tools' ] );
    add_filter( 'mwai_mcp_callback', [ $this, 'handle_call' ], 10, 4 );
    add_filter( 'mwai_mcp_undo_targets', [ $this, 'undo_targets' ], 10, 3 );
    add_filter( 'mwai_mcp_undo_kinds', [ $this, 'undo_kinds' ] );
  }
  #endregion

  #region Undo (labs/mcp-undo.php)
  // Products are restored through WooCommerce (lookup tables, stock status, price sync).
  // Order status changes have no capturer on purpose: they send emails and move stock, so
  // they are journaled as not undoable and reverted from the order screen.
  private const UNDO_PRODUCT_PROPS = [ 'name', 'status', 'description', 'short_description', 'sku',
    'regular_price', 'sale_price', 'stock_quantity', 'stock_status', 'manage_stock' ];

  public function undo_targets( $targets, string $tool, array $a ) {
    $product = function ( $id, array $props ) {
      return [ 'kind' => 'wc_product', 'id' => (int) $id, 'props' => array_values( $props ) ];
    };
    switch ( $tool ) {
      case 'wc_create_product':
        return [];
      case 'wc_update_product':
        $props = array_intersect( self::UNDO_PRODUCT_PROPS, array_keys( $a ) );
        return !empty( $a['id'] ) && $props ? [ $product( $a['id'], $props ) ] : null;
      case 'wc_alter_product':
        $field = (string) ( $a['field'] ?? '' );
        return !empty( $a['id'] ) && in_array( $field, [ 'name', 'description', 'short_description' ], true ) ? [ $product( $a['id'], [ $field ] ) ] : null;
      case 'wc_update_stock':
        return !empty( $a['product_id'] ) ? [ $product( $a['product_id'], [ 'stock_quantity', 'stock_status' ] ) ] : null;
      case 'wc_bulk_update_stock':
        $updates = is_string( $a['updates'] ?? null ) ? json_decode( $a['updates'], true ) : ( $a['updates'] ?? [] );
        $ids = array_filter( array_map( function ( $u ) { return (int) ( $u['product_id'] ?? 0 ); }, (array) $updates ) );
        return $ids ? array_map( function ( $id ) use ( $product ) {
          return $product( $id, [ 'stock_quantity', 'stock_status' ] );
        }, array_values( array_unique( $ids ) ) ) : null;
      case 'wc_delete_product':
      case 'wc_delete_coupon':
        return !empty( $a['id'] ) ? [ [ 'kind' => 'post', 'id' => (int) $a['id'], 'fields' => [ 'post_status' ] ] ] : null;
      case 'wc_save_coupon':
        // A new coupon is found by the creation hook; a change keeps the fields it touches.
        $fields = is_string( $a['fields'] ?? null ) ? json_decode( $a['fields'], true ) : ( $a['fields'] ?? [] );
        return !empty( $a['id'] ) ? [ [ 'kind' => 'wc_coupon', 'id' => (int) $a['id'], 'props' => array_keys( (array) $fields ) ] ] : [];
      case 'wc_save_variation':
        $fields = is_string( $a['fields'] ?? null ) ? json_decode( $a['fields'], true ) : ( $a['fields'] ?? [] );
        $props = array_keys( (array) $fields );
        if ( in_array( 'stock_quantity', $props, true ) ) {
          $props[] = 'manage_stock';
        }
        return !empty( $a['variation_id'] ) ? [ $product( $a['variation_id'], $props ) ] : [];
    }
    return $targets;
  }

  public function undo_kinds( array $kinds ): array {
    $kinds['wc_coupon'] = [
      'read' => function ( $t ) {
        $coupon = new WC_Coupon( (int) $t['id'] );
        if ( !$coupon->get_id() ) {
          return null;
        }
        $data = $coupon->get_data();
        $data['date_expires'] = $coupon->get_date_expires() ? $coupon->get_date_expires()->getTimestamp() : null;
        return array_intersect_key( $data, array_flip( $t['props'] ) );
      },
      'write' => function ( $t, $state ) {
        $coupon = new WC_Coupon( (int) $t['id'] );
        if ( !$coupon->get_id() ) {
          throw new Exception( "Coupon #{$t['id']} no longer exists." );
        }
        self::set_props( $coupon, (array) $state );
        $coupon->save();
      },
      'can' => function ( $t ) { return current_user_can( 'edit_post', (int) $t['id'] ); },
      'title' => function ( $t ) {
        $coupon = new WC_Coupon( (int) $t['id'] );
        return $coupon->get_id() ? 'Coupon ' . $coupon->get_code() : 'Coupon';
      },
    ];
    $kinds['wc_product'] = [
      'read' => function ( $t ) {
        $product = wc_get_product( (int) $t['id'] );
        return $product ? array_intersect_key( $product->get_data(), array_flip( $t['props'] ) ) : null;
      },
      'write' => function ( $t, $state ) {
        $product = wc_get_product( (int) $t['id'] );
        if ( !$product ) {
          throw new Exception( "Product #{$t['id']} no longer exists." );
        }
        self::set_props( $product, (array) $state );
        $product->save();
      },
      'can' => function ( $t ) { return current_user_can( 'edit_post', (int) $t['id'] ); },
      'title' => function ( $t ) { return Meow_MWAI_Labs_MCP_Undo::post_title( (int) $t['id'] ); },
    ];
    return $kinds;
  }
  #endregion

  #region Helpers
  private function empty_schema(): array {
    return [ 'type' => 'object', 'properties' => (object) [] ];
  }

  /**
   * Format product data for consistent output
   */
  private function format_product( $product ): array {
    if ( !$product || !is_a( $product, 'WC_Product' ) ) {
      return [];
    }

    return [
      'id' => $product->get_id(),
      'name' => $product->get_name(),
      'slug' => $product->get_slug(),
      'type' => $product->get_type(),
      'status' => $product->get_status(),
      'sku' => $product->get_sku(),
      'price' => $product->get_price(),
      'regular_price' => $product->get_regular_price(),
      'sale_price' => $product->get_sale_price(),
      'stock_status' => $product->get_stock_status(),
      'stock_quantity' => $product->get_stock_quantity(),
      'manage_stock' => $product->get_manage_stock(),
      'description' => $product->get_description(),
      'short_description' => $product->get_short_description(),
      'categories' => array_map( function ( $term ) {
        return [ 'id' => $term->term_id, 'name' => $term->name, 'slug' => $term->slug ];
      }, get_the_terms( $product->get_id(), 'product_cat' ) ?: [] ),
      'permalink' => $product->get_permalink(),
    ];
  }

  /**
   * Format order data for consistent output
   */
  private function format_order( $order ): array {
    if ( !$order || !is_a( $order, 'WC_Order' ) ) {
      return [];
    }

    $line_items = [];
    foreach ( $order->get_items() as $item ) {
      $line_items[] = [
        'id' => $item->get_id(),
        'name' => $item->get_name(),
        'product_id' => $item->get_product_id(),
        'quantity' => $item->get_quantity(),
        'total' => $item->get_total(),
      ];
    }

    return [
      'id' => $order->get_id(),
      'order_number' => $order->get_order_number(),
      'status' => $order->get_status(),
      'date_created' => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
      'total' => $order->get_total(),
      'currency' => $order->get_currency(),
      'customer_id' => $order->get_customer_id(),
      'billing' => [
        'first_name' => $order->get_billing_first_name(),
        'last_name' => $order->get_billing_last_name(),
        'email' => $order->get_billing_email(),
        'phone' => $order->get_billing_phone(),
      ],
      'line_items' => $line_items,
      'payment_method' => $order->get_payment_method_title(),
    ];
  }

  /**
   * Format customer data for consistent output
   */
  private function format_customer( $customer ): array {
    if ( !$customer || !is_a( $customer, 'WC_Customer' ) ) {
      return [];
    }

    return [
      'id' => $customer->get_id(),
      'email' => $customer->get_email(),
      'first_name' => $customer->get_first_name(),
      'last_name' => $customer->get_last_name(),
      'username' => $customer->get_username(),
      'billing' => [
        'first_name' => $customer->get_billing_first_name(),
        'last_name' => $customer->get_billing_last_name(),
        'company' => $customer->get_billing_company(),
        'address_1' => $customer->get_billing_address_1(),
        'city' => $customer->get_billing_city(),
        'state' => $customer->get_billing_state(),
        'postcode' => $customer->get_billing_postcode(),
        'country' => $customer->get_billing_country(),
        'email' => $customer->get_billing_email(),
        'phone' => $customer->get_billing_phone(),
      ],
      'total_spent' => wc_format_decimal( $customer->get_total_spent(), 2 ),
      'order_count' => $customer->get_order_count(),
    ];
  }
  #endregion

  #region Tools
  private function tools(): array {
    $tools = [

      /* ───────── TIER 1: Products ───────── */
      'wc_list_products' => [
        'name' => 'wc_list_products',
        'description' => 'List and search products with optional filters (status, stock_status, category, search term, limit, offset).',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'status' => [
              'type' => 'string',
              'description' => 'Product status: publish, draft, pending, or any.',
            ],
            'stock_status' => [
              'type' => 'string',
              'description' => 'Stock status filter: instock, outofstock, onbackorder.',
            ],
            'category' => [
              'type' => 'string',
              'description' => 'Category slug to filter by.',
            ],
            'search' => [
              'type' => 'string',
              'description' => 'Search term for product name or description.',
            ],
            'limit' => [
              'type' => 'integer',
              'description' => 'Maximum number of products to return (default: 20).',
            ],
            'offset' => [
              'type' => 'integer',
              'description' => 'Number of products to skip (for pagination).',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_get_product' => [
        'name' => 'wc_get_product',
        'description' => 'Get detailed information about a specific product by ID.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Product ID.',
            ],
          ],
          'required' => [ 'id' ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_create_product' => [
        'name' => 'wc_create_product',
        'description' => 'Create a new product with specified details.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'name' => [
              'type' => 'string',
              'description' => 'Product name.',
            ],
            'type' => [
              'type' => 'string',
              'description' => 'Product type: simple, variable, grouped, external (default: simple).',
            ],
            'status' => [
              'type' => 'string',
              'description' => 'Product status: publish, draft, pending (default: publish).',
            ],
            'description' => [
              'type' => 'string',
              'description' => 'Product description (full).',
            ],
            'short_description' => [
              'type' => 'string',
              'description' => 'Product short description.',
            ],
            'sku' => [
              'type' => 'string',
              'description' => 'Product SKU (Stock Keeping Unit).',
            ],
            'regular_price' => [
              'type' => 'string',
              'description' => 'Regular price.',
            ],
            'sale_price' => [
              'type' => 'string',
              'description' => 'Sale price.',
            ],
            'stock_quantity' => [
              'type' => 'integer',
              'description' => 'Stock quantity.',
            ],
            'manage_stock' => [
              'type' => 'boolean',
              'description' => 'Enable stock management (default: false).',
            ],
          ],
          'required' => [ 'name' ],
        ],
        'accessLevel' => 'write',
      ],

      'wc_update_product' => [
        'name' => 'wc_update_product',
        'description' => 'Update an existing product. Only provided fields will be updated.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Product ID.',
            ],
            'name' => [
              'type' => 'string',
              'description' => 'Product name.',
            ],
            'status' => [
              'type' => 'string',
              'description' => 'Product status: publish, draft, pending.',
            ],
            'description' => [
              'type' => 'string',
              'description' => 'Product description (full).',
            ],
            'short_description' => [
              'type' => 'string',
              'description' => 'Product short description.',
            ],
            'sku' => [
              'type' => 'string',
              'description' => 'Product SKU.',
            ],
            'regular_price' => [
              'type' => 'string',
              'description' => 'Regular price.',
            ],
            'sale_price' => [
              'type' => 'string',
              'description' => 'Sale price.',
            ],
            'stock_quantity' => [
              'type' => 'integer',
              'description' => 'Stock quantity.',
            ],
            'stock_status' => [
              'type' => 'string',
              'description' => 'Stock status: instock, outofstock, onbackorder.',
            ],
            'manage_stock' => [
              'type' => 'boolean',
              'description' => 'Enable stock management.',
            ],
          ],
          'required' => [ 'id' ],
        ],
        'accessLevel' => 'write',
      ],

      'wc_delete_product' => [
        'name' => 'wc_delete_product',
        'description' => 'Delete a product by ID. This action is permanent.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Product ID.',
            ],
            'force' => [
              'type' => 'boolean',
              'description' => 'Whether to bypass trash and permanently delete (default: false).',
            ],
          ],
          'required' => [ 'id' ],
        ],
        'accessLevel' => 'admin',
      ],

      'wc_alter_product' => [
        'name' => 'wc_alter_product',
        'description' => 'Search-and-replace inside a product field without re-uploading the entire content. Efficient for making small edits to long descriptions. Supports regex patterns (PHP-PCRE with delimiters like /pattern/i).',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Product ID.',
            ],
            'field' => [
              'type' => 'string',
              'description' => 'Field to modify: description, short_description, or name.',
            ],
            'search' => [
              'type' => 'string',
              'description' => 'Text or regex pattern to search for.',
            ],
            'replace' => [
              'type' => 'string',
              'description' => 'Replacement text.',
            ],
            'regex' => [
              'type' => 'boolean',
              'description' => 'Treat search as regex pattern (default: false).',
            ],
          ],
          'required' => [ 'id', 'field', 'search', 'replace' ],
        ],
        'accessLevel' => 'write',
      ],

      /* ───────── TIER 1: Orders ───────── */
      'wc_list_orders' => [
        'name' => 'wc_list_orders',
        'description' => 'List and search orders with optional filters (status, customer, date range, limit, offset).',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'status' => [
              'type' => 'string',
              'description' => 'Order status: pending, processing, on-hold, completed, cancelled, refunded, failed, or any.',
            ],
            'customer' => [
              'type' => 'integer',
              'description' => 'Customer ID to filter orders.',
            ],
            'date_after' => [
              'type' => 'string',
              'description' => 'Filter orders created after this date (YYYY-MM-DD format).',
            ],
            'date_before' => [
              'type' => 'string',
              'description' => 'Filter orders created before this date (YYYY-MM-DD format).',
            ],
            'limit' => [
              'type' => 'integer',
              'description' => 'Maximum number of orders to return (default: 20).',
            ],
            'offset' => [
              'type' => 'integer',
              'description' => 'Number of orders to skip (for pagination).',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_get_order' => [
        'name' => 'wc_get_order',
        'description' => 'Get detailed information about a specific order by ID, including line items and customer details.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Order ID.',
            ],
          ],
          'required' => [ 'id' ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_update_order_status' => [
        'name' => 'wc_update_order_status',
        'description' => 'Update the status of an order (e.g., mark as completed, processing, shipped).',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Order ID.',
            ],
            'status' => [
              'type' => 'string',
              'description' => 'New status: pending, processing, on-hold, completed, cancelled, refunded, failed.',
            ],
          ],
          'required' => [ 'id', 'status' ],
        ],
        'accessLevel' => 'write',
      ],

      'wc_add_order_note' => [
        'name' => 'wc_add_order_note',
        'description' => 'Add a note to an order. Notes can be private (internal) or customer-facing.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Order ID.',
            ],
            'note' => [
              'type' => 'string',
              'description' => 'Note content.',
            ],
            'customer_note' => [
              'type' => 'boolean',
              'description' => 'Whether the note is visible to the customer (default: false).',
            ],
          ],
          'required' => [ 'id', 'note' ],
        ],
        'accessLevel' => 'write',
      ],

      'wc_create_refund' => [
        'name' => 'wc_create_refund',
        'description' => 'Create a refund for an order. Can be full or partial refund.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'order_id' => [
              'type' => 'integer',
              'description' => 'Order ID to refund.',
            ],
            'amount' => [
              'type' => 'string',
              'description' => 'Refund amount (leave empty for full refund).',
            ],
            'reason' => [
              'type' => 'string',
              'description' => 'Reason for the refund.',
            ],
          ],
          'required' => [ 'order_id' ],
        ],
        'accessLevel' => 'admin',
      ],

      'wc_get_orders_by_customer' => [
        'name' => 'wc_get_orders_by_customer',
        'description' => 'Get all orders for a specific customer by customer ID or email.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'customer_id' => [
              'type' => 'integer',
              'description' => 'Customer ID.',
            ],
            'customer_email' => [
              'type' => 'string',
              'description' => 'Customer email address.',
            ],
            'limit' => [
              'type' => 'integer',
              'description' => 'Maximum number of orders to return (default: 20).',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      /* ───────── TIER 1: Inventory ───────── */
      'wc_update_stock' => [
        'name' => 'wc_update_stock',
        'description' => 'Update stock quantity for a specific product.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'product_id' => [
              'type' => 'integer',
              'description' => 'Product ID.',
            ],
            'quantity' => [
              'type' => 'integer',
              'description' => 'New stock quantity.',
            ],
          ],
          'required' => [ 'product_id', 'quantity' ],
        ],
        'accessLevel' => 'write',
      ],

      /* ───────── TIER 2: Analytics ───────── */
      'wc_get_sales_report' => [
        'name' => 'wc_get_sales_report',
        'description' => 'Get sales report data for a specific date range.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'date_after' => [
              'type' => 'string',
              'description' => 'Start date (YYYY-MM-DD format). Default: 30 days ago.',
            ],
            'date_before' => [
              'type' => 'string',
              'description' => 'End date (YYYY-MM-DD format). Default: today.',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_get_top_sellers' => [
        'name' => 'wc_get_top_sellers',
        'description' => 'Get best-selling products for a specific period.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'limit' => [
              'type' => 'integer',
              'description' => 'Number of top sellers to return (default: 10).',
            ],
            'date_after' => [
              'type' => 'string',
              'description' => 'Start date (YYYY-MM-DD format). Default: 30 days ago.',
            ],
            'date_before' => [
              'type' => 'string',
              'description' => 'End date (YYYY-MM-DD format). Default: today.',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_get_revenue_stats' => [
        'name' => 'wc_get_revenue_stats',
        'description' => 'Get revenue statistics including total sales, net sales, average order value.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'date_after' => [
              'type' => 'string',
              'description' => 'Start date (YYYY-MM-DD format). Default: 30 days ago.',
            ],
            'date_before' => [
              'type' => 'string',
              'description' => 'End date (YYYY-MM-DD format). Default: today.',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_get_low_stock_products' => [
        'name' => 'wc_get_low_stock_products',
        'description' => 'Get products with stock below a specified threshold.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'threshold' => [
              'type' => 'integer',
              'description' => 'Stock threshold (default: 5).',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_get_stock_report' => [
        'name' => 'wc_get_stock_report',
        'description' => 'Get comprehensive stock report showing in-stock, out-of-stock, and low-stock products.',
        'inputSchema' => $this->empty_schema(),
        'accessLevel' => 'read',
      ],

      'wc_bulk_update_stock' => [
        'name' => 'wc_bulk_update_stock',
        'description' => 'Update stock quantities for multiple products at once. Provide an array of product updates.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'updates' => [
              'type' => 'array',
              'description' => 'Array of objects with product_id and quantity fields.',
              'items' => [
                'type' => 'object',
                'properties' => [
                  'product_id' => [ 'type' => 'integer' ],
                  'quantity' => [ 'type' => 'integer' ],
                ],
              ],
            ],
          ],
          'required' => [ 'updates' ],
        ],
        'accessLevel' => 'write',
      ],

      /* ───────── TIER 2: Customers ───────── */
      'wc_list_customers' => [
        'name' => 'wc_list_customers',
        'description' => 'List customers with optional search and filters.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'search' => [
              'type' => 'string',
              'description' => 'Search term for customer name or email.',
            ],
            'limit' => [
              'type' => 'integer',
              'description' => 'Maximum number of customers to return (default: 20).',
            ],
            'offset' => [
              'type' => 'integer',
              'description' => 'Number of customers to skip (for pagination).',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_get_customer' => [
        'name' => 'wc_get_customer',
        'description' => 'Get detailed customer information including order history and total spent.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Customer ID.',
            ],
          ],
          'required' => [ 'id' ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_update_customer' => [
        'name' => 'wc_update_customer',
        'description' => 'Update customer information.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [
              'type' => 'integer',
              'description' => 'Customer ID.',
            ],
            'email' => [
              'type' => 'string',
              'description' => 'Customer email.',
            ],
            'first_name' => [
              'type' => 'string',
              'description' => 'First name.',
            ],
            'last_name' => [
              'type' => 'string',
              'description' => 'Last name.',
            ],
          ],
          'required' => [ 'id' ],
        ],
        'accessLevel' => 'write',
      ],

      /* ───────── TIER 2: Reviews ───────── */
      'wc_list_reviews' => [
        'name' => 'wc_list_reviews',
        'description' => 'List product reviews with optional filters (status, product_id).',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'status' => [
              'type' => 'string',
              'description' => 'Review status: approve, hold, spam, or all (default: approve).',
            ],
            'product_id' => [
              'type' => 'integer',
              'description' => 'Filter reviews by product ID.',
            ],
            'limit' => [
              'type' => 'integer',
              'description' => 'Maximum number of reviews to return (default: 20).',
            ],
          ],
        ],
        'accessLevel' => 'read',
      ],

      'wc_approve_review' => [
        'name' => 'wc_approve_review',
        'description' => 'Approve a pending product review.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'review_id' => [
              'type' => 'integer',
              'description' => 'Review/comment ID.',
            ],
          ],
          'required' => [ 'review_id' ],
        ],
        'accessLevel' => 'write',
      ],

      'wc_delete_review' => [
        'name' => 'wc_delete_review',
        'description' => 'Delete a product review (spam or inappropriate content).',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'review_id' => [
              'type' => 'integer',
              'description' => 'Review/comment ID.',
            ],
          ],
          'required' => [ 'review_id' ],
        ],
        'accessLevel' => 'admin',
      ],

      /* ───────── Coupons and variations ───────── */
      'wc_list_coupons' => [
        'name' => 'wc_list_coupons',
        'description' => 'List coupons: code, discount type and amount, usage so far and limits, expiry, minimum spend, free shipping, restrictions. Pass search to find a code.',
        'inputSchema' => [ 'type' => 'object', 'properties' => [
          'search' => [ 'type' => 'string', 'description' => 'Part of a coupon code.' ],
          'limit' => [ 'type' => 'integer', 'description' => 'Max coupons (default 30).' ],
        ] ],
        'accessLevel' => 'read',
      ],
      'wc_save_coupon' => [
        'name' => 'wc_save_coupon',
        'description' => 'Create a coupon, or change one (pass its id). Fields: code, discount_type (percent, fixed_cart or fixed_product), amount, description, date_expires (YYYY-MM-DD, or null for never), usage_limit, usage_limit_per_user, minimum_amount, maximum_amount, individual_use, free_shipping, exclude_sale_items, product_ids, excluded_product_ids, email_restrictions. Can be undone with mcp_undo_change.',
        'inputSchema' => [ 'type' => 'object', 'properties' => [
          'id' => [ 'type' => 'integer', 'description' => 'The coupon to change; omit to create one.' ],
          'fields' => [ 'type' => 'object', 'additionalProperties' => true, 'description' => 'The coupon fields to set.' ],
        ], 'required' => [ 'fields' ] ],
        'accessLevel' => 'write',
      ],
      'wc_delete_coupon' => [
        'name' => 'wc_delete_coupon',
        'description' => 'Move a coupon to the trash, so it stops working. It can be undone with mcp_undo_change.',
        'inputSchema' => [ 'type' => 'object', 'properties' => [
          'id' => [ 'type' => 'integer', 'description' => 'The coupon ID.' ],
        ], 'required' => [ 'id' ] ],
        'accessLevel' => 'write',
      ],
      'wc_list_variations' => [
        'name' => 'wc_list_variations',
        'description' => 'For a variable product: its attributes (e.g. Size: S, M, L) and every variation with its attributes, SKU, prices, stock and status.',
        'inputSchema' => [ 'type' => 'object', 'properties' => [
          'product_id' => [ 'type' => 'integer', 'description' => 'The variable product ID.' ],
        ], 'required' => [ 'product_id' ] ],
        'accessLevel' => 'read',
      ],
      'wc_set_product_attributes' => [
        'name' => 'wc_set_product_attributes',
        'description' => 'Set the attributes a product varies by, which turns it into a variable product: "attributes" is a list of {"name": "Size", "options": ["S", "M", "L"]}. Existing variations are kept. Then create the variations with wc_save_variation.',
        'inputSchema' => [ 'type' => 'object', 'properties' => [
          'product_id' => [ 'type' => 'integer' ],
          'attributes' => [ 'type' => 'array', 'items' => [ 'type' => 'object', 'additionalProperties' => true ] ],
        ], 'required' => [ 'product_id', 'attributes' ] ],
        'accessLevel' => 'write',
      ],
      'wc_save_variation' => [
        'name' => 'wc_save_variation',
        'description' => 'Create a variation of a variable product, or change one (pass variation_id). "attributes" picks the options it stands for, e.g. {"Size": "M"} (create only). Fields: regular_price, sale_price, sku, stock_quantity (turns stock management on), stock_status, status (publish or private to disable), description, weight, image_id. Can be undone with mcp_undo_change.',
        'inputSchema' => [ 'type' => 'object', 'properties' => [
          'product_id' => [ 'type' => 'integer', 'description' => 'The variable product.' ],
          'variation_id' => [ 'type' => 'integer', 'description' => 'The variation to change; omit to create one.' ],
          'attributes' => [ 'type' => 'object', 'additionalProperties' => true ],
          'fields' => [ 'type' => 'object', 'additionalProperties' => true ],
        ], 'required' => [ 'product_id' ] ],
        'accessLevel' => 'write',
      ],
    ];
    if ( $this->has_subscriptions() ) {
      $tools = array_merge( $tools, $this->subscription_tools() );
    }
    return $tools;
  }

  /* ───────── WooCommerce Subscriptions (read-only, only when the plugin is active) ───────── */
  private function subscription_tools(): array {
    $date = [ 'type' => 'string', 'description' => 'YYYY-MM-DD.' ];
    $limit = [ 'type' => 'integer', 'description' => 'Maximum results, 1 to 100 (default 20).' ];
    $offset = [ 'type' => 'integer', 'description' => 'Results to skip, for paging.' ];
    return [
      'wc_list_subscriptions' => [
        'name' => 'wc_list_subscriptions',
        'description' => 'List WooCommerce Subscriptions with status, customer, billing email, total, billing period, start, next payment, last order and end dates (site timezone). Filter by status, customer (ID or email), product, or a next payment date range. Use wc_get_subscription for renewal orders and failed payments, and wc_get_overdue_subscriptions for unpaid ones.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'status' => [ 'type' => 'string', 'description' => 'active, on-hold, pending, pending-cancel, cancelled, expired, switched, or any (default). Several: a comma-separated list.' ],
            'customer_id' => [ 'type' => 'integer', 'description' => 'Customer user ID.' ],
            'customer_email' => [ 'type' => 'string', 'description' => 'Customer account email. Ignored if customer_id is set.' ],
            'product_id' => [ 'type' => 'integer', 'description' => 'Only subscriptions containing this product.' ],
            'next_payment_after' => $date,
            'next_payment_before' => $date,
            'limit' => $limit,
            'offset' => $offset,
          ],
        ],
        'accessLevel' => 'read',
      ],
      'wc_get_subscription' => [
        'name' => 'wc_get_subscription',
        'description' => 'Get one subscription in full: status, dates (start, trial end, next payment, last order, end), items, payment method, failed payment count, and its related orders (parent, renewals, switches, resubscribes) with each order\'s status, total and paid date, newest first.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'id' => [ 'type' => 'integer', 'description' => 'Subscription ID.' ],
          ],
          'required' => [ 'id' ],
        ],
        'accessLevel' => 'read',
      ],
      'wc_get_overdue_subscriptions' => [
        'name' => 'wc_get_overdue_subscriptions',
        'description' => 'Find subscriptions whose payment is overdue: on-hold ones (a renewal is unpaid or failed), and active ones whose next payment date has passed by more than grace_hours. Each comes with the reason, days overdue, failed payment count and the latest renewal order.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'grace_hours' => [ 'type' => 'integer', 'description' => 'Hours past the next payment date before an active subscription counts as overdue (default 24), since renewals run on a schedule.' ],
            'limit' => [ 'type' => 'integer', 'description' => 'Maximum results, 1 to 100 (default 50).' ],
            'offset' => $offset,
          ],
        ],
        'accessLevel' => 'read',
      ],
      'wc_list_failed_renewals' => [
        'name' => 'wc_list_failed_renewals',
        'description' => 'List subscription renewal orders that were not paid, newest first, with the subscriptions they belong to. Status: failed (default), pending, on-hold, or unpaid (all three). Optional date range on the order creation date.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'status' => [ 'type' => 'string', 'description' => 'failed (default), pending, on-hold, or unpaid.' ],
            'date_after' => $date,
            'date_before' => $date,
            'limit' => $limit,
            'offset' => $offset,
          ],
        ],
        'accessLevel' => 'read',
      ],
    ];
  }
  #endregion

  #region Register
  public function register_rest_tools( array $prev ): array {
    $tools = $this->tools();

    // Add category and annotations to each tool
    foreach ( $tools as &$tool ) {
      if ( !isset( $tool['category'] ) ) {
        $tool['category'] = 'AI Engine (WooCommerce)';
      }

      // Add MCP tool annotations
      if ( !isset( $tool['annotations'] ) ) {
        $name = $tool['name'];

        // Read-only tools
        $is_readonly = (
          strpos( $name, '_list_' ) !== false ||
          strpos( $name, '_get_' ) !== false
        );

        // Destructive tools
        $is_destructive = (
          strpos( $name, '_delete_' ) !== false ||
          strpos( $name, '_refund' ) !== false
        );

        $tool['annotations'] = [
          'readOnlyHint' => $is_readonly,
          'destructiveHint' => !$is_readonly && $is_destructive,
          'openWorldHint' => false,
        ];
      }
    }

    $merged = array_merge( $prev, array_values( $tools ) );
    return $merged;
  }
  #endregion

  #region Callback
  public function handle_call( $prev, string $tool, array $args, int|string|null $id ) {
    if ( !empty( $prev ) || !isset( $this->tools()[ $tool ] ) ) {
      return $prev;
    }
    // These tools act on the whole site, so they refuse rather than run as another user.
    if ( !current_user_can( 'manage_woocommerce' ) ) {
      throw new Exception( 'This tool needs an account that can manage WooCommerce.', Meow_MWAI_Labs_MCP::DENIED_CODE );
    }
    return $this->dispatch( $tool, $args );
  }
  #endregion

  #region Dispatcher
  private function dispatch( string $tool, array $a ) {

    switch ( $tool ) {

      /* ───────── Products ───────── */
      case 'wc_list_products':
        $args = [
          'limit' => isset( $a['limit'] ) ? absint( $a['limit'] ) : 20,
          'offset' => isset( $a['offset'] ) ? absint( $a['offset'] ) : 0,
          'return' => 'objects',
        ];

        if ( !empty( $a['status'] ) ) {
          $args['status'] = sanitize_text_field( $a['status'] );
        }
        if ( !empty( $a['stock_status'] ) ) {
          $args['stock_status'] = sanitize_text_field( $a['stock_status'] );
        }
        if ( !empty( $a['category'] ) ) {
          $args['category'] = [ sanitize_text_field( $a['category'] ) ];
        }
        if ( !empty( $a['search'] ) ) {
          $args['s'] = sanitize_text_field( $a['search'] );
        }

        $products = wc_get_products( $args );
        $result = array_map( [ $this, 'format_product' ], $products );

        return [
          'total' => count( $result ),
          'products' => $result,
        ];

      case 'wc_get_product':
        $product_id = absint( $a['id'] ?? 0 );
        if ( !$product_id ) {
          throw new Exception( 'Product ID is required.' );
        }

        $product = wc_get_product( $product_id );
        if ( !$product ) {
          throw new Exception( 'Product not found.' );
        }

        return $this->format_product( $product );

      case 'wc_create_product':
        $name = sanitize_text_field( $a['name'] ?? '' );
        if ( empty( $name ) ) {
          throw new Exception( 'Product name is required.' );
        }

        $type = sanitize_text_field( $a['type'] ?? 'simple' );
        $product = new WC_Product_Simple();
        $product->set_name( $name );
        $product->set_status( sanitize_text_field( $a['status'] ?? 'publish' ) );

        if ( !empty( $a['description'] ) ) {
          $product->set_description( wp_kses_post( $a['description'] ) );
        }
        if ( !empty( $a['short_description'] ) ) {
          $product->set_short_description( wp_kses_post( $a['short_description'] ) );
        }
        if ( !empty( $a['sku'] ) ) {
          $product->set_sku( sanitize_text_field( $a['sku'] ) );
        }
        if ( isset( $a['regular_price'] ) ) {
          $product->set_regular_price( sanitize_text_field( $a['regular_price'] ) );
        }
        if ( isset( $a['sale_price'] ) ) {
          $product->set_sale_price( sanitize_text_field( $a['sale_price'] ) );
        }
        if ( isset( $a['stock_quantity'] ) ) {
          $product->set_stock_quantity( absint( $a['stock_quantity'] ) );
        }
        if ( isset( $a['manage_stock'] ) ) {
          $product->set_manage_stock( (bool) $a['manage_stock'] );
        }

        $product_id = $product->save();

        return [
          'id' => $product_id,
          'message' => 'Product created successfully.',
        ];

      case 'wc_update_product':
        $product_id = absint( $a['id'] ?? 0 );
        if ( !$product_id ) {
          throw new Exception( 'Product ID is required.' );
        }

        $product = wc_get_product( $product_id );
        if ( !$product ) {
          throw new Exception( 'Product not found.' );
        }

        if ( isset( $a['name'] ) ) {
          $product->set_name( sanitize_text_field( $a['name'] ) );
        }
        if ( isset( $a['status'] ) ) {
          $product->set_status( sanitize_text_field( $a['status'] ) );
        }
        if ( isset( $a['description'] ) ) {
          $product->set_description( wp_kses_post( $a['description'] ) );
        }
        if ( isset( $a['short_description'] ) ) {
          $product->set_short_description( wp_kses_post( $a['short_description'] ) );
        }
        if ( isset( $a['sku'] ) ) {
          $product->set_sku( sanitize_text_field( $a['sku'] ) );
        }
        if ( isset( $a['regular_price'] ) ) {
          $product->set_regular_price( sanitize_text_field( $a['regular_price'] ) );
        }
        if ( isset( $a['sale_price'] ) ) {
          $product->set_sale_price( sanitize_text_field( $a['sale_price'] ) );
        }
        if ( isset( $a['stock_quantity'] ) ) {
          $product->set_stock_quantity( absint( $a['stock_quantity'] ) );
        }
        if ( isset( $a['stock_status'] ) ) {
          $product->set_stock_status( sanitize_text_field( $a['stock_status'] ) );
        }
        if ( isset( $a['manage_stock'] ) ) {
          $product->set_manage_stock( (bool) $a['manage_stock'] );
        }

        $product->save();

        return [
          'id' => $product_id,
          'message' => 'Product updated successfully.',
        ];

      case 'wc_delete_product':
        $product_id = absint( $a['id'] ?? 0 );
        if ( !$product_id ) {
          throw new Exception( 'Product ID is required.' );
        }

        $product = wc_get_product( $product_id );
        if ( !$product ) {
          throw new Exception( 'Product not found.' );
        }

        $force = (bool) ( $a['force'] ?? false );
        $product->delete( $force );

        return [
          'id' => $product_id,
          'message' => $force ? 'Product permanently deleted.' : 'Product moved to trash.',
        ];

      case 'wc_alter_product':
        $product_id = absint( $a['id'] ?? 0 );
        $field = sanitize_key( $a['field'] ?? '' );
        $search = $a['search'] ?? null;
        $replace = $a['replace'] ?? '';
        $is_regex = (bool) ( $a['regex'] ?? false );

        if ( !$product_id || !$field || $search === null ) {
          throw new Exception( 'Product ID, field, search, and replace are required.' );
        }

        // Map field names to WooCommerce getter/setter methods
        $field_map = [
          'description' => [ 'get_description', 'set_description' ],
          'short_description' => [ 'get_short_description', 'set_short_description' ],
          'name' => [ 'get_name', 'set_name' ],
        ];

        if ( !isset( $field_map[ $field ] ) ) {
          throw new Exception( 'Field must be: description, short_description, or name.' );
        }

        $product = wc_get_product( $product_id );
        if ( !$product ) {
          throw new Exception( 'Product not found.' );
        }

        $getter = $field_map[ $field ][0];
        $setter = $field_map[ $field ][1];
        $content = $product->$getter();
        $count = 0;

        if ( $is_regex ) {
          // Validate regex pattern
          set_error_handler( fn () => false );
          $test = preg_match( $search, '' );
          restore_error_handler();
          if ( $test === false ) {
            throw new Exception( 'Invalid regex pattern.' );
          }
          $new_content = preg_replace( $search, $replace, $content, -1, $count );
          if ( $new_content === null ) {
            throw new Exception( 'Regex error.' );
          }
        }
        else {
          $new_content = str_replace( $search, $replace, $content, $count );
        }

        if ( $count === 0 ) {
          return [
            'id' => $product_id,
            'replacements' => 0,
            'message' => 'No occurrences found; product unchanged.',
          ];
        }

        $product->$setter( $new_content );
        $product->save();

        return [
          'id' => $product_id,
          'field' => $field,
          'replacements' => $count,
          'message' => $count . ' replacement' . ( $count === 1 ? '' : 's' ) . ' applied.',
        ];

        /* ───────── Orders ───────── */
      case 'wc_list_orders':
        $args = [
          'limit' => isset( $a['limit'] ) ? absint( $a['limit'] ) : 20,
          'offset' => isset( $a['offset'] ) ? absint( $a['offset'] ) : 0,
          'return' => 'objects',
        ];

        if ( !empty( $a['status'] ) ) {
          $args['status'] = sanitize_text_field( $a['status'] );
        }
        if ( !empty( $a['customer'] ) ) {
          $args['customer'] = absint( $a['customer'] );
        }
        if ( !empty( $a['date_after'] ) ) {
          $args['date_created'] = '>=' . sanitize_text_field( $a['date_after'] );
        }
        if ( !empty( $a['date_before'] ) ) {
          $args['date_created'] = '<=' . sanitize_text_field( $a['date_before'] );
        }

        $orders = wc_get_orders( $args );
        $result = array_map( [ $this, 'format_order' ], $orders );

        return [
          'total' => count( $result ),
          'orders' => $result,
        ];

      case 'wc_get_order':
        $order_id = absint( $a['id'] ?? 0 );
        if ( !$order_id ) {
          throw new Exception( 'Order ID is required.' );
        }

        $order = wc_get_order( $order_id );
        if ( !$order ) {
          throw new Exception( 'Order not found.' );
        }

        return $this->format_order( $order );

      case 'wc_update_order_status':
        $order_id = absint( $a['id'] ?? 0 );
        $status = sanitize_text_field( $a['status'] ?? '' );

        if ( !$order_id || !$status ) {
          throw new Exception( 'Order ID and status are required.' );
        }

        $order = wc_get_order( $order_id );
        if ( !$order ) {
          throw new Exception( 'Order not found.' );
        }

        // Remove wc- prefix if provided
        $status = str_replace( 'wc-', '', $status );
        $order->update_status( $status );

        return [
          'id' => $order_id,
          'status' => $order->get_status(),
          'message' => 'Order status updated successfully.',
        ];

      case 'wc_add_order_note':
        $order_id = absint( $a['id'] ?? 0 );
        $note = sanitize_textarea_field( $a['note'] ?? '' );

        if ( !$order_id || !$note ) {
          throw new Exception( 'Order ID and note are required.' );
        }

        $order = wc_get_order( $order_id );
        if ( !$order ) {
          throw new Exception( 'Order not found.' );
        }

        $customer_note = (bool) ( $a['customer_note'] ?? false );
        $note_id = $order->add_order_note( $note, $customer_note ? 1 : 0 );

        return [
          'id' => $order_id,
          'note_id' => $note_id,
          'message' => 'Order note added successfully.',
        ];

      case 'wc_create_refund':
        $order_id = absint( $a['order_id'] ?? 0 );
        if ( !$order_id ) {
          throw new Exception( 'Order ID is required.' );
        }

        $order = wc_get_order( $order_id );
        if ( !$order ) {
          throw new Exception( 'Order not found.' );
        }

        $amount = isset( $a['amount'] ) ? sanitize_text_field( $a['amount'] ) : $order->get_total();
        $reason = sanitize_text_field( $a['reason'] ?? '' );

        $refund = wc_create_refund( [
          'order_id' => $order_id,
          'amount' => $amount,
          'reason' => $reason,
        ] );

        if ( is_wp_error( $refund ) ) {
          throw new Exception( $refund->get_error_message() );
        }

        return [
          'order_id' => $order_id,
          'refund_id' => $refund->get_id(),
          'amount' => $amount,
          'message' => 'Refund created successfully.',
        ];

      case 'wc_get_orders_by_customer':
        $customer_id = isset( $a['customer_id'] ) ? absint( $a['customer_id'] ) : 0;
        $customer_email = isset( $a['customer_email'] ) ? sanitize_email( $a['customer_email'] ) : '';

        if ( !$customer_id && !$customer_email ) {
          throw new Exception( 'Customer ID or email is required.' );
        }

        $args = [
          'limit' => isset( $a['limit'] ) ? absint( $a['limit'] ) : 20,
          'return' => 'objects',
        ];

        if ( $customer_id ) {
          $args['customer'] = $customer_id;
        }
        elseif ( $customer_email ) {
          $args['billing_email'] = $customer_email;
        }

        $orders = wc_get_orders( $args );
        $result = array_map( [ $this, 'format_order' ], $orders );

        return [
          'total' => count( $result ),
          'orders' => $result,
        ];

        /* ───────── Inventory ───────── */
      case 'wc_update_stock':
        $product_id = absint( $a['product_id'] ?? 0 );
        $quantity = isset( $a['quantity'] ) ? absint( $a['quantity'] ) : null;

        if ( !$product_id || $quantity === null ) {
          throw new Exception( 'Product ID and quantity are required.' );
        }

        $product = wc_get_product( $product_id );
        if ( !$product ) {
          throw new Exception( 'Product not found.' );
        }

        $product->set_stock_quantity( $quantity );
        $product->save();

        return [
          'product_id' => $product_id,
          'stock_quantity' => $product->get_stock_quantity(),
          'message' => 'Stock updated successfully.',
        ];

        /* ───────── Analytics ───────── */
      case 'wc_get_sales_report':
        $date_after = isset( $a['date_after'] ) ? sanitize_text_field( $a['date_after'] ) : date( 'Y-m-d', strtotime( '-30 days' ) );
        $date_before = isset( $a['date_before'] ) ? sanitize_text_field( $a['date_before'] ) : date( 'Y-m-d' );

        $orders = wc_get_orders( [
          'limit' => -1,
          'status' => [ 'completed', 'processing' ],
          'date_created' => $date_after . '...' . $date_before,
          'return' => 'objects',
        ] );

        $total_sales = 0;
        $order_count = count( $orders );

        foreach ( $orders as $order ) {
          $total_sales += $order->get_total();
        }

        $avg_order_value = $order_count > 0 ? $total_sales / $order_count : 0;

        return [
          'period' => [
            'from' => $date_after,
            'to' => $date_before,
          ],
          'total_sales' => wc_format_decimal( $total_sales, 2 ),
          'order_count' => $order_count,
          'average_order_value' => wc_format_decimal( $avg_order_value, 2 ),
        ];

      case 'wc_get_top_sellers':
        $limit = isset( $a['limit'] ) ? absint( $a['limit'] ) : 10;
        $date_after = isset( $a['date_after'] ) ? sanitize_text_field( $a['date_after'] ) : date( 'Y-m-d', strtotime( '-30 days' ) );
        $date_before = isset( $a['date_before'] ) ? sanitize_text_field( $a['date_before'] ) : date( 'Y-m-d' );

        global $wpdb;

        $query = $wpdb->prepare(
          "SELECT
            oim.meta_value as product_id,
            SUM( oim2.meta_value ) as qty
          FROM {$wpdb->prefix}woocommerce_order_items oi
          LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id
          LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2 ON oi.order_item_id = oim2.order_item_id
          LEFT JOIN {$wpdb->posts} orders ON oi.order_id = orders.ID
          WHERE
            orders.post_type = 'shop_order'
            AND orders.post_status IN ('wc-completed', 'wc-processing')
            AND orders.post_date >= %s
            AND orders.post_date <= %s
            AND oim.meta_key = '_product_id'
            AND oim2.meta_key = '_qty'
          GROUP BY product_id
          ORDER BY qty DESC
          LIMIT %d",
          $date_after . ' 00:00:00',
          $date_before . ' 23:59:59',
          $limit
        );

        $results = $wpdb->get_results( $query );
        $top_sellers = [];

        foreach ( $results as $result ) {
          $product = wc_get_product( $result->product_id );
          if ( $product ) {
            $top_sellers[] = [
              'product_id' => $result->product_id,
              'name' => $product->get_name(),
              'quantity_sold' => absint( $result->qty ),
            ];
          }
        }

        return [
          'period' => [
            'from' => $date_after,
            'to' => $date_before,
          ],
          'top_sellers' => $top_sellers,
        ];

      case 'wc_get_revenue_stats':
        $date_after = isset( $a['date_after'] ) ? sanitize_text_field( $a['date_after'] ) : date( 'Y-m-d', strtotime( '-30 days' ) );
        $date_before = isset( $a['date_before'] ) ? sanitize_text_field( $a['date_before'] ) : date( 'Y-m-d' );

        $orders = wc_get_orders( [
          'limit' => -1,
          'status' => [ 'completed', 'processing' ],
          'date_created' => $date_after . '...' . $date_before,
          'return' => 'objects',
        ] );

        $total_sales = 0;
        $total_refunds = 0;
        $order_count = count( $orders );

        foreach ( $orders as $order ) {
          $total_sales += $order->get_total();
          $total_refunds += $order->get_total_refunded();
        }

        $net_sales = $total_sales - $total_refunds;
        $avg_order_value = $order_count > 0 ? $net_sales / $order_count : 0;

        return [
          'period' => [
            'from' => $date_after,
            'to' => $date_before,
          ],
          'total_sales' => wc_format_decimal( $total_sales, 2 ),
          'total_refunds' => wc_format_decimal( $total_refunds, 2 ),
          'net_sales' => wc_format_decimal( $net_sales, 2 ),
          'order_count' => $order_count,
          'average_order_value' => wc_format_decimal( $avg_order_value, 2 ),
        ];

      case 'wc_get_low_stock_products':
        $threshold = isset( $a['threshold'] ) ? absint( $a['threshold'] ) : 5;

        $args = [
          'limit' => -1,
          'stock_status' => 'instock',
          'return' => 'objects',
        ];

        $products = wc_get_products( $args );
        $low_stock = [];

        foreach ( $products as $product ) {
          if ( $product->managing_stock() ) {
            $stock_qty = $product->get_stock_quantity();
            if ( $stock_qty !== null && $stock_qty <= $threshold ) {
              $low_stock[] = [
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'sku' => $product->get_sku(),
                'stock_quantity' => $stock_qty,
              ];
            }
          }
        }

        return [
          'threshold' => $threshold,
          'total' => count( $low_stock ),
          'products' => $low_stock,
        ];

      case 'wc_get_stock_report':
        $products = wc_get_products( [ 'limit' => -1, 'return' => 'objects' ] );

        $in_stock = 0;
        $out_of_stock = 0;
        $on_backorder = 0;
        $low_stock = 0;

        foreach ( $products as $product ) {
          $stock_status = $product->get_stock_status();

          if ( $stock_status === 'instock' ) {
            $in_stock++;
            if ( $product->managing_stock() && $product->get_stock_quantity() !== null && $product->get_stock_quantity() <= 5 ) {
              $low_stock++;
            }
          }
          elseif ( $stock_status === 'outofstock' ) {
            $out_of_stock++;
          }
          elseif ( $stock_status === 'onbackorder' ) {
            $on_backorder++;
          }
        }

        return [
          'total_products' => count( $products ),
          'in_stock' => $in_stock,
          'out_of_stock' => $out_of_stock,
          'on_backorder' => $on_backorder,
          'low_stock' => $low_stock,
        ];

      case 'wc_bulk_update_stock':
        if ( empty( $a['updates'] ) || !is_array( $a['updates'] ) ) {
          throw new Exception( 'Updates array is required.' );
        }

        $results = [];
        foreach ( $a['updates'] as $update ) {
          $product_id = absint( $update['product_id'] ?? 0 );
          $quantity = isset( $update['quantity'] ) ? absint( $update['quantity'] ) : null;

          if ( !$product_id || $quantity === null ) {
            $results[] = [
              'product_id' => $product_id,
              'success' => false,
              'message' => 'Invalid product ID or quantity.',
            ];
            continue;
          }

          $product = wc_get_product( $product_id );
          if ( !$product ) {
            $results[] = [
              'product_id' => $product_id,
              'success' => false,
              'message' => 'Product not found.',
            ];
            continue;
          }

          $product->set_stock_quantity( $quantity );
          $product->save();

          $results[] = [
            'product_id' => $product_id,
            'success' => true,
            'stock_quantity' => $product->get_stock_quantity(),
          ];
        }

        return [
          'total_updated' => count( array_filter( $results, fn ( $r ) => $r['success'] ) ),
          'results' => $results,
        ];

        /* ───────── Customers ───────── */
      case 'wc_list_customers':
        $args = [
          'role' => 'customer',
          'number' => isset( $a['limit'] ) ? absint( $a['limit'] ) : 20,
          'offset' => isset( $a['offset'] ) ? absint( $a['offset'] ) : 0,
        ];

        if ( !empty( $a['search'] ) ) {
          $args['search'] = '*' . sanitize_text_field( $a['search'] ) . '*';
        }

        $user_query = new WP_User_Query( $args );
        $users = $user_query->get_results();
        $customers = [];

        foreach ( $users as $user ) {
          $customer = new WC_Customer( $user->ID );
          $customers[] = $this->format_customer( $customer );
        }

        return [
          'total' => count( $customers ),
          'customers' => $customers,
        ];

      case 'wc_get_customer':
        $customer_id = absint( $a['id'] ?? 0 );
        if ( !$customer_id ) {
          throw new Exception( 'Customer ID is required.' );
        }

        $customer = new WC_Customer( $customer_id );
        if ( !$customer->get_id() ) {
          throw new Exception( 'Customer not found.' );
        }

        return $this->format_customer( $customer );

      case 'wc_update_customer':
        $customer_id = absint( $a['id'] ?? 0 );
        if ( !$customer_id ) {
          throw new Exception( 'Customer ID is required.' );
        }

        $customer = new WC_Customer( $customer_id );
        if ( !$customer->get_id() ) {
          throw new Exception( 'Customer not found.' );
        }
        // A customer ID is any user ID: without this a Shop Manager could change an
        // administrator's email and take the account over with a password reset.
        if ( !current_user_can( 'edit_user', $customer_id ) ) {
          throw new Exception( 'You are not allowed to edit this user.', Meow_MWAI_Labs_MCP::DENIED_CODE );
        }

        if ( isset( $a['email'] ) ) {
          $customer->set_email( sanitize_email( $a['email'] ) );
        }
        if ( isset( $a['first_name'] ) ) {
          $customer->set_first_name( sanitize_text_field( $a['first_name'] ) );
        }
        if ( isset( $a['last_name'] ) ) {
          $customer->set_last_name( sanitize_text_field( $a['last_name'] ) );
        }

        $customer->save();

        return [
          'id' => $customer_id,
          'message' => 'Customer updated successfully.',
        ];

        /* ───────── Reviews ───────── */
      case 'wc_list_reviews':
        $args = [
          'post_type' => 'product',
          'status' => isset( $a['status'] ) ? sanitize_text_field( $a['status'] ) : 'approve',
          'number' => isset( $a['limit'] ) ? absint( $a['limit'] ) : 20,
        ];

        if ( isset( $a['product_id'] ) ) {
          $args['post_id'] = absint( $a['product_id'] );
        }

        $comments = get_comments( $args );
        $reviews = [];

        foreach ( $comments as $comment ) {
          $reviews[] = [
            'id' => $comment->comment_ID,
            'product_id' => $comment->comment_post_ID,
            'author' => $comment->comment_author,
            'email' => $comment->comment_author_email,
            'content' => $comment->comment_content,
            'rating' => get_comment_meta( $comment->comment_ID, 'rating', true ),
            'date' => $comment->comment_date,
            'status' => $comment->comment_approved,
          ];
        }

        return [
          'total' => count( $reviews ),
          'reviews' => $reviews,
        ];

      case 'wc_approve_review':
        $review_id = absint( $a['review_id'] ?? 0 );
        if ( !$review_id ) {
          throw new Exception( 'Review ID is required.' );
        }

        $result = wp_set_comment_status( $review_id, 'approve' );
        if ( !$result ) {
          throw new Exception( 'Failed to approve review.' );
        }

        return [
          'review_id' => $review_id,
          'message' => 'Review approved successfully.',
        ];

      case 'wc_delete_review':
        $review_id = absint( $a['review_id'] ?? 0 );
        if ( !$review_id ) {
          throw new Exception( 'Review ID is required.' );
        }

        $result = wp_delete_comment( $review_id, true );
        if ( !$result ) {
          throw new Exception( 'Failed to delete review.' );
        }

        return [
          'review_id' => $review_id,
          'message' => 'Review deleted successfully.',
        ];

        /* ───────── Coupons ───────── */
      case 'wc_list_coupons':
        $posts = get_posts( [ 'post_type' => 'shop_coupon', 'post_status' => 'publish', 'numberposts' => min( 100, absint( $a['limit'] ?? 30 ) ?: 30 ),
          's' => sanitize_text_field( (string) ( $a['search'] ?? '' ) ) ] );
        return [ 'coupons' => array_map( function ( $post ) { return $this->coupon_row( new WC_Coupon( $post->ID ) ); }, $posts ) ];

      case 'wc_save_coupon':
        $fields = is_string( $a['fields'] ?? null ) ? json_decode( $a['fields'], true ) : ( $a['fields'] ?? [] );
        $fields = is_array( $fields ) ? $fields : [];
        $coupon = new WC_Coupon( absint( $a['id'] ?? 0 ) );
        if ( !empty( $a['id'] ) && !$coupon->get_id() ) {
          throw new Exception( 'Coupon not found.' );
        }
        if ( !$coupon->get_id() && empty( $fields['code'] ) ) {
          throw new Exception( 'A new coupon needs a code.' );
        }
        if ( !empty( $fields['code'] ) ) {
          $code = wc_format_coupon_code( (string) $fields['code'] );
          $existing = wc_get_coupon_id_by_code( $code );
          if ( $existing && $existing !== $coupon->get_id() ) {
            throw new Exception( "The code \"$code\" is already used by coupon #$existing." );
          }
          $fields['code'] = $code;
        }
        if ( isset( $fields['discount_type'] ) && !array_key_exists( $fields['discount_type'], wc_get_coupon_types() ) ) {
          throw new Exception( 'discount_type must be one of: ' . implode( ', ', array_keys( wc_get_coupon_types() ) ) . '.' );
        }
        $allowed = [ 'code', 'discount_type', 'amount', 'description', 'date_expires', 'usage_limit', 'usage_limit_per_user',
          'minimum_amount', 'maximum_amount', 'individual_use', 'free_shipping', 'exclude_sale_items', 'product_ids',
          'excluded_product_ids', 'email_restrictions' ];
        $unknown = array_diff( array_keys( $fields ), $allowed );
        if ( $unknown ) {
          throw new Exception( 'Unknown coupon field(s): ' . implode( ', ', $unknown ) . '.' );
        }
        self::set_props( $coupon, array_intersect_key( $fields, array_flip( $allowed ) ) );
        $coupon->save();
        return $this->coupon_row( new WC_Coupon( $coupon->get_id() ) );

      case 'wc_delete_coupon':
        $coupon_id = absint( $a['id'] ?? 0 );
        if ( get_post_type( $coupon_id ) !== 'shop_coupon' ) {
          throw new Exception( 'Coupon not found.' );
        }
        if ( !wp_trash_post( $coupon_id ) ) {
          throw new Exception( 'The coupon could not be moved to the trash.' );
        }
        return 'Coupon #' . $coupon_id . ' moved to the trash.';

        /* ───────── Variations ───────── */
      case 'wc_list_variations':
        $product = $this->variable_product( absint( $a['product_id'] ?? 0 ) );
        return [ 'product_id' => $product->get_id(), 'attributes' => $this->attribute_rows( $product ),
          'variations' => array_map( function ( $variation_id ) {
            return $this->variation_row( wc_get_product( $variation_id ) );
          }, $product->get_children() ) ];

      case 'wc_set_product_attributes':
        $product_id = absint( $a['product_id'] ?? 0 );
        $product = wc_get_product( $product_id );
        if ( !$product || $product->is_type( 'variation' ) ) {
          throw new Exception( 'Product not found.' );
        }
        $list = is_string( $a['attributes'] ?? null ) ? json_decode( $a['attributes'], true ) : ( $a['attributes'] ?? [] );
        $attributes = [];
        foreach ( (array) $list as $position => $item ) {
          $name = sanitize_text_field( (string) ( $item['name'] ?? '' ) );
          $options = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', (array) ( $item['options'] ?? [] ) ) ), 'strlen' ) );
          if ( $name === '' || !$options ) {
            throw new Exception( 'Each attribute needs a name and options.' );
          }
          $attribute = new WC_Product_Attribute();
          // A global attribute (Products → Attributes) is used when one has this name; else a custom one.
          $taxonomy = wc_attribute_taxonomy_name( $name );
          if ( taxonomy_exists( $taxonomy ) ) {
            $term_ids = [];
            foreach ( $options as $option ) {
              $term = get_term_by( 'name', $option, $taxonomy ) ?: wp_insert_term( $option, $taxonomy );
              $term_ids[] = is_array( $term ) ? (int) $term['term_id'] : (int) $term->term_id;
            }
            $attribute->set_id( wc_attribute_taxonomy_id_by_name( $name ) );
            $attribute->set_name( $taxonomy );
            $attribute->set_options( $term_ids );
          }
          else {
            $attribute->set_name( $name );
            $attribute->set_options( $options );
          }
          $attribute->set_position( $position );
          $attribute->set_visible( true );
          $attribute->set_variation( true );
          $attributes[] = $attribute;
        }
        if ( !$product->is_type( 'variable' ) ) {
          wp_set_object_terms( $product_id, 'variable', 'product_type' );
          $product = new WC_Product_Variable( $product_id );
        }
        $product->set_attributes( $attributes );
        $product->save();
        return [ 'product_id' => $product_id, 'type' => 'variable', 'attributes' => $this->attribute_rows( wc_get_product( $product_id ) ) ];

      case 'wc_save_variation':
        $product = $this->variable_product( absint( $a['product_id'] ?? 0 ) );
        $fields = is_string( $a['fields'] ?? null ) ? json_decode( $a['fields'], true ) : ( $a['fields'] ?? [] );
        $fields = is_array( $fields ) ? $fields : [];
        if ( !empty( $a['variation_id'] ) ) {
          $variation = wc_get_product( absint( $a['variation_id'] ) );
          if ( !$variation || !$variation->is_type( 'variation' ) || $variation->get_parent_id() !== $product->get_id() ) {
            throw new Exception( 'This variation does not belong to this product.' );
          }
        }
        else {
          $variation = new WC_Product_Variation();
          $variation->set_parent_id( $product->get_id() );
          $wanted = is_string( $a['attributes'] ?? null ) ? json_decode( $a['attributes'], true ) : ( $a['attributes'] ?? [] );
          $set = [];
          foreach ( $product->get_attributes() as $key => $attribute ) {
            $label = wc_attribute_label( $attribute->get_name(), $product );
            $value = $wanted[ $label ] ?? $wanted[ $attribute->get_name() ] ?? null;
            if ( $value === null ) {
              continue;
            }
            $choices = $attribute->is_taxonomy() ? wp_list_pluck( $attribute->get_terms(), 'name', 'slug' ) : array_combine( $attribute->get_options(), $attribute->get_options() );
            $match = array_search( strtolower( (string) $value ), array_map( 'strtolower', $choices ), true );
            if ( $match === false ) {
              throw new Exception( "\"$value\" is not an option of $label (" . implode( ', ', $choices ) . ').' );
            }
            $set[ $key ] = $attribute->is_taxonomy() ? $match : $choices[ $match ];
          }
          if ( !$set ) {
            throw new Exception( 'Pass the attributes this variation stands for, e.g. {"Size": "M"}. See wc_list_variations.' );
          }
          $variation->set_attributes( $set );
          $variation->set_status( 'publish' );
        }
        $allowed = [ 'regular_price', 'sale_price', 'sku', 'stock_quantity', 'stock_status', 'status', 'description', 'weight', 'image_id' ];
        $unknown = array_diff( array_keys( $fields ), $allowed );
        if ( $unknown ) {
          throw new Exception( 'Unknown variation field(s): ' . implode( ', ', $unknown ) . '.' );
        }
        if ( array_key_exists( 'stock_quantity', $fields ) ) {
          $variation->set_manage_stock( $fields['stock_quantity'] !== null );
        }
        self::set_props( $variation, $fields );
        $variation->save();
        WC_Product_Variable::sync( $product->get_id() );
        return $this->variation_row( wc_get_product( $variation->get_id() ) );

      case 'wc_list_subscriptions':
      case 'wc_get_subscription':
      case 'wc_get_overdue_subscriptions':
      case 'wc_list_failed_renewals':
        return $this->dispatch_subscriptions( $tool, $a );

      default:
        throw new Exception( 'Unknown tool' );
    }
  }

  #region Subscriptions
  private const SUB_STATUSES = [ 'active', 'on-hold', 'pending', 'pending-cancel', 'cancelled', 'expired', 'switched' ];
  private const SUB_RELATED_TYPES = [ 'parent', 'renewal', 'switch', 'resubscribe' ];
  // Overdue subscriptions are read in one go (on-hold, then late active ones), up to this many.
  private const SUB_OVERDUE_CAP = 2000;

  private function has_subscriptions(): bool {
    return function_exists( 'wcs_get_subscriptions' ) && function_exists( 'wcs_get_subscription' )
      && function_exists( 'wcs_get_orders_with_meta_query' ) && function_exists( 'wcs_get_date_meta_key' );
  }

  // Next payment dates are stored in UTC as "Y-m-d H:i:s", or 0 when there is none; a real date is
  // required so subscriptions without one never match a "before" filter.
  private function sub_next_payment_query( ?int $after, ?int $before ): array {
    $key = wcs_get_date_meta_key( 'next_payment' );
    $query = [ [ 'key' => $key, 'value' => '2000-01-01 00:00:00', 'compare' => '>', 'type' => 'DATETIME' ] ];
    if ( $after !== null ) {
      $query[] = [ 'key' => $key, 'value' => gmdate( 'Y-m-d H:i:s', $after ), 'compare' => '>=', 'type' => 'DATETIME' ];
    }
    if ( $before !== null ) {
      $query[] = [ 'key' => $key, 'value' => gmdate( 'Y-m-d H:i:s', $before ), 'compare' => '<=', 'type' => 'DATETIME' ];
    }
    return $query;
  }

  private function dispatch_subscriptions( string $tool, array $a ) {
    $limit = min( 100, max( 1, absint( $a['limit'] ?? ( $tool === 'wc_get_overdue_subscriptions' ? 50 : 20 ) ) ) );
    $offset = absint( $a['offset'] ?? 0 );

    switch ( $tool ) {
      case 'wc_list_subscriptions':
        $query = [ 'subscription_status' => $this->sub_statuses( $a['status'] ?? 'any' ), 'orderby' => 'start_date', 'order' => 'DESC',
          'subscriptions_per_page' => $limit + 1, 'offset' => $offset ];
        if ( !empty( $a['customer_id'] ) ) {
          $query['customer_id'] = absint( $a['customer_id'] );
        }
        elseif ( !empty( $a['customer_email'] ) ) {
          $user = get_user_by( 'email', sanitize_email( $a['customer_email'] ) );
          if ( !$user ) {
            return [ 'total' => 0, 'subscriptions' => [], 'note' => 'No customer account uses this email.' ];
          }
          $query['customer_id'] = $user->ID;
        }
        if ( !empty( $a['product_id'] ) ) {
          $query['product_id'] = absint( $a['product_id'] );
        }
        $after = $this->sub_day( $a['next_payment_after'] ?? '', false );
        $before = $this->sub_day( $a['next_payment_before'] ?? '', true );
        if ( $after !== null || $before !== null ) {
          $query['meta_query'] = $this->sub_next_payment_query( $after, $before );
        }
        $subs = array_values( wcs_get_subscriptions( $query ) );
        return $this->sub_page( $subs, $limit, $offset, [ $this, 'format_subscription' ] );

      case 'wc_get_subscription':
        $subscription = wcs_get_subscription( absint( $a['id'] ?? 0 ) );
        if ( !$subscription ) {
          throw new Exception( 'Subscription not found.' );
        }
        $row = $this->format_subscription( $subscription );
        $row['failed_payment_count'] = (int) $subscription->get_failed_payment_count();
        $orders = [];
        foreach ( self::SUB_RELATED_TYPES as $type ) {
          foreach ( $subscription->get_related_orders( 'all', $type ) as $order ) {
            $orders[] = [ 'relation' => $type ] + $this->sub_order_row( $order );
          }
        }
        usort( $orders, function ( $x, $y ) { return strcmp( (string) $y['date_created'], (string) $x['date_created'] ); } );
        $row['related_orders_total'] = count( $orders );
        $row['related_orders'] = array_slice( $orders, 0, 50 );
        $row['timezone'] = wp_timezone_string();
        return $row;

      case 'wc_get_overdue_subscriptions':
        $now = time();
        $cutoff = $now - HOUR_IN_SECONDS * absint( $a['grace_hours'] ?? 24 );
        $on_hold = wcs_get_subscriptions( [ 'subscription_status' => [ 'on-hold' ], 'subscriptions_per_page' => self::SUB_OVERDUE_CAP ] );
        $late = wcs_get_subscriptions( [ 'subscription_status' => [ 'active' ], 'subscriptions_per_page' => self::SUB_OVERDUE_CAP,
          'meta_query' => $this->sub_next_payment_query( null, $cutoff ) ] );
        $all = array_values( $on_hold + $late );
        $result = $this->sub_page( array_slice( $all, $offset, $limit + 1 ), $limit, $offset, function ( $sub ) use ( $now ) {
          $row = $this->format_subscription( $sub );
          $next = $sub->get_time( 'next_payment' );
          $latest = null;
          foreach ( $sub->get_related_orders( 'all', 'renewal' ) as $order ) {
            if ( !$latest || ( $order->get_date_created() && $latest->get_date_created() && $order->get_date_created() > $latest->get_date_created() ) ) {
              $latest = $order;
            }
          }
          $since = $next && $next < $now ? $next : ( $latest && $latest->get_date_created() ? $latest->get_date_created()->getTimestamp() : 0 );
          $row['overdue_reason'] = $sub->has_status( 'on-hold' )
            ? 'On hold: a renewal is unpaid or its payment failed.'
            : 'Active, but the next payment date has passed without a renewal.';
          $row['days_overdue'] = $since ? (int) floor( ( $now - $since ) / DAY_IN_SECONDS ) : null;
          $row['failed_payment_count'] = (int) $sub->get_failed_payment_count();
          $row['latest_renewal'] = $latest ? $this->sub_order_row( $latest ) : null;
          return $row;
        } );
        $result['overdue_total'] = count( $all );
        return $result;

      case 'wc_list_failed_renewals':
        $statuses = [ 'failed' => [ 'failed' ], 'pending' => [ 'pending' ], 'on-hold' => [ 'on-hold' ], 'unpaid' => [ 'failed', 'pending', 'on-hold' ] ];
        $status = sanitize_key( $a['status'] ?? 'failed' );
        if ( !isset( $statuses[ $status ] ) ) {
          throw new Exception( 'Status must be failed, pending, on-hold or unpaid.' );
        }
        $query = [ 'type' => 'shop_order', 'status' => $statuses[ $status ], 'orderby' => 'date', 'order' => 'DESC',
          'limit' => $limit + 1, 'offset' => $offset, 'return' => 'objects',
          'meta_query' => [ [ 'key' => '_subscription_renewal', 'compare' => 'EXISTS' ] ] ];
        $after = $this->sub_day( $a['date_after'] ?? '', false );
        $before = $this->sub_day( $a['date_before'] ?? '', true );
        if ( $after !== null && $before !== null ) {
          $query['date_created'] = $after . '...' . $before;
        }
        elseif ( $after !== null ) {
          $query['date_created'] = '>=' . $after;
        }
        elseif ( $before !== null ) {
          $query['date_created'] = '<=' . $before;
        }
        $orders = array_values( wcs_get_orders_with_meta_query( $query ) );
        return $this->sub_page( $orders, $limit, $offset, function ( $order ) {
          $row = $this->sub_order_row( $order );
          $row['customer_id'] = $order->get_customer_id();
          $row['billing_email'] = $order->get_billing_email();
          $row['payment_method'] = $order->get_payment_method_title();
          $row['subscription_ids'] = array_map( 'intval', array_keys( wcs_get_subscriptions_for_renewal_order( $order ) ) );
          return $row;
        }, 'orders' );
    }
    throw new Exception( 'Unknown tool' );
  }

  // One more row than asked for is fetched, only to know whether another page exists.
  private function sub_page( array $items, int $limit, int $offset, callable $format, string $key = 'subscriptions' ): array {
    $more = count( $items ) > $limit;
    $items = array_slice( $items, 0, $limit );
    $result = [ 'total' => count( $items ), 'more' => $more ];
    if ( $more ) {
      $result['next_offset'] = $offset + $limit;
    }
    $result['timezone'] = wp_timezone_string();
    $result[ $key ] = array_map( $format, $items );
    return $result;
  }

  private function sub_statuses( $status ): array {
    $list = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', (string) $status ) ) ) );
    if ( !$list || in_array( 'any', $list, true ) ) {
      return [ 'any' ];
    }
    $unknown = array_diff( $list, self::SUB_STATUSES );
    if ( $unknown ) {
      throw new Exception( 'Unknown subscription status: ' . implode( ', ', $unknown ) . '. Use ' . implode( ', ', self::SUB_STATUSES ) . ' or any.' );
    }
    return array_values( $list );
  }

  // A YYYY-MM-DD day in the site's timezone, as a timestamp (start of day, or end of day for "before").
  private function sub_day( $value, bool $end ): ?int {
    $value = trim( (string) $value );
    if ( $value === '' ) {
      return null;
    }
    $day = DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
    if ( !$day || $day->format( 'Y-m-d' ) !== $value ) {
      throw new Exception( "Dates use YYYY-MM-DD, not \"{$value}\"." );
    }
    return $end ? $day->getTimestamp() + DAY_IN_SECONDS - 1 : $day->getTimestamp();
  }

  private function sub_date( $subscription, string $type ): ?string {
    $date = $subscription->get_date( $type, 'site' );
    return $date ? (string) $date : null;
  }

  private function format_subscription( $subscription ): array {
    $items = [];
    foreach ( $subscription->get_items() as $item ) {
      $items[] = [
        'product_id' => $item->get_product_id(),
        'variation_id' => $item->get_variation_id() ?: null,
        'name' => $item->get_name(),
        'quantity' => $item->get_quantity(),
        'total' => $item->get_total(),
      ];
    }
    return [
      'id' => $subscription->get_id(),
      'status' => $subscription->get_status(),
      'customer_id' => $subscription->get_customer_id(),
      'billing' => [
        'first_name' => $subscription->get_billing_first_name(),
        'last_name' => $subscription->get_billing_last_name(),
        'email' => $subscription->get_billing_email(),
        'phone' => $subscription->get_billing_phone(),
      ],
      'total' => $subscription->get_total(),
      'currency' => $subscription->get_currency(),
      'billing_period' => $subscription->get_billing_period(),
      'billing_interval' => (int) $subscription->get_billing_interval(),
      'start_date' => $this->sub_date( $subscription, 'start' ),
      'trial_end' => $this->sub_date( $subscription, 'trial_end' ),
      'next_payment' => $this->sub_date( $subscription, 'next_payment' ),
      'last_order_date' => $this->sub_date( $subscription, 'last_order_date_created' ),
      'end_date' => $this->sub_date( $subscription, 'end' ),
      'payment_method' => $subscription->get_payment_method_title(),
      'manual_renewal' => (bool) $subscription->is_manual(),
      'parent_order_id' => $subscription->get_parent_id() ?: null,
      'renewal_order_count' => count( $subscription->get_related_orders( 'ids', 'renewal' ) ),
      'items' => $items,
    ];
  }

  private function sub_order_row( $order ): array {
    $created = $order->get_date_created();
    $paid = $order->get_date_paid();
    return [
      'order_id' => $order->get_id(),
      'status' => $order->get_status(),
      'total' => $order->get_total(),
      'currency' => $order->get_currency(),
      'date_created' => $created ? $created->date_i18n( 'Y-m-d H:i:s' ) : null,
      'date_paid' => $paid ? $paid->date_i18n( 'Y-m-d H:i:s' ) : null,
    ];
  }
  #endregion

  // WC_Data::set_props() silently skips null values, so "no expiry" or "no stock count" was never
  // written, by the tools or by undo. Each setter is called instead, null included.
  private static function set_props( $object, array $props ) {
    foreach ( $props as $prop => $value ) {
      $setter = 'set_' . $prop;
      if ( is_callable( [ $object, $setter ] ) ) {
        $object->$setter( $value );
      }
    }
  }

  private function coupon_row( WC_Coupon $c ): array {
    $expires = $c->get_date_expires();
    return [ 'id' => $c->get_id(), 'code' => $c->get_code(), 'discount_type' => $c->get_discount_type(), 'amount' => $c->get_amount(),
      'description' => $c->get_description(), 'usage_count' => $c->get_usage_count(), 'usage_limit' => $c->get_usage_limit() ?: null,
      'usage_limit_per_user' => $c->get_usage_limit_per_user() ?: null, 'date_expires' => $expires ? $expires->date( 'Y-m-d' ) : null,
      'minimum_amount' => $c->get_minimum_amount() ?: null, 'maximum_amount' => $c->get_maximum_amount() ?: null,
      'individual_use' => $c->get_individual_use(), 'free_shipping' => $c->get_free_shipping(), 'exclude_sale_items' => $c->get_exclude_sale_items(),
      'product_ids' => $c->get_product_ids(), 'excluded_product_ids' => $c->get_excluded_product_ids(), 'email_restrictions' => $c->get_email_restrictions() ];
  }

  private function variable_product( int $product_id ): WC_Product_Variable {
    $product = wc_get_product( $product_id );
    if ( !$product ) {
      throw new Exception( 'Product not found.' );
    }
    if ( !$product->is_type( 'variable' ) ) {
      throw new Exception( 'This product is not variable. Give it attributes first with wc_set_product_attributes.' );
    }
    return $product;
  }

  private function attribute_rows( WC_Product $product ): array {
    $rows = [];
    foreach ( $product->get_attributes() as $attribute ) {
      $rows[] = [ 'name' => wc_attribute_label( $attribute->get_name(), $product ),
        'options' => $attribute->is_taxonomy() ? wp_list_pluck( $attribute->get_terms(), 'name' ) : $attribute->get_options(),
        'used_for_variations' => $attribute->get_variation() ];
    }
    return $rows;
  }

  private function variation_row( $v ): array {
    return [ 'variation_id' => $v->get_id(), 'attributes' => $v->get_attributes(), 'sku' => $v->get_sku(), 'regular_price' => $v->get_regular_price(),
      'sale_price' => $v->get_sale_price(), 'stock_quantity' => $v->get_manage_stock() ? $v->get_stock_quantity() : null,
      'stock_status' => $v->get_stock_status(), 'status' => $v->get_status() ];
  }
  #endregion
}
