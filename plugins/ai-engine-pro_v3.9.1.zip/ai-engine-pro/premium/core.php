<?php

class MeowPro_MWAI_Core {
  private $item = 'AI Engine Pro';
  private $core = null;

  public function __construct( $core ) {
    $this->core = $core;

    // Common behaviors, license, update system, etc.
    new MeowKitPro_MWAI_Licenser( MWAI_PREFIX, MWAI_ENTRY, MWAI_DOMAIN, $this->item, MWAI_VERSION );
    add_filter( 'edd_sl_plugin_updater_api_params', [ $this, 'add_mcp_usage_to_update_check' ], 10, 3 );

    // Content Aware
    new MeowPro_MWAI_ContentAware( $core );

    // Realtime
    new MeowPro_MWAI_Realtime( $core );

    // Function Aware
    new MeowPro_MWAI_FunctionAware( $core );

    // Editor Assistant
    if ( $this->core->get_option( 'module_assistant' ) ) {
      new MeowPro_MWAI_EditorAssistant( $core );
    }

    // Assistants
    if ( $this->core->get_option( 'module_assistants', false ) ) {
      $mwai_assistants = new MeowPro_MWAI_Assistants( $core );
    }

    // Statistics
    if ( $this->core->get_option( 'module_statistics', false ) ) {
      global $mwai_stats;
      $mwai_stats = new MeowPro_MWAI_Statistics();
    }

    // Embeddings
    if ( $this->core->get_option( 'module_embeddings', false ) ) {
      global $mwai_embeddings;
      $mwai_embeddings = new MeowPro_MWAI_Embeddings();
    }

    // Forms
    if ( !is_admin() && $this->core->get_option( 'module_forms', false ) ) {
      global $mwai_forms;
      $mwai_forms = new MeowPro_MWAI_Forms();
    }

    // Cross-Site
    if ( $this->core->get_option( 'module_cross_site', false ) ) {
      new MeowPro_MWAI_CrossSite( $core );
    }

    // Models API
    if ( $this->core->get_option( 'module_models_api', false ) ) {
      new MeowPro_MWAI_ModelsApi( $core );
    }

    // Workspace: moved to the free core (classes/modules/workspace.php); its
    // Knowledge, MCP Servers and Functions features stay Pro-gated inside.

    // Overrides for the Pro
    add_filter( 'mwai_plugin_title', [ $this, 'plugin_title' ], 10, 1 );
    add_action( 'mwai_support_db_loaded', [ $this, 'support_db_loaded' ] );
  }

  public function __destruct() {
    remove_filter( 'mwai_plugin_title', [ $this, 'plugin_title' ], 10 );
  }

  public function plugin_title( $string ) {
    return $string . ' (Pro)';
  }

  // One yes or no on the update check AI Engine Pro already makes: was MCP used for real in the
  // last 30 days? It tells us how many sites rely on MCP, with nothing about what they did.
  // Next to it, how many phones are paired with Workspace (a count, 0 when the module is off).
  // The hook is shared by every EDD plugin, so only AI Engine's own request gets the flag.
  public function add_mcp_usage_to_update_check( $params, $apiData, $pluginFile ) {
    if ( plugin_basename( (string) $pluginFile ) !== plugin_basename( MWAI_ENTRY ) ) {
      return $params;
    }
    $last = (int) get_option( 'mwai_mcp_last_used', 0 );
    $params['mcp_active'] = ( $last > time() - 30 * DAY_IN_SECONDS ) ? 1 : 0;
    // Was an assistant newly connected (OAuth) in the last 30 days? Next to mcp_active, it tells us
    // how many sites connect and then never use it, which the first-run prompts try to fix.
    $params['mcp_new_connection'] = $this->mcp_new_connection() ? 1 : 0;
    $params['workspace_devices'] = $this->core->get_option( 'module_workspace' )
      ? Meow_MWAI_Modules_Workspace::count_paired_devices() : 0;
    return $params;
  }

  private function mcp_new_connection(): bool {
    global $wpdb;
    $table = $wpdb->prefix . 'mwai_mcp_oauth_tokens';
    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
      return false;
    }
    // Refreshed tokens keep the original grant's 'created', so this is the first approval.
    $since = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
    return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$table} WHERE created > %s LIMIT 1", $since ) );
  }
}
