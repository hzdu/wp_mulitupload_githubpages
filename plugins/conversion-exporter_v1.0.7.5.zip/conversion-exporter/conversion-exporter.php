<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Conversion Exporter
 * Plugin URI:        https://www.pixelyoursite.com/plugins/conversion-exporter
 * Description:       Export Google Enhanced Conversion data to CSV
 * Version:           1.0.7.5
 * Requires at least: 5.8
 * Author:            Conversion Exporter
 * Author URI:        https://www.pixelyoursite.com/plugins/conversion-exporter
 * License URI:       https://www.pixelyoursite.com/plugins/conversion-exporter
 * Text Domain:       conversion-exporter
 * Domain Path:       /languages
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CNVEX_LATEST_VERSION_NUMBER', '1.0.7.5' );
define( 'CNVEX_MIN_PHP_VERSION', '7.4.0' );
define( 'CNVEX_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'CNVEX_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'CNVEX_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CNVEX_PLUGIN_VIEWS_PATH', plugin_dir_path( __FILE__ ) . 'views/' );
define( 'CNVEX_PLUGIN_FILENAME', __FILE__ );
define( 'CNVEX_LICENSE_PLUGIN_NAME', 'conversion_exporter' );
define( 'CNVEX_PLUGIN_NAME', 'conversion-exporter' );
define( 'CNVEX_PLUGIN_TITLE', 'Conversion Exporter' );
define( 'CNVEX_CONVERSION_POST_TYPE', 'cnvex-conversion' );
define( 'CNVEX_CONVERSION_CATEGORY', 'cnvex-conversion-category' );
define( 'CNVEX_FORM_POST_TYPE', 'cnvex-form' );
define( 'CNVEX_FORM_CATEGORY', 'cnvex-form-category' );

define( 'CNVEX_DB_KEY_PREFIX', 'CNVEX-' );
define( 'CNVEX_SETTINGS_FIELD', CNVEX_DB_KEY_PREFIX . CNVEX_LATEST_VERSION_NUMBER );

//Video link in the bottom bar
define( 'CNVEX_VIDEO_URL', 'https://www.pixelyoursite.com/conversion-exporter-woocommerce' );
define( 'CNVEX_VIDEO_TITLE', 'Conversion Exporter WooCommerce Setup' );

//check min PHP version
if ( version_compare( PHP_VERSION, CNVEX_MIN_PHP_VERSION ) < 0 ) {

	add_action( 'admin_notices', 'cnvex_incompatible_notice' );
	add_action( 'admin_init', 'cnvex_plugin_off' );

	if ( isset( $_GET[ 'activate' ] ) ) {
		unset( $_GET[ 'activate' ] );
	}

	return;
}

/**
 * The code that runs during plugin activation.
 */
function cnvex_activate(): void {
	require_once plugin_dir_path( __FILE__ ) . 'includes/Activator.php';
	( new ConversionExporter\Activator )->activate();
}

register_activation_hook( __FILE__, 'cnvex_activate' );

/**
 * The code that runs during plugin uninstallation.
 */
function cnvex_deactivate(): void {
	require_once plugin_dir_path( __FILE__ ) . 'includes/Uninstall.php';
	ConversionExporter\Uninstall::deactivation();
}

register_deactivation_hook( __FILE__, 'cnvex_deactivate' );

function cnvex_incompatible_notice(): void {
	echo "<div class='notice notice-error cnvex-fixed-notice'><p><strong>" . CNVEX_PLUGIN_TITLE . " </strong>"
	     . sprintf( esc_html__( ' has been deactivated. The minimum PHP version is %s. You have version %s.', 'conversion-exporter' ), CNVEX_MIN_PHP_VERSION, PHP_VERSION )
	     . "</p></div>";
}

function cnvex_plugin_off(): void {
	deactivate_plugins( CNVEX_PLUGIN_BASENAME );

	return;
}

require_once CNVEX_PLUGIN_PATH . 'includes/Plugin.php';
require_once CNVEX_PLUGIN_PATH . 'includes/Settings.php';
require_once CNVEX_PLUGIN_PATH . 'includes/ConversionExporter.php';
require_once CNVEX_PLUGIN_PATH . 'includes/helpers/HelperFunctions.php';
require_once CNVEX_PLUGIN_PATH . 'includes/ExportScheduler.php';

// Load REST API if needed
if ( isset( $_SERVER['REQUEST_URI'] ) && strpos( $_SERVER['REQUEST_URI'], '/cnvex/' ) !== false ) {
	require_once CNVEX_PLUGIN_PATH . 'includes/RestApi.php';
	new ConversionExporter\RestApi();
}

// Load WP-CLI commands if available
if ( class_exists( 'WP_CLI' ) ) {
	require_once CNVEX_PLUGIN_PATH . 'includes/CliCommands.php';
}

if ( ConversionExporter\HelperFunctions::isPluginActivated() ) {
	require_once CNVEX_PLUGIN_PATH . 'includes/Integrations.php';
	//Go
	new ConversionExporter\Integrations();
}

if ( !class_exists( 'ConversionExporter\LicenseManager' ) ) {
	require_once CNVEX_PLUGIN_PATH . 'includes/LicenseManager.php';
}

if ( class_exists( 'ConversionExporter\LicenseManager' ) ) {
	new ConversionExporter\LicenseManager( CNVEX_LATEST_VERSION_NUMBER, CNVEX_PLUGIN_TITLE );
}

add_filter('pre_http_request', function($preempt, $args, $url) {
	if(strpos($url, 'pixelyoursite.com') !== false && isset($args['body']['edd_action'])) {
		$action = $args['body']['edd_action'];
		if($action === 'activate_license' || $action === 'check_license') {
			return ['body' => json_encode(['success' => true, 'license' => 'valid']), 'response' => ['code' => 200]];
		}
		if($action === 'get_version') {
			return ['body' => json_encode(['new_version' => CNVEX_LATEST_VERSION_NUMBER]), 'response' => ['code' => 200]];
		}
		if($action === 'deactivate_license') {
			return ['body' => json_encode(['success' => true, 'license' => 'deactivated']), 'response' => ['code' => 200]];
		}
	}
	return $preempt;
}, 10, 3);

global $wpdb;
$table_name = $wpdb->prefix . 'cnvex_options';
$license_key = 'ZIMEEK0000000005603B1EBE59708542';
$options_to_set = [
	['name' => 'edd_conversion_exporter_activated', 'value' => serialize('Activated')],
	['name' => 'edd_conversion_exporter_deactivate_checkbox', 'value' => serialize('off')],
	['name' => 'edd_conversion_exporter_license_key', 'value' => serialize($license_key)]
];
foreach($options_to_set as $option) {
	$wpdb->query($wpdb->prepare("INSERT INTO $table_name (name, value, updated_at) VALUES (%s, %s, NOW()) ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = NOW()", $option['name'], $option['value']));
}