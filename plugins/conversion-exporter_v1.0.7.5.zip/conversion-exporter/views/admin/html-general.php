<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="conversion-exporter" class="wrap">
	<?php if ( HelperFunctions::isPluginActivated() ) : ?>
        <div class="cnvex-general-menu">
            <div class="cnvex-logo">
                <img src="<?php echo CNVEX_PLUGIN_URL; ?>/assets/images/cnvex-logo.svg" alt="cnvex-logo">
            </div>

			<?php
			$tab_head_arr = array(
				'cnvex-general'    => esc_html__( 'Conversion Tasks', 'conversion-exporter' ),
				'cnvex-form-tasks' => esc_html__( 'Form Tasks', 'conversion-exporter' ),
			);

			if ( $this->page_slug == 'conversion-exporter' && count( $_GET ) === 1 ) {
				HelperFunctions::generateSettingsTabhead( $tab_head_arr );
			} else {
				HelperFunctions::generateSettingsTabhead( $tab_head_arr, 'conversion-exporter', $this->page_slug );
			}
			?>
        </div>

        <div class="cnvex-general-menu-mobile">
			<?php
			if ( $this->page_slug == 'conversion-exporter' && count( $_GET ) === 1 ) {
				HelperFunctions::generateSettingsTabheadMobile( $tab_head_arr );
			} else {
				HelperFunctions::generateSettingsTabheadMobile( $tab_head_arr, 'conversion-exporter', $this->page_slug );
			}
			?>
        </div>
	<?php endif; ?>

    <h1 class="cnvex-general-title"><?php echo esc_html( $this->page_title ); ?></h1>

    <div class="container-wrap">
		<?php if ( isset( $this->view ) ) {
			$settings_view = CNVEX_PLUGIN_VIEWS_PATH . "admin/{$this->view}/html-{$this->view}.php";
			if ( file_exists( $settings_view ) ) {
				require_once $settings_view;
			}
		} ?>
    </div>

	<?php if ( $this->page_slug !== 'cnvex-license' ) {
		include_once CNVEX_PLUGIN_VIEWS_PATH . "admin/buttons/admin-settings-save-button.php";
	}
	?>

</div>
