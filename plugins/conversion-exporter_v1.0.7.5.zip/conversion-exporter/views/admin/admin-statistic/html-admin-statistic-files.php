<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$upload_dir = wp_upload_dir()[ 'basedir' ];
$upload_url = wp_upload_dir()[ 'baseurl' ];

$subdir       = isset( $_GET[ 'path' ] ) ? sanitize_text_field( $_GET[ 'path' ] ) : '';
$current_path = realpath( $upload_dir . '/' . $subdir );

if ( strpos( $current_path, realpath( $upload_dir ) ) !== 0 ) {
	wp_die( 'Invalid path.' );
}

?>
<div class="container">
    <div class="cards-wrapper cards-wrapper-style2 gap-24">
        <div class="card card-static card-style3">
            <div class="card-body">
				<?php

				if ( $subdir ) {
					$parent = dirname( $subdir );
					echo '<p><a href="?page=' . $this->page_slug . '&tab=admin-statistic-files&path=' . urlencode(
							$parent === '.' ? '' : $parent
						) . '">' . __( 'Back', 'conversion-exporter' ) . '</a></p>';
				}

				echo '<ul style="line-height:1.8em;">';

				foreach ( scandir( $current_path ) as $item ) {
					if ( $item === '.' || $item === '..' ) {
						continue;
					}
					$item_path     = $current_path . '/' . $item;
					$relative_path = ltrim( $subdir . '/' . $item, '/' );

					if ( is_dir( $item_path ) ) {
						echo '<li>📁 <a href="?page=' . $this->page_slug . '&tab=admin-statistic-files&path='
						     . urlencode( $relative_path ) . '">' . esc_html( $item ) . '</a></li>';
					} else {
						$file_url = $upload_url . '/' . str_replace( '\\', '/', $relative_path );
						echo '<li>📄 <a href="' . esc_url( $file_url ) . '" target="_blank">' . esc_html( $item )
						     . '</a></li>';
					}
				}

				echo '</ul>';
				?>
            </div>
        </div>
    </div>
</div>