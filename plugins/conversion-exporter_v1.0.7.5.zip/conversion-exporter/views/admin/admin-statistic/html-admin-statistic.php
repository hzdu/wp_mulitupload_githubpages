<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( isset( $_GET[ 'tab' ] ) ) {
	if ( $_GET[ 'tab' ] == 'admin-statistic-files' ) {
		include 'html-admin-statistic-files.php';
	} elseif ( $_GET[ 'tab' ] == 'admin-statistic-table' ) {
		include 'html-admin-statistic-table.php';
	} elseif ( $_GET[ 'tab' ] == 'admin-statistic-debug' ) {
		include 'html-admin-statistic-debug.php';
	}
}