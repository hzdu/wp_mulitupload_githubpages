<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="container">
    <div class="cards-wrapper cards-wrapper-style2 gap-24">
        <div class="card card-static card-style3">
            <div class="card-body">
                <?php
                    $log_file = WP_CONTENT_DIR . '/debug.log';
                    if ( file_exists( $log_file ) ) :
                        echo '<div style="white-space: pre-wrap; font-family: monospace; background: #111; color: #0f0; padding: 10px; max-height: 80vh; overflow: auto;">';
                            echo esc_html( file_get_contents( $log_file ) );
                            echo '</div>';
                    else : ?>
                        <p> <?php esc_html__( 'No debug log found.', 'conversion-exporter' ); ?></p>
                    <?php endif;
                ?>
            </div>
        </div>
    </div>
</div>