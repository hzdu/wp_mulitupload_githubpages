<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$allowed_tables = array(
	'cnvex_form_data'        => 'Form Data',
	'cnvex_consent_data'     => 'Consent Data',
	'cnvex_file_data'        => 'File Data',
	'cnvex_create_file_data' => 'Create File Data',
	'cnvex_options'          => 'Options',
);

$current_table_slug = isset( $_GET[ 'table' ] ) ? sanitize_text_field( wp_unslash( $_GET[ 'table' ] ) ) : '';

?>
<div class="container">
    <div class="cards-wrapper cards-wrapper-style2 gap-24">
        <div class="card card-static card-style3">
            <div class="card-body">
                <div class="mb-16">
                    <p class="mb-4 fw-600"><?php echo esc_html__( 'Select table:', 'conversion-exporter' ); ?></p>
                    <ul style="display:flex; gap:12px; flex-wrap:wrap; margin:8px 0; padding:0; list-style:none;">
						<?php foreach ( $allowed_tables as $slug => $label ) : ?>
                            <li>
                                <a href="?page=<?php echo esc_attr(
									$this->page_slug
								); ?>&tab=admin-statistic-table&table=<?php echo esc_attr( $slug ); ?>"
                                   class="btn btn-primary btn-primary-type2 <?php echo ( $current_table_slug
								                                                         === $slug ) ? 'btn-selected' : ''; ?>">
									<?php echo esc_html( $label ); ?>
                                </a>
                            </li>
						<?php endforeach; ?>
                    </ul>
                </div>

				<?php if ( empty( $current_table_slug )
				           || !array_key_exists(
						$current_table_slug,
						$allowed_tables
					) ) : ?>
                    <p><?php echo esc_html__(
							'Choose a table above to view its contents.',
							'conversion-exporter'
						); ?></p>
				<?php else : ?>
					<?php
					global $wpdb;

					$table_name   = $wpdb->prefix . $current_table_slug;
					$like         = '%' . $wpdb->esc_like( $table_name ) . '%';
					$exists_query = $wpdb->prepare( 'SHOW TABLES LIKE %s', $like );
					$table_exists = (bool) $wpdb->get_var( $exists_query );

					if ( !$table_exists ) : ?>
                        <p><?php echo esc_html(
								sprintf( __( 'Table %s does not exist.', 'conversion-exporter' ), $table_name )
							); ?></p>
					<?php else : ?>
						<?php
						$paged           = isset( $_GET[ 'paged' ] ) ? max( 1, absint( $_GET[ 'paged' ] ) ) : 1;
						$per_page        = isset( $_GET[ 'per_page' ] ) ? absint( $_GET[ 'per_page' ] ) : 50;
						$per_page        = min( 200, max( 10, $per_page ) ); // constrain per_page between 10 and 200
						$offset          = ( $paged - 1 ) * $per_page;
						$total           = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table_name}`" );
						$sql             = $wpdb->prepare(
							"SELECT * FROM `{$table_name}` ORDER BY `id` DESC LIMIT %d OFFSET %d",
							$per_page,
							$offset
						);
						$results         = $wpdb->get_results( $sql, ARRAY_A );

						if ( empty( $results ) ) : ?>
                            <p><?php echo esc_html__( 'No rows found for this page.', 'conversion-exporter' ); ?></p>
						<?php else :
							$columns = array_keys( $results[ 0 ] );
							$total_pages = max( 1, (int) ceil( $total / $per_page ) );
							$from        = $total ? ( $offset + 1 ) : 0;
							$to          = min( $offset + $per_page, $total );
							$base_qs     = '?page=' . rawurlencode( $this->page_slug )
							               . '&tab=admin-statistic-table&table=' . rawurlencode( $current_table_slug )
							               . '&per_page=' . $per_page . '&paged=';
							?>
                            <div style="overflow:auto; max-width:100%;">
                                <div class="tablenav top"
                                     style="margin-bottom:8px; display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                                    <span class="displaying-num">
                                        <?php echo esc_html(
	                                        sprintf(
		                                        __( 'Showing %1$s–%2$s of %3$s', 'conversion-exporter' ),
		                                        number_format_i18n( $from ),
		                                        number_format_i18n( $to ),
		                                        number_format_i18n( $total )
	                                        )
                                        ); ?>
                                    </span>
                                    <form method="get" style="margin:0;">
                                        <input type="hidden" name="page"
                                               value="<?php echo esc_attr( $this->page_slug ); ?>"/>
                                        <input type="hidden" name="tab" value="admin-statistic-table"/>
                                        <input type="hidden" name="table"
                                               value="<?php echo esc_attr( $current_table_slug ); ?>"/>
                                        <label><?php echo esc_html__( 'Per page:', 'conversion-exporter' ); ?>
                                            <select name="per_page" class="cnvex-select"
                                                    style="min-width:120px; padding:4px 8px; border:1px solid #ccd0d4; border-radius:4px; background:#fff; height:32px; line-height:32px;"
                                                    onchange="this.form.submit()">
												<?php foreach ( array( 10, 25, 50, 100, 200 ) as $pp ) : ?>
                                                    <option value="<?php echo esc_attr( $pp ); ?>" <?php selected(
														$per_page,
														$pp
													); ?>><?php echo esc_html( $pp ); ?></option>
												<?php endforeach; ?>
                                            </select>
                                        </label>
                                    </form>
                                </div>

                                <table class="widefat striped mt-24" style="min-width:800px;">
                                    <thead>
                                    <tr>
										<?php foreach ( $columns as $col ) : ?>
                                            <th><?php echo esc_html( (string) $col ); ?></th>
										<?php endforeach; ?>
                                    </tr>
                                    </thead>
                                    <tbody>
									<?php foreach ( $results as $row ) : ?>
                                        <tr>
											<?php foreach ( $columns as $col ) :
												$val = isset( $row[ $col ] ) ? (string) $row[ $col ] : '';
												?>
                                                <td style="white-space:pre-wrap; word-break:break-word; max-width:600px;">
													<?php echo esc_html( $val ); ?>
                                                </td>
											<?php endforeach; ?>
                                        </tr>
									<?php endforeach; ?>
                                    </tbody>
                                </table>

                                <div class="tablenav bottom"
                                     style="margin-top:8px; display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                                    <span class="tablenav-pages">
                                        <?php
                                        $prev = max( 1, $paged - 1 );
                                        $next = min( $total_pages, $paged + 1 );
                                        ?>
                                        <a class="first-page <?php echo $paged <= 1 ? 'disabled' : ''; ?>"
                                           href="<?php echo esc_url( $base_qs . 1 ); ?>">«</a>
                                        <a class="prev-page <?php echo $paged <= 1 ? 'disabled' : ''; ?>"
                                           href="<?php echo esc_url( $base_qs . $prev ); ?>">‹</a>
                                        <?php
                                        $start = max( 1, $paged - 2 );
                                        $end   = min( $total_pages, $paged + 2 );
                                        for ( $i = $start; $i <= $end; $i++ ) :
	                                        ?>
                                            <a class="page-number <?php echo $i === $paged ? 'current' : ''; ?>"
                                               href="<?php echo esc_url( $base_qs . $i ); ?>"><?php echo esc_html(
			                                        number_format_i18n( $i )
		                                        ); ?></a>
                                        <?php endfor; ?>
                                        <a class="next-page <?php echo $paged >= $total_pages ? 'disabled' : ''; ?>"
                                           href="<?php echo esc_url( $base_qs . $next ); ?>">›</a>
                                        <a class="last-page <?php echo $paged >= $total_pages ? 'disabled' : ''; ?>"
                                           href="<?php echo esc_url( $base_qs . $total_pages ); ?>">»</a>
                                    </span>
                                </div>
                            </div>
						<?php endif; ?>
					<?php endif; ?>
				<?php endif; ?>
            </div>
        </div>
    </div>
</div>