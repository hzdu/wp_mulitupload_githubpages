<?php

namespace ConversionExporter;

// If this file is called directly, abort.
if ( !defined( 'WPINC' ) ) {
	die;
}
if ( !isset( $absolute_position ) ) {
	$absolute_position = true;
}
?>
<div class="cnvex-loader-wrap <?php echo $absolute_position ? 'loader-absolute' : ''; ?>">
    <img src="<?php echo esc_url( CNVEX_PLUGIN_URL . '/assets/images/loader.svg' ); ?>" class="cnvex-loader"
         alt="cnvex-loader"/>
</div>
