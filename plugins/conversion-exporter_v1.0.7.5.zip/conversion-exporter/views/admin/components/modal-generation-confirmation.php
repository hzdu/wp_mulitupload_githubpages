<?php

namespace ConversionExporter;

// If this file is called directly, abort.
if ( !defined( 'WPINC' ) ) {
	die;
}

?>

<div class="cnvex-modal cnvex-modal-generation-confirmation-wrap">
    <div class="cnvex-modal-content-wrap">
        <div class="cnvex-modal-content">
            <p class="mb-24 fw-500"><?php esc_html_e( 'The generation process is in progress. It will take a few minutes. (Depends on the number of orders)', 'conversion-exporter' ); ?></p>
            <div class="modal-buttons">
                <button type="button"
                        class="btn btn-primary btn-primary-type2 cnvex-modal-generation-confirmation"
                        data-filename=""><i
                            class="icon-renew"></i> <?php esc_html_e( 'OK', 'conversion-exporter' ); ?>
                </button>
            </div>
        </div>
    </div>
</div>
