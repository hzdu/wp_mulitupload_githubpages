<?php

namespace ConversionExporter;

// If this file is called directly, abort.
if ( !defined( 'WPINC' ) ) {
	die;
}

?>

<div class="cnvex-modal cnvex-delete-form-wrap">
    <div class="cnvex-modal-content-wrap">
        <div class="cnvex-modal-content">
            <p class="mb-24 fw-500"><?php esc_html_e( 'Are you sure you want to delete form?', 'conversion-exporter' ); ?></p>
            <div class="modal-buttons">
                <button type="button" class="btn btn-red btn-primary-type2 cnvex-delete-form-cancel"><i
                            class="icon-restore"></i> <?php esc_html_e( 'Cancel', 'conversion-exporter' ); ?>
                </button>
                <button type="button"
                        class="btn btn-primary btn-primary-type2 cnvex-delete-form"
                        data-id=""><i
                            class="icon-renew"></i> <?php esc_html_e( 'OK', 'conversion-exporter' ); ?>
                </button>
            </div>
        </div>
    </div>
</div>
