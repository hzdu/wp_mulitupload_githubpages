<?php

namespace ConversionExporter;

// If this file is called directly, abort.
if ( !defined( 'WPINC' ) ) {
	die;
}

?>

<div class="cnvex-modal cnvex-error-download-conversion-wrap">
    <div class="cnvex-modal-content-wrap">
        <div class="cnvex-modal-content">
			<?php HelperNotices::renderWarningMessage( '' ); ?>
            <div class="modal-buttons">
                <button type="button"
                        class="btn btn-primary btn-primary-type2 cnvex-error-download-conversion"><i
                            class="icon-renew"></i> <?php esc_html_e( 'OK', 'conversion-exporter' ); ?>
                </button>
            </div>
        </div>
    </div>
</div>
