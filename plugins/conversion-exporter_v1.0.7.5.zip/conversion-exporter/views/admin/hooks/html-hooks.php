<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="container">
    <div class="cards-wrapper cards-wrapper-style2 gap-24 hooks-filters">
        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_filter_woo_statuses - Filter for Woocommerce statuses', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'Filter for Woocommerce statuses in conversion tasks', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'Status key must be without prefix "wc-"', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'array $statuses, int $export_id' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_filter_woo_statuses', function ( $statuses, $export_id ) {
    $statuses[] = 'on-hold';
    return $statuses;
}, 10, 2 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_disable_full_file_generation - Disable full file generation', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'The filter disables generation of the full file in conversion tasks', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'bool $status, int $export_id' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_disable_full_file_generation', function ( $status, $export_id ) {
     if( get_current_user_id() == 0 ) {
        return true;
    }
    return $status;
}, 10, 2 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_disable_password_protection - Disable password protection', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'The filter disables password protection in conversion tasks', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'bool $status, int $export_id' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_disable_password_protection', function ( $status, $export_id ) {
     if( get_current_user_id() == 0 ) {
        return true;
    }
    return $status;
}, 10, 2 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_filter_csv_columns - Filter columns in CSV conversion file', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'This filter will let you change the columns in the CSV conversion file.', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'The column key is the key by which you can access to add a value.', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'Column value is the column header. It must be with prefix "cv:"', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'array $columns, int $export_id' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_filter_csv_columns', function ( $columns, $export_id ) {
     if( get_current_user_id() == 0 ) {
        $columns[ 'postal_code' ] = 'cv:postal_code';
    } else {
        // Example: Remove the 'last_name' column
        unset( $columns[ 'last_name' ] );
    }
    return $columns;
}, 10, 2 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_filter_woo_csv_fields - Edit column data in CSV conversion file when source is Woocommerce', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'This filter will let you change the column values in the CSV conversion file when source is Woocommerce.', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'The field key is the key from your cnvex_filter_csv_columns hook or change generated value.', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'Field value is your value', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'array $fields, int $export_id, WC_Order $order' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_filter_woo_csv_fields', function ( $fields, $export_id, $order ) {
     if( $export_id == 1 ) {
        $fields[ 'postal_code' ] = $order->get_billing_postcode();
    } else {
        $fields[ 'postal_code' ] = 12345; // Example: Set a static value
    }
    return $fields;
}, 10, 3 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_filter_form_csv_fields - Edit column data in CSV conversion file when source is Form', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'This filter will let you change the column values in the CSV conversion file when source is Form.', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'The field key is the key from your cnvex_filter_csv_columns hook or change generated value.', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'Field value is your value', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'array $fields, int $export_id, array $lead' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_filter_form_csv_fields', function ( $fields, $export_id, $lead ) {
    $user = get_user_by( 'email', $lead[ 'email' ] );
    if( $user ) {
        $fields[ 'postal_code' ] = get_user_meta( $user->ID, 'billing_postcode', true );
    } else {
        $fields[ 'postal_code' ] = '';
    }
    return $fields;
}, 10, 3 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_{mode_name}_value - Override consent value', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php echo esc_html( '{mode_name} - ad_user_data, ad_personalization' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'This filter overrides consent mode value in the CSV conversion file', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'The value can be denied/granted', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'string $consent_value, int $export_id, int|null $order_id' ); ?></p>
                        <p class="mb-4"><strong>$consent_value</strong><?php esc_html_e( ' - the current consent value (denied/granted)', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><strong>$export_id</strong><?php esc_html_e( ' - the conversion task ID', 'conversion-exporter' ); ?></p>
                        <p><strong>$order_id</strong><?php esc_html_e( ' - the WooCommerce order ID for order exports, or null for form/lead exports', 'conversion-exporter' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_ad_user_data_value', function ( $consent_value, $export_id, $order_id ) {
    if ( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( $order && $order->get_meta( '_my_ad_consent' ) === 'no' ) {
            return 'denied';
        }
    }
    return $consent_value;
}, 10, 3 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_save_form_data - Manage user data from captured form', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'This filter manages user data from captured form in the form task', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'array $data, int $form_id' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_save_form_data', function ( $data, $form_id ) {
    if( get_current_user_id() == 0 ) {
        $data[ 'first_name' ] = 'Anonymous';
    }
    return $data;
}, 10, 2 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_form_data_retention_option - Disable form data retention option', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'Disable form data retention option in form task', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'bool $status, int $form_id' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_form_data_retention_option', function ( $status, $form_id ) {
    if( get_current_user_id() == 0 ) {
        return true;
    }
    return $status;
}, 10, 2 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_form_data_retention_values - Modify data retention values', 'conversion-exporter' ); ?></h4>
                </div>
				<?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'Modify data retention values in form task', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'Array $options has 2 auto-delete parameters: "days" and "entries"', 'conversion-exporter' ); ?></p>
                        <p class="mb-4"><?php esc_html_e( 'Use 0 to disable any option', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'array $options, int $form_id' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_form_data_retention_values', function ( $options, $form_id ) {
    if( get_current_user_id() == 0 ) {
        $options[ 'days' ] = 30; // Set auto-delete after 30 days
        $options[ 'entries' ] = 1000; // Set auto-delete after 1000 entries
    }
    return $options;
}, 10, 2 );</pre>
                            <div class="input-copy input-copy-pre">
								<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card card-style3 hook-card">
            <div class="card-header card-header-style2 disable-card-wrap d-flex justify-content-between align-items-center">
                <div class="disable-card align-items-center">
                    <h4 class="primary-heading-type2"><?php esc_html_e( 'cnvex_cookies_consent - Manage cookie files', 'conversion-exporter' ); ?></h4>
                </div>
			    <?php HelperFunctions::cardCollapseSettings(); ?>
            </div>
            <div class="card-body">
                <div class="gap-24">

                    <div>
                        <p class="mb-4"><?php esc_html_e( 'Manage cookie files depending on user consent', 'conversion-exporter' ); ?></p>
                        <p><strong><?php esc_html_e( 'Params:', 'conversion-exporter' ); ?></strong> <?php echo esc_html( 'bool $enabled' ); ?></p>
                    </div>

                    <div>
                        <p class="mb-4 fw-600"><?php esc_html_e( 'Example', 'conversion-exporter' ); ?>:</p>
                        <div class="example-block copy-block-wrap">
                    <pre class="copy_text">
add_filter( 'cnvex_cookies_consent', function ( $enabled ) {
    if( get_current_user_id() == 0 ) {
        return false;
    }
    return $enabled;
} );</pre>
                            <div class="input-copy input-copy-pre">
							    <?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>