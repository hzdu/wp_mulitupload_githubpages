<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}


$status = ConversionExporter()->getOption( 'edd_conversion_exporter_activated' );
?>

<div class="card card-static card-style9 license license-edd">
    <div class="card-header card-header-style3">
        <div class="d-flex justify-content-between align-items-center w-100">
            <div class="d-flex align-items-center">
                <div class="cnvex-logo-small mr-16">
                    <img src="<?php echo esc_url( CNVEX_PLUGIN_URL ); ?>/assets/images/cnvex-logo.svg" alt="cnvex-logo">
                </div>

                <h3 class="primary-heading-type2">
					<?php esc_html_e( 'Manage your Conversion Exporter license', 'conversion-exporter' ); ?>
                </h3>
            </div>

            <div class="deactivation-wrap deactivation-wrap-top">
				<?php if ( $status == 'Activated' || $status == 'Expired' ) : ?>
                    <div class="deactivate-button">
                        <button
                                name="deactivate"
                                class="btn btn-red btn-primary-type2 cnvex-license-action">
							<?php esc_attr_e( 'Deactivate License', 'conversion-exporter' ); ?>
                        </button>
                    </div>
				<?php endif; ?>

                <div class="license-loader">
					<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/spinner.php"; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="gap-22">
            <div class="license-info">
				<?php if ( $status == 'Activated' || $status == 'Expired' ) : ?>
                    <h4 class="secondary-heading"><?php esc_html_e( 'Your license key:', 'conversion-exporter' ); ?></h4>
                    <p class="text-green fw-500"><?php esc_html_e( 'Activated', 'conversion-exporter' ); ?></p>
				<?php endif; ?>

                <h4 class="secondary-heading"><?php esc_html_e( 'Plugin version:', 'conversion-exporter' ); ?></h4>

                <div>
                    <span class="fw-500"><?php echo esc_html( CNVEX_LATEST_VERSION_NUMBER ); ?></span>
                </div>

                <h4 class="secondary-heading"><?php esc_html_e( 'License name:', 'conversion-exporter' ); ?></h4>

                <div>
                    <span class="fw-500"><?php echo esc_html( CNVEX_PLUGIN_TITLE ); ?></span>
                </div>
            </div>

            <div>
                <h4 class="font-semibold-type2 mb-2">
					<?php esc_html_e( 'Your license key', 'conversion-exporter' ); ?>:
                </h4>

				<?php if ( $status == 'Activated' || $status == 'Expired' ) : ?>
                    <div class="cnvex-license-key">
                        <input type="hidden" name="action" value="cnvex_deactivate_license" />
                        <input type="hidden" id="edd_conversion_exporter_deactivate_checkbox"
                               name="edd_conversion_exporter_deactivate_checkbox" value="">

                        <input id="api_key"
                               class="input-full"
                               name="edd_conversion_exporter[edd_conversion_exporter_api_key]"
                               size="25"
                               required="required"
                               type="text"
                               placeholder="******************************************">

                        <div class="license-key-action license-loader license-loader-bottom">
                            <button
                                    name="activate"
                                    class="btn btn-green btn-primary-type2 cnvex-license-action">
								<?php esc_attr_e( 'Reactivate License', 'conversion-exporter' ); ?>
                            </button>

                            <div class="deactivation-wrap">
                                <div class="deactivate-button">
                                    <button
                                            name="deactivate"
                                            class="btn btn-red btn-primary-type2 cnvex-license-action">
										<?php esc_attr_e( 'Deactivate License', 'conversion-exporter' ); ?>
                                    </button>
                                </div>
                            </div>

							<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/spinner.php"; ?>
                        </div>
                    </div>
				<?php else : ?>
                    <div class="cnvex-license-key">
                        <input type="hidden" name="action" value="cnvex_validate_license" />

                        <div>
                            <input id="api_key"
                                   class="input-full"
                                   name="edd_conversion_exporter[edd_conversion_exporter_api_key]"
                                   size="25"
                                   required="required"
                                   type="text"
                                   value="">

                            <p class="license-description mt-4 lh-162">
								<?php esc_html_e( 'You have your license key in the order confirmation email, and you can get it from ', 'conversion-exporter' );
								?>
                                <a href="<?php echo esc_url( 'https://www.pixelyoursite.com/my-account' ); ?>"
                                   rel="nofollow"
                                   class="link link-small"
                                   target="_blank">
									<?php esc_html_e( 'your account', 'conversion-exporter' );
									?></a>
								<?php esc_html_e( ' on our website. We also sent you an email containing your login data.', 'conversion-exporter' );
								?>
                            </p>
                        </div>

                        <div class="license-key-action license-loader license-loader-bottom">
                            <input type="submit"
                                   name="submit"
                                   class="btn btn-primary btn-primary-type2 activate-license-action"
                                   value="<?php esc_attr_e( 'Activate License', 'conversion-exporter' ); ?>">

							<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/spinner.php"; ?>
                        </div>
                    </div>
				<?php endif; ?>

                <div class="mt-24">
					<?php HelperNotices::renderInfoMessageType2( sprintf( __( 'If your don\'t have key, you can take it from %s', 'conversion-exporter' ), '<a href="https://www.pixelyoursite.com/my-account" rel="nofollow" target="_blank">' . __( 'here', 'conversion-exporter' ) . '</a>' ) ); ?>
                </div>

				<?php $error_license = get_transient( 'cnvex_license_notice' ); ?>
				<?php if ( !empty( $error_license ) ) : ?>
                    <div class="mt-24">
						<?php
						$message = __( 'Activation error', 'conversion-exporter' ) . ': ' . $error_license;
						HelperNotices::renderCriticalMessage( $message ); ?>
                    </div>
					<?php delete_transient( 'cnvex_license_notice' ); ?>
				<?php endif; ?>

				<?php $deactivation_notice = get_transient( 'cnvex_license_deactivation_notice' ); ?>
				<?php if ( !empty( $deactivation_notice ) ) : ?>
                    <div class="mt-24">
						<?php HelperNotices::renderWarningMessage( $deactivation_notice ); ?>
                    </div>
					<?php
					delete_transient( 'cnvex_license_deactivation_notice' );
				endif; ?>

				<?php $success_notice = get_transient( 'cnvex_license_success_notice' ); ?>
				<?php if ( !empty( $success_notice ) ) : ?>
                    <div class="mt-24">
						<?php HelperNotices::renderSuccessMessage( $success_notice ); ?>
                    </div>
					<?php
					delete_transient( 'cnvex_license_success_notice' );
				endif; ?>
            </div>
        </div>
    </div>
</div>
