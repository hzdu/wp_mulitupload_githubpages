<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="container-middle">
    <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
          method="post"
          id="cnvex_settings_form"
          class="cnvex-settings-form">
		<?php
		// Set nonce:
		if ( function_exists( 'wp_create_nonce' ) ) {
			$nonce_value = wp_create_nonce( 'cnvex-update-' . CNVEX_SETTINGS_FIELD  );
			echo '<input type="hidden" id="cnvex_nonce" name="_wpnonce" value="' . esc_attr( $nonce_value ) . '">';
		}
        ?>

		<?php include_once CNVEX_PLUGIN_VIEWS_PATH . "admin/license/html-edd-license.php"; ?>
    </form>
</div>