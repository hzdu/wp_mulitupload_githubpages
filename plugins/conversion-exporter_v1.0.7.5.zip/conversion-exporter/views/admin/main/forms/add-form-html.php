<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$data_retention_options = array(
	'never' => __( 'Never Delete', 'conversion-exporter' ),
	'auto'  => __( 'Auto Delete', 'conversion-exporter' ),
)
?>

<div class="container">
    <form method="post"
          action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
          class="cnvex-settings-form">

        <input type="hidden" name="cnvex_update_action" value="add_form" id="cnvex_update_action"/>
        <input type="hidden" name="action" value="cnvex_save_settings">
        <input type="hidden" name="conversion-exporter[_cnvex_form_data_input]" value="" id="cnvex_form_data_input"/>
		<?php
		if ( function_exists( 'wp_create_nonce' ) ) {
			$nonce_value = wp_create_nonce( 'cnvex-update-' . CNVEX_SETTINGS_FIELD  );
			echo '<input type="hidden" id="cnvex_nonce" name="_wpnonce" value="' . esc_attr( $nonce_value ) . '">';
		}
        ?>
        <div class="card card-static card-style3">
            <div class="card-body">
                <div class="gap-24">
                    <div class="list-item">
                        <div class="d-flex align-items-center">
							<?php Form()->renderSwitcherInput( '_cnvex_enable', true, null, false, false, true ); ?>
                            <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Enable Form', 'conversion-exporter' ); ?></h4>
                        </div>
                    </div>

                    <div class="list-item">
                        <h4 class="font-semibold-type2 mb-4">
							<?php esc_html_e( 'Form name', 'conversion-exporter' ); ?><span class="text-red"> *</span>:
                        </h4>
						<?php Form()->renderTextInput( '_cnvex_form_name', true, null, '', 'js-control-element', 'required' ); ?>
                    </div>

                    <div class="list-item">
                        <div class="line mb-24"></div>

                        <h4 class="font-semibold-type2 mb-4">
							<?php esc_html_e( 'Page URL to scan', 'conversion-exporter' ); ?>:</h4>

                        <div class="scan-form">
							<?php Form()->renderTextInput( '_cnvex_page_url', true, null, '', 'js-control-element' ); ?>

                            <div class="scan-button-wrap">
                                <button type="button" id="cnvex_scan_button" class="btn btn-primary btn-primary-type2">
									<?php esc_html_e( 'Scan', 'conversion-exporter' ); ?>
                                </button>
								<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/spinner.php"; ?>
                            </div>
                        </div>

                        <div class="error-message mt-24"
                             style="display: none;">
							<?php HelperNotices::renderCriticalMessage( '' ); ?>
                        </div>
                    </div>

                    <div class="list-item map-list-wrap" style="display: none;">
                        <div class="mb-24">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Select form', 'conversion-exporter' ); ?>:
                            </h4>

							<?php Form()->renderSelectInput( '_cnvex_form', array(), true, null, __( 'Select form', 'conversion-exporter' ), false, '', 'full' ); ?>
                        </div>

                        <div class="map-list">
                            <div id="cnvex_form_data_container" class="cnvex-hidden">
                                <select name="_cnvex_form_fields" id="cnvex_form_data"></select>
                            </div>

                            <div class="cnvex-hidden">
                                <input type="hidden"
                                       name="<?php echo esc_attr( $this->getPluginSlug() ); ?>[_cnvex_form_type]"
                                       id="_cnvex_form_type"
                                       value=""
                                >
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Select email field', 'conversion-exporter' ); ?><span
                                            class="text-red">*</span>:
                                </h4>

								<?php Form()->renderSelectInput( '_cnvex_email_field', array(), true, null, __( 'Select email field', 'conversion-exporter' ), false, '', 'full' ); ?>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Select first name field', 'conversion-exporter' ); ?>:
                                </h4>

								<?php Form()->renderSelectInput( '_cnvex_first_name_field', array(), true, null, __( 'Select first name field', 'conversion-exporter' ), false, '', 'full' ); ?>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Select last name field', 'conversion-exporter' ); ?>:
                                </h4>

								<?php Form()->renderSelectInput( '_cnvex_last_name_field', array(), true, null, __( 'Select last name field', 'conversion-exporter' ), false, '', 'full' ); ?>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Select phone (optional)', 'conversion-exporter' ); ?>:
                                </h4>

								<?php Form()->renderSelectInput( '_cnvex_phone_field', array(), true, null, __( 'Select phone', 'conversion-exporter' ), false, '', 'full' ); ?>
                            </div>
                        </div>
                    </div>

                    <div class="list-item">
                        <div class="line mb-24"></div>

                        <h4 class="font-semibold-type2 mb-4">
							<?php esc_html_e( 'Data Retention options', 'conversion-exporter' ); ?>:
                        </h4>

						<?php Form()->renderSelectInput( '_cnvex_data_retention', $data_retention_options, true ); ?>

                        <div id="cnvex-auto-delete" class="mt-24" style="display: none;">
                            <h4 class="font-semibold-type2 mb-8">
								<?php esc_html_e( 'Auto-delete after', 'conversion-exporter' ); ?>:
                            </h4>

                            <div class="delete-option-group">
                                <div class="delete-option">
									<?php Form()->renderNumberInput( '_cnvex_delete_days', true, null, false, 0 ); ?>
                                    <span><?php esc_html_e( 'days', 'conversion-exporter' ); ?></span>
                                </div>

                                <div>
									<?php esc_html_e( 'Or', 'conversion-exporter' ); ?>
                                </div>

                                <div class="delete-option">
									<?php Form()->renderNumberInput( '_cnvex_delete_entries', true, null, false, 0 ); ?>
                                    <span><?php esc_html_e( 'entries', 'conversion-exporter' ); ?></span>
                                </div>
                            </div>

                            <p class="text-gray mt-8"><?php esc_html_e( 'Use 0 to disable any option.', 'conversion-exporter' ); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
