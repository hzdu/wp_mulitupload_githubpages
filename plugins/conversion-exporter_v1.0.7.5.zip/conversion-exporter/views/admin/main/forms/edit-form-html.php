<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$id = sanitize_text_field( $_GET[ 'form_id' ] );

$data_retention_options = array(
	'auto'  => __( 'Auto Delete', 'conversion-exporter' ),
	'never' => __( 'Never Delete', 'conversion-exporter' ),
);

$form_type = get_post_meta( $id, '_cnvex_form_type', true );
$page_url = get_post_meta( $id, '_cnvex_page_url', true );
$active_form = get_post_meta( $id, '_cnvex_form', true );
$forms_data = get_post_meta( $id, '_cnvex_form_data_input', true );
$form_options = $form_fields = array();
$message = '';

if ( !empty( $forms_data ) ) {
	foreach ( $forms_data as $form ) {
		$data = isset( $form[ 'id' ] ) && $form[ 'id' ] != '' ? '#' . $form[ 'id' ] : ( $form[ 'selector' ] ?? '' );

		if ( !empty( $data ) ) {
			$form_options[] = array(
				'option_name'  => $data,
				'option_value' => $data,
			);

			if ( $data == $active_form ) {
				if ( isset( $form[ 'fields' ] ) && is_array( $form[ 'fields' ] ) ) {
					foreach ( $form[ 'fields' ] as $field ) {
						$form_fields[] = array(
							'option_name'  => $field[ 'name' ],
							'option_value' => $field[ 'value' ],
						);
					}
				}
			}
		}
	}
}

$current_form_data = Form()->getFormData( $id );

$count_gclid = count( array_filter( $current_form_data, function ( $item ) {
	return array_key_exists( 'gclid', $item ) && !empty( $item[ 'gclid' ] );
} ) );

$args_posts = array(
	'post_type'      => CNVEX_CONVERSION_POST_TYPE,
	'post_status'    => 'publish',
	'posts_per_page' => -1,
	'order'          => 'ASC',
	'orderby'        => 'DATE',
	'meta_query'     => array(
		array(
			'key'   => '_cnvex_enable',
			'value' => 1,
		)
	),
	'meta_type'      => 'NUMERIC',
);
$exports = get_posts( $args_posts );

$used_exports = array();
if ( !empty( $exports ) ) {
	foreach ( $exports as $export ) {
		$export_forms = get_post_meta( $export->ID, '_cnvex_form_ids', true );
		$source = get_post_meta( $export->ID, '_cnvex_source', true );
		if ( $source == 'woo' || empty( $export_forms ) || !is_array( $export_forms ) || !in_array( $id, $export_forms ) ) {
			continue;
		}
		$last_export_time = get_post_meta( $export->ID, '_cnvex_last_export', true );
		if ( empty( $last_export_time ) ) {
			$last_export = __( 'Last export: Never', 'conversion-exporter' );
		} else {
			$last_export_time = date( "Y-m-d H:i:s", $last_export_time );
			$last_export = sprintf( __( 'Last export: %s', 'conversion-exporter' ), $last_export_time );
		}
		$used_exports[] = array(
			'export_id'   => $export->ID,
			'name'        => get_post_meta( $export->ID, '_cnvex_conversion_name', true ),
			'url'         => get_admin_url() . 'admin.php?page=conversion-exporter&conversion_task_id=' . $export->ID,
			'last_export' => $last_export,
		);
	}
}

?>

<div class="container">
    <form method="post"
          action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
          class="cnvex-settings-form">

        <input type="hidden" name="cnvex_update_action" value="update_admin_settings_form" id="cnvex_update_action"/>
        <input type="hidden" name="action" value="cnvex_save_settings">
        <input type="hidden" name="cnvex_form_id" value="<?php echo esc_attr( $id ); ?>" id="cnvex_form_id"/>
        <input type="hidden" name="conversion-exporter[_cnvex_form_data_input]"
               value="<?php echo esc_attr( json_encode( $forms_data ) ); ?>" id="cnvex_form_data_input"/>
		<?php
		if ( function_exists( 'wp_create_nonce' ) ) {
			$nonce_value = wp_create_nonce( 'cnvex-update-' . CNVEX_SETTINGS_FIELD  );
			echo '<input type="hidden" id="cnvex_nonce" name="_wpnonce" value="' . esc_attr( $nonce_value ) . '">';
		}
        ?>
        <div class="card card-static card-style3">
            <div class="card-body">
                <div class="gap-24">
                    <div class="list-item">
                        <div class="d-flex align-items-center">
							<?php Form()->renderSwitcherInput( '_cnvex_enable', true, $id ); ?>
                            <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Enable Form', 'conversion-exporter' ); ?></h4>
                        </div>
                    </div>

                    <div class="list-item">
                        <h4 class="font-semibold-type2 mb-4">
							<?php esc_html_e( 'Form name', 'conversion-exporter' ); ?><span class="text-red"> *</span>:
                        </h4>
						<?php Form()->renderTextInput( '_cnvex_form_name', true, $id, '', 'js-control-element', 'required' ); ?>
                    </div>

                    <div class="list-item">
                        <div class="line mb-24"></div>

                        <h4 class="font-semibold-type2 mb-4">
							<?php esc_html_e( 'Page URL to scan', 'conversion-exporter' ); ?>:</h4>

                        <div class="scan-form">
							<?php Form()->renderTextInput( '_cnvex_page_url', true, $id, '', 'js-control-element' ); ?>

                            <div class="scan-button-wrap">
                                <button type="button" id="cnvex_scan_button" class="btn btn-primary btn-primary-type2">
									<?php esc_html_e( 'Scan', 'conversion-exporter' ); ?>
                                </button>
								<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/spinner.php"; ?>
                            </div>
                        </div>

                        <div class="error-message mt-24"
                             style="<?php echo empty( $message ) ? 'display: none;' : ''; ?>">
							<?php HelperNotices::renderCriticalMessage( $message ); ?>
                        </div>
                    </div>

                    <div class="list-item map-list-wrap <?php echo empty( $page_url ) || empty( $forms_data ) ? 'cnvex-hidden' : '' ?>">
                        <div class="mb-24">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Select form', 'conversion-exporter' ); ?>:
                            </h4>

							<?php Form()->renderSelectInput( '_cnvex_form', $form_options, true, $id, __( 'Select form', 'conversion-exporter' ), false, '', 'full' ); ?>

                        </div>

                        <div class="map-list">
                            <div id="cnvex_form_data_container" class="cnvex-hidden">
                                <select name="_cnvex_form_fields"
                                        id="cnvex_form_data"
                                >
									<?php if ( !empty( $forms_data ) ) :
										foreach ( $forms_data as $form ) :
											$form_name = isset( $form[ 'id' ] ) && $form[ 'id' ] != '' ? 'form#' . $form[ 'id' ] : ( $form[ 'selector' ] ?? '' );
											$form_id = isset( $form[ 'id' ] ) && $form[ 'id' ] != '' ? '#' . $form[ 'id' ] : ( $form[ 'selector' ] ?? '' );
											if ( !empty( $form_name ) ) {
												if ( isset( $form[ 'fields' ] ) && is_array( $form[ 'fields' ] ) ) {
													foreach ( $form[ 'fields' ] as $field ) {
														?>
                                                        <option value="<?php esc_attr_e( $field[ 'value' ] ); ?>"
                                                                data-form-id="<?php echo esc_attr( $form_id ); ?>"
                                                                data-form-type="<?php echo esc_attr( $form_type ); ?>"
                                                        >
															<?php echo esc_attr( $field[ 'name' ] ); ?>
                                                        </option>
														<?php
													}
												}
											}
										endforeach;
									endif; ?>
                                </select>
                            </div>

                            <div class="cnvex-hidden">
                                <input type="hidden"
                                       name="<?php echo esc_attr( $this->getPluginSlug() ); ?>[_cnvex_form_type]"
                                       id="_cnvex_form_type"
                                       value="<?php echo esc_attr( $form_type ); ?>"
                                >
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Select email field', 'conversion-exporter' ); ?><span
                                            class="text-red">*</span>:
                                </h4>

								<?php Form()->renderSelectInput( '_cnvex_email_field', $form_fields, true, $id, __( 'Select email field', 'conversion-exporter' ), false, '', 'full' ); ?>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Select first name field', 'conversion-exporter' ); ?>:
                                </h4>

								<?php Form()->renderSelectInput( '_cnvex_first_name_field', $form_fields, true, $id, __( 'Select first name field', 'conversion-exporter' ), false, '', 'full' ); ?>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Select last name field', 'conversion-exporter' ); ?>:
                                </h4>

								<?php Form()->renderSelectInput( '_cnvex_last_name_field', $form_fields, true, $id, __( 'Select last name field', 'conversion-exporter' ), false, '', 'full' ); ?>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Select phone (optional)', 'conversion-exporter' ); ?>:
                                </h4>

								<?php Form()->renderSelectInput( '_cnvex_phone_field', $form_fields, true, $id, __( 'Select phone', 'conversion-exporter' ), false, '', 'full' ); ?>
                            </div>
                        </div>
                    </div>

                    <div class="line"></div>

                    <div class="list-item">
                        <h4 class="font-semibold-type2 mb-12">
							<?php esc_html_e( 'Form information', 'conversion-exporter' ); ?>:
                        </h4>
                        <p class="mb-4"><?php esc_html_e( 'Forms captured', 'conversion-exporter' ); ?>:
                            <span class="font-semibold-type2"><?php echo count( $current_form_data ); ?></span>
                        </p>

                        <p class="mb-12"><?php esc_html_e( 'Forms with GCLID', 'conversion-exporter' ); ?>:
                            <span class="font-semibold-type2"><?php echo esc_html( $count_gclid ); ?></span>
                        </p>

						<?php if ( !empty( $used_exports ) ) : ?>
                            <p class="mb-4">
								<?php esc_html_e( 'This form is used by the following conversion tasks', 'conversion-exporter' ); ?>
                                :
                            </p>

                            <ul class="cnvex-list">
								<?php foreach ( $used_exports as $export ) : ?>
                                    <li>
                                        <a href="<?php echo esc_url( $export[ 'url' ] ); ?>"
                                           class="link" target="_blank">
											<?php echo esc_html( $export[ 'name' ] ); ?>
                                        </a>
                                        -
                                        <span class="font-semibold-type2"">
										<?php echo esc_html( $export[ 'last_export' ] ); ?>
                                        </span>
                                    </li>
								<?php endforeach; ?>
                            </ul>
						<?php else :
							HelperNotices::renderInfoMessage( __( 'This form is not used by any conversion task.', 'conversion-exporter' ) );
						endif; ?>
                    </div>

                    <div class="line"></div>

                    <div class="list-item">

                        <h4 class="font-semibold-type2 mb-4">
							<?php esc_html_e( 'Data Retention options', 'conversion-exporter' ); ?>:
                        </h4>

						<?php Form()->renderSelectInput( '_cnvex_data_retention', $data_retention_options, true, $id );
						$data_retention = get_post_meta( $id, '_cnvex_data_retention', true );
						?>

                        <div id="cnvex-auto-delete" class="mt-24"
                             style="<?php echo $data_retention == 'auto' ? '' : 'display: none'; ?>">
                            <h4 class="font-semibold-type2 mb-8">
								<?php esc_html_e( 'Auto-delete after', 'conversion-exporter' ); ?>:
                            </h4>

                            <div class="delete-option-group">
                                <div class="delete-option">
									<?php Form()->renderNumberInput( '_cnvex_delete_days', true, $id ); ?>
                                    <span><?php esc_html_e( 'days', 'conversion-exporter' ); ?></span>
                                </div>

                                <div>
									<?php esc_html_e( 'Or', 'conversion-exporter' ); ?>
                                </div>

                                <div class="delete-option">
									<?php Form()->renderNumberInput( '_cnvex_delete_entries', true, $id ); ?>
                                    <span><?php esc_html_e( 'entries', 'conversion-exporter' ); ?></span>
                                </div>
                            </div>

                            <p class="text-gray mt-8"><?php esc_html_e( 'Use 0 to disable any option.', 'conversion-exporter' ); ?></p>
                        </div>
                    </div>


					<?php
					$email = get_post_meta( $id, '_cnvex_email_field', true );
					if ( empty( $email ) ) {
						HelperNotices::renderWarningMessage( __( 'You have not select an email field. Please scan the page and select email field.', 'conversion-exporter' ) );
					}
					?>
                </div>
            </div>
        </div>
    </form>
</div>
