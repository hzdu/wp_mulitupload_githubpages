<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$meta = get_post_meta( $id );
$enabled = $meta[ '_cnvex_enable' ][ 0 ] == '1';

$current_form_data = Form()->getFormData( $id );
$count_gclid = count( array_filter( $current_form_data, function ( $item ) {
	return array_key_exists( 'gclid', $item ) && !empty( $item[ 'gclid' ] );
} ) );

$current_form_data = Form()->getFormData( $id );

$last_exported = Form()->getLastExportedForm( $id );
if ( empty( $last_exported ) ) {
	$last_exported = __( 'Never', 'conversion-exporter' );
}
?>

<div class="forms-wrap <?php echo $enabled ? '' : 'disabled'; ?>"
     id="cnvex-form-<?php echo esc_attr( $id ); ?>"
     data-id="<?php echo esc_attr( $id ); ?>">
    <div class="card card-static card-style2">
        <div class="card-header card-header-style1 disable-card-wrap">
            <div class="form-item">
                <div class="form-actions-wrap">
                    <div class="enable-form">
						<?php Form()->renderSwitcherInput( '_cnvex_enable', true, $id, false, false, false, false, true ); ?>
                        <h4 class="secondary-heading switcher-label"><?php esc_attr_e( $meta[ '_cnvex_form_name' ][ 0 ] ); ?></h4>
                    </div>

                    <div class="form-actions">
                        <div class="form-actions-buttons">
                            <div class="form-enabled-actions action-buttons">
                                <a href="<?php echo esc_url( get_admin_url( null, 'admin.php?page=conversion-exporter' ) . '&form_id=' . $id ); ?>"
                                   class="btn btn-gray-type2 with-small-icon btn-primary-type2"><i
                                            class="icon-edit"></i>
                                    <span>
	                                    <?php esc_html_e( 'Edit', 'conversion-exporter' ); ?>
                                    </span>
                                </a>

                                <button type="button" data-id="<?php echo esc_attr( $id ); ?>"
                                        class="btn btn-red btn-primary-type2 with-small-icon form_delete_btn">
                                    <i class="icon-delete"></i>
                                    <span>
                                        <?php esc_html_e( 'Delete', 'conversion-exporter' ); ?>
                                    </span>
                                </button>
                            </div>

                            <div class="form-disabled-actions">
                                <p class="text-gray text-extra-small fw-500">
									<?php esc_html_e( 'Disabled', 'conversion-exporter' ); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-body">
            <p>
                <span class="font-semibold text-gray text-small"><?php esc_html_e( 'Forms captured', 'conversion-exporter' ); ?>: </span>
                <span class="text-gray text-small"><?php echo count( $current_form_data ); ?></span>
            </p>

            <p>
                <span class="font-semibold text-gray text-small"><?php esc_html_e( 'Forms with GCLID', 'conversion-exporter' ); ?>: </span>
                <span class="text-gray text-small"><?php echo esc_html( $count_gclid ); ?></span>
            </p>

            <p>
                <span class="font-semibold text-gray text-small"><?php esc_html_e( 'Last exported', 'conversion-exporter' ); ?>: </span>
                <span class="text-gray text-small"><?php echo esc_html( $last_exported ); ?></span>
            </p>
        </div>
    </div>
</div>