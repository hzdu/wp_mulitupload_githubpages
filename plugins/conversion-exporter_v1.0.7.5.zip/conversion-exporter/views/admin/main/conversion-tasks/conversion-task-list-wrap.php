<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$meta    = get_post_meta( $id );
$enabled = $meta[ '_cnvex_enable' ][ 0 ] == '1';

$last_update = get_post_meta( $id, '_cnvex_last_export', true );
if ( empty( $last_update ) ) {
	$last_time = __( 'Never', 'conversion-exporter' );
} else {
	$last_time = date( "Y-m-d H:i:s", $last_update );
}

$last_crawl = FileManager()->getLastCrawledFile( $id );
if ( empty( $last_crawl ) ) {
	$last_crawl = __( 'Never', 'conversion-exporter' );
}

$conversion_type    = get_post_meta( $id, '_cnvex_conversion_type', true );
$conversion_options = array(
	'clicks'            => __( 'Conversions from clicks', 'conversion-exporter' ),
	'clicks_enhanced'   => __( 'Conversions from clicks (Enhanced for leads)', 'conversion-exporter' ),
	'adjustments_order' => __( 'Conversions adjustments using Order ID', 'conversion-exporter' )
);

?>

<div class="exports-wrap <?php echo $enabled ? '' : 'disabled'; ?>"
     id="cnvex-conversion-task-<?php echo esc_attr( $id ); ?>"
     data-id="<?php echo esc_attr( $id ); ?>">
    <div class="card card-static card-style2">
        <div class="card-header card-header-style1 disable-card-wrap">
            <div class="export-item">
                <div class="export-actions-wrap">
                    <div class="enable-export">
						<?php ConversionExport()->renderSwitcherInput(
							'_cnvex_enable',
							true,
							$id,
							false,
							false,
							false,
							false,
							true
						); ?>
                        <h4 class="secondary-heading switcher-label"><?php esc_attr_e(
								$meta[ '_cnvex_conversion_name' ][ 0 ]
							); ?></h4>
                    </div>

                    <div class="export-actions">
                        <div class="export-actions-buttons">
                            <div class="export-enabled-actions action-buttons">
                                <a href="<?php echo esc_url(
									get_admin_url( null, 'admin.php?page=conversion-exporter' ) . '&conversion_task_id='
									. $id
								); ?>"
                                   class="btn btn-gray-type2 with-small-icon btn-primary-type2"><i
                                            class="icon-edit"></i>
                                    <span>
	                                    <?php esc_html_e( 'Edit', 'conversion-exporter' ); ?>
                                    </span>
                                </a>

                                <button type="button" data-id="<?php echo esc_attr( $id ); ?>"
                                        class="btn btn-red btn-primary-type2 with-small-icon conversion_task_delete_btn">
                                    <i class="icon-delete"></i>
                                    <span>
                                        <?php esc_html_e( 'Delete', 'conversion-exporter' ); ?>
                                    </span>
                                </button>
                            </div>

                            <div class="export-disabled-actions">
                                <p class="text-gray text-extra-small fw-500">
									<?php esc_html_e( 'Disabled', 'conversion-exporter' ); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="conversion-task-list-wrap">
                <div>
					<?php if ( array_key_exists( $conversion_type, $conversion_options ) ) : ?>
                        <p>
                            <span class="font-semibold text-gray text-small"><?php esc_html_e(
									'Template type',
									'conversion-exporter'
								); ?>: </span>
                            <span class="text-gray text-small"><?php echo esc_html(
									$conversion_options[ $conversion_type ]
								); ?></span>
                        </p>
					<?php endif; ?>

                    <p>
                        <span class="font-semibold text-gray text-small"><?php esc_html_e(
								'Last update',
								'conversion-exporter'
							); ?>: </span>
                        <span class="text-gray text-small"><?php echo esc_html( $last_time ); ?></span>
                    </p>

                    <p>
                        <span class="font-semibold text-gray text-small"><?php esc_html_e(
								'Last Google crawl',
								'conversion-exporter'
							); ?>: </span>
                        <span class="text-gray text-small"><?php echo esc_html( $last_crawl ); ?></span>
                    </p>
                </div>

                <div class="regenerate-export-list-wrap">
                    <button type="button"
                            class="btn btn-primary btn-primary-type2 regenerate-export"
                            data-id="<?php echo esc_attr( $id ); ?>"
                    >
						<?php esc_html_e( 'Regenerate CSV files', 'conversion-exporter' ); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>