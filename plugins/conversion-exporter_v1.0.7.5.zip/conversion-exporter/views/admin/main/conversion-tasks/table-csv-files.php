<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !empty( $files ) ) : ?>
    <div class="cnvex-table-wrap">
        <h4 class="font-semibold-type2 mb-4">
			<?php esc_html_e( 'The list of created conversion files', 'conversion-exporter' ); ?>:
        </h4>

        <div class="cnvex-table-inner">
            <table border="1" cellpadding="5" cellspacing="0" class="cnvex-table table-files">
                <thead>
                <tr>
                    <th class="column1 text-small centered"><?php esc_html_e( 'Status', 'conversion-exporter' ); ?></th>
                    <th class="column2 text-small"><?php esc_html_e( 'File name', 'conversion-exporter' ); ?></th>
                    <th class="column3 text-small"><?php esc_html_e( 'Created', 'conversion-exporter' ); ?></th>
                    <th class="column4 text-small"><?php esc_html_e( 'ADS Downloaded', 'conversion-exporter' ); ?></th>
                    <th class="column5"></th>
                    <th class="column6"></th>
                </tr>
                </thead>
                <tbody>

				<?php
				foreach ( $files as $file ) {
					$filePath = FileManager()->getFilePath( $id, $file[ 'uuid' ] );
					$schedule = get_post_meta( $id, '_cnvex_use_schedule', true );
					if ( $schedule ) {
						$label = ( ( empty( $file[ 'downloaded_date' ] ) && $file[ 'main_file' ] ) ? __( 'Pending', 'conversion-exporter' ) : ( $file[ 'ads_downloaded' ] ? '<i class="icon-check"></i>' : '<i class="icon-close"></i>' ) );
					} else {
						$label = '<i class="icon-check"></i>';
					}
					if ( is_file( $filePath ) ) {
						echo '<tr>';
						echo '<td class="text-small centered">' . wp_kses_post( $label ) . '</td>';
						echo '<td class="text-small">' . esc_html( $file[ 'real_name' ] ) . '</td>';
						echo '<td class="text-small">' . esc_html( $file[ 'created_at' ] ) . '</td>';
						echo '<td class="text-small">' . ( !empty( $file[ 'downloaded_date' ] ) ? esc_html( $file[ 'downloaded_date' ] ) : '' ) . '</td>';
						echo '<td class="file-actions">
                            <a href="#" class="button-link link-edit download_conversion_file" data-filename="' . esc_html( $file[ 'real_name' ] ) . '">' . esc_html__( 'Download', 'conversion-exporter' ) . '</a>
                          </td>';
						echo '<td>
                            <a href="#" class="button-link link-delete delete_conversion_file" data-filename="' . esc_html( $file[ 'real_name' ] ) . '">' . esc_html__( 'Delete', 'conversion-exporter' ) . '</a>
                          </td>';
						echo '</tr>';
					}
				}
				?>
                </tbody>
            </table>
        </div>
    </div>

<?php else :
	HelperNotices::renderInfoMessage( __( 'No downloaded files yet', 'conversion-exporter' ) );
endif; ?>



