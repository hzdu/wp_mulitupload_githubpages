<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$id = sanitize_text_field( $_GET[ 'conversion_task_id' ] );

$source_options = array(
	'form' => __( 'Form', 'conversion-exporter' ),
);

$order_statuses = array();

if ( HelperFunctions::isWoocommerceActive() ) {
	$source_options[ 'woo' ] = __( 'WooCommerce', 'conversion-exporter' );
	$wc_order_statuses = wc_get_order_statuses();
	foreach ( $wc_order_statuses as $key => $status ) {
		$new_key = str_replace( 'wc-', '', $key );
		$order_statuses[ $new_key ] = $status;
	}
}

$form_options = Form()->getForms();

$conversion_options = array(
	'clicks'            => __( 'Conversions from clicks', 'conversion-exporter' ),
	'clicks_enhanced'   => __( 'Conversions from clicks (Enhanced for leads)', 'conversion-exporter' ),
);

if ( HelperFunctions::isWoocommerceActive() ) {
	$conversion_options[ 'adjustments_order' ] = __( 'Conversions adjustments using Order ID', 'conversion-exporter' );
}

$conversion_format_options = array(
	'data_manager' => __( 'Google Ads Data Manager format', 'conversion-exporter' ),
	'uploads'      => __( 'Conversion Uploads format', 'conversion-exporter' ),
);

$main_file = FileManager()->getMainFile( $id );
$full_file = FileManager()->getFullFile( $id );
$files = FileManager()->getFilesByExportId( $id );
$current_generation_full = FileManager()->currentGeneratingTask( $id, false );
$current_generation_main = FileManager()->currentGeneratingTask( $id );

$conversion_type = get_post_meta( $id, '_cnvex_conversion_type', true );
$conversion_format = get_post_meta( $id, '_cnvex_conversion_format', true );
$generation_method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';

?>

<div class="container">
    <form method="post"
          action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
          class="cnvex-settings-form">

        <input type="hidden" name="cnvex_update_action" value="update_admin_settings_form" id="cnvex_update_action"/>
        <input type="hidden" name="action" value="cnvex_save_settings">
        <input type="hidden" name="cnvex_conversion_task_id" value="<?php echo esc_attr( $id ); ?>"
               id="cnvex_conversion_task_id"/>
        <input type="hidden" name="cnvex_delete_conversion_file" value="" id="cnvex_delete_conversion_file">

		<?php if ( $current_generation_full ) : ?>
            <input type="hidden" name="cnvex_current_generation_full" value="1"
                   id="cnvex_current_generation_full">
		<?php endif;

		if ( $current_generation_main ) : ?>
            <input type="hidden" name="cnvex_current_generation_main" value="1"
                   id="cnvex_current_generation_main">
		<?php endif;

		if ( function_exists( 'wp_create_nonce' ) ) {
			$nonce_value = wp_create_nonce( 'cnvex-update-' . CNVEX_SETTINGS_FIELD  );
			echo '<input type="hidden" id="cnvex_nonce" name="_wpnonce" value="' . esc_attr( $nonce_value ) . '">';
		}
        ?>
        <div class="conversion-item">
            <div class="card card-static card-style3">
                <div class="card-body">
                    <div class="gap-24">
	                    <?php if ( $generation_method === 'wp-cron' && defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
		                    HelperNotices::renderCriticalMessage( sprintf(
			                    esc_html__( 'Warning! Cron is disabled and WP-Cron is used for export. Conversion exporter may not work correctly. Please select another generation method on the %ssettings page%s', 'conversion-exporter' ),
			                    '<a href="' . esc_url( get_admin_url( null, 'admin.php?page=cnvex-settings' ) )
			                    . '" target="_blank" class="link link-small">',
			                    '</a>' ) );

	                    } ?>

                        <div class="list-item">
                            <div class="d-flex align-items-center">
								<?php ConversionExport()->renderSwitcherInput( '_cnvex_enable', true, $id ); ?>
                                <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Enable Conversion Task', 'conversion-exporter' ); ?></h4>
                            </div>
                        </div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Task name', 'conversion-exporter' ); ?><span
                                        class="text-red"> *</span>:</h4>
							<?php ConversionExport()->renderTextInput( '_cnvex_conversion_name', true, $id, '', 'js-control-element', 'required' ); ?>

                            <p class="text-gray mt-4 m-mt-8"><?php echo sprintf( esc_html__( 'For internal use only.', 'conversion-exporter' ), '<b>', '</b>' ); ?></p>
                        </div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Conversion URL', 'conversion-exporter' ); ?>:</h4>
							<?php $url = get_post_meta( $id, '_cnvex_conversion_url', true ); ?>

                            <div class="card card-style8 conversion-url-edit">
                                <div class="card-header card-header-style3">
                                    <div class="gap-8">
                                        <a href="<?php echo esc_url( $url ); ?>" class="link conversion-link"
                                           target="_blank"><?php echo esc_url( $url ); ?></a>
                                    </div>

									<?php HelperFunctions::cardCollapseSettingsWithText( 'Edit url' ); ?>
                                </div>

                                <div class="card-body">
									<?php ConversionExport()->renderTextInput( '_cnvex_conversion_url', true, $id, '', 'js-control-element' ); ?>
                                </div>
                            </div>
                        </div>

                        <div class="list-item d-flex align-items-center">
							<?php ConversionExport()->renderSwitcherInput( '_cnvex_consent_enable', true, $id ); ?>

                            <h4 class="secondary-heading switcher-label"><?php echo sprintf( esc_html__( 'Enable Consent. Configure the settings %shere%s', 'conversion-exporter' ), '<a href="' . esc_url( get_admin_url( null, 'admin.php?page=cnvex-settings' ) ) . '" target="_blank" class="link">', '</a>' ); ?></h4>
                        </div>

                        <div class="line"></div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
			                    <?php esc_html_e( 'Conversion format', 'conversion-exporter' ); ?>:
                            </h4>

		                    <?php ConversionExport()->renderSelectInput( '_cnvex_conversion_format', $conversion_format_options, true, $id, '', false, false, 'middle' ); ?>

                            <div id="cnvex-conversion-format-uploads" class="mt-16" <?php echo ( $conversion_format == 'data_manager' ) ? 'style="display: none"' : ''; ?>>
			                    <?php HelperNotices::renderInfoMessage( __( 'It uses in Google Ads > Goals > Conversions > Uploads', 'conversion-exporter' ) ); ?>
                            </div>

                            <div id="cnvex-conversion-format-data-manager" class="mt-16" <?php echo ( $conversion_format == 'uploads' ) ? 'style="display: none"' : ''; ?>>
			                    <?php HelperNotices::renderInfoMessage( __( 'It uses in Google Ads > Tools > Data Manager > HTTPS', 'conversion-exporter' ) ); ?>
                            </div>

                            <div class="mt-24" id="cnvex-conversion-type-wrap" <?php echo ( $conversion_format == 'data_manager' ) ? 'style="display: none"' : ''; ?>>
                                <h4 class="font-semibold-type2 mb-4">
			                        <?php esc_html_e( 'Conversion type', 'conversion-exporter' ); ?>:
                                </h4>

		                        <?php ConversionExport()->renderSelectInput( '_cnvex_conversion_type', $conversion_options, true, $id, '', false, false, 'middle' ); ?>

                                <div id="cnvex-gclid-notice"
                                     class="mt-16" <?php echo ( $conversion_type == 'clicks_enhanced' || $conversion_type == 'adjustments_order' ) ? 'style="display: none"' : ''; ?>>
			                        <?php HelperNotices::renderInfoMessage( __( 'GCLID is required for this type of conversion export. Only entries where GCLID was captured will be exported.', 'conversion-exporter' ) ); ?>
                                </div>
                            </div>
                        </div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
			                    <?php esc_html_e( 'Conversion name', 'conversion-exporter' ); ?><span
                                        class="text-red"> *</span>:</h4>
		                    <?php ConversionExport()->renderTextInput( '_cnvex_conversion_task_name', true, $id, '', 'js-control-element', 'required' ); ?>

                            <p class="text-gray mt-4 m-mt-8"><?php echo sprintf( esc_html__( 'Use the %sexact conversion name%s from Google Ads — spelling and spaces must match.', 'conversion-exporter' ), '<b>', '</b>' ); ?></p>
                        </div>

                        <div class="list-item">
							<?php $source = get_post_meta( $id, '_cnvex_source', true ); ?>
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Source', 'conversion-exporter' ); ?>:
                            </h4>

                            <div class="mb-24">
								<?php ConversionExport()->renderSelectInput( '_cnvex_source', $source_options, true, $id ); ?>
                            </div>

							<?php if ( HelperFunctions::isWoocommerceActive() ) : ?>
                                <div id="cnvex-source-woo" <?php echo $source === 'woo' ? '' : 'style="display: none"'; ?>>
                                    <div id="cnvex_order_statuses_wrap" class="mb-24" <?php echo ( $conversion_format == 'uploads' && $conversion_type == 'adjustments_order' ) ? 'style="display: none"' : ''; ?>>
                                        <h4 class="font-semibold-type2 mb-4">
											<?php esc_html_e( 'Order statuses to include in the conversion task', 'conversion-exporter' );
											?>:
                                        </h4>

										<?php ConversionExport()->renderMultiSelectInput( '_cnvex_order_statuses', $order_statuses, true, $id ); ?>
                                    </div>

                                    <div class="d-flex align-items-center mb-24">
										<?php ConversionExport()->renderSwitcherInput( '_cnvex_woo_include_data', true, $id ); ?>
                                        <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Include Converted Lead Data', 'conversion-exporter' ); ?></h4>
                                    </div>

                                    <div class="d-flex align-items-center">
										<?php ConversionExport()->renderSwitcherInput( '_cnvex_woo_include_value', true, $id ); ?>
                                        <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Include Value', 'conversion-exporter' ); ?></h4>
                                    </div>

									<?php $conversion_type = get_post_meta( $id, '_cnvex_conversion_type', true ); ?>

                                    <div id="cnvex-woo-not-track-by-tag" class="mt-24">
										<?php if ( HelperFunctions::isPYSActivated() ) : ?>
                                            <div class="d-flex align-items-center">
												<?php ConversionExport()->renderSwitcherInput( '_cnvex_orders_not_track_by_tag', true, $id ); ?>
                                                <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Only orders not tracked by the PixelYourSite Google Tag', 'conversion-exporter' ); ?></h4>
                                            </div>
										<?php else : ?>
                                            <div class="dimmy_checkbox d-flex align-items-center">
												<?php ConversionExport()->renderSwitcherInput( '_cnvex_orders_not_track_by_tag', true, null, true ); ?>
                                                <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Only orders not tracked by the PixelYourSite Google Tag', 'conversion-exporter' ); ?></h4>
                                            </div>

                                            <div class="mt-8">
												<?php HelperNotices::renderWarningMessage( __( 'This option needs PixelYourSite Professional or PixelYourSite free', 'conversion-exporter' ) ); ?>
                                            </div>
										<?php endif; ?>
                                    </div>
                                </div>
							<?php endif; ?>

                            <div id="cnvex-source-form" <?php echo ( $source === 'form' || !HelperFunctions::isWoocommerceActive() ) ? '' : 'style="display: none"'; ?>>
                                <div class="mb-24">
                                    <h4 class="font-semibold-type2 mb-4">
										<?php esc_html_e( 'Select one or more captured forms', 'conversion-exporter' ); ?>
                                        :
                                    </h4>

									<?php ConversionExport()->renderMultiSelectInput( '_cnvex_form_ids', $form_options, true, $id ); ?>
                                </div>

                                <div class="mb-24">
                                    <h4 class="font-semibold-type2">
										<?php esc_html_e( 'Fixed value', 'conversion-exporter' ); ?>:</h4>
									<?php ConversionExport()->renderTextInput( '_cnvex_form_value', true, $id, '', 'js-control-element', false, false, 'standard' ); ?>
                                </div>

                                <div>
                                    <h4 class="font-semibold-type2">
										<?php esc_html_e( 'Fixed currency', 'conversion-exporter' ); ?>:</h4>
									<?php ConversionExport()->renderTextInput( '_cnvex_form_currency', true, $id, '', 'js-control-element', false, false, 'standard' ); ?>
                                </div>

                            </div>
                        </div>

                        <div class="list-item d-flex align-items-center">
		                    <?php ConversionExport()->renderSwitcherInput( '_cnvex_items_only_with_gclid', true, $id ); ?>

                            <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Only entries with GCLID', 'conversion-exporter' ); ?></h4>
                        </div>

                        <div class="line"></div>

                        <div class="list-item" id="cnvex-export-data-range">
                            <div>
                                <h4 class="font-semibold-type2 mb-4">
									<?php esc_html_e( 'Start generation from date', 'conversion-exporter' ); ?>:
                                </h4>

                                <input type="text"
                                       class="cnvex-datepicker cnvex-datepickers-from input-standard"
                                       name="<?php echo esc_attr( $this->getPluginSlug() ); ?>[_cnvex_date_from]"
                                       value="<?php echo esc_attr( get_post_meta( $id, '_cnvex_date_from', true ) ); ?>"
                                       autocomplete="off"
                                       placeholder="<?php esc_attr_e( 'Select date', 'conversion-exporter' ); ?>"
                                />

                                <p class="text-gray mt-4 m-mt-8"><?php esc_html_e( 'This conversion will start with data from this field. Auto-updates will get data starting from the previous update.', 'conversion-exporter' ); ?></p>
                                <p class="text-gray mt-4"><?php esc_html_e( 'Leave empty for unlimited', 'conversion-exporter' ); ?></p>
                            </div>
                        </div>

                        <div class="list-item">
                            <div class="d-flex align-items-center">
								<?php ConversionExport()->renderSwitcherInput( '_cnvex_use_schedule', true, $id ); ?>
                                <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Detect when the Google Ads crawler accesses the file and mark it as loaded', 'conversion-exporter' ); ?></h4>
                            </div>

                            <p class="text-gray mt-4"><?php esc_html_e( 'Data will be updated starting from that moment', 'conversion-exporter' ); ?></p>
                        </div>

                        <div class="line"></div>

                        <div class="list-item task-gray-bg">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'File download link', 'conversion-exporter' ); ?>:
                            </h4>

                            <div id="cnvex-main-file-download" class="mb-24">
								<?php if ( !empty( $main_file ) ) : ?>
									<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/main/conversion-tasks/main-file-download.php"; ?>
								<?php else : ?>
									<?php
									if ( $current_generation_main ) {
										HelperNotices::renderInfoMessage( __( 'Generating the file', 'conversion-exporter' ) );
									} else {
										HelperNotices::renderInfoMessage( __( 'No files yet', 'conversion-exporter' ) );
									} ?>
								<?php endif; ?>
                            </div>

                            <h4 class="font-semibold-type2 mb-16">
								<?php esc_html_e( 'Password protection', 'conversion-exporter' ); ?>:
                            </h4>

                            <div class="password-protection-wrap">
                                <div>
                                    <h4 class="font-semibold-type2 mb-4">
										<?php esc_html_e( 'Username', 'conversion-exporter' ); ?>:
                                    </h4>

                                    <div class="copy-block-wrap mb-16">
										<?php
										$username = get_post_meta( $id, '_cnvex_username', true );
										?>

										<?php ConversionExport()->renderTextInput( '_cnvex_username', true, $id, '', 'js-control-element', false, false, 'standard' ); ?>

                                        <div class="input-copy"
                                             onclick="copyShortcode( '<?php echo esc_html( $username ); ?>', this)">
											<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <h4 class="font-semibold-type2 mb-4">
										<?php esc_html_e( 'Password', 'conversion-exporter' ); ?>:
                                    </h4>

                                    <div class="copy-block-wrap">
										<?php
										$username = get_post_meta( $id, '_cnvex_password', true );
										?>

										<?php ConversionExport()->renderPasswordInput( '_cnvex_password', true, $id, '', 'js-control-element' ); ?>

                                        <div class="input-copy"
                                             onclick="copyShortcode( '<?php echo esc_html( $username ); ?>', this)">
											<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="list-item task-gray-bg">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Last generation time', 'conversion-exporter' ); ?>:
                            </h4>

                            <div id="cnvex-last-generation-time" class="mb-16">
								<?php $last_time = get_post_meta( $id, '_cnvex_last_export', true );
								if ( empty( $last_time ) ) : ?>
									<?php HelperNotices::renderInfoMessage( __( 'No files yet', 'conversion-exporter' ) ); ?>
								<?php else :
									$last_time = date( "Y-m-d H:i:s", $last_time );
									?>
                                    <p><?php echo esc_html( $last_time ); ?></p>
								<?php endif; ?>
                            </div>

                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Last crawled the file', 'conversion-exporter' ); ?>:
                            </h4>

                            <div>
								<?php $last_crawl = FileManager()->getLastCrawledFile( $id );
								if ( empty( $last_crawl ) ) : ?>
									<?php HelperNotices::renderInfoMessage( __( 'Never', 'conversion-exporter' ) ); ?>
								<?php else :
									?>
                                    <p><?php echo esc_html( $last_crawl ); ?></p>
								<?php endif; ?>
                            </div>
                        </div>

                        <div class="list-item" id="cnvex-csv-files-list">
                            <h4 class="font-semibold-type2 mb-4">
								<?php require_once CNVEX_PLUGIN_VIEWS_PATH . 'admin/main/conversion-tasks/table-csv-files.php'; ?>
                        </div>

                        <div class="list-item task-gray-bg">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Full file download link', 'conversion-exporter' ); ?>:
                            </h4>

                            <div id="cnvex-full-file-download">
								<?php
								$full_disabled = apply_filters( 'cnvex_disable_full_file_generation', false, $id );
								if ( $full_disabled ) {
									HelperNotices::renderWarningMessage( __( 'Full file generation is disabled by a filter', 'conversion-exporter' ) );
								} else {
									if ( !empty( $full_file ) ) {
										include CNVEX_PLUGIN_VIEWS_PATH . "admin/main/conversion-tasks/full-file-download.php";
									} else {
										if ( $current_generation_full ) {
											HelperNotices::renderInfoMessage( __( 'Generating the file', 'conversion-exporter' ) );
										} else {
											HelperNotices::renderInfoMessage( __( 'No files yet', 'conversion-exporter' ) );
										}
									}
								} ?>
                            </div>
                        </div>

						<?php
						$error = get_post_meta( $id, '_cnvex_last_error', true );
						if ( !empty( $error ) ) {
							$error = __( 'Last error: ', 'conversion-exporter' ) . $error;
							HelperNotices::renderCriticalMessage( $error );
						}
						?>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-delete-conversion-file.php"; ?>
<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-error-download-conversion.php"; ?>
<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-generation-confirmation.php"; ?>