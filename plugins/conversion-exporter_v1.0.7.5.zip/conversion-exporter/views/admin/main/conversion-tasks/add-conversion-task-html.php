<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$order_statuses = array();
$source_options = array();

if ( HelperFunctions::isWoocommerceActive() ) {
	$source_options[ 'woo' ] = __( 'WooCommerce', 'conversion-exporter' );
	$wc_order_statuses       = wc_get_order_statuses();
	foreach ( $wc_order_statuses as $key => $status ) {
		$new_key                    = str_replace( 'wc-', '', $key );
		$order_statuses[ $new_key ] = $status;
	}
}

$source_options[ 'form' ] = __( 'Form', 'conversion-exporter' );
$form_options             = Form()->getForms();

$conversion_options = array(
	'clicks'            => __( 'Conversions from clicks', 'conversion-exporter' ),
	'clicks_enhanced'   => __( 'Conversions from clicks (Enhanced for leads)', 'conversion-exporter' ),
);

if ( HelperFunctions::isWoocommerceActive() ) {
	$conversion_options[ 'adjustments_order' ] = __( 'Conversions adjustments using Order ID', 'conversion-exporter' );
}

$conversion_format_options = array(
	'data_manager' => __( 'Google Ads Data Manager format', 'conversion-exporter' ),
	'uploads'      => __( 'Conversion Uploads format', 'conversion-exporter' ),
);

$generation_method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';

?>

<div class="container">
    <form method="post"
          action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
          class="cnvex-settings-form">

        <input type="hidden" name="cnvex_update_action" value="add_conversion_export" id="cnvex_update_action"/>
        <input type="hidden" name="action" value="cnvex_save_settings">
		<?php
		if ( function_exists( 'wp_create_nonce' ) ) {
			$nonce_value = wp_create_nonce( 'cnvex-update-' . CNVEX_SETTINGS_FIELD  );
			echo '<input type="hidden" id="cnvex_nonce" name="_wpnonce" value="' . esc_attr( $nonce_value ) . '">';
		}
        ?>
        <div class="conversion-item">
            <div class="card card-static card-style3">
                <div class="card-body">
                    <div class="gap-24">
						<?php if ( $generation_method === 'wp-cron' && defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
							HelperNotices::renderCriticalMessage( sprintf(
								esc_html__( 'Warning! Cron is disabled and WP-Cron is used for export. Conversion exporter may not work correctly. Please select another generation method on the %ssettings page%s', 'conversion-exporter' ),
								'<a href="' . esc_url( get_admin_url( null, 'admin.php?page=cnvex-settings' ) )
								. '" target="_blank" class="link link-small">',
								'</a>' ) );

						} ?>

                        <div class="list-item d-flex align-items-center">
							<?php ConversionExport()->renderSwitcherInput( '_cnvex_enable', true, null, false, false, true ); ?>
                            <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Enable Conversion Task', 'conversion-exporter' ); ?></h4>
                        </div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Task name', 'conversion-exporter' ); ?><span
                                        class="text-red"> *</span>:</h4>
							<?php ConversionExport()->renderTextInput( '_cnvex_conversion_name', true, null, '', 'js-control-element', 'required' ); ?>

                            <p class="text-gray mt-4 m-mt-8"><?php echo sprintf( esc_html__( 'For internal use only.', 'conversion-exporter' ), '<b>', '</b>' ); ?></p>
                        </div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Conversion URL', 'conversion-exporter' ); ?>:</h4>
							<?php ConversionExport()->renderTextInput( '_cnvex_conversion_url', true, null, '', 'js-control-element' ); ?>
                        </div>

                        <div class="list-item d-flex align-items-center">
							<?php ConversionExport()->renderSwitcherInput( '_cnvex_consent_enable', true, null, false, false, true ); ?>

                            <h4 class="secondary-heading switcher-label"><?php echo sprintf( esc_html__( 'Enable Consent. Configure the settings %shere%s', 'conversion-exporter' ), '<a href="'
							                                                                                                                                                         . esc_url( get_admin_url( null, 'admin.php?page=cnvex-settings' ) )
							                                                                                                                                                         . '" target="_blank" class="link">', '</a>' ); ?></h4>
                        </div>

                        <div class="line"></div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
			                    <?php esc_html_e( 'Conversion format', 'conversion-exporter' ); ?>:
                            </h4>

		                    <?php ConversionExport()->renderSelectInput( '_cnvex_conversion_format', $conversion_format_options, true, null, '', false, false, 'middle' ); ?>

                            <div id="cnvex-conversion-format-uploads" class="mt-16" style="display: none">
			                    <?php HelperNotices::renderInfoMessage( __( 'It uses in Google Ads > Goals > Conversions > Uploads', 'conversion-exporter' ) ); ?>
                            </div>

                            <div id="cnvex-conversion-format-data-manager" class="mt-16">
			                    <?php HelperNotices::renderInfoMessage( __( 'It uses in Google Ads > Tools > Data Manager > HTTPS', 'conversion-exporter' ) ); ?>
                            </div>

                            <div class="mt-24" style="display: none;" id="cnvex-conversion-type-wrap">
                                <h4 class="font-semibold-type2 mb-4">
			                        <?php esc_html_e( 'Conversion type', 'conversion-exporter' ); ?>:
                                </h4>

		                        <?php ConversionExport()->renderSelectInput( '_cnvex_conversion_type', $conversion_options, true, null, '', false, false, 'middle' ); ?>

                                <div id="cnvex-gclid-notice" class="mt-16">
			                        <?php HelperNotices::renderInfoMessage( __( 'GCLID is required for this type of conversion export. Only entries where GCLID was captured will be exported.', 'conversion-exporter' ) ); ?>
                                </div>
                            </div>
                        </div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
                                <?php esc_html_e( 'Conversion name', 'conversion-exporter' ); ?><span
                                        class="text-red"> *</span>:</h4>
                                <?php ConversionExport()->renderTextInput( '_cnvex_conversion_task_name', true, null, '', 'js-control-element', 'required' ); ?>

                            <p class="text-gray mt-4 m-mt-8"><?php echo sprintf( esc_html__( 'Use the %sexact conversion name%s from Google Ads — spelling and spaces must match.', 'conversion-exporter' ), '<b>', '</b>' ); ?></p>
                        </div>

                        <div class="list-item">
                            <h4 class="font-semibold-type2 mb-4">
								<?php esc_html_e( 'Source', 'conversion-exporter' ); ?>:
                            </h4>

                            <div class="mb-24">
								<?php ConversionExport()->renderSelectInput( '_cnvex_source', $source_options, true ); ?>
                            </div>

							<?php if ( HelperFunctions::isWoocommerceActive() ) : ?>
                                <div id="cnvex-source-woo">
                                    <div id="cnvex_order_statuses_wrap" class="mb-24">
                                        <h4 class="font-semibold-type2 mb-4">
											<?php esc_html_e( 'Order statuses to include in the conversion task', 'conversion-exporter' );
											?>:
                                        </h4>

										<?php
										$default_order_statuses = array(
											'completed',
											'processing'
										);
										ConversionExport()->renderMultiSelectInput( '_cnvex_order_statuses', $order_statuses, true, null, false, '', '', $default_order_statuses ); ?>
                                    </div>

                                    <div class="d-flex align-items-center mb-24">
										<?php ConversionExport()->renderSwitcherInput( '_cnvex_woo_include_data', true, null, false, false, true ); ?>
                                        <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Include Converted Lead Data', 'conversion-exporter' ); ?></h4>
                                    </div>

                                    <div class="d-flex align-items-center">
										<?php ConversionExport()->renderSwitcherInput( '_cnvex_woo_include_value', true, null, false, false, true ); ?>
                                        <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Include Value', 'conversion-exporter' ); ?></h4>
                                    </div>

                                    <div id="cnvex-woo-not-track-by-tag" class="mt-24">
										<?php if ( HelperFunctions::isPYSActivated() ) : ?>
                                            <div class="d-flex align-items-center">
												<?php ConversionExport()->renderSwitcherInput( '_cnvex_orders_not_track_by_tag', true ); ?>
                                                <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Only orders not tracked by the PixelYourSite Google Tag', 'conversion-exporter' ); ?></h4>
                                            </div>
										<?php else : ?>
                                            <div class="dimmy_checkbox d-flex align-items-center">
												<?php ConversionExport()->renderSwitcherInput( '_cnvex_orders_not_track_by_tag', true, null, true ); ?>
                                                <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Only orders not tracked by the PixelYourSite Google Tag', 'conversion-exporter' ); ?></h4>
                                            </div>

                                            <div class="mt-8">
												<?php HelperNotices::renderWarningMessage( __( 'This option needs PixelYourSite Professional or PixelYourSite free', 'conversion-exporter' ) ); ?>
                                            </div>
										<?php endif; ?>
                                    </div>
                                </div>
							<?php endif; ?>

                            <div id="cnvex-source-form" <?php echo !HelperFunctions::isWoocommerceActive() ? '' : 'style="display: none"'; ?>>
                                <div class="mb-24">
                                    <h4 class="font-semibold-type2 mb-4">
										<?php esc_html_e( 'Select one or more captured forms', 'conversion-exporter' ); ?>
                                        :
                                    </h4>

									<?php ConversionExport()->renderMultiSelectInput( '_cnvex_form_ids', $form_options, true ); ?>
                                </div>

                                <div class="mb-24">
                                    <h4 class="font-semibold-type2">
										<?php esc_html_e( ' Fixed value', 'conversion-exporter' ); ?>:</h4>
									<?php ConversionExport()->renderTextInput( '_cnvex_form_value', true, null, '', 'js-control-element', false, false, 'standard' ); ?>
                                </div>

                                <div>
                                    <h4 class="font-semibold-type2">
										<?php esc_html_e( ' Fixed currency', 'conversion-exporter' ); ?>:</h4>
									<?php ConversionExport()->renderTextInput( '_cnvex_form_currency', true, null, '', 'js-control-element', false, false, 'standard' ); ?>
                                </div>
                            </div>
                        </div>

                        <div class="list-item d-flex align-items-center">
		                    <?php ConversionExport()->renderSwitcherInput( '_cnvex_items_only_with_gclid', true ); ?>

                            <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Only entries with GCLID', 'conversion-exporter' ); ?></h4>
                        </div>

                        <div class="line"></div>

                        <div class="list-item">
                            <div id="cnvex-export-data-range">
                                <div>
                                    <h4 class="font-semibold-type2 mb-4">
										<?php esc_html_e( 'Start generation from date', 'conversion-exporter' ); ?>:
                                    </h4>

                                    <input type="text"
                                           class="cnvex-datepicker cnvex-datepickers-from input-standard"
                                           name="<?php echo esc_attr( $this->getPluginSlug() ); ?>[_cnvex_date_from]"
                                           autocomplete="off"
                                           placeholder="<?php esc_attr_e( 'Select date', 'conversion-exporter' ); ?>"
                                    />
                                    <p class="text-gray mt-4 m-mt-8"><?php esc_html_e( 'This conversion will start with data from this field. Auto-updates will get data starting from the previous update.', 'conversion-exporter' ); ?></p>
                                    <p class="text-gray mt-4"><?php esc_html_e( 'Leave empty for unlimited', 'conversion-exporter' ); ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="list-item">
                            <div class="d-flex align-items-center">
								<?php ConversionExport()->renderSwitcherInput( '_cnvex_use_schedule', true, null, false, false, true ); ?>
                                <h4 class="secondary-heading switcher-label"><?php esc_html_e( 'Detect when the Google Ads crawler accesses the file and mark it as loaded', 'conversion-exporter' ); ?></h4>
                            </div>

                            <p class="text-gray mt-4"><?php esc_html_e( 'Data will be updated starting from that moment', 'conversion-exporter' ); ?></p>
                        </div>

                        <div class="line"></div>

                        <div class="list-item task-gray-bg">
                            <h4 class="font-semibold-type2 mb-16">
								<?php esc_html_e( 'Password protection', 'conversion-exporter' ); ?>:
                            </h4>

                            <div class="password-protection-wrap">
                                <div>
                                    <h4 class="font-semibold-type2 mb-4">
										<?php esc_html_e( 'Username', 'conversion-exporter' ); ?>:
                                    </h4>

                                    <div class="mb-16">
										<?php ConversionExport()->renderTextInput( '_cnvex_username', true, null, '', 'js-control-element', false, false, 'standard' ); ?>
                                    </div>
                                </div>

                                <div>
                                    <h4 class="font-semibold-type2 mb-4">
										<?php esc_html_e( 'Password', 'conversion-exporter' ); ?>:
                                    </h4>

									<?php ConversionExport()->renderPasswordInput( '_cnvex_password', true, null, '', 'js-control-element' ); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
