<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="file-download-wrap download_action">
    <div class="flex-grow-1 copy-block-wrap">
		<?php
		$slug = get_post_meta( $id, '_cnvex_file_slug_full', true );
		$link = get_site_url() . "/conversion-exports/$id/$slug";
		?>
        <div class="disabled-input input-full">
            <p class="link link-small"><?php echo esc_html( $link ); ?></p>
        </div>

        <div class="input-copy"
             onclick="copyShortcode( '<?php echo esc_html( $link ); ?>', this)">
			<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
        </div>
    </div>

    <div class="download_action">
        <button class="btn btn-primary btn-primary-type2 with-icon btn_download_action" data-full="1"><i
                    class="icon-download mr-4"></i> <?php esc_html_e( 'Download file', 'conversion-exporter' ); ?>
        </button>
		<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/spinner.php"; ?>
    </div>
</div>