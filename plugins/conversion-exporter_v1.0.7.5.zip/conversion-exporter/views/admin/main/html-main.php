<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( isset( $_GET[ 'add_conversion_task' ] ) ) {
	require_once CNVEX_PLUGIN_VIEWS_PATH . 'admin/main/conversion-tasks/add-conversion-task-html.php';
} elseif ( isset( $_GET[ 'conversion_task_id' ] ) ) {
	require_once CNVEX_PLUGIN_VIEWS_PATH . 'admin/main/conversion-tasks/edit-conversion-task-html.php';
} elseif ( isset( $_GET[ 'add_form' ] ) ) {
	require_once CNVEX_PLUGIN_VIEWS_PATH . 'admin/main/forms/add-form-html.php';
} elseif ( isset( $_GET[ 'form_id' ] ) ) {
	require_once CNVEX_PLUGIN_VIEWS_PATH . 'admin/main/forms/edit-form-html.php';
} else {

	//inside the settings form
	$setting_views_a = array(
		'cnvex-general'    => 'conversion-tasks.php',
		'cnvex-form-tasks' => 'forms.php',
	);

	$admin_url = HelperFunctions::buildAdminUrl( 'conversion-exporter', HelperFunctions::getCurrentAdminTab() );

	?>
    <div class="container">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
              id="cnvex_settings_form" class="cnvex-settings-form">
            <input type="hidden" name="cnvex_update_action" value="update_admin_settings_form"/>
            <input type="hidden" name="action" value="cnvex_save_settings">

			<?php
			// Set nonce:
			if ( function_exists( 'wp_create_nonce' ) ) {
				$nonce_value = wp_create_nonce( 'cnvex-update-' . CNVEX_SETTINGS_FIELD  );
				echo '<input type="hidden" id="cnvex_nonce" name="_wpnonce" value="' . esc_attr( $nonce_value ) . '">';
			}

			foreach ( $setting_views_a as $target_id => $value ) {
				$settings_view = CNVEX_PLUGIN_VIEWS_PATH . 'admin/main/' . $value;

				if ( file_exists( $settings_view ) && HelperFunctions::getCurrentAdminTab() == $target_id ) {
					require_once $settings_view;
				}
			}
			?>
        </form>
    </div>
	<?php
}
