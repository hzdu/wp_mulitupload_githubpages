<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

?>

<input type="hidden" name="cnvex_delete_form_id" value="" id="cnvex_delete_form_id">

<div class="cards-wrapper cards-wrapper-style2 forms gap-22">
    <div class="card card-static card-style4">
        <div class="card-header card-header-style2">
            <div class="header-full-width">
                <h3 class="primary-heading"><?php esc_html_e( 'Forms', 'conversion-exporter' ); ?></h3>

                <a href="<?php echo esc_url( get_admin_url( null, 'admin.php?page=conversion-exporter' ) . '&add_form' ); ?>"
                   class="btn btn-primary btn-primary-type3 with-icon"><i
                            class="icon-plus mr-8"></i> <?php esc_html_e( 'Add New Form', 'conversion-exporter' ); ?>
                </a>
            </div>
        </div>

        <div class="card-body">
            <div class="gap-8">
				<?php
				$args_posts = array(
					'post_type'      => CNVEX_FORM_POST_TYPE,
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'order'          => 'ASC',
					'orderby'        => 'DATE',
				);
				$loop_posts = new \WP_Query( $args_posts );
				if ( !$loop_posts->have_posts() ) {
					echo __( 'No forms found', 'conversion-exporter' );
				} else {
					while ( $loop_posts->have_posts() ) {
						$loop_posts->the_post();
						$id = get_the_ID();
						include CNVEX_PLUGIN_VIEWS_PATH . 'admin/main/forms/form-list-wrap.php';
					}
				}
				?>
            </div>
        </div>
    </div>
</div>

<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-delete-form.php"; ?>

