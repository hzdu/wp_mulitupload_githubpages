<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

?>

<input type="hidden" name="cnvex_delete_conversion_task_id" value="" id="cnvex_delete_conversion_task_id">

<div class="cards-wrapper cards-wrapper-style2 conversion-tasks gap-22">
    <div class="card card-static card-style4">
        <div class="card-header card-header-style2">
            <div class="header-full-width">
                <h3 class="primary-heading"><?php esc_html_e( 'Conversion Tasks', 'conversion-exporter' ); ?></h3>

                <a href="<?php echo esc_url( get_admin_url( null, 'admin.php?page=conversion-exporter' ) . '&add_conversion_task' ); ?>"
                   class="btn btn-primary btn-primary-type3 with-icon"><i
                            class="icon-plus mr-8"></i> <?php esc_html_e( 'Add New Conversion Task', 'conversion-exporter' ); ?>
                </a>
            </div>
        </div>

        <div class="card-body">
            <div class="gap-8">
				<?php
				$args_posts = array(
					'post_type'      => CNVEX_CONVERSION_POST_TYPE,
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'order'          => 'ASC',
					'orderby'        => 'DATE',
				);
				$loop_posts = new \WP_Query( $args_posts );
				if ( !$loop_posts->have_posts() ) {
					echo __( 'No conversion tasks found', 'conversion-exporter' );
				} else {
					while ( $loop_posts->have_posts() ) {
						$loop_posts->the_post();
						$id = get_the_ID();
						include CNVEX_PLUGIN_VIEWS_PATH . 'admin/main/conversion-tasks/conversion-task-list-wrap.php';
					}
				}

				?>
            </div>
        </div>
    </div>
</div>

<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-delete-conversion-task.php"; ?>
<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-error-download-conversion.php"; ?>
<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-generation-confirmation.php"; ?>

