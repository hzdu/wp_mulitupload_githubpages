<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$number_files_options = array(
	'5'  => 5,
	'6'  => 6,
	'7'  => 7,
	'8'  => 8,
	'9'  => 9,
	'10' => 10,
	'11' => 11,
	'12' => 12,
	'13' => 13,
	'14' => 14,
	'15' => 15,
	'16' => 16,
	'17' => 17,
	'18' => 18,
	'19' => 19,
	'20' => 20
);

$how_ofter_create = array(
	'twice_day'      => __( 'Twice a day', 'conversion-exporter' ),
	'once_day'       => __( 'Once a day', 'conversion-exporter' ),
	'every_two_days' => __( 'Once every two days', 'conversion-exporter' ),
	'once_week'      => __( 'Once a week', 'conversion-exporter' ),
);

$generation_methods = array(
	'wp-cron'   => __( 'WP-Cron', 'conversion-exporter' ),
	'scheduler' => __( 'Own Scheduler', 'conversion-exporter' ),
	'external'  => __( 'External Calls', 'conversion-exporter' ),
);

?>
<div class="container">
    <form method="post" action="<?php echo esc_url( get_admin_url( null, 'admin.php?page=cnvex-settings' ) ); ?>"
          id="cnvex_settings_form" class="cnvex-settings-form">
        <input type="hidden" name="cnvex_update_action" value="update_admin_settings_form"/>
        <input type="hidden" name="cnvex-remove-form-data" id="cnvex-remove-form-data" value="">

		<?php
		// Set nonce:
		if ( function_exists( 'wp_create_nonce' ) ) {
			$nonce_value = wp_create_nonce( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );
			echo '<input type="hidden" id="cnvex_nonce" name="_wpnonce" value="' . esc_attr( $nonce_value ) . '">';
		}
		?>

        <div class="cards-wrapper cards-wrapper-style2 general-settings">
            <div class="gap-24">
                <div class="card card-static card-style9">
                    <div class="card-body">
                        <div class="gap-22">
                            <div class="d-flex align-items-center">
								<?php ConversionExporter()->renderSwitcherInput( 'sha256_encode' ); ?>
                                <h4 class="secondary-heading switcher-label"><?php esc_html_e(
										'Use SHA256 hashing for conversion data',
										'conversion-exporter'
									); ?></h4>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-8"><?php esc_html_e(
										'How many files to store in a conversion task',
										'conversion-exporter'
									); ?></h4>
								<?php ConversionExporter()->renderSelectInput(
									'number_files',
									$number_files_options
								); ?>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-8"><?php esc_html_e(
										'How often create export CSV files',
										'conversion-exporter'
									); ?></h4>
								<?php ConversionExporter()->renderSelectInput(
									'how_often_create_csv',
									$how_ofter_create
								); ?>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-8"><?php esc_html_e(
										'Generation method',
										'conversion-exporter'
									); ?></h4>
								<?php ConversionExporter()->renderSelectInput(
									'generation_method',
									$generation_methods
								); ?>
                                <p class="text-gray mt-8">
									<?php esc_html_e(
										'Choose how exports should be regenerated:',
										'conversion-exporter'
									); ?>
                                </p>
                                <ul class="cnvex-list">
                                    <li><span class="font-semibold-type2"><?php esc_html_e(
												'WP-Cron',
												'conversion-exporter'
											); ?></span> - <?php esc_html_e(
											'Uses WordPress built-in cron system (default)',
											'conversion-exporter'
										); ?></li>
                                    <li><span class="font-semibold-type2"><?php esc_html_e(
												'Own Scheduler',
												'conversion-exporter'
											); ?></span> - <?php esc_html_e(
											'Recommended when WP-Cron is disabled or not working',
											'conversion-exporter'
										); ?></li>
                                    <li><span class="font-semibold-type2"><?php esc_html_e(
												'External Calls',
												'conversion-exporter'
											); ?></span> - <?php esc_html_e(
											'For cached sites or server cron jobs',
											'conversion-exporter'
										); ?></li>
                                </ul>
                                <div class="mt-4" id="cnvex-external-calls-info" style="display: none;">
                                    <p class="font-semibold-type2 mb-8"><?php esc_html_e(
											'External calls examples:',
											'conversion-exporter'
										); ?></p>
                                    <p class="text-gray mt-2"><?php esc_html_e(
											'REST API',
											'conversion-exporter'
										); ?></p>


									<?php $code = 'GET ' . esc_url( get_site_url() )
									              . '/wp-json/cnvex/v1/check_exports'; ?>

                                    <div class="shortcode-wrap settings-shortcode">
                                        <div class="shortcode">
                                            <span class="shortcode-title">
                                                <?php echo wp_kses_post( $code ) ?>
                                            </span>
                                            <div class="shortcode-copy"
                                                 onclick="copyShortcode( '<?php echo wp_kses_post( $code ); ?>', this)">
												<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <p class="text-gray"><?php esc_html_e( 'WP-CLI:', 'conversion-exporter' ); ?></p>

									<?php $code = 'wp cnvex check_exports'; ?>

                                    <div class="shortcode-wrap settings-shortcode">
                                        <div class="shortcode">
                                            <span class="shortcode-title">
                                                <?php echo wp_kses_post( $code ) ?>
                                            </span>
                                            <div class="shortcode-copy"
                                                 onclick="copyShortcode( '<?php echo wp_kses_post( $code ); ?>', this)">
												<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <p class="text-gray"><?php esc_html_e(
											'External calls can be used in addition to WP-Cron or Own Scheduler.',
											'conversion-exporter'
										); ?></p>
                                </div>
                            </div>

                            <div class="d-flex align-items-center">
								<?php ConversionExporter()->renderSwitcherInput( 'remove_data_on_deactivation' ); ?>
                                <h4 class="secondary-heading switcher-label"><?php esc_html_e(
										'Remove all data when deactivating the plugin',
										'conversion-exporter'
									); ?></h4>
                            </div>

                            <div>
                                <h4 class="font-semibold-type2 mb-8">
									<?php esc_html_e( 'GCLID backup parameters', 'conversion-exporter' ); ?>
                                </h4>
								<?php
								$gclid_backup_parameters = ConversionExporter()->getOption( 'gclid_backup_parameters' );
								ConversionExporter()->renderMultiSelectInput(
									'gclid_backup_parameters',
									$gclid_backup_parameters,
									false,
									null,
									false,
									'cnvex-select2-tags'
								); ?>

                                <p class="text-gray mt-4"><?php esc_html_e(
										'Backup parameter names for GCLID capture. Checked when primary sources (gclid/gbraid/wbraid) are unavailable.',
										'conversion-exporter'
									); ?></p>
                                <p class="text-gray mt-4"><?php echo sprintf(
										__( '%s to learn more.', 'conversion-exporter' ),
										sprintf(
											'<a href="https://www.pixelyoursite.com/fix-safari-gclid-removal-conversion-exporter" target="_blank" rel="nofollow" class="link">%s</a>',
											__( 'Click', 'conversion-exporter' )
										)
									); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-static card-style9">
                    <div class="card-header card-header-style3">
                        <h3 class="primary-heading-type2">
							<?php esc_html_e( 'ConsentMagic Integration', 'conversion-exporter' ); ?>
                        </h3>
                    </div>

                    <div class="card-body">
                        <div class="gap-24">
                            <div class="d-flex align-items-center">
								<?php ConversionExporter()->renderSwitcherInput( 'consent_enable' ); ?>
                                <h4 class="secondary-heading switcher-label"><?php esc_html_e(
										'Enable Consent',
										'conversion-exporter'
									); ?></h4>
                            </div>

                            <div>
								<?php if ( HelperFunctions::isConsentMagicPluginInstalled() ) : ?>
									<?php if ( HelperFunctions::isConsentMagicPluginActivated() ) : ?>
                                        <div class="cnvex-consent-options-wrap gap-24 <?php echo !ConversionExporter(
										)->getOption( 'consent_enable' ) ? 'disabled' : ''; ?>">
                                            <div class="d-flex align-items-center">
												<?php ConversionExporter()->renderSwitcherInput(
													'store_cm_consent'
												); ?>
                                                <h4 class="secondary-heading switcher-label"><?php esc_html_e(
														'Store ConsentMagic consent for captured Form Tasks',
														'conversion-exporter'
													); ?></h4>
                                            </div>

											<?php
											$categories          = ConsentManager()->getCMCategories();
											$categories_options  = array_column( $categories, 'name', 'slug' );
											$selected_categories = ConversionExporter()->getOption(
												'exclude_cm_categories'
											);
											?>

                                            <div>
                                                <h4 class="font-semibold-type2 mb-8">
													<?php esc_html_e(
														'Exclude conversions if there is NEGATIVE consent for the following ConsentMagic categories',
														'conversion-exporter'
													); ?>
                                                </h4>
												<?php ConversionExporter()->renderMultiSelectInput(
													'exclude_cm_categories',
													$categories_options
												); ?>
                                            </div>

                                            <div class="d-flex align-items-center">
												<?php ConversionExporter()->renderSwitcherInput(
													'export_without_consent'
												); ?>
                                                <h4 class="secondary-heading switcher-label"><?php esc_html_e(
														'Export conversions, if a conversion has no stored consent',
														'conversion-exporter'
													); ?></h4>
                                            </div>
                                        </div>
									<?php else: ?>
										<?php
										$message = sprintf(
											__(
												'You have Consent Magic installed, but it’s not activated yet. Go to the %s and activate it',
												'conversion-exporter'
											),
											'<a href="' . admin_url( "plugins.php" ) . '" class="link link-small">'
											. __( 'Plugins page', 'conversion-exporter' ) . '</a>'
										);
										HelperNotices::renderWarningMessage( $message );
										?>
									<?php endif; ?>
								<?php else: ?>
									<?php
									$message = sprintf(
										__( 'You need the %s', 'conversion-exporter' ),
										'<a href="https://www.pixelyoursite.com/plugins/consentmagic?utm_source=ConversionExporter" target="_blank" class="link link-small">'
										. __( 'ConsentMagic plugin', 'conversion-exporter' ) . '</a>'
									);
									HelperNotices::renderWarningMessage( $message );
									?>
								<?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-static card-style9">
                    <div class="card-body no-border">
                        <div class="gap-24">
                            <div class="settings-block">
                                <h4 class="primary-heading-type2"><?php esc_html_e(
										'Clear all the forms stored data',
										'conversion-exporter'
									); ?></h4>

                                <button type="button"
                                        class="btn btn-primary btn-primary-type2 delete-all-plugin-data-confirm">
									<?php esc_html_e( 'Clear data', 'conversion-exporter' ); ?>
                                </button>
                            </div>

							<?php HelperNotices::renderWarningInfoMessage(
								__( 'This option will clear all the forms stored data.', 'conversion-exporter' )
							); ?>
                        </div>
                    </div>
                </div>

                <!-- Cache info -->
                <div class="card card-static card-style9 cache-info">
                    <div class="card-header card-header-style2">
                        <div class="d-flex align-items-center">
                            <i class="icon-info"></i>
                            <h4 class="primary-heading-type2"><?php esc_html_e(
									'Cache information',
									'conversion-exporter'
								); ?></h4>
                        </div>
                    </div>

                    <div class="card-body">
                        <p> <?php esc_html_e(
								'When using caching plugins or server-level caching (such as LiteSpeed Cache, W3 Total Cache, WP Super Cache, etc.), you need to add the following URI pattern to your cache exclusions to ensure proper functionality of the Conversion Exporter.',
								'conversion-exporter'
							); ?> </p>

						<?php $code = '/conversion-exports/'; ?>

                        <div class="shortcode-wrap settings-shortcode">
                            <div class="shortcode">
                            <span class="shortcode-title">
                                <?php echo wp_kses_post( $code ) ?>
                            </span>
                                <div class="shortcode-copy"
                                     onclick="copyShortcode( '<?php echo wp_kses_post( $code ); ?>', this)">
									<?php HelperFunctions::renderTooltip( 'icon-content-copy' ); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-remove-all-data.php"; ?>
		<?php include CNVEX_PLUGIN_VIEWS_PATH . "admin/components/modal-delete-form-data.php"; ?>
    </form>
</div>

