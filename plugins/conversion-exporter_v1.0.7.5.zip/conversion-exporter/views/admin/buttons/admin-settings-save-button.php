<?php

namespace ConversionExporter;

// If this file is called directly, abort.
if ( !defined( 'WPINC' ) ) {
	die;
}
?>
<div class="save-settings">

	<?php if ( isset( $_GET[ 'conversion_task_id' ] ) ) : ?>
        <div class="regenerate-export-wrap">
            <button type="button"
                    class="regenerate-export"
                    data-id="<?php echo esc_attr( sanitize_text_field( $_GET[ 'conversion_task_id' ] ) ); ?>"
            >
	            <?php esc_html_e( 'Regenerate CSV files', 'conversion-exporter' ); ?>
            </button>
        </div>
	<?php endif; ?>

    <div class="video-link">
		<?php if ( !empty( CNVEX_VIDEO_URL ) && !empty( CNVEX_VIDEO_TITLE ) ) : ?>
            <span class="font-semibold"><?php esc_html_e( 'Recommended', 'conversion-exporter' ); ?>: </span>
            <a href="<?php echo esc_url( CNVEX_VIDEO_URL ); ?>" target="_blank" class="link link-underline">
				<?php echo esc_html( CNVEX_VIDEO_TITLE ); ?>
            </a>
		<?php endif; ?>
    </div>

    <div class="save-settings-actions">
		<?php
		if ( isset( $_GET[ 'add_conversion_task' ] ) || isset( $_GET[ 'conversion_task_id' ] ) ) : ?>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=conversion-exporter' ) ); ?>"
               class="back-button"><?php esc_html_e( 'Back', 'conversion-exporter' ); ?></a>
            <button id="cnvex-save-settings"><?php esc_html_e( 'Save', 'conversion-exporter' ); ?></button>
		<?php elseif ( isset( $_GET[ 'add_form' ] ) || isset( $_GET[ 'form_id' ] ) ) : ?>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=conversion-exporter&tab=cnvex-form-tasks' ) ); ?>"
               class="back-button"><?php esc_html_e( 'Back', 'conversion-exporter' ); ?></a>
            <button id="cnvex-save-settings"><?php esc_html_e( 'Save', 'conversion-exporter' ); ?></button>
		<?php else : ?>
            <button id="cnvex-save-settings"><?php esc_html_e( 'Save Changes', 'conversion-exporter' ); ?></button>
		<?php endif; ?>
    </div>
</div>
