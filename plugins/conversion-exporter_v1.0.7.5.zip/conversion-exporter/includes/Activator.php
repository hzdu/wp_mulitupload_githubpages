<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Activator
 *
 * This class handles the activation of the plugin, including adding roles,
 * installing necessary database tables, and activating the plugin for all sites
 * in a multisite network.
 */
class Activator {

	/**
	 * This method is called when the plugin is activated.
	 * It adds roles, installs necessary database tables, and activates the plugin
	 * for all sites in a multisite network if applicable.
	 *
	 * @return void
	 */
	public function activate(): void {
		$this->addRoles();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		if ( is_multisite() ) {
			$this->activateSiteInNetwork();
		} else {
			$this->installTables();
		}

		$this->registerRewriteRules();
		flush_rewrite_rules();
	}

	/**
	 * Register rewrite rules for downloading files with parameters via GET request.
	 * This function registers rewrite rules for downloading files with parameters via GET request.
	 * It adds rewrite tags for the export ID and file name, and a rewrite rule for the download URL.
	 * @return void
	 */
	private function registerRewriteRules(): void {
		add_rewrite_tag( '%cnvex_export_id%', '([0-9]+)' );
		add_rewrite_tag( '%cnvex_file%', '([^/]+)' );

		add_rewrite_rule( '^conversion-exports/([0-9]+)/([^/]+)/?$', 'index.php?cnvex_export_id=$matches[1]&cnvex_file=$matches[2]', 'top' );
	}

	/**
	 * This method is called when the plugin is activated in a multisite network.
	 * It retrieves all blogs in the network and activates the plugin on each one,
	 * ensuring that necessary database tables are created for each site.
	 *
	 * @return void
	 */
	private function activateSiteInNetwork(): void {
		// Get all blogs in the network and activate plugin on each one
		global $wpdb;
		$blog_ids = $wpdb->get_col( $wpdb->prepare( 'SELECT blog_id FROM %1$s', $wpdb->blogs ) );
		foreach ( $blog_ids as $blog_id ) {
			switch_to_blog( $blog_id );
			$this->installTables();
			restore_current_blog();
		}
	}

	/**
	 * This method adds the 'cnvex_manage' capability to the administrator role.
	 * This allows administrators to manage the Conversion Exporter plugin.
	 *
	 * @return void
	 */
	private function addRoles(): void {
		$role = get_role( 'administrator' );
		if ( $role ) {
			$role->add_cap( 'cnvex_manage' );
		}
	}

	/**
	 * Install necessary database tables for the plugin.
	 *
	 * This function creates the required tables in the WordPress database
	 * to store form data, file data, and file creation data.
	 *
	 * @return void
	 */
	private function installTables(): void {
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		// Table for storing form data
		$table_name = $wpdb->prefix . 'cnvex_form_data';
		$like         = '%' . $wpdb->esc_like( $table_name ) . '%';
		$search_query = $wpdb->prepare( "SHOW TABLES LIKE %s", $like );
		if ( !$wpdb->get_results( $search_query, ARRAY_N ) ) {
			$sql = "CREATE TABLE $table_name (
					`id` INT NOT NULL AUTO_INCREMENT,
					`form_id` INT NOT NULL,
					`gclid` VARCHAR(200),
					`gbraid` VARCHAR(200),
					`wbraid` VARCHAR(200),
					`first_name` VARCHAR(100),
					`last_name` VARCHAR(100),
					`email` VARCHAR(200) NOT NULL,
					`phone` VARCHAR(30),
					`ip_address` VARCHAR(100) NOT NULL,
					`user_agent` VARCHAR(300) NOT NULL,
					`session_attributes` VARCHAR(2000) NOT NULL,
					`analytics_storage` VARCHAR(20) DEFAULT NULL,
					`ad_storage` VARCHAR(20) DEFAULT NULL,
					`ad_user_data` VARCHAR(20) DEFAULT NULL,
					`ad_personalization` VARCHAR(20) DEFAULT NULL,
					`submitted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
					`exported_at` DATETIME DEFAULT NULL,
					PRIMARY KEY (`id`)
				);";
			dbDelta( $sql );
		}

		// Table for storing consent data
		$table_name = $wpdb->prefix . 'cnvex_consent_data';
		$like         = '%' . $wpdb->esc_like( $table_name ) . '%';
		$search_query = $wpdb->prepare( "SHOW TABLES LIKE %s", $like );
		if ( !$wpdb->get_results( $search_query, ARRAY_N ) ) {
			$sql = "CREATE TABLE $table_name (
					`id` INT NOT NULL AUTO_INCREMENT,
					`form_data_id` INT NOT NULL,
					`form_task_id` INT NOT NULL,
					`category_id` INT NOT NULL,
					`category_slug` VARCHAR(100) NOT NULL,
					`value` TINYINT(1) NOT NULL,
					`submitted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
					PRIMARY KEY (`id`)
				);";
			dbDelta( $sql );
		}

		// Table for storing file data
		$table_name = $wpdb->prefix . 'cnvex_file_data';
		$like         = '%' . $wpdb->esc_like( $table_name ) . '%';
		$search_query = $wpdb->prepare( "SHOW TABLES LIKE %s", $like );
		if ( !$wpdb->get_results( $search_query, ARRAY_N ) ) {
			$sql = "CREATE TABLE $table_name (
					`id` INT NOT NULL AUTO_INCREMENT,
					`export_id` INT NOT NULL,
					`real_name` VARCHAR(200) NOT NULL,
					`uuid` VARCHAR(200),
					`main_file` TINYINT(1) NOT NULL,
					`full_file` TINYINT(1) NOT NULL DEFAULT 0,
					`ads_downloaded` TINYINT(1) NOT NULL,
					`downloaded_date` DATETIME DEFAULT NULL,
					`status` TINYINT(1) NOT NULL DEFAULT 0,
					`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
					PRIMARY KEY (`id`)
				);";
			dbDelta( $sql );
		}

		// Table for storing file creation data
		$table_name = $wpdb->prefix . 'cnvex_create_file_data';
		$like         = '%' . $wpdb->esc_like( $table_name ) . '%';
		$search_query = $wpdb->prepare( "SHOW TABLES LIKE %s", $like );
		if ( !$wpdb->get_results( $search_query, ARRAY_N ) ) {
			$sql = "CREATE TABLE $table_name (
					`id` INT NOT NULL AUTO_INCREMENT,
					`export_ids` JSON NOT NULL,
					`orders` JSON NOT NULL,
					`type` VARCHAR(20),
					`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
					PRIMARY KEY (`id`)
				);";
			dbDelta( $sql );
		}

		// Creates a table to store all the options.
		$table_name   = $wpdb->prefix . 'cnvex_options';
		$like         = '%' . $wpdb->esc_like( $table_name ) . '%';
		$search_query = $wpdb->prepare( "SHOW TABLES LIKE %s", $like );
		if ( !$wpdb->get_results( $search_query, ARRAY_N ) ) {
			$sql = "CREATE TABLE `$table_name`(
			    `id` INT NOT NULL AUTO_INCREMENT,
			    `name` VARCHAR(100) NOT NULL,
			    `value` MEDIUMTEXT NULL DEFAULT '',
                `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			     PRIMARY KEY(`id`),
                 UNIQUE `name` (`name`)
            )";
			dbDelta( $sql );
		}
	}
}
