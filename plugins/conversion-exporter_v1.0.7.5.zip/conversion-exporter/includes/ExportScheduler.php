<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ExportScheduler
 * Conversion Exporter Scheduler
 * Handles scheduling and execution of export regeneration tasks for the Conversion Exporter plugin.
 * This scheduler works independently of WP-Cron and triggers exports based on scheduled times.
 */
class ExportScheduler {

	/**
	 * Constructor
	 * Initializes the scheduler and sets up hooks based on the generation method.
	 */
	public function __construct() {
		// Prevent initialization if we're already processing exports
		if ( isset( $_SERVER[ 'REQUEST_URI' ] )
		     && strpos( $_SERVER[ 'REQUEST_URI' ], '/cnvex/v1/exports_update' ) !== false ) {
			return;
		}

		// Only activate scheduler if the generation method is set to 'scheduler'
		$method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';
		if ( $method === 'scheduler' && HelperFunctions::isPluginActivated() ) {
			add_action( 'wp_loaded', array( $this, 'checkScheduledExports' ), 20 );
		}
	}

	/**
	 * Checks if there are any scheduled exports that need to be processed.
	 * This function determines whether there are past-due export generation jobs that require action.
	 * If scheduled export jobs exist, it triggers an asynchronous HTTP request to execute the export update process.
	 * @return bool
	 */
	public function checkScheduledExports(): bool {
		if ( !HelperFunctions::isPluginActivated() || !function_exists( __NAMESPACE__ . '\\ConversionExport' ) ) {
			return false;
		}

		$last_run = get_transient( 'cnvex_scheduler_last_run' );
		if ( $last_run && $last_run > time() - 120 ) {
			return false;
		}

		// Check if there are any scheduled exports
		$check = ConversionExport()->exportChecker();
		set_transient( 'cnvex_scheduler_last_run', time(), 120 );

		return $check;
	}
}

new ExportScheduler();

