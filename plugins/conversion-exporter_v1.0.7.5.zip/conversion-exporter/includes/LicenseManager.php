<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/** * Class LicenseManager
 * Handles the management of the EDD license for the Conversion Exporter plugin.
 * This includes checking the license status, activating and deactivating the license,
 * and scheduling cron jobs for license checks.
 */
class LicenseManager {

	private string $data_key                    = '';
	private string $edd_api_key                 = '';
	private string $plugin_name                 = '';
	private string $edd_deactivate_checkbox_key = '';
	private string $edd_activated_key           = '';
	private string $license_name                = '';
	private string $edd_check_license_key       = '';
	private string $plugin_version              = '';

	public string $edd_check_for_update_key = '';
	public string $api_url                  = '';
	public string $edd_license_key          = '';

	public function __construct( $plugin_version, $plugin_name ) {

		$this->edd_check_for_update_key    = 'edd_' . CNVEX_LICENSE_PLUGIN_NAME . 'check_for_update_key';
		$this->api_url                     = 'https://www.pixelyoursite.com';
		$this->edd_license_key             = 'edd_' . CNVEX_LICENSE_PLUGIN_NAME . '_license_key';
		$this->data_key                    = CNVEX_LICENSE_PLUGIN_NAME;
		$this->edd_api_key                 = 'edd_' . CNVEX_LICENSE_PLUGIN_NAME . '_api_key';
		$this->plugin_name                 = $plugin_name;
		$this->edd_check_license_key       = $this->data_key . '_check_license';
		$this->license_name                = 'edd';
		$this->plugin_version              = $plugin_version;
		$this->edd_activated_key           = $this->license_name . '_' . $this->data_key . '_activated';
		$this->edd_deactivate_checkbox_key = $this->license_name . '_' . $this->data_key . '_deactivate_checkbox';

		if ( is_admin() ) {
			add_action( 'admin_init', array(
				$this,
				'checkLicense'
			) );

			/**
			 * Check for software updates
			 */
			if ( get_transient( $this->edd_check_for_update_key ) === false && $this->isPluginActivated() ) {
				$this->checkUpdate();
			}
			add_action( 'admin_init', array(
				$this,
				'checkUpdate'
			), 0 );

			add_action( 'admin_post_cnvex_validate_license', function() {
				$this->validateOptions();
				wp_safe_redirect( admin_url( 'admin.php?page=cnvex-license' ) );
			} );

			add_action( 'admin_post_cnvex_deactivate_license', function() {
				$this->eddLicenseKeyDeactivation();
				wp_safe_redirect( admin_url( 'admin.php?page=cnvex-license' ) );
			} );
		}

		if ( $this->isPluginActivated() ) {
			add_action( 'cnvex_check_license', array(
				$this,
				'checkLicenseCron'
			), 200 );

			$this->cronCheckStatus();
		}
	}

	/**
	 * Check the license status and handle activation or deactivation.
	 * This function checks if the license key is valid, activates it if necessary,
	 * and handles deactivation based on the user's input.
	 * It also registers settings for the license key and deactivation checkbox.
	 * @return void
	 */
	public function checkLicense(): void {
		if ( get_transient( $this->edd_check_license_key ) === false && $this->isPluginActivated() ) {
			$activation_key = ConversionExporter()->getOption( $this->edd_license_key );
			$response       = $this->remote_query( $activation_key, 'check_license' );

			$status_code = wp_remote_retrieve_response_code( $response );
			if ( $status_code == 403 || $status_code == 415 ) {
				$ip_list = HelperFunctions::getAllServerIps();
				$message = __(
					           "The request may have been blocked by our firewall. Please try again later. If the problem persists, contact our support and provide the following IP addresses: ",
					           'conversion-exporter'
				           ) . $ip_list;

				set_transient( 'cnvex_license_notice', $message, 60 );

				return;
			}

			if ( !is_wp_error( $response ) ) {
				$response = json_decode( wp_remote_retrieve_body( $response ) );
				if ( $response->success === false || $response->license === 'invalid'
				     || $response->license === 'expired'
				     || $response->license === 'disabled'
				     || $response->license === 'key_mismatch'
				     || $response->license === 'invalid_item_id'
				     || $response->license === 'item_name_mismatch' ) {

					ConversionExporter()->updateOptions( array( $this->edd_activated_key => 'Deactivated' ) );
					ConversionExporter()->updateOptions( array( $this->edd_deactivate_checkbox_key => 'on' ) );
					ConversionExporter()->updateOptions( array( $this->edd_license_key => '' ) );

					delete_transient( $this->edd_check_license_key );
					set_transient(
						'cnvex_license_notice',
						sprintf( __( 'Your license is %s', 'conversion-exporter' ), $response->license ),
						30
					);
					$this->cronDeactivate();

					wp_safe_redirect( admin_url( '/admin.php?page=cnvex-license' ) );
					exit;

				} else {
					if ( $response->success === true && $response->license === 'valid' ) {
						set_transient( $this->edd_check_license_key, $this->edd_check_license_key, DAY_IN_SECONDS );
					} else {
						set_transient( $this->edd_check_license_key, $this->edd_check_license_key, 600 );
						set_transient(
							'cnvex_license_notice',
							__( 'Error activation license', 'conversion-exporter' ),
							30
						);
					}
				}
			} else {
				set_transient( $this->edd_check_license_key, $this->edd_check_license_key, 600 );
				set_transient( 'cnvex_license_notice', __( 'Error activation license', 'conversion-exporter' ), 30 );
			}
		}
	}

	/**
	 * Check if the plugin is activated.
	 * This function checks the activation status of the plugin by looking at the
	 * 'edd_conversion_exporter_activated' option. It returns true if the plugin is activated
	 * or expired, otherwise it returns false.
	 * @return bool True if the plugin is activated or expired, false otherwise.
	 */
	private function isPluginActivated(): bool {
		// Delegate to the shared helper to avoid duplication and ensure single DB check per request
		return HelperFunctions::isPluginActivated();
	}

	/**
	 * Validate the options for the EDD license key.
	 * This function checks if the input is not null and processes the activation of the license key.
	 * It updates the options based on the activation result and sets appropriate messages.
	 * @param array|null $input The input data to validate.
	 */
	public function validateOptions( ?array $input = null ): void {

		if ( !isset( $_POST[ 'edd_conversion_exporter' ][ $this->edd_api_key ] ) ) {
			return;
		}

		$api_key = trim( sanitize_text_field( $_POST[ 'edd_conversion_exporter' ][ $this->edd_api_key ] ) );
		ConversionExporter()->updateOptions( array( $this->edd_license_key => $api_key ) );

		$activation_result = $this->remote_query( $api_key, 'activate_license' );

		if ( is_wp_error( $activation_result ) || wp_remote_retrieve_response_code( $activation_result ) != 200 ) {
			$message = __(
				'Connection failed to the License Key API server. Try again later. There may be a problem on your server preventing outgoing requests, or the store is blocking your request to activate the plugin/theme.',
				'conversion-exporter'
			);
			ConversionExporter()->updateOptions( array( $this->edd_activated_key => 'Deactivated' ) );
			ConversionExporter()->updateOptions( array( $this->edd_deactivate_checkbox_key => 'on' ) );
			add_settings_error( 'edd_error_text', 'api_key_check_error', esc_html( $message ) );
			// add error
			set_transient( 'cnvex_license_notice', esc_html( $message ), 30 );
		}

		$status_code = wp_remote_retrieve_response_code( $activation_result );
		if ( $status_code == 403 || $status_code == 415 ) {
			$ip_list = HelperFunctions::getAllServerIps();
			$message = __(
				           "The request may have been blocked by our firewall. Please try again later. If the problem persists, contact our support and provide the following IP addresses: ",
				           'conversion-exporter'
			           ) . $ip_list;

			set_transient( 'cnvex_license_notice', $message, 60 );
			add_settings_error( 'edd_activation_text', 'edd_activation_error', esc_html( $message ) );

			return;
		}

		$activation_result = json_decode( wp_remote_retrieve_body( $activation_result ) );

		if ( !empty( $activation_result ) ) {
			if ( $activation_result->success === true && $activation_result->license === 'valid' ) {
				$message = __( sprintf( '%s activated. ', $this->plugin_name ), 'conversion-exporter' ) . __(
						'Activation completed successfully',
						'conversion-exporter'
					);
				add_settings_error( 'activate_text', 'activate_msg', esc_html( $message ), 'updated' );
				ConversionExporter()->updateOptions( array( $this->edd_activated_key => 'Activated' ) );
				ConversionExporter()->updateOptions( array( $this->edd_deactivate_checkbox_key => 'off' ) );
				delete_transient( 'cnvex_license_notice' );
				set_transient( 'cnvex_license_success_notice', esc_html( $message ), 30 );
			}

			if ( $activation_result->success === false ) {
				switch ( $activation_result->error ) {

					case 'expired' :
						$message = sprintf(
							__( 'Your license key expired on %s.', 'conversion-exporter' ),
							date_i18n(
								get_option( 'date_format' ),
								strtotime( $activation_result->expires, current_time( 'timestamp' ) )
							)
						);
						break;

					case 'revoked' :
						$message = __( 'Your license key has been disabled.', 'conversion-exporter' );
						break;

					case 'missing':
					case 'invalid':
						$message = __( 'Invalid license.', 'conversion-exporter' );
						break;

					case 'site_inactive' :
						$message = __( 'Your license is not active for this URL.', 'conversion-exporter' );
						break;

					case 'item_name_mismatch' :
						$message = sprintf(
							__( 'This appears to be an invalid license key for %s.', 'conversion-exporter' ),
							$this->plugin_name
						);
						break;

					case 'no_activations_left':
						$message = __( 'Your license key has reached its activation limit.', 'conversion-exporter' );
						break;

					default :
						$message = __( 'An error occurred, please try again.', 'conversion-exporter' );
						break;
				}

				add_settings_error( 'edd_error_text', 'api_key_check_error', esc_html( $message ) );
				ConversionExporter()->updateOptions( array( $this->edd_activated_key => 'Deactivated' ) );
				$this->cronDeactivate();

				// add error
				set_transient( 'cnvex_license_notice', esc_html( $message ), 30 );
			}
		} else {
			$message = __(
				'The API Key activation could not be completed due to an unknown error possibly on the store server The activation results were empty.',
				'conversion-exporter'
			);
			add_settings_error(
				'not_activated_empty_response_text',
				'not_activated_empty_response_error',
				esc_html( $message ),
				'updated'
			);
			set_transient( 'cnvex_license_notice', $message, 30 );
		}
	}

	/**
	 * Handle the deactivation of the EDD license key.
	 * This function checks the input for the deactivation request and processes it accordingly.
	 * If the input is 'reactivate', it validates the options. Otherwise, it attempts to deactivate
	 * the license key and updates the relevant options based on the result.
	 */
	public function eddLicenseKeyDeactivation(): void {

		if ( !isset( $_POST[ 'edd_conversion_exporter_deactivate_checkbox' ] ) ) {
			return;
		}

		$type = $_POST[ 'edd_conversion_exporter_deactivate_checkbox' ] == 'deactivate' ? 'deactivate' : 'reactivate';

		if ( $type == 'reactivate' && isset( $_POST[ 'edd_conversion_exporter' ] ) ) {
			$this->validateOptions();
		} else {
			$activation_status = ConversionExporter()->getOption( $this->edd_activated_key );
			$activation_key    = ConversionExporter()->getOption( $this->edd_license_key );

			if ( !empty( $activation_key )
			     && ( $activation_status == 'Activated'
			          || $activation_status == 'Expired' ) ) {
				// deactivates API Key activation
				$deactivation_result = $this->remote_query( $activation_key, 'deactivate_license' );

				if ( is_wp_error( $deactivation_result )
				     || 200 !== wp_remote_retrieve_response_code( $deactivation_result ) ) {

					$status_code = wp_remote_retrieve_response_code( $deactivation_result );
					if ( $status_code == 403 || $status_code == 415 ) {
						$ip_list = HelperFunctions::getAllServerIps();
						$message = __(
							           "The request may have been blocked by our firewall. Please try again later. If the problem persists, contact our support and provide the following IP addresses: ",
							           'conversion-exporter'
						           ) . $ip_list;

						set_transient( 'cnvex_license_notice', $message, 60 );
						add_settings_error( 'edd_deactivation_text', 'edd_deactivation_error', esc_html( $message ) );

						return;
					}

					$message = ( is_wp_error( $deactivation_result )
					             && !empty(
						$deactivation_result->get_error_message()
						) ) ? $deactivation_result->get_error_message() : __(
						'An error occurred, please try again.',
						'conversion-exporter'
					);
					add_settings_error( 'edd_deactivation_text', 'edd_deactivation_error', esc_html( $message ) );
					set_transient( 'cnvex_license_notice', $message, 30 );
				} else {
					$message = __(
						sprintf( '%s deactivated is successfully.', $this->plugin_name ),
						'conversion-exporter'
					);
					ConversionExporter()->updateOptions( array( $this->edd_activated_key => 'Deactivated' ) );
					ConversionExporter()->updateOptions( array( $this->edd_deactivate_checkbox_key => 'on' ) );
					ConversionExporter()->updateOptions( array( $this->edd_license_key => '' ) );
					add_settings_error(
						'edd_deactivation_text',
						'edd_deactivation_message',
						esc_html( $message ),
						'updated'
					);
					set_transient( 'cnvex_license_deactivation_notice', esc_html( $message ), 30 );
					$this->cronDeactivate();
				}
			}
		}
	}

	/**
	 * Perform a remote query to the EDD API.
	 * @param string $key    The license key.
	 * @param string $action The action to perform (e.g., 'activate_license', 'deactivate_license').
	 * @return \WP_Error|array The response from the API or an error object.
	 */
	public function remote_query( string $key, string $action ) {
		$api_params = array(
			'edd_action' => $action,
			'license'    => $key,
			'item_name'  => $this->plugin_name,
			'url'        => home_url()
		);

		$response = wp_remote_post( $this->api_url, array(
			'timeout'   => 15,
			'sslverify' => true,
			'body'      => $api_params
		) );

		return $response;
	}

	/**
	 * Deactivate all scheduled cron jobs related to the plugin.
	 * This function clears all scheduled hooks related to the plugin's export functionality,
	 * including export schedules, full export schedules, export checker, and form data retention.
	 * @return void
	 */
	public function cronDeactivate(): void {
		if ( wp_next_scheduled( 'cnvex_export_schedule' ) ) {
			wp_clear_scheduled_hook( 'cnvex_export_schedule' );
		}

		$args = array(
			true
		);
		if ( wp_next_scheduled( 'cnvex_export_full_schedule', $args ) ) {
			wp_clear_scheduled_hook( 'cnvex_export_full_schedule', $args );
		}

		if ( wp_next_scheduled( 'cnvex_export_checker' ) ) {
			wp_clear_scheduled_hook( 'cnvex_export_checker' );
		}

		if ( wp_next_scheduled( 'cnvex_form_data_retention' ) ) {
			wp_clear_scheduled_hook( 'cnvex_form_data_retention' );
		}

		if ( wp_next_scheduled( 'cnvex_check_license' ) ) {
			wp_clear_scheduled_hook( 'cnvex_check_license' );
		}
	}

	/**
	 * Check for updates using the EDD Updater.
	 * This function initializes the EDD Updater with the necessary parameters
	 * and sets a transient to prevent frequent update checks.
	 * @return void
	 */
	public function checkUpdate(): void {

		if ( !class_exists( 'ConversionExporter\EddUpdater' ) ) {
			require_once CNVEX_PLUGIN_PATH . 'includes/EddUpdater.php';
		}

		$license_key = ConversionExporter()->getOption( $this->edd_license_key );

		$plugin_updater = new EddUpdater( $this->api_url, CNVEX_PLUGIN_FILENAME, array(
			'version'   => CNVEX_LATEST_VERSION_NUMBER,
			'license'   => $license_key,
			'item_name' => $this->plugin_name,
			'author'    => CNVEX_PLUGIN_TITLE
		) );

		set_transient( $this->edd_check_for_update_key, $this->edd_check_for_update_key, DAY_IN_SECONDS );
	}

	/**
	 * Check the license status via a cron job.
	 * This function checks the license status and updates the options accordingly.
	 * If the license is invalid, it deactivates the plugin and updates the relevant options.
	 * @return void
	 */
	public function checkLicenseCron(): void {
		$license_status = $this->getLicenseStatus();

		if ( !empty( $license_status ) && isset( $license_status[ 'success' ] )
		     && isset( $license_status[ 'license' ] ) ) {
			if ( $license_status[ 'success' ] === false && $license_status[ 'license' ] === 'invalid' ) {
				ConversionExporter()->updateOptions( array( $this->edd_activated_key => 'Deactivated' ) );
				ConversionExporter()->updateOptions( array( $this->edd_deactivate_checkbox_key => 'on' ) );
				ConversionExporter()->updateOptions( array( $this->edd_license_key => '' ) );
			}
		}
	}

	/**
	 * Get the license status.
	 * @return array|string|null The license status or null if not set.
	 */
	public function getLicenseStatus() {
		$status = $this->getEddStatus();
		if ( !empty( $status ) ) {
			$status = json_decode( $status, true );
		}

		return $status;
	}

	/**
	 * Get the EDD status.
	 * @return string The EDD status response.
	 */
	public function getEddStatus(): string {

		$api_params = array(
			'edd_action' => 'check_license',
			'license'    => ConversionExporter()->getOption( $this->edd_license_key ),
			'item_name'  => $this->plugin_name,
			'url'        => home_url()
		);

		$request = wp_remote_post( $this->api_url, array(
			'timeout'   => 15,
			'sslverify' => true,
			'body'      => $api_params
		) );

		if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) != 200 ) {
			// Request failed
			return '';
		}

		return wp_remote_retrieve_body( $request );
	}

	/**
	 * Schedule a cron event to check the license status daily.
	 * This function checks if a cron event for checking the license status is scheduled,
	 * and if not, schedules it to run daily.
	 * @return void
	 */
	public function cronCheckStatus(): void {
		if ( !wp_next_scheduled( 'cnvex_check_license' ) ) {
			wp_schedule_event( time(), 'daily', 'cnvex_check_license' );
		}
	}
}