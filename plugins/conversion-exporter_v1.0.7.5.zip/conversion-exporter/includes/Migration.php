<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Migration
 *
 * Handles the migration of data from the old plugin to the new one.
 */
class Migration {

	private ConversionExporter $ConversionExporter;

	public function __construct( ConversionExporter $ConversionExporter ) {
		$this->ConversionExporter = $ConversionExporter;
	}

	/**
	 * Check if we need to migrate data from the old plugin to the new one.
	 * @return void
	 */
	public function maybeMigrate(): void {

		$check_settings = $this->ConversionExporter->getOption( 'check_settings' );
		//check template changes for current plugin version
		if ( $check_settings != CNVEX_LATEST_VERSION_NUMBER ) {
			if ( $check_settings && version_compare( $check_settings, '1.0.2', '<=' ) ) {
				add_action( 'init', array(
					$this,
					'migrateTo103'
				), 11 );
			}

			$this->ConversionExporter->updateOptions( array( 'check_settings' => CNVEX_LATEST_VERSION_NUMBER ) );
		}
	}

	/**
	 * Migrate data from the old plugin to the new one.
	 * @return void
	 */
	public function migrateTo103(): void {
		$args [ 'post_type' ] = CNVEX_CONVERSION_POST_TYPE;
		$exports = get_posts( $args );
		if ( $exports ) {
			foreach ( $exports as $export ) {
				$name = get_post_meta( $export->ID, '_cnvex_conversion_task_name', true );
				update_post_meta( $export->ID, '_cnvex_conversion_name', $name );
			}
		}
	}
}
