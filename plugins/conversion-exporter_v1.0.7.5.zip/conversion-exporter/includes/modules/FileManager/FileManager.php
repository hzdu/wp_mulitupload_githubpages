<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class FileManager
 * Handles file management operations for the Conversion Exporter plugin.
 * This includes creating, deleting, and retrieving files related to exports.
 */
class FileManager {
	protected static ?FileManager $instance = null;

	private string $file_path;

	private string $file_table_name;

	/**
	 * Get the singleton instance of FileManager.
	 * @return FileManager|null Returns the instance of FileManager or null if not initialized.
	 */
	public static function get_instance(): ?FileManager {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function __construct() {
		$this->file_path       = $this->getUploadDir();
		$this->file_table_name = 'cnvex_file_data';

		$this->createUploadMainHtaccessFile();

		add_action( 'template_redirect', function() {
			$request_uri = $_SERVER[ 'REQUEST_URI' ] ?? '';

			if ( strpos( $request_uri, '/wp-content/uploads/conversion-exports/' ) !== false ) {
				status_header( 403 );
				wp_die( 'Direct access to exports is forbidden.', 'Forbidden', [ 'response' => 403 ] );
				exit;
			}
		} );

		add_action( 'parse_request', function( $wp ) {
			$uri = $_SERVER[ 'REQUEST_URI' ] ?? '';

			if ( strpos( $uri, '/wp-content/uploads/conversion-exports/' ) !== false ) {
				status_header( 403 );
				exit( '403 Forbidden' );
			}
		} );
	}

	/**
	 * Generate a new file entry for the given export ID and file name.
	 * This function will generate a unique UUID for the file, and create a record in the database.
	 * @param int    $export_id The ID of the export to which the file belongs.
	 * @param string $file_name The name of the file to be created.
	 * @param bool   $full      Whether this is a full export file or not.
	 * @return string The path to the created file.
	 */
	public function createFileEntry( int $export_id, string $file_name, bool $full = false ): string {
		$directory = $this->file_path . $export_id;
		$this->checkDirectory( $directory );
		$uuid = $this->generateName();
		$this->createTableRecord( $export_id, $file_name, $uuid, $full );

		return $this->getFilePath( $export_id, $uuid );
	}

	/**
	 * Check if the directory exists, and create it if it doesn't.
	 * Also creates an index.php file in the directory to prevent directory listing.
	 * @param string $directory The path to the directory to check.
	 */
	private function checkDirectory( string $directory ): void {
		if ( !file_exists( $directory ) ) {
			wp_mkdir_p( $directory );
			$this->createUploadNestedHtaccessFile( $directory );
			$this->createIndexPhpFile( $directory );
		}
	}

	/**
	 * Create .htaccess file in the conversion exports directory.
	 * @return bool True when the .htaccess file exists, false on failure.
	 */
	public function createUploadMainHtaccessFile(): bool {
		$upload_dir = $this->getUploadDir();

		// Create directory if it doesn't exist
		if ( !file_exists( $upload_dir ) ) {
			wp_mkdir_p( $upload_dir );
		}

		$htaccess_file = $this->getUploadDir() . '.htaccess';

		if ( file_exists( $htaccess_file ) ) {
			return true;
		}

		if ( !function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}

		$contents = '# Disable PHP and Python scripts parsing.
<Files *>
  SetHandler none
  SetHandler default-handler
  RemoveHandler .cgi .php .php3 .php4 .php5 .phtml .pl .py .pyc .pyo
  RemoveType .cgi .php .php3 .php4 .php5 .phtml .pl .py .pyc .pyo
</Files>
<IfModule mod_php5.c>
  php_flag engine off
</IfModule>
<IfModule mod_php7.c>
  php_flag engine off
</IfModule>
<IfModule mod_php8.c>
  php_flag engine off
</IfModule>
<IfModule headers_module>
  Header set X-Robots-Tag "noindex"
</IfModule>';

		return insert_with_markers( $htaccess_file, 'ConversionExporter', $contents );
	}

	/**
	 * Create .htaccess file in the conversion exports directory.
	 * @return bool True when the .htaccess file exists, false on failure.
	 */
	public function createUploadNestedHtaccessFile( $upload_dir ): bool {

		// Create directory if it doesn't exist
		if ( !file_exists( $upload_dir ) ) {
			wp_mkdir_p( $upload_dir );
		}

		$htaccess_file = $upload_dir . '/.htaccess';

		if ( file_exists( $htaccess_file ) ) {
			return true;
		}

		if ( !function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}

		$contents = '# Disable access for any file in the nested dir.
# Apache 2.2
<IfModule !authz_core_module>
          Deny from all
</IfModule>

# Apache 2.4+
<IfModule authz_core_module>
          Require all denied
</IfModule>';

		return insert_with_markers( $htaccess_file, 'ConversionExporter', $contents );
	}

	/**
	 * Create index.php file in the conversion exports directory.
	 * @return void Number of bytes written or false on failure.
	 */
	public function createIndexPhpFile( $upload_dir ): void {

		if ( !is_dir( $upload_dir ) || is_link( $upload_dir ) ) {
			return;
		}

		$index_file = wp_normalize_path( trailingslashit( $upload_dir ) . 'index.php' );

		if ( !file_exists( $index_file ) ) {
			$data = '<?php
header($_SERVER[\'SERVER_PROTOCOL\'] . \' 404 Not Found\');
header(\'Status: 404 Not Found\');
';
			file_put_contents( $index_file, $data );

		}

		$index_file = wp_normalize_path( trailingslashit( $upload_dir ) . 'index.html' );
		if ( !file_exists( $index_file ) ) {
			file_put_contents( $index_file, '' );
		}
	}

	/**
	 * Get upload directory path for conversion exports.
	 * @return string
	 */
	public function getUploadDir(): string {
		$u = wp_upload_dir();
		$base_dir = wp_normalize_path( $u[ 'basedir' ] ?? '' );

		if ( !empty( $u[ 'error' ] ) || $base_dir === ''
		     || strpos( $base_dir, wp_normalize_path( WP_CONTENT_DIR ) ) !== 0 ) {
			$base_dir = trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ) . 'uploads';
		}

		return trailingslashit( $base_dir ) . 'conversion-exports/';
	}

	/**
	 * Generate a unique name for the file using a UUID.
	 * This function generates a random 16-byte string, modifies it to conform to the UUID version 4 format,
	 * and returns it as a string.
	 * @return string The generated UUID in the format xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx.
	 */
	private function generateName(): string {
		$data      = random_bytes( 16 );
		$data[ 6 ] = chr( ( ord( $data[ 6 ] ) & 0x0f ) | 0x40 );
		$data[ 8 ] = chr( ( ord( $data[ 8 ] ) & 0x3f ) | 0x80 );

		return vsprintf( '%s%s-%s-%s-%s-%s%s%s', str_split( bin2hex( $data ), 4 ) );
	}

	/**
	 * Create a record in the database for the file.
	 * This function will insert a new record into the database with the given export ID, file name, UUID,
	 * and whether it is a full export file or not.
	 * @param int    $export_id The ID of the export to which the file belongs.
	 * @param string $file_name The name of the file to be created.
	 * @param string $uuid      The UUID of the file.
	 * @param int    $full      Whether this is a full export file (1) or not (0).
	 */
	private function createTableRecord( int $export_id, string $file_name, string $uuid, int $full = 0 ): void {
		$file = $this->getFileByUuid( $export_id, $uuid );
		if ( empty( $file ) ) {
			global $wpdb;
			$table = $wpdb->prefix . $this->file_table_name;
			$data  = array(
				'export_id'      => $export_id,
				'real_name'      => $file_name,
				'uuid'           => $uuid,
				'ads_downloaded' => 0,
				'main_file'      => $full ? 0 : 1,
				'status'         => 0,
				'full_file'      => $full,
				'created_at'     => current_time( 'mysql' ),
			);

			$wpdb->insert( $table, $data );
		}
	}

	/**
	 * Delete a record from the database by UUID.
	 * This function will delete the record with the given UUID from the database.
	 * @param string $uuid The UUID of the file to be deleted.
	 */
	public function deleteTableRecord( string $uuid ): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;

		$wpdb->delete( $table, array( 'uuid' => $uuid ) );
	}

	/**
	 * Get all files associated with a specific export ID.
	 * This function retrieves all files that are not marked as full files and have a status of 1,
	 * ordered by the creation date in descending order.
	 * @param int $export_id The ID of the export for which to retrieve files.
	 * @return array An array of file records associated with the given export ID.
	 */
	public function getFilesByExportId( int $export_id ): array {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		$files = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table 
         		   WHERE export_id=%s 
         		     AND full_file=0
         		     AND status=1
				   ORDER BY created_at DESC", $export_id ), ARRAY_A );

		if ( empty( $files ) ) {
			return array();
		}

		return $files;
	}

	/**
	 * Get the file path for a specific export ID and UUID.
	 * This function constructs the file path based on the export ID and UUID.
	 * @param int    $export_id The ID of the export to which the file belongs.
	 * @param string $uuid      The UUID of the file.
	 * @return string The constructed file path.
	 */
	public function getFilePath( int $export_id, string $uuid ): string {
		return $this->file_path . $export_id . '/' . $uuid . '.csv';
	}

	/**
	 * Get the file name by UUID for a specific export ID.
	 * This function retrieves the real name of the file associated with the given export ID and UUID.
	 * @param int    $export_id The ID of the export to which the file belongs.
	 * @param string $uuid      The UUID of the file.
	 * @return string|null The real name of the file, or null if not found.
	 */
	public function getFileByUuid( int $export_id, string $uuid ): ?string {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		$file  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table 
         		   WHERE export_id=%s
					 AND uuid=%s", $export_id, $uuid ), ARRAY_A );

		if ( empty( $file ) ) {
			return null;
		}

		return $file[ 'real_name' ];
	}

	/**
	 * Get the UUID of a file by its export ID and real name.
	 * This function retrieves the UUID of a file associated with the given export ID and real name.
	 * @param int    $export_id The ID of the export to which the file belongs.
	 * @param string $name      The real name of the file.
	 * @return string|null The UUID of the file, or null if not found.
	 */
	public function getFileUuid( int $export_id, string $name ): ?string {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		$file  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table 
         		   WHERE export_id=%s
					 AND real_name=%s", $export_id, $name ), ARRAY_A );

		if ( empty( $file ) ) {
			return null;
		}

		return $file[ 'uuid' ];
	}

	/**
	 * Delete all files associated with a specific export ID.
	 * This function will delete all records in the database for the given export ID,
	 * and also remove the directory containing the files.
	 * @param int $export_id The ID of the export for which to delete files.
	 */
	public function deleteFiles( int $export_id ): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		$wpdb->delete( $table, array( 'export_id' => $export_id ) );

		$directory = $this->file_path . $export_id;
		$this->removeDirectoryRecursive( $directory );
	}

	/**
	 * Mark a file as downloaded.
	 * This function will update the given file in the database and set
	 * its "ads_downloaded" field to 1 and "downloaded_date" to the current date.
	 * @param int    $export_id The ID of the export to which the file belongs.
	 * @param string $uuid      The UUID of the file to be marked.
	 */
	public function markFileAsDownloaded( int $export_id, string $uuid ): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;

		$data = array(
			'ads_downloaded'  => 1,
			'downloaded_date' => current_time( 'mysql' ),
		);

		// Update the file in the database.
		$wpdb->update( $table, $data, array(
			'export_id' => $export_id,
			'uuid'      => $uuid
		) );
	}

	/**
	 * Set the download date for a file.
	 * This function will update the "downloaded_date" field of the file in the database
	 * to the current date and time.
	 * @param int    $export_id The ID of the export to which the file belongs.
	 * @param string $uuid      The UUID of the file to be updated.
	 */
	public function setDownloadDate( int $export_id, string $uuid ): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;

		$data = array(
			'downloaded_date' => current_time( 'mysql' ),
		);

		// Update the file in the database.
		$wpdb->update( $table, $data, array(
			'export_id' => $export_id,
			'uuid'      => $uuid
		) );
	}

	/**
	 * Remove a directory and all its contents recursively.
	 * This function will delete all files and subdirectories inside the given directory.
	 * It will also delete the given directory itself.
	 * @param string $dir The path to the directory to be deleted.
	 * @return bool True on success, false on failure.
	 */
	public function removeDirectoryRecursive( string $dir ): bool {
		if ( !is_dir( $dir ) ) {
			return false;
		}

		// Get all the files and directories inside the given directory.
		$files = array_diff( scandir( $dir ), array(
			'.',
			'..'
		) );

		foreach ( $files as $file ) {
			$path = $dir . '/' . $file;

			// If the item is a directory, recursively delete it.
			if ( is_dir( $path ) ) {
				$this->removeDirectoryRecursive( $path );
			} // If the item is a file, delete it.
			else {
				unlink( $path );
			}
		}

		// Delete the given directory itself.
		rmdir( $dir );

		return true;
	}

	/**
	 * Get the main file for a specific export ID.
	 * This function retrieves the main file associated with the given export ID
	 * and a specified status (default is 1).
	 * @param int $export_id The ID of the export to which the file belongs.
	 * @param int $status    The status of the file (default is 1).
	 * @return array|null The main file record, or null if not found.
	 */
	public function getMainFile( int $export_id, int $status = 1 ): ?array {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		$file  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table 
         		   WHERE export_id=%s
					 AND main_file=1
         		     AND status=%s
				   ORDER BY created_at DESC", $export_id, $status ), ARRAY_A );

		if ( empty( $file ) ) {
			return null;
		}

		return $file;
	}

	/**
	 * Get the full file for a specific export ID.
	 * This function retrieves the full file associated with the given export ID
	 * and a specified status (default is 1).
	 * @param int $export_id The ID of the export to which the file belongs.
	 * @param int $status    The status of the file (default is 1).
	 * @return array|null The full file record, or null if not found.
	 */
	public function getFullFile( int $export_id, int $status = 1 ): ?array {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		$file  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table 
         		   WHERE export_id=%s
					 AND full_file=1
         		     AND status=%s
				   ORDER BY created_at DESC", $export_id, $status ), ARRAY_A );

		if ( empty( $file ) ) {
			return null;
		}

		return $file;
	}

	/**
	 * Rename a file in the database.
	 * This function updates the real name of the file in the database and sets it as not the main file.
	 * @param int    $file_id  The ID of the file to be renamed.
	 * @param string $new_name The new name for the file.
	 */
	public function renameFile( int $file_id, string $new_name ): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		$data  = array(
			'real_name' => $new_name,
			'main_file' => 0,
		);
		$wpdb->update( $table, $data, array( 'id' => $file_id ) );
	}

	/**
	 * Set the live status of a file.
	 * This function updates the status of the file in the database and handles the renaming of main files.
	 * @param int    $export_id The ID of the export to which the file belongs.
	 * @param string $type      The type of file ('main', 'full', 'main_part', 'full_part').
	 */
	public function setFileLiveStatus( int $export_id, string $type = 'main' ): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;

		$data = array(
			'status' => 1,
		);

		if ( $type == 'full' || $type == 'full_part' ) {
			$old = $this->getFullFile( $export_id );
			if ( $old ) {
				$file_path = $this->getFilePath( $export_id, $old[ 'uuid' ] );
				if ( file_exists( $file_path ) ) {
					unlink( $file_path );
				}

				$this->deleteTableRecord( $old[ 'uuid' ] );
			}

			update_post_meta( $export_id, '_cnvex_last_full_export', strtotime( 'now' ) );

			// Update the file in the database.
			$wpdb->update( $table, $data, array(
				'export_id' => $export_id,
				'full_file' => 1,
			) );
		} elseif ( $type == 'main' || $type == 'main_part' ) {
			//Rename main file
			$main_file_live = $this->getMainFile( $export_id );
			if ( $main_file_live ) {
				$file_path = $this->getFilePath( $export_id, $main_file_live[ 'uuid' ] );
				if ( file_exists( $file_path ) ) {
					$start_date = !empty( $main_file_live[ 'downloaded_date' ] ) ? ( $main_file_live[ 'downloaded_date' ]
					                                                                 . '-' ) : '';

					$file_slug = get_post_meta( $export_id, '_cnvex_file_slug', true );
					$file_slug = str_replace( '.csv', '', $file_slug );
					$filename   = $file_slug . '-' . esc_html( $start_date )
					              . esc_html( date( 'Y-m-d-H-i-s' ) ) . '-' . strtotime( 'now' ) . '.csv';
					$filename   = str_replace( [
						':',
						' '
					], '-', $filename );
					FileManager()->renameFile( $main_file_live[ 'id' ], $filename );
				}
			}

			//Check files count
			$number_files = ConversionExporter()->getOption( 'number_files' );
			$files        = $this->getFilesByExportId( $export_id );
			array_splice( $files, 0, $number_files - 1 );
			if ( !empty( $files ) ) {
				foreach ( $files as $file ) {
					$file_path = $this->getFilePath( $export_id, $file[ 'uuid' ] );
					if ( file_exists( $file_path ) ) {
						unlink( $file_path );
					}
					$this->deleteTableRecord( $file[ 'uuid' ] );
				}
			}

			update_post_meta( $export_id, '_cnvex_last_export', strtotime( 'now' ) );

			// Update the file in the database.
			$wpdb->update( $table, $data, array(
				'export_id' => $export_id,
				'main_file' => 1,
			) );
		}

		// Remove last error
		delete_post_meta( $export_id, '_cnvex_last_error' );
	}

	/**
	 * Get the last crawled file for a specific export ID.
	 * This function retrieves the last downloaded date of the main file for the given export ID,
	 * ordered by the downloaded date in descending order.
	 * @param int $export_id The ID of the export to which the file belongs.
	 * @return string|null The last downloaded date, or null if not found.
	 */
	public function getLastCrawledFile( int $export_id ): ?string {
		global $wpdb;

		$table                = $wpdb->prefix . $this->file_table_name;
		$last_downloaded_date = $wpdb->get_var( $wpdb->prepare( "SELECT downloaded_date
         FROM $table
         WHERE downloaded_date IS NOT NULL
            AND ads_downloaded = 1
		 	AND export_id = %d
		 	AND full_file = 0
		 	AND status = 1
         ORDER BY downloaded_date DESC
         LIMIT 1", $export_id ) );

		return $last_downloaded_date;
	}

	/**
	 * Check if the current generating task is for the specified export ID.
	 * This function checks if the last generating task for the main or full file
	 * includes the specified export ID in its export IDs.
	 * @param int  $export_id The ID of the export to check.
	 * @param bool $main_file Whether to check for the main file (true) or full file (false).
	 * @return bool|null Returns true if the export ID is found, false if not, or null if no task exists.
	 */
	public function currentGeneratingTask( int $export_id, bool $main_file = true ): ?bool {
		global $wpdb;

		$table_file_data = $wpdb->prefix . 'cnvex_file_data';

		if ( $main_file ) {
			$type = 'main_part';
		} else {
			$type = 'full_part';
		}

		$active_check = $wpdb->get_var( $wpdb->prepare( "
			    SELECT COUNT(*) 
			    FROM $table_file_data
			    WHERE export_id = %d 
			        AND (%s = 'main_part' AND main_file = 1 OR %s = 'full_part' AND full_file = 1)
			        AND status = 1", $export_id, $type, $type ) );

		if ( $active_check > 0 ) {
			return null;
		}

		$table_create_data = $wpdb->prefix . 'cnvex_create_file_data';

		$query = $wpdb->prepare( "
			SELECT * 
				FROM $table_create_data
				WHERE type = %s  
				ORDER BY created_at 
					DESC LIMIT 1", $type );

		$task = $wpdb->get_row( $query, ARRAY_A );
		if ( empty( $task ) ) {
			return null;
		}

		$task[ 'export_ids' ] = json_decode( $task[ 'export_ids' ], true );

		if ( in_array( $export_id, $task[ 'export_ids' ] ) ) {
			return true;
		}

		return false;
	}
}

/**
 * Returns the singleton instance of FileManager.
 * This function is a convenience wrapper for accessing the FileManager instance.
 * @return FileManager|null The instance of FileManager or null if not initialized.
 */
function FileManager(): ?FileManager {
	return FileManager::get_instance();
}

FileManager();