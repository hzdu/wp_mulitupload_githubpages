<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Form
 * Handles the form management functionality of the Conversion Exporter plugin.
 * This class provides methods for updating form settings, scanning pages for forms,
 * handling HTML content, and capturing form data.
 */
class Form extends Settings implements Plugin {

	private static array $formMetaFields = array(
		'_cnvex_enable',
		'_cnvex_form_name',
		'_cnvex_page_url',
		'_cnvex_form',
		'_cnvex_form_type',
		'_cnvex_form_data_input',
		'_cnvex_email_field',
		'_cnvex_first_name_field',
		'_cnvex_last_name_field',
		'_cnvex_phone_field',
		'_cnvex_data_retention',
		'_cnvex_delete_days',
		'_cnvex_delete_entries',
	);

	protected static ?Form $instance = null;

	/**
	 * Get the singleton instance of the Form class.
	 * @return Form|null
	 */
	public static function get_instance(): ?Form {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function __construct() {
		parent::__construct( 'form' );

		$className = basename( str_replace( '\\', '/', get_class( $this ) ) );

		$this->locateOptions( CNVEX_PLUGIN_PATH . 'includes/modules/' . $className
		                      . '/options_fields.json', CNVEX_PLUGIN_PATH . 'includes/modules/' . $className
		                                                . '/options_defaults.json' );

		// Update enabled/disabled conversion task
		add_action( 'wp_ajax_cnvex_form_update', array(
			$this,
			'formUpdate'
		) );

		//Scan page
		add_action( 'wp_ajax_cnvex_scan_page', array(
			$this,
			'scanPage'
		) );

		//Scan page
		add_action( 'wp_ajax_cnvex_handle_html', array(
			$this,
			'handleHTML'
		) );

		//Capture form data
		add_action( 'wp_ajax_cnvex_form_send', array(
			$this,
			'captureFormData'
		) );
		add_action( 'wp_ajax_nopriv_cnvex_form_send', array(
			$this,
			'captureFormData'
		) );

		if ( !wp_next_scheduled( 'cnvex_form_data_retention' ) ) {
			wp_schedule_event( time(), 'daily', 'cnvex_form_data_retention' );
		}

		// Cron actions
		add_action( 'cnvex_form_data_retention', array(
			$this,
			'formCronDataRetention'
		) );
	}

	/**
	 * Get the form meta fields used in the plugin.
	 * This method returns an array of meta fields that are used to store additional information
	 * about forms in the plugin. These fields are typically used for storing settings and configurations
	 * related to each form.
	 * @return array An array of form meta fields.
	 */
	public static function getFormMetaFields(): array {
		return self::$formMetaFields;
	}

	/**
	 * Returns the latest version number of the plugin.
	 * This method is used to retrieve the current version of the plugin,
	 * which can be useful for compatibility checks or displaying version information.
	 * @return string The latest version number of the plugin.
	 */
	public function getPluginVersion(): string {
		return CNVEX_LATEST_VERSION_NUMBER;
	}

	/**
	 * Update form settings based on the submitted data.
	 * This method processes the form data submitted via AJAX, updates the form meta,
	 * and sends a JSON response indicating success or failure.
	 * @return void
	 */
	public function formUpdate(): void {
		// Check nonce:
		check_admin_referer( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );
		$this->managePermissions();

		$id     = isset( $_POST[ 'id' ] ) ? sanitize_text_field( $_POST[ 'id' ] ) : null;
		$active = isset( $_POST[ 'active' ] ) ? sanitize_text_field( $_POST[ 'active' ] ) : null;
		update_post_meta( $id, '_cnvex_enable', $active );

		wp_send_json_success();
		wp_die();
	}

	/**
	 * Scan a page for forms by URL.
	 * This method checks if the provided URL is valid, belongs to the current site,
	 * and then retrieves the forms data from that URL.
	 * @return void
	 */
	public function scanPage(): void {
		// Check nonce:
		check_admin_referer( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );
		$this->managePermissions();

		if ( empty( $_POST[ 'url' ] ) ) {
			wp_send_json_success( array(
				'error'   => __( 'No URL provided', 'conversion-exporter' ),
				'success' => false
			) );
			wp_die();
		}

		$url = urldecode( trim( $_POST[ 'url' ] ) );

		if ( !filter_var( $url, FILTER_VALIDATE_URL ) ) {
			wp_send_json_success( array(
				'error'   => __( 'Not a valid URL', 'conversion-exporter' ),
				'success' => false
			) );
			wp_die();
		}

		$site_host = parse_url( home_url(), PHP_URL_HOST );
		$url_host  = parse_url( $url, PHP_URL_HOST );

		if ( $site_host !== $url_host ) {
			wp_send_json_success( array(
				'error'   => __( 'URL does not belong to this site', 'conversion-exporter' ),
				'success' => false
			) );
			wp_die();
		}

		$forms_data = $this->getFormsData( sanitize_url( urldecode( $_POST[ 'url' ] ) ) );

		wp_send_json_success( $forms_data );
		wp_die();
	}

	/**
	 * This method processes the HTML content submitted via AJAX, decodes and decompresses it,
	 * extracts form data, and returns the results in a JSON response.
	 * @return void
	 */
	public function handleHTML(): void {
		// Check nonce:
		check_admin_referer( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );
		$this->managePermissions();

		if ( empty( $_POST[ 'html' ] ) ) {
			wp_send_json_success( array(
				'error'   => __( 'No HTML provided', 'conversion-exporter' ),
				'success' => false
			) );
			wp_die();
		}

		$encoded    = wp_unslash( $_POST[ 'html' ] );
		$compressed = base64_decode( $encoded );

		$html = gzdecode( $compressed );
		if ( $html === false ) {
			wp_send_json_success( array(
				'error'   => __( 'Something went wrong', 'conversion-exporter' ),
				'success' => false
			) );
			wp_die();
		}

		$forms_data = $this->extractFormData( $html );
		$data       = array(
			'success'    => false,
			'error'      => '',
			'forms_data' => array()
		);

		if ( empty( $forms_data ) ) {
			$data[ 'error' ] = __( 'No forms found on the page', 'conversion-exporter' );
		} else {
			$data[ 'forms_data' ] = $forms_data;
			$data[ 'success' ]    = true;
		}

		wp_send_json_success( $data );
		wp_die();
	}

	/**
	 * Get forms data from a given URL.
	 * @param string $url The URL to fetch forms data from.
	 * @return array An array containing success status, error message, and forms data.
	 */
	public function getFormsData( string $url ): array {
		$data = array(
			'success'    => false,
			'error'      => '',
			'get_js'     => false,
			'forms_data' => array()
		);

		if ( empty( $url ) ) {
			$data[ 'error' ] = __( 'No URL provided', 'conversion-exporter' );

			return $data;
		}

		$page_html = @file_get_contents( $url );
		if ( $page_html === false ) {
			$curl = curl_init( $url );
			curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
			curl_setopt( $curl, CURLOPT_CONNECTTIMEOUT, 10 );
			curl_setopt( $curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36' );
			curl_setopt( $curl, CURLOPT_FOLLOWLOCATION, true );
			curl_setopt( $curl, CURLOPT_HEADER, true );
			curl_setopt( $curl, CURLOPT_NOBODY, false );

			$response  = curl_exec( $curl );
			$http_code = curl_getinfo( $curl, CURLINFO_HTTP_CODE );
			curl_close( $curl );

			// Cloudflare codes
			if ( $http_code === 403 || $http_code === 503 ) {
				$data[ 'get_js' ] = true;

				return $data;
			}

			if ( $http_code === 404 ) {
				$data[ 'error' ] = __( 'Page not found (404)', 'conversion-exporter' );

				return $data;
			}

			if ( !$response ) {
				$data[ 'error' ] = __( 'Error! Couldn\'t get the page HTML.', 'conversion-exporter' );

				return $data;
			}

			$page_html = $response;
		}

		//Cloudflare JavaScript challenge or captcha page
		if ( strpos( $page_html, 'jschl_vc' ) !== false || strpos( $page_html, '/cdn-cgi/l/chk_jschl' ) !== false
		     || strpos( $page_html, 'cf-browser-verification' ) !== false
		     || strpos( $page_html, 'Cloudflare Ray ID' ) !== false
		     || strpos( $page_html, 'Attention Required! | Cloudflare' ) !== false ) {
			$data[ 'get_js' ] = true;

			return $data;
		}

		$forms_data = $this->extractFormData( $page_html );

		if ( empty( $forms_data ) ) {
			$data[ 'error' ] = __( 'No forms found on the page', 'conversion-exporter' );
		} else {
			$data[ 'forms_data' ] = $forms_data;
			$data[ 'success' ]    = true;
		}

		return $data;
	}

	/**
	 * Extracts form data from the provided HTML content.
	 * This method uses DOMDocument and XPath to parse the HTML and extract form fields.
	 * It identifies different form plugins (Contact Form 7, Fluent Forms, Ninja Forms and other) based on their HTML structure.
	 * @param string $html The HTML content to extract form data from.
	 * @return array An array of extracted form data, including form ID, class, action, method, fields, and form type.
	 */
	private function extractFormData( string $html ): array {
		$forms_data = array();
		libxml_use_internal_errors( true );
		$dom = new \DomDocument();
		@$dom->loadHTML( $html );

		$xpath = new \DomXPath( $dom );

		$forms = $xpath->query( './/form' );

		foreach ( $forms as $form ) {
			$form_fields_data = array();
			$form_fields      = $xpath->query( './/input[@type="text" or @type="email" or @type="tel"]', $form );
			foreach ( $form_fields as $form_field ) {

				$form_fields_data[] = array(
					'id'       => $form_field->getAttribute( 'id' ),
					'name'     => $form_field->getAttribute( 'name' ),
					'value'    => $form_field->getAttribute( 'name' ),
					'type'     => $form_field->getAttribute( 'type' ),
					'class'    => $form_field->getAttribute( 'class' ),
					'selector' => $this->getFullCSSSelector( $form_field, $form )
				);
			}

			$form_html = $dom->saveHTML( $form );
			if ( strpos( $form_html, 'wpcf7-form' ) !== false ) {
				$plugin = 'contact-form-7';
			} elseif ( strpos( $form_html, 'fluentform' ) !== false ) {
				$plugin = 'fluentform';
			} else {
				$plugin = 'standard';
			}

			$forms_data[] = array(
				'id'        => $form->getAttribute( 'id' ),
				'class'     => $form->getAttribute( 'class' ),
				'action'    => $form->getAttribute( 'action' ),
				'method'    => $form->getAttribute( 'method' ),
				'selector'  => $this->getFullCSSSelector( $form, $xpath->query( './/body' )->item( 1 ) ),
				'fields'    => $form_fields_data,
				'form_type' => $plugin
			);
		}

		// search Ninja forms
		if ( function_exists( 'Ninja_Forms' ) ) {
			$exclude_field_types = array(
				'starrating',
				'recaptcha',
				'spam',
				'hidden',
				'confirm',
				'html',
				'total',
				'liststate',
				'submit',
				'listselect',
				'listradio',
				'listmultiselect',
				'listcheckbox',
				'date',
				'checkbox',
				'listcountry',
				'number',
				'hr',
				'total',
				'product',
				'shipping',
				'quantity'
			);

			$forms = $xpath->query( './/div[@role="form"]' );
			foreach ( $forms as $form ) {
				$form_id = preg_replace( '/[^0-9]/', '', $form->getAttribute( 'id' ) );
				if ( !$form_id ) {
					continue;
				}
				$form_fields_data = array();
				$form_fields      = Ninja_Forms()->form( $form_id )->get_fields();
				foreach ( $form_fields as $form_field ) {
					$field_type = $form_field->get_setting( 'type' );
					if ( in_array( $field_type, $exclude_field_types ) ) {
						continue;
					}
					$field_id           = $form_field->get_id();
					$form_fields_data[] = array(
						'id'    => $field_id,
						'name'  => $form_field->get_setting( 'label' ),
						'value' => $field_id,
						'type'  => '',
						'class' => '',
					);
				}
				$forms_data[] = array(
					'id'        => $form->getAttribute( 'id' ),
					'class'     => $form->getAttribute( 'class' ),
					'action'    => $form->getAttribute( 'action' ),
					'method'    => $form->getAttribute( 'method' ),
					'selector'  => $this->getFullCSSSelector( $form, $xpath->query( './/body' )->item( 1 ) ),
					'fields'    => $form_fields_data,
					'form_type' => 'ninja'
				);
			}
		}

		return $forms_data;
	}

	/**
	 * Get the full CSS selector for a given node.
	 * @param $node  - The DOM node to get the selector for.
	 * @param $pNode - The parent node to compare against.
	 * @return string The full CSS selector for the node.
	 */
	private function getFullCSSSelector( $node, $pNode ): string {
		$nodeID = $this->getNodeID( $node );
		if ( $nodeID != '' ) {
			return $node->nodeName . '#' . $nodeID;
		} elseif ( $node->nodeName == 'body' || $node == $pNode ) {
			return $node->nodeName;
		} else {
			return $this->getFullCSSSelector( $node->parentNode, $pNode ) . '>' . $node->nodeName;
		}
	}

	/**
	 * Get the ID attribute of a DOM node.
	 * @param $node - The DOM node to get the ID from.
	 * @return string The ID of the node, or an empty string if not found.
	 */
	private function getNodeID( $node ): string {
		$nodeID    = '';
		$nodeAttrs = $node->attributes;
		foreach ( $nodeAttrs as $nodeAttr ) {
			if ( $nodeAttr->nodeName == 'id' ) {
				$nodeID = $nodeAttr->nodeValue;
			}
		}

		return $nodeID;
	}

	/**
	 * Handle permissions for managing forms.
	 * This method checks if the current user has the required capability to manage forms.
	 * If not, it terminates the script with an error message.
	 * @return void
	 */
	public function managePermissions(): void {
		// Lock out non-admins:
		if ( !current_user_can( 'cnvex_manage' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permission to perform this operation', 'conversion-exporter' ) );
		}
	}

	/**
	 * Verify the public nonce for AJAX requests.
	 * This method checks if the nonce provided in the POST request is valid.
	 * If the nonce is invalid, it terminates the script with an error message.
	 * @return void
	 */
	public function verifyPublicNonce(): void {
		$nonce = empty( $_POST[ 'nonce' ] ) ? '' : stripslashes_deep( $_POST[ 'nonce' ] );
		if ( !wp_verify_nonce( $nonce, 'cnvex-ajax-nonce' ) ) {
			wp_die( esc_html__( 'Invalid code', 'conversion-exporter' ) );
		}
	}

	/**
	 * Capture form data from AJAX request.
	 * This method processes the form data submitted via AJAX, validates the input,
	 * and saves it to the database.
	 * @return void
	 */
	public function captureFormData(): void {

		$this->verifyPublicNonce();

		if ( !isset( $_POST[ 'form_id' ] ) ) {
			wp_send_json_success( array(
				'error'   => __( 'Form ID not provided', 'conversion-exporter' ),
				'success' => false
			) );
			wp_die();
		}

		if ( !isset( $_POST[ 'email_field' ] ) || !filter_var( $_POST[ 'email_field' ], FILTER_VALIDATE_EMAIL ) ) {
			wp_send_json_success( array(
				'error'   => __( 'Invalid email', 'conversion-exporter' ),
				'success' => false
			) );
			wp_die();
		}

		$form_id            = sanitize_text_field( $_POST[ 'form_id' ] );
		$gclid              = isset( $_POST[ 'gclid' ] ) ? sanitize_text_field( $_POST[ 'gclid' ] ) : '';
		$gbraid             = isset( $_POST[ 'gbraid' ] ) ? sanitize_text_field( $_POST[ 'gbraid' ] ) : '';
		$wbraid             = isset( $_POST[ 'wbraid' ] ) ? sanitize_text_field( $_POST[ 'wbraid' ] ) : '';
		$first_name_field   = isset( $_POST[ 'first_name_field' ] ) ? sanitize_text_field( $_POST[ 'first_name_field' ] ) : '';
		$last_name_field    = isset( $_POST[ 'last_name_field' ] ) ? sanitize_text_field( $_POST[ 'last_name_field' ] ) : '';
		$email_field        = sanitize_email( $_POST[ 'email_field' ] );
		$phone_field        = isset( $_POST[ 'phone_field' ] ) ? sanitize_text_field( $_POST[ 'phone_field' ] ) : '';
		$session_attributes = isset( $_POST[ 'session_attributes' ] ) ? sanitize_text_field( $_POST[ 'session_attributes' ] ) : '';
		$consent            = $consent_mode = array();

		$store_consent = ConversionExporter()->getOption( 'consent_enable' ) == 1
		                 && ConversionExporter()->getOption( 'store_cm_consent' ) == 1;
		if ( $store_consent ) {
			if ( isset( $_POST[ 'consent' ] ) && is_array( $_POST[ 'consent' ] ) ) {
				$consent = HelperFunctions::recursivelySanitize( $_POST[ 'consent' ] );
			}

			$consent_mode = apply_filters( 'cm_google_consent_mode', array(
				'analytics_storage'  => array(
					'enabled' => true,
					'value'   => 'granted',
				),
				'ad_storage'         => array(
					'enabled' => true,
					'value'   => 'granted',
				),
				'ad_user_data'       => array(
					'enabled' => true,
					'value'   => 'granted',
				),
				'ad_personalization' => array(
					'enabled' => true,
					'value'   => 'granted',
				),
			) );
		}

		$data = array(
			'form_id'            => $form_id,
			'gclid'              => $gclid,
			'gbraid'             => $gbraid,
			'wbraid'             => $wbraid,
			'first_name'         => $first_name_field,
			'last_name'          => $last_name_field,
			'email'              => $email_field,
			'phone'              => $phone_field,
			'consent'            => $consent,
			'consent_mode'       => $consent_mode,
			'session_attributes' => $session_attributes,
			'ip_address'         => HelperFunctions::getClientIP(),
			'user_agent'         => $_SERVER[ 'HTTP_USER_AGENT' ] ?? '',
		);

		$this->createFormDataEntry( $data );
	}

	/**
	 * Create or update form data entry in the database.
	 * This method checks if a form entry with the given GCLID exists. If it does, it updates the entry;
	 * otherwise, it creates a new entry. It also handles consent data if consent management is enabled.
	 * @param array $data
	 */
	private function createFormDataEntry( array $data ): void {

		global $wpdb;
		$table = $wpdb->prefix . 'cnvex_form_data';
		$form  = null;

		if ( !empty( $data[ 'gclid' ] ) || !empty( $data[ 'gbraid' ] ) || !empty( $data[ 'wbraid' ] ) ) {
			$conditions = array();
			$params     = array( $data[ 'form_id' ] );

			if ( !empty( $data[ 'gclid' ] ) ) {
				$conditions[] = 'gclid=%s';
				$params[]     = $data[ 'gclid' ];
			}

			if ( !empty( $data[ 'gbraid' ] ) ) {
				$conditions[] = 'gbraid=%s';
				$params[]     = $data[ 'gbraid' ];
			}

			if ( !empty( $data[ 'wbraid' ] ) ) {
				$conditions[] = 'wbraid=%s';
				$params[]     = $data[ 'wbraid' ];
			}

			$where_clause = implode( ' OR ', $conditions );

			$form = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table 
				         WHERE form_id=%s
				         AND ($where_clause)
				         ORDER BY submitted_at DESC", ...$params ), ARRAY_A );
		}

		$form_data = apply_filters( 'cnvex_save_form_data', array(
			'first_name' => $data[ 'first_name' ],
			'last_name'  => $data[ 'last_name' ],
			'email'      => $data[ 'email' ],
			'phone'      => $data[ 'phone' ],
			'ip_address' => $data[ 'ip_address' ],
			'user_agent' => $data[ 'user_agent' ],
		), $data[ 'form_id' ] );

		$first_name_field = sanitize_text_field( !empty( $form_data[ 'first_name' ] ) ? $form_data[ 'first_name' ] : $data[ 'first_name' ] );
		$last_name_field  = sanitize_text_field( !empty( $form_data[ 'last_name' ] ) ? $form_data[ 'last_name' ] : $data[ 'last_name' ] );
		$email_field      = sanitize_email( !empty( $form_data[ 'email' ] ) ? $form_data[ 'email' ] : $data[ 'email' ] );
		$phone_field      = sanitize_text_field( !empty( $form_data[ 'phone' ] ) ? $form_data[ 'phone' ] : $data[ 'phone' ] );
		$ip_address_field = sanitize_text_field( !empty( $form_data[ 'ip_address' ] ) ? $form_data[ 'ip_address' ] : $data[ 'ip_address' ] );
		$user_agent_field = sanitize_text_field( !empty( $form_data[ 'user_agent' ] ) ? $form_data[ 'user_agent' ] : $data[ 'user_agent' ] );

		if ( !empty( $form ) ) {
			$table_data = array(
				'gclid'              => !empty( $form[ 'gclid' ] ) ? $form[ 'gclid' ] : $data[ 'gclid' ],
				'gbraid'             => !empty( $form[ 'gbraid' ] ) ? $form[ 'gbraid' ] : $data[ 'gbraid' ],
				'wbraid'             => !empty( $form[ 'wbraid' ] ) ? $form[ 'wbraid' ] : $data[ 'wbraid' ],
				'first_name'         => !empty( $first_name_field ) ? $first_name_field : $form[ 'first_name' ],
				'last_name'          => !empty( $last_name_field ) ? $last_name_field : $form[ 'last_name' ],
				'email'              => !empty( $email_field ) ? $email_field : $form[ 'email' ],
				'phone'              => !empty( $phone_field ) ? $phone_field : $form[ 'phone' ],
				'ip_address'         => !empty( $ip_address_field ) ? $ip_address_field : $form[ 'ip_address' ],
				'user_agent'         => !empty( $user_agent_field ) ? $user_agent_field : $form[ 'user_agent' ],
				'session_attributes' => !empty( $data[ 'session_attributes' ] ) ? $data[ 'session_attributes' ] : $form[ 'session_attributes' ],
				'submitted_at'       => current_time( 'mysql' ),
				'analytics_storage'  => !empty( $data[ 'consent_mode' ] ) ? $data[ 'consent_mode' ][ 'analytics_storage' ][ 'value' ] : null,
				'ad_storage'         => !empty( $data[ 'consent_mode' ] ) ? $data[ 'consent_mode' ][ 'ad_storage' ][ 'value' ] : null,
				'ad_user_data'       => !empty( $data[ 'consent_mode' ] ) ? $data[ 'consent_mode' ][ 'ad_user_data' ][ 'value' ] : null,
				'ad_personalization' => !empty( $data[ 'consent_mode' ] ) ? $data[ 'consent_mode' ][ 'ad_personalization' ][ 'value' ] : null,
			);

			$wpdb->update( $table, $table_data, array( 'id' => $form[ 'id' ] ) );
			ConsentManager()->createConsentDataEntry( $form[ 'id' ], $data[ 'form_id' ], $data[ 'consent' ] );
		} else {
			$table_data = array(
				'form_id'            => $data[ 'form_id' ],
				'gclid'              => $data[ 'gclid' ],
				'gbraid'             => $data[ 'gbraid' ],
				'wbraid'             => $data[ 'wbraid' ],
				'first_name'         => $first_name_field,
				'last_name'          => $last_name_field,
				'email'              => $email_field,
				'phone'              => $phone_field,
				'ip_address'         => $ip_address_field,
				'user_agent'         => $user_agent_field,
				'session_attributes' => $data[ 'session_attributes' ],
				'submitted_at'       => current_time( 'mysql' ),
				'analytics_storage'  => !empty( $data[ 'consent_mode' ] ) ? $data[ 'consent_mode' ][ 'analytics_storage' ][ 'value' ] : null,
				'ad_storage'         => !empty( $data[ 'consent_mode' ] ) ? $data[ 'consent_mode' ][ 'ad_storage' ][ 'value' ] : null,
				'ad_user_data'       => !empty( $data[ 'consent_mode' ] ) ? $data[ 'consent_mode' ][ 'ad_user_data' ][ 'value' ] : null,
				'ad_personalization' => !empty( $data[ 'consent_mode' ] ) ? $data[ 'consent_mode' ][ 'ad_personalization' ][ 'value' ] : null,
			);

			$wpdb->insert( $table, $table_data );

			// If the insert was successful, assign the new ID to the new consent entry.
			if ( $wpdb->insert_id !== false ) {
				ConsentManager()->createConsentDataEntry( $wpdb->insert_id, $data[ 'form_id' ], $data[ 'consent' ] );
			}
		}
	}

	/**
	 * Get all forms.
	 * This method retrieves all forms that are enabled and returns them as an associative array
	 * with form IDs as keys and form names as values.
	 * @return array An associative array of form IDs and names.
	 */
	public function getForms(): array {
		$args         = array(
			'post_type'      => CNVEX_FORM_POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'order'          => 'ASC',
			'orderby'        => 'DATE',
			'meta_query'     => array(
				array(
					'key'   => '_cnvex_enable',
					'value' => 1,
				)
			),
			'meta_type'      => 'NUMERIC',
		);
		$forms        = get_posts( $args );
		$forms_output = array();

		if ( !empty( $forms ) ) {
			foreach ( $forms as $form ) {
				$forms_output[ $form->ID ] = get_post_meta( $form->ID, '_cnvex_form_name', true );
			}
		}

		return $forms_output;
	}

	/**
	 * Get form data by form ID.
	 * This method retrieves all form data entries for a specific form ID from the database.
	 * @param string $form_id The ID of the form to retrieve data for.
	 * @return array An array of form data entries, or an empty array if no data is found.
	 */
	public function getFormData( string $form_id ): array {
		$form_data = array();
		if ( !empty( $form_id ) ) {
			global $wpdb;
			$table     = $wpdb->prefix . 'cnvex_form_data';
			$form_data = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE form_id=%s ORDER BY submitted_at DESC", $form_id ), ARRAY_A );
		}

		return $form_data;
	}

	/**
	 * Remove form data by form ID.
	 * This method deletes all form data entries associated with a specific form ID from the database.
	 * @param string $form_id The ID of the form whose data should be removed.
	 * @return void
	 */
	public function removeFormData( string $form_id ): void {
		if ( !empty( $form_id ) ) {
			global $wpdb;
			$table = $wpdb->prefix . 'cnvex_form_data';
			$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE form_id=%s", $form_id ) );
		}
	}

	/**
	 * Remove all form data from the database.
	 * This method truncates the form data table, effectively removing all entries.
	 * @return void
	 */
	public function removeAllFormData(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'cnvex_form_data';
		$wpdb->query( "TRUNCATE TABLE $table" );
	}

	/**
	 * Cron job to handle data retention for forms.
	 * This method checks each form's data retention settings and deletes entries based on the configured
	 * number of days or entries to retain. It uses WordPress's WPDB class for database operations.
	 * @return void
	 */
	public function formCronDataRetention(): void {
		$forms = $this->getForms();
		if ( empty( $forms ) ) {
			return;
		}

		foreach ( $forms as $form_id => $form_name ) {
			$data_retention = get_post_meta( $form_id, '_cnvex_data_retention', true );
			$disable        = apply_filters( 'cnvex_form_data_retention_option', $data_retention
			                                                                     === 'never', $form_id );

			if ( has_filter( 'cnvex_form_data_retention_option' ) && $disable ) {
				continue;
			}
			if ( !has_filter( 'cnvex_form_data_retention_option' )
			     && ( $data_retention === 'never'
			          || empty( $data_retention ) ) ) {
				continue;
			}

			$delete_days = get_post_meta( $form_id, '_cnvex_delete_days', true );
			if ( empty( $delete_days ) ) {
				$delete_days = 0;
			}
			$delete_entries = get_post_meta( $form_id, '_cnvex_delete_entries', true );
			if ( empty( $delete_entries ) ) {
				$delete_entries = 0;
			}

			$delete_options = apply_filters( 'cnvex_form_data_retention_values', array(
				'days'    => $delete_days,
				'entries' => $delete_entries,
			), $form_id );

			$delete_days    = $delete_options[ 'days' ];
			$delete_entries = $delete_options[ 'entries' ];

			global $wpdb;
			$table = $wpdb->prefix . 'cnvex_form_data';

			if ( is_numeric( $delete_days ) && $delete_days > 0 ) {
				$wpdb->query( $wpdb->prepare( "
					DELETE FROM $table
					       WHERE form_id=%s
					         AND submitted_at < DATE_SUB(NOW(), INTERVAL %d DAY)", $form_id, (int) $delete_days ) );

			}

			if ( is_numeric( $delete_entries ) && $delete_entries > 0 ) {
				$wpdb->query( $wpdb->prepare( "
					DELETE FROM $table
					       WHERE form_id=%s
					         AND id NOT IN (
						         SELECT id FROM (
							         SELECT id FROM $table
							         WHERE form_id=%s
							         ORDER BY submitted_at DESC
							         LIMIT %d
						         ) AS subquery 
					         )", $form_id, $form_id, (int) $delete_entries ) );
			}
		}
	}

	/**
	 * Get the last exported form date.
	 * This method retrieves the most recent export date for a specific form ID from the database.
	 * @param string $form_id The ID of the form to check.
	 * @return string|null The last exported date in 'Y-m-d H:i:s' format, or null if not found.
	 */
	public function getLastExportedForm( string $form_id ): ?string {
		global $wpdb;
		$table         = $wpdb->prefix . 'cnvex_form_data';
		$last_exported = $wpdb->get_var( $wpdb->prepare( "SELECT MAX(exported_at) FROM $table WHERE form_id=%s", $form_id ) );

		return $last_exported;
	}
}

/**
 * Get the instance of the Form class.
 * @return Form|null The Form instance or null if it doesn't exist.
 */
function Form(): ?Form {
	return Form::get_instance();
}

Form();