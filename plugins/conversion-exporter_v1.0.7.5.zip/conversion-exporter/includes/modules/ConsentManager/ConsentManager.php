<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ConsentManager class handles the management of consent data for forms.
 * It provides methods to create, retrieve, and delete consent records in the database.
 */
class ConsentManager {
	protected static ?ConsentManager $instance    = null;
	private string                   $table_name;
	private string                   $cm_category = 'cs-cookies-category';

	/**
	 * Returns the singleton instance of ConsentManager.
	 *
	 * @return ConsentManager|null The instance of ConsentManager or null if not initialized.
	 */
	public static function get_instance(): ?ConsentManager {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		global $wpdb;
		$this->table_name = $wpdb->prefix . 'cnvex_consent_data';
	}

	/**
	 * Creates a new consent data entry in the database.
	 *
	 * @param int $data_id The ID of the form data.
	 * @param int $form_id The ID of the form task.
	 * @param array $consent An array of consent items, each containing 'id', 'slug', and 'value'.
	 */
	public function createConsentDataEntry( int $data_id, int $form_id, array $consent ): void {
		if ( !empty( $consent ) ) {
			global $wpdb;
			$wpdb->delete( $this->table_name, array( 'form_data_id' => $data_id ) );

			foreach ( $consent as $item ) {
				$term = get_term_by( 'slug', $item[ 'slug' ], $this->cm_category );
				if ( !empty( $term ) ) {
					$data = array(
						'form_data_id'  => $data_id,
						'form_task_id'  => $form_id,
						'category_id'   => $item[ 'id' ],
						'category_slug' => $item[ 'slug' ],
						'value'         => (int) $item[ 'value' ],
						'submitted_at'  => current_time( 'mysql' ),
					);

					$wpdb->insert( $this->table_name, $data );
				}
			}
		}
	}

	/**
	 * Retrieves ConsentMagic categories.
	 *
	 * @return array An array of consent categories.
	 */
	public function getCMCategories(): array {

		$ignore = array();
		$unassigned = get_term_by( 'slug', 'unassigned', $this->cm_category );
		$ignore[] = $unassigned->term_id;
		$necessary = get_term_by( 'slug', 'necessary', $this->cm_category );
		$ignore[] = $necessary->term_id;

		$terms = get_terms( array(
			'taxonomy'   => $this->cm_category,
			'hide_empty' => false,
			'exclude'    => $ignore,
		) );

		$categories = array();
		if ( !is_wp_error( $terms ) && !empty( $terms ) ) {
			foreach ( $terms as $term ) {
				$categories[] = array(
					'id'   => $term->term_id,
					'slug' => $term->slug,
					'name' => $term->name,
				);
			}
		}

		return $categories;
	}

	/**
	 * Retrieves a category slug by a specific field and value.
	 *
	 * @param string $field The field to search by (e.g., 'id', 'slug').
	 * @param string $value The value to search for.
	 *
	 * @return string|null The category slug if found, null otherwise.
	 */
	public function getCategoryBy( string $field, string $value ): ?string {
		$term = get_term_by( $field, $value, $this->cm_category );

		if ( $term ) {
			return $term->slug;
		}

		return null;
	}

	/**
	 * Deletes consent records for a specific form task ID.
	 *
	 * @param int $form_id The form task ID for which to delete consent records.
	 */
	public function deleteConsentRecord( int $form_id ): void {
		global $wpdb;
		$wpdb->delete( $this->table_name, array( 'form_task_id' => $form_id ) );

	}

	/**
	 * Removes all consent data from the database.
	 *
	 * This function truncates the consent data table, effectively removing all records.
	 */
	public function removeAllConsentData(): void {
		global $wpdb;
		$wpdb->query( "TRUNCATE TABLE {$this->table_name}" );
	}
}

/**
 * Returns the singleton instance of ConsentManager.
 *
 * @return ConsentManager|null The instance of ConsentManager or null if not initialized.
 */
function ConsentManager(): ?ConsentManager {
	return ConsentManager::get_instance();
}

ConsentManager();