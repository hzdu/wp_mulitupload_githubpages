<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class OrderManager
 * Handles the management of WooCommerce orders, including adding custom columns,
 * rendering order fields, and saving GCLID to order metadata.
 */
class OrderManager {
	protected static ?OrderManager $instance = null;

	/**
	 * Returns the singleton instance of OrderManager.
	 * @return OrderManager|null The instance of OrderManager or null if not initialized.
	 */
	public static function get_instance(): ?OrderManager {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function __construct() {
		add_action( 'woocommerce_init', array(
			$this,
			'addColumns'
		), PHP_INT_MAX );

		add_action( 'add_meta_boxes', array(
			$this,
			'wooAddOrderMetaBoxes'
		) );

		// Add gclid to order metadata
		add_action( 'woocommerce_new_order', array(
			$this,
			'saveGclidToOrderMeta'
		) );

		// Update order data before order is saved to avoid recursion on save()
		add_action( 'woocommerce_before_order_object_save', array(
			$this,
			'updateOrderData'
		), 10, 1 );

		add_action( 'template_redirect', array(
			$this,
			'saveSessionAttributesToOrderMeta'
		) );
	}

	/**
	 * Adds custom columns to the WooCommerce orders list table.
	 * This function checks the WooCommerce version and whether High-Performance Order Storage is enabled,
	 * then adds the GCLID column to the orders list.
	 * @return void
	 */
	public function addColumns(): void {
		if ( $this->checkWooCommerceVersion( '7.0.0' )
		     && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			// Orders columns
			add_filter( 'manage_woocommerce_page_wc-orders_columns', array(
				$this,
				'addOrderColumns'
			), PHP_INT_MAX );
			add_action( 'manage_woocommerce_page_wc-orders_custom_column', array(
				$this,
				'renderOrderColumns'
			), PHP_INT_MAX, 2 );
		} else {
			// Products columns
			add_filter( 'manage_edit-shop_order_columns', array(
				$this,
				'addOrderColumns'
			), PHP_INT_MAX );
			add_action( 'manage_shop_order_posts_custom_column', array(
				$this,
				'renderOrderColumns'
			), PHP_INT_MAX, 2 );
		}
	}

	/** * Checks if the WooCommerce version is greater than or equal to the specified version.
	 * @param string $version The version to compare against.
	 * @return bool True if the current WooCommerce version is greater than or equal to the specified version, false otherwise.
	 */
	private function checkWooCommerceVersion( string $version ): bool {
		if ( defined( 'WC_VERSION' ) && WC_VERSION ) {
			return version_compare( WC_VERSION, $version, '>=' );
		} else if ( defined( 'WOOCOMMERCE_VERSION' ) && WOOCOMMERCE_VERSION ) {
			return version_compare( WOOCOMMERCE_VERSION, $version, '>=' );
		} else {
			return false;
		}
	}

	/**
	 * Adds a custom column for GCLID to the WooCommerce orders list table.
	 * This function adds a new column to the orders list table to display the GCLID status.
	 * @param array $columns The existing columns in the orders list table.
	 * @return array The modified columns with the GCLID column added.
	 */
	public function addOrderColumns( array $columns ): array {
		$columns[ 'cnvex_gclid' ] = esc_html__( 'GCLID', 'conversion-exporter' );

		return $columns;
	}

	/**
	 * Renders the content of the GCLID column in the WooCommerce orders list table.
	 * This function checks if the GCLID meta exists for the order and displays 'Yes' or 'No'.
	 * @param $column   - The name of the column being rendered.
	 * @param $post_obj - The post object or order object.
	 * @return void
	 */
	public function renderOrderColumns( $column, $post_obj ): void {
		if ( $column === 'cnvex_gclid' ) {
			global $post;
			$orderId = ( $post instanceof \WP_Post ) ? $post->ID : $post_obj->get_id();
			$order   = wc_get_order( $orderId );
			$gclid   = $order->get_meta( "_cnvex_gclid" );
			$gbraid  = $order->get_meta( "_cnvex_gbraid" );
			$wbraid  = $order->get_meta( "_cnvex_wbraid" );

			if ( $gclid || $gbraid || $wbraid ) {
				echo __( 'Yes', 'conversion-exporter' );
			} else {
				echo __( 'No', 'conversion-exporter' );
			}
		}
	}

	/**
	 * Adds a meta box to the WooCommerce order edit screen to display conversion exporter fields.
	 * This function checks if High-Performance Order Storage is enabled and adds the meta box accordingly.
	 * @return void
	 */
	public function wooAddOrderMetaBoxes(): void {
		$screen = $this->isWooUseHPStorage() ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';

		add_meta_box( 'cnvex-woo-order-fields', __( 'Conversion Exporter', 'conversion-exporter' ), array(
			$this,
			"renderOrderFields"
		), $screen );
	}

	/**
	 * Renders the custom fields for the order in the meta box.
	 * This function retrieves the GCLID, modified status, last exported time, and conversion tasks
	 * associated with the order and displays them in a styled format.
	 * @param $post * The post or order object.
	 * @return void
	 */
	public function renderOrderFields( $post ): void {
		if ( $post instanceof \WP_Post ) {
			$orderId = $post->ID;
		} elseif ( method_exists( $post, 'get_id' ) ) {
			$orderId = $post->get_id();
		} else {
			$orderId = null;
		}

		if ( $orderId ) {
			$order            = wc_get_order( $orderId );
			$gclid            = $order->get_meta( "_cnvex_gclid" );
			$gbraid           = $order->get_meta( "_cnvex_gbraid" );
			$wbraid           = $order->get_meta( "_cnvex_wbraid" );
			$modified         = $order->get_meta( "_cnvex_total_changed" ) == 1;
			$exported_at      = $order->get_meta( "_cnvex_exported_at" );
			$conversion_tasks = $order->get_meta( "_cnvex_conversion_tasks" );
			?>
            <style>
                .cnvex-order-fields {
                    margin: 20px 10px 0;
                }

                .cnvex-order-fields-title {
                    font-weight: 700;
                }

                .cnvex-order-task-list {
                    margin-left: 20px;
                }
            </style>

            <div class="cnvex-order-fields">
                <p>
                    <span class="cnvex-order-fields-title"><?php echo esc_html__( 'GCLID', 'conversion-exporter' )
                                                                      . ': '; ?></span>
					<?php echo $gclid ? esc_html__( 'yes', 'conversion-exporter' ) : esc_html__(
						'no',
						'conversion-exporter'
					); ?>
                </p>

                <p>
                    <span class="cnvex-order-fields-title"><?php echo esc_html__( 'GBRAID', 'conversion-exporter' )
                                                                      . ': '; ?></span>
					<?php echo $gbraid ? esc_html__( 'yes', 'conversion-exporter' ) : esc_html__(
						'no',
						'conversion-exporter'
					); ?>
                </p>

                <p>
                    <span class="cnvex-order-fields-title"><?php echo esc_html__( 'WBRAID', 'conversion-exporter' )
                                                                      . ': '; ?></span>
					<?php echo $wbraid ? esc_html__( 'yes', 'conversion-exporter' ) : esc_html__(
						'no',
						'conversion-exporter'
					); ?>
                </p>

                <p>
                    <span class="cnvex-order-fields-title"><?php echo esc_html__(
	                                                                      'The Total was modified',
	                                                                      'conversion-exporter'
                                                                      ) . ': '; ?></span>
					<?php echo $modified ? esc_html__( 'yes', 'conversion-exporter' ) : esc_html__(
						'no',
						'conversion-exporter'
					); ?>
                </p>

				<?php if ( $exported_at ) : ?>
                    <p>
                        <span class="cnvex-order-fields-title"><?php echo esc_html__(
	                                                                          'Last exported at',
	                                                                          'conversion-exporter'
                                                                          ) . ': '; ?></span>
						<?php echo esc_html( $exported_at ); ?>
                    </p>
				<?php else : ?>
                    <p>
                        <span class="cnvex-order-fields-title"><?php echo esc_html__(
	                                                                          'Last exported at',
	                                                                          'conversion-exporter'
                                                                          ) . ': '; ?></span>
						<?php echo esc_html__( 'Never', 'conversion-exporter' ); ?>
                    </p>
				<?php endif; ?>
				<?php if ( empty( !$conversion_tasks ) ) : ?>
                    <p class="cnvex-order-fields-title"><?php echo esc_html__(
						                                               'Used in conversion tasks',
						                                               'conversion-exporter'
					                                               ) . ': '; ?></p>
                    <ul class="cnvex-order-task-list">
						<?php foreach ( $conversion_tasks as $conversion_task ) {
							$title = get_post_meta( $conversion_task, '_cnvex_conversion_name', true );
							$url   = esc_url(
								get_admin_url( null, 'admin.php?page=conversion-exporter' ) . '&conversion_task_id='
								. $conversion_task
							);
							?>
                            <li>
                                <a href="<?php echo esc_url( $url ); ?>"
                                   target="_blank"><?php echo esc_html( $title ); ?></a>
                            </li>
						<?php } ?>
                    </ul>
				<?php else : ?>
                    <p>
                        <span class="cnvex-order-fields-title"><?php echo esc_html__(
	                                                                          'Used in conversion tasks',
	                                                                          'conversion-exporter'
                                                                          ) . ': '; ?></span>
						<?php echo esc_html__(
							'This order is not used by any conversion task.',
							'conversion-exporter'
						); ?>
                    </p>
				<?php endif; ?>
            </div>
			<?php
		}
	}

	/**
	 * Save the GCLID to the order meta after the order is saved.
	 * This function is a callback for the `woocommerce_new_order` action.
	 * @param int $order_id The ID of the order that was created.
	 * @return void
	 */
	public function saveGclidToOrderMeta( int $order_id ): void {

		// Get the order object
		$order = wc_get_order( $order_id );

		// If the order object is valid
		if ( $order && is_a( $order, 'WC_Order' ) ) {

			$ids = array(
				'cnvex_gbraid' => 'ce_gbid',
				'cnvex_wbraid' => 'ce_wbid',
			);

			if ( isset( $_COOKIE[ '_gcl_aw' ] ) ) {
				$parts = explode( '.', sanitize_text_field( $_COOKIE[ '_gcl_aw' ] ) );
				if ( count( $parts ) === 3 ) {
					$gclid = $parts[ 2 ];
				}
				$order->update_meta_data( '_cnvex_gclid', $gclid );
			} else {
				$ids[ 'cnvex_gclid' ] = 'ce_gid';
			}

			foreach ( $ids as $key => $id ) {
				if ( isset( $_COOKIE[ $id ] ) ) {
					$order->update_meta_data( '_' . $key, sanitize_text_field( $_COOKIE[ $id ] ) );
				}
			}

			if ( WC()->session && WC()->session->get_session_data() !== null ) {
				$session_attributes = WC()->session->get( 'cnvex_session_attributes' );

                if ( !empty( $session_attributes ) ) {
					$order->update_meta_data( '_cnvex_session_attributes', $session_attributes );
				}
			}

			// Save meta data to order
			$order->save_meta_data();
		}
	}

	public function saveSessionAttributesToOrderMeta(): void {

		if ( !function_exists( 'WC' ) || !WC() || !WC()->session ) {
			return;
		}
		$params = array();

		foreach ( $_GET as $key => $value ) {
			if ( strpos( $key, 'gad_' ) === 0 ) {
				$params[ $key ] = sanitize_text_field( $value );
			}
		}

		if ( !isset( $params[ 'session_start_time_usec' ] ) ) {
			$params[ 'session_start_time_usec' ] = (string) ( microtime( true ) * 1000000 );
		}

		$params[ 'landing_page_url' ]        = ( isset( $_SERVER[ 'HTTPS' ] ) ? "https" : "http" )
		                                       . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$params[ 'landing_page_referrer' ]   = isset( $_SERVER[ 'HTTP_REFERER' ] ) ? esc_url_raw(
			$_SERVER[ 'HTTP_REFERER' ]
		) : '';
		$params[ 'landing_page_user_agent' ] = isset( $_SERVER[ 'HTTP_USER_AGENT' ] ) ? sanitize_text_field(
			$_SERVER[ 'HTTP_USER_AGENT' ]
		) : '';

		$json   = json_encode( $params, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		$base64 = rtrim( strtr( base64_encode( $json ), '+/', '-_' ), '=' );

		WC()->session->set( 'cnvex_session_attributes', $base64 );
	}

	/**
	 * Update order data when the order is updated.
	 * This function checks if the order total has changed and updates the metadata accordingly.
	 * @param \WC_Order $order The order object being saved.
	 * @return void
	 */
	public function updateOrderData( $order ): void {

		// Ensure we are working with a WC_Order object; this hook passes the object directly.
		if ( !$order || !( $order instanceof \WC_Order ) ) {
			return;
		}

		// Normalize totals to avoid false positives due to floating precision
		$decimals      = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		$current_total = (float) $order->get_total();
		$current_norm  = round( $current_total, $decimals );

		// Read previous total raw to distinguish between "not set" and "0"
		$old_total_raw = $order->get_meta( '_cnvex_old_order_total', true );
		$has_old_total = $old_total_raw !== '' && $old_total_raw !== null;
		$old_total     = $has_old_total ? (float) $old_total_raw : 0.0;
		$old_norm      = round( $old_total, $decimals );

		// Initialize meta if missing; do not call save() here to avoid recursion
		if ( !$has_old_total ) {
			$order->update_meta_data( '_cnvex_old_order_total', $current_norm );
			$order->update_meta_data( '_cnvex_total_changed', 0 );

			return;
		}

		// Mark flag based on comparison; persistence handled by the surrounding save() process
		if ( $current_norm !== $old_norm ) {
			$order->update_meta_data( '_cnvex_total_changed', 1 );
			$order->update_meta_data( '_cnvex_old_order_total', $current_norm );
		} else {
			$order->update_meta_data( '_cnvex_total_changed', 0 );
		}
	}

	/**
	 * Check is Woo Supporting High-Performance Order Storage
	 * @return bool
	 */
	public function isWooUseHPStorage(): bool {
		if ( class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class ) ) {
			return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		}

		return false;
	}

	/**
	 * Get all order statuses except for 'wc-draft', 'wc-trash', 'wc-auto-draft', and 'wc-failed'.
	 * @return array An array of order statuses.
	 */
	public function getOrderStatuses(): array {

		$all_statuses     = array_keys( wc_get_order_statuses() );
		$removed_statuses = array( 'wc-draft', 'wc-trash', 'wc-auto-draft', 'wc-failed' );
		$statuses         = array_diff( $all_statuses, $removed_statuses );

		return $statuses;
	}

}

/**
 * Returns the singleton instance of OrderManager.
 * This function is a convenience wrapper for OrderManager::get_instance().
 * @return OrderManager|null The instance of OrderManager or null if not initialized.
 */
function OrderManager(): ?OrderManager {
	return OrderManager::get_instance();
}

OrderManager();