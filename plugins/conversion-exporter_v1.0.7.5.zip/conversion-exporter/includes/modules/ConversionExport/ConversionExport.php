<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ConversionExport
 * Handles the conversion export functionality for the Conversion Exporter plugin.
 * This class manages the creation, downloading, and scheduling of conversion exports.
 */
class ConversionExport extends Settings implements Plugin {

	protected static ?ConversionExport $instance = null;

	private static array $conversionMetaFields = array(
		'_cnvex_enable',
		'_cnvex_conversion_name',
		'_cnvex_conversion_task_name',
		'_cnvex_conversion_url',
		'_cnvex_consent_enable',
		'_cnvex_conversion_type',
		'_cnvex_conversion_format',
		'_cnvex_source',
		'_cnvex_order_statuses',
		'_cnvex_woo_include_data',
		'_cnvex_woo_include_value',
		'_cnvex_orders_not_track_by_tag',
		'_cnvex_form_ids',
		'_cnvex_form_value',
		'_cnvex_form_currency',
		'_cnvex_items_only_with_gclid',
		'_cnvex_date_from',
		'_cnvex_delivery_method',
		'_cnvex_username',
		'_cnvex_password',
		'_cnvex_last_export',
		'_cnvex_last_full_export',
		'_cnvex_last_error',
		'_cnvex_use_schedule',
		'_cnvex_file_slug',
		'_cnvex_file_slug_full'
	);

	private string $file_table_name;

	private array $state = array();

	/**
	 * Retrieves the instance of the ConversionExport class.
	 * If the instance doesn't exist, it creates a new one. Otherwise, it returns the existing instance.
	 * @return ConversionExport|null
	 */
	public static function get_instance(): ?ConversionExport {
		if ( self::$instance === null ) {
			// Create a new instance if it doesn't exist
			self::$instance = new self();
		}

		// Return the existing instance
		return self::$instance;
	}

	/**
	 * Constructor for the ConversionExport class.
	 * Initializes the ConversionExport module by setting up hooks, scheduling events,
	 * and locating options. It also sets the file table name and adds necessary actions
	 * for handling AJAX requests, cron jobs, and downloading files.
	 */
	public function __construct() {
		parent::__construct( 'conversion-export' );

		// Get the class name for locating options
		$className = basename( str_replace( '\\', '/', get_class( $this ) ) );

		// Locate options files
		$this->locateOptions(
			CNVEX_PLUGIN_PATH . 'includes/modules/' . $className . '/options_fields.json',
			CNVEX_PLUGIN_PATH . 'includes/modules/' . $className . '/options_defaults.json'
		);

		// Set the table name for storing file data
		$this->file_table_name = 'cnvex_create_file_data';

		// Register AJAX actions
		add_action( 'wp_ajax_cnvex_conversion_task_update', array(
			$this,
			'conversionTaskUpdate'
		) );
		add_action( 'wp_ajax_cnvex_export_conversion', array(
			$this,
			'downloadExport'
		) );
		add_action( 'wp_ajax_cnvex_download_conversion_file', array(
			$this,
			'downloadConversionFile'
		) );
		add_action( 'wp_ajax_cnvex_regenerate_export', array(
			$this,
			'regenerateExport'
		) );

		// check file generation status
		add_action( 'wp_ajax_cnvex_check_generation_status', array(
			$this,
			'checkGenerationStatus'
		) );

		// Schedule cron events if not already scheduled
		add_action( 'init', array(
			$this,
			'scheduleCronEvents'
		) );

		// Register cron actions for export schedules
		add_action( 'cnvex_export_schedule', array(
			$this,
			'createNewConversionExport'
		) );
		add_action( 'cnvex_export_schedule_single', array(
			$this,
			'createNewConversionExport'
		) );
		add_action( 'cnvex_export_full_schedule', array(
			$this,
			'createNewConversionExport'
		) );
		add_action( 'cnvex_export_full_schedule_single', array(
			$this,
			'createNewConversionExport'
		) );
		add_action( 'cnvex_export_part_schedule_single', array(
			$this,
			'createNewPartConversionExport'
		) );
		add_action( 'cnvex_export_part_full_schedule_single', array(
			$this,
			'createNewPartConversionExport'
		), 10, 2 );
		add_action( 'cnvex_export_checker', array(
			$this,
			'exportChecker'
		) );

		add_action( 'init', array(
			$this,
			'registerRewriteRules'
		) );

		add_filter( 'query_vars', function( $vars ) {
			$vars[] = 'cnvex_export_id';
			$vars[] = 'cnvex_file';

			return $vars;
		} );

		// Register action for downloading files with parameters via GET request
		add_action( 'template_redirect', array(
			$this,
			'downloadConversionFileWithGet'
		) );
	}

	/**
	 * Schedule cron events for export tasks.
	 * This function schedules cron events for export tasks based on the specified frequency.
	 * It checks if the events are already scheduled and schedules them if necessary.
	 * @return void
	 */
	public function scheduleCronEvents(): void {
		$method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';
		$val    = ConversionExporter()->getOption( 'how_often_create_csv' ) ?: 'daily';

		// Always ensure checker is scheduled (independent helper cron)
		if ( !wp_next_scheduled( 'cnvex_export_checker' ) ) {
			wp_schedule_event( time(), 'hourly', 'cnvex_export_checker' );
		}

		if ( $method === 'wp-cron' ) {
			// Schedule periodic export jobs only for WP-Cron method
			if ( !wp_next_scheduled( 'cnvex_export_schedule' ) ) {
				wp_schedule_event( time(), $val, 'cnvex_export_schedule' );
			}
			$args = array( true );
			if ( !wp_next_scheduled( 'cnvex_export_full_schedule', $args ) ) {
				wp_schedule_event( time(), $val, 'cnvex_export_full_schedule', $args );
			}
		} else {
			// Clear periodic export cron if method is not WP-Cron
			if ( wp_next_scheduled( 'cnvex_export_schedule' ) ) {
				wp_clear_scheduled_hook( 'cnvex_export_schedule' );
			}
			$args = array( true );
			if ( wp_next_scheduled( 'cnvex_export_full_schedule', $args ) ) {
				wp_clear_scheduled_hook( 'cnvex_export_full_schedule', $args );
			}
		}
	}


	/**
	 * Returns the current version number of the Conversion Exporter plugin.
	 * @return string The current version number of the Conversion Exporter plugin.
	 */
	public function getPluginVersion(): string {
		return CNVEX_LATEST_VERSION_NUMBER;
	}

	/**
	 * Retrieve the list of Conversion Meta Fields.
	 * @return array The Conversion Meta Fields
	 */
	public static function getConversionMetaFields(): array {
		return self::$conversionMetaFields;
	}


	/**
	 * Handles the AJAX request for updating the status of a conversion task.
	 * Check nonce, manage permissions, retrieve the task ID and active status from the $_POST data,
	 * update the task meta, and send the response.
	 * @return void
	 */
	public function conversionTaskUpdate(): void {
		// Check nonce:
		check_admin_referer( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );

		// Manage permissions:
		$this->managePermissions();

		// Retrieve the task ID from the $_POST data:
		$id = isset( $_POST[ 'id' ] ) ? sanitize_text_field( $_POST[ 'id' ] ) : null;

		// Retrieve the active status from the $_POST data:
		$active = isset( $_POST[ 'active' ] ) ? sanitize_text_field( $_POST[ 'active' ] ) : null;

		// Update the task meta:
		update_post_meta( $id, '_cnvex_enable', $active );

		// Send the response:
		wp_send_json_success();

		// Die:
		wp_die();
	}

	/**
	 * Download the export file.
	 * This function checks the nonce and user permissions, retrieves the export ID from the POST request,
	 * and attempts to download the corresponding export file if it exists.
	 * @return void
	 */
	public function downloadExport(): void {
		// Check nonce for security
		check_admin_referer( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );

		// Check user permissions
		$this->managePermissions();

		// Get export ID from the POST request
		$export_id = isset( $_POST[ 'export_id' ] ) ? sanitize_text_field( $_POST[ 'export_id' ] ) : null;

		if ( !empty( $export_id ) ) {
			// Retrieve the main file associated with the export ID
			$full = isset( $_POST[ 'full' ] ) ? sanitize_text_field( $_POST[ 'full' ] ) : null;
			if ( !empty( $full ) ) {
				$file = FileManager()->getFullFile( $export_id );
			} else {
				$file = FileManager()->getMainFile( $export_id );
			}

			if ( !empty( $file ) ) {
				// Get the file path using export ID and file UUID
				$file_path = FileManager()->getFilePath( $export_id, $file[ 'uuid' ] );

				if ( file_exists( $file_path ) ) {
					// Set headers for file download
					header( 'Content-Type: text/csv; charset=utf-8' );
					header( 'Content-Disposition: attachment; filename=' . basename( $file[ 'real_name' ] ) );
					header( 'Content-Length: ' . filesize( $file_path ) );

					// Output the file content
					readfile( $file_path );
				} else {
					// Send error response if file does not exist
					wp_send_json_error( __( 'File not found', 'conversion-exporter' ) );
				}
			} else {
				wp_send_json_error( __( 'No conversion files found', 'conversion-exporter' ) );
			}

			wp_die();
		}

		wp_send_json_error( __( 'Something went wrong', 'conversion-exporter' ) );
		wp_die();
	}

	/**
	 * Creates a new conversion export.
	 * This function will create a new conversion export. It retrieves the last iteration
	 * of the export from the database and, if necessary, initializes a new export state.
	 * Depending on the $full parameter, it will either handle a full or main export.
	 * It processes posts of type CNVEX_CONVERSION_POST_TYPE that are published and enabled.
	 * @param bool $full Whether to create a full export (true) or a main export (false). Defaults to false.
	 * @return void
	 */
	public function createNewConversionExport( bool $full = false ): void {

		// Retrieve the last iteration based on the type of export
		if ( $full ) {
			$this->getLastIteration( 'full' );
		} else {
			$this->getLastIteration();
		}

		// Initialize a new export state if it doesn't exist
		if ( empty( $this->state ) ) {
			$args_posts = array(
				'post_type'      => CNVEX_CONVERSION_POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'order'          => 'ASC',
				'orderby'        => 'DATE',
				'meta_query'     => array(
					array(
						'key'   => '_cnvex_enable',
						'value' => 1,
					)
				),
				'meta_type'      => 'NUMERIC',
			);

			// Query the posts
			$loop_posts = new \WP_Query( $args_posts );

			// If no posts are found, save the current state and exit
			if ( !$loop_posts->have_posts() ) {
				$this->saveLastIteration();

				return;
			}

			// Extract post IDs for export and initialize the state
			$exports_ids = wp_list_pluck( $loop_posts->posts, 'ID' );
			$this->state = array(
				'export_ids' => $exports_ids,
				'orders'     => array(),
				'type'       => $full ? 'full' : 'main',
				'created_at' => current_time( 'mysql' ),
				'save'       => true,
			);
		}

		// Process the export based on the state
		if ( !empty( $this->state[ 'export_ids' ] ) ) {
			$export_id = $this->state[ 'export_ids' ][ 0 ];
			if ( !$this->checkExportStatus( $export_id ) ) {
				array_shift( $this->state[ 'export_ids' ] );
			} else {
				if ( $full ) {
					$this->createExportFullFile();
				} else {
					$this->createExport();
				}
			}
		}

		// Save the current state of the export
		$this->saveLastIteration();
	}

	/**
	 * Creates a new part of a conversion export.
	 * This function will create a new part of a conversion export. It will
	 * retrieve the last iteration of the export from the database and add the
	 * given export ID to the export_ids array. If there is no previous
	 * iteration, it will create a new array and add the export ID to it. Then
	 * it will create a new export file and save the last iteration to the
	 * database.
	 * @param int  $export_id The ID of the export to be added to the export.
	 * @param bool $full      Whether to create a full export (true) or a main export (false). Defaults to false.
	 */
	public function createNewPartConversionExport( int $export_id, bool $full = false ): void {

		$full_disabled = apply_filters( 'cnvex_disable_full_file_generation', false, $export_id );
		if ( $full && $full_disabled ) {
			return;
		}

		if ( $full ) {
			$this->getLastPartIteration( $export_id, 'full_part' );
		} else {
			$this->getLastPartIteration( $export_id );
		}

		if ( empty( $this->state ) ) {
			$this->state = array(
				'export_ids' => array( $export_id ),
				'orders'     => array(),
				'type'       => $full ? 'full_part' : 'main_part',
				'created_at' => current_time( 'mysql' ),
				'save'       => true,
			);
		}

		if ( !$this->checkExportStatus( $export_id ) ) {
			array_shift( $this->state[ 'export_ids' ] );
		} else {
			if ( $full ) {
				$this->createExportFullFile();
			} else {
				$this->createExport();
			}
		}

		$this->saveLastIteration();
	}

	/**
	 * Get the last iteration of the export from the database.
	 * This function will retrieve the last iteration of the export from the
	 * database. It will return an array with the last iteration of the export
	 * or an empty array if there is no previous iteration.
	 * @param string $type The type of the export. Defaults to 'main'.
	 */
	private function getLastIteration( string $type = 'main' ): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		// Retrieve the last iteration of the export from the database.
		$files = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table 
         		   WHERE type=%s
				   ORDER BY created_at ASC",
				$type
			),
			ARRAY_A
		);

		if ( empty( $files ) ) {
			// If there is no previous iteration, return an empty array.
			return;
		}

		// Decode the orders and export ids from json to an array.
		$files[ 'orders' ]     = json_decode( $files[ 'orders' ] );
		$files[ 'export_ids' ] = json_decode( $files[ 'export_ids' ] );
		$files[ 'save' ]       = true;

		// Set the state of the export to the last iteration.
		$this->state = $files;
	}

	/**
	 * Get the last iteration of the part export from the database.
	 * This function will retrieve the last iteration of the export from the
	 * database. It will return an array with the last iteration of the export
	 * or an empty array if there is no previous iteration.
	 * @param int    $export_id The ID of the export to retrieve.
	 * @param string $type      The type of the export. Defaults to 'main'.
	 */
	private function getLastPartIteration( int $export_id, string $type = 'main_part' ): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		// Retrieve the last iteration of the export from the database.
		$files = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table 
         		   WHERE JSON_CONTAINS(export_ids, %s)
         		     AND type=%s
				   ORDER BY created_at ASC",
				$export_id,
				$type
			),
			ARRAY_A
		);

		if ( empty( $files ) ) {
			// If there is no previous iteration, return an empty array.
			return;
		}

		// Decode the orders and export ids from json to an array.
		$files[ 'orders' ]     = json_decode( $files[ 'orders' ] );
		$files[ 'export_ids' ] = json_decode( $files[ 'export_ids' ] );
		$files[ 'save' ]       = true;

		// Set the state of the export to the last iteration.
		$this->state = $files;
	}

	/**
	 * Save the current state of the export to the database.
	 * This function is used to save the current state of the export to the
	 * database. It will update the file in the database with the current
	 * state of the export.
	 * @return void
	 */
	private function saveLastIteration(): void {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;
		if ( empty( $this->state ) ) {
			return;
		}

		$method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';

		// If the export is complete, remove the record from the database.
		if ( $this->state[ 'save' ] && empty( $this->state[ 'export_ids' ] ) && empty( $this->state[ 'orders' ] ) ) {
			if ( !empty( $this->state[ 'id' ] ) ) {
				$wpdb->delete( $table, array(
					'id' => $this->state[ 'id' ]
				) );

				if ( $method !== 'wp-cron' ) {
					if ( $this->state[ 'type' ] == 'full' || $this->state[ 'type' ] == 'main' ) {
						$transient = 'cnvex_last_export_schedule';
						if ( $this->state[ 'type' ] == 'full' ) {
							$transient = 'cnvex_last_full_export_schedule';
						}

						$how_often_create_csv = ConversionExporter()->getOption( 'how_often_create_csv' ) ?: 'once_day';
						$intervals            = ConversionExporter()->addCronIntervals( array() );
						$interval             = $intervals[ $how_often_create_csv ];
						set_transient( $transient, time(), $interval[ 'interval' ] );
					}
				}
			}
		} else {
			$data = array(
				'export_ids' => json_encode( $this->state[ 'export_ids' ] ),
				'orders'     => json_encode( $this->state[ 'orders' ] ),
				'type'       => $this->state[ 'type' ]
			);

			// Update the file in the database.
			if ( isset( $this->state[ 'id' ] ) ) {
				$wpdb->update( $table, $data, array(
					'id' => $this->state[ 'id' ]
				) );
			} else {
				$wpdb->insert( $table, $data );
			}

			// Schedule the next export.
			if ( $this->state[ 'type' ] == 'full' ) {
				$hook = 'cnvex_export_full_schedule_single';
				$args = array(
					true
				);
			} elseif ( $this->state[ 'type' ] == 'main' ) {
				$hook = 'cnvex_export_schedule_single';
				$args = array();
			} elseif ( $this->state[ 'type' ] == 'main_part' ) {
				$hook = 'cnvex_export_part_schedule_single';
				$args = array( (int) $this->state[ 'export_ids' ][ 0 ] );
			} elseif ( $this->state[ 'type' ] == 'full_part' ) {
				$hook = 'cnvex_export_part_full_schedule_single';
				$args = array(
					(int) $this->state[ 'export_ids' ][ 0 ],
					true
				);
			} else {
				return;
			}

			if ( $method === 'wp-cron' ) {
				if ( !wp_next_scheduled( $hook, $args ) ) {
					wp_schedule_single_event( time() + 10, $hook, $args );
				}
			} else {
				if ( $this->state[ 'type' ] == 'main_part' || $this->state[ 'type' ] == 'full_part' ) {
					$full       = $this->state[ 'type' ] == 'full_part' ? 1 : 0;
					$url_params = array(
						'time'       => time(),
						'part'       => 1,
						'export_id'  => $this->state[ 'export_ids' ][ 0 ] ?? null,
						'full'       => $full,
						'request_id' => 'cnvex_' . ( $full ? 'full_' : '' ) . time() . '_' . rand( 1000, 9999 ),
					);
				} else {
					$full       = $this->state[ 'type' ] == 'full' ? 1 : 0;
					$url_params = array(
						'time'       => time(),
						'full'       => $full,
						'request_id' => 'cnvex_' . ( $full ? 'full_' : '' ) . time() . '_' . rand( 1000, 9999 ),
					);
				}

				$args_req = array(
					'timeout'   => 0.01,
					'blocking'  => false,
					'sslverify' => true
				);

				if ( defined( 'CNVEX_SCHEDULER_REQUEST_USERNAME' ) && defined( 'CNVEX_SCHEDULER_REQUEST_PASSWORD' ) ) {
					$args_req[ 'headers' ] = array(
						'Authorization' => 'Basic ' . base64_encode(
								CNVEX_SCHEDULER_REQUEST_USERNAME . ':' . CNVEX_SCHEDULER_REQUEST_PASSWORD
							)
					);
				} else {
					// Use internal token for authentication when Basic Auth constants are not defined
					$url_params[ 'cnvex_token' ] = HelperFunctions::getInternalApiToken();
				}

				$url = add_query_arg( $url_params, site_url( 'wp-json/cnvex/v1/exports_update' ) );
				wp_remote_get( $url, $args_req );
			}
		}
	}

	/**
	 * Maybe save the last iteration to the database.
	 * This function checks the given state and determines if it needs to be saved
	 * to the database. It updates the state with an ID if a new database entry is created.
	 * @param array $state The state array to potentially save.
	 * @param bool  $force Optional. Whether to force the save. Defaults to false.
	 * @return array The updated state array.
	 */
	public function maybeSaveLastIteration( array $state, bool $force = false ): array {
		// If the state is empty, there is nothing to save.
		if ( empty( $state ) ) {
			return $state;
		}

		if ( !$force ) {
			// Return if there are no export IDs and orders in the current state
			if ( empty( $this->state[ 'export_ids' ] ) && empty( $this->state[ 'orders' ] ) ) {
				return $state;
			}

			// Return if the state already has an ID
			if ( !empty( $this->state[ 'id' ] ) ) {
				return $state;
			}
		}

		global $wpdb;

		// Get the table name.
		$table  = $wpdb->prefix . $this->file_table_name;
		$result = '';

		if ( !empty( $state[ 'id' ] ) ) {
			// Fetch the latest entry for the given type from the database.
			$result = $wpdb->get_row(
				$wpdb->prepare(
					"
				SELECT * 
				FROM $table 
				WHERE id=%s",
					$state[ 'id' ]
				),
				ARRAY_A
			);
		}

		// If no entry exists, insert a new record into the database.
		if ( empty( $result ) ) {
			$data = array(
				'export_ids' => json_encode( $state[ 'export_ids' ] ),
				'orders'     => json_encode( $state[ 'orders' ] ),
				'type'       => $state[ 'type' ]
			);

			// Insert the new record into the database.
			$wpdb->insert( $table, $data );

			// If the insert was successful, assign the new ID to the state.
			if ( $wpdb->insert_id !== false ) {
				$state[ 'id' ] = $wpdb->insert_id;
			}
		}

		return $state;
	}

	/**
	 * Create a new export
	 * This function is used to create a new export. It will create a new
	 * export file and generate a CSV file for each export.
	 * @return void
	 */
	public function createExport(): void {
		$export_id = $this->state[ 'export_ids' ][ 0 ];
		$type      = get_post_meta( $export_id, '_cnvex_source', true );
		if ( $type == 'woo' && !HelperFunctions::isWoocommerceActive() ) {
			update_post_meta(
				$export_id,
				'_cnvex_last_error',
				__( 'WooCommerce is not active', 'conversion-exporter' )
			);
			array_shift( $this->state[ 'export_ids' ] );

			return;
		}

		$date_range  = array();
		$last_export = get_post_meta( $export_id, '_cnvex_last_export', true );
		if ( !empty( $last_export ) ) {
			$date = new \DateTime();
			$date->setTimestamp( $last_export );
			$date_range[ 'after' ] = $date->format( 'Y-m-d H:i:s' );
		} else {
			// Get the date from
			$from = get_post_meta( $export_id, '_cnvex_date_from', true );
			if ( !empty( $from ) ) {
				$date_from = new \DateTime( $from );
				$date_from->setTime( 0, 0, 0 );
				$date_range = array(
					'after' => $date_from->format( 'Y-m-d H:i:s' ),
				);
			}
		}
		$date_range[ 'before' ] = current_time( 'mysql' );

		// Check if file download by schedule
		$main_file_live = FileManager()->getMainFile( $export_id );

		if ( $main_file_live ) {
			$file_path = FileManager()->getFilePath( $export_id, $main_file_live[ 'uuid' ] );
			if ( file_exists( $file_path ) ) {
				$schedule = get_post_meta( $export_id, '_cnvex_use_schedule', true );
				if ( $schedule && !$main_file_live[ 'ads_downloaded' ] ) {
					array_shift( $this->state[ 'export_ids' ] );

					return;
				}
			} else {
				FileManager()->deleteTableRecord( $main_file_live[ 'uuid' ] );
			}
		}

		// Get the main file
		$main_file = FileManager()->getMainFile( $export_id, 0 );
		$new       = false;
		if ( !$main_file ) {
			// Create a new file
			$file_slug = get_post_meta( $export_id, '_cnvex_file_slug', true );
			$file      = FileManager()->createFileEntry( $export_id, $file_slug );
			$new       = true;
		} else {
			// Get the file path
			$file = FileManager()->getFilePath( $export_id, $main_file[ 'uuid' ] );
		}

		// Generate CSV file
		$this->state = CsvGenerator()->generateCSV( $this->state, $file, $date_range, $new );
	}

	/**
	 * Generate a full export CSV file
	 * This function is used to generate a full export CSV file.
	 * The function checks if the user has access to the file and if the file exists.
	 * If the file exists, it generates the full export CSV file and exits.
	 * If not, it displays an error message.
	 * @return void
	 */
	public function createExportFullFile(): void {
		$export_id = $this->state[ 'export_ids' ][ 0 ];
		$disabled  = apply_filters( 'cnvex_disable_full_file_generation', false, $export_id );
		if ( $disabled ) {
			array_shift( $this->state[ 'export_ids' ] );

			return;
		}

		$type = get_post_meta( $export_id, '_cnvex_source', true );
		if ( $type == 'woo' && !HelperFunctions::isWoocommerceActive() ) {
			update_post_meta(
				$export_id,
				'_cnvex_last_error',
				__( 'WooCommerce is not active', 'conversion-exporter' )
			);
			array_shift( $this->state[ 'export_ids' ] );

			return;
		}

		// Define the date range
		$date_range = array();
		$from       = get_post_meta( $export_id, '_cnvex_date_from', true );
		if ( !empty( $from ) ) {
			// Set the date range
			$date_from = new \DateTime( $from );
			$date_from->setTime( 0, 0, 0 );
			$date_range[ 'after' ] = $date_from->format( 'Y-m-d H:i:s' );
		}

		// Set the date range
		$date_range[ 'before' ] = current_time( 'mysql' );

		// Get the full file
		$full_file = FileManager()->getFullFile( $export_id, 0 );
		// If the file does not exist, create a new one
		$new = false;
		if ( !$full_file ) {
			$file_slug = get_post_meta( $export_id, '_cnvex_file_slug_full', true );
			$file      = FileManager()->createFileEntry( $export_id, $file_slug, true );
			$new       = true;
		} else {
			// Get the file path
			$file = FileManager()->getFilePath( $export_id, $full_file[ 'uuid' ] );
		}

		// Generate the full export CSV file
		$this->state = CsvGenerator()->generateCSV( $this->state, $file, $date_range, $new );
	}

	/**
	 * Check if the user has access to the Conversion Exporter settings.
	 * This function checks if the user has the cnvex_manage capability.
	 * If the user does not have the capability, it dies with a message.
	 * @return void
	 */
	public function managePermissions(): void {
		// Lock out non-admins:
		if ( !current_user_can( 'cnvex_manage' ) ) {
			wp_die(
				esc_html__( 'You do not have sufficient permission to perform this operation', 'conversion-exporter' )
			);
		}
	}

	/**
	 * Download conversion file
	 * This function is used to download the conversion file.
	 * The function checks if the user has access to the file and if the file exists.
	 * If the file exists, it downloads the file and exits.
	 * If not, it displays an error message.
	 * @return void
	 */
	public function downloadConversionFile(): void {
		// Check nonce:
		check_admin_referer( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );
		$this->managePermissions();

		$filename  = sanitize_text_field( $_POST[ 'filename' ] );
		$export_id = sanitize_text_field( $_POST[ 'export_id' ] );

		// Get the UUID of the file
		$uuid = FileManager()->getFileUuid( $export_id, $filename );

		// Get the path to the file
		$file_path = FileManager()->getFilePath( $export_id, $uuid );

		// Check if the file exists
		if ( file_exists( $file_path ) ) {
			// Download the file
			header( 'Content-Type: text/csv; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename=' . basename( $filename ) );
			header( 'Content-Length: ' . filesize( $file_path ) );
			readfile( $file_path );
			exit;
		} else {
			// Display an error message if the file does not exist
			wp_send_json_error( __( 'File not found', 'conversion-exporter' ) );
		}

		wp_die();
	}

	/**
	 * Download conversion file via GET
	 * This function is used to download a conversion file via GET.
	 * The function checks if the user has access to the file and if the file exists.
	 * If the file exists, it downloads the file and exits.
	 * If not, it displays an error message.
	 * @return void
	 */
	public function downloadConversionFileWithGet(): void {

		$export_id = get_query_var( 'cnvex_export_id' );
		$slug      = get_query_var( 'cnvex_file' );

		if ( empty( $export_id ) || empty( $slug ) ) {
			return;
		}

		if ( !ctype_digit( (string) $export_id ) ) {
			status_header( 400 );
			exit;
		}
		$export_id = (int) $export_id;

		// Check if the request is coming from Google
		$userAgent = $_SERVER[ 'HTTP_USER_AGENT' ] ?? '';
		if ( stripos( $userAgent, 'google' ) === false ) {

			$ip = $_SERVER[ 'HTTP_CF_CONNECTING_IP' ] ??
			      $_SERVER[ 'HTTP_X_FORWARDED_FOR' ] ?? $_SERVER[ 'REMOTE_ADDR' ];

			if ( !$ip ) {
				exit;
			}
			$hostname = gethostbyaddr( $ip );
			if ( $hostname === false || stripos( $hostname, 'google' ) === false ) {
				http_response_code( 403 );
				esc_html_e( 'Access denied', 'conversion-exporter' );
				exit;
			}
		}

		// Get the export post
		$post = get_post( $export_id );

		if ( $post ) {
			// Check if the export is enabled
			$enable = get_post_meta( $post->ID, '_cnvex_enable', true );
			if ( $enable ) {
				$disable_protection = apply_filters( 'cnvex_disable_password_protection', false, $export_id );
				if ( !$disable_protection ) {
					// Get the username and password
					$user     = get_post_meta( $post->ID, '_cnvex_username', true );
					$password = get_post_meta( $post->ID, '_cnvex_password', true );

					// Check if the username and password are set
					if ( !empty( $user ) && !empty( $password ) ) {
						// Check if the username and password are correct
						if ( !isset( $_SERVER[ 'PHP_AUTH_USER' ] ) || !isset( $_SERVER[ 'PHP_AUTH_PW' ] )
						     || $_SERVER[ 'PHP_AUTH_USER' ] !== $user
						     || $_SERVER[ 'PHP_AUTH_PW' ] !== $password ) {
							header( 'WWW-Authenticate: Basic realm="CSV Access"' );
							header( 'HTTP/1.0 401 Unauthorized' );
							esc_html_e( 'Access denied', 'conversion-exporter' );
							exit;
						}
					}
				}

				// Get the file
				if ( substr( $slug, -9 ) === '-full.csv' ) {
					$file = FileManager()->getFullFile( $export_id );
				} else {
					$file = FileManager()->getMainFile( $export_id );
				}
				$file_path = FileManager()->getFilePath( $export_id, $file[ 'uuid' ] );

				// Check if the file exists
				if ( file_exists( $file_path ) ) {
					// Check if the export is scheduled
					$schedule = get_post_meta( $export_id, '_cnvex_use_schedule', true );
					if ( $schedule ) {
						FileManager()->markFileAsDownloaded( $export_id, $file[ 'uuid' ] );
					} else {
						FileManager()->setDownloadDate( $export_id, $file[ 'uuid' ] );
					}

					// Download the file
					header( 'Content-Type: text/csv' );
					header( "Content-Disposition: attachment; filename={$file[ 'real_name' ]}" );
					header( 'Content-Length: ' . filesize( $file_path ) );
					readfile( $file_path );
				}
			}
		}

		exit;
	}

	/**
	 * Export checker
	 * This function checks if there are any export tasks in the database and schedules them for processing.
	 * It retrieves tasks from the database and schedules them based on their type.
	 * @return bool
	 */
	public function exportChecker(): bool {
		global $wpdb;

		$table  = $wpdb->prefix . $this->file_table_name;
		$tasks  = $wpdb->get_results( "SELECT * FROM $table", ARRAY_A );
		$method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';

		if ( empty( $tasks ) ) {

			if ( $method === 'wp-cron' ) {
				return false;
			}

			$transients = array(
				'cnvex_last_export_schedule',
				'cnvex_last_full_export_schedule',
			);
			$need_run   = false;

			foreach ( $transients as $transient ) {
				$last_export = get_transient( $transient );

				if ( !$last_export ) {
					$this->state = array();
					$this->createNewConversionExport( $transient === 'cnvex_last_full_export_schedule' );
					$need_run = true;
				}
			}

			if ( $need_run ) {
				return true;
			}
		}

		foreach ( $tasks as $task ) {
			$hook = null;
			$args = array();
			$export_id = null;

			// Remove stale rows: nothing left to export
			$task_export_ids = json_decode( $task[ 'export_ids' ] ?? '', true );
			$task_orders     = json_decode( $task[ 'orders' ] ?? '', true );
			if ( empty( $task_export_ids ) && empty( $task_orders ) ) {
				$wpdb->delete( $table, array( 'id' => $task[ 'id' ] ) );
				continue;
			}

			switch ( $task[ 'type' ] ) {
				case 'main':
				{
					$hook = 'cnvex_export_schedule_single';
					$args = array();
					break;
				}
				case 'main_part':
				{
					$hook = 'cnvex_export_part_schedule_single';
					if ( !empty( $task[ 'export_ids' ] ) ) {
						$export_ids = json_decode( $task[ 'export_ids' ], true );
						if ( is_array( $export_ids ) && isset( $export_ids[ 0 ] ) ) {
							$export_id = (int) $export_ids[ 0 ];
						}
					}
					$args = array( $export_id );
					break;
				}
				case 'full':
				{
					$hook = 'cnvex_export_full_schedule_single';
					$args = array(
						true
					);
					break;
				}
				case 'full_part':
				{
					$hook = 'cnvex_export_part_full_schedule_single';
					if ( !empty( $task[ 'export_ids' ] ) ) {
						$export_ids = json_decode( $task[ 'export_ids' ], true );
						if ( is_array( $export_ids ) && isset( $export_ids[ 0 ] ) ) {
							$export_id = (int) $export_ids[ 0 ];
						}
					}
					$args = array(
						$export_id,
						true
					);
					break;
				}
				default:
				{
					break;
				}
			}

			if ( $method === 'wp-cron' ) {
				if ( !wp_next_scheduled( $hook, $args ) ) {
					wp_schedule_single_event( time() + 10, $hook, $args );
				}
			} else {
				if ( $task[ 'type' ] == 'main_part' || $task[ 'type' ] == 'full_part' ) {
					if ( !$export_id || !$this->checkExportStatus( $export_id ) ) {
						$wpdb->delete( $table, array( 'id' => $task[ 'id' ] ) );
						continue;
					}
					$full       = $task[ 'type' ] == 'full_part' ? 1 : 0;
					$url_params = array(
						'time'       => time(),
						'part'       => 1,
						'export_id'  => $export_id,
						'full'       => $full,
						'request_id' => 'cnvex_' . ( $full ? 'full_' : '' ) . time() . '_' . rand( 1000, 9999 ),
					);
				} else {
					$full       = $task[ 'type' ] == 'full' ? 1 : 0;
					$url_params = array(
						'time'       => time(),
						'full'       => $full,
						'request_id' => 'cnvex_' . ( $full ? 'full_' : '' ) . time() . '_' . rand( 1000, 9999 ),
					);
				}

				$args_req = array(
					'timeout'   => 0.01,
					'blocking'  => false,
					'sslverify' => true
				);

				if ( defined( 'CNVEX_SCHEDULER_REQUEST_USERNAME' ) && defined( 'CNVEX_SCHEDULER_REQUEST_PASSWORD' ) ) {
					$args_req[ 'headers' ] = array(
						'Authorization' => 'Basic ' . base64_encode(
								CNVEX_SCHEDULER_REQUEST_USERNAME . ':' . CNVEX_SCHEDULER_REQUEST_PASSWORD
							)
					);
				} else {
					// Use internal token for authentication when Basic Auth constants are not defined
					$url_params[ 'cnvex_token' ] = HelperFunctions::getInternalApiToken();
				}

				$url = add_query_arg( $url_params, site_url( 'wp-json/cnvex/v1/exports_update' ) );
				wp_remote_get( $url, $args_req );

				return true;
			}
		}

		return false;
	}

	/**
	 * Check the status of the generation task.
	 * This function checks if a generation task is in progress and returns its status.
	 * If the task is in progress, it schedules the next part of the export.
	 * If the task is completed, it returns the generated file and its list.
	 * @return void
	 */
	public function checkGenerationStatus(): void {
		// Check nonce for security
		check_admin_referer( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );

		// Check user permissions
		$this->managePermissions();

		// Get export ID from the POST request
		$id = isset( $_POST[ 'export_id' ] ) ? sanitize_text_field( $_POST[ 'export_id' ] ) : null;

		if ( $id ) {
			$id        = (int) $id;
			$main_file = isset( $_POST[ 'type' ] ) && $_POST[ 'type' ] == 'main';
			$generate  = FileManager()->currentGeneratingTask( $id, $main_file );

			if ( !$main_file ) {
				$disabled = apply_filters( 'cnvex_disable_full_file_generation', false, $id );
			} else {
				$disabled = false;
			}

			$method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';

			if ( !$disabled && $generate ) {
				// Check if the export is scheduled
				if ( $main_file ) {
					$args = array( $id );

					if ( $method === 'wp-cron' ) {
						if ( !wp_next_scheduled( 'cnvex_export_part_schedule_single', $args ) ) {
							wp_schedule_single_event( time() + 10, 'cnvex_export_part_schedule_single', $args );
						}
					} else {
						if ( !$this->checkProcessingExportID( $id, 'main_part' ) ) {
							$url_params = array(
								'time'       => time(),
								'part'       => 1,
								'export_id'  => $id,
								'full'       => 0,
								'request_id' => 'cnvex_' . time() . '_' . rand( 1000, 9999 ),
							);
							$args_req = array(
								'timeout'   => 0.01,
								'blocking'  => false,
								'sslverify' => true
							);
							if ( defined( 'CNVEX_SCHEDULER_REQUEST_USERNAME' )
							     && defined( 'CNVEX_SCHEDULER_REQUEST_PASSWORD' ) ) {
								$args_req[ 'headers' ] = array(
									'Authorization' => 'Basic ' . base64_encode(
											CNVEX_SCHEDULER_REQUEST_USERNAME . ':' . CNVEX_SCHEDULER_REQUEST_PASSWORD
										)
								);
							} else {
								// Use internal token for authentication
								$url_params[ 'cnvex_token' ] = HelperFunctions::getInternalApiToken();
							}

							$url = add_query_arg( $url_params, site_url( 'wp-json/cnvex/v1/exports_update' ) );
							wp_remote_get( $url, $args_req );
						}
					}
				} else {
					$method = ConversionExporter()->getOption( 'generation_method' );
					if ( $method === 'wp-cron' ) {
						$args = array(
							$id,
							true
						);

						if ( !wp_next_scheduled( 'cnvex_export_part_full_schedule_single', $args ) ) {
							wp_schedule_single_event( time() + 30, 'cnvex_export_part_full_schedule_single', $args );
						}
					} else {
						if ( !$this->checkProcessingExportID( $id, 'full_part' ) ) {
							$url_params = array(
								'time'       => time(),
								'part'       => 1,
								'export_id'  => $id,
								'full'       => 1,
								'request_id' => 'cnvex_full_' . time() . '_' . rand( 1000, 9999 ),
							);
							$args_req = array(
								'timeout'   => 0.01,
								'blocking'  => false,
								'sslverify' => true
							);
							if ( defined( 'CNVEX_SCHEDULER_REQUEST_USERNAME' )
							     && defined( 'CNVEX_SCHEDULER_REQUEST_PASSWORD' ) ) {
								$args_req[ 'headers' ] = array(
									'Authorization' => 'Basic ' . base64_encode(
											CNVEX_SCHEDULER_REQUEST_USERNAME . ':' . CNVEX_SCHEDULER_REQUEST_PASSWORD
										)
								);
							} else {
								// Use internal token for authentication
								$url_params[ 'cnvex_token' ] = HelperFunctions::getInternalApiToken();
							}

							$url = add_query_arg( $url_params, site_url( 'wp-json/cnvex/v1/exports_update' ) );
							wp_remote_get( $url, $args_req );
						}
					}
				}

				// If a generation task is in progress, return its status
				wp_send_json_success( array(
					'status' => 'in_progress'
				) );
				wp_die();
			}

			ob_start();
			if ( $main_file ) {
				include CNVEX_PLUGIN_VIEWS_PATH . "admin/main/conversion-tasks/main-file-download.php";
			} else {
				include CNVEX_PLUGIN_VIEWS_PATH . "admin/main/conversion-tasks/full-file-download.php";
			}
			$html = ob_get_clean();

			if ( $main_file ) {
				ob_start();
				$files = FileManager()->getFilesByExportId( $id );
				include CNVEX_PLUGIN_VIEWS_PATH . "admin/main/conversion-tasks/table-csv-files.php";
				$file_list = ob_get_clean();
			} else {
				$file_list = '';
			}

			wp_send_json_success( array(
				'status' => 'completed',
				'data'   => array(
					'file'      => $html,
					'file_list' => $file_list,
					'time'      => current_time( 'mysql' ),
				)
			) );
			wp_die();
		}

		wp_send_json_error( array(
			'status' => __( 'Something went wrong', 'conversion-exporter' )
		) );
		wp_die();
	}

	/**
	 * Register rewrite rules for downloading files with parameters via GET request.
	 * This function registers rewrite rules for downloading files with parameters via GET request.
	 * It adds rewrite tags for the export ID and file name, and a rewrite rule for the download URL.
	 * @return void
	 */
	public function registerRewriteRules(): void {
		add_rewrite_tag( '%cnvex_export_id%', '([0-9]+)' );
		add_rewrite_tag( '%cnvex_file%', '([^/]+)' );

		add_rewrite_rule(
			'^conversion-exports/([0-9]+)/([^/]+)/?$',
			'index.php?cnvex_export_id=$matches[1]&cnvex_file=$matches[2]',
			'top'
		);
	}

	public function regenerateExport(): void {
		// Check nonce:
		check_admin_referer( 'cnvex-update-' . CNVEX_SETTINGS_FIELD );
		$this->managePermissions();

		$export_id = (int) sanitize_text_field( $_POST[ 'id' ] );
		$this->manageGenerationExport( $export_id );

		wp_die();
	}

	/**
	 * Manage the generation of an export.
	 * This function manages the generation of an export. It checks if the export is already being processed,
	 * and if not, it schedules the export for generation. It also checks if the full export is disabled,
	 * and if not, it schedules the full export for generation.
	 * @param int $export_id The ID of the export to be generated.
	 * @return void
	 */
	public function manageGenerationExport( int $export_id ): void {
		if ( !empty( $export_id ) ) {
			$method = ConversionExporter()->getOption( 'generation_method' );

			$full_disabled = apply_filters( 'cnvex_disable_full_file_generation', false, $export_id );
			if ( !$full_disabled ) {
				if ( !$this->checkProcessingExportID( $export_id, 'full_part' ) ) {
					$this->state = array(
						'export_ids' => array( $export_id ),
						'orders'     => array(),
						'type'       => 'full_part',
						'created_at' => current_time( 'mysql' ),
						'save'       => true,
					);

					$this->saveLastIteration();
				}
			}

			if ( !$this->checkProcessingExportID( $export_id, 'main_part' ) ) {
				$this->state = array(
					'export_ids' => array( $export_id ),
					'orders'     => array(),
					'type'       => 'main_part',
					'created_at' => current_time( 'mysql' ),
					'save'       => true,
				);
				$this->saveLastIteration();
			}

			switch ( $method ) {
				case 'wp-cron':
					$hook = 'cnvex_export_part_schedule_single';
					$args = array( $export_id );

					if ( !wp_next_scheduled( $hook, $args ) ) {
						wp_schedule_single_event( time() + 10, $hook, $args );
					}

					$hook = 'cnvex_export_part_full_schedule_single';
					$args = array(
						$export_id,
						true
					);
					if ( !wp_next_scheduled( $hook, $args ) ) {
						wp_schedule_single_event( time() + 20, $hook, $args );
					}

					break;

				default:
					break;
			}
		}
	}

	/**
	 * Check if the export ID is currently being processed.
	 * This function checks if the export ID is currently being processed.
	 * @param int    $export_id The ID of the export to check.
	 * @param string $type      The type of the export to check.
	 * @return bool Returns true if the export ID is being processed or disabled, false otherwise.
	 */
	public function checkProcessingExportID( int $export_id, string $type ): bool {
		global $wpdb;
		$table = $wpdb->prefix . $this->file_table_name;

		if ( !$this->checkExportStatus( $export_id ) ) {
			return true;
		}

		$results = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table 
				         WHERE type = %s 
				         AND JSON_CONTAINS(export_ids, %s)",
				$type,
				$export_id
			)
		);

		return !empty( $results );
	}

	/**
	 * Check if the export is enabled.
	 * This function checks if the export is enabled.
	 * @param int    $export_id The ID of the export to check.
	 * @return bool Returns true if the export is enabled, false otherwise.
	 */
	public function checkExportStatus( int $export_id ): bool {
		$post = get_post( $export_id );
		if ( $post ) {
			$enable = get_post_meta( $post->ID, '_cnvex_enable', true );
			if ( !$enable ) {
				return false;
			}
		} else {
			return false;
		}

		return true;
	}
}

/**
 * Get the instance of the ConversionExport class.
 * @return ConversionExport|null The ConversionExport instance or null if it doesn't exist.
 */
function ConversionExport(): ?ConversionExport {
	return ConversionExport::get_instance();
}

ConversionExport();