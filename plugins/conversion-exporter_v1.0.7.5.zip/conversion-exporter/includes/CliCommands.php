<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// Check if WP-CLI is available
if ( !class_exists( 'WP_CLI' ) ) {
	return;
}

/**
 * Class CliCommands
 * WP-CLI commands for Conversion Exporter
 * Provides command-line interface for managing exports.
 * These commands can be used in cron jobs or manual execution.
 */
class CliCommands {

	/**
	 * Run scheduled exports
	 * Executes all exports that are scheduled to run.
	 */
	public function check_exports( $args, $assoc_args ) {

		$method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';
		if ( $method !== 'external' ) {
			\WP_CLI::error( 'Generation method is not set to external. Please set it to external in the settings.' );

			return;
		}

		\WP_CLI::log( 'Starting scheduled exports...' );

		$scheduler = new ExportScheduler();
		$check     = $scheduler->checkScheduledExports();

		if ( !$check ) {
			\WP_CLI::success( 'No exports scheduled to run.' );
		} else {
			\WP_CLI::success( 'Exports scheduled to run.' );
		}
	}
}

// Register WP-CLI commands
\WP_CLI::add_command( 'cnvex', __NAMESPACE__ . '\\CliCommands' );

