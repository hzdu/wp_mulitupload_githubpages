<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

abstract class AdminPage {
	protected string $plugin_name;
	protected string $page_title;
	protected string $plugin_slug = 'conversion-exporter';

	public function __construct() {
		$this->plugin_name = CNVEX_PLUGIN_TITLE;
		add_action( 'init', function () {
			$this->renderTitle();
		} );
	}

	/**
	 * Registers the admin page by hooking into the WordPress admin menu.
	 *
	 * @return void
	 */
	public function renderHTML(): void {
		include CNVEX_PLUGIN_VIEWS_PATH . 'admin/html-general.php';
	}


	/**
	 * Manages permissions for the admin page.
	 *
	 * @return void
	 */
	public function managePermissions(): void {
		// Lock out non-admins:
		if ( !current_user_can( 'cnvex_manage' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permission to perform this operation', 'conversion-exporter' ) );
		}
	}

	/**
	 * Checks if the nonce is valid for the current request.
	 *
	 * @return bool
	 */
	public function checkNonce(): bool {
		return isset( $_POST[ '_wpnonce' ] ) && wp_verify_nonce( $_POST[ '_wpnonce' ], 'cnvex-update-' . CNVEX_SETTINGS_FIELD ) && isset( $_POST[ 'cnvex_update_action' ] ) && isset( $_POST[ $this->plugin_slug ] );
	}

	/**
	 * Returns the plugin name.
	 *
	 * @return string The name of the plugin.
	 */
	public function getPluginSlug(): string {
		return $this->plugin_slug;
	}
}