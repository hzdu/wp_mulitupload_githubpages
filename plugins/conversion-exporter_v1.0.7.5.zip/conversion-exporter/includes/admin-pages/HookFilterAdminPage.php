<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class HookFilterAdminPage extends AdminPage implements AdminPageInterface {

	protected string $page_slug = 'cnvex-hook-filter';
	protected string $view      = 'hooks';

	/**
	 * Registers the plugin menu.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'admin_menu', array(
			$this,
			'addMenu'
		) );
	}

	/**
	 * Sets the page title for the hooks and filters admin page.
	 *
	 * @return void
	 */
	public function renderTitle(): void {
		$this->page_title = __( 'Hooks & Filters', 'conversion-exporter' );
	}

	/**
	 * Adds the hooks and filters admin page as a submenu under the main plugin menu.
	 *
	 * @return void
	 */
	public function addMenu(): void {
		global $submenu;

		add_submenu_page( 'conversion-exporter', __( 'Hooks & Filters', 'conversion-exporter' ), __( 'Hooks & Filters', 'conversion-exporter' ), 'cnvex_manage', $this->page_slug, array(
			$this,
			'renderPage'
		) );
	}

	/**
	 * Renders the hooks and filters admin page.
	 * This method manages permissions and renders the HTML for the page.
	 *
	 * @return void
	 */
	public function renderPage(): void {
		$this->managePermissions();
		if ( !empty( $message = get_transient( 'cnvex_error_message' ) ) ) {
			HelperNotices::renderWpErrorNotice( $message );
		}
		$this->renderHTML();
	}

	/**
	 * Returns the unique slug for the hooks and filters admin page.
	 *
	 * @return string The page slug.
	 */
	public function getPageSlug(): string {
		return $this->page_slug;
	}
}
