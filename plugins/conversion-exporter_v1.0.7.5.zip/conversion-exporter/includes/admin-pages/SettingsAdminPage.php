<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SettingsAdminPage
 * Handles the creation and management of the settings admin page for the Conversion Exporter plugin.
 * Provides functionality for rendering the page, updating settings, and managing cron jobs.
 */
class SettingsAdminPage extends AdminPage implements AdminPageInterface {

	/**
	 * @var string $page_slug The unique slug for the settings admin page.
	 */
	protected string $page_slug = 'cnvex-settings';

	/**
	 * @var string $view The view type for the settings admin page.
	 */
	protected string $view = 'settings';

	/**
	 * Registers the settings admin page by hooking into the WordPress admin menu.
	 * @return void
	 */
	public function register(): void {
		add_action( 'admin_menu', array(
			$this,
			'addMenu'
		) );
	}

	/**
	 * Sets the page title for the settings admin page.
	 * @return void
	 */
	public function renderTitle(): void {
		$this->page_title = __( 'Settings', 'conversion-exporter' );
	}

	/**
	 * Adds the settings admin page as a submenu under the main plugin menu.
	 * Renames the first submenu item to "Main".
	 * @return void
	 */
	public function addMenu(): void {
		global $submenu;

		add_submenu_page(
			'conversion-exporter',
			__( 'Settings', 'conversion-exporter' ),
			__( 'Settings', 'conversion-exporter' ),
			'cnvex_manage',
			$this->page_slug,
			array(
				$this,
				'renderPage'
			)
		);

		// rename first submenu item
		if ( isset( $submenu[ 'conversion-exporter' ] ) ) {
			$submenu[ 'conversion-exporter' ][ 0 ][ 0 ] = __( 'Main', 'conversion-exporter' );
		}
	}

	/**
	 * Renders the settings admin page and handles form submissions.
	 * @return void
	 */
	public function renderPage(): void {
		$this->managePermissions();

		if ( $this->checkNonce() ) {
			if ( isset( $_POST[ 'cnvex-remove-form-data' ] ) && $_POST[ 'cnvex-remove-form-data' ] == 1 ) {
				$this->removeFormDataHandler();
			} else {
				$this->updateSettings();
			}
		}

		if ( !empty( $message = get_transient( 'cnvex_error_message' ) ) ) {
			HelperNotices::renderWpErrorNotice( $message );
		}

		$this->renderHTML();
	}

	/**
	 * Retrieves the slug of the settings admin page.
	 * @return string The page slug.
	 */
	public function getPageSlug(): string {
		return $this->page_slug;
	}

	/**
	 * Updates plugin settings based on submitted form data.
	 * Reschedules cron jobs if the "how_often_create_csv" setting is changed.
	 * @return void
	 */
	private function updateSettings(): void {
		$post_data = HelperFunctions::recursivelySanitize( $_POST[ 'conversion-exporter' ] );

		$exclude_cm_categories      = ( isset( $post_data[ 'exclude_cm_categories' ] )
		                                && is_array(
			                                $post_data[ 'exclude_cm_categories' ]
		                                ) ) ? $post_data[ 'exclude_cm_categories' ] : array();
		$exclude_cm_categories_save = array();
		foreach ( $exclude_cm_categories as $category ) {
			if ( !empty( $category ) ) {
				$exclude_cm_categories_save[] = $category;
			}
		}
		$post_data[ 'exclude_cm_categories' ] = $exclude_cm_categories_save;

		$gclid_backup_parameters      = ( isset( $post_data[ 'gclid_backup_parameters' ] )
		                                  && is_array(
			                                  $post_data[ 'gclid_backup_parameters' ]
		                                  ) ) ? $post_data[ 'gclid_backup_parameters' ] : array();
		$gclid_backup_parameters_save = array();
		foreach ( $gclid_backup_parameters as $param ) {
			if ( !empty( $param ) ) {
				$gclid_backup_parameters_save[] = $param;
			}
		}
		$post_data[ 'gclid_backup_parameters' ] = $gclid_backup_parameters_save;

		if ( isset( $post_data[ 'how_often_create_csv' ] ) && $post_data[ 'generation_method' ] ) {
			$this->handleRegenerationMethodChange(
				$post_data[ 'how_often_create_csv' ],
				$post_data[ 'generation_method' ]
			);
		}

		foreach ( $post_data as $item_name => $val ) {
			ConversionExporter()->updateOptions( array( $item_name => $val ) );
		}
	}

	/**
	 * Handle generation method change
	 * Updates cron schedules based on the selected generation method
	 * @param string $new_create_csv_method
	 * @param string $new_generation_method
	 * @return void
	 */
	private function handleRegenerationMethodChange( string $new_create_csv_method, string $new_generation_method ): void {
		$old_generation_method = ConversionExporter()->getOption( 'generation_method' );

		if ( $old_generation_method === $new_generation_method ) {
			if ( $new_generation_method === 'wp-cron' ) {
				$old_create_csv_method = ConversionExporter()->getOption( 'how_often_create_csv' );
				if ( $old_create_csv_method === $new_create_csv_method ) {
					return; // No need to reschedule if the value hasn't changed
				}

				$this->scheduleCronJob( $new_create_csv_method );
			}

			return; // No change needed
		}

		// If switching away from WP-Cron, clear periodic export cron hooks
		if ( $new_generation_method !== 'wp-cron' ) {
			if ( wp_next_scheduled( 'cnvex_export_schedule' ) ) {
				wp_clear_scheduled_hook( 'cnvex_export_schedule' );
			}
			$args = array( true );
			if ( wp_next_scheduled( 'cnvex_export_full_schedule', $args ) ) {
				wp_clear_scheduled_hook( 'cnvex_export_full_schedule', $args );
			}

			delete_transient( 'cnvex_last_export_schedule' );
			delete_transient( 'cnvex_last_full_export_schedule' );
		} else {
			$this->scheduleCronJob( $new_create_csv_method );
		}
	}

	/**
	 * Schedules or reschedules cron jobs based on the provided frequency value.
	 * @param string $val The frequency value for the cron job.
	 * @return void
	 */
	public function scheduleCronJob( string $val ): void {

		if ( wp_next_scheduled( 'cnvex_export_schedule' ) ) {
			wp_clear_scheduled_hook( 'cnvex_export_schedule' );
		}

		$args = array(
			true
		);
		if ( wp_next_scheduled( 'cnvex_export_full_schedule', $args ) ) {
			wp_clear_scheduled_hook( 'cnvex_export_full_schedule', $args );
		}

		wp_schedule_event( time(), $val, 'cnvex_export_schedule' );
		wp_schedule_event( time(), $val, 'cnvex_export_full_schedule', $args );
	}

	/**
	 * Removes all form data associated with the plugin.
	 * @return void
	 */
	private function removeFormDataHandler(): void {
		Form()->removeAllFormData();
		ConsentManager()->removeAllConsentData();
	}
}