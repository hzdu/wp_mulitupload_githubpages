<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class StatisticAdminPage extends AdminPage implements AdminPageInterface {

	protected string $page_slug = 'cnvex-admin-statistic';
	protected string $view      = 'admin-statistic';

	/**
	 * Registers the plugin menu.
	 * @return void
	 */
	public function register(): void {
		if ( isset( $_GET[ 'page' ] ) && $_GET[ 'page' ] == $this->page_slug ) {
			add_action( 'admin_menu', array(
				$this,
				'addMenu'
			) );
		}
	}

	/**
	 * Sets the page title for the admin statistic admin page.
	 * @return void
	 */
	public function renderTitle(): void {
		$this->page_title = __( 'Admin Statistic', 'conversion-exporter' );
	}

	/**
	 * Add the admin page statistic to the WordPress menu.
	 * @return void
	 */
	public function addMenu(): void {
		global $submenu;

		add_submenu_page(
			'conversion-exporter',
			__( 'Admin Statistic', 'conversion-exporter' ),
			__( 'Admin Statistic', 'conversion-exporter' ),
			'cnvex_manage',
			$this->page_slug,
			array(
				$this,
				'renderPage'
			)
		);
	}

	/**
	 * Renders the admin statistic admin page.
	 * This method manages permissions and renders the HTML for the page.
	 * @return void
	 */
	public function renderPage(): void {
		$this->managePermissions();
		$this->renderHTML();
	}

	/**
	 * Returns the unique slug for the admin statistic admin page.
	 * @return string The page slug.
	 */
	public function getPageSlug(): string {
		return $this->page_slug;
	}
}
