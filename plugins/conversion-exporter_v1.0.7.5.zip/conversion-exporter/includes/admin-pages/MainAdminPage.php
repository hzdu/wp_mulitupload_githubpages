<?php

namespace ConversionExporter;

// Prevent direct access to the file
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MainAdminPage
 * Handles the main admin page functionality for the Conversion Exporter plugin.
 */
class MainAdminPage extends AdminPage implements AdminPageInterface {

	/**
	 * @var string $page_slug The slug for the admin page.
	 */
	protected string $page_slug = 'conversion-exporter';

	/**
	 * @var string $view The view identifier for the admin page.
	 */
	protected string $view = 'main';

	public function __construct() {
		parent::__construct();

		add_action( 'admin_post_cnvex_save_settings', array(
			$this,
			'handleSaveSettings'
		) );
	}

	/**
	 * Handles the saving of settings based on the submitted form data.
	 * This method checks for nonce verification and processes different actions
	 * such as adding or updating conversion exports and forms.
	 * @return void
	 */
	public function handleSaveSettings(): void {
		if ( $this->checkNonce() ) {
			// Handle form submissions based on the action specified in $_POST
			if ( $_POST[ 'cnvex_update_action' ] == 'add_conversion_export' ) {
				$id = $this->addConversionExportHandler();
				if ( $id ) {
					wp_safe_redirect( admin_url( 'admin.php?page=conversion-exporter&conversion_task_id=' . $id ) );
					exit;
				}
			} elseif ( !empty( $_POST[ 'cnvex_conversion_task_id' ] ) ) {
				$id = sanitize_text_field( $_POST[ 'cnvex_conversion_task_id' ] );
				if ( empty( $_POST[ 'cnvex_delete_conversion_file' ] ) ) {
					$this->updateConversionExportHandler();
				} else {
					$this->deleteConversionFileHandler();
				}
				wp_safe_redirect( admin_url( 'admin.php?page=conversion-exporter&conversion_task_id=' . $id ) );
				exit;
			} elseif ( !empty( $_POST[ 'cnvex_delete_conversion_task_id' ] ) ) {
				$this->deleteConversionExportHandler();
				wp_safe_redirect( admin_url( 'admin.php?page=conversion-exporter' ) );
				exit;
			} elseif ( $_POST[ 'cnvex_update_action' ] == 'add_form' ) {
				$id = $this->addFormHandler();
				if ( $id ) {
					wp_safe_redirect( admin_url( 'admin.php?page=conversion-exporter&form_id=' . $id ) );
				}
				exit;
			} elseif ( isset( $_POST[ 'cnvex_form_id' ] ) ) {
				$id = sanitize_text_field( $_POST[ 'cnvex_form_id' ] );
				$this->updateFormHandler();
				wp_safe_redirect( admin_url( 'admin.php?page=conversion-exporter&form_id=' . $id ) );
				exit;
			} elseif ( !empty( $_POST[ 'cnvex_delete_form_id' ] ) ) {
				$this->deleteFormHandler();
				wp_safe_redirect( admin_url( 'admin.php?page=conversion-exporter&tab=cnvex-form-tasks' ) );
				exit;
			}
		}

		wp_safe_redirect( admin_url( 'admin.php?page=conversion-exporter' ) );
		exit;
	}

	/**
	 * Registers the admin page and sets up the necessary hooks.
	 * @return void
	 */
	public function register(): void {
		add_action( 'admin_menu', array(
			$this,
			'addMenu'
		) );
	}

	/**
	 * Sets the page title based on the current context.
	 * It checks for various query parameters to determine the appropriate title.
	 * @return void
	 */
	public function renderTitle(): void {
		if ( isset( $_GET[ 'add_conversion_task' ] ) ) {
			$this->page_title = __( 'New Conversion Task', 'conversion-exporter' );
		} elseif ( isset( $_GET[ 'conversion_task_id' ] ) ) {
			$id               = sanitize_text_field( $_GET[ 'conversion_task_id' ] );
			$this->page_title = __( 'Edit', 'conversion-exporter' ) . ' ' . get_post_meta(
					$id,
					'_cnvex_conversion_name',
					true
				);
		} elseif ( isset( $_GET[ 'add_form' ] ) ) {
			$this->page_title = __( 'New Form', 'conversion-exporter' );
		} elseif ( isset( $_GET[ 'form_id' ] ) ) {
			$id               = sanitize_text_field( $_GET[ 'form_id' ] );
			$this->page_title = __( 'Edit', 'conversion-exporter' ) . ' ' . get_post_meta(
					$id,
					'_cnvex_form_name',
					true
				);
		} elseif ( isset( $_GET[ 'tab' ] ) ) {
			if ( $_GET[ 'tab' ] == 'cnvex-form-tasks' ) {
				$this->page_title = __( 'Form Tasks', 'conversion-exporter' );
			} else {
				$this->page_title = __( 'Conversion Tasks', 'conversion-exporter' );
			}
		} else {
			$this->page_title = __( 'Conversion Tasks', 'conversion-exporter' );
		}
	}

	/**
	 * Renders the admin page and processes form submissions.
	 * It also manages permissions before rendering the HTML content.
	 * @return void
	 */
	public function renderPage(): void {
		$this->managePermissions();
		if ( !empty( $message = get_transient( 'cnvex_error_message' ) ) ) {
			HelperNotices::renderWpErrorNotice( $message );
		}
		$this->renderHTML();
	}

	/**
	 * Adds the main admin page to the WordPress admin menu.
	 * This method creates a top-level menu item for the Conversion Exporter plugin.
	 * @return void
	 */
	public function addMenu(): void {
		add_menu_page(
			__( 'Conversion Exporter', 'conversion-exporter' ),
			__( 'Conversion Exporter', 'conversion-exporter' ),
			'cnvex_manage',
			'conversion-exporter',
			array(
				$this,
				'renderPage'
			),
			CNVEX_PLUGIN_URL . '/assets/images/cnvex-logo.png',
			90
		);
	}

	/**
	 * Gets the slug for the admin page.
	 * @return string The page slug.
	 */
	public function getPageSlug(): string {
		return $this->page_slug;
	}

	/**
	 * This method processes the form data submitted via POST request,
	 * validates it, and creates a new conversion export task if the task name is unique.
	 * @return ?int
	 */
	private function addConversionExportHandler(): ?int {

		$post_data = HelperFunctions::recursivelySanitize( $_POST[ 'conversion-exporter' ] );

		if ( empty( $post_data[ '_cnvex_conversion_task_name' ] ) || empty( $post_data[ '_cnvex_conversion_name' ] ) ) {
			return null;
		}

		if ( !HelperFunctions::postExistsBySlug(
			$post_data[ '_cnvex_conversion_name' ],
			CNVEX_CONVERSION_POST_TYPE
		) ) {
			$category = get_term_by( 'slug', 'exports', CNVEX_CONVERSION_CATEGORY );
			if ( $category && is_object( $category ) ) {
				$form_ids      = ( isset( $post_data[ '_cnvex_form_ids' ] )
				                   && is_array(
					                   $post_data[ '_cnvex_form_ids' ]
				                   ) ) ? $post_data[ '_cnvex_form_ids' ] : array();
				$form_ids_save = array();
				foreach ( $form_ids as $form_id ) {
					if ( !empty( $form_id ) ) {
						$form_ids_save[] = $form_id;
					}
				}

				$order_statuses      = ( isset( $post_data[ '_cnvex_order_statuses' ] )
				                         && is_array(
					                         $post_data[ '_cnvex_order_statuses' ]
				                         ) ) ? $post_data[ '_cnvex_order_statuses' ] : array();
				$order_statuses_save = array();
				foreach ( $order_statuses as $status ) {
					if ( !empty( $status ) ) {
						$order_statuses_save[] = $status;
					}
				}

				$file_slug = sanitize_title( $post_data[ '_cnvex_conversion_name' ] );

				$category_id = $category->term_id;
				$data        = array(
					'post_type'     => CNVEX_CONVERSION_POST_TYPE,
					'post_title'    => $post_data[ '_cnvex_conversion_name' ],
					'post_category' => array( $category_id ),
					'post_status'   => 'publish',
					'ping_status'   => 'closed',
					'post_author'   => 1,
					'meta_input'    => array(
						'_cnvex_enable'                  => $post_data[ '_cnvex_enable' ] ?? null,
						'_cnvex_conversion_name'         => $post_data[ '_cnvex_conversion_name' ],
						'_cnvex_conversion_task_name'    => $post_data[ '_cnvex_conversion_task_name' ],
						'_cnvex_conversion_url'          => $post_data[ '_cnvex_conversion_url' ] ?? null,
						'_cnvex_consent_enable'          => $post_data[ '_cnvex_consent_enable' ] ?? null,
						'_cnvex_source'                  => $post_data[ '_cnvex_source' ] ?? null,
						'_cnvex_conversion_type'         => $post_data[ '_cnvex_conversion_type' ] ?? null,
						'_cnvex_conversion_format'       => $post_data[ '_cnvex_conversion_format' ] ?? null,
						'_cnvex_order_statuses'          => $order_statuses_save,
						'_cnvex_woo_include_data'        => $post_data[ '_cnvex_woo_include_data' ] ?? null,
						'_cnvex_woo_include_value'       => $post_data[ '_cnvex_woo_include_value' ] ?? null,
						'_cnvex_orders_not_track_by_tag' => $post_data[ '_cnvex_orders_not_track_by_tag' ] ?? null,
						'_cnvex_form_ids'                => $form_ids_save,
						'_cnvex_form_value'              => $post_data[ '_cnvex_form_value' ] ?? null,
						'_cnvex_form_currency'           => $post_data[ '_cnvex_form_currency' ] ?? null,
						'_cnvex_items_only_with_gclid'   => $post_data[ '_cnvex_items_only_with_gclid' ] ?? null,
						'_cnvex_date_from'               => $post_data[ '_cnvex_date_from' ] ?? null,
						'_cnvex_username'                => $post_data[ '_cnvex_username' ] ?? null,
						'_cnvex_password'                => $post_data[ '_cnvex_password' ] ?? null,
						'_cnvex_use_schedule'            => $post_data[ '_cnvex_use_schedule' ] ?? null,
						'_cnvex_delivery_method'         => 'hosted_feed',
						'_cnvex_file_slug'               => $file_slug . '.csv',
						'_cnvex_file_slug_full'          => $file_slug . '-full.csv',
					)
				);
				$post_id     = wp_insert_post( $data );
				wp_set_object_terms( $post_id, $data[ 'post_category' ], CNVEX_CONVERSION_CATEGORY );

				ConversionExport()->manageGenerationExport( $post_id );

				return $post_id;
			}
		} else {
			$message = __( 'Conversion task with this name already exists.', 'conversion-exporter' );
			set_transient( 'cnvex_error_message', $message, 20 );
		}

		return null;
	}

	/**
	 * Handles the update of an existing conversion export task.
	 * @return void
	 */
	private function updateConversionExportHandler(): void {
		$options   = ConversionExport::getConversionMetaFields();
		$id        = sanitize_text_field( $_POST[ 'cnvex_conversion_task_id' ] );
		$post_data = HelperFunctions::recursivelySanitize( $_POST[ 'conversion-exporter' ] );

		if ( empty( $post_data[ '_cnvex_conversion_task_name' ] ) || empty( $post_data[ '_cnvex_conversion_name' ] ) ) {
			return;
		}

		$form_ids      = ( isset( $post_data[ '_cnvex_form_ids' ] )
		                   && is_array(
			                   $post_data[ '_cnvex_form_ids' ]
		                   ) ) ? $post_data[ '_cnvex_form_ids' ] : array();
		$form_ids_save = array();
		foreach ( $form_ids as $form_id ) {
			if ( !empty( $form_id ) ) {
				$form_ids_save[] = $form_id;
			}
		}
		$post_data[ '_cnvex_form_ids' ] = $form_ids_save;

		$order_statuses      = ( isset( $post_data[ '_cnvex_order_statuses' ] )
		                         && is_array(
			                         $post_data[ '_cnvex_order_statuses' ]
		                         ) ) ? $post_data[ '_cnvex_order_statuses' ] : array();
		$order_statuses_save = array();
		foreach ( $order_statuses as $status ) {
			if ( !empty( $status ) ) {
				$order_statuses_save[] = $status;
			}
		}
		$post_data[ '_cnvex_order_statuses' ] = $order_statuses_save;

		foreach ( $post_data as $item_name => $val ) {
			if ( in_array( $item_name, $options ) ) {
				update_post_meta( $id, $item_name, $val );
			}
		}
	}

	/**
	 * Deletes a conversion export task and its associated files.
	 * This method retrieves the task ID from the POST request, deletes the post,
	 * and removes any files associated with the task.
	 * @return void
	 */
	private function deleteConversionExportHandler(): void {
		$id = sanitize_text_field( $_POST[ 'cnvex_delete_conversion_task_id' ] );
		if ( !empty( $id ) ) {
			wp_delete_post( $id, true );
		}

		FileManager()->deleteFiles( $id );
	}

	/**
	 * Handles the creation of a new form task.
	 * @return ?int
	 */
	private function addFormHandler(): ?int {
		$post_data = HelperFunctions::recursivelySanitize( $_POST[ 'conversion-exporter' ] );

		if ( empty( $post_data[ '_cnvex_form_name' ] ) ) {
			return null;
		}

		if ( !HelperFunctions::postExistsBySlug( $post_data[ '_cnvex_form_name' ], CNVEX_FORM_POST_TYPE ) ) {
			$form = get_term_by( 'slug', 'forms', CNVEX_FORM_CATEGORY );
			if ( $form && is_object( $form ) ) {
				$form_data_input = wp_unslash( $post_data[ '_cnvex_form_data_input' ] ?? null );
				$form_data_array = json_decode( $form_data_input, true );

				if ( !is_array( $form_data_array ) ) {
					$form_data_array = array();
				}

				$category_id = $form->term_id;
				$data        = array(
					'post_type'     => CNVEX_FORM_POST_TYPE,
					'post_title'    => $post_data[ '_cnvex_form_name' ],
					'post_category' => array( $category_id ),
					'post_status'   => 'publish',
					'ping_status'   => 'closed',
					'post_author'   => 1,
					'meta_input'    => array(
						'_cnvex_enable'           => $post_data[ '_cnvex_enable' ] ?? null,
						'_cnvex_form_name'        => $post_data[ '_cnvex_form_name' ],
						'_cnvex_page_url'         => $post_data[ '_cnvex_page_url' ] ?? null,
						'_cnvex_form_data_input'  => $form_data_array,
						'_cnvex_form'             => $post_data[ '_cnvex_form' ] ?? null,
						'_cnvex_form_type'        => $post_data[ '_cnvex_form_type' ] ?? null,
						'_cnvex_email_field'      => $post_data[ '_cnvex_email_field' ] ?? null,
						'_cnvex_first_name_field' => $post_data[ '_cnvex_first_name_field' ] ?? null,
						'_cnvex_last_name_field'  => $post_data[ '_cnvex_last_name_field' ] ?? null,
						'_cnvex_phone_field'      => $post_data[ '_cnvex_phone_field' ] ?? null,
						'_cnvex_data_retention'   => $post_data[ '_cnvex_data_retention' ] ?? null,
						'_cnvex_delete_days'      => $post_data[ '_cnvex_delete_days' ] ?? null,
						'_cnvex_delete_entries'   => $post_data[ '_cnvex_delete_entries' ] ?? null,
					)
				);
				$post_id     = wp_insert_post( $data );

				wp_set_object_terms( $post_id, $data[ 'post_category' ], CNVEX_FORM_CATEGORY );

				return $post_id;
			}
		} else {
			$message = __( 'Form task with this name already exists.', 'conversion-exporter' );
			set_transient( 'cnvex_error_message', $message, 20 );
		}

		return null;
	}

	/**
	 * Handles the update of an existing form task.
	 * @return void
	 */
	private function updateFormHandler(): void {
		$options   = Form::getFormMetaFields();
		$id        = sanitize_text_field( $_POST[ 'cnvex_form_id' ] );
		$post_data = HelperFunctions::recursivelySanitize( $_POST[ 'conversion-exporter' ] );

		if ( empty( $post_data[ '_cnvex_form_name' ] ) ) {
			return;
		}

		foreach ( $post_data as $item_name => $val ) {
			if ( in_array( $item_name, $options ) ) {
				if ( $item_name == '_cnvex_form_data_input' ) {
					$val = wp_unslash( $val );
					$val = json_decode( $val, true );
					if ( !is_array( $val ) ) {
						$val = array();
					}
				}
				update_post_meta( $id, $item_name, $val );
			}
		}
	}

	/**
	 * Handles the deletion of a form task.
	 * @return void
	 */
	private function deleteFormHandler(): void {
		$id = sanitize_text_field( $_POST[ 'cnvex_delete_form_id' ] );
		if ( !empty( $id ) ) {
			wp_delete_post( $id, true );
			Form()->removeFormData( $id );
			ConsentManager()->deleteConsentRecord( $id );
		}
	}

	/**
	 * Deletes a specific conversion file associated with a task.
	 * @return void
	 */
	private function deleteConversionFileHandler(): void {
		$filename  = sanitize_text_field( $_POST[ 'cnvex_delete_conversion_file' ] );
		$export_id = sanitize_text_field( $_POST[ 'cnvex_conversion_task_id' ] );

		$uuid      = FileManager()->getFileUuid( $export_id, $filename );
		$file_path = FileManager()->getFilePath( $export_id, $uuid );

		if ( file_exists( $file_path ) ) {
			unlink( $file_path );
		}

		FileManager()->deleteTableRecord( $uuid );
	}
}