<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

interface AdminPageInterface {
	/**
	 * Registers hooks for the page and handles saving
	 */
	public function register();

	/**
	 * Renders the page
	 */
	public function renderPage();

	/**
	 * Renders the title
	 */
	public function renderTitle();

	/**
	 * Returns the page slug
	 */
	public function getPageSlug();
}
