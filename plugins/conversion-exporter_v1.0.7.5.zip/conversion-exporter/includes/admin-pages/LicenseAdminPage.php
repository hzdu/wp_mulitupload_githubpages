<?php

namespace ConversionExporter;

// Prevent direct access to the file
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class LicenseAdminPage
 * Handles the license admin page functionality for the Conversion Exporter plugin.
 */
class LicenseAdminPage extends AdminPage implements AdminPageInterface {

	/**
	 * @var string $page_slug The slug for the admin page.
	 */
	protected string $page_slug = 'cnvex-license';

	/**
	 * @var string $view The view identifier for the admin page.
	 */
	protected string $view = 'license';

	/**
	 * @var string $data_key The key used to store license data.
	 */
	public string $data_key;

	/**
	 * @var string $edd_deactivate_checkbox_key The key for the deactivate checkbox option.
	 */
	public string $edd_deactivate_checkbox_key;

	/**
	 * Register the admin page and its associated actions.
	 *
	 * @return void
	 */
	public function register(): void {
		$this->data_key = 'edd_' . CNVEX_LICENSE_PLUGIN_NAME;
		$this->edd_deactivate_checkbox_key = $this->data_key . '_deactivate_checkbox';
		add_action( 'admin_menu', array(
			$this,
			'addMenu'
		) );
	}

	/**
	 * Set the title for the admin page.
	 *
	 * @return void
	 */
	public function renderTitle(): void {
		$this->page_title = __( 'License', 'conversion-exporter' );
	}

	/**
	 * Add the admin page to the WordPress menu.
	 *
	 * @return void
	 */
	public function addMenu(): void {
		if ( HelperFunctions::isPluginActivated() ) {
			add_submenu_page( 'conversion-exporter', __( 'License', 'conversion-exporter' ), __( 'License', 'conversion-exporter' ), 'cnvex_manage', $this->page_slug, array(
				$this,
				'renderPage'
			) );
		} else {
			add_menu_page( __( 'Conversion Exporter', 'conversion-exporter' ), __( 'Conversion Exporter', 'conversion-exporter' ), 'cnvex_manage', $this->page_slug, array(
				$this,
				'renderPage'
			), CNVEX_PLUGIN_URL . '/assets/images/cnvex-logo.png', 90 );
		}
	}

	/**
	 * Render the admin page content.
	 *
	 * @return void
	 */
	public function renderPage(): void {
		$this->managePermissions();
		if ( !empty( $message = get_transient( 'cnvex_error_message' ) ) ) {
			HelperNotices::renderWpErrorNotice( $message );
		}
		$this->renderHTML();
	}

	/**
	 * Get the slug for the admin page.
	 *
	 * @return string The page slug.
	 */
	public function getPageSlug(): string {
		return $this->page_slug;
	}
}