<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Class RestApi
 * Handles REST API endpoints for Conversion Exporter
 * Provides REST API routes for triggering export updates and other operations.
 * This allows external systems to trigger exports via HTTP requests.
 */
class RestApi {

	public function __construct() {
		$method = ConversionExporter()->getOption( 'generation_method' ) ?: 'wp-cron';
		if ( $method !== 'wp-cron' ) {
			add_action( 'rest_api_init', array( $this, 'registerRoutes' ) );
		}
	}

	/**
	 * Register all REST API routes
	 * @return void
	 */
	public function registerRoutes(): void {
		// Main endpoint for triggering export updates
		register_rest_route(
			'cnvex/v1',
			'/exports_update',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handleExportsUpdate' ),
				'permission_callback' => array( $this, 'checkPermissions' ),
			)
		);


		// Main endpoint for check export updates (external calls)
		register_rest_route(
			'cnvex/v1',
			'/check_exports',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handleCheckExports' ),
				'permission_callback' => array( $this, 'checkPermissions' ),
			)
		);
	}

	/**
	 * Handle exports update request
	 * Main endpoint that triggers the export generation process
	 * @param \WP_REST_Request $request REST request object
	 * @return \WP_REST_Response REST response
	 */
	public function handleExportsUpdate( \WP_REST_Request $request ): \WP_REST_Response {

		set_transient( 'cnvex_scheduler_last_run', time(), 120 );

		// If explicitly requested to run a part step, trigger it and return
		$part      = $request->get_param( 'part' );
		$export_id = (int) $request->get_param( 'export_id' );
		$full      = (bool) $request->get_param( 'full' );
		if ( $part && $export_id ) {
			$this->triggerPartExport( $export_id, $full );

			return new \WP_REST_Response(
				array(
					'success'   => true,
					'message'   => 'Part export triggered',
					'export_id' => $export_id,
					'full'      => $full,
					'timestamp' => time(),
				)
			);
		}

		// Run the scheduled exports
		$this->triggerExport( $full );

		// Return response
		return new \WP_REST_Response(
			array(
				'success'   => true,
				'message'   => __( 'Exports triggered successfully', 'conversion-exporter' ),
				'timestamp' => time(),
			), 200
		);
	}

	public function handleCheckExports( \WP_REST_Request $request ): \WP_REST_Response {

		$scheduler = new ExportScheduler();
		$check     = $scheduler->checkScheduledExports();

		if ( $check ) {
			return new \WP_REST_Response(
				array(
					'success'   => true,
					'message'   => __( 'Exports scheduled to run', 'conversion-exporter' ),
					'timestamp' => time(),
				), 200
			);
		} else {
			return new \WP_REST_Response(
				array(
					'success'   => false,
					'message'   => __( 'No exports scheduled to run', 'conversion-exporter' ),
					'timestamp' => time(),
				), 200
			);
		}
	}

	/**
	 * Check permissions for REST API access
	 * Authentication methods (in priority order):
	 * 1. Basic Auth - if CNVEX_SCHEDULER_REQUEST_USERNAME and CNVEX_SCHEDULER_REQUEST_PASSWORD constants are defined
	 * 2. Internal token - auto-generated token for internal wp_remote_get() calls (used when constants are not defined)
	 * 3. WordPress capability - fallback for authenticated admin users
	 * @param \WP_REST_Request $request REST request object
	 * @return bool True if access is allowed, false otherwise
	 */
	public function checkPermissions( \WP_REST_Request $request ): bool {
		// Method 1: Basic Auth (if constants are defined)
		if ( defined( 'CNVEX_SCHEDULER_REQUEST_USERNAME' )
		     && defined( 'CNVEX_SCHEDULER_REQUEST_PASSWORD' ) ) {
			$auth_header   = $request->get_header( 'authorization' );
			$expected_auth = 'Basic ' . base64_encode(
					CNVEX_SCHEDULER_REQUEST_USERNAME . ':' . CNVEX_SCHEDULER_REQUEST_PASSWORD
				);

			return hash_equals( $expected_auth, $auth_header ?? '' );
		}

		// Method 2: Internal token (for wp_remote_get() calls without user session)
		$request_token = $request->get_param( 'cnvex_token' );
		if ( $request_token ) {
			$stored_token = HelperFunctions::getInternalApiToken();
			if ( hash_equals( $stored_token, $request_token ) ) {
				return true;
			}
		}

		// Method 3: WordPress capability (for authenticated admin users)
		return current_user_can( 'manage_options' );
	}

	/**
	 * Trigger a specific export
	 * @param bool $full
	 * @return void
	 */
	private function triggerExport( bool $full = false ): void {

		if ( $full ) {
			$transient = 'cnvex_last_full_export_schedule';
		} else {
			$transient = 'cnvex_last_export_schedule';
		}

		$last_export          = get_transient( $transient );
		$how_often_create_csv = ConversionExporter()->getOption( 'how_often_create_csv' ) ?: 'once_day';
		$intervals            = ConversionExporter()->addCronIntervals( array() );
		$interval             = $intervals[ $how_often_create_csv ];

		if ( $last_export && $last_export > time() - $interval[ 'interval' ] ) {
			return;
		}

		do_action( 'cnvex_export_schedule', $full );
	}

	/**
	 * Trigger part export step (main_part or full_part)
	 * @param int  $export_id Export ID
	 * @param bool $full      Whether to trigger full part
	 * @return void
	 */
	private function triggerPartExport( int $export_id, bool $full = false ): void {
		if ( $full ) {
			do_action( 'cnvex_export_part_full_schedule_single', $export_id, true );
		} else {
			do_action( 'cnvex_export_part_schedule_single', $export_id );
		}
	}
}

