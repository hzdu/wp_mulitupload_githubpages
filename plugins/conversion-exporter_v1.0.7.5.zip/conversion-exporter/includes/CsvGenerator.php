<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CsvGenerator
 * Generates CSV files for conversion exports based on the specified export state and date range.
 * Handles both WooCommerce orders and form submissions.
 */
class CsvGenerator {

	protected static ?CsvGenerator $instance = null;

	private static int $orderLimit = 500;

	private static int $orderBatchLimit = 600;

	private static array $filteredConversionTemplateFields = array();

	/**
	 * Returns the singleton instance of this class.
	 * @return CsvGenerator|null The singleton instance.
	 */
	public static function get_instance(): ?CsvGenerator {
		// Check if the instance is null
		if ( self::$instance === null ) {
			// Create a new instance of the class
			self::$instance = new self();
		}

		// Return the singleton instance
		return self::$instance;
	}

	private function __construct() {
	}

	/**
	 * Generates a CSV file for the given export state.
	 * @param array  $state      The current state of the export.
	 * @param string $file_path  The path to the CSV file.
	 * @param array  $date_range The date range for filtering data.
	 * @param bool   $new        Whether to create a new file or append to an existing one.
	 * @return array The updated state after processing.
	 */
	public function generateCSV( array $state, string $file_path, array $date_range, bool $new = false ): array {
		$export_id = $state[ 'export_ids' ][ 0 ];
		$output    = fopen( $file_path, $new === true ? 'w' : 'a' );

		// Handle file opening failure
		if ( !$output ) {
			update_post_meta( $export_id, '_cnvex_last_error', __( 'Failed to create file', 'conversion-exporter' ) );
			array_shift( $state[ 'export_ids' ] );

			return $state;
		}

		$source_type     = get_post_meta( $export_id, '_cnvex_source', true );
		$source_format   = get_post_meta( $export_id, '_cnvex_conversion_format', true );
		$conversion_type = $source_format == 'data_manager' ? 'data_manager' : get_post_meta(
			$export_id,
			'_cnvex_conversion_type',
			true
		);

		$template = ConversionTemplates::getTemplate( $source_format, $conversion_type );

		// Validate conversion type
		if ( empty( $template ) ) {
			update_post_meta(
				$export_id,
				'_cnvex_last_error',
				__( 'Unexpected conversion type', 'conversion-exporter' )
			);
			array_shift( $state[ 'export_ids' ] );

			return $state;
		}

		$user_columns   = array();
		$system_columns = array();

		foreach ( $template as $k => $field ) {
			if ( $field[ 'user_field' ] ) {
				$user_columns[ $k ] = $field[ 'name' ];
			} else {
				$system_columns[ $k ] = $field[ 'name' ];
			}
		}

		$user_columns = apply_filters( 'cnvex_filter_csv_columns', $user_columns, $export_id );

		if ( $source_format !== 'data_manager' ) {
			foreach ( $user_columns as &$header ) {
				if ( strncmp( $header, 'cv:', 3 ) !== 0 ) {
					$header = 'cv:' . $header;
				}
			}
			unset ( $header );
		}

		$headers = array_merge( $system_columns, $user_columns );

		foreach ( $headers as $k => $header ) {
			if ( isset( $template[ $k ] ) ) {
				static::$filteredConversionTemplateFields[ $k ] = $template[ $k ];
			} else {
				static::$filteredConversionTemplateFields[ $k ] = array(
					'required'   => false,
					'user_field' => true,
					'hash'       => true,
					'name'       => $header,
					'value'      => '',
				);
			}
		}

		// Write CSV headers if creating a new file
		if ( $new === true ) {
			if ( $source_format == 'data_manager' ) {
				fwrite( $output, implode( ',', $headers ) . "\n" );
			} else {
				$gmt_offset   = get_option( 'gmt_offset' );
				$sign         = ( $gmt_offset >= 0 ) ? '+' : '-';
				$abs_offset   = abs( $gmt_offset );
				$hours        = floor( $abs_offset );
				$minutes      = ( $abs_offset - $hours ) * 60;
				$timezone_str = sprintf( '%s%02d%02d', $sign, $hours, $minutes );

				// Write timezone information
				fputcsv( $output, [
					"Parameters:TimeZone={$timezone_str}",
					...array_fill( 0, count( $headers ) - 1, '' ),
				] );

				// Write header row
				fputcsv( $output, $headers );
			}
		}

		$consent_enable         = ConversionExporter()->getOption( 'consent_enable' ) == 1
		                          && get_post_meta( $export_id, '_cnvex_consent_enable', true ) == 1
		                          && HelperFunctions::isConsentMagicPluginActivated();
		$exclude_cm_categories  = ConversionExporter()->getOption( 'exclude_cm_categories' );
		$export_without_consent = ConversionExporter()->getOption( 'export_without_consent' );

		// Process WooCommerce orders
		if ( $source_type === 'woo' ) {
			if ( empty( $state[ 'orders' ] ) ) {

				if ( $conversion_type == 'adjustments_order' ) {
					$statuses = OrderManager()->getOrderStatuses();
				} else {
					$statuses = get_post_meta( $export_id, '_cnvex_order_statuses', true );
					$statuses = apply_filters( 'cnvex_filter_woo_statuses', $statuses, $export_id );
				}

				if ( !empty( $statuses ) ) {

					$pys_not_tracked_option = get_post_meta( $export_id, '_cnvex_orders_not_track_by_tag', true )
					                          && HelperFunctions::isPYSActivated();

					$last_processed_id = get_post_meta(
						$export_id,
						'_cnvex_last_order_id_' . $state[ 'type' ],
						true
					) ?: 0;

					// Get orders starting from last processed ID
					$orders = $this->getOrdersFromId(
						$last_processed_id + 1,
						$statuses,
						$date_range,
						self::$orderBatchLimit
					);

					if ( empty( $orders ) ) {
						delete_post_meta( $export_id, '_cnvex_last_order_id_' . $state[ 'type' ] );
					} else {
						$orders_filtered = array();

						if ( $pys_not_tracked_option || $conversion_type == 'adjustments_order' || $consent_enable ) {
							foreach ( $orders as $order_data ) {
								$order = wc_get_order( $order_data->id );
								if ( !$order ) {
									continue;
								}

								// Check if the order has the purchase event fired
								if ( $pys_not_tracked_option
								     && $order->get_meta(
										'_pys_purchase_event_fired',
										true
									) ) {
									// If it has, skip this order
									continue;
								}

								if ( $conversion_type == 'adjustments_order'
								     && !$order->get_meta( '_cnvex_total_changed', true )
								     && $order->get_type() !== 'shop_order_refund' ) {
									// If the order hasn't been changed, skip this order
									continue;
								}

								if ( $consent_enable ) {
									if ( $order->get_meta( '_cs_expressed' ) ) {
										$categories               = $order->get_meta( "_cs_category_no" );
										$exclude_categories_order = array();

										if ( !empty( $categories ) ) {
											foreach ( $categories as $category ) {
												$slug = ConsentManager()->getCategoryBy( 'name', $category );
												if ( $slug ) {
													$exclude_categories_order[] = $slug;
												}
											}
										}

										if ( !empty( $exclude_cm_categories )
										     && !empty(
											array_intersect(
												$exclude_cm_categories,
												$exclude_categories_order
											)
											) ) {
											continue;
										}
									} else {
										if ( $export_without_consent == 0 ) {
											continue;
										}
									}
								}

								$orders_filtered[] = $order->get_id();
							}
						} else {
							$orders_filtered = wp_list_pluck( $orders, 'id' );
						}

						// Update last processed ID
						$last_processed_id = max( wp_list_pluck( $orders, 'id' ) );
						update_post_meta( $export_id, '_cnvex_last_order_id_' . $state[ 'type' ], $last_processed_id );

						$state[ 'orders' ] = $orders_filtered;
						$state[ 'save' ]   = false;
					}

					// Save state if necessary
					$state = ConversionExport()->maybeSaveLastIteration( $state );
				}
			}

			$count = min( self::$orderLimit, count( $state[ 'orders' ] ) );

			// Write order data to CSV
			for ( $i = 0; $i < $count; $i++ ) {
				$order_id = array_shift( $state[ 'orders' ] );
				$order    = wc_get_order( $order_id );
				if ( $order ) {
					$data = $this->generateCSVBodyFromWoo( $conversion_type, $export_id, $order );

					if ( !empty( $data ) ) {
						fputcsv( $output, $data );

						// Update order meta to mark it as exported
						$order->update_meta_data( '_cnvex_exported', true );
						$order->update_meta_data( '_cnvex_exported_at', current_time( 'mysql' ) );

						$used_tasks = $order->get_meta('_cnvex_conversion_tasks');
						if ( $used_tasks ) {
							$used_tasks = is_array( $used_tasks ) ? $used_tasks : array( $used_tasks );
							if ( !in_array( $export_id, $used_tasks ) ) {
								$used_tasks[] = $export_id;
							}
						} else {
							$used_tasks = array( $export_id );
						}

						$order->update_meta_data( '_cnvex_conversion_tasks', $used_tasks );
						$order->save_meta_data();

						// If the order is a refund, update the parent order
						if ( $order instanceof \WC_Order_Refund ) {
							$parent_order = wc_get_order( $order->get_parent_id() );

							if ( $parent_order ) {
								$parent_order->update_meta_data('_cnvex_exported', true);
								$parent_order->update_meta_data('_cnvex_exported_at', current_time('mysql'));
								$parent_order->save_meta_data();
							}
						}
					}
				}

				$state[ 'save' ] = false;
			}

			// Finalize export if all orders processed
			if ( empty( $state[ 'orders' ] ) && $state[ 'save' ] ) {
				$export_id = array_shift( $state[ 'export_ids' ] );
				FileManager()->setFileLiveStatus( $export_id, $state[ 'type' ] );
			}

			// Process form submissions
		} elseif ( $source_type === 'form' ) {
			$forms = get_post_meta( $export_id, '_cnvex_form_ids', true );
			$forms = !empty( $forms ) ? array_filter(
				$forms,
				fn ( $form ) => (int) get_post_meta( $form, '_cnvex_enable', true ) === 1
			) : array();

			if ( !empty( $forms ) ) {
				// Save state if necessary
				$state = ConversionExport()->maybeSaveLastIteration( $state );

				global $wpdb;
				$table_name = $wpdb->prefix . 'cnvex_form_data';
				$conditions = [];
				$params     = [];

				$placeholders = implode( ', ', array_fill( 0, count( $forms ), '%d' ) );
				$conditions[] = "form_id IN ($placeholders)";
				$params       = array_merge( $params, $forms );

				// Add date range conditions
				if ( !empty( $date_range[ 'after' ] ) && !empty( $date_range[ 'before' ] ) ) {
					$conditions[] = "forms.submitted_at BETWEEN %s AND %s";
					$params[]     = $date_range[ 'after' ];
					$params[]     = $date_range[ 'before' ];
				} elseif ( !empty( $date_range[ 'after' ] ) ) {
					$conditions[] = "forms.submitted_at >= %s";
					$params[]     = $date_range[ 'after' ];
				} elseif ( !empty( $date_range[ 'before' ] ) ) {
					$conditions[] = "forms.submitted_at <= %s";
					$params[]     = $date_range[ 'before' ];
				}

				if ( $consent_enable ) {
					// first condition: exclude if there are categories with value = 0
					if ( !empty( $exclude_cm_categories ) ) {
						$placeholders = implode( ', ', array_fill( 0, count( $exclude_cm_categories ), '%s' ) );

						$conditions[] = "NOT EXISTS (
							SELECT 1 FROM {$wpdb->prefix}cnvex_consent_data AS consent
							WHERE consent.form_data_id = forms.id
							AND consent.category_slug IN ($placeholders)
							AND consent.value = 0
						)";

						$params = array_merge( $params, $exclude_cm_categories );
					}

					// second condition: if export without consent is not allowed
					if ( !$export_without_consent ) {
						$conditions[] = "EXISTS (
							SELECT 1 FROM {$wpdb->prefix}cnvex_consent_data AS consent
							WHERE consent.form_data_id = forms.id
						)";
					}
				}

				$where = implode( ' AND ', $conditions );

				$sql   = $wpdb->prepare( "SELECT forms.* FROM {$table_name} AS forms WHERE {$where}", ...$params );
				$leads = $wpdb->get_results( $sql, ARRAY_A );

				// Write lead data to CSV
				if ( !empty( $leads ) ) {
					foreach ( $leads as $lead ) {
						$data = $this->generateCSVBodyFromForms( $conversion_type, $export_id, $lead );
						if ( !empty( $data ) ) {
							fputcsv( $output, $data );
						}
					}

					// Update exported leads
					$ids_to_update = wp_list_pluck( $leads, 'id' );

					if ( !empty( $ids_to_update ) ) {
						$placeholders = implode( ', ', array_fill( 0, count( $ids_to_update ), '%d' ) );
						$update_sql   = $wpdb->prepare(
							"UPDATE {$table_name} SET exported_at = NOW() WHERE id IN ($placeholders)",
							...$ids_to_update
						);
						$wpdb->query( $update_sql );
					}
				}
			}

			// Finalize export if all forms processed
			$export_id = array_shift( $state[ 'export_ids' ] );
			FileManager()->setFileLiveStatus( $export_id, $state[ 'type' ] );
		}

		fclose( $output );

		return $state;
	}

	/**
	 * Retrieves orders from the database based on the provided parameters.
	 * @param int   $start_id    The ID to start from.
	 *                           Defaults to 0.
	 * @param array $statuses    The order statuses to include.
	 * @param array $date_range  The date range to filter by.
	 * @param int   $limit       The maximum number of orders to retrieve.
	 *                           Defaults to 200.
	 * @return array The retrieved orders.
	 */
	private function getOrdersFromId( int $start_id, array $statuses, array $date_range, int $limit = 200 ): array {
		global $wpdb;

		$statuses_with_prefix = array_map( function( $status ) {
			return strpos( $status, 'wc-' ) === 0 ? $status : 'wc-' . $status;
		}, $statuses );
		$status_placeholders  = implode( ',', array_fill( 0, count( $statuses_with_prefix ), '%s' ) );

		$hposEnabled = class_exists('\Automattic\WooCommerce\Utilities\OrderUtil')
		               && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

		if ( $hposEnabled ) {
			// HPOS system
			$order_table = $wpdb->prefix . 'wc_orders';

			$sql = "SELECT id, status, date_created_gmt, type FROM {$order_table}
                WHERE id >= %d
                AND type IN ('shop_order', 'shop_order_refund')
                AND status IN ({$status_placeholders})
                AND date_created_gmt BETWEEN %s AND %s
                ORDER BY id ASC
                LIMIT %d";
		} else {
			// Legacy posts system
			$sql = "SELECT ID as id, post_status as status, post_date as date_created_gmt, post_type as type FROM {$wpdb->posts} 
				        WHERE ID >= %d 
				        AND post_type IN ('shop_order', 'shop_order_refund')
				        AND post_status IN ({$status_placeholders})
				        AND post_date BETWEEN %s AND %s
				        ORDER BY ID ASC 
				        LIMIT %d";
		}

		$params = array_merge(
			array( $start_id ),
			$statuses_with_prefix,
			array( $date_range[ 'after' ], $date_range[ 'before' ], $limit )
		);

		$results = $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );

		return $results;
	}

	/**
	 * Generate the CSV body data from a WooCommerce order.
	 * @param string             $type      The type of conversion.
	 * @param int                $export_id The export ID.
	 * @param \WC_Abstract_Order $order     The WooCommerce order object.
	 * @return array|null The CSV data array or null if gclid is missing.
	 */
	private function generateCSVBodyFromWoo( string $type, int $export_id, \WC_Abstract_Order $order ): ?array {

		$gclid       = $order->get_meta( '_cnvex_gclid' );
		$gbraid      = $order->get_meta( '_cnvex_gbraid' );
		$wbraid      = $order->get_meta( '_cnvex_wbraid' );
		$google_clid = $gclid ?: ( $gbraid ?: ( $wbraid ?: '' ) );

		$only_with_gclid = get_post_meta( $export_id, '_cnvex_items_only_with_gclid', true );

		if ( ( $type == 'clicks' || $only_with_gclid ) && empty( $google_clid ) ) {
			return null; // Return null if gclid is required but missing
		}

		$sha256_encode = ConversionExporter()->getOption( 'sha256_encode' );
		$include_data  = get_post_meta( $export_id, '_cnvex_woo_include_data', true );
		$include_value = get_post_meta( $export_id, '_cnvex_woo_include_value', true );
		$order_type    = $order->get_type();

		$refunded_value = 0.0;
		if ( $order instanceof \WC_Order_Refund ) {
			$refunded_value = (float) $order->get_amount();
		} elseif ( $order instanceof \WC_Order ) {
			$refunded_value = (float) $order->get_total_refunded();
		}

		if ( $order_type == 'shop_order_refund' ) {
			$parent_order_id = $order->get_parent_id();
			$parent_order    = wc_get_order( $parent_order_id );
			$total           = (float) $parent_order->get_total();
		} else {
			$total = $order->get_total();
		}

		if ( $refunded_value !== 0.0 && $refunded_value >= $total ) {
			$refunded_order = true;
		} else {
			$refunded_order = false;
		}

		// Iterate over each field in the conversion template
		foreach ( self::$filteredConversionTemplateFields as $key => &$field ) {
			switch ( $key ) {
				case 'gclid':
					$field[ 'value' ] = esc_html( $google_clid );
					break;
				case 'wbraid':
					$field[ 'value' ] = esc_html( $wbraid );
					break;
				case 'gbraid':
					$field[ 'value' ] = esc_html( $gbraid );
					break;
				case 'conversion_name':
					$field[ 'value' ] = esc_html( get_post_meta( $export_id, '_cnvex_conversion_task_name', true ) );
					break;
				case 'conversion_time':
					$field[ 'value' ] = esc_html( $order->get_date_created()->format( 'Y-m-d H:i:s' ) );
					break;
				case 'conversion_value':
				case 'adjustment_value':
					if ( $order_type == 'shop_order_refund' ) {
						if ( $refunded_order ) {
							$total_refunded = '';
						} else {
							$total_refunded = $total - $refunded_value;
						}

						$field[ 'value' ] = $include_value ? esc_html( $total_refunded ) : '';
					} else {
						$field[ 'value' ] = $include_value ? esc_html( $order->get_total() ) : '';
					}
					break;
				case 'conversion_currency':
				case 'adjustment_value_currency':
					if ( $refunded_order ) {
						$field[ 'value' ] = '';
					} else {
						$field[ 'value' ] = $include_value ? esc_html( $order->get_currency() ) : '';
					}
					break;
				case 'ad_user_data':
					$ad_user_data = $order->get_meta( '_cm_ad_user_data', true );
					if ( empty( $ad_user_data ) ) {
						$ad_user_data = 'granted';
					}
					$ad_user_data     = apply_filters( 'cnvex_ad_user_data_value', $ad_user_data, $export_id, $order->get_id() );
					$field[ 'value' ] = esc_html( $ad_user_data );
					break;
				case 'ad_personalization':
					$ad_personalization = $order->get_meta( '_cm_ad_personalization', true );
					if ( empty( $ad_personalization ) ) {
						$ad_personalization = 'granted';
					}
					$ad_personalization = apply_filters(
						'cnvex_ad_personalization_value',
						$ad_personalization,
						$export_id,
						$order->get_id()
					);
					$field[ 'value' ]   = esc_html( $ad_personalization );
					break;
				case 'transaction_id':
					if ( $order_type == 'shop_order_refund' ) {
						$field[ 'value' ] = esc_html( $include_data ? $order->get_parent_id() : '' );
					} else {
						// For regular orders, use the order ID
						$field[ 'value' ] = esc_html( $include_data ? $order->get_id() : '' );
					}
					break;
				case 'first_name':
					$user_firstname = '';
					if ( $include_data ) {
						$user_firstname = $this->getBillingFieldWoo( $order, 'first_name' );
					}
					$field[ 'value' ] = esc_html( $user_firstname );
					break;
				case 'last_name':
					$user_lastname = '';
					if ( $include_data ) {
						$user_lastname = $this->getBillingFieldWoo( $order, 'last_name' );
					}
					$field[ 'value' ] = esc_html( $user_lastname );
					break;
				case 'email':
					$user_email = '';
					if ( $include_data ) {
						$user_email = $this->getBillingFieldWoo( $order, 'email' );
					}
					$field[ 'value' ] = esc_html( $user_email );
					break;
				case 'phone_number':
					$user_phone = '';
					if ( $include_data ) {
						$user_phone = HelperFunctions::formatPhoneNumber(
							$this->getBillingFieldWoo( $order, 'phone' )
						);
					}
					$field[ 'value' ] = esc_html( $user_phone );
					break;
				case 'adjustment_time':
					$field[ 'value' ] = esc_html( date( 'Y-m-d H:i:s' ) );
					break;
				case 'adjustment_type':
					if ( $refunded_order ) {
						$field[ 'value' ] = 'RETRACT';
					} else {
						$field[ 'value' ] = 'RESTATE';
					}
					break;
				case 'user_agent':
					$field[ 'value' ] = method_exists(
						$order,
						'get_customer_user_agent'
					) ? $order->get_customer_user_agent() : $order->get_meta( '_customer_user_agent' );
					break;
				case 'ip_address':
					$field[ 'value' ] = method_exists(
						$order,
						'get_customer_ip_address'
					) ? $order->get_customer_ip_address() : $order->get_meta( '_customer_ip_address' );
					break;
				case 'session_attributes':
					$field[ 'value' ] = $order->get_meta( '_cnvex_session_attributes' );
					break;
				default:
					break;
			}
		}
		unset( $field ); // Unset the reference to avoid issues

		$user_fields = array();

		foreach ( static::$filteredConversionTemplateFields as $key => $field ) {
			if ( $field[ 'user_field' ] ) {
				$user_fields[ $key ] = $field[ 'value' ];
			}
		}

		$user_fields = apply_filters( 'cnvex_filter_woo_csv_fields', $user_fields, $export_id, $order );
		if ( is_array( $user_fields ) && !empty( $user_fields ) ) {
			// Add user fields to the filtered conversion template fields
			foreach ( static::$filteredConversionTemplateFields as $key => &$field ) {
				if ( $field[ 'hash' ] ) {
					$val = $user_fields[ $key ] ?? $field[ 'value' ];

					if ( $key == 'phone_number' ) {
						// Format phone number if it's a user field
						$val = HelperFunctions::formatPhoneNumber( $val );
					} elseif ( $key == 'email' ) {
						// Sanitize email field
						$val = sanitize_email( $val );
					}
					$field[ 'value' ] = $sha256_encode ? HelperFunctions::sha256Encode(
						$val
					) : HelperFunctions::sanitizeTextField( $val );
				}
			}
		}
		unset( $field ); // Unset the reference to avoid issues

		return array_map( [ self::class, 'sanitizeCsvValue' ], array_column( static::$filteredConversionTemplateFields, 'value' ) );
	}

	/**
	 * Generates the body of a CSV file for forms from the given export and lead
	 * @param string $type      The type of export to generate the CSV for (clicks or adjustments_gclid)
	 * @param int    $export_id The ID of the export to generate the CSV for
	 * @param array  $lead      The lead data to generate the CSV from
	 * @return array|null The generated CSV data or null if there is no GCLID
	 */
	private function generateCSVBodyFromForms( string $type, int $export_id, array $lead ): ?array {

		$gclid       = $lead[ 'gclid' ];
		$gbraid      = $lead[ 'gbraid' ];
		$wbraid      = $lead[ 'wbraid' ];
		$google_clid = $gclid ?: ( $gbraid ?: ( $wbraid ?: '' ) );

		$only_with_gclid = get_post_meta( $export_id, '_cnvex_items_only_with_gclid', true );

		if ( ( $type == 'clicks' || $only_with_gclid ) && empty( $google_clid ) ) {
			return null; // Return null if gclid is required but missing
		}

		$sha256_encode = ConversionExporter()->getOption( 'sha256_encode' );

		foreach ( self::$filteredConversionTemplateFields as $key => &$field ) {
			switch ( $key ) {
				case 'gclid':
					// The GCLID from the lead data
					$field[ 'value' ] = esc_html( $google_clid );
					break;
				case 'wbraid':
					// The wbraid from the lead data
					$field[ 'value' ] = esc_html( $lead[ 'wbraid' ] );
					break;
				case 'gbraid':
					// The gbraid from the lead data
					$field[ 'value' ] = esc_html( $lead[ 'gbraid' ] );
					break;
				case 'conversion_name':
					// The name of the conversion task
					$field[ 'value' ] = esc_html( get_post_meta( $export_id, '_cnvex_conversion_task_name', true ) );
					break;
				case 'conversion_time':
					// The submitted date and time of the lead
					$field[ 'value' ] = esc_html( $lead[ 'submitted_at' ] );
					break;
				case 'conversion_value':
				case 'adjustment_value':
					// The value of the conversion task
					$value            = get_post_meta( $export_id, '_cnvex_form_value', true );
					$field[ 'value' ] = !empty( $value ) ? esc_html( $value ) : '';
					break;
				case 'conversion_currency':
				case 'adjustment_value_currency':
					// The currency of the conversion task
					$currency         = get_post_meta( $export_id, '_cnvex_form_currency', true );
					$field[ 'value' ] = !empty( $currency ) ? esc_html( $currency ) : '';
					break;
				case 'ad_user_data':
					// The consent value for ad user data
					$field[ 'value' ] = apply_filters(
						'cnvex_ad_user_data_value',
						$lead[ 'ad_user_data' ],
						$export_id,
						null
					);
					break;
				case 'ad_personalization':
					// The consent value for ad personalization
					$field[ 'value' ] = apply_filters(
						'cnvex_ad_personalization_value',
						$lead[ 'ad_personalization' ],
						$export_id,
						null
					);
					break;
				case 'transaction_id':
					// The transaction ID of the conversion
					$field[ 'value' ] = '';
					break;
				case 'first_name':
					// The first name of the lead
					$field[ 'value' ] = esc_html( $lead[ 'first_name' ] );
					break;
				case 'last_name':
					// The last name of the lead
					$field[ 'value' ] = esc_html( $lead[ 'last_name' ] );
					break;
				case 'email':
					// The email of the lead
					$field[ 'value' ] = sanitize_email( $lead[ 'email' ] );
					break;
				case 'phone_number':
					// The phone number of the lead
					$phone            = $lead[ 'phone' ];
					$user_phone       = HelperFunctions::formatPhoneNumber( $phone );
					$field[ 'value' ] = esc_html( $user_phone );
					break;
				case 'adjustment_time':
					// The current date and time
					$field[ 'value' ] = esc_html( date( 'Y-m-d H:i:s' ) );
					break;
				case 'adjustment_type':
					// The type of adjustment
					$field[ 'value' ] = 'RESTATE';
					break;
				case 'user_agent':
					$field[ 'value' ] = esc_html( $lead[ 'user_agent' ] );
					break;
				case 'ip_address':
					$field[ 'value' ] = esc_html( $lead[ 'ip_address' ] );
					break;
				case 'session_attributes':
					$field[ 'value' ] = esc_html( $lead[ 'session_attributes' ] );
					break;
				default:
					break;
			}
		}
		unset( $field ); // Unset the reference to avoid issues

		$user_fields = array();

		foreach ( static::$filteredConversionTemplateFields as $key => $field ) {
			if ( $field[ 'user_field' ] ) {
				$user_fields[ $key ] = $field[ 'value' ];
			}
		}

		$user_fields = apply_filters( 'cnvex_filter_form_csv_fields', $user_fields, $export_id, $lead );
		if ( is_array( $user_fields ) && !empty( $user_fields ) ) {
			// Add user fields to the filtered conversion template fields
			foreach ( static::$filteredConversionTemplateFields as $key => &$field ) {
				if ( $field[ 'hash' ] ) {
					$val = $user_fields[ $key ] ?? $field[ 'value' ];

					if ( $key == 'phone_number' ) {
						// Format phone number if it's a user field
						$val = HelperFunctions::formatPhoneNumber( $val );
					} elseif ( $key == 'email' ) {
						// Sanitize email field
						$val = sanitize_email( $val );
					}
					$field[ 'value' ] = $sha256_encode ? HelperFunctions::sha256Encode(
						$val
					) : HelperFunctions::sanitizeTextField( $val );
				}
			}
		}
		unset( $field ); // Unset the reference to avoid issues

		return array_map( [ self::class, 'sanitizeCsvValue' ], array_column( static::$filteredConversionTemplateFields, 'value' ) );
	}

	/**
	 * Sanitizes a value for safe CSV output to prevent formula injection.
	 * Prepends a single quote if the value starts with dangerous characters
	 * that spreadsheet software may interpret as formulas.
	 *
	 * @param mixed $value The value to sanitize.
	 * @return string The sanitized value.
	 */
	private static function sanitizeCsvValue( $value ): string {
		$value = (string) $value;

		if ( $value !== '' && in_array( $value[0], [ '=', '+', '-', '@', "\t", "\r" ], true ) ) {
			$value = "'" . $value;
		}

		return $value;
	}

	/**
	 * Retrieves the billing field value from a WooCommerce order.
	 * @param \WC_Abstract_Order $order The WooCommerce order object.
	 * @param string             $field The billing field to retrieve (e.g., 'email', 'first_name', 'last_name', 'phone').
	 * @return string The value of the specified billing field.
	 */
	private function getBillingFieldWoo( \WC_Abstract_Order $order, string $field ): string {
		if ( $order instanceof \WC_Order_Refund ) {
			$parent_order = wc_get_order( $order->get_parent_id() );

			return $parent_order ? $parent_order->{"get_billing_$field"}() : '';
		}

		return $order->{"get_billing_$field"}();
	}
}

/**
 * Returns an instance of the CsvGenerator class.
 * @return CsvGenerator|null
 */
function CsvGenerator(): ?CsvGenerator {
	return CsvGenerator::get_instance();
}
