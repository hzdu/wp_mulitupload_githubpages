<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class ConversionTemplates {
	public static array $uploads = array(
		'clicks'            => array(
			'gclid'               => array(),
			'conversion_name'     => array(),
			'conversion_time'     => array(),
			'conversion_value'    => array(),
			'conversion_currency' => array(),
			'ad_user_data'        => array(),
			'ad_personalization'  => array(),
			'transaction_id'      => array(),
			'first_name'          => array(),
			'last_name'           => array(),
			'email'               => array(),
			'phone_number'        => array(),
		),
		'clicks_enhanced'   => array(
			'gclid'               => array(),
			'email'               => array( 'user_field' => false, 'name' => 'Email' ),
			'phone_number'        => array( 'user_field' => false, 'name' => 'Phone Number' ),
			'conversion_name'     => array(),
			'conversion_time'     => array(),
			'conversion_value'    => array(),
			'conversion_currency' => array(),
			'ad_user_data'        => array(),
			'ad_personalization'  => array(),
			'transaction_id'      => array(),
			'first_name'          => array(),
			'last_name'           => array(),
		),
		'adjustments_order' => array(
			'gclid'                     => array(),
			'transaction_id'            => array( 'name' => 'Order ID' ),
			'conversion_name'           => array(),
			'adjustment_time'           => array(),
			'adjustment_type'           => array(),
			'adjustment_value'          => array(),
			'adjustment_value_currency' => array(),
		),
	);

	public static array $data_manager = array(
		'data_manager' => array(
			'gclid'               => array( 'name' => 'gclid' ),
			'conversion_name'     => array( 'name' => 'conversion_name' ),
			'conversion_time'     => array( 'name' => 'conversion_time' ),
			'conversion_value'    => array( 'name' => 'conversion_value' ),
			'conversion_currency' => array( 'name' => 'currency_code' ),
			'ad_user_data'        => array( 'name' => 'ad_user_data' ),
			'ad_personalization'  => array( 'name' => 'ad_personalization' ),
			'transaction_id'      => array( 'name' => 'order_id' ),
			'first_name'          => array( 'name' => 'hashed_first_name' ),
			'last_name'           => array( 'name' => 'hashed_last_name' ),
			'email'               => array( 'name' => 'hashed_email' ),
			'phone_number'        => array( 'name' => 'hashed_phone_number' ),
			'user_agent'          => array( 'name' => 'user_agent' ),
			'ip_address'          => array( 'name' => 'ip_address' ),
			'session_attributes'  => array( 'name' => 'session_attributes' ),
		),
	);

	/**
	 * Retrieves a conversion template based on the specified group and name.
	 *
	 * @param string $group The group of the template (e.g., 'uploads', 'data_manager').
	 * @param string $name  The name of the template within the group.
	 * @return array The conversion template fields with their respective configurations.
	 */
	public static function getTemplate( string $group, string $name ): array {
		if ( !isset( self::$$group ) ) {
			return [];
		}

		$templates = self::$$group;

		if ( !isset( $templates[ $name ] ) ) {
			return [];
		}

		$result = [];
		foreach ( $templates[ $name ] as $field => $overrides ) {
			$base             = ConversionFields::$defaults[ $field ] ?? [];
			$result[ $field ] = array_merge( $base, $overrides );
		}

		return $result;
	}
}