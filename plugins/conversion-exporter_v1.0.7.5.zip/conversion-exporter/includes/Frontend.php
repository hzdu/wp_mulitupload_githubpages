<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Frontend
 * Handles the frontend functionality of the Conversion Exporter plugin.
 * This includes enqueuing scripts and checking if scripts should be loaded.
 */
class Frontend {
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array(
			$this,
			'enqueueScripts'
		) );
	}

	/**
	 * Enqueues the frontend scripts and localizes data for the Conversion Exporter plugin.
	 * This method checks if the scripts should be loaded based on the current page context,
	 * and if so, it enqueues the main script and localizes necessary data.
	 * @return void
	 */
	public function enqueueScripts(): void {

		if ( $this->checkLoading() ) {
			$keys   = array(
				'gclid',
				'gbraid',
				'wbraid'
			);
			$params = array();
			$google_click  = false;

			foreach ( $keys as $key ) {
				if ( isset( $_GET[ $key ] ) ) {
					$params[ $key ] = sanitize_text_field( $_GET[ $key ] );
					$google_click = true;
				}
			}

			$gclid_backup_parameters = ConversionExporter()->getOption( 'gclid_backup_parameters' );
			if ( !empty( $gclid_backup_parameters ) && !$google_click ) {
				foreach ( $gclid_backup_parameters as $param ) {
					if ( !empty( $_GET[ $param ] ) ) {
						$params[ $param ] = sanitize_text_field( $_GET[ $param ] );
					}
				}
			}

			wp_enqueue_script( 'cnvex-frontend-script', CNVEX_PLUGIN_URL . 'assets/scripts/cnvex-public.min.js', array(
				'jquery',
			), CNVEX_LATEST_VERSION_NUMBER, time() );

			wp_localize_script( 'cnvex-frontend-script', 'CNVEX_Data', array(
				'ajaxurl'                 => admin_url( 'admin-ajax.php' ),
				'nonce'                   => wp_create_nonce( 'cnvex-ajax-nonce' ),
				'form_triggers'           => $this->getFormTriggers(),
				'get_parameters'          => $params,
				'consent_enable'          => (int) ConversionExporter()->getOption( 'consent_enable' ),
				'store_cm_consent'        => (int) ConversionExporter()->getOption( 'store_cm_consent' ),
				'gclid_backup_parameters' => $gclid_backup_parameters,
				'cookie_consent'          => apply_filters( 'cnvex_cookies_consent', true ) ? 1 : 0
			) );
		}
	}

	/**
	 * Checks if the scripts should be loaded based on the current page context.
	 * The scripts will not be loaded if Elementor is active and the user is in preview or edit mode.
	 * @return bool True if scripts should be loaded, false otherwise.
	 */
	public function checkLoading(): bool {

		if ( !function_exists('is_plugin_active') ) {
			@include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$elementorActive = function_exists('is_plugin_active')
		                   && ( is_plugin_active('elementor/elementor.php') || is_plugin_active('elementor-pro/elementor-pro.php') );
		if ( $elementorActive && class_exists('\Elementor\Plugin') ) {
			$inst = \Elementor\Plugin::$instance ?? null;
			if ( $inst && isset($inst->preview) && method_exists($inst->preview,'is_preview_mode') && $inst->preview->is_preview_mode() ) return false;
			if ( $inst && isset($inst->editor)  && method_exists($inst->editor, 'is_edit_mode')    && $inst->editor->is_edit_mode() )   return false;
		}
		return true;
	}

	/**
	 * Retrieves the form triggers for the Conversion Exporter plugin.
	 * This method fetches all published forms that have the '_cnvex_enable' meta key set to 1,
	 * and returns an array of form triggers with their details.
	 * @return array An associative array of form triggers with their details.
	 */
	private function getFormTriggers(): array {
		$args         = array(
			'post_type'      => CNVEX_FORM_POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'order'          => 'ASC',
			'orderby'        => 'DATE',
			'meta_query'     => array(
				array(
					'key'   => '_cnvex_enable',
					'value' => 1,
				)
			),
			'meta_type'      => 'NUMERIC',
		);
		$forms        = get_posts( $args );
		$formTriggers = array();

		if ( !empty( $forms ) ) {
			foreach ( $forms as $form ) {
				$formTriggers[ $form->ID ] = array(
					'form_id'          => $form->ID,
					'page_url'         => get_post_meta( $form->ID, '_cnvex_page_url', true ),
					'form'             => get_post_meta( $form->ID, '_cnvex_form', true ),
					'form_type'        => get_post_meta( $form->ID, '_cnvex_form_type', true ),
					'email_field'      => get_post_meta( $form->ID, '_cnvex_email_field', true ),
					'first_name_field' => get_post_meta( $form->ID, '_cnvex_first_name_field', true ),
					'last_name_field'  => get_post_meta( $form->ID, '_cnvex_last_name_field', true ),
					'phone_field'      => get_post_meta( $form->ID, '_cnvex_phone_field', true ),
				);
			}
		}

		return $formTriggers;
	}
}

