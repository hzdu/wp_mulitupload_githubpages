<?php

namespace ConversionExporter;

/**
 * This class defines all code necessary to run during the plugin's initialization.
 */
class I18n {
	/**
	 * Registers the plugin's text domain for translation.
	 *
	 * This method is called when the plugins_loaded action is triggered.
	 * It loads the plugin's text domain for translation.
	 */
	public function load_plugin_textdomain(): void {
		load_plugin_textdomain( 'conversion-exporter', false, dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/' );
	}
}
