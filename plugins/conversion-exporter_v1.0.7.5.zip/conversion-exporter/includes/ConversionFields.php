<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class ConversionFields {
	public static array $defaults = array(
		'gclid'               => array(
			'required'   => true,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Google Click ID',
			'value'      => '',
		),
		'gbraid'               => array(
			'required'   => true,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'gbraid',
			'value'      => '',
		),
		'wbraid'               => array(
			'required'   => true,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'wbraid',
			'value'      => '',
		),
		'conversion_name'     => array(
			'required'   => true,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Conversion Name',
			'value'      => '',
		),
		'conversion_time'     => array(
			'required'   => true,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Conversion Time',
			'value'      => '',
		),
		'conversion_value'    => array(
			'required'   => false,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Conversion Value',
			'value'      => '',
		),
		'conversion_currency' => array(
			'required'   => false,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Conversion Currency',
			'value'      => '',
		),
		'ad_user_data'        => array(
			'required'   => false,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Ad User Data',
			'value'      => '',
		),
		'ad_personalization'  => array(
			'required'   => false,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Ad Personalization',
			'value'      => '',
		),
		'transaction_id'      => array(
			'required'   => false,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'cv:transaction_id',
			'value'      => '',
		),
		'first_name'          => array(
			'required'   => false,
			'user_field' => true,
			'hash'       => true,
			'name'       => 'cv:first_name',
			'value'      => '',
		),
		'last_name'           => array(
			'required'   => false,
			'user_field' => true,
			'hash'       => true,
			'name'       => 'cv:last_name',
			'value'      => '',
		),
		'email'               => array(
			'required'   => false,
			'user_field' => true,
			'hash'       => true,
			'name'       => 'cv:email',
			'value'      => '',
		),
		'phone_number'        => array(
			'required'   => false,
			'user_field' => true,
			'hash'       => true,
			'name'       => 'cv:phone_number',
			'value'      => '',
		),
		'adjustment_time'           => array(
			'required'   => false,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Adjustment Time',
			'value'      => '',
		),
		'adjustment_type'           => array(
			'required'   => true,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Adjustment Type',
			'value'      => '',
		),
		'adjustment_value'          => array(
			'required'   => false,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Adjusted Value',
			'value'      => '',
		),
		'adjustment_value_currency' => array(
			'required'   => false,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Adjusted Value Currency',
			'value'      => '',
		),
		'user_agent' => array(
			'required'   => true,
			'user_field' => true,
			'hash'       => true,
			'name'       => 'User agent',
			'value'      => '',
		),
		'ip_address' => array(
			'required'   => true,
			'user_field' => true,
			'hash'       => true,
			'name'       => 'IP address',
			'value'      => '',
		),
		'session_attributes' => array(
			'required'   => true,
			'user_field' => false,
			'hash'       => false,
			'name'       => 'Session attributes',
			'value'      => '',
		),
	);
}