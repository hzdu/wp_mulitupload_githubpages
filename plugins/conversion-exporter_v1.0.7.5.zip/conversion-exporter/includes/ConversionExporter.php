<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ConversionExporter
 *
 * Main plugin class for the Conversion Exporter plugin.
 * This class initializes the plugin, sets up the admin and frontend functionality,
 * and handles localization and cron schedules.
 */
class ConversionExporter extends Settings implements Plugin {

	protected static ?ConversionExporter $instance = null;

	/** @var Admin */
	protected Admin $admin;

	private array $require_files = array(
		'includes/helpers/HelperFunctions.php',
		'includes/helpers/HelperNotices.php',
		'includes/ConversionFields.php',
		'includes/ConversionTemplates.php',
		'includes/CsvGenerator.php',
		'includes/Frontend.php',
		'includes/Admin.php',
		'includes/Logger.php',
		'includes/I18n.php',
		'includes/Migration.php',
		'includes/AdminPageManager.php',
		'includes/admin-pages/AdminPage.php',
		'includes/admin-pages/AdminPageInterface.php',
		'includes/admin-pages/MainAdminPage.php',
		'includes/admin-pages/LicenseAdminPage.php',
		'includes/admin-pages/HookFilterAdminPage.php',
		'includes/admin-pages/SettingsAdminPage.php',
		'includes/admin-pages/StatisticAdminPage.php',
	);

	public function __construct() {

		$this->requireFiles();

		add_action( 'plugins_loaded', array(
			$this,
			'init'
		) );
		parent::__construct( 'conversion-exporter-plugin' );

		// Run migrations before other initialization
		$this->runMigrations();
	}

	/**
	 * Run plugin migrations if needed.
	 * @return void
	 */
	private function runMigrations(): void {
		( new Migration( $this ) )->maybeMigrate();
	}

	/**
	 * Returns the plugin version number.
	 *
	 * @return string The version number of the plugin.
	 */
	public function getPluginVersion(): string {
		return CNVEX_LATEST_VERSION_NUMBER;
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 * Uses the CS_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 */
	private function setLocale(): void {

		$plugin_i18n = new I18n();
		add_action( 'plugins_loaded', array(
			$plugin_i18n,
			'load_plugin_textdomain'
		) );
	}

	/**
	 * Requires the necessary files for the plugin.
	 * This method includes all the required files for the plugin to function properly.
	 *
	 * @return void
	 */
	private function requireFiles(): void {
		foreach ( $this->require_files as $require_file ) {
			require_once CNVEX_PLUGIN_PATH . $require_file;
		}
	}

	/**
	 * Returns the singleton instance of the ConversionExporter class.
	 *
	 * @return ConversionExporter|null The instance of the ConversionExporter class or null if not instantiated.
	 */
	public static function get_instance(): ?ConversionExporter {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Initializes the plugin.
	 * This method is called when the plugin is loaded and sets up the admin functionality.
	 *
	 * @return void
	 */
	public function init(): void {
		if ( HelperFunctions::isPluginActivated() ) {
			add_action( 'init', array(
				$this,
				'frontendInit'
			) );

			add_action( 'init', function() {
				add_filter( 'cron_schedules', array(
					$this,
					'addCronIntervals'
				) );
			}, 9 );

			$this->setLocale();
		}

		$this->admin = new Admin();
	}

	/**
	 * Initializes the frontend functionality of the plugin.
	 * This method is called when the plugin is loaded and sets up the frontend functionality.
	 *
	 * @return void
	 */
	public function frontendInit(): void {
		new Frontend();
	}

	/**
	 * Adds custom cron intervals to the WordPress cron schedules.
	 * This method allows the plugin to define custom intervals for scheduled tasks.
	 *
	 * @param array $schedules The existing cron schedules.
	 * @return array The modified cron schedules with additional intervals.
	 */
	public function addCronIntervals( array $schedules ): array {
		$schedules[ 'twice_day' ] = array(
			'interval' => 12 * HOUR_IN_SECONDS,
			'display'  => __( 'Twice a day', 'conversion-exporter' ),
		);

		$schedules[ 'once_day' ] = array(
			'interval' => DAY_IN_SECONDS,
			'display'  => __( 'Once a day', 'conversion-exporter' ),
		);

		$schedules[ 'every_two_days' ] = array(
			'interval' => 2 * DAY_IN_SECONDS,
			'display'  => __( 'Once every two days', 'conversion-exporter' ),
		);

		$schedules[ 'once_week' ] = array(
			'interval' => WEEK_IN_SECONDS,
			'display'  => __( 'Once a week', 'conversion-exporter' ),
		);

		return $schedules;
	}
}

/**
 * Returns the singleton instance of the ConversionExporter class.
 *
 * @return ConversionExporter|null The instance of the ConversionExporter class or null if not instantiated.
 */
function ConversionExporter(): ?ConversionExporter {
	return ConversionExporter::get_instance();
}