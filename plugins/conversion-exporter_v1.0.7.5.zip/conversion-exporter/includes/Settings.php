<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Settings
 * Base class for plugin settings management.
 * Provides methods to load, update, and render settings options.
 */
abstract class Settings {

	/**
	 * Options section slug
	 * @var string
	 */
	private string $slug;

	/**
	 * Options values
	 * @var null|array
	 */
	private ?array $values = array();

	/**
	 * Database option key
	 * @var string
	 */
	private string $option_key = '';

	/**
	 * Default options values
	 * @var array
	 */
	private array $defaults = array();

	/**
	 * List of all options
	 * @var array
	 */
	private array $options = array();

	private string $defaults_json_path;

	/**
	 * The unique identifier of this plugin.
	 */
	public string $plugin_name;

	private string $options_table_name = 'cnvex_options';

	/**
	 * Constructor
	 * @param string $slug
	 */
	public function __construct( string $slug ) {
		$this->slug       = $slug;
		$this->option_key = 'cnvex_' . $slug;

		$this->plugin_name = 'conversion-exporter';
		$this->locateOptions( CNVEX_PLUGIN_PATH . 'includes/options_fields.json', CNVEX_PLUGIN_PATH
		                                                                          . 'includes/options_defaults.json' );

		$this->maybeLoad();
	}

	/**
	 * Get the slug of the options section
	 * @return string
	 */
	public function getSlug(): string {
		return $this->slug;
	}

	/**
	 * Load options fields and options defaults from specified files
	 * @param string $fields   Path to options fields file
	 * @param string $defaults Path to options defaults file
	 * @return void
	 */
	public function locateOptions( string $fields, string $defaults ): void {

		$this->loadJSON( $fields, false );
		$this->loadJSON( $defaults, true );

		$this->defaults_json_path = $defaults;

	}

	/**
	 * Reset options to defaults
	 * This method will reset all options to their default values as defined in the defaults JSON file.
	 * If the defaults file does not exist, it will do nothing.
	 * @return void
	 */
	public function resetToDefaults(): void {

		if ( !file_exists( $this->defaults_json_path ) ) {
			return;
		}

		$content = file_get_contents( $this->defaults_json_path );
		$values  = json_decode( $content, true );

		global $wpdb;
		$table_name = $wpdb->prefix . $this->options_table_name;
		$wpdb->query( "TRUNCATE TABLE $table_name" );
		$this->updateOptions( $values );
	}

	/**
	 * Load options fields or options defaults from specified file
	 * @param string $file
	 * @param bool   $is_defaults
	 * @return void
	 */
	private function loadJSON( string $file, bool $is_defaults ): void {

		if ( !file_exists( $file ) ) {
			return;
		}

		$content = file_get_contents( $file );
		$values  = json_decode( $content, true );

		if ( null === $values ) {
			return;
		}

		if ( $is_defaults ) {
			$this->defaults = $values;
		} else {
			$this->options = $values;
		}
	}

	/**
	 * Gets an option value or its default value
	 * @param string $key Option key
	 * @return mixed The value specified for the option or a default value for the option.
	 */
	public function getOption( string $key ) {

		// get option default if unset
		if ( !isset( $this->values[ $key ] ) ) {
			$this->values[ $key ] = $this->defaults[ $key ] ?? null;
		}

		return $this->values[ $key ];
	}

	/**
	 * Load options from DB into memory
	 * @param bool $force
	 * @return void
	 */
	private function maybeLoad( bool $force = false ): void {
		if ( $force || empty( $this->values ) ) {
			global $wpdb;
			$table_name = $wpdb->prefix . $this->options_table_name;
			$sql        = "
					SELECT `name`, `value`
						FROM $table_name";
			$values     = $wpdb->get_results( $sql, ARRAY_A );

			if ( !empty( $values ) ) {
				foreach ( $values as $value ) {
					$this->values[ $value[ 'name' ] ] = $this->unserializeValue( $value[ 'value' ] );
				}
			}
		}

		// if there are no settings defined, use default values
		if ( !is_array( $this->values ) ) {
			$this->values = $this->defaults;
		}
	}

	/**
	 * Serialize values for storage when needed
	 * @param mixed $value
	 * @return string
	 */
	private function serializeValue( $value ): string {
		if ( is_bool( $value ) || is_null( $value ) || is_array( $value ) || is_object( $value ) ) {
			return serialize( $value );
		}

		return $value;
	}

	/**
	 * Check if a string looks like a PHP serialized value
	 * @param string $value
	 * @return bool
	 */
	private function isSerialized( string $value ): bool {
		$value = trim( $value );
		if ( $value === '' ) {
			return false;
		}
		if ( $value === 'N;' ) {
			return true;
		} // null

		$tokens = [
			'b',
			'i',
			'd',
			's',
			'a',
			'O'
		];
		if ( !in_array( $value[ 0 ], $tokens ) ) {
			return false;
		}

		$lastChar = substr( $value, -1 );
		if ( $lastChar !== ';' && $lastChar !== '}' ) {
			return false;
		}

		return true;
	}

	/**
	 * Unserialize or JSON-decode stored value
	 * @param string $value
	 * @param bool   $array
	 * @return mixed
	 */
	private function unserializeValue( $value, $array = true ) {
		// Try to unserialize first (for new format)
		if ( $this->isSerialized( $value ) ) {
			return unserialize( $value );
		}

		// Fallback to JSON decode for backward compatibility
		$decoded = json_decode( $value, $array );

		// If JSON decode was successful and it's not a string that looks like JSON
		if ( json_last_error() === JSON_ERROR_NONE && $value !== $decoded ) {
			return $decoded;
		}

		return $value;
	}

	/**
	 * Persist options into DB
	 * @param ?array $options
	 * @return void
	 */
	public function updateOptions( ?array $options = array() ): void {

		global $wpdb;
		$table_name = $wpdb->prefix . $this->options_table_name;

		foreach ( $options as $key => $value ) {
			$this->values [ $key ] = $value;
			$sql                   = $wpdb->prepare( "
					INSERT INTO $table_name (name, value, updated_at)
					    VALUES (%s, %s, NOW())
					    ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = NOW()", $key, $this->serializeValue( $value ) );

			$wpdb->query( $sql );
		}
	}

    /**
     * Delete an option from DB storage
     * @param string $key_input
     * @return void
     */
    public function deleteOption( $key_input ): void {
        global $wpdb;
        $table_name = $wpdb->prefix . $this->options_table_name;

        if ( isset( $this->options[ $key_input ] ) ) {
            unset( $this->values[ $key_input ] );
            $sql = $wpdb->prepare( "
				DELETE FROM $table_name
				WHERE `name` = %s", $key_input );
            $wpdb->query( $sql );
        }
    }

	/**
	 * Sanitize form field
	 * @param string       $key   Field key
	 * @param array|string $value Field value
	 * @return mixed Sanitized field value
	 */
	private function sanitize_form_field( string $key, $value ) {

		$type = $this->options[ $key ];

		// look for very specific sanitization filter
		$filter_name = "{$this->option_key}_settings_sanitize_{$key}_field";

		if ( has_filter( $filter_name ) ) {
			return apply_filters( $filter_name, $value );
		}

		// look for a sanitize_FIELDTYPE_field method
		if ( is_callable( array(
			$this,
			'sanitize_' . $type . '_field'
		) ) ) {
			return $this->{'sanitize_' . $type . '_field'}( $value );
		}

		// fallback to text
		return $this->sanitize_text_field( $value );
	}

	/**
	 * Sanitize text field
	 * @param mixed $value Value to sanitize
	 * @return string|array Sanitized value
	 */
	public function sanitize_text_field( $value ) {

		$value = is_null( $value ) ? '' : $value;

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $val ) {
				$value[ $key ] = wp_kses_post( trim( stripslashes( $val ) ) );
			}

			return $value;
		} else {
			return wp_kses_post( trim( stripslashes( $value ) ) );
		}
	}

	/**
	 * Get the plugin name
	 * @return string
	 */
	public function getPluginName(): string {
		return $this->plugin_name;
	}

	/**
	 * Render text input field
	 * This method generates a text input field with various attributes and options.
	 * @param string $key
	 * @param bool   $meta
	 * @param ?int   $id
	 * @param string $placeholder
	 * @param string $class
	 * @param bool   $required
	 * @param bool   $disabled
	 * @param string $type
	 */
	public function renderTextInput( string $key, bool $meta = false, ?int $id = null, string $placeholder = '', string $class = '', bool $required = false, bool $disabled = false, string $type = 'full' ): void {
		$attr_name  = $this->getPluginName() . "[$key]";
		$attr_id    = $key;
		$attr_value = $meta ? get_post_meta( $id, $key, true ) : $this->getOption( $key );

		?>
        <input type="text"
               name="<?php echo esc_attr( $attr_name ); ?>"
               id="<?php echo esc_attr( $attr_id ); ?>"
               placeholder="<?php esc_attr_e( $placeholder ); ?>"
               class="form-control input-<?php echo esc_attr( $type ); ?> <?php echo esc_attr( $class ); ?>"
               value="<?php esc_attr_e( $attr_value ); ?>"
	        <?php echo $required ? 'required' : ''; ?>
			<?php disabled( $disabled ); ?>
        />
		<?php
	}

	/**
	 * Render switcher input
	 * This method generates a switcher input field with various attributes and options.
	 * @param string      $key
	 * @param bool        $meta
	 * @param ?int        $id
	 * @param bool        $disabled
	 * @param bool|string $label
	 * @param bool        $default
	 * @param string|bool $custom_classes
	 * @param bool        $unique_attr_id
	 */
	public function renderSwitcherInput( string $key, bool $meta = false, ?int $id = null, bool $disabled = false, $label = false, bool $default = false, $custom_classes = false, bool $unique_attr_id = false ): void {
		$attr_value = $meta ? get_post_meta( $id, $key, true ) : $this->getOption( $key );
		if ( $unique_attr_id ) {
			$attr_id = $key . '_' . uniqid();
		} else {
			$attr_id = $key;
		}
		$attr_name = $this->getPluginName() . "[$key]";
		$classes   = array( 'primary-switch' );

		if ( $custom_classes ) {
			$classes[] = $custom_classes;
		}

		$classes = implode( ' ', $classes );

		if ( $default === false ) {
			$default = $attr_value;
		}

		?>
        <div class="<?php esc_attr_e( $classes ); ?>">
			<?php if ( !$disabled ) : ?>
                <input type="hidden" name="<?php echo esc_attr( $attr_name ); ?>" value="0"
                       class="<?php echo esc_attr( $key ); ?>">
			<?php endif; ?>

            <input type="checkbox"
                   name="<?php echo esc_attr( $attr_name ); ?>"
                   value="1"
				<?php disabled( $disabled ); ?>
				<?php checked( $default ); ?>
                   id="<?php echo esc_attr( $attr_id ); ?>"
                   class="primary-switch-input <?php echo esc_attr( $key ); ?>"
            >

            <label class="primary-switch-btn" for="<?php echo esc_attr( $attr_id ); ?>"></label>
			<?php if ( $label ) : ?>
                <h4 class="switcher-label secondary-heading"><?php echo esc_html( $label ); ?></h4>
			<?php endif; ?>
        </div>

		<?php
	}

	/**
	 * Render select input
	 * This method generates a select input field with various attributes and options.
	 * @param string $key
	 * @param array  $options
	 * @param bool   $meta
	 * @param ?int   $id
	 * @param string $placeholder
	 * @param bool   $disabled
	 * @param bool   $required
	 * @param string $type
	 */
	public function renderSelectInput( string $key, array $options = array(), bool $meta = false, ?int $id = null, string $placeholder = '', bool $disabled = false, bool $required = false, string $type = 'standard' ): void {
		$attr_value = $meta ? get_post_meta( $id, $key, true ) : $this->getOption( $key );
		$attr_id    = $key;
		$attr_name  = $this->getPluginName() . "[$key]";
		?>

        <div class="select-wrap select-<?php echo esc_attr( $type ); ?>-wrap <?php echo $disabled ? 'disabled' : ''; ?>">
            <select class="form-control-cnvex <?php echo esc_attr( $key ); ?>
                    <?php echo $disabled ? 'disabled' : ''; ?>"
                    id="<?php esc_attr_e( $attr_id ); ?>"
                    name="<?php esc_attr_e( $attr_name ); ?>"
                    autocomplete="off"
                    placeholder="<?php esc_attr_e( $placeholder ); ?>"
	            <?php echo $required ? 'required' : ''; ?>
                    style="width: 100%;">
				<?php if ( $placeholder ) : ?>
                    <option></option>
				<?php endif; ?>
				<?php foreach ( $options as $option_key => $option_value ) : ?>
					<?php if ( is_array( $option_value ) ) { ?>
                        <option value="<?php echo esc_attr( $option_value[ 'option_value' ] ); ?>" <?php selected( esc_attr( $option_value[ 'option_value' ] ), esc_attr( $attr_value ) ); ?>><?php echo esc_attr( $option_value[ 'option_name' ] ); ?></option>
					<?php } else { ?>
                        <option value="<?php echo esc_attr( $option_key ); ?>" <?php selected( esc_attr( $option_key ), is_array( $attr_value ) ? esc_attr( $attr_value[ mb_strtolower( $option_value ) ] ) : esc_attr( $attr_value ) ); ?>><?php echo esc_attr( $option_value ); ?></option>
					<?php } endforeach; ?>
            </select>
        </div>
		<?php
	}

	/**
	 * Render multi-select input
	 * This method generates a multi-select input field with various attributes and options.
	 * @param string $key
	 * @param array  $options
	 * @param bool   $meta
	 * @param ?int   $id
	 * @param bool   $disabled
	 * @param string $class
	 * @param string $placeholder
	 * @param mixed  $default
	 * @return void
	 */
	public function renderMultiSelectInput( string $key, array $options = array(), bool $meta = false, ?int $id = null, bool $disabled = false, string $class = '', string $placeholder = '', $default = false ): void {
		$attr_id   = $key . '_' . uniqid();
		$attr_name = $this->getPluginName() . "[$key][]";
		$selected  = $meta ? get_post_meta( $id, $key, true ) : $this->getOption( $key );

		if ( $selected === false || !is_array( $selected ) ) {
			$selected = array();
		}

		if ( $default !== false ) {
			$selected = $default;
		}
		?>

        <div class="select-wrap select-full-wrap">
            <input type="hidden" name="<?php esc_attr_e( $attr_name ); ?>" value="">
            <select class="form-control-cnvex select-full <?php echo esc_attr( $class ); ?>"
                    name="<?php esc_attr_e( $attr_name ); ?>"
                    id="<?php esc_attr_e( $attr_id ); ?>"
				<?php disabled( $disabled ); ?>
                    style="width: 100%;"
                    placeholder="<?php esc_attr_e( $placeholder ); ?>"
                    multiple="multiple">
				<?php if ( $options ) { ?>
					<?php foreach ( $options as $option_key => $option_value ) : ?>
                        <option value="
                        <?php if ( $class == 'cnvex-select2-tags' ) {
                            echo esc_attr( $option_value );
                        } else {
                            echo esc_attr( $option_key );
                        } ?>
                        "
							<?php
							if ( $option_key != 'null' ) {
								if ( $class == 'cnvex-select2-tags' ) {
                                    selected( in_array( $option_value, $selected ) );
                                } else {
                                    selected( in_array( $option_key, $selected ) );
                                }
							}
							?>
							<?php disabled( $option_key, 'disabled' ); ?>
                        >
							<?php echo esc_attr( $option_value ); ?>
                        </option>
					<?php endforeach; ?>
				<?php } ?>
            </select>
        </div>

		<?php
	}

	/**
	 * its method generates a number input field with increment and decrement buttons.
	 * @param             $key
	 * @param bool        $meta
	 * @param int|null    $id
	 * @param bool        $disabled
	 * @param bool        $default
	 * @param string|null $placeholder
	 * @return void
	 */
	function renderNumberInput( $key, bool $meta = false, ?int $id = null, bool $disabled = false, bool $default = false, ?string $placeholder = null ): void {
		$attr_name  = $this->getPluginName() . "[$key]";
		$attr_id    = $key;
		$attr_value = $meta ? get_post_meta( $id, $key, true ) : $this->getOption( $key );

		if ( $default === false ) {
			$default = $attr_value;
		}
		?>

        <div class="input-number-wrapper">
            <button class="decrease"><i class="icon-minus"></i></button>
            <input <?php disabled( $disabled ); ?>
                    type="number"
                    name="<?php esc_attr_e( $attr_name ); ?>"
                    id="<?php esc_attr_e( $attr_id ); ?>"
                    value="<?php esc_attr_e( $default ); ?>"
                    placeholder="<?php esc_attr_e( $placeholder ); ?>"
                    min="0"
            >
            <button class="increase"><i class="icon-plus"></i></button>
        </div>

		<?php
	}

	/**
	 * Render password input field
	 * This method generates a password input field with a toggle button to show/hide the password.
	 * @param string $key
	 * @param bool   $meta
	 * @param ?int   $id
	 * @param string $placeholder
	 * @param string $class
	 * @param bool   $required
	 * @param bool   $disabled
	 * @return void
	 */
	public function renderPasswordInput( string $key, bool $meta = false, ?int $id = null, string $placeholder = '', string $class = '', bool $required = false, bool $disabled = false ): void {
		$attr_name  = $this->getPluginName() . "[$key]";
		$attr_id    = $key;
		$attr_value = $meta ? get_post_meta( $id, $key, true ) : $this->getOption( $key );

		?>
        <div class="input-password-wrap">
            <input type="password"
                   name="<?php echo esc_attr( $attr_name ); ?>"
                   id="<?php echo esc_attr( $attr_id ); ?>"
                   placeholder="<?php echo esc_attr( $placeholder ); ?>"
                   class="form-control input-password <?php echo esc_attr( $class ); ?>"
                   value="<?php echo esc_attr( $attr_value ); ?>"
                   autocomplete="off"
				<?php echo $required ? 'required' : ''; ?>
				<?php disabled( $disabled ); ?>
            />
            <button type="button"
                    class="toggle-password-button"
                    data-target="<?php echo esc_attr( $attr_id ); ?>">
                <i class="icon icon-view"></i>
                <i class="icon icon-hide" style="display: none;"></i>
            </button>
        </div>
		<?php
	}
}