<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Integrations
 *
 * Handles the registration of integration modules for the Conversion Exporter plugin.
 * Each module is responsible for integrating with different systems or functionalities.
 */
class Integrations {

	private array $integration_modules = array(
		'ConversionExport',
		'Form',
		'OrderManager',
		'FileManager',
		'ConsentManager',
	);

	public function __construct() {
		$this->register_modules();
	}

	/**
	 * Registers the integration modules by including their respective files.
	 * Each module is expected to be located in the 'includes/modules/' directory.
	 *
	 * @return void
	 */
	public function register_modules(): void {
		$path = CNVEX_PLUGIN_PATH . 'includes/modules/';

		foreach ( $this->integration_modules as $module ) {
			$file = $path . $module . '/' . $module . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
				// full class name with namespace
				$class_name = 'ConversionExporter\\' . $module;
			}
		}
	}
}
