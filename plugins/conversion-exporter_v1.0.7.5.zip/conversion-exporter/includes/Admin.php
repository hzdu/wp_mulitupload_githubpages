<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Admin
 *
 * Handles the registration of admin pages, styles, scripts, post types, and taxonomies for the Conversion Exporter plugin.
 */
class Admin {

	protected AdminPageManager $page_manager;

	private array $allowedPageSlugs = array();

	public function __construct() {

		//Register admin pages
		$this->page_manager = new AdminPageManager();

		if ( HelperFunctions::isPluginActivated() ) {
			$this->page_manager->addPage( new MainAdminPage() );
			$this->page_manager->addPage( new SettingsAdminPage() );
			$this->page_manager->addPage( new HookFilterAdminPage() );
			$this->page_manager->addPage( new StatisticAdminPage() );

			add_action( 'init', array(
				$this,
				'registerTaxonomies'
			) );
			add_action( 'init', array(
				$this,
				'registerPostTypes'
			) );
		}

		$this->page_manager->addPage( new LicenseAdminPage() );
		$this->register_page_slugs();

		add_action( 'admin_enqueue_scripts', array(
			$this,
			'enqueueStyles'
		) );
		add_action( 'admin_enqueue_scripts', array(
			$this,
			'enqueueScripts'
		) );
	}

	/**
	 * Registers the page slugs for the admin pages.
	 * This method populates the allowedPageSlugs array with the slugs of all registered admin pages.
	 *
	 * @return void
	 */
	private function register_page_slugs(): void {
		$pages = $this->page_manager->getPages();
		foreach ( $pages as $page ) {
			$this->allowedPageSlugs[] = $page->getPageSlug();
		}
	}

	/**
	 * Enqueues the necessary styles for the admin area.
	 * This includes the main plugin stylesheet and the Select2 library.
	 *
	 * @return void
	 */
	public function enqueueStyles(): void {
		if ( in_array( HelperFunctions::getCurrentAdminPage(), $this->allowedPageSlugs ) ) {
			wp_enqueue_style( 'CNVEX-Style', CNVEX_PLUGIN_URL . "assets/css/cnvex-admin.min.css", array(), CNVEX_LATEST_VERSION_NUMBER );
			wp_enqueue_style( 'CNVEX-select2', CNVEX_PLUGIN_URL . "assets/css/select2.min.css", array(), CNVEX_LATEST_VERSION_NUMBER );
			wp_enqueue_style( 'cnvex-noto-sans-font', 'https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wdth,wght@0,62.5..100,100..900;1,62.5..100,100..900&display=swap', array(), null );
		}
	}

	/**
	 * Enqueues the necessary scripts for the admin area.
	 * This includes the main plugin script and the Select2 library.
	 * It also localizes the script with AJAX URL and nonce for security.
	 *
	 * @return void
	 */
	public function enqueueScripts(): void {
		if ( in_array( HelperFunctions::getCurrentAdminPage(), $this->allowedPageSlugs ) ) {
			wp_enqueue_script( 'cnvex-script', CNVEX_PLUGIN_URL . 'assets/scripts/cnvex-admin.min.js', array(
				'jquery',
			), CNVEX_LATEST_VERSION_NUMBER, time() );

			wp_enqueue_script( 'cnvex-select2', CNVEX_PLUGIN_URL . 'assets/scripts/select2.min.js', array( 'jquery' ), CNVEX_LATEST_VERSION_NUMBER, true );

			wp_localize_script( 'cnvex-script', 'CNVEX_Admin_Data', array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'cnvex-ajax-nonce' )
			) );

			if ( isset( $_GET[ 'page' ] ) && ( $_GET[ 'page' ] == 'conversion-exporter' ) ) {
				wp_enqueue_script( 'jquery-ui-datepicker' );
				wp_enqueue_style( 'cnvex_calendar', CNVEX_PLUGIN_URL . 'assets/css/calendar.css', array(), CNVEX_LATEST_VERSION_NUMBER );
			}
		}
	}

	/**
	 * Registers custom post types for the plugin.
	 * This includes "Conversion Exports" and "Form Exports".
	 * Each post type has its own labels, capabilities, and taxonomies.
	 *
	 * @return void
	 */
	public function registerPostTypes(): void {
		$labels = array(
			'name'               => esc_html__( 'Conversion Exports', 'conversion-exporter' ),
			'all_items'          => esc_html__( 'Conversion Exports', 'conversion-exporter' ),
			'singular_name'      => esc_html__( 'Export Conversion Exports', 'conversion-exporter' ),
			'add_new'            => esc_html__( 'Add New', 'conversion-exporter' ),
			'add_new_item'       => esc_html__( 'Add New Conversion Export', 'conversion-exporter' ),
			'edit_item'          => esc_html__( 'Edit Conversion Export', 'conversion-exporter' ),
			'new_item'           => esc_html__( 'New Conversion Export', 'conversion-exporter' ),
			'view_item'          => esc_html__( 'View Conversion Export', 'conversion-exporter' ),
			'search_items'       => esc_html__( 'Search Conversion Export', 'conversion-exporter' ),
			'not_found'          => esc_html__( 'Nothing found', 'conversion-exporter' ),
			'not_found_in_trash' => esc_html__( 'Nothing found in Trash', 'conversion-exporter' ),
			'parent_item_colon'  => ''
		);
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
			'show_ui'             => false,
			'query_var'           => false,
			'rewrite'             => true,
			'show_in_menu'        => false,
			'menu_icon'           => '',
			'capabilities'        => array(
				'publish_posts'       => 'cnvex_manage',
				'edit_posts'          => 'cnvex_manage',
				'edit_others_posts'   => 'cnvex_manage',
				'delete_posts'        => 'cnvex_manage',
				'delete_others_posts' => 'cnvex_manage',
				'read_private_posts'  => 'cnvex_manage',
				'edit_post'           => 'cnvex_manage',
				'delete_post'         => 'cnvex_manage',
				'read_post'           => 'cnvex_manage',
			),
			'taxonomies'          => array( CNVEX_CONVERSION_CATEGORY ),
			'hierarchical'        => true,
			'menu_position'       => null,
			'supports'            => array(
				'title',
				'editor',
				'page-attributes'
			)
		);
		register_post_type( CNVEX_CONVERSION_POST_TYPE, $args );

		$labels = array(
			'name'               => esc_html__( 'Form Exports', 'conversion-exporter' ),
			'all_items'          => esc_html__( 'Form Exports', 'conversion-exporter' ),
			'singular_name'      => esc_html__( 'Export Form Exports', 'conversion-exporter' ),
			'add_new'            => esc_html__( 'Add New', 'conversion-exporter' ),
			'add_new_item'       => esc_html__( 'Add New Form Export', 'conversion-exporter' ),
			'edit_item'          => esc_html__( 'Edit Form Export', 'conversion-exporter' ),
			'new_item'           => esc_html__( 'New Form Export', 'conversion-exporter' ),
			'view_item'          => esc_html__( 'View Form Export', 'conversion-exporter' ),
			'search_items'       => esc_html__( 'Search Form Export', 'conversion-exporter' ),
			'not_found'          => esc_html__( 'Nothing found', 'conversion-exporter' ),
			'not_found_in_trash' => esc_html__( 'Nothing found in Trash', 'conversion-exporter' ),
			'parent_item_colon'  => ''
		);
		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
			'show_ui'             => false,
			'query_var'           => false,
			'rewrite'             => true,
			'show_in_menu'        => false,
			'menu_icon'           => '',
			'capabilities'        => array(
				'publish_posts'       => 'cnvex_manage',
				'edit_posts'          => 'cnvex_manage',
				'edit_others_posts'   => 'cnvex_manage',
				'delete_posts'        => 'cnvex_manage',
				'delete_others_posts' => 'cnvex_manage',
				'read_private_posts'  => 'cnvex_manage',
				'edit_post'           => 'cnvex_manage',
				'delete_post'         => 'cnvex_manage',
				'read_post'           => 'cnvex_manage',
			),
			'taxonomies'          => array( CNVEX_FORM_CATEGORY ),
			'hierarchical'        => true,
			'menu_position'       => null,
			'supports'            => array(
				'title',
				'editor',
				'page-attributes'
			)
		);
		register_post_type( CNVEX_FORM_POST_TYPE, $args );
	}

	/**
	 * Registers custom taxonomies for the plugin.
	 * This includes "Conversion Category" for conversion exports and "Form Category" for form exports.
	 * Each taxonomy has its own labels, capabilities, and settings.
	 *
	 * @return void
	 */
	public function registerTaxonomies(): void {
		register_taxonomy( CNVEX_CONVERSION_CATEGORY, CNVEX_CONVERSION_POST_TYPE, array(
			'label'              => esc_html__( 'Conversion Category', 'conversion-exporter' ),
			'rewrite'            => array( 'slug' => CNVEX_CONVERSION_CATEGORY ),
			'hierarchical'       => true,
			'show_in_menu'       => true,
			'show_ui'            => true,
			'query_var'          => true,
			'capabilities'       => array(
				'manage_terms' => 'cnvex_manage',
				'edit_terms'   => 'cnvex_manage',
				'delete_terms' => 'cnvex_manage',
				'assign_terms' => 'cnvex_manage',
			),
			'publicly_queryable' => false
		) );

		register_taxonomy( CNVEX_FORM_CATEGORY, CNVEX_FORM_POST_TYPE, array(
			'label'              => esc_html__( 'Conversion Category', 'conversion-exporter' ),
			'rewrite'            => array( 'slug' => CNVEX_FORM_CATEGORY ),
			'hierarchical'       => true,
			'show_in_menu'       => true,
			'show_ui'            => true,
			'query_var'          => true,
			'capabilities'       => array(
				'manage_terms' => 'cnvex_manage',
				'edit_terms'   => 'cnvex_manage',
				'delete_terms' => 'cnvex_manage',
				'assign_terms' => 'cnvex_manage',
			),
			'publicly_queryable' => false
		) );

		$term = get_term_by( 'slug', 'exports', CNVEX_CONVERSION_CATEGORY );
		if ( !$term ) {
			wp_insert_term( 'Exports', CNVEX_CONVERSION_CATEGORY, array(
				'description' => '',
				'slug'        => 'exports'
			) );
		}

		$term = get_term_by( 'slug', 'forms', CNVEX_FORM_CATEGORY );
		if ( !$term ) {
			wp_insert_term( 'Forms', CNVEX_FORM_CATEGORY, array(
				'description' => '',
				'slug'        => 'forms'
			) );
		}
	}
}
