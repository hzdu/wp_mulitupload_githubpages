<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Interface Plugin
 *
 * Defines the methods that a plugin must implement.
 */
interface Plugin {

	public function getPluginName();

	public function getPluginVersion();
}