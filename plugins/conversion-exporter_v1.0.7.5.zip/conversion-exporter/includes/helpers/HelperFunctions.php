<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class HelperFunctions {

	/**
	 * Get current admin page
	 * @param string $default
	 * @return string
	 */
	public static function getCurrentAdminPage( string $default = 'cnvex-conversion-tasks' ): string {
		if ( !empty( $_GET[ 'page' ] ) ) {
			return sanitize_text_field( $_GET[ 'page' ] );
		}

		return $default;
	}

	/**
	 * Get current admin tab
	 * @param string $default
	 * @return string
	 */
	public static function getCurrentAdminTab( string $default = 'cnvex-general' ): string {
		if ( !empty( $_GET[ 'tab' ] ) ) {
			return sanitize_text_field( $_GET[ 'tab' ] );
		}

		return $default;
	}

	/**
	 * Generate tab head for General page.
	 * @param        $title_arr
	 * @param string $page
	 * @param string $default
	 * @return void
	 */
	public static function generateSettingsTabhead( $title_arr, string $page = 'conversion-exporter', string $default = 'cnvex-general' ): void {
		$out_arr = array();
		foreach ( $title_arr as $k => $v ) {
			$out_arr[ $k ] = $v;
		} ?>

        <nav class="nav cnvex-nav-tabs">
			<?php
			foreach ( $out_arr as $k => $v ) {
				if ( is_array( $v ) ) {
					$v = ( isset( $v[ 2 ] ) ? $v[ 2 ] : '' ) . $v[ 0 ] . ' ' . ( isset( $v[ 1 ] ) ? $v[ 1 ] : '' );
				}
				if ( $page == 'conversion-exporter' && $k == static::getCurrentAdminTab( $default ) ) {
					$class = 'active';
				} else {
					$class = '';
				}
				$admin_url = static::isPluginActivated() ? static::buildAdminUrl( $page, $k ) : admin_url(
					'admin.php?page=cnvex-license'
				);
				?>
                <a class="cnvex-nav-tab cnvex-nav-link <?php echo esc_attr( $class ); ?>"
                   href="<?php echo esc_url( $admin_url ); ?>"><?php echo esc_attr( $v ); ?></a>
				<?php
			}
			?>
        </nav>
		<?php
	}

	/**
	 * Generate tab head for General page on mobile.
	 * @param        $title_arr
	 * @param string $page
	 * @param string $default
	 * @return void
	 */
	public static function generateSettingsTabheadMobile( $title_arr, string $page = 'conversion-exporter', string $default = 'cnvex-general' ): void {
		$out_arr = array();
		foreach ( $title_arr as $k => $v ) {
			$out_arr[ $k ] = $v;
		}

		$current_tab = static::getCurrentAdminTab( $default );
		$active      = isset( $out_arr[ $current_tab ] );
		?>

        <button class="cnvex-dropdown-toggle">
            <span class="cnvex-current-menu <?php echo esc_attr( $active ? 'active' : '' ); ?>"><?php echo esc_html(
		            $out_arr[ $current_tab ] ?? $out_arr[ 'cnvex-general' ]
	            ); ?></span>
            <i class="icon-chevron-down"></i>
        </button>

        <ul class="cnvex-dropdown-menu">
			<?php
			foreach ( $out_arr as $k => $v ) {
				if ( is_array( $v ) ) {
					$v = ( isset( $v[ 2 ] ) ? $v[ 2 ] : '' ) . $v[ 0 ] . ' ' . ( isset( $v[ 1 ] ) ? $v[ 1 ] : '' );
				}
				if ( $page == 'conversion-exporter' && $k == $current_tab ) {
					$class = 'active';
				} else {
					$class = '';
				}
				$admin_url = static::isPluginActivated() ? static::buildAdminUrl( $page, $k ) : admin_url(
					'admin.php?page=cnvex-license'
				);
				?>
                <li class="<?php echo esc_attr( $class ); ?>"><a
                            href="<?php echo esc_url( $admin_url ); ?>"><?php echo esc_attr(
							$v
						); ?></a><?php echo wp_kses_post(
						$class == 'active' ? '<i class="icon-check"></i>' : ''
					); ?>
                </li>
				<?php
			}
			?>
        </ul>
		<?php
	}

	/**
	 * Check if plugin is activated
	 * Safe on first activation: avoids touching custom tables before they exist.
	 * @return bool
	 */
	public static function isPluginActivated(): bool {
		static $cached_result = null;
		if ( $cached_result !== null ) {
			return $cached_result;
		}

		global $wpdb;
		// Ensure our custom options table exists before querying it
		$table_name   = $wpdb->prefix . 'cnvex_options';
		$like         = '%' . $wpdb->esc_like( $table_name ) . '%';
		$search_query = $wpdb->prepare( 'SHOW TABLES LIKE %s', $like );
		$table_exists = (bool) $wpdb->get_var( $search_query );

		if ( !$table_exists ) {
			// During first activation the table is not yet created, consider plugin as not activated
			$cached_result = false;

			return false;
		}

		if ( ConversionExporter()->getOption( 'edd_conversion_exporter_activated' ) == 'Activated'
		     || ConversionExporter()->getOption( 'edd_conversion_exporter_activated' ) == 'Expired' ) {
			$cached_result = true;
		} else {
			$cached_result = false;
		}

		return $cached_result;
	}

	/**
	 * Build admin url
	 * @param        $page
	 * @param string $tab
	 * @param string $action
	 * @param array  $extra
	 * @return string
	 */
	public static function buildAdminUrl( $page, string $tab = '', string $action = '', array $extra = array() ): string {

		$args = array( 'page' => $page );

		if ( $tab ) {
			$args[ 'tab' ] = $tab;
		}

		if ( $action ) {
			$args[ 'action' ] = $action;
		}

		$args = array_merge( $args, $extra );

		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/**
	 * Recursively sanitize $_POST array
	 * @param mixed $data
	 * @param array $rules
	 * @return mixed
	 */
	public static function recursivelySanitize( $data, array $rules = [] ) {
		if ( is_array( $data ) ) {
			foreach ( $data as $key => $value ) {
				$rule         = $rules[ $key ] ?? null;
				$data[ $key ] = static::recursivelySanitize(
					$value,
					is_array( $rule ) ? $rule : ( $rule ? [ '__rule' => $rule ] : array() )
				);
			}
		} elseif ( is_scalar( $data ) ) {
			$rule = $rules[ '__rule' ] ?? null;

			switch ( $rule ) {
				case 'email':
					$data = sanitize_email( $data );
					break;
				case 'url':
					$data = esc_url_raw( $data );
					break;
				case 'int':
					$data = intval( $data );
					break;
				case 'float':
					$data = floatval( $data );
					break;
				case 'bool':
					$data = (bool) $data;
					break;
				case 'raw':
					$data = wp_kses_post( $data );
					break;
				default:
					$data = sanitize_text_field( $data );
			}
		}

		return $data;
	}

	/**
	 * Check if post exists
	 * @param $post_name
	 * @param $post_type
	 * @return bool
	 */
	public static function postExistsBySlug( $post_name, $post_type ): bool {
		global $wpdb;
		if ( $wpdb->query(
			$wpdb->prepare(
				"SELECT post_name FROM $wpdb->posts WHERE post_name = %s AND post_type = %s",
				$post_name,
				$post_type
			)
		) ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Format phone number
	 * @param string|null $number
	 * @return string|null
	 */
	public static function formatPhoneNumber( ?string $number ): ?string {
		if ( $number === null || $number === '' ) {
			return null;
		}
		$digitsOnly = preg_replace( '/\D+/', '', (string) $number );
		$formatted  = '+' . $digitsOnly;
		if ( preg_match( '/^\+?[1-9]\d{1,14}$/', $formatted ) ) {
			return $formatted;
		}

		return null;
	}

	/**
	 * Check if WooCommerce is active
	 * @return bool
	 */
	public static function isWoocommerceActive(): bool {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Sha256 encode string
	 * @param string|null $value
	 * @return string|null
	 */
	public static function sha256Encode( ?string $value ): ?string {
		$encoded = '';
		if ( $value ) {
			$encoded = hash( 'sha256', strtolower( trim( $value ) ) );
		}

		return $encoded;
	}

	/**
	 * Sanitize text field
	 * @param string|null $string
	 * @return string|null
	 */
	public static function sanitizeTextField( ?string $string ): ?string {
		$string = sanitize_text_field( $string );
		$string = trim( $string );

		return $string;
	}

	/**
	 * Render tooltip
	 * @param $icon
	 * @param $text_tooltip
	 * @return void
	 */
	public static function renderTooltip( $icon, $text_tooltip = 'Copied' ): void {
		?>
        <div class="tooltip">
            <span class="copy-btn"><i class="<?php echo esc_attr( $icon ); ?>"></i></span>
            <span class="tooltip-text"><?php echo esc_attr__( $text_tooltip, 'conv' ); ?></span>
        </div>
		<?php
	}

	/**
	 * Check if PixelYourSite is activated
	 * @return bool
	 */
	public static function isPYSActivated(): bool {

		if ( !function_exists( 'is_plugin_active' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( is_plugin_active( 'pixelyoursite-pro/pixelyoursite-pro.php' )
		     || is_plugin_active( 'pixelyoursite/facebook-pixel-master.php' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Render card collapse settings button
	 * @param bool $card_toggle
	 * @return void
	 */
	public static function cardCollapseSettings( bool $card_toggle = true ): void {
		?>
        <span class="card-collapse <?php echo esc_attr( $card_toggle ? 'card-toggle' : '' ); ?>">
            <?php include CNVEX_PLUGIN_VIEWS_PATH . '/admin/buttons/admin-properties-button.php'; ?>
        </span>
		<?php
	}

	/**
	 * Check if Consent Magic plugin is installed
	 * @return bool
	 */
	public static function isConsentMagicPluginInstalled(): bool {
		if ( !function_exists( 'is_plugin_active' ) ) {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}
		$installed_plugins = get_plugins();
		$plugin_slug       = 'consent-magic/consent-magic.php';
		$plugin_slug_pro   = "consent-magic-pro/consent-magic-pro.php";

		return array_key_exists( $plugin_slug, $installed_plugins )
		       || in_array( $plugin_slug, $installed_plugins, true )
		       || array_key_exists( $plugin_slug_pro, $installed_plugins )
		       || in_array( $plugin_slug_pro, $installed_plugins, true );
	}

	/**
	 * Check if Consent Magic plugin is activated
	 * @return bool
	 */
	public static function isConsentMagicPluginActivated(): bool {
		if ( !function_exists( 'is_plugin_active' ) ) {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}

		return ( is_plugin_active( 'consent-magic-pro/consent-magic-pro.php' )
		         || is_plugin_active( 'consent-magic/consent-magic.php' ) );
	}

	/**
	 * Render card collapse settings with text
	 * @param string $edit
	 * @param string $collapse
	 * @param bool   $card_toggle
	 * @param bool   $return
	 * @return ?string
	 */
	public static function cardCollapseSettingsWithText( string $edit = 'Edit', string $collapse = 'Collapse', bool $card_toggle = true, bool $return = false ) {
		$html = '
            <div class="card-collapse card-collapse-text ' . ( $card_toggle ? 'card-toggle' : '' ) . '">
                <div class="first">' . esc_html__( $edit, 'conversion-exporter' ) . '
                </div>
        
                <div class="second translate-right">' . esc_html__( $collapse, 'conversion-exporter' ) . '
                </div>
            </div>';

		if ( $return ) {
			return $html;
		} else {
			echo $html;
		}
	}

	/**
	 * Get client IP address
	 * @return string
	 */
	public static function getClientIP(): string {

		$ip = '';
		if ( isset( $_SERVER[ 'HTTP_CF_CONNECTING_IP' ] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER[ 'HTTP_CF_CONNECTING_IP' ] ) );
		} elseif ( !empty( $_SERVER[ 'HTTP_CLIENT_IP' ] ) ) {
			//ip from share internet
			$ip = sanitize_text_field( $_SERVER[ 'HTTP_CLIENT_IP' ] );
		} elseif ( !empty( $_SERVER[ 'HTTP_X_FORWARDED_FOR' ] ) ) {
			//ip pass from proxy
			$ip = sanitize_text_field( wp_unslash( $_SERVER[ 'HTTP_X_FORWARDED_FOR' ] ) );
		} elseif ( !empty( $_SERVER[ 'REMOTE_ADDR' ] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER[ 'REMOTE_ADDR' ] ) );
		}

		return explode( ",", $ip )[ 0 ];
	}

    /**
     * Get all server IPs
     * @return string
     */
	public static function getAllServerIps(): string {
		$ips = [];

		// 1. Get external/public IP using an external service
		$external_ip = @file_get_contents( 'https://api64.ipify.org?format=json' );
		if ( $external_ip ) {
			$decoded = json_decode( $external_ip, true );
			if ( !empty( $decoded[ 'ip' ] ) ) {
				$ips[] = $decoded[ 'ip' ];
			}
		}

		// 2. Get IP from the server's hostname
		$hostname = gethostname();
		if ( $hostname ) {
			$hostname_ip = gethostbyname( $hostname );
			if ( filter_var( $hostname_ip, FILTER_VALIDATE_IP ) ) {
				$ips[] = $hostname_ip;
			}

			// 3. Get all IPs associated with the hostname
			$multiple_ips = gethostbynamel( $hostname );
			if ( is_array( $multiple_ips ) ) {
				foreach ( $multiple_ips as $ip ) {
					if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
						$ips[] = $ip;
					}
				}
			}
		}

		// 4. Get IP resolved from the server name (e.g., domain)
		if ( !empty( $_SERVER[ 'SERVER_NAME' ] ) ) {
			$server_name_ip = gethostbyname( $_SERVER[ 'SERVER_NAME' ] );
			if ( filter_var( $server_name_ip, FILTER_VALIDATE_IP ) ) {
				$ips[] = $server_name_ip;
			}
		}

		// 5. Get the IP address of the interface the server is running on
		if ( !empty( $_SERVER[ 'SERVER_ADDR' ] ) && filter_var( $_SERVER[ 'SERVER_ADDR' ], FILTER_VALIDATE_IP ) ) {
			$ips[] = $_SERVER[ 'SERVER_ADDR' ];
		}

		// Remove duplicates and return as a comma-separated string
		$unique_ips = array_unique( $ips );

		return implode( ', ', $unique_ips );
	}

	/**
	 * Generate or retrieve the internal API token for wp_remote_get() calls
	 * Token is stored in wp_options and regenerated if missing
	 * @return string The internal API token
	 */
	public static function getInternalApiToken(): string {
		$token = ConversionExporter()->getOption( 'internal_api_token' );
		if ( !$token ) {
			$token = wp_generate_password( 64, false );
            ConversionExporter()->updateOptions( array( 'internal_api_token' => $token ) );
		}

		return $token;
	}

}
