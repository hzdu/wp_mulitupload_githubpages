<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Uninstall
 *
 * Handles the uninstallation of the Conversion Exporter plugin.
 * This includes removing settings, posts, terms, and database tables.
 */
class Uninstall {

	/**
	 * This function is called when the plugin is deactivated.
	 *
	 * @param bool $license Whether to remove license data or not.
	 */
	public static function deactivation( bool $license = true ): void {
		if ( ConversionExporter()->getOption( 'remove_data_on_deactivation' ) == 1 ) {
			global $wpdb;

			$table = $wpdb->prefix . 'cnvex_options';
			if ( !$license ) {
				$column = 'name';
				$options = array(
					'edd_conversion_exporter',
					'edd_conversion_exporter_activated',
					'edd_license_key',
					'edd_conversion_exporter_deactivate_checkbox',
				);

				$placeholders = implode( ',', array_fill( 0, count( $options ), '%s' ) );

				$sql = $wpdb->prepare(
					"DELETE FROM $table WHERE $column NOT IN ($placeholders)",
					$options
				);
			} else {
				$sql = $wpdb->prepare( 'DROP TABLE IF EXISTS %1$s;', $table );
			}
			$wpdb->query( $sql );

			$args = array();
			$args[ 'posts_per_page' ] = -1;
			$args[ 'numberposts' ] = -1;

			// Remove conversion tasks:
			$args [ 'post_type' ] = CNVEX_CONVERSION_POST_TYPE;
			$posts = get_posts( $args );
			if ( $posts ) {
				foreach ( $posts as $post ) {
					wp_delete_post( $post->ID, true );
				}
			}

			FileManager()->removeDirectoryRecursive( FileManager()->getUploadDir() );

			// Remove forms:
			$args [ 'post_type' ] = CNVEX_FORM_POST_TYPE;
			$posts = get_posts( $args );
			if ( $posts ) {
				foreach ( $posts as $post ) {
					wp_delete_post( $post->ID, true );
				}
			}

			// Remove conversion categories
			$args = array(
				'taxonomy'   => CNVEX_CONVERSION_CATEGORY,
				'hide_empty' => false,
			);
			$categories = get_terms( $args );
			if ( $categories ) {
				foreach ( $categories as $category ) {
					wp_delete_term( $category->term_id, CNVEX_CONVERSION_CATEGORY );
				}
			}

			// Remove form categories
			$args = array(
				'taxonomy'   => CNVEX_FORM_CATEGORY,
				'hide_empty' => false,
			);
			$categories = get_terms( $args );
			if ( $categories ) {
				foreach ( $categories as $category ) {
					wp_delete_term( $category->term_id, CNVEX_FORM_CATEGORY );
				}
			}

			//Remove tables
			$tables = array(
				'cnvex_form_data',
				'cnvex_file_data',
				'cnvex_create_file_data',
				'cnvex_consent_data',
			);

			foreach ( $tables as $table ) {
				$table_name = $wpdb->prefix . $table;
				$sql = $wpdb->prepare( 'DROP TABLE IF EXISTS %1$s;', $table_name );
				$wpdb->query( $sql );
			}
		}

		self::cronDeactivate();

		flush_rewrite_rules();
	}

	/**
	 * This function is called when the plugin is deactivated.
	 * It clears all scheduled cron jobs related to the plugin.
	 *
	 * @return void
	 */
	private static function cronDeactivate(): void {
		if ( wp_next_scheduled( 'cnvex_export_schedule' ) ) {
			wp_clear_scheduled_hook( 'cnvex_export_schedule' );
		}

		$args = array(
			true
		);
		if ( wp_next_scheduled( 'cnvex_export_full_schedule', $args ) ) {
			wp_clear_scheduled_hook( 'cnvex_export_full_schedule', $args );
		}

		if ( wp_next_scheduled( 'cnvex_export_checker' ) ) {
			wp_clear_scheduled_hook( 'cnvex_export_checker' );
		}

		if ( wp_next_scheduled( 'cnvex_form_data_retention' ) ) {
			wp_clear_scheduled_hook( 'cnvex_form_data_retention' );
		}

		if ( wp_next_scheduled( 'cnvex_check_license' ) ) {
			wp_clear_scheduled_hook( 'cnvex_check_license' );
		}
	}
}
