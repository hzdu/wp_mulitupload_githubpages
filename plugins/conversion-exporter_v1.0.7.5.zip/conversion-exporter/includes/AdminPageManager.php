<?php

namespace ConversionExporter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AdminPageManager
 *
 * Manages the registration and retrieval of admin pages for the Conversion Exporter plugin.
 * Each admin page must implement the AdminPageInterface.
 */
class AdminPageManager {

	/** @var AdminPageInterface[] */
	protected array $pages = array();

	/**
	 * Registers an admin page.
	 *
	 * @param AdminPageInterface $page The admin page to register.
	 */
	public function addPage( AdminPageInterface $page ): void {
		$this->pages[] = $page;
		$page->register();
	}

	/**
	 * Enqueues styles for all registered admin pages.
	 *
	 * @return array
	 */
	public function getPages(): array {
		return $this->pages;
	}
}
