/*! elementor-pro - v4.4.0 - 09-11-2026 */
(function(react, _wordpress_i18n) {
	//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp$21 = Object.defineProperty;
	var __name = (target, value) => __defProp$21(target, "name", {
		value,
		configurable: true
	});
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp$21 = Object.prototype.hasOwnProperty;
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) __defProp$21(target, name, {
			get: all[name],
			enumerable: true
		});
		if (!no_symbols) __defProp$21(target, Symbol.toStringTag, { value: "Module" });
		return target;
	};
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
			key = keys[i];
			if (!__hasOwnProp$21.call(to, key) && key !== except) __defProp$21(to, key, {
				get: ((k) => from[k]).bind(null, key),
				enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
			});
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp$21(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));
	//#endregion
	react = __toESM(react);
	//#region modules/forms/submissions/assets/js/admin/data/commands/restore.js
	var Restore = class extends $e.modules.CommandData {
		static getEndpointFormat() {
			return "form-submissions/restore/{id}";
		}
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/data/commands/export.js
	var Export = class extends $e.modules.CommandData {
		static getEndpointFormat() {
			return "form-submissions/export/{id}";
		}
		onCatchApply() {}
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/data/commands/referer.js
	var Referer = class extends $e.modules.CommandData {
		static getEndpointFormat() {
			return "form-submissions/referer/{id}";
		}
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/data/commands/index.js
	var commands_exports = /* @__PURE__ */ __exportAll({
		Export: () => Export,
		Index: () => Index$2,
		Referer: () => Referer,
		Restore: () => Restore
	});
	var Index$2 = class extends $e.modules.CommandData {
		static {
			__name(this, "Index");
		}
		static getEndpointFormat() {
			return "form-submissions/{id}";
		}
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/data/component.js
	var Component = class extends $e.modules.ComponentBase {
		getNamespace() {
			return "form-submissions";
		}
		defaultData() {
			return this.importCommands(commands_exports);
		}
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/data/commands/forms-index.js
	var forms_index_exports = /* @__PURE__ */ __exportAll({ Index: () => Index$1 });
	var Index$1 = class extends $e.modules.CommandData {
		static {
			__name(this, "Index");
		}
		static getEndpointFormat() {
			return "forms/{id}";
		}
	};
	//#endregion
	//#region \0@oxc-project+runtime@0.140.0/helpers/esm/typeof.js
	function _typeof(o) {
		"@babel/helpers - typeof";
		return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
			return typeof o;
		} : function(o) {
			return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
		}, _typeof(o);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.140.0/helpers/esm/toPrimitive.js
	function toPrimitive(t, r) {
		if ("object" != _typeof(t) || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != _typeof(i)) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.140.0/helpers/esm/toPropertyKey.js
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == _typeof(i) ? i : i + "";
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.140.0/helpers/esm/defineProperty.js
	function _defineProperty(e, r, t) {
		return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
			value: t,
			enumerable: !0,
			configurable: !0,
			writable: !0
		}) : e[r] = t, e;
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/data/forms-component.js
	var FormsComponent = class extends $e.modules.ComponentBase {
		getNamespace() {
			return this.constructor.namespace;
		}
		defaultData() {
			return this.importCommands(forms_index_exports);
		}
	};
	_defineProperty(FormsComponent, "namespace", "forms");
	//#endregion
	//#region node_modules/prop-types/lib/ReactPropTypesSecret.js
	/**
	* Copyright (c) 2013-present, Facebook, Inc.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_ReactPropTypesSecret = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
	}));
	//#endregion
	//#region node_modules/prop-types/factoryWithThrowingShims.js
	/**
	* Copyright (c) 2013-present, Facebook, Inc.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_factoryWithThrowingShims = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		var ReactPropTypesSecret = require_ReactPropTypesSecret();
		function emptyFunction() {}
		function emptyFunctionWithReset() {}
		emptyFunctionWithReset.resetWarningCache = emptyFunction;
		module.exports = function() {
			function shim(props, propName, componentName, location, propFullName, secret) {
				if (secret === ReactPropTypesSecret) return;
				var err = /* @__PURE__ */ new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
				err.name = "Invariant Violation";
				throw err;
			}
			shim.isRequired = shim;
			function getShim() {
				return shim;
			}
			var ReactPropTypes = {
				array: shim,
				bigint: shim,
				bool: shim,
				func: shim,
				number: shim,
				object: shim,
				string: shim,
				symbol: shim,
				any: shim,
				arrayOf: getShim,
				element: shim,
				elementType: shim,
				instanceOf: getShim,
				node: shim,
				objectOf: getShim,
				oneOf: getShim,
				oneOfType: getShim,
				shape: getShim,
				exact: getShim,
				checkPropTypes: emptyFunctionWithReset,
				resetWarningCache: emptyFunction
			};
			ReactPropTypes.PropTypes = ReactPropTypes;
			return ReactPropTypes;
		};
	}));
	//#endregion
	//#region node_modules/prop-types/index.js
	var require_prop_types = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = require_factoryWithThrowingShims()();
	}));
	//#endregion
	//#region scripts/vite/shims/create-react-context.js
	var import_browser = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
		/**
		* Use invariant() to assert state which your program assumes to be true.
		*
		* Provide sprintf-style format (only %s is supported) and arguments
		* to provide information about what broke and what you were
		* expecting.
		*
		* The invariant message will be stripped in production, but the invariant
		* will remain to ensure logic does not differ in production.
		*/
		var invariant = function(condition, format, a, b, c, d, e, f) {
			if (!condition) {
				var error;
				if (format === void 0) error = /* @__PURE__ */ new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
				else {
					var args = [
						a,
						b,
						c,
						d,
						e,
						f
					];
					var argIndex = 0;
					error = new Error(format.replace(/%s/g, function() {
						return args[argIndex++];
					}));
					error.name = "Invariant Violation";
				}
				error.framesToPop = 1;
				throw error;
			}
		};
		module.exports = invariant;
	})))());
	var create_react_context_default = react.createContext;
	//#endregion
	//#region node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js
	/**
	* Copyright (c) 2013-present, Facebook, Inc.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	function componentWillMount() {
		var state = this.constructor.getDerivedStateFromProps(this.props, this.state);
		if (state !== null && state !== void 0) this.setState(state);
	}
	function componentWillReceiveProps(nextProps) {
		function updater(prevState) {
			var state = this.constructor.getDerivedStateFromProps(nextProps, prevState);
			return state !== null && state !== void 0 ? state : null;
		}
		this.setState(updater.bind(this));
	}
	function componentWillUpdate(nextProps, nextState) {
		try {
			var prevProps = this.props;
			var prevState = this.state;
			this.props = nextProps;
			this.state = nextState;
			this.__reactInternalSnapshotFlag = true;
			this.__reactInternalSnapshot = this.getSnapshotBeforeUpdate(prevProps, prevState);
		} finally {
			this.props = prevProps;
			this.state = prevState;
		}
	}
	componentWillMount.__suppressDeprecationWarning = true;
	componentWillReceiveProps.__suppressDeprecationWarning = true;
	componentWillUpdate.__suppressDeprecationWarning = true;
	function polyfill(Component) {
		var prototype = Component.prototype;
		if (!prototype || !prototype.isReactComponent) throw new Error("Can only polyfill class components");
		if (typeof Component.getDerivedStateFromProps !== "function" && typeof prototype.getSnapshotBeforeUpdate !== "function") return Component;
		var foundWillMountName = null;
		var foundWillReceivePropsName = null;
		var foundWillUpdateName = null;
		if (typeof prototype.componentWillMount === "function") foundWillMountName = "componentWillMount";
		else if (typeof prototype.UNSAFE_componentWillMount === "function") foundWillMountName = "UNSAFE_componentWillMount";
		if (typeof prototype.componentWillReceiveProps === "function") foundWillReceivePropsName = "componentWillReceiveProps";
		else if (typeof prototype.UNSAFE_componentWillReceiveProps === "function") foundWillReceivePropsName = "UNSAFE_componentWillReceiveProps";
		if (typeof prototype.componentWillUpdate === "function") foundWillUpdateName = "componentWillUpdate";
		else if (typeof prototype.UNSAFE_componentWillUpdate === "function") foundWillUpdateName = "UNSAFE_componentWillUpdate";
		if (foundWillMountName !== null || foundWillReceivePropsName !== null || foundWillUpdateName !== null) {
			var componentName = Component.displayName || Component.name;
			var newApiName = typeof Component.getDerivedStateFromProps === "function" ? "getDerivedStateFromProps()" : "getSnapshotBeforeUpdate()";
			throw Error("Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n" + componentName + " uses " + newApiName + " but also contains the following legacy lifecycles:" + (foundWillMountName !== null ? "\n  " + foundWillMountName : "") + (foundWillReceivePropsName !== null ? "\n  " + foundWillReceivePropsName : "") + (foundWillUpdateName !== null ? "\n  " + foundWillUpdateName : "") + "\n\nThe above lifecycles should be removed. Learn more about this warning here:\nhttps://fb.me/react-async-component-lifecycle-hooks");
		}
		if (typeof Component.getDerivedStateFromProps === "function") {
			prototype.componentWillMount = componentWillMount;
			prototype.componentWillReceiveProps = componentWillReceiveProps;
		}
		if (typeof prototype.getSnapshotBeforeUpdate === "function") {
			if (typeof prototype.componentDidUpdate !== "function") throw new Error("Cannot polyfill getSnapshotBeforeUpdate() for components that do not define componentDidUpdate() on the prototype");
			prototype.componentWillUpdate = componentWillUpdate;
			var componentDidUpdate = prototype.componentDidUpdate;
			prototype.componentDidUpdate = function componentDidUpdatePolyfill(prevProps, prevState, maybeSnapshot) {
				var snapshot = this.__reactInternalSnapshotFlag ? this.__reactInternalSnapshot : maybeSnapshot;
				componentDidUpdate.call(this, prevProps, prevState, snapshot);
			};
		}
		return Component;
	}
	//#endregion
	//#region node_modules/@reach/router/es/lib/utils.js
	var startsWith = function startsWith(string, search) {
		return string.substr(0, search.length) === search;
	};
	var pick = function pick(routes, uri) {
		var match = void 0;
		var default_ = void 0;
		var uriPathname = uri.split("?")[0];
		var uriSegments = segmentize(uriPathname);
		var isRootUri = uriSegments[0] === "";
		var ranked = rankRoutes(routes);
		for (var i = 0, l = ranked.length; i < l; i++) {
			var missed = false;
			var route = ranked[i].route;
			if (route.default) {
				default_ = {
					route,
					params: {},
					uri
				};
				continue;
			}
			var routeSegments = segmentize(route.path);
			var params = {};
			var max = Math.max(uriSegments.length, routeSegments.length);
			var index = 0;
			for (; index < max; index++) {
				var routeSegment = routeSegments[index];
				var uriSegment = uriSegments[index];
				if (isSplat(routeSegment)) {
					var param = routeSegment.slice(1) || "*";
					params[param] = uriSegments.slice(index).map(decodeURIComponent).join("/");
					break;
				}
				if (uriSegment === void 0) {
					missed = true;
					break;
				}
				var dynamicMatch = paramRe.exec(routeSegment);
				if (dynamicMatch && !isRootUri) {
					!(reservedNames.indexOf(dynamicMatch[1]) === -1) && (0, import_browser.default)(false);
					var value = decodeURIComponent(uriSegment);
					params[dynamicMatch[1]] = value;
				} else if (routeSegment !== uriSegment) {
					missed = true;
					break;
				}
			}
			if (!missed) {
				match = {
					route,
					params,
					uri: "/" + uriSegments.slice(0, index).join("/")
				};
				break;
			}
		}
		return match || default_ || null;
	};
	var resolve = function resolve(to, base) {
		if (startsWith(to, "/")) return to;
		var _to$split = to.split("?");
		var toPathname = _to$split[0];
		var toQuery = _to$split[1];
		var basePathname = base.split("?")[0];
		var toSegments = segmentize(toPathname);
		var baseSegments = segmentize(basePathname);
		if (toSegments[0] === "") return addQuery(basePathname, toQuery);
		if (!startsWith(toSegments[0], ".")) {
			var pathname = baseSegments.concat(toSegments).join("/");
			return addQuery((basePathname === "/" ? "" : "/") + pathname, toQuery);
		}
		var allSegments = baseSegments.concat(toSegments);
		var segments = [];
		for (var i = 0, l = allSegments.length; i < l; i++) {
			var segment = allSegments[i];
			if (segment === "..") segments.pop();
			else if (segment !== ".") segments.push(segment);
		}
		return addQuery("/" + segments.join("/"), toQuery);
	};
	var insertParams = function insertParams(path, params) {
		var _path$split = path.split("?");
		var pathBase = _path$split[0];
		var _path$split$ = _path$split[1];
		var query = _path$split$ === void 0 ? "" : _path$split$;
		var constructedPath = "/" + segmentize(pathBase).map(function(segment) {
			var match = paramRe.exec(segment);
			return match ? params[match[1]] : segment;
		}).join("/");
		var _params$location = params.location;
		_params$location = _params$location === void 0 ? {} : _params$location;
		var _params$location$sear = _params$location.search;
		var searchSplit = (_params$location$sear === void 0 ? "" : _params$location$sear).split("?")[1] || "";
		constructedPath = addQuery(constructedPath, query, searchSplit);
		return constructedPath;
	};
	var validateRedirect = function validateRedirect(from, to) {
		var filter = function filter(segment) {
			return isDynamic(segment);
		};
		return segmentize(from).filter(filter).sort().join("/") === segmentize(to).filter(filter).sort().join("/");
	};
	var paramRe = /^:(.+)/;
	var SEGMENT_POINTS = 4;
	var STATIC_POINTS = 3;
	var DYNAMIC_POINTS = 2;
	var SPLAT_PENALTY = 1;
	var ROOT_POINTS = 1;
	var isRootSegment = function isRootSegment(segment) {
		return segment === "";
	};
	var isDynamic = function isDynamic(segment) {
		return paramRe.test(segment);
	};
	var isSplat = function isSplat(segment) {
		return segment && segment[0] === "*";
	};
	var rankRoute = function rankRoute(route, index) {
		return {
			route,
			score: route.default ? 0 : segmentize(route.path).reduce(function(score, segment) {
				score += SEGMENT_POINTS;
				if (isRootSegment(segment)) score += ROOT_POINTS;
				else if (isDynamic(segment)) score += DYNAMIC_POINTS;
				else if (isSplat(segment)) score -= SEGMENT_POINTS + SPLAT_PENALTY;
				else score += STATIC_POINTS;
				return score;
			}, 0),
			index
		};
	};
	var rankRoutes = function rankRoutes(routes) {
		return routes.map(rankRoute).sort(function(a, b) {
			return a.score < b.score ? 1 : a.score > b.score ? -1 : a.index - b.index;
		});
	};
	var segmentize = function segmentize(uri) {
		return uri.replace(/(^\/+|\/+$)/g, "").split("/");
	};
	var addQuery = function addQuery(pathname) {
		for (var _len = arguments.length, query = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) query[_key - 1] = arguments[_key];
		query = query.filter(function(q) {
			return q && q.length > 0;
		});
		return pathname + (query && query.length > 0 ? "?" + query.join("&") : "");
	};
	var reservedNames = ["uri", "path"];
	/**
	* Shallow compares two objects.
	* @param {Object} obj1 The first object to compare.
	* @param {Object} obj2 The second object to compare.
	*/
	var shallowCompare = function shallowCompare(obj1, obj2) {
		var obj1Keys = Object.keys(obj1);
		return obj1Keys.length === Object.keys(obj2).length && obj1Keys.every(function(key) {
			return obj2.hasOwnProperty(key) && obj1[key] === obj2[key];
		});
	};
	//#endregion
	//#region node_modules/@reach/router/es/lib/history.js
	var _extends$1 = Object.assign || function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	var getLocation = function getLocation(source) {
		var _source$location = source.location;
		var search = _source$location.search;
		var hash = _source$location.hash;
		var href = _source$location.href;
		var origin = _source$location.origin;
		var protocol = _source$location.protocol;
		var host = _source$location.host;
		var hostname = _source$location.hostname;
		var port = _source$location.port;
		var pathname = source.location.pathname;
		if (!pathname && href && canUseDOM) pathname = new URL(href).pathname;
		return {
			pathname: encodeURI(decodeURI(pathname)),
			search,
			hash,
			href,
			origin,
			protocol,
			host,
			hostname,
			port,
			state: source.history.state,
			key: source.history.state && source.history.state.key || "initial"
		};
	};
	var createHistory = function createHistory(source, options) {
		var listeners = [];
		var location = getLocation(source);
		var transitioning = false;
		var resolveTransition = function resolveTransition() {};
		return {
			get location() {
				return location;
			},
			get transitioning() {
				return transitioning;
			},
			_onTransitionComplete: function _onTransitionComplete() {
				transitioning = false;
				resolveTransition();
			},
			listen: function listen(listener) {
				listeners.push(listener);
				var popstateListener = function popstateListener() {
					location = getLocation(source);
					listener({
						location,
						action: "POP"
					});
				};
				source.addEventListener("popstate", popstateListener);
				return function() {
					source.removeEventListener("popstate", popstateListener);
					listeners = listeners.filter(function(fn) {
						return fn !== listener;
					});
				};
			},
			navigate: function navigate(to) {
				var _ref = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
				var state = _ref.state;
				var _ref$replace = _ref.replace;
				var replace = _ref$replace === void 0 ? false : _ref$replace;
				if (typeof to === "number") source.history.go(to);
				else {
					state = _extends$1({}, state, { key: Date.now() + "" });
					try {
						if (transitioning || replace) source.history.replaceState(state, null, to);
						else source.history.pushState(state, null, to);
					} catch (e) {
						source.location[replace ? "replace" : "assign"](to);
					}
				}
				location = getLocation(source);
				transitioning = true;
				var transition = new Promise(function(res) {
					return resolveTransition = res;
				});
				listeners.forEach(function(listener) {
					return listener({
						location,
						action: "PUSH"
					});
				});
				return transition;
			}
		};
	};
	var createMemorySource = function createMemorySource() {
		var initialPath = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "/";
		var searchIndex = initialPath.indexOf("?");
		var initialLocation = {
			pathname: searchIndex > -1 ? initialPath.substr(0, searchIndex) : initialPath,
			search: searchIndex > -1 ? initialPath.substr(searchIndex) : ""
		};
		var index = 0;
		var stack = [initialLocation];
		var states = [null];
		return {
			get location() {
				return stack[index];
			},
			addEventListener: function addEventListener(name, fn) {},
			removeEventListener: function removeEventListener(name, fn) {},
			history: {
				get entries() {
					return stack;
				},
				get index() {
					return index;
				},
				get state() {
					return states[index];
				},
				pushState: function pushState(state, _, uri) {
					var _uri$split = uri.split("?");
					var pathname = _uri$split[0];
					var _uri$split$ = _uri$split[1];
					var search = _uri$split$ === void 0 ? "" : _uri$split$;
					index++;
					stack.push({
						pathname,
						search: search.length ? "?" + search : search
					});
					states.push(state);
				},
				replaceState: function replaceState(state, _, uri) {
					var _uri$split2 = uri.split("?");
					var pathname = _uri$split2[0];
					var _uri$split2$ = _uri$split2[1];
					stack[index] = {
						pathname,
						search: _uri$split2$ === void 0 ? "" : _uri$split2$
					};
					states[index] = state;
				},
				go: function go(to) {
					var newIndex = index + to;
					if (newIndex < 0 || newIndex > states.length - 1) return;
					index = newIndex;
				}
			}
		};
	};
	var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
	var globalHistory = createHistory(function getSource() {
		return canUseDOM ? window : createMemorySource();
	}());
	globalHistory.navigate;
	//#endregion
	//#region node_modules/@reach/router/es/index.js
	var _extends = Object.assign || function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	function _objectWithoutProperties(obj, keys) {
		var target = {};
		for (var i in obj) {
			if (keys.indexOf(i) >= 0) continue;
			if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
			target[i] = obj[i];
		}
		return target;
	}
	function _classCallCheck(instance, Constructor) {
		if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
	}
	function _possibleConstructorReturn(self, call) {
		if (!self) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
		return call && (typeof call === "object" || typeof call === "function") ? call : self;
	}
	function _inherits(subClass, superClass) {
		if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
		subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
			value: subClass,
			enumerable: false,
			writable: true,
			configurable: true
		} });
		if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
	}
	var createNamedContext = function createNamedContext(name, defaultValue) {
		var Ctx = create_react_context_default(defaultValue);
		Ctx.displayName = name;
		return Ctx;
	};
	var LocationContext = createNamedContext("Location");
	var Location = function Location(_ref) {
		var children = _ref.children;
		return react.default.createElement(LocationContext.Consumer, null, function(context) {
			return context ? children(context) : react.default.createElement(LocationProvider, null, children);
		});
	};
	var LocationProvider = function(_React$Component) {
		_inherits(LocationProvider, _React$Component);
		function LocationProvider() {
			var _temp;
			var _this;
			var _ret;
			_classCallCheck(this, LocationProvider);
			for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
			return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.state = {
				context: _this.getContext(),
				refs: { unlisten: null }
			}, _temp), _possibleConstructorReturn(_this, _ret);
		}
		LocationProvider.prototype.getContext = function getContext() {
			var _props$history = this.props.history;
			return {
				navigate: _props$history.navigate,
				location: _props$history.location
			};
		};
		LocationProvider.prototype.componentDidCatch = function componentDidCatch(error, info) {
			if (isRedirect(error)) {
				var _navigate = this.props.history.navigate;
				_navigate(error.uri, { replace: true });
			} else throw error;
		};
		LocationProvider.prototype.componentDidUpdate = function componentDidUpdate(prevProps, prevState) {
			if (prevState.context.location !== this.state.context.location) this.props.history._onTransitionComplete();
		};
		LocationProvider.prototype.componentDidMount = function componentDidMount() {
			var _this2 = this;
			var refs = this.state.refs;
			var history = this.props.history;
			history._onTransitionComplete();
			refs.unlisten = history.listen(function() {
				Promise.resolve().then(function() {
					requestAnimationFrame(function() {
						if (!_this2.unmounted) _this2.setState(function() {
							return { context: _this2.getContext() };
						});
					});
				});
			});
		};
		LocationProvider.prototype.componentWillUnmount = function componentWillUnmount() {
			var refs = this.state.refs;
			this.unmounted = true;
			refs.unlisten();
		};
		LocationProvider.prototype.render = function render() {
			var context = this.state.context;
			var children = this.props.children;
			return react.default.createElement(LocationContext.Provider, { value: context }, typeof children === "function" ? children(context) : children || null);
		};
		return LocationProvider;
	}(react.default.Component);
	LocationProvider.defaultProps = { history: globalHistory };
	var BaseContext = createNamedContext("Base", {
		baseuri: "/",
		basepath: "/"
	});
	var Router = function Router(props) {
		return react.default.createElement(BaseContext.Consumer, null, function(baseContext) {
			return react.default.createElement(Location, null, function(locationContext) {
				return react.default.createElement(RouterImpl, _extends({}, baseContext, locationContext, props));
			});
		});
	};
	var RouterImpl = function(_React$PureComponent) {
		_inherits(RouterImpl, _React$PureComponent);
		function RouterImpl() {
			_classCallCheck(this, RouterImpl);
			return _possibleConstructorReturn(this, _React$PureComponent.apply(this, arguments));
		}
		RouterImpl.prototype.render = function render() {
			var _props = this.props;
			var location = _props.location;
			var _navigate2 = _props.navigate;
			var basepath = _props.basepath;
			var primary = _props.primary;
			var children = _props.children;
			_props.baseuri;
			var _props$component = _props.component;
			var component = _props$component === void 0 ? "div" : _props$component;
			var domProps = _objectWithoutProperties(_props, [
				"location",
				"navigate",
				"basepath",
				"primary",
				"children",
				"baseuri",
				"component"
			]);
			var routes = react.default.Children.toArray(children).reduce(function(array, child) {
				var routes = createRoute(basepath)(child);
				return array.concat(routes);
			}, []);
			var pathname = location.pathname;
			var match = pick(routes, pathname);
			if (match) {
				var params = match.params;
				var uri = match.uri;
				var route = match.route;
				var element = match.route.value;
				basepath = route.default ? basepath : route.path.replace(/\*$/, "");
				var props = _extends({}, params, {
					uri,
					location,
					navigate: function navigate(to, options) {
						return _navigate2(resolve(to, uri), options);
					}
				});
				var clone = react.default.cloneElement(element, props, element.props.children ? react.default.createElement(Router, {
					location,
					primary
				}, element.props.children) : void 0);
				var FocusWrapper = primary ? FocusHandler : component;
				var wrapperProps = primary ? _extends({
					uri,
					location,
					component
				}, domProps) : domProps;
				return react.default.createElement(BaseContext.Provider, { value: {
					baseuri: uri,
					basepath
				} }, react.default.createElement(FocusWrapper, wrapperProps, clone));
			} else return null;
		};
		return RouterImpl;
	}(react.default.PureComponent);
	RouterImpl.defaultProps = { primary: true };
	var FocusContext = createNamedContext("Focus");
	var FocusHandler = function FocusHandler(_ref3) {
		var uri = _ref3.uri;
		var location = _ref3.location;
		var component = _ref3.component;
		var domProps = _objectWithoutProperties(_ref3, [
			"uri",
			"location",
			"component"
		]);
		return react.default.createElement(FocusContext.Consumer, null, function(requestFocus) {
			return react.default.createElement(FocusHandlerImpl, _extends({}, domProps, {
				component,
				requestFocus,
				uri,
				location
			}));
		});
	};
	var initialRender = true;
	var focusHandlerCount = 0;
	var FocusHandlerImpl = function(_React$Component2) {
		_inherits(FocusHandlerImpl, _React$Component2);
		function FocusHandlerImpl() {
			var _temp2;
			var _this4;
			var _ret2;
			_classCallCheck(this, FocusHandlerImpl);
			for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) args[_key2] = arguments[_key2];
			return _ret2 = (_temp2 = (_this4 = _possibleConstructorReturn(this, _React$Component2.call.apply(_React$Component2, [this].concat(args))), _this4), _this4.state = {}, _this4.requestFocus = function(node) {
				if (!_this4.state.shouldFocus && node) node.focus();
			}, _temp2), _possibleConstructorReturn(_this4, _ret2);
		}
		FocusHandlerImpl.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
			if (prevState.uri == null) return _extends({ shouldFocus: true }, nextProps);
			else {
				var myURIChanged = nextProps.uri !== prevState.uri;
				var navigatedUpToMe = prevState.location.pathname !== nextProps.location.pathname && nextProps.location.pathname === nextProps.uri;
				return _extends({ shouldFocus: myURIChanged || navigatedUpToMe }, nextProps);
			}
		};
		FocusHandlerImpl.prototype.componentDidMount = function componentDidMount() {
			focusHandlerCount++;
			this.focus();
		};
		FocusHandlerImpl.prototype.componentWillUnmount = function componentWillUnmount() {
			focusHandlerCount--;
			if (focusHandlerCount === 0) initialRender = true;
		};
		FocusHandlerImpl.prototype.componentDidUpdate = function componentDidUpdate(prevProps, prevState) {
			if (prevProps.location !== this.props.location && this.state.shouldFocus) this.focus();
		};
		FocusHandlerImpl.prototype.focus = function focus() {
			var requestFocus = this.props.requestFocus;
			if (requestFocus) requestFocus(this.node);
			else if (initialRender) initialRender = false;
			else if (this.node) {
				if (!this.node.contains(document.activeElement)) this.node.focus();
			}
		};
		FocusHandlerImpl.prototype.render = function render() {
			var _this5 = this;
			var _props2 = this.props;
			_props2.children;
			var style = _props2.style;
			_props2.requestFocus;
			var _props2$component = _props2.component;
			var Comp = _props2$component === void 0 ? "div" : _props2$component;
			_props2.uri;
			_props2.location;
			var domProps = _objectWithoutProperties(_props2, [
				"children",
				"style",
				"requestFocus",
				"component",
				"uri",
				"location"
			]);
			return react.default.createElement(Comp, _extends({
				style: _extends({ outline: "none" }, style),
				tabIndex: "-1",
				ref: function ref(n) {
					return _this5.node = n;
				}
			}, domProps), react.default.createElement(FocusContext.Provider, { value: this.requestFocus }, this.props.children));
		};
		return FocusHandlerImpl;
	}(react.default.Component);
	polyfill(FocusHandlerImpl);
	var k = function k() {};
	var forwardRef = react.default.forwardRef;
	if (typeof forwardRef === "undefined") forwardRef = function forwardRef(C) {
		return C;
	};
	var Link$1 = forwardRef(function(_ref4, ref) {
		var innerRef = _ref4.innerRef;
		var props = _objectWithoutProperties(_ref4, ["innerRef"]);
		return react.default.createElement(BaseContext.Consumer, null, function(_ref5) {
			_ref5.basepath;
			var baseuri = _ref5.baseuri;
			return react.default.createElement(Location, null, function(_ref6) {
				var location = _ref6.location;
				var navigate = _ref6.navigate;
				var to = props.to;
				var state = props.state;
				var replace = props.replace;
				var _props$getProps = props.getProps;
				var getProps = _props$getProps === void 0 ? k : _props$getProps;
				var anchorProps = _objectWithoutProperties(props, [
					"to",
					"state",
					"replace",
					"getProps"
				]);
				var href = resolve(to, baseuri);
				var encodedHref = encodeURI(href);
				var isCurrent = location.pathname === encodedHref;
				var isPartiallyCurrent = startsWith(location.pathname, encodedHref);
				return react.default.createElement("a", _extends({
					ref: ref || innerRef,
					"aria-current": isCurrent ? "page" : void 0
				}, anchorProps, getProps({
					isCurrent,
					isPartiallyCurrent,
					href,
					location
				}), {
					href,
					onClick: function onClick(event) {
						if (anchorProps.onClick) anchorProps.onClick(event);
						if (shouldNavigate(event)) {
							event.preventDefault();
							var shouldReplace = replace;
							if (typeof replace !== "boolean" && isCurrent) {
								var _location$state = _extends({}, location.state);
								_location$state.key;
								var restState = _objectWithoutProperties(_location$state, ["key"]);
								shouldReplace = shallowCompare(_extends({}, state), restState);
							}
							navigate(href, {
								state,
								replace: shouldReplace
							});
						}
					}
				}));
			});
		});
	});
	Link$1.displayName = "Link";
	function RedirectRequest(uri) {
		this.uri = uri;
	}
	var isRedirect = function isRedirect(o) {
		return o instanceof RedirectRequest;
	};
	var redirectTo = function redirectTo(to) {
		throw new RedirectRequest(to);
	};
	var RedirectImpl = function(_React$Component3) {
		_inherits(RedirectImpl, _React$Component3);
		function RedirectImpl() {
			_classCallCheck(this, RedirectImpl);
			return _possibleConstructorReturn(this, _React$Component3.apply(this, arguments));
		}
		RedirectImpl.prototype.componentDidMount = function componentDidMount() {
			var _props3 = this.props;
			var navigate = _props3.navigate;
			var to = _props3.to;
			_props3.from;
			var _props3$replace = _props3.replace;
			var replace = _props3$replace === void 0 ? true : _props3$replace;
			var state = _props3.state;
			_props3.noThrow;
			var baseuri = _props3.baseuri;
			var props = _objectWithoutProperties(_props3, [
				"navigate",
				"to",
				"from",
				"replace",
				"state",
				"noThrow",
				"baseuri"
			]);
			Promise.resolve().then(function() {
				navigate(insertParams(resolve(to, baseuri), props), {
					replace,
					state
				});
			});
		};
		RedirectImpl.prototype.render = function render() {
			var _props4 = this.props;
			_props4.navigate;
			var to = _props4.to;
			_props4.from;
			_props4.replace;
			_props4.state;
			var noThrow = _props4.noThrow;
			var baseuri = _props4.baseuri;
			var props = _objectWithoutProperties(_props4, [
				"navigate",
				"to",
				"from",
				"replace",
				"state",
				"noThrow",
				"baseuri"
			]);
			var resolvedTo = resolve(to, baseuri);
			if (!noThrow) redirectTo(insertParams(resolvedTo, props));
			return null;
		};
		return RedirectImpl;
	}(react.default.Component);
	var Redirect = function Redirect(props) {
		return react.default.createElement(BaseContext.Consumer, null, function(_ref7) {
			var baseuri = _ref7.baseuri;
			return react.default.createElement(Location, null, function(locationContext) {
				return react.default.createElement(RedirectImpl, _extends({}, locationContext, { baseuri }, props));
			});
		});
	};
	var useLocation = function useLocation() {
		var context = (0, react.useContext)(LocationContext);
		if (!context) throw new Error("useLocation hook was used but a LocationContext.Provider was not found in the parent tree. Make sure this is used in a component that is a child of Router");
		return context.location;
	};
	var useNavigate = function useNavigate() {
		var context = (0, react.useContext)(LocationContext);
		if (!context) throw new Error("useNavigate hook was used but a LocationContext.Provider was not found in the parent tree. Make sure this is used in a component that is a child of Router");
		return context.navigate;
	};
	var stripSlashes = function stripSlashes(str) {
		return str.replace(/(^\/+|\/+$)/g, "");
	};
	var createRoute = function createRoute(basepath) {
		return function(element) {
			if (!element) return null;
			if (element.type === react.default.Fragment && element.props.children) return react.default.Children.map(element.props.children, createRoute(basepath));
			!(element.props.path || element.props.default || element.type === Redirect) && (0, import_browser.default)(false);
			element.type === Redirect && (!element.props.from || !element.props.to) && (0, import_browser.default)(false);
			element.type === Redirect && !validateRedirect(element.props.from, element.props.to) && (0, import_browser.default)(false);
			if (element.props.default) return {
				value: element,
				default: true
			};
			var elementPath = element.type === Redirect ? element.props.from : element.props.path;
			var path = elementPath === "/" ? basepath : stripSlashes(basepath) + "/" + stripSlashes(elementPath);
			return {
				value: element,
				default: element.props.default,
				path: element.props.children ? stripSlashes(path) + "/*" : path
			};
		};
	};
	var shouldNavigate = function shouldNavigate(event) {
		return !event.defaultPrevented && event.button === 0 && !(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/context/notices-context.js
	var import_prop_types = /* @__PURE__ */ __toESM(require_prop_types());
	var { createContext: createContext$1, useState: useState$18, useCallback: useCallback$8, useContext: useContext$1 } = react.default;
	var NOTICE_TYPE_SUCCESS = "success";
	var NOTICE_TYPE_ERROR = "error";
	var NoticesContext = createContext$1({ notices: [] });
	function useNoticesContext() {
		return useContext$1(NoticesContext);
	}
	function NoticesProvider(props) {
		const [notices, setNotices] = useState$18([]);
		const dismiss = useCallback$8((key) => {
			setNotices((prev) => prev.filter((notice) => notice.key !== key));
		}, []);
		const notify = useCallback$8(({ message, undoAction, type, dismissible = true }) => {
			if (!message) return;
			const key = Date.now() + Math.random();
			setNotices((prev) => [{
				key,
				message,
				type,
				undoAction,
				dismissible
			}, ...prev]);
			if (props.dismissTimeout) setTimeout(() => dismiss(key), props.dismissTimeout);
		}, []);
		const notifyError = useCallback$8((message) => {
			notify({
				message,
				type: NOTICE_TYPE_ERROR
			});
		}, [notify]);
		const notifySuccess = useCallback$8((message, undoAction) => {
			notify({
				message,
				undoAction,
				type: NOTICE_TYPE_SUCCESS
			});
		}, [notify]);
		return /* @__PURE__ */ react.default.createElement(NoticesContext.Provider, { value: {
			notices,
			notify,
			notifyError,
			notifySuccess,
			dismiss
		} }, props.children);
	}
	NoticesProvider.propTypes = {
		children: import_prop_types.default.any,
		dismissTimeout: import_prop_types.default.number
	};
	NoticesProvider.defaultProps = { dismissTimeout: 4e3 };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/context/settings-context.js
	var { createContext, useContext } = react.default;
	var SettingsContext = createContext({});
	function useSettingsContext() {
		return useContext(SettingsContext);
	}
	function SettingsProvider(props) {
		return /* @__PURE__ */ react.default.createElement(SettingsContext.Provider, { value: props.value }, props.children);
	}
	SettingsProvider.propTypes = {
		children: import_prop_types.default.any,
		value: import_prop_types.default.object.isRequired
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/notice.js
	function Notice(props) {
		return /* @__PURE__ */ react.default.createElement("div", { className: `notice notice-${props.model.type} ${props.model.dismissible ? "is-dismissible" : ""}` }, /* @__PURE__ */ react.default.createElement("p", null, props.model.message, props.model.undoAction && /* @__PURE__ */ react.default.createElement(react.default.Fragment, null, "\xA0", /* @__PURE__ */ react.default.createElement("a", {
			href: "#",
			onClick: (e) => {
				e.preventDefault();
				props.model.undoAction();
			}
		}, (0, _wordpress_i18n.__)("Undo", "elementor-pro")))), props.model.dismissible && /* @__PURE__ */ react.default.createElement("button", {
			type: "button",
			className: "notice-dismiss",
			onClick: props.dismiss
		}, /* @__PURE__ */ react.default.createElement("span", { className: "screen-reader-text" }, (0, _wordpress_i18n.__)("Dismiss this notice.", "elementor-pro"))));
	}
	Notice.propTypes = {
		model: import_prop_types.default.shape({
			key: import_prop_types.default.number.isRequired,
			message: import_prop_types.default.string.isRequired,
			type: import_prop_types.default.oneOf([NOTICE_TYPE_SUCCESS, NOTICE_TYPE_ERROR]).isRequired,
			dismissible: import_prop_types.default.bool,
			undoAction: import_prop_types.default.func
		}),
		dismiss: import_prop_types.default.func
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/notices.js
	function Notices() {
		const { notices, dismiss } = useNoticesContext();
		return notices.map((notice) => /* @__PURE__ */ react.default.createElement(Notice, {
			key: notice.key,
			model: notice,
			dismiss: () => dismiss(notice.key)
		}));
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/wp-table/header.js
	function Header(props) {
		return /* @__PURE__ */ react.default.createElement("thead", null, props.children);
	}
	Header.propTypes = { children: import_prop_types.default.any };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/wp-table/body.js
	function Body(props) {
		return /* @__PURE__ */ react.default.createElement("tbody", { id: "the-list" }, props.children);
	}
	Body.propTypes = { children: import_prop_types.default.any };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/wp-table/footer.js
	function Footer(props) {
		return /* @__PURE__ */ react.default.createElement("tfoot", null, props.children);
	}
	Footer.propTypes = { children: import_prop_types.default.any };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/wp-table/row.js
	function Row(props) {
		return /* @__PURE__ */ react.default.createElement("tr", {
			style: props.style,
			className: props.className
		}, props.children);
	}
	Row.propTypes = {
		children: import_prop_types.default.any,
		style: import_prop_types.default.object,
		className: import_prop_types.default.string
	};
	Row.defaultProps = {
		style: {},
		className: ""
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/wp-table/cell.js
	function Cell(props) {
		const Component = props.component;
		return /* @__PURE__ */ react.default.createElement(Component, {
			className: props.className,
			style: props.style,
			"data-colname": props.colName,
			colSpan: props.colSpan
		}, props.children);
	}
	Cell.propTypes = {
		component: import_prop_types.default.string,
		children: import_prop_types.default.any,
		className: import_prop_types.default.string,
		style: import_prop_types.default.object,
		colName: import_prop_types.default.string,
		colSpan: import_prop_types.default.number
	};
	Cell.defaultProps = {
		component: "td",
		className: ""
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/wp-table/orderable-cell.js
	var __defProp$20 = Object.defineProperty;
	var __defProps$7 = Object.defineProperties;
	var __getOwnPropDescs$7 = Object.getOwnPropertyDescriptors;
	var __getOwnPropSymbols$20 = Object.getOwnPropertySymbols;
	var __hasOwnProp$20 = Object.prototype.hasOwnProperty;
	var __propIsEnum$20 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$20 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$20(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$20 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$20.call(b, prop)) __defNormalProp$20(a, prop, b[prop]);
		if (__getOwnPropSymbols$20) {
			for (var prop of __getOwnPropSymbols$20(b)) if (__propIsEnum$20.call(b, prop)) __defNormalProp$20(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var __spreadProps$7 = /* @__PURE__ */ __name((a, b) => __defProps$7(a, __getOwnPropDescs$7(b)), "__spreadProps");
	function OrderableCell(props) {
		const className = `${props.className} sortable ${props.order.current.by === props.order.key && `sorted ${props.order.current.direction}`}`;
		return /* @__PURE__ */ react.default.createElement(Cell, {
			component: props.component,
			style: props.style,
			className
		}, /* @__PURE__ */ react.default.createElement("a", {
			href: "#",
			onClick: () => props.order.onChange({
				by: props.order.key,
				direction: props.order.key === props.order.current.by && "asc" === props.order.current.direction ? "desc" : "asc"
			})
		}, /* @__PURE__ */ react.default.createElement("span", null, props.children), /* @__PURE__ */ react.default.createElement("span", { className: "sorting-indicator" })));
	}
	OrderableCell.propTypes = __spreadProps$7(__spreadValues$20({}, Cell.propTypes), { order: import_prop_types.default.shape({
		key: import_prop_types.default.string.isRequired,
		current: import_prop_types.default.shape({
			by: import_prop_types.default.string,
			direction: import_prop_types.default.oneOf(["asc", "desc"])
		}).isRequired,
		onChange: import_prop_types.default.func.isRequired
	}).isRequired });
	OrderableCell.defaultProps = __spreadProps$7(__spreadValues$20({}, Cell.defaultProps), { component: "th" });
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/wp-table/row-actions.js
	var __defProp$19 = Object.defineProperty;
	var __getOwnPropSymbols$19 = Object.getOwnPropertySymbols;
	var __hasOwnProp$19 = Object.prototype.hasOwnProperty;
	var __propIsEnum$19 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$19 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$19(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$19 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$19.call(b, prop)) __defNormalProp$19(a, prop, b[prop]);
		if (__getOwnPropSymbols$19) {
			for (var prop of __getOwnPropSymbols$19(b)) if (__propIsEnum$19.call(b, prop)) __defNormalProp$19(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	function RowActions(props) {
		return /* @__PURE__ */ react.default.createElement("div", {
			className: "row-actions",
			style: { fontWeight: "normal" }
		}, props.actions.map((action, index) => {
			const isLastAction = index + 1 === props.actions.length;
			const ActionComponent = action.component || "a";
			return /* @__PURE__ */ react.default.createElement("span", {
				key: action.key,
				className: action.className
			}, /* @__PURE__ */ react.default.createElement(ActionComponent, __spreadValues$19({
				href: "#",
				"aria-label": action.label,
				onClick: (e) => {
					e.preventDefault();
					action.onApply(props.item);
				}
			}, action.props ? action.props(props.item) : {}), action.label), !isLastAction && /* @__PURE__ */ react.default.createElement("span", null, "\xA0|\xA0"));
		}));
	}
	RowActions.propTypes = {
		actions: import_prop_types.default.arrayOf(import_prop_types.default.shape({
			key: import_prop_types.default.string.isRequired,
			label: import_prop_types.default.string.isRequired,
			onApply: import_prop_types.default.func,
			className: import_prop_types.default.string,
			props: import_prop_types.default.func,
			component: import_prop_types.default.any
		})),
		item: import_prop_types.default.object
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/wp-table/index.js
	function WpTable(props) {
		return /* @__PURE__ */ react.default.createElement("table", {
			className: `wp-list-table widefat fixed table-view-list ${props.className}`,
			style: props.style
		}, props.children);
	}
	WpTable.propTypes = {
		children: import_prop_types.default.any,
		style: import_prop_types.default.object,
		className: import_prop_types.default.string
	};
	WpTable.defaultProps = { className: "" };
	WpTable.Header = Header;
	WpTable.Body = Body;
	WpTable.Footer = Footer;
	WpTable.Row = Row;
	WpTable.Cell = Cell;
	WpTable.OrderableCell = OrderableCell;
	WpTable.RowActions = RowActions;
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/post-box.js
	function PostBox(props) {
		return /* @__PURE__ */ react.default.createElement("div", { className: "postbox" }, /* @__PURE__ */ react.default.createElement("div", { className: "postbox-header" }, props.header), /* @__PURE__ */ react.default.createElement("div", { className: "inner" }, props.children));
	}
	PostBox.propTypes = {
		header: import_prop_types.default.oneOfType([
			import_prop_types.default.string,
			import_prop_types.default.node,
			import_prop_types.default.arrayOf(import_prop_types.default.node)
		]),
		children: import_prop_types.default.oneOfType([import_prop_types.default.node, import_prop_types.default.arrayOf(import_prop_types.default.node)])
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/utils/date.js
	var momentLocale = moment.localeData();
	function formatToLocalDate(dateString) {
		return wp.date.format(momentLocale.longDateFormat("LL"), dateString);
	}
	function formatToLocalTime(dateString) {
		return wp.date.format(momentLocale.longDateFormat("LT"), dateString);
	}
	function formatToLocalDateTime(dateString) {
		return `${formatToLocalDate(dateString)} ${formatToLocalTime(dateString)}`;
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/notice-messages.js
	var generalError = () => (0, _wordpress_i18n.__)("Something went wrong, please try again later.", "elementor-pro");
	var notice_messages_default = {
		trashed: {
			success: (count = 1) => (0, _wordpress_i18n.sprintf)((0, _wordpress_i18n._n)("%d submission moved to Trash.", "%d submissions moved to Trash.", count, "elementor-pro"), count),
			error: generalError
		},
		deleted: {
			success: (count = 1) => (0, _wordpress_i18n.sprintf)((0, _wordpress_i18n._n)("%d submission permanently deleted.", "%d submissions permanently deleted.", count, "elementor-pro"), count),
			error: generalError
		},
		updated: {
			success: (count = 1) => (0, _wordpress_i18n.sprintf)((0, _wordpress_i18n._n)("%d submission has been successfully updated.", "%d submissions have been successfully updated.", count, "elementor-pro"), count),
			error: generalError
		},
		restored: {
			success: (count = 1) => (0, _wordpress_i18n.sprintf)((0, _wordpress_i18n._n)("%d submission restored from Trash.", "%d submissions restored from Trash.", count, "elementor-pro"), count),
			error: generalError
		},
		markedAsRead: {
			success: () => null,
			error: generalError
		},
		markedAsUnread: {
			success: () => null,
			error: generalError
		},
		actionLogs: {
			success: () => (0, _wordpress_i18n.__)("Action completed successfully.", "elementor-pro"),
			failed: () => (0, _wordpress_i18n.__)("Action failed to run, please check your integration.", "elementor-pro")
		}
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/form-actions-log.js
	function FormActionsLog(props) {
		return /* @__PURE__ */ react.default.createElement(PostBox, { header: /* @__PURE__ */ react.default.createElement("h2", null, (0, _wordpress_i18n.__)("Actions Log", "elementor-pro")) }, 0 === props.actions.length && /* @__PURE__ */ react.default.createElement("div", { className: "inside" }, /* @__PURE__ */ react.default.createElement("p", { style: { margin: 0 } }, " ", (0, _wordpress_i18n.__)("No form actions.", "elementor-pro"), " ")), props.actions.map((actionLog) => {
			return /* @__PURE__ */ react.default.createElement("div", {
				className: `inside e-form-submissions-action-log e-form-submissions-action-log--${"success" === actionLog.status ? "success" : "error"}`,
				key: actionLog.name
			}, /* @__PURE__ */ react.default.createElement("p", null, /* @__PURE__ */ react.default.createElement("strong", { className: "e-form-submissions-action-log__label" }, " ", actionLog.label, " "), /* @__PURE__ */ react.default.createElement("i", { className: `${"success" === actionLog.status ? "eicon-success eicon-check-circle-o" : "eicon-error eicon-warning"} e-form-submissions-action-log__icon` }), /* @__PURE__ */ react.default.createElement("span", { className: "e-form-submissions-action-log__date" }, " ", formatToLocalDateTime(actionLog.created_at), " ")), /* @__PURE__ */ react.default.createElement("p", { className: `e-form-submissions-action-log__message` }, actionLog.log || notice_messages_default.actionLogs[actionLog.status]()));
		}));
	}
	FormActionsLog.propTypes = { actions: import_prop_types.default.arrayOf(import_prop_types.default.shape({
		status: import_prop_types.default.oneOf(["success", "failed"]),
		name: import_prop_types.default.string,
		label: import_prop_types.default.string,
		created_at: import_prop_types.default.string,
		log: import_prop_types.default.string
	})).isRequired };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/hooks/use-data-action.js
	var { useRef: useRef$4, useCallback: useCallback$7, useState: useState$17, useMemo: useMemo$12 } = react.default;
	var STATUS_IDLE = "idle";
	var STATUS_LOADING = "loading";
	var STATUS_SUCCESS = "success";
	var STATUS_ERROR = "error";
	function useDataAction(action, deps = []) {
		const abortControllerRef = useRef$4();
		const [status, setStatus] = useState$17(STATUS_IDLE);
		return [useCallback$7((...args) => {
			if (abortControllerRef.current) abortControllerRef.current.abort();
			abortControllerRef.current = new AbortController();
			setStatus(STATUS_LOADING);
			return action(args, {
				abortController: abortControllerRef.current,
				status
			}).then((result) => {
				setStatus(STATUS_SUCCESS);
				return result;
			}).catch((error) => {
				setStatus(STATUS_ERROR);
				return Promise.reject(error);
			});
		}, [useMemo$12(() => [...deps, status], [deps, status])]), {
			abortController: abortControllerRef.current,
			status
		}];
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/text.js
	var __defProp$18 = Object.defineProperty;
	var __getOwnPropSymbols$18 = Object.getOwnPropertySymbols;
	var __hasOwnProp$18 = Object.prototype.hasOwnProperty;
	var __propIsEnum$18 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$18 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$18(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$18 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$18.call(b, prop)) __defNormalProp$18(a, prop, b[prop]);
		if (__getOwnPropSymbols$18) {
			for (var prop of __getOwnPropSymbols$18(b)) if (__propIsEnum$18.call(b, prop)) __defNormalProp$18(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var { useState: useState$16, useMemo: useMemo$11 } = react.default;
	var availableInputTypes = {
		email: "email",
		date: "date",
		time: "time",
		tel: "tel",
		url: "url",
		number: "number",
		text: "text"
	};
	var defaultInputType = availableInputTypes.text;
	function Text(props) {
		const [localValue, setLocalValue] = useState$16(props.value);
		const inputType = useMemo$11(() => {
			var _a;
			return Object.prototype.hasOwnProperty.call(availableInputTypes, (_a = props.field) == null ? void 0 : _a.type) ? availableInputTypes[props.field.type] : defaultInputType;
		}, [props.field]);
		return props.isEditMode ? /* @__PURE__ */ react.default.createElement("input", {
			type: inputType,
			value: localValue,
			onChange: ({ target: { value } }) => {
				setLocalValue(value);
				props.onChange(value);
			}
		}) : props.children || props.value;
	}
	Text.propTypes = __spreadValues$18({ children: import_prop_types.default.oneOfType([import_prop_types.default.node, import_prop_types.default.string]) }, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/email.js
	var __defProp$17 = Object.defineProperty;
	var __getOwnPropSymbols$17 = Object.getOwnPropertySymbols;
	var __hasOwnProp$17 = Object.prototype.hasOwnProperty;
	var __propIsEnum$17 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$17 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$17(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$17 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$17.call(b, prop)) __defNormalProp$17(a, prop, b[prop]);
		if (__getOwnPropSymbols$17) {
			for (var prop of __getOwnPropSymbols$17(b)) if (__propIsEnum$17.call(b, prop)) __defNormalProp$17(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	function Email(props) {
		return /* @__PURE__ */ react.default.createElement(Text, {
			value: props.value,
			isEditMode: props.isEditMode,
			onChange: props.onChange,
			field: props.field
		}, props.value && /* @__PURE__ */ react.default.createElement("a", { href: `mailto:${props.value}` }, props.value));
	}
	Email.propTypes = __spreadValues$17({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/tel.js
	var __defProp$16 = Object.defineProperty;
	var __getOwnPropSymbols$16 = Object.getOwnPropertySymbols;
	var __hasOwnProp$16 = Object.prototype.hasOwnProperty;
	var __propIsEnum$16 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$16 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$16(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$16 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$16.call(b, prop)) __defNormalProp$16(a, prop, b[prop]);
		if (__getOwnPropSymbols$16) {
			for (var prop of __getOwnPropSymbols$16(b)) if (__propIsEnum$16.call(b, prop)) __defNormalProp$16(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	function Tel(props) {
		return /* @__PURE__ */ react.default.createElement(Text, {
			value: props.value,
			isEditMode: props.isEditMode,
			onChange: props.onChange,
			field: props.field
		}, props.value && /* @__PURE__ */ react.default.createElement("a", { href: `tel:${props.value}` }, props.value));
	}
	Tel.propTypes = __spreadValues$16({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/url.js
	var __defProp$15 = Object.defineProperty;
	var __getOwnPropSymbols$15 = Object.getOwnPropertySymbols;
	var __hasOwnProp$15 = Object.prototype.hasOwnProperty;
	var __propIsEnum$15 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$15 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$15(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$15 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$15.call(b, prop)) __defNormalProp$15(a, prop, b[prop]);
		if (__getOwnPropSymbols$15) {
			for (var prop of __getOwnPropSymbols$15(b)) if (__propIsEnum$15.call(b, prop)) __defNormalProp$15(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	function Url(props) {
		return /* @__PURE__ */ react.default.createElement(Text, {
			value: props.value,
			isEditMode: props.isEditMode,
			onChange: props.onChange,
			field: props.field
		}, props.value && /* @__PURE__ */ react.default.createElement("a", {
			href: props.value,
			target: "_blank",
			rel: "noreferrer"
		}, props.value));
	}
	Url.propTypes = __spreadValues$15({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/hooks/use-form-field-options.js
	var { useMemo: useMemo$10 } = react.default;
	function useFormFieldOptions(options = []) {
		return useMemo$10(() => {
			if (!Array.isArray(options)) return [];
			return options.map((rawOption) => {
				if ("string" === typeof rawOption) {
					const [label, value] = rawOption.split("|");
					return {
						label,
						value: value === void 0 ? label : value
					};
				}
				if (rawOption && "label" in rawOption && "value" in rawOption) return rawOption;
				return null;
			}).filter(Boolean);
		}, [options]);
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/radio.js
	var __defProp$14 = Object.defineProperty;
	var __getOwnPropSymbols$14 = Object.getOwnPropertySymbols;
	var __hasOwnProp$14 = Object.prototype.hasOwnProperty;
	var __propIsEnum$14 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$14 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$14(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$14 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$14.call(b, prop)) __defNormalProp$14(a, prop, b[prop]);
		if (__getOwnPropSymbols$14) {
			for (var prop of __getOwnPropSymbols$14(b)) if (__propIsEnum$14.call(b, prop)) __defNormalProp$14(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var { useState: useState$15 } = react.default;
	function Radio(props) {
		const [localValue, setLocalValue] = useState$15(props.value);
		return useFormFieldOptions(props.field.options).map((option) => {
			const id = props.field.id + "-" + option.value;
			return /* @__PURE__ */ react.default.createElement("label", {
				className: "e-form-submissions-value-label",
				key: option.value,
				htmlFor: id
			}, /* @__PURE__ */ react.default.createElement("input", {
				id,
				type: "radio",
				value: option.value,
				checked: props.isEditMode ? option.value === localValue : option.value === props.value,
				onChange: () => {
					setLocalValue(option.value);
					props.onChange(option.value);
				},
				disabled: !props.isEditMode
			}), option.label);
		});
	}
	Radio.propTypes = __spreadValues$14({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/select.js
	var __defProp$13 = Object.defineProperty;
	var __getOwnPropSymbols$13 = Object.getOwnPropertySymbols;
	var __hasOwnProp$13 = Object.prototype.hasOwnProperty;
	var __propIsEnum$13 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$13 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$13(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$13 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$13.call(b, prop)) __defNormalProp$13(a, prop, b[prop]);
		if (__getOwnPropSymbols$13) {
			for (var prop of __getOwnPropSymbols$13(b)) if (__propIsEnum$13.call(b, prop)) __defNormalProp$13(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var { useState: useState$14 } = react.default;
	function Select(props) {
		const value = props.field.is_multiple ? props.value.split(", ") : props.value;
		const [localValue, setLocalValue] = useState$14(value);
		const options = useFormFieldOptions(props.field.options);
		return /* @__PURE__ */ react.default.createElement("select", {
			value: props.isEditMode ? localValue : value,
			multiple: props.field.is_multiple,
			onChange: (e) => {
				const selectedValues = Array.from(e.target.selectedOptions, (option) => option.value);
				setLocalValue(props.field.is_multiple ? selectedValues : selectedValues[0]);
				props.onChange(selectedValues.join(", "));
			},
			disabled: !props.isEditMode
		}, options.map((option) => /* @__PURE__ */ react.default.createElement("option", {
			value: option.value,
			key: option.value
		}, option.label)));
	}
	Select.propTypes = __spreadValues$13({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/hooks/use-watch.js
	var { useEffect: useEffect$6, useRef: useRef$3 } = react.default;
	function useWatch(callback, deps) {
		const isFirstRender = useRef$3(true);
		useEffect$6(() => {
			if (isFirstRender.current) {
				isFirstRender.current = false;
				return;
			}
			callback();
		}, deps);
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/checkbox.js
	var __defProp$12 = Object.defineProperty;
	var __getOwnPropSymbols$12 = Object.getOwnPropertySymbols;
	var __hasOwnProp$12 = Object.prototype.hasOwnProperty;
	var __propIsEnum$12 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$12 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$12(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$12 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$12.call(b, prop)) __defNormalProp$12(a, prop, b[prop]);
		if (__getOwnPropSymbols$12) {
			for (var prop of __getOwnPropSymbols$12(b)) if (__propIsEnum$12.call(b, prop)) __defNormalProp$12(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var { useState: useState$13, useMemo: useMemo$9 } = react.default;
	function SingleCheckbox(props) {
		const [localValue, setLocalValue] = useState$13(props.value), id = props.field.id + "-" + props.value;
		return /* @__PURE__ */ react.default.createElement("label", {
			className: "e-form-submissions-value-label",
			htmlFor: id
		}, /* @__PURE__ */ react.default.createElement("input", {
			id,
			type: "checkbox",
			value: props.value || "on",
			checked: props.isEditMode ? !!localValue : !!props.value,
			onChange: (e) => {
				const value = e.target.checked ? props.value || "on" : "";
				setLocalValue(value);
				props.onChange(value);
			},
			disabled: !props.isEditMode
		}), props.value && "on" !== props.value ? props.value : null);
	}
	SingleCheckbox.propTypes = __spreadValues$12({}, basePropTypes);
	function MultiCheckbox(props) {
		const value = useMemo$9(() => props.value.split(", "), [props.value]), [localValue, setLocalValue] = useState$13(value);
		useWatch(() => props.onChange(localValue.join(", ")), [localValue]);
		return useFormFieldOptions(props.field.options).map((option) => {
			const id = props.field.id + "-" + option.value;
			return /* @__PURE__ */ react.default.createElement("label", {
				className: "e-form-submissions-value-label",
				key: option.value,
				htmlFor: id
			}, /* @__PURE__ */ react.default.createElement("input", {
				id,
				type: "checkbox",
				value: option.value,
				checked: props.isEditMode ? localValue.includes(option.value) : value.includes(option.value),
				onChange: (e) => {
					const checked = e.target.checked;
					setLocalValue((prev) => {
						if (!checked) prev = prev.filter((item) => item !== option.value);
						else prev = [...prev, option.value];
						return prev;
					});
				},
				disabled: !props.isEditMode
			}), option.label);
		});
	}
	MultiCheckbox.propTypes = __spreadValues$12({}, basePropTypes);
	function Checkbox$1(props) {
		var _a;
		return ((_a = props.field.options) == null ? void 0 : _a.length) ? /* @__PURE__ */ react.default.createElement(MultiCheckbox, __spreadValues$12({}, props)) : /* @__PURE__ */ react.default.createElement(SingleCheckbox, __spreadValues$12({}, props));
	}
	__name(Checkbox$1, "Checkbox");
	Checkbox$1.propTypes = __spreadValues$12({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/acceptance.js
	var __defProp$11 = Object.defineProperty;
	var __getOwnPropSymbols$11 = Object.getOwnPropertySymbols;
	var __hasOwnProp$11 = Object.prototype.hasOwnProperty;
	var __propIsEnum$11 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$11 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$11(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$11 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$11.call(b, prop)) __defNormalProp$11(a, prop, b[prop]);
		if (__getOwnPropSymbols$11) {
			for (var prop of __getOwnPropSymbols$11(b)) if (__propIsEnum$11.call(b, prop)) __defNormalProp$11(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var { useState: useState$12 } = react.default;
	function Acceptance(props) {
		const [localValue, setLocalValue] = useState$12(props.value), id = props.field.id + "-" + props.value;
		return /* @__PURE__ */ react.default.createElement("label", {
			className: "e-form-submissions-value-label",
			htmlFor: id
		}, /* @__PURE__ */ react.default.createElement("input", {
			id,
			type: "checkbox",
			value: "on",
			checked: props.isEditMode ? "on" === localValue : "on" === props.value,
			onChange: (e) => {
				const value = e.target.checked ? "on" : "";
				setLocalValue(value);
				props.onChange(value);
			},
			disabled: !props.isEditMode
		}));
	}
	Acceptance.propTypes = __spreadValues$11({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/upload.js
	var __defProp$10 = Object.defineProperty;
	var __getOwnPropSymbols$10 = Object.getOwnPropertySymbols;
	var __hasOwnProp$10 = Object.prototype.hasOwnProperty;
	var __propIsEnum$10 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$10 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$10(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$10 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$10.call(b, prop)) __defNormalProp$10(a, prop, b[prop]);
		if (__getOwnPropSymbols$10) {
			for (var prop of __getOwnPropSymbols$10(b)) if (__propIsEnum$10.call(b, prop)) __defNormalProp$10(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	function Upload(props) {
		const value = props.value.split(" , ");
		if ("attached" === value[0]) {
			const message = value.length > 1 ? (0, _wordpress_i18n.__)("Attachments to email won't be saved.", "elementor-pro") : (0, _wordpress_i18n.__)("Attachment to email won't be saved.", "elementor-pro");
			return /* @__PURE__ */ react.default.createElement("span", null, message);
		}
		return value.map((path) => /* @__PURE__ */ react.default.createElement("div", { key: path }, /* @__PURE__ */ react.default.createElement("a", {
			href: path,
			target: "_blank",
			rel: "noreferrer"
		}, path)));
	}
	Upload.propTypes = __spreadValues$10({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/date.js
	var __defProp$9 = Object.defineProperty;
	var __getOwnPropSymbols$9 = Object.getOwnPropertySymbols;
	var __hasOwnProp$9 = Object.prototype.hasOwnProperty;
	var __propIsEnum$9 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$9 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$9(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$9 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$9.call(b, prop)) __defNormalProp$9(a, prop, b[prop]);
		if (__getOwnPropSymbols$9) {
			for (var prop of __getOwnPropSymbols$9(b)) if (__propIsEnum$9.call(b, prop)) __defNormalProp$9(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	function Date$1(props) {
		return /* @__PURE__ */ react.default.createElement(Text, {
			value: props.value,
			isEditMode: props.isEditMode,
			onChange: props.onChange,
			field: props.field
		}, props.value && formatToLocalDate(props.value));
	}
	__name(Date$1, "Date");
	Date$1.propTypes = __spreadValues$9({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/time.js
	var __defProp$8 = Object.defineProperty;
	var __getOwnPropSymbols$8 = Object.getOwnPropertySymbols;
	var __hasOwnProp$8 = Object.prototype.hasOwnProperty;
	var __propIsEnum$8 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$8 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$8(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$8 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$8.call(b, prop)) __defNormalProp$8(a, prop, b[prop]);
		if (__getOwnPropSymbols$8) {
			for (var prop of __getOwnPropSymbols$8(b)) if (__propIsEnum$8.call(b, prop)) __defNormalProp$8(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	function Time(props) {
		return /* @__PURE__ */ react.default.createElement(Text, {
			value: props.value,
			isEditMode: props.isEditMode,
			onChange: props.onChange,
			field: props.field
		}, props.value && formatToLocalTime(`2000-01-01 ${props.value}`));
	}
	Time.propTypes = __spreadValues$8({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/textarea.js
	var __defProp$7 = Object.defineProperty;
	var __getOwnPropSymbols$7 = Object.getOwnPropertySymbols;
	var __hasOwnProp$7 = Object.prototype.hasOwnProperty;
	var __propIsEnum$7 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$7 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$7(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$7 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$7.call(b, prop)) __defNormalProp$7(a, prop, b[prop]);
		if (__getOwnPropSymbols$7) {
			for (var prop of __getOwnPropSymbols$7(b)) if (__propIsEnum$7.call(b, prop)) __defNormalProp$7(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var { useState: useState$11 } = react.default;
	function Textarea(props) {
		const [localValue, setLocalValue] = useState$11(props.value);
		return props.isEditMode ? /* @__PURE__ */ react.default.createElement("textarea", {
			value: props.isEditMode ? localValue : props.value,
			rows: "4",
			onChange: (e) => {
				const value = e.target.value;
				setLocalValue(value);
				props.onChange(value);
			}
		}) : props.value;
	}
	Textarea.propTypes = __spreadValues$7({}, basePropTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-value/index.js
	var __defProp$6 = Object.defineProperty;
	var __defProps$6 = Object.defineProperties;
	var __getOwnPropDescs$6 = Object.getOwnPropertyDescriptors;
	var __getOwnPropSymbols$6 = Object.getOwnPropertySymbols;
	var __hasOwnProp$6 = Object.prototype.hasOwnProperty;
	var __propIsEnum$6 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$6 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$6(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$6 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$6.call(b, prop)) __defNormalProp$6(a, prop, b[prop]);
		if (__getOwnPropSymbols$6) {
			for (var prop of __getOwnPropSymbols$6(b)) if (__propIsEnum$6.call(b, prop)) __defNormalProp$6(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var __spreadProps$6 = /* @__PURE__ */ __name((a, b) => __defProps$6(a, __getOwnPropDescs$6(b)), "__spreadProps");
	var { useMemo: useMemo$8 } = react.default;
	var defaultComponent = Text;
	var components = Object.entries({
		Email,
		Tel,
		Url,
		Radio,
		Select,
		Checkbox: Checkbox$1,
		Acceptance,
		Upload,
		Date: Date$1,
		Time,
		Textarea,
		Text
	}).reduce((current, [key, component]) => __spreadProps$6(__spreadValues$6({}, current), { [key.toLowerCase()]: component }), {});
	var basePropTypes = {
		value: import_prop_types.default.string,
		isEditMode: import_prop_types.default.bool,
		onChange: import_prop_types.default.func.isRequired,
		field: import_prop_types.default.shape({
			id: import_prop_types.default.string.isRequired,
			type: import_prop_types.default.string,
			options: import_prop_types.default.arrayOf(import_prop_types.default.string),
			is_multiple: import_prop_types.default.bool
		})
	};
	function SubmissionValue(props) {
		const Component = useMemo$8(() => {
			var _a;
			const key = (_a = props.field) == null ? void 0 : _a.type;
			return Object.prototype.hasOwnProperty.call(components, key) ? components[key] : defaultComponent;
		}, [props.field, props.value]);
		return /* @__PURE__ */ react.default.createElement(Component, {
			value: props.value,
			field: props.field,
			isEditMode: props.isEditMode,
			onChange: (value) => props.onChange(props.field.id, value)
		});
	}
	SubmissionValue.propTypes = __spreadValues$6({}, basePropTypes);
	SubmissionValue.defaultProps = { isEditMode: false };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/pages/item.js
	var __defProp$5 = Object.defineProperty;
	var __defProps$5 = Object.defineProperties;
	var __getOwnPropDescs$5 = Object.getOwnPropertyDescriptors;
	var __getOwnPropSymbols$5 = Object.getOwnPropertySymbols;
	var __hasOwnProp$5 = Object.prototype.hasOwnProperty;
	var __propIsEnum$5 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$5 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$5(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$5 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$5.call(b, prop)) __defNormalProp$5(a, prop, b[prop]);
		if (__getOwnPropSymbols$5) {
			for (var prop of __getOwnPropSymbols$5(b)) if (__propIsEnum$5.call(b, prop)) __defNormalProp$5(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var __spreadProps$5 = /* @__PURE__ */ __name((a, b) => __defProps$5(a, __getOwnPropDescs$5(b)), "__spreadProps");
	var { useEffect: useEffect$5, useState: useState$10, useMemo: useMemo$7 } = react.default;
	function Item(props) {
		var _a;
		var _b;
		const [{ data }, setFetchResult] = useState$10({
			data: {},
			meta: {}
		}), [error, setError] = useState$10(null), [isEditMode, setIsEditMode] = useState$10(false), [formData, setFormData] = useState$10({}), navigate = useNavigate(), { notifySuccess, notifyError } = useNoticesContext(), { isTrashEnabled } = useSettingsContext();
		const fields = useMemo$7(() => {
			var _a2;
			return (_a2 = data.form) == null ? void 0 : _a2.fields.reduce((current, field) => __spreadProps$5(__spreadValues$5({}, current), { [field.id]: field }), {});
		}, [(_a = data.form) == null ? void 0 : _a.fields]);
		useEffect$5(() => {
			$e.data.get("form-submissions/index", { id: props.id }, { refresh: true }).then((result) => {
				setFetchResult(result.data);
				return result.data;
			}).then((resultData) => {
				if (resultData.data.is_read) return;
				$e.data.update("form-submissions/index", { is_read: true }, { id: props.id });
			}).catch((e) => setError(e));
		}, []);
		const [deleteItem] = useDataAction(([query = {}], { abortController }) => {
			const messages = notice_messages_default[query.force ? "deleted" : "trashed"];
			return $e.data.delete("form-submissions/index", __spreadValues$5({ id: props.id }, query), { signal: abortController.signal }).then(() => notifySuccess(messages.success(1))).then(() => navigate("/")).catch(() => notifyError(messages.error()));
		}, [props.id]);
		const [update, { status: updateStatus }] = useDataAction(([values]) => {
			return $e.data.update("form-submissions/index", { values }, { id: props.id }).then((result) => setFetchResult(result.data)).then(() => {
				setIsEditMode(false);
				setFormData({});
			}).then(() => notifySuccess(notice_messages_default.updated.success(1))).catch(() => notifyError(notice_messages_default.updated.error()));
		}, [props.id]);
		if (!Object.keys(data).length) {
			if (error) return /* @__PURE__ */ react.default.createElement("p", null, " ", error.message || (0, _wordpress_i18n.__)("Not Found", "elementor-pro"), " ");
			return (0, _wordpress_i18n.__)("Loading...", "elementor-pro");
		}
		return /* @__PURE__ */ react.default.createElement("div", { id: "poststuff" }, /* @__PURE__ */ react.default.createElement("form", {
			id: "post-body",
			className: "metabox-holder columns-2",
			onSubmit: (e) => {
				e.preventDefault();
				if (!isEditMode || updateStatus === "loading") return;
				update(formData);
			}
		}, /* @__PURE__ */ react.default.createElement("div", { id: "post-body-content" }, /* @__PURE__ */ react.default.createElement("div", { className: "e-form-submissions-main" }, /* @__PURE__ */ react.default.createElement(PostBox, { header: /* @__PURE__ */ react.default.createElement("div", { className: "e-form-submissions-main__header" }, /* @__PURE__ */ react.default.createElement("h2", null, (0, _wordpress_i18n.__)("Submission", "elementor-pro"), " #", data.id), /* @__PURE__ */ react.default.createElement("button", {
			onClick: (e) => {
				e.preventDefault();
				if (updateStatus === "loading") return;
				setIsEditMode((prev) => !prev);
			},
			className: "button button-secondary",
			type: "button",
			disabled: updateStatus === STATUS_LOADING
		}, isEditMode ? (0, _wordpress_i18n.__)("Cancel", "elementor-pro") : (0, _wordpress_i18n.__)("Edit", "elementor-pro"))) }, /* @__PURE__ */ react.default.createElement(WpTable, { className: "e-form-submissions-item-table" }, /* @__PURE__ */ react.default.createElement(WpTable.Body, null, ((_b = data.values) == null ? void 0 : _b.length) > 0 ? data.values.map((value) => {
			var _a2;
			return /* @__PURE__ */ react.default.createElement(WpTable.Row, { key: value.id }, /* @__PURE__ */ react.default.createElement(WpTable.Cell, null, ((_a2 = fields == null ? void 0 : fields[value.key]) == null ? void 0 : _a2.label) || value.key), /* @__PURE__ */ react.default.createElement(WpTable.Cell, null, /* @__PURE__ */ react.default.createElement(SubmissionValue, {
				value: value.value,
				field: (fields == null ? void 0 : fields[value.key]) || {
					id: value.key,
					type: "text"
				},
				isEditMode,
				onChange: (id, fieldValue) => setFormData((prev) => __spreadProps$5(__spreadValues$5({}, prev), { [id]: fieldValue }))
			})));
		}) : /* @__PURE__ */ react.default.createElement(WpTable.Row, null, /* @__PURE__ */ react.default.createElement(WpTable.Cell, { colSpan: "2" }, (0, _wordpress_i18n.__)("No data", "elementor-pro"))))))), data.form_actions_log && /* @__PURE__ */ react.default.createElement(FormActionsLog, { actions: data.form_actions_log })), /* @__PURE__ */ react.default.createElement("div", {
			className: "postbox-container",
			id: "postbox-container-1"
		}, /* @__PURE__ */ react.default.createElement(PostBox, { header: /* @__PURE__ */ react.default.createElement("h2", null, (0, _wordpress_i18n.__)("Additional Info", "elementor-pro"), " ") }, /* @__PURE__ */ react.default.createElement("div", { className: "submitbox" }, /* @__PURE__ */ react.default.createElement("div", { id: "misc-publishing-actions" }, data.post && /* @__PURE__ */ react.default.createElement("div", { className: "misc-pub-section" }, (0, _wordpress_i18n.__)("Form:", "elementor-pro"), " ", /* @__PURE__ */ react.default.createElement("a", {
			href: data.post.edit_url,
			target: "_blank",
			rel: "noreferrer"
		}, data.form.name, " (#", data.form.element_id, ")")), /* @__PURE__ */ react.default.createElement("div", { className: "misc-pub-section" }, (0, _wordpress_i18n.__)("Page:", "elementor-pro"), " ", /* @__PURE__ */ react.default.createElement("a", {
			href: data.referer,
			target: "_blank",
			rel: "noreferrer"
		}, data.referer_title || /* @__PURE__ */ react.default.createElement("i", { className: "eicon-editor-external-link e-form-submissions-referer-icon" }))), /* @__PURE__ */ react.default.createElement("div", { className: "misc-pub-section" }, (0, _wordpress_i18n.__)("Create Date:", "elementor-pro"), " ", /* @__PURE__ */ react.default.createElement("strong", null, formatToLocalDateTime(data.created_at))), /* @__PURE__ */ react.default.createElement("div", { className: "misc-pub-section" }, (0, _wordpress_i18n.__)("Update Date:", "elementor-pro"), " ", /* @__PURE__ */ react.default.createElement("strong", null, formatToLocalDateTime(data.updated_at))), data.user_name && /* @__PURE__ */ react.default.createElement("div", { className: "misc-pub-section" }, (0, _wordpress_i18n.__)("User Name:", "elementor-pro"), " ", /* @__PURE__ */ react.default.createElement("strong", null, data.user_name)), data.user_ip && /* @__PURE__ */ react.default.createElement("div", { className: "misc-pub-section" }, (0, _wordpress_i18n.__)("User IP:", "elementor-pro"), " ", /* @__PURE__ */ react.default.createElement("strong", null, data.user_ip)), data.user_agent && /* @__PURE__ */ react.default.createElement("div", { className: "misc-pub-section" }, (0, _wordpress_i18n.__)("User Agent:", "elementor-pro"), " ", /* @__PURE__ */ react.default.createElement("strong", null, data.user_agent))), /* @__PURE__ */ react.default.createElement("div", { id: "major-publishing-actions" }, /* @__PURE__ */ react.default.createElement("div", { id: "delete-action" }, /* @__PURE__ */ react.default.createElement("a", {
			className: "submitdelete deletion",
			href: "#",
			onClick: (e) => {
				e.preventDefault();
				deleteItem({ force: isTrashEnabled ? 0 : 1 });
			}
		}, isTrashEnabled ? (0, _wordpress_i18n.__)("Move to Trash", "elementor-pro") : (0, _wordpress_i18n.__)("Delete Permanently", "elementor-pro"))), /* @__PURE__ */ react.default.createElement("div", { id: "publishing-action" }, /* @__PURE__ */ react.default.createElement("button", {
			type: "submit",
			name: "save",
			id: "publish",
			className: "button button-primary button-large",
			disabled: !isEditMode || updateStatus === "loading"
		}, (0, _wordpress_i18n.__)("Update", "elementor-pro"))), /* @__PURE__ */ react.default.createElement("div", { className: "clear" })))))), /* @__PURE__ */ react.default.createElement("br", { className: "clear" }));
	}
	Item.propTypes = { id: import_prop_types.default.string };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/checkbox/bulk.js
	var { useCallback: useCallback$6 } = react.default;
	function Bulk(props) {
		const onChange = useCallback$6((e) => {
			const value = e.target.checked ? [...props.allValues] : [];
			props.onChange(value);
		}, [
			props.onChange,
			props.checkedGroup,
			props.allValues
		]);
		return /* @__PURE__ */ react.default.createElement("input", {
			type: "checkbox",
			checked: props.checkedGroup.length === props.allValues.length && props.allValues.length > 0,
			onChange
		});
	}
	Bulk.propTypes = {
		checkedGroup: import_prop_types.array.isRequired,
		allValues: import_prop_types.array.isRequired,
		onChange: import_prop_types.func.isRequired
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/checkbox/index.js
	var { useCallback: useCallback$5 } = react.default;
	function Checkbox(props) {
		const onChange = useCallback$5((e) => {
			const value = e.target.checked ? [...props.checkedGroup, props.value] : props.checkedGroup.filter((checkedItem) => checkedItem !== props.value);
			props.onChange(value);
		}, [
			props.onChange,
			props.checkedGroup,
			props.value
		]);
		return /* @__PURE__ */ react.default.createElement("input", {
			type: "checkbox",
			checked: props.checkedGroup.includes(props.value),
			onChange
		});
	}
	Checkbox.propTypes = {
		checkedGroup: import_prop_types.array.isRequired,
		value: import_prop_types.number.isRequired,
		onChange: import_prop_types.func.isRequired
	};
	Checkbox.Bulk = Bulk;
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/date-filter.js
	var { useState: useState$9, useMemo: useMemo$6, useCallback: useCallback$4 } = react.default;
	function DateFilter(props) {
		const [forceCustomSelect, setForceCustomSelect] = useState$9(false);
		const options = useMemo$6(() => {
			const format = (date) => wp.date.date("Y-m-d", date);
			const now = /* @__PURE__ */ new Date();
			const yesterday = new Date(now);
			const last7Days = new Date(now);
			const last30Days = new Date(now);
			yesterday.setDate(yesterday.getDate() - 1);
			last7Days.setDate(last7Days.getDate() - 7);
			last30Days.setDate(last30Days.getDate() - 30);
			return [
				{
					label: (0, _wordpress_i18n.__)("All Time", "elementor-pro"),
					value: "all",
					filter: {
						before: null,
						after: null
					}
				},
				{
					label: (0, _wordpress_i18n.__)("Today", "elementor-pro"),
					value: "today",
					filter: {
						before: null,
						after: format(now)
					}
				},
				{
					label: (0, _wordpress_i18n.__)("Yesterday", "elementor-pro"),
					value: "yesterday",
					filter: {
						before: format(yesterday),
						after: format(yesterday)
					}
				},
				{
					label: (0, _wordpress_i18n.__)("Last 7 days", "elementor-pro"),
					value: "last7",
					filter: {
						before: null,
						after: format(last7Days)
					}
				},
				{
					label: (0, _wordpress_i18n.__)("Last 30 days", "elementor-pro"),
					value: "last_30",
					filter: {
						before: null,
						after: format(last30Days)
					}
				},
				{
					label: (0, _wordpress_i18n.__)("Custom", "elementor-pro"),
					value: "custom",
					filter: {
						before: null,
						after: null
					}
				}
			];
		}, []);
		const selectedValue = useMemo$6(() => {
			if (forceCustomSelect) return "custom";
			const selected = options.find((option) => option.filter.after === props.value.after && option.filter.before === props.value.before);
			if (!selected) return "custom";
			return selected.value;
		}, [
			options,
			props.value,
			forceCustomSelect
		]);
		const onSelectChanged = useCallback$4(({ target: { value } }) => {
			const selected = options.find((option) => option.value === value);
			setForceCustomSelect("custom" === selected.value);
			props.onChange(selected.filter);
		}, [options]);
		const onDateInputChanged = useCallback$4((value) => {
			if (selectedValue !== "custom") return;
			props.onChange(value);
		}, [selectedValue]);
		return /* @__PURE__ */ react.default.createElement(react.default.Fragment, null, props.label && /* @__PURE__ */ react.default.createElement("label", {
			htmlFor: `filter-by-${props.name}`,
			className: "screen-reader-text"
		}, props.label), /* @__PURE__ */ react.default.createElement("select", {
			id: `filter-by-${props.name}`,
			value: selectedValue,
			onChange: onSelectChanged
		}, options.map(({ value, label }) => {
			return /* @__PURE__ */ react.default.createElement("option", {
				key: value,
				value
			}, " ", label, " ");
		})), "custom" === selectedValue && /* @__PURE__ */ react.default.createElement(react.default.Fragment, null, /* @__PURE__ */ react.default.createElement("input", {
			type: "date",
			"aria-label": (0, _wordpress_i18n.__)("Start Date", "elementor-pro"),
			value: props.value.after || "",
			onChange: ({ target: { value } }) => onDateInputChanged({ after: value })
		}), "\xA0 - \xA0", /* @__PURE__ */ react.default.createElement("input", {
			type: "date",
			"aria-label": (0, _wordpress_i18n.__)("End Date", "elementor-pro"),
			value: props.value.before || "",
			onChange: ({ target: { value } }) => onDateInputChanged({ before: value })
		})));
	}
	DateFilter.propTypes = {
		value: import_prop_types.default.shape({
			after: import_prop_types.default.string,
			before: import_prop_types.default.string
		}),
		label: import_prop_types.default.string,
		onChange: import_prop_types.default.func.isRequired,
		name: import_prop_types.default.string.isRequired
	};
	DateFilter.defaultProps = {
		value: {
			after: null,
			before: null
		},
		options: []
	};
	//#endregion
	//#region \0@oxc-project+runtime@0.140.0/helpers/esm/asyncToGenerator.js
	function asyncGeneratorStep(n, t, e, r, o, a, c) {
		try {
			var i = n[a](c);
			var u = i.value;
		} catch (n) {
			e(n);
			return;
		}
		i.done ? t(u) : Promise.resolve(u).then(r, o);
	}
	function _asyncToGenerator(n) {
		return function() {
			var t = this;
			var e = arguments;
			return new Promise(function(r, o) {
				var a = n.apply(t, e);
				function _next(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
				}
				function _throw(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
				}
				_next(void 0);
			});
		};
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/utils/download-blob.js
	/**
	* A util function to make sure the user download the blob data.
	*
	* @param {any}    blob
	* @param {string} filename
	*/
	function downloadBlob(blob, filename = "") {
		const link = document.createElement("a");
		link.setAttribute("href", URL.createObjectURL(blob));
		link.style.visibility = "hidden";
		if (filename) link.setAttribute("download", filename);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	}
	var __vitePreload = function preload(baseModule, deps, importerUrl) {
		let promise = Promise.resolve();
		function handlePreloadError(err) {
			const e = new Event("vite:preloadError", { cancelable: true });
			e.payload = err;
			window.dispatchEvent(e);
			if (!e.defaultPrevented) throw err;
		}
		return promise.then((res) => {
			for (const item of res || []) {
				if (item.status !== "rejected") continue;
				handlePreloadError(item.reason);
			}
			return baseModule().catch(handlePreloadError);
		});
	};
	//#endregion
	//#region node_modules/jszip/dist/jszip.min.js
	var require_jszip_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		/*!
		
		JSZip v3.10.1 - A JavaScript class for generating and reading zip files
		<http://stuartk.com/jszip>
		
		(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
		Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.
		
		JSZip uses the library pako released under the MIT license :
		https://github.com/nodeca/pako/blob/main/LICENSE
		*/
		(function(e) {
			if ("object" == typeof exports && "undefined" != typeof module) module.exports = e();
			else if ("function" == typeof define && define.amd) define([], e);
			else ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).JSZip = e();
		})(function() {
			return function s(a, o, h) {
				function u(r, e) {
					if (!o[r]) {
						if (!a[r]) {
							var t = "function" == typeof require && require;
							if (!e && t) return t(r, !0);
							if (l) return l(r, !0);
							var n = /* @__PURE__ */ new Error("Cannot find module '" + r + "'");
							throw n.code = "MODULE_NOT_FOUND", n;
						}
						var i = o[r] = { exports: {} };
						a[r][0].call(i.exports, function(e) {
							var t = a[r][1][e];
							return u(t || e);
						}, i, i.exports, s, a, o, h);
					}
					return o[r].exports;
				}
				for (var l = "function" == typeof require && require, e = 0; e < h.length; e++) u(h[e]);
				return u;
			}({
				1: [function(e, t, r) {
					"use strict";
					var d = e("./utils");
					var c = e("./support");
					var p = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
					r.encode = function(e) {
						for (var t, r, n, i, s, a, o, h = [], u = 0, l = e.length, f = l, c = "string" !== d.getTypeOf(e); u < e.length;) f = l - u, n = c ? (t = e[u++], r = u < l ? e[u++] : 0, u < l ? e[u++] : 0) : (t = e.charCodeAt(u++), r = u < l ? e.charCodeAt(u++) : 0, u < l ? e.charCodeAt(u++) : 0), i = t >> 2, s = (3 & t) << 4 | r >> 4, a = 1 < f ? (15 & r) << 2 | n >> 6 : 64, o = 2 < f ? 63 & n : 64, h.push(p.charAt(i) + p.charAt(s) + p.charAt(a) + p.charAt(o));
						return h.join("");
					}, r.decode = function(e) {
						var t;
						var r;
						var n;
						var i;
						var s;
						var a;
						var o = 0;
						var h = 0;
						var u = "data:";
						if (e.substr(0, u.length) === u) throw new Error("Invalid base64 input, it looks like a data url.");
						var l;
						var f = 3 * (e = e.replace(/[^A-Za-z0-9+/=]/g, "")).length / 4;
						if (e.charAt(e.length - 1) === p.charAt(64) && f--, e.charAt(e.length - 2) === p.charAt(64) && f--, f % 1 != 0) throw new Error("Invalid base64 input, bad content length.");
						for (l = c.uint8array ? new Uint8Array(0 | f) : new Array(0 | f); o < e.length;) t = p.indexOf(e.charAt(o++)) << 2 | (i = p.indexOf(e.charAt(o++))) >> 4, r = (15 & i) << 4 | (s = p.indexOf(e.charAt(o++))) >> 2, n = (3 & s) << 6 | (a = p.indexOf(e.charAt(o++))), l[h++] = t, 64 !== s && (l[h++] = r), 64 !== a && (l[h++] = n);
						return l;
					};
				}, {
					"./support": 30,
					"./utils": 32
				}],
				2: [function(e, t, r) {
					"use strict";
					var n = e("./external");
					var i = e("./stream/DataWorker");
					var s = e("./stream/Crc32Probe");
					var a = e("./stream/DataLengthProbe");
					function o(e, t, r, n, i) {
						this.compressedSize = e, this.uncompressedSize = t, this.crc32 = r, this.compression = n, this.compressedContent = i;
					}
					o.prototype = {
						getContentWorker: function() {
							var e = new i(n.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length"));
							var t = this;
							return e.on("end", function() {
								if (this.streamInfo.data_length !== t.uncompressedSize) throw new Error("Bug : uncompressed data size mismatch");
							}), e;
						},
						getCompressedWorker: function() {
							return new i(n.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize", this.compressedSize).withStreamInfo("uncompressedSize", this.uncompressedSize).withStreamInfo("crc32", this.crc32).withStreamInfo("compression", this.compression);
						}
					}, o.createWorkerFrom = function(e, t, r) {
						return e.pipe(new s()).pipe(new a("uncompressedSize")).pipe(t.compressWorker(r)).pipe(new a("compressedSize")).withStreamInfo("compression", t);
					}, t.exports = o;
				}, {
					"./external": 6,
					"./stream/Crc32Probe": 25,
					"./stream/DataLengthProbe": 26,
					"./stream/DataWorker": 27
				}],
				3: [function(e, t, r) {
					"use strict";
					var n = e("./stream/GenericWorker");
					r.STORE = {
						magic: "\0\0",
						compressWorker: function() {
							return new n("STORE compression");
						},
						uncompressWorker: function() {
							return new n("STORE decompression");
						}
					}, r.DEFLATE = e("./flate");
				}, {
					"./flate": 7,
					"./stream/GenericWorker": 28
				}],
				4: [function(e, t, r) {
					"use strict";
					var n = e("./utils");
					var o = function() {
						for (var e, t = [], r = 0; r < 256; r++) {
							e = r;
							for (var n = 0; n < 8; n++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
							t[r] = e;
						}
						return t;
					}();
					t.exports = function(e, t) {
						return void 0 !== e && e.length ? "string" !== n.getTypeOf(e) ? function(e, t, r, n) {
							var i = o;
							var s = n + r;
							e ^= -1;
							for (var a = n; a < s; a++) e = e >>> 8 ^ i[255 & (e ^ t[a])];
							return -1 ^ e;
						}(0 | t, e, e.length, 0) : function(e, t, r, n) {
							var i = o;
							var s = n + r;
							e ^= -1;
							for (var a = n; a < s; a++) e = e >>> 8 ^ i[255 & (e ^ t.charCodeAt(a))];
							return -1 ^ e;
						}(0 | t, e, e.length, 0) : 0;
					};
				}, { "./utils": 32 }],
				5: [function(e, t, r) {
					"use strict";
					r.base64 = !1, r.binary = !1, r.dir = !1, r.createFolders = !0, r.date = null, r.compression = null, r.compressionOptions = null, r.comment = null, r.unixPermissions = null, r.dosPermissions = null;
				}, {}],
				6: [function(e, t, r) {
					"use strict";
					var n = null;
					n = "undefined" != typeof Promise ? Promise : e("lie"), t.exports = { Promise: n };
				}, { lie: 37 }],
				7: [function(e, t, r) {
					"use strict";
					var n = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Uint32Array;
					var i = e("pako");
					var s = e("./utils");
					var a = e("./stream/GenericWorker");
					var o = n ? "uint8array" : "array";
					function h(e, t) {
						a.call(this, "FlateWorker/" + e), this._pako = null, this._pakoAction = e, this._pakoOptions = t, this.meta = {};
					}
					r.magic = "\b\0", s.inherits(h, a), h.prototype.processChunk = function(e) {
						this.meta = e.meta, null === this._pako && this._createPako(), this._pako.push(s.transformTo(o, e.data), !1);
					}, h.prototype.flush = function() {
						a.prototype.flush.call(this), null === this._pako && this._createPako(), this._pako.push([], !0);
					}, h.prototype.cleanUp = function() {
						a.prototype.cleanUp.call(this), this._pako = null;
					}, h.prototype._createPako = function() {
						this._pako = new i[this._pakoAction]({
							raw: !0,
							level: this._pakoOptions.level || -1
						});
						var t = this;
						this._pako.onData = function(e) {
							t.push({
								data: e,
								meta: t.meta
							});
						};
					}, r.compressWorker = function(e) {
						return new h("Deflate", e);
					}, r.uncompressWorker = function() {
						return new h("Inflate", {});
					};
				}, {
					"./stream/GenericWorker": 28,
					"./utils": 32,
					pako: 38
				}],
				8: [function(e, t, r) {
					"use strict";
					function A(e, t) {
						var r;
						var n = "";
						for (r = 0; r < t; r++) n += String.fromCharCode(255 & e), e >>>= 8;
						return n;
					}
					function n(e, t, r, n, i, s) {
						var a;
						var o;
						var h = e.file;
						var u = e.compression;
						var l = s !== O.utf8encode;
						var f = I.transformTo("string", s(h.name));
						var c = I.transformTo("string", O.utf8encode(h.name));
						var d = h.comment;
						var p = I.transformTo("string", s(d));
						var m = I.transformTo("string", O.utf8encode(d));
						var _ = c.length !== h.name.length;
						var g = m.length !== d.length;
						var b = "";
						var v = "";
						var y = "";
						var w = h.dir;
						var k = h.date;
						var x = {
							crc32: 0,
							compressedSize: 0,
							uncompressedSize: 0
						};
						t && !r || (x.crc32 = e.crc32, x.compressedSize = e.compressedSize, x.uncompressedSize = e.uncompressedSize);
						var S = 0;
						t && (S |= 8), l || !_ && !g || (S |= 2048);
						var z = 0;
						var C = 0;
						w && (z |= 16), "UNIX" === i ? (C = 798, z |= function(e, t) {
							var r = e;
							return e || (r = t ? 16893 : 33204), (65535 & r) << 16;
						}(h.unixPermissions, w)) : (C = 20, z |= function(e) {
							return 63 & (e || 0);
						}(h.dosPermissions)), a = k.getUTCHours(), a <<= 6, a |= k.getUTCMinutes(), a <<= 5, a |= k.getUTCSeconds() / 2, o = k.getUTCFullYear() - 1980, o <<= 4, o |= k.getUTCMonth() + 1, o <<= 5, o |= k.getUTCDate(), _ && (v = A(1, 1) + A(B(f), 4) + c, b += "up" + A(v.length, 2) + v), g && (y = A(1, 1) + A(B(p), 4) + m, b += "uc" + A(y.length, 2) + y);
						var E = "";
						return E += "\n\0", E += A(S, 2), E += u.magic, E += A(a, 2), E += A(o, 2), E += A(x.crc32, 4), E += A(x.compressedSize, 4), E += A(x.uncompressedSize, 4), E += A(f.length, 2), E += A(b.length, 2), {
							fileRecord: R.LOCAL_FILE_HEADER + E + f + b,
							dirRecord: R.CENTRAL_FILE_HEADER + A(C, 2) + E + A(p.length, 2) + "\0\0\0\0" + A(z, 4) + A(n, 4) + f + b + p
						};
					}
					var I = e("../utils");
					var i = e("../stream/GenericWorker");
					var O = e("../utf8");
					var B = e("../crc32");
					var R = e("../signature");
					function s(e, t, r, n) {
						i.call(this, "ZipFileWorker"), this.bytesWritten = 0, this.zipComment = t, this.zipPlatform = r, this.encodeFileName = n, this.streamFiles = e, this.accumulate = !1, this.contentBuffer = [], this.dirRecords = [], this.currentSourceOffset = 0, this.entriesCount = 0, this.currentFile = null, this._sources = [];
					}
					I.inherits(s, i), s.prototype.push = function(e) {
						var t = e.meta.percent || 0;
						var r = this.entriesCount;
						var n = this._sources.length;
						this.accumulate ? this.contentBuffer.push(e) : (this.bytesWritten += e.data.length, i.prototype.push.call(this, {
							data: e.data,
							meta: {
								currentFile: this.currentFile,
								percent: r ? (t + 100 * (r - n - 1)) / r : 100
							}
						}));
					}, s.prototype.openedSource = function(e) {
						this.currentSourceOffset = this.bytesWritten, this.currentFile = e.file.name;
						var t = this.streamFiles && !e.file.dir;
						if (t) {
							var r = n(e, t, !1, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
							this.push({
								data: r.fileRecord,
								meta: { percent: 0 }
							});
						} else this.accumulate = !0;
					}, s.prototype.closedSource = function(e) {
						this.accumulate = !1;
						var t = this.streamFiles && !e.file.dir;
						var r = n(e, t, !0, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
						if (this.dirRecords.push(r.dirRecord), t) this.push({
							data: function(e) {
								return R.DATA_DESCRIPTOR + A(e.crc32, 4) + A(e.compressedSize, 4) + A(e.uncompressedSize, 4);
							}(e),
							meta: { percent: 100 }
						});
						else for (this.push({
							data: r.fileRecord,
							meta: { percent: 0 }
						}); this.contentBuffer.length;) this.push(this.contentBuffer.shift());
						this.currentFile = null;
					}, s.prototype.flush = function() {
						for (var e = this.bytesWritten, t = 0; t < this.dirRecords.length; t++) this.push({
							data: this.dirRecords[t],
							meta: { percent: 100 }
						});
						var r = this.bytesWritten - e;
						var n = function(e, t, r, n, i) {
							var s = I.transformTo("string", i(n));
							return R.CENTRAL_DIRECTORY_END + "\0\0\0\0" + A(e, 2) + A(e, 2) + A(t, 4) + A(r, 4) + A(s.length, 2) + s;
						}(this.dirRecords.length, r, e, this.zipComment, this.encodeFileName);
						this.push({
							data: n,
							meta: { percent: 100 }
						});
					}, s.prototype.prepareNextSource = function() {
						this.previous = this._sources.shift(), this.openedSource(this.previous.streamInfo), this.isPaused ? this.previous.pause() : this.previous.resume();
					}, s.prototype.registerPrevious = function(e) {
						this._sources.push(e);
						var t = this;
						return e.on("data", function(e) {
							t.processChunk(e);
						}), e.on("end", function() {
							t.closedSource(t.previous.streamInfo), t._sources.length ? t.prepareNextSource() : t.end();
						}), e.on("error", function(e) {
							t.error(e);
						}), this;
					}, s.prototype.resume = function() {
						return !!i.prototype.resume.call(this) && (!this.previous && this._sources.length ? (this.prepareNextSource(), !0) : this.previous || this._sources.length || this.generatedError ? void 0 : (this.end(), !0));
					}, s.prototype.error = function(e) {
						var t = this._sources;
						if (!i.prototype.error.call(this, e)) return !1;
						for (var r = 0; r < t.length; r++) try {
							t[r].error(e);
						} catch (e) {}
						return !0;
					}, s.prototype.lock = function() {
						i.prototype.lock.call(this);
						for (var e = this._sources, t = 0; t < e.length; t++) e[t].lock();
					}, t.exports = s;
				}, {
					"../crc32": 4,
					"../signature": 23,
					"../stream/GenericWorker": 28,
					"../utf8": 31,
					"../utils": 32
				}],
				9: [function(e, t, r) {
					"use strict";
					var u = e("../compressions");
					var n = e("./ZipFileWorker");
					r.generateWorker = function(e, a, t) {
						var o = new n(a.streamFiles, t, a.platform, a.encodeFileName);
						var h = 0;
						try {
							e.forEach(function(e, t) {
								h++;
								var r = function(e, t) {
									var r = e || t;
									var n = u[r];
									if (!n) throw new Error(r + " is not a valid compression method !");
									return n;
								}(t.options.compression, a.compression);
								var n = t.options.compressionOptions || a.compressionOptions || {};
								var i = t.dir;
								var s = t.date;
								t._compressWorker(r, n).withStreamInfo("file", {
									name: e,
									dir: i,
									date: s,
									comment: t.comment || "",
									unixPermissions: t.unixPermissions,
									dosPermissions: t.dosPermissions
								}).pipe(o);
							}), o.entriesCount = h;
						} catch (e) {
							o.error(e);
						}
						return o;
					};
				}, {
					"../compressions": 3,
					"./ZipFileWorker": 8
				}],
				10: [function(e, t, r) {
					"use strict";
					function n() {
						if (!(this instanceof n)) return new n();
						if (arguments.length) throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");
						this.files = Object.create(null), this.comment = null, this.root = "", this.clone = function() {
							var e = new n();
							for (var t in this) "function" != typeof this[t] && (e[t] = this[t]);
							return e;
						};
					}
					(n.prototype = e("./object")).loadAsync = e("./load"), n.support = e("./support"), n.defaults = e("./defaults"), n.version = "3.10.1", n.loadAsync = function(e, t) {
						return new n().loadAsync(e, t);
					}, n.external = e("./external"), t.exports = n;
				}, {
					"./defaults": 5,
					"./external": 6,
					"./load": 11,
					"./object": 15,
					"./support": 30
				}],
				11: [function(e, t, r) {
					"use strict";
					var u = e("./utils");
					var i = e("./external");
					var n = e("./utf8");
					var s = e("./zipEntries");
					var a = e("./stream/Crc32Probe");
					var l = e("./nodejsUtils");
					function f(n) {
						return new i.Promise(function(e, t) {
							var r = n.decompressed.getContentWorker().pipe(new a());
							r.on("error", function(e) {
								t(e);
							}).on("end", function() {
								r.streamInfo.crc32 !== n.decompressed.crc32 ? t(/* @__PURE__ */ new Error("Corrupted zip : CRC32 mismatch")) : e();
							}).resume();
						});
					}
					t.exports = function(e, o) {
						var h = this;
						return o = u.extend(o || {}, {
							base64: !1,
							checkCRC32: !1,
							optimizedBinaryString: !1,
							createFolders: !1,
							decodeFileName: n.utf8decode
						}), l.isNode && l.isStream(e) ? i.Promise.reject(/* @__PURE__ */ new Error("JSZip can't accept a stream when loading a zip file.")) : u.prepareContent("the loaded zip file", e, !0, o.optimizedBinaryString, o.base64).then(function(e) {
							var t = new s(o);
							return t.load(e), t;
						}).then(function(e) {
							var t = [i.Promise.resolve(e)];
							var r = e.files;
							if (o.checkCRC32) for (var n = 0; n < r.length; n++) t.push(f(r[n]));
							return i.Promise.all(t);
						}).then(function(e) {
							for (var t = e.shift(), r = t.files, n = 0; n < r.length; n++) {
								var i = r[n];
								var s = i.fileNameStr;
								var a = u.resolve(i.fileNameStr);
								h.file(a, i.decompressed, {
									binary: !0,
									optimizedBinaryString: !0,
									date: i.date,
									dir: i.dir,
									comment: i.fileCommentStr.length ? i.fileCommentStr : null,
									unixPermissions: i.unixPermissions,
									dosPermissions: i.dosPermissions,
									createFolders: o.createFolders
								}), i.dir || (h.file(a).unsafeOriginalName = s);
							}
							return t.zipComment.length && (h.comment = t.zipComment), h;
						});
					};
				}, {
					"./external": 6,
					"./nodejsUtils": 14,
					"./stream/Crc32Probe": 25,
					"./utf8": 31,
					"./utils": 32,
					"./zipEntries": 33
				}],
				12: [function(e, t, r) {
					"use strict";
					var n = e("../utils");
					var i = e("../stream/GenericWorker");
					function s(e, t) {
						i.call(this, "Nodejs stream input adapter for " + e), this._upstreamEnded = !1, this._bindStream(t);
					}
					n.inherits(s, i), s.prototype._bindStream = function(e) {
						var t = this;
						(this._stream = e).pause(), e.on("data", function(e) {
							t.push({
								data: e,
								meta: { percent: 0 }
							});
						}).on("error", function(e) {
							t.isPaused ? this.generatedError = e : t.error(e);
						}).on("end", function() {
							t.isPaused ? t._upstreamEnded = !0 : t.end();
						});
					}, s.prototype.pause = function() {
						return !!i.prototype.pause.call(this) && (this._stream.pause(), !0);
					}, s.prototype.resume = function() {
						return !!i.prototype.resume.call(this) && (this._upstreamEnded ? this.end() : this._stream.resume(), !0);
					}, t.exports = s;
				}, {
					"../stream/GenericWorker": 28,
					"../utils": 32
				}],
				13: [function(e, t, r) {
					"use strict";
					var i = e("readable-stream").Readable;
					function n(e, t, r) {
						i.call(this, t), this._helper = e;
						var n = this;
						e.on("data", function(e, t) {
							n.push(e) || n._helper.pause(), r && r(t);
						}).on("error", function(e) {
							n.emit("error", e);
						}).on("end", function() {
							n.push(null);
						});
					}
					e("../utils").inherits(n, i), n.prototype._read = function() {
						this._helper.resume();
					}, t.exports = n;
				}, {
					"../utils": 32,
					"readable-stream": 16
				}],
				14: [function(e, t, r) {
					"use strict";
					t.exports = {
						isNode: "undefined" != typeof Buffer,
						newBufferFrom: function(e, t) {
							if (Buffer.from && Buffer.from !== Uint8Array.from) return Buffer.from(e, t);
							if ("number" == typeof e) throw new Error("The \"data\" argument must not be a number");
							return new Buffer(e, t);
						},
						allocBuffer: function(e) {
							if (Buffer.alloc) return Buffer.alloc(e);
							var t = new Buffer(e);
							return t.fill(0), t;
						},
						isBuffer: function(e) {
							return Buffer.isBuffer(e);
						},
						isStream: function(e) {
							return e && "function" == typeof e.on && "function" == typeof e.pause && "function" == typeof e.resume;
						}
					};
				}, {}],
				15: [function(e, t, r) {
					"use strict";
					function s(e, t, r) {
						var n;
						var i = u.getTypeOf(t);
						var s = u.extend(r || {}, f);
						s.date = s.date || /* @__PURE__ */ new Date(), null !== s.compression && (s.compression = s.compression.toUpperCase()), "string" == typeof s.unixPermissions && (s.unixPermissions = parseInt(s.unixPermissions, 8)), s.unixPermissions && 16384 & s.unixPermissions && (s.dir = !0), s.dosPermissions && 16 & s.dosPermissions && (s.dir = !0), s.dir && (e = g(e)), s.createFolders && (n = _(e)) && b.call(this, n, !0);
						var a = "string" === i && !1 === s.binary && !1 === s.base64;
						r && void 0 !== r.binary || (s.binary = !a), (t instanceof c && 0 === t.uncompressedSize || s.dir || !t || 0 === t.length) && (s.base64 = !1, s.binary = !0, t = "", s.compression = "STORE", i = "string");
						var o = null;
						o = t instanceof c || t instanceof l ? t : p.isNode && p.isStream(t) ? new m(e, t) : u.prepareContent(e, t, s.binary, s.optimizedBinaryString, s.base64);
						var h = new d(e, o, s);
						this.files[e] = h;
					}
					var i = e("./utf8");
					var u = e("./utils");
					var l = e("./stream/GenericWorker");
					var a = e("./stream/StreamHelper");
					var f = e("./defaults");
					var c = e("./compressedObject");
					var d = e("./zipObject");
					var o = e("./generate");
					var p = e("./nodejsUtils");
					var m = e("./nodejs/NodejsStreamInputAdapter");
					var _ = function(e) {
						"/" === e.slice(-1) && (e = e.substring(0, e.length - 1));
						var t = e.lastIndexOf("/");
						return 0 < t ? e.substring(0, t) : "";
					};
					var g = function(e) {
						return "/" !== e.slice(-1) && (e += "/"), e;
					};
					var b = function(e, t) {
						return t = void 0 !== t ? t : f.createFolders, e = g(e), this.files[e] || s.call(this, e, null, {
							dir: !0,
							createFolders: t
						}), this.files[e];
					};
					function h(e) {
						return "[object RegExp]" === Object.prototype.toString.call(e);
					}
					t.exports = {
						load: function() {
							throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
						},
						forEach: function(e) {
							var t;
							var r;
							var n;
							for (t in this.files) n = this.files[t], (r = t.slice(this.root.length, t.length)) && t.slice(0, this.root.length) === this.root && e(r, n);
						},
						filter: function(r) {
							var n = [];
							return this.forEach(function(e, t) {
								r(e, t) && n.push(t);
							}), n;
						},
						file: function(e, t, r) {
							if (1 !== arguments.length) return e = this.root + e, s.call(this, e, t, r), this;
							if (h(e)) {
								var n = e;
								return this.filter(function(e, t) {
									return !t.dir && n.test(e);
								});
							}
							var i = this.files[this.root + e];
							return i && !i.dir ? i : null;
						},
						folder: function(r) {
							if (!r) return this;
							if (h(r)) return this.filter(function(e, t) {
								return t.dir && r.test(e);
							});
							var e = this.root + r;
							var t = b.call(this, e);
							var n = this.clone();
							return n.root = t.name, n;
						},
						remove: function(r) {
							r = this.root + r;
							var e = this.files[r];
							if (e || ("/" !== r.slice(-1) && (r += "/"), e = this.files[r]), e && !e.dir) delete this.files[r];
							else for (var t = this.filter(function(e, t) {
								return t.name.slice(0, r.length) === r;
							}), n = 0; n < t.length; n++) delete this.files[t[n].name];
							return this;
						},
						generate: function() {
							throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
						},
						generateInternalStream: function(e) {
							var t;
							var r = {};
							try {
								if ((r = u.extend(e || {}, {
									streamFiles: !1,
									compression: "STORE",
									compressionOptions: null,
									type: "",
									platform: "DOS",
									comment: null,
									mimeType: "application/zip",
									encodeFileName: i.utf8encode
								})).type = r.type.toLowerCase(), r.compression = r.compression.toUpperCase(), "binarystring" === r.type && (r.type = "string"), !r.type) throw new Error("No output type specified.");
								u.checkSupport(r.type), "darwin" !== r.platform && "freebsd" !== r.platform && "linux" !== r.platform && "sunos" !== r.platform || (r.platform = "UNIX"), "win32" === r.platform && (r.platform = "DOS");
								var n = r.comment || this.comment || "";
								t = o.generateWorker(this, r, n);
							} catch (e) {
								(t = new l("error")).error(e);
							}
							return new a(t, r.type || "string", r.mimeType);
						},
						generateAsync: function(e, t) {
							return this.generateInternalStream(e).accumulate(t);
						},
						generateNodeStream: function(e, t) {
							return (e = e || {}).type || (e.type = "nodebuffer"), this.generateInternalStream(e).toNodejsStream(t);
						}
					};
				}, {
					"./compressedObject": 2,
					"./defaults": 5,
					"./generate": 9,
					"./nodejs/NodejsStreamInputAdapter": 12,
					"./nodejsUtils": 14,
					"./stream/GenericWorker": 28,
					"./stream/StreamHelper": 29,
					"./utf8": 31,
					"./utils": 32,
					"./zipObject": 35
				}],
				16: [function(e, t, r) {
					"use strict";
					t.exports = e("stream");
				}, { stream: void 0 }],
				17: [function(e, t, r) {
					"use strict";
					var n = e("./DataReader");
					function i(e) {
						n.call(this, e);
						for (var t = 0; t < this.data.length; t++) e[t] = 255 & e[t];
					}
					e("../utils").inherits(i, n), i.prototype.byteAt = function(e) {
						return this.data[this.zero + e];
					}, i.prototype.lastIndexOfSignature = function(e) {
						for (var t = e.charCodeAt(0), r = e.charCodeAt(1), n = e.charCodeAt(2), i = e.charCodeAt(3), s = this.length - 4; 0 <= s; --s) if (this.data[s] === t && this.data[s + 1] === r && this.data[s + 2] === n && this.data[s + 3] === i) return s - this.zero;
						return -1;
					}, i.prototype.readAndCheckSignature = function(e) {
						var t = e.charCodeAt(0);
						var r = e.charCodeAt(1);
						var n = e.charCodeAt(2);
						var i = e.charCodeAt(3);
						var s = this.readData(4);
						return t === s[0] && r === s[1] && n === s[2] && i === s[3];
					}, i.prototype.readData = function(e) {
						if (this.checkOffset(e), 0 === e) return [];
						var t = this.data.slice(this.zero + this.index, this.zero + this.index + e);
						return this.index += e, t;
					}, t.exports = i;
				}, {
					"../utils": 32,
					"./DataReader": 18
				}],
				18: [function(e, t, r) {
					"use strict";
					var n = e("../utils");
					function i(e) {
						this.data = e, this.length = e.length, this.index = 0, this.zero = 0;
					}
					i.prototype = {
						checkOffset: function(e) {
							this.checkIndex(this.index + e);
						},
						checkIndex: function(e) {
							if (this.length < this.zero + e || e < 0) throw new Error("End of data reached (data length = " + this.length + ", asked index = " + e + "). Corrupted zip ?");
						},
						setIndex: function(e) {
							this.checkIndex(e), this.index = e;
						},
						skip: function(e) {
							this.setIndex(this.index + e);
						},
						byteAt: function() {},
						readInt: function(e) {
							var t;
							var r = 0;
							for (this.checkOffset(e), t = this.index + e - 1; t >= this.index; t--) r = (r << 8) + this.byteAt(t);
							return this.index += e, r;
						},
						readString: function(e) {
							return n.transformTo("string", this.readData(e));
						},
						readData: function() {},
						lastIndexOfSignature: function() {},
						readAndCheckSignature: function() {},
						readDate: function() {
							var e = this.readInt(4);
							return new Date(Date.UTC(1980 + (e >> 25 & 127), (e >> 21 & 15) - 1, e >> 16 & 31, e >> 11 & 31, e >> 5 & 63, (31 & e) << 1));
						}
					}, t.exports = i;
				}, { "../utils": 32 }],
				19: [function(e, t, r) {
					"use strict";
					var n = e("./Uint8ArrayReader");
					function i(e) {
						n.call(this, e);
					}
					e("../utils").inherits(i, n), i.prototype.readData = function(e) {
						this.checkOffset(e);
						var t = this.data.slice(this.zero + this.index, this.zero + this.index + e);
						return this.index += e, t;
					}, t.exports = i;
				}, {
					"../utils": 32,
					"./Uint8ArrayReader": 21
				}],
				20: [function(e, t, r) {
					"use strict";
					var n = e("./DataReader");
					function i(e) {
						n.call(this, e);
					}
					e("../utils").inherits(i, n), i.prototype.byteAt = function(e) {
						return this.data.charCodeAt(this.zero + e);
					}, i.prototype.lastIndexOfSignature = function(e) {
						return this.data.lastIndexOf(e) - this.zero;
					}, i.prototype.readAndCheckSignature = function(e) {
						return e === this.readData(4);
					}, i.prototype.readData = function(e) {
						this.checkOffset(e);
						var t = this.data.slice(this.zero + this.index, this.zero + this.index + e);
						return this.index += e, t;
					}, t.exports = i;
				}, {
					"../utils": 32,
					"./DataReader": 18
				}],
				21: [function(e, t, r) {
					"use strict";
					var n = e("./ArrayReader");
					function i(e) {
						n.call(this, e);
					}
					e("../utils").inherits(i, n), i.prototype.readData = function(e) {
						if (this.checkOffset(e), 0 === e) return /* @__PURE__ */ new Uint8Array(0);
						var t = this.data.subarray(this.zero + this.index, this.zero + this.index + e);
						return this.index += e, t;
					}, t.exports = i;
				}, {
					"../utils": 32,
					"./ArrayReader": 17
				}],
				22: [function(e, t, r) {
					"use strict";
					var n = e("../utils");
					var i = e("../support");
					var s = e("./ArrayReader");
					var a = e("./StringReader");
					var o = e("./NodeBufferReader");
					var h = e("./Uint8ArrayReader");
					t.exports = function(e) {
						var t = n.getTypeOf(e);
						return n.checkSupport(t), "string" !== t || i.uint8array ? "nodebuffer" === t ? new o(e) : i.uint8array ? new h(n.transformTo("uint8array", e)) : new s(n.transformTo("array", e)) : new a(e);
					};
				}, {
					"../support": 30,
					"../utils": 32,
					"./ArrayReader": 17,
					"./NodeBufferReader": 19,
					"./StringReader": 20,
					"./Uint8ArrayReader": 21
				}],
				23: [function(e, t, r) {
					"use strict";
					r.LOCAL_FILE_HEADER = "PK", r.CENTRAL_FILE_HEADER = "PK", r.CENTRAL_DIRECTORY_END = "PK", r.ZIP64_CENTRAL_DIRECTORY_LOCATOR = "PK\x07", r.ZIP64_CENTRAL_DIRECTORY_END = "PK", r.DATA_DESCRIPTOR = "PK\x07\b";
				}, {}],
				24: [function(e, t, r) {
					"use strict";
					var n = e("./GenericWorker");
					var i = e("../utils");
					function s(e) {
						n.call(this, "ConvertWorker to " + e), this.destType = e;
					}
					i.inherits(s, n), s.prototype.processChunk = function(e) {
						this.push({
							data: i.transformTo(this.destType, e.data),
							meta: e.meta
						});
					}, t.exports = s;
				}, {
					"../utils": 32,
					"./GenericWorker": 28
				}],
				25: [function(e, t, r) {
					"use strict";
					var n = e("./GenericWorker");
					var i = e("../crc32");
					function s() {
						n.call(this, "Crc32Probe"), this.withStreamInfo("crc32", 0);
					}
					e("../utils").inherits(s, n), s.prototype.processChunk = function(e) {
						this.streamInfo.crc32 = i(e.data, this.streamInfo.crc32 || 0), this.push(e);
					}, t.exports = s;
				}, {
					"../crc32": 4,
					"../utils": 32,
					"./GenericWorker": 28
				}],
				26: [function(e, t, r) {
					"use strict";
					var n = e("../utils");
					var i = e("./GenericWorker");
					function s(e) {
						i.call(this, "DataLengthProbe for " + e), this.propName = e, this.withStreamInfo(e, 0);
					}
					n.inherits(s, i), s.prototype.processChunk = function(e) {
						if (e) {
							var t = this.streamInfo[this.propName] || 0;
							this.streamInfo[this.propName] = t + e.data.length;
						}
						i.prototype.processChunk.call(this, e);
					}, t.exports = s;
				}, {
					"../utils": 32,
					"./GenericWorker": 28
				}],
				27: [function(e, t, r) {
					"use strict";
					var n = e("../utils");
					var i = e("./GenericWorker");
					function s(e) {
						i.call(this, "DataWorker");
						var t = this;
						this.dataIsReady = !1, this.index = 0, this.max = 0, this.data = null, this.type = "", this._tickScheduled = !1, e.then(function(e) {
							t.dataIsReady = !0, t.data = e, t.max = e && e.length || 0, t.type = n.getTypeOf(e), t.isPaused || t._tickAndRepeat();
						}, function(e) {
							t.error(e);
						});
					}
					n.inherits(s, i), s.prototype.cleanUp = function() {
						i.prototype.cleanUp.call(this), this.data = null;
					}, s.prototype.resume = function() {
						return !!i.prototype.resume.call(this) && (!this._tickScheduled && this.dataIsReady && (this._tickScheduled = !0, n.delay(this._tickAndRepeat, [], this)), !0);
					}, s.prototype._tickAndRepeat = function() {
						this._tickScheduled = !1, this.isPaused || this.isFinished || (this._tick(), this.isFinished || (n.delay(this._tickAndRepeat, [], this), this._tickScheduled = !0));
					}, s.prototype._tick = function() {
						if (this.isPaused || this.isFinished) return !1;
						var e = null;
						var t = Math.min(this.max, this.index + 16384);
						if (this.index >= this.max) return this.end();
						switch (this.type) {
							case "string":
								e = this.data.substring(this.index, t);
								break;
							case "uint8array":
								e = this.data.subarray(this.index, t);
								break;
							case "array":
							case "nodebuffer": e = this.data.slice(this.index, t);
						}
						return this.index = t, this.push({
							data: e,
							meta: { percent: this.max ? this.index / this.max * 100 : 0 }
						});
					}, t.exports = s;
				}, {
					"../utils": 32,
					"./GenericWorker": 28
				}],
				28: [function(e, t, r) {
					"use strict";
					function n(e) {
						this.name = e || "default", this.streamInfo = {}, this.generatedError = null, this.extraStreamInfo = {}, this.isPaused = !0, this.isFinished = !1, this.isLocked = !1, this._listeners = {
							data: [],
							end: [],
							error: []
						}, this.previous = null;
					}
					n.prototype = {
						push: function(e) {
							this.emit("data", e);
						},
						end: function() {
							if (this.isFinished) return !1;
							this.flush();
							try {
								this.emit("end"), this.cleanUp(), this.isFinished = !0;
							} catch (e) {
								this.emit("error", e);
							}
							return !0;
						},
						error: function(e) {
							return !this.isFinished && (this.isPaused ? this.generatedError = e : (this.isFinished = !0, this.emit("error", e), this.previous && this.previous.error(e), this.cleanUp()), !0);
						},
						on: function(e, t) {
							return this._listeners[e].push(t), this;
						},
						cleanUp: function() {
							this.streamInfo = this.generatedError = this.extraStreamInfo = null, this._listeners = [];
						},
						emit: function(e, t) {
							if (this._listeners[e]) for (var r = 0; r < this._listeners[e].length; r++) this._listeners[e][r].call(this, t);
						},
						pipe: function(e) {
							return e.registerPrevious(this);
						},
						registerPrevious: function(e) {
							if (this.isLocked) throw new Error("The stream '" + this + "' has already been used.");
							this.streamInfo = e.streamInfo, this.mergeStreamInfo(), this.previous = e;
							var t = this;
							return e.on("data", function(e) {
								t.processChunk(e);
							}), e.on("end", function() {
								t.end();
							}), e.on("error", function(e) {
								t.error(e);
							}), this;
						},
						pause: function() {
							return !this.isPaused && !this.isFinished && (this.isPaused = !0, this.previous && this.previous.pause(), !0);
						},
						resume: function() {
							if (!this.isPaused || this.isFinished) return !1;
							var e = this.isPaused = !1;
							return this.generatedError && (this.error(this.generatedError), e = !0), this.previous && this.previous.resume(), !e;
						},
						flush: function() {},
						processChunk: function(e) {
							this.push(e);
						},
						withStreamInfo: function(e, t) {
							return this.extraStreamInfo[e] = t, this.mergeStreamInfo(), this;
						},
						mergeStreamInfo: function() {
							for (var e in this.extraStreamInfo) Object.prototype.hasOwnProperty.call(this.extraStreamInfo, e) && (this.streamInfo[e] = this.extraStreamInfo[e]);
						},
						lock: function() {
							if (this.isLocked) throw new Error("The stream '" + this + "' has already been used.");
							this.isLocked = !0, this.previous && this.previous.lock();
						},
						toString: function() {
							var e = "Worker " + this.name;
							return this.previous ? this.previous + " -> " + e : e;
						}
					}, t.exports = n;
				}, {}],
				29: [function(e, t, r) {
					"use strict";
					var h = e("../utils");
					var i = e("./ConvertWorker");
					var s = e("./GenericWorker");
					var u = e("../base64");
					var n = e("../support");
					var a = e("../external");
					var o = null;
					if (n.nodestream) try {
						o = e("../nodejs/NodejsStreamOutputAdapter");
					} catch (e) {}
					function l(e, o) {
						return new a.Promise(function(t, r) {
							var n = [];
							var i = e._internalType;
							var s = e._outputType;
							var a = e._mimeType;
							e.on("data", function(e, t) {
								n.push(e), o && o(t);
							}).on("error", function(e) {
								n = [], r(e);
							}).on("end", function() {
								try {
									t(function(e, t, r) {
										switch (e) {
											case "blob": return h.newBlob(h.transformTo("arraybuffer", t), r);
											case "base64": return u.encode(t);
											default: return h.transformTo(e, t);
										}
									}(s, function(e, t) {
										var r;
										var n = 0;
										var i = null;
										var s = 0;
										for (r = 0; r < t.length; r++) s += t[r].length;
										switch (e) {
											case "string": return t.join("");
											case "array": return Array.prototype.concat.apply([], t);
											case "uint8array":
												for (i = new Uint8Array(s), r = 0; r < t.length; r++) i.set(t[r], n), n += t[r].length;
												return i;
											case "nodebuffer": return Buffer.concat(t);
											default: throw new Error("concat : unsupported type '" + e + "'");
										}
									}(i, n), a));
								} catch (e) {
									r(e);
								}
								n = [];
							}).resume();
						});
					}
					function f(e, t, r) {
						var n = t;
						switch (t) {
							case "blob":
							case "arraybuffer":
								n = "uint8array";
								break;
							case "base64": n = "string";
						}
						try {
							this._internalType = n, this._outputType = t, this._mimeType = r, h.checkSupport(n), this._worker = e.pipe(new i(n)), e.lock();
						} catch (e) {
							this._worker = new s("error"), this._worker.error(e);
						}
					}
					f.prototype = {
						accumulate: function(e) {
							return l(this, e);
						},
						on: function(e, t) {
							var r = this;
							return "data" === e ? this._worker.on(e, function(e) {
								t.call(r, e.data, e.meta);
							}) : this._worker.on(e, function() {
								h.delay(t, arguments, r);
							}), this;
						},
						resume: function() {
							return h.delay(this._worker.resume, [], this._worker), this;
						},
						pause: function() {
							return this._worker.pause(), this;
						},
						toNodejsStream: function(e) {
							if (h.checkSupport("nodestream"), "nodebuffer" !== this._outputType) throw new Error(this._outputType + " is not supported by this method");
							return new o(this, { objectMode: "nodebuffer" !== this._outputType }, e);
						}
					}, t.exports = f;
				}, {
					"../base64": 1,
					"../external": 6,
					"../nodejs/NodejsStreamOutputAdapter": 13,
					"../support": 30,
					"../utils": 32,
					"./ConvertWorker": 24,
					"./GenericWorker": 28
				}],
				30: [function(e, t, r) {
					"use strict";
					if (r.base64 = !0, r.array = !0, r.string = !0, r.arraybuffer = "undefined" != typeof ArrayBuffer && "undefined" != typeof Uint8Array, r.nodebuffer = "undefined" != typeof Buffer, r.uint8array = "undefined" != typeof Uint8Array, "undefined" == typeof ArrayBuffer) r.blob = !1;
					else {
						var n = /* @__PURE__ */ new ArrayBuffer(0);
						try {
							r.blob = 0 === new Blob([n], { type: "application/zip" }).size;
						} catch (e) {
							try {
								var i = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
								i.append(n), r.blob = 0 === i.getBlob("application/zip").size;
							} catch (e) {
								r.blob = !1;
							}
						}
					}
					try {
						r.nodestream = !!e("readable-stream").Readable;
					} catch (e) {
						r.nodestream = !1;
					}
				}, { "readable-stream": 16 }],
				31: [function(e, t, s) {
					"use strict";
					for (var o = e("./utils"), h = e("./support"), r = e("./nodejsUtils"), n = e("./stream/GenericWorker"), u = new Array(256), i = 0; i < 256; i++) u[i] = 252 <= i ? 6 : 248 <= i ? 5 : 240 <= i ? 4 : 224 <= i ? 3 : 192 <= i ? 2 : 1;
					u[254] = u[254] = 1;
					function a() {
						n.call(this, "utf-8 decode"), this.leftOver = null;
					}
					function l() {
						n.call(this, "utf-8 encode");
					}
					s.utf8encode = function(e) {
						return h.nodebuffer ? r.newBufferFrom(e, "utf-8") : function(e) {
							var t;
							var r;
							var n;
							var i;
							var s;
							var a = e.length;
							var o = 0;
							for (i = 0; i < a; i++) 55296 == (64512 & (r = e.charCodeAt(i))) && i + 1 < a && 56320 == (64512 & (n = e.charCodeAt(i + 1))) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++), o += r < 128 ? 1 : r < 2048 ? 2 : r < 65536 ? 3 : 4;
							for (t = h.uint8array ? new Uint8Array(o) : new Array(o), i = s = 0; s < o; i++) 55296 == (64512 & (r = e.charCodeAt(i))) && i + 1 < a && 56320 == (64512 & (n = e.charCodeAt(i + 1))) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++), r < 128 ? t[s++] = r : (r < 2048 ? t[s++] = 192 | r >>> 6 : (r < 65536 ? t[s++] = 224 | r >>> 12 : (t[s++] = 240 | r >>> 18, t[s++] = 128 | r >>> 12 & 63), t[s++] = 128 | r >>> 6 & 63), t[s++] = 128 | 63 & r);
							return t;
						}(e);
					}, s.utf8decode = function(e) {
						return h.nodebuffer ? o.transformTo("nodebuffer", e).toString("utf-8") : function(e) {
							var t;
							var r;
							var n;
							var i;
							var s = e.length;
							var a = new Array(2 * s);
							for (t = r = 0; t < s;) if ((n = e[t++]) < 128) a[r++] = n;
							else if (4 < (i = u[n])) a[r++] = 65533, t += i - 1;
							else {
								for (n &= 2 === i ? 31 : 3 === i ? 15 : 7; 1 < i && t < s;) n = n << 6 | 63 & e[t++], i--;
								1 < i ? a[r++] = 65533 : n < 65536 ? a[r++] = n : (n -= 65536, a[r++] = 55296 | n >> 10 & 1023, a[r++] = 56320 | 1023 & n);
							}
							return a.length !== r && (a.subarray ? a = a.subarray(0, r) : a.length = r), o.applyFromCharCode(a);
						}(e = o.transformTo(h.uint8array ? "uint8array" : "array", e));
					}, o.inherits(a, n), a.prototype.processChunk = function(e) {
						var t = o.transformTo(h.uint8array ? "uint8array" : "array", e.data);
						if (this.leftOver && this.leftOver.length) {
							if (h.uint8array) {
								var r = t;
								(t = new Uint8Array(r.length + this.leftOver.length)).set(this.leftOver, 0), t.set(r, this.leftOver.length);
							} else t = this.leftOver.concat(t);
							this.leftOver = null;
						}
						var n = function(e, t) {
							var r;
							for ((t = t || e.length) > e.length && (t = e.length), r = t - 1; 0 <= r && 128 == (192 & e[r]);) r--;
							return r < 0 ? t : 0 === r ? t : r + u[e[r]] > t ? r : t;
						}(t);
						var i = t;
						n !== t.length && (h.uint8array ? (i = t.subarray(0, n), this.leftOver = t.subarray(n, t.length)) : (i = t.slice(0, n), this.leftOver = t.slice(n, t.length))), this.push({
							data: s.utf8decode(i),
							meta: e.meta
						});
					}, a.prototype.flush = function() {
						this.leftOver && this.leftOver.length && (this.push({
							data: s.utf8decode(this.leftOver),
							meta: {}
						}), this.leftOver = null);
					}, s.Utf8DecodeWorker = a, o.inherits(l, n), l.prototype.processChunk = function(e) {
						this.push({
							data: s.utf8encode(e.data),
							meta: e.meta
						});
					}, s.Utf8EncodeWorker = l;
				}, {
					"./nodejsUtils": 14,
					"./stream/GenericWorker": 28,
					"./support": 30,
					"./utils": 32
				}],
				32: [function(e, t, a) {
					"use strict";
					var o = e("./support");
					var h = e("./base64");
					var r = e("./nodejsUtils");
					var u = e("./external");
					function n(e) {
						return e;
					}
					function l(e, t) {
						for (var r = 0; r < e.length; ++r) t[r] = 255 & e.charCodeAt(r);
						return t;
					}
					e("setimmediate"), a.newBlob = function(t, r) {
						a.checkSupport("blob");
						try {
							return new Blob([t], { type: r });
						} catch (e) {
							try {
								var n = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
								return n.append(t), n.getBlob(r);
							} catch (e) {
								throw new Error("Bug : can't construct the Blob.");
							}
						}
					};
					var i = {
						stringifyByChunk: function(e, t, r) {
							var n = [];
							var i = 0;
							var s = e.length;
							if (s <= r) return String.fromCharCode.apply(null, e);
							for (; i < s;) "array" === t || "nodebuffer" === t ? n.push(String.fromCharCode.apply(null, e.slice(i, Math.min(i + r, s)))) : n.push(String.fromCharCode.apply(null, e.subarray(i, Math.min(i + r, s)))), i += r;
							return n.join("");
						},
						stringifyByChar: function(e) {
							for (var t = "", r = 0; r < e.length; r++) t += String.fromCharCode(e[r]);
							return t;
						},
						applyCanBeUsed: {
							uint8array: function() {
								try {
									return o.uint8array && 1 === String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1)).length;
								} catch (e) {
									return !1;
								}
							}(),
							nodebuffer: function() {
								try {
									return o.nodebuffer && 1 === String.fromCharCode.apply(null, r.allocBuffer(1)).length;
								} catch (e) {
									return !1;
								}
							}()
						}
					};
					function s(e) {
						var t = 65536;
						var r = a.getTypeOf(e);
						var n = !0;
						if ("uint8array" === r ? n = i.applyCanBeUsed.uint8array : "nodebuffer" === r && (n = i.applyCanBeUsed.nodebuffer), n) for (; 1 < t;) try {
							return i.stringifyByChunk(e, r, t);
						} catch (e) {
							t = Math.floor(t / 2);
						}
						return i.stringifyByChar(e);
					}
					function f(e, t) {
						for (var r = 0; r < e.length; r++) t[r] = e[r];
						return t;
					}
					a.applyFromCharCode = s;
					var c = {};
					c.string = {
						string: n,
						array: function(e) {
							return l(e, new Array(e.length));
						},
						arraybuffer: function(e) {
							return c.string.uint8array(e).buffer;
						},
						uint8array: function(e) {
							return l(e, new Uint8Array(e.length));
						},
						nodebuffer: function(e) {
							return l(e, r.allocBuffer(e.length));
						}
					}, c.array = {
						string: s,
						array: n,
						arraybuffer: function(e) {
							return new Uint8Array(e).buffer;
						},
						uint8array: function(e) {
							return new Uint8Array(e);
						},
						nodebuffer: function(e) {
							return r.newBufferFrom(e);
						}
					}, c.arraybuffer = {
						string: function(e) {
							return s(new Uint8Array(e));
						},
						array: function(e) {
							return f(new Uint8Array(e), new Array(e.byteLength));
						},
						arraybuffer: n,
						uint8array: function(e) {
							return new Uint8Array(e);
						},
						nodebuffer: function(e) {
							return r.newBufferFrom(new Uint8Array(e));
						}
					}, c.uint8array = {
						string: s,
						array: function(e) {
							return f(e, new Array(e.length));
						},
						arraybuffer: function(e) {
							return e.buffer;
						},
						uint8array: n,
						nodebuffer: function(e) {
							return r.newBufferFrom(e);
						}
					}, c.nodebuffer = {
						string: s,
						array: function(e) {
							return f(e, new Array(e.length));
						},
						arraybuffer: function(e) {
							return c.nodebuffer.uint8array(e).buffer;
						},
						uint8array: function(e) {
							return f(e, new Uint8Array(e.length));
						},
						nodebuffer: n
					}, a.transformTo = function(e, t) {
						if (t = t || "", !e) return t;
						a.checkSupport(e);
						return c[a.getTypeOf(t)][e](t);
					}, a.resolve = function(e) {
						for (var t = e.split("/"), r = [], n = 0; n < t.length; n++) {
							var i = t[n];
							"." === i || "" === i && 0 !== n && n !== t.length - 1 || (".." === i ? r.pop() : r.push(i));
						}
						return r.join("/");
					}, a.getTypeOf = function(e) {
						return "string" == typeof e ? "string" : "[object Array]" === Object.prototype.toString.call(e) ? "array" : o.nodebuffer && r.isBuffer(e) ? "nodebuffer" : o.uint8array && e instanceof Uint8Array ? "uint8array" : o.arraybuffer && e instanceof ArrayBuffer ? "arraybuffer" : void 0;
					}, a.checkSupport = function(e) {
						if (!o[e.toLowerCase()]) throw new Error(e + " is not supported by this platform");
					}, a.MAX_VALUE_16BITS = 65535, a.MAX_VALUE_32BITS = -1, a.pretty = function(e) {
						var t;
						var r;
						var n = "";
						for (r = 0; r < (e || "").length; r++) n += "\\x" + ((t = e.charCodeAt(r)) < 16 ? "0" : "") + t.toString(16).toUpperCase();
						return n;
					}, a.delay = function(e, t, r) {
						setImmediate(function() {
							e.apply(r || null, t || []);
						});
					}, a.inherits = function(e, t) {
						function r() {}
						r.prototype = t.prototype, e.prototype = new r();
					}, a.extend = function() {
						var e;
						var t;
						var r = {};
						for (e = 0; e < arguments.length; e++) for (t in arguments[e]) Object.prototype.hasOwnProperty.call(arguments[e], t) && void 0 === r[t] && (r[t] = arguments[e][t]);
						return r;
					}, a.prepareContent = function(r, e, n, i, s) {
						return u.Promise.resolve(e).then(function(n) {
							return o.blob && (n instanceof Blob || -1 !== ["[object File]", "[object Blob]"].indexOf(Object.prototype.toString.call(n))) && "undefined" != typeof FileReader ? new u.Promise(function(t, r) {
								var e = new FileReader();
								e.onload = function(e) {
									t(e.target.result);
								}, e.onerror = function(e) {
									r(e.target.error);
								}, e.readAsArrayBuffer(n);
							}) : n;
						}).then(function(e) {
							var t = a.getTypeOf(e);
							return t ? ("arraybuffer" === t ? e = a.transformTo("uint8array", e) : "string" === t && (s ? e = h.decode(e) : n && !0 !== i && (e = function(e) {
								return l(e, o.uint8array ? new Uint8Array(e.length) : new Array(e.length));
							}(e))), e) : u.Promise.reject(/* @__PURE__ */ new Error("Can't read the data of '" + r + "'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"));
						});
					};
				}, {
					"./base64": 1,
					"./external": 6,
					"./nodejsUtils": 14,
					"./support": 30,
					setimmediate: 54
				}],
				33: [function(e, t, r) {
					"use strict";
					var n = e("./reader/readerFor");
					var i = e("./utils");
					var s = e("./signature");
					var a = e("./zipEntry");
					var o = e("./support");
					function h(e) {
						this.files = [], this.loadOptions = e;
					}
					h.prototype = {
						checkSignature: function(e) {
							if (!this.reader.readAndCheckSignature(e)) {
								this.reader.index -= 4;
								var t = this.reader.readString(4);
								throw new Error("Corrupted zip or bug: unexpected signature (" + i.pretty(t) + ", expected " + i.pretty(e) + ")");
							}
						},
						isSignature: function(e, t) {
							var r = this.reader.index;
							this.reader.setIndex(e);
							var n = this.reader.readString(4) === t;
							return this.reader.setIndex(r), n;
						},
						readBlockEndOfCentral: function() {
							this.diskNumber = this.reader.readInt(2), this.diskWithCentralDirStart = this.reader.readInt(2), this.centralDirRecordsOnThisDisk = this.reader.readInt(2), this.centralDirRecords = this.reader.readInt(2), this.centralDirSize = this.reader.readInt(4), this.centralDirOffset = this.reader.readInt(4), this.zipCommentLength = this.reader.readInt(2);
							var e = this.reader.readData(this.zipCommentLength);
							var t = o.uint8array ? "uint8array" : "array";
							var r = i.transformTo(t, e);
							this.zipComment = this.loadOptions.decodeFileName(r);
						},
						readBlockZip64EndOfCentral: function() {
							this.zip64EndOfCentralSize = this.reader.readInt(8), this.reader.skip(4), this.diskNumber = this.reader.readInt(4), this.diskWithCentralDirStart = this.reader.readInt(4), this.centralDirRecordsOnThisDisk = this.reader.readInt(8), this.centralDirRecords = this.reader.readInt(8), this.centralDirSize = this.reader.readInt(8), this.centralDirOffset = this.reader.readInt(8), this.zip64ExtensibleData = {};
							for (var e, t, r, n = this.zip64EndOfCentralSize - 44; 0 < n;) e = this.reader.readInt(2), t = this.reader.readInt(4), r = this.reader.readData(t), this.zip64ExtensibleData[e] = {
								id: e,
								length: t,
								value: r
							};
						},
						readBlockZip64EndOfCentralLocator: function() {
							if (this.diskWithZip64CentralDirStart = this.reader.readInt(4), this.relativeOffsetEndOfZip64CentralDir = this.reader.readInt(8), this.disksCount = this.reader.readInt(4), 1 < this.disksCount) throw new Error("Multi-volumes zip are not supported");
						},
						readLocalFiles: function() {
							var e;
							var t;
							for (e = 0; e < this.files.length; e++) t = this.files[e], this.reader.setIndex(t.localHeaderOffset), this.checkSignature(s.LOCAL_FILE_HEADER), t.readLocalPart(this.reader), t.handleUTF8(), t.processAttributes();
						},
						readCentralDir: function() {
							var e;
							for (this.reader.setIndex(this.centralDirOffset); this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER);) (e = new a({ zip64: this.zip64 }, this.loadOptions)).readCentralPart(this.reader), this.files.push(e);
							if (this.centralDirRecords !== this.files.length && 0 !== this.centralDirRecords && 0 === this.files.length) throw new Error("Corrupted zip or bug: expected " + this.centralDirRecords + " records in central dir, got " + this.files.length);
						},
						readEndOfCentral: function() {
							var e = this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);
							if (e < 0) throw !this.isSignature(0, s.LOCAL_FILE_HEADER) ? /* @__PURE__ */ new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html") : /* @__PURE__ */ new Error("Corrupted zip: can't find end of central directory");
							this.reader.setIndex(e);
							var t = e;
							if (this.checkSignature(s.CENTRAL_DIRECTORY_END), this.readBlockEndOfCentral(), this.diskNumber === i.MAX_VALUE_16BITS || this.diskWithCentralDirStart === i.MAX_VALUE_16BITS || this.centralDirRecordsOnThisDisk === i.MAX_VALUE_16BITS || this.centralDirRecords === i.MAX_VALUE_16BITS || this.centralDirSize === i.MAX_VALUE_32BITS || this.centralDirOffset === i.MAX_VALUE_32BITS) {
								if (this.zip64 = !0, (e = this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR)) < 0) throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");
								if (this.reader.setIndex(e), this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR), this.readBlockZip64EndOfCentralLocator(), !this.isSignature(this.relativeOffsetEndOfZip64CentralDir, s.ZIP64_CENTRAL_DIRECTORY_END) && (this.relativeOffsetEndOfZip64CentralDir = this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END), this.relativeOffsetEndOfZip64CentralDir < 0)) throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");
								this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir), this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END), this.readBlockZip64EndOfCentral();
							}
							var r = this.centralDirOffset + this.centralDirSize;
							this.zip64 && (r += 20, r += 12 + this.zip64EndOfCentralSize);
							var n = t - r;
							if (0 < n) this.isSignature(t, s.CENTRAL_FILE_HEADER) || (this.reader.zero = n);
							else if (n < 0) throw new Error("Corrupted zip: missing " + Math.abs(n) + " bytes.");
						},
						prepareReader: function(e) {
							this.reader = n(e);
						},
						load: function(e) {
							this.prepareReader(e), this.readEndOfCentral(), this.readCentralDir(), this.readLocalFiles();
						}
					}, t.exports = h;
				}, {
					"./reader/readerFor": 22,
					"./signature": 23,
					"./support": 30,
					"./utils": 32,
					"./zipEntry": 34
				}],
				34: [function(e, t, r) {
					"use strict";
					var n = e("./reader/readerFor");
					var s = e("./utils");
					var i = e("./compressedObject");
					var a = e("./crc32");
					var o = e("./utf8");
					var h = e("./compressions");
					var u = e("./support");
					function l(e, t) {
						this.options = e, this.loadOptions = t;
					}
					l.prototype = {
						isEncrypted: function() {
							return 1 == (1 & this.bitFlag);
						},
						useUTF8: function() {
							return 2048 == (2048 & this.bitFlag);
						},
						readLocalPart: function(e) {
							var t;
							var r;
							if (e.skip(22), this.fileNameLength = e.readInt(2), r = e.readInt(2), this.fileName = e.readData(this.fileNameLength), e.skip(r), -1 === this.compressedSize || -1 === this.uncompressedSize) throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");
							if (null === (t = function(e) {
								for (var t in h) if (Object.prototype.hasOwnProperty.call(h, t) && h[t].magic === e) return h[t];
								return null;
							}(this.compressionMethod))) throw new Error("Corrupted zip : compression " + s.pretty(this.compressionMethod) + " unknown (inner file : " + s.transformTo("string", this.fileName) + ")");
							this.decompressed = new i(this.compressedSize, this.uncompressedSize, this.crc32, t, e.readData(this.compressedSize));
						},
						readCentralPart: function(e) {
							this.versionMadeBy = e.readInt(2), e.skip(2), this.bitFlag = e.readInt(2), this.compressionMethod = e.readString(2), this.date = e.readDate(), this.crc32 = e.readInt(4), this.compressedSize = e.readInt(4), this.uncompressedSize = e.readInt(4);
							var t = e.readInt(2);
							if (this.extraFieldsLength = e.readInt(2), this.fileCommentLength = e.readInt(2), this.diskNumberStart = e.readInt(2), this.internalFileAttributes = e.readInt(2), this.externalFileAttributes = e.readInt(4), this.localHeaderOffset = e.readInt(4), this.isEncrypted()) throw new Error("Encrypted zip are not supported");
							e.skip(t), this.readExtraFields(e), this.parseZIP64ExtraField(e), this.fileComment = e.readData(this.fileCommentLength);
						},
						processAttributes: function() {
							this.unixPermissions = null, this.dosPermissions = null;
							var e = this.versionMadeBy >> 8;
							this.dir = !!(16 & this.externalFileAttributes), 0 == e && (this.dosPermissions = 63 & this.externalFileAttributes), 3 == e && (this.unixPermissions = this.externalFileAttributes >> 16 & 65535), this.dir || "/" !== this.fileNameStr.slice(-1) || (this.dir = !0);
						},
						parseZIP64ExtraField: function() {
							if (this.extraFields[1]) {
								var e = n(this.extraFields[1].value);
								this.uncompressedSize === s.MAX_VALUE_32BITS && (this.uncompressedSize = e.readInt(8)), this.compressedSize === s.MAX_VALUE_32BITS && (this.compressedSize = e.readInt(8)), this.localHeaderOffset === s.MAX_VALUE_32BITS && (this.localHeaderOffset = e.readInt(8)), this.diskNumberStart === s.MAX_VALUE_32BITS && (this.diskNumberStart = e.readInt(4));
							}
						},
						readExtraFields: function(e) {
							var t;
							var r;
							var n;
							var i = e.index + this.extraFieldsLength;
							for (this.extraFields || (this.extraFields = {}); e.index + 4 < i;) t = e.readInt(2), r = e.readInt(2), n = e.readData(r), this.extraFields[t] = {
								id: t,
								length: r,
								value: n
							};
							e.setIndex(i);
						},
						handleUTF8: function() {
							var e = u.uint8array ? "uint8array" : "array";
							if (this.useUTF8()) this.fileNameStr = o.utf8decode(this.fileName), this.fileCommentStr = o.utf8decode(this.fileComment);
							else {
								var t = this.findExtraFieldUnicodePath();
								if (null !== t) this.fileNameStr = t;
								else {
									var r = s.transformTo(e, this.fileName);
									this.fileNameStr = this.loadOptions.decodeFileName(r);
								}
								var n = this.findExtraFieldUnicodeComment();
								if (null !== n) this.fileCommentStr = n;
								else {
									var i = s.transformTo(e, this.fileComment);
									this.fileCommentStr = this.loadOptions.decodeFileName(i);
								}
							}
						},
						findExtraFieldUnicodePath: function() {
							var e = this.extraFields[28789];
							if (e) {
								var t = n(e.value);
								return 1 !== t.readInt(1) ? null : a(this.fileName) !== t.readInt(4) ? null : o.utf8decode(t.readData(e.length - 5));
							}
							return null;
						},
						findExtraFieldUnicodeComment: function() {
							var e = this.extraFields[25461];
							if (e) {
								var t = n(e.value);
								return 1 !== t.readInt(1) ? null : a(this.fileComment) !== t.readInt(4) ? null : o.utf8decode(t.readData(e.length - 5));
							}
							return null;
						}
					}, t.exports = l;
				}, {
					"./compressedObject": 2,
					"./compressions": 3,
					"./crc32": 4,
					"./reader/readerFor": 22,
					"./support": 30,
					"./utf8": 31,
					"./utils": 32
				}],
				35: [function(e, t, r) {
					"use strict";
					function n(e, t, r) {
						this.name = e, this.dir = r.dir, this.date = r.date, this.comment = r.comment, this.unixPermissions = r.unixPermissions, this.dosPermissions = r.dosPermissions, this._data = t, this._dataBinary = r.binary, this.options = {
							compression: r.compression,
							compressionOptions: r.compressionOptions
						};
					}
					var s = e("./stream/StreamHelper");
					var i = e("./stream/DataWorker");
					var a = e("./utf8");
					var o = e("./compressedObject");
					var h = e("./stream/GenericWorker");
					n.prototype = {
						internalStream: function(e) {
							var t = null;
							var r = "string";
							try {
								if (!e) throw new Error("No output type specified.");
								var n = "string" === (r = e.toLowerCase()) || "text" === r;
								"binarystring" !== r && "text" !== r || (r = "string"), t = this._decompressWorker();
								var i = !this._dataBinary;
								i && !n && (t = t.pipe(new a.Utf8EncodeWorker())), !i && n && (t = t.pipe(new a.Utf8DecodeWorker()));
							} catch (e) {
								(t = new h("error")).error(e);
							}
							return new s(t, r, "");
						},
						async: function(e, t) {
							return this.internalStream(e).accumulate(t);
						},
						nodeStream: function(e, t) {
							return this.internalStream(e || "nodebuffer").toNodejsStream(t);
						},
						_compressWorker: function(e, t) {
							if (this._data instanceof o && this._data.compression.magic === e.magic) return this._data.getCompressedWorker();
							var r = this._decompressWorker();
							return this._dataBinary || (r = r.pipe(new a.Utf8EncodeWorker())), o.createWorkerFrom(r, e, t);
						},
						_decompressWorker: function() {
							return this._data instanceof o ? this._data.getContentWorker() : this._data instanceof h ? this._data : new i(this._data);
						}
					};
					for (var u = [
						"asText",
						"asBinary",
						"asNodeBuffer",
						"asUint8Array",
						"asArrayBuffer"
					], l = function() {
						throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
					}, f = 0; f < u.length; f++) n.prototype[u[f]] = l;
					t.exports = n;
				}, {
					"./compressedObject": 2,
					"./stream/DataWorker": 27,
					"./stream/GenericWorker": 28,
					"./stream/StreamHelper": 29,
					"./utf8": 31
				}],
				36: [function(e, l, t) {
					(function(t) {
						"use strict";
						var r;
						var n;
						var e = t.MutationObserver || t.WebKitMutationObserver;
						if (e) {
							var i = 0;
							var s = new e(u);
							var a = t.document.createTextNode("");
							s.observe(a, { characterData: !0 }), r = function() {
								a.data = i = ++i % 2;
							};
						} else if (t.setImmediate || void 0 === t.MessageChannel) r = "document" in t && "onreadystatechange" in t.document.createElement("script") ? function() {
							var e = t.document.createElement("script");
							e.onreadystatechange = function() {
								u(), e.onreadystatechange = null, e.parentNode.removeChild(e), e = null;
							}, t.document.documentElement.appendChild(e);
						} : function() {
							setTimeout(u, 0);
						};
						else {
							var o = new t.MessageChannel();
							o.port1.onmessage = u, r = function() {
								o.port2.postMessage(0);
							};
						}
						var h = [];
						function u() {
							var e;
							var t;
							n = !0;
							for (var r = h.length; r;) {
								for (t = h, h = [], e = -1; ++e < r;) t[e]();
								r = h.length;
							}
							n = !1;
						}
						l.exports = function(e) {
							1 !== h.push(e) || n || r();
						};
					}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
				}, {}],
				37: [function(e, t, r) {
					"use strict";
					var i = e("immediate");
					function u() {}
					var l = {};
					var s = ["REJECTED"];
					var a = ["FULFILLED"];
					var n = ["PENDING"];
					function o(e) {
						if ("function" != typeof e) throw new TypeError("resolver must be a function");
						this.state = n, this.queue = [], this.outcome = void 0, e !== u && d(this, e);
					}
					function h(e, t, r) {
						this.promise = e, "function" == typeof t && (this.onFulfilled = t, this.callFulfilled = this.otherCallFulfilled), "function" == typeof r && (this.onRejected = r, this.callRejected = this.otherCallRejected);
					}
					function f(t, r, n) {
						i(function() {
							var e;
							try {
								e = r(n);
							} catch (e) {
								return l.reject(t, e);
							}
							e === t ? l.reject(t, /* @__PURE__ */ new TypeError("Cannot resolve promise with itself")) : l.resolve(t, e);
						});
					}
					function c(e) {
						var t = e && e.then;
						if (e && ("object" == typeof e || "function" == typeof e) && "function" == typeof t) return function() {
							t.apply(e, arguments);
						};
					}
					function d(t, e) {
						var r = !1;
						function n(e) {
							r || (r = !0, l.reject(t, e));
						}
						function i(e) {
							r || (r = !0, l.resolve(t, e));
						}
						var s = p(function() {
							e(i, n);
						});
						"error" === s.status && n(s.value);
					}
					function p(e, t) {
						var r = {};
						try {
							r.value = e(t), r.status = "success";
						} catch (e) {
							r.status = "error", r.value = e;
						}
						return r;
					}
					(t.exports = o).prototype.finally = function(t) {
						if ("function" != typeof t) return this;
						var r = this.constructor;
						return this.then(function(e) {
							return r.resolve(t()).then(function() {
								return e;
							});
						}, function(e) {
							return r.resolve(t()).then(function() {
								throw e;
							});
						});
					}, o.prototype.catch = function(e) {
						return this.then(null, e);
					}, o.prototype.then = function(e, t) {
						if ("function" != typeof e && this.state === a || "function" != typeof t && this.state === s) return this;
						var r = new this.constructor(u);
						this.state !== n ? f(r, this.state === a ? e : t, this.outcome) : this.queue.push(new h(r, e, t));
						return r;
					}, h.prototype.callFulfilled = function(e) {
						l.resolve(this.promise, e);
					}, h.prototype.otherCallFulfilled = function(e) {
						f(this.promise, this.onFulfilled, e);
					}, h.prototype.callRejected = function(e) {
						l.reject(this.promise, e);
					}, h.prototype.otherCallRejected = function(e) {
						f(this.promise, this.onRejected, e);
					}, l.resolve = function(e, t) {
						var r = p(c, t);
						if ("error" === r.status) return l.reject(e, r.value);
						var n = r.value;
						if (n) d(e, n);
						else {
							e.state = a, e.outcome = t;
							for (var i = -1, s = e.queue.length; ++i < s;) e.queue[i].callFulfilled(t);
						}
						return e;
					}, l.reject = function(e, t) {
						e.state = s, e.outcome = t;
						for (var r = -1, n = e.queue.length; ++r < n;) e.queue[r].callRejected(t);
						return e;
					}, o.resolve = function(e) {
						if (e instanceof this) return e;
						return l.resolve(new this(u), e);
					}, o.reject = function(e) {
						var t = new this(u);
						return l.reject(t, e);
					}, o.all = function(e) {
						var r = this;
						if ("[object Array]" !== Object.prototype.toString.call(e)) return this.reject(/* @__PURE__ */ new TypeError("must be an array"));
						var n = e.length;
						var i = !1;
						if (!n) return this.resolve([]);
						var s = new Array(n);
						var a = 0;
						var t = -1;
						var o = new this(u);
						for (; ++t < n;) h(e[t], t);
						return o;
						function h(e, t) {
							r.resolve(e).then(function(e) {
								s[t] = e, ++a !== n || i || (i = !0, l.resolve(o, s));
							}, function(e) {
								i || (i = !0, l.reject(o, e));
							});
						}
					}, o.race = function(e) {
						var t = this;
						if ("[object Array]" !== Object.prototype.toString.call(e)) return this.reject(/* @__PURE__ */ new TypeError("must be an array"));
						var r = e.length;
						var n = !1;
						if (!r) return this.resolve([]);
						var i = -1;
						var s = new this(u);
						for (; ++i < r;) a = e[i], t.resolve(a).then(function(e) {
							n || (n = !0, l.resolve(s, e));
						}, function(e) {
							n || (n = !0, l.reject(s, e));
						});
						var a;
						return s;
					};
				}, { immediate: 36 }],
				38: [function(e, t, r) {
					"use strict";
					var n = {};
					(0, e("./lib/utils/common").assign)(n, e("./lib/deflate"), e("./lib/inflate"), e("./lib/zlib/constants")), t.exports = n;
				}, {
					"./lib/deflate": 39,
					"./lib/inflate": 40,
					"./lib/utils/common": 41,
					"./lib/zlib/constants": 44
				}],
				39: [function(e, t, r) {
					"use strict";
					var a = e("./zlib/deflate");
					var o = e("./utils/common");
					var h = e("./utils/strings");
					var i = e("./zlib/messages");
					var s = e("./zlib/zstream");
					var u = Object.prototype.toString;
					var l = 0;
					var f = -1;
					var c = 0;
					var d = 8;
					function p(e) {
						if (!(this instanceof p)) return new p(e);
						this.options = o.assign({
							level: f,
							method: d,
							chunkSize: 16384,
							windowBits: 15,
							memLevel: 8,
							strategy: c,
							to: ""
						}, e || {});
						var t = this.options;
						t.raw && 0 < t.windowBits ? t.windowBits = -t.windowBits : t.gzip && 0 < t.windowBits && t.windowBits < 16 && (t.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new s(), this.strm.avail_out = 0;
						var r = a.deflateInit2(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy);
						if (r !== l) throw new Error(i[r]);
						if (t.header && a.deflateSetHeader(this.strm, t.header), t.dictionary) {
							var n;
							if (n = "string" == typeof t.dictionary ? h.string2buf(t.dictionary) : "[object ArrayBuffer]" === u.call(t.dictionary) ? new Uint8Array(t.dictionary) : t.dictionary, (r = a.deflateSetDictionary(this.strm, n)) !== l) throw new Error(i[r]);
							this._dict_set = !0;
						}
					}
					function n(e, t) {
						var r = new p(t);
						if (r.push(e, !0), r.err) throw r.msg || i[r.err];
						return r.result;
					}
					p.prototype.push = function(e, t) {
						var r;
						var n;
						var i = this.strm;
						var s = this.options.chunkSize;
						if (this.ended) return !1;
						n = t === ~~t ? t : !0 === t ? 4 : 0, "string" == typeof e ? i.input = h.string2buf(e) : "[object ArrayBuffer]" === u.call(e) ? i.input = new Uint8Array(e) : i.input = e, i.next_in = 0, i.avail_in = i.input.length;
						do {
							if (0 === i.avail_out && (i.output = new o.Buf8(s), i.next_out = 0, i.avail_out = s), 1 !== (r = a.deflate(i, n)) && r !== l) return this.onEnd(r), !(this.ended = !0);
							0 !== i.avail_out && (0 !== i.avail_in || 4 !== n && 2 !== n) || ("string" === this.options.to ? this.onData(h.buf2binstring(o.shrinkBuf(i.output, i.next_out))) : this.onData(o.shrinkBuf(i.output, i.next_out)));
						} while ((0 < i.avail_in || 0 === i.avail_out) && 1 !== r);
						return 4 === n ? (r = a.deflateEnd(this.strm), this.onEnd(r), this.ended = !0, r === l) : 2 !== n || (this.onEnd(l), !(i.avail_out = 0));
					}, p.prototype.onData = function(e) {
						this.chunks.push(e);
					}, p.prototype.onEnd = function(e) {
						e === l && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = o.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
					}, r.Deflate = p, r.deflate = n, r.deflateRaw = function(e, t) {
						return (t = t || {}).raw = !0, n(e, t);
					}, r.gzip = function(e, t) {
						return (t = t || {}).gzip = !0, n(e, t);
					};
				}, {
					"./utils/common": 41,
					"./utils/strings": 42,
					"./zlib/deflate": 46,
					"./zlib/messages": 51,
					"./zlib/zstream": 53
				}],
				40: [function(e, t, r) {
					"use strict";
					var c = e("./zlib/inflate");
					var d = e("./utils/common");
					var p = e("./utils/strings");
					var m = e("./zlib/constants");
					var n = e("./zlib/messages");
					var i = e("./zlib/zstream");
					var s = e("./zlib/gzheader");
					var _ = Object.prototype.toString;
					function a(e) {
						if (!(this instanceof a)) return new a(e);
						this.options = d.assign({
							chunkSize: 16384,
							windowBits: 0,
							to: ""
						}, e || {});
						var t = this.options;
						t.raw && 0 <= t.windowBits && t.windowBits < 16 && (t.windowBits = -t.windowBits, 0 === t.windowBits && (t.windowBits = -15)), !(0 <= t.windowBits && t.windowBits < 16) || e && e.windowBits || (t.windowBits += 32), 15 < t.windowBits && t.windowBits < 48 && 0 == (15 & t.windowBits) && (t.windowBits |= 15), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new i(), this.strm.avail_out = 0;
						var r = c.inflateInit2(this.strm, t.windowBits);
						if (r !== m.Z_OK) throw new Error(n[r]);
						this.header = new s(), c.inflateGetHeader(this.strm, this.header);
					}
					function o(e, t) {
						var r = new a(t);
						if (r.push(e, !0), r.err) throw r.msg || n[r.err];
						return r.result;
					}
					a.prototype.push = function(e, t) {
						var r;
						var n;
						var i;
						var s;
						var a;
						var o;
						var h = this.strm;
						var u = this.options.chunkSize;
						var l = this.options.dictionary;
						var f = !1;
						if (this.ended) return !1;
						n = t === ~~t ? t : !0 === t ? m.Z_FINISH : m.Z_NO_FLUSH, "string" == typeof e ? h.input = p.binstring2buf(e) : "[object ArrayBuffer]" === _.call(e) ? h.input = new Uint8Array(e) : h.input = e, h.next_in = 0, h.avail_in = h.input.length;
						do {
							if (0 === h.avail_out && (h.output = new d.Buf8(u), h.next_out = 0, h.avail_out = u), (r = c.inflate(h, m.Z_NO_FLUSH)) === m.Z_NEED_DICT && l && (o = "string" == typeof l ? p.string2buf(l) : "[object ArrayBuffer]" === _.call(l) ? new Uint8Array(l) : l, r = c.inflateSetDictionary(this.strm, o)), r === m.Z_BUF_ERROR && !0 === f && (r = m.Z_OK, f = !1), r !== m.Z_STREAM_END && r !== m.Z_OK) return this.onEnd(r), !(this.ended = !0);
							h.next_out && (0 !== h.avail_out && r !== m.Z_STREAM_END && (0 !== h.avail_in || n !== m.Z_FINISH && n !== m.Z_SYNC_FLUSH) || ("string" === this.options.to ? (i = p.utf8border(h.output, h.next_out), s = h.next_out - i, a = p.buf2string(h.output, i), h.next_out = s, h.avail_out = u - s, s && d.arraySet(h.output, h.output, i, s, 0), this.onData(a)) : this.onData(d.shrinkBuf(h.output, h.next_out)))), 0 === h.avail_in && 0 === h.avail_out && (f = !0);
						} while ((0 < h.avail_in || 0 === h.avail_out) && r !== m.Z_STREAM_END);
						return r === m.Z_STREAM_END && (n = m.Z_FINISH), n === m.Z_FINISH ? (r = c.inflateEnd(this.strm), this.onEnd(r), this.ended = !0, r === m.Z_OK) : n !== m.Z_SYNC_FLUSH || (this.onEnd(m.Z_OK), !(h.avail_out = 0));
					}, a.prototype.onData = function(e) {
						this.chunks.push(e);
					}, a.prototype.onEnd = function(e) {
						e === m.Z_OK && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = d.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
					}, r.Inflate = a, r.inflate = o, r.inflateRaw = function(e, t) {
						return (t = t || {}).raw = !0, o(e, t);
					}, r.ungzip = o;
				}, {
					"./utils/common": 41,
					"./utils/strings": 42,
					"./zlib/constants": 44,
					"./zlib/gzheader": 47,
					"./zlib/inflate": 49,
					"./zlib/messages": 51,
					"./zlib/zstream": 53
				}],
				41: [function(e, t, r) {
					"use strict";
					var n = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Int32Array;
					r.assign = function(e) {
						for (var t = Array.prototype.slice.call(arguments, 1); t.length;) {
							var r = t.shift();
							if (r) {
								if ("object" != typeof r) throw new TypeError(r + "must be non-object");
								for (var n in r) r.hasOwnProperty(n) && (e[n] = r[n]);
							}
						}
						return e;
					}, r.shrinkBuf = function(e, t) {
						return e.length === t ? e : e.subarray ? e.subarray(0, t) : (e.length = t, e);
					};
					var i = {
						arraySet: function(e, t, r, n, i) {
							if (t.subarray && e.subarray) e.set(t.subarray(r, r + n), i);
							else for (var s = 0; s < n; s++) e[i + s] = t[r + s];
						},
						flattenChunks: function(e) {
							var t;
							var r;
							var n;
							var i;
							var s;
							var a;
							for (t = n = 0, r = e.length; t < r; t++) n += e[t].length;
							for (a = new Uint8Array(n), t = i = 0, r = e.length; t < r; t++) s = e[t], a.set(s, i), i += s.length;
							return a;
						}
					};
					var s = {
						arraySet: function(e, t, r, n, i) {
							for (var s = 0; s < n; s++) e[i + s] = t[r + s];
						},
						flattenChunks: function(e) {
							return [].concat.apply([], e);
						}
					};
					r.setTyped = function(e) {
						e ? (r.Buf8 = Uint8Array, r.Buf16 = Uint16Array, r.Buf32 = Int32Array, r.assign(r, i)) : (r.Buf8 = Array, r.Buf16 = Array, r.Buf32 = Array, r.assign(r, s));
					}, r.setTyped(n);
				}, {}],
				42: [function(e, t, r) {
					"use strict";
					var h = e("./common");
					var i = !0;
					var s = !0;
					try {
						String.fromCharCode.apply(null, [0]);
					} catch (e) {
						i = !1;
					}
					try {
						String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1));
					} catch (e) {
						s = !1;
					}
					for (var u = new h.Buf8(256), n = 0; n < 256; n++) u[n] = 252 <= n ? 6 : 248 <= n ? 5 : 240 <= n ? 4 : 224 <= n ? 3 : 192 <= n ? 2 : 1;
					function l(e, t) {
						if (t < 65537 && (e.subarray && s || !e.subarray && i)) return String.fromCharCode.apply(null, h.shrinkBuf(e, t));
						for (var r = "", n = 0; n < t; n++) r += String.fromCharCode(e[n]);
						return r;
					}
					u[254] = u[254] = 1, r.string2buf = function(e) {
						var t;
						var r;
						var n;
						var i;
						var s;
						var a = e.length;
						var o = 0;
						for (i = 0; i < a; i++) 55296 == (64512 & (r = e.charCodeAt(i))) && i + 1 < a && 56320 == (64512 & (n = e.charCodeAt(i + 1))) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++), o += r < 128 ? 1 : r < 2048 ? 2 : r < 65536 ? 3 : 4;
						for (t = new h.Buf8(o), i = s = 0; s < o; i++) 55296 == (64512 & (r = e.charCodeAt(i))) && i + 1 < a && 56320 == (64512 & (n = e.charCodeAt(i + 1))) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++), r < 128 ? t[s++] = r : (r < 2048 ? t[s++] = 192 | r >>> 6 : (r < 65536 ? t[s++] = 224 | r >>> 12 : (t[s++] = 240 | r >>> 18, t[s++] = 128 | r >>> 12 & 63), t[s++] = 128 | r >>> 6 & 63), t[s++] = 128 | 63 & r);
						return t;
					}, r.buf2binstring = function(e) {
						return l(e, e.length);
					}, r.binstring2buf = function(e) {
						for (var t = new h.Buf8(e.length), r = 0, n = t.length; r < n; r++) t[r] = e.charCodeAt(r);
						return t;
					}, r.buf2string = function(e, t) {
						var r;
						var n;
						var i;
						var s;
						var a = t || e.length;
						var o = new Array(2 * a);
						for (r = n = 0; r < a;) if ((i = e[r++]) < 128) o[n++] = i;
						else if (4 < (s = u[i])) o[n++] = 65533, r += s - 1;
						else {
							for (i &= 2 === s ? 31 : 3 === s ? 15 : 7; 1 < s && r < a;) i = i << 6 | 63 & e[r++], s--;
							1 < s ? o[n++] = 65533 : i < 65536 ? o[n++] = i : (i -= 65536, o[n++] = 55296 | i >> 10 & 1023, o[n++] = 56320 | 1023 & i);
						}
						return l(o, n);
					}, r.utf8border = function(e, t) {
						var r;
						for ((t = t || e.length) > e.length && (t = e.length), r = t - 1; 0 <= r && 128 == (192 & e[r]);) r--;
						return r < 0 ? t : 0 === r ? t : r + u[e[r]] > t ? r : t;
					};
				}, { "./common": 41 }],
				43: [function(e, t, r) {
					"use strict";
					t.exports = function(e, t, r, n) {
						for (var i = 65535 & e | 0, s = e >>> 16 & 65535 | 0, a = 0; 0 !== r;) {
							for (r -= a = 2e3 < r ? 2e3 : r; s = s + (i = i + t[n++] | 0) | 0, --a;);
							i %= 65521, s %= 65521;
						}
						return i | s << 16 | 0;
					};
				}, {}],
				44: [function(e, t, r) {
					"use strict";
					t.exports = {
						Z_NO_FLUSH: 0,
						Z_PARTIAL_FLUSH: 1,
						Z_SYNC_FLUSH: 2,
						Z_FULL_FLUSH: 3,
						Z_FINISH: 4,
						Z_BLOCK: 5,
						Z_TREES: 6,
						Z_OK: 0,
						Z_STREAM_END: 1,
						Z_NEED_DICT: 2,
						Z_ERRNO: -1,
						Z_STREAM_ERROR: -2,
						Z_DATA_ERROR: -3,
						Z_BUF_ERROR: -5,
						Z_NO_COMPRESSION: 0,
						Z_BEST_SPEED: 1,
						Z_BEST_COMPRESSION: 9,
						Z_DEFAULT_COMPRESSION: -1,
						Z_FILTERED: 1,
						Z_HUFFMAN_ONLY: 2,
						Z_RLE: 3,
						Z_FIXED: 4,
						Z_DEFAULT_STRATEGY: 0,
						Z_BINARY: 0,
						Z_TEXT: 1,
						Z_UNKNOWN: 2,
						Z_DEFLATED: 8
					};
				}, {}],
				45: [function(e, t, r) {
					"use strict";
					var o = function() {
						for (var e, t = [], r = 0; r < 256; r++) {
							e = r;
							for (var n = 0; n < 8; n++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
							t[r] = e;
						}
						return t;
					}();
					t.exports = function(e, t, r, n) {
						var i = o;
						var s = n + r;
						e ^= -1;
						for (var a = n; a < s; a++) e = e >>> 8 ^ i[255 & (e ^ t[a])];
						return -1 ^ e;
					};
				}, {}],
				46: [function(e, t, r) {
					"use strict";
					var h;
					var c = e("../utils/common");
					var u = e("./trees");
					var d = e("./adler32");
					var p = e("./crc32");
					var n = e("./messages");
					var l = 0;
					var f = 4;
					var m = 0;
					var _ = -2;
					var g = -1;
					var b = 4;
					var i = 2;
					var v = 8;
					var y = 9;
					var s = 286;
					var a = 30;
					var o = 19;
					var w = 2 * s + 1;
					var k = 15;
					var x = 3;
					var S = 258;
					var z = S + x + 1;
					var C = 42;
					var E = 113;
					var A = 1;
					var I = 2;
					var O = 3;
					var B = 4;
					function R(e, t) {
						return e.msg = n[t], t;
					}
					function T(e) {
						return (e << 1) - (4 < e ? 9 : 0);
					}
					function D(e) {
						for (var t = e.length; 0 <= --t;) e[t] = 0;
					}
					function F(e) {
						var t = e.state;
						var r = t.pending;
						r > e.avail_out && (r = e.avail_out), 0 !== r && (c.arraySet(e.output, t.pending_buf, t.pending_out, r, e.next_out), e.next_out += r, t.pending_out += r, e.total_out += r, e.avail_out -= r, t.pending -= r, 0 === t.pending && (t.pending_out = 0));
					}
					function N(e, t) {
						u._tr_flush_block(e, 0 <= e.block_start ? e.block_start : -1, e.strstart - e.block_start, t), e.block_start = e.strstart, F(e.strm);
					}
					function U(e, t) {
						e.pending_buf[e.pending++] = t;
					}
					function P(e, t) {
						e.pending_buf[e.pending++] = t >>> 8 & 255, e.pending_buf[e.pending++] = 255 & t;
					}
					function L(e, t) {
						var r;
						var n;
						var i = e.max_chain_length;
						var s = e.strstart;
						var a = e.prev_length;
						var o = e.nice_match;
						var h = e.strstart > e.w_size - z ? e.strstart - (e.w_size - z) : 0;
						var u = e.window;
						var l = e.w_mask;
						var f = e.prev;
						var c = e.strstart + S;
						var d = u[s + a - 1];
						var p = u[s + a];
						e.prev_length >= e.good_match && (i >>= 2), o > e.lookahead && (o = e.lookahead);
						do
							if (u[(r = t) + a] === p && u[r + a - 1] === d && u[r] === u[s] && u[++r] === u[s + 1]) {
								s += 2, r++;
								do								;
while (u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && s < c);
								if (n = S - (c - s), s = c - S, a < n) {
									if (e.match_start = t, o <= (a = n)) break;
									d = u[s + a - 1], p = u[s + a];
								}
							}
						while ((t = f[t & l]) > h && 0 != --i);
						return a <= e.lookahead ? a : e.lookahead;
					}
					function j(e) {
						var t;
						var r;
						var n;
						var i;
						var s;
						var a;
						var o;
						var h;
						var u;
						var l;
						var f = e.w_size;
						do {
							if (i = e.window_size - e.lookahead - e.strstart, e.strstart >= f + (f - z)) {
								for (c.arraySet(e.window, e.window, f, f, 0), e.match_start -= f, e.strstart -= f, e.block_start -= f, t = r = e.hash_size; n = e.head[--t], e.head[t] = f <= n ? n - f : 0, --r;);
								for (t = r = f; n = e.prev[--t], e.prev[t] = f <= n ? n - f : 0, --r;);
								i += f;
							}
							if (0 === e.strm.avail_in) break;
							if (a = e.strm, o = e.window, h = e.strstart + e.lookahead, u = i, l = void 0, l = a.avail_in, u < l && (l = u), r = 0 === l ? 0 : (a.avail_in -= l, c.arraySet(o, a.input, a.next_in, l, h), 1 === a.state.wrap ? a.adler = d(a.adler, o, l, h) : 2 === a.state.wrap && (a.adler = p(a.adler, o, l, h)), a.next_in += l, a.total_in += l, l), e.lookahead += r, e.lookahead + e.insert >= x) for (s = e.strstart - e.insert, e.ins_h = e.window[s], e.ins_h = (e.ins_h << e.hash_shift ^ e.window[s + 1]) & e.hash_mask; e.insert && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[s + x - 1]) & e.hash_mask, e.prev[s & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = s, s++, e.insert--, !(e.lookahead + e.insert < x)););
						} while (e.lookahead < z && 0 !== e.strm.avail_in);
					}
					function Z(e, t) {
						for (var r, n;;) {
							if (e.lookahead < z) {
								if (j(e), e.lookahead < z && t === l) return A;
								if (0 === e.lookahead) break;
							}
							if (r = 0, e.lookahead >= x && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + x - 1]) & e.hash_mask, r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), 0 !== r && e.strstart - r <= e.w_size - z && (e.match_length = L(e, r)), e.match_length >= x) if (n = u._tr_tally(e, e.strstart - e.match_start, e.match_length - x), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= x) {
								for (e.match_length--; e.strstart++, e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + x - 1]) & e.hash_mask, r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart, 0 != --e.match_length;);
								e.strstart++;
							} else e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + 1]) & e.hash_mask;
							else n = u._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
							if (n && (N(e, !1), 0 === e.strm.avail_out)) return A;
						}
						return e.insert = e.strstart < x - 1 ? e.strstart : x - 1, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : e.last_lit && (N(e, !1), 0 === e.strm.avail_out) ? A : I;
					}
					function W(e, t) {
						for (var r, n, i;;) {
							if (e.lookahead < z) {
								if (j(e), e.lookahead < z && t === l) return A;
								if (0 === e.lookahead) break;
							}
							if (r = 0, e.lookahead >= x && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + x - 1]) & e.hash_mask, r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = x - 1, 0 !== r && e.prev_length < e.max_lazy_match && e.strstart - r <= e.w_size - z && (e.match_length = L(e, r), e.match_length <= 5 && (1 === e.strategy || e.match_length === x && 4096 < e.strstart - e.match_start) && (e.match_length = x - 1)), e.prev_length >= x && e.match_length <= e.prev_length) {
								for (i = e.strstart + e.lookahead - x, n = u._tr_tally(e, e.strstart - 1 - e.prev_match, e.prev_length - x), e.lookahead -= e.prev_length - 1, e.prev_length -= 2; ++e.strstart <= i && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + x - 1]) & e.hash_mask, r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), 0 != --e.prev_length;);
								if (e.match_available = 0, e.match_length = x - 1, e.strstart++, n && (N(e, !1), 0 === e.strm.avail_out)) return A;
							} else if (e.match_available) {
								if ((n = u._tr_tally(e, 0, e.window[e.strstart - 1])) && N(e, !1), e.strstart++, e.lookahead--, 0 === e.strm.avail_out) return A;
							} else e.match_available = 1, e.strstart++, e.lookahead--;
						}
						return e.match_available && (n = u._tr_tally(e, 0, e.window[e.strstart - 1]), e.match_available = 0), e.insert = e.strstart < x - 1 ? e.strstart : x - 1, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : e.last_lit && (N(e, !1), 0 === e.strm.avail_out) ? A : I;
					}
					function M(e, t, r, n, i) {
						this.good_length = e, this.max_lazy = t, this.nice_length = r, this.max_chain = n, this.func = i;
					}
					function H() {
						this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = v, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new c.Buf16(2 * w), this.dyn_dtree = new c.Buf16(2 * (2 * a + 1)), this.bl_tree = new c.Buf16(2 * (2 * o + 1)), D(this.dyn_ltree), D(this.dyn_dtree), D(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new c.Buf16(k + 1), this.heap = new c.Buf16(2 * s + 1), D(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new c.Buf16(2 * s + 1), D(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
					}
					function G(e) {
						var t;
						return e && e.state ? (e.total_in = e.total_out = 0, e.data_type = i, (t = e.state).pending = 0, t.pending_out = 0, t.wrap < 0 && (t.wrap = -t.wrap), t.status = t.wrap ? C : E, e.adler = 2 === t.wrap ? 0 : 1, t.last_flush = l, u._tr_init(t), m) : R(e, _);
					}
					function K(e) {
						var t = G(e);
						return t === m && function(e) {
							e.window_size = 2 * e.w_size, D(e.head), e.max_lazy_match = h[e.level].max_lazy, e.good_match = h[e.level].good_length, e.nice_match = h[e.level].nice_length, e.max_chain_length = h[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = x - 1, e.match_available = 0, e.ins_h = 0;
						}(e.state), t;
					}
					function Y(e, t, r, n, i, s) {
						if (!e) return _;
						var a = 1;
						if (t === g && (t = 6), n < 0 ? (a = 0, n = -n) : 15 < n && (a = 2, n -= 16), i < 1 || y < i || r !== v || n < 8 || 15 < n || t < 0 || 9 < t || s < 0 || b < s) return R(e, _);
						8 === n && (n = 9);
						var o = new H();
						return (e.state = o).strm = e, o.wrap = a, o.gzhead = null, o.w_bits = n, o.w_size = 1 << o.w_bits, o.w_mask = o.w_size - 1, o.hash_bits = i + 7, o.hash_size = 1 << o.hash_bits, o.hash_mask = o.hash_size - 1, o.hash_shift = ~~((o.hash_bits + x - 1) / x), o.window = new c.Buf8(2 * o.w_size), o.head = new c.Buf16(o.hash_size), o.prev = new c.Buf16(o.w_size), o.lit_bufsize = 1 << i + 6, o.pending_buf_size = 4 * o.lit_bufsize, o.pending_buf = new c.Buf8(o.pending_buf_size), o.d_buf = 1 * o.lit_bufsize, o.l_buf = 3 * o.lit_bufsize, o.level = t, o.strategy = s, o.method = r, K(e);
					}
					h = [
						new M(0, 0, 0, 0, function(e, t) {
							var r = 65535;
							for (r > e.pending_buf_size - 5 && (r = e.pending_buf_size - 5);;) {
								if (e.lookahead <= 1) {
									if (j(e), 0 === e.lookahead && t === l) return A;
									if (0 === e.lookahead) break;
								}
								e.strstart += e.lookahead, e.lookahead = 0;
								var n = e.block_start + r;
								if ((0 === e.strstart || e.strstart >= n) && (e.lookahead = e.strstart - n, e.strstart = n, N(e, !1), 0 === e.strm.avail_out)) return A;
								if (e.strstart - e.block_start >= e.w_size - z && (N(e, !1), 0 === e.strm.avail_out)) return A;
							}
							return e.insert = 0, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : (e.strstart > e.block_start && (N(e, !1), e.strm.avail_out), A);
						}),
						new M(4, 4, 8, 4, Z),
						new M(4, 5, 16, 8, Z),
						new M(4, 6, 32, 32, Z),
						new M(4, 4, 16, 16, W),
						new M(8, 16, 32, 32, W),
						new M(8, 16, 128, 128, W),
						new M(8, 32, 128, 256, W),
						new M(32, 128, 258, 1024, W),
						new M(32, 258, 258, 4096, W)
					], r.deflateInit = function(e, t) {
						return Y(e, t, v, 15, 8, 0);
					}, r.deflateInit2 = Y, r.deflateReset = K, r.deflateResetKeep = G, r.deflateSetHeader = function(e, t) {
						return e && e.state ? 2 !== e.state.wrap ? _ : (e.state.gzhead = t, m) : _;
					}, r.deflate = function(e, t) {
						var r;
						var n;
						var i;
						var s;
						if (!e || !e.state || 5 < t || t < 0) return e ? R(e, _) : _;
						if (n = e.state, !e.output || !e.input && 0 !== e.avail_in || 666 === n.status && t !== f) return R(e, 0 === e.avail_out ? -5 : _);
						if (n.strm = e, r = n.last_flush, n.last_flush = t, n.status === C) if (2 === n.wrap) e.adler = 0, U(n, 31), U(n, 139), U(n, 8), n.gzhead ? (U(n, (n.gzhead.text ? 1 : 0) + (n.gzhead.hcrc ? 2 : 0) + (n.gzhead.extra ? 4 : 0) + (n.gzhead.name ? 8 : 0) + (n.gzhead.comment ? 16 : 0)), U(n, 255 & n.gzhead.time), U(n, n.gzhead.time >> 8 & 255), U(n, n.gzhead.time >> 16 & 255), U(n, n.gzhead.time >> 24 & 255), U(n, 9 === n.level ? 2 : 2 <= n.strategy || n.level < 2 ? 4 : 0), U(n, 255 & n.gzhead.os), n.gzhead.extra && n.gzhead.extra.length && (U(n, 255 & n.gzhead.extra.length), U(n, n.gzhead.extra.length >> 8 & 255)), n.gzhead.hcrc && (e.adler = p(e.adler, n.pending_buf, n.pending, 0)), n.gzindex = 0, n.status = 69) : (U(n, 0), U(n, 0), U(n, 0), U(n, 0), U(n, 0), U(n, 9 === n.level ? 2 : 2 <= n.strategy || n.level < 2 ? 4 : 0), U(n, 3), n.status = E);
						else {
							var a = v + (n.w_bits - 8 << 4) << 8;
							a |= (2 <= n.strategy || n.level < 2 ? 0 : n.level < 6 ? 1 : 6 === n.level ? 2 : 3) << 6, 0 !== n.strstart && (a |= 32), a += 31 - a % 31, n.status = E, P(n, a), 0 !== n.strstart && (P(n, e.adler >>> 16), P(n, 65535 & e.adler)), e.adler = 1;
						}
						if (69 === n.status) if (n.gzhead.extra) {
							for (i = n.pending; n.gzindex < (65535 & n.gzhead.extra.length) && (n.pending !== n.pending_buf_size || (n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), F(e), i = n.pending, n.pending !== n.pending_buf_size));) U(n, 255 & n.gzhead.extra[n.gzindex]), n.gzindex++;
							n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), n.gzindex === n.gzhead.extra.length && (n.gzindex = 0, n.status = 73);
						} else n.status = 73;
						if (73 === n.status) if (n.gzhead.name) {
							i = n.pending;
							do {
								if (n.pending === n.pending_buf_size && (n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), F(e), i = n.pending, n.pending === n.pending_buf_size)) {
									s = 1;
									break;
								}
								s = n.gzindex < n.gzhead.name.length ? 255 & n.gzhead.name.charCodeAt(n.gzindex++) : 0, U(n, s);
							} while (0 !== s);
							n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), 0 === s && (n.gzindex = 0, n.status = 91);
						} else n.status = 91;
						if (91 === n.status) if (n.gzhead.comment) {
							i = n.pending;
							do {
								if (n.pending === n.pending_buf_size && (n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), F(e), i = n.pending, n.pending === n.pending_buf_size)) {
									s = 1;
									break;
								}
								s = n.gzindex < n.gzhead.comment.length ? 255 & n.gzhead.comment.charCodeAt(n.gzindex++) : 0, U(n, s);
							} while (0 !== s);
							n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), 0 === s && (n.status = 103);
						} else n.status = 103;
						if (103 === n.status && (n.gzhead.hcrc ? (n.pending + 2 > n.pending_buf_size && F(e), n.pending + 2 <= n.pending_buf_size && (U(n, 255 & e.adler), U(n, e.adler >> 8 & 255), e.adler = 0, n.status = E)) : n.status = E), 0 !== n.pending) {
							if (F(e), 0 === e.avail_out) return n.last_flush = -1, m;
						} else if (0 === e.avail_in && T(t) <= T(r) && t !== f) return R(e, -5);
						if (666 === n.status && 0 !== e.avail_in) return R(e, -5);
						if (0 !== e.avail_in || 0 !== n.lookahead || t !== l && 666 !== n.status) {
							var o = 2 === n.strategy ? function(e, t) {
								for (var r;;) {
									if (0 === e.lookahead && (j(e), 0 === e.lookahead)) {
										if (t === l) return A;
										break;
									}
									if (e.match_length = 0, r = u._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, r && (N(e, !1), 0 === e.strm.avail_out)) return A;
								}
								return e.insert = 0, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : e.last_lit && (N(e, !1), 0 === e.strm.avail_out) ? A : I;
							}(n, t) : 3 === n.strategy ? function(e, t) {
								for (var r, n, i, s, a = e.window;;) {
									if (e.lookahead <= S) {
										if (j(e), e.lookahead <= S && t === l) return A;
										if (0 === e.lookahead) break;
									}
									if (e.match_length = 0, e.lookahead >= x && 0 < e.strstart && (n = a[i = e.strstart - 1]) === a[++i] && n === a[++i] && n === a[++i]) {
										s = e.strstart + S;
										do										;
while (n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && i < s);
										e.match_length = S - (s - i), e.match_length > e.lookahead && (e.match_length = e.lookahead);
									}
									if (e.match_length >= x ? (r = u._tr_tally(e, 1, e.match_length - x), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (r = u._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), r && (N(e, !1), 0 === e.strm.avail_out)) return A;
								}
								return e.insert = 0, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : e.last_lit && (N(e, !1), 0 === e.strm.avail_out) ? A : I;
							}(n, t) : h[n.level].func(n, t);
							if (o !== O && o !== B || (n.status = 666), o === A || o === O) return 0 === e.avail_out && (n.last_flush = -1), m;
							if (o === I && (1 === t ? u._tr_align(n) : 5 !== t && (u._tr_stored_block(n, 0, 0, !1), 3 === t && (D(n.head), 0 === n.lookahead && (n.strstart = 0, n.block_start = 0, n.insert = 0))), F(e), 0 === e.avail_out)) return n.last_flush = -1, m;
						}
						return t !== f ? m : n.wrap <= 0 ? 1 : (2 === n.wrap ? (U(n, 255 & e.adler), U(n, e.adler >> 8 & 255), U(n, e.adler >> 16 & 255), U(n, e.adler >> 24 & 255), U(n, 255 & e.total_in), U(n, e.total_in >> 8 & 255), U(n, e.total_in >> 16 & 255), U(n, e.total_in >> 24 & 255)) : (P(n, e.adler >>> 16), P(n, 65535 & e.adler)), F(e), 0 < n.wrap && (n.wrap = -n.wrap), 0 !== n.pending ? m : 1);
					}, r.deflateEnd = function(e) {
						var t;
						return e && e.state ? (t = e.state.status) !== C && 69 !== t && 73 !== t && 91 !== t && 103 !== t && t !== E && 666 !== t ? R(e, _) : (e.state = null, t === E ? R(e, -3) : m) : _;
					}, r.deflateSetDictionary = function(e, t) {
						var r;
						var n;
						var i;
						var s;
						var a;
						var o;
						var h;
						var u;
						var l = t.length;
						if (!e || !e.state) return _;
						if (2 === (s = (r = e.state).wrap) || 1 === s && r.status !== C || r.lookahead) return _;
						for (1 === s && (e.adler = d(e.adler, t, l, 0)), r.wrap = 0, l >= r.w_size && (0 === s && (D(r.head), r.strstart = 0, r.block_start = 0, r.insert = 0), u = new c.Buf8(r.w_size), c.arraySet(u, t, l - r.w_size, r.w_size, 0), t = u, l = r.w_size), a = e.avail_in, o = e.next_in, h = e.input, e.avail_in = l, e.next_in = 0, e.input = t, j(r); r.lookahead >= x;) {
							for (n = r.strstart, i = r.lookahead - (x - 1); r.ins_h = (r.ins_h << r.hash_shift ^ r.window[n + x - 1]) & r.hash_mask, r.prev[n & r.w_mask] = r.head[r.ins_h], r.head[r.ins_h] = n, n++, --i;);
							r.strstart = n, r.lookahead = x - 1, j(r);
						}
						return r.strstart += r.lookahead, r.block_start = r.strstart, r.insert = r.lookahead, r.lookahead = 0, r.match_length = r.prev_length = x - 1, r.match_available = 0, e.next_in = o, e.input = h, e.avail_in = a, r.wrap = s, m;
					}, r.deflateInfo = "pako deflate (from Nodeca project)";
				}, {
					"../utils/common": 41,
					"./adler32": 43,
					"./crc32": 45,
					"./messages": 51,
					"./trees": 52
				}],
				47: [function(e, t, r) {
					"use strict";
					t.exports = function() {
						this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1;
					};
				}, {}],
				48: [function(e, t, r) {
					"use strict";
					t.exports = function(e, t) {
						var r = e.state;
						var n = e.next_in;
						var i;
						var s;
						var a;
						var o;
						var h;
						var u;
						var l;
						var f;
						var c;
						var d;
						var p;
						var m;
						var _;
						var g;
						var b;
						var v;
						var y;
						var w;
						var k;
						var x;
						var S;
						var z = e.input;
						var C;
						i = n + (e.avail_in - 5), s = e.next_out, C = e.output, a = s - (t - e.avail_out), o = s + (e.avail_out - 257), h = r.dmax, u = r.wsize, l = r.whave, f = r.wnext, c = r.window, d = r.hold, p = r.bits, m = r.lencode, _ = r.distcode, g = (1 << r.lenbits) - 1, b = (1 << r.distbits) - 1;
						e: do {
							p < 15 && (d += z[n++] << p, p += 8, d += z[n++] << p, p += 8), v = m[d & g];
							t: for (;;) {
								if (d >>>= y = v >>> 24, p -= y, 0 === (y = v >>> 16 & 255)) C[s++] = 65535 & v;
								else {
									if (!(16 & y)) {
										if (0 == (64 & y)) {
											v = m[(65535 & v) + (d & (1 << y) - 1)];
											continue t;
										}
										if (32 & y) {
											r.mode = 12;
											break e;
										}
										e.msg = "invalid literal/length code", r.mode = 30;
										break e;
									}
									w = 65535 & v, (y &= 15) && (p < y && (d += z[n++] << p, p += 8), w += d & (1 << y) - 1, d >>>= y, p -= y), p < 15 && (d += z[n++] << p, p += 8, d += z[n++] << p, p += 8), v = _[d & b];
									r: for (;;) {
										if (d >>>= y = v >>> 24, p -= y, !(16 & (y = v >>> 16 & 255))) {
											if (0 == (64 & y)) {
												v = _[(65535 & v) + (d & (1 << y) - 1)];
												continue r;
											}
											e.msg = "invalid distance code", r.mode = 30;
											break e;
										}
										if (k = 65535 & v, p < (y &= 15) && (d += z[n++] << p, (p += 8) < y && (d += z[n++] << p, p += 8)), h < (k += d & (1 << y) - 1)) {
											e.msg = "invalid distance too far back", r.mode = 30;
											break e;
										}
										if (d >>>= y, p -= y, (y = s - a) < k) {
											if (l < (y = k - y) && r.sane) {
												e.msg = "invalid distance too far back", r.mode = 30;
												break e;
											}
											if (S = c, (x = 0) === f) {
												if (x += u - y, y < w) {
													for (w -= y; C[s++] = c[x++], --y;);
													x = s - k, S = C;
												}
											} else if (f < y) {
												if (x += u + f - y, (y -= f) < w) {
													for (w -= y; C[s++] = c[x++], --y;);
													if (x = 0, f < w) {
														for (w -= y = f; C[s++] = c[x++], --y;);
														x = s - k, S = C;
													}
												}
											} else if (x += f - y, y < w) {
												for (w -= y; C[s++] = c[x++], --y;);
												x = s - k, S = C;
											}
											for (; 2 < w;) C[s++] = S[x++], C[s++] = S[x++], C[s++] = S[x++], w -= 3;
											w && (C[s++] = S[x++], 1 < w && (C[s++] = S[x++]));
										} else {
											for (x = s - k; C[s++] = C[x++], C[s++] = C[x++], C[s++] = C[x++], 2 < (w -= 3););
											w && (C[s++] = C[x++], 1 < w && (C[s++] = C[x++]));
										}
										break;
									}
								}
								break;
							}
						} while (n < i && s < o);
						n -= w = p >> 3, d &= (1 << (p -= w << 3)) - 1, e.next_in = n, e.next_out = s, e.avail_in = n < i ? i - n + 5 : 5 - (n - i), e.avail_out = s < o ? o - s + 257 : 257 - (s - o), r.hold = d, r.bits = p;
					};
				}, {}],
				49: [function(e, t, r) {
					"use strict";
					var I = e("../utils/common");
					var O = e("./adler32");
					var B = e("./crc32");
					var R = e("./inffast");
					var T = e("./inftrees");
					var D = 1;
					var F = 2;
					var N = 0;
					var U = -2;
					var P = 1;
					var n = 852;
					var i = 592;
					function L(e) {
						return (e >>> 24 & 255) + (e >>> 8 & 65280) + ((65280 & e) << 8) + ((255 & e) << 24);
					}
					function s() {
						this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new I.Buf16(320), this.work = new I.Buf16(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
					}
					function a(e) {
						var t;
						return e && e.state ? (t = e.state, e.total_in = e.total_out = t.total = 0, e.msg = "", t.wrap && (e.adler = 1 & t.wrap), t.mode = P, t.last = 0, t.havedict = 0, t.dmax = 32768, t.head = null, t.hold = 0, t.bits = 0, t.lencode = t.lendyn = new I.Buf32(n), t.distcode = t.distdyn = new I.Buf32(i), t.sane = 1, t.back = -1, N) : U;
					}
					function o(e) {
						var t;
						return e && e.state ? ((t = e.state).wsize = 0, t.whave = 0, t.wnext = 0, a(e)) : U;
					}
					function h(e, t) {
						var r;
						var n;
						return e && e.state ? (n = e.state, t < 0 ? (r = 0, t = -t) : (r = 1 + (t >> 4), t < 48 && (t &= 15)), t && (t < 8 || 15 < t) ? U : (null !== n.window && n.wbits !== t && (n.window = null), n.wrap = r, n.wbits = t, o(e))) : U;
					}
					function u(e, t) {
						var r;
						var n;
						return e ? (n = new s(), (e.state = n).window = null, (r = h(e, t)) !== N && (e.state = null), r) : U;
					}
					var l;
					var f;
					var c = !0;
					function j(e) {
						if (c) {
							var t;
							for (l = new I.Buf32(512), f = new I.Buf32(32), t = 0; t < 144;) e.lens[t++] = 8;
							for (; t < 256;) e.lens[t++] = 9;
							for (; t < 280;) e.lens[t++] = 7;
							for (; t < 288;) e.lens[t++] = 8;
							for (T(D, e.lens, 0, 288, l, 0, e.work, { bits: 9 }), t = 0; t < 32;) e.lens[t++] = 5;
							T(F, e.lens, 0, 32, f, 0, e.work, { bits: 5 }), c = !1;
						}
						e.lencode = l, e.lenbits = 9, e.distcode = f, e.distbits = 5;
					}
					function Z(e, t, r, n) {
						var i;
						var s = e.state;
						return null === s.window && (s.wsize = 1 << s.wbits, s.wnext = 0, s.whave = 0, s.window = new I.Buf8(s.wsize)), n >= s.wsize ? (I.arraySet(s.window, t, r - s.wsize, s.wsize, 0), s.wnext = 0, s.whave = s.wsize) : (n < (i = s.wsize - s.wnext) && (i = n), I.arraySet(s.window, t, r - n, i, s.wnext), (n -= i) ? (I.arraySet(s.window, t, r - n, n, 0), s.wnext = n, s.whave = s.wsize) : (s.wnext += i, s.wnext === s.wsize && (s.wnext = 0), s.whave < s.wsize && (s.whave += i))), 0;
					}
					r.inflateReset = o, r.inflateReset2 = h, r.inflateResetKeep = a, r.inflateInit = function(e) {
						return u(e, 15);
					}, r.inflateInit2 = u, r.inflate = function(e, t) {
						var r;
						var n;
						var i;
						var s;
						var a;
						var o;
						var h;
						var u;
						var l;
						var f;
						var c;
						var d;
						var p;
						var m;
						var _;
						var g;
						var b;
						var v;
						var y;
						var w;
						var k;
						var x;
						var S;
						var z;
						var C = 0;
						var E = new I.Buf8(4);
						var A = [
							16,
							17,
							18,
							0,
							8,
							7,
							9,
							6,
							10,
							5,
							11,
							4,
							12,
							3,
							13,
							2,
							14,
							1,
							15
						];
						if (!e || !e.state || !e.output || !e.input && 0 !== e.avail_in) return U;
						12 === (r = e.state).mode && (r.mode = 13), a = e.next_out, i = e.output, h = e.avail_out, s = e.next_in, n = e.input, o = e.avail_in, u = r.hold, l = r.bits, f = o, c = h, x = N;
						e: for (;;) switch (r.mode) {
							case P:
								if (0 === r.wrap) {
									r.mode = 13;
									break;
								}
								for (; l < 16;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if (2 & r.wrap && 35615 === u) {
									E[r.check = 0] = 255 & u, E[1] = u >>> 8 & 255, r.check = B(r.check, E, 2, 0), l = u = 0, r.mode = 2;
									break;
								}
								if (r.flags = 0, r.head && (r.head.done = !1), !(1 & r.wrap) || (((255 & u) << 8) + (u >> 8)) % 31) {
									e.msg = "incorrect header check", r.mode = 30;
									break;
								}
								if (8 != (15 & u)) {
									e.msg = "unknown compression method", r.mode = 30;
									break;
								}
								if (l -= 4, k = 8 + (15 & (u >>>= 4)), 0 === r.wbits) r.wbits = k;
								else if (k > r.wbits) {
									e.msg = "invalid window size", r.mode = 30;
									break;
								}
								r.dmax = 1 << k, e.adler = r.check = 1, r.mode = 512 & u ? 10 : 12, l = u = 0;
								break;
							case 2:
								for (; l < 16;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if (r.flags = u, 8 != (255 & r.flags)) {
									e.msg = "unknown compression method", r.mode = 30;
									break;
								}
								if (57344 & r.flags) {
									e.msg = "unknown header flags set", r.mode = 30;
									break;
								}
								r.head && (r.head.text = u >> 8 & 1), 512 & r.flags && (E[0] = 255 & u, E[1] = u >>> 8 & 255, r.check = B(r.check, E, 2, 0)), l = u = 0, r.mode = 3;
							case 3:
								for (; l < 32;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								r.head && (r.head.time = u), 512 & r.flags && (E[0] = 255 & u, E[1] = u >>> 8 & 255, E[2] = u >>> 16 & 255, E[3] = u >>> 24 & 255, r.check = B(r.check, E, 4, 0)), l = u = 0, r.mode = 4;
							case 4:
								for (; l < 16;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								r.head && (r.head.xflags = 255 & u, r.head.os = u >> 8), 512 & r.flags && (E[0] = 255 & u, E[1] = u >>> 8 & 255, r.check = B(r.check, E, 2, 0)), l = u = 0, r.mode = 5;
							case 5:
								if (1024 & r.flags) {
									for (; l < 16;) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									r.length = u, r.head && (r.head.extra_len = u), 512 & r.flags && (E[0] = 255 & u, E[1] = u >>> 8 & 255, r.check = B(r.check, E, 2, 0)), l = u = 0;
								} else r.head && (r.head.extra = null);
								r.mode = 6;
							case 6:
								if (1024 & r.flags && (o < (d = r.length) && (d = o), d && (r.head && (k = r.head.extra_len - r.length, r.head.extra || (r.head.extra = new Array(r.head.extra_len)), I.arraySet(r.head.extra, n, s, d, k)), 512 & r.flags && (r.check = B(r.check, n, d, s)), o -= d, s += d, r.length -= d), r.length)) break e;
								r.length = 0, r.mode = 7;
							case 7:
								if (2048 & r.flags) {
									if (0 === o) break e;
									for (d = 0; k = n[s + d++], r.head && k && r.length < 65536 && (r.head.name += String.fromCharCode(k)), k && d < o;);
									if (512 & r.flags && (r.check = B(r.check, n, d, s)), o -= d, s += d, k) break e;
								} else r.head && (r.head.name = null);
								r.length = 0, r.mode = 8;
							case 8:
								if (4096 & r.flags) {
									if (0 === o) break e;
									for (d = 0; k = n[s + d++], r.head && k && r.length < 65536 && (r.head.comment += String.fromCharCode(k)), k && d < o;);
									if (512 & r.flags && (r.check = B(r.check, n, d, s)), o -= d, s += d, k) break e;
								} else r.head && (r.head.comment = null);
								r.mode = 9;
							case 9:
								if (512 & r.flags) {
									for (; l < 16;) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									if (u !== (65535 & r.check)) {
										e.msg = "header crc mismatch", r.mode = 30;
										break;
									}
									l = u = 0;
								}
								r.head && (r.head.hcrc = r.flags >> 9 & 1, r.head.done = !0), e.adler = r.check = 0, r.mode = 12;
								break;
							case 10:
								for (; l < 32;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								e.adler = r.check = L(u), l = u = 0, r.mode = 11;
							case 11:
								if (0 === r.havedict) return e.next_out = a, e.avail_out = h, e.next_in = s, e.avail_in = o, r.hold = u, r.bits = l, 2;
								e.adler = r.check = 1, r.mode = 12;
							case 12: if (5 === t || 6 === t) break e;
							case 13:
								if (r.last) {
									u >>>= 7 & l, l -= 7 & l, r.mode = 27;
									break;
								}
								for (; l < 3;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								switch (r.last = 1 & u, l -= 1, 3 & (u >>>= 1)) {
									case 0:
										r.mode = 14;
										break;
									case 1:
										if (j(r), r.mode = 20, 6 !== t) break;
										u >>>= 2, l -= 2;
										break e;
									case 2:
										r.mode = 17;
										break;
									case 3: e.msg = "invalid block type", r.mode = 30;
								}
								u >>>= 2, l -= 2;
								break;
							case 14:
								for (u >>>= 7 & l, l -= 7 & l; l < 32;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if ((65535 & u) != (u >>> 16 ^ 65535)) {
									e.msg = "invalid stored block lengths", r.mode = 30;
									break;
								}
								if (r.length = 65535 & u, l = u = 0, r.mode = 15, 6 === t) break e;
							case 15: r.mode = 16;
							case 16:
								if (d = r.length) {
									if (o < d && (d = o), h < d && (d = h), 0 === d) break e;
									I.arraySet(i, n, s, d, a), o -= d, s += d, h -= d, a += d, r.length -= d;
									break;
								}
								r.mode = 12;
								break;
							case 17:
								for (; l < 14;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if (r.nlen = 257 + (31 & u), u >>>= 5, l -= 5, r.ndist = 1 + (31 & u), u >>>= 5, l -= 5, r.ncode = 4 + (15 & u), u >>>= 4, l -= 4, 286 < r.nlen || 30 < r.ndist) {
									e.msg = "too many length or distance symbols", r.mode = 30;
									break;
								}
								r.have = 0, r.mode = 18;
							case 18:
								for (; r.have < r.ncode;) {
									for (; l < 3;) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									r.lens[A[r.have++]] = 7 & u, u >>>= 3, l -= 3;
								}
								for (; r.have < 19;) r.lens[A[r.have++]] = 0;
								if (r.lencode = r.lendyn, r.lenbits = 7, S = { bits: r.lenbits }, x = T(0, r.lens, 0, 19, r.lencode, 0, r.work, S), r.lenbits = S.bits, x) {
									e.msg = "invalid code lengths set", r.mode = 30;
									break;
								}
								r.have = 0, r.mode = 19;
							case 19:
								for (; r.have < r.nlen + r.ndist;) {
									for (; g = (C = r.lencode[u & (1 << r.lenbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l);) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									if (b < 16) u >>>= _, l -= _, r.lens[r.have++] = b;
									else {
										if (16 === b) {
											for (z = _ + 2; l < z;) {
												if (0 === o) break e;
												o--, u += n[s++] << l, l += 8;
											}
											if (u >>>= _, l -= _, 0 === r.have) {
												e.msg = "invalid bit length repeat", r.mode = 30;
												break;
											}
											k = r.lens[r.have - 1], d = 3 + (3 & u), u >>>= 2, l -= 2;
										} else if (17 === b) {
											for (z = _ + 3; l < z;) {
												if (0 === o) break e;
												o--, u += n[s++] << l, l += 8;
											}
											l -= _, k = 0, d = 3 + (7 & (u >>>= _)), u >>>= 3, l -= 3;
										} else {
											for (z = _ + 7; l < z;) {
												if (0 === o) break e;
												o--, u += n[s++] << l, l += 8;
											}
											l -= _, k = 0, d = 11 + (127 & (u >>>= _)), u >>>= 7, l -= 7;
										}
										if (r.have + d > r.nlen + r.ndist) {
											e.msg = "invalid bit length repeat", r.mode = 30;
											break;
										}
										for (; d--;) r.lens[r.have++] = k;
									}
								}
								if (30 === r.mode) break;
								if (0 === r.lens[256]) {
									e.msg = "invalid code -- missing end-of-block", r.mode = 30;
									break;
								}
								if (r.lenbits = 9, S = { bits: r.lenbits }, x = T(D, r.lens, 0, r.nlen, r.lencode, 0, r.work, S), r.lenbits = S.bits, x) {
									e.msg = "invalid literal/lengths set", r.mode = 30;
									break;
								}
								if (r.distbits = 6, r.distcode = r.distdyn, S = { bits: r.distbits }, x = T(F, r.lens, r.nlen, r.ndist, r.distcode, 0, r.work, S), r.distbits = S.bits, x) {
									e.msg = "invalid distances set", r.mode = 30;
									break;
								}
								if (r.mode = 20, 6 === t) break e;
							case 20: r.mode = 21;
							case 21:
								if (6 <= o && 258 <= h) {
									e.next_out = a, e.avail_out = h, e.next_in = s, e.avail_in = o, r.hold = u, r.bits = l, R(e, c), a = e.next_out, i = e.output, h = e.avail_out, s = e.next_in, n = e.input, o = e.avail_in, u = r.hold, l = r.bits, 12 === r.mode && (r.back = -1);
									break;
								}
								for (r.back = 0; g = (C = r.lencode[u & (1 << r.lenbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l);) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if (g && 0 == (240 & g)) {
									for (v = _, y = g, w = b; g = (C = r.lencode[w + ((u & (1 << v + y) - 1) >> v)]) >>> 16 & 255, b = 65535 & C, !(v + (_ = C >>> 24) <= l);) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									u >>>= v, l -= v, r.back += v;
								}
								if (u >>>= _, l -= _, r.back += _, r.length = b, 0 === g) {
									r.mode = 26;
									break;
								}
								if (32 & g) {
									r.back = -1, r.mode = 12;
									break;
								}
								if (64 & g) {
									e.msg = "invalid literal/length code", r.mode = 30;
									break;
								}
								r.extra = 15 & g, r.mode = 22;
							case 22:
								if (r.extra) {
									for (z = r.extra; l < z;) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									r.length += u & (1 << r.extra) - 1, u >>>= r.extra, l -= r.extra, r.back += r.extra;
								}
								r.was = r.length, r.mode = 23;
							case 23:
								for (; g = (C = r.distcode[u & (1 << r.distbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l);) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if (0 == (240 & g)) {
									for (v = _, y = g, w = b; g = (C = r.distcode[w + ((u & (1 << v + y) - 1) >> v)]) >>> 16 & 255, b = 65535 & C, !(v + (_ = C >>> 24) <= l);) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									u >>>= v, l -= v, r.back += v;
								}
								if (u >>>= _, l -= _, r.back += _, 64 & g) {
									e.msg = "invalid distance code", r.mode = 30;
									break;
								}
								r.offset = b, r.extra = 15 & g, r.mode = 24;
							case 24:
								if (r.extra) {
									for (z = r.extra; l < z;) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									r.offset += u & (1 << r.extra) - 1, u >>>= r.extra, l -= r.extra, r.back += r.extra;
								}
								if (r.offset > r.dmax) {
									e.msg = "invalid distance too far back", r.mode = 30;
									break;
								}
								r.mode = 25;
							case 25:
								if (0 === h) break e;
								if (d = c - h, r.offset > d) {
									if ((d = r.offset - d) > r.whave && r.sane) {
										e.msg = "invalid distance too far back", r.mode = 30;
										break;
									}
									p = d > r.wnext ? (d -= r.wnext, r.wsize - d) : r.wnext - d, d > r.length && (d = r.length), m = r.window;
								} else m = i, p = a - r.offset, d = r.length;
								for (h < d && (d = h), h -= d, r.length -= d; i[a++] = m[p++], --d;);
								0 === r.length && (r.mode = 21);
								break;
							case 26:
								if (0 === h) break e;
								i[a++] = r.length, h--, r.mode = 21;
								break;
							case 27:
								if (r.wrap) {
									for (; l < 32;) {
										if (0 === o) break e;
										o--, u |= n[s++] << l, l += 8;
									}
									if (c -= h, e.total_out += c, r.total += c, c && (e.adler = r.check = r.flags ? B(r.check, i, c, a - c) : O(r.check, i, c, a - c)), c = h, (r.flags ? u : L(u)) !== r.check) {
										e.msg = "incorrect data check", r.mode = 30;
										break;
									}
									l = u = 0;
								}
								r.mode = 28;
							case 28:
								if (r.wrap && r.flags) {
									for (; l < 32;) {
										if (0 === o) break e;
										o--, u += n[s++] << l, l += 8;
									}
									if (u !== (4294967295 & r.total)) {
										e.msg = "incorrect length check", r.mode = 30;
										break;
									}
									l = u = 0;
								}
								r.mode = 29;
							case 29:
								x = 1;
								break e;
							case 30:
								x = -3;
								break e;
							case 31: return -4;
							case 32:
							default: return U;
						}
						return e.next_out = a, e.avail_out = h, e.next_in = s, e.avail_in = o, r.hold = u, r.bits = l, (r.wsize || c !== e.avail_out && r.mode < 30 && (r.mode < 27 || 4 !== t)) && Z(e, e.output, e.next_out, c - e.avail_out) ? (r.mode = 31, -4) : (f -= e.avail_in, c -= e.avail_out, e.total_in += f, e.total_out += c, r.total += c, r.wrap && c && (e.adler = r.check = r.flags ? B(r.check, i, c, e.next_out - c) : O(r.check, i, c, e.next_out - c)), e.data_type = r.bits + (r.last ? 64 : 0) + (12 === r.mode ? 128 : 0) + (20 === r.mode || 15 === r.mode ? 256 : 0), (0 == f && 0 === c || 4 === t) && x === N && (x = -5), x);
					}, r.inflateEnd = function(e) {
						if (!e || !e.state) return U;
						var t = e.state;
						return t.window && (t.window = null), e.state = null, N;
					}, r.inflateGetHeader = function(e, t) {
						var r;
						return e && e.state ? 0 == (2 & (r = e.state).wrap) ? U : ((r.head = t).done = !1, N) : U;
					}, r.inflateSetDictionary = function(e, t) {
						var r;
						var n = t.length;
						return e && e.state ? 0 !== (r = e.state).wrap && 11 !== r.mode ? U : 11 === r.mode && O(1, t, n, 0) !== r.check ? -3 : Z(e, t, n, n) ? (r.mode = 31, -4) : (r.havedict = 1, N) : U;
					}, r.inflateInfo = "pako inflate (from Nodeca project)";
				}, {
					"../utils/common": 41,
					"./adler32": 43,
					"./crc32": 45,
					"./inffast": 48,
					"./inftrees": 50
				}],
				50: [function(e, t, r) {
					"use strict";
					var D = e("../utils/common");
					var F = [
						3,
						4,
						5,
						6,
						7,
						8,
						9,
						10,
						11,
						13,
						15,
						17,
						19,
						23,
						27,
						31,
						35,
						43,
						51,
						59,
						67,
						83,
						99,
						115,
						131,
						163,
						195,
						227,
						258,
						0,
						0
					];
					var N = [
						16,
						16,
						16,
						16,
						16,
						16,
						16,
						16,
						17,
						17,
						17,
						17,
						18,
						18,
						18,
						18,
						19,
						19,
						19,
						19,
						20,
						20,
						20,
						20,
						21,
						21,
						21,
						21,
						16,
						72,
						78
					];
					var U = [
						1,
						2,
						3,
						4,
						5,
						7,
						9,
						13,
						17,
						25,
						33,
						49,
						65,
						97,
						129,
						193,
						257,
						385,
						513,
						769,
						1025,
						1537,
						2049,
						3073,
						4097,
						6145,
						8193,
						12289,
						16385,
						24577,
						0,
						0
					];
					var P = [
						16,
						16,
						16,
						16,
						17,
						17,
						18,
						18,
						19,
						19,
						20,
						20,
						21,
						21,
						22,
						22,
						23,
						23,
						24,
						24,
						25,
						25,
						26,
						26,
						27,
						27,
						28,
						28,
						29,
						29,
						64,
						64
					];
					t.exports = function(e, t, r, n, i, s, a, o) {
						var h;
						var u;
						var l;
						var f;
						var c;
						var d;
						var p;
						var m;
						var _;
						var g = o.bits;
						var b = 0;
						var v = 0;
						var y = 0;
						var w = 0;
						var k = 0;
						var x = 0;
						var S = 0;
						var z = 0;
						var C = 0;
						var E = 0;
						var A = null;
						var I = 0;
						var O = new D.Buf16(16);
						var B = new D.Buf16(16);
						var R = null;
						var T = 0;
						for (b = 0; b <= 15; b++) O[b] = 0;
						for (v = 0; v < n; v++) O[t[r + v]]++;
						for (k = g, w = 15; 1 <= w && 0 === O[w]; w--);
						if (w < k && (k = w), 0 === w) return i[s++] = 20971520, i[s++] = 20971520, o.bits = 1, 0;
						for (y = 1; y < w && 0 === O[y]; y++);
						for (k < y && (k = y), b = z = 1; b <= 15; b++) if (z <<= 1, (z -= O[b]) < 0) return -1;
						if (0 < z && (0 === e || 1 !== w)) return -1;
						for (B[1] = 0, b = 1; b < 15; b++) B[b + 1] = B[b] + O[b];
						for (v = 0; v < n; v++) 0 !== t[r + v] && (a[B[t[r + v]]++] = v);
						if (d = 0 === e ? (A = R = a, 19) : 1 === e ? (A = F, I -= 257, R = N, T -= 257, 256) : (A = U, R = P, -1), b = y, c = s, S = v = E = 0, l = -1, f = (C = 1 << (x = k)) - 1, 1 === e && 852 < C || 2 === e && 592 < C) return 1;
						for (;;) {
							for (p = b - S, _ = a[v] < d ? (m = 0, a[v]) : a[v] > d ? (m = R[T + a[v]], A[I + a[v]]) : (m = 96, 0), h = 1 << b - S, y = u = 1 << x; i[c + (E >> S) + (u -= h)] = p << 24 | m << 16 | _ | 0, 0 !== u;);
							for (h = 1 << b - 1; E & h;) h >>= 1;
							if (0 !== h ? (E &= h - 1, E += h) : E = 0, v++, 0 == --O[b]) {
								if (b === w) break;
								b = t[r + a[v]];
							}
							if (k < b && (E & f) !== l) {
								for (0 === S && (S = k), c += y, z = 1 << (x = b - S); x + S < w && !((z -= O[x + S]) <= 0);) x++, z <<= 1;
								if (C += 1 << x, 1 === e && 852 < C || 2 === e && 592 < C) return 1;
								i[l = E & f] = k << 24 | x << 16 | c - s | 0;
							}
						}
						return 0 !== E && (i[c + E] = b - S << 24 | 4194304), o.bits = k, 0;
					};
				}, { "../utils/common": 41 }],
				51: [function(e, t, r) {
					"use strict";
					t.exports = {
						2: "need dictionary",
						1: "stream end",
						0: "",
						"-1": "file error",
						"-2": "stream error",
						"-3": "data error",
						"-4": "insufficient memory",
						"-5": "buffer error",
						"-6": "incompatible version"
					};
				}, {}],
				52: [function(e, t, r) {
					"use strict";
					var i = e("../utils/common");
					var o = 0;
					var h = 1;
					function n(e) {
						for (var t = e.length; 0 <= --t;) e[t] = 0;
					}
					var s = 0;
					var a = 29;
					var u = 256;
					var l = u + 1 + a;
					var f = 30;
					var c = 19;
					var _ = 2 * l + 1;
					var g = 15;
					var d = 16;
					var p = 7;
					var m = 256;
					var b = 16;
					var v = 17;
					var y = 18;
					var w = [
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						1,
						1,
						1,
						1,
						2,
						2,
						2,
						2,
						3,
						3,
						3,
						3,
						4,
						4,
						4,
						4,
						5,
						5,
						5,
						5,
						0
					];
					var k = [
						0,
						0,
						0,
						0,
						1,
						1,
						2,
						2,
						3,
						3,
						4,
						4,
						5,
						5,
						6,
						6,
						7,
						7,
						8,
						8,
						9,
						9,
						10,
						10,
						11,
						11,
						12,
						12,
						13,
						13
					];
					var x = [
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						2,
						3,
						7
					];
					var S = [
						16,
						17,
						18,
						0,
						8,
						7,
						9,
						6,
						10,
						5,
						11,
						4,
						12,
						3,
						13,
						2,
						14,
						1,
						15
					];
					var z = new Array(2 * (l + 2));
					n(z);
					var C = new Array(2 * f);
					n(C);
					var E = new Array(512);
					n(E);
					var A = new Array(256);
					n(A);
					var I = new Array(a);
					n(I);
					var O;
					var B;
					var R;
					var T = new Array(f);
					function D(e, t, r, n, i) {
						this.static_tree = e, this.extra_bits = t, this.extra_base = r, this.elems = n, this.max_length = i, this.has_stree = e && e.length;
					}
					function F(e, t) {
						this.dyn_tree = e, this.max_code = 0, this.stat_desc = t;
					}
					function N(e) {
						return e < 256 ? E[e] : E[256 + (e >>> 7)];
					}
					function U(e, t) {
						e.pending_buf[e.pending++] = 255 & t, e.pending_buf[e.pending++] = t >>> 8 & 255;
					}
					function P(e, t, r) {
						e.bi_valid > d - r ? (e.bi_buf |= t << e.bi_valid & 65535, U(e, e.bi_buf), e.bi_buf = t >> d - e.bi_valid, e.bi_valid += r - d) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += r);
					}
					function L(e, t, r) {
						P(e, r[2 * t], r[2 * t + 1]);
					}
					function j(e, t) {
						for (var r = 0; r |= 1 & e, e >>>= 1, r <<= 1, 0 < --t;);
						return r >>> 1;
					}
					function Z(e, t, r) {
						var n;
						var i;
						var s = new Array(g + 1);
						var a = 0;
						for (n = 1; n <= g; n++) s[n] = a = a + r[n - 1] << 1;
						for (i = 0; i <= t; i++) {
							var o = e[2 * i + 1];
							0 !== o && (e[2 * i] = j(s[o]++, o));
						}
					}
					function W(e) {
						var t;
						for (t = 0; t < l; t++) e.dyn_ltree[2 * t] = 0;
						for (t = 0; t < f; t++) e.dyn_dtree[2 * t] = 0;
						for (t = 0; t < c; t++) e.bl_tree[2 * t] = 0;
						e.dyn_ltree[2 * m] = 1, e.opt_len = e.static_len = 0, e.last_lit = e.matches = 0;
					}
					function M(e) {
						8 < e.bi_valid ? U(e, e.bi_buf) : 0 < e.bi_valid && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0;
					}
					function H(e, t, r, n) {
						var i = 2 * t;
						var s = 2 * r;
						return e[i] < e[s] || e[i] === e[s] && n[t] <= n[r];
					}
					function G(e, t, r) {
						for (var n = e.heap[r], i = r << 1; i <= e.heap_len && (i < e.heap_len && H(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !H(t, n, e.heap[i], e.depth));) e.heap[r] = e.heap[i], r = i, i <<= 1;
						e.heap[r] = n;
					}
					function K(e, t, r) {
						var n;
						var i;
						var s;
						var a;
						var o = 0;
						if (0 !== e.last_lit) for (; n = e.pending_buf[e.d_buf + 2 * o] << 8 | e.pending_buf[e.d_buf + 2 * o + 1], i = e.pending_buf[e.l_buf + o], o++, 0 === n ? L(e, i, t) : (L(e, (s = A[i]) + u + 1, t), 0 !== (a = w[s]) && P(e, i -= I[s], a), L(e, s = N(--n), r), 0 !== (a = k[s]) && P(e, n -= T[s], a)), o < e.last_lit;);
						L(e, m, t);
					}
					function Y(e, t) {
						var r;
						var n;
						var i;
						var s = t.dyn_tree;
						var a = t.stat_desc.static_tree;
						var o = t.stat_desc.has_stree;
						var h = t.stat_desc.elems;
						var u = -1;
						for (e.heap_len = 0, e.heap_max = _, r = 0; r < h; r++) 0 !== s[2 * r] ? (e.heap[++e.heap_len] = u = r, e.depth[r] = 0) : s[2 * r + 1] = 0;
						for (; e.heap_len < 2;) s[2 * (i = e.heap[++e.heap_len] = u < 2 ? ++u : 0)] = 1, e.depth[i] = 0, e.opt_len--, o && (e.static_len -= a[2 * i + 1]);
						for (t.max_code = u, r = e.heap_len >> 1; 1 <= r; r--) G(e, s, r);
						for (i = h; r = e.heap[1], e.heap[1] = e.heap[e.heap_len--], G(e, s, 1), n = e.heap[1], e.heap[--e.heap_max] = r, e.heap[--e.heap_max] = n, s[2 * i] = s[2 * r] + s[2 * n], e.depth[i] = (e.depth[r] >= e.depth[n] ? e.depth[r] : e.depth[n]) + 1, s[2 * r + 1] = s[2 * n + 1] = i, e.heap[1] = i++, G(e, s, 1), 2 <= e.heap_len;);
						e.heap[--e.heap_max] = e.heap[1], function(e, t) {
							var r;
							var n;
							var i;
							var s;
							var a;
							var o;
							var h = t.dyn_tree;
							var u = t.max_code;
							var l = t.stat_desc.static_tree;
							var f = t.stat_desc.has_stree;
							var c = t.stat_desc.extra_bits;
							var d = t.stat_desc.extra_base;
							var p = t.stat_desc.max_length;
							var m = 0;
							for (s = 0; s <= g; s++) e.bl_count[s] = 0;
							for (h[2 * e.heap[e.heap_max] + 1] = 0, r = e.heap_max + 1; r < _; r++) p < (s = h[2 * h[2 * (n = e.heap[r]) + 1] + 1] + 1) && (s = p, m++), h[2 * n + 1] = s, u < n || (e.bl_count[s]++, a = 0, d <= n && (a = c[n - d]), o = h[2 * n], e.opt_len += o * (s + a), f && (e.static_len += o * (l[2 * n + 1] + a)));
							if (0 !== m) {
								do {
									for (s = p - 1; 0 === e.bl_count[s];) s--;
									e.bl_count[s]--, e.bl_count[s + 1] += 2, e.bl_count[p]--, m -= 2;
								} while (0 < m);
								for (s = p; 0 !== s; s--) for (n = e.bl_count[s]; 0 !== n;) u < (i = e.heap[--r]) || (h[2 * i + 1] !== s && (e.opt_len += (s - h[2 * i + 1]) * h[2 * i], h[2 * i + 1] = s), n--);
							}
						}(e, t), Z(s, u, e.bl_count);
					}
					function X(e, t, r) {
						var n;
						var i;
						var s = -1;
						var a = t[1];
						var o = 0;
						var h = 7;
						var u = 4;
						for (0 === a && (h = 138, u = 3), t[2 * (r + 1) + 1] = 65535, n = 0; n <= r; n++) i = a, a = t[2 * (n + 1) + 1], ++o < h && i === a || (o < u ? e.bl_tree[2 * i] += o : 0 !== i ? (i !== s && e.bl_tree[2 * i]++, e.bl_tree[2 * b]++) : o <= 10 ? e.bl_tree[2 * v]++ : e.bl_tree[2 * y]++, s = i, u = (o = 0) === a ? (h = 138, 3) : i === a ? (h = 6, 3) : (h = 7, 4));
					}
					function V(e, t, r) {
						var n;
						var i;
						var s = -1;
						var a = t[1];
						var o = 0;
						var h = 7;
						var u = 4;
						for (0 === a && (h = 138, u = 3), n = 0; n <= r; n++) if (i = a, a = t[2 * (n + 1) + 1], !(++o < h && i === a)) {
							if (o < u) for (; L(e, i, e.bl_tree), 0 != --o;);
							else 0 !== i ? (i !== s && (L(e, i, e.bl_tree), o--), L(e, b, e.bl_tree), P(e, o - 3, 2)) : o <= 10 ? (L(e, v, e.bl_tree), P(e, o - 3, 3)) : (L(e, y, e.bl_tree), P(e, o - 11, 7));
							s = i, u = (o = 0) === a ? (h = 138, 3) : i === a ? (h = 6, 3) : (h = 7, 4);
						}
					}
					n(T);
					var q = !1;
					function J(e, t, r, n) {
						P(e, (s << 1) + (n ? 1 : 0), 3), function(e, t, r, n) {
							M(e), n && (U(e, r), U(e, ~r)), i.arraySet(e.pending_buf, e.window, t, r, e.pending), e.pending += r;
						}(e, t, r, !0);
					}
					r._tr_init = function(e) {
						q || (function() {
							var e;
							var t;
							var r;
							var n;
							var i;
							var s = new Array(g + 1);
							for (n = r = 0; n < a - 1; n++) for (I[n] = r, e = 0; e < 1 << w[n]; e++) A[r++] = n;
							for (A[r - 1] = n, n = i = 0; n < 16; n++) for (T[n] = i, e = 0; e < 1 << k[n]; e++) E[i++] = n;
							for (i >>= 7; n < f; n++) for (T[n] = i << 7, e = 0; e < 1 << k[n] - 7; e++) E[256 + i++] = n;
							for (t = 0; t <= g; t++) s[t] = 0;
							for (e = 0; e <= 143;) z[2 * e + 1] = 8, e++, s[8]++;
							for (; e <= 255;) z[2 * e + 1] = 9, e++, s[9]++;
							for (; e <= 279;) z[2 * e + 1] = 7, e++, s[7]++;
							for (; e <= 287;) z[2 * e + 1] = 8, e++, s[8]++;
							for (Z(z, l + 1, s), e = 0; e < f; e++) C[2 * e + 1] = 5, C[2 * e] = j(e, 5);
							O = new D(z, w, u + 1, l, g), B = new D(C, k, 0, f, g), R = new D(new Array(0), x, 0, c, p);
						}(), q = !0), e.l_desc = new F(e.dyn_ltree, O), e.d_desc = new F(e.dyn_dtree, B), e.bl_desc = new F(e.bl_tree, R), e.bi_buf = 0, e.bi_valid = 0, W(e);
					}, r._tr_stored_block = J, r._tr_flush_block = function(e, t, r, n) {
						var i;
						var s;
						var a = 0;
						0 < e.level ? (2 === e.strm.data_type && (e.strm.data_type = function(e) {
							var t;
							var r = 4093624447;
							for (t = 0; t <= 31; t++, r >>>= 1) if (1 & r && 0 !== e.dyn_ltree[2 * t]) return o;
							if (0 !== e.dyn_ltree[18] || 0 !== e.dyn_ltree[20] || 0 !== e.dyn_ltree[26]) return h;
							for (t = 32; t < u; t++) if (0 !== e.dyn_ltree[2 * t]) return h;
							return o;
						}(e)), Y(e, e.l_desc), Y(e, e.d_desc), a = function(e) {
							var t;
							for (X(e, e.dyn_ltree, e.l_desc.max_code), X(e, e.dyn_dtree, e.d_desc.max_code), Y(e, e.bl_desc), t = c - 1; 3 <= t && 0 === e.bl_tree[2 * S[t] + 1]; t--);
							return e.opt_len += 3 * (t + 1) + 5 + 5 + 4, t;
						}(e), i = e.opt_len + 3 + 7 >>> 3, (s = e.static_len + 3 + 7 >>> 3) <= i && (i = s)) : i = s = r + 5, r + 4 <= i && -1 !== t ? J(e, t, r, n) : 4 === e.strategy || s === i ? (P(e, 2 + (n ? 1 : 0), 3), K(e, z, C)) : (P(e, 4 + (n ? 1 : 0), 3), function(e, t, r, n) {
							var i;
							for (P(e, t - 257, 5), P(e, r - 1, 5), P(e, n - 4, 4), i = 0; i < n; i++) P(e, e.bl_tree[2 * S[i] + 1], 3);
							V(e, e.dyn_ltree, t - 1), V(e, e.dyn_dtree, r - 1);
						}(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, a + 1), K(e, e.dyn_ltree, e.dyn_dtree)), W(e), n && M(e);
					}, r._tr_tally = function(e, t, r) {
						return e.pending_buf[e.d_buf + 2 * e.last_lit] = t >>> 8 & 255, e.pending_buf[e.d_buf + 2 * e.last_lit + 1] = 255 & t, e.pending_buf[e.l_buf + e.last_lit] = 255 & r, e.last_lit++, 0 === t ? e.dyn_ltree[2 * r]++ : (e.matches++, t--, e.dyn_ltree[2 * (A[r] + u + 1)]++, e.dyn_dtree[2 * N(t)]++), e.last_lit === e.lit_bufsize - 1;
					}, r._tr_align = function(e) {
						P(e, 2, 3), L(e, m, z), function(e) {
							16 === e.bi_valid ? (U(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : 8 <= e.bi_valid && (e.pending_buf[e.pending++] = 255 & e.bi_buf, e.bi_buf >>= 8, e.bi_valid -= 8);
						}(e);
					};
				}, { "../utils/common": 41 }],
				53: [function(e, t, r) {
					"use strict";
					t.exports = function() {
						this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
					};
				}, {}],
				54: [function(e, t, r) {
					(function(e) {
						(function(r, n) {
							"use strict";
							if (!r.setImmediate) {
								var i;
								var s;
								var t;
								var a;
								var o = 1;
								var h = {};
								var u = !1;
								var l = r.document;
								var e = Object.getPrototypeOf && Object.getPrototypeOf(r);
								e = e && e.setTimeout ? e : r, i = "[object process]" === {}.toString.call(r.process) ? function(e) {
									process.nextTick(function() {
										c(e);
									});
								} : function() {
									if (r.postMessage && !r.importScripts) {
										var e = !0;
										var t = r.onmessage;
										return r.onmessage = function() {
											e = !1;
										}, r.postMessage("", "*"), r.onmessage = t, e;
									}
								}() ? (a = "setImmediate$" + Math.random() + "$", r.addEventListener ? r.addEventListener("message", d, !1) : r.attachEvent("onmessage", d), function(e) {
									r.postMessage(a + e, "*");
								}) : r.MessageChannel ? ((t = new MessageChannel()).port1.onmessage = function(e) {
									c(e.data);
								}, function(e) {
									t.port2.postMessage(e);
								}) : l && "onreadystatechange" in l.createElement("script") ? (s = l.documentElement, function(e) {
									var t = l.createElement("script");
									t.onreadystatechange = function() {
										c(e), t.onreadystatechange = null, s.removeChild(t), t = null;
									}, s.appendChild(t);
								}) : function(e) {
									setTimeout(c, 0, e);
								}, e.setImmediate = function(e) {
									"function" != typeof e && (e = new Function("" + e));
									for (var t = new Array(arguments.length - 1), r = 0; r < t.length; r++) t[r] = arguments[r + 1];
									return h[o] = {
										callback: e,
										args: t
									}, i(o), o++;
								}, e.clearImmediate = f;
							}
							function f(e) {
								delete h[e];
							}
							function c(e) {
								if (u) setTimeout(c, 0, e);
								else {
									var t = h[e];
									if (t) {
										u = !0;
										try {
											(function(e) {
												var t = e.callback;
												var r = e.args;
												switch (r.length) {
													case 0:
														t();
														break;
													case 1:
														t(r[0]);
														break;
													case 2:
														t(r[0], r[1]);
														break;
													case 3:
														t(r[0], r[1], r[2]);
														break;
													default: t.apply(n, r);
												}
											})(t);
										} finally {
											f(e), u = !1;
										}
									}
								}
							}
							function d(e) {
								e.source === r && "string" == typeof e.data && 0 === e.data.indexOf(a) && c(+e.data.slice(a.length));
							}
						})("undefined" == typeof self ? void 0 === e ? this : e : self);
					}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
				}, {}]
			}, {}, [10])(10);
		});
	}));
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/hooks/use-export.js
	var __defProp$4 = Object.defineProperty;
	var __defProps$4 = Object.defineProperties;
	var __getOwnPropDescs$4 = Object.getOwnPropertyDescriptors;
	var __getOwnPropSymbols$4 = Object.getOwnPropertySymbols;
	var __hasOwnProp$4 = Object.prototype.hasOwnProperty;
	var __propIsEnum$4 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$4 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$4(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$4 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$4.call(b, prop)) __defNormalProp$4(a, prop, b[prop]);
		if (__getOwnPropSymbols$4) {
			for (var prop of __getOwnPropSymbols$4(b)) if (__propIsEnum$4.call(b, prop)) __defNormalProp$4(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var __spreadProps$4 = /* @__PURE__ */ __name((a, b) => __defProps$4(a, __getOwnPropDescs$4(b)), "__spreadProps");
	var EXPORT_MODE_SELECTED = "selected";
	var EXPORT_MODE_FILTERED = "filtered";
	var { useState: useState$8, useMemo: useMemo$5 } = react.default;
	var ZIP_NAME_FORMAT = "elementor-submissions-export-{DATE}";
	var EXPORT_FILE_NAME_FORMAT = "elementor-submissions-export-{FORM_LABEL}-{DATE}";
	var defaultOptions$1 = {
		maxRowsPerRequest: 1e4,
		checked: [],
		filter: {}
	};
	function useExport(hookOptions) {
		const options = useMemo$5(() => __spreadValues$4(__spreadValues$4({}, defaultOptions$1), hookOptions), [hookOptions]);
		const { notifyError } = useNoticesContext();
		const [progress, setProgress] = useState$8({
			count: 0,
			success: 0
		});
		const mode = useMemo$5(() => {
			if (options.checked.length > 0) return EXPORT_MODE_SELECTED;
			const filter = Object.fromEntries(Object.entries(options.filter).filter(([, value]) => value));
			if (1 === Object.keys(filter).length && "all" === filter.status) return "all";
			return EXPORT_MODE_FILTERED;
		}, [options.checked, options.filter]);
		const [exportSubmissions, { status: exportStatus }] = useDataAction(([query, total], { abortController, status }) => {
			if (status === "loading" && abortController) {
				abortController.abort();
				return Promise.reject({ message: "Aborted" });
			}
			const numberOfRequests = Math.ceil(total / options.maxRowsPerRequest);
			let exportDataByForm = {};
			let promise = Promise.resolve();
			setProgress({
				count: numberOfRequests,
				success: 0
			});
			for (let i = 1; i <= numberOfRequests; i++) promise = promise.then(() => $e.data.get("form-submissions/export", __spreadProps$4(__spreadValues$4({}, query), {
				per_page: options.maxRowsPerRequest,
				page: i
			}), {
				refresh: true,
				signal: abortController.signal
			})).then((result) => {
				const shouldSaveHeaders = 1 === i;
				exportDataByForm = mergeFormExportData(result.data.data, exportDataByForm, shouldSaveHeaders);
				setProgress((prev) => __spreadProps$4(__spreadValues$4({}, prev), { success: i }));
			});
			return promise.then(() => downloadExportsResults(Object.values(exportDataByForm))).catch((error) => notifyError(error.message));
		}, [options.maxRowsPerRequest]);
		return [exportSubmissions, {
			mode,
			progress,
			status: exportStatus
		}];
	}
	function mergeFormExportData(response, current, shouldSaveHeaders) {
		response.forEach((formResult) => {
			var _a;
			if (!shouldSaveHeaders) delete formResult.content[0];
			current = __spreadProps$4(__spreadValues$4({}, current), { [formResult.id]: __spreadProps$4(__spreadValues$4({}, formResult), { content: (((_a = current[formResult.id]) == null ? void 0 : _a.content) || "") + formResult.content.join("\n") }) });
		});
		return current;
	}
	function downloadExportsResults(dataResults) {
		const currentDate = wp.date.date("Y-m-d");
		const files = dataResults.map((item) => transformFormResultIntoBlob(item, currentDate));
		if (1 === files.length) {
			downloadBlob(files[0].blob, files[0].filename);
			return;
		}
		__vitePreload(_asyncToGenerator(function* () {
			const { default: JSZip } = yield Promise.resolve().then(() => /* @__PURE__ */ __toESM(require_jszip_min()));
			return { default: JSZip };
		}), void 0).then(({ default: JSZip }) => {
			const zip = new JSZip();
			files.forEach(({ filename, blob }) => zip.file(filename, blob));
			return zip.generateAsync({ type: "blob" });
		}).then((zipBlob) => {
			downloadBlob(zipBlob, ZIP_NAME_FORMAT.replace("{DATE}", currentDate));
		});
	}
	function transformFormResultIntoBlob(formResult, currentDate) {
		return {
			filename: EXPORT_FILE_NAME_FORMAT.replace("{FORM_LABEL}", formResult.form_label).replace("{DATE}", currentDate).concat(`.${formResult.extension}`),
			blob: new Blob(["﻿", formResult.content], { type: formResult.mimetype })
		};
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/export-button.js
	var { useMemo: useMemo$4 } = react.default;
	var buttonContentOptions = {
		["all"]: (0, _wordpress_i18n.__)("Export All to CSV", "elementor-pro"),
		[EXPORT_MODE_FILTERED]: (0, _wordpress_i18n.__)("Export Filtered to CSV", "elementor-pro"),
		[EXPORT_MODE_SELECTED]: (0, _wordpress_i18n.__)("Export Selected to CSV", "elementor-pro")
	};
	function ExportButton(props) {
		const ProgressPercentage = useMemo$4(() => {
			if (!props.progress) return 0;
			const { count, success } = props.progress;
			if (0 === count || 0 === success) return 0;
			return Math.round(success / count * 100);
		}, [props.progress]);
		return /* @__PURE__ */ react.default.createElement("button", {
			className: "button button-primary e-export-button",
			onClick: () => !props.disabled && props.onClick(),
			disabled: props.disabled
		}, props.isLoading ? /* @__PURE__ */ react.default.createElement(react.default.Fragment, null, /* @__PURE__ */ react.default.createElement("i", { className: "eicon-loading eicon-animation-spin" }), " \xA0", /* @__PURE__ */ react.default.createElement("span", null, " ", ProgressPercentage, "% "), " \xA0", (0, _wordpress_i18n.__)("Click to Cancel", "elementor-pro")) : buttonContentOptions[props.mode]);
	}
	ExportButton.propTypes = {
		onClick: import_prop_types.default.func.isRequired,
		isLoading: import_prop_types.default.bool,
		mode: import_prop_types.default.oneOf([
			"all",
			EXPORT_MODE_SELECTED,
			EXPORT_MODE_FILTERED
		]),
		disabled: import_prop_types.default.bool,
		progress: import_prop_types.default.shape({
			count: import_prop_types.default.number,
			success: import_prop_types.default.number
		})
	};
	ExportButton.defaultProps = {
		isLoading: false,
		hasSelected: false,
		disabled: false
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/link.js
	var __defProp$3 = Object.defineProperty;
	var __defProps$3 = Object.defineProperties;
	var __getOwnPropDescs$3 = Object.getOwnPropertyDescriptors;
	var __getOwnPropSymbols$3 = Object.getOwnPropertySymbols;
	var __hasOwnProp$3 = Object.prototype.hasOwnProperty;
	var __propIsEnum$3 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$3 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$3(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$3 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$3.call(b, prop)) __defNormalProp$3(a, prop, b[prop]);
		if (__getOwnPropSymbols$3) {
			for (var prop of __getOwnPropSymbols$3(b)) if (__propIsEnum$3.call(b, prop)) __defNormalProp$3(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var __spreadProps$3 = /* @__PURE__ */ __name((a, b) => __defProps$3(a, __getOwnPropDescs$3(b)), "__spreadProps");
	function Link(props) {
		const ref = (0, react.useRef)();
		(0, react.useEffect)(() => {
			if (!ref.current) return;
			ref.current.setAttribute("href", `${location.href.split("#")[0]}#${props.to}`);
		}, [props.to, ref.current]);
		return /* @__PURE__ */ react.default.createElement(Link$1, __spreadProps$3(__spreadValues$3({}, props), { ref }));
	}
	Link.propTypes = __spreadValues$3({}, Link$1.propTypes);
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/links-filter.js
	var { useCallback: useCallback$3, useMemo: useMemo$3 } = react.default;
	function LinksFilter(props) {
		const onChange = useCallback$3((e, value) => {
			e.preventDefault();
			if (!props.onChange) return;
			props.onChange(value);
		}, []);
		const options = useMemo$3(() => {
			return props.options.filter((option) => option.shouldShow);
		}, [props.options]);
		return /* @__PURE__ */ react.default.createElement("ul", { className: "subsubsub" }, options.map((option, index) => {
			const isLast = index + 1 === options.length;
			return /* @__PURE__ */ react.default.createElement("li", { key: option.value }, "\xA0", /* @__PURE__ */ react.default.createElement("a", {
				href: "#",
				className: option.value === props.value ? "current" : "",
				onClick: (e) => onChange(e, option.value)
			}, option.label, void 0 !== option.count && /* @__PURE__ */ react.default.createElement("span", { className: "count" }, " (", option.count, ")")), "\xA0", isLast ? "" : "|");
		}));
	}
	LinksFilter.propTypes = {
		options: import_prop_types.default.arrayOf(import_prop_types.default.shape({
			value: import_prop_types.default.string,
			label: import_prop_types.default.string,
			count: import_prop_types.default.number,
			shouldShow: import_prop_types.default.bool
		})),
		value: import_prop_types.default.string,
		onChange: import_prop_types.default.func
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/pagination.js
	var { useCallback: useCallback$2, useMemo: useMemo$2 } = react.default;
	function Pagination(props) {
		const canNavigateBack = useMemo$2(() => 1 !== props.currentPage, [props.currentPage]);
		const canNavigateNext = useMemo$2(() => props.lastPage > props.currentPage, [props.currentPage, props.lastPage]);
		const NavigateBackElement = canNavigateBack ? "a" : "span";
		const NavigateNextElement = canNavigateNext ? "a" : "span";
		const navigate = useCallback$2((e, shouldNavigate, page) => {
			e.preventDefault();
			if (!shouldNavigate) return;
			props.onChange(page);
		}, [props.onChange]);
		if (!props.currentPage) return "";
		return /* @__PURE__ */ react.default.createElement("div", { className: `tablenav-pages ${props.lastPage <= 1 && "one-page"}` }, /* @__PURE__ */ react.default.createElement("span", { className: "displaying-num" }, props.total, " ", (0, _wordpress_i18n.__)("items", "elementor-pro")), 1 < props.lastPage && /* @__PURE__ */ react.default.createElement("span", { className: "pagination-links" }, /* @__PURE__ */ react.default.createElement(NavigateBackElement, {
			className: `tablenav-pages-navspan button ${!canNavigateBack && "disabled"}`,
			onClick: (e) => navigate(e, canNavigateBack, 1)
		}, "«"), "\xA0", /* @__PURE__ */ react.default.createElement(NavigateBackElement, {
			className: `tablenav-pages-navspan button ${!canNavigateBack && "disabled"}`,
			onClick: (e) => navigate(e, canNavigateBack, props.currentPage - 1)
		}, "‹"), /* @__PURE__ */ react.default.createElement("span", { className: "paging-input" }, /* @__PURE__ */ react.default.createElement("span", { className: "screen-reader-text" }, (0, _wordpress_i18n.__)("Current Page", "elementor-pro")), /* @__PURE__ */ react.default.createElement("span", {
			className: "paging-input",
			style: { margin: "0 6px" }
		}, /* @__PURE__ */ react.default.createElement("span", { className: "tablenav-paging-text" }, props.currentPage, " ", (0, _wordpress_i18n.__)("of", "elementor-pro"), /* @__PURE__ */ react.default.createElement("span", {
			className: "total-pages",
			style: { margin: "0" }
		}, " ", props.lastPage)))), /* @__PURE__ */ react.default.createElement(NavigateNextElement, {
			className: `tablenav-pages-navspan button ${!canNavigateNext && "disabled"}`,
			onClick: (e) => navigate(e, canNavigateNext, props.currentPage + 1)
		}, "›"), "\xA0", /* @__PURE__ */ react.default.createElement(NavigateNextElement, {
			className: `tablenav-pages-navspan button ${!canNavigateNext && "disabled"}`,
			onClick: (e) => navigate(e, canNavigateNext, props.lastPage)
		}, "»")));
	}
	Pagination.propTypes = {
		currentPage: import_prop_types.default.number,
		total: import_prop_types.default.number,
		lastPage: import_prop_types.default.number,
		perPage: import_prop_types.default.number,
		onChange: import_prop_types.default.func.isRequired
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/referer-filter.js
	var { useEffect: useEffect$3, useRef: useRef$1, useState: useState$7 } = react.default;
	function renderSelect2(el, onChange) {
		jQuery(el).select2({
			allowClear: true,
			placeholder: (0, _wordpress_i18n.__)("All Pages", "elementor-pro"),
			dir: elementorCommon.config.isRTL ? "rtl" : "ltr",
			ajax: {
				delay: 400,
				transport({ data: { search } }, success, failure) {
					return $e.data.get("form-submissions/referer", { search }, { refresh: true }).then(success).catch(failure);
				},
				data(params) {
					return { search: params.term };
				},
				processResults({ data }) {
					return { results: data.data.map(({ value, label }) => ({
						id: encodeURIComponent(value),
						text: label
					})) };
				},
				cache: true
			},
			minimumInputLength: 3
		}).on("select2:select select2:unselect", (e) => {
			onChange(e.target.value);
		});
	}
	function RefererFilter(props) {
		const [options, setOptions] = useState$7([{
			value: "",
			label: (0, _wordpress_i18n.__)("All Pages", "elementor-pro")
		}]);
		const ref = useRef$1();
		useEffect$3(() => {
			let $select2 = null;
			if (props.value) $e.data.get("form-submissions/referer", { value: props.value }, { refresh: true }).then(({ data }) => setOptions((prev) => [...prev, ...data.data])).then(() => $select2 = renderSelect2(ref.current, props.onChange));
			else $select2 = renderSelect2(ref.current, props.onChange);
			return () => {
				if (!$select2) return;
				$select2.select2("destroy").off("select2:select select2:unselect");
			};
		}, []);
		return /* @__PURE__ */ react.default.createElement(react.default.Fragment, null, /* @__PURE__ */ react.default.createElement("label", {
			htmlFor: "filter-by-referer",
			className: "screen-reader-text"
		}, (0, _wordpress_i18n.__)("Filter by Page", "elementor-pro")), /* @__PURE__ */ react.default.createElement("select", {
			ref,
			id: "filter-by-referer",
			value: props.value
		}, options.map(({ value, label }) => {
			return /* @__PURE__ */ react.default.createElement("option", {
				key: value,
				value: encodeURIComponent(value)
			}, " ", label, " ");
		})));
	}
	RefererFilter.propTypes = {
		value: import_prop_types.default.string,
		onChange: import_prop_types.default.func.isRequired
	};
	RefererFilter.defaultProps = { value: "" };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/resource-filter.js
	var { useState: useState$6, useEffect: useEffect$2 } = react.default;
	function ResourceFilter(props) {
		const [localOptions, setLocalOptions] = useState$6([]);
		useEffect$2(() => {
			$e.data.get(props.resourceOptions.command, props.resourceOptions.args, { refresh: true }).then((result) => setLocalOptions(result.data.data));
		}, []);
		return /* @__PURE__ */ react.default.createElement(react.default.Fragment, null, props.label && /* @__PURE__ */ react.default.createElement("label", {
			htmlFor: `filter-by-${props.name}`,
			className: "screen-reader-text"
		}, props.label), /* @__PURE__ */ react.default.createElement("select", {
			id: `filter-by-${props.name}`,
			value: props.value,
			onChange: (e) => props.onChange(e.target.value)
		}, [...props.options, ...localOptions].map(({ value, label }) => {
			return /* @__PURE__ */ react.default.createElement("option", {
				key: value,
				value
			}, " ", label, " ");
		})));
	}
	ResourceFilter.propTypes = {
		value: import_prop_types.default.string,
		onChange: import_prop_types.default.func.isRequired,
		label: import_prop_types.default.string,
		name: import_prop_types.default.string.isRequired,
		options: import_prop_types.default.arrayOf(import_prop_types.default.shape({
			label: import_prop_types.default.string,
			value: import_prop_types.default.string
		})),
		resourceOptions: import_prop_types.default.shape({
			command: import_prop_types.default.string,
			args: import_prop_types.default.object
		})
	};
	ResourceFilter.defaultProps = {
		value: "",
		options: []
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/search-box.js
	var { useState: useState$5, useRef, useCallback: useCallback$1 } = react.default;
	var DEFAULT_DEBOUNCE_TIMEOUT = 600;
	function SearchBox(props) {
		const [localValue, setLocalValue] = useState$5(props.value || ""), debounceHandler = useRef(null);
		const onChange = useCallback$1((e) => {
			if (debounceHandler.current) clearTimeout(debounceHandler.current);
			const value = e.target.value;
			setLocalValue(value);
			debounceHandler.current = setTimeout(() => props.onChange(value), props.debounceTimeout);
		}, []);
		return /* @__PURE__ */ react.default.createElement("p", { className: "search-box e-form-submissions-search" }, props.label && /* @__PURE__ */ react.default.createElement("label", {
			className: "screen-reader-text",
			htmlFor: "search-input"
		}, props.label), props.isSearching && /* @__PURE__ */ react.default.createElement("span", { className: "e-form-submissions-search__spinner" }, /* @__PURE__ */ react.default.createElement("i", { className: "eicon-loading eicon-animation-spin" })), /* @__PURE__ */ react.default.createElement("input", {
			type: "search",
			id: "search-input",
			name: "s",
			value: localValue,
			onChange,
			placeholder: (0, _wordpress_i18n.__)("Search...", "elementor-pro")
		}));
	}
	SearchBox.propTypes = {
		value: import_prop_types.default.string,
		onChange: import_prop_types.default.func.isRequired,
		label: import_prop_types.default.string,
		debounceTimeout: import_prop_types.default.number,
		isSearching: import_prop_types.default.bool
	};
	SearchBox.defaultProps = {
		debounceTimeout: DEFAULT_DEBOUNCE_TIMEOUT,
		isSearching: false
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/submission-row.js
	var { useState: useState$4 } = react.default;
	function SubmissionRow(props) {
		var _a;
		var _b;
		const [isMobileRowOpen, setIsMobileRowOpen] = useState$4(false);
		const mainValue = ((_b = (_a = props.item) == null ? void 0 : _a.main) == null ? void 0 : _b.value) || (0, _wordpress_i18n.__)("Unknown", "elementor-pro");
		return /* @__PURE__ */ react.default.createElement(WpTable.Row, {
			className: isMobileRowOpen ? "is-expanded" : "",
			style: { fontWeight: !props.item.is_read ? "bold" : "inherit" }
		}, /* @__PURE__ */ react.default.createElement(WpTable.Cell, {
			component: "th",
			className: "check-column"
		}, props.checkBoxComponent), /* @__PURE__ */ react.default.createElement(WpTable.Cell, { className: "has-row-actions column-primary" }, "trash" === props.item.status ? mainValue : /* @__PURE__ */ react.default.createElement(Link, {
			to: `/${props.item.id}`,
			"aria-label": "View"
		}, mainValue), props.rowActionComponent, /* @__PURE__ */ react.default.createElement("button", {
			type: "button",
			className: "toggle-row",
			onClick: () => setIsMobileRowOpen((prev) => !prev)
		}, /* @__PURE__ */ react.default.createElement("span", { className: "screen-reader-text" }, (0, _wordpress_i18n.__)("Show more details", "elementor-pro")))), /* @__PURE__ */ react.default.createElement(WpTable.Cell, {
			className: "column-actions",
			colName: props.tableTitles.actions_log_status.label
		}, props.item.actions_count > 0 && /* @__PURE__ */ react.default.createElement("i", {
			className: `${props.item.actions_count === props.item.actions_succeeded_count ? "eicon-success eicon-check-circle-o" : "eicon-error eicon-warning"}`,
			title: `${props.item.actions_succeeded_count}/${props.item.actions_count} ${(0, _wordpress_i18n.__)("Succeed", "elementor-pro")}`
		})), /* @__PURE__ */ react.default.createElement(WpTable.Cell, {
			className: "column-form",
			colName: props.tableTitles.form.label
		}, props.item.post && /* @__PURE__ */ react.default.createElement("a", {
			href: props.item.post.edit_url,
			target: "_blank",
			rel: "noreferrer"
		}, props.item.form.name, " (", props.item.form.element_id, ")")), /* @__PURE__ */ react.default.createElement(WpTable.Cell, {
			className: "column-page",
			colName: props.tableTitles.page.label
		}, /* @__PURE__ */ react.default.createElement("a", {
			href: props.item.referer,
			target: "_blank",
			rel: "noreferrer",
			title: props.item.referer_title
		}, props.item.referer_title || /* @__PURE__ */ react.default.createElement("i", { className: "eicon-editor-external-link e-form-submissions-referer-icon" }))), /* @__PURE__ */ react.default.createElement(WpTable.Cell, {
			className: "column-id",
			colName: props.tableTitles.id.label
		}, props.item.id), /* @__PURE__ */ react.default.createElement(WpTable.Cell, {
			className: "column-date",
			colName: props.tableTitles.created_at.label
		}, formatToLocalDateTime(props.item.created_at)));
	}
	SubmissionRow.propTypes = {
		item: import_prop_types.default.object.isRequired,
		tableTitles: import_prop_types.default.objectOf(import_prop_types.default.shape({ label: import_prop_types.default.string })),
		rowActionComponent: import_prop_types.default.node,
		checkBoxComponent: import_prop_types.default.node
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/hooks/use-methods-reducer.js
	var __defProp$2 = Object.defineProperty;
	var __defProps$2 = Object.defineProperties;
	var __getOwnPropDescs$2 = Object.getOwnPropertyDescriptors;
	var __getOwnPropSymbols$2 = Object.getOwnPropertySymbols;
	var __hasOwnProp$2 = Object.prototype.hasOwnProperty;
	var __propIsEnum$2 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$2 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$2(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$2 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$2.call(b, prop)) __defNormalProp$2(a, prop, b[prop]);
		if (__getOwnPropSymbols$2) {
			for (var prop of __getOwnPropSymbols$2(b)) if (__propIsEnum$2.call(b, prop)) __defNormalProp$2(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var __spreadProps$2 = /* @__PURE__ */ __name((a, b) => __defProps$2(a, __getOwnPropDescs$2(b)), "__spreadProps");
	function useMethodsReducer(methods, initialState, init = void 0) {
		const [state, dispatch] = react.default.useReducer((currentState, action) => {
			if (!Object.prototype.hasOwnProperty.call(methods, action.type)) throw Error(`The action type ${action.type} is not exists`);
			return methods[action.type](currentState, action.payload);
		}, initialState, init);
		return [
			state,
			generateActions(methods, dispatch),
			dispatch
		];
	}
	function generateActions(methods, dispatch) {
		return Object.keys(methods).reduce((current, type) => {
			return __spreadProps$2(__spreadValues$2({}, current), { [type]: (payload) => dispatch({
				type,
				payload
			}) });
		}, {});
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/hooks/use-router-query-string.js
	var __defProp$1 = Object.defineProperty;
	var __defProps$1 = Object.defineProperties;
	var __getOwnPropDescs$1 = Object.getOwnPropertyDescriptors;
	var __getOwnPropSymbols$1 = Object.getOwnPropertySymbols;
	var __hasOwnProp$1 = Object.prototype.hasOwnProperty;
	var __propIsEnum$1 = Object.prototype.propertyIsEnumerable;
	var __defNormalProp$1 = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp$1(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value, "__defNormalProp");
	var __spreadValues$1 = /* @__PURE__ */ __name((a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp$1.call(b, prop)) __defNormalProp$1(a, prop, b[prop]);
		if (__getOwnPropSymbols$1) {
			for (var prop of __getOwnPropSymbols$1(b)) if (__propIsEnum$1.call(b, prop)) __defNormalProp$1(a, prop, b[prop]);
		}
		return a;
	}, "__spreadValues");
	var __spreadProps$1 = /* @__PURE__ */ __name((a, b) => __defProps$1(a, __getOwnPropDescs$1(b)), "__spreadProps");
	var { useEffect: useEffect$1, useState: useState$3 } = react.default;
	function useRouterQueryString(queryArgs = []) {
		const location = useLocation(), [isLocationRead, setIsLocationRead] = useState$3(false), [query, setQuery] = useState$3(false);
		useEffect$1(() => {
			if (!(location == null ? void 0 : location.pathname) || isLocationRead) return;
			const parsedQueryString = queryArgs.reduce((current, arg) => {
				const value = wp.url.getQueryArg(location.pathname, arg);
				if (void 0 === value) return current;
				return __spreadProps$1(__spreadValues$1({}, current), { [arg]: value });
			}, {});
			setQuery(parsedQueryString);
			setIsLocationRead(true);
		}, [location]);
		useEffect$1(() => {
			if (!query) return;
			const basePath = location.pathname.split("?")[0] || "/";
			history.pushState(void 0, void 0, `#${wp.url.addQueryArgs(basePath, query)}`);
		}, [query]);
		return [query, setQuery];
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.140.0/helpers/esm/objectSpread2.js
	function ownKeys(e, r) {
		var t = Object.keys(e);
		if (Object.getOwnPropertySymbols) {
			var o = Object.getOwnPropertySymbols(e);
			r && (o = o.filter(function(r2) {
				return Object.getOwnPropertyDescriptor(e, r2).enumerable;
			})), t.push.apply(t, o);
		}
		return t;
	}
	function _objectSpread2(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = null != arguments[r] ? arguments[r] : {};
			r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
				_defineProperty(e, r2, t[r2]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
				Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
			});
		}
		return e;
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/hooks/use-rest-data-list.js
	var { useState: useState$2, useEffect, useMemo: useMemo$1 } = react.default;
	/**
	* Default options for the use function
	*
	* @type {{useRouterQueryString: boolean, allowedFilters: Array}}
	*/
	var defaultOptions = {
		allowedFilters: [],
		useRouterQueryString: false,
		hooks: { afterFetch: () => {} }
	};
	var defaultQueryArgs = [
		"order",
		"order_by",
		"page",
		"per_page"
	];
	var currentFlatQuery = {};
	/**
	* Main function
	*
	* @param {any}    command
	* @param {Object} options
	* @return {{fetchData: any, data: any, meta: any, query: any, actions: {setOrder: any, setFilter: any, setPage: any}}} REST data
	*/
	function useRestDataList(command, options = {}) {
		options = _objectSpread2(_objectSpread2({}, defaultOptions), options);
		const queryArgs = [...defaultQueryArgs, ...options.allowedFilters], [{ data, meta }, setFetchResult] = useState$2({
			data: [],
			meta: {}
		}), { query, flatQuery, actions: { setFilter, setPage, setOrder, setInitial } } = useQuery(), [routerQueryString, setRouterQueryString] = useRouterQueryString(queryArgs);
		currentFlatQuery = flatQuery;
		const [fetchData, { status: fetchDataStatus }] = useDataAction((args, { abortController }) => $e.data.get(command, currentFlatQuery, {
			refresh: true,
			signal: abortController.signal
		}).then((response) => setFetchResult(response.data)).then(() => options.hooks.afterFetch()), [command, flatQuery]);
		useEffect(() => {
			const queryStringResult = options.useRouterQueryString ? routerQueryString : {};
			setInitial({
				filter: {
					search: (queryStringResult === null || queryStringResult === void 0 ? void 0 : queryStringResult.search) || null,
					status: (queryStringResult === null || queryStringResult === void 0 ? void 0 : queryStringResult.status) || "all",
					form: (queryStringResult === null || queryStringResult === void 0 ? void 0 : queryStringResult.form) || null,
					referer: (queryStringResult === null || queryStringResult === void 0 ? void 0 : queryStringResult.referer) || null,
					after: (queryStringResult === null || queryStringResult === void 0 ? void 0 : queryStringResult.after) || null,
					before: (queryStringResult === null || queryStringResult === void 0 ? void 0 : queryStringResult.before) || null
				},
				page: queryStringResult.page || 1,
				perPage: queryStringResult.per_page || 50,
				order: {
					by: queryStringResult.order_by || "created_at",
					direction: queryStringResult.order || "desc"
				}
			});
		}, []);
		useEffect(() => {
			if (!query.ready) return;
			if (options.useRouterQueryString) setRouterQueryString(flatQuery);
			fetchData();
		}, [flatQuery]);
		return {
			data,
			meta,
			query,
			flatQuery,
			fetchData,
			statuses: { fetchDataStatus },
			actions: {
				setFilter,
				setOrder,
				setPage
			}
		};
	}
	/**
	* A reducer for the query of the rest list fetch.
	*
	* @return {{perPage: any, page: number}|{filter: any, page: number}|{ready: boolean}|{page: any}|(any|{})|Array|{sort: any}} { query, flatQuery, actions }
	*/
	function useQuery() {
		const [query, actions] = useMethodsReducer({
			setFilter: (state, filter) => _objectSpread2(_objectSpread2({}, state), {}, {
				page: 1,
				filter: _objectSpread2(_objectSpread2({}, state.filter), filter)
			}),
			setPage: (state, page) => _objectSpread2(_objectSpread2({}, state), {}, { page }),
			setPerPage: (state, perPage) => _objectSpread2(_objectSpread2({}, state), {}, {
				page: 1,
				perPage
			}),
			setOrder: (state, order) => _objectSpread2(_objectSpread2({}, state), {}, { order }),
			setInitial: (state, payload) => _objectSpread2(_objectSpread2(_objectSpread2({}, state), payload), {}, { ready: true })
		}, {
			ready: false,
			filter: {},
			page: 1,
			perPage: null,
			order: {
				by: "id",
				direction: "desc"
			}
		});
		return {
			query,
			flatQuery: useMemo$1(() => {
				return Object.fromEntries(Object.entries(_objectSpread2(_objectSpread2({}, query.filter), {}, {
					page: query.page,
					per_page: query.perPage,
					order: query.order.direction,
					order_by: query.order.by
				})).filter(([, value]) => {
					if (Array.isArray(value) && 0 === value.length) return false;
					return !!value;
				}));
			}, [query]),
			actions
		};
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/components/bulk-action-select.js
	var { useState: useState$1, useCallback } = react.default;
	function BulkActionSelect(props) {
		const [value, setValue] = useState$1(""), applyAction = useCallback((e) => {
			e.preventDefault();
			const action = props.actions.find((item) => item.value === value);
			if (!action) return;
			action.onApply();
			setValue("");
		}, [value, props.actions]);
		return /* @__PURE__ */ react.default.createElement("form", {
			className: `actions bulkactions ${props.className}`,
			onSubmit: applyAction
		}, /* @__PURE__ */ react.default.createElement("label", {
			htmlFor: "bulk-action-selector-top",
			className: "screen-reader-text"
		}, (0, _wordpress_i18n.__)("Select bulk action", "elementor-pro")), /* @__PURE__ */ react.default.createElement("select", {
			name: "action",
			value,
			onChange: (e) => setValue(e.target.value)
		}, /* @__PURE__ */ react.default.createElement("option", {
			value: "",
			disabled: true
		}, (0, _wordpress_i18n.__)("Bulk actions", "elementor-pro")), props.actions.map((action) => {
			return /* @__PURE__ */ react.default.createElement("option", {
				key: action.value,
				value: action.value
			}, action.label);
		})), /* @__PURE__ */ react.default.createElement("input", {
			type: "submit",
			className: "button action",
			value: (0, _wordpress_i18n.__)("Apply", "elementor-pro")
		}));
	}
	BulkActionSelect.propTypes = {
		className: import_prop_types.string,
		actions: import_prop_types.arrayOf(import_prop_types.shape({
			label: import_prop_types.string.isRequired,
			value: import_prop_types.string.isRequired,
			onApply: import_prop_types.func.isRequired
		})).isRequired
	};
	BulkActionSelect.defaultProps = { className: "" };
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/pages/index.js
	var __defProp = Object.defineProperty;
	var __defProps = Object.defineProperties;
	var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
	var __getOwnPropSymbols = Object.getOwnPropertySymbols;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __propIsEnum = Object.prototype.propertyIsEnumerable;
	var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
		enumerable: true,
		configurable: true,
		writable: true,
		value
	}) : obj[key] = value;
	var __spreadValues = (a, b) => {
		for (var prop in b || (b = {})) if (__hasOwnProp.call(b, prop)) __defNormalProp(a, prop, b[prop]);
		if (__getOwnPropSymbols) {
			for (var prop of __getOwnPropSymbols(b)) if (__propIsEnum.call(b, prop)) __defNormalProp(a, prop, b[prop]);
		}
		return a;
	};
	var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
	var { useMemo, useState } = react.default;
	var ORDERABLE_CELLS = [
		"id",
		"created_at",
		"main_meta_id"
	];
	var STATUSES = [
		{
			value: "all",
			label: (0, _wordpress_i18n.__)("All", "elementor-pro")
		},
		{
			value: "unread",
			label: (0, _wordpress_i18n.__)("Unread", "elementor-pro")
		},
		{
			value: "read",
			label: (0, _wordpress_i18n.__)("Read", "elementor-pro")
		},
		{
			value: "trash",
			label: (0, _wordpress_i18n.__)("Trash", "elementor-pro")
		}
	];
	function Index() {
		var _a;
		const { notifyError, notifySuccess } = useNoticesContext();
		const { isTrashEnabled } = useSettingsContext();
		const [checked, setChecked] = useState([]);
		const { data, meta, fetchData, flatQuery, query: { order, filter }, statuses: { fetchDataStatus }, actions: { setFilter, setOrder, setPage } } = useRestDataList("form-submissions/index", {
			allowedFilters: [
				"search",
				"status",
				"form",
				"referer",
				"after",
				"before"
			],
			useRouterQueryString: true,
			hooks: { afterFetch: () => setChecked([]) }
		});
		const isTrashFilterOn = useMemo(() => "trash" === filter.status, [filter.status]);
		const [exportSubmissions, exportOptions] = useExport({
			checked,
			filter
		});
		const [updateRead] = useDataAction(([query, isRead], { abortController }) => {
			if (!validateRestAction(query)) return Promise.reject();
			const messages = notice_messages_default[isRead ? "markedAsRead" : "markedAsUnread"];
			return $e.data.update("form-submissions/index", { is_read: isRead }, query, { signal: abortController.signal }).then((result) => {
				var _a2;
				return notifySuccess(messages.success(((_a2 = result.data.meta) == null ? void 0 : _a2.affected) || 1));
			}).then(fetchData).catch(() => notifyError(messages.error()));
		});
		const [restoreItems] = useDataAction(([query], { abortController }) => {
			if (!validateRestAction(query)) return Promise.reject();
			return $e.data.update("form-submissions/restore", {}, query, { signal: abortController.signal }).then((result) => {
				var _a2;
				return notifySuccess(notice_messages_default.restored.success(((_a2 = result.data.meta) == null ? void 0 : _a2.affected) || 1));
			}).then(fetchData).catch(() => notifyError(notice_messages_default.restored.error()));
		});
		const [deleteItems] = useDataAction(([query], { abortController }) => {
			if (!validateRestAction(query)) return Promise.reject();
			const messages = notice_messages_default[query.force ? "deleted" : "trashed"];
			return $e.data.delete("form-submissions/index", query, { signal: abortController.signal }).then((result) => {
				var _a2;
				return notifySuccess(messages.success(((_a2 = result.data.meta) == null ? void 0 : _a2.affected) || 1), query.force ? null : () => restoreItems(query));
			}).then(fetchData).catch(() => notifyError(messages.error()));
		});
		const rowActions = useMemo(() => [
			{
				key: "view",
				label: (0, _wordpress_i18n.__)("View", "elementor-pro"),
				shouldShow: (item) => "trash" !== item.status,
				props: (item) => ({
					to: `/${item.id}`,
					onClick: void 0
				}),
				component: Link
			},
			{
				key: "restore",
				label: (0, _wordpress_i18n.__)("Restore", "elementor-pro"),
				onApply: (item) => restoreItems({ id: item.id }),
				shouldShow: (item) => "trash" === item.status
			},
			{
				key: "trash",
				label: (0, _wordpress_i18n.__)("Trash", "elementor-pro"),
				onApply: (item) => deleteItems({ id: item.id }),
				shouldShow: (item) => "trash" !== item.status && isTrashEnabled,
				className: "trash"
			},
			{
				key: "delete",
				label: (0, _wordpress_i18n.__)("Delete Permanently", "elementor-pro"),
				onApply: (item) => deleteItems({
					id: item.id,
					force: 1
				}),
				shouldShow: (item) => "trash" === item.status || !isTrashEnabled,
				className: "trash"
			},
			{
				key: "read",
				label: (0, _wordpress_i18n.__)("Mark as Read", "elementor-pro"),
				onApply: (item) => updateRead({ id: item.id }, true),
				shouldShow: (item) => "trash" !== item.status && !item.is_read
			},
			{
				key: "unread",
				label: (0, _wordpress_i18n.__)("Mark as Unread", "elementor-pro"),
				onApply: (item) => updateRead({ id: item.id }, false),
				shouldShow: (item) => "trash" !== item.status && item.is_read
			}
		], []);
		const bulkActions = useMemo(() => {
			return [
				{
					label: (0, _wordpress_i18n.__)("Mark as Read", "elementor-pro"),
					value: "read",
					onApply: () => updateRead({ ids: checked }, true),
					shouldShow: () => !isTrashFilterOn
				},
				{
					label: (0, _wordpress_i18n.__)("Mark as Unread", "elementor-pro"),
					value: "unread",
					onApply: () => updateRead({ ids: checked }, false),
					shouldShow: () => !isTrashFilterOn
				},
				{
					label: (0, _wordpress_i18n.__)("Move to Trash", "elementor-pro"),
					value: "trash",
					onApply: () => deleteItems({ ids: checked }),
					shouldShow: () => !isTrashFilterOn && isTrashEnabled
				},
				{
					label: (0, _wordpress_i18n.__)("Delete Permanently", "elementor-pro"),
					value: "delete",
					onApply: () => deleteItems({
						ids: checked,
						force: 1
					}),
					shouldShow: () => isTrashFilterOn || !isTrashEnabled
				},
				{
					label: (0, _wordpress_i18n.__)("Restore", "elementor-pro"),
					value: "restore",
					onApply: () => restoreItems({ ids: checked }),
					shouldShow: () => isTrashFilterOn
				}
			].filter((action) => action.shouldShow());
		}, [checked, isTrashFilterOn]);
		const tableTitles = useMemo(() => ({
			main_meta_id: {
				label: (0, _wordpress_i18n.__)("Main", "elementor-pro"),
				className: "column-primary"
			},
			actions_log_status: {
				label: (0, _wordpress_i18n.__)("Actions Status", "elementor-pro"),
				className: "column-actions"
			},
			form: {
				label: (0, _wordpress_i18n.__)("Form", "elementor-pro"),
				className: "column-form"
			},
			page: {
				label: (0, _wordpress_i18n.__)("Page", "elementor-pro"),
				className: "column-page"
			},
			id: {
				label: (0, _wordpress_i18n.__)("ID", "elementor-pro"),
				className: "column-id"
			},
			created_at: {
				label: (0, _wordpress_i18n.__)("Submission Date", "elementor-pro"),
				className: "column-date"
			}
		}), []);
		const headerFooterRow = /* @__PURE__ */ react.default.createElement(WpTable.Row, null, /* @__PURE__ */ react.default.createElement(WpTable.Cell, { className: "manage-column bulk-checkbox-column" }, /* @__PURE__ */ react.default.createElement(Checkbox.Bulk, {
			checkedGroup: checked,
			onChange: setChecked,
			allValues: data.map((checkedItem) => checkedItem.id)
		})), Object.entries(tableTitles).map(([key, tableTitle]) => {
			const cellProps = {
				component: "th",
				className: `manage-column ${tableTitle.className || ""}`
			};
			if (ORDERABLE_CELLS.includes(key)) return /* @__PURE__ */ react.default.createElement(WpTable.OrderableCell, __spreadProps(__spreadValues({}, cellProps), {
				key,
				order: {
					key,
					current: order,
					onChange: (value) => setOrder(value)
				}
			}), tableTitle.label);
			return /* @__PURE__ */ react.default.createElement(WpTable.Cell, __spreadValues({ key }, cellProps), tableTitle.label);
		}));
		const exportButton = /* @__PURE__ */ react.default.createElement("div", { className: "alignright" }, /* @__PURE__ */ react.default.createElement(ExportButton, {
			onClick: () => {
				var _a2;
				exportSubmissions("selected" === exportOptions.mode ? { ids: checked } : __spreadValues({}, flatQuery), checked.length || ((_a2 = meta.pagination) == null ? void 0 : _a2.total));
			},
			isLoading: STATUS_LOADING === exportOptions.status,
			progress: exportOptions.progress,
			mode: exportOptions.mode,
			disabled: !((_a = meta.pagination) == null ? void 0 : _a.total) && "loading" !== exportOptions.status
		}));
		const tablePagination = meta.pagination && /* @__PURE__ */ react.default.createElement(Pagination, {
			total: meta.pagination.total,
			currentPage: meta.pagination.current_page,
			lastPage: meta.pagination.last_page,
			perPage: meta.pagination.per_page,
			onChange: (value) => setPage(value)
		});
		return /* @__PURE__ */ react.default.createElement(react.default.Fragment, null, /* @__PURE__ */ react.default.createElement("div", null, /* @__PURE__ */ react.default.createElement(SearchBox, {
			key: "search",
			value: filter.search,
			onChange: (value) => setFilter({ search: value }),
			isSearching: !!filter.search && fetchDataStatus === "loading"
		}), /* @__PURE__ */ react.default.createElement(LinksFilter, {
			options: STATUSES.map(({ value, label }) => {
				var _a2;
				var _b;
				return {
					value,
					label,
					count: (_a2 = meta.count) == null ? void 0 : _a2[value],
					shouldShow: "all" === value || ((_b = meta.count) == null ? void 0 : _b[value]) > 0
				};
			}),
			value: filter.status,
			onChange: (value) => setFilter({ status: value })
		}), /* @__PURE__ */ react.default.createElement("div", { className: "clear" }), /* @__PURE__ */ react.default.createElement("div", { className: "tablenav top" }, /* @__PURE__ */ react.default.createElement(BulkActionSelect, {
			actions: bulkActions,
			className: "alignleft"
		}), /* @__PURE__ */ react.default.createElement("div", { className: "alignleft actions" }, /* @__PURE__ */ react.default.createElement(RefererFilter, {
			value: filter.referer || "",
			onChange: ((value) => setFilter({ referer: value }))
		}), /* @__PURE__ */ react.default.createElement(ResourceFilter, {
			value: filter.form || "",
			onChange: ((value) => setFilter({ form: value })),
			options: [{
				value: "",
				label: (0, _wordpress_i18n.__)("All Forms", "elementor-pro")
			}],
			resourceOptions: {
				type: "resource",
				command: "forms/index",
				args: { context: "options" }
			},
			name: "form",
			label: (0, _wordpress_i18n.__)("Filter by form", "elementor-pro")
		}), /* @__PURE__ */ react.default.createElement(DateFilter, {
			value: {
				after: filter.after,
				before: filter.before
			},
			onChange: ({ after, before }) => {
				setFilter(__spreadValues(__spreadValues({}, after !== void 0 ? { after } : {}), before !== void 0 ? { before } : {}));
			},
			label: (0, _wordpress_i18n.__)("Filter by date", "elementor-pro"),
			name: "date"
		})), exportButton, tablePagination), /* @__PURE__ */ react.default.createElement(WpTable, { className: "e-form-submissions-list-table striped table-view-list" }, headerFooterRow && /* @__PURE__ */ react.default.createElement(WpTable.Header, null, headerFooterRow), /* @__PURE__ */ react.default.createElement(WpTable.Body, null, !["loading", "idle"].includes(fetchDataStatus) && 0 === data.length && /* @__PURE__ */ react.default.createElement(WpTable.Row, { className: "no-items" }, /* @__PURE__ */ react.default.createElement(WpTable.Cell, {
			className: "colspanchange",
			colSpan: 7
		}, (0, _wordpress_i18n.__)("No submissions found.", "elementor-pro"))), data.map((item) => {
			const filteredRowActions = rowActions.filter((action) => action.shouldShow(item));
			return /* @__PURE__ */ react.default.createElement(SubmissionRow, {
				key: item.id,
				item,
				tableTitles,
				checkBoxComponent: /* @__PURE__ */ react.default.createElement(Checkbox, {
					checkedGroup: checked,
					onChange: setChecked,
					value: item.id
				}),
				rowActionComponent: /* @__PURE__ */ react.default.createElement(WpTable.RowActions, {
					actions: filteredRowActions,
					item
				})
			});
		})), headerFooterRow && /* @__PURE__ */ react.default.createElement(WpTable.Footer, null, headerFooterRow)), /* @__PURE__ */ react.default.createElement("div", { className: "tablenav bottom" }, /* @__PURE__ */ react.default.createElement(BulkActionSelect, {
			actions: bulkActions,
			className: "alignleft"
		}), exportButton, tablePagination)));
	}
	function validateRestAction(query) {
		return query.id || query.ids && query.ids.length > 0;
	}
	//#endregion
	//#region node_modules/reach-router-hash-history/index.js
	function getHashPath() {
		const href = window.location.href;
		const hashIndex = href.indexOf("#");
		return hashIndex === -1 ? "" : href.substring(hashIndex + 1);
	}
	function pushHashPath(path) {
		window.location.hash = "#" + path;
	}
	function replaceHashPath(path) {
		const hashIndex = window.location.href.indexOf("#");
		window.location.replace(window.location.href.slice(0, hashIndex >= 0 ? hashIndex : 0) + "#" + path);
	}
	var createHashSource = (initialPathname = "/") => {
		let index = 0;
		return {
			get location() {
				return {
					pathname: getHashPath(),
					search: ""
				};
			},
			addEventListener(name, fn) {
				if (name === "popstate") window.addEventListener("hashchange", fn);
			},
			removeEventListener(name, fn) {
				if (name === "popstate") window.addEventListener("hashchange", fn);
			},
			history: {
				get entries() {
					return [{
						pathname: getHashPath(),
						search: ""
					}];
				},
				get index() {
					return index;
				},
				get state() {},
				pushState(state, _, uri) {
					pushHashPath(uri);
				},
				replaceState(state, _, uri) {
					replaceHashPath(uri);
				}
			}
		};
	};
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/app.js
	var history$1 = createHistory(createHashSource());
	function App() {
		return /* @__PURE__ */ react.default.createElement("div", { id: "elementor-form-submissions" }, /* @__PURE__ */ react.default.createElement(SettingsProvider, { value: window.elementorSubmissionsConfig }, /* @__PURE__ */ react.default.createElement(NoticesProvider, null, /* @__PURE__ */ react.default.createElement(Notices, null), /* @__PURE__ */ react.default.createElement(LocationProvider, { history: history$1 }, /* @__PURE__ */ react.default.createElement(Router, null, /* @__PURE__ */ react.default.createElement(Index, { path: "/" }), /* @__PURE__ */ react.default.createElement(Item, { path: "/:id" }))))));
	}
	//#endregion
	//#region modules/forms/submissions/assets/js/admin/admin.js
	$e.components.register(new Component());
	$e.components.register(new FormsComponent());
	var AppWrapper = elementorCommon.config.isDebug ? react.default.StrictMode : react.default.Fragment;
	ReactDOM.render(/* @__PURE__ */ react.default.createElement(AppWrapper, null, /* @__PURE__ */ react.default.createElement(App, null)), document.getElementById("e-form-submissions"));
	//#endregion
})(React, wp.i18n);

//# sourceMappingURL=form-submission-admin.js.map