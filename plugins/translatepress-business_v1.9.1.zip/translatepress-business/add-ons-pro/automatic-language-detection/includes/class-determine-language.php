<?php

class TRP_IN_ALD_Determine_Language {

	public function __construct() {
		// using relative path because this function is also called outside WP
		require_once( __DIR__ . '/class-browser-language.php' );
		require_once( __DIR__ . '/class-ip-language.php' );
	}

	/**
	 * Return preferred language code based on parameters.
	 *
	 * Returns null if there are no matches between available languages and desired languages.
	 *
	 * @param $published_languages array       TranslatePress settings['publish-languages']
	 * @param $iso_codes array                 Iso codes of the published languages
	 * @param $detection_method string         ald_settings['detection-method']
	 *
	 * @return null|string
	 */
	public function get_needed_language( $published_languages, $iso_codes, $detection_method ) {
		switch ( $detection_method ) {
			case 'browser-ip': {
				$browser_language_code = $this->get_browser_language( $published_languages, $iso_codes );
				return $browser_language_code ? $browser_language_code : $this->get_ip_language( $published_languages, $iso_codes );
			}
			case 'ip-browser': {
				$ip_language_code = $this->get_ip_language( $published_languages, $iso_codes );
				return $ip_language_code ? $ip_language_code : $this->get_browser_language( $published_languages, $iso_codes );
			}
			case 'browser': {
				return $this->get_browser_language( $published_languages, $iso_codes );
			}
			case 'ip': {
				return $this->get_ip_language( $published_languages, $iso_codes );
			}
		}

		return null;
	}

	private function get_browser_language( $published_languages, $iso_codes ) {
		$trp_browser_language = new TRP_IN_Browser_Language();
		return $trp_browser_language->get_browser_language( $published_languages, $iso_codes );
	}

	private function get_ip_language( $published_languages, $iso_codes ) {
		$trp_ip_language = new TRP_IN_IP_Language();
		return $trp_ip_language->get_ip_language( $published_languages, $iso_codes );
	}
}
