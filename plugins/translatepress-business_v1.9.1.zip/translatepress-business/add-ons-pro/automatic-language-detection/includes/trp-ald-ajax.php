<?php

/**
 * Class TRP_IN_ALD_Ajax
 *
 * Lightweight Ajax endpoint for resolving the visitor country by IP.
 */
class TRP_IN_ALD_Ajax {

    /**
     * TRP_IN_ALD_Ajax constructor. Outputs a validated country code.
     *
     */
    public function __construct() {

        if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
            header( 'Allow: POST' );
            $this->send_json( null, 405 );
        }

        if ( isset( $_POST['action'] ) && 'trp_ald_get_needed_language' === $_POST['action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Public, read-only endpoint.
            $this->send_legacy_needed_language();
        }

        if ( ! isset( $_POST['action'] ) || 'trp_ald_get_ip_country' !== $_POST['action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Public, read-only endpoint.
            $this->send_json( null, 400 );
        }

        try {
            require_once( __DIR__ . '/class-ip-language.php' );
            $trp_ip_language = new TRP_IN_IP_Language();
            $country_code    = $trp_ip_language->get_country_iso_code();
        } catch ( Throwable $error ) {
            $this->send_json( null, 500 );
        }

        $country_code = is_string( $country_code ) ? strtoupper( $country_code ) : null;
        if ( ! $country_code || ! preg_match( '/\A[A-Z]{2}\z/', $country_code ) ) {
            $country_code = null;
        }

        $this->send_json( $country_code );
    }

    /**
     * Answer the request sent by the pre-1.1.3 script.
     *
     * A CDN or JS-combining plugin can keep serving the old script after an update.
     * On an error response it would save the current page language for 30 days,
     * so keep resolving the language for it. Remove once the old script is out of caches.
     */
    private function send_legacy_needed_language() {
        $detection_methods = array( 'browser-ip', 'ip-browser', 'browser', 'ip' );
        $detection_method  = isset( $_POST['detection_method'] ) && is_string( $_POST['detection_method'] ) ? $_POST['detection_method'] : ''; // phpcs:ignore
        $published_languages = $this->get_posted_language_codes( 'publish_languages' );
        $iso_codes           = $this->get_posted_language_codes( 'iso_codes' );

        if ( ! in_array( $detection_method, $detection_methods, true ) || empty( $published_languages ) || empty( $iso_codes ) ) {
            $this->send_json( null );
        }

        try {
            require_once( __DIR__ . '/class-determine-language.php' );
            $trp_determine_language = new TRP_IN_ALD_Determine_Language();
            $needed_language        = $trp_determine_language->get_needed_language( array_values( $published_languages ), $iso_codes, $detection_method );
        } catch ( Throwable $error ) {
            $this->send_json( null, 500 );
        }

        $this->send_json( is_string( $needed_language ) ? $needed_language : null );
    }

    /**
     * Read a posted array of language codes, keeping only entries shaped like a language code.
     *
     * @param string $key POST key.
     * @return array
     */
    private function get_posted_language_codes( $key ) {
        $language_codes = array();
        if ( ! isset( $_POST[ $key ] ) || ! is_array( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
            return $language_codes;
        }

        foreach ( $_POST[ $key ] as $index => $code ) { // phpcs:ignore
            if ( is_string( $code ) && preg_match( '/\A[A-Za-z0-9_-]{1,20}\z/', $code ) &&
                ( is_int( $index ) || preg_match( '/\A[A-Za-z0-9_-]{1,20}\z/', $index ) ) ) {
                $language_codes[ $index ] = $code;
            }
        }

        return $language_codes;
    }

    /**
     * Send a JSON response without loading WordPress.
     *
     * @param string|null $value       Country code, language code or null.
     * @param int         $status_code HTTP response status.
     */
    private function send_json( $value, $status_code = 200 ) {
        http_response_code( $status_code );
        header( 'Content-Type: application/json; charset=UTF-8' );
        header( 'X-Content-Type-Options: nosniff' );
        header( 'X-Robots-Tag: noindex' );
        header( "Content-Security-Policy: default-src 'none'; frame-ancestors 'none'; sandbox" );
        header( 'X-Frame-Options: DENY' );
        header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );

        echo json_encode( $value, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON response containing only a validated country/language code or null; WordPress is not loaded.
        exit;
    }
}

new TRP_IN_ALD_Ajax;

die();
