﻿=== TranslatePress - Business ===
Contributors: cozmoslabs, razvan.mo, madalin.ungureanu, sareiodata
Donate link: https://www.translatepress.com/
Tags: translate, translation, multilingual, automatic translation, bilingual, front-end translation, google translate, language
Requires at least: 3.1.0
Tested up to: 7.1.5
Requires PHP: 7.4
Stable tag: 1.9.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Translate your entire site directly from the front-end and go multilingual. Full support for WooCommerce, page builders + Google Translate integration
 
== Description ==

**Experience a better way to translate your WordPress site and go multilingual, directly from the front-end using a visual translation interface.**

TranslatePress is a [WordPress translation plugin](https://translatepress.com/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) that anyone can use.

The interface allows you to easily translate the entire page at once, including output from shortcodes, forms and page builders. It also works out of the box with WooCommerce.

Built the WordPress way, TranslatePress - Multilingual is a GPL and self hosted translation plugin, meaning you'll own all your translations, forever. It's the fastest way to create a bilingual or [multilingual site](https://translatepress.com/how-to-create-a-multilingual-wordpress-site/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree).

https://www.youtube.com/watch?v=pUlYisvBm8g

== Multilingual & Translation Features ==

* Translate all your website content directly from the front-end, in a friendly user interface (translations are displayed in real-time).
* Fully compatible with all themes and plugins
* Live preview of your translated pages, as you edit them.
* [Image translation](https://translatepress.com/docs/image-translation/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) support, for [translating images, sliders and other media](https://translatepress.com/translate-images-in-wordpress/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree).
* Support for both manual and automatic translation
* Ability to [translate dynamic strings](https://translatepress.com/translate-dynamic-strings-wordpress/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) (gettext) added by WordPress, plugins and themes.
* Integrates with Google Translate, allowing you to set up Automatic Translation using your own Google API key.
* Translate larger html blocks by merging strings into translation blocks.
* Place language switchers anywhere using shortcode **[language-switcher]**, WP menu item or as a floating dropdown.
* Editorial control allowing you to publish your language only when all your translations are done
* Conditional display content shortcode based on language [trp_language language="en_US"] English content only [/trp_language]
* Possibility to [edit gettext strings](https://translatepress.com/edit-plugin-strings/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) from themes and plugins from English to English, without adding another language. Basically a string-replace functionality.
* Translate only certain paths and [exclude content from being translated](https://translatepress.com/partially-translate-wordpress-exclude-posts-pages-products/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree)
* Translation Block feature in which you can translate multiple html elements together
* Native **Gutenberg** support, so you can easily [translate Gutenberg blocks](https://translatepress.com/translate-gutenberg-blocks-in-wordpress/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree)
* Out of the box [WooCommerce](https://translatepress.com/translate-woocommerce-products-translatepress/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) compatibility

Note: this plugin uses the Google Translation API to translate the strings on your site. This feature can be enabled or disabled according to your preferences.

Users with administrator rights have access to the following settings:

* select default language of the website and one translation language, for bilingual sites
* choose whether language switcher should display languages in their native names or English name
* force custom links to open in current language
* enable or disable url subdirectory for the default language
* enable automatic translation via Google Translate

== Powerful Translation Add-ons ==

TranslatePress - Multilingual has a range of [premium Add-ons](https://translatepress.com/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) that allow you to extend the power of this WordPress translation plugin:

**Pro Add-ons** (available in the [premium versions](https://translatepress.com/pricing/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) only)

* [Extra Languages](https://translatepress.com/docs/addons/multiple-languages/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) - allows you to add an unlimited number of translation languages, with the possibility to publish languages later after you complete the translation
* [SEO Pack](https://translatepress.com/docs/addons/seo-pack/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) - lets you translate meta information (like page title, description, url slug, image alt tag, Twitter and Facebook Social Graph tags & more) for boosting your multilingual SEO and increase traffic. Works with all popular SEO plugins.
* [Different Domain per Language](https://translatepress.com/docs/developers/different-domain-per-language/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) - assign a different domain to each language you add (e.g. domain.de, domain.es) and improve international SEO by creating a fully local experience for your visitors
* [Translator Accounts](https://translatepress.com/docs/addons/translator-accounts/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) - create or allow existing users to translate the site without admin rights
* [Browse as User Role](https://translatepress.com/docs/addons/browse-as-role/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) - view and translate content that is visible only to a particular user role
* [Navigation Based on Language](https://translatepress.com/docs/addons/navigate-based-language/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) - configure and display different menu items for different languages
* [Automatic User Language Detection](https://translatepress.com/docs/addons/automatic-user-language-detection/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) - redirect first time visitors to their preferred language based on their browser settings or IP address
* [DeepL Automatic Translation](https://translatepress.com/docs/addons/deepl-automatic-translation/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree) - The DeepL Automatic Translation add-on lets you automatically translate your website through the DeepL API

**Keyboard Shortcuts**

* **CTRL ( ⌘ ) + S** – Save translation for the currently editing strings
* **CTRL ( ⌘ ) + ALT + Z** – Discard all changes for the currently editing strings
* **CTRL ( ⌘ ) + ALT + →** (Right Arrow) – Navigate to next string
* **CTRL ( ⌘ ) + ALT + ←** (Left Arrow) – Navigate to previous string

= Website =

[translatepress.com](https://translatepress.com/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree)

= Documentation =

[Visit TranslatePress WordPress Translation plugin documentation page](https://translatepress.com/docs/translatepress/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree)


= Demo Site =

You can test out TranslatePress - Multilingual plugin by [visiting our demo site](https://demo.translatepress.com/)

== Installation ==

1. Upload the translatepress folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings -> TranslatePress and choose a translation language.
4. Open the front-end translation editor from the admin bar to translate your site.

== Frequently Asked Questions ==

= Where are my translations stored? =

All the translation are stored locally in your server's database.

= What types of content can I translate? =

TranslatePress - Multilingual plugin works out of the box with WooCommerce, custom post types, complex themes and site builders, so you'll be able to translate any type of content.

= How is it different from other multilingual & translation plugins like WPML or Polylang? =

TranslatePress is easier to use and more intuitive altogether. No more switching between the editor, string translation interfaces or badly translated plugins. You can now translate the full page content directly from the front-end. This makes TranslatePress a great alternative to plugins like Polylang and WPML.

= How do I start to translate my WordPress site? =

After installing the plugin, select your secondary language and click "Translate Site" to start translating your entire site exactly as it looks in the front-end.

= Will it slow down my website? =

TranslatePress will have little impact on your site speed. For more details see [Top WordPress Translation Plugins Compared Based on Page Load Time](https://translatepress.com/top-wordpress-translation-plugins-compared-based-on-page-load-time/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree)

= Can you translate your WooCommerce store? =

Yes, TranslatePress works out of the box with WooCommerce. You can use to build a [multilingual WooCommerce store](https://translatepress.com/translate-woocommerce-products-translatepress/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree).

= Where can I find out more information? =

For more information please check out our [documentation](https://translatepress.com/docs/translatepress/?utm_source=wp.org&utm_medium=tp-description-page&utm_campaign=TPFree).




== Changelog ==
= 1.9.1 =
* Fixed database optimization failing with "Invalid gettext table name" on servers where table names are case-insensitive (e.g. Windows) and the table prefix contains uppercase letters

= 1.9.0 =
* Improved handling of duplicate slugs cases, previously resulting in 404 errors on translated pages
* Fixed alignment issue in Automatic User Language Detection hello bar popup

= 1.8.9 =
* Improved Automatic User Language Detection: fewer server requests, browser language detected without a server call, works on hosts that block direct PHP access, and no longer locks visitors to the wrong language when detection fails

= 1.8.8 =
* Fixed meta tag og:locale when using SEOPress to follow current TranslatePress language
* Keep the language detection popup out of page builder editors

= 1.8.7 =
* Improved the term slug translation query to prevent SQL injection vulnerabilities
* Improved the slug uniqueness query to prevent SQL injection vulnerabilities
* Fixed broken access control in when saving post slug translations
* Fixed WooCommerce cart removal 404 in secondary languages with SEO Pack
* Automatically translate post slugs for all languages in the editor
* Fixed Multiple Domains REST authentication recursion
* Validate current host against configured domains
* Improved sanitization of trp-ald-ajax output used for detecting user language
* Fixed Different Domain per Language: 404 for translated slugs starting with the language code
* Fixed SSO iframe loop + cross-domain forced logout in Different Domain per Language

= 1.8.6 =
* New feature: Added automatic language detection popup configurator
* Fixed composite WooCommerce product permalink base

= 1.8.5 =
* Changed update cache period to 24 hours

= 1.8.4 =
* Added filter on machine translated slug

= 1.8.3 =
* Fix issue with Elementor websites language switcher not working correctly with Different Domain per Language addon.
* Changed location of license checker function
* Added different wording for the License page

= 1.8.2 =
* Added the plugin updater code from TranslatePress - Multilingual into this plugin

= 1.8.1 =
* Fix Yoast/RankMath/SEOPress sitemaps showing untranslated slugs on secondary domains when Different Domain per Language is enabled
* Improved handling of possible errors resulted from API calls that retrieved DeepL supported languages list
* Fix Elementor language switcher links getting replaced with the current domain

= 1.7.9 =
* Fixed issue regarding inserting translated slugs as originals. Prevent attachment slugs from being machine translated
* Fixed CORS on Elementor fonts, post CSS, and widget HTML for Different Domain per Language

= 1.7.8 =
* Added support for automatically translating hierarchical slugs like page-parent/page-child or WooCommerce slugs like product/category-parent/category-child/product-name
* Fixed redirect loop for composite WooCommerce base. Display composite WooCommerce base in the string translation editor
* Fixed WooCommerce redirect loop on product category pages
* Fixed CORS font issue for Breakdance plugin

= 1.7.7 =
* Fix WooCommerce translated product base redirect loop with uppercase custom permalinks
* Fix bug where completing the WooCommerce checkout was not working on secondary languages
* Make languages sortable in free version as well

= 1.7.6 =
* Fixed WooCommerce product base handling when using %product_cat% permalinks
* Fixed mobile WooCommerce reset password cookie path for translated account URLs
* Serve correct sitemaps for Yoast, RankMath, SEOPress and AIOSEO with Different Domain per Language add-on

= 1.7.5 =
* Add redirect support for Rank Math and Redirection redirects in secondary languages
* Fix custom WooCommerce base fallback on secondary languages
* Oembed rest link did not work on slug translated pages due to WP not finding the correct post id
* Fixed JS error when clicking Change Language on the Automatic User Language Detection pop-up
* Fixed clicking "Close and do not switch language" navigating to top of page
* Minor CSS tweaks on the pop-up for Automatic User Language Detection

= 1.7.4 =
* Added a new add-on: Different Domain for Language

= 1.7.3 =
* Do not force post slug uniqueness on private CPT's as it can cause issues
* Fix fatal error when the pro addon was installed without the free version

= 1.7.2 =
* Fixed MaxMind autoloader loading classes from other plugins in some cases
* Updated Geo IP database to 20260109 version

= 1.7.1 =
* Fixed PHP warning related to gettext slugs
* Updated Geo IP database to 20251212 version

= 1.7.0 =
 * Added support for DeepL translation for 75 languages
 * Added support for Latin American Spanish automatic translation for DeepL
 * Added hook trp_deepl_request_params for next-gen model_type parameter support for DeepL
 * Added support for exact match search in Slugs tab from String Translation by placing the string in quotes: "example"

= 1.6.9 =
* Fix issue with sitemaps where the first language is not the default, the slug for the first language was not translated
* Updated Geo IP database to 20251031 version

= 1.6.8 =
* Added a retry mechanism to better handle deadlocks errors when inserting original slugs in database
* Fixed missing anchor text from Automatic User Language Detection pop-up
* Fixed PHP warnings in gettext slug translations
* Fixed PHP notice about due to applying strtolower on null value

= 1.6.7 =
* Start Translating in under 5 minutes with a new onboarding flow for TranslatePress to quickly setup languages, automatic translation and add-ons
* Fixed headers already sent error when trying to install TranslatePress - Multilingual from admin notification

= 1.6.6 =
* Fixed unnecessary non-costly calls to DeepL API when having unsupported languages
* Updated Geo IP database to 20251003 version

= 1.6.5 =
* Improved reliability of detecting WP crons by using wp_doing_cron function
* Added filter to stop translating slugs of type other
* Updated Geo IP database to 20250926 version

= 1.6.4 =
* Fixed translating slugs for taxonomies imported through Meta Box importer
* Updated Geo IP database to 20250815 version

= 1.6.3 =
* Prevent translation of slugs containing only numerals
* Fixed flush_permalinks call when activating SEO Pack add-on
* Fixed edge case of uncaught type error in PHP 8.3

= 1.6.2 =
* Fixed paginated widgets when using Elementor Pro on pages with translated slugs
* Updated Geo IP database to 20250523 version

= 1.6.1 =
* Fixed pagination 404 issue when pagination base is translated

= 1.5.9 =
* Fixed unnecessary redirect when dealing with uppercase encoded translated slug
* Fixed Elementor pagination redirect issue on pages with translated slug
* Added support for DeepL throttle in case the API returns 429 too many requests response

= 1.5.8 =
* Fixed issue with automatically translating slugs from non-latin language
* Fixed attachment links redirects error on posts with translated slugs
* Added hook to allow DeepL glossary usage

= 1.5.7 =
* Fixed remove languages button not working properly when clicking trash icon
* Fixed remove item button displaying the confirmation dialog twice in Advanced Settings
* Fixed compatibility issue between WP Cron and translating slugs
* Added hook to solve a redirect issue during certain types of pagination

= 1.5.6 =
* Redesigned TranslatePress Settings UI
* Fixed pagination urls not having translated slugs on secondary languages

= 1.5.5 =
* Fixed redirect loop on pages with translated slugs on sites that enforce missing trailing slash on paths

= 1.5.4 =
* Fixed issue with GET parameters having broken encoding or forced lowercase causing compatibility issues with other plugins
* Fixed redirect loop issues in some cases
* Fixed subdirectory installs 404 issues in some cases
* Added hook trp_translated_request_uri

= 1.5.3 =
* Fixed not being able to remove products from cart on additional languages in WooCommerce
* Updated Geo IP database to 20250207 version

= 1.5.2 =
* Fixed deprecated way of calling DeepL API
* Extended keyword search in String Translation UI to return results from slug translations too, alongside matching default language slugs
* Improved String Translation UI by showing inactive translations of slugs for original slugs that no longer exist
* Added new feature to delete slug translations in String Translation UI, useful for cleaning up unwanted suffixes when having duplicate original slug conflicts
* Fixed broken translated urls when having multiple terms separated by plus or comma
* Fixed broken GET parameters in translated urls, sometimes causing redirect loops
* Fixed some cases of broken translated urls containing non-latin characters
* Fixed untranslated rel=next and rel=prev link tags added by SEO plugins

= 1.5.1 =
* Improved compatibility with WP Rocket cache when redirecting to the url with translated slugs
* Fixed WooCommerce password reset on urls with translated slugs

= 1.5.0 =
* Improved performance by calling fewer SQL commands on tables when automatically translating slugs, avoiding possible deadlocks
* Fixed bug preventing manually translating non-latin original term slugs in String Translation interface
* Fixed showing encoded translation when manually editing slugs with non-latin translation in the front-end editor
* Fixed bug where non-public CPT slugs were automatically translated resulting in 404 errors in some cases
* Fixed edge case when slugs of type "other" were not automatically translated
* Fixed PHP deprecated notice about constant FILTER_SANITIZE_STRING when detecting user language

= 1.4.9 =
* Fixed slug translation not working properly on WordPress Multisite or subfolder installs
* Fixed issue with searching non-latin term slugs in String Translation

= 1.4.8 =
* SEO Pack: Fixed some cases of infinite redirects and 404 caused by duplicated translations occurring during database upgrade
* SEO Pack: Fixed incorrectly adding -2 suffixes in some cases when trying to ensure slug uniqueness
* SEO Pack: Fixed case of migrating duplicated translation slugs due to a bug in the previous method of slug storage
* SEO Pack: Fixed issue with translating non-latin slugs in String Translation
* SEO Pack: Improved String Translation Slugs editor by showing inactive post type base slugs and taxonomies
* SEO Pack: Improved front-end speed and avoid possible timeouts if the database upgrade has not been performed yet
* SEO Pack: Improved loading time of String Translation by counting items in SQL

= 1.4.7 =
* SEO Pack: Fixed inability to manually edit non-latin slugs in String Translation
* SEO Pack: Added a check to avoid errors before renaming obsolete slug tables from 1.4.3 version when rolling back and forth

= 1.4.6 =
* SEO Pack: Fixed slug translation issues. It's recommended to back-up your database before updating
* SEO Pack: Fixed issue with making sure translated slugs are unique

= 1.4.5 =
* SEO Pack: Fixed slug translation issues
* SEO Pack: Added Advanced option to Load legacy SEO Pack Add-On

= 1.4.4 =
* SEO Pack: Fixed slug translation issues

= 1.4.3 =
* SEO Pack: Fixed missing tables SQL errors after updating to previous version
* SEO Pack: Fixed issues when running the database update

= 1.4.2 =
* SEO Pack: Major refactoring of url slugs handling. It's recommended to back-up your database before updating
* SEO Pack: Numerous fixes including support for WooCommerce custom permalinks, custom post permalinks, permalinks without base category, automatic slug translation for hierarchical pages

= 1.4.1 =
* Added support for Chinese Traditional automatic translations
* Fixed edge case error when DeepL API request for supported languages is not responding

= 1.4.0 =
* SEO Pack: Fixed sitemap hreflang codes not reflecting the Advanced setting to remove country code
* Automatic User Language Detection: Updated Geo IP database to 20240607 version
* DeepL: UI improvements to the Automatic Translation tab

= 1.3.9 =
* DeepL: Added support for Arabic language
* Automatic User Language Detection: Updated Geo IP database to 20240416 version

= 1.3.8 =
* SEO Pack: Added support for translating article:section and article:tag meta tags
* Automatic User Language Detection: Updated Geo IP database to 20240305 version

= 1.3.7 =
* Translator Accounts: Added Translate Site sidebar button in WP Dashboard for Translator accounts
* Automatic User Language Detection: Updated Geo IP database to 20231208 version

= 1.3.6 =
* SEO Pack: Fixed compatibility issue with ACF where translated CPT base slug would lead to 404 pages

= 1.3.5 =
* SEO Pack: Fixed 404 urls when selecting multiple terms in a category on translated pages, generally used in filtering features
* Automatic User Language Detection: Updated Geo IP database to 20231027 version

= 1.3.4 =
* SEO Pack: Fixed edge case issue with incorrectly translating post slugs in default language
* SEO Pack: Added extra parameters to trp_get_term_args hook

= 1.3.3 =
* SEO Pack: Improved automatic slug translation when original slug contains hyphens by preventing translation engines from sometimes generating identical translations with the original slug
* SEO Pack: Added filter trp_allow_redirect_to_translated_url to prevent redirect in custom cases
* SEO Pack: Added filter trp_get_term_args when searching for the original term slug based on translation

= 1.3.2 =
* SEO Pack: Fixed automatic slug translation issue with The Events Calendar plugin
* Automatic User Language Detection: Updated Geo IP database to 20230901 version
* Automatic User Language Detection: Fixed popup issue when clicking on flags to change language

= 1.3.1 =
* Automatic User Language Detection: Fixed dropdown of languages from pop-up not working in some cases
* SEO Pack: Fixed some cases of disappearing CPT slugs translations leading to 404 pages
* SEO Pack: Improved handling of translated slugs when using Automatic Slug Translation

= 1.3.0 =
* Fixed an edge case issue that prevented activation of TranslatePress - Business plugin
* SEO Pack: Fixed issue with Automatic Slug Translation when having multiple post types queried

= 1.2.9 =
* SEO Pack: Added hook when saving post slugs
* Automatic User Language Detection: Fixed html in popup
* DeepL: Show formality option only for languages that support it
* DeepL: Translation Engine formality is now preselected when adding new languages with explicit formality

= 1.2.8 =
* Automatic User Language Detection: Improved add-on settings UI by placing them in a subtab of Advanced settings
* Automatic User Language Detection: Updated GeoIP database to 20230613 version

= 1.2.7 =
* SEO Pack: Fixed edge case error with trim function being passed an array
* Extra languages: Improved handling extra languages in TranslatePress General settings

= 1.2.6 =
* SEO Pack: Fixed some cases of re-saving WooCommerce permalinks adding an extra slash to product cpt causing 404
* SEO Pack: Fixed url encoding in non-latin languages when automatic slug translation is on
* SEO Pack: Fixed automatic slug translation not working for cpt on individual posts
* SEO Pack: Fixed language switcher not working from one language to another when translating slugs in non-latin languages

= 1.2.5 =
* DeepL: Added support for Norwegian (Bokmal) language

= 1.2.4 =
* Automatic User Language Detection: Fixed keeping GET parameters after changing language from pop-up
* Translator Accounts: Added hook to programmatically prevent showing admin bar for translator user role if needed

= 1.2.3 =
* Automatic User Language Detection: Updated GeoIP database to 20221209 version
* Automatic User Language Detection: Added filter to not show change language pop-up for iPhones
* Automatic User Language Detection: Skip enqueueing css file when pop-up functionality is not loaded

= 1.2.2 =
* SEO Pack: Added filter trp_redirect_status to allow changing redirect status from all wp_redirect calls

= 1.2.1 =
* SEO Pack: Fixed dependency error if TP Multilingual is not up-to-date

= 1.2.0 =
* SEO Pack: Fixed WooCommerce product slug translation in Hebrew

= 1.1.9 =
* SEO Pack: Fixed slug translation in urls from sitemap generated by All in One SEO plugin
* SEO Pack: Fixed missing default language urls from sitemap generated by All in One SEO plugin when first language is not the default language

= 1.1.8 =
* Automatic User Language Detection: Fixed showing the correct detected language in the pop-up
* Automatic User Language Detection: Updated GeoIP database to 20220712 version

= 1.1.7 =
* SEO Pack: Fixed issue with term slug translation created with JetEngine
* SEO Pack: Fixed notice with undefined variable
* Automatic User Language Detection: Ensuring compatibility with the option to change html lang attribute

= 1.1.6 =
* Fix: issue with Automatic User Language Detection redirect not working on home page for the default language
* Fix: correctly replace the {{sugested_language}} tag for the Automatic User Language Detection add-on

= 1.1.5 =
* SEO Pack: Improved compatibility with Elementor Sitemap

= 1.1.4 =
* Automatic User Language Detection: Improved pop-up compatibility with themes

= 1.1.3 =
* Automatic User Language Detection: Fixed the 'Close and do not show again' button on the pop-up not working sometimes

= 1.1.2 =
* SEO Pack: Fixed WooCommerce taxonomies slugs manual translations not saving properly in some cases
* SEO Pack: Added filter to fix edge case issue on listing page in WP dashboard 

= 1.1.1 =
* Automatic User Language Detection: Show front-end pop-up to visitors, asking to change language instead of redirecting directly to detected language
* Automatic User Language Detection: Updated Geo IP location database to 20220315 version
* SEO Pack: Fixed sitemap containing urls with language slugs linking to paths excluded from translation
* SEO Pack: Fixed issue affecting translation of some particular JSON requests

= 1.1.0 =
* Automatic User Language Detection: Improved compatibility with themes by removing redirect urls dependence to hreflang tags
* DeepL: Improved Automatic Translation tab checking for translation API key validity

= 1.0.9 =
* DeepL: Added support for language formality
* Automatic User Language Detection: Fixed javascript links incorrectly switching to default language

= 1.0.8 =
* SEO Pack: Show unique translated slug after saving translation in String Translation Editor
* SEO Pack: Sanitized translated slugs for CPT slugs and Taxonomy slugs
* Automatic User Language Detection: Fixed loading loop inside Beaver Builder Editor
* Automatic User Language Detection: Updated Geo IP location database to 20111109 version

= 1.0.7 =
* SEO Pack: Fixed php notices about term_id

= 1.0.6 =
* SEO Pack: Added support for translating og image, og image alt and other image related meta tags used in SEO
* SEO Pack: Fixed cases when language switcher did not work when tax base slug and term slug were translated with special chars in them
* SEO Pack: Fixed cases of 404 when both tax base and term slug translations had special characters in them

= 1.0.5 =
* Added Install & Activate button in admin notice if TranslatePress - Multilingual is not active

= 1.0.4 =
* Automatic User Language Detection: Fixed error on trp-ald-ajax retrieving first time visitor language

= 1.0.3 =
* Automatic User Language Detection: Fixed error on trp-ald-ajax retrieving first time visitor language

= 1.0.2 =
* SEO Pack: Fixed an issue with /shop/%product_cat%/ permalink for WooCommerce
* Automatic User Language Detection: Fixed redirecting after logout
* Automatic User Language Detection: Fixed endless redirect on some custom languages
* Automatic User Language Detection: Fixed redirecting when hreflang tags are missing

= 1.0.1 =
* DeepL: Added British English variant for Australia, New Zealand and South Africa
* Translator Accounts: Fixed Translator role not being added for new installations
* SEO Pack: Fixed refreshing Yoast sitemap on add-on activation/deactivation

= 1.0.0 =
* First repackaged version

