<?php
namespace YayMail\TemplatePatterns;

use YayMail\Abstracts\BasePattern;
use YayMail\Utils\SingletonTrait;

/**
 * Class PatternService
 */
class PatternService {

    use SingletonTrait;

    protected $patterns = [];

    /**
     * @var bool
     */
    protected $loaded = false;

    /**
     * Discover and register patterns on first actual use, instead of on
     * every request regardless of whether anything needs them.
     *
     * @return void
     */
    protected function ensure_loaded() {
        if ( $this->loaded ) {
            return;
        }

        $this->loaded = true;

        PatternsLoader::get_instance();
    }

    /**
     * @param BasePattern $section_template_instance SectionTemplate object
     */
    public function register( BasePattern $pattern_instance ) {
        if ( ! $pattern_instance instanceof BasePattern ) {
            return;
        }

        $registered_patterns = array_map(
            function( $item ) {
                return $item->get_type();
            },
            $this->patterns
        );

        if ( in_array( $pattern_instance->get_type(), $registered_patterns, true ) ) {
            return;
        }

        $this->patterns[] = $pattern_instance;

        $registered_sections = SectionTemplateService::get_instance()->get_list();

        foreach ( $registered_sections as $section ) {
            if ( $section->get_type() === $pattern_instance->get_section() ) {

                $section->add_pattern( $pattern_instance );
            }
        }

    }

    public function get_list() {
        $this->ensure_loaded();

        return $this->patterns;
    }

    public function get_list_data() {
        $this->ensure_loaded();

        return array_map(
            function( BasePattern $item ) {
                return $item->get_raw_data();
            },
            $this->patterns
        );
    }
}
