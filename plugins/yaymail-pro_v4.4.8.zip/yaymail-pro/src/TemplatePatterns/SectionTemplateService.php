<?php
namespace YayMail\TemplatePatterns;

use YayMail\Abstracts\BasePattern;
use YayMail\Abstracts\BaseSectionTemplate;
use YayMail\Utils\SingletonTrait;

/**
 * Class SectionTemplateService
 */
class SectionTemplateService {

    use SingletonTrait;

    protected $sections = [];

    /**
     * @var bool
     */
    protected $loaded = false;

    /**
     * Discover and register section templates on first actual use, instead
     * of on every request regardless of whether anything needs them.
     *
     * @return void
     */
    protected function ensure_loaded() {
        if ( $this->loaded ) {
            return;
        }

        $this->loaded = true;

        SectionTemplatesLoader::get_instance();
    }

    /**
     * @param BaseSectionTemplate $section_template_instance SectionTemplate object
     */
    public function register( BaseSectionTemplate $section_template_instance ) {
        if ( ! $section_template_instance instanceof BaseSectionTemplate ) {
            return;
        }

        $registered_sections = array_map(
            function( $item ) {
                return $item->get_type();
            },
            $this->sections
        );

        if ( in_array( $section_template_instance->get_type(), $registered_sections, true ) ) {
            return;
        }

        $this->sections[] = $section_template_instance;
    }

    public function get_list() {
        $this->ensure_loaded();

        return $this->sections;
    }

    public function get_list_data() {
        $this->ensure_loaded();

        return array_map(
            function( BaseSectionTemplate $item ) {
                return $item->get_raw_data();
            },
            $this->sections
        );
    }
}
