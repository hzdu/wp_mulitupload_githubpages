<?php
namespace YayMail\Elements;

use YayMail\Abstracts\BaseElement;
use YayMail\Utils\SingletonTrait;

/**
 * Featured Posts Element
 */
class FeaturedPosts extends BaseElement {

    use SingletonTrait;

    protected static $type = 'featured_posts';

    public $available_email_ids = [ YAYMAIL_ALL_EMAILS ];

    public static function get_data( $attributes = [] ) {
        self::$icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
  <path d="M4,2.5h12c.83,0,1.5.67,1.5,1.5v12c0,.83-.67,1.5-1.5,1.5H4c-.83,0-1.5-.67-1.5-1.5V4c0-.83.67-1.5,1.5-1.5ZM5,5v10h10V5H5ZM7,7h6v1.5H7V7Zm0,3h6v1.5H7v-1.5Zm0,3h4v1.5H7v-1.5Z"/>
</svg>';

        $button_conditions = [
            [
                'comparison' => 'contain',
                'value'      => [ 'button' ],
                'attribute'  => 'showing_items',
            ],
        ];

        return [
            'id'        => uniqid(),
            'type'      => self::$type,
            'name'      => __( 'Featured Posts', 'yaymail' ),
            'icon'      => self::$icon,
            'group'     => 'block',
            'tags'      => [ 'wordpress' ],
            'available' => true,
            'position'  => 221,
            'status_info'     => [
                'text' => __( 'New', 'yaymail' ),
            ],
            'data'      => [
                'padding'                  => [
                    'value_path'    => 'padding',
                    'component'     => 'Spacing',
                    'title'         => __( 'Padding', 'yaymail' ),
                    'default_value' => isset( $attributes['padding'] ) ? $attributes['padding'] : [
                        'top'    => '15',
                        'right'  => '50',
                        'bottom' => '15',
                        'left'   => '50',
                    ],
                    'type'          => 'style',
                ],
                'background_color'         => [
                    'value_path'    => 'background_color',
                    'component'     => 'Color',
                    'title'         => __( 'Background color', 'yaymail' ),
                    'default_value' => isset( $attributes['background_color'] ) ? $attributes['background_color'] : '#fff',
                    'type'          => 'style',
                ],
                'text_color'               => [
                    'value_path'    => 'text_color',
                    'component'     => 'Color',
                    'title'         => __( 'Text color', 'yaymail' ),
                    'default_value' => isset( $attributes['text_color'] ) ? $attributes['text_color'] : YAYMAIL_COLOR_TEXT_DEFAULT,
                    'type'          => 'style',
                ],
                'font_family'              => [
                    'value_path'    => 'font_family',
                    'component'     => 'FontFamilySelector',
                    'title'         => __( 'Font family', 'yaymail' ),
                    'default_value' => isset( $attributes['font_family'] ) ? $attributes['font_family'] : YAYMAIL_DEFAULT_FAMILY,
                    'type'          => 'style',
                ],
                'content_breaker'          => [
                    'component' => 'LineBreaker',
                ],
                'content_group_definition' => [
                    'component'   => 'GroupDefinition',
                    'title'       => __( 'Content', 'yaymail' ),
                    'description' => __( 'Handle block items settings', 'yaymail' ),
                ],
                'showing_items'            => [
                    'value_path'    => 'showing_items',
                    'component'     => 'CheckboxGroup',
                    'title'         => __( 'Showing items', 'yaymail' ),
                    'default_value' => isset( $attributes['showing_items'] ) ? $attributes['showing_items'] : [ 'top_content', 'post_image', 'post_title', 'post_excerpt', 'post_date', 'post_author', 'button' ],
                    'type'          => 'content',
                    'options'       => [
                        [
                            'label' => __( 'Top content', 'yaymail' ),
                            'value' => 'top_content',
                        ],
                        [
                            'label' => __( 'Post image', 'yaymail' ),
                            'value' => 'post_image',
                        ],
                        [
                            'label' => __( 'Post title', 'yaymail' ),
                            'value' => 'post_title',
                        ],
                        [
                            'label' => __( 'Post excerpt', 'yaymail' ),
                            'value' => 'post_excerpt',
                        ],
                        [
                            'label' => __( 'Post date', 'yaymail' ),
                            'value' => 'post_date',
                        ],
                        [
                            'label' => __( 'Post author', 'yaymail' ),
                            'value' => 'post_author',
                        ],
                        [
                            'label' => __( 'Button', 'yaymail' ),
                            'value' => 'button',
                        ],
                    ],
                ],
                'top_content'              => [
                    'value_path'    => 'top_content',
                    'component'     => 'RichTextEditor',
                    'title'         => __( 'Top content', 'yaymail' ),
                    'default_value' => isset( $attributes['top_content'] ) ? $attributes['top_content'] : '<p style="text-align: center;"><span style="font-size: 18px;"><strong>FEATURED POSTS</strong></span></p>
                    <p style="font-size: 14px; text-align: center;">&nbsp;</p>
                    <p style="text-align: center;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>',
                    'type'          => 'content',
                    'conditions'    => [
                        [
                            'comparison' => 'contain',
                            'value'      => [ 'top_content' ],
                            'attribute'  => 'showing_items',
                        ],
                    ],
                ],
                'button_breaker'           => [
                    'component'  => 'LineBreaker',
                    'conditions' => $button_conditions,
                ],
                'button_group_definition'  => [
                    'component'   => 'GroupDefinition',
                    'title'       => __( 'Button', 'yaymail' ),
                    'description' => __( 'Handle button settings', 'yaymail' ),
                    'conditions'  => $button_conditions,
                ],
                'button_label'             => [
                    'value_path'    => 'button_label',
                    'component'     => 'TextInput',
                    'title'         => __( 'Button text', 'yaymail' ),
                    'default_value' => isset( $attributes['button_label'] ) ? $attributes['button_label'] : __( 'READ MORE', 'yaymail' ),
                    'type'          => 'content',
                    'conditions'    => $button_conditions,
                ],
                'button_background_color'  => [
                    'value_path'    => 'button_background_color',
                    'component'     => 'Color',
                    'title'         => __( 'Button background color', 'yaymail' ),
                    'default_value' => isset( $attributes['button_background_color'] ) ? $attributes['button_background_color'] : '#ec4770',
                    'type'          => 'style',
                    'conditions'    => $button_conditions,
                ],
                'button_text_color'        => [
                    'value_path'    => 'button_text_color',
                    'component'     => 'Color',
                    'title'         => __( 'Button text color', 'yaymail' ),
                    'default_value' => isset( $attributes['button_text_color'] ) ? $attributes['button_text_color'] : '#ffffff',
                    'type'          => 'style',
                    'conditions'    => $button_conditions,
                ],
                'posts_breaker'            => [
                    'component' => 'LineBreaker',
                ],
                'posts_group_definition'   => [
                    'component'   => 'GroupDefinition',
                    'title'       => __( 'Posts', 'yaymail' ),
                    'description' => __( 'Handle posts settings', 'yaymail' ),
                ],
                'posts_per_row'            => [
                    'value_path'    => 'posts_per_row',
                    'component'     => 'NumberInput',
                    'title'         => __( 'Posts per row', 'yaymail' ),
                    'default_value' => isset( $attributes['posts_per_row'] ) ? $attributes['posts_per_row'] : '2',
                    'min'           => 1,
                    'max'           => 3,
                    'type'          => 'content',
                ],
                'post_type'                => [
                    'value_path'    => 'post_type',
                    'component'     => 'Selector',
                    'title'         => __( 'Post type', 'yaymail' ),
                    'default_value' => isset( $attributes['post_type'] ) ? $attributes['post_type'] : 'newest',
                    'type'          => 'content',
                    'options'       => [
                        [
                            'label' => __( 'Newest', 'yaymail' ),
                            'value' => 'newest',
                        ],
                        [
                            'label' => __( 'Category selections', 'yaymail' ),
                            'value' => 'category_selections',
                        ],
                        [
                            'label' => __( 'Tag selections', 'yaymail' ),
                            'value' => 'tag_selections',
                        ],
                        [
                            'label' => __( 'Post selections', 'yaymail' ),
                            'value' => 'post_selections',
                        ],
                    ],
                ],
                'categories'               => [
                    'value_path'    => 'categories',
                    'component'     => 'EntitiesSelector',
                    'title'         => __( 'Post categories', 'yaymail' ),
                    'default_value' => isset( $attributes['categories'] ) ? $attributes['categories'] : [],
                    'type'          => 'content',
                    'entity_type'   => 'post_categories',
                    'conditions'    => [
                        [
                            'value'     => 'category_selections',
                            'attribute' => 'post_type',
                        ],
                    ],
                ],
                'tags'                     => [
                    'value_path'    => 'tags',
                    'component'     => 'EntitiesSelector',
                    'title'         => __( 'Post tags', 'yaymail' ),
                    'default_value' => isset( $attributes['tags'] ) ? $attributes['tags'] : [],
                    'type'          => 'content',
                    'entity_type'   => 'post_tags',
                    'conditions'    => [
                        [
                            'value'     => 'tag_selections',
                            'attribute' => 'post_type',
                        ],
                    ],
                ],
                'posts'                    => [
                    'value_path'    => 'posts',
                    'component'     => 'EntitiesSelector',
                    'title'         => __( 'Posts', 'yaymail' ),
                    'default_value' => isset( $attributes['posts'] ) ? $attributes['posts'] : [],
                    'type'          => 'content',
                    'entity_type'   => 'posts',
                    'conditions'    => [
                        [
                            'value'     => 'post_selections',
                            'attribute' => 'post_type',
                        ],
                    ],
                ],
                'sorted_by'                => [
                    'value_path'    => 'sorted_by',
                    'component'     => 'Selector',
                    'title'         => __( 'Sorted by', 'yaymail' ),
                    'default_value' => isset( $attributes['sorted_by'] ) ? $attributes['sorted_by'] : 'none',
                    'options'       => [
                        [
                            'label' => __( 'None', 'yaymail' ),
                            'value' => 'none',
                        ],
                        [
                            'label' => __( 'Name A-Z', 'yaymail' ),
                            'value' => 'name_a_z',
                        ],
                        [
                            'label' => __( 'Name Z-A', 'yaymail' ),
                            'value' => 'name_z_a',
                        ],
                        [
                            'label' => __( 'Date ascending', 'yaymail' ),
                            'value' => 'date_ascending',
                        ],
                        [
                            'label' => __( 'Date descending', 'yaymail' ),
                            'value' => 'date_descending',
                        ],
                        [
                            'label' => __( 'Random', 'yaymail' ),
                            'value' => 'random',
                        ],
                    ],
                    'type'          => 'content',
                ],
                'number_of_posts'          => [
                    'value_path'    => 'number_of_posts',
                    'component'     => 'NumberInput',
                    'title'         => __( 'Number of featured posts', 'yaymail' ),
                    'default_value' => isset( $attributes['number_of_posts'] ) ? $attributes['number_of_posts'] : '4',
                    'type'          => 'content',
                    'min'           => 1,
                    'max'           => 20,
                    'is_debounce'   => true,
                    'conditions'    => [
                        [
                            'comparison' => '!=',
                            'value'      => 'post_selections',
                            'attribute'  => 'post_type',
                        ],
                    ],
                ],
            ],
        ];
    }
}
