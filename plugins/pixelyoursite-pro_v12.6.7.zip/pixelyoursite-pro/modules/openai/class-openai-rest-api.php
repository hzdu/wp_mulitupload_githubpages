<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * OpenAI Ads REST endpoint for browser-originated server events.
 *
 * The AJAX action stays available as a fallback; this route is preferred because
 * it is not affected by admin-ajax throttling on shared hosts.
 *
 * The base class writes the id into `payload['eventID']`, which is exactly what
 * OpenAIServer::mapEventToServerEvent() reads for the event `id` — so no
 * override of data_to_single_event() is needed here, unlike TikTok.
 */
class OpenAI_REST_API extends AbstractRestAPI {

	/**
	 * @return string
	 */
	protected function getRestNamespace() {
		return 'pys-openai/v1';
	}

	/**
	 * @return OpenAIServer
	 */
	protected function getServerInstance() {
		return OpenAIServer();
	}

	/**
	 * @return OpenAI
	 */
	protected function getPixelInstance() {
		return OpenAI();
	}

	/**
	 * @return bool
	 */
	protected function isServerApiEnabled() {
		return OpenAI()->isServerApiEnabled();
	}

	/**
	 * @return string
	 */
	protected function getScriptVariableName() {
		return 'pysOpenAIRest';
	}

	/**
	 * Accept the page URL the event happened on.
	 *
	 * Declared here rather than in AbstractRestAPI so TikTok and Pinterest are
	 * unaffected.
	 *
	 * @return array
	 */
	protected function get_event_args() {

		$args = parent::get_event_args();

		$args[ 'event_source_url' ] = array(
			'required'          => false,
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		);

		return $args;
	}

	/**
	 * Attach the originating page URL before dispatch.
	 *
	 * `source_url` is required for web events, and the base handler would leave
	 * the sender to resolve it from the current request — which on this route is
	 * `/wp-json/pys-openai/v1/event`, not the page. The browser sends the real
	 * URL; a request that omits it still carries it in the Referer header, since
	 * a fetch or beacon fired from the visitor's page reports that page.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function handle_event( $request ) {

		$this->getPixelInstance()->getLog()->debug(
			'handleEvent send to OpenAI server from REST API'
			. ' event: ' . $request->get_param( 'event' )
			. ' eventID: ' . $request->get_param( 'eventID' )
		);

		$event      = $request->get_param( 'event' );
		$data       = $request->get_param( 'data' ) ?: array();
		$ids        = $request->get_param( 'ids' );
		$event_id   = $request->get_param( 'eventID' );
		$woo_order  = $request->get_param( 'woo_order' );
		$edd_order  = $request->get_param( 'edd_order' );
		$event_slug = $request->get_param( 'event_slug' );
		$source_url = $request->get_param( 'event_source_url' );

		if ( empty( $source_url ) ) {
			$referer = $request->get_header( 'referer' );

			if ( !empty( $referer ) ) {
				$source_url = esc_url_raw( $referer );
			}
		}

		if ( empty( $event ) || empty( $ids ) ) {
			return new \WP_Error(
				'missing_parameters',
				'Missing mandatory parameters: event and ids',
				array( 'status' => 400 )
			);
		}

		$single_event = $this->data_to_single_event(
			$event, $data, $event_id, $ids, $woo_order, $edd_order, $event_slug
		);

		if ( !empty( $source_url ) && wp_http_validate_url( $source_url ) ) {
			$single_event->addPayload( array( 'event_source_url' => $source_url ) );
		}

		$authenticated = $this->authenticateVisitor();

		try {
			if ( $this->server_instance->isQueueEnabled() && PYS()->getOption( 'queue_use_for_ajax' ) ) {
				$this->server_instance->sendEventsToQueue( array( $single_event ) );
			} else {
				$this->server_instance->sendEventsNow( array( $single_event ) );
			}
		} finally {
			if ( $authenticated ) {
				// Back to the state this request had before us: anonymous.
				wp_set_current_user( 0 );
			}
		}

		return new \WP_REST_Response( array( 'success' => true ), 200 );
	}

	/**
	 * Recognise the visitor this event belongs to.
	 *
	 * @return bool Whether a user was set and has to be unset afterwards.
	 */
	private function authenticateVisitor(): bool {

		if ( get_current_user_id() > 0 ) {
			return false; // already recognised; not ours to change or restore
		}

		if ( !defined( 'LOGGED_IN_COOKIE' ) || empty( $_COOKIE[ LOGGED_IN_COOKIE ] ) ) {
			return false;
		}

		$user_id = wp_validate_auth_cookie( $_COOKIE[ LOGGED_IN_COOKIE ], 'logged_in' );

		if ( !$user_id ) {
			return false;
		}

		wp_set_current_user( (int) $user_id );

		return true;
	}
}

/**
 * Accessor function for the OpenAI REST API
 *
 * @return OpenAI_REST_API
 */
function OpenAI_REST_API() {
	static $instance = null;

	if ( $instance === null ) {
		$instance = new OpenAI_REST_API();
	}

	return $instance;
}
