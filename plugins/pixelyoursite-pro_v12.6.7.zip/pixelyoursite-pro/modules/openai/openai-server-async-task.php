<?php
namespace PixelYourSite;

defined( 'ABSPATH' ) or die( 'Direct access not allowed' );

/**
 * OpenAI Ads async task handler.
 *
 * Only used when the events queue is disabled — otherwise events go through
 * EventsQueue and this class is never instantiated.
 */
class OpenAIAsyncTask extends AbstractAsyncTask {

	/**
	 * Action name for this async task
	 *
	 * @var string
	 */
	protected $action = 'pys_send_openai_server_event';

	/**
	 * Get the server instance for OpenAI
	 *
	 * @return OpenAIServer
	 */
	protected function getServerInstance(): OpenAIServer {
		return OpenAIServer();
	}
}
