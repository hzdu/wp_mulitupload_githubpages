<?php

namespace PixelYourSite;

use PixelYourSite\OpenAI\Helpers;
use PYS_PRO_GLOBAL\GuzzleHttp\Client;

require_once PYS_PATH . '/modules/openai/openai-server-async-task.php';

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * OpenAI Ads Conversions API sender.
 *
 * Endpoint contract (verified against the live endpoint 2026-08-18):
 *   POST https://bzr.openai.com/v1/events?pid=<PIXEL-ID>
 *   Authorization: Bearer <conversions api key>
 *   { "integration_source": "...", "validate_only": bool, "events": [ { ... } ] }
 */
class OpenAIServer extends AbstractServerEvents {

	/** Conversions API endpoint. The pixel id goes in `?pid=`, not the body. */
	const API_URL = 'https://bzr.openai.com/v1/events';

	/** Stable identifier for the sending integration, reported to OpenAI. */
	const INTEGRATION_SOURCE = 'pixelyoursite-pro';

	/** How far in the past `timestamp_ms` may be — 7 days, per the docs. */
	const MAX_EVENT_AGE = 604800;

	/** How far in the future `timestamp_ms` may be — 10 minutes, per the docs. */
	const MAX_EVENT_FUTURE = 600;

	/**
	 * Event names the Conversions API accepts. `custom` is listed but needs a
	 * `custom_event_name` alongside it.
	 */
	const SUPPORTED_EVENTS = array(
		'appointment_scheduled',
		'checkout_started',
		'contents_viewed',
		'items_added',
		'lead_created',
		'order_created',
		'page_viewed',
		'registration_completed',
		'subscription_created',
		'trial_started',
		'custom',
	);

	private static $_instance;
	private        $isEnabled;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct() {
		parent::__construct();
		add_action( 'init', array( $this, 'init' ) );
	}

	/**
	 * Register the fallback paths the browser can use when the inline server
	 * send is unavailable — blocked by consent, delayed, or a dynamic event.
	 *
	 * @return void
	 */
	public function init() {

		$this->isEnabled = OpenAI()->isServerApiEnabled();

		if ( !$this->isEnabled ) {
			return;
		}

		$this->registerAjaxHandlers();

		if ( !PYS()->getOption( 'queue_enabled', true ) ) {
			new OpenAIAsyncTask();
		}
	}

	/**
	 * @return OpenAI
	 */
	protected function getPixelInstance() {
		return OpenAI();
	}

	/**
	 * @return string
	 */
	protected function getQueuePlatformName() {
		return 'openai';
	}

	/**
	 * @return string
	 */
	protected function getServerEventAction() {
		return 'pys_send_openai_server_event';
	}

	/**
	 * @return string
	 */
	protected function getAjaxActionName() {
		return 'pys_openai_api_event';
	}

	/**
	 * Only the documented event names may go out. An unknown name would be
	 * rejected by the endpoint anyway; dropping it here keeps the log readable
	 * and costs nothing.
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	protected function isEventSupported( $event ): bool {

		$name = $event->getPayloadValue( 'name' );

		if ( !is_string( $name ) || !in_array( $name, self::SUPPORTED_EVENTS, true ) ) {
			return false;
		}

		if ( $name === 'custom' ) {
			$params = is_array( $event->params ) ? $event->params : array();

			return !empty( $params[ 'custom_event_name' ] );
		}

		return true;
	}

	/**
	 * Build the Conversions API event object.
	 *
	 * @param SingleEvent $event
	 * @return \stdClass
	 */
	protected function mapEventToServerEvent( $event ) {

		$eventData = $event->getData();

		$eventData = EventsManager::filterEventParams( $eventData, $event->getCategory(), array(
			'event_id' => $event->getId(),
			'pixel'    => OpenAI()->getSlug(),
		) );

		$wooOrder = $event->payload[ 'woo_order' ] ?? null;
		$eddOrder = $event->payload[ 'edd_order' ] ?? null;

		$serverEvent = new \stdClass;

		$serverEvent->id = (string) ( $event->payload[ 'eventID' ] ?? $event->payload[ 'event_id' ] ?? '' );

		$serverEvent->type          = (string) $eventData[ 'name' ];
		$serverEvent->timestamp_ms  = $this->currentTimestampMs();
		$serverEvent->action_source = 'web';
		$serverEvent->source_url    = $this->resolveSourceUrl( $event );

		if ( OpenAI()->getConsentMode() ) {
			$serverEvent->opt_out = true;
		}

		$params = is_array( $eventData[ 'params' ] ) ? $eventData[ 'params' ] : array();

		if ( $serverEvent->type === 'custom' && !empty( $params[ 'custom_event_name' ] ) ) {
			$serverEvent->custom_event_name = (string) $params[ 'custom_event_name' ];
		}

		$this->persistClickId();

		$click_id = Helpers\pys_openai_get_click_id();

		if ( $click_id !== '' ) {
			$serverEvent->oppref = $click_id;
		}

		$userData = $this->getUserData( $wooOrder, $eddOrder );

		if ( count( get_object_vars( $userData ) ) > 0 ) {
			$serverEvent->user = $userData;
		}

		$serverEvent->data = $this->normaliseData( $params[ 'data' ] ?? array( 'type' => 'contents' ) );

		return $serverEvent;
	}

	/**
	 * Coerce the data object to the types the endpoint demands.
	 *
	 * @param array|object $data
	 * @return \stdClass
	 */
	private function normaliseData( $data ) {

		$data = $this->flattenEditorParams( (array) $data );

		if ( isset( $data[ 'type' ] ) ) {
			$data[ 'type' ] = (string) $data[ 'type' ];
		}

		if ( isset( $data[ 'amount' ] ) ) {
			$data[ 'amount' ] = (int) $data[ 'amount' ];
		}

		if ( isset( $data[ 'currency' ] ) ) {
			$data[ 'currency' ] = (string) $data[ 'currency' ];
		}

		if ( isset( $data[ 'plan_id' ] ) ) {
			$data[ 'plan_id' ] = (string) $data[ 'plan_id' ];
		}

		if ( !empty( $data[ 'contents' ] ) && is_array( $data[ 'contents' ] ) ) {

			$contents = array();

			foreach ( $data[ 'contents' ] as $item ) {

				$item = (array) $item;

				foreach ( array( 'id', 'name', 'content_type', 'currency' ) as $string_field ) {
					if ( isset( $item[ $string_field ] ) ) {
						$item[ $string_field ] = (string) $item[ $string_field ];
					}
				}

				foreach ( array( 'quantity', 'amount' ) as $int_field ) {
					if ( isset( $item[ $int_field ] ) ) {
						$item[ $int_field ] = (int) $item[ $int_field ];
					}
				}

				$contents[] = $item;
			}

			$data[ 'contents' ] = $contents;
		}

		return (object) $data;
	}

	/**
	 * Turn the editor's parameter objects back into plain values.
	 *
	 * @param array $data
	 * @return array
	 */
	private function flattenEditorParams( array $data ) {

		foreach ( $data as $key => $value ) {

			if ( $key === 'contents' && is_array( $value ) ) {

				$items = array();

				foreach ( $value as $item ) {
					$item = $this->flattenEditorParams( (array) $item );

					if ( !empty( $item ) ) {
						$items[] = $item;
					}
				}

				// An empty list says nothing: send no key rather than `[]`.
				if ( empty( $items ) ) {
					unset( $data[ 'contents' ] );
				} else {
					$data[ 'contents' ] = $items;
				}

				continue;
			}

			if ( !is_array( $value ) ) {
				continue;
			}

			$is_editor_param = array_key_exists( 'value', $value )
				|| array_key_exists( 'selector', $value )
				|| array_key_exists( 'dynamic', $value );

			if ( !$is_editor_param ) {
				continue;
			}

			$dynamic = !empty( $value[ 'dynamic' ] ) && !empty( $value[ 'selector' ] );
			$plain   = $dynamic || !isset( $value[ 'value' ] ) ? '' : $value[ 'value' ];

			if ( $plain === '' ) {
				unset( $data[ $key ] );
			} else {
				$data[ $key ] = $plain;
			}
		}

		// currency travels with amount, and neither is worth sending alone.
		if ( isset( $data[ 'amount' ] ) && empty( $data[ 'currency' ] ) ) {
			unset( $data[ 'amount' ] );
		}

		return $data;
	}

	/**
	 * What each matching field is called on the wire.
	 */
	const MATCHING_FIELD_NAMES = array(
		'email_sha256'        => 'emails_sha256',
		'phone_number_sha256' => 'phone_numbers_sha256',
		'external_id_sha256'  => 'external_ids_sha256',
		'first_name_sha256'   => 'first_names_sha256',
		'last_name_sha256'    => 'last_names_sha256',
		'country'             => 'countries',
		'city'                => 'cities',
		'region'              => 'regions',
		'postal_code'         => 'postal_codes',
	);

	/**
	 * The event's `user` object.
	 * Every field OpenAI accepts and nothing else.
	 *
	 * @param int|null $wooOrder
	 * @param int|null $eddOrder
	 * @return \stdClass
	 */
	protected function getUserData( $wooOrder = null, $eddOrder = null ) {

		$userData = new \stdClass;

		$ip = self::getIpAddress();

		if ( !empty( $ip ) && self::isValidIpAddress( $ip ) ) {
			$userData->ip_address = $ip;
		}

		$user_agent = self::getHttpUserAgent();

		if ( !empty( $user_agent ) ) {
			$userData->user_agent = $user_agent;
		}

		if ( !empty( $_COOKIE[ '__obref' ] ) ) {
			$obref = sanitize_text_field( wp_unslash( $_COOKIE[ '__obref' ] ) );

			if ( $obref !== '' ) {
				$userData->obref = $obref;
			}
		}

		if ( OpenAI()->getOption( 'advanced_matching_enabled' ) ) {

			foreach ( OpenAI()->getServerMatchingValues( $wooOrder, $eddOrder ) as $field => $values ) {

				$name = self::MATCHING_FIELD_NAMES[ $field ] ?? null;

				if ( null === $name || empty( $values ) ) {
					continue;
				}

				$userData->$name = array_values( $values );
			}

		} elseif ( EventsManager::isTrackExternalId() ) {

			$external_id = OpenAI()->getExternalId( $wooOrder, $eddOrder );

			if ( $external_id !== '' ) {
				$userData->external_ids_sha256 = array( hash( 'sha256', $external_id ) );
			}
		}

		return apply_filters( 'pys_openai_server_user_data', $userData, $wooOrder, $eddOrder );
	}

	/**
	 * Persist OpenAI's click identifier for later requests.
	 *
	 * @return void
	 */
	private function persistClickId(): void {

		if ( !empty( $_COOKIE[ '__oppref' ] ) || headers_sent() ) {
			return;
		}

		if ( !Consent()->checkConsent( 'openai' ) ) {
			return;
		}

		$from_url = Helpers\pys_openai_get_click_id();

		if ( $from_url === '' ) {
			return;
		}

		setcookie( '__oppref', $from_url, 2147483647, '/', pys_cookie_domain() );
		$_COOKIE[ '__oppref' ] = $from_url;
	}

	/**
	 * Send one event to every recipient pixel.
	 *
	 * @param array      $pixel_Ids Recipient pixel ids, already resolved upstream.
	 * @param \stdClass  $event     One mapped Conversions API event.
	 * @return array{status:string,message:string} See AbstractServerEvents::sendResult().
	 */
	public function sendEvent( $pixel_Ids, $event ) {

		if ( !$event ) {
			return self::sendResult( self::SEND_SKIPPED, 'No event to send' );
		}

		if ( !OpenAI()->enabled() || !OpenAI()->isServerApiEnabled() ) {
			return self::sendResult( self::SEND_SKIPPED, 'OpenAI pixel or its Conversions API is disabled' );
		}

		if ( !$this->isTimestampSendable( $event->timestamp_ms ?? null ) ) {
			OpenAI()->getLog()->debug( 'OpenAI server event skipped — timestamp outside the accepted window', array(
				'event'        => $event->type ?? '',
				'timestamp_ms' => $event->timestamp_ms ?? null,
			) );

			return self::sendResult( self::SEND_FAILED, 'Event timestamp is outside the window the endpoint accepts' );
		}

		if ( !$this->access_token ) {
			$this->access_token = OpenAI()->getApiTokens();
		}

		$validate_only = (bool) OpenAI()->getOption( 'server_validate_only' );

		$sent           = false;
		$retry_message  = '';
		$failed_message = '';

		foreach ( (array) $pixel_Ids as $pixel_Id ) {

			if ( empty( $pixel_Id ) || empty( $this->access_token[ $pixel_Id ] ) ) {
				continue;
			}

			$request = $this->buildRequest( $pixel_Id, $event, $validate_only );

			OpenAI()->getLog()->debug(
				'Send OpenAI server event ' . ( $event->type ?? '' ) . ' to pixel ' . $pixel_Id,
				$this->logSafeRequest( $request )
			);

			try {
				$client = new Client();

				$response = $client->request( 'POST', $request[ 'url' ], array(
					'headers'         => $request[ 'headers' ],
					'body'            => $request[ 'body' ],
					'timeout'         => pys_server_request_timeout(),
					'connect_timeout' => pys_server_connect_timeout(),
				) );

				$raw = (string) $response->getBody();

				OpenAI()->getLog()->debug( 'Response from OpenAI server', array(
					'pixel_id' => $pixel_Id,
					'status'   => $response->getStatusCode(),
					'body'     => $raw,
				) );

				$body     = json_decode( $raw, true );
				$accepted = is_array( $body ) && isset( $body[ 'accepted_events' ] )
					? (int) $body[ 'accepted_events' ]
					: 1;

				if ( $accepted < 1 ) {
					OpenAI()->getLog()->error(
						'OpenAI accepted no events: ' . $raw,
						$this->logSafeRequest( $request )
					);
					// The same payload would be refused again.
					$failed_message = sprintf( 'OpenAI pixel %s: accepted_events 0', $pixel_Id );
					continue;
				}

				$sent = true;

				ServerEventsManager::addFiredPixel( 'openai', $pixel_Id );

			} catch ( \Exception $e ) {

				$detail = '';

				if ( method_exists( $e, 'getResponse' ) && $e->getResponse() ) {
					$body = $e->getResponse()->getBody();

					if ( method_exists( $body, 'rewind' ) ) {
						$body->rewind();
					}

					$detail = (string) $body;
				}

				OpenAI()->getLog()->error(
					'Error send OpenAI server event ' . $e->getMessage()
					. ( $detail !== '' ? ': ' . $detail : '' ),
					$this->logSafeRequest( $request )
				);

				$status  = $this->classifyGuzzleException( $e );
				$message = sprintf( 'OpenAI pixel %s: %s', $pixel_Id, $e->getMessage() );

				if ( $status === self::SEND_FAILED ) {
					$failed_message = $message;
				} else {
					$retry_message = $message;
				}
			}
		}

		if ( $retry_message !== '' ) {
			return self::sendResult( self::SEND_RETRY, $retry_message );
		}

		if ( $failed_message !== '' ) {
			return self::sendResult( self::SEND_FAILED, $failed_message );
		}

		return $sent
			? self::sendResult( self::SEND_SENT )
			: self::sendResult( self::SEND_SKIPPED, 'No pixel ID with a configured Conversions API key' );
	}

	/**
	 * Resolve `source_url`, which the endpoint requires for every web event.
	 *
	 * @param SingleEvent $event
	 * @return string
	 */
	private function resolveSourceUrl( $event ): string {

		$from_browser = $event->getPayloadValue( 'event_source_url' );

		if ( is_string( $from_browser ) && $from_browser !== '' && wp_http_validate_url( $from_browser ) ) {
			return $this->sanitizeUri( $from_browser );
		}

		$uri = $this->getEventUri( $event );

		if ( is_string( $uri ) && $uri !== '' && wp_http_validate_url( $uri ) ) {
			return $uri;
		}

		return home_url( '/' );
	}

	/**
	 * Assemble the HTTP request for one recipient pixel.
	 *
	 * @param string    $pixel_Id
	 * @param \stdClass $event
	 * @param bool      $validate_only
	 * @return array{url:string,headers:array,body:string}
	 */
	public function buildRequest( $pixel_Id, $event, $validate_only = false ): array {

		$body = array(
			'integration_source' => self::INTEGRATION_SOURCE,
			'validate_only'      => (bool) $validate_only,
			'events'             => array( $event ),
		);

		return array(
			'url'     => self::API_URL . '?pid=' . rawurlencode( $pixel_Id ),
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . ( $this->access_token[ $pixel_Id ] ?? '' ),
			),
			'body'    => wp_json_encode( $body ),
		);
	}

	/**
	 * The request as it goes on the wire, in a form that is safe to write to a
	 * log the admin can download.
	 *
	 * @param array $request
	 * @return array
	 */
	private function logSafeRequest( array $request ): array {

		$body = json_decode( isset( $request[ 'body' ] ) ? $request[ 'body' ] : '', true );

		return array(
			'url'  => isset( $request[ 'url' ] ) ? $request[ 'url' ] : '',
			'body' => $body === null ? ( $request[ 'body' ] ?? '' ) : $body,
		);
	}

	/**
	 * Current time as an integer millisecond timestamp.
	 *
	 * @return int
	 */
	private function currentTimestampMs(): int {
		return (int) round( microtime( true ) * 1000 );
	}

	/**
	 * The endpoint accepts `timestamp_ms` no older than 7 days and no more than
	 * 10 minutes ahead. Advance Purchase Tracking can legitimately produce older
	 * events (a webhook arriving late), so this is checked rather than assumed.
	 *
	 * @param mixed $timestamp_ms
	 * @return bool
	 */
	public function isTimestampSendable( $timestamp_ms ): bool {

		if ( !is_numeric( $timestamp_ms ) ) {
			return false;
		}

		$age = ( $this->currentTimestampMs() - (int) $timestamp_ms ) / 1000;

		return $age <= self::MAX_EVENT_AGE && $age >= -self::MAX_EVENT_FUTURE;
	}
}

/**
 * @return OpenAIServer
 */
function OpenAIServer(): OpenAIServer {
	return OpenAIServer::instance();
}
