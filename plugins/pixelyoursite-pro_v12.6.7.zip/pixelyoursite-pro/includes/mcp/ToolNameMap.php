<?php
/**
 * Ability ID → MCP tool name resolver.
 * The WP Abilities API forbids underscores in ability names, but the public
 * tool names use them (`set_woo_event_config`, …). This is the
 * `mcp_adapter_tool_name` filter callback: it swaps in the underscore name
 * for abilities we own and leaves other plugins' abilities untouched. The
 * ping fixtures are intentionally absent and keep their hyphen names.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class ToolNameMap {

	/**
	 * Single source of truth: hyphen ability ID → underscore MCP tool name.
	 * Adding an ability without a row here means it ships under its
	 * hyphenated default name, which Claude will not recognise.
	 */
	public const MAP = array(
		'pixelyoursite-pro/get-usage-guidance'                => 'get_usage_guidance',
		'pixelyoursite-pro/get-tracking-audit'                => 'get_tracking_audit',
		'pixelyoursite-pro/get-credential-setup-instructions' => 'get_credential_setup_instructions',
		'pixelyoursite-pro/set-platform-credential'           => 'set_platform_credential',
		'pixelyoursite-pro/get-platform-pixels'               => 'get_platform_pixels',
		'pixelyoursite-pro/get-advanced-matching-config'      => 'get_advanced_matching_config',
		'pixelyoursite-pro/scan-page-for-form-fields'         => 'scan_page_for_form_fields',
		'pixelyoursite-pro/set-advanced-matching-fields'      => 'set_advanced_matching_fields',
		'pixelyoursite-pro/get-woo-events-config'             => 'get_woo_events_config',
		'pixelyoursite-pro/set-woo-event-config'              => 'set_woo_event_config',
		'pixelyoursite-pro/get-edd-events-config'             => 'get_edd_events_config',
		'pixelyoursite-pro/set-edd-event-config'              => 'set_edd_event_config',
		'pixelyoursite-pro/get-automatic-events-config'       => 'get_automatic_events_config',
		'pixelyoursite-pro/set-automatic-event-config'        => 'set_automatic_event_config',
		'pixelyoursite-pro/get-superpack-config'              => 'get_superpack_config',
		'pixelyoursite-pro/set-superpack-config'              => 'set_superpack_config',
		'pixelyoursite-pro/search-woo-products'               => 'search_woo_products',
		'pixelyoursite-pro/get-custom-events'                 => 'get_custom_events',
		'pixelyoursite-pro/get-custom-event'                  => 'get_custom_event',
		'pixelyoursite-pro/set-custom-event'                  => 'set_custom_event',
		'pixelyoursite-pro/manage-custom-event'               => 'manage_custom_event',
		'pixelyoursite-pro/get-catalog-feed-alignment'        => 'get_catalog_feed_alignment',
		'pixelyoursite-pro/get-edd-feed-alignment'            => 'get_edd_feed_alignment',
		'pixelyoursite-pro/get-attribution-summary'           => 'get_attribution_summary',
		'pixelyoursite-pro/get-attribution-drill'             => 'get_attribution_drill',
	);

	/**
	 * Direct lookup for PHP callers that need the public name without going
	 * through the filter. Returns null if the ID isn't mapped.
	 *
	 * @param string $abilityId Hyphen ability ID.
	 * @return string|null Underscore MCP tool name, or null if unmapped.
	 */
	public static function resolve( string $abilityId ): ?string {
		return self::MAP[ $abilityId ] ?? null;
	}

	/**
	 * Callback for the `mcp_adapter_tool_name` filter. Returns the mapped
	 * underscore name for our abilities, or `$defaultName` untouched for
	 * everyone else (other plugins may hook this filter too).
	 *
	 * @param string $defaultName Sanitised default name.
	 * @param mixed  $ability     `\WP_Ability` in practice. Typed loose so a
	 *                            future signature change doesn't fatal.
	 * @return string The resolved MCP tool name.
	 */
	public static function filter( $defaultName, $ability ) {
		if ( !is_object( $ability ) || !method_exists( $ability, 'get_name' ) ) {
			return $defaultName;
		}

		$mapped = self::MAP[ $ability->get_name() ] ?? null;

		return null === $mapped ? $defaultName : $mapped;
	}
}