<?php
/**
 * `set_woo_event_config` — partial write to WooCommerce event config.
 * Pro/read-only-gated, `mcp_note` required. Strict whitelist (funnel toggles
 * and value settings are not writable). Keys map via {@see ArgKeyMapper};
 * values are coerced per-arg. Three write scopes:
 *  - AGGREGATE (core + every active platform): lifecycle toggles +
 *    `track_subscriptions`.
 *  - GLOBAL_ONLY (core only): lifecycle thresholds + `poas_enabled`.
 *  - PER_PLATFORM (active platforms, no core): the content_id family.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\Platforms;
use PixelYourSite\MCP\EventToggleMap;

final class SetWooEventConfigAbility extends AbstractWriteAbility {

	public const ID = 'pixelyoursite-pro/set-woo-event-config';

	private const MCP_TOOL_NAME = 'set_woo_event_config';

	/** Lifecycle toggles + subscriptions — write core + per-active-platform. */
	private const AGGREGATE_ARGS = array(
		'new_customer',
		'returning_customer',
		'frequent_shopper',
		'vip_client',
		'big_whale',
		'track_subscriptions',
	);

	/**
	 * Thresholds + POAS + GLOBAL funnel-event master toggles + value settings —
	 * core only (#8b). Funnel toggles here are the GLOBAL masters; the
	 * per-platform layer is `platform_event_toggles`.
	 */
	private const GLOBAL_ONLY_ARGS = array(
		'frequent_shopper_transactions',
		'vip_client_transactions',
		'vip_client_average_value',
		'big_whale_ltv',
		'poas_enabled',
		// Global funnel-event master toggles.
		'purchase',
		'view_content',
		'view_category',
		'add_to_cart',
		'initiate_checkout',
		'view_cart',
		'view_item_list',
		'remove_from_cart',
		'checkout_steps',
		// Value settings (`value_mode` gates tax/shipping/fees).
		'value_mode',
		'tax_option',
		'shipping_option',
		'fees_option',
		'order_id_prefix',
		'add_to_cart_on_button_click',
		'add_to_cart_on_cart_page',
		'add_to_cart_on_checkout_page',
	);

	/** content_id family — per-active-platform only, no core key. */
	private const PER_PLATFORM_ARGS = array(
		'content_id_source',
		'content_id_prefix',
		'content_id_suffix',
		'content_id_custom_field_name',
		'content_id_logic',
		'variable_as_simple',
		'wpml_unified_id',
	);

	/**
	 * Args written to ONE module only (arg => slug). `content_id_logic` is
	 * Facebook-only; other modules register the key vestigially and are
	 * neither written nor reported as unsupported.
	 */
	private const SINGLE_PLATFORM_ARGS = array(
		'content_id_logic' => 'facebook',
	);

	/**
	 * The content-id family — written to every active module except GA / Ads
	 * (the Google-side content id lives in `gatags`, so those keys are
	 * vestigial there). `content_id_logic` is excluded (Facebook-only above).
	 */
	private const CONTENT_ID_FAMILY_ARGS = array(
		'content_id_source',
		'content_id_prefix',
		'content_id_suffix',
		'content_id_custom_field_name',
		'variable_as_simple',
		'wpml_unified_id',
	);

	/** Modules excluded from content-id-family writes (Google side = gatags). */
	private const CONTENT_ID_EXCLUDED_PLATFORMS = array(
		'google_analytics',
		'google_ads',
	);

	/** Boolean-coerced args. */
	private const BOOL_ARGS = array(
		'new_customer',
		'returning_customer',
		'frequent_shopper',
		'vip_client',
		'big_whale',
		'track_subscriptions',
		'poas_enabled',
		'variable_as_simple',
		'wpml_unified_id',
		// Global funnel-event master toggles (#8b).
		'purchase',
		'view_content',
		'view_category',
		'add_to_cart',
		'initiate_checkout',
		'view_cart',
		'view_item_list',
		'remove_from_cart',
		'checkout_steps',
		'add_to_cart_on_button_click',
		'add_to_cart_on_cart_page',
		'add_to_cart_on_checkout_page',
	);

	/** Integer-coerced args. */
	private const INT_ARGS = array(
		'frequent_shopper_transactions',
		'vip_client_transactions',
	);

	/** Float-coerced args. */
	private const FLOAT_ARGS = array(
		'vip_client_average_value',
		'big_whale_ltv',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Set WooCommerce Event Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Writes a partial update to WooCommerce event configuration. Pro-only. Strict whitelist — keys not listed are silently ignored. Writable: lifecycle toggles (`new_customer`, `returning_customer`, `frequent_shopper`, `vip_client`, `big_whale`); lifecycle thresholds (`frequent_shopper_transactions`, `vip_client_transactions`, `vip_client_average_value`, `big_whale_ltv`); `track_subscriptions` (requires the WooCommerce Subscriptions plugin — rejected with 409 if inactive; check `subscriptions_plugin_active`); `poas_enabled`; content ID family (`content_id_source` [`product_id`|`product_sku`|`custom_field`], `content_id_prefix`, `content_id_suffix`, `content_id_custom_field_name` [the WooCommerce meta key read when source is `custom_field` — REQUIRED when setting source to custom_field; changing it launches a background missing-ID scan, read the result from get_woo_events_config `content_id.custom_field_scan`], `content_id_logic` [Facebook only, requires Facebook for WooCommerce plugin], `variable_as_simple`, `wpml_unified_id` [requires WPML plugin — rejected with 409 if inactive; check `wpml_active`]). GLOBAL funnel-event master toggles ARE writable (`purchase`, `view_content`, `view_category`, `add_to_cart`, `initiate_checkout`, `view_cart`, `view_item_list`, `remove_from_cart`, `checkout_steps`) — these are the master on/off for an event across ALL platforms (an event fires for a platform only when this master AND that platform toggle are on). AddToCart FIRING POINTS ("When to fire the add to cart event") are writable too (core sub-options of the AddToCart event, not separate events): `add_to_cart_on_button_click`, `add_to_cart_on_cart_page`, `add_to_cart_on_checkout_page`. Value settings are also writable: `tax_option`/`shipping_option`/`fees_option` (`included`|`excluded`) and `order_id_prefix`. The PER-PLATFORM event-firing toggles ARE writable here via `platform_event_toggles` — whether a SPECIFIC platform fires a specific event (e.g. fire Purchase for Meta but not TikTok). This is the per-platform layer beneath the global toggle: an event reaches a platform only when BOTH the global toggle and the platform toggle are on. Pass a list of `{ platform, event, enabled }` (platform = a slug or `all`); read the current matrix from `get_woo_events_config.platform_events`. Non-registering platforms are reported in `unsupported_toggles`. Lifecycle toggles + `track_subscriptions` are applied uniformly to ALL active platforms plus the global setting; thresholds + `poas_enabled` are global-only; content_id is stored PER-PLATFORM. By default the content_id args write to every active platform, but pass `content_id_platform` to scope them to ONE platform (e.g. set a prefix for Meta only, or a different source for Google) — content_id is genuinely per-platform (read the current per-platform values from `get_woo_events_config.content_id_by_platform`); Google (GA4 + Ads) share the unified `gatags` holder. When changing `content_id_source`, first ASK the user whether the platform catalog feed uses a prefix/suffix and pass `content_id_prefix`/`content_id_suffix` in the same call — without aligned IDs dynamic ads will not match. **Two-step write (server-enforced):** call FIRST without `confirm` to get a `confirmation_required` preview with the current→new diff per field and the `aggregated_to` platform list; show that to the user, get their explicit go-ahead, then call again with `confirm: true` and the same args to write. A call without `confirm: true` never writes. On the confirmed write, returns `saved: true`, `changed`, and `aggregated_to` (every active platform the change reached — includes Bing/Reddit when their addons are active). Not every key reaches every platform: `content_id_logic` applies to **Facebook only** (it is the Facebook for WooCommerce content-id strategy — `aggregated_to` will be just `["facebook"]` for it); Google Ads has no content_id prefix/suffix. The response `unsupported` map lists, per arg, which participating platforms could NOT store a key (those are excluded from `aggregated_to`) — surface it to the user. Pass `mcp_note`.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'new_customer'                  => array(
					'type'        => 'boolean',
					'description' => 'Enable / disable the NewCustomer lifecycle event (labelled "FirstTimeBuyer" in the PYS admin UI). NOTE: this is the first-purchase lifecycle event, not the Google "new customer parameter" on purchase events — those are separate.'
				),
				'returning_customer'            => array(
					'type'        => 'boolean',
					'description' => 'Enable / disable the ReturningCustomer lifecycle event.'
				),
				'frequent_shopper'              => array(
					'type'        => 'boolean',
					'description' => 'Enable / disable the FrequentShopper lifecycle event.'
				),
				'vip_client'                    => array(
					'type'        => 'boolean',
					'description' => 'Enable / disable the VIPClient lifecycle event.'
				),
				'big_whale'                     => array(
					'type'        => 'boolean',
					'description' => 'Enable / disable the BigWhale lifecycle event.'
				),
				'frequent_shopper_transactions' => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => 'Completed transactions that trigger FrequentShopper.'
				),
				'vip_client_transactions'       => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => 'Completed transactions required for VIPClient.'
				),
				'vip_client_average_value'      => array(
					'type'        => 'number',
					'minimum'     => 0,
					'description' => 'Average order value threshold (store currency) for VIPClient.'
				),
				'big_whale_ltv'                 => array(
					'type'        => 'number',
					'minimum'     => 0,
					'description' => 'Total lifetime spend threshold (store currency) for BigWhale.'
				),
				'track_subscriptions'           => array(
					'type'        => 'boolean',
					'description' => 'Enable subscription lifecycle tracking. REQUIRES the WooCommerce Subscriptions plugin — if it is not active, the call is rejected with a 409 (check `subscriptions_plugin_active` from get_woo_events_config first). Do not pass this arg when that plugin is inactive.'
				),
				'poas_enabled'                  => array(
					'type'        => 'boolean',
					'description' => 'Profit on Ad Spend — send `value` as profit instead of revenue on purchase events.'
				),
				'purchase'                      => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce Purchase event (core `woo_purchase_enabled`). false disables Purchase for ALL platforms; an event fires for a platform only when this master AND that platform toggle (`platform_event_toggles`) are on. Use `platform_event_toggles` to control a single platform.'
				),
				'view_content'                  => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce ViewContent event (all platforms).'
				),
				'view_category'                 => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce ViewCategory event (all platforms).'
				),
				'add_to_cart'                   => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce AddToCart event (all platforms).'
				),
				'add_to_cart_on_button_click'   => array(
					'type'        => 'boolean',
					'description' => 'AddToCart FIRING POINT (core, "When to fire the add to cart event"): fire on the add-to-cart button click. Not a separate event — a sub-option of the AddToCart event.'
				),
				'add_to_cart_on_cart_page'      => array(
					'type'        => 'boolean',
					'description' => 'AddToCart FIRING POINT: fire on the cart page.'
				),
				'add_to_cart_on_checkout_page'  => array(
					'type'        => 'boolean',
					'description' => 'AddToCart FIRING POINT: fire on the checkout page.'
				),
				'initiate_checkout'             => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce InitiateCheckout event (all platforms).'
				),
				'view_cart'                     => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce ViewCart event (all platforms).'
				),
				'view_item_list'                => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce ViewItemList event (all platforms).'
				),
				'remove_from_cart'              => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce RemoveFromCart event (all platforms).'
				),
				'checkout_steps'                => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the WooCommerce checkout-steps events (all platforms).'
				),
				'value_mode'                    => array(
					'type'        => 'string',
					'enum'        => array( 'price', 'custom' ),
					'description' => 'Value-calculation mode. `price` = "Use WooCommerce price settings" (tax/shipping/fees options are IGNORED). `custom` = "Customize Tax and Shipping" (tax_option/shipping_option/fees_option take effect). Setting any of tax/shipping/fees auto-switches this to `custom` if it was `price` (a note is returned). Set `price` to revert to WooCommerce defaults.'
				),
				'tax_option'                    => array(
					'type'        => 'string',
					'enum'        => array( 'included', 'excluded' ),
					'description' => 'Value setting: whether tax is included in or excluded from the order value sent with events. Only applies when `value_mode` is `custom` (auto-enabled when you set this).'
				),
				'shipping_option'               => array(
					'type'        => 'string',
					'enum'        => array( 'included', 'excluded' ),
					'description' => 'Value setting: include/exclude shipping in the order value sent with events.'
				),
				'fees_option'                   => array(
					'type'        => 'string',
					'enum'        => array( 'included', 'excluded' ),
					'description' => 'Value setting: include/exclude fees in the order value sent with events.'
				),
				'order_id_prefix'               => array(
					'type'        => 'string',
					'description' => 'Value setting: string prepended to order IDs sent with events (e.g. a store prefix). Empty string clears it.'
				),
				'content_id_source'             => array(
					'type'        => 'string',
					'enum'        => array( 'product_id', 'product_sku', 'custom_field' ),
					'description' => 'Value sent as `content_ids` on commerce events. Must match the platform catalog feed. `product_id` = WordPress post ID (default, always present). `product_sku` = WooCommerce SKU (empty for products without one — risky). `custom_field` = read the ID from a WooCommerce post-meta key — REQUIRES `content_id_custom_field_name`; setting it launches a background scan of products missing that field (read the result later from get_woo_events_config `content_id.custom_field_scan`).'
				),
				'content_id_prefix'             => array(
					'type'        => 'string',
					'description' => 'String prepended to content IDs. Must match the catalog feed prefix.'
				),
				'content_id_suffix'             => array(
					'type'        => 'string',
					'description' => 'String appended to content IDs. Must match the catalog feed suffix.'
				),
				'content_id_custom_field_name'  => array(
					'type'        => 'string',
					'description' => 'The WooCommerce post-meta key the content ID is read from when `content_id_source` is `custom_field` (variations fall back to the parent product). REQUIRED whenever source is (or becomes) `custom_field`. Pick a REAL key from get_woo_events_config `content_id.available_custom_field_keys` (the populated product meta keys) — do NOT invent one; a key present on 0 products makes every content ID blank and the write returns a WARNING note (surface it). Changing it re-runs the background missing-ID scan.'
				),
				'content_id_logic'              => array(
					'type'        => 'string',
					'enum'        => array(
						'default',
						'facebook_for_woocommerce'
					),
					'description' => 'Facebook content-id strategy. `default` (PixelYourSite logic) can be set anytime — including to clear a stale value. `facebook_for_woocommerce` (align IDs with the Facebook for WooCommerce extension catalog) requires that plugin active — rejected with 409 otherwise. Check `content_id.facebook_for_woocommerce_active` from get_woo_events_config.'
				),
				'variable_as_simple'            => array(
					'type'        => 'boolean',
					'description' => 'Treat variable products as their parent (simple) product when emitting content IDs.'
				),
				'wpml_unified_id'               => array(
					'type'        => 'boolean',
					'description' => 'Use one unified content ID across WPML translations of the same product. REQUIRES the WPML plugin — rejected with 409 if it is not active (the setting only applies to multilingual sites). Check `content_id.wpml_active` from get_woo_events_config first.'
				),
				'content_id_platform'           => array(
					'type'        => 'string',
					'enum'        => array( 'facebook', 'tiktok', 'pinterest', 'bing', 'reddit', 'gtm', 'gatags', 'google_analytics', 'google_ads', 'google', 'openai', 'all' ),
					'description' => 'Optional. Scopes the content-id family args (`content_id_source`/`content_id_prefix`/`content_id_suffix`/`content_id_logic`/`variable_as_simple`/`wpml_unified_id`) to ONE platform — so you can set e.g. a prefix for Meta without touching TikTok/Pinterest/etc. Omit (or `all`) to write all platforms at once (back-compat). Content-id is stored per-platform; read the current per-platform values from `get_woo_events_config.content_id_by_platform`. Google (GA4 + Google Ads) share a single unified holder — pass `gatags` (or `google`/`google_analytics`/`google_ads`, all mapped to `gatags`). Does NOT affect lifecycle toggles / thresholds in the same call (those still apply globally / to all platforms).'
				),
				'platform_event_toggles'       => array(
					'type'        => 'array',
					'description' => 'PER-PLATFORM event-firing toggles — controls whether a specific platform fires a specific WooCommerce event. This is the per-platform layer that sits UNDER the global event toggle: an event reaches a platform only when BOTH its global toggle and this per-platform toggle are on (read both via get_woo_events_config — `funnel_events`/`lifecycle_events` are global, `platform_events` is this matrix). Each item is `{ platform, event, enabled }`. `platform` is a single slug (`facebook`/`tiktok`/`google_analytics`/`google_ads`/`pinterest`/`bing`/`reddit`/`gtm`) or `all` (every active platform that registers the event). `event` is the event stem (e.g. `purchase`, `add_to_cart`, `view_content`, `view_category`, `initiate_checkout`, `remove_from_cart`, plus lifecycle `FirstTimeBuyer`/`ReturningCustomer`/`frequent_shopper`/`vip_client`/`big_whale`, and platform-specific ones like TikTok `advance_purchase`/`compete_payment`). Not every platform registers every event — those that do not are reported in `unsupported_toggles` and skipped (for `all`, non-registering platforms are silently skipped). Subject to the SAME two-step `confirm` gate as the rest of this tool; the preview lists each platform×event `current → new`.',
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'platform', 'event', 'enabled' ),
						'additionalProperties' => false,
						'properties'           => array(
							'platform' => array(
								'type'        => 'string',
								'enum'        => EventToggleMap::TARGET_PLATFORMS,
								'description' => 'Target platform slug, or `all` for every active platform that registers this event.',
							),
							'event'    => array(
								'type'        => 'string',
								'enum'        => EventToggleMap::WOO_EVENTS,
								'description' => 'WooCommerce event to toggle. Some logical events fan out to several per-platform keys: `purchase` also flips TikTok\'s CompletePayment (`compete_payment`). So toggling `purchase` for a platform covers ALL of that platform\'s purchase-related toggles. To target one sub-toggle only, pass its specific stem (e.g. `compete_payment`). The response `platform_event_toggles[].member`/`label` show exactly which keys (and their admin names, e.g. "PlaceAnOrder") were affected. Use `get_woo_events_config.platform_event_labels` to map UI wording to a stem.',
							),
							'enabled'  => array(
								'type'        => 'boolean',
								'description' => 'true = fire this event for the platform; false = do not fire.',
							),
						),
					),
				),
				'confirm'                       => array(
					'type'        => 'boolean',
					'description' => 'Two-step write guard. Call FIRST without this flag (or with `false`) to get a `confirmation_required` preview showing the current→new diff per field (and per platform×event for `platform_event_toggles`) and which platforms the change fans out to — nothing is written. Show that preview to the user, get their explicit go-ahead, THEN call again with `confirm: true` and the same args to actually write. This is server-enforced: a call without `confirm: true` never writes.',
				),
			),
			// `required: ["mcp_note"]` added by AbstractWriteAbility::resolvedInputSchema().
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'saved'                 => array( 'type' => 'boolean' ),
				'available'             => array( 'type' => 'boolean' ),
				'confirmation_required' => array(
					'type'        => 'boolean',
					'description' => 'True when the call was a preview (no `confirm: true`). Nothing was written — show `pending_changes` to the user and call again with `confirm: true`.',
				),
				'pending_changes'       => array(
					'type'                 => 'object',
					'description'          => 'Preview only. Per-arg `{ current, new }` diff of what WOULD be written.',
					'additionalProperties' => true,
				),
				'changed'               => array(
					'type'                 => 'object',
					'description'          => 'The values actually written, keyed by arg name. Present only on a confirmed write.',
					'additionalProperties' => true,
				),
				'aggregated_to'         => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Active platform slugs the aggregate / per-platform writes fanned out to (or would, on preview). A platform appears here only if it actually accepted at least one of the per-platform keys.',
				),
				'unsupported'           => array(
					'type'                 => 'object',
					'description'          => 'Per-arg list of participating platforms that do NOT register that key and therefore did not store it (e.g. Google Ads has no content_id prefix/suffix). Note `content_id_logic` is Facebook-only by design and is not reported here for other platforms. Surface this to the user so they know the change did not reach those platforms.',
					'additionalProperties' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				),
				'platform_event_toggles' => array(
					'type'        => 'array',
					'description' => 'Per-platform event toggles in this call: on preview, what WOULD change; on a confirmed write, what was written. Each entry `{ platform, event, current, new }`.',
					'items'       => array( 'type' => 'object' ),
				),
				'unsupported_toggles'   => array(
					'type'        => 'array',
					'description' => 'Per-platform event toggles that could NOT be applied. Each entry `{ platform, event, reason }` (reason: `unknown_event`, `platform_inactive`, `event_not_supported`, or `no_active_platform_registers_event` for `all`).',
					'items'       => array( 'type' => 'object' ),
				),
				'notes'                 => array(
					'type'        => 'array',
					'description' => 'Side-effect notices the user did NOT explicitly request — e.g. a global event master auto-enabled (two-level gate) or value mode switched to "Customize". You MUST relay every note to the user in your reply, both at the preview step and after the confirmed write — never silently omit them.',
					'items'       => array( 'type' => 'string' ),
				),
			),
		);
	}

	/**
	 * Validate, partition by scope, and write the WooCommerce config (or
	 * preview it when `confirm` is absent).
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		if ( !is_array( $input ) ) {
			$input = array();
		}
		unset( $input[ 'mcp_note' ] );

		$confirm = !empty( $input[ 'confirm' ] );
		unset( $input[ 'confirm' ] );

		$rawToggles = array();
		if ( isset( $input[ 'platform_event_toggles' ] ) && is_array( $input[ 'platform_event_toggles' ] ) ) {
			$rawToggles = $input[ 'platform_event_toggles' ];
		}
		unset( $input[ 'platform_event_toggles' ] );

		if ( !function_exists( '\\PixelYourSite\\isWooCommerceActive' ) || !\PixelYourSite\isWooCommerceActive() ) {
			return new \WP_Error(
				'pys_mcp_woo_inactive',
				'WooCommerce is not active — cannot write WooCommerce event config.',
				array( 'status' => 409 )
			);
		}

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		if ( null === $pys ) {
			return new \WP_Error( 'pys_mcp_pys_unavailable', 'PixelYourSite is not loaded.', array( 'status' => 500 ) );
		}

		// `track_subscriptions` requires the WooCommerce Subscriptions plugin
		// (mirrors the admin UI, which disables the switcher without it).
		if ( array_key_exists( 'track_subscriptions', $input )
		     && function_exists( '\\PixelYourSite\\isWooCommerceSubscriptionsActive' )
		     && !\PixelYourSite\isWooCommerceSubscriptionsActive() ) {
			return new \WP_Error(
				'pys_mcp_woo_subscriptions_inactive',
				'`track_subscriptions` requires the WooCommerce Subscriptions plugin, which is not active on this site. Install and activate it first, then retry. (Other config args in this call were not written either — re-send them without `track_subscriptions`.)',
				array( 'status' => 409 )
			);
		}

		// `content_id_logic = facebook_for_woocommerce` requires that plugin;
		// `default` is always allowed (and clears a stale value).
		if ( 'facebook_for_woocommerce' === ( $input[ 'content_id_logic' ] ?? '' )
		     && !self::isFacebookForWooActive() ) {
			return new \WP_Error(
				'pys_mcp_woo_fb_for_woo_inactive',
				'Setting `content_id_logic` to `facebook_for_woocommerce` requires the Facebook for WooCommerce plugin, which is not active on this site. Activate it first, or use `default`. (Other config args in this call were not written either.)',
				array( 'status' => 409 )
			);
		}

		// `wpml_unified_id` requires WPML (mirrors the admin UI gate).
		if ( array_key_exists( 'wpml_unified_id', $input ) && !self::isWpmlActive() ) {
			return new \WP_Error(
				'pys_mcp_woo_wpml_inactive',
				'`wpml_unified_id` requires the WPML plugin, which is not active on this site. The unified-ID-across-translations logic only applies to multilingual sites. (Other config args in this call were not written either — re-send them without `wpml_unified_id`.)',
				array( 'status' => 409 )
			);
		}

		$cidPlatform = isset( $input[ 'content_id_platform' ] ) && is_string( $input[ 'content_id_platform' ] )
			? trim( $input[ 'content_id_platform' ] ) : '';
		unset( $input[ 'content_id_platform' ] );
		if ( 'all' === $cidPlatform ) {
			$cidPlatform = '';
		}
		if ( in_array( $cidPlatform, array( 'google', 'google_analytics', 'google_ads' ), true ) ) {
			$cidPlatform = 'gatags';
		}

		// Partition incoming args by write scope, coercing values.
		$corePayload     = array();   // global key writes (aggregate + global-only)
		$platformPayload = array();   // per-platform writes (aggregate + per-platform-only)
		$realKeyToArg    = array();   // real PYS key → arg name (for reporting)
		$changed         = array();

		foreach ( $input as $arg => $rawValue ) {
			$arg     = (string) $arg;
			$realKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, $arg );
			if ( null === $realKey ) {
				continue; // not whitelisted — silently ignored
			}
			$value = self::coerce( $arg, $rawValue );

			$isAggregate   = in_array( $arg, self::AGGREGATE_ARGS, true );
			$isGlobalOnly  = in_array( $arg, self::GLOBAL_ONLY_ARGS, true );
			$isPerPlatform = in_array( $arg, self::PER_PLATFORM_ARGS, true );

			if ( $isAggregate || $isGlobalOnly ) {
				$corePayload[ $realKey ] = $value;
			}
			if ( $isAggregate || $isPerPlatform ) {
				$platformPayload[ $realKey ] = $value;
				$realKeyToArg[ $realKey ]    = $arg;
			}
			$changed[ $arg ] = $value;
		}

		if ( empty( $changed ) && empty( $rawToggles ) ) {
			return new \WP_Error(
				'pys_mcp_woo_no_args',
				'No writable WooCommerce config args provided. Pass at least one whitelisted key (e.g. `big_whale`, `content_id_source`) or `platform_event_toggles`.',
				array( 'status' => 400 )
			);
		}

		$valueModeNote = '';
		if ( !isset( $input[ 'value_mode' ] )
		     && !empty( array_intersect( array_keys( $changed ), array( 'tax_option', 'shipping_option', 'fees_option' ) ) ) ) {
			$vmKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'value_mode' );
			if ( null !== $vmKey && 'custom' !== (string) $pys->getOption( $vmKey ) ) {
				$corePayload[ $vmKey ]   = 'custom';
				$changed[ 'value_mode' ] = 'custom';
				$valueModeNote           = 'Switched value mode to "Customize Tax and Shipping" (was "Use WooCommerce price settings") so the tax/shipping/fees options take effect.';
			}
		}

		$activeSettings = Platforms::activeSettings();

		// Validate the content-id qualifier against active content-id targets.
		if ( '' !== $cidPlatform && !isset( $activeSettings[ $cidPlatform ] ) ) {
			return new \WP_Error(
				'pys_mcp_woo_cid_platform_invalid',
				sprintf(
					'`content_id_platform: %s` is not an active content-id platform. Active: %s. (Google content_id is held by `gatags`; GA/Google Ads share it.)',
					$cidPlatform,
					implode( ', ', array_keys( $activeSettings ) )
				),
				array( 'status' => 400 )
			);
		}

		if ( '' !== $cidPlatform
		     && !empty( array_intersect( array_keys( $changed ), self::PER_PLATFORM_ARGS ) ) ) {
			$baseKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'content_id_source' );
			$inst    = $activeSettings[ $cidPlatform ];
			if ( null !== $baseKey && method_exists( $inst, 'issetOption' ) && !$inst->issetOption( $baseKey ) ) {
				return new \WP_Error(
					'pys_mcp_woo_cid_platform_unsupported',
					sprintf(
						'`%s` has no WooCommerce content_id setting — nothing to write. Use a platform listed in get_woo_events_config.content_id_by_platform.',
						$cidPlatform
					),
					array( 'status' => 400 )
				);
			}
		}

		if ( 'custom_field' === ( $input[ 'content_id_source' ] ?? '' ) ) {
			$providedField = isset( $input[ 'content_id_custom_field_name' ] )
				? trim( (string) $input[ 'content_id_custom_field_name' ] ) : '';
			if ( '' === $providedField ) {
				$fieldKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'content_id_custom_field_name' );
				$targets  = ( '' !== $cidPlatform ) ? array( $cidPlatform ) : array_keys( $activeSettings );
				$missing  = false;
				foreach ( $targets as $t ) {
					$s = $activeSettings[ $t ] ?? null;
					if ( null === $s || in_array( $t, self::CONTENT_ID_EXCLUDED_PLATFORMS, true ) ) {
						continue;
					}
					if ( !method_exists( $s, 'issetOption' ) || !$s->issetOption( $fieldKey ) ) {
						continue;
					}
					if ( '' === trim( (string) $s->getOption( $fieldKey, '' ) ) ) {
						$missing = true;
						break;
					}
				}
				if ( $missing ) {
					return new \WP_Error(
						'pys_mcp_woo_custom_field_name_required',
						'Setting `content_id_source` to `custom_field` requires `content_id_custom_field_name` (the WooCommerce meta key holding the catalog ID). Ask the user which meta key to read and pass it in the same call. (Nothing was written.)',
						array( 'status' => 409 )
					);
				}
			}
		}

		$customFieldWarn = '';
		$cfName          = isset( $input[ 'content_id_custom_field_name' ] ) ? trim( (string) $input[ 'content_id_custom_field_name' ] ) : '';
		if ( '' !== $cfName && 0 === GetWooEventsConfigAbility::metaKeyProductCount( $cfName ) ) {
			$suggested       = array_map( static function ( $m ) {
				return $m[ 'key' ];
			}, array_slice( GetWooEventsConfigAbility::productMetaKeys( 8 ), 0, 8 ) );
			$customFieldWarn = sprintf(
				'WARNING: the meta key `%s` is present on 0 products, so every content ID sourced from it will be BLANK (products will not match the catalog). This is usually a typo or a non-existent field. %s Use `product_id` unless this key is intentional and will be populated.',
				$cfName,
				empty( $suggested ) ? '' : 'Populated product meta keys you could use instead: ' . implode( ', ', $suggested ) . '.'
			);
		}

		$toggleWrites      = array();   // slug => [ realKey => bool ]
		$togglePending     = array();   // [ { platform, event, current, new } ]
		$toggleUnsupported = array();   // [ { platform, event, reason } ]
		$masterEnable      = array();   // core master key => event stem (auto-enabled)
		foreach ( $rawToggles as $entry ) {
			if ( !is_array( $entry ) ) {
				continue;
			}
			$tPlatform = isset( $entry[ 'platform' ] ) && is_string( $entry[ 'platform' ] ) ? $entry[ 'platform' ] : '';
			$tEvent    = isset( $entry[ 'event' ] ) && is_string( $entry[ 'event' ] ) ? $entry[ 'event' ] : '';
			$tEnabled  = !empty( $entry[ 'enabled' ] );
			if ( '' === $tPlatform || '' === $tEvent ) {
				continue;
			}
			if ( !EventToggleMap::isKnownEvent( 'woo', $tEvent ) ) {
				$toggleUnsupported[] = array( 'platform' => $tPlatform, 'event' => $tEvent, 'reason' => 'unknown_event' );
				continue;
			}

			$members = EventToggleMap::resolveMembers( 'woo', $tEvent );
			$targets = 'all' === $tPlatform ? array_keys( $activeSettings ) : array( $tPlatform );
			$matchedAny = false;
			foreach ( $targets as $slug ) {
				$settings = $activeSettings[ $slug ] ?? null;
				if ( null === $settings || !method_exists( $settings, 'issetOption' ) ) {
					if ( 'all' !== $tPlatform ) {
						$toggleUnsupported[] = array( 'platform' => $slug, 'event' => $tEvent, 'reason' => 'platform_inactive' );
					}
					continue;
				}
				$slugMatched = false;
				foreach ( $members as $stem ) {
					if ( !EventToggleMap::platformSupports( 'woo', $slug, $stem, $settings ) ) {
						continue;
					}
					$slugMatched = true;
					$matchedAny  = true;

					if ( EventToggleMap::isCoreScoped( 'woo', $stem, $slug ) ) {
						$ckey                 = EventToggleMap::masterKey( 'woo', $stem, $slug );
						$corePayload[ $ckey ] = $tEnabled;
						$togglePending[]      = array(
							'platform' => $slug,
							'event'    => $tEvent,
							'member'   => $stem,
							'label'    => EventToggleMap::labelFor( 'woo', $slug, $stem ),
							'current'  => method_exists( $pys, 'getOption' ) ? EventToggleMap::toBool( $pys->getOption( $ckey ) ) : false,
							'new'      => $tEnabled,
						);
						continue;
					}

					$key                           = EventToggleMap::key( 'woo', $stem );
					$toggleWrites[ $slug ][ $key ] = $tEnabled;
					$togglePending[]               = array(
						'platform' => $slug,
						'event'    => $tEvent,
						'member'   => $stem,
						'label'    => EventToggleMap::labelFor( 'woo', $slug, $stem ),
						'current'  => EventToggleMap::toBool( $settings->getOption( $key ) ),
						'new'      => $tEnabled,
					);

					if ( $tEnabled ) {
						$mKey = EventToggleMap::masterKey( 'woo', $stem, $slug );
						if ( !isset( $corePayload[ $mKey ] ) && method_exists( $pys, 'issetOption' )
						     && $pys->issetOption( $mKey ) && !EventToggleMap::toBool( $pys->getOption( $mKey ) ) ) {
							$corePayload[ $mKey ]  = true;
							$masterEnable[ $mKey ] = $stem;
						}
					}
				}
				if ( !$slugMatched && 'all' !== $tPlatform ) {
					$toggleUnsupported[] = array( 'platform' => $slug, 'event' => $tEvent, 'reason' => 'event_not_supported' );
				}
			}
			if ( 'all' === $tPlatform && !$matchedAny ) {
				$toggleUnsupported[] = array( 'platform' => 'all', 'event' => $tEvent, 'reason' => 'no_active_platform_registers_event' );
			}
		}

		// Per active platform, which per-platform keys it actually registers
		// (`issetOption`); PYS drops writes to unregistered keys silently.
		$accepts = array();
		foreach ( $activeSettings as $slug => $settings ) {
			$accepts[ $slug ] = array();
			foreach ( $platformPayload as $realKey => $value ) {
				$arg = $realKeyToArg[ $realKey ] ?? $realKey;
				if ( !self::isValidTarget( $arg, $slug ) ) {
					continue;
				}
				if ( '' !== $cidPlatform && in_array( $arg, self::PER_PLATFORM_ARGS, true ) && $slug !== $cidPlatform ) {
					continue;
				}
				if ( method_exists( $settings, 'issetOption' ) && $settings->issetOption( $realKey ) ) {
					$accepts[ $slug ][] = $realKey;
				}
			}
		}

		$unsupported = array();
		foreach ( $activeSettings as $slug => $settings ) {
			if ( empty( $accepts[ $slug ] ) ) {
				continue; // not a participant in this call
			}
			foreach ( $platformPayload as $realKey => $value ) {
				$arg = $realKeyToArg[ $realKey ] ?? $realKey;
				// Args not meant for this module aren't "unsupported" here.
				if ( !self::isValidTarget( $arg, $slug ) ) {
					continue;
				}

				if ( '' !== $cidPlatform && in_array( $arg, self::PER_PLATFORM_ARGS, true ) && $slug !== $cidPlatform ) {
					continue;
				}
				if ( !in_array( $realKey, $accepts[ $slug ], true ) ) {
					$unsupported[ $arg ][] = $slug;
				}
			}
		}

		// Platforms that will receive at least one per-platform key.
		$aggregatedTo = array();
		if ( !empty( $platformPayload ) ) {
			foreach ( $accepts as $slug => $keys ) {
				if ( !empty( $keys ) ) {
					$aggregatedTo[] = $slug;
				}
			}
		}

		// Two-step confirm gate: without `confirm: true`, preview the diff and
		// write nothing.
		$masterNotes = self::masterNotes( $masterEnable );
		if ( '' !== $valueModeNote ) {
			$masterNotes[] = $valueModeNote;
		}
		if ( '' !== $customFieldWarn ) {
			$masterNotes[] = $customFieldWarn;
		}

		if ( !$confirm ) {
			$pending = array();
			foreach ( $changed as $arg => $newValue ) {
				$pending[ $arg ] = array(
					'current' => self::currentValue( $arg, $pys, $activeSettings, $cidPlatform ),
					'new'     => $newValue,
				);
			}
			foreach ( $masterEnable as $mKey => $stem ) {
				$pending[ 'global_' . $stem ] = array( 'current' => false, 'new' => true );
			}
			$preview = array(
				'available'             => true,
				'confirmation_required' => true,
				'pending_changes'       => (object) $pending,
				'aggregated_to'         => $aggregatedTo,
			);
			if ( !empty( $unsupported ) ) {
				$preview[ 'unsupported' ] = $unsupported;
			}
			if ( !empty( $togglePending ) ) {
				$preview[ 'platform_event_toggles' ] = $togglePending;
			}
			if ( !empty( $toggleUnsupported ) ) {
				$preview[ 'unsupported_toggles' ] = $toggleUnsupported;
			}
			if ( !empty( $masterNotes ) ) {
				$preview[ 'notes' ] = $masterNotes;
			}

			return $preview;
		}

		// ---- Confirmed write ---------------------------------------------
		if ( !empty( $corePayload ) ) {
			$pys->updateOptions( $corePayload );
		}
		$scanTriggered = array();
		if ( !empty( $platformPayload ) ) {
			$srcKey  = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'content_id_source' );
			$fldKey  = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'content_id_custom_field_name' );
			foreach ( $activeSettings as $slug => $settings ) {
				// Only write keys this platform registers (filtered above).
				$accepted = array_intersect_key( $platformPayload, array_flip( $accepts[ $slug ] ) );
				if ( empty( $accepted ) ) {
					continue;
				}
				$settings->updateOptions( $accepted );

				// custom_field mode set/changed here → (re)launch the missing-ID scan.
				$sourceTouched = null !== $srcKey && array_key_exists( $srcKey, $accepted );
				$fieldTouched  = null !== $fldKey && array_key_exists( $fldKey, $accepted );
				$effSource     = ( $sourceTouched ? (string) $accepted[ $srcKey ] : (string) $settings->getOption( $srcKey, '' ) );
				if ( 'custom_field' === $effSource && ( $sourceTouched || $fieldTouched ) && class_exists( '\\PixelYourSite\\PysContentIdScanner' ) ) {
					$fieldName = (string) $settings->getOption( $fldKey, '' );
					if ( '' !== $fieldName ) {
						\PixelYourSite\PysContentIdScanner::startScan( (string) $slug, $fieldName );
						$scanTriggered[] = (string) $slug;
					}
				}
			}
		}

		if ( !empty( $scanTriggered ) ) {
			$masterNotes[] = sprintf(
				'Started a background content-ID scan for: %s (custom_field mode). Any product whose meta key is empty will send a blank ID — read the missing-ID counts later from get_woo_events_config `content_id.custom_field_scan`.',
				implode( ', ', array_unique( $scanTriggered ) )
			);
		}

		// Per-platform event-toggle writes (one updateOptions per target slot).
		foreach ( $toggleWrites as $slug => $kv ) {
			$settings = $activeSettings[ $slug ] ?? null;
			if ( null !== $settings && !empty( $kv ) ) {
				$settings->updateOptions( $kv );
			}
		}

		if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		foreach ( $masterEnable as $mKey => $stem ) {
			$changed[ 'global_' . $stem ] = true;
		}

		$result = array(
			'saved'         => true,
			'available'     => true,
			'changed'       => (object) $changed,
			'aggregated_to' => $aggregatedTo,
		);
		if ( !empty( $unsupported ) ) {
			$result[ 'unsupported' ] = $unsupported;
		}
		if ( !empty( $togglePending ) ) {
			$result[ 'platform_event_toggles' ] = $togglePending;
		}
		if ( !empty( $toggleUnsupported ) ) {
			$result[ 'unsupported_toggles' ] = $toggleUnsupported;
		}
		if ( !empty( $masterNotes ) ) {
			$result[ 'notes' ] = $masterNotes;
		}

		return $result;
	}

	/**
	 * Current stored value for an arg, for the preview diff. Aggregate /
	 * global-only args read from the global `core` settings; per-platform args
	 * (content_id family) read from the TARGET platform when a content_id
	 * qualifier is set (so the diff reflects the platform actually being
	 * written), else a representative active platform.
	 *
	 * @param string                $arg            Public arg name.
	 * @param mixed                 $pys            PYS core settings instance.
	 * @param array<string, object> $activeSettings Active module instances by slug.
	 * @param string                $cidPlatform    Target content_id platform, or '' for all.
	 * @return mixed
	 */
	/**
	 * Human-readable notes for masters auto-enabled by per-platform toggles.
	 *
	 * @param array<string, string> $masterEnable masterKey => event stem.
	 * @return array<int, string>
	 */
	private static function masterNotes( array $masterEnable ): array {
		$notes = array();
		foreach ( $masterEnable as $stem ) {
			$notes[ $stem ] = sprintf(
				'Auto-enabled the global "%s" toggle (it was OFF, so the per-platform enable would not have fired) — "%s" now fires on every platform whose per-platform toggle is on.',
				EventToggleMap::labelFor( 'woo', '', $stem ),
				EventToggleMap::labelFor( 'woo', '', $stem )
			);
		}

		return array_values( $notes );
	}

	private static function currentValue( string $arg, $pys, array $activeSettings, string $cidPlatform = '' ) {
		$realKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, $arg );
		if ( null === $realKey ) {
			return null;
		}

		if ( !in_array( $arg, self::PER_PLATFORM_ARGS, true ) || empty( $activeSettings ) ) {
			return self::coerce( $arg, $pys->getOption( $realKey ) );
		}

		if ( '' !== $cidPlatform && isset( $activeSettings[ $cidPlatform ] ) ) {
			return self::coerce( $arg, $activeSettings[ $cidPlatform ]->getOption( $realKey ) );
		}

		$distinct = array();
		foreach ( $activeSettings as $slug => $inst ) {
			if ( !self::isValidTarget( $arg, $slug ) || !method_exists( $inst, 'issetOption' )
			     || !$inst->issetOption( $realKey ) ) {
				continue;
			}
			$distinct[ (string) self::coerce( $arg, $inst->getOption( $realKey ) ) ] = true;
		}
		$values = array_keys( $distinct );
		if ( count( $values ) === 1 ) {
			return $values[ 0 ];
		}
		if ( empty( $values ) ) {
			return self::coerce( $arg, $pys->getOption( $realKey ) );
		}

		return '(varies: ' . implode( ', ', $values ) . ')';
	}

	/**
	 * "Which platforms does each setting group reach" map, using the same
	 * routing rules as the writer (isValidTarget + issetOption). Consumed by
	 * `get_woo_events_config`. Probes one representative key per group;
	 * thresholds + `poas_enabled` are global, not per-platform.
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function resolveScope(): array {
		$activeSettings = Platforms::activeSettings();

		$probe = array(
			'lifecycle'        => array(
				'arg' => 'big_whale',
				'key' => ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'big_whale' )
			),
			'content_id'       => array(
				'arg' => 'content_id_source',
				'key' => ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'content_id_source' )
			),
			'content_id_logic' => array(
				'arg' => 'content_id_logic',
				'key' => ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'content_id_logic' )
			),
		);

		$scope = array();
		foreach ( $probe as $group => $p ) {
			$scope[ $group ] = array();
			if ( null === $p[ 'key' ] ) {
				continue;
			}
			foreach ( $activeSettings as $slug => $settings ) {
				if ( !self::isValidTarget( $p[ 'arg' ], $slug ) ) {
					continue;
				}
				if ( method_exists( $settings, 'issetOption' ) && $settings->issetOption( $p[ 'key' ] ) ) {
					$scope[ $group ][] = $slug;
				}
			}
		}

		$scope[ 'thresholds_and_poas' ] = array( '(global setting — not per-platform)' );

		return $scope;
	}

	/**
	 * Is `$slug` a valid fan-out target for `$arg`? Single-platform args go to
	 * their named module only; the content-id family skips GA / Ads; anything
	 * else goes to any active module that registers it.
	 *
	 * @param string $arg  Public arg name.
	 * @param string $slug Platform slug.
	 * @return bool
	 */
	private static function isValidTarget( string $arg, string $slug ): bool {
		if ( isset( self::SINGLE_PLATFORM_ARGS[ $arg ] ) ) {
			return self::SINGLE_PLATFORM_ARGS[ $arg ] === $slug;
		}
		if ( in_array( $arg, self::CONTENT_ID_FAMILY_ARGS, true )
		     && in_array( $slug, self::CONTENT_ID_EXCLUDED_PLATFORMS, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Is the Facebook for WooCommerce extension active? Prefers the PYS
	 * helper (single source of truth); falls back to the class check the
	 * helper itself uses (`WC_Facebookcommerce`).
	 *
	 * @return bool
	 */
	private static function isFacebookForWooActive(): bool {
		if ( function_exists( '\\PixelYourSite\\Facebook\\Helpers\\isFacebookForWooCommerceActive' ) ) {
			return (bool) \PixelYourSite\Facebook\Helpers\isFacebookForWooCommerceActive();
		}

		return class_exists( 'WC_Facebookcommerce' );
	}

	/**
	 * Is the WPML plugin active? Mirrors the admin UI's `isWPMLActive()` gate.
	 *
	 * @return bool
	 */
	private static function isWpmlActive(): bool {
		if ( function_exists( '\\PixelYourSite\\isWPMLActive' ) ) {
			return (bool) \PixelYourSite\isWPMLActive();
		}
		if ( !function_exists( 'is_plugin_active' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return function_exists( 'is_plugin_active' )
		       && is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' );
	}

	/**
	 * Coerce a raw arg value to the type the option expects (defensive — the
	 * schema already validates at the adapter layer).
	 *
	 * @param string $arg Public arg name.
	 * @param mixed  $raw
	 * @return mixed
	 */
	private static function coerce( string $arg, $raw ) {
		if ( in_array( $arg, self::BOOL_ARGS, true ) ) {
			return (bool) $raw;
		}
		if ( in_array( $arg, self::INT_ARGS, true ) ) {
			return (int) $raw;
		}
		if ( in_array( $arg, self::FLOAT_ARGS, true ) ) {
			return (float) $raw;
		}

		return is_string( $raw ) ? $raw : (string) $raw;
	}
}