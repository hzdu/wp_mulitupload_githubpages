<?php
/**
 * `get_custom_event` — full read-only detail of ONE PYS custom event by
 * `event_id`: event-level settings, enabled platforms, triggers (stable
 * `trigger_index`) and conditions (`condition_index`), plus the authoritative
 * menus of what can be added. Field names mirror the admin so the result can be
 * written back via `set_custom_event`.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\CustomEventConditionMap;
use PixelYourSite\MCP\CustomEventTriggerMap;
use PixelYourSite\MCP\CustomEventPlatformMap;

final class GetCustomEventAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-custom-event';

	private const ADMIN_UI_PATH = 'PixelYourSite → Events';

	private const PLATFORM_MAP = array(
		'facebook'         => array( 'e' => 'facebook_enabled', 'pid' => 'facebook_pixel_id', 'pid_arr' => true, 'et' => 'facebook_event_type', 'cet' => 'facebook_custom_event_type', 'pe' => 'facebook_params_enabled', 'p' => 'facebook_params', 'cp' => 'facebook_custom_params', 'ts' => 'facebook_track_single_woo_data', 'tc' => 'facebook_track_cart_woo_data', 'cl' => null ),
		'tiktok'           => array( 'e' => 'tiktok_enabled', 'pid' => 'tiktok_pixel_id', 'pid_arr' => false, 'et' => 'tiktok_event_type', 'cet' => 'tiktok_custom_event_type', 'pe' => 'tiktok_params_enabled', 'p' => 'tiktok_params', 'cp' => 'tiktok_custom_params', 'ts' => 'tiktok_track_single_woo_data', 'tc' => 'tiktok_track_cart_woo_data', 'cl' => null ),
		'pinterest'        => array( 'e' => 'pinterest_enabled', 'pid' => 'pinterest_pixel_id', 'pid_arr' => false, 'et' => 'pinterest_event_type', 'cet' => 'pinterest_custom_event_type', 'pe' => 'pinterest_params_enabled', 'p' => 'pinterest_params', 'cp' => 'pinterest_custom_params', 'ts' => 'pinterest_track_single_woo_data', 'tc' => 'pinterest_track_cart_woo_data', 'cl' => null ),
		'openai'           => array( 'e' => 'openai_enabled', 'pid' => 'openai_pixel_id', 'pid_arr' => true, 'et' => 'openai_event_type', 'cet' => 'openai_custom_event_type', 'pe' => 'openai_params_enabled', 'p' => 'openai_params', 'cp' => null, 'ts' => 'openai_track_single_woo_data', 'tc' => 'openai_track_cart_woo_data', 'cl' => null ),
		'google_analytics' => array( 'e' => 'ga_enabled', 'pid' => 'ga_pixel_id', 'pid_arr' => true, 'et' => 'ga_event_action', 'cet' => 'ga_custom_event_action', 'pe' => null, 'p' => 'ga_params', 'cp' => 'ga_custom_params', 'ts' => null, 'tc' => null, 'cl' => 'ga_conversion_label' ),
		'ga_ads'           => array( 'e' => 'ga_ads_enabled', 'pid' => 'ga_ads_pixel_id', 'pid_arr' => true, 'et' => 'ga_ads_event_action', 'cet' => 'ga_ads_custom_event_action', 'pe' => null, 'p' => 'ga_ads_params', 'cp' => 'ga_ads_custom_params', 'ts' => 'ga_ads_track_single_woo_data', 'tc' => 'ga_ads_track_cart_woo_data', 'cl' => 'ga_ads_conversion_label' ),
		'gtm'              => array( 'e' => 'gtm_enabled', 'pid' => 'gtm_pixel_id', 'pid_arr' => true, 'et' => 'gtm_event_action', 'cet' => 'gtm_custom_event_action', 'pe' => null, 'p' => 'gtm_params', 'cp' => 'gtm_custom_params', 'ts' => 'gtm_track_single_woo_data', 'tc' => 'gtm_track_cart_woo_data', 'cl' => 'gtm_conversion_label' ),
		'google_ads'       => array( 'e' => 'google_ads_enabled', 'pid' => 'google_ads_conversion_id', 'pid_arr' => true, 'et' => 'google_ads_event_action', 'cet' => 'google_ads_custom_event_action', 'pe' => null, 'p' => null, 'cp' => 'google_ads_custom_params', 'ts' => null, 'tc' => null, 'cl' => 'google_ads_conversion_label' ),
		'bing'             => array( 'e' => 'bing_enabled', 'pid' => 'bing_pixel_id', 'pid_arr' => false, 'et' => 'bing_event_type', 'cet' => 'bing_custom_event_type', 'pe' => 'bing_params_enabled', 'p' => 'bing_params', 'cp' => 'bing_custom_params', 'ts' => 'bing_track_single_woo_data', 'tc' => 'bing_track_cart_woo_data', 'cl' => null ),
		'reddit'           => array( 'e' => 'reddit_enabled', 'pid' => 'reddit_pixel_id', 'pid_arr' => false, 'et' => 'reddit_event_type', 'cet' => 'reddit_custom_event_type', 'pe' => 'reddit_params_enabled', 'p' => 'reddit_params', 'cp' => null, 'ts' => 'reddit_track_single_woo_data', 'tc' => 'reddit_track_cart_woo_data', 'cl' => null ),
	);

	private const TRIGGER_PARAMS_BY_TYPE = array(
		'page_visit'            => array( 'delay' ),
		'home_page'             => array( 'delay' ),
		'post_type'             => array( 'delay', 'post_type_value' ),
		'number_page_visit'     => array( 'number_visit', 'conditional_number_visit' ),
		'css_click'             => array( 'click_count', 'click_time_limit' ),
		'video_view'            => array( 'video_view_urls', 'video_view_play_trigger', 'video_view_disable_watch_video' ),
		'video_speed'           => array( 'video_speed_urls', 'video_speed_rate', 'video_speed_triggers' ),
		'form_field'            => array( 'form_field_urls', 'form_field_forms', 'form_field_fields', 'form_field_type' ),
		'email_link'            => array( 'email_link_disable_email_event' ),
		'purchase'              => array( 'purchase_transaction_only', 'track_transaction_ID', 'track_value_and_currency' ),
		'add_to_cart'           => array( 'track_value_and_currency' ),
		'gads_phone_conversion' => array( 'gads_phone_numbers' ),
		// url_click, css_mouseover, scroll_pos, copy_element → rules only.
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get Custom Event';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Returns the FULL configuration of one PixelYourSite custom event by `event_id` (get the id from `get_custom_events`). Sections: event-level (`title`, `enabled`, `trigger_logic` OR/AND, `fire_frequency` once/every_time, `enable_time_window` + `time_window` for "fire only once in N hours", `conditions_enabled`, `conditions_logic`); `platforms` — ONLY the platforms this event is enabled for, each with its pixel selection (`pixel_ids` array for facebook/openai/google_analytics/ga_ads/gtm/google_ads, or scalar `pixel_id` for tiktok/pinterest/bing/reddit; `all` = every pixel of that platform), `event_type` (+ `custom_event_type` when the type is the custom one), `params_enabled`, standard `params`, `custom_params`, woo-data flags and `conversion_label` where the platform has one; `triggers` — each with a stable `trigger_index` (use it for point-wise edits via `set_custom_event`), `type`, its `params` and `rules` (rule/value pairs); `conditions` — each with `condition_index`, `type`, and `rule`/`value` or `device` / `user_role` / `product_ids`+`product_match_mode` (the WooCommerce Product ID condition; `products` adds the readable name of every listed id, and `includes` = the order contains at least one of them while `includes_only` = the order contains nothing else). Field names mirror the admin so they can be written back. Also returns `available_condition_types` and `available_trigger_types` — the AUTHORITATIVE menus of what you can add to this event (condition types with their allowed `rule`/`device` values; trigger types each flagged `editable`). When the user asks "what can I add?", answer from these arrays — never guess or invent types. `available_event_types` gives, per ENABLED platform, the full event-type menu WITH each event\'s params (GA / GTM / Google Ads are grouped by category, like the admin) — use it to answer "what event types / params are available for platform X" and to set a valid `event_type`; do NOT guess event types or their params. The `params` array for each event is AUTHORITATIVE and COMPLETE: list ONLY those params. An event whose `params` is an EMPTY array (e.g. GA `conversion`, `tutorial_begin`) accepts NO standard params — state exactly that and offer `custom_params`; NEVER fill in params from your own GA4 / Google Ads knowledge (PixelYourSite only supports what this menu lists, and a write of an unlisted param is rejected). Read-only. Returns an error if no custom event has that id. Call this before editing an event so you patch real values, not guesses.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'required'             => array( 'event_id' ),
			'additionalProperties' => false,
			'properties'           => array(
				'event_id' => array(
					'type'        => 'integer',
					'description' => 'The custom event post ID (from `get_custom_events`).',
				),
			),
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'event_id', 'title' ),
			'properties' => array(
				'event_id'           => array( 'type' => 'integer' ),
				'title'              => array( 'type' => 'string' ),
				'enabled'            => array( 'type' => 'boolean' ),
				'feature_enabled'    => array(
					'type'        => 'boolean',
					'description' => 'Master switch `custom_events_enabled`; when false the event never fires regardless of `enabled`.',
				),
				'admin_ui_path'      => array( 'type' => 'string' ),
				'trigger_logic'      => array( 'type' => 'string' ),
				'fire_frequency'     => array( 'type' => 'string' ),
				'enable_time_window' => array( 'type' => 'boolean' ),
				'time_window'        => array( 'type' => 'integer' ),
				'conditions_enabled' => array( 'type' => 'boolean' ),
				'conditions_logic'   => array( 'type' => 'string' ),
				'platforms'          => array(
					'type'                 => 'object',
					'description'          => 'Per-platform config, only for platforms this event is enabled for.',
					'additionalProperties' => array( 'type' => 'object' ),
				),
				'triggers'           => array(
					'type'        => 'array',
					'description' => 'Triggers with stable `trigger_index` for point-wise edits.',
					'items'       => array( 'type' => 'object' ),
				),
				'conditions'         => array(
					'type'        => 'array',
					'description' => 'Conditions with stable `condition_index`.',
					'items'       => array( 'type' => 'object' ),
				),
				'available_condition_types' => array(
					'type'        => 'array',
					'description' => 'The COMPLETE list of condition types you can add to this event via set_custom_event (with allowed `rule` / `device` values). Use this — do NOT guess condition types.',
					'items'       => array( 'type' => 'object' ),
				),
				'available_trigger_types'   => array(
					'type'        => 'array',
					'description' => 'The COMPLETE list of trigger types, each flagged `editable` (false = read-only / admin-only). Use this — do NOT guess trigger types.',
					'items'       => array( 'type' => 'object' ),
				),
				'available_event_types'     => array(
					'type'                 => 'object',
					'description' => 'Per ENABLED platform: the authoritative event-type menu with each event\'s params ({name, input_type, required}). GA / GTM / Google Ads are `grouped` by category (groups[].event_types[]); other platforms are flat (event_types[]). Use this to answer "what event types / params for platform X" and to set a valid `event_type` — never guess, and never say a platform lacks an event type without checking here first (most platforms DO support standard ecommerce events; type names are platform- and CASE-specific, e.g. `AddToCart` for facebook/tiktok/bing/reddit vs `addtocart` for pinterest vs `add_to_cart` for GA/GTM/ga_ads — map the user\'s wording to the menu value). Each event\'s `params` list is COMPLETE; an EMPTY `params` array means the event takes NO standard params (use custom_params) — do not invent params from general GA4 knowledge. Each platform entry also carries `custom_params_supported` (bool): when FALSE the platform accepts ONLY its standard params and NO custom params (reddit and openai) — do not offer custom_params there. One more flag appears for `openai`, whose taxonomy is CLOSED (one field it does not know makes its Conversions API reject the WHOLE event, not just that field, which is why it takes no fields of your own at all): `params_without_dynamic_values` (`amount`, `currency` — these take a literal value, never a CSS `selector` / `dynamic:true`; `amount` is a decimal in the shop currency, converted server-side, and `currency` must be an ISO 4217 code).',
					'additionalProperties' => array( 'type' => 'object' ),
				),
				'connectable_platforms'     => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Writable platforms that can be ENABLED on this event right now — their addon is active AND a pixel is configured. ONLY offer / enable platforms from this list when the user asks "which platforms can I add"; a platform NOT here is not connected (addon off or no pixel) and enabling it is rejected. Do not guess from the full platform list.',
				),
				'dynamic_parameter_tokens'  => array(
					'type'        => 'object',
					'description' => 'Authoritative catalogue of PixelYourSite dynamic-parameter tokens. Any param value (in `params` or `custom_params`) may be one of these tokens passed verbatim as the value (e.g. value `[id]`, `[title]`, `[url_utm_source]`, `[field_email]`, `[mp_total]`) — PYS substitutes the real value when the event fires. `fixed` = exact tokens; `patterns` = `[url_PARAM]` / `[field_NAME]` / `[mp_VARIABLE]` where you fill in the name. Use these exact names; do not invent tokens. Do NOT send personal data via tokens.',
				),
			),
		);
	}

	/**
	 * Build the full detail for one custom event.
	 *
	 * @param mixed $input Validated args: { event_id }.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		$eventId = isset( $input[ 'event_id' ] ) ? (int) $input[ 'event_id' ] : 0;

		if ( $eventId <= 0 || 'pys_event' !== get_post_type( $eventId ) ) {
			return new \WP_Error(
				'pys_mcp_custom_event_not_found',
				sprintf( 'No custom event with id %d. Call get_custom_events for the list of valid event_ids.', $eventId ),
				array( 'status' => 404 )
			);
		}
		if ( !class_exists( '\\PixelYourSite\\CustomEventFactory' ) ) {
			return new \WP_Error( 'pys_mcp_custom_events_unavailable', 'Custom events are not available on this site.', array( 'status' => 503 ) );
		}

		$event = \PixelYourSite\CustomEventFactory::getById( $eventId );
		$data  = method_exists( $event, 'getAllData' ) ? (array) $event->getAllData() : array();

		$pys             = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		$featureEnabled  = null !== $pys && self::toBool( $pys->getOption( 'custom_events_enabled' ) );

		$out = array(
			'event_id'           => $eventId,
			'title'              => self::sanitiseUserString( $event->getTitle() ),
			'enabled'            => (bool) $event->__get( 'enabled' ),
			'feature_enabled'    => $featureEnabled,
			'admin_ui_path'      => self::ADMIN_UI_PATH,
			'trigger_logic'      => (string) ( $data[ 'trigger_logic' ] ?? 'OR' ),
			'fire_frequency'     => (string) ( $data[ 'fire_frequency' ] ?? 'every_time' ),
			'enable_time_window' => self::toBool( $data[ 'enable_time_window' ] ?? false ),
			'time_window'        => (int) ( $data[ 'time_window' ] ?? 24 ),
			'conditions_enabled' => self::toBool( $data[ 'conditions_enabled' ] ?? false ),
			'conditions_logic'   => (string) ( $data[ 'conditions_logic' ] ?? 'OR' ),
			'platforms'          => self::platforms( $data ),
			'triggers'           => self::triggers( $event ),
			'conditions'         => self::conditions( $event ),
			'available_condition_types' => self::availableConditionTypes(),
			'available_trigger_types'   => self::availableTriggerTypes(),
			'available_event_types'     => self::availableEventTypes( $data ),
			'connectable_platforms'     => self::connectablePlatforms(),
			'dynamic_parameter_tokens'  => self::dynamicParameterTokens(),
		);

		return $out;
	}

	/**
	 * Writable platforms that can be ENABLED on this event right now — i.e. their
	 * addon is active AND a pixel is configured. Only OFFER / enable platforms from
	 * this list; the rest are not connected (addon off or no pixel) and enabling
	 * them is rejected.
	 *
	 * @return array<int, string>
	 */
	private static function connectablePlatforms(): array {
		$out = array();
		foreach ( SetCustomEventAbility::WRITABLE_PLATFORMS as $slug ) {
			if ( CustomEventPlatformMap::isConnectable( $slug ) ) {
				$out[] = $slug;
			}
		}
		return $out;
	}

	/**
	 * The authoritative catalogue of PixelYourSite dynamic-parameter tokens. Any
	 * param value (standard `params` OR `custom_params`) may be one of these tokens
	 * passed verbatim as the value — PYS substitutes the real value when the event
	 * fires. This is static (same for every event) but surfaced here so the caller
	 * uses the exact token names instead of guessing.
	 *
	 * @return array<string, mixed>
	 */
	private static function dynamicParameterTokens(): array {
		return array(
			'note'     => 'A param value (in `params` or `custom_params`) may be a dynamic token — pass it verbatim as the value (e.g. params:{content_name:{value:"[title]"}} or a custom_param {name:"src", value:"[url_utm_source]"}). PYS replaces it at fire time. Do NOT use these to send users\' personal data.',
			'fixed'    => array(
				array( 'token' => '[id]',            'value' => 'WordPress post ID' ),
				array( 'token' => '[title]',         'value' => 'content title' ),
				array( 'token' => '[content_type]',  'value' => 'post type (post, product, page, …)' ),
				array( 'token' => '[categories]',    'value' => 'content categories' ),
				array( 'token' => '[tags]',          'value' => 'content tags' ),
				array( 'token' => '[total]',         'value' => "WooCommerce/EDD order total, when it exists" ),
				array( 'token' => '[subtotal]',      'value' => "WooCommerce/EDD order subtotal, when it exists" ),
			),
			'patterns' => array(
				array( 'token' => '[url_PARAM]',     'value' => 'value of URL query parameter PARAM (e.g. [url_utm_source] for ?utm_source=…); the event omits it if the parameter is absent on the page' ),
				array( 'token' => '[field_NAME]',    'value' => 'value of the form field whose name is NAME (e.g. field name `email` → [field_email]); used with a form trigger' ),
				array( 'token' => '[mp_VARIABLE]',   'value' => 'MemberPress variable VARIABLE (always prefix `mp_`, e.g. [mp_total]); only on a thankyou page using the [mepr-ecommerce-tracking] shortcode' ),
			),
		);
	}

	/**
	 * Per-platform event-type menus (with each event's params) for the platforms
	 * this event has ENABLED — so the caller picks a real event_type + knows its
	 * params instead of guessing. GA / GTM / Google Ads are grouped by category.
	 *
	 * @param array $data The event's full data array.
	 * @return array<string, array<string, mixed>>
	 */
	private static function availableEventTypes( array $data ): array {
		$out = array();
		foreach ( self::PLATFORM_MAP as $slug => $m ) {
			if ( !self::toBool( $data[ $m[ 'e' ] ] ?? false ) ) {
				continue; // platform not enabled for this event
			}
			$menu = CustomEventPlatformMap::eventTypeMenu( $slug );
			if ( !empty( $menu ) ) {
				$def = CustomEventPlatformMap::get( $slug );
				$menu[ 'custom_params_supported' ] = null !== ( $def[ 'custom_params' ] ?? null );

				$staticOnly = CustomEventPlatformMap::staticOnlyParams( $slug );
				if ( !empty( $staticOnly ) ) {
					$menu[ 'params_without_dynamic_values' ] = $staticOnly;
				}

				$out[ $slug ] = $menu;
			}
		}

		return $out;
	}

	/**
	 * The authoritative menu of condition types (so Claude never guesses). Each:
	 * { type, label, shape, rules? (rule_value types), device_values? (device) }.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function availableConditionTypes(): array {
		$out = array();
		foreach ( CustomEventConditionMap::types() as $type ) {
			$shape = CustomEventConditionMap::shape( $type );
			$row   = array(
				'type'  => $type,
				'label' => CustomEventConditionMap::label( $type ),
				'shape' => $shape,
			);
			if ( CustomEventConditionMap::SHAPE_RULE_VALUE === $shape ) {
				$row[ 'rules' ] = CustomEventConditionMap::ruleValues( $type );
			} elseif ( CustomEventConditionMap::SHAPE_DEVICE === $shape ) {
				$row[ 'device_values' ] = CustomEventConditionMap::DEVICE_VALUES;
			} elseif ( CustomEventConditionMap::SHAPE_USER_ROLE === $shape ) {
				$row[ 'roles' ] = self::availableUserRoles();
			} elseif ( CustomEventConditionMap::SHAPE_PRODUCT_ID === $shape ) {
				$row[ 'product_match_modes' ] = CustomEventConditionMap::productMatchModes();
				$row[ 'requires_trigger' ]    = 'purchase';
				$row[ 'id_lookup_tool' ]      = 'search_woo_products';
			}
			$out[] = $row;
		}

		return $out;
	}

	/**
	 * The authoritative menu of trigger types with their editability + allowed
	 * rule values (so Claude never guesses). Each: { type, label, editable, rules? }.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function availableTriggerTypes(): array {
		$out = array();
		foreach ( CustomEventTriggerMap::types() as $type ) {
			$row = array(
				'type'     => $type,
				'label'    => CustomEventTriggerMap::label( $type ),
				'editable' => CustomEventTriggerMap::isEditable( $type ),
			);
			$rules = CustomEventTriggerMap::ruleValues( $type );
			if ( !empty( $rules ) ) {
				$row[ 'rules' ] = $rules;
			}
			if ( CustomEventTriggerMap::supportsUrlWildcard( $type ) ) {
				$row[ 'all_pages_value' ] = '*';
				$row[ 'all_pages_hint' ]  = 'To match ALL pages/URLs, use a rule item with value "*" (e.g. {rule:"contains", value:"*"}) — "*" matches everything regardless of the rule.';
			}
			if ( 'gads_phone_conversion' === $type ) {
				$row[ 'phone_numbers' ] = 'Required: an array of ONE OR MORE {number, label} objects (e.g. [{"number":"+1...","label":"Main"},{"number":"+1...","label":"Support"}]). Both number and label required per entry.';
				$row[ 'exclusive' ]     = 'Google-Ads-only + EXCLUSIVE: adding this removes all other triggers, disables every non-Ads platform, and restricts Google pixels to Ads. Warn the user before confirming.';
			}

			if ( CustomEventTriggerMap::isEditable( $type ) ) {
				$params = array();
				$def    = CustomEventTriggerMap::get( $type );
				foreach ( (array) ( $def[ 'params' ] ?? array() ) as $p ) {
					$spec = CustomEventTriggerMap::paramSpec( $p );
					if ( empty( $spec ) ) {
						continue;
					}
					$entry = array_merge( array( 'name' => $p ), $spec );

					if ( 'post_type_value' === $p ) {
						$entry[ 'values' ] = self::availablePostTypes();
					}
					$params[] = $entry;
				}
				if ( !empty( $params ) ) {
					$row[ 'params' ] = $params;
				}
			}
			$out[] = $row;
		}

		// Active form-plugin trigger types (CF7, WPForms, …)
		foreach ( CustomEventTriggerMap::formPlugins() as $slug => $plugin ) {
			$row = array(
				'type'             => $slug,
				'label'            => CustomEventTriggerMap::formPluginName( $slug ),
				'editable'         => CustomEventTriggerMap::isEditable( $slug ),
				'is_form_trigger'  => true,
			);
			if ( CustomEventTriggerMap::isEditable( $slug ) ) {
				$forms = array();
				foreach ( CustomEventTriggerMap::formPluginForms( $slug ) as $id => $title ) {
					$forms[] = array( 'value' => $id, 'label' => (string) $title );
				}
				$row[ 'forms' ]            = $forms;
				$row[ 'form_submit_mode' ] = CustomEventTriggerMap::FORM_SUBMIT_MODES;
				$row[ 'fields' ]           = 'forms (array of form ids), form_submit_mode, disabled_form_action (bool)';
			} else {
				$row[ 'note' ] = 'Configured from a live page scan in the admin — not editable via MCP.';
			}
			$out[] = $row;
		}

		return $out;
	}

	/**
	 * Per-platform blocks for the enabled platforms only.
	 *
	 * @param array $data The event's full data array.
	 * @return array<string, array<string, mixed>>
	 */
	private static function platforms( array $data ): array {
		$out = array();
		foreach ( self::PLATFORM_MAP as $slug => $m ) {
			if ( !self::toBool( $data[ $m[ 'e' ] ] ?? false ) ) {
				continue; // platform not enabled for this event
			}

			$block = array( 'enabled' => true );

			// Pixel selection: array (multi) vs scalar (single).
			$pid = $data[ $m[ 'pid' ] ] ?? null;
			if ( $m[ 'pid_arr' ] ) {
				$block[ 'pixel_ids' ] = array_values( array_filter( (array) $pid, static function ( $v ) {
					return null !== $v && '' !== $v;
				} ) );
			} else {
				$block[ 'pixel_id' ] = (string) $pid;
			}

			$block[ 'event_type' ] = (string) ( $data[ $m[ 'et' ] ] ?? '' );
			if ( null !== $m[ 'cet' ] && !empty( $data[ $m[ 'cet' ] ] ) ) {
				$block[ 'custom_event_type' ] = (string) $data[ $m[ 'cet' ] ];
			}

			if ( null !== $m[ 'pe' ] ) {
				$block[ 'params_enabled' ] = self::toBool( $data[ $m[ 'pe' ] ] ?? false );
			}
			if ( null !== $m[ 'p' ] && !empty( $data[ $m[ 'p' ] ] ) ) {
				$params = array();
				foreach ( (array) $data[ $m[ 'p' ] ] as $pk => $pv ) {
					$has = is_array( $pv ) ? ( '' !== (string) ( $pv[ 'value' ] ?? '' ) ) : ( null !== $pv && '' !== $pv );
					if ( $has ) {
						$params[ $pk ] = $pv;
					}
				}
				if ( !empty( $params ) ) {
					$block[ 'params' ] = $params;
				}
			}
			if ( null !== $m[ 'cp' ] && !empty( $data[ $m[ 'cp' ] ] ) ) {
				$block[ 'custom_params' ] = $data[ $m[ 'cp' ] ];
			}
			if ( null !== $m[ 'ts' ] ) {
				$block[ 'track_single_woo_data' ] = self::toBool( $data[ $m[ 'ts' ] ] ?? false );
			}
			if ( null !== $m[ 'tc' ] ) {
				$block[ 'track_cart_woo_data' ] = self::toBool( $data[ $m[ 'tc' ] ] ?? false );
			}
			if ( null !== $m[ 'cl' ] && !empty( $data[ $m[ 'cl' ] ] ) ) {
				$block[ 'conversion_label' ] = (string) $data[ $m[ 'cl' ] ];
			}

			// Platform-specific extra fields (e.g. GTM dataLayer options).
			foreach ( CustomEventPlatformMap::extras( $slug ) as $field => $spec ) {
				if ( !array_key_exists( $spec[ 'key' ], $data ) ) {
					continue;
				}
				$block[ $field ] = 'bool' === $spec[ 'type' ]
					? self::toBool( $data[ $spec[ 'key' ] ] )
					: (string) $data[ $spec[ 'key' ] ];
			}

			$out[ $slug ] = $block;
		}

		return $out;
	}

	/**
	 * Normalise the trigger objects into readable rows with a stable index.
	 *
	 * @param \PixelYourSite\CustomEvent $event Event model.
	 * @return array<int, array<string, mixed>>
	 */
	private static function triggers( $event ): array {
		$out      = array();
		$triggers = is_array( $event->getTriggers() ) ? $event->getTriggers() : array();
		foreach ( $triggers as $trigger ) {
			if ( !is_object( $trigger ) || !method_exists( $trigger, 'getTriggerType' ) ) {
				continue;
			}
			$row = array(
				'trigger_index' => (int) $trigger->getTriggerIndex(),
				'type'          => (string) $trigger->getTriggerType(),
			);

			// rule/value pairs (page_visit, url_click, scroll_pos, email_link, …).
			$rules = method_exists( $trigger, 'getTriggers' ) ? $trigger->getTriggers() : array();
			if ( !empty( $rules ) ) {
				$row[ 'rules' ] = self::sanitiseRules( $rules );
			}

			// Per-type relevant params that are actually set
			$params    = array();
			$relevant  = self::TRIGGER_PARAMS_BY_TYPE[ (string) $trigger->getTriggerType() ] ?? array();
			foreach ( $relevant as $name ) {
				$val = $trigger->getParam( $name );
				if ( null === $val || '' === $val || ( is_array( $val ) && empty( $val ) ) ) {
					continue;
				}
				if ( is_bool( $val ) && false === $val ) {
					continue; // skip default-off booleans for compactness
				}
				$params[ $name ] = is_string( $val ) ? self::sanitiseUserString( $val, 0 ) : $val;
			}
			if ( !empty( $params ) ) {
				$row[ 'params' ] = $params;
			}

			// Form-plugin triggers (CF7, WPForms, …)
			$type = (string) $trigger->getTriggerType();
			if ( CustomEventTriggerMap::isFormPlugin( $type ) ) {
				$available = CustomEventTriggerMap::formPluginForms( $type );
				$selected  = method_exists( $trigger, 'getForms' ) ? (array) $trigger->getForms() : array();
				$forms     = array();
				foreach ( $selected as $fid ) {
					$forms[] = array(
						'id'    => $fid,
						'title' => isset( $available[ $fid ] ) ? self::sanitiseUserString( $available[ $fid ] ) : null,
					);
				}
				$row[ 'forms' ]                = $forms;
				$row[ 'form_submit_mode' ]     = $trigger->getParam( 'form_submit_mode' ) ?: 'both';
				$row[ 'disabled_form_action' ] = (bool) $trigger->getParam( 'disabled_form_action' );
			}

			$out[] = $row;
		}

		return $out;
	}

	/**
	 * Strip tags from user-derived rule VALUES (URLs / match strings) while
	 * leaving the rule operator (an enum) intact. No truncation — rule values are
	 * written back verbatim.
	 *
	 * @param mixed $rules Rule/value pairs from the trigger.
	 * @return array
	 */
	private static function sanitiseRules( $rules ): array {
		$out = array();
		foreach ( (array) $rules as $rule ) {
			if ( is_array( $rule ) ) {
				if ( array_key_exists( 'value', $rule ) ) {
					$rule[ 'value' ] = self::sanitiseUserString( $rule[ 'value' ], 0 );
				}
				$out[] = $rule;
			} else {
				$out[] = self::sanitiseUserString( $rule, 0 );
			}
		}
		return $out;
	}

	/**
	 * Normalise the condition objects into readable rows with a stable index.
	 *
	 * @param \PixelYourSite\CustomEvent $event Event model.
	 * @return array<int, array<string, mixed>>
	 */
	private static function conditions( $event ): array {
		$out        = array();
		$conditions = method_exists( $event, 'getConditions' ) && is_array( $event->getConditions() )
			? $event->getConditions() : array();
		foreach ( $conditions as $condition ) {
			if ( !is_object( $condition ) || !method_exists( $condition, 'getConditionType' ) ) {
				continue;
			}
			$type = (string) $condition->getConditionType();
			$row  = array(
				'condition_index' => (int) $condition->getConditionIndex(),
				'type'            => $type,
			);

			switch ( $type ) {
				case 'device':
					$row[ 'device' ] = $condition->getParam( 'device' );
					break;
				case 'user_role':
					$row[ 'user_role' ] = $condition->getParam( 'user_role' );
					break;
				case 'product_id':
					$product_ids                 = (array) $condition->getParam( 'product_ids' );
					$row[ 'product_ids' ]        = array_map( 'intval', $product_ids );
					$row[ 'product_match_mode' ] = (string) $condition->getParam( 'product_match_mode' );
					$row[ 'products' ]           = self::productLabels( $product_ids );
					break;
				default: // url_filters, url_parameters, landing_page, source
					$row[ 'rule' ]  = $condition->getParam( 'condition_rule' );
					$row[ 'value' ] = self::sanitiseUserString( $condition->getParam( 'condition_value' ), 0 );
					break;
			}

			$out[] = $row;
		}

		return $out;
	}

	/**
	 * Readable names for the products of a product_id condition, so the reader
	 * sees what an ID actually is (a deleted product is reported as such).
	 *
	 * @param array<int, mixed> $product_ids Stored product/variation IDs.
	 * @return array<int, array<string, mixed>>
	 */
	private static function productLabels( array $product_ids ): array {
		$out = array();

		foreach ( $product_ids as $product_id ) {
			$product_id = (int) $product_id;
			$label      = class_exists( '\\PixelYourSite\\ConditionalEvent' )
				? \PixelYourSite\ConditionalEvent::getProductLabel( $product_id )
				: (string) $product_id;

			$out[] = array(
				'id'    => $product_id,
				'label' => self::sanitiseUserString( $label, 0 ),
			);
		}

		return $out;
	}

	/**
	 * Registered post types as { value, label } — the same set the admin
	 * post_type-trigger dropdown offers (get_post_types(null,'objects')).
	 *
	 * @return array<int, array<string, string>>
	 */
	private static function availablePostTypes(): array {
		$out = array();
		foreach ( get_post_types( array(), 'objects' ) as $type ) {
			$out[] = array(
				'value' => (string) $type->name,
				'label' => (string) ( $type->label ?: $type->name ),
			);
		}

		return $out;
	}

	/**
	 * User roles as { value, label } — guest + the site's registered roles, the
	 * same set the user_role condition accepts (SetCustomEventAbility::validRoles).
	 *
	 * @return array<int, array<string, string>>
	 */
	private static function availableUserRoles(): array {
		$out = array( array( 'value' => 'guest', 'label' => 'Guest (not logged in)' ) );
		if ( function_exists( '\\PixelYourSite\\getAvailableUserRoles' ) ) {
			foreach ( (array) \PixelYourSite\getAvailableUserRoles() as $slug => $name ) {
				$out[] = array( 'value' => (string) $slug, 'label' => (string) $name );
			}
		}

		return $out;
	}

	/**
	 * Coerce a mixed value to a boolean (PYS stores bools as bool/'1'/1/'true').
	 *
	 * @param mixed $value Raw value.
	 * @return bool
	 */
	private static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}
