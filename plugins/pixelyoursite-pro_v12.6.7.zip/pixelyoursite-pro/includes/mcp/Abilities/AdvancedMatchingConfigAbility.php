<?php
/**
 * `get_advanced_matching_config` — read-only snapshot of the advanced
 * matching field-name lists.
 * Returns the eight stored lists (4 DOM, 4 URL-param) plus an
 * `automatic_coverage` block describing what PYS already matches without
 * any config (logged-in users, WC / EDD customers) and which dimensions
 * have no coverage. Read-only.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\Platforms;
use PixelYourSite\MCP\AdvancedMatchingMap;

final class AdvancedMatchingConfigAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-advanced-matching-config';

	/** WP-admin path for these settings, cited verbatim by Claude. */
	private const ADMIN_UI_PATH = 'PixelYourSite → Global Settings → "Advanced user-data detections" card';

	/** DOM input name lists: public short name => real PYS key (phone = `_tel_`). */
	private const DOM_KEYS = array(
		'first_name' => 'advance_matching_fn_names',
		'last_name'  => 'advance_matching_ln_names',
		'phone'      => 'advance_matching_tel_names',
		'email'      => 'advance_matching_em_names',
	);

	/** URL-query parameter name lists — landing pages with prefilled forms. */
	private const URL_KEYS = array(
		'first_name' => 'advance_matching_url_fn_names',
		'last_name'  => 'advance_matching_url_ln_names',
		'phone'      => 'advance_matching_url_tel_names',
		'email'      => 'advance_matching_url_em_names',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Advanced Matching Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Returns the eight advanced-matching field-name lists (4 DOM form inputs + 4 URL parameters), the PER-PLATFORM matching opt-in switches, and the automatic-coverage context. The field-name lists improve match quality across MULTIPLE destinations — Meta Advanced Matching and EMQ (Event Match Quality), TikTok Pixel/Events API Match Rate, Google Ads Enhanced Conversions, GA4 User-Provided Data, and OpenAI Ads matching — they share the same DOM field-name config. SEPARATELY, each pixel platform has its OWN matching master switch reported in `per_platform` (Facebook/TikTok "Advanced Matching", Pinterest "Enhanced Matching", Bing "Enhanced Conversions", GA4/GTM "User-Provided Data" with sub-options, Google Ads "Enhanced Conversions (manual)") — if a platform\'s switch is off, the shared field-name lists do nothing for it. Write those switches with `set_advanced_matching_fields` `platform_matching_toggles`. A `per_platform` entry also carries `fields_sent` where PYS has a VERIFIED list of what that platform receives — today only `openai`: `sent` (the field names), `limits` (how many values a field carries where more than one is allowed) and a `note` on what is hashed and where each value comes from. Answer "what data does PYS send to <platform>?" from `fields_sent`, and for a platform that has none say plainly that there is no verified list rather than guessing — do NOT infer one from `dom_fields`, which describes what is COLLECTED from forms, not what any platform forwards. IMPORTANT: every one of these per-platform switches — INCLUDING TikTok "Advanced Matching" — is fully controllable through this MCP. Do NOT tell the user a platform\'s matching can only be changed in the WordPress admin: when asked to enable/disable matching for TikTok (or any listed platform), do it via `set_advanced_matching_fields` `platform_matching_toggles` (with the standard confirmation), never refuse as "admin-only". Call this when the audit shows `advanced_matching: incomplete`, or when the user asks about ANY of: match quality, EMQ, TikTok match rate, Enhanced Conversions, user-provided data, or whether matching is enabled for a specific platform. Use `automatic_coverage` to explain that logged-in users and ecommerce customers are already matched — the gap is anonymous form submissions; `gaps` flags which DOM dimensions have no coverage. After reading the config, proactively ask whether the user has a key page with an important form (checkout, contact, lead) that can be scanned (`scan_page_for_form_fields`) for additional field names.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array<string, mixed>
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array<string, mixed>
	 */
	public static function outputSchema(): array {
		$dimensions = array(
			'type'       => 'object',
			'required'   => array( 'first_name', 'last_name', 'phone', 'email' ),
			'properties' => array(
				'first_name' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'last_name'  => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'phone'      => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'email'      => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
			),
		);

		return array(
			'type'       => 'object',
			'required'   => array(
				'admin_ui_path',
				'dom_fields',
				'url_params',
				'auto_save_url_params',
				'per_platform',
				'automatic_coverage',
				'gaps'
			),
			'properties' => array(
				'admin_ui_path'        => array(
					'type'        => 'string',
					'description' => 'Verbatim WP-admin breadcrumb where the user can edit these settings. Quote as-is when suggesting manual edits — do not paraphrase or compose paths from setting names.',
				),
				'dom_fields'           => $dimensions,
				'url_params'           => $dimensions,
				'auto_save_url_params' => array( 'type' => 'boolean' ),
				'per_platform'         => array(
					'type'                 => 'object',
					'description'          => 'Per-platform matching opt-in, keyed by ACTIVE platform slug. Each entry: `{ enabled: bool, label: string, sub_options?: { send_multiple_values: bool, use_encoding?: bool } }`. `label` is the admin wording for that platform. `sub_options` appear for GA4 (send_multiple_values + use_encoding) and GTM (send_multiple_values). `fields_sent` appears where PYS has a VERIFIED list of what that platform receives — today only `openai`, with `sent` (the field names), `limits` (how many values a field carries where more than one is allowed) and a `note` on hashing and on where each value comes from. Answer "what data does PYS send to <platform>?" from `fields_sent`, and say plainly that there is no verified list for a platform that has none — do NOT infer one from `dom_fields`, which describes what is COLLECTED from forms, not what any platform forwards. When `enabled` is false the shared field-name lists do nothing for that platform. Write via `set_advanced_matching_fields.platform_matching_toggles`.',
					'additionalProperties' => array(
						'type'       => 'object',
						'properties' => array(
							'enabled'     => array( 'type' => 'boolean' ),
							'label'       => array( 'type' => 'string' ),
							'fields_sent' => array(
								'type'        => 'object',
								'description' => 'What this platform actually receives: `sent` (field names), `limits` (values per field where more than one is allowed) and a `note`. Present only where PYS has a verified list.',
							),
							'sub_options' => array(
								'type'                 => 'object',
								'additionalProperties' => array( 'type' => 'boolean' ),
							),
						),
					),
				),
				'locked_defaults'      => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
					'description'          => 'Built-in DEFAULT matching field names per DOM dimension that PYS ALWAYS matches — they cannot be removed (the admin shows them as locked) and are matched even if absent from `dom_fields`. So `last_name`/`last-name`/`last name`, `first_name`/…/`name`, `phone`/`tel` are always active; email has none. Do not try to remove these via `set_advanced_matching_fields` — it has no effect.',
				),
				'automatic_coverage'   => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'string' ),
				),
				'gaps'                 => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
			),
		);
	}

	/**
	 * Built-in LOCKED default matching field names per DOM dimension — PYS
	 * always matches these regardless of the stored lists, and the admin
	 * renders them as locked chips (they cannot be removed). Mirrors
	 * `html-main-settings.php`: hardcoded defaults for first_name / last_name /
	 * phone (none for email or URL params), PLUS any active form plugin's
	 * `getDefaultMatchingInput()` (CF7, Elementor, WPForms, …) via the
	 * `pys_form_event_factory` filter.
	 *
	 * @return array<string, array<int, string>> dimension => default names.
	 */
	public static function lockedDefaults(): array {
		$defaults = array(
			'first_name' => array( 'first_name', 'first-name', 'first name', 'name' ),
			'last_name'  => array( 'last_name', 'last-name', 'last name' ),
			'phone'      => array( 'phone', 'tel' ),
			'email'      => array(),
		);

		// dimension => the key the form plugin uses (phone → `tel`).
		$pluginKey = array( 'first_name' => 'first_name', 'last_name' => 'last_name', 'phone' => 'tel' );

		$factory = function_exists( 'apply_filters' ) ? apply_filters( 'pys_form_event_factory', array() ) : array();
		if ( is_array( $factory ) ) {
			foreach ( $factory as $plugin ) {
				if ( !is_object( $plugin ) || !method_exists( $plugin, 'getDefaultMatchingInput' ) ) {
					continue;
				}
				$pd = $plugin->getDefaultMatchingInput();
				if ( !is_array( $pd ) ) {
					continue;
				}
				foreach ( $pluginKey as $dim => $pk ) {
					if ( !empty( $pd[ $pk ] ) && is_array( $pd[ $pk ] ) ) {
						$defaults[ $dim ] = array_values( array_unique( array_merge( $defaults[ $dim ], $pd[ $pk ] ) ) );
					}
				}
			}
		}

		return $defaults;
	}

	/**
	 * Returns the advanced-matching field-name lists and coverage context.
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;

		$domFields = array();
		foreach ( self::DOM_KEYS as $dimension => $optionKey ) {
			$value                   = $pys ? $pys->getOption( $optionKey, array() ) : array();
			$domFields[ $dimension ] = is_array( $value ) ? array_values( $value ) : array();
		}

		$urlParams = array();
		foreach ( self::URL_KEYS as $dimension => $optionKey ) {
			$value                   = $pys ? $pys->getOption( $optionKey, array() ) : array();
			$urlParams[ $dimension ] = is_array( $value ) ? array_values( $value ) : array();
		}

		$lockedDefaults = self::lockedDefaults();

		$gaps = array();
		foreach ( array( 'first_name', 'last_name', 'phone', 'email' ) as $dim ) {
			if ( empty( $domFields[ $dim ] ) && empty( $lockedDefaults[ $dim ] ) ) {
				$gaps[] = sprintf(
					'No %s DOM-field names configured — anonymous form %s matching is inactive.',
					str_replace( '_', ' ', $dim ),
					str_replace( '_', ' ', $dim )
				);
			}
		}

		$autoSave = $pys ? self::toBool( $pys->getOption( 'enable_auto_save_advance_matching_url', true ) ) : true;

		// Per-platform matching opt-in (only platforms active on this site).
		$perPlatform = array();
		foreach ( Platforms::activeSettings() as $slug => $settings ) {
			if ( AdvancedMatchingMap::has( $slug ) && is_object( $settings ) && method_exists( $settings, 'getOption' ) ) {
				$perPlatform[ $slug ] = AdvancedMatchingMap::readState( $slug, $settings );
			}
		}

		return array(
			'admin_ui_path'        => self::ADMIN_UI_PATH,
			'dom_fields'           => $domFields,
			'url_params'           => $urlParams,
			'auto_save_url_params' => $autoSave,
			'per_platform'         => $perPlatform,
			'locked_defaults'      => $lockedDefaults,
			'automatic_coverage'   => self::automaticCoverage(),
			'gaps'                 => $gaps,
		);
	}

	/**
	 * Coverage prose for Claude, conditional on WC/EDD being active.
	 *
	 * @return array<string, string>
	 */
	private static function automaticCoverage(): array {
		$out = array(
			'logged_in_users' => 'Logged-in WordPress users have first/last name and email automatically populated from their user account — no field-name config needed.',
			'anonymous_forms' => 'Anonymous form submissions rely on the `dom_fields` lists to map form input `name` attributes to advanced matching dimensions. URL-param matching uses `url_params`.',
		);

		if ( function_exists( '\\PixelYourSite\\isWooCommerceActive' ) && \PixelYourSite\isWooCommerceActive() ) {
			$out[ 'woocommerce_customers' ] = 'WooCommerce checkout / order events automatically pull first/last name, email, phone from billing data — no field-name config needed for those events.';
		}
		if ( function_exists( '\\PixelYourSite\\isEddActive' ) && \PixelYourSite\isEddActive() ) {
			$out[ 'edd_customers' ] = 'EDD checkout / order events automatically pull first/last name and email from the customer record.';
		}

		return $out;
	}

	/**
	 * Normalise the auto-save flag (PYS sometimes stores it as a string).
	 *
	 * @param mixed $value Raw option value.
	 * @return bool
	 */
	private static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}