<?php
/**
 * `get_woo_events_config` — read-only snapshot of WooCommerce event config.
 * Returns `{ available: false }` when WooCommerce is off, else five
 * sections: funnel_events, lifecycle_events, subscriptions, content_id and
 * value_settings. content_id is per-platform in PYS, so it reports a
 * representative platform's values plus a `diverges_across_platforms` flag.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\Platforms;
use PixelYourSite\MCP\EventToggleMap;

final class GetWooEventsConfigAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-woo-events-config';

	private const ADMIN_UI_PATH = 'PixelYourSite → WooCommerce';

	/** Funnel event name => core option key. All default-enabled. */
	private const FUNNEL_KEYS = array(
		'ViewContent'          => 'woo_view_content_enabled',
		'AddToCart'            => 'woo_add_to_cart_enabled',
		'InitiateCheckout'     => 'woo_initiate_checkout_enabled',
		'Purchase'             => 'woo_purchase_enabled',
		'ViewCart'             => 'woo_view_cart_enabled',
		'ViewItemList'         => 'woo_view_item_list_enabled',
		'RemoveFromCart'       => 'woo_remove_from_cart_enabled',
		'CheckoutSteps'        => 'woo_checkout_steps_enabled',
	);

	/** content_id sub-keys read per-platform. */
	private const CONTENT_ID_KEYS = array(
		'source'             => 'woo_content_id',
		'prefix'             => 'woo_content_id_prefix',
		'suffix'             => 'woo_content_id_suffix',
		'custom_field_name'  => 'woo_content_id_custom_field_name',
		'logic'              => 'woo_content_id_logic',
		'variable_as_simple' => 'woo_variable_as_simple',
		'wpml_unified_id'    => 'woo_wpml_unified_id',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get WooCommerce Events Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Returns the full WooCommerce event configuration for PYS in one response. Returns `{ "available": false }` immediately if WooCommerce is not active. Sections: `funnel_events` (compact `{ all_enabled: true }` when all are in default-enabled state, else the full per-event map), `add_to_cart_triggers` (WHERE the AddToCart event fires — "When to fire the add to cart event": `on_button_click` / `on_cart_page` / `on_checkout_page`; write via set_woo_event_config same-named args), `lifecycle_events` (on/off + threshold for NewCustomer, ReturningCustomer, FrequentShopper, VIPClient, BigWhale), `subscriptions` (`track_subscriptions`, `poas_enabled`), `content_id` (source [`product_id`|`product_sku`|`custom_field`] / prefix / suffix / `custom_field_name` [the WooCommerce meta key read when source is `custom_field`] / `custom_field_scan` [present in custom_field mode: `{status, total_scanned, missing_count}` from the PYS content-ID scanner — products whose meta key is empty and would send a blank ID] / `available_custom_field_keys` [present in custom_field mode: the real populated product meta keys `{key, product_count}` ranked by coverage — use these to answer "which custom fields exist" and to pick a valid `content_id_custom_field_name`, never invent one] / logic / variable_as_simple / wpml_unified_id + `facebook_for_woocommerce_active` — true when the Facebook for WooCommerce extension is installed, which both enables `content_id_logic` editing and risks double-firing pixel events), `value_settings` (tax / shipping / fees / order-id prefix — read-only), `platform_events` (PER-PLATFORM event-firing matrix: for each active platform, which events it is set to fire — an event reaches a platform only when BOTH its global toggle in `funnel_events`/`lifecycle_events` AND the platform toggle here are on; only events a platform registers are listed, and the sets differ per platform; write these via `set_woo_event_config` `platform_event_toggles`), and `platform_scope` (which active platforms each writable setting-group reaches — use it to answer "which pixels does setting X apply to?" instantly, no write needed; e.g. `content_id_logic` → Facebook only, content_id family → all content-id platforms incl. Google Tags but NOT separate GA/Google Ads). Call this when the audit shows `woo_events: warning | incomplete | error`, or when the user asks about WC tracking (including which platforms a setting affects). Do not call it if the audit shows `woo_events: ok`.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'available' ),
			'properties' => array(
				'available'        => array( 'type' => 'boolean' ),
				'admin_ui_path'    => array( 'type' => 'string' ),
				'platform_scope'   => array(
					'type'                 => 'object',
					'description'          => 'Which active platforms each writable setting-group reaches when changed via set_woo_event_config. Keys: `lifecycle` (toggles + track_subscriptions), `content_id` (source/prefix/suffix/variable_as_simple/wpml_unified_id), `content_id_logic` (Facebook-only), `thresholds_and_poas` (global, not per-platform). Use this to answer "which pixels does setting X apply to?" without a write.',
					'additionalProperties' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				),
				'funnel_events'    => array( 'type' => 'object' ),
				'add_to_cart_triggers' => array( 'type' => 'object' ),
				'lifecycle_events' => array( 'type' => 'object' ),
				'subscriptions'    => array( 'type' => 'object' ),
				'content_id'       => array( 'type' => 'object' ),
				'content_id_by_platform' => array(
					'type'                 => 'object',
					'description'          => 'Per-platform content_id values (the genuine per-platform state — each platform can differ). Keyed by slug => { source, prefix, suffix, logic?, variable_as_simple?, wpml_unified_id? } (only keys the platform registers). GA/Google Ads are omitted — their content_id is the unified `gatags` entry. Write a single platform via `set_woo_event_config` `content_id_platform`.',
					'additionalProperties' => array( 'type' => 'object' ),
				),
				'value_settings'   => array( 'type' => 'object' ),
				'platform_events'  => array(
					'type'                 => 'object',
					'description'          => 'PER-PLATFORM event-firing toggles: for each active platform, which events it is set to fire. An event actually fires for a platform only when BOTH its global toggle (`funnel_events`/`lifecycle_events` above) AND the platform toggle here are on. Only events the platform registers are listed (sets differ per platform). Keyed by platform slug → { event_stem => bool }. Write via `set_woo_event_config` `platform_event_toggles`.',
					'additionalProperties' => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'boolean' ),
					),
				),
				'platform_event_labels' => array(
					'type'                 => 'object',
					'description'          => 'Admin-facing label for each (platform, event) in `platform_events`. Use it to map the user\'s UI wording to the stem to write: e.g. TikTok `purchase` is shown as "PlaceAnOrder", TikTok `compete_payment` as "CompletePayment", Pinterest `purchase` as "Checkout". OpenAI uses its own taxonomy for EVERY event — `view_content` is "contents_viewed", `add_to_cart` "items_added", `initiate_checkout` "checkout_started", `purchase` "order_created" — so never report an OpenAI event under its stem name or a Facebook-style name. Keyed by slug → { event_stem => label }.',
					'additionalProperties' => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'string' ),
					),
				),
				'event_groups'     => array(
					'type'                 => 'object',
					'description'          => 'Logical events that fan out to several per-platform member stems when toggled via `set_woo_event_config`. E.g. `purchase` → `[purchase, compete_payment]`: toggling the `purchase` event also flips TikTok\'s CompletePayment. Keyed by logical event → member stems.',
					'additionalProperties' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				),
			),
		);
	}

	/**
	 * Build the read-only WooCommerce config snapshot.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		if ( !function_exists( '\\PixelYourSite\\isWooCommerceActive' ) || !\PixelYourSite\isWooCommerceActive() ) {
			return array( 'available' => false );
		}

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		if ( null === $pys ) {
			return array( 'available' => false );
		}

		return array(
			'available'        => true,
			'admin_ui_path'    => self::ADMIN_UI_PATH,
			// Which platforms each writable group reaches (same routing as the set tool).
			'platform_scope'   => SetWooEventConfigAbility::resolveScope(),
			'funnel_events'    => self::funnelEvents( $pys ),
			'add_to_cart_triggers' => array(
				'on_button_click'  => self::toBool( $pys->getOption( 'woo_add_to_cart_on_button_click' ) ),
				'on_cart_page'     => self::toBool( $pys->getOption( 'woo_add_to_cart_on_cart_page' ) ),
				'on_checkout_page' => self::toBool( $pys->getOption( 'woo_add_to_cart_on_checkout_page' ) ),
			),
			'lifecycle_events' => self::lifecycleEvents( $pys ),
			'subscriptions'    => array(
				'track_subscriptions'         => self::toBool( $pys->getOption( 'woo_track_subscriptions' ) ),
				'poas_enabled'                => self::toBool( $pys->getOption( 'woo_poas_enabled' ) ),
				// WooCommerce Subscriptions active? When false, `track_subscriptions` is locked.
				'subscriptions_plugin_active' => function_exists(
					'\\PixelYourSite\\isWooCommerceSubscriptionsActive'
				) ? (bool) \PixelYourSite\isWooCommerceSubscriptionsActive() : false,
			),
			'content_id'             => self::contentId(),

			'content_id_by_platform' => self::contentIdByPlatform(),
			'value_settings'   => array(
				'value_mode'      => (string) $pys->getOption( 'woo_event_value', '' ),
				'tax_option'      => (string) $pys->getOption( 'woo_tax_option', '' ),
				'shipping_option' => (string) $pys->getOption( 'woo_shipping_option', '' ),
				'fees_option'     => (string) $pys->getOption( 'woo_fees_option', '' ),
				'order_id_prefix' => (string) $pys->getOption( 'woo_order_id_prefix', '' ),
			),

			'platform_events'        => EventToggleMap::platformMatrix( 'woo' ),
			'platform_event_labels'  => EventToggleMap::labelMatrix( 'woo' ),
			'event_groups'           => EventToggleMap::multiKeyGroups( 'woo' ),
		);
	}

	/**
	 * Compact when every funnel event is enabled (the default). Otherwise
	 * the full per-event boolean map so Claude sees exactly what's off.
	 *
	 * @param mixed $pys PYS settings instance.
	 * @return array<string, mixed>
	 */
	private static function funnelEvents( $pys ): array {
		$map   = array();
		$allOn = true;
		foreach ( self::FUNNEL_KEYS as $event => $key ) {
			$on            = self::toBool( $pys->getOption( $key ) );
			$map[ $event ] = $on;
			if ( !$on ) {
				$allOn = false;
			}
		}

		return $allOn ? array( 'all_enabled' => true ) : $map;
	}

	/**
	 * Lifecycle on/off + threshold. Thresholds are global (`core`) only.
	 *
	 * @param mixed $pys PYS settings instance.
	 * @return array<string, mixed>
	 */
	private static function lifecycleEvents( $pys ): array {
		return array(
			// "NewCustomer" == the FirstTimeBuyer event (NOT
			// `woo_new_customer_enabled`, the Google new-customer parameter).
			'NewCustomer'       => array(
				'enabled'   => self::toBool( $pys->getOption( 'woo_FirstTimeBuyer_enabled' ) ),
				'pys_event' => 'FirstTimeBuyer',
			),
			'ReturningCustomer' => array(
				'enabled' => self::toBool( $pys->getOption( 'woo_ReturningCustomer_enabled' ) ),
			),
			'FrequentShopper'   => array(
				'enabled'      => self::toBool( $pys->getOption( 'woo_frequent_shopper_enabled' ) ),
				'transactions' => (int) $pys->getOption( 'woo_frequent_shopper_transactions', 0 ),
			),
			'VIPClient'         => array(
				'enabled'       => self::toBool( $pys->getOption( 'woo_vip_client_enabled' ) ),
				'transactions'  => (int) $pys->getOption( 'woo_vip_client_transactions', 0 ),
				'average_value' => (float) $pys->getOption( 'woo_vip_client_average_value', 0 ),
			),
			'BigWhale'          => array(
				'enabled' => self::toBool( $pys->getOption( 'woo_big_whale_enabled' ) ),
				'ltv'     => (float) $pys->getOption( 'woo_big_whale_ltv', 0 ),
			),
		);
	}

	/**
	 * content_id lives per-platform. Report a representative active
	 * platform's values; flag `diverges_across_platforms` when active
	 * platforms disagree on any sub-key (dirty / hand-edited state).
	 *
	 * @return array<string, mixed>
	 */
	private static function contentId(): array {
		$settings = Platforms::activeSettings();

		$out = array(
			'source'             => '',
			'prefix'             => '',
			'suffix'             => '',
			'custom_field_name'  => '',
			'logic'              => '',
			'variable_as_simple' => false,
			'wpml_unified_id'    => false,
		);

		if ( !empty( $settings ) ) {
			// Representative = first active platform.
			$slug                        = (string) array_key_first( $settings );
			$first                       = reset( $settings );
			$out[ 'source' ]             = (string) $first->getOption( self::CONTENT_ID_KEYS[ 'source' ], '' );
			$out[ 'prefix' ]             = (string) $first->getOption( self::CONTENT_ID_KEYS[ 'prefix' ], '' );
			$out[ 'suffix' ]             = (string) $first->getOption( self::CONTENT_ID_KEYS[ 'suffix' ], '' );
			$out[ 'custom_field_name' ]  = (string) $first->getOption( self::CONTENT_ID_KEYS[ 'custom_field_name' ], '' );
			$out[ 'logic' ]              = (string) $first->getOption( self::CONTENT_ID_KEYS[ 'logic' ], '' );
			$out[ 'variable_as_simple' ] = self::toBool(
				$first->getOption( self::CONTENT_ID_KEYS[ 'variable_as_simple' ] )
			);
			$out[ 'wpml_unified_id' ]    = self::toBool(
				$first->getOption( self::CONTENT_ID_KEYS[ 'wpml_unified_id' ] )
			);

			if ( 'custom_field' === $out[ 'source' ] ) {
				$scan = self::contentIdScan( $slug );
				if ( null !== $scan ) {
					$out[ 'custom_field_scan' ] = $scan;
				}
				$out[ 'available_custom_field_keys' ] = self::productMetaKeys( 40 );
			}

			$out[ 'diverges_across_platforms' ] = self::contentIdDiverges( $settings );
		}

		$out[ 'facebook_for_woocommerce_active' ] = self::fbForWooActive();

		$out[ 'wpml_active' ] = self::wpmlActive();

		return $out;
	}

	/**
	 * Per-platform content_id values — the genuine per-platform state (each
	 * platform can have a different source/prefix/suffix). GA / Google Ads are
	 * omitted because their content_id is held by the unified `gatags` module.
	 *
	 * @return array<string, array<string, mixed>> slug => { source, prefix, ... }.
	 */
	private static function contentIdByPlatform(): array {
		$out = array();
		foreach ( Platforms::activeSettings() as $slug => $inst ) {
			if ( in_array( $slug, array( 'google_analytics', 'google_ads' ), true ) ) {
				continue; // vestigial — Google content_id lives in `gatags`
			}
			if ( !method_exists( $inst, 'issetOption' ) || !$inst->issetOption( self::CONTENT_ID_KEYS[ 'source' ] ) ) {
				continue;
			}
			$row = array();
			foreach ( self::CONTENT_ID_KEYS as $label => $key ) {
				if ( !$inst->issetOption( $key ) ) {
					continue;
				}
				$val           = $inst->getOption( $key );
				$row[ $label ] = in_array( $label, array( 'variable_as_simple', 'wpml_unified_id' ), true )
					? self::toBool( $val ) : (string) $val;
			}
			// custom_field mode: attach the per-product missing-ID scan report.
			if ( 'custom_field' === ( $row[ 'source' ] ?? '' ) ) {
				$scan = self::contentIdScan( (string) $slug );
				if ( null !== $scan ) {
					$row[ 'custom_field_scan' ] = $scan;
				}
			}
			if ( !empty( $row ) ) {
				$out[ $slug ] = $row;
			}
		}

		return $out;
	}

	/**
	 * The PYS content-ID scan report (custom_field mode) for a platform, reduced
	 * to status + counts. Null when the scanner is unavailable or no report yet.
	 *
	 * @param string $slug Platform slug.
	 * @return array{status: string, total_scanned: int, missing_count: int}|null
	 */
	private static function contentIdScan( string $slug ): ?array {
		if ( '' === $slug || !class_exists( '\\PixelYourSite\\PysContentIdScanner' ) ) {
			return null;
		}
		$rep = \PixelYourSite\PysContentIdScanner::getReport( $slug );
		if ( !is_array( $rep ) || empty( $rep ) ) {
			return null;
		}
		return array(
			'status'        => (string) ( $rep[ 'status' ] ?? '' ),
			'total_scanned' => (int) ( $rep[ 'total_scanned' ] ?? 0 ),
			'missing_count' => isset( $rep[ 'missing' ] ) && is_array( $rep[ 'missing' ] ) ? count( $rep[ 'missing' ] ) : 0,
		);
	}

	/**
	 * Populated product meta keys — the candidates for a `custom_field` content-ID
	 * source. Distinct meta_key over products/variations with a non-empty value,
	 * ranked by how many products carry it (best ID candidates first). Bounded.
	 * Lets the caller answer "which custom fields exist" instead of guessing.
	 *
	 * @param int $limit Max keys to return.
	 * @return array<int, array{key: string, product_count: int}>
	 */
	public static function productMetaKeys( int $limit = 40 ): array {
		global $wpdb;
		$sql  = $wpdb->prepare(
			"SELECT pm.meta_key AS k, COUNT( DISTINCT pm.post_id ) AS c
			 FROM {$wpdb->postmeta} pm
			 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE p.post_type IN ( 'product', 'product_variation' )
			   AND pm.meta_value <> ''
			 GROUP BY pm.meta_key
			 ORDER BY c DESC, pm.meta_key ASC
			 LIMIT %d",
			$limit
		);
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array( 'key' => (string) $r[ 'k' ], 'product_count' => (int) $r[ 'c' ] );
		}
		return $out;
	}

	/**
	 * How many products/variations carry a NON-EMPTY value for a meta key. 0 means
	 * the key is empty everywhere → a content_id sourced from it would be blank.
	 *
	 * @param string $metaKey Meta key.
	 * @return int
	 */
	public static function metaKeyProductCount( string $metaKey ): int {
		if ( '' === $metaKey ) {
			return 0;
		}
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT( DISTINCT pm.post_id )
			 FROM {$wpdb->postmeta} pm
			 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE p.post_type IN ( 'product', 'product_variation' )
			   AND pm.meta_key = %s AND pm.meta_value <> ''",
			$metaKey
		) );
	}

	/**
	 * True when active platforms disagree on any content_id sub-key.
	 *
	 * @param array $settings Active platform settings instances.
	 * @return bool
	 */
	private static function contentIdDiverges( array $settings ): bool {
		$seen = array();
		foreach ( $settings as $inst ) {
			$sig = array();
			foreach ( self::CONTENT_ID_KEYS as $opt ) {
				$sig[] = (string) $inst->getOption( $opt, '' );
			}
			$seen[ implode( '|', $sig ) ] = true;
			if ( count( $seen ) > 1 ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Facebook for WooCommerce plugin active — risk of double-firing pixel events.
	 *
	 * @return bool
	 */
	private static function fbForWooActive(): bool {
		return class_exists( 'WC_Facebookcommerce' ) || function_exists( 'facebook_for_woocommerce' );
	}

	/**
	 * WPML plugin active — gates `wpml_unified_id` editability.
	 *
	 * @return bool
	 */
	private static function wpmlActive(): bool {
		if ( function_exists( '\\PixelYourSite\\isWPMLActive' ) ) {
			return (bool) \PixelYourSite\isWPMLActive();
		}

		return false;
	}

	/**
	 * Coerce a mixed option value to a boolean.
	 *
	 * @param mixed $value Raw option value.
	 * @return bool
	 */
	private static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}