<?php
/**
 * `get_tracking_audit` — single-call health check across every PYS domain,
 * the entry point for a tracking conversation. Returns a `summary` (one
 * status per domain) plus `detail` only for domains that need action.
 * Read-only; never echoes credentials (CAPI tokens show as
 * `configured` / `missing`).
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\Provenance;

final class GetTrackingAuditAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-tracking-audit';

	/**
	 * Pixel/identity platforms: slug => [accessor, main-id key, capi?]. GTM
	 * is included (its `gtm_id` is the identity); its enabled state is
	 * reported separately by the `gtm` domain.
	 */
	private const PIXEL_PLATFORMS = array(
		'facebook'         => array( 'PixelYourSite\\Facebook', 'pixel_id', true ),
		'tiktok'           => array( 'PixelYourSite\\TikTok', 'pixel_id', true ),
		'google_analytics' => array( 'PixelYourSite\\GA', 'tracking_id', true ),
		'pinterest'        => array( 'PixelYourSite\\Pinterest', 'pixel_id', true ),
		'google_ads'       => array( 'PixelYourSite\\Ads', 'ads_ids', false ),
		'bing'             => array( 'PixelYourSite\\Bing', 'pixel_id', false ),
		'reddit'           => array( 'PixelYourSite\\Reddit', 'pixel_id', false ),
		'openai'           => array( 'PixelYourSite\\OpenAI', 'pixel_id', true ),
		'gtm'              => array( 'PixelYourSite\\GTM', 'gtm_id', false ),
	);

	private const SUPERPACK_EXTRA_ACCESSORS = array(
		'facebook'         => 'getFbAdditionalPixel',
		'google_analytics' => 'getGaAdditionalPixel',
	);

	private const EC_PLATFORMS = array(
		'google_ads' => array( 'PixelYourSite\\Ads', 'ads_ids', 'enhanced_conversions_manual_enabled', true ),
		'bing'       => array( 'PixelYourSite\\Bing', 'pixel_id', 'enhanced_conversions_enabled', false ),
	);

	/** DOM advanced-matching dimensions → option key. */
	private const AM_DOM_KEYS = array(
		'first_name' => 'advance_matching_fn_names',
		'last_name'  => 'advance_matching_ln_names',
		'phone'      => 'advance_matching_tel_names',
		'email'      => 'advance_matching_em_names',
	);

	/** URL-param advanced-matching dimensions → option key (for value-quality scan). */
	private const AM_URL_KEYS = array(
		'url_first_name' => 'advance_matching_url_fn_names',
		'url_last_name'  => 'advance_matching_url_ln_names',
		'url_phone'      => 'advance_matching_url_tel_names',
		'url_email'      => 'advance_matching_url_em_names',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Tracking Audit';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Single-call health check across every PYS tracking domain: pixels, server-side credentials (CAPI / Measurement Protocol / Enhanced Conversions), advanced matching, content ID, WooCommerce events, EDD events, custom events, GTM, SuperPack, and recent MCP activity. This is the entry point — call it first in any new conversation about tracking. Two layers: `summary` always has one status per domain (`ok` / `warning` / `incomplete` / `error` / `not_active`; SuperPack & GTM use `active`/`not_active`); `detail` only contains domains that are NOT ok and NOT not_active — healthy / non-applicable domains are absent by design. Use `summary` to decide which domain-specific read tool to call next; do NOT call a domain read tool for a domain shown `ok` or `not_active`. A third optional section `notes` carries informational, non-actionable observations (e.g. a dormant content_id_logic value that currently has no effect, suspicious advanced-matching entries, the catalog-feed alignment reminder) — surface relevant ones but do NOT treat them as errors or as flagged domains. Do not call this tool again after a write — every write tool returns its own confirmation. Credentials are never echoed (tokens show as `configured`/`missing`). The `pixels` domain also flags CONFIGURED-BUT-DISABLED pixels (a pixel with an ID whose master switch is off, so it will not fire): when any exist the domain is `warning` and `detail.pixels.disabled` maps each platform to `primary_disabled` (master switch off → re-enable via `set_platform_credential` `enabled: true`) and/or `extra_disabled_count` (Super Pack extra pixels toggled off → re-enable a specific one via `set_platform_credential` `pixel_index` + `enabled: true`). For any CAPI platform that is NOT fully healthy, its row gains a `state` and a `fix` block: `fix.action` is `generate_token` (external step — open `fix.url`, get the token, then save it via `set_platform_credential`), `enable_capi` (token already saved — just call `set_platform_credential` with `capi_enabled: true`, no external step), or `set_ad_account` (Pinterest only — token+delivery fine, just set `ad_account_id`). Healthy CAPI platforms stay listed for positive confirmation but carry no `state`/`fix`. Use `fix.instructions`/`fix.url` to give the user actionable steps and offer the tool call. The CAPI `token`/`capi_enabled`/`state`/`fix` fields describe each platform\'s PRIMARY pixel. When Super Pack is active and a platform has extra pixels (Facebook/GA4), the row also carries `extra_pixels: {count, capi_gaps, capi_disabled}` (over ENABLED extras): `capi_gaps` = CAPI on but no token (won\'t deliver); `capi_disabled` = a CAPI token is saved but CAPI is OFF (server-side not sending despite a token). When either is > 0 an `extra_pixels.note` is added and the domain is flagged warning — call `get_platform_pixels` for the per-pixel breakdown and fix each by `pixel_index` (`capi_enabled: true`). The CAPI domain also covers Enhanced Conversions (the server-side enrichment for platforms with NO CAPI token): Bing reports a single `enhanced_conversions` (`enabled`/`disabled`); Google Ads EC is PER CONVERSION PIXEL and reports `enhanced_conversions_by_pixel` (`primary` + `extra_pixels[]`, each with `conversion_id`, `enabled` and `enhanced_conversions`). Only ENABLED conversion pixels count toward the EC warning — a DISABLED pixel does not fire, so EC on it is irrelevant and is not flagged (it is still listed, with `enabled: false`, so disabled pixels are visible). When any ENABLED conversion pixel has EC off, the row is flagged `state: enhanced_conversions_off` (all off) or `enhanced_conversions_partial` (some off) + a `fix` (`mcp_writable: true`). EC is a plain PYS toggle (NOT a Google Ads / Microsoft admin action, NOT a token): enable via `set_platform_credential` `enhanced_conversions: true` — for Google Ads pass `pixel_index` to target one conversion pixel or omit it to do all; it is consent-sensitive so the write needs `confirm: true`. Recommended but optional. When a funnel event is disabled, it surfaces under the relevant ecommerce domain — you CAN re-enable it with `set_woo_event_config` / `set_edd_event_config` (the global funnel toggle args, e.g. `purchase`, `initiate_checkout`, `add_to_cart`), after confirming with the user; offer to do it rather than only pointing at the admin. The `custom_events` domain summarises user-defined custom events: `warning` when the master feature `custom_events_enabled` is off (none fire) or when some events have no triggers (can never fire), with `detail` giving counts (total/active/paused) and the trigger-less events — drill in with `get_custom_events` / `get_custom_event` and fix via `set_custom_event` / `manage_custom_event`.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'summary' ),
			'properties' => array(
				'summary' => array( 'type' => 'object', 'additionalProperties' => array( 'type' => 'string' ) ),
				'detail'  => array( 'type' => 'object' ),
				'notes'   => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Informational, non-actionable observations (e.g. a dormant content_id_logic value, suspicious advanced-matching entries). Distinct from `detail`, which is per-domain and only for flagged domains. Surface relevant notes to the user but do not treat them as errors.',
				),
			),
		);
	}

	/**
	 * Build the audit summary / detail / notes across all domains.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;

		$summary = array();
		$detail  = array();
		$notes   = array();

		foreach ( self::domains( $pys ) as $domain => $eval ) {
			$summary[ $domain ] = $eval[ 'status' ];
			// `detail`: actionable, only for flagged domains.
			if ( !in_array( $eval[ 'status' ], array( 'ok', 'not_active', 'active' ), true )
			     && !empty( $eval[ 'detail' ] ) ) {
				$detail[ $domain ] = $eval[ 'detail' ];
			}
			// `notes`: informational, surfaced regardless of status.
			if ( !empty( $eval[ 'notes' ] ) ) {
				foreach ( $eval[ 'notes' ] as $n ) {
					$notes[] = $n;
				}
			}
		}

		$out = array( 'summary' => $summary );
		if ( !empty( $detail ) ) {
			$out[ 'detail' ] = $detail;
		}
		if ( !empty( $notes ) ) {
			$out[ 'notes' ] = $notes;
		}

		return $out;
	}

	/**
	 * Evaluate every domain → [status, detail].
	 *
	 * @param mixed $pys
	 * @return array<string, array{status:string, detail:array|null}>
	 */
	private static function domains( $pys ): array {
		$wcActive  = function_exists( '\\PixelYourSite\\isWooCommerceActive' ) && \PixelYourSite\isWooCommerceActive();
		$eddActive = function_exists( '\\PixelYourSite\\isEddActive' ) && \PixelYourSite\isEddActive();

		return array(
			'pixels'                 => self::evalPixels(),
			'capi'                   => self::evalCapi(),
			'advanced_matching'      => self::evalAdvancedMatching( $pys ),
			'content_id'             => self::evalContentId( $wcActive, $eddActive ),
			'woo_events'             => self::evalEcommerce( $pys, $wcActive, 'woo' ),
			'edd_events'             => self::evalEcommerce( $pys, $eddActive, 'edd' ),
			'custom_events'          => self::evalCustomEvents( $pys ),
			'catalog_feed_alignment' => self::evalCatalogFeedAlignment(),
			'edd_feed_alignment'     => self::evalEddFeedAlignment(),
			'woo_reports'            => self::evalReports( 'woo' ),
			'edd_reports'            => self::evalReports( 'edd' ),
			'gtm'                    => self::evalGtm(),
			'superpack'              => self::evalSuperPack(),
			'mcp_activity'           => self::evalMcpActivity(),
		);
	}

	/**
	 * Pixels: which platforms have a main id.
	 *
	 * @return array<string, mixed>
	 */
	private static function evalPixels(): array {
		$present  = array();
		$disabled = array();
		foreach ( self::PIXEL_PLATFORMS as $slug => $spec ) {
			$has              = self::hasId( $spec[ 0 ], $spec[ 1 ] );
			$present[ $slug ] = $has;
			if ( !$has ) {
				continue;
			}

			$entry = array();
			if ( 'gtm' !== $slug ) {
				$inst = self::instance( $spec[ 0 ] );
				$raw  = $inst ? $inst->getOption( 'main_pixel_enabled' ) : null;
				if ( null !== $raw && !self::toBool( $raw ) ) {
					$entry[ 'primary_disabled' ] = true;
				}
			}
			// Super Pack EXTRA pixels that are configured but toggled off.
			$extraOff = self::disabledExtraPixels( $slug );
			if ( $extraOff > 0 ) {
				$entry[ 'extra_disabled_count' ] = $extraOff;
			}
			if ( !empty( $entry ) ) {
				$disabled[ $slug ] = $entry;
			}
		}
		$any = in_array( true, $present, true );

		if ( !$any ) {
			return array( 'status' => 'incomplete', 'detail' => array( 'pixel_present' => $present ) );
		}
		if ( !empty( $disabled ) ) {
			return array(
				'status' => 'warning',
				'detail' => array(
					'pixel_present' => $present,
					'disabled'      => $disabled,
					'note'          => 'These configured pixels are TURNED OFF and will NOT fire. `primary_disabled` = the platform master switch is off — re-enable via set_platform_credential with `enabled: true` (or in the admin). `extra_disabled_count` = how many Super Pack EXTRA pixels are toggled off — re-enable a specific one via set_platform_credential with its `pixel_index` + `enabled: true` (see get_platform_pixels for the per-pixel breakdown).',
				),
			);
		}

		return array(
			'status' => 'ok',
			'detail' => array( 'pixel_present' => $present ),
		);
	}

	/**
	 * Count Super Pack EXTRA pixels that are configured (non-empty id) but
	 * toggled OFF (`isEnable` false) for Facebook / GA4 / Google Ads. 0 when
	 * Super Pack is inactive or the platform has no extra pixels.
	 *
	 * @param string $slug Platform slug.
	 * @return int
	 */
	private static function disabledExtraPixels( string $slug ): int {
		$map = array(
			'facebook'         => 'getFbAdditionalPixel',
			'google_analytics' => 'getGaAdditionalPixel',
			'google_ads'       => 'getAdsAdditionalPixel',
		);
		$method = $map[ $slug ] ?? null;
		if ( null === $method ) {
			return 0;
		}
		if ( !function_exists( '\\PixelYourSite\\isSuperPackActive' ) || !\PixelYourSite\isSuperPackActive() ) {
			return 0;
		}
		if ( !function_exists( '\\PixelYourSite\\SuperPack' ) ) {
			return 0;
		}
		$sp = \PixelYourSite\SuperPack();
		if ( !is_object( $sp ) || !method_exists( $sp, 'getOption' ) || !self::toBool( $sp->getOption( 'additional_ids_enabled' ) ) ) {
			return 0;
		}
		if ( !method_exists( $sp, $method ) ) {
			return 0;
		}
		$n = 0;
		foreach ( (array) $sp->$method() as $p ) {
			if ( !is_object( $p ) ) {
				continue;
			}
			$id = isset( $p->pixel ) ? trim( (string) $p->pixel ) : '';
			if ( '' === $id ) {
				continue; // unconfigured slot
			}
			if ( empty( $p->isEnable ) ) {
				$n++;
			}
		}

		return $n;
	}

	/**
	 * CAPI / server-side: for CAPI-capable platforms that HAVE a pixel,
	 * is the token configured + delivery enabled? Token never echoed.
	 *
	 * @return array<string, mixed>
	 */
	private static function evalCapi(): array {
		$rows    = array();
		$warning = false;
		foreach ( self::PIXEL_PLATFORMS as $slug => $spec ) {
			if ( !$spec[ 2 ] ) {
				continue; // platform has no server-side token (ads/bing/reddit/gtm)
			}
			if ( !self::hasId( $spec[ 0 ], $spec[ 1 ] ) ) {
				continue;
			}
			$inst     = self::instance( $spec[ 0 ] );
			$tokenSet = $inst && self::hasValue( $inst->getOption( 'server_access_api_token' ) );
			$capiOn   = $inst && self::toBool( $inst->getOption( 'use_server_api' ) );

			$row = array(
				'token'        => $tokenSet ? 'configured' : 'missing',
				'capi_enabled' => $capiOn,
			);

			$adAccountSet = true;
			if ( 'pinterest' === $slug ) {
				$adAccountSet           = $inst && self::hasValue( $inst->getOption( 'ad_account_id' ) );
				$row[ 'ad_account_id' ] = $adAccountSet ? 'configured' : 'missing';
			}

			$healthy = $tokenSet && $capiOn && $adAccountSet;
			if ( !$healthy ) {
				$warning        = true;
				$state          = self::capiState( $slug, $tokenSet, $capiOn, $adAccountSet );
				$row[ 'state' ] = $state;
				$row[ 'fix' ]   = self::capiFixGuidance( $slug, $state, $inst );
			}

			$extra = self::capiExtraSummary( $slug );
			if ( $extra[ 'count' ] > 0 ) {
				$row[ 'extra_pixels' ] = array(
					'count'         => $extra[ 'count' ],
					'capi_gaps'     => $extra[ 'capi_gaps' ],
					'capi_disabled' => $extra[ 'capi_disabled' ],
				);
				$issues = array();
				if ( $extra[ 'capi_gaps' ] > 0 ) {
					$issues[] = sprintf( '%d have CAPI enabled but NO token (server-side will not deliver)', $extra[ 'capi_gaps' ] );
				}
				if ( $extra[ 'capi_disabled' ] > 0 ) {
					$issues[] = sprintf( '%d have a CAPI token saved but CAPI is OFF (server-side not sending — enable with set_platform_credential `capi_enabled: true` + the pixel_index)', $extra[ 'capi_disabled' ] );
				}
				if ( !empty( $issues ) ) {
					$row[ 'extra_pixels' ][ 'note' ] = 'Among enabled extra pixels: ' . implode( '; ', $issues )
					                                   . '. Call get_platform_pixels for the per-pixel breakdown (pixel_index, token), then fix each by pixel_index (>= 1).';
					$warning = true;
				}
			}

			$rows[ $slug ] = $row;
		}

		foreach ( self::EC_PLATFORMS as $slug => $spec ) {
			list( $fn, $idKey, $ecKey, $isMarker ) = $spec;
			if ( 'bing' === $slug && ( !function_exists( '\\PixelYourSite\\isBingActive' ) || !\PixelYourSite\isBingActive() ) ) {
				continue; // addon inactive
			}
			if ( !self::hasId( $fn, $idKey ) ) {
				continue; // no pixel/conversion → EC not expected
			}
			$inst = self::instance( $fn );

			if ( $isMarker ) {
				$byPixel = self::adsEcByPixel( $inst );
				$row     = array( 'enhanced_conversions_by_pixel' => $byPixel );

				$anyOff = false;
				$anyOn  = false;
				$rate   = static function( $e ) use ( &$anyOff, &$anyOn ) {
					if ( empty( $e[ 'enabled' ] ) ) {
						return; // disabled pixel → not firing → ignore for EC warning
					}
					'disabled' === $e[ 'enhanced_conversions' ] ? $anyOff = true : $anyOn = true;
				};
				if ( isset( $byPixel[ 'primary' ] ) ) {
					$rate( $byPixel[ 'primary' ] );
				}
				foreach ( $byPixel[ 'extra_pixels' ] ?? array() as $e ) {
					$rate( $e );
				}
				if ( $anyOff ) {
					$row[ 'state' ] = $anyOn ? 'enhanced_conversions_partial' : 'enhanced_conversions_off';
					$row[ 'fix' ]   = self::ecFixGuidance( $slug );
					$warning        = true;
				}
				$rows[ $slug ] = $row;
				continue;
			}

			// Bing: single platform-wide checkbox bool.
			$ecOn = self::toBool( $inst ? $inst->getOption( $ecKey ) : null );
			$row  = array( 'enhanced_conversions' => $ecOn ? 'enabled' : 'disabled' );
			if ( !$ecOn ) {
				$row[ 'state' ] = 'enhanced_conversions_off';
				$row[ 'fix' ]   = self::ecFixGuidance( $slug );
				$warning        = true;
			}
			$rows[ $slug ] = $row;
		}

		if ( empty( $rows ) ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		return array(
			'status' => $warning ? 'warning' : 'ok',
			'detail' => array( 'platforms' => $rows ),
		);
	}

	/**
	 * Fix guidance for a platform whose Enhanced Conversions are off. There is
	 * no MCP write tool for the EC toggle, so the fix is admin-only. EC is
	 * recommended but optional (it sends hashed first-party data → needs consent).
	 *
	 * @param string $slug Platform slug (google_ads | bing).
	 * @return array<string, mixed>
	 */
	private static function ecFixGuidance( string $slug ): array {
		if ( 'google_ads' === $slug ) {
			return array(
				'action'        => 'enable_enhanced_conversions',
				'instructions'  => 'One or more Google Ads conversion pixels have Enhanced Conversions OFF (see enhanced_conversions_by_pixel for which). EC sends hashed first-party data to improve match quality — a plain PixelYourSite toggle, NOT a Google Ads admin action and NOT a token. It is PER conversion pixel: call set_platform_credential with platform: google_ads, enhanced_conversions: true and `pixel_index` (0 = primary, 1..N = extra) to enable ONE, or OMIT pixel_index to enable ALL at once. Consent-sensitive → the call needs confirm: true (hashed user data). Recommended but optional.',
				'admin_ui_path' => 'PixelYourSite → Google Ads → "Enable enhanced conversions" (per pixel)',
				'mcp_writable'  => true,
			);
		}

		return array(
			'action'        => 'enable_enhanced_conversions',
			'instructions'  => 'The Bing / Microsoft UET tag is set but Enhanced Conversions is OFF — it sends hashed first-party data to improve conversion match quality. A plain PixelYourSite toggle (NOT a Microsoft admin action, NOT a token): call set_platform_credential with platform: bing and enhanced_conversions: true (single platform-wide switch). Consent-sensitive → needs confirm: true. Recommended but optional.',
			'admin_ui_path' => 'PixelYourSite → Bing → Enhanced Conversions',
			'mcp_writable'  => true,
		);
	}

	/**
	 * Classify a CAPI gap into a single state string. Only called for
	 * non-healthy platforms. `ad_account_missing` is Pinterest-only (token +
	 * delivery are both fine, the Ad Account ID is the only thing missing).
	 *
	 * @param string $slug         Platform slug.
	 * @param bool   $tokenSet     Token is present and non-empty.
	 * @param bool   $capiOn       use_server_api is true.
	 * @param bool   $adAccountSet Pinterest Ad Account ID is present (always true for other platforms).
	 * @return string
	 */
	private static function capiState( string $slug, bool $tokenSet, bool $capiOn, bool $adAccountSet ): string {
		if ( !$tokenSet && !$capiOn ) {
			return 'token_missing_capi_disabled';
		}
		if ( !$tokenSet ) {
			return 'token_missing';
		}
		if ( !$capiOn ) {
			return 'capi_disabled';
		}
		// token present + delivery on → the only remaining gap is Pinterest's Ad Account ID.
		return 'ad_account_missing';
	}

	/**
	 * Build the actionable fix block for a flagged CAPI platform.
	 *   - generate_token: external step (platform dashboard) then save via set_platform_credential.
	 *   - enable_capi:     token already saved, just flip use_server_api via set_platform_credential.
	 *   - set_ad_account:  Pinterest token + delivery are fine, only ad_account_id is missing.
	 * Token values are never echoed.
	 *
	 * @param string      $slug  Platform slug (facebook, tiktok, google_analytics, pinterest).
	 * @param string      $state One of token_missing_capi_disabled | token_missing | capi_disabled | ad_account_missing.
	 * @param object|null $inst  Platform singleton (used to read the pixel ID for deep links / missing checks).
	 * @return array<string, mixed>
	 */
	private static function capiFixGuidance( string $slug, string $state, $inst ): array {
		// Delivery toggle off, but the token is already saved — enable via tool, no external step.
		if ( 'capi_disabled' === $state ) {
			// Pinterest may ALSO be missing its Ad Account ID — fold it into the same call.
			if ( 'pinterest' === $slug && ( !$inst || !self::hasValue( $inst->getOption( 'ad_account_id' ) ) ) ) {
				return array(
					'action'           => 'enable_capi',
					'instructions'     => 'Token is saved but server-side delivery is off AND the Ad Account ID is missing. Call set_platform_credential with capi_enabled: true and ad_account_id (shown top-left of Pinterest Business Hub, format 549…) — both are required for delivery.',
					'missing'          => array( 'Ad Account ID' ),
					'url'              => 'https://www.pinterest.com/business/hub/',
					'token_shown_once' => null,
				);
			}
			return array(
				'action'           => 'enable_capi',
				'instructions'     => 'Token is already saved. Call set_platform_credential with capi_enabled: true for this platform — no need to re-enter the token.',
				'url'              => null,
				'token_shown_once' => null,
			);
		}

		// Pinterest token + delivery are fine, only the Ad Account ID is missing — tool fix, no external token.
		if ( 'ad_account_missing' === $state ) {
			return array(
				'action'           => 'set_ad_account',
				'instructions'     => 'CAPI is enabled with a valid token, but the Ad Account ID is missing — the Pinterest Conversions API will not deliver until it is set. Find it top-left of Pinterest Business Hub (format 549…) and call set_platform_credential with ad_account_id.',
				'missing'          => array( 'Ad Account ID' ),
				'url'              => 'https://www.pinterest.com/business/hub/',
				'token_shown_once' => null,
			);
		}

		switch ( $slug ) {
			case 'facebook':
				$rawId   = $inst ? $inst->getOption( 'pixel_id' ) : null;
				$pixelId = '';
				if ( is_array( $rawId ) ) {
					foreach ( $rawId as $v ) {
						if ( is_string( $v ) && '' !== trim( $v ) ) {
							$pixelId = trim( $v );
							break;
						}
					}
				} elseif ( is_string( $rawId ) && '' !== trim( $rawId ) ) {
					$pixelId = trim( $rawId );
				}
				$url = $pixelId
					? 'https://business.facebook.com/events_manager2/list/pixel/' . rawurlencode( $pixelId ) . '/settings'
					: 'https://business.facebook.com/events_manager2/';
				return array(
					'action'           => 'generate_token',
					'instructions'     => 'Meta Events Manager → your pixel → Settings → Conversions API → Generate access token. Copy the token (shown once) then call set_platform_credential with platform: facebook and the token value.',
					'url'              => $url,
					'token_shown_once' => true,
				);

			case 'tiktok':
				return array(
					'action'           => 'generate_token',
					'instructions'     => 'TikTok Events Manager → your pixel → Settings → Events API → Generate access token. Token is shown once — save it before closing the dialog.',
					'url'              => 'https://ads.tiktok.com/i18n/events_manager/',
					'token_shown_once' => true,
				);

			case 'openai':
				return array(
					'action'           => 'generate_token',
					'instructions'     => 'OpenAI Ads Manager → Conversions → Data source → the "Save your key" dialog issues the Conversions API key (and the Pixel ID). Shown once, and no endpoint lists existing keys. Register each conversion event in Conversions → Conversion events as well, or events are accepted but never counted.',
					'url'              => 'https://ads.openai.com/',
					'token_shown_once' => true,
				);

			case 'google_analytics':
				return array(
					'action'           => 'generate_token',
					'instructions'     => 'GA4 → Admin → Data Streams → [your stream] → Measurement Protocol API secrets → Create. Copy the Secret value (not the Measurement ID — those are different things).',
					'url'              => 'https://analytics.google.com',
					'token_shown_once' => false,
				);

			case 'pinterest':
				$missingToken = !$inst || !self::hasValue( $inst->getOption( 'server_access_api_token' ) );
				$missingAcct  = !$inst || !self::hasValue( $inst->getOption( 'ad_account_id' ) );
				$missing      = array();
				if ( $missingToken ) {
					$missing[] = 'access token';
				}
				if ( $missingAcct ) {
					$missing[] = 'Ad Account ID';
				}
				if ( $missingToken && $missingAcct ) {
					$pinInstr = 'Pinterest Business Hub → Conversions → Conversions API → Generate token. Also note your Ad Account ID (top-left of the Business Hub, format 549…). BOTH are missing and required — call set_platform_credential with the token AND ad_account_id.';
				} elseif ( $missingToken ) {
					$pinInstr = 'Pinterest Business Hub → Conversions → Conversions API → Generate token. The Ad Account ID is ALREADY configured — do NOT ask the user for it. Get only the token and call set_platform_credential with it (delivery turns on automatically).';
				} else {
					$pinInstr = 'The access token is already saved; only the Ad Account ID is missing. Find it top-left of Pinterest Business Hub (format 549…) and call set_platform_credential with ad_account_id — no need to re-enter the token.';
				}
				return array(
					'action'           => 'generate_token',
					'instructions'     => $pinInstr,
					'missing'          => $missing,
					'url'              => 'https://www.pinterest.com/business/hub/',
					'token_shown_once' => true,
				);
		}

		// Fallback — should not be reached for supported CAPI platforms.
		return array(
			'action'           => 'generate_token',
			'instructions'     => '',
			'url'              => null,
			'token_shown_once' => null,
		);
	}

	/**
	 * Summarise a platform's Super Pack extra pixels' CAPI health. Counts (over
	 * ENABLED extras only — a disabled pixel doesn't fire, so its CAPI is moot):
	 *   - `count`        : configured extras (incl. disabled, for acknowledgement)
	 *   - `capi_gaps`    : CAPI ON but NO token → server-side won't deliver
	 *   - `capi_disabled`: token saved but CAPI OFF → server-side not sending despite a token
	 * Only Facebook and GA4 have CAPI-capable extra pixels; others return zeros.
	 * Full per-pixel breakdown stays in get_platform_pixels — this only powers the flag.
	 *
	 * @param string $slug Platform slug.
	 * @return array{count:int, capi_gaps:int, capi_disabled:int}
	 */
	private static function capiExtraSummary( string $slug ): array {
		$empty  = array( 'count' => 0, 'capi_gaps' => 0, 'capi_disabled' => 0 );
		$method = self::SUPERPACK_EXTRA_ACCESSORS[ $slug ] ?? null;
		if ( null === $method ) {
			return $empty;
		}
		if ( !function_exists( '\\PixelYourSite\\isSuperPackActive' ) || !\PixelYourSite\isSuperPackActive() ) {
			return $empty;
		}
		if ( !function_exists( '\\PixelYourSite\\SuperPack' ) ) {
			return $empty;
		}
		$sp = \PixelYourSite\SuperPack();
		if ( !is_object( $sp ) || !method_exists( $sp, 'getOption' ) || !self::toBool( $sp->getOption( 'additional_ids_enabled' ) ) ) {
			return $empty;
		}
		if ( !method_exists( $sp, $method ) ) {
			return $empty;
		}

		$count    = 0;
		$gaps     = 0;
		$disabled = 0;
		foreach ( (array) $sp->$method() as $pixel ) {
			if ( !is_object( $pixel ) ) {
				continue;
			}
			$id = isset( $pixel->pixel ) ? trim( (string) $pixel->pixel ) : '';
			if ( '' === $id ) {
				continue; // unconfigured slot → not a real extra pixel
			}
			$count++;
			if ( empty( $pixel->isEnable ) ) {
				continue; // pixel itself disabled → not firing → CAPI state is moot
			}
			$capiOn = !empty( $pixel->isUseServerApi );

			$stdToken = isset( $pixel->server_access_api_token ) ? trim( (string) $pixel->server_access_api_token ) : '';
			$extToken = is_array( $pixel->extensions ?? null ) && isset( $pixel->extensions[ 'api_token' ] )
				? trim( (string) $pixel->extensions[ 'api_token' ] ) : '';
			$hasToken = ( '' !== $stdToken || '' !== $extToken );
			if ( $capiOn && !$hasToken ) {
				$gaps++; // CAPI on but no token → won't deliver
			} elseif ( !$capiOn && $hasToken ) {
				$disabled++; // token saved but CAPI off → server-side not sending
			}
		}

		return array( 'count' => $count, 'capi_gaps' => $gaps, 'capi_disabled' => $disabled );
	}

	/**
	 * Ordered Google Ads conversion pixels: primary (index 0, first non-empty
	 * `ads_ids`) then each stored Super Pack extra (index 1..N). Index aligns with
	 * the EC marker "index_N" and the MCP pixel_index. Each entry carries `enabled`
	 * (primary: main_pixel_enabled, default on; extra: isEnable) — a disabled pixel
	 * does not fire, so EC on it is moot.
	 *
	 * @param object|null $settings Ads Settings instance.
	 * @return array<int, array{index:int, conversion_id:string, enabled:bool}>
	 */
	private static function adsConversionPixels( $settings ): array {
		$out = array();
		if ( !is_object( $settings ) || !method_exists( $settings, 'getOption' ) ) {
			return $out;
		}
		$primaryId = '';
		foreach ( (array) $settings->getOption( 'ads_ids' ) as $v ) {
			if ( is_string( $v ) && '' !== trim( $v ) ) {
				$primaryId = trim( $v );
				break;
			}
		}
		if ( '' !== $primaryId ) {
			$rawEn = $settings->getOption( 'main_pixel_enabled' );
			$out[] = array(
				'index'         => 0,
				'conversion_id' => $primaryId,
				'enabled'       => ( null === $rawEn ) ? true : self::toBool( $rawEn ),
			);
		}
		if ( function_exists( '\\PixelYourSite\\isSuperPackActive' ) && \PixelYourSite\isSuperPackActive()
		     && function_exists( '\\PixelYourSite\\SuperPack' ) ) {
			$sp = \PixelYourSite\SuperPack();
			if ( is_object( $sp ) && method_exists( $sp, 'getAdsAdditionalPixel' ) ) {
				$i = 1;
				foreach ( (array) $sp->getAdsAdditionalPixel() as $p ) {
					$id = ( is_object( $p ) && isset( $p->pixel ) ) ? trim( (string) $p->pixel ) : '';
					if ( '' !== $id ) {
						$out[] = array(
							'index'         => $i,
							'conversion_id' => $id,
							'enabled'       => !empty( $p->isEnable ),
						);
					}
					$i++;
				}
			}
		}

		return $out;
	}

	/**
	 * Per-pixel Enhanced Conversions state for Google Ads, derived from the
	 * "index_P" marker array. Shape: { primary: {conversion_id, enabled, enhanced_conversions},
	 * extra_pixels: [{pixel_index, conversion_id, enabled, enhanced_conversions}] }.
	 *
	 * @param object|null $settings Ads Settings instance.
	 * @return array<string, mixed>
	 */
	private static function adsEcByPixel( $settings ): array {
		$markers = array();
		if ( is_object( $settings ) && method_exists( $settings, 'getOption' ) ) {
			foreach ( (array) $settings->getOption( 'enhanced_conversions_manual_enabled' ) as $v ) {
				if ( is_string( $v ) ) {
					$markers[ $v ] = true;
				}
			}
		}
		$res = array();
		foreach ( self::adsConversionPixels( $settings ) as $p ) {
			$state = isset( $markers[ 'index_' . $p[ 'index' ] ] ) ? 'enabled' : 'disabled';
			if ( 0 === $p[ 'index' ] ) {
				$res[ 'primary' ] = array( 'conversion_id' => $p[ 'conversion_id' ], 'enabled' => $p[ 'enabled' ], 'enhanced_conversions' => $state );
			} else {
				$res[ 'extra_pixels' ][] = array(
					'pixel_index'          => $p[ 'index' ],
					'enabled'              => $p[ 'enabled' ],
					'conversion_id'        => $p[ 'conversion_id' ],
					'enhanced_conversions' => $state,
				);
			}
		}

		return $res;
	}

	/**
	 * Advanced matching: DOM gaps. Auto-coverage noted.
	 *
	 * @param mixed $pys
	 * @return array<string, mixed>
	 */
	private static function evalAdvancedMatching( $pys ): array {
		if ( null === $pys ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}
		$gaps = array();
		foreach ( self::AM_DOM_KEYS as $dim => $key ) {
			$v     = $pys->getOption( $key, array() );
			$clean = is_array( $v ) ? array_filter( $v, static function( $x ) {
				return is_string( $x ) && '' !== trim( $x );
			} ) : array();
			if ( empty( $clean ) ) {
				$gaps[] = $dim;
			}
		}
		// Flag values that can't be valid field/param names (`@` or numeric)
		// across all 8 lists. Informational only — does not change status.
		$suspicious = array();
		foreach ( array_merge( self::AM_DOM_KEYS, self::AM_URL_KEYS ) as $dim => $key ) {
			$v = $pys->getOption( $key, array() );
			if ( !is_array( $v ) ) {
				continue;
			}
			foreach ( $v as $val ) {
				if ( !is_string( $val ) ) {
					continue;
				}
				$val = trim( $val );
				if ( '' === $val ) {
					continue;
				}
				if ( false !== strpos( $val, '@' ) || ctype_digit( $val ) ) {
					$suspicious[] = $dim . ': ' . $val;
				}
			}
		}
		$notes = array();
		if ( !empty( $suspicious ) ) {
			$notes[] = 'Advanced matching contains entries that don\'t look like valid form-field / URL-param names (an `@` means an actual email value was pasted instead of a parameter name; purely numeric values are unlikely field names): '
			           . implode( ', ', $suspicious )
			           . '. These don\'t break tracking (they just never match) but clutter the config. You CAN remove them via `set_advanced_matching_fields` with `mode: remove` (pass each bogus value under its list, e.g. `url_email_params: ["dxdfg@dsf.gfh"]`) after confirming with the user — offer to do it rather than only pointing at the admin (PixelYourSite → Global Settings → "Advanced user-data detections").';
		}

		if ( empty( $gaps ) ) {
			return array( 'status' => 'ok', 'detail' => null, 'notes' => $notes );
		}

		return array(
			'status' => 'incomplete',
			'detail' => array(
				'dom_gaps'           => $gaps,
				'automatic_coverage' => 'Logged-in users and WooCommerce/EDD customers are matched automatically from account/order data. The gaps above only affect anonymous form visitors — use scan_page_for_form_fields + set_advanced_matching_fields if that audience matters.',
				'what_reaches_each_platform' => 'These gaps are about what is COLLECTED from forms, not about what any platform receives — the two are different questions. Each platform also has its own matching switch, and where PYS has a verified list of the fields a platform transmits, `get_advanced_matching_config` reports it per platform as `fields_sent`. Read that before telling the user what leaves their site for a given platform.',
			),
			'notes'  => $notes,
		);
	}

	/**
	 * Content ID. Always `ok` when ecommerce is active (no server-detectable
	 * failure), plus informational notes: dormant `facebook_for_woocommerce`
	 * logic, and a catalog-feed alignment reminder.
	 *
	 * @param bool $wcActive
	 * @param bool $eddActive
	 * @return array<string, mixed>
	 */
	private static function evalContentId( bool $wcActive, bool $eddActive ): array {
		if ( !$wcActive && !$eddActive ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}
		$notes = array();

		$fbForWoo = class_exists( 'WC_Facebookcommerce' ) || function_exists( 'facebook_for_woocommerce' );
		$fb       = self::instance( 'PixelYourSite\\Facebook' );
		if ( $wcActive && $fb && 'facebook_for_woocommerce' === (string) $fb->getOption( 'woo_content_id_logic' )
		     && !$fbForWoo ) {
			$notes[] = 'WooCommerce content_id_logic is stored as `facebook_for_woocommerce`, but the Facebook for WooCommerce plugin is inactive — PYS currently uses DEFAULT logic, so content IDs generate normally (no problem right now). The stored value is dormant: if you later activate Facebook for WooCommerce it will switch to that plugin\'s logic. To clear it, set content_id_logic to `default`.';
		}

		// Catalog-feed alignment — the one content-id risk PYS can't detect.
		$notes[] = 'Content-ID reminder: confirm your platform catalog feed uses the SAME content_id source (product/download id vs SKU) and prefix/suffix that PYS sends — a mismatch makes dynamic ads show wrong items. PYS cannot see the feed, so verify it in the platform catalog manager.';

		return array( 'status' => 'ok', 'detail' => null, 'notes' => $notes );
	}

	/**
	 * Woo / EDD: not_active if the platform is off; warning if any funnel
	 * event is disabled; ok otherwise.
	 *
	 * @param mixed  $pys
	 * @param bool   $active
	 * @param string $prefix
	 * @return array<string, mixed>
	 */
	private static function evalEcommerce( $pys, bool $active, string $prefix ): array {
		if ( null === $pys || !$active ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}
		$funnelKeys = 'woo' === $prefix ? array(
			'woo_view_content_enabled',
			'woo_add_to_cart_enabled',
			'woo_initiate_checkout_enabled',
			'woo_purchase_enabled',
			'woo_view_cart_enabled',
			'woo_view_item_list_enabled',
			'woo_remove_from_cart_enabled',
			'woo_checkout_steps_enabled',
		) : array(
			'edd_view_content_enabled',
			'edd_view_category_enabled',
			'edd_add_to_cart_enabled',
			'edd_initiate_checkout_enabled',
			'edd_purchase_enabled',
			'edd_remove_from_cart_enabled'
		);

		$disabled = array();
		foreach ( $funnelKeys as $key ) {
			if ( !self::toBool( $pys->getOption( $key ) ) ) {
				$disabled[] = $key;
			}
		}
		if ( empty( $disabled ) ) {
			return array( 'status' => 'ok', 'detail' => null );
		}
		$path    = 'woo'
		        === $prefix ? 'PixelYourSite → WooCommerce → Events' : 'PixelYourSite → Easy Digital Downloads → Events';
		$setTool = 'woo' === $prefix ? 'set_woo_event_config' : 'set_edd_event_config';

		return array(
			'status' => 'warning',
			'detail' => array(
				'disabled_funnel_events' => $disabled,
				'note'                   => sprintf(
					'These funnel events are off. They ARE re-enableable via `%s` (pass the funnel toggle arg, e.g. `purchase`/`initiate_checkout`/`add_to_cart`) after user confirmation — offer to do it. Or the user can toggle them manually in the admin.',
					$setTool
				),
				'admin_ui_path'          => $path,
			),
		);
	}

	/**
	 * Custom events: not_active when none exist; warning when the master feature
	 * is off (none fire) or some events have no triggers (can never fire); ok
	 * otherwise. Counts are over all events (active + paused).
	 *
	 * @param mixed $pys
	 * @return array<string, mixed>
	 */
	private static function evalCustomEvents( $pys ): array {
		if ( !class_exists( '\\PixelYourSite\\CustomEventFactory' ) ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}
		$events = (array) \PixelYourSite\CustomEventFactory::get( 'any' );
		$total  = count( $events );
		if ( 0 === $total ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		$feature    = null !== $pys && self::toBool( $pys->getOption( 'custom_events_enabled' ) );
		$paused     = 0;
		$noTriggers = array();
		foreach ( $events as $event ) {
			if ( !is_object( $event ) ) {
				continue;
			}
			if ( !(bool) $event->__get( 'enabled' ) ) {
				$paused++;
			}
			$triggers = method_exists( $event, 'getTriggers' ) && is_array( $event->getTriggers() ) ? $event->getTriggers() : array();
			if ( empty( $triggers ) ) {
				$noTriggers[] = array( 'event_id' => (int) $event->getPostId(), 'title' => (string) $event->getTitle() );
			}
		}

		$detail = array(
			'feature_enabled' => $feature,
			'total'           => $total,
			'active'          => $total - $paused,
			'paused'          => $paused,
		);
		$warning = false;
		if ( !$feature ) {
			$warning                  = true;
			$detail[ 'note_feature' ] = 'The custom-events master feature (custom_events_enabled) is OFF — none of these events fire regardless of their own state. Enable it in PixelYourSite → Events.';
		}
		if ( !empty( $noTriggers ) ) {
			$warning                   = true;
			$detail[ 'without_triggers' ] = $noTriggers;
			$detail[ 'note_triggers' ]    = sprintf( '%d custom event(s) have no triggers and can never fire — add a trigger with set_custom_event, or remove the event with manage_custom_event.', count( $noTriggers ) );
		}
		$detail[ 'tools' ] = 'get_custom_events (list) → get_custom_event (detail) → set_custom_event (edit) / manage_custom_event (enable/disable/duplicate/delete).';

		return array( 'status' => $warning ? 'warning' : 'ok', 'detail' => $detail );
	}

	/**
	 * Catalog feed alignment: does PYS's content-ID format match the Product
	 * Catalog Feed plugin's feed(s)? Delegates to GetCatalogFeedAlignmentAbility
	 * and reduces to a status. `ok` requires EVERY feed to be `recommendation:
	 * none` — a feed that matches while using product_sku (matches_but_sku_risk)
	 * or one PYS sends via custom_field (custom_field_not_comparable) still needs
	 * surfacing, so the user has a signal to call get_catalog_feed_alignment.
	 *
	 * @return array{status: string, detail: array|null}
	 */
	private static function evalCatalogFeedAlignment(): array {

		if ( !function_exists( '\\PixelYourSite\\isWooCommerceActive' ) || !\PixelYourSite\isWooCommerceActive()
			|| !GetCatalogFeedAlignmentAbility::feedPluginActive() ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		$result = GetCatalogFeedAlignmentAbility::execute( array() );
		if ( empty( $result[ 'available' ] ) || empty( $result[ 'feeds' ] ) ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		$flagged = array();
		foreach ( $result[ 'feeds' ] as $f ) {
			if ( 'none' === ( $f[ 'recommendation' ] ?? '' ) ) {
				continue;
			}
			$flagged[] = array(
				'feed_name'      => $f[ 'feed_name' ] ?? '',
				'feed_type'      => $f[ 'feed_type' ] ?? '',
				'recommendation' => $f[ 'recommendation' ] ?? '',
			);
		}

		if ( empty( $flagged ) ) {
			return array( 'status' => 'ok', 'detail' => null );
		}

		return array( 'status' => 'warning', 'detail' => array( 'flagged_feeds' => $flagged ) );
	}

	/**
	 * EDD feed alignment: does PYS's EDD content-ID format match what EDD Products
	 * Feed Pro sends to Google Merchant Center? Delegates to
	 * GetEddFeedAlignmentAbility.
	 * not_active — EDD or the feed plugin absent, or no feeds configured.
	 * ok         — content_id matches (or only legacy feeds exist). Detail absent.
	 * warning    — a Google Merchant mismatch was detected. Detail present.
	 *
	 * @return array{status: string, detail: array|null}
	 */
	private static function evalEddFeedAlignment(): array {

		if ( !function_exists( '\\PixelYourSite\\isEddActive' ) || !\PixelYourSite\isEddActive()
			|| !GetEddFeedAlignmentAbility::feedPluginActive() ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		$result = GetEddFeedAlignmentAbility::execute( array() );
		if ( empty( $result[ 'available' ] ) ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		if ( !empty( $result[ 'all_ok' ] ) ) {
			return array( 'status' => 'ok', 'detail' => null );
		}

		return array(
			'status' => 'warning',
			'detail' => array(
				'mismatch_reason' => $result[ 'content_id' ][ 'mismatch_reason' ] ?? 'content_id_mismatch',
			),
		);
	}

	/**
	 * PYS attribution reports sync status for one store (woo | edd).
	 * not_active: store not installed, or PYS "save data to orders" disabled.
	 * warning:    reports on but the historical import has not FINISHED.
	 * ok:         sync complete. detail absent unless warning.
	 *
	 * @param string $store woo | edd.
	 * @return array{status: string, detail: array|null}
	 */
	private static function evalReports( string $store ): array {
		$active = 'woo' === $store
			? ( function_exists( 'WC' ) || class_exists( 'WooCommerce' ) )
			: ( function_exists( 'EDD' ) || class_exists( 'Easy_Digital_Downloads' ) );
		if ( !$active ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		$opt = 'woo' === $store ? 'woo_enabled_save_data_to_orders' : 'edd_enabled_save_data_to_orders';
		if ( null === $pys || !$pys->getOption( $opt ) ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		if ( !function_exists( '\\PixelYourSite\\PysStatistic' ) ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}
		$s    = \PixelYourSite\PysStatistic();
		$stat = 'woo' === $store ? ( $s->wooStatistic ?? null ) : ( $s->eddStatistic ?? null );
		if ( !$stat ) {
			return array( 'status' => 'not_active', 'detail' => null );
		}

		if ( \PixelYourSite\OrderStatistics::$SYNC_STATUS_FINISH !== $stat->getSyncStatus() ) {
			return array(
				'status' => 'warning',
				'detail' => array(
					'reason'      => 'sync_incomplete',
					'description' => sprintf( 'Historical order import for %s reports has not completed — run the sync in PixelYourSite → %s Reports before relying on attribution figures.', strtoupper( $store ), 'woo' === $store ? 'WooCommerce' : 'EDD' ),
				),
			);
		}

		return array( 'status' => 'ok', 'detail' => null );
	}

	/**
	 * GTM: active when the container is enabled.
	 *
	 * @return array<string, mixed>
	 */
	private static function evalGtm(): array {
		$gtm = self::instance( 'PixelYourSite\\GTM' );
		$on  = $gtm && method_exists( $gtm, 'enabled' ) && $gtm->enabled();

		return array( 'status' => $on ? 'active' : 'not_active', 'detail' => null );
	}

	/**
	 * SuperPack: active when the add-on is loaded.
	 *
	 * @return array<string, mixed>
	 */
	private static function evalSuperPack(): array {
		$on = function_exists( '\\PixelYourSite\\isSuperPackActive' ) && \PixelYourSite\isSuperPackActive();

		return array( 'status' => $on ? 'active' : 'not_active', 'detail' => null );
	}

	/**
	 * Recent MCP write activity from the provenance log. Always ok.
	 *
	 * @return array<string, mixed>
	 */
	private static function evalMcpActivity(): array {
		$recent = Provenance::getRecent( 1 );
		if ( empty( $recent ) ) {
			return array( 'status' => 'ok', 'detail' => null );
		}

		// Detail lives in the Settings-tab UI; the audit just reports healthy.
		return array( 'status' => 'ok', 'detail' => null );
	}

	// ---- helpers ----------------------------------------------------------

	/**
	 * Resolve a platform singleton that exposes getOption().
	 *
	 * @param string $fn
	 * @return object|null
	 */
	private static function instance( string $fn ) {
		if ( !function_exists( $fn ) ) {
			return null;
		}
		$inst = $fn();

		return is_object( $inst ) && method_exists( $inst, 'getOption' ) ? $inst : null;
	}

	/**
	 * Whether a platform instance has a non-empty value for the given key.
	 *
	 * @param string $fn
	 * @param string $key
	 * @return bool
	 */
	private static function hasId( string $fn, string $key ): bool {
		$inst = self::instance( $fn );

		return $inst && self::hasValue( $inst->getOption( $key ) );
	}

	/**
	 * Whether a scalar or array option holds a non-empty string value.
	 *
	 * @param mixed $value
	 * @return bool
	 */
	private static function hasValue( $value ): bool {
		if ( is_array( $value ) ) {
			foreach ( $value as $v ) {
				if ( is_string( $v ) && '' !== trim( $v ) ) {
					return true;
				}
			}

			return false;
		}

		return is_string( $value ) && '' !== trim( $value );
	}

	/**
	 * Normalize a stored option value to a boolean.
	 *
	 * @param mixed $value
	 * @return bool
	 */
	private static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}

		return is_int( $value ) && 1 === $value;
	}
}