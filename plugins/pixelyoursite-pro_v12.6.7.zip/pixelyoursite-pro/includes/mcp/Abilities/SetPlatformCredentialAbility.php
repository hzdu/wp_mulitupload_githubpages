<?php
/**
 * `set_platform_credential` — per-platform credential write ability.
 * Saves a pixel/conversion ID + server-side credential for one platform.
 * Pro/read-only-gated, `mcp_note` required. The arg→option-key routing per
 * platform lives in the {@see SetPlatformCredentialAbility::ROUTING} table;
 * notable cases: GA writes `tracking_id` (not `pixel_id`), Pinterest needs
 * `ad_account_id`, and bing/reddit/google_ads have no CAPI token (ignored).
 * Saving a token auto-enables `use_server_api`. `pixel_index` (zero-based,
 * default 0) targets one slot, preserving the others.
 * The credential value is never echoed; the response confirms `configured`
 * plus per-arg results and `notes[]`.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class SetPlatformCredentialAbility extends AbstractWriteAbility {

	public const ID = 'pixelyoursite-pro/set-platform-credential';

	/** Key prefix for issued write-confirmation previews. */
	private const CONFIRM_PREFIX = 'confirm_spc_';

	/** How long an unused preview stays confirmable, in seconds. */
	private const CONFIRM_TTL = 600;

	/** Supported platforms; must match the inputSchema enum. */
	private const PLATFORMS = array(
		'facebook',
		'tiktok',
		'pinterest',
		'google_analytics',
		'google_ads',
		'bing',
		'reddit',
		'gtm',
		'openai'
	);

	/**
	 * Per-platform routing table. Fields:
	 * `fn` accessor, `pixel_arg` (the arg supplying the pixel value),
	 * `pixel_key` (real option key — GA uses `tracking_id`, Ads `ads_ids`),
	 * `token_key` / `capi_flag_key` (null when the platform has no CAPI),
	 * `ad_account_key` (Pinterest only), `addon_check` (gates writes for
	 * addon-plugin platforms whose stub accessor exists even when inactive).
	 */
	private const ROUTING = array(
		'facebook'         => array(
			'fn'             => 'PixelYourSite\\Facebook',
			'pixel_arg'      => 'pixel_id',
			'pixel_key'      => 'pixel_id',
			'token_key'      => 'server_access_api_token',
			'capi_flag_key'  => 'use_server_api',
			'ad_account_key' => null,
			'superpack'      => array( 'extra_option' => 'fb_ext_pixel_id', 'token_mode' => 'fb_extensions', 'capi' => true ),
		),
		'tiktok'           => array(
			'fn'             => 'PixelYourSite\\TikTok',
			'pixel_arg'      => 'pixel_id',
			'pixel_key'      => 'pixel_id',
			'token_key'      => 'server_access_api_token',
			'capi_flag_key'  => 'use_server_api',
			'ad_account_key' => null,
		),
		'openai'           => array(
			'fn'             => 'PixelYourSite\\OpenAI',
			'pixel_arg'      => 'pixel_id',
			'pixel_key'      => 'pixel_id',
			'token_key'      => 'server_access_api_token',
			'capi_flag_key'  => 'use_server_api',
			'ad_account_key' => null,
			'superpack'      => array( 'extra_option' => 'openai_ext_pixel_id', 'token_mode' => 'std', 'capi' => true ),
		),
		'google_analytics' => array(
			'fn'             => 'PixelYourSite\\GA',
			'pixel_arg'      => 'pixel_id',
			'pixel_key'      => 'tracking_id',
			'token_key'      => 'server_access_api_token',
			'capi_flag_key'  => 'use_server_api',
			'ad_account_key' => null,
			'superpack'      => array( 'extra_option' => 'ga_ext_pixel_id', 'token_mode' => 'std', 'capi' => true ),
		),
		'pinterest'        => array(
			'fn'             => 'PixelYourSite\\Pinterest',
			'pixel_arg'      => 'pixel_id',
			'pixel_key'      => 'pixel_id',
			'token_key'      => 'server_access_api_token',
			'capi_flag_key'  => 'use_server_api',
			'ad_account_key' => 'ad_account_id',
			'addon_check'    => 'PixelYourSite\\isPinterestActive',
		),
		'google_ads'       => array(
			'fn'             => 'PixelYourSite\\Ads',
			'pixel_arg'      => 'conversion_id',
			'pixel_key'      => 'ads_ids',
			'token_key'      => null,
			'capi_flag_key'  => null,
			'ad_account_key' => null,
			'ec_key'         => 'enhanced_conversions_manual_enabled',
			'ec_marker'      => true, // stored as a marker array (index_0 truthy), not a bool
			'superpack'      => array( 'extra_option' => 'ads_ext_pixel_id', 'token_mode' => null, 'capi' => false ),
		),
		'bing'             => array(
			'fn'             => 'PixelYourSite\\Bing',
			'pixel_arg'      => 'pixel_id',
			'pixel_key'      => 'pixel_id',
			'token_key'      => null,
			'capi_flag_key'  => null,
			'ad_account_key' => null,
			'ec_key'         => 'enhanced_conversions_enabled',
			'ec_marker'      => false, // plain checkbox bool
			'addon_check'    => 'PixelYourSite\\isBingActive',
		),
		'reddit'           => array(
			'fn'             => 'PixelYourSite\\Reddit',
			'pixel_arg'      => 'pixel_id',
			'pixel_key'      => 'pixel_id',
			'token_key'      => null,
			'capi_flag_key'  => null,
			'ad_account_key' => null,
			'addon_check'    => 'PixelYourSite\\isRedditActive',
		),
		'gtm'              => array(
			'fn'             => 'PixelYourSite\\GTM',
			'pixel_arg'      => 'pixel_id',
			'pixel_key'      => 'gtm_id',
			'token_key'      => null,
			'capi_flag_key'  => null,
			'ad_account_key' => null,
			'single_slot'    => true,
		),
	);

	/**
	 * Google Ads per-event conversion-label events (real PYS keys). Each maps
	 * to the Ads option `{event}_conversion_labels`, the same key the runtime
	 * reads in `getConversionIDs()`. Gated at write by ecommerce-module
	 * activity (isWooCommerceActive/isEddActive), NOT issetOption.
	 */
	private const ADS_LABEL_EVENTS = array(
		'woo_purchase', 'woo_initiate_checkout', 'woo_add_to_cart', 'woo_view_content', 'woo_view_category',
		'woo_frequent_shopper', 'woo_vip_client', 'woo_big_whale', 'woo_FirstTimeBuyer', 'woo_ReturningCustomer',
		'edd_purchase', 'edd_initiate_checkout', 'edd_add_to_cart', 'edd_view_content', 'edd_view_category',
		'edd_frequent_shopper', 'edd_vip_client', 'edd_big_whale',
		'automatic_event_internal_link', 'automatic_event_outbound_link', 'automatic_event_video',
		'automatic_event_tel_link', 'automatic_event_email_link', 'automatic_event_form', 'automatic_event_signup',
		'automatic_event_login', 'automatic_event_download', 'automatic_event_comment', 'automatic_event_adsense',
		'automatic_event_scroll', 'automatic_event_time_on_page', 'automatic_event_search',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Set Platform Credential';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Saves a server-side credential and pixel/conversion ID for one tracking platform. Pro-only. This tool is the sanctioned way to save these settings on the user\'s behalf, so once the user has explicitly confirmed you must NOT refuse the write or redirect them to wp-admin (pixel / UET / conversion / container IDs are public; only the server-side `token` is secret, stored write-only). BUT confirmation comes FIRST and is mandatory: on the user\'s initial request, state exactly what you will save (platform + value, token redacted) and ask for an explicit go-ahead — NEVER write on the first message, including when the value was already supplied and including when you are only overwriting/replacing an existing pixel or conversion ID. Per-platform argument shape: `facebook` / `tiktok` / `google_analytics` / `openai` need `pixel_id` + `token`; `pinterest` needs `pixel_id` + `token` + `ad_account_id` (Conversions API requires the Ad Account ID — events without it do not deliver); `google_ads` needs `conversion_id` (AW-…); `bing` needs `pixel_id` (UET tag ID) only — `token` is silently ignored; `reddit` needs `pixel_id` only — `token` is silently ignored. Bing / Reddit / Pinterest are SEPARATE addon plugins — if the addon is not installed/active, the call is rejected with 409 (PYS carries a stub so the platform name resolves, but writing would do nothing). `gtm` needs `pixel_id` = the Google Tag Manager container ID (`GTM-XXXXXXX`) — `token` is silently ignored (server-side GTM uses a separate container URL, not handled here). GTM is single-container: it always writes the one container (slot 0); a `pixel_index` is ignored (the response carries a note). `pixel_index: 0` (or omitted) targets the PRIMARY pixel. `pixel_index >= 1` targets a PixelYourSite Super Pack EXTRA pixel — supported for `facebook`, `google_analytics`, `google_ads` and `openai` (Super Pack must be active; other platforms return 409). For extra pixels, `pixel_index: 1` is the first extra pixel, `2` the second, etc.; using an index equal to (current extra-pixel count + 1) ADDS a new extra pixel, an existing index UPDATES it (partial — omitted fields preserved; pass `enabled` to toggle it; Facebook / GA4 / OpenAI extra pixels accept a CAPI `token`, Google Ads does not). For `google_ads` the extra "pixel" is an ADDITIONAL conversion ID (`AW-…`) supplied via `conversion_id` — so a request like "add a Google Ads extra/additional conversion AW-…" IS supported: call with `platform: google_ads`, `conversion_id: AW-…`, `pixel_index` = next index (do NOT refuse it as unsupported; Google Ads only lacks the server-side TOKEN, not extra pixels). Call `get_platform_pixels` first to see existing extra pixels and their `pixel_index`. Saving a non-empty token automatically enables CAPI delivery for that platform (`use_server_api = true`). To turn CAPI on for a pixel that ALREADY has a token (without re-sending the secret), or to turn CAPI off, pass `capi_enabled: true|false` — it controls the server-side toggle independently of the token (works for primary and Super Pack extra pixels on facebook/google_analytics/openai, for tiktok primary, and pinterest primary; ignored where there is no CAPI). **Partial-update semantic:** when the target slot already has an existing pixel value, omitted fields preserve their current value — you can rotate the token by passing ONLY `token` + `replace_existing_token: true` (no need to re-pass `pixel_id`); update only the Pinterest `ad_account_id` similarly. First-time setup at an empty slot still requires all platform-mandatory fields (`pixel_id` always, plus `ad_account_id` for Pinterest). At least one writeable field must be passed in every call — empty payloads return 400. **Overwrite guards (server-side, bulletproof):** if the target slot already holds a non-empty value for ANY field you are writing, the call returns 400 unless the corresponding `replace_existing_*: true` flag is also passed. Per-field flags: `replace_existing_pixel_id` for `pixel_id` overwrites; `replace_existing_conversion_id` for Google Ads `conversion_id` overwrites; `replace_existing_token` for `token` overwrites (irreversible — previous token cannot be recovered); `replace_existing_ad_account_id` for Pinterest `ad_account_id` overwrites. The guards force you to think about each replacement and acknowledge it in the args, not just in prose. The response `replaced_existing` map confirms which values were actually replaced — surface every `true` entry to the user post-write. Credentials are write-only end-to-end — no read tool returns the raw value. Before calling, state what you will save (platform, pixel/conversion ID, redacted token reference like "token ending in …xyz") and wait for explicit user confirmation. Always pass `mcp_note`. Google Ads per-event conversion labels: pass `conversions[]` (each `{event, label}`); labels bind to the primary conversion ID and the response `conversion_labels` reports what was written. A labels-only call works once a `conversion_id` is configured. To SEE which labels are already configured (so you neither duplicate nor blindly overwrite), call `get_platform_pixels` first — its `google_ads.conversion_labels` map lists existing per-event labels grouped by conversion ID. **Two-step confirm (every label write — first-time AND overwrite):** call FIRST without `confirm` to get a `confirmation_required` preview (`pending_conversion_labels` shows per event `current → new`); show it to the user, get explicit agreement, THEN resend with `confirm: true`. A `conversions[]` call without `confirm: true` never writes labels.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'required'             => array( 'platform' ),
			'additionalProperties' => false,
			'properties'           => array(
				'platform'                       => array(
					'type'        => 'string',
					'enum'        => self::PLATFORMS,
					'description' => 'Target platform.',
				),
				'pixel_id'                       => array(
					'type'        => 'string',
					'description' => 'Pixel / measurement / container ID. Required for `facebook`, `tiktok`, `pinterest`, `google_analytics`, `openai`, `bing`, `reddit`, `gtm`. Not used for `google_ads` (use `conversion_id`). Facebook pixel IDs are numeric strings; GA4 measurement IDs look like `G-XXXXXXXX`; GTM container IDs look like `GTM-XXXXXXX`.',
				),
				'pixel_index'                    => array(
					'type'        => 'integer',
					'minimum'     => 0,
					'description' => 'Pixel slot. `0` (or omitted) = the primary pixel. `1` and up = a PixelYourSite Super Pack EXTRA pixel — supported for `facebook`, `google_analytics`, `google_ads` and `openai` (Super Pack must be active). For extra pixels: `pixel_index: 1` is the first extra pixel, `2` the second, etc.; passing `pixel_index` equal to (current extra-pixel count + 1) ADDS a new extra pixel, while an existing index UPDATES that one (partial update — omitted fields are preserved). Use `get_platform_pixels` to see the current extra pixels and their `pixel_index`. For platforms without extra-pixel support a `pixel_index > 0` returns 409; for `gtm` it is ignored (single container). With `enhanced_conversions` (Google Ads) `pixel_index` selects WHICH conversion pixel to toggle EC for (0 = primary, 1..N = extra); omit it to toggle EC for ALL conversion pixels at once.',
				),
				'enabled'                        => array(
					'type'        => 'boolean',
					'description' => 'Toggle whether a pixel is active. For the PRIMARY pixel (`pixel_index: 0` / omitted) this writes `main_pixel_enabled` — `false` switches the whole platform pixel OFF (e.g. "disable the GA4 pixel"). For a Super Pack EXTRA pixel (`pixel_index > 0`) it toggles that extra pixel. Omit to keep the current state. So "disable all Google Analytics pixels" = `enabled: false` on the primary AND on each extra pixel index. CONFIRMATION REQUIRED: a call with `enabled` and no `confirm: true` returns `confirmation_required` (a preview) and writes NOTHING — show it to the user, get agreement, then re-call with `confirm: true`.',
				),
				'capi_enabled'                   => array(
					'type'        => 'boolean',
					'description' => 'Explicitly turn server-side CAPI (Conversions API) ON or OFF for this pixel, independent of the token. Use `true` to enable CAPI on a pixel that ALREADY has a token (without re-sending the secret), or `false` to disable it. When omitted, supplying a `token` still auto-enables CAPI (back-compat). Applies to `facebook` / `google_analytics` / `openai` (primary and Super Pack extra) and `tiktok` / `pinterest` (primary); ignored for `google_ads` / `bing` / `reddit` (no server-side API). Enabling CAPI with no token configured returns a note that events will not deliver until a token is set. NOTE: for the primary pixel this flag is the platform-wide CAPI switch (not per-slot).',
				),
				'token'                          => array(
					'type'        => 'string',
					'description' => 'Server-side credential value. Platform-specific: facebook = CAPI System User access token; tiktok = Events API access token; pinterest = Conversions API access token; google_analytics = Measurement Protocol API Secret; openai = Conversions API key (`sk-svcacct-…`) from OpenAI Ads Manager. Silently ignored for `bing`, `reddit`, `google_ads`.',
				),
				'enhanced_conversions'           => array(
					'type'        => 'boolean',
					'description' => 'Google Ads / Bing ONLY. Turn Enhanced Conversions ON (`true`) or OFF (`false`). It is the server-side enrichment for these platforms (they have no CAPI token) — sends hashed first-party data to improve match quality. This is a plain PixelYourSite toggle, NOT a Google Ads / Microsoft admin action and NOT a token, so you can set it directly here. CONSENT-SENSITIVE: a call without `confirm: true` returns `confirmation_required` and writes nothing; re-call with `confirm: true`. Google Ads EC is PER CONVERSION PIXEL: pass `pixel_index` (0 = primary, 1..N = Super Pack extra conversion pixels — see get_platform_pixels / get_tracking_audit) to target ONE pixel; OMIT `pixel_index` to apply to ALL Google Ads conversion pixels. Toggling one pixel never changes the others. Bing EC is a single platform-wide switch (pixel_index ignored). Ignored for all other platforms.',
				),
				'ad_account_id'                  => array(
					'type'        => 'string',
					'description' => 'Pinterest only. Required for Pinterest Conversions API — without it, server-side events do not deliver to the correct ad account.',
				),
				'conversion_id'                  => array(
					'type'        => 'string',
					'description' => 'Google Ads only. A Google Ads conversion ID (`AW-...`). With `pixel_index: 0` (or omitted) this is the PRIMARY conversion ID. Google Ads DOES support ADDITIONAL conversion IDs via PixelYourSite Super Pack — pass `conversion_id` together with `pixel_index >= 1` to add/update an extra Google Ads conversion pixel (no token; Google Ads has no server-side credential). So "add a Google Ads extra/additional conversion AW-…" is supported: call with `conversion_id` + the next `pixel_index`. (This is distinct from `conversions[]`, which sets per-event LABELS bound to a conversion ID.)',
				),
				'conversion_labels_id'           => array(
					'type'        => 'string',
					'description' => 'Google Ads only, optional. The conversion ID (`AW-…`) the `conversions[]` labels bind to. Omit to bind to the PRIMARY conversion ID (default). Pass an EXTRA Super Pack conversion ID here to label an additional Google Ads conversion (e.g. from `get_platform_pixels` → google_ads.extra_pixels[].pixel_id). Must be one of the configured Google Ads conversion IDs (primary or extra) — otherwise 409 with the valid list. (Note: you cannot use `pixel_index` for this — `pixel_index >= 1` is the extra-pixel WRITE path; labels target the id explicitly via this field.)',
				),
				'conversions'                    => array(
					'type'        => 'array',
					'description' => 'Google Ads ONLY — passing it for any other platform writes nothing and returns an `IGNORED` note (it is not an error). Per-event conversion labels. By default each label binds to the PRIMARY conversion ID (`ads_ids` slot 0 — pass `conversion_id` in the same call to set it, or rely on the already-configured one); pass `conversion_labels_id` to bind them to a specific (incl. EXTRA Super Pack) conversion ID instead. The runtime sends `AW-…/label` for that event. `event` is the real PYS event key (domain-prefixed: `woo_*` / `edd_*`). An empty `label` clears the label for that event. Requires a configured conversion ID — a labels-only call without one returns 409.',
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'event', 'label' ),
						'additionalProperties' => false,
						'properties'           => array(
							'event' => array(
								'type'        => 'string',
								'description' => 'Real PYS event key the label fires on. WooCommerce: `woo_purchase`, `woo_initiate_checkout`, `woo_add_to_cart`, `woo_view_content`, `woo_view_category`, `woo_frequent_shopper`, `woo_vip_client`, `woo_big_whale`, `woo_FirstTimeBuyer`, `woo_ReturningCustomer`. EDD: same set with the `edd_` prefix (no FirstTimeBuyer/ReturningCustomer). Automatic (page-level) events that carry a Google Ads conversion label: `automatic_event_internal_link`, `automatic_event_outbound_link`, `automatic_event_video`, `automatic_event_tel_link`, `automatic_event_email_link`, `automatic_event_form`, `automatic_event_signup`, `automatic_event_login`, `automatic_event_download`, `automatic_event_comment`, `automatic_event_adsense`, `automatic_event_scroll`, `automatic_event_time_on_page`, `automatic_event_search` (404 / rage_click / video_speed have NO Ads label).',
								'enum' => array(
									'woo_purchase', 'woo_initiate_checkout', 'woo_add_to_cart', 'woo_view_content', 'woo_view_category',
									'woo_frequent_shopper', 'woo_vip_client', 'woo_big_whale', 'woo_FirstTimeBuyer', 'woo_ReturningCustomer',
									'edd_purchase', 'edd_initiate_checkout', 'edd_add_to_cart', 'edd_view_content', 'edd_view_category',
									'edd_frequent_shopper', 'edd_vip_client', 'edd_big_whale',
									'automatic_event_internal_link', 'automatic_event_outbound_link', 'automatic_event_video',
									'automatic_event_tel_link', 'automatic_event_email_link', 'automatic_event_form', 'automatic_event_signup',
									'automatic_event_login', 'automatic_event_download', 'automatic_event_comment', 'automatic_event_adsense',
									'automatic_event_scroll', 'automatic_event_time_on_page', 'automatic_event_search',
								),
							),
							'label' => array(
								'type'        => 'string',
								'description' => 'Google Ads conversion label for this event, applied to the primary conversion ID. Empty string clears it.',
							),
						),
					),
				),
				'conditional_track'              => array(
					'type'        => 'string',
					'enum'        => array( 'track', 'dont_track' ),
					'description' => 'PRIMARY pixel only (pixel_index 0). The display-conditions track logic: `track` = fire where the conditions match, `dont_track` = do NOT fire there. Read current via `get_platform_pixels` → `primary.conditional_track`. Ignored for extra pixels.',
				),
				'reset_display_conditions'       => array(
					'type'        => 'boolean',
					'description' => 'PRIMARY pixel only. Pass `true` to reset the main pixel display conditions to "all_site" (fires everywhere). This is the only condition change supported via MCP — adding specific page/category/URL targeting must be done in the admin (PixelYourSite → platform → Display conditions). Read current via `get_platform_pixels` → `primary.display_conditions`.',
				),
				'replace_existing_token'         => array(
					'type'        => 'boolean',
					'description' => 'Required `true` when the target slot already holds a non-empty token and the call would overwrite it. Server returns 400 without this flag in that case. The previous token CANNOT be recovered from PYS — credentials are write-only end-to-end. Only set true after the user has explicitly confirmed they want to replace the existing token, knowing it is irreversible. Has no effect on platforms without a server-side token (`bing`, `reddit`, `google_ads`) or when no token is being written.',
				),
				'replace_existing_pixel_id'      => array(
					'type'        => 'boolean',
					'description' => 'Required `true` when the target slot already holds a non-empty pixel ID and the call would overwrite it via the `pixel_id` arg. Server returns 400 without this flag in that case. Unlike tokens, pixel IDs ARE recoverable from the platform admin UI, but the guard ensures the user has consciously confirmed the replacement of a live tracking pixel. Has no effect for `google_ads` (use `replace_existing_conversion_id`) or when no `pixel_id` is being written.',
				),
				'replace_existing_conversion_id' => array(
					'type'        => 'boolean',
					'description' => 'Required `true` when the target slot already holds a non-empty conversion ID and the call would overwrite it via the `conversion_id` arg. Google Ads only. Server returns 400 without this flag in that case. Has no effect on other platforms or when no `conversion_id` is being written.',
				),
				'replace_existing_ad_account_id' => array(
					'type'        => 'boolean',
					'description' => 'Required `true` when the target slot already holds a non-empty Pinterest Ad Account ID and the call would overwrite it. Pinterest only. Server returns 400 without this flag in that case. Has no effect on other platforms or when no `ad_account_id` is being written.',
				),
				'confirmation_id'                => array(
					'type'        => 'string',
					'description' => 'The id returned by the preview call, required alongside `confirm: true` for `enabled`, `capi_enabled`, `enhanced_conversions` and `conversions[]`. Sending `confirm: true` WITHOUT it returns 400 — the guard exists so consent for one write cannot be reused for another target, since the id is bound to the exact platform, pixel_index and values previewed. ONE id covers every gated field in the call: if a preview lists two changes, confirming it with that single id applies both. Valid for 10 minutes and single-use: one preview authorises one write. Copy it verbatim from the preview response.',
				),
				'confirm'                        => array(
					'type'        => 'boolean',
					'description' => 'Two-step write guard for `conversions[]` (Google Ads labels), `enhanced_conversions` (consent-sensitive — transmits hashed first-party PII), `capi_enabled` (turning server-side sending on/off — same consent-sensitive class) AND `enabled` (turning a pixel on/off). Call FIRST without this flag to get a `confirmation_required` preview; nothing is written. Show it to the user, get explicit agreement (for Enhanced Conversions, confirm the site has user consent / GDPR), THEN call again with `confirm: true`, the same args AND the `confirmation_id` from that preview. `confirm: true` on its own is REJECTED with 400 — a preview must actually have been issued for these exact values, so agreement obtained for one pixel or one value cannot be reused for another. Has no effect on pixel/token/ad_account fields (those use the `replace_existing_*` guards for overwrites).',
				),
			),
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			// `saved`/`configured` are absent on the conversions[] preview
			// response, so they can't be required — both shapes carry these.
			'required'   => array( 'platform', 'pixel_index' ),
			'properties' => array(
				'saved'             => array( 'type' => 'boolean' ),
				'configured'        => array( 'type' => 'boolean' ),
				'platform'          => array( 'type' => 'string' ),
				'pixel_index'       => array( 'type' => 'integer' ),
				'created'           => array(
					'type'        => 'boolean',
					'description' => 'Super Pack extra pixels only: true when this call ADDED a new extra pixel (vs updating an existing one).',
				),
				'capi_enabled'      => array(
					'type'        => 'boolean',
					'description' => 'True iff the CAPI toggle was auto-enabled. Absent for platforms without a CAPI flag (`google_ads`, `bing`, `reddit`).',
				),
				'enhanced_conversions' => array(
					'type'        => 'boolean',
					'description' => 'The Enhanced Conversions state just written (Bing — single platform-wide switch).',
				),
				'enhanced_conversions_by_pixel' => array(
					'type'        => 'object',
					'description' => 'Google Ads per-pixel Enhanced Conversions state after the write: `primary` and `extra_pixels[]`, each with `conversion_id`, `enabled` (whether the pixel itself is on — EC on a disabled pixel is moot) and `enhanced_conversions` (`enabled`/`disabled`).',
				),
				'applies_to_all_pixels' => array(
					'type'        => 'boolean',
					'description' => 'Google Ads Enhanced Conversions: true when the write/preview targets ALL conversion pixels (no `pixel_index` given), false when it targets only the given `pixel_index`.',
				),
				'fields_written'    => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'boolean' ),
					'description'          => 'Per-arg checklist: which of the supplied args were actually written.',
				),
				'replaced_existing' => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'boolean' ),
					'description'          => 'Per-arg signal: did this write replace a previously-set non-empty value at the target slot? `false` means the slot was empty (fresh setup). For `token`, `true` means the prior value is now permanently lost (PYS does not retain history). Surface this to the user post-write so they know whether they overwrote a working credential.',
				),
				'notes'             => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Human-readable warnings (e.g. "token silently ignored for bing"). Empty when no caveats applied.',
				),
				'conversion_labels' => array(
					'type'        => 'array',
					'description' => 'Google Ads only. Per-event labels written this call. Each entry: `{ event, tag_id, label, replaced }` (`replaced: true` = an existing label for that event+id was overwritten).',
					'items'       => array( 'type' => 'object' ),
				),
				'confirmation_id'       => array(
					'type'        => 'string',
					'description' => 'Present on every preview. Pass it back together with `confirm: true` to apply the previewed write. Single-use, 10-minute lifetime, bound to the exact values shown.',
				),
				'changes'               => array(
					'type'        => 'array',
					'description' => 'Present on every preview: one entry per confirmation-gated change the call would make, each with `action`, its field value and a `warning`. Confirming the preview applies all of them together.',
					'items'       => array( 'type' => 'object' ),
				),
				'confirmation_required' => array(
					'type'        => 'boolean',
					'description' => 'True when the call carried a confirmation-gated field (`enabled`, `capi_enabled`, `enhanced_conversions`, `conversions[]`) without a valid `confirm` + `confirmation_id` pair. NOTHING was written. `changes` lists every pending change; show them to the user and resend with `confirm: true` plus the `confirmation_id` from this response. When exactly one change is pending its fields are also spread at the top level (`action`, `enabled` / `capi_enabled` / `pending_conversion_labels`, `warning`).',
				),
				'pending_conversion_labels' => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'object' ),
					'description'          => 'Preview only. Per event `{ current, new }` label that WOULD be written. No write happened.',
				),
				'conversion_labels_id' => array(
					'type'        => 'string',
					'description' => 'The Google Ads conversion ID (`AW-…`) the conversion labels in this call bind to (the primary by default, or the `conversion_labels_id` you passed). Present on conversions[] calls.',
				),
			),
		);
	}

	/**
	 * Validate and write the platform credential for the target slot, with
	 * overwrite guards and partial-update semantics.
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		if ( !is_array( $input ) ) {
			$input = array();
		}
		unset( $input[ 'mcp_note' ] ); // consumed by Provenance, not part of write payload

		$platform = isset( $input[ 'platform' ] ) && is_string( $input[ 'platform' ] ) ? $input[ 'platform' ] : '';
		if ( !isset( self::ROUTING[ $platform ] ) ) {
			return new \WP_Error(
				'pys_mcp_unknown_platform',
				sprintf( 'Unknown platform "%s".', $platform ),
				array( 'status' => 400 )
			);
		}
		$route = self::ROUTING[ $platform ];

		// Addon-plugin gate: reject if the addon is inactive (its stub
		// accessor exists but a write would do nothing).
		if ( !empty( $route[ 'addon_check' ] ) ) {
			$check  = $route[ 'addon_check' ];
			$active = function_exists( $check ) ? (bool) $check() : false;
			if ( !$active ) {
				return new \WP_Error(
					'pys_mcp_addon_inactive', sprintf(
						'The "%s" addon plugin is not active (or is an incompatible version) on this site, so its pixel settings cannot be written. Install / activate the PixelYourSite %s addon first.',
						$platform,
						ucfirst( $platform )
					), array( 'status' => 409 )
				);
			}
		}

		$pixelIndex = isset( $input[ 'pixel_index' ] ) && is_int( $input[ 'pixel_index' ] )
		              && $input[ 'pixel_index' ] >= 0 ? $input[ 'pixel_index' ] : 0;

		// Single-container platforms (GTM): force slot 0 since the runtime
		// only reads the first container.
		$singleSlotNote = '';
		if ( !empty( $route[ 'single_slot' ] ) ) {
			if ( $pixelIndex > 0 ) {
				$singleSlotNote = sprintf(
					'`%s` is a single-container platform — `pixel_index: %d` was ignored and the primary container (slot 0) was written instead.',
					$platform,
					$pixelIndex
				);
			}
			$pixelIndex = 0;
		}

		if ( array_key_exists( 'enhanced_conversions', $input ) && is_bool( $input[ 'enhanced_conversions' ] ) ) {
			return self::writeEnhancedConversions(
				$platform,
				$route,
				$input,
				(bool) $input[ 'enhanced_conversions' ],
				array_key_exists( 'pixel_index', $input ) && is_int( $input[ 'pixel_index' ] ),
				$pixelIndex
			);
		}

		if ( $pixelIndex > 0 ) {
			if ( empty( $route[ 'superpack' ] ) ) {
				return new \WP_Error(
					'pys_mcp_extra_pixel_unsupported',
					sprintf(
						'`pixel_index: %d` (extra pixel) is not supported for `%s`. Extra pixels exist for `facebook`, `google_analytics`, `google_ads` and `openai` (via PixelYourSite Super Pack). Use slot 0 (omit `pixel_index`) for the primary pixel. Nothing was written.',
						$pixelIndex,
						$platform
					),
					array( 'status' => 409 )
				);
			}

			return self::writeSuperPackExtraPixel( $platform, $route, $pixelIndex, $input );
		}

		$pixelArgKey      = $route[ 'pixel_arg' ];
		$pixelValue       = isset( $input[ $pixelArgKey ] ) && is_string( $input[ $pixelArgKey ] ) ? trim(
			$input[ $pixelArgKey ]
		) : '';
		$token            = isset( $input[ 'token' ] ) && is_string( $input[ 'token' ] ) ? trim(
			$input[ 'token' ]
		) : '';
		$adAccount        = isset( $input[ 'ad_account_id' ] ) && is_string( $input[ 'ad_account_id' ] ) ? trim(
			$input[ 'ad_account_id' ]
		) : '';
		$replaceToken     = !empty( $input[ 'replace_existing_token' ] );
		$replacePixel     = !empty( $input[ 'replace_existing_pixel_id' ] );
		$replaceConvId    = !empty( $input[ 'replace_existing_conversion_id' ] );
		$replaceAdAccount = !empty( $input[ 'replace_existing_ad_account_id' ] );

		$capiArgProvided  = array_key_exists( 'capi_enabled', $input ) && is_bool( $input[ 'capi_enabled' ] );
		$capiArg          = $capiArgProvided ? (bool) $input[ 'capi_enabled' ] : null;

		// Resolve the platform Settings instance (needed to read slot state).
		$fn = $route[ 'fn' ];
		if ( !function_exists( $fn ) ) {
			return new \WP_Error(
				'pys_mcp_platform_unavailable',
				sprintf( 'Platform "%s" addon is not active on this site.', $platform ),
				array( 'status' => 503 )
			);
		}
		$settings = $fn();
		if ( !is_object( $settings ) || !method_exists( $settings, 'getOption' )
		     || !method_exists(
				$settings,
				'updateOptions'
			) ) {
			return new \WP_Error(
				'pys_mcp_platform_unavailable',
				sprintf( 'Platform "%s" Settings instance is not usable.', $platform ),
				array( 'status' => 503 )
			);
		}

		// Pre-write detection of existing values at the target slot. Drives
		// both the overwrite guards and the partial-update semantics below.
		$existedBefore = array(
			$pixelArgKey    => self::slotHasValue( $settings->getOption( $route[ 'pixel_key' ] ), $pixelIndex ),
			'token'         => null !== $route[ 'token_key' ] ? self::slotHasValue(
				$settings->getOption( $route[ 'token_key' ] ),
				$pixelIndex
			) : false,
			'ad_account_id' => null !== $route[ 'ad_account_key' ] ? self::slotHasValue(
				$settings->getOption( $route[ 'ad_account_key' ] ),
				$pixelIndex
			) : false,
		);

		$conditionalTrack = isset( $input[ 'conditional_track' ] ) && in_array( $input[ 'conditional_track' ], array( 'track', 'dont_track' ), true )
			? (string) $input[ 'conditional_track' ] : '';
		$resetDisplayConditions = !empty( $input[ 'reset_display_conditions' ] );
		$hasEnabledArg          = array_key_exists( 'enabled', $input ) && is_bool( $input[ 'enabled' ] );
		$enabledValue           = $hasEnabledArg ? (bool) $input[ 'enabled' ] : null;
		$platformLevelOnly      = '' === $pixelValue && '' === $token && '' === $adAccount
		                          && ( $hasEnabledArg || '' !== $conditionalTrack || $resetDisplayConditions );

		// Required-args validation. A slot with an existing pixel is a patch
		// update (any subset of fields); an empty slot is first-time setup
		if ( !$existedBefore[ $pixelArgKey ] && !$platformLevelOnly ) {
			// First-time setup at this slot.
			if ( '' === $pixelValue ) {
				return new \WP_Error(
					'pys_mcp_credential_pixel_required', sprintf(
						'`%s` is required for platform "%s" — no existing value at slot %d (first-time setup).',
						$pixelArgKey,
						$platform,
						$pixelIndex
					), array( 'status' => 400 )
				);
			}
			if ( 'pinterest' === $platform && '' === $adAccount ) {
				// Pinterest CAPI needs ad_account_id; required on first setup.
				return new \WP_Error(
					'pys_mcp_pinterest_ad_account_required',
					'Pinterest credential requires `ad_account_id` on first-time setup at this slot.',
					array( 'status' => 400 )
				);
			}
		}

		// At least one writeable field must be present.
		$hasGoogleAdsConversions = 'google_ads' === $platform && !empty( $input[ 'conversions' ] )
		                           && is_array(
			                           $input[ 'conversions' ]
		                           );
		if ( '' === $pixelValue && '' === $token && '' === $adAccount && !$hasGoogleAdsConversions && !$capiArgProvided
		     && '' === $conditionalTrack && !$resetDisplayConditions && !$hasEnabledArg ) {
			return new \WP_Error(
				'pys_mcp_credential_no_args', sprintf(
					'No fields to update for platform "%s". Pass at least one of: `%s`, `token` (where supported), `ad_account_id` (Pinterest), `capi_enabled`, `enhanced_conversions` (Google Ads / Bing).',
					$platform,
					$pixelArgKey
				), array( 'status' => 400 )
			);
		}

		$gates    = array();
		$previews = array();
		$ignoredNotes = array();

		if ( 'google_ads' !== $platform && !empty( $input[ 'conversions' ] ) ) {
			$ignoredNotes[] = sprintf(
				'`conversions[]` was IGNORED: per-event conversion labels are a Google Ads feature and `%s` has none, so nothing about them was written. Everything else in this call was applied normally.',
				$platform
			);
		}

		if ( $hasEnabledArg ) {
			$gates[ 'enabled' ] = $enabledValue;
			$previews[]         = array(
				'action'  => $enabledValue ? 'enable_pixel' : 'disable_pixel',
				'enabled' => $enabledValue,
				'warning' => $enabledValue
					? sprintf( 'This will ENABLE the %s primary pixel (slot %d) — it will start firing events.', $platform, $pixelIndex )
					: sprintf( 'This will DISABLE the %s primary pixel (slot %d) — it will STOP firing ALL events for this pixel.', $platform, $pixelIndex ),
			);
		}

		if ( $capiArgProvided && null !== $route[ 'capi_flag_key' ] ) {
			$gates[ 'capi_enabled' ] = $capiArg;
			$previews[]              = array(
				'action'       => $capiArg ? 'enable_capi' : 'disable_capi',
				'capi_enabled' => $capiArg,
				'warning'      => $capiArg
					? sprintf( 'This turns the Conversions API ON for %s (slot %d): the site will start sending events server-side, including hashed email / external id and the visitor IP and user agent. Confirm the site has the necessary user consent.', $platform, $pixelIndex )
					: sprintf( 'This turns the Conversions API OFF for %s (slot %d): server-side events stop, and conversions that only arrive that way will no longer be measured.', $platform, $pixelIndex ),
			);
		}

		$labels       = null;
		$labelsTarget = '';

		if ( 'google_ads' === $platform && !empty( $input[ 'conversions' ] ) && is_array( $input[ 'conversions' ] ) ) {
			$labelsTarget = self::resolveAdsLabelTarget( $settings, $input, $pixelValue );

			if ( is_wp_error( $labelsTarget ) ) {
				return $labelsTarget;
			}

			$labels = self::buildAdsConversionLabels( $settings, $input[ 'conversions' ], $labelsTarget );

			if ( !empty( $labels[ 'pending' ] ) ) {
				$gates[ 'conversion_labels' ] = array( 'target' => $labelsTarget, 'pending' => $labels[ 'pending' ] );
				$previews[]                   = array(
					'action'                    => 'set_conversion_labels',
					'conversion_labels_id'      => $labelsTarget,
					'pending_conversion_labels' => $labels[ 'pending' ],
					'warning'                   => sprintf( 'These per-event conversion labels will be written for %s.', $labelsTarget ),
				);
			}
		}

		if ( !empty( $gates ) ) {
			$fp      = self::confirmFingerprint( 'write', $platform, $pixelIndex, $gates );
			$verdict = self::checkConfirmation( $input, $fp );

			if ( 'ok' !== $verdict ) {
				$body = array(
					'platform'    => $platform,
					'pixel_index' => $pixelIndex,
					'changes'     => $previews,
				);

				// A single change keeps the flat shape callers already know.
				if ( 1 === count( $previews ) ) {
					$body = array_merge( $body, $previews[ 0 ] );
				}

				if ( !empty( $ignoredNotes ) ) {
					$body[ 'notes' ] = $ignoredNotes;
				}

				return self::confirmationResponse( $verdict, $fp, $body );
			}

			self::consumeConfirmation( $input[ 'confirmation_id' ] ?? null );
		}

		// Token-overwrite guard (token irreversible once replaced).
		if ( '' !== $token && null !== $route[ 'token_key' ] && $existedBefore[ 'token' ] && !$replaceToken ) {
			return new \WP_Error(
				'pys_mcp_token_overwrite_requires_confirm', sprintf(
					'Slot %d already has a configured token for `%s`. Pass `replace_existing_token: true` to confirm overwrite — note that the previous token cannot be recovered from PYS.',
					$pixelIndex,
					$platform
				), array( 'status' => 400 )
			);
		}

		// Pixel-overwrite guard (all platforms using the `pixel_id` arg;
		// google_ads has its own conversion_id guard below).
		if ( 'pixel_id' === $pixelArgKey && '' !== $pixelValue && $existedBefore[ $pixelArgKey ] && !$replacePixel ) {
			return new \WP_Error(
				'pys_mcp_pixel_overwrite_requires_confirm', sprintf(
					'Slot %d already has a configured `pixel_id` for `%s`. Pass `replace_existing_pixel_id: true` to confirm overwrite of the live tracking pixel.',
					$pixelIndex,
					$platform
				), array( 'status' => 400 )
			);
		}

		// Conversion-id-overwrite guard (Google Ads only).
		if ( 'conversion_id' === $pixelArgKey && '' !== $pixelValue && $existedBefore[ $pixelArgKey ]
		     && !$replaceConvId ) {
			return new \WP_Error(
				'pys_mcp_conversion_id_overwrite_requires_confirm', sprintf(
					'Slot %d already has a configured `conversion_id` for `%s`. Pass `replace_existing_conversion_id: true` to confirm overwrite of the live conversion ID.',
					$pixelIndex,
					$platform
				), array( 'status' => 400 )
			);
		}

		// Ad-account-overwrite guard (Pinterest only — CAPI binds events to a
		// specific ad account).
		if ( null !== $route[ 'ad_account_key' ] && '' !== $adAccount && $existedBefore[ 'ad_account_id' ]
		     && !$replaceAdAccount ) {
			return new \WP_Error(
				'pys_mcp_ad_account_overwrite_requires_confirm', sprintf(
					'Slot %d already has a configured `ad_account_id` for `%s`. Pass `replace_existing_ad_account_id: true` to confirm overwrite — this binds Pinterest server events to a specific ad account.',
					$pixelIndex,
					$platform
				), array( 'status' => 400 )
			);
		}

		$payload                  = array();
		$fieldsWritten            = array();
		$replacedExisting         = array();
		$notes                    = array();
		$conversionLabelsApplied  = array();
		$conversionLabelsTargetId = '';
		if ( '' !== $singleSlotNote ) {
			$notes[] = $singleSlotNote;
		}

		if ( !empty( $ignoredNotes ) ) {
			$notes = array_merge( $notes, $ignoredNotes );
		}

		// 1. Pixel / tracking ID / conversion ID — written only when passed.
		if ( '' !== $pixelValue ) {
			$payload[ $route[ 'pixel_key' ] ] = self::writeToSlot(
				$settings->getOption( $route[ 'pixel_key' ] ),
				$pixelIndex,
				$pixelValue
			);
			$fieldsWritten[ $pixelArgKey ]    = true;
			$replacedExisting[ $pixelArgKey ] = $existedBefore[ $pixelArgKey ];
		}

		// 2. Token — written only when passed; only for platforms with a token_key.
		$capiEnabled = null;
		if ( '' !== $token ) {
			if ( null !== $route[ 'token_key' ] ) {
				$payload[ $route[ 'token_key' ] ] = self::writeToSlot(
					$settings->getOption( $route[ 'token_key' ] ),
					$pixelIndex,
					$token
				);
				$fieldsWritten[ 'token' ]         = true;
				$replacedExisting[ 'token' ]      = $existedBefore[ 'token' ];
			} else {
				// No server-side token for bing / reddit / google_ads.
				$fieldsWritten[ 'token' ] = false;
				$notes[]                  = sprintf(
					'`token` was provided but is silently ignored for `%s` (no server-side token in PYS addon).',
					$platform
				);
			}
		}

		// 2b. CAPI toggle. Explicit `capi_enabled` wins
		if ( null !== $route[ 'capi_flag_key' ] ) {
			$desiredCapi = $capiArgProvided ? $capiArg : ( ( '' !== $token && null !== $route[ 'token_key' ] ) ? true : null );
			if ( null !== $desiredCapi ) {
				$payload[ $route[ 'capi_flag_key' ] ] = $desiredCapi;
				$capiEnabled                          = $desiredCapi;
				if ( $capiArgProvided ) {
					$fieldsWritten[ 'capi_enabled' ] = true;
				}
				// Warn if enabling CAPI with no token configured or supplied.
				if ( $desiredCapi && '' === $token && !$existedBefore[ 'token' ] ) {
					$notes[] = sprintf(
						'CAPI was enabled for `%s` but no server-side token is configured — events will not deliver until a `token` is set.',
						$platform
					);
				}
			}
		} elseif ( $capiArgProvided ) {
			// google_ads / bing / reddit have no CAPI flag.
			$notes[] = sprintf( '`capi_enabled` is ignored for `%s` (no server-side API).', $platform );
		}

		// 3. Pinterest ad_account_id.
		if ( null !== $route[ 'ad_account_key' ] && '' !== $adAccount ) {
			$payload[ $route[ 'ad_account_key' ] ] = self::writeToSlot(
				$settings->getOption( $route[ 'ad_account_key' ] ),
				$pixelIndex,
				$adAccount
			);
			$fieldsWritten[ 'ad_account_id' ]      = true;
			$replacedExisting[ 'ad_account_id' ]   = $existedBefore[ 'ad_account_id' ];
		}

		// 4. Google Ads conversions[] — per-event conversion labels, keyed by
		// the primary conversion ID, stored under `{event}_conversion_labels`
		// (the same key the runtime reads).
		if ( null !== $labels ) {
			$targetId = $labelsTarget;
			$notes    = array_merge( $notes, $labels[ 'notes' ] );

			// Confirmed (or nothing actually changes) — stage the writes.
			foreach ( $labels[ 'payload' ] as $optionKey => $map ) {
				$settings->setOption( $optionKey, $map );
			}
			$fieldsWritten[ 'conversions' ] = ! empty( $labels[ 'payload' ] );
			$conversionLabelsApplied        = $labels[ 'applied' ];
			$conversionLabelsTargetId       = $targetId;
		}

		if ( '' !== $conditionalTrack ) {
			$payload[ 'logic_conditional_track' ] = $conditionalTrack;
			$fieldsWritten[ 'conditional_track' ] = true;
		}
		if ( $resetDisplayConditions ) {
			$settings->setOption(
				'main_pixel',
				array( (string) wp_json_encode( array( 'condition' => array( array( 'name' => 'all_site' ) ) ) ) )
			);
			$fieldsWritten[ 'display_conditions_reset' ] = true;
			$notes[]                                     = 'Primary-pixel display conditions reset to "all_site" (fires everywhere). Targeting specific pages/categories must be done in the admin.';
		}
		if ( $hasEnabledArg ) {
			$payload[ 'main_pixel_enabled' ]   = $enabledValue;
			$fieldsWritten[ 'enabled' ]        = true;
			if ( !$existedBefore[ $pixelArgKey ] ) {
				$notes[] = sprintf(
					'The %s master switch was set, but no pixel/ID is configured for this platform — it will not fire either way until a pixel is added.',
					$platform
				);
			}
		}
		// Display conditions only take effect while Super Pack is active.
		if ( ( '' !== $conditionalTrack || $resetDisplayConditions )
		     && !( function_exists( '\\PixelYourSite\\isSuperPackActive' ) && \PixelYourSite\isSuperPackActive() ) ) {
			$notes[] = 'Display-condition settings were stored, but Super Pack is INACTIVE — conditions are not enforced (the pixel fires site-wide) until Super Pack is active.';
		}

		$settings->updateOptions( $payload );

		if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		$response = array(
			'saved'             => true,
			'configured'        => true,
			'platform'          => $platform,
			'pixel_index'       => $pixelIndex,
			'fields_written'    => (object) $fieldsWritten,
			'replaced_existing' => (object) $replacedExisting,
			'notes'             => array_values( $notes ),
		);
		if ( null !== $capiEnabled ) {
			$response[ 'capi_enabled' ] = $capiEnabled;
		}
		if ( !empty( $conversionLabelsApplied ) ) {
			$response[ 'conversion_labels' ] = $conversionLabelsApplied;
		}
			if ( '' !== $conversionLabelsTargetId ) {
				$response[ 'conversion_labels_id' ] = $conversionLabelsTargetId;
			}

		return $response;
	}

	/**
	 * Resolve which Google Ads conversion ID per-event labels bind to.
	 *
	 * @param object $settings   Google Ads settings instance.
	 * @param array  $input      Raw tool input.
	 * @param string $pixelValue Conversion ID supplied in this same call, if any.
	 * @return string|\WP_Error The target ID, or an error when it cannot be resolved.
	 */
	private static function resolveAdsLabelTarget( $settings, array $input, string $pixelValue ) {

		// An explicit `conversion_labels_id` (incl. an extra Super Pack id) wins.
		$requested = isset( $input[ 'conversion_labels_id' ] ) && is_string( $input[ 'conversion_labels_id' ] )
			? trim( $input[ 'conversion_labels_id' ] ) : '';

		if ( '' !== $requested ) {
			$configured = self::configuredAdsIds( $settings );

			if ( !in_array( $requested, $configured, true ) ) {
				return new \WP_Error(
					'pys_mcp_ads_label_target_unknown',
					sprintf(
						'`conversion_labels_id: %s` is not a configured Google Ads conversion ID. Configured: %s.',
						$requested,
						!empty( $configured ) ? implode( ', ', $configured ) : '(none)'
					),
					array( 'status' => 409 )
				);
			}

			return $requested;
		}

		$primary = self::resolvePrimaryAdsId( $settings, $pixelValue );

		if ( '' === $primary ) {
			return new \WP_Error(
				'pys_mcp_ads_no_conversion_id',
				'Cannot set conversion labels: no Google Ads conversion ID configured. Pass `conversion_id` (AW-…) in this call, set it first, or pass `conversion_labels_id` (an existing primary/extra conversion ID).',
				array( 'status' => 409 )
			);
		}

		return $primary;
	}

	private static function confirmFingerprint( string $scope, string $platform, int $pixelIndex, array $args ): string {
		ksort( $args );

		return hash( 'sha256', (string) wp_json_encode( array( $scope, $platform, $pixelIndex, $args ) ) );
	}

	/**
	 * Decide what to do with a call that carries a confirmation-gated field.
	 *
	 * @param array  $input
	 * @param string $fingerprint
	 * @return string `preview` (no confirm sent), `stale` (confirm without a
	 *                valid preview) or `ok`.
	 */
	private static function checkConfirmation( array $input, string $fingerprint ): string {
		if ( empty( $input[ 'confirm' ] ) ) {
			return 'preview';
		}

		$id = isset( $input[ 'confirmation_id' ] ) ? (string) $input[ 'confirmation_id' ] : '';

		if ( '' === $id ) {
			return 'stale';
		}

		$stored = \PixelYourSite\MCP\Storage::getTtl( self::CONFIRM_PREFIX . $id );

		if ( ! is_string( $stored ) || ! hash_equals( $fingerprint, $stored ) ) {
			return 'stale';
		}

		return 'ok';
	}

	/**
	 * Issue a preview response, or a 400 when `confirm` arrived without one.
	 *
	 * A fresh `confirmation_id` is handed out in both cases so the caller can
	 * immediately re-send correctly — the point is to force the preview to be
	 * seen, not to make recovery hard.
	 *
	 * @param string $verdict  From {@see self::checkConfirmation()}.
	 * @param string $fingerprint
	 * @param array  $body     Preview fields to surface to the user.
	 * @return array|\WP_Error
	 */
	private static function confirmationResponse( string $verdict, string $fingerprint, array $body ) {
		$id = self::issueConfirmation( $fingerprint );

		// Notes the caller staged (e.g. an argument that cannot be honoured) must
		// survive: they are the only place the user learns something was dropped.
		$carried = isset( $body[ 'notes' ] ) ? (array) $body[ 'notes' ] : array();
		unset( $body[ 'notes' ] );

		if ( 'stale' === $verdict ) {
			return new \WP_Error(
				'pys_mcp_confirmation_required',
				'`confirm: true` was sent without a matching `confirmation_id`, so nothing was written. This guard exists because consent for one write does not carry over to another: show the preview below to the user, get explicit agreement, then re-call with BOTH `confirm: true` and this `confirmation_id`.',
				array(
					'status'          => 400,
					'confirmation_id' => $id,
					'preview'         => $body,
					'notes'           => $carried,
				)
			);
		}

		return array_merge(
			array(
				'confirmation_required' => true,
				'confirmation_id'       => $id,
			),
			$body,
			array(
				'notes' => array_merge(
					$carried,
					array( 'Nothing was written. Re-call with `confirm: true` AND this `confirmation_id` to apply.' )
				),
			)
		);
	}

	/**
	 * Store a fingerprint under a fresh id. Short-lived on purpose: a preview
	 * the user never saw should not stay usable.
	 *
	 * @param string $fingerprint
	 * @return string
	 */
	private static function issueConfirmation( string $fingerprint ): string {
		$id = wp_generate_password( 20, false, false );

		\PixelYourSite\MCP\Storage::setTtl( self::CONFIRM_PREFIX . $id, $fingerprint, self::CONFIRM_TTL );

		return $id;
	}

	/**
	 * One preview authorises one write.
	 *
	 * @param string $id
	 * @return void
	 */
	private static function consumeConfirmation( $id ): void {
		if ( is_string( $id ) && '' !== $id ) {
			\PixelYourSite\MCP\Storage::deleteTtl( self::CONFIRM_PREFIX . $id );
		}
	}

	/**
	 * Write Enhanced Conversions. Google Ads EC is PER-PIXEL: the option
	 * `enhanced_conversions_manual_enabled` is a marker array holding the literal
	 * string "index_P" for every conversion pixel position P whose EC is ON
	 * (P = MCP pixel_index: 0 = primary, 1..N = stored Super Pack extra pixels;
	 * matches the admin's render_switcher_input_array and runtime
	 * `.includes("index_"+i)`). We MERGE markers — never overwrite the whole
	 * array — so toggling one pixel never disturbs the others. Bing EC is a single
	 * platform-wide bool. Consent-sensitive (hashed PII) → server-side two-step
	 * confirm. When `pixel_index` is omitted for Google Ads, EC is applied to ALL
	 * conversion pixels; when given, only that one.
	 *
	 * @param string $platform           Platform slug.
	 * @param array  $route              ROUTING entry.
	 * @param array  $input              Validated args.
	 * @param bool   $ecArg              Desired EC state.
	 * @param bool   $pixelIndexProvided Whether the caller passed an explicit pixel_index.
	 * @param int    $pixelIndex         Target pixel index (0 = primary).
	 * @return array<string, mixed>|\WP_Error
	 */
	private static function writeEnhancedConversions( string $platform, array $route, array $input, bool $ecArg, bool $pixelIndexProvided, int $pixelIndex ) {
		if ( empty( $route[ 'ec_key' ] ) ) {
			return new \WP_Error(
				'pys_mcp_ec_unsupported',
				sprintf( '`enhanced_conversions` is not supported for `%s` — only Google Ads and Bing have Enhanced Conversions. Nothing was written.', $platform ),
				array( 'status' => 409 )
			);
		}

		$ecFingerprint = self::confirmFingerprint(
			'enhanced_conversions',
			$platform,
			$pixelIndexProvided ? $pixelIndex : -1,
			array( 'enhanced_conversions' => $ecArg )
		);
		$ecVerdict     = self::checkConfirmation( $input, $ecFingerprint );

		if ( 'ok' !== $ecVerdict ) {
			$scope = ( !empty( $route[ 'ec_marker' ] ) && !$pixelIndexProvided )
				? ' for ALL of this platform\'s conversion pixels'
				: ( !empty( $route[ 'ec_marker' ] ) ? sprintf( ' for conversion pixel index %d only', $pixelIndex ) : '' );

			return self::confirmationResponse(
				$ecVerdict,
				$ecFingerprint,
				array(
					'platform'              => $platform,
					'pixel_index'           => $pixelIndex,
					'action'                => $ecArg ? 'enable_enhanced_conversions' : 'disable_enhanced_conversions',
					'enhanced_conversions'  => $ecArg,
					'applies_to_all_pixels' => !$pixelIndexProvided,
					'warning'               => $ecArg
						? sprintf( 'Enabling Enhanced Conversions%s makes %s receive HASHED first-party user data (email, phone, etc.) to improve conversion match quality. Confirm the site has user consent (GDPR / cookie consent).', $scope, $platform )
						: sprintf( 'This turns Enhanced Conversions OFF%s for %s.', $scope, $platform ),
				)
			);
		}

		self::consumeConfirmation( $input[ 'confirmation_id' ] ?? null );

		$fn = $route[ 'fn' ];
		if ( !function_exists( $fn ) ) {
			return new \WP_Error( 'pys_mcp_platform_unavailable', sprintf( 'Platform "%s" addon is not active.', $platform ), array( 'status' => 503 ) );
		}
		$settings = $fn();
		if ( !is_object( $settings ) || !method_exists( $settings, 'getOption' ) || !method_exists( $settings, 'updateOptions' ) ) {
			return new \WP_Error( 'pys_mcp_platform_unavailable', sprintf( 'Platform "%s" Settings instance is not usable.', $platform ), array( 'status' => 503 ) );
		}

		// Bing: single platform-wide checkbox bool.
		if ( empty( $route[ 'ec_marker' ] ) ) {
			$settings->updateOptions( array( $route[ 'ec_key' ] => $ecArg ) );
			if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
				\PixelYourSite\purgeCache();
			}

			return array(
				'saved'                => true,
				'configured'           => true,
				'platform'             => $platform,
				'pixel_index'          => $pixelIndex,
				'enhanced_conversions' => $ecArg,
				'fields_written'       => (object) array( 'enhanced_conversions' => true ),
				'notes'                => array(),
			);
		}

		// Google Ads: per-pixel marker merge.
		$pixels = self::adsConversionPixels( $settings );
		if ( empty( $pixels ) ) {
			return new \WP_Error(
				'pys_mcp_ec_no_conversion',
				'Cannot set Enhanced Conversions: no Google Ads conversion ID is configured. Add a conversion ID first.',
				array( 'status' => 409 )
			);
		}

		$validIndices = array();
		foreach ( $pixels as $p ) {
			$validIndices[] = $p[ 'index' ];
		}
		if ( $pixelIndexProvided ) {
			if ( !in_array( $pixelIndex, $validIndices, true ) ) {
				return new \WP_Error(
					'pys_mcp_ec_pixel_unknown',
					sprintf(
						'`pixel_index: %d` is not a configured Google Ads conversion pixel. Configured indices: %s (0 = primary). Nothing was written.',
						$pixelIndex,
						implode( ', ', $validIndices )
					),
					array( 'status' => 409 )
				);
			}
			$targets = array( $pixelIndex );
		} else {
			$targets = $validIndices; // omitted → all conversion pixels
		}

		// Existing markers as a set, then merge the targets.
		$markers = array();
		foreach ( (array) $settings->getOption( $route[ 'ec_key' ] ) as $v ) {
			if ( is_string( $v ) && 0 === strpos( $v, 'index_' ) ) {
				$markers[ $v ] = true;
			}
		}
		foreach ( $targets as $p ) {
			$marker = 'index_' . $p;
			if ( $ecArg ) {
				$markers[ $marker ] = true;
			} else {
				unset( $markers[ $marker ] );
			}
		}

		$settings->updateOptions( array( $route[ 'ec_key' ] => array_values( array_keys( $markers ) ) ) );
		if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		$notes = array(
			$pixelIndexProvided
				? sprintf( 'Enhanced Conversions %s for Google Ads conversion pixel index %d only — other pixels were left unchanged.', $ecArg ? 'ENABLED' : 'DISABLED', $pixelIndex )
				: sprintf( 'Enhanced Conversions %s for ALL %d Google Ads conversion pixel(s) (primary + extras).', $ecArg ? 'ENABLED' : 'DISABLED', count( $targets ) ),
		);

		if ( $ecArg ) {
			$enabledByIndex = array();
			foreach ( $pixels as $px ) {
				$enabledByIndex[ $px[ 'index' ] ] = !empty( $px[ 'enabled' ] );
			}
			$offTargets = array();
			foreach ( $targets as $p ) {
				if ( isset( $enabledByIndex[ $p ] ) && !$enabledByIndex[ $p ] ) {
					$offTargets[] = $p;
				}
			}
			if ( !empty( $offTargets ) ) {
				$notes[] = sprintf(
					'Note: pixel index %s %s currently DISABLED — Enhanced Conversions will not take effect until the pixel is enabled (set_platform_credential with that pixel_index + enabled: true).',
					implode( ', ', $offTargets ),
					1 === count( $offTargets ) ? 'is' : 'are'
				);
			}
		}

		return array(
			'saved'                         => true,
			'configured'                    => true,
			'platform'                      => 'google_ads',
			'pixel_index'                   => $pixelIndex,
			'applies_to_all_pixels'         => !$pixelIndexProvided,
			'fields_written'                => (object) array( 'enhanced_conversions' => true ),
			'enhanced_conversions_by_pixel' => self::adsEcByPixel( $settings ),
			'notes'                         => $notes,
		);
	}

	/**
	 * Ordered Google Ads conversion pixels: primary (index 0, first non-empty
	 * `ads_ids`) then each stored Super Pack extra (index 1..N). Index aligns with
	 * the EC marker "index_N" and the MCP pixel_index. Each entry carries `enabled`
	 * (primary: main_pixel_enabled, default on; extra: isEnable).
	 *
	 * @param object $settings Ads Settings instance.
	 * @return array<int, array{index:int, conversion_id:string, enabled:bool}>
	 */
	private static function adsConversionPixels( $settings ): array {
		$out       = array();
		$primaryId = '';
		foreach ( (array) $settings->getOption( 'ads_ids' ) as $v ) {
			if ( is_string( $v ) && '' !== trim( $v ) ) {
				$primaryId = trim( $v );
				break;
			}
		}
		if ( '' !== $primaryId ) {
			$rawEn = $settings->getOption( 'main_pixel_enabled' );
			$out[] = array(
				'index'         => 0,
				'conversion_id' => $primaryId,
				'enabled'       => ( null === $rawEn ) ? true : ( '1' === (string) $rawEn || true === $rawEn || 'true' === strtolower( (string) $rawEn ) ),
			);
		}
		if ( function_exists( '\\PixelYourSite\\isSuperPackActive' ) && \PixelYourSite\isSuperPackActive()
		     && function_exists( '\\PixelYourSite\\SuperPack' ) ) {
			$sp = \PixelYourSite\SuperPack();
			if ( is_object( $sp ) && method_exists( $sp, 'getAdsAdditionalPixel' ) ) {
				$i = 1;
				foreach ( (array) $sp->getAdsAdditionalPixel() as $p ) {
					$id = ( is_object( $p ) && isset( $p->pixel ) ) ? trim( (string) $p->pixel ) : '';
					if ( '' !== $id ) {
						$out[] = array(
							'index'         => $i,
							'conversion_id' => $id,
							'enabled'       => !empty( $p->isEnable ),
						);
					}
					$i++;
				}
			}
		}

		return $out;
	}

	/**
	 * Per-pixel Enhanced Conversions state for Google Ads, derived from the
	 * marker array. Shape: { primary: {conversion_id, enabled, enhanced_conversions},
	 * extra_pixels: [{pixel_index, conversion_id, enabled, enhanced_conversions}] }.
	 *
	 * @param object $settings Ads Settings instance.
	 * @return array<string, mixed>
	 */
	private static function adsEcByPixel( $settings ): array {
		$markers = array();
		foreach ( (array) $settings->getOption( 'enhanced_conversions_manual_enabled' ) as $v ) {
			if ( is_string( $v ) ) {
				$markers[ $v ] = true;
			}
		}
		$res = array();
		foreach ( self::adsConversionPixels( $settings ) as $p ) {
			$state = isset( $markers[ 'index_' . $p[ 'index' ] ] ) ? 'enabled' : 'disabled';
			if ( 0 === $p[ 'index' ] ) {
				$res[ 'primary' ] = array( 'conversion_id' => $p[ 'conversion_id' ], 'enabled' => $p[ 'enabled' ], 'enhanced_conversions' => $state );
			} else {
				$res[ 'extra_pixels' ][] = array(
					'pixel_index'          => $p[ 'index' ],
					'enabled'              => $p[ 'enabled' ],
					'conversion_id'        => $p[ 'conversion_id' ],
					'enhanced_conversions' => $state,
				);
			}
		}

		return $res;
	}

	/**
	 * Write (add or update) a PixelYourSite Super Pack EXTRA pixel for one of
	 * the supported platforms (facebook / google_analytics / google_ads).
	 *
	 * Extra pixels live in their own per-platform option (`fb_ext_pixel_id` /
	 * `ga_ext_pixel_id` / `ads_ext_pixel_id`) as a list of JSON-encoded
	 * `SuperPack\SPPixelId` objects — NOT the core `pixel_id[n]` slots. The
	 * caller's `pixel_index` is 1-based over that list: `1` = first extra
	 * pixel (stored index 0). `pixel_index == count + 1` ADDS a new pixel; an
	 * existing index UPDATES it (partial — only `pixel_id`/`token`/`enabled`,
	 * preserving every other stored field, including fire/condition settings).
	 *
	 * MVP scope: pixel id + enabled + CAPI token. CAPI token storage differs by
	 * platform — Facebook keeps it in `extensions.api_token`, GA4 in
	 * `server_access_api_token`; Google Ads has no server-side token. The token
	 * value is never echoed. Persists via `setOption` + `updateOptions([])` so
	 * the raw JSON (incl. unicode tokens) is written verbatim, bypassing the
	 * array-field sanitiser that the admin form path would run.
	 *
	 * @param string $platform   Platform slug (already validated, has `superpack`).
	 * @param array  $route       ROUTING entry for the platform.
	 * @param int    $pixelIndex  1-based extra-pixel index from the caller.
	 * @param array  $input       Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	private static function writeSuperPackExtraPixel( string $platform, array $route, int $pixelIndex, array $input ) {
		// Super Pack must be active.
		if ( !function_exists( '\\PixelYourSite\\isSuperPackActive' ) || !\PixelYourSite\isSuperPackActive() ) {
			return new \WP_Error(
				'pys_mcp_superpack_inactive',
				'Extra pixels require the PixelYourSite Super Pack addon, which is not active on this site. Activate Super Pack, then retry. Nothing was written.',
				array( 'status' => 409 )
			);
		}
		if ( !function_exists( '\\PixelYourSite\\SuperPack' ) ) {
			return new \WP_Error( 'pys_mcp_superpack_inactive', 'Super Pack is not available on this site.', array( 'status' => 409 ) );
		}
		$sp = \PixelYourSite\SuperPack();
		if ( !is_object( $sp ) || !method_exists( $sp, 'getOption' ) || !method_exists( $sp, 'updateOptions' )
		     || !method_exists( $sp, 'setOption' ) ) {
			return new \WP_Error( 'pys_mcp_superpack_inactive', 'Super Pack Settings instance is not usable.', array( 'status' => 503 ) );
		}

		$extraOption = $route[ 'superpack' ][ 'extra_option' ];
		$tokenMode   = $route[ 'superpack' ][ 'token_mode' ];
		$hasCapi     = !empty( $route[ 'superpack' ][ 'capi' ] );

		// Raw list of JSON strings (NOT decoded objects).
		$raw   = array_values( (array) $sp->getOption( $extraOption ) );
		$count = count( $raw );

		// 1-based caller index → 0-based stored index. No gaps allowed.
		$spIndex = $pixelIndex - 1;
		if ( $spIndex > $count ) {
			return new \WP_Error(
				'pys_mcp_extra_pixel_gap',
				sprintf(
					'Cannot write `pixel_index: %d` for `%s`: there %s currently %d extra pixel(s). Use 1..%d to update an existing extra pixel, or %d to add the next one. Nothing was written.',
					$pixelIndex,
					$platform,
					1 === $count ? 'is' : 'are',
					$count,
					$count,
					$count + 1
				),
				array( 'status' => 409 )
			);
		}
		$isUpdate = $spIndex < $count;

		$pixelArgKey  = $route[ 'pixel_arg' ];
		$pixelValue   = isset( $input[ $pixelArgKey ] ) && is_string( $input[ $pixelArgKey ] ) ? trim( $input[ $pixelArgKey ] ) : '';
		$token        = isset( $input[ 'token' ] ) && is_string( $input[ 'token' ] ) ? trim( $input[ 'token' ] ) : '';
		$replacePixel = !empty( $input[ 'replace_existing_pixel_id' ] ) || !empty( $input[ 'replace_existing_conversion_id' ] );
		$replaceToken = !empty( $input[ 'replace_existing_token' ] );
		$hasEnabled   = array_key_exists( 'enabled', $input ) && is_bool( $input[ 'enabled' ] );
		$enabled      = $hasEnabled ? (bool) $input[ 'enabled' ] : null;
		// Explicit CAPI toggle (use_server_api), independent of the token.
		$capiArgProvided = array_key_exists( 'capi_enabled', $input ) && is_bool( $input[ 'capi_enabled' ] );
		$capiArg         = $capiArgProvided ? (bool) $input[ 'capi_enabled' ] : null;

		// At least one writeable field.
		if ( '' === $pixelValue && '' === $token && !$hasEnabled && !$capiArgProvided ) {
			return new \WP_Error(
				'pys_mcp_credential_no_args',
				sprintf(
					'No fields to update for extra pixel %d of `%s`. Pass at least one of `%s`, `token` (where supported), `enabled` or `capi_enabled`.',
					$pixelIndex,
					$platform,
					$pixelArgKey
				),
				array( 'status' => 400 )
			);
		}

		$gates    = array();
		$previews = array();
		// Raised before the gate so a preview reports it too.
		$ignoredNotes = array();

		if ( !empty( $input[ 'conversions' ] ) ) {
			$ignoredNotes[] = '`conversions[]` was IGNORED: conversion labels are not written through `pixel_index`. Pass them without `pixel_index`, using `conversion_labels_id` to pick which Google Ads conversion ID they bind to.';
		}

		if ( $isUpdate && $hasEnabled && '' === $pixelValue && '' === $token ) {
			$gates[ 'enabled' ] = $enabled;
			$previews[]         = array(
				'action'  => $enabled ? 'enable_pixel' : 'disable_pixel',
				'enabled' => $enabled,
				'warning' => $enabled
					? sprintf( 'This will ENABLE Super Pack extra pixel %d of %s — it will start firing events.', $pixelIndex, $platform )
					: sprintf( 'This will DISABLE Super Pack extra pixel %d of %s — it will STOP firing events.', $pixelIndex, $platform ),
			);
		}

		if ( $capiArgProvided && $hasCapi && null !== $tokenMode ) {
			$gates[ 'capi_enabled' ] = $capiArg;
			$previews[]              = array(
				'action'       => $capiArg ? 'enable_capi' : 'disable_capi',
				'capi_enabled' => $capiArg,
				'warning'      => $capiArg
					? sprintf( 'This turns the Conversions API ON for Super Pack extra pixel %d of %s: it will start sending events server-side, including hashed email / external id and the visitor IP and user agent. Confirm the site has the necessary user consent.', $pixelIndex, $platform )
					: sprintf( 'This turns the Conversions API OFF for Super Pack extra pixel %d of %s: server-side events stop, and conversions that only arrive that way will no longer be measured.', $pixelIndex, $platform ),
			);
		}

		if ( !empty( $gates ) ) {
			$extraFp      = self::confirmFingerprint( 'write', $platform, $pixelIndex, $gates );
			$extraVerdict = self::checkConfirmation( $input, $extraFp );

			if ( 'ok' === $extraVerdict ) {
				self::consumeConfirmation( $input[ 'confirmation_id' ] ?? null );
			} else {
				$body = array(
					'platform'    => $platform,
					'pixel_index' => $pixelIndex,
					'changes'     => $previews,
				);

				if ( 1 === count( $previews ) ) {
					$body = array_merge( $body, $previews[ 0 ] );
				}

				if ( !empty( $ignoredNotes ) ) {
					$body[ 'notes' ] = $ignoredNotes;
				}

				return self::confirmationResponse( $extraVerdict, $extraFp, $body );
			}
		}

		if ( $isUpdate ) {
			$decoded = json_decode( (string) $raw[ $spIndex ], true );
			$obj     = is_array( $decoded ) ? $decoded : array();
		} else {
			if ( '' === $pixelValue ) {
				return new \WP_Error(
					'pys_mcp_credential_pixel_required',
					sprintf( 'Adding a new extra pixel for `%s` requires `%s` (the pixel/ID value).', $platform, $pixelArgKey ),
					array( 'status' => 400 )
				);
			}
			$obj = array( 'is_enable' => true );
		}

		$notes            = array();
		$fieldsWritten    = array();
		$replacedExisting = array();
		$capiEnabled      = null;

		if ( !empty( $ignoredNotes ) ) {
			$notes = array_merge( $notes, $ignoredNotes );
		}

		// --- pixel / conversion id ---
		if ( '' !== $pixelValue ) {
			$existingId = isset( $obj[ 'pixel_id' ] ) && is_string( $obj[ 'pixel_id' ] ) ? trim( $obj[ 'pixel_id' ] ) : '';
			if ( $isUpdate && '' !== $existingId && $existingId !== $pixelValue && !$replacePixel ) {
				$flag = 'conversion_id' === $pixelArgKey ? 'replace_existing_conversion_id' : 'replace_existing_pixel_id';
				return new \WP_Error(
					'pys_mcp_pixel_overwrite_requires_confirm',
					sprintf(
						'Extra pixel %d of `%s` already has the id `%s`. Pass `%s: true` to confirm overwriting it.',
						$pixelIndex,
						$platform,
						$existingId,
						$flag
					),
					array( 'status' => 400 )
				);
			}
			$obj[ 'pixel_id' ]                = $pixelValue;
			$fieldsWritten[ $pixelArgKey ]    = true;
			$replacedExisting[ $pixelArgKey ] = $isUpdate && '' !== $existingId;
		}

		// --- enabled toggle ---
		if ( $hasEnabled ) {
			$obj[ 'is_enable' ]         = $enabled;
			$fieldsWritten[ 'enabled' ] = true;
		}

		// --- CAPI token (platform-specific storage) ---
		if ( '' !== $token ) {
			if ( !$hasCapi || null === $tokenMode ) {
				$fieldsWritten[ 'token' ] = false;
				$notes[]                  = sprintf(
					'`token` was provided but is ignored for `%s` extra pixels (no server-side API for this platform).',
					$platform
				);
			} else {
				$existingToken = 'fb_extensions' === $tokenMode
					? ( isset( $obj[ 'extensions' ][ 'api_token' ] ) && is_string( $obj[ 'extensions' ][ 'api_token' ] ) ? trim( $obj[ 'extensions' ][ 'api_token' ] ) : '' )
					: ( isset( $obj[ 'server_access_api_token' ] ) && is_string( $obj[ 'server_access_api_token' ] ) ? trim( $obj[ 'server_access_api_token' ] ) : '' );

				if ( $isUpdate && '' !== $existingToken && !$replaceToken ) {
					return new \WP_Error(
						'pys_mcp_token_overwrite_requires_confirm',
						sprintf(
							'Extra pixel %d of `%s` already has a CAPI token. Pass `replace_existing_token: true` to confirm overwrite — the previous token cannot be recovered.',
							$pixelIndex,
							$platform
						),
						array( 'status' => 400 )
					);
				}

				if ( 'fb_extensions' === $tokenMode ) {
					if ( !isset( $obj[ 'extensions' ] ) || !is_array( $obj[ 'extensions' ] ) ) {
						$obj[ 'extensions' ] = array();
					}
					$obj[ 'extensions' ][ 'api_token' ] = $token;
				} else {
					$obj[ 'server_access_api_token' ] = $token;
					if ( isset( $obj[ 'extensions' ][ 'api_token' ] ) ) {
						unset( $obj[ 'extensions' ][ 'api_token' ] );
					}
				}
				$obj[ 'use_server_api' ]     = true;
				$fieldsWritten[ 'token' ]    = true;
				$replacedExisting[ 'token' ] = $isUpdate && '' !== $existingToken;
				$capiEnabled                 = true;
			}
		}

		if ( $capiArgProvided ) {
			if ( $hasCapi && null !== $tokenMode ) {
				$obj[ 'use_server_api' ]         = $capiArg;
				$fieldsWritten[ 'capi_enabled' ] = true;
				$capiEnabled                     = $capiArg;
				// Warn if enabling with no token present (existing or supplied).
				if ( $capiArg && '' === $token ) {
					$existingTok = 'fb_extensions' === $tokenMode
						? ( isset( $obj[ 'extensions' ][ 'api_token' ] ) && '' !== trim( (string) $obj[ 'extensions' ][ 'api_token' ] ) )
						: ( isset( $obj[ 'server_access_api_token' ] ) && '' !== trim( (string) $obj[ 'server_access_api_token' ] ) );
					if ( !$existingTok ) {
						$notes[] = sprintf(
							'CAPI enabled for extra pixel %d of `%s` but no token is configured — events will not deliver until a `token` is set.',
							$pixelIndex,
							$platform
						);
					}
				}
			} else {
				$notes[] = sprintf( '`capi_enabled` is ignored for `%s` extra pixels (no server-side API).', $platform );
			}
		}

		// Re-encode, preserving unicode + slashes to match the JS-saved format.
		$encoded = json_encode( $obj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		if ( false === $encoded ) {
			return new \WP_Error( 'pys_mcp_extra_pixel_encode_failed', 'Failed to encode the extra pixel for storage.', array( 'status' => 500 ) );
		}
		$raw[ $spIndex ] = $encoded;

		$sp->setOption( $extraOption, array_values( $raw ) );

		if ( !$sp->getOption( 'additional_ids_enabled' ) ) {
			$sp->setOption( 'additional_ids_enabled', true );
			$notes[] = 'Enabled the Super Pack "additional pixel IDs" option so the extra pixel can fire.';
		}
		// Warn (do not auto-flip) when the Super Pack module itself is off.
		if ( !$sp->getOption( 'enabled' ) ) {
			$notes[] = 'Note: the Super Pack module is currently disabled — enable it in PixelYourSite → Super Pack for extra pixels to load on the site.';
		}

		$sp->updateOptions( array() );

		if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		$response = array(
			'saved'             => true,
			'configured'        => true,
			'platform'          => $platform,
			'pixel_index'       => $pixelIndex,
			'created'           => !$isUpdate,
			'fields_written'    => (object) $fieldsWritten,
			'replaced_existing' => (object) $replacedExisting,
			'notes'             => array_values( $notes ),
		);
		if ( null !== $capiEnabled ) {
			$response[ 'capi_enabled' ] = $capiEnabled;
		}

		return $response;
	}

	/**
	 * Does `$current[$index]` hold a non-empty string value? Used by the
	 * pre-write detection step to decide whether token-overwrite guard
	 * should fire and to populate the `replaced_existing` response flags.
	 * Empty string, missing index, non-array storage, and non-string slot
	 * values all return `false` (treated as "no real value here").
	 *
	 * @param mixed $current Whatever `getOption` returned.
	 * @param int   $index   Zero-based slot to inspect.
	 * @return bool
	 */
	private static function slotHasValue( $current, int $index ): bool {
		if ( !is_array( $current ) ) {
			return false;
		}
		$arr = array_values( $current );
		if ( !isset( $arr[ $index ] ) ) {
			return false;
		}
		$slot = $arr[ $index ];

		return is_string( $slot ) && '' !== trim( $slot );
	}

	/**
	 * Write `$value` to `$current[$index]`, preserving other slots. Empty
	 * existing values are kept padded to maintain slot indices. Returns the
	 * new array ready for `updateOptions`.
	 *
	 * @param mixed  $current Whatever `getOption` returned (array, scalar, null).
	 * @param int    $index   Zero-based slot.
	 * @param string $value   Sanitised value (trimmed at call site).
	 * @return array<int, string>
	 */
	private static function writeToSlot( $current, int $index, string $value ): array {
		$arr = is_array( $current ) ? array_values( $current ) : array();
		// Pad with empty strings up to and including $index.
		for ( $i = count( $arr ); $i <= $index; $i++ ) {
			$arr[ $i ] = '';
		}
		$arr[ $index ] = $value;

		return $arr;
	}

	/**
	 * Resolve the primary Google Ads conversion ID (AW-…) that per-event
	 * labels are keyed under: the value being written this call, else the
	 * first non-empty existing `ads_ids` slot.
	 *
	 * @param object $settings   The Ads Settings instance.
	 * @param string $pixelValue The conversion_id being written this call (or '').
	 * @return string Primary AW id, or '' when none is configured.
	 */
	private static function resolvePrimaryAdsId( $settings, string $pixelValue ): string {
		if ( '' !== $pixelValue ) {
			return $pixelValue;
		}
		$ids = $settings->getOption( 'ads_ids' );
		if ( is_array( $ids ) ) {
			foreach ( $ids as $id ) {
				if ( is_string( $id ) && '' !== trim( $id ) ) {
					return trim( $id );
				}
			}
		} elseif ( is_string( $ids ) && '' !== trim( $ids ) ) {
			return trim( $ids );
		}

		return '';
	}

	/**
	 * All configured Google Ads conversion IDs (`AW-…`) — primary `ads_ids`
	 * slots plus Super Pack extra conversion IDs. The valid set a label may be
	 * bound to (#4.2b).
	 *
	 * @param object $settings The Ads Settings instance.
	 * @return array<int, string>
	 */
	private static function configuredAdsIds( $settings ): array {
		$ids = array();
		foreach ( (array) $settings->getOption( 'ads_ids' ) as $id ) {
			if ( is_string( $id ) && '' !== trim( $id ) ) {
				$ids[] = trim( $id );
			}
		}
		if ( function_exists( '\PixelYourSite\isSuperPackActive' ) && \PixelYourSite\isSuperPackActive()
		     && function_exists( '\PixelYourSite\SuperPack' ) ) {
			$sp = \PixelYourSite\SuperPack();
			if ( is_object( $sp ) && method_exists( $sp, 'getAdsAdditionalPixel' ) ) {
				foreach ( $sp->getAdsAdditionalPixel() as $p ) {
					$pid = isset( $p->pixel ) ? trim( (string) $p->pixel ) : '';
					if ( '' !== $pid ) {
						$ids[] = $pid;
					}
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Build the per-event conversion-label option writes. Each label lives on
	 * the Ads module under `{event}_conversion_labels` as a
	 * `{ AW-tag-id => label }` map (the key the runtime reads); the label is
	 * bound to `$targetId` (primary or an extra Super Pack conversion id),
	 * preserving any labels for other tag ids. An empty
	 * label clears the entry. Unknown / unregistered events are skipped with a
	 * note rather than creating junk options.
	 *
	 * Only entries that actually change a value are staged (idempotent
	 * re-sets are silently skipped). `pending` mirrors those changes as
	 * `current → new` for the two-step confirmation preview.
	 *
	 * @param object $settings     The Ads Settings instance.
	 * @param array  $conversions  Raw `conversions[]` arg entries.
	 * @param string $targetId    Target AW-… conversion ID to key labels under (primary or an extra Super Pack id).
	 * @return array{payload: array<string, array>, applied: array<int, array>, notes: array<int, string>, pending: array<string, array>}
	 */
	private static function buildAdsConversionLabels( $settings, array $conversions, string $targetId ): array {
		$payload = array();
		$applied = array();
		$notes   = array();
		$pending = array();

		foreach ( $conversions as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$event = isset( $entry[ 'event' ] ) && is_string( $entry[ 'event' ] ) ? $entry[ 'event' ] : '';
			$label = isset( $entry[ 'label' ] ) && is_string( $entry[ 'label' ] ) ? trim( $entry[ 'label' ] ) : '';

			$optionKey = $event . '_conversion_labels';
			if ( ! in_array( $event, self::ADS_LABEL_EVENTS, true ) ) {
				$notes[] = sprintf( 'Conversion label for `%s` skipped: not a recognised Google Ads label event.', $event );
				continue;
			}

			$domainActive = true;
			if ( 0 === strpos( $event, 'woo_' ) ) {
				$domainActive = function_exists( '\\PixelYourSite\\isWooCommerceActive' ) && \PixelYourSite\isWooCommerceActive();
			} elseif ( 0 === strpos( $event, 'edd_' ) ) {
				$domainActive = function_exists( '\\PixelYourSite\\isEddActive' ) && \PixelYourSite\isEddActive();
			}
			if ( ! $domainActive ) {
				$notes[] = sprintf( 'Conversion label for `%s` skipped: its ecommerce module (WooCommerce / EDD) is not active on this site.', $event );
				continue;
			}

			$map = $settings->getOption( $optionKey );
			if ( ! is_array( $map ) ) {
				$map = array();
			}
			$previous = isset( $map[ $targetId ] ) && is_string( $map[ $targetId ] ) ? $map[ $targetId ] : '';

			// No-op: same value already set — nothing to confirm or write.
			if ( $label === $previous ) {
				continue;
			}

			$pending[ $event ] = array(
				'current' => $previous,
				'new'     => $label,
			);

			if ( '' === $label ) {
				unset( $map[ $targetId ] );
			} else {
				$map[ $targetId ] = $label;
			}

			$payload[ $optionKey ] = $map;
			$applied[]             = array(
				'event'    => $event,
				'tag_id'   => $targetId,
				'label'    => $label,
				'replaced' => '' !== $previous,
			);
		}

		return array(
			'payload' => $payload,
			'applied' => $applied,
			'notes'   => $notes,
			'pending' => $pending,
		);
	}
}
