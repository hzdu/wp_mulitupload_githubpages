<?php
/**
 * `get_custom_events` — read-only list of PYS custom events.
 *
 * Lightweight overview: one row per custom event (post type `pys_event`) with
 * id, title, enabled state, which platforms are enabled, trigger / condition
 * counts and the fire settings. Use `get_custom_event` for the full per-event
 * detail. The feature master gate (`custom_events_enabled`) is reported too —
 * when off, no custom event fires regardless of its own state.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class GetCustomEventsAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-custom-events';

	private const ADMIN_UI_PATH = 'PixelYourSite → Events';

	private const TRIGGER_LABELS = array(
		'page_visit'            => 'Page visit',
		'home_page'             => 'Home page',
		'add_to_cart'           => 'WooCommerce add to cart',
		'purchase'              => 'WooCommerce purchase',
		'number_page_visit'     => 'Number of Page Visits',
		'url_click'             => 'Click on HTML link',
		'css_click'             => 'Click on CSS selector',
		'css_mouseover'         => 'Mouse over CSS selector',
		'scroll_pos'            => 'Page Scroll',
		'post_type'             => 'Post type',
		'video_view'            => 'Embedded Video View',
		'email_link'            => 'Email Link',
		'form_field'            => 'Filling out a form field',
		'copy_element'          => 'Copy element (text copy)',
		'video_speed'           => 'Embedded Video speed',
		'gads_phone_conversion' => 'Google Ads Phone Conversion',
	);

	private const PLATFORM_FNS = array(
		'facebook'  => '\\PixelYourSite\\Facebook',
		'openai'    => '\\PixelYourSite\\OpenAI',
		'gtm'       => '\\PixelYourSite\\GTM',
		'tiktok'    => '\\PixelYourSite\\Tiktok',
		'bing'      => '\\PixelYourSite\\Bing',
		'pinterest' => '\\PixelYourSite\\Pinterest',
		'reddit'    => '\\PixelYourSite\\Reddit',
	);

	private const PLATFORM_EVENT_METHODS = array(
		'facebook'  => 'isFacebookEnabled',
		'openai'    => 'isOpenAIEnabled',
		'gtm'       => 'isGTMEnabled',
		'tiktok'    => 'isTikTokEnabled',
		'bing'      => 'isBingEnabled',
		'pinterest' => 'isPinterestEnabled',
		'reddit'    => 'isRedditEnabled',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get Custom Events';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Lists the PixelYourSite CUSTOM EVENTS configured on this site — user-defined events that fire to one or more pixels when their triggers match. This is the lightweight overview (one row per event); call `get_custom_event` with an `event_id` from here for the full per-event detail (per-platform settings, triggers, conditions, parameters). Top-level `feature_enabled` reflects the master switch `custom_events_enabled` — when false NO custom event fires regardless of its own `enabled` state, so surface that first. Each `events[]` row has: `event_id` (use it for `get_custom_event` / `set_custom_event` / `manage_custom_event`), `title`, `enabled` (the event\'s own active/paused state), `networks` (the networks this event ACTUALLY fires to — same logic as the admin Events "Networks" column: a network is listed only when the platform is globally enabled AND has pixels AND the event targets it; so an event can target a platform yet not appear here if that platform has no pixels or is off. Google is split into `google_tags` = Google Analytics / Google tag (`G-…`) and `google_ads` = Google Ads (`AW-…`), both off the unify-analytics setting — mirroring the separate GA and Ads icons in the admin), `trigger_count`, `trigger_types` (the working triggers as readable labels, one per trigger in order — e.g. "Page visit", "Email Link", "Page Scroll" — type only, no detail; use `get_custom_event` for trigger detail), `condition_count`, `conditions_enabled`, `trigger_logic` (OR/AND), `fire_frequency` (once / every_time) and `time_window` (when "fire only once in N hours" is on). An event with `trigger_count: 0` never fires (no trigger to match) — worth flagging. Read-only. Call this when the user asks what custom events exist, or to find an event before editing it.';
	}

	/**
	 * Input JSON-Schema (no args).
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'feature_enabled', 'events' ),
			'properties' => array(
				'feature_enabled' => array(
					'type'        => 'boolean',
					'description' => 'Master switch `custom_events_enabled`. When false, NO custom event fires regardless of its own enabled state.',
				),
				'admin_ui_path'   => array( 'type' => 'string' ),
				'events'          => array(
					'type'        => 'array',
					'description' => 'One row per custom event. Use `event_id` for the detail / write tools.',
					'items'       => array( 'type' => 'object' ),
				),
			),
		);
	}

	/**
	 * Build the custom-events overview list.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;

		$featureEnabled = null !== $pys && self::toBool( $pys->getOption( 'custom_events_enabled' ) );

		$events = array();
		if ( class_exists( '\\PixelYourSite\\CustomEventFactory' ) ) {
			foreach ( \PixelYourSite\CustomEventFactory::get( 'any' ) as $event ) {
				$events[] = self::summarize( $event );
			}
		}

		return array(
			'feature_enabled' => $featureEnabled,
			'admin_ui_path'   => self::ADMIN_UI_PATH,
			'events'          => $events,
		);
	}

	/**
	 * Compact summary of one custom event.
	 *
	 * @param \PixelYourSite\CustomEvent $event Event model.
	 * @return array<string, mixed>
	 */
	private static function summarize( $event ): array {
		$platforms = self::availableNetworks( $event );

		$triggers   = is_array( $event->getTriggers() ) ? $event->getTriggers() : array();
		$conditions = method_exists( $event, 'getConditions' ) && is_array( $event->getConditions() )
			? $event->getConditions() : array();

		$triggerTypes = array();
		foreach ( $triggers as $trigger ) {
			if ( is_object( $trigger ) && method_exists( $trigger, 'getTriggerType' ) ) {
				$slug           = (string) $trigger->getTriggerType();
				$triggerTypes[] = self::TRIGGER_LABELS[ $slug ] ?? $slug;
			}
		}

		$row = array(
			'event_id'           => (int) $event->getPostId(),
			'title'              => self::sanitiseUserString( $event->getTitle() ),
			'enabled'            => (bool) $event->__get( 'enabled' ),
			'networks'           => $platforms,
			'trigger_count'      => count( $triggers ),
			'trigger_types'      => $triggerTypes,
			'condition_count'    => count( $conditions ),
			'conditions_enabled' => self::toBool( $event->__get( 'conditions_enabled' ) ),
			'trigger_logic'      => (string) ( $event->__get( 'trigger_logic' ) ?: 'OR' ),
			'fire_frequency'     => (string) ( $event->__get( 'fire_frequency' ) ?: 'every_time' ),
		);

		// "Fire only once in N hours" — surface the window only when armed.
		if ( self::toBool( $event->__get( 'enable_time_window' ) ) ) {
			$row[ 'time_window' ] = (int) $event->__get( 'time_window' );
		}

		return $row;
	}

	/**
	 * Networks an event ACTUALLY fires to — mirrors the admin "Networks" column: a
	 * network counts only when the platform is globally enabled AND has pixels AND
	 * the event targets it. Google splits off the unify gate into `google_tags`
	 * (GA `G-…` present) and `google_ads` (Ads `AW-…` present).
	 *
	 * @param \PixelYourSite\CustomEvent $event Event model.
	 * @return array<int, string> Network slugs.
	 */
	private static function availableNetworks( $event ): array {
		$nets = array();

		// Facebook + the simple per-platform networks.
		if ( self::platformLive( self::PLATFORM_FNS[ 'facebook' ] ) && self::eventOn( $event, self::PLATFORM_EVENT_METHODS[ 'facebook' ] ) ) {
			$nets[] = 'facebook';
		}

		// Google block: one unify gate, split into Google Tags (GA) + Google Ads.
		$gaGate = ( self::platformLive( '\\PixelYourSite\\Ads' ) || self::platformLive( '\\PixelYourSite\\GA' ) )
		          && self::eventOn( $event, 'isUnifyAnalyticsEnabled' );
		if ( $gaGate && self::eventOn( $event, 'isGoogleAnalyticsPresent' ) ) {
			$nets[] = 'google_tags';
		}
		if ( $gaGate && self::eventOn( $event, 'isGoogleAdsPresent' ) ) {
			$nets[] = 'google_ads';
		}

		// GTM also needs a present check (a real GTM- container selected).
		if ( self::platformLive( self::PLATFORM_FNS[ 'gtm' ] ) && self::eventOn( $event, 'isGTMEnabled' ) && self::eventOn( $event, 'isGTMPresent' ) ) {
			$nets[] = 'gtm';
		}

		foreach ( array( 'tiktok', 'bing', 'pinterest', 'reddit', 'openai' ) as $slug ) {
			if ( self::platformLive( self::PLATFORM_FNS[ $slug ] ) && self::eventOn( $event, self::PLATFORM_EVENT_METHODS[ $slug ] ) ) {
				$nets[] = $slug;
			}
		}

		return $nets;
	}

	/**
	 * Platform is globally enabled and has at least one pixel.
	 *
	 * @param string $fn Global settings accessor (e.g. `\PixelYourSite\Facebook`).
	 * @return bool
	 */
	private static function platformLive( string $fn ): bool {
		if ( !function_exists( $fn ) ) {
			return false;
		}
		$inst = $fn();

		return is_object( $inst ) && method_exists( $inst, 'enabled' ) && $inst->enabled()
		       && method_exists( $inst, 'getPixelIDs' ) && !empty( $inst->getPixelIDs() );
	}

	/**
	 * Call a boolean CustomEvent method if it exists.
	 *
	 * @param \PixelYourSite\CustomEvent $event  Event model.
	 * @param string                     $method Method name.
	 * @return bool
	 */
	private static function eventOn( $event, string $method ): bool {
		return method_exists( $event, $method ) && (bool) $event->$method();
	}

	/**
	 * Coerce a mixed option/data value to a boolean (PYS stores bools as
	 * bool / '1' / 1 / 'true').
	 *
	 * @param mixed $value Raw value.
	 * @return bool
	 */
	private static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}
