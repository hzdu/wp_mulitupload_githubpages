<?php
/**
 * `search_woo_products` — read-only lookup of WooCommerce products and
 * variations by name, SKU, ID or variation ATTRIBUTE VALUES.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class SearchWooProductsAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/search-woo-products';

	private const ADMIN_UI_PATH = 'WooCommerce → Products';

	private const PER_PAGE = 30;

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Search WooCommerce Products';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Finds WooCommerce PRODUCTS and VARIATIONS by name, SKU, post ID or — for a term of two or more words — by the variation\'s ATTRIBUTE VALUES (the colour, size and so on that the variation is made of). Use it to turn what the user says into the numeric ids the `product_id` condition of `set_custom_event` needs: never ask the user for an id and never guess one, look it up here first. Each `results[]` row has `id` (pass this to set_custom_event `product_ids`), `label` (the same text the admin picker shows: product name, the attribute values when the variation title leaves them out, then the id, a `variation` / `any variation` marker and the SKU), `type` (`simple` / `variable` / `variation` / grouped / external), `name`, `sku`, plus `parent_id` and `attributes` for a variation. Which id to pass matters: a VARIABLE parent id matches an order containing ANY of its variations, a VARIATION id matches only that one variation — pick the parent when the user names the product, the variation when they name attributes. Results are paged (30 per page): when `more` is true, call again with `page` + 1 before telling the user something was not found, because a product with many variations spans several pages. If several rows could be what the user meant — variations differing in a single attribute, say — show them the labels and ask which one instead of picking silently. Read-only, nothing is changed. Requires WooCommerce.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'required'             => array( 'term' ),
			'properties'           => array(
				'term' => array(
					'type'        => 'string',
					'description' => 'What to look for: a product or variation name, an SKU, a numeric post id, or the variation\'s attribute values separated by spaces / commas. Attribute matching needs at least two words.',
				),
				'page' => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => '1-based page, 30 rows each. Default 1. Follow up with the next page while the response says `more: true`.',
				),
			),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'results', 'more' ),
			'properties' => array(
				'results'       => array(
					'type'        => 'array',
					'description' => 'Matching products and variations. `id` is what the `product_id` condition takes.',
					'items'       => array( 'type' => 'object' ),
				),
				'more'          => array(
					'type'        => 'boolean',
					'description' => 'True when further pages exist — call again with the next `page` before concluding nothing was found.',
				),
				'page'          => array( 'type' => 'integer' ),
				'term'          => array( 'type' => 'string' ),
				'admin_ui_path' => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * Resolve a term to product / variation rows.
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		$input = is_array( $input ) ? $input : array();
		$term  = self::sanitiseUserString( $input['term'] ?? '', 0 );
		$page  = isset( $input['page'] ) ? max( 1, (int) $input['page'] ) : 1;

		if ( '' === trim( $term ) ) {
			return new \WP_Error( 'pys_mcp_search_products_no_term', '`term` must not be empty.', array( 'status' => 400 ) );
		}

		if ( !function_exists( '\\PixelYourSite\\isWooCommerceActive' ) || !\PixelYourSite\isWooCommerceActive() ) {
			return new \WP_Error( 'pys_mcp_search_products_no_woo', 'WooCommerce is not active on this site, so there are no products to search.', array( 'status' => 409 ) );
		}

		$found = \PixelYourSite\pysSearchWooProducts( $term, $page, self::PER_PAGE );

		$results = array();
		foreach ( $found['results'] as $row ) {
			$clean = array(
				'id'    => (int) $row['id'],
				'label' => self::sanitiseUserString( $row['label'] ?? '', 0 ),
				'type'  => self::sanitiseUserString( $row['type'] ?? '' ),
				'name'  => self::sanitiseUserString( $row['name'] ?? '', 0 ),
				'sku'   => self::sanitiseUserString( $row['sku'] ?? '' ),
			);

			if ( isset( $row['parent_id'] ) ) {
				$clean['parent_id']  = (int) $row['parent_id'];
				$clean['attributes'] = self::sanitiseUserString( $row['attributes'] ?? '', 0 );
			}

			$results[] = $clean;
		}

		return array(
			'results'       => $results,
			'more'          => (bool) $found['more'],
			'page'          => $page,
			'term'          => $term,
			'admin_ui_path' => self::ADMIN_UI_PATH,
		);
	}
}
