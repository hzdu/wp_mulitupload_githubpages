<?php
/**
 * Declarative registry of the per-platform data layout inside a custom event:
 * one MAP row per platform with its option keys, pixel-selection shape
 * (array vs scalar), event-type source and custom-type marker. Adding a platform
 * or field is a one-row edit. Google is split as PYS stores it: `google_analytics`,
 * `ga_ads` (unify-analytics branch) and `google_ads`.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class CustomEventPlatformMap {

	/** event-type list kind: flat per-platform list, GA grouped, fixed, or none. */
	public const EVENTS_FLAT     = 'flat';
	public const EVENTS_GA_GROUP = 'ga_group';
	public const EVENTS_FIXED    = 'fixed';
	public const EVENTS_NONE     = 'none';

	private const MAP = array(
		'facebook'         => array(
			'enabled' => 'facebook_enabled', 'pixel' => 'facebook_pixel_id', 'pixel_array' => true,
			'event_type' => 'facebook_event_type', 'custom_event_type' => 'facebook_custom_event_type', 'custom_values' => array( 'CustomEvent' ),
			'params_enabled' => 'facebook_params_enabled', 'params' => 'facebook_params', 'custom_params' => 'facebook_custom_params',
			'track_single' => 'facebook_track_single_woo_data', 'track_cart' => 'facebook_track_cart_woo_data', 'conversion_label' => null,
			'pixel_fns' => array( '\\PixelYourSite\\Facebook' ), 'events_kind' => self::EVENTS_FLAT, 'events_source' => 'facebook',
		),
		'tiktok'           => array(
			'enabled' => 'tiktok_enabled', 'pixel' => 'tiktok_pixel_id', 'pixel_array' => false,
			'event_type' => 'tiktok_event_type', 'custom_event_type' => 'tiktok_custom_event_type', 'custom_values' => array( 'CustomEvent' ),
			'params_enabled' => 'tiktok_params_enabled', 'params' => 'tiktok_params', 'custom_params' => 'tiktok_custom_params',
			'track_single' => 'tiktok_track_single_woo_data', 'track_cart' => 'tiktok_track_cart_woo_data', 'conversion_label' => null,
			'pixel_fns' => array( '\\PixelYourSite\\Tiktok' ), 'events_kind' => self::EVENTS_FLAT, 'events_source' => 'tiktok',
		),
		'pinterest'        => array(
			'enabled' => 'pinterest_enabled', 'pixel' => 'pinterest_pixel_id', 'pixel_array' => false,
			'event_type' => 'pinterest_event_type', 'custom_event_type' => 'pinterest_custom_event_type', 'custom_values' => array( 'custom', 'partner_defined' ),
			'params_enabled' => 'pinterest_params_enabled', 'params' => 'pinterest_params', 'custom_params' => 'pinterest_custom_params',
			'track_single' => 'pinterest_track_single_woo_data', 'track_cart' => 'pinterest_track_cart_woo_data', 'conversion_label' => null,
			'pixel_fns' => array( '\\PixelYourSite\\Pinterest' ), 'events_kind' => self::EVENTS_FLAT, 'events_source' => 'pinterest',
		),
		'bing'             => array(
			'enabled' => 'bing_enabled', 'pixel' => 'bing_pixel_id', 'pixel_array' => false,
			'event_type' => 'bing_event_type', 'custom_event_type' => 'bing_custom_event_type', 'custom_values' => array( 'Custom' ),
			'params_enabled' => 'bing_params_enabled', 'params' => 'bing_params', 'custom_params' => 'bing_custom_params',
			'track_single' => 'bing_track_single_woo_data', 'track_cart' => 'bing_track_cart_woo_data', 'conversion_label' => null,
			'pixel_fns' => array( '\\PixelYourSite\\Bing' ), 'events_kind' => self::EVENTS_FLAT, 'events_source' => 'bing',
		),
		'reddit'           => array(
			'enabled' => 'reddit_enabled', 'pixel' => 'reddit_pixel_id', 'pixel_array' => false,
			'event_type' => 'reddit_event_type', 'custom_event_type' => 'reddit_custom_event_type', 'custom_values' => array( 'Custom' ),
			'params_enabled' => 'reddit_params_enabled', 'params' => 'reddit_params', 'custom_params' => null,
			'track_single' => 'reddit_track_single_woo_data', 'track_cart' => 'reddit_track_cart_woo_data', 'conversion_label' => null,
			'pixel_fns' => array( '\\PixelYourSite\\Reddit' ), 'events_kind' => self::EVENTS_FLAT, 'events_source' => 'reddit',
		),
		'openai'           => array(
			'enabled' => 'openai_enabled', 'pixel' => 'openai_pixel_id', 'pixel_array' => true,
			'event_type' => 'openai_event_type', 'custom_event_type' => 'openai_custom_event_type', 'custom_values' => array( 'custom' ),
			'params_enabled' => 'openai_params_enabled', 'params' => 'openai_params', 'custom_params' => null,
			'track_single' => 'openai_track_single_woo_data', 'track_cart' => 'openai_track_cart_woo_data', 'conversion_label' => null,
			'pixel_fns' => array( '\\PixelYourSite\\OpenAI' ), 'events_kind' => self::EVENTS_FLAT, 'events_source' => 'openai',
		),
		'google_analytics' => array(
			'enabled' => 'ga_enabled', 'pixel' => 'ga_pixel_id', 'pixel_array' => true,
			'event_type' => 'ga_event_action', 'custom_event_type' => 'ga_custom_event_action', 'custom_values' => array( '_custom', 'CustomEvent' ),
			'params_enabled' => null, 'params' => 'ga_params', 'custom_params' => 'ga_custom_params',
			'track_single' => null, 'track_cart' => null, 'conversion_label' => 'ga_conversion_label',
			'pixel_fns' => array( '\\PixelYourSite\\GA' ), 'events_kind' => self::EVENTS_GA_GROUP, 'events_source' => null,
		),
		'ga_ads'           => array(
			'enabled' => 'ga_ads_enabled', 'pixel' => 'ga_ads_pixel_id', 'pixel_array' => true,
			'event_type' => 'ga_ads_event_action', 'custom_event_type' => 'ga_ads_custom_event_action', 'custom_values' => array( '_custom', 'CustomEvent' ),
			'params_enabled' => null, 'params' => 'ga_ads_params', 'custom_params' => 'ga_ads_custom_params',
			'track_single' => 'ga_ads_track_single_woo_data', 'track_cart' => 'ga_ads_track_cart_woo_data', 'conversion_label' => 'ga_ads_conversion_label',
			'pixel_fns' => array( '\\PixelYourSite\\GA', '\\PixelYourSite\\Ads' ), 'events_kind' => self::EVENTS_GA_GROUP, 'events_source' => null,
		),
		'google_ads'       => array(
			'enabled' => 'google_ads_enabled', 'pixel' => 'google_ads_conversion_id', 'pixel_array' => true,
			'event_type' => 'google_ads_event_action', 'custom_event_type' => 'google_ads_custom_event_action', 'custom_values' => array( '_custom', 'CustomEvent' ),
			'params_enabled' => null, 'params' => null, 'custom_params' => 'google_ads_custom_params',
			'track_single' => null, 'track_cart' => null, 'conversion_label' => 'google_ads_conversion_label',
			'pixel_fns' => array( '\\PixelYourSite\\Ads' ), 'events_kind' => self::EVENTS_FIXED, 'events_source' => null,
		),
		'gtm'              => array(
			'enabled' => 'gtm_enabled', 'pixel' => 'gtm_pixel_id', 'pixel_array' => true,
			'event_type' => 'gtm_event_action', 'custom_event_type' => 'gtm_custom_event_action', 'custom_values' => array( '_custom', 'CustomEvent' ),
			'params_enabled' => null, 'params' => 'gtm_params', 'custom_params' => 'gtm_custom_params',
			'track_single' => 'gtm_track_single_woo_data', 'track_cart' => 'gtm_track_cart_woo_data', 'conversion_label' => 'gtm_conversion_label',
			'pixel_fns' => array( '\\PixelYourSite\\GTM' ), 'events_kind' => self::EVENTS_GA_GROUP, 'events_source' => null,
		),
	);

	/**
	 * Rules a platform's own API adds on top of the common shape. Only OpenAI has
	 * them: its taxonomy is CLOSED, and unlike every other platform here a field
	 * it does not know does not just go unused -- the endpoint answers 400 and
	 * drops the WHOLE event, so every conversion configured on it is lost.
	 */
	private const PLATFORM_RULES = array(
		'openai' => array(
			'static_only_params'                => array( 'amount', 'currency' ),
			'validators'                        => array(
				'currency' => array(
					'fn'      => '\\PixelYourSite\\OpenAI\\Helpers\\pys_openai_is_valid_currency',
					'message' => 'must be an ISO 4217 currency code, e.g. USD or EUR. The endpoint checks the code against that standard, not its shape: BTC is three letters and is still refused, and the refusal fails the whole event.',
				),
			),
			'custom_name'                       => array(
				'fn'       => '\\PixelYourSite\\CustomEvent::sanitizeOpenAICustomEventName',
				'message'  => '1-64 characters: latin letters, digits, `_` and `-`, starting and ending with a letter or a digit.',
				'reserved' => true,
			),
		),
	);

	/**
	 * Platform-specific EXTRA event fields beyond the common set (enabled, pixel,
	 * event_type, params, …). Keyed by slug → mcp field name → { key (real data
	 * key), type ('bool'|'string'), label, hint? }. Only GTM has these today.
	 */
	private const PLATFORM_EXTRAS = array(
		'gtm' => array(
			'automated_params'             => array( 'key' => 'gtm_automated_param',       'type' => 'bool',   'label' => 'Add the automated parameters in the dataLayer' ),
			'remove_custom_trigger_object' => array( 'key' => 'gtm_remove_customTrigger',   'type' => 'bool',   'label' => 'Remove the customTrigger object from the dataLayer after the event fires' ),
			'use_custom_object_name'       => array( 'key' => 'gtm_use_custom_object_name', 'type' => 'bool',   'label' => 'Use a custom value for the custom-parameters dataLayer object' ),
			'custom_object_name'           => array( 'key' => 'gtm_custom_object_name',     'type' => 'string', 'label' => 'Custom dataLayer object name (the GTM variable key); requires use_custom_object_name=true to take effect' ),
		),
	);

	/**
	 * Platform-specific extra fields (see PLATFORM_EXTRAS). Empty for most platforms.
	 *
	 * @param string $slug Platform slug.
	 * @return array<string, array<string, string>>
	 */
	public static function extras( string $slug ): array {
		return self::PLATFORM_EXTRAS[ $slug ] ?? array();
	}

	/**
	 * Params of this platform that may not carry a `selector` / `dynamic:true`.
	 *
	 * @param string $slug Platform slug.
	 * @return array<int, string>
	 */
	public static function staticOnlyParams( string $slug ): array {
		return (array) ( self::PLATFORM_RULES[ $slug ][ 'static_only_params' ] ?? array() );
	}

	/**
	 * The value rule for one param, as { fn, message }, or null when the platform
	 * has none for it.
	 *
	 * @param string $slug  Platform slug.
	 * @param string $param Param name.
	 * @return array<string, string>|null
	 */
	public static function paramValidator( string $slug, string $param ): ?array {
		$rule = self::PLATFORM_RULES[ $slug ][ 'validators' ][ $param ] ?? null;

		return is_array( $rule ) && is_callable( $rule[ 'fn' ] ) ? $rule : null;
	}

	/**
	 * The platform's own rule for the free event NAME, as { fn, message, reserved },
	 * or null when the generic key sanitiser is the rule.
	 *
	 * @param string $slug Platform slug.
	 * @return array<string, mixed>|null
	 */
	public static function customNameRule( string $slug ): ?array {
		$rule = self::PLATFORM_RULES[ $slug ][ 'custom_name' ] ?? null;

		return is_array( $rule ) && is_callable( $rule[ 'fn' ] ) ? $rule : null;
	}

	/**
	 * The platform's STANDARD event-type values -- the names a free custom-event
	 * name may not reuse when the platform reserves them.
	 *
	 * @param string $slug Platform slug.
	 * @return array<int, string>
	 */
	public static function reservedCustomNames( string $slug ): array {
		$rule = self::PLATFORM_RULES[ $slug ][ 'custom_name' ] ?? null;

		if ( empty( $rule[ 'reserved' ] ) ) {
			return array();
		}

		$def = self::MAP[ $slug ] ?? null;

		return array_values( array_diff(
			self::validEventTypes( $slug ),
			(array) ( $def[ 'custom_values' ] ?? array() )
		) );
	}

	/**
	 * Fixed Google Ads action list (mirrors renderGoogleAdsActionInput).
	 */
	private const GOOGLE_ADS_ACTIONS = array(
		'_custom', 'disabled', 'add_payment_info', 'add_to_cart', 'add_to_wishlist', 'begin_checkout',
		'checkout_progress', 'conversion', 'generate_lead', 'login', 'purchase', 'refund',
		'remove_from_cart', 'search', 'select_content', 'set_checkout_option', 'share', 'sign_up',
		'view_item', 'view_item_list', 'view_promotion', 'view_search_results',
	);

	/**
	 * All platform slugs.
	 *
	 * @return array<int, string>
	 */
	public static function slugs(): array {
		return array_keys( self::MAP );
	}

	/**
	 * Whether a slug is known.
	 *
	 * @param string $slug Platform slug.
	 * @return bool
	 */
	public static function has( string $slug ): bool {
		return isset( self::MAP[ $slug ] );
	}

	/**
	 * Full layout for a slug, or null.
	 *
	 * @param string $slug Platform slug.
	 * @return array<string, mixed>|null
	 */
	public static function get( string $slug ): ?array {
		return self::MAP[ $slug ] ?? null;
	}

	/**
	 * Whether a slug's pixel selection is an array (multi) vs scalar (single).
	 *
	 * @param string $slug Platform slug.
	 * @return bool
	 */
	public static function pixelIsArray( string $slug ): bool {
		return !empty( self::MAP[ $slug ][ 'pixel_array' ] );
	}

	/**
	 * Valid pixel ids for a slug (the ids the admin would offer), excluding the
	 * `all` sentinel which callers handle separately.
	 *
	 * @param string $slug Platform slug.
	 * @return array<int, string>
	 */
	public static function validPixelIds( string $slug ): array {
		$def = self::MAP[ $slug ] ?? null;
		if ( null === $def ) {
			return array();
		}
		$ids = array();
		foreach ( $def[ 'pixel_fns' ] as $fn ) {
			if ( !function_exists( $fn ) ) {
				continue;
			}
			$inst = $fn();
			if ( is_object( $inst ) && method_exists( $inst, 'getAllPixels' ) ) {
				foreach ( (array) $inst->getAllPixels( false ) as $id ) {
					if ( is_string( $id ) && '' !== $id ) {
						$ids[] = $id;
					}
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Whether a platform can be ENABLED on an event right now: its addon is active
	 * AND at least one pixel is configured. When an addon is inactive the accessor
	 * (e.g. `Pinterest()`) returns a stub whose `configured()` is false, so this
	 * also covers "addon off". For unified `ga_ads` either GA or Ads counts.
	 *
	 * @param string $slug Platform slug.
	 * @return bool
	 */
	public static function isConnectable( string $slug ): bool {
		$def = self::MAP[ $slug ] ?? null;
		if ( null === $def ) {
			return false;
		}
		foreach ( $def[ 'pixel_fns' ] as $fn ) {
			if ( !function_exists( $fn ) ) {
				continue;
			}
			$inst = $fn();
			if ( is_object( $inst ) && method_exists( $inst, 'configured' ) && $inst->configured() ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Valid event-type values for a slug (for validating `event_type`). Includes
	 * the custom marker(s). Empty array = don't validate (unknown source).
	 *
	 * @param string $slug Platform slug.
	 * @return array<int, string>
	 */
	public static function validEventTypes( string $slug ): array {
		$def = self::MAP[ $slug ] ?? null;
		if ( null === $def ) {
			return array();
		}
		$types = array();

		switch ( $def[ 'events_kind' ] ) {
			case self::EVENTS_FLAT:
				$src    = $def[ 'events_source' ];
				$getter = '\\PixelYourSite\\PYS_Event_Definitions::get_' . $src . '_events';
				if ( is_callable( $getter ) ) {
					$types = array_keys( (array) call_user_func( $getter ) );
				}
				break;
			case self::EVENTS_GA_GROUP:
				if ( is_callable( '\\PixelYourSite\\PYS_Event_Definitions::get_ga_events' ) ) {
					foreach ( (array) \PixelYourSite\PYS_Event_Definitions::get_ga_events() as $group ) {
						foreach ( (array) $group as $name => $_fields ) {
							$types[] = (string) $name;
						}
					}
				}
				break;
			case self::EVENTS_FIXED:
				$types = self::GOOGLE_ADS_ACTIONS;
				break;
		}

		// Always allow the platform's custom-type marker(s).
		$types = array_merge( $types, $def[ 'custom_values' ] );

		return array_values( array_unique( array_filter( $types, static function ( $v ) {
			return is_string( $v ) && '' !== $v;
		} ) ) );
	}

	/**
	 * Full event-type MENU for a slug, with the params each event accepts — the
	 * authoritative list for the caller to pick from. GA / GTM are GROUPED by
	 * category (as in the admin); other platforms are flat.
	 * Shape: { grouped:false, event_types:[{value, params:[{name,input_type,required}]}] }
	 *     or { grouped:true,  groups:[{group, event_types:[...]}] }.
	 *
	 * @param string $slug Platform slug.
	 * @return array<string, mixed>
	 */
	public static function eventTypeMenu( string $slug ): array {
		$def = self::MAP[ $slug ] ?? null;
		if ( null === $def ) {
			return array();
		}

		switch ( $def[ 'events_kind' ] ) {
			case self::EVENTS_FLAT:
				$getter = '\\PixelYourSite\\PYS_Event_Definitions::get_' . $def[ 'events_source' ] . '_events';
				if ( !is_callable( $getter ) ) {
					return array();
				}
				$list = array();
				foreach ( (array) call_user_func( $getter ) as $name => $params ) {
					if ( '' === (string) $name ) {
						continue; // the blank placeholder entry
					}
					$list[] = self::eventEntry( $slug, (string) $name, self::normalizeEventParams( $params ) );
				}

				return array( 'grouped' => false, 'event_types' => $list );

			case self::EVENTS_GA_GROUP:
				if ( !is_callable( '\\PixelYourSite\\PYS_Event_Definitions::get_ga_events' ) ) {
					return array();
				}
				$groups = array();
				foreach ( (array) \PixelYourSite\PYS_Event_Definitions::get_ga_events() as $group => $events ) {
					$evs = array();
					foreach ( (array) $events as $name => $params ) {
						if ( '' === (string) $name ) {
							continue;
						}
						$evs[] = self::eventEntry( $slug, (string) $name, self::normalizeEventParams( $params ) );
					}
					$groups[] = array( 'group' => (string) $group, 'event_types' => $evs );
				}

				return array( 'grouped' => true, 'groups' => $groups );

			case self::EVENTS_FIXED:
				$list = array();
				foreach ( self::GOOGLE_ADS_ACTIONS as $a ) {
					$list[] = self::eventEntry( $slug, $a, array() );
				}

				return array( 'grouped' => false, 'event_types' => $list );
		}

		return array();
	}

	/**
	 * One event-type menu entry: { value, params, custom_name? }. `custom_name:true`
	 * marks the platform's "enter your own name" type (facebook CustomEvent,
	 * pinterest custom/partner_defined, bing Custom, GA/GTM _custom/CustomEvent,
	 * google_ads _custom) — selecting it requires a `custom_event_type` name.
	 *
	 * @param string $slug   Platform slug.
	 * @param string $value  Event type value.
	 * @param array  $params Normalised params for the event.
	 * @return array<string, mixed>
	 */
	private static function eventEntry( string $slug, string $value, array $params ): array {
		$entry = array( 'value' => $value, 'params' => $params );
		if ( self::isCustomEventType( $slug, $value ) ) {
			$entry[ 'custom_name' ] = true;
		}

		return $entry;
	}

	/**
	 * Valid STANDARD param names for a given (platform, event_type) — the params
	 * the admin shows for that event. [] for unknown / custom / param-less events.
	 *
	 * @param string $slug      Platform slug.
	 * @param string $eventType Selected event type value.
	 * @return array<int, string>
	 */
	public static function eventParamNames( string $slug, string $eventType ): array {
		$menu = self::eventTypeMenu( $slug );
		if ( empty( $menu ) ) {
			return array();
		}
		$pick = static function ( array $eventTypes ) use ( $eventType ) {
			foreach ( $eventTypes as $e ) {
				if ( ( $e[ 'value' ] ?? null ) === $eventType ) {
					return array_map( static function ( $p ) {
						return $p[ 'name' ];
					}, $e[ 'params' ] );
				}
			}

			return null;
		};
		if ( !empty( $menu[ 'grouped' ] ) ) {
			foreach ( $menu[ 'groups' ] as $g ) {
				$r = $pick( $g[ 'event_types' ] );
				if ( null !== $r ) {
					return $r;
				}
			}

			return array();
		}

		$r = $pick( $menu[ 'event_types' ] );

		return null !== $r ? $r : array();
	}

	/**
	 * For a GROUPED platform (GA / GTM / ga_ads), the category group label that
	 * contains the given event_type (first match — an event can be in several
	 * groups; they are cosmetic, same params). '' for flat platforms or no match.
	 * The admin event-type dropdown is two-level (group → event), so the stored
	 * `*_event_action_group` must contain the action or the event won't display.
	 *
	 * @param string $slug      Platform slug.
	 * @param string $eventType Event type value.
	 * @return string
	 */
	public static function eventGroupFor( string $slug, string $eventType ): string {
		$menu = self::eventTypeMenu( $slug );
		if ( empty( $menu[ 'grouped' ] ) ) {
			return '';
		}
		foreach ( $menu[ 'groups' ] as $g ) {
			foreach ( $g[ 'event_types' ] as $e ) {
				if ( ( $e[ 'value' ] ?? null ) === $eventType ) {
					return (string) $g[ 'group' ];
				}
			}
		}

		return '';
	}

	/**
	 * ALL category group labels that contain the given event_type (for grouped
	 * platforms). An event can be in several groups (e.g. begin_checkout is in
	 * Jobs… / Retail/Ecommerce / Travel) — used to validate an explicit group and
	 * to know when to ask the user which one. [] for flat platforms / no match.
	 *
	 * @param string $slug      Platform slug.
	 * @param string $eventType Event type value.
	 * @return array<int, string>
	 */
	public static function eventGroupsFor( string $slug, string $eventType ): array {
		$menu = self::eventTypeMenu( $slug );
		if ( empty( $menu[ 'grouped' ] ) ) {
			return array();
		}
		$out = array();
		foreach ( $menu[ 'groups' ] as $g ) {
			foreach ( $g[ 'event_types' ] as $e ) {
				if ( ( $e[ 'value' ] ?? null ) === $eventType ) {
					$out[] = (string) $g[ 'group' ];
					break;
				}
			}
		}

		return $out;
	}

	/**
	 * Whether an event_type value is the platform's "custom" marker (which carries
	 * no standard params — use custom_params instead).
	 *
	 * @param string $slug      Platform slug.
	 * @param string $eventType Event type value.
	 * @return bool
	 */
	public static function isCustomEventType( string $slug, string $eventType ): bool {
		$def = self::MAP[ $slug ] ?? null;

		return null !== $def && in_array( $eventType, (array) $def[ 'custom_values' ], true );
	}

	/**
	 * Normalise an event's param definitions to { name, input_type, required }.
	 * Flat platforms carry the param name in `label` (with `name` = full POST key);
	 * GA / GTM carry it in `name`.
	 *
	 * @param mixed $params Raw param definitions for one event.
	 * @return array<int, array<string, mixed>>
	 */
	private static function normalizeEventParams( $params ): array {
		$out = array();
		foreach ( (array) $params as $p ) {
			if ( !is_array( $p ) ) {
				continue;
			}
			$name = ( isset( $p[ 'label' ] ) && '' !== $p[ 'label' ] ) ? $p[ 'label' ] : ( $p[ 'name' ] ?? '' );
			$name = (string) $name;
			if ( '' === $name ) {
				continue;
			}
			$out[] = array(
				'name'       => $name,
				'input_type' => (string) ( $p[ 'input_type' ] ?? 'string' ),
				'required'   => !empty( $p[ 'required' ] ),
			);
		}

		return $out;
	}
}
