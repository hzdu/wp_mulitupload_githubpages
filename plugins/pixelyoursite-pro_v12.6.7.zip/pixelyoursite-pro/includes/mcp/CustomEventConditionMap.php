<?php
/**
 * Declarative registry of custom-event CONDITION types (label + value shape:
 * rule_value / device / user_role), mirroring CustomEvent::update()'s
 * `$args['conditions']` parser. Adding or fixing a condition type is a one-row edit.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class CustomEventConditionMap {

	public const SHAPE_RULE_VALUE = 'rule_value';
	public const SHAPE_DEVICE     = 'device';
	public const SHAPE_USER_ROLE  = 'user_role';
	public const SHAPE_PRODUCT_ID = 'product_id';

	private const MAP = array(
		'url_filters'    => array( 'label' => 'URL filters', 'shape' => self::SHAPE_RULE_VALUE ),
		'url_parameters' => array( 'label' => 'URL parameters', 'shape' => self::SHAPE_RULE_VALUE ),
		'landing_page'   => array( 'label' => 'Landing page', 'shape' => self::SHAPE_RULE_VALUE ),
		'source'         => array( 'label' => 'Source', 'shape' => self::SHAPE_RULE_VALUE ),
		'device'         => array( 'label' => 'Device', 'shape' => self::SHAPE_DEVICE ),
		'user_role'      => array( 'label' => 'User role', 'shape' => self::SHAPE_USER_ROLE ),
		'product_id'     => array( 'label' => 'Product ID', 'shape' => self::SHAPE_PRODUCT_ID ),
	);

	private const RULE_VALUES = array(
		'url_filters'    => array( 'contains', 'match' ),
		'url_parameters' => array( 'contains', 'match' ),
		'source'         => array( 'contains', 'match' ),
		'landing_page'   => array( 'contains', 'match', 'param_contains', 'param_match' ),
	);

	public const DEVICE_VALUES = array( 'Desktop', 'Mobile' );

	/**
	 * Match modes of the product_id condition, taken from the model itself so
	 * the two never drift apart.
	 *
	 * @return array<int, string>
	 */
	public static function productMatchModes(): array {
		if ( class_exists( '\\PixelYourSite\\ConditionalEvent' ) ) {
			return \PixelYourSite\ConditionalEvent::getProductMatchModes();
		}

		return array( 'includes', 'includes_only' );
	}

	/**
	 * Allowed condition_rule values for a rule_value type ([] otherwise).
	 *
	 * @param string $type Condition type slug.
	 * @return array<int, string>
	 */
	public static function ruleValues( string $type ): array {
		return self::RULE_VALUES[ $type ] ?? array();
	}

	/**
	 * All known condition type slugs.
	 *
	 * @return array<int, string>
	 */
	public static function types(): array {
		return array_keys( self::MAP );
	}

	/**
	 * Whether a type is known.
	 *
	 * @param string $type Condition type slug.
	 * @return bool
	 */
	public static function has( string $type ): bool {
		return isset( self::MAP[ $type ] );
	}

	/**
	 * Admin-facing label (falls back to the raw slug).
	 *
	 * @param string $type Condition type slug.
	 * @return string
	 */
	public static function label( string $type ): string {
		return self::MAP[ $type ][ 'label' ] ?? $type;
	}

	/**
	 * Arg shape for a type (rule_value / device / user_role). Defaults to
	 * rule_value for unknown types (the admin default).
	 *
	 * @param string $type Condition type slug.
	 * @return string
	 */
	public static function shape( string $type ): string {
		return self::MAP[ $type ][ 'shape' ] ?? self::SHAPE_RULE_VALUE;
	}
}
