<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

abstract class Settings {

    /**
     * Options section slug
     *
     * @var string
     */
    private $slug;

    /**
     * Options values
     *
     * @var array
     */
    private $values = array();

    /**
     * Database option key
     *
     * @var string
     */
    private $option_key = '';

    /**
     * Default options values
     *
     * @var array
     */
    private $defaults = array();

    /**
     * List of all options
     *
     * @var array
     */
    private $options = array();

    private $defaults_json_path;
    private static ?bool $table_exists = null;

    /**
     * True once locateOptions() has loaded the defaults for this options group.
     *
     * @var bool
     */
    private $defaults_located = false;

    /**
     * True when values were loaded from the database before the defaults were
     * known. Such a load is incomplete: options missing from the stored row are
     * not backfilled from the defaults, so it must not be treated as final.
     *
     * @var bool
     */
    private $loaded_without_defaults = false;

    public static function storage_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'pys_options';
    }

    private static function table_exists(): bool {
        if (self::$table_exists !== null) {
            return self::$table_exists;
        }

        // Try object cache first
        $cached = wp_cache_get('pys_options_table_exists', 'pys');
        if ($cached !== false) {
            return self::$table_exists = (bool) $cached;
        }

        global $wpdb;
        $table  = self::storage_table();
        $exists = (bool) $wpdb->get_var(
            $wpdb->prepare("SHOW TABLES LIKE %s", $table)
        );
        if (!$exists) {
            // Create table
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE IF NOT EXISTS $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            option_name VARCHAR(191) NOT NULL,
            option_value LONGTEXT NOT NULL,
            migrated TINYINT(1) NOT NULL DEFAULT 1,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY option_name (option_name)
        ) $charset_collate;";
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);

            // After dbDelta table exists
            $exists = true;
        }
        // Cache for 12h; adjust as you like
        wp_cache_set('pys_options_table_exists', $exists, 'pys', 12 * HOUR_IN_SECONDS);
        return self::$table_exists = $exists;
    }
    /**
     * Constructor
     *
     * @param string $slug
     */
    public function __construct( $slug ) {
        $this->slug = $slug;
        $this->option_key = 'pys_' . $slug;
    }

    public function getSlug() {
        return $this->slug;
    }

    /**
     * Return the list of registered option field keys for this module.
     *
     * Keys come from the module's options_fields.json (loaded via locateOptions)
     * plus any runtime-added fields. Used by the Site Profile exporter to iterate
     * a module's fields without hardcoding per-edition JSON file paths.
     *
     * @return string[]
     */
    public function getOptionKeys() {
        return array_keys( $this->options );
    }

    /**
     * Load options fields and options defaults from specified files
     *
     * @param string $fields   Path to options fields file
     * @param string $defaults Path to options defaults file
     */
    public function locateOptions( $fields, $defaults ) {

        $this->loadJSON( $fields, false );
        $this->loadJSON( $defaults, true );

        $this->defaults_json_path = $defaults;
        $this->defaults_located = true;
        self::table_exists();

        // Values read before this point were merged with an empty defaults set,
        // so any option missing from the stored row resolved to null instead of
        // its default. Now that the defaults are known, load them again.
        if ( $this->loaded_without_defaults ) {
            $this->loaded_without_defaults = false;
            $this->maybeLoad( true );
        }
    }

    /**
     * Whether locateOptions() has run, so getOption() can return a real value.
     *
     * Before it has, a missing option reads as null — indistinguishable from one
     * deliberately unset, or from a boolean that is off. pys_cookie_domain()
     * needs that difference, or it memoises a cookie scope guessed from an
     * option it could not read. `did_action( 'init' )` is no substitute: it is
     * already 1 through 'init' priorities 0-8, while locateOptions() runs inside
     * PYS::init() at priority 9.
     *
     * @return bool
     */
    public function optionsLocated() {
        return (bool) $this->defaults_located;
    }

    public function resetToDefaults() {

        if ( ! file_exists( $this->defaults_json_path ) ) {
            return;
        }

        // List of fields to preserve
        $preserve_fields = [
            'enabled',

            'tracking_id',
            'enable_server_container',
            'server_access_api_token',
            'server_container_url',
            'transport_url',

            'pixel_id',
            'advanced_matching_enabled',
            'server_access_api_token',
            'use_server_api',
            'verify_meta_tag',
            'test_api_event_code',

            'ads_ids',
            'verify_meta_tag',

            'gtm_id',
            'gtm_just_data_layer',
        ];

        // Load current values
        $this->maybeLoad();
        $current_values = $this->values;

        // Preserve the values of specified fields
        $preserved_values = [];
        foreach ( $preserve_fields as $field ) {
            if ( isset( $current_values[ $field ] ) ) {
                $preserved_values[ $field ] = $current_values[ $field ];
            }
        }

        // Load default values
        $content = file_get_contents( $this->defaults_json_path );
        $default_values = json_decode( $content, true );

        // Merge preserved values with default values
        $merged_values = array_merge( $default_values, $preserved_values );

        // Update options with the merged values
        $this->updateOptions( $merged_values );

    }

    /**
     * Load options fields or options defaults from specified file
     *
     * @param string $file
     * @param bool   $is_defaults
     */
    private function loadJSON( $file, $is_defaults ) {

        if ( ! file_exists( $file ) ) {
            return;
        }

        $content = file_get_contents( $file );
        $values = json_decode( $content, true );

        if ( null === $values ) {
            return;
        }

        if ( $is_defaults ) {
            $this->defaults = $values;
        } else {
            $this->options = $values;
        }

    }

    /**
     * Reading from a new table.
     *
     * @return array|null  array of values or null if there is no entry
     */
    private function pys_get_from_storage( $option_key ) {
        global $wpdb;
        // Resolve the flag on demand: it must not depend on locateOptions()
        // having already run for some options group in this request.
        if (!self::table_exists()) {
            return null;
        }

        $table = self::storage_table();

        // Safe to query the table
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT option_value FROM $table WHERE option_name = %s LIMIT 1",
                $option_key
            ),
            ARRAY_A
        );

        if ( ! $row ) {
            return null;
        }

        $val = maybe_unserialize( $row['option_value'] );
        return is_array( $val ) ? $val : [];
    }
    /**
     * Write to a new table.
     *
     * @return bool
     */
    private function pys_set_in_storage( $option_key, $value, $migrated = 1 ) {
        global $wpdb;
        if (!self::table_exists()) {
            return null;
        }
        $table = self::storage_table();
        $data  = [
            'option_value' => maybe_serialize( $value ),
            'migrated'     => (int) $migrated,
        ];
        $format = [ '%s', '%d' ];
        // Checking if there is a record
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE option_name = %s",
                $option_key
            )
        );

        if ( $exists ) {
            // We are updating
            $result = $wpdb->update(
                $table,
                $data,
                [ 'option_name' => $option_key ],
                $format,
                [ '%s' ]
            );
        } else {
            // Insert a new one
            $result = $wpdb->insert(
                $table,
                array_merge( [ 'option_name' => $option_key ], $data ),
                array_merge( [ '%s' ], $format )
            );
        }

        return $result !== false;
    }
    /**
     * Add new option field
     *
     * @param string $key
     * @param string $field_type
     * @param mixed  $default
     */
    public function addOption( $key, $field_type, $default ) {
        $this->options[ $key ] = $field_type;
        $this->defaults[ $key ] = $default;
    }

    /**
     * Gets an option value or its default value
     *
     * @param  string $key      Option key
     * @param  mixed  $fallback Option fallback value if no default is set
     *
     * @return mixed The value specified for the option or a default value for the option.
     */
    public function getOption( $key, $fallback = null ) {

        $this->maybeLoad();

        // get option default if unset
        if ( ! isset( $this->values[ $key ] ) ) {
            $this->values[ $key ] = isset( $this->defaults[ $key ] )
                ? $this->defaults[ $key ] : null;
        }

        // use fall back value if default is not set
        if ( null === $this->values[ $key ] && ! is_null( $fallback ) ) {
            $this->values[ $key ] = $fallback;
        }

        return $this->values[ $key ];

    }

    public function setOption($key, $value){
        $this->maybeLoad();
        if (isset($value) ) {
            $this->values[ $key ] = $value;
        }
    }

    /**
     * Load values from database
     *
     * @param bool $force Force options load
     */
    private function maybeLoad( $force = false ) {

        if ( ! $force && ! empty( $this->values ) ) {
            return; // already loaded
        }

        // Remember whether this load happens before the defaults are known, so
        // locateOptions() can redo it (see locateOptions()).
        $this->loaded_without_defaults = ! $this->defaults_located;

        // 1) Let's try a new table
        $stored = $this->pys_get_from_storage( $this->option_key );
        if ( is_array( $stored ) ) {
            $this->values = wp_parse_args( $stored, $this->defaults );
            return;
        }

        // 2) Let's try the old way (wp_options)
        $legacy = get_option( $this->option_key, null );
        if ( is_array( $legacy ) ) {
            // Migration to a new table
            $this->pys_set_in_storage( $this->option_key, $legacy, 1 );
            $this->values = wp_parse_args( $legacy, $this->defaults );
            return;
        }

        // 3) If nothing, we take defaults
        $this->values = $this->defaults;

    }

    public function reloadOptions() {
        $this->maybeLoad( true );
    }

    /**
     * Sanitize and save options
     *
     * @param null|array $values Optional. If set, options values will be received from param instead of $_POST.
     */
    public function updateOptions( $values = null ) {

        $this->maybeLoad();

        if ( is_array( $values ) ) {
            $form_data = $values;
        } else {
            if ( isset( $_POST['pys'][ $this->slug ] ) && is_array( $_POST['pys'][ $this->slug ] ) ) {
                $form_data = $_POST['pys'][ $this->slug ];
            } else {
                $form_data = [];
            }
        }

        // We only apply valid fields and sanitize them
        foreach ( $form_data as $key => $value ) {
            if ( isset( $this->options[ $key ] ) ) {
                $this->values[ $key ] = $this->sanitize_form_field( $key, $value );
            }
        }

        // We write to a new table (primarily)
        $written = $this->pys_set_in_storage( $this->option_key, $this->values, 1 );

        if ( ! $written ) {
            // Fallback: if we couldn't write to our table, we save it in wp_options
            update_option( $this->option_key, $this->values, false );
        }

    }

    /**
     * Sanitize form field
     *
     * @param string $key   Field key
     * @param array  $value Field value
     *
     * @return mixed Sanitized field value
     */
    private function sanitize_form_field( $key, $value ) {

        $type = $this->options[ $key ];

        // look for very specific sanitization filter
        $filter_name = "{$this->option_key}_settings_sanitize_{$key}_field";
        if ( has_filter( $filter_name ) ) {
            return apply_filters( $filter_name, $value );
        }

        // look for a sanitize_FIELDTYPE_field method
        if ( is_callable( array( $this, 'sanitize_' . $type . '_field' ) ) ) {
            return $this->{'sanitize_' . $type . '_field'}( $value );
        }

        // fallback to text
        return $this->sanitize_text_field( $value );

    }

    /**
     * Output text input
     *
     * @param        $key
     * @param string $placeholder
     * @param bool   $disabled
     * @param bool   $hidden
     * @param bool   $empty
     */
    public function render_text_input( $key, $placeholder = '', $disabled = false, $hidden = false, $empty = false, $type = 'standard' ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;
        $attr_value = $empty == false ? $this->getOption( $key ) : "";

        $classes = array(
            "input-$type"
        );

        if ( $hidden ) {
            $classes[] = 'form-control-hidden';
        }

        $classes = implode( ' ', $classes );
        ?>

        <input <?php disabled( $disabled ); ?>
                type="text"
                name="<?php echo esc_attr( $attr_name ); ?>"
                id="<?php echo esc_attr( $attr_id ); ?>"
                value="<?php echo esc_attr( $attr_value ); ?>"
                placeholder="<?php echo esc_attr( $placeholder ); ?>"
                class="<?php echo esc_attr( $classes ); ?>">
        <?php
    }

    /**
     * Output text input
     *
     * @param        $key
     * @param string $placeholder
     * @param bool   $disabled
     * @param bool   $hidden
     * @param bool   $empty
     */
    public function render_password_input( $key, $placeholder = '', $disabled = false, $hidden = false, $empty = false, $type = 'standard' ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;
        $attr_value = $empty == false ? $this->getOption( $key ) : "";

        $classes = array(
            "input-$type",
            "passwordInput"
        );

        if ( $hidden ) {
            $classes[] = 'form-control-hidden';
        }

        $classes = implode( ' ', $classes );
        ?>
        <div class="password-block">
            <input <?php disabled( $disabled ); ?>
                    type="text"
                    name="<?php echo esc_attr( $attr_name ); ?>"
                    id="<?php echo esc_attr( $attr_id ); ?>"
                    value="<?php echo esc_attr( $attr_value ); ?>"
                    placeholder="<?php echo esc_attr( $placeholder ); ?>"
                    class="<?php echo esc_attr( $classes ); ?>"
                    style="display:none;"
            >

            <input type="text" class="maskedInput input-<?php echo esc_attr( $type ); ?>" data-value="<?php echo esc_attr( $attr_value ); ?>">
        </div>
        <?php
    }

    /**
     * Output pixel ID input (text)
     *
     * @param        $key
     * @param string $placeholder
     * @param int    $index
     */
    public function render_pixel_id( $key, $placeholder = '', $index = 0 ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_id = 'pys_' . $this->slug . '_' . $key . '_' . $index;

        $values = (array) $this->getOption( $key );
        $attr_value = isset( $values[ $index ] ) ? $values[ $index ] : null;

        ?>

        <input type="text" name="<?php echo esc_attr( $attr_name ); ?>"
               id="<?php echo esc_attr( $attr_id ); ?>"
               value="<?php echo esc_attr( $attr_value ); ?>"
               placeholder="<?php echo esc_attr( $placeholder ); ?>"
               class="input-standard">
        <?php

    }


    /**
     * Output text area input array item
     *
     * @param        $key
     * @param string $placeholder
     * @param int $index
     * @param bool $enabled
     */
    public function render_text_area_array_item( $key, $placeholder = '', $index = 0, $enabled = true ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_id = 'pys_' . $this->slug . '_' . $key . '_' . $index;

        $values = (array) $this->getOption( $key );
        $attr_value = isset( $values[ $index ] ) ? $values[ $index ] : null;

        ?>

        <textarea type="text" name="<?php echo esc_attr( $attr_name ); ?>"
                  id="<?php echo esc_attr( $attr_id ); ?>"
                  placeholder="<?php echo esc_attr( $placeholder ); ?>"
                  class="textarea-standard" <?= !$enabled ? 'disabled' : ''; ?>><?php echo esc_attr( $attr_value ); ?></textarea>

        <?php
    }

    /**
     * Output text input array item
     *
     * @param        $key
     * @param string $placeholder
     * @param int    $index
     */
    public function render_text_input_array_item( $key, $placeholder = '', $index = 0,$hidden = false ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_id = 'pys_' . $this->slug . '_' . $key . '_' . $index;

        $values = (array) $this->getOption( $key );
        $attr_value = isset( $values[ $index ] ) ? $values[ $index ] : null;

        ?>

        <input type=<?=$hidden? "hidden": "text"?> name="<?php echo esc_attr( $attr_name ); ?>"
               id="<?php echo esc_attr( $attr_id ); ?>"
               value="<?php echo esc_attr( $attr_value ); ?>"
               placeholder="<?php echo esc_attr( $placeholder ); ?>"
               class="input-standard">
        <?php
    }


    /**
     * Output text area input
     *
     * @param        $key
     * @param string $placeholder
     * @param bool   $disabled
     * @param bool   $hidden
     */
    public function render_text_area_input( $key, $placeholder = '', $disabled = false, $hidden = false ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;
        $attr_value = $this->getOption( $key );

        $classes = array( 'textarea-large' );

        if( $hidden ) {
            $classes[] = 'form-control-hidden';
        }

        $classes = implode( ' ', $classes );

        ?>

        <textarea <?php disabled( $disabled ); ?> name="<?php echo esc_attr( $attr_name ); ?>"
                                                  id="<?php echo esc_attr( $attr_id ); ?>" rows="5"
                                                  placeholder="<?php echo esc_attr( $placeholder ); ?>"
                                                  class="<?php echo esc_attr( $classes ); ?>"><?php esc_html_e( $attr_value ); ?></textarea>

        <?php

    }

    /**
     * Output checkbox input stylized as switcher
     *
     * @param      $key
     * @param bool $collapse
     * @param bool $disabled
     */
    public function render_switcher_input( $key, $collapse = false, $disabled = false, $type = 'secondary' ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;
        $attr_value = $this->getOption( $key );
        $input_class = $label_class = '';

        $classes = array( "$type-switch" );

        if ( $collapse ) {
            $classes[] = 'collapse-control';
        }

        if ( $disabled ) {
            $classes[] = 'disabled';
        }

        if ( $type === 'primary' ) {
            $input_class = 'primary-switch-input';
            $label_class = 'primary-switch-btn';
        } elseif ( $type === 'secondary' ) {
            $input_class = 'custom-switch-input';
            $label_class = 'custom-switch-btn';
        }

        $classes = implode( ' ', $classes );

        ?>

        <div class="<?php echo esc_attr( $classes ); ?>">

            <?php if ( !$disabled ) : ?>
                <input type="hidden" name="<?php echo esc_attr( $attr_name ); ?>" value="0">
            <?php endif; ?>

            <?php if ( $collapse ) : ?>
                <input type="checkbox" name="<?php echo esc_attr( $attr_name ); ?>"
                       value="1" <?php disabled( $disabled, true ); ?> <?php checked( $attr_value, true ); ?>
                       id="<?php echo esc_attr( $attr_id ); ?>"
                       class="<?php echo esc_attr( $input_class ); ?>"
                       data-target="pys_<?php echo esc_attr( $this->slug ); ?>_<?php echo esc_attr( $key ); ?>_panel">
            <?php else : ?>
                <input type="checkbox" name="<?php echo esc_attr( $attr_name ); ?>"
                       value="1" <?php disabled( $disabled, true ); ?> <?php checked( $attr_value, true ); ?>
                       id="<?php echo esc_attr( $attr_id ); ?>"
                       class="<?php echo esc_attr( $input_class ); ?>">
            <?php endif; ?>

            <label class="<?php echo esc_attr( $label_class ); ?>" for="<?php echo esc_attr( $attr_id ); ?>">
                <?php if ( $type === 'primary' ) : ?>
                    <span class="<?php echo esc_attr( $label_class ); ?>-slider"></span>
                <?php endif; ?>
            </label>
        </div>

        <?php
    }

    public function render_switcher_input_array( $key, $index = 0 ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_id = 'pys_' . $this->slug . '_' . $key . "_" . $index;
        $attr_values = (array) $this->getOption( $key );
        $value = "index_" . $index;
        $valueIndex = array_search( $value, $attr_values );

        $classes = array( 'secondary-switch' );
        $classes = implode( ' ', $classes );

        ?>

        <div class="<?php echo esc_attr( $classes ); ?>">
            <input type="checkbox"
                   name="<?php echo esc_attr( $attr_name ); ?>"
                   value="<?php echo esc_attr( $value ); ?>"
                <?php echo $valueIndex !== false ? "checked" : "" ?>
                   id="<?php echo esc_attr( $attr_id ); ?>"
                   class="custom-switch-input <?php echo esc_attr( $key ); ?>">

            <label class="custom-switch-btn" for="<?php echo esc_attr( $attr_id ); ?>"></label>
        </div>

        <?php
    }

    function renderDummySwitcher($isEnable = false) {
        $attr = $isEnable ? " checked='checked'" : "";
        ?>

        <div class="secondary-switch disabled">
            <input type="checkbox" value="1" disabled="disabled" <?=$attr?> class="custom-switch-input">
            <label class="custom-switch-btn"></label>
        </div>

        <?php
    }

    /**
     * Output checkbox input
     *
     * @param      $key
     * @param      $label
     * @param bool $disabled
     */
    public function render_checkbox_input( $key, $label, $disabled = false ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_value = $this->getOption( $key );
        $id = $key . "_" . random_int( 1, 1000000 );

        ?>

        <div class="small-checkbox">
            <input type="hidden" name="<?php echo esc_attr( $attr_name ); ?>" value="0">
            <input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $attr_name ); ?>"
                   value="1"
                   class="small-control-input" <?php disabled( $disabled, true ); ?> <?php checked( $attr_value, true ); ?>>
            <label class="small-control small-checkbox-label" for="<?php echo esc_attr( $id ); ?>">
                <span class="small-control-indicator"><i class="icon-check"></i></span>
                <span class="small-control-description"><?php echo wp_kses_post( $label ); ?></span>
            </label>
        </div>

        <?php
    }

    /**
     * Output checkbox input array
     *
     * @param      $key
     * @param      $label
     * @param bool $disabled
     */
    public function render_checkbox_input_revert_array( $key, $label, $value, $disabled = false ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_values = (array) $this->getOption( $key );

        $isChecked = !in_array( $value, $attr_values );
        $id = $key . "_" . random_int( 1, 1000000 );
        ?>
        <div class="small-checkbox">
            <input type="hidden" name="<?php echo esc_attr( $attr_name ); ?>" value="<?= $value ?>">
            <input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $attr_name ); ?>"
                   value="<?= "revert_" . $value ?>"
                   class="small-control-input" <?php disabled( $disabled, true ); ?>
                <?php echo $isChecked ? "checked" : "" ?>>
            <label class="small-control small-checkbox-label" for="<?php echo esc_attr( $id ); ?>">
                <span class="small-control-indicator"><i class="icon-check"></i></span>
                <span class="small-control-description"><?php echo wp_kses_post( $label ); ?></span>
            </label>
        </div>

        <?php
    }


    public function render_checkbox_original_input_array($key, $label, $value, $disabled = false ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_values = (array) $this->getOption( $key );
        $id = $key . "_" . random_int( 1, 1000000 );
        $isChecked = in_array($value, $attr_values, true);
        ?>
        <div class="small-checkbox">
            <input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $attr_name ); ?>"
                   value="<?= $value ?>"
                   class="small-control-input" <?php disabled( $disabled, true ); ?> <?php echo $isChecked ? "checked" : "" ?>>
            <label class="small-control small-checkbox-label" for="<?php echo esc_attr( $id ); ?>">
                <span class="small-control-indicator"><i class="icon-check"></i></span>
                <span class="small-control-description"><?php echo wp_kses_post( $label ); ?></span>
            </label>
        </div>

        <?php

    }

    public function render_checkbox_input_array( $key, $label, $index = 0, $disabled = false ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_values = (array) $this->getOption( $key );
        $value = "index_" . $index;
        $valueIndex = array_search( $value, $attr_values );
        $id = $key . "_" . rand( 1, 1000000 );

        ?>
        <div class="small-checkbox">
            <input type="hidden" name="<?php echo esc_attr( $attr_name ); ?>" value="0">
            <input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $attr_name ); ?>"
                   value="<?= $value ?>"
                   class="small-control-input" <?php disabled( $disabled, true ); ?>
                <?php echo $valueIndex !== false ? "checked" : "" ?>>
            <label class="small-control small-checkbox-label" for="<?php echo esc_attr( $id ); ?>">
                <span class="small-control-indicator"><i class="icon-check"></i></span>
                <span class="small-control-description"><?php echo wp_kses_post( $label ); ?></span>
            </label>
        </div>

        <?php

    }


    public function render_checkbox_input_array_brand( $key, $label, $index = 0, $disabled = false ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_values = (array) $this->getOption( $key );
        $value = $index;
        $valueIndex = array_search( $value, $attr_values );
        $id = $key . "_" . rand( 1, 1000000 );
        ?>

        <div class="small-checkbox">
            <input type="checkbox"
                   name="<?php echo esc_attr( $attr_name ); ?>"
                   value="<?= $value ?>"
                   id="<?php echo esc_attr( $id ); ?>"
                   class="small-control-input"
                <?php disabled( $disabled, true ); ?>
                <?= $valueIndex !== false ? "checked" : "" ?>>
            <label class="small-control small-checkbox-label" for="<?php echo esc_attr( $id ); ?>">
                <span class="small-control-indicator"><i class="icon-check"></i></span>
                <span class="small-control-description"><?php echo wp_kses_post( $label ); ?></span>
            </label>
        </div>
        <?php
    }

    /**
     * Output radio input
     *
     * @param      $key
     * @param      $value
     * @param      $label
     * @param bool $disabled
     * @param bool $with_pro_badge
     */
    public function render_radio_input( $key, $value, $label, $disabled = false, $with_pro_badge = false ) {

        $id = $key . "_" . rand( 1, 1000000 );
        $attr_name = "pys[$this->slug][$key]";
        ?>

        <div class="radio-standard">
            <input type="radio"
                   name="<?php echo esc_attr( $attr_name ); ?>"
                <?php disabled( $disabled, true ); ?>
                   class="custom-control-input"
                   id="<?php echo esc_attr( $id ); ?>"
                <?php checked( $this->getOption( $key ), $value ); ?>
                   value="<?php echo esc_attr( $value ); ?>">
            <label class="standard-control radio-checkbox-label" for="<?php echo esc_attr( $id ); ?>">
                <span class="standard-control-indicator"></span>
                <span class="standard-control-description"><?php echo wp_kses_post( $label ); ?></span>
                <?php if ( $with_pro_badge ) {
                    renderCogBadge();
                } ?>
            </label>
        </div>

        <?php
    }

    /**
     * Output number input
     *
     * @param      $key
     * @param null $placeholder
     * @param bool $disabled
     */
    public function render_number_input( $key, $placeholder = '', $disabled = false, $max = null, $min = 0, $step = 'any', $suffix = '' ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;
        $attr_value = $this->getOption( $key );

        ?>
        <div class="input-number-wrapper">
            <button class="decrease"><i class="icon-minus"></i></button>
            <input <?php disabled( $disabled ); ?> type="number" name="<?php echo esc_attr( $attr_name ); ?>"
                                                   id="<?php echo esc_attr( $attr_id ); ?>"
                                                   value="<?php echo esc_attr( $attr_value ); ?>"
                                                   placeholder="<?php echo esc_attr( $placeholder ); ?>"
                                                   min="<?= $min ?>"
                <?php if ( $max != null ) : ?> max="<?= $max ?>" <?php endif; ?>
                                                   step="<?= $step ?>"
            >
            <button class="increase"><i class="icon-plus"></i></button>
        </div>

        <?php
    }

    /**
     * Output number input
     *
     * @param      $key
     * @param null $placeholder
     * @param bool $disabled
     */
    public function render_number_input_percent( $key, $placeholder = '', $disabled = false, $max = null, $min = 0, $step = 'any' ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;
        $attr_value = $this->getOption( $key );

        ?>
        <div class="input-number-wrapper input-number-wrapper-percent">
            <button class="decrease"><i class="icon-minus"></i></button>
            <input <?php disabled( $disabled ); ?> type="number" name="<?php echo esc_attr( $attr_name ); ?>"
                                                   id="<?php echo esc_attr( $attr_id ); ?>"
                                                   value="<?php echo esc_attr( $attr_value ); ?>"
                                                   placeholder="<?php echo esc_attr( $placeholder ); ?>"
                                                   min="<?= $min ?>"
                <?php if ( $max != null ) : ?> max="<?= $max ?>" <?php endif; ?>
                                                   step="<?= $step ?>"
            >
            <button class="increase"><i class="icon-plus"></i></button>
        </div>

        <?php

    }

    /**
     * Output select input
     *
     * @param      $key
     * @param      $options
     * @param bool $disabled
     * @param null $visibility_target
     * @param null $visibility_value
     */
    public function render_select_input( $key, $options, $disabled = false, $visibility_target = null, $visibility_value = null, $searchable = false ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;

        $classes = array( 'select-standard' );

        if ( $visibility_target ) {
            $classes[] = 'controls-visibility';
        }

        if($searchable){
            $classes[] = 'pys-pysselect2';
        }

        $classes = implode( ' ', $classes );

        ?>
        <div class="select-standard-wrap">
            <select class="<?php echo esc_attr( $classes ); ?>" id="<?php echo esc_attr( $attr_id ); ?>"
                    name="<?php echo esc_attr( $attr_name ); ?>" <?php disabled( $disabled ); ?>
                    data-target="<?php echo esc_attr( $visibility_target ); ?>"
                    data-value="<?php echo esc_attr( $visibility_value ); ?>" autocomplete="off">

                <option value="" disabled selected>Please, select...</option>

                <?php foreach ( $options as $option_key => $option_value ) : ?>
                    <option value="<?php echo esc_attr( $option_key ); ?>" <?php selected( $option_key, esc_attr( $this->getOption( $key ) ) ); ?> <?php disabled( $option_key, 'disabled' ); ?>><?php echo esc_attr( $option_value ); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php
    }

    /**
     * Output multi select input
     *
     * @param      $key
     * @param      $values
     * @param bool $disabled
     * @param string $placeholder
     */
    public function render_group_select_brand_taxonomy( $key, $values, $disabled = false, $placeholder = "" ) {

        $attr_name = "pys[$this->slug][$key]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;
        ?>

        <div class="select-standard-wrap">
            <input type="hidden" name="<?php echo esc_attr( $attr_name ); ?>" value="">
            <select class="pys-pysselect2 select-standard pysselect2-brand"
                    data-placeholder="<?= $placeholder ?>"
                    name="<?php echo esc_attr( $attr_name ); ?>"
                    id="<?php echo esc_attr( $attr_id ); ?>"
                <?php disabled( $disabled ); ?>
                    autocomplete="off">
                <?php foreach ( $values[ 'empty' ] as $option_key => $option_value ) {
                    if ( $option_key == 'product_visibility' ) continue; ?>
                    <option value="<?php echo esc_attr( $option_key ); ?>" <?php selected( $option_key, esc_attr( $this->getOption( $key ) ) ); ?>><?php echo esc_attr( $option_value ); ?></option>';
                <?php } ?>
                <?php if ( isset( $values[ 'match' ] ) ) : ?>
                    <optgroup label='Match "brand" Attributes'>
                        <?php foreach ( $values[ 'match' ] as $option_key => $option_value ) {
                            if ( $option_key == 'product_visibility' ) continue; ?>
                            <option value="<?php echo esc_attr( $option_key ); ?>" <?php selected( $option_key, esc_attr( $this->getOption( $key ) ) ); ?>><?php echo esc_attr( $option_value ); ?></option>';
                        <?php } ?>
                    </optgroup>
                <?php endif; ?>
                <?php if ( isset( $values[ 'global' ] ) ) : ?>
                    <optgroup label="Global Product Attributes">
                        <?php foreach ( $values[ 'global' ] as $option_key => $option_value ) {
                            if ( $option_key == 'product_visibility' ) continue; ?>
                            <option value="<?php echo esc_attr( $option_key ); ?>" <?php selected( $option_key, esc_attr( $this->getOption( $key ) ) ); ?>><?php echo esc_attr( $option_value ); ?></option>';
                        <?php } ?>
                    </optgroup>
                <?php endif; ?>
                <?php if ( isset( $values[ 'pa' ] ) ) : ?>
                    <optgroup label="Product Attributes">
                        <?php foreach ( $values[ 'pa' ] as $option_key => $option_value ) {
                            if ( $option_key == 'product_visibility' ) continue; ?>
                            <option value="<?php echo esc_attr( $option_key ); ?>" <?php selected( $option_key, esc_attr( $this->getOption( $key ) ) ); ?> <?php disabled( $option_key, 'disabled' ); ?>><?php echo esc_attr( $option_value ); ?></option>';
                        <?php } ?>
                    </optgroup>
                <?php endif; ?>

            </select>
        </div>

        <?php
    }

    /**
     * Output multi select input
     *
     * @param      $key
     * @param      $values
     * @param bool $disabled
     */
    public function render_multi_select_input( $key, $values, $disabled = false, $placeholder = "" ) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;

        $selected = $this->getOption( $key ) ? $this->getOption( $key ) : array();
        ?>

        <input type="hidden" name="<?php echo esc_attr( $attr_name ); ?>" value="">
        <select class="pys-pysselect2"
                data-placeholder="<?= $placeholder ?>"
                name="<?php echo esc_attr( $attr_name ); ?>"
                id="<?php echo esc_attr( $attr_id ); ?>" <?php disabled( $disabled ); ?> style="width: 100%;"
                multiple>
            <?php foreach ( $values as $option_key => $option_value ) : ?>
                <option value="<?php echo esc_attr( $option_key ); ?>"
                    <?php selected( in_array( $option_key, $selected ) ); ?>
                    <?php disabled( $option_key, 'disabled' ); ?>
                >
                    <?php echo esc_attr( $option_value ); ?>
                </option>
            <?php endforeach; ?>

        </select>

        <?php
    }

    /**
     * Output tags select input
     *
     * @param      $key
     * @param bool $disabled
     */
    public function render_tags_select_input( $key, $disabled = false ,$default = []) {

        $attr_name = "pys[$this->slug][$key][]";
        $attr_id = 'pys_' . $this->slug . '_' . $key;

        $tags = $this->getOption( $key );
        $tags = is_array( $tags ) ? array_filter( $tags ) : array();
        $tags = array_diff($tags,$default);
        ?>

        <input type="hidden" name="<?php echo esc_attr( $attr_name ); ?>" value="">
        <select class="pys-tags-pysselect2" name="<?php echo esc_attr( $attr_name ); ?>"
                id="<?php echo esc_attr( $attr_id ); ?>" <?php disabled( $disabled ); ?> style="width: 100%;"
                multiple>

            <?php foreach ( $default as $tag ) : ?>
                <option  value="<?php echo esc_attr( $tag ); ?>" selected locked="locked">
                    <?php echo esc_attr( $tag ); ?>
                </option>
            <?php endforeach; ?>

            <?php foreach ( $tags as $tag ) : ?>
                <option value="<?php echo esc_attr( $tag ); ?>" selected>
                    <?php echo esc_attr( $tag ); ?>
                </option>
            <?php endforeach; ?>

        </select>

        <?php
    }

    function render_hide_pixel_block() { ?>
        <?php if ( SuperPack()->getOption( 'enable_hide_this_tag_by_url' ) ) : ?>
            <div class="line-dark"></div>

            <div class="hide-block-item-switcher">
                <?php $this->render_switcher_input( "hide_this_url" ); ?>
                <h4 class="switcher-label secondary_heading">Hide this tag if the URL includes</h4>
            </div>

            <div class="hide-block-item">
                <h4 class="primary_heading mb-4">Hide this tag if the page URL any of these values. The tag will not
                    fire on the specific page only.</h4>
                <?php $this->render_tags_select_input( 'hide_this_url_contain', false ); ?>
            </div>
        <?php endif; ?>

        <?php if ( SuperPack()->getOption( 'enable_hide_this_tag_by_tags' ) ) : ?>
            <div class="line-dark"></div>

            <div class="hide-block-item-switcher">
                <?php $this->render_switcher_input( "hide_this_tag" ); ?>
                <h4 class="switcher-label secondary_heading">Hide this tag if the landing URL includes any of these
                    values</h4>
            </div>

            <div class="hide-block-item">
                <h4 class="primary_heading mb-4">Hide this tag if the <b>landing page URL</b> includes any of these URL
                    parameters values. The tag will not fire on any pages. </h4>
                <?php $this->render_tags_select_input( 'hide_this_tag_contain', false ); ?>
                <div class="pt-4">
                    <p class="form-text">Use the parameter and value (param_name=value), or just the parameter's name
                        (param_name).</p>
                    <p class="form-text">Example: Use brand=Apple, or brand, to hide the tag when the landing page URL
                        contains brand=Apple</p>
                </div>
            </div>

            <div class="hide-block-item">
                <h4 class="primary_heading mr-16">Hide for:</h4>
                <?php $this->render_number_input( "hide_this_tag_timeout", '', false, 720, 0, 0.01 ); ?>
                <span class="ml-16">Hours</span>
            </div>

        <?php endif;
    }

    /**
     * Sanitize text field value
     *
     * @param $value
     *
     * @return string
     */
    public function sanitize_text_field( $value ) {

        $value = is_null( $value ) ? '' : $value;

        return wp_kses_post( trim( stripslashes( $value ) ) );

    }

    /**
     * Sanitize textarea field value
     *
     * @param $value
     *
     * @return string
     */
    public function sanitize_textarea_field( $value ){

        $value = is_null( $value ) ? '' : $value;

        return trim( stripslashes( $value ) );

    }

    /**
     * Sanitize number field value
     *
     * @param $value
     *
     * @return float
     */
    public function sanitize_number_field( $value ) {
        return (float) $value;
    }

    /**
     * Sanitize checkbox field value
     *
     * @param $value
     *
     * @return bool
     */
    public function sanitize_checkbox_field( $value ) {

        if ( is_bool( $value ) || is_numeric( $value ) ) {
            return (bool) $value;
        } else {
            return false;
        }

    }

    /**
     * Sanitize radio field value
     *
     * @param $value
     *
     * @return null|string
     */
    public function sanitize_radio_field( $value ) {
        return ! is_null( $value ) ? trim( stripslashes( $value ) ) : null;
    }

    /**
     * Sanitize select field value
     *
     * @see deepSanitizeTextField()
     *
     * @param $value
     *
     * @return array|string
     */
    public function sanitize_select_field( $value ) {

        $value = is_null( $value ) ? '' : $value;

        return deepSanitizeTextField( stripslashes( $value ) );

    }

    /**
     * Sanitize tags select value
     *
     * @see deepSanitizeTextField()
     *
     * @param $value
     *
     * @return array
     */
    public function sanitize_multi_select_field( $value ) {
        return is_array( $value ) ? array_map( 'PixelYourSite\deepSanitizeTextField', $value ) : array();
    }

    /**
     * @param $value
     *
     * @return array
     */
    public function sanitize_tag_select_field( $value ) {
        return is_array( $value ) ? array_map( 'PixelYourSite\deepSanitizeTextField', $value ) : array();
    }

    /**
     * Sanitize array field value
     *
     * @param $values
     *
     * @return array
     */
    public function sanitize_array_field( $values ) {

        $values = is_array( $values ) ? $values : array();
        $sanitized = array();

        foreach ( $values as $key => $value ) {

            $new_value = $this->sanitize_text_field( $value );

            if ( ! empty( $new_value ) && ! in_array( $new_value, $sanitized ) ) {
                $sanitized[ $key ] = $new_value;
            }

        }

        return $sanitized;
    }

    /**
     * Sanitize array field value
     *
     * @param $values
     *
     * @return array
     */
    public function sanitize_array_textarea_field( $values ) {

        $values = is_array( $values ) ? $values : array();
        $sanitized = array();

        foreach ( $values as $key => $value ) {

            $new_value = $this->sanitize_textarea_field( $value );

            if ( ! empty( $new_value ) && ! in_array( $new_value, $sanitized ) ) {
                $sanitized[ $key ] = $new_value;
            }

        }

        return $sanitized;
    }

    /**
     * Sanitize revert_array field value
     *
     * This array save only unchecked values
     *
     * @param $values
     *
     * @return array
     */
    public function sanitize_revert_array_field( $values ) {

        $values = is_array( $values ) ? $values : array();
        $sanitized = array();

        $disabled = array();

        foreach ( $values as $key => $value ) {
            if(strpos($value, "revert_") !== false) {
                $disabled[] = str_replace("revert_","",$value);
                unset($values[$key]);
            }
        }
        foreach ( $values as $key => $value ) {

            $new_value = $this->sanitize_text_field( $value );

            if (  !empty( $new_value ) && ! in_array( $new_value, $sanitized ) && !in_array($new_value,$disabled)) {
                $sanitized[ $key ] = $new_value;
            }

        }

        return $sanitized;

    }

    /**
     * Sanitize array field value with duplicates value
     *
     * @param $values
     *
     * @return array
     */
    public function sanitize_array_v_field( $values ) {

        $values = is_array( $values ) ? $values : array();
        $sanitized = array();

        foreach ( $values as $key => $value ) {

            $new_value = $this->sanitize_text_field( $value );

            if ( ! empty( $new_value ) ) {
                $sanitized[ $key ] = $new_value;
            }

        }

        return $sanitized;

    }
    public function convertTimeToSeconds($timeValue = 24, $type = 'hours')
    {
        switch ($type){
            case 'hours':
                $time = $timeValue * 60 * 60;
                break;
            case 'minute':
                $time = $timeValue * 60;
                break;
            case 'seconds':
                $time = $timeValue;
                break;
        }
        return $time;
    }

    function get_object_taxonomies_for_brand(){
        $attributes['empty']['empty'] = 'Select taxonomy';

        $taxonomy_objects = get_object_taxonomies( 'product', 'objects');
        foreach ($taxonomy_objects as $taxonomy_key => $taxonomy_object) {
            $cat = 'global';
            if(substr( $taxonomy_key, 0, 3 ) === "pa_")
            {
                $cat = 'pa';
            }
            if( stripos($taxonomy_key, 'brand')) {
                $cat = 'match';
            }
            if( $taxonomy_key == 'product_type' ) {
                $attributes[$cat][$taxonomy_key]= 'Product Type ('.$taxonomy_key.')';
            } else {
                $attributes[$cat][$taxonomy_key]= $taxonomy_object->label.' ('.$taxonomy_key.')';
            }
        }
        return $attributes;
    }

    function getMainTagId(){
        $id = $this->getPixelIDs();
        $main_tag = '';
        if(is_array($id) && isset($id[0]))
        {
            $main_tag = $id[0];
        }else{
            $main_tag = $id;
        }
        return (!empty($main_tag)) ? $main_tag : '';
    }
    function getHideInfoPixels(){
        $pixels = array();

        if($this->getOption( 'hide_this_tag' )) {
            $pixels[] = array(
                'pixel' => $this->getPixelIDs()[0],
                'hide_tag_contain' => $this->getOption('hide_this_tag_contain'),
                'hide_tag_time' => $this->getOption('hide_this_tag_timeout')
            );
        }
        if(SuperPack()->getOption( 'additional_ids_enabled' )) {
            $additionalPixels = array();
            switch ($this->getSlug()) {
                case 'facebook' :
                    $additionalPixels = SuperPack()->getFbAdditionalPixel(); break;
                case 'ga' :
                    $additionalPixels = SuperPack()->getGaAdditionalPixel(); break;
                case 'ads' :
                    $additionalPixels = SuperPack()->getAdsAdditionalPixel(); break;
                case 'openai' :
                    if ( method_exists( SuperPack(), 'getOpenAiAdditionalPixel' ) ) {
                        $additionalPixels = SuperPack()->getOpenAiAdditionalPixel();
                    }
                    break;

            }
            foreach ($additionalPixels as $_pixel) {
                if($_pixel->isHide){
                    $pixels[] = array(
                        'pixel' => $_pixel->pixel,
                        'hide_tag_contain' => $_pixel->hideCondition,
                        'hide_tag_time' => $_pixel->hideTime
                    );
                }
            }
        }


        return $pixels;
    }
    function checkHidePixel() {
        $existing_hide_pixels = apply_filters('hide_pixels', []);

        $full_url = pys_get_current_page_url();

        if (isset($_COOKIE['hide_tag_' . $this->getMainTagId()])) {
            $existing_hide_pixels[] = $this->getMainTagId();
        }
        if ($this->getOption('hide_this_url')) {
            $hide_keywords = $this->getOption('hide_this_url_contain') ?: [];

            foreach ($hide_keywords as $keyword) {
                if (empty($keyword)) continue;
                if (stripos($full_url, $keyword) !== false) {
                    $existing_hide_pixels[] = $this->getMainTagId();
                    break;
                }
            }
        }

        if ($existing_hide_pixels) {
            add_filter('hide_pixels', function () use ($existing_hide_pixels) {
                return array_unique($existing_hide_pixels);
            });
        }
    }

    public function normalizeSPOptions( $main_pixel, $main_pixel_options ) {

        $options = array(
            'pixel_id'       => $main_pixel,
            'is_enable'      => $this->getOption( 'main_pixel_enabled' ),
            'is_fire_signal' => $this->getOption( 'is_fire_signal' ),
            'is_fire_woo'    => $this->getOption( 'is_fire_woo' ),
            'is_fire_edd'    => $this->getOption( 'is_fire_edd' ),
            'logic_conditional_track'    => $this->getOption( 'logic_conditional_track' ),
        );

        if ( !empty( $main_pixel_options ) ) {
            $options = array_merge( json_decode( $main_pixel_options, true ), $options );
        }

        return $options;
    }

    public function renderValueOptionsBlock( $context, $useEnable = true, $usePopover = true, $useBorder = true, $title = '' ) {
        if ( empty( $context ) ) {
            return;
        }

        if ( empty( $title ) ) {
            $title = 'Value parameter settings:';
        }

        $prefixes = [
            'purchase',
            'initiate_checkout',
            'complete_registration'
        ];
        if ( count( array_filter( $prefixes, function ( $prefix ) use ( $context ) {
                return strpos( $context, $prefix ) !== false;
            } ) ) > 0 ) {
            $priceText = 'Order\'s total';
            $percentText = 'Percent of the order\'s total';
        } else {
            $priceText = 'Product price';
            $percentText = 'Percent of the product price';
        }
        ?>
        <div class="gap-24">
            <div class="d-flex align-items-center">
                <?php if ( !is_null( $this->getOption( $context . '_value_enabled' ) ) || $useEnable ) : ?>
                    <div class="mr-16">
                        <?php $this->render_switcher_input( $context . '_value_enabled', true ); ?>
                    </div>
                <?php endif; ?>
                <h4 class="secondary_heading"><?php echo esc_html( $title ); ?></h4>
                <?php
                if ( $usePopover ) {
                    renderPopoverButton( $context . '_event_value' );
                } ?>
            </div>

            <div <?php if ( !is_null( $this->getOption( $context . '_value_enabled' ) ) ) {
                renderCollapseTargetAttributes( $context . '_value_enabled', PYS() );
            } ?>>
                <div class="radio-inputs-wrap-big woo-settings-block">
                    <?php $this->render_radio_input( $context . '_value_option', 'price', $priceText ); ?>

                    <?php if ( strpos( $context, 'edd_' ) !== 0 ) { ?>
                        <?php if ( !isPixelCogActive() && !isWcCogFeatureEnabled()  ) { ?>
                            <?php $this->render_radio_input( $context . '_value_option', 'cog', 'Price minus Cost of Goods.', true, true ); ?>
                        <?php } else { ?>
                            <?php $this->render_radio_input( $context . '_value_option', 'cog', 'Price minus Cost of Goods', false ); ?>
                        <?php } ?>
                    <?php } ?>

                    <div class="grid-table">
                        <?php if ( !is_null( $this->getOption( $context . '_value_percent' ) ) ) { ?>
                            <?php $this->render_radio_input( $context . '_value_option', 'percent', $percentText ); ?>
                            <?php $this->render_number_input( $context . '_value_percent' ); ?>
                        <?php } ?>

                        <?php $this->render_radio_input( $context . '_value_option', 'global', 'Use global value' ); ?>
                        <?php $this->render_number_input( $context . '_value_global' ); ?>
                    </div>
                </div>

                <?php if ( $useBorder ) : ?>
                    <div class="line mt-24"></div>
                <?php endif; ?>
            </div>
        </div>


        <?php
    }

    public function issetOption( $key ) {

        $this->maybeLoad();

        if ( isset( $this->defaults[ $key ] ) ) {
            return true;
        }

        return false;
    }


    public function renderSPOptionForPixel()
    { ?>
        <div class="gap-16">
            <div>
                <?php $this->render_checkbox_input( 'is_fire_signal', 'Fire the active automated events for this pixel' ); ?>
            </div>
            <?php if ( isWooCommerceActive() ) : ?>
                <div>
                    <?php $this->render_checkbox_input( 'is_fire_woo', 'Fire the WooCommerce events for this pixel' ); ?>
                </div>
            <?php endif; ?>
            <?php if ( isEddActive() ) : ?>
                <div>
                    <?php $this->render_checkbox_input( 'is_fire_edd', 'Fire the Easy Digital Downloads events for this pixel' ); ?>
                </div>
            <?php endif; ?>
        </div>

        <div>
            <h4 class="primary_heading mb-8">Display conditions:</h4>
            <div class="conditions-logic-track">
                <label>Logic: </label>
                <?php
                $track_options = array(
                    'track' => 'Track',
                    'dont_track' => 'Don\'t track',
                );
                $this->render_select_input('logic_conditional_track', $track_options);
                ?>
            </div>
            <?php
            $main_pixel = $this->getOption( 'main_pixel' );
            if ( !empty( $main_pixel ) && isset( $main_pixel[ 0 ] ) ) {
                $conditions = SuperPack\SPPixelId::fromArray( json_decode( $main_pixel[ 0 ], true ) );
                SuperPack\SpPixelCondition()->renderHtml( $conditions->displayConditions );
            } else {
                SuperPack\SpPixelCondition()->renderHtml();
            } ?>
        </div>

        <?php
        if ( SuperPack()->getOption( 'enable_hide_this_tag_by_tags' ) || SuperPack()->getOption( 'enable_hide_this_tag_by_url' ) ) {
            $this->render_hide_pixel_block();
        }
    }
}