<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/** @var PYS $this */

include "html-popovers.php";

?>

<div class="cards-wrapper cards-wrapper-style2 gap-24 setting-wrapper">
    <!-- External IDs -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('External IDs', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input( 'send_external_id' ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Use external_id', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('A stable per-browser id sent as external_id. It is derived from the request on the first page view and then kept in a cookie called pbid.', 'pys');?>
                    </p>
                </div>
                <div class="d-flex align-items-center number-option-block">
                    <label class="primary_heading"><?php _e('external_id expire days for cookie:','pys');?></label>
                    <?php PYS()->render_number_input( 'external_id_expire', '', false, 365, 1); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Ajax options -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Ajax options', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input("server_event_use_ajax" ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Use Ajax when API is enabled, or when external_id\'s are used. Keep this option active if you use a cache.', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Use Ajax when Meta conversion API, or Pinterest API are enabled, or when external_id\'s are used. This helps serving unique event_id values for each pair of browser/server events, ensuring deduplication works. It also ensures uniques external_id\'s are used for each user. Keep this option active if you use a cache solution that can serve the same event_id or the same external_id multiple times.', 'pys');?>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input("server_static_event_use_ajax" ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Use Ajax for <b>Static events</b> when API is enabled.', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Do not use AJAX requests for static events if it interferes with page loading, or if the requests during loading block other site functions (such as updating the cart during loading).', 'pys');?>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input("use_send_beacon" ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Use <b>navigator.sendBeacon</b> instead of jQuery.ajax for better performance', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('This option improves site performance by using the modern sendBeacon API which allows the browser to reliably deliver events in the background while prioritizing resources for the page itself. Falls back to jQuery.ajax if sendBeacon is not supported.', 'pys');?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- REST API -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('REST API', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input( 'fetch_user_data_via_rest' ); ?>
                        <h4 class="switcher-label secondary_heading">
                            <?php _e( 'Fetch visitor data via REST API <strong>(for full-page caching)</strong>', 'pys' ); ?>
                        </h4>
                    </div>
                    <div class="pys-notice pys-notice-warning mt-4" style="background:#fff8e1;border-left:4px solid #f0ad4e;padding:12px 16px;border-radius:4px;">
                        <strong><?php _e( '&#9888; Two situations need this &mdash; otherwise leave it off', 'pys' ); ?></strong>
                        <p class="mt-2 mb-0">
                            <?php _e(
                                'When active, everything that belongs to one particular visitor is taken out of the '
                                . 'cached HTML and loaded per page view through a separate REST API call: User ID, '
                                . 'nonces, the Advanced Matching parameters of logged-in visitors for the Meta, '
                                . 'TikTok, Pinterest, Reddit and OpenAI pixels, and the visit data recorded in the '
                                . 'PHP session (landing page, traffic source, UTM parameters).<br><br>'
                                . '<strong>Turn it on if your cache serves logged-in visitors a shared copy of the '
                                . 'page.</strong> Advanced Matching for visitors who are not logged in is already '
                                . 'cache-safe: the plugin never writes their email, phone or name into the page &mdash; '
                                . 'the browser supplies them from the visitor\'s own cookie. Logged-in visitors are '
                                . 'different: their profile and billing data exist only on the server, and this option '
                                . 'fetches them per visitor instead of rendering them into a page a cache could hand to '
                                . 'somebody else.<br><br>'
                                . '<strong>Turn it on also if</strong> you need the visit data of visitors who have not '
                                . 'accepted cookies yet, because without this call the landing page, the traffic source '
                                . 'and the UTM parameters come only from the cookies of that visitor and from the '
                                . 'current URL, and a consent manager that blocks those cookies leaves nothing to '
                                . 'read.<br><br>'
                                . 'The landing page, the traffic source and the UTM parameters are kept out of the '
                                . 'cached HTML at all times, with or without this option, and so is the Advanced '
                                . 'Matching of visitors who are not logged in, so those never travel from one visitor '
                                . 'to another.<br><br>'
                                . '<strong>The cost:</strong> one extra REST request, with a full WordPress boot, on '
                                . 'every page view, and the pixel events wait for its answer before they fire. On '
                                . 'shared hosting that is noticeable.',
                                'pys'
                            ); ?>
                        </p>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e(
                            'After enabling, also exclude <code>/wp-json/pys/v1/dynamic-options</code> from all '
                            . 'caching rules in your caching plugin.',
                            'pys'
                        ); ?>
                    </p>
                    <p class="text-gray mt-4">
                        <?php _e(
                            'Order confirmation pages are an exception: their Advanced Matching comes from the order '
                            . 'itself and stays in the page, because those pages are never HTML-cached and the data '
                            . 'can only be read from the order URL.<br><br>'
                            . 'Note that this option covers PixelYourSite only. Other plugins may also print personal '
                            . 'data into the page (WooCommerce blocks, email marketing scripts), so if you cache pages '
                            . 'for logged-in users, excluding them from the cache remains the safest setup.',
                            'pys'
                        ); ?>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center number-option-block">
                        <label class="primary_heading"><?php _e('REST API rate limit (requests per minute per IP):', 'pys');?></label>
                        <?php PYS()->render_number_input( 'pys_check_permission_rate_limit', '', false, null, 1, 1 ); ?>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Maximum number of server-side tracking requests allowed per minute, per IP address, for each pixel endpoint. Requests over this limit receive an HTTP 429 response. Default is 60 (1 request per second). Increase this value if legitimate fast-browsing customers are being blocked, especially on stores with multiple active pixels firing on every page.', 'pys');?>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input( 'rest_order_validation_enabled' ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e( 'Validate orders for server-side purchase events', 'pys' );?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e( 'The server-side tracking endpoint is open to anonymous visitors, so anyone can post a purchase event to it. With this on, a purchase event that names an order is accepted only when that order really exists, is not in a status you excluded, and matches the order key when the browser sent one — which stops fabricated purchases from reaching your ad platforms.', 'pys' );?>
                    </p>
                    <p class="text-gray mt-4">
                        <?php _e( 'Turn it off only if your orders are created outside WooCommerce or Easy Digital Downloads — for example a headless checkout or a custom payment flow — and legitimate purchases are being dropped. Turning it off does not affect custom events, and it changes nothing on sites without WooCommerce or EDD: there the order check is skipped in either case.', 'pys' );?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Disable PHP session -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Disable PHP session', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('session_disable'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Disable PHP sessions', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Turn this on if the PHPSESSID cookie itself causes trouble — for example a page cache that refuses to serve cached pages once the cookie is set. It is no longer needed for speed: on AJAX and REST requests the session is now opened read-only, so it is released immediately instead of being held for the whole request. Note that other plugins can open a PHP session of their own, so this option cannot guarantee that the PHPSESSID cookie disappears from your site altogether.', 'pys');?>
                    </p>
                    <p class="text-gray mt-4">
                        <?php _e('Cost of turning it on: the landing page, the traffic source and the UTM parameters then come only from the cookies of that visitor and from the current URL, and the REST API option above has nothing left to read. With full-page caching the cookies are usually the better source anyway — on a cache hit PHP does not run, so the session records nothing — but if a consent manager blocks the cookies of the plugin, the visit stays unrecorded until the visitor accepts them.', 'pys');?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Advanced user-data detections -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Advanced user-data detections', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('enable_auto_save_advance_matching'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Forms', 'pys');?> <a class="link" href="https://www.youtube.com/watch?v=snUKcsTbvCk" target="_blank"><?php _e('Watch video', 'pys');?></a></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('You can define the form\'s fields we can use by adding their names in these fields.', 'pys');?>
                    </p>
                </div>
                <div>
                    <h4 class="primary_heading mb-4">Fn:</h4>
                    <?php
                        $default_name_input = ["first_name","first-name","first name","name"];
                        $eventsFormFactory = apply_filters("pys_form_event_factory",[]);
                        foreach ($eventsFormFactory as $activeFormPlugin) :
                            if(isset($activeFormPlugin->getDefaultMatchingInput()['first_name']))
                            {
                                $default_name_input = array_unique( array_merge( $default_name_input , $activeFormPlugin->getDefaultMatchingInput()['first_name'] ) );
                            }
                        endforeach;
                        PYS()->render_tags_select_input('advance_matching_fn_names',false, $default_name_input);
                    ?>
                </div>
                <div>
                    <h4 class="primary_heading mb-4">Ln:</h4>
                    <?php
                        $default_last_name_input = ["last_name","last-name","last name"];
                        foreach ($eventsFormFactory as $activeFormPlugin) :
                            if(isset($activeFormPlugin->getDefaultMatchingInput()['last_name']))
                            {
                                $default_last_name_input = array_unique( array_merge( $default_last_name_input , $activeFormPlugin->getDefaultMatchingInput()['last_name'] ) );
                            }
                        endforeach;
                        PYS()->render_tags_select_input('advance_matching_ln_names',false, $default_last_name_input);
                    ?>
                </div>
                <div>
                    <h4 class="primary_heading mb-4">Tel:</h4>
                    <?php
                        $default_tel_input = ["phone","tel"];
                        foreach ($eventsFormFactory as $activeFormPlugin) :
                            if(isset($activeFormPlugin->getDefaultMatchingInput()['tel']))
                            {
                                $default_tel_input = array_unique( array_merge( $default_tel_input , $activeFormPlugin->getDefaultMatchingInput()['tel'] ) );
                            }
                        endforeach;
                        PYS()->render_tags_select_input('advance_matching_tel_names',false,$default_tel_input);
                    ?>
                </div>
                <div>
                    <h4 class="primary_heading mb-4">Em:</h4>
                    <?php PYS()->render_tags_select_input( 'advance_matching_em_names' ); ?>
                    <p class="text-gray mt-4">
                        <?php _e('Use it only if we don\'t automatically detect the email field. Most forms correctly use type email, allowing us to detect the email values with no extra configuration.', 'pys');?>
                    </p>
                </div>

                <hr>

                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input( 'enable_auto_save_advance_matching_url' ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('URL Parameters', 'pys');?> <a class="link" href="https://www.youtube.com/watch?v=7kigOV2-tAI" target="_blank"><?php _e('Watch video', 'pys');?></a></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('You can define URL parameters using this format: [url_parameter-name-here]. Example: [url_utm_term] will take the value from a utm_term parameter if it\'s present.', 'pys');?>
                    </p>
                </div>
                <div>
                    <h4 class="primary_heading mb-4">Fn:</h4>
                    <?php PYS()->render_tags_select_input( 'advance_matching_url_fn_names' ); ?>
                </div>
                <div>
                    <h4 class="primary_heading mb-4">Ln:</h4>
                    <?php PYS()->render_tags_select_input( 'advance_matching_url_ln_names' ); ?>
                </div>
                <div>
                    <h4 class="primary_heading mb-4">Tel:</h4>
                    <?php PYS()->render_tags_select_input( 'advance_matching_url_tel_names' ); ?>
                </div>
                <div>
                    <h4 class="primary_heading mb-4">Em:</h4>
                    <?php PYS()->render_tags_select_input( 'advance_matching_url_em_names' ); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Data persistency -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Data persistency', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="radio-inputs-wrap">
                        <?php PYS()->render_radio_input( 'data_persistency', 'keep_data', __('Keep the data in the browser for as long as possible', 'pys') ); ?>
                        <?php PYS()->render_radio_input( 'data_persistency', 'recent_data', __('Use the most recent data', 'pys') ); ?>
                    </div>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input( 'enable_advanced_form_data_cookie' ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e( 'Store detected user data in a cookie', 'pys' ); ?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e( 'Values detected from forms, URL parameters, login and checkout are kept in the <code>pys_advanced_form_data</code> cookie on your own domain, so later events can still be matched to the same visitor. Turn this off to stop storing them; matching will then only use data available on the page itself. Declare this cookie in your privacy policy if you keep it enabled.', 'pys' ); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Reports attribution -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Reports attribution', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center number-option-block">
                        <h4 class="primary_heading"><?php _e('First Visit Options:','pys');?></h4>
                        <?php PYS()->render_number_input('cookie_duration', '', false, null, 1); ?>
                        <h4 class="primary_heading"><?php _e('day(s)','pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Define for how long we will store cookies for the "First Visit" attribution model.
                            Used for events parameters (<i>landing page, traffic source, UTMs</i>) and WooCommerce or EDD Reports.', 'pys');?>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center number-option-block">
                        <h4 class="primary_heading"><?php _e('Last Visit Options:','pys');?></h4>
                        <?php PYS()->render_number_input('last_visit_duration', '', false, null, 1); ?>
                        <h4 class="primary_heading"><?php _e('min','pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Define for how long we will store the cookies for the "Last Visit" attribution model.
                            Used for events parameters (<i>landing page, traffic source, UTMs</i>) and WooCommerce or EDD Reports.', 'pys');?>
                    </p>
                </div>
                <div>
                    <h4 class="primary_heading mb-12"><?php _e('Attribution model for events parameters:', 'pys');?></h4>
                    <div class="radio-inputs-wrap">
                        <?php PYS()->render_radio_input( 'visit_data_model', 'first_visit', __('First Visit')); ?>
                        <?php PYS()->render_radio_input( 'visit_data_model', 'last_visit', __('Last Visit')); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Disable the plugin -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Disable the plugin', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('block_robot_enabled', false); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Disable the plugin for known web crawlers', 'pys');?></h4>
                    </div>
                </div>
                <div>
                    <h4 class="primary_heading mb-4"><?php _e('Exclude these robots from blocking', 'pys');?></h4>
                    <?php PYS()->render_tags_select_input('exclude_blocked_robots',false); ?>
                    <p class="text-gray mt-4">
                        <?php _e('You can exclude robots by their user-agent. You can use either the full name or part of it.', 'pys');?>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('block_ip_enabled'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Disable the plugin for these IP addresses:', 'pys');?></h4>
                    </div>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_tags_select_input('blocked_ips',false); ?>
                    </div>
                </div>
                <div>
                    <h4 class="primary_heading mb-4"><?php _e('Ignore these user roles from tracking:', 'pys');?></h4>
                    <?php PYS()->render_multi_select_input('do_not_track_user_roles', getAvailableUserRoles()); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- User role permissions -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('User role permissions', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <h4 class="primary_heading mb-4"><?php _e('Permissions:', 'pys');?></h4>
                    <?php PYS()->render_multi_select_input('admin_permissions', getAvailableUserRoles()); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Remove parameters -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Remove parameters', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('enable_remove_source_url_params'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Remove URL parameters from <i><code>event_source_url</code></i>. Event_source_url is required
                            for Facebook CAPI events. In order to avoid sending parameters that might contain private
                            information, we recommend to keep this option ON.', 'pys');?></h4>
                    </div>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('enable_remove_target_url_param'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Remove target_url parameters.', 'pys');?></h4>
                    </div>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('enable_remove_download_url_param'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Remove download_url parameters.', 'pys');?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Caches -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Caches', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <p class="text-grey">
                        If you use site or server uses caches and you notice issues with the plugin, you can add these exceptions to "Exclude JavaScript Files" in minification or delay options:
                    </p>
                </div>
                <div>
                    <div class="example-block">
                        <label>Example:</label>
                        <pre class="copy_text">
pys-js-extra
pysOptions
wp-content/plugins/pixelyoursite-pro/dist/scripts/public.js
wp-content/plugins/pixelyoursite-pro/dist/scripts/js.cookie-2.1.3.min.js
wp-content/plugins/pixelyoursite-pro/dist/scripts/sha256.js
wp-content/plugins/pixelyoursite-pro/dist/jquery.bind-first-0.2.3.min.js

                            <div class="copy-icon" data-toggle="pys-popover"
        data-tippy-trigger="click" data-tippy-placement="bottom"
        data-popover_id="copied-popover"></div></pre>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Other stuff -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Other stuff', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('debug_enabled'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Debugging Mode. You will be able to see details about the events inside your browser console (developer tools).', 'pys');?></h4>
                    </div>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('compress_front_js'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Compress frontend js', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Compress JS files (please test all your events if you enable this option because it can create conflicts with various caches).', 'pys');?>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('hide_version_plugin_in_console'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Remove the name of the plugin from the console', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Once ON, we remove all mentions about the plugin or add-ons from the console.', 'pys');?>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input( 'track_cookie_for_subdomains' ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Track domains and subdomains together', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Enable this option if you want unified tracking for our native landing pages, traffic sources, and UTMs data. When there are different installations, this option must be enabled on both the domain and the subdomain.', 'pys');?>
                    </p>
                </div>
                <?php if ( isWooCommerceActive() ) : ?>
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input( 'woo_hide_pys_meta_from_rest_api' ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Hide PixelYourSite metadata from WooCommerce REST API', 'pys');?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('When enabled, PixelYourSite metadata (like pys_enrich_data, pys_ga_cookie, pys_fb_cookie) will be excluded from WooCommerce REST API order responses. This helps avoid JSON parsing issues with third-party integrations while keeping all tracking data visible in your WordPress Admin dashboard.', 'pys');?>
                    </p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


