<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

const HTML_WARNING  = '<i class="fa fa-exclamation-triangle text-warning" aria-hidden="true" style="color: #fa0;"></i> ';
const HTML_CRITICAL = '<i class="fa fa-exclamation-circle" aria-hidden="true" style="color: #d64d4d;"></i> ';
const TEXT_WARNING  = '[warning] ';
const TEXT_CRITICAL = '[critical] ';

/**
 * @return array
 */
function get_system_report_data( $for_download = false ) {
    global $wpdb;


    /**
     * Wordpress
     */
    
    $wordpress = array(
        'Home URL'     => get_option( 'home' ),
        'Site URL'     => get_option( 'siteurl' ),
        'WP version'   => get_bloginfo( 'version' ),
        'WP multisite' => is_multisite() ? 'Yes' : 'No',
        'Language'     => get_locale(),
    );
    
    /**
     * Server
     */

    // check php version
    if ( version_compare( phpversion(), '5.3.0', '<' ) ) {
        $version_check  = $for_download ? TEXT_CRITICAL : HTML_CRITICAL;
        $version_check .= 'Ask your hosting company to upgrade you to at least PHP 5.6.15 or newer. ';
    } elseif ( version_compare( phpversion(), '5.6.14', '<' ) ) {
        $version_check = $for_download ? TEXT_WARNING : HTML_WARNING;
        $version_check .= 'Ask your hosting company to upgrade you to at least PHP 5.6.15 or newer. ';
    } else {
        $version_check = '';
    }

    // check mb_string extension presence
    if ( extension_loaded( 'mbstring' ) ) {
        $mb_string_check = 'Yes';
    } else {
        $mb_string_check = $for_download ? TEXT_WARNING : HTML_WARNING;
        $mb_string_check .= 'No. Ask your hosting company to upgrade to enable "mbstring" extension.';
    }
    
    $server = array(
        'Server info'      => isset( $_SERVER['SERVER_SOFTWARE'] ) ? $_SERVER['SERVER_SOFTWARE'] : 'Unknown',
        'PHP version'      => phpversion() . $version_check,
        'Multibyte string' => $mb_string_check,
        'MySQL version'    => ( ! empty( $wpdb->is_mysql ) ? $wpdb->db_version() : 'Unknown' ),
    );
    
    /**
     * Plugins
     */
    
    $plugins = array();

    $conflict_plugins = array(
        'sumodiscounts/sumodiscounts.php' => array(
            'type' => 'warning',
        ),
        'imagify/imagify.php'             => array(
            'type' => 'warning',
        ),
    );
    
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    require_once( ABSPATH . 'wp-admin/includes/update.php' );
    
    if ( function_exists( 'get_plugin_updates' ) ) {
        
        // Get both site plugins and network plugins
        $active_plugins = (array) get_option( 'active_plugins', array() );
        if ( is_multisite() ) {
            $network_activated_plugins = array_keys( get_site_option( 'active_sitewide_plugins', array() ) );
            $active_plugins            = array_merge( $active_plugins, $network_activated_plugins );
        }
        
        $available_updates = get_plugin_updates();
        
        foreach ( $active_plugins as $plugin ) {

            $data  = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin );
            $name  = $data['Name'];
            $value = '';

            // check for conflicts
            if ( array_key_exists( $plugin, $conflict_plugins ) ) {

                $conflict_data = $conflict_plugins[ $plugin ];

                if ( $for_download ) {
                    $value .= $conflict_data['type'] == 'warning' ? TEXT_WARNING : TEXT_CRITICAL;
                } else {
                    $value .= $conflict_data['type'] == 'warning' ? HTML_WARNING : HTML_CRITICAL;
                }

            }

            // add plugin author name and URL
            if ( $for_download ) {
                $value .= 'by ' . $data['AuthorName'] . ' [' . esc_url_raw( $data['PluginURI'] ) . ']';
            } else {
                $value .= 'by <a class="link" href="' . esc_url_raw( $data['PluginURI'] ) . '" target="_blank">' .
                    $data['AuthorName'] . '</a> ';
            }

            // plugin version
            $value .= '[' . $data['Version'] . '] ';

            // available update version if any
            if ( array_key_exists( $plugin, $available_updates ) ) {
                $update = $available_updates[ $plugin ];
                $value .= '[Update available: ' . $update->update->new_version . '] ';
            }

            // is network activated?
            if ( $data['Network'] ) {
                $value .= '[Network] ';
            }
            
            $plugins[ $name ] = trim( $value );
            
        }
        
    }
    
    /**
     * Theme
     */
    
    $active_theme = wp_get_theme();
    
    $theme = array(
        'Name'        => $active_theme->Name,
        'Version'     => $active_theme->Version,
        'Author URL'  => esc_url_raw( $active_theme->{'Author URI'} ),
        'Child Theme' => is_child_theme() ? 'Yes' : 'No',
    );
    
    if ( is_child_theme() ) {
        
        $parent_theme = wp_get_theme( $active_theme->Template );
        
        $theme['Parent Theme Name']    = $parent_theme->Name;
        $theme['Parent Theme Version'] = $parent_theme->Version;
        $theme['Parent Author URL']    = $parent_theme->{'Author URI'};
        
    }
    
    /**
     * Server-side events queue
     *
     * Server-side events reach the platforms through the queue, and the queue is
     * drained by WP-Cron. When someone reports "events are missing" or "the
     * checkout is slow", this is the first thing to look at, so it belongs in the
     * report rather than being asked for by hand.
     */

    $queue = array();

    if ( function_exists( 'PixelYourSite\EventsQueue' ) ) {

        $health = EventsQueue()->getCronHealth();
        $stats  = EventsQueue()->getAllQueueStats();

        if ( $health['level'] === 'error' ) {
            $marker = $for_download ? TEXT_CRITICAL : HTML_CRITICAL;
        } elseif ( $health['level'] === 'warning' ) {
            $marker = $for_download ? TEXT_WARNING : HTML_WARNING;
        } else {
            $marker = '';
        }

        $notes = array();
        foreach ( $health['messages'] as $message ) {
            $notes[] = $message['text'];
        }

        $queue['Delivery health'] = $marker . ucfirst( $health['level'] )
            . ( $notes ? ' — ' . implode( ' ', $notes ) : '' );

        $queue['Queue system']              = $health['enabled'] ? 'Enabled' : 'Disabled';
        $queue['Queue our own AJAX/REST']   = PYS()->getOption( 'queue_use_for_ajax' ) ? 'Yes' : 'No';
        $queue['Processing interval']       = human_time_diff( 0, (int) $health['interval'] );

        if ( $health['next_run'] ) {
            $next_run = (int) $health['next_run'];
            $queue['Next scheduled run'] = wp_date( 'Y-m-d H:i:s', $next_run )
                . ( $next_run > time()
                    ? ' (in ' . human_time_diff( time(), $next_run ) . ')'
                    : ' (overdue by ' . human_time_diff( $next_run, time() ) . ')' );
        } else {
            $queue['Next scheduled run'] = ( $for_download ? TEXT_CRITICAL : HTML_CRITICAL ) . 'Not scheduled';
        }

        $queue['Events pending'] = (int) $health['pending']
            . ( $health['oldest_pending_age'] !== null
                ? ' (oldest waiting ' . human_time_diff( time() - (int) $health['oldest_pending_age'], time() ) . ')'
                : '' );

        $queue['Events failed']          = (int) $health['failed'];
        $queue['Events processed today'] = $stats['processed'];
        $queue['Last processed']         = $stats['last_processed'];
        $queue['Success rate']           = $stats['success_rate'] . '%';

        $cron_flags = array();
        if ( $health['disable_wp_cron'] ) {
            $cron_flags[] = 'DISABLE_WP_CRON';
        }
        if ( $health['alternate_wp_cron'] ) {
            $cron_flags[] = 'ALTERNATE_WP_CRON';
        }
        $queue['WP-Cron constants'] = $cron_flags ? implode( ', ', $cron_flags ) : 'none set';

        $queue['Limits'] = sprintf(
            'max size %d, max retries %d, pending events deleted after %d day(s)',
            (int) PYS()->getOption( 'queue_max_size', 10000 ),
            (int) PYS()->getOption( 'queue_max_retries', 3 ),
            (int) $health['cleanup_days']
        );

        // html-report.php echoes values unescaped, so anything option-derived is
        // escaped here. It is a slug, so this is a no-op for the text download.
        $queue['Add to Cart catch method'] = esc_html( (string) PYS()->getOption( 'woo_add_to_cart_catch_method' ) );
        $queue['PHP sessions']             = PYS()->getOption( 'session_disable' ) ? 'Disabled' : 'Enabled';

    } else {
        $queue['Queue system'] = 'Unavailable';
    }

    /**
     * Tracking cookies
     *
     * Without a Public Suffix List PHP waits for the front end to report the
     * accepted cookie domain; if that script never runs the wait never ends and
     * server-side `_fbp` stays off silently — hence this section. Escaping is
     * here because html-report.php echoes values raw.
     */

    $cookies = array();

    foreach ( pys_cookie_domain_diagnostics() as $label => $row ) {
        $marker = '';
        if ( $row['warn'] ) {
            $marker = $for_download ? TEXT_WARNING : HTML_WARNING;
        }
        $cookies[ $label ] = $marker . esc_html( $row['text'] );
    }

    $report = array(
        'WordPress Environment' => $wordpress,
        'Server Environment'    => $server,
        'Tracking Cookies'      => $cookies,
        'Server Events Queue'   => $queue,
        'Active Plugins'        => $plugins,
        'Theme'                 => $theme,
    );
    
    return apply_filters( 'pys_system_report', $report, $for_download );
    
}

/**
 * Process a system report download.
 */
function download_system_report() {
    
    if ( empty( $_POST['pys_action'] ) || 'download_system_report' !== $_POST['pys_action'] ) {
        return;
    }
    
    if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'pys_download_system_report_nonce' ) ) {
        return;
    }
    
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    // prepare human-readable system report
    $output      = "";
    $report_data = get_system_report_data( true );
    
    foreach ( $report_data as $section_name => $section_report ) {
        
        $output .= "\r\n";
        $output .= "### {$section_name } ###";
        $output .= "\r\n";
        $output .= "\r\n";
        
        foreach ( $section_report as $name => $value ) {
            
            $output .= "{$name}: $value";
            $output .= "\r\n";
            
        }
        
    }
    
    // send report to client browser
    ignore_user_abort( true );
    nocache_headers();
    header( 'Content-Type: text/plain; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename=pys-system-report-' . date( 'm-d-Y' ) . '.txt' );
    header( "Expires: 0" );
    echo $output;
    exit;
    
}

add_action( 'admin_init', 'PixelYourSite\download_system_report' );