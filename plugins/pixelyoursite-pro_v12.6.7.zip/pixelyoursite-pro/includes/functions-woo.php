<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

function pys_get_all_product_meta_keys(): array {
    $cache_key = 'pys_product_meta_keys';
    $cached    = get_transient( $cache_key );

    if ( $cached !== false ) {
        return $cached;
    }

    global $wpdb;

    $keys = $wpdb->get_col( "
        SELECT DISTINCT pm.meta_key
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE p.post_type IN ('product', 'product_variation')
          AND p.post_status = 'publish'
        ORDER BY pm.meta_key ASC
    " );

    $keys = is_array( $keys ) ? $keys : [];

    set_transient( $cache_key, $keys, HOUR_IN_SECONDS );

    return $keys;
}

function isWooCommerceVersionGte( $version ) {

    if ( defined( 'WC_VERSION' ) && WC_VERSION ) {
        return version_compare( WC_VERSION, $version, '>=' );
    } else if ( defined( 'WOOCOMMERCE_VERSION' ) && WOOCOMMERCE_VERSION ) {
        return version_compare( WOOCOMMERCE_VERSION, $version, '>=' );
    } else {
        return false;
    }

}

/**
 * @param \WC_Product|\WP_Post $product
 *
 * @return bool
 */
function wooProductIsType( $product, $type ) {

    if ( isWooCommerceVersionGte( '2.7' ) ) {
        return $type == $product->is_type( $type );
    } else {
        return $product->product_type == $type;
    }

}

function getWooPayPalEventName() {

    $woo_paypal_custom_event_type = PYS()->getOption( 'woo_paypal_custom_event_type' );

    if ( PYS()->getOption( 'woo_paypal_event_type' ) == 'custom' && ! empty( $woo_paypal_custom_event_type ) ) {
        return sanitizeKey( PYS()->getOption( 'woo_paypal_custom_event_type' ) );
    } else {
        return PYS()->getOption( 'woo_paypal_event_type' );
    }
}

function getWooProductPrice( $product_id, $qty = 1,$customPrice = -1 ) {

    $product = wc_get_product( $product_id );

    if( false == $product ) {
        return 0;
    }

    if($product->get_type() == "variable") {
        $prices = $product->get_variation_prices( true );
        if(empty( $prices['price'] )) {
            $productPrice = $product->get_price();
        } else {
            $productPrice = current( $prices['price'] );
        }

    } else {
        $productPrice = $product->get_price();
    }

    if($customPrice > -1 && $customPrice != "") {
        $productPrice = $customPrice;
    }


    if(PYS()->getOption( 'woo_event_value' ) === 'custom') {
        $include_tax = PYS()->getOption( 'woo_tax_option' ) == 'included' ? true : false;
        if ( $product->is_taxable() && $include_tax ) {
            $value = wc_get_price_including_tax( $product, array(
                'price' => $productPrice,
                'qty' => $qty
            ) );
        } else {
            $value = wc_get_price_excluding_tax( $product, array(
                'price' => $productPrice,
                'qty' => $qty
            ) );
        }
        return pys_round($value);
    }

    if ( $product->is_taxable()) {
        $value = wc_get_price_including_tax( $product, array(
            'price' => $productPrice,
            'qty' => $qty
        ) );
    } else {
        $value = wc_get_price_excluding_tax( $product, array(
            'price' => $productPrice,
            'qty' => $qty
        ) );
    }

    return $value;

}

    /**
 * Unit price of a single item for the Purchase event.
 *
 * The amount is taken from the order line, i.e. the amount the customer has actually paid. This
 * covers the purchased variation, coupons and discounts, per-line custom prices (Name Your Price,
 * funnel offers) and currency switchers.
 *
 * A catalog lookup by product ID must not be used here: when "Treat variable products like simple
 * products" is on, the ID is the parent one, and a variable product has no price of its own -
 * getWooProductPrice() then returns the cheapest variation price (get_variation_prices() is sorted
 * ascending), which has nothing to do with the purchased variation.
 *
 * @param \WC_Order_Item_Product|array $line       Order line item, or a single entry of $event->args['products'].
 * @param int|null                     $product_id Used for the catalog fallback only.
 *
 * @return float
 */
function getWooPurchaseItemPrice( $line, $product_id = null ) {

    $qty = null;

    if ( $line instanceof \WC_Order_Item_Product ) {
        $qty       = (float) $line->get_quantity();
        $total     = (float) $line->get_total();
        $total_tax = (float) $line->get_total_tax();
    } elseif ( is_array( $line ) && isset( $line['total'], $line['quantity'] ) ) {
        $qty       = (float) $line['quantity'];
        $total     = (float) $line['total'];
        $total_tax = isset( $line['total_tax'] ) ? (float) $line['total_tax'] : 0;
    }

    // no usable order line, keep the catalog based behavior
    if ( $qty === null || $qty <= 0 ) {
        return getWooProductPrice( $product_id );
    }

    if ( PYS()->getOption( 'woo_event_value' ) === 'custom' ) {
        $include_tax = PYS()->getOption( 'woo_tax_option' ) == 'included';
    } else {
        // getWooProductPrice() adds tax for taxable products, keep the same convention
        $include_tax = true;
    }

    if ( $include_tax ) {
        $total += $total_tax;
    }

    return pys_round( $total / $qty );
}

function getWooProductPriceToDisplay( $product_id, $qty = 1,$customPrice = -1 ) {

    if ( ! $product = wc_get_product( $product_id ) ) {
        return 0;
    }
    if($product->get_type() == "bundle") {
        $price = (float) getDefaultBundlePrice($product);//->get_bundle_price("min",true);
        return formatPriceTrimZeros($price);
    }
    if($product->get_type() == "variable") {
        $prices = $product->get_variation_prices( true );
        if(empty( $prices['price'] )) {
            $productPrice = $product->get_price();
        } else {
            $variation_id = key($prices['price']); // Getting the variation ID
            $variation = wc_get_product($variation_id); // Creating a Variation Instance

            if ($variation && is_a($variation, 'WC_Product')) { // Check if $variation is a valid product object
                $productPrice = current( $prices['price'] );
            } else {
                // Handle the case where no valid variation is found
                // For example, fallback to the parent product's price or set a default price
                $productPrice = $product->get_price(); // Fallback to the parent product's price
            }
        }

    } else {
        $productPrice = $product->get_price();
    }
    if($customPrice > -1 && $customPrice != "") {
        $productPrice = $customPrice;
    }



    return formatPriceTrimZeros(wc_get_price_to_display( $product, array( 'qty' => $qty,'price'=>$productPrice ) ) );
}

function getWooBundleProductCartPrice( $cart_item ) {

    $price = $cart_item['line_subtotal'];

    if ( ! isWooCartAvailable() || empty( $cart_item['bundled_items'] ) || ! is_array( $cart_item['bundled_items'] ) ) {
        return $price;
    }

    foreach ($cart_item['bundled_items'] as $has) {
        $bundled_cart_item = WC()->cart->get_cart_item($has);
        if ( ! is_array( $bundled_cart_item ) || ! isset( $bundled_cart_item["line_subtotal"] ) ) continue;
        $price += $bundled_cart_item["line_subtotal"];
    }

    return $price;
}


/**
 * @param \WC_Product_Bundle $product
 */
function getDefaultBundlePrice($product) {
    $qty = 1;
    $price_prop = "price";
    $price_calc = 'display';
    $strict = false;
    $min_or_max = "min";
    if($product->contains( 'priced_individually' )) {

        $price_fn = 'get_' . $price_prop;
        $price    = wc_format_decimal( \WC_PB_Product_Prices::get_product_price( $product, array(
            'price' => $product->$price_fn(),
            'qty'   => $qty,
            'calc'  => $price_calc,
        ) ), wc_get_price_decimals() );

        $bundled_items = $product->get_bundled_items();

        if ( ! empty( $bundled_items ) ) {
            foreach ( $bundled_items as $bundled_item ) {

                if ( false === $bundled_item->is_purchasable() ) {
                    continue;
                }

                if ( false === $bundled_item->is_priced_individually() ) {
                    continue;
                }

                if($bundled_item->is_optional()) {
                    continue;
                }

                $bundled_item_qty = $qty * $bundled_item->get_quantity( "default", array( 'context' => 'price', 'check_optional' => $min_or_max === 'min' ) );

                if ( $bundled_item_qty ) {

                    $price += wc_format_decimal( $bundled_item->calculate_price( array(
                        'min_or_max' => $min_or_max,
                        'qty'        => $bundled_item_qty,
                        'strict'     => $strict,
                        'calc'       => $price_calc,
                        'prop'       => $price_prop
                    ) ), wc_get_price_decimals() );
                }
            }
        }

    } else {
        $price_fn = 'get_' . $price_prop;
        $price    = \WC_PB_Product_Prices::get_product_price( $product, array(
            'price' => $product->$price_fn(),
            'qty'   => $qty,
            'calc'  => $price_calc,
        ) );


    }

    return $price;
}

/**
 * @param SingleEvent $event
 */
function getWooEventCartSubtotal($event) {
    $subTotal = 0;
    $include_tax = get_option( 'woocommerce_tax_display_cart' ) == 'incl';
    if ( WC()->cart ) {
        $subTotal = WC()->cart->get_subtotal(); // Total cost of goods excluding taxes and discounts
        $subtotal_tax = WC()->cart->get_subtotal_tax(); // Tax on the amount of goods

        if($include_tax) {
            $subTotal += $subtotal_tax;
        }
    }
    return pys_round($subTotal);
}

/**
 * @param SingleEvent $event
 */
function getWooEventCartTotal($event) {

    return getWooEventCartSubtotal($event);
}
/**
 * @param SingleEvent $event
 */
function getWooEventOrderTotal( $event ) {

    if(!$event->args['order_id']) return 0;

    // Check if AWCDP order is passed in args (for partial payments)
    if (isset($event->args['awcdp_order']) && $event->args['awcdp_order'] instanceof \AWCDP_Order) {
        $order = $event->args['awcdp_order'];
    } else {
        $order = wc_get_order($event->args['order_id']);
    }

    if (!$order) {
        return 0;
    }

    if(PYS()->getOption( 'woo_event_value' ) != 'custom') {
        $total = $order->get_total();
        return pys_round($total);
    }

    $include_tax = PYS()->getOption( 'woo_tax_option' ) == 'included' ? true : false;
    $include_shipping = PYS()->getOption( 'woo_shipping_option' ) == 'included' ? true : false;
    $include_fees = PYS()->getOption( 'woo_fees_option' ) == 'included' ? true : false;


    $total = 0;
    foreach ($order->get_items() as $item_id => $item) {
        $line_total = $item->get_total(); // Total cost
        if ($include_tax) {
            $line_total += $item->get_total_tax(); // Add tax if included
        }
        $total += $line_total;
    }

    if ($include_shipping) {
        $total += $order->get_shipping_total(); // Shipping cost
        if ($include_tax) {
            $total += $order->get_shipping_tax(); // Shipping tax
        }
    }

    if ($include_fees) {
        foreach ($order->get_fees() as $fee) {
            $total += $fee->get_total();
        }
    }
    return pys_round($total );

}

function getWooCartSubtotal() {
    if ( ! isWooCartAvailable() ) return 0;

    WC()->cart->calculate_totals();
    // subtotal is always same value on front-end and depends on PYS options
    $include_tax = get_option( 'woocommerce_tax_display_cart' ) == 'incl';

    if ( $include_tax ) {

        if ( isWooCommerceVersionGte( '3.2.0' ) ) {
            $subtotal = (float) WC()->cart->get_subtotal() + (float) WC()->cart->get_subtotal_tax();
        } else {
            $subtotal = WC()->cart->subtotal;
        }

    } else {

        if ( isWooCommerceVersionGte( '3.2.0' ) ) {
            $subtotal = (float) WC()->cart->get_subtotal();
        } else {
            $subtotal = WC()->cart->subtotal_ex_tax;
        }

    }

    return $subtotal;
}

function getWooCartTotal() {

    if ( ! isWooCartAvailable() ) return 0;

    $include_tax = PYS()->getOption( 'woo_tax_option' ) == 'included' ? true : false;

    if ( $include_tax ) {
        $total = WC()->cart->cart_contents_total + WC()->cart->tax_total;
    } else {
        $total = WC()->cart->cart_contents_total;
    }

    return $total;

}

/**
 * @param \WC_Order $order
 *
 * @return string
 */
function getWooOrderTotal( $order ) {

    $include_tax = PYS()->getOption( 'woo_tax_option' ) == 'included' ? true : false;
    $include_shipping = PYS()->getOption( 'woo_shipping_option' ) == 'included' ? true : false;
    $include_fees = PYS()->getOption( 'woo_fees_option' ) == 'included' ? true : false;

    if ($include_shipping && $include_tax && $include_fees) {

        $total = $order->get_total();   // full order price

    } elseif ( ! $include_shipping && ! $include_tax ) {

        $cart_subtotal  = $order->get_subtotal();

        if ( isWooCommerceVersionGte( '2.7' ) ) {
            $discount_total = (float) $order->get_discount_total( 'edit' );
        } else {
            $discount_total = $order->get_total_discount();
        }

        $total = $cart_subtotal - $discount_total;

    } elseif ( ! $include_shipping && $include_tax ) {

        if ( isWooCommerceVersionGte( '2.7' ) ) {
            $cart_total     = (float) $order->get_total( 'edit' );
            $shipping_total = (float) $order->get_shipping_total( 'edit' );
            $shipping_tax   = (float) $order->get_shipping_tax( 'edit' );
        } else {
            $cart_total     = $order->get_total();
            $shipping_total = $order->get_total_shipping();
            $shipping_tax   = $order->get_shipping_tax();
        }

        $total = $cart_total - $shipping_total - $shipping_tax;

    } else {
        // $include_shipping && !$include_tax

        $cart_subtotal  = $order->get_subtotal();

        if ( isWooCommerceVersionGte( '2.7' ) ) {
            $discount_total = (float) $order->get_discount_total( 'edit' );
            $shipping_total = (float) $order->get_shipping_total( 'edit' );
        } else {
            $discount_total = $order->get_total_discount();
            $shipping_total = $order->get_total_shipping();
        }

        $total = $cart_subtotal - $discount_total + $shipping_total;

    }

    if(!$include_fees){
        $fees = $order->get_fees();
        $fee_amount = 0;

        foreach ($fees as $fee) {
            $fee_amount += $fee->get_total();
        }
        if($fee_amount > 0){
            $total = $total - $fee_amount;
        }
    }
    //wc_get_price_thousand_separator is ignored
    return number_format( $total, wc_get_price_decimals(), '.', '' );

}

/**
 * @deprecated use getWooProductValue
 * @param String $valueOption
 * @param float $global
 * @param float $percent
 * @param int $product_id
 * @param int $qty
 * @return false|float|int
 */

function getWooEventValue( $valueOption, $global, $percent, $product_id,$qty ) {
    return getWooProductValue([
        'valueOption' => $valueOption,
        'global' => $global,
        'percent' => $percent,
        'product_id' => $product_id,
        'qty' => $qty
    ]);
}

function getWooProductValue($args) {
    $valueOption = $args['valueOption'];
    $global = $args['global'];
    $percent = $args['percent'];
    $product_id = $args['product_id'];
    $qty = $args['qty'];


    $product = wc_get_product($product_id);
    if(!$product) return 0;

    $productPrice = "";

    if(!empty($args['price'])) {
        $productPrice = $args['price'];
    }
    // for cartflow product sale
    $salePrice = getWfcProductSalePrice($product,$args);
    if($salePrice > -1 ) {
        $productPrice = $salePrice;
    }



    if ( $valueOption == 'cog' && pys_cog_source_is_available() ) {
        return pys_cog_get_product_profit( $product, $qty, $productPrice );
    }

    if ( PYS()->getOption( 'woo_event_value' ) == 'custom' ) {
        $amount = getWooProductPrice( $product_id, $qty,$productPrice );
    } else {
        $amount = getWooProductPriceToDisplay( $product_id, $qty,$productPrice );
    }

    switch ( $valueOption ) {
        case 'global': $value = $global; break;
        case 'percent':
            $percents = (float) $percent;
            $percents = str_replace( '%', null, $percents );
            $percents = (float) $percents / 100;
            $value    = (float) $amount * $percents;
            break;
        default:$value = (float)$amount;
    }
    return formatPriceTrimZeros($value);
}

function getWcfEventValueOrder( $valueOption, $wcf_offer_step_id, $global, $percent ,$quantity) {

    $wcf_product = getWcfOfferProduct($wcf_offer_step_id);
    $product = wc_get_product($wcf_product['product']);
    $price = getWfcProductSalePrice($product,$wcf_product);
    $offer_shipping_fee = wcf_get_offer_shipping($wcf_offer_step_id);

    if($price < 0) {
        $price = $product->get_price();
    }


    if ( PYS()->getOption( 'woo_event_value' ) == 'custom' ) {
        $include_tax = PYS()->getOption( 'woo_tax_option' ) == 'included' ? true : false;
        $include_shipping = PYS()->getOption( 'woo_shipping_option' ) == 'included' ? true : false;

        if($include_shipping) {
            $amount = $price * $quantity + $offer_shipping_fee;
        } else {
            $amount = $price * $quantity;
        }
    } else {
        $amount = $price * $quantity;
    }

    switch ( $valueOption ) {
        case 'global':
            $value = (float) $global;
            break;

        case 'cog':
            // Use shared helper — works for both 'pixel_cog' and 'wc_cog' sources
            if ( pys_cog_source_is_available() ) {
                $cog_value = pys_cog_get_product_profit( $product, $quantity, $price );
                $value     = ( $cog_value !== '' ) ? (float) round( $cog_value, 2 ) : (float) $amount;
            } else {
                $value = (float) $amount;
            }
            break;

        case 'percent':
            $percents = (float) $percent;
            $percents = str_replace( '%', null, $percents );
            $percents = (float) $percents / 100;
            $value    = (float) $amount * $percents;
            break;

        default:    // "price" option
            $value = (float) $amount;
    }

    return $value;
}

/**
 * @param string $valueOption  'global' | 'cog' | 'percent' | default = price
 * @param float  $global       Fixed global value
 * @param string $percent      Percent 0–100
 * @param float  $total        Order subtotal (price fallback)
 * @param array  $args         Event args with 'products' key
 */
function getWooEventValueProducts( $valueOption, $global, $percent, $total, $args ) {

    if ( $valueOption == 'global' ) return $global;

    if ( $valueOption == 'percent' ) {
        $percents = (float) str_replace( '%', null, (float) $percent ) / 100;
        return (float) $total * $percents;
    }

    if ( $valueOption == 'cog' && pys_cog_source_is_available() ) {
        // For order-level events: use the order profit helper (handles both sources)
        // $args contains 'products' array built from the order items
        $cog_value = getAvailableProductCogOrder( $args );
        if ( $cog_value !== '' && is_numeric( $cog_value ) ) {
            return (float) round( $cog_value, 2 );
        }
    }

    return formatPriceTrimZeros( $total );
}
/**
 * @deprecated
 * @param  $valueOption
 * @param \WC_Order $order
 * @param $global
 * @param $order_id
 * @param $content_ids
 * @param int $percent
 * @return float|int
 */
function getWooEventValueOrder( $valueOption, $order, $global, $percent = 100 ) {

    if ( PYS()->getOption( 'woo_event_value' ) == 'custom' ) {
        $amount = getWooOrderTotal( $order );
    } else {
        $amount = $order->get_total();
    }
    switch ( $valueOption ) {
        case 'global':
            $value = (float) $global;
            break;

        case 'cog':
            // Use the pre-calculated profit stored by the COG plugin on the order meta.
            // Avoids calling getAvailableProductCogOrder() with a wrong type (int vs array).
            if ( isPixelCogActive() ) {
                $profit = $order->get_meta( '_pixel_cost_of_goods_order_profit', true );
                $value  = ( $profit !== '' && $profit !== false ) ? (float) round( $profit, 2 ) : (float) $amount;
            } else {
                $value = (float) $amount;
            }
            break;

        case 'percent':
            $percents = (float) $percent;
            $percents = str_replace( '%', null, $percents );
            $percents = (float) $percents / 100;
            $value    = (float) $amount * $percents;
            break;

        default:    // "price" option
            $value = (float) $amount;
    }

    return formatPriceTrimZeros($value);

}


/**
 * @deprecated
 * @param $valueOption
 * @param $global
 * @param int $percent
 * @return bool|float|int|mixed|string|\WC_Tax
 */
function getWooEventValueCart( $valueOption, $global, $percent = 100 ) {

    if ( ! isWooCartAvailable() ) return 0;

    if ( $valueOption == 'cog' && pys_cog_source_is_available() ) {
        // getAvailableProductCogCart() now handles both 'pixel_cog' and 'wc_cog' sources
        $cog_value = getAvailableProductCogCart();
        if ( $cog_value !== '' && is_numeric( $cog_value ) ) {
            return (float) round( $cog_value, 2 );
        }
        if ( get_option( '_pixel_cog_tax_calculating' ) == 'no' ) {
            return WC()->cart->cart_contents_total;
        }
        return WC()->cart->cart_contents_total + WC()->cart->tax_total;
    }


    if ( PYS()->getOption( 'woo_event_value' ) == 'custom' ) {
        $amount = getWooCartTotal();
    } else {
        $amount = $params['value'] = WC()->cart->subtotal;
    }

    switch ( $valueOption ) {
        case 'global':
            $value = (float) $global;
            break;

        case 'percent':
            $percents = (float) $percent;
            $percents = str_replace( '%', null, $percents );
            $percents = (float) $percents / 100;
            $value    = (float) $amount * $percents;
            break;

        default:    // "price" option
            $value = (float) $amount;
    }

    return formatPriceTrimZeros($value);
}

/**
 * Order statuses counted in the customer-value params: predicted_ltv,
 * average_order and transactions_count.
 *
 * Deliberately separate from woo_ltv_order_statuses, which belongs to the
 * audiences CSV export only.
 *
 * @return array statuses with the "wc-" prefix, never empty
 */
function getWooCustomerValueStatuses() {

    $defaults = array( 'wc-processing', 'wc-completed' );

    $statuses = PYS()->getOption( 'woo_customer_value_order_statuses', array() );
    $statuses = is_array( $statuses ) ? array_filter( $statuses ) : array();

    if ( empty( $statuses ) ) {
        // all statuses cleared in the UI: keep the historical behavior
        $statuses = $defaults;
    }

    /**
     * Filter the order statuses counted in predicted_ltv, average_order and
     * transactions_count. Useful for statuses that are not registered with
     * WooCommerce and so never show up in the settings multi select.
     *
     * @param array $statuses Statuses with the "wc-" prefix.
     */
    $statuses = apply_filters( 'pys_woo_customer_value_order_statuses', array_values( array_unique( $statuses ) ) );
    $statuses = is_array( $statuses ) ? array_filter( $statuses ) : array();

    // the multi select stores "wc-completed", a hand-written filter may pass "completed"
    $statuses = array_map( function ( $status ) {
        return strpos( $status, 'wc-' ) === 0 ? $status : 'wc-' . $status;
    }, $statuses );

    // drafts and trashed orders are never a customer value, whatever the filter says
    // ("trash" is normalized to "wc-trash" above)
    $statuses = array_values( array_diff( array_unique( $statuses ), array( 'wc-checkout-draft', 'wc-trash' ) ) );

    return empty( $statuses ) ? $defaults : $statuses;
}

/**
 * Zeroed customer totals, used whenever there is nothing to count. Keeps the
 * return type of the customer-value helpers stable.
 *
 * @return array
 */
function getWooEmptyCustomerTotals() {
    return array( 'orders_count' => 0, 'avg_order_value' => 0, 'ltv' => 0 );
}

function getWooUserStat($orderId = 0) {

    $customerId = getCustomerIdFromOrder($orderId);
    $customerEmail = getCustomerEmailFromOrder($orderId);

    return getUserPurchaseData($customerId, $customerEmail, $orderId);
}

function getCustomerEmailFromOrder($orderId)
{
    global $wpdb;
    $orderTable = isWooUseHPStorage() ? $wpdb->prefix . "wc_orders" : $wpdb->postmeta;
    $selectClause = isWooUseHPStorage() ? "SELECT billing_email FROM $orderTable WHERE id = %d" : "SELECT meta_value FROM $orderTable WHERE post_id = %d AND meta_key = '_billing_email'";

    return $wpdb->get_var($wpdb->prepare($selectClause, $orderId));
}
function getCustomerIdFromOrder($orderId) {
    global $wpdb;
    $orderTable = isWooUseHPStorage() ? $wpdb->prefix . "wc_orders" : $wpdb->postmeta;
    $selectClause = isWooUseHPStorage() ? "SELECT customer_id FROM $orderTable WHERE id = %d" : "SELECT meta_value FROM $orderTable WHERE post_id = %d AND meta_key = '_customer_user'";

    return $wpdb->get_var($wpdb->prepare($selectClause, $orderId));
}
/**
 * Customer totals used by predicted_ltv, average_order and transactions_count.
 *
 * The customer is matched by user id OR billing email, and the status filter
 * applies to both branches. The order that triggered the event is always
 * counted, whatever its status, so a Purchase can never report zero
 * transactions.
 *
 * @param int|null    $userId
 * @param string|null $userEmail
 * @param int         $currentOrderId Order that triggered the event, 0 for none.
 *
 * @return array orders_count, avg_order_value, ltv
 */
function getUserPurchaseData($userId = null, $userEmail = null, $currentOrderId = 0) {
    global $wpdb;

    $userId         = (int) $userId;
    $userEmail      = is_string( $userEmail ) ? trim( $userEmail ) : '';
    $currentOrderId = (int) $currentOrderId;

    if ( ! $userId && $userEmail === '' ) {
        return getWooEmptyCustomerTotals();
    }

    /**
     * Filter whether the order that triggered the event is counted even when
     * its status is not selected in the settings.
     *
     * @param bool $include
     * @param int  $currentOrderId
     */
    if ( $currentOrderId > 0 && ! apply_filters( 'pys_woo_customer_value_include_current_order', true, $currentOrderId ) ) {
        $currentOrderId = 0;
    }

    if ( ! isWooUseHPStorage() ) {
        return getLegacyUserPurchaseData( $userId, $userEmail, $currentOrderId );
    }

    $statuses = getWooCustomerValueStatuses();

    // customer matching: id OR email, grouped so the status filter applies to both
    $match  = array();
    $params = array();

    if ( $userId ) {
        $match[]  = 'o.customer_id = %d';
        $params[] = $userId;
    }

    if ( $userEmail !== '' ) {
        $match[]  = 'o.billing_email = %s';
        $params[] = $userEmail;
    }

    $statusPlaceholders = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );
    $params             = array_merge( $params, $statuses );

    $currentOrderSql = '';
    if ( $currentOrderId > 0 ) {
        $currentOrderSql = ' OR o.id = %d';
        $params[]        = $currentOrderId;
    }

    // type filter: wc_orders also holds subscriptions and refund records
    $query = $wpdb->prepare(
        "SELECT SUM(o.total_amount) AS ltv,
                AVG(o.total_amount) AS avg_order_value,
                COUNT(o.id)         AS orders_count
         FROM {$wpdb->prefix}wc_orders AS o
         WHERE o.type = 'shop_order'
           AND ( " . implode( ' OR ', $match ) . " )
           AND ( o.status IN ({$statusPlaceholders}){$currentOrderSql} )",
        $params
    );

    $result = $wpdb->get_row( $query );

    if ( ! $result || ! $result->orders_count ) {
        return getWooEmptyCustomerTotals();
    }

    return array(
        'orders_count'    => (int) $result->orders_count,
        'avg_order_value' => round( (float) $result->avg_order_value, 2 ),
        'ltv'             => round( (float) $result->ltv, 2 ),
    );
}

/**
 * Same as getUserPurchaseData(), for stores still on the posts table.
 *
 * @param int    $userId
 * @param string $userEmail
 * @param int    $currentOrderId
 *
 * @return array
 */
function getLegacyUserPurchaseData($userId, $userEmail, $currentOrderId = 0) {
    global $wpdb;

    $userId         = (int) $userId;
    $userEmail      = is_string( $userEmail ) ? trim( $userEmail ) : '';
    $currentOrderId = (int) $currentOrderId;

    if ( ! $userId && $userEmail === '' ) {
        return getWooEmptyCustomerTotals();
    }

    $statuses = getWooCustomerValueStatuses();

    $match  = array();
    $params = array();

    if ( $userId ) {
        $match[]  = "( pm.meta_key = '_customer_user' AND pm.meta_value = %d )";
        $params[] = $userId;
    }

    if ( $userEmail !== '' ) {
        $match[]  = "( pm.meta_key = '_billing_email' AND pm.meta_value = %s )";
        $params[] = $userEmail;
    }

    $statusPlaceholders = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );
    $params             = array_merge( $params, $statuses );

    $currentOrderSql = '';
    if ( $currentOrderId > 0 ) {
        $currentOrderSql = ' OR o.ID = %d';
        $params[]        = $currentOrderId;
    }

    $query = $wpdb->prepare(
        "SELECT DISTINCT o.ID
         FROM {$wpdb->posts} AS o
         JOIN {$wpdb->postmeta} AS pm ON pm.post_id = o.ID
         WHERE ( " . implode( ' OR ', $match ) . " )
           AND o.post_type = 'shop_order'
           AND ( o.post_status IN ({$statusPlaceholders}){$currentOrderSql} )",
        $params
    );

    $order_ids = $wpdb->get_col( $query );

    if ( empty( $order_ids ) ) {
        return getWooEmptyCustomerTotals();
    }

    // sum the raw order totals, like the HPOS branch does with total_amount
    $idPlaceholders = implode( ', ', array_fill( 0, count( $order_ids ), '%d' ) );

    $totals = $wpdb->get_row( $wpdb->prepare(
        "SELECT SUM(meta_value) AS ltv,
                AVG(meta_value) AS avg_order_value,
                COUNT(meta_value) AS orders_count
         FROM {$wpdb->postmeta}
         WHERE meta_key = '_order_total'
           AND post_id IN ({$idPlaceholders})",
        $order_ids
    ) );

    if ( ! $totals || ! $totals->orders_count ) {
        return getWooEmptyCustomerTotals();
    }

    return array(
        'orders_count'    => (int) $totals->orders_count,
        'avg_order_value' => round( (float) $totals->avg_order_value, 2 ),
        'ltv'             => round( (float) $totals->ltv, 2 ),
    );
}

/**
 * @param int      $user_id
 * @param int|null $order_id            Order the totals are requested for.
 * @param bool     $includeCurrentOrder Count $order_id whatever its status.
 *
 * @return array
 */
function getWooCustomerTotals($user_id = 0, $order_id = null, $includeCurrentOrder = true) {

    $customerEmail = $order_id !== null ? getCustomerEmailFromOrder($order_id) : null;
    $user_id = $order_id !== null ? getCustomerIdFromOrder($order_id) : ($user_id == 0 && is_user_logged_in() ? get_current_user_id() : $user_id);

    if (empty($order_id) && empty($user_id)) {
        return getWooEmptyCustomerTotals();
    }

    $currentOrderId = $includeCurrentOrder ? (int) $order_id : 0;

    return getUserPurchaseData($user_id, $customerEmail, $currentOrderId);
}
function wooMapOrderId($orderId) {
    return PYS()->getOption("woo_order_id_prefix").$orderId;
}


function getWooCustomAudiencesFromOldTable($order_statues) {
    global $wpdb;
    $csv_data = [];
    $order_statues_placeholders = implode( ', ', array_fill( 0, count( $order_statues ), '%s' ) );
    // collect all unique customers by email
    $query = $wpdb->prepare( "
        SELECT  postmeta.meta_value AS email, postmeta.post_id
        FROM    $wpdb->postmeta AS postmeta
        WHERE   postmeta.meta_key = '_billing_email'
                AND postmeta.post_id IN (
                    SELECT ID FROM $wpdb->posts 
                    WHERE post_type = 'shop_order'
                    AND post_status IN ({$order_statues_placeholders})
                )
    ", $order_statues );

    $results = $wpdb->get_results( $query );

    $customers = array();

    // format data as email => [ order_ids ]
    foreach ( $results as $row ) {

        $order_ids   = isset( $customers[ $row->email ] ) ? $customers[ $row->email ] : array();
        $order_ids[] = (int) $row->post_id;

        $customers[ $row->email ] = $order_ids;

    }

    @ini_set( 'max_execution_time', 180 );

    // collect data per each customer
    foreach ( $customers as $email => $order_ids ) {

        $order_ids_placeholders = implode( ',', array_fill( 0, count( $order_ids ), '%d' ) );

        // calculate customer LTV
        $query = $wpdb->prepare( "
            SELECT  SUM( meta_value )
            FROM    $wpdb->postmeta
            WHERE   post_id IN ( {$order_ids_placeholders} )
                    AND meta_key = '_order_total'
        ", $order_ids );

        $customer_ltv = $wpdb->get_col( $query );

        // query customer data from last order
        $query = $wpdb->prepare( "
            SELECT  meta_key, meta_value
            FROM    $wpdb->postmeta
            WHERE   post_id = %d
                    AND meta_key IN ( '_billing_first_name', '_billing_last_name', '_billing_city', '_billing_state',
                    '_billing_postcode', '_billing_country', '_billing_phone' )
        ", end( $order_ids ) );

        $results = $wpdb->get_results( $query );

        $customer_meta          = wp_list_pluck( $results, 'meta_value', 'meta_key' );
        $customer_meta['ltv']   = (float) $customer_ltv[0];
        $customer_meta['email'] = $email;

        $csv_data[] = $customer_meta;

    }

    return $csv_data;

}

function getWooCustomAudiencesFromHP($order_statues) {
    global $wpdb;
    $csv_data = [];
    $orderTable = $wpdb->prefix."wc_orders";
    $addressTable = $wpdb->prefix."wc_order_addresses";
    $order_statues_placeholders = implode( ', ', array_fill( 0, count( $order_statues ), '%s' ) );
    // collect all unique customers by email
    $query = $wpdb->prepare( "
        SELECT  t1.billing_email as email,
                SUM(t1.total_amount) as ltv, 
                t3.first_name as _billing_first_name,
                t3.last_name as _billing_last_name, 
                t3.city as _billing_city,
                t3.state as _billing_state,
                t3.postcode as _billing_postcode,
                t3.country as _billing_country,
                t3.phone as _billing_phone 
        FROM $orderTable as t1 
            LEFT JOIN (SELECT billing_email, MAX(id) last_id FROM $orderTable GROUP BY billing_email) t2 
                ON t1.billing_email = t2.billing_email 
            LEFT JOIN $addressTable as t3 
                ON t3.order_id = t2.last_id AND t3.address_type = 'billing' 
        WHERE   status IN ({$order_statues_placeholders})
        GROUP BY t1.billing_email
        
    ", $order_statues );

    return $wpdb->get_results( $query,ARRAY_A  );
}

function wooExportCustomAudiences() {
    global $wpdb;

    ob_clean();

    $order_statues = PYS()->getOption( 'woo_ltv_order_statuses', array() );

    if ( empty( $order_statues ) ) {
        $order_statues = array_keys( wc_get_order_statuses() );
    }
    if(isWooUseHPStorage()) {
        $csv_data = getWooCustomAudiencesFromHP($order_statues);
    } else {
        $csv_data = getWooCustomAudiencesFromOldTable($order_statues);
    }




    // generate file name
    $site_name = site_url();
    $site_name = str_replace( array( 'http://', 'https://' ), '', $site_name );
    $site_name = strtolower( preg_replace( "/[^A-Za-z]/", '_', $site_name ) );
    $file_name = date('Ymd') . '_' . $site_name . '_woo_customers.csv';
    // output CSV
    header( 'Content-Type: text/csv; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename=' . $file_name );

    $output = fopen( 'php://output', 'w' );

    // headings
    fputcsv( $output, array( 'email', 'phone', 'fn', 'ln', 'ct', 'st', 'country', 'zip', 'value' ) );

    // rows
    foreach ( $csv_data as $row ) {

        fputcsv( $output, array(
            $row['email'],
            isset( $row['_billing_phone'] ) ? $row['_billing_phone'] : '',
            isset( $row['_billing_first_name'] ) ? $row['_billing_first_name'] : '',
            isset( $row['_billing_last_name'] ) ? $row['_billing_last_name'] : '',
            isset( $row['_billing_city'] ) ? $row['_billing_city'] : '',
            isset( $row['_billing_state'] ) ? $row['_billing_state'] : '',
            isset( $row['_billing_country'] ) ? $row['_billing_country'] : '',
            isset( $row['_billing_postcode'] ) ? $row['_billing_postcode'] : '',
            $row['ltv']
        ) );

    }

    exit;

}

/*
 * -----------------------------------------------------------------------------
 * Order-received access control
 * -----------------------------------------------------------------------------
 * WooCommerce resolves the order-received endpoint from the URL path and then
 * validates the order key before it renders any order detail; on a key mismatch
 * it deliberately renders an empty thank-you page so order IDs cannot be probed.
 *
 * The plugin used to resolve the order from the same URL without ever comparing
 * the key, so any visitor could read the tracking payload — and the Facebook
 * Advanced Matching block, which carries the buyer's email, phone, name and
 * address — for any order ID. Every request-to-order-ID conversion now goes
 * through wooGetOrderIdFromRequest(), which refuses to return an ID the visitor
 * is not allowed to see.
 */

/**
 * Order key submitted with the current request, with its case preserved.
 *
 * Order keys are `wc_order_` . wp_generate_password( 13, false ) — mixed case —
 * so sanitize_key() must NOT be used here: it lowercases, and hash_equals()
 * would then fail for virtually every real order.
 *
 * @return string Empty string when the request carries no key.
 */
function pysWooGetSubmittedOrderKey() {

    foreach ( array( 'key', 'order_key' ) as $param ) {
        if ( isset( $_REQUEST[ $param ] ) && is_string( $_REQUEST[ $param ] ) && '' !== $_REQUEST[ $param ] ) {
            return sanitize_text_field( wp_unslash( $_REQUEST[ $param ] ) );
        }
    }

    return '';

}

/**
 * Order IDs created during this visitor's session.
 *
 * Read from the WooCommerce session and from our own signed cookie, because
 * neither survives every flow on its own: WC_Order::payment_complete() and
 * WC_Shortcode_Checkout::order_received() both reset the WooCommerce session
 * pointers before the thank-you page renders.
 *
 * @return int[]
 */
function pysWooGetSessionOrderIds() {

    $ids = array();

    if ( function_exists( 'WC' ) && isset( WC()->session ) && WC()->session ) {
        $stored = WC()->session->get( 'pys_session_orders' );
        if ( is_array( $stored ) ) {
            $ids = $stored;
        }
    }

    if ( ! empty( $_COOKIE['pys_woo_orders'] ) ) {
        $ids = array_merge( $ids, pysWooParseSessionOrdersCookie( wp_unslash( $_COOKIE['pys_woo_orders'] ) ) );
    }

    return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );

}

/**
 * @param string $raw Raw cookie value, "1,2,3|<hmac>".
 * @return int[]
 */
function pysWooParseSessionOrdersCookie( $raw ) {

    if ( ! is_string( $raw ) || false === strpos( $raw, '|' ) ) {
        return array();
    }

    list( $payload, $signature ) = explode( '|', $raw, 2 );

    if ( ! hash_equals( hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) ), $signature ) ) {
        return array();
    }

    return array_filter( array_map( 'absint', explode( ',', $payload ) ) );

}

/**
 * Remember that this visitor created this order, so the purchase event still
 * fires when the payment gateway returns them without the order key.
 *
 * @param int $order_id
 */
function pysWooRecordSessionOrder( $order_id ) {

    $order_id = absint( $order_id );

    if ( ! $order_id ) {
        return;
    }

    $ids = pysWooGetSessionOrderIds();

    if ( in_array( $order_id, $ids, true ) ) {
        return;
    }

    $ids[] = $order_id;

    if ( count( $ids ) > 10 ) {
        $ids = array_slice( $ids, - 10 );
    }

    if ( function_exists( 'WC' ) && isset( WC()->session ) && WC()->session ) {
        WC()->session->set( 'pys_session_orders', $ids );
    }

    pysWooSetSessionOrdersCookie( $ids );

    pysWooAccessCacheEpoch( true );

}

/**
 * Cache generation for pysWooRequestCanAccessOrder(), bumped whenever the set of
 * orders this visitor is known to own changes within the same request.
 *
 * @param bool $bump
 * @return int
 */
function pysWooAccessCacheEpoch( $bump = false ) {

    static $epoch = 0;

    if ( $bump ) {
        $epoch ++;
    }

    return $epoch;

}

/**
 * @param int[] $ids
 */
function pysWooSetSessionOrdersCookie( $ids ) {

    $payload = implode( ',', array_map( 'absint', $ids ) );
    $value   = $payload . '|' . hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );

    // keep it readable within the current request as well
    $_COOKIE['pys_woo_orders'] = $value;

    if ( headers_sent() ) {
        return;
    }

    $expires = time() + 2 * HOUR_IN_SECONDS;
    $path    = defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/';
    $domain  = defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '';
    $secure  = is_ssl();

    /*
     * Gateways that return the buyer with a cross-site POST (some PayU and LATAM
     * integrations) do not send SameSite=Lax cookies. SameSite=None requires
     * Secure, so plain HTTP falls back to Lax and relies on the order key.
     */
    $samesite = $secure ? 'None' : 'Lax';

    setcookie( 'pys_woo_orders', $value, array(
        'expires'  => $expires,
        'path'     => $path,
        'domain'   => $domain,
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => $samesite,
    ) );

}

/**
 * @param int $order_id
 * @return bool
 */
function pysWooSessionHasOrder( $order_id ) {
    return in_array( absint( $order_id ), pysWooGetSessionOrderIds(), true );
}

/**
 * Opt-in fallback for gateways that return the buyer without the order key AND
 * outside of their original session (a cross-site POST drops the session
 * cookie). Disabled by default:
 *
 *     add_filter( 'pys_woo_legacy_gateway_compat', '__return_true' );
 *
 * Even when enabled it only covers orders created within the last hour that
 * actually went through, and it never unlocks personal data.
 *
 * @param \WC_Order $order
 * @return bool
 */
function pysWooLegacyGatewayCompatAllows( $order ) {

    if ( ! apply_filters( 'pys_woo_legacy_gateway_compat', false ) ) {
        return false;
    }

    $created = $order->get_date_created();

    if ( ! $created ) {
        return false;
    }

    $window = (int) apply_filters( 'pys_woo_legacy_gateway_compat_window', HOUR_IN_SECONDS );

    if ( ( time() - $created->getTimestamp() ) > $window ) {
        return false;
    }

    // same form the rest of the plugin compares against, e.g. getPurchaseOrderId()
    $status = 'wc-' . $order->get_status( 'edit' );

    // never a customer-facing order, whatever the site is configured to track
    if ( in_array( $status, array( 'wc-trash', 'wc-draft', 'wc-auto-draft' ), true ) ) {
        return false;
    }

    /*
     * Otherwise defer to the site's own Purchase rules rather than a list of our
     * own: a store that deliberately tracks Purchase on `pending` (bank transfer
     * and similar) must keep tracking it here too, or this fallback would break
     * the very gateways it exists for.
     */
    $disabled = (array) PYS()->getOption( 'woo_order_purchase_disabled_status' );

    return ! in_array( $status, $disabled, true );

}

/**
 * Whether the current request may see this order's data.
 *
 * @param int    $order_id
 * @param string $context 'default' for tracking payloads, 'pii' for personal
 *                        data such as Advanced Matching or rendered order
 *                        details. The 'pii' context never falls back to legacy
 *                        gateway compatibility.
 * @return bool
 */
function pysWooRequestCanAccessOrder( $order_id, $context = 'default' ) {

    static $cache = array();

    $order_id = absint( $order_id );

    if ( ! $order_id || ! function_exists( 'wc_get_order' ) ) {
        return false;
    }

    // everything the answer depends on that can still change within a request:
    // the known-orders marker, the current user, and the submitted order key
    $state = pysWooAccessCacheEpoch() . '|' . get_current_user_id() . '|' . pysWooGetSubmittedOrderKey();

    if ( ! isset( $cache[ $state ][ $context ][ $order_id ] ) ) {
        $cache[ $state ][ $context ][ $order_id ] = (bool) apply_filters(
            'pys_woo_request_can_access_order',
            pysWooCheckOrderAccess( $order_id, $context ),
            $order_id,
            $context
        );
    }

    return $cache[ $state ][ $context ][ $order_id ];

}

/**
 * @param int    $order_id
 * @param string $context
 * @return bool
 */
function pysWooCheckOrderAccess( $order_id, $context ) {

    $order = wc_get_order( $order_id );

    /*
     * Must be a customer order. wc_get_order() also returns refunds, and
     * WC_Order_Refund extends WC_Abstract_Order — it has neither get_order_key()
     * nor get_customer_id(). Orders and refunds share one ID sequence, so an
     * enumerating request lands on refund IDs sooner or later; without this
     * check that would be a fatal error instead of a denial.
     */
    if ( ! $order instanceof \WC_Order ) {
        return false;
    }

    // shop managers
    if ( current_user_can( 'manage_woocommerce' ) ) {
        return true;
    }

    /*
     * The order belongs to the logged-in customer.
     *
     * The is_user_logged_in() guard is load bearing. WooCommerce grants
     * `view_order` whenever the current user ID equals the order's customer ID
     * (wc_customer_has_capability()), and both are 0 for a guest order viewed by
     * a logged-out visitor — so an unguarded capability check would hand every
     * guest order to anyone. Same reason the customer ID is required to be > 0.
     */
    $customer_id = (int) $order->get_customer_id();

    if ( is_user_logged_in()
         && ( ( $customer_id > 0 && (int) get_current_user_id() === $customer_id )
              || current_user_can( 'view_order', $order_id ) ) ) {
        return true;
    }

    // the request carries the real order key
    $submitted_key = pysWooGetSubmittedOrderKey();

    if ( '' !== $submitted_key ) {
        $real_key = (string) $order->get_order_key();
        if ( '' !== $real_key && hash_equals( $real_key, $submitted_key ) ) {
            return true;
        }
    }

    // the order was placed in this visitor's session — covers gateways and
    // funnel plugins (CartFlows, PayU, ...) that drop the key from the URL
    if ( pysWooSessionHasOrder( $order_id ) ) {
        return true;
    }

    // WooCommerce's own session pointers; they are reset early, so they only
    // ever add coverage on top of our own marker
    if ( function_exists( 'WC' ) && isset( WC()->session ) && WC()->session ) {
        if ( $order_id === absint( WC()->session->get( 'order_awaiting_payment' ) )
             || $order_id === absint( WC()->session->get( 'store_api_draft_order' ) ) ) {
            return true;
        }
    }

    if ( 'pii' !== $context && pysWooLegacyGatewayCompatAllows( $order ) ) {
        return true;
    }

    return false;

}

/**
 * Order ID referenced by the current request, before any access check.
 *
 * @return int Order ID, or -1 when the request references no order.
 */
function pysWooResolveOrderIdFromRequest() {

    global $wp;

    if ( ! isWooCommerceActive() ) {
        return -1;
    }

    /*
     * When a key is submitted, resolve through the key itself. That lookup is
     * what ties the key to an order; the old code preferred the URL path
     * variable and so never validated the key on exactly the requests that
     * mattered.
     */
    $submitted_key = pysWooGetSubmittedOrderKey();

    if ( '' !== $submitted_key ) {
        $order_id = (int) wc_get_order_id_by_order_key( $submitted_key );
        if ( $order_id > 0 ) {
            return $order_id;
        }
    }

    $order_received = isset( $wp->query_vars['order-received'] ) ? absint( $wp->query_vars['order-received'] ) : 0;
    $is_received    = PYS()->woo_is_order_received_page();

    /*
     * WooCommerce's own deprecated pair is `?order=<id>&key=<key>` — it always
     * carries the key, so requiring authorisation here costs nothing.
     */
    if ( $is_received && ( isset( $_REQUEST['orderId'] ) || isset( $_REQUEST['order'] ) ) ) {
        $order_id = absint( isset( $_REQUEST['orderId'] ) ? $_REQUEST['orderId'] : $_REQUEST['order'] );
        if ( ! $order_id ) {
            $order_id = $order_received;
        }
        if ( $order_id > 0 ) {
            return $order_id;
        }
    }

    if ( $order_received > 0 && $is_received ) {
        return $order_received;
    }

    // gateway specific parameters: PayU, some LATAM gateways, CartFlows
    foreach ( array( 'referenceCode', 'ref_venta', 'wcf-order' ) as $param ) {
        if ( ! empty( $_REQUEST[ $param ] ) ) {
            $order_id = absint( $_REQUEST[ $param ] );
            if ( $order_id > 0 ) {
                return $order_id;
            }
        }
    }

    return -1;

}

/**
 * Order ID for the current request, or -1 when there is none the visitor is
 * allowed to see.
 *
 * @return int
 */
function wooGetOrderIdFromRequest() {

    static $resolved = null;

    if ( null !== $resolved ) {
        return $resolved;
    }

    $order_id = pysWooResolveOrderIdFromRequest();

    if ( $order_id > 0 && ! pysWooRequestCanAccessOrder( $order_id ) ) {
        $order_id = -1;
    }

    // the query vars this depends on are only final once `wp` has run
    if ( did_action( 'wp' ) ) {
        $resolved = $order_id;
    }

    return $order_id;

}

/**
 * True when the current request references an order this visitor may see.
 *
 * This used to return true on the mere presence of one of the order-id request
 * parameters, which is what allowed anyone to read order data by guessing an
 * order ID. Access control lives in wooGetOrderIdFromRequest().
 *
 * @return bool
 */
function wooIsRequestContainOrderId() {
    return wooGetOrderIdFromRequest() > 0;
}

/**
 * @param \WC_Product $product
 * @return array
 */
function pys_woo_get_product_data($product,$args) {

    if ( $product->get_type() == 'variation' ) {
        $parent_id = $product->get_parent_id(); // get terms from parent
        $tags = getObjectTerms( 'product_tag', $parent_id );
        $categories = getObjectTermsWithId( 'product_cat', $parent_id );
    } else {
        $tags = getObjectTerms( 'product_tag', $product->get_id() );
        $categories = getObjectTermsWithId( 'product_cat', $product->get_id() );
    }



    $product_price = $product->get_price();
    // for cartflow product sale
    $sale_price = getWfcProductSalePrice($product,$args);
    if($sale_price > -1) {
        $product_price = $sale_price;
    }

    $product_type = $product->get_type();

    $isGrouped = $product_type == "grouped";
    $child = [];
    if($isGrouped) {
        $product_ids = $product->get_children();
        foreach ($product_ids as $id) {
            $child = wc_get_product($id);
            if(!$child) continue;
            if($child->get_type() == "variable") { // skip  variable products in grouped product
                continue;
            }
            $child[] = [
                'id' => $id,
                'quantity' => 1
            ];
        }
    }
    $variation_attr = null;
    if($product_type == 'variation') {
        $variation_attr = $product->get_variation_attributes();
    }

    return [
        'id'            => $product->get_id(),
        'name'          => $product->get_name(),
        'tags'          => $tags,
        'categories'    => $categories,
        'price'         => $product_price,
        'type'          => $product_type,
        'child'         => $child,
        'is_external'   => false,
        'quantity'      => $args['quantity'],
        'variation_attr'=> $variation_attr
    ];
}

function pys_woo_get_cog_product_value( $product, $quantity, $price ) {
    $price_args = [ 'qty' => $quantity, 'price' => $price ];
    if ( get_option( '_pixel_cog_tax_calculating' ) == 'no' ) {
        $amount = wc_get_price_excluding_tax( $product, $price_args );
    } else {
        $amount = wc_get_price_including_tax( $product, $price_args );
    }

    $cog = getAvailableProductCog( $product );

    if ( $cog['val'] ) {
        if ( $cog['type'] == 'fix' ) {
            // Fixed COG is per-unit: subtract (cost_per_unit × quantity) from total amount
            $value = (float) $amount - ( (float) $cog['val'] * (int) $quantity );
        } else {
            // Percent: subtract percentage of the total taxed/untaxed amount
            $value = (float) $amount - ( (float) $amount * (float) $cog['val'] / 100 );
        }
    } else {
        $value = (float) $amount;
    }

    return formatPriceTrimZeros( $value );
}

/**
 * Check is Woo Supporting High-Performance Order Storage
 * @return bool
 */
function isWooUseHPStorage() {
    if(class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class )) {
        return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
    }
    return false;

}
function getBrandForWooItem($item_id) {
    if (!PYS()->getOption('enable_woo_brand')) {
        return false;
    }

    $brand_names = [];

    // Check plugins
    $plugin_taxonomies = [
	    'PYS_BRAND_PYS_PCF' => 'wpfoof-brand',
	    'PYS_BRAND_PBFW'    => 'product_brand',
	    'PYS_BRAND_WB'      => 'product_brand',
	    'PYS_BRAND_YWBA'    => '_yoast_wpseo_primary_yith_product_brand',
	    'PYS_BRAND_PEWB'    => 'pwb-brand',
	    'PYS_BRAND_PRWB'    => 'product_brand'
    ];

    foreach ($plugin_taxonomies as $plugin_const_name => $taxonomy) {
        if (defined($plugin_const_name) &&
            is_plugin_active(constant($plugin_const_name)) &&
            in_array( $plugin_const_name, PYS()->getOption( 'woo_brand_taxonomy_plugin' ), true ) ) {
            if (in_array($taxonomy, ['wpfoof-brand', '_yoast_wpseo_primary_yith_product_brand'])) {
                $result = get_post_meta($item_id, $taxonomy, true);
                if (!empty($result)) {
                    $brand_names[] = $result;
                }
            } else {
                $terms = wp_get_object_terms($item_id, $taxonomy);
                if (!empty($terms) && !is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        if (is_object($term) && property_exists($term, 'name')) {
                            $brand_names[] = $term->name;
                        }
                    }
                }
            }
            if (!empty($brand_names)) {
                return implode('/', $brand_names);
            }
        }
    }

    // Check custom taxonomy
    if (!empty(PYS()->getOption('woo_brand_taxonomy'))) {
        $terms = get_the_terms($item_id, PYS()->getOption('woo_brand_taxonomy'));
        if (!empty($terms) && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                if (is_object($term) && property_exists($term, 'name')) {
                    $brand_names[] = $term->name;
                }
            }
        }
        if (!empty($brand_names)) {
            return implode('/', $brand_names);
        }
    }

    // Autodetect brand taxonomy
    /*if (in_array('autodetect', PYS()->getOption('woo_brand_taxonomy_plugin'))) {
        $registered_taxonomies = get_taxonomies();
        foreach ($registered_taxonomies as $taxonomy) {
            $taxonomy_object = get_taxonomy($taxonomy);
            if (strpos($taxonomy_object->name, 'brand') !== false) {
                $terms = get_the_terms($item_id, $taxonomy);
                if (!empty($terms) && !is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        if (is_object($term) && property_exists($term, 'name')) {
                            $brand_names[] = $term->name;
                        }
                    }
                }
                if (!empty($brand_names)) {
                    return implode('/', $brand_names);
                }
            }
        }
    }*/

    return false;
}

function getVariableIdByAttributes($product) {
    if ($product->is_type('variable')) {
        $variations = $product->get_available_variations();
        $attributes = $_GET;
        unset($attributes['product_id']);
        // Normalize keys by removing 'attribute_' prefix
        $normalized_attributes = [];
        foreach ($attributes as $key => $value) {
            if (strpos($key, 'attribute_') === 0) {
                $normalized_key = str_replace('attribute_', '', $key);
                $normalized_attributes[$normalized_key] = $value;
            }
        }

        // If no attributes are provided, use the default attributes
        if (empty($normalized_attributes)) {
            $normalized_attributes = $product->get_default_attributes();
        }

        if(empty($normalized_attributes)) {
            return null;
        }
        $matched_variation_id = null;

        foreach ($variations as $variation) {
            $matched = true;

            foreach ($variation['attributes'] as $key => $value) {
                $attribute_key = str_replace('attribute_', '', $key);

                // Check if the attribute is set to "Any" (empty value) or matches the normalized attribute
                if ($value === '' || (isset($normalized_attributes[$attribute_key]) && strtolower($value) === strtolower($normalized_attributes[$attribute_key]))) {
                    continue;
                } else {
                    $matched = false;
                    break;
                }
            }

            if ($matched) {
                $matched_variation_id = $variation['variation_id'];
                break;
            }
        }

        if (!is_null($matched_variation_id)) {
            return $matched_variation_id;
        }
    }
    return null;
}
/**
 * Search WooCommerce products AND variations for the Product ID condition of
 * custom events. Shared by the admin picker (AJAX) and the MCP
 * `search_woo_products` tool, so both resolve a name the same way.
 *
 * @param string $term     Search term.
 * @param int    $page     1-based page.
 * @param int    $per_page Rows per page.
 * @return array{results: array<int, array<string, mixed>>, more: bool}
 */
function pysSearchWooProducts( $term, $page = 1, $per_page = 30 ) {
    $term     = is_string( $term ) ? trim( $term ) : '';
    $page     = max( 1, (int) $page );
    $per_page = max( 1, min( 100, (int) $per_page ) );

    if ( $term === '' || !isWooCommerceActive() || !class_exists( 'WC_Data_Store' ) ) {
        return array( 'results' => array(), 'more' => false );
    }

    // One row past the page, so the caller knows whether to keep paging.
    $offset = ( $page - 1 ) * $per_page;
    $fetch  = $offset + $per_page + 1;

    $data_store = \WC_Data_Store::load( 'product' );
    $store_ids  = array_map( 'absint', (array) $data_store->search_products( $term, '', true, false, $fetch ) );

    $attribute_ids = pysSearchWooVariationsByAttributes( $term, $fetch );
    $exact_ids     = pysFilterExactVariationAttributeMatches( $term, $attribute_ids );
    $partial_ids   = array_diff( $attribute_ids, $exact_ids );

    $product_ids = array_merge( $exact_ids, $store_ids, $partial_ids );
    $product_ids = array_values( array_filter( array_unique( $product_ids ) ) );

    $has_more = count( $product_ids ) > $offset + $per_page;
    $results  = array();

    foreach ( array_slice( $product_ids, $offset, $per_page ) as $product_id ) {
        $product = wc_get_product( $product_id );

        if ( !$product ) {
            continue; // the data store also returns parent ids, 0 among them
        }

        $row = array(
            'id'    => (int) $product_id,
            'label' => ConditionalEvent::getProductLabel( $product_id ),
            'type'  => $product->get_type(),
            'name'  => $product->get_name(),
            'sku'   => (string) $product->get_sku(),
        );

        if ( $product->is_type( 'variation' ) ) {
            $row['parent_id']  = (int) $product->get_parent_id();
            $row['attributes'] = function_exists( 'wc_get_formatted_variation' )
                ? wc_get_formatted_variation( $product, true, true, false )
                : '';
        }

        $results[] = $row;
    }

    return array( 'results' => $results, 'more' => $has_more );
}

/**
 * Variation IDs whose attribute values match every token of the search term
 *
 * @param string $term  Raw search term.
 * @param int    $limit Maximum IDs to return.
 * @return array<int, int>
 */
function pysSearchWooVariationsByAttributes( $term, $limit ) {
    global $wpdb;

    $tokens = preg_split( '/[\s,]+/', (string) $term, - 1, PREG_SPLIT_NO_EMPTY );

    if ( !is_array( $tokens ) || count( $tokens ) < 2 ) {
        return array();
    }

    $tokens = array_slice( $tokens, 0, 6 );
    $ids    = null;

    foreach ( $tokens as $token ) {
        $matched = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT pm.post_id
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE p.post_type = 'product_variation'
               AND p.post_status IN ( 'publish', 'private' )
               AND pm.meta_key LIKE %s
               AND pm.meta_value LIKE %s
             LIMIT %d",
            $wpdb->esc_like( 'attribute_' ) . '%',
            '%' . $wpdb->esc_like( $token ) . '%',
            max( 1, (int) $limit ) * 10
        ) );

        $matched = array_map( 'absint', (array) $matched );
        $ids     = null === $ids ? $matched : array_intersect( $ids, $matched );

        if ( empty( $ids ) ) {
            return array();
        }
    }

    return array_slice( array_values( $ids ), 0, max( 1, (int) $limit ) );
}

/**
 * Of the given variation IDs
 *
 * @param string          $term Raw search term.
 * @param array<int, int> $ids  Variation IDs to grade.
 * @return array<int, int>
 */
function pysFilterExactVariationAttributeMatches( $term, $ids ) {
    $tokens = preg_split( '/[\s,]+/', (string) $term, - 1, PREG_SPLIT_NO_EMPTY );

    if ( !is_array( $tokens ) || count( $tokens ) < 2 || empty( $ids ) ) {
        return array();
    }

    $tokens = array_map( 'strtolower', $tokens );
    sort( $tokens );

    $exact = array();

    foreach ( $ids as $id ) {
        $variation = wc_get_product( $id );

        if ( !$variation || !$variation->is_type( 'variation' ) ) {
            continue;
        }

        $values = array_filter( array_map( 'strval', array_values( $variation->get_variation_attributes() ) ), 'strlen' );
        $values = array_map( 'strtolower', $values );
        sort( $values );

        if ( $values === $tokens ) {
            $exact[] = (int) $id;
        }
    }

    return $exact;
}
