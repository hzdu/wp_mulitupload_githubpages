<?php

namespace PixelYourSite\SuperPack;

use PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function adminSecondaryNavTabs( $tabs ) {
	
	$tabs['superpack_settings'] = array(
		'url'  => PixelYourSite\buildAdminUrl( 'pixelyoursite', 'superpack_settings' ),
		'name' => 'Super Pack Settings',
		'icon' => PYS_URL . '/dist/images/superpack-logo.svg'
	);
	
	return $tabs;

}

function renderSettingsPage() {

	/** @noinspection PhpIncludeInspection */
    include PYS_SUPER_PACK_PATH . '/modules/superpack/views/html-settings.php';

}

function adminNoticePysProNotActive() {
	
	if ( current_user_can( 'manage_options' ) ) : ?>
	
        <div class="notice notice-error pys-notice">
            <p>PixelYourSite Super Pack Add-on needs PixelYourSite PRO in order to work. Activate it now.</p>
        </div>
	
	<?php endif;
	
}

function adminNoticePysProOutdated() {
	
	if ( current_user_can( 'manage_options' ) ) : ?>
	
        <div class="notice notice-error pys-notice">
            <p>PixelYourSite Super Pack Add-on requires PixelYourSite PRO version <?php echo
                PYS_SUPER_PACK_PRO_MIN_VERSION; ?> or newer. Please, update to latest version.</p>
        </div>
	
	<?php endif;
	
}

/**
 * Server API state of an additional pixel.
 *
 * @param SPPixelId $pixel_info
 * @param string    $token The pixel's token or API secret.
 * @param bool      $id_ok False when the API never serves this ID (GA: Universal Analytics).
 * @return string 'inactive', 'disabled', 'no_token' or 'ok'.
 */
function serverApiPixelState( $pixel_info, $token, $id_ok = true ) {

	if ( !$pixel_info->isEnable || empty( $pixel_info->pixel ) || !$id_ok ) {
		return 'inactive';
	}

	if ( !$pixel_info->isUseServerApi ) {
		return 'disabled';
	}

	return trim( (string) $token ) === '' ? 'no_token' : 'ok';
}

/**
 * How the warnings name a tag's API, and the video they link to.
 *
 * @param string $slug 'ga' or 'openai'.
 * @return array
 */
function serverApiLabels( $slug ) {

	$labels = array(
		'facebook' => array(
			'api'   => 'Conversion API',
			'token' => 'Conversion API token',
			'video' => 'https://www.youtube.com/watch?v=HM98mGZshvc',
		),
		'ga'     => array(
			'api'   => 'Measurement Protocol',
			'token' => 'Measurement Protocol API secret',
			'video' => 'https://www.youtube.com/watch?v=cURMzxY3JSg',
		),
		'openai' => array(
			'api'   => 'OpenAI Conversions API',
			'token' => 'OpenAI Conversions API key',
			'video' => 'https://www.youtube.com/watch?v=m2KWGlW-8cQ',
		),
	);

	return $labels[ $slug ] ?? array( 'api' => '', 'token' => '', 'video' => '' );
}

/**
 * Warning triangle next to "Enable Pixel".
 *
 * @param string $slug
 * @param string $state See serverApiPixelState().
 */
function renderServerApiTriangle( $slug, $state ) {

	$labels = serverApiLabels( $slug );
	$hidden = in_array( $state, array( 'disabled', 'no_token' ), true ) ? '' : ' pys-capi-hidden';
	?>
    <span class="pys-capi-warning-triangle ml-8<?php echo esc_attr( $hidden ); ?>" title="<?php echo esc_attr( sprintf( '%s is not configured for this pixel', $labels['api'] ) ); ?>">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path d="M12 2 L22 21 L2 21 Z" fill="#f0b849" stroke="#a8780f" stroke-width="1" stroke-linejoin="round"/>
            <rect x="11" y="9" width="2" height="6" fill="#fff"/>
            <circle cx="12" cy="18" r="1" fill="#fff"/>
        </svg>
    </span>
	<?php
}

/**
 * Per-pixel warning: 'enable' under the API toggle, 'token' under the token field.
 *
 * @param string $slug
 * @param string $kind  'enable' or 'token'.
 * @param string $state See serverApiPixelState().
 */
function renderServerApiPixelWarning( $slug, $kind, $state ) {

	$labels = serverApiLabels( $slug );

	if ( 'enable' === $kind ) {
		$text = sprintf( 'Enable %s for this pixel.', $labels['api'] );
		$shown = 'disabled' === $state;
	} else {
		$text = sprintf( 'Add the %s for this pixel.', $labels['token'] );
		$shown = 'no_token' === $state;
	}
	?>
    <div class="notice notice-warning inline pys-capi-pixel-warning pys-capi-<?php echo esc_attr( $kind ); ?>-warning<?php echo $shown ? '' : ' pys-capi-hidden'; ?>">
        <p><?php echo esc_html( $text ); ?> <a href="<?php echo esc_url( $labels['video'] ); ?>" target="_blank" class="link">Watch this video to learn how to do it.</a></p>
    </div>
	<?php
}
