<?php

namespace PixelYourSite;

/**
 * Remembers a form submission that ends with a page load (redirect or plain
 * POST), so the next page this visitor renders can fire the custom events
 * tied to that form. PYS::init() picks the transient up on 'wp'.
 */
class FormSubmissionHandler {

    /**
     * Lifetime of the marker, seconds. Long enough for a payment gateway or an
     * auth step between the form and the thank-you page.
     */
    const TTL = 300;

    private $form_track;
	public function __construct() {
		add_filter( 'gform_confirmation', array( $this, 'my_gform_after_submission' ), 50, 4 );
		add_action( 'wpforms_process_complete', array( $this, 'my_wpforms_after_submission'), 10, 4 );
		add_action( 'fluentform/submission_inserted', array( $this, 'my_fluentform_after_submission'), 10, 3);
        add_action( 'elementor_pro/forms/new_record', array( $this, 'my_elementor_after_submission'), 10, 2 );
        add_action( 'forminator_form_after_handle_submit', array( $this, 'my_forminator_after_submission'), 10, 2 );
	}

    /**
     * Transient key for the visitor of the current request. The write happens
     * inside the form plugin's submit request, the read on the page that
     * follows, so both sides must derive the key the same way.
     *
     * Guests used to be keyed by IP alone, which everyone behind the same
     * NAT, VPN or proxy shares — one visitor's Purchase could then fire on
     * another visitor's page view. The user agent narrows that down without
     * a cookie.
     *
     * @return string
     */
    public static function transientKey() {
        $user_id = get_current_user_id();

        if ( $user_id ) {
            return 'form_track_' . $user_id;
        }

        $user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';

        return 'form_track_' . md5( PYS()->get_user_ip() . '|' . $user_agent );
    }

    private function remember() {
        set_transient( self::transientKey(), $this->form_track, self::TTL );
    }

    function my_elementor_after_submission($record, $handler)
    {
        $form_id = $record->get_form_settings( 'id' );
        $this->form_track = array('formType' => 'elementor_form', 'formId' => $form_id);
        $this->remember();
    }
	function my_gform_after_submission($confirmation, $form, $entry, $ajax) {
		if(!$ajax || (!empty($confirmation) && is_array($confirmation) && array_key_exists('redirect', $confirmation))) {
			$this->form_track = array('formType' => 'gravity', 'formId' => $form['id']);
			$this->remember();
		}

		return $confirmation;
	}
	function my_wpforms_after_submission($fields, $entry, $form_data, $entry_id) {
		if ( !(isset( $form_data['settings']['ajax_submit'] ) && $form_data['settings']['ajax_submit'] == '1') ) {
			$this->form_track = array( 'formType' => 'wpforms', 'formId' => $form_data['id'] );
			$this->remember();
		}
	}

	function my_fluentform_after_submission($entryId, $formData, $form) {
		if($form->settings['confirmation']['redirectTo'] !== 'samePage'){
			$this->form_track = array( 'formType' => 'fluentform', 'formId' => $form->id );
			$this->remember();
		}
	}

    function my_forminator_after_submission($form_id, $response) {
        if (class_exists('\Forminator_API')) {
            $form = \Forminator_API::get_form( $form_id );
            // Check if AJAX is used
            if ( (isset($form->behaviors) && is_array($form->behaviors) && array_filter($form->behaviors, fn($behavior) => !empty($behavior['redirect-url']))) || (! isset( $_SERVER['HTTP_X_REQUESTED_WITH'] ) || strtolower( $_SERVER['HTTP_X_REQUESTED_WITH'] ) !== 'xmlhttprequest')) {
                $this->form_track = array( 'formType' => 'forminator', 'formId' => $form_id );
                $this->remember();
            }
        } else {
            error_log('Forminator_API class not found.');
        }
    }
}