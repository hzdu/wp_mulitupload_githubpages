<?php

namespace PixelYourSite;

use PixelYourSite;
use PixelYourSite\OpenAI\Helpers;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require_once PYS_PATH . '/modules/openai/function_helpers.php';
require_once PYS_PATH . '/modules/openai/openai-logger.php';

/**
 * OpenAI Ads (ChatGPT Ads) pixel module.
 *
 * Measurement stack: JavaScript Pixel (oaiq), Conversions API and Image Tag,
 * all keyed to the same Pixel ID. See implementations/openai-ads-pixel-integration-plan.md
 */
class OpenAI extends Settings implements Pixel {

	private static $_instance;
	private        $configured;
	private        $logger;

	private $moduleName = 'OpenAI';

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function getModuleName() {
		return $this->moduleName;
	}

	public function __construct() {
		parent::__construct( 'openai' );
		$this->locateOptions(
			PYS_PATH . '/modules/openai/options_fields.json',
			PYS_PATH . '/modules/openai/options_defaults.json'
		);

		add_action( 'pys_register_pixels', function ( $core ) {
			/** @var PYS $core */
			$core->registerPixel( $this );
		} );

		$this->logger = new OpenAI_logger();
		add_action( 'init', array( $this, 'init' ), 9 );
	}

	public function init() {
		$this->logger->init();
	}

	public function enabled() {
		if ( isSuperPackActive() && SuperPack()->getOption( 'enabled' ) ) {
			return true;
		}

		return $this->getOption( 'main_pixel_enabled' );
	}

	public function configured() {

		$license_status = PYS()->getOption( 'license_status' );
		$pixel_id = $this->getAllPixels();
		$disabled = false;
		$main_pixel_enabled = $this->getOption( 'main_pixel_enabled' );

		if ( isSuperPackActive() && version_compare( SuperPack()->getPluginVersion(), '3.1.1.1', '>=' ) ) {
			$disabledPixel = apply_filters( 'pys_pixel_disabled', array(), $this->getSlug() );
			$disabled = in_array( '1', $disabledPixel ) && in_array( 'all', $disabledPixel );
			$main_pixel_enabled = true;
		}

		$this->configured = !empty( $license_status ) // license was activated before
			&& count( $pixel_id ) > 0
			&& $main_pixel_enabled
			&& !$disabled;

		return $this->configured;
	}

	public function getPixelIDs() {

		if ( isSuperPackActive()
			&& SuperPack()->getOption( 'enabled' )
			&& SuperPack()->getOption( 'additional_ids_enabled' ) ) {
			if ( !$this->getOption( 'main_pixel_enabled' ) ) {
				return apply_filters( 'pys_openai_ids', [] );
			}
		}

		$pixels = (array) $this->getOption( 'pixel_id' );

		if ( count( $pixels ) == 0 || empty( $pixels[ 0 ] ) ) {
			return apply_filters( 'pys_openai_ids', [] );
		}

		$id = array_shift( $pixels );

		return apply_filters( 'pys_openai_ids', array( $id ) ); // return first id only
	}

	/**
	 * Every pixel id the page should initialise: the main one plus Super Pack's
	 * additional ids, minus anything hidden on this request.
	 *
	 * @param bool $checkLang
	 * @return array
	 */
	public function getAllPixels( $checkLang = true ) {

		$pixels = $this->getPixelIDs();

		foreach ( $this->getAdditionalPixels() as $_pixel ) {
			if ( $_pixel->isEnable && ( !$checkLang || $_pixel->isValidForCurrentLang() ) ) {
				$pixels[] = $_pixel->pixel;
			}
		}

		$hide_pixels = apply_filters( 'hide_pixels', array() );

		if ( is_array( $hide_pixels ) && !empty( $hide_pixels ) ) {
			$pixels = array_filter( $pixels, static function ( $element ) use ( $hide_pixels ) {
				return !in_array( $element, $hide_pixels );
			} );
		}

		return array_values( array_unique( $pixels ) );
	}

	/**
	 * Super Pack's additional OpenAI pixels.
	 *
	 * Guarded by method_exists so this edition of Pro keeps working against a
	 * Super Pack build that predates OpenAI support — it simply reports none.
	 *
	 * @return SuperPack\SPPixelId[]
	 */
	private function getAdditionalPixels() {

		if ( !isSuperPackActive( '3.0.0' )
			|| !SuperPack()->getOption( 'enabled' )
			|| !SuperPack()->getOption( 'additional_ids_enabled' )
			|| !method_exists( SuperPack(), 'getOpenAiAdditionalPixel' ) ) {
			return array();
		}

		$pixels = SuperPack()->getOpenAiAdditionalPixel();

		return is_array( $pixels ) ? $pixels : array();
	}

	/**
	 * Pixel ids the event should be sent to.
	 *
	 * SuperPack-aware filtering is added in a later stage; the extension point
	 * lives here so callers never talk to getPixelIDs() directly.
	 *
	 * @param SingleEvent $event
	 * @return array
	 */
	public function getAllPixelsForEvent( $event ) {

		$pixels = array();
		$main_pixel = $this->getPixelIDs();

		if ( isSuperPackActive( '3.0.0' )
			&& SuperPack()->getOption( 'enabled' )
			&& SuperPack()->getOption( 'additional_ids_enabled' ) ) {

			if ( !empty( $main_pixel ) ) {
				$pixel_options = SuperPack\SPPixelId::fromArray( $this->getMainPixelOptions( $main_pixel ) );

				if ( $pixel_options->isValidForEvent( $event ) && $pixel_options->isConditionalValidForEvent( $event ) ) {
					$pixels = array_merge( $pixels, $main_pixel );
				}
			}

			// Each additional pixel carries its own display conditions and
			// is_fire_* switches, so it is admitted or rejected on its own terms.
			foreach ( $this->getAdditionalPixels() as $_pixel ) {
				if ( $_pixel->isValidForEvent( $event ) && $_pixel->isConditionalValidForEvent( $event ) ) {
					$pixels[] = $_pixel->pixel;
				}
			}

		} elseif ( $this->getOption( 'main_pixel_enabled' ) ) {
			$pixels = array_merge( $pixels, $main_pixel );
		}

		return array_values( array_unique( $pixels ) );
	}

	/**
	 * The main pixel's Super Pack options blob, normalised for SPPixelId.
	 *
	 * @param array $main_pixel Result of getPixelIDs().
	 * @return array
	 */
	private function getMainPixelOptions( $main_pixel ) {

		$stored = $this->getOption( 'main_pixel' );

		return $this->normalizeSPOptions(
			$main_pixel[ 0 ],
			( !empty( $stored ) && isset( $stored[ 0 ] ) ) ? $stored[ 0 ] : ''
		);
	}

	/**
	 * The module has no `is_fire_signal` option, because it maps no automatic
	 * events for the switch to gate. The shared implementation would still emit
	 * the key, reading it as null, and SPPixelId treats a present-but-null value
	 * as "off" — leaving a dead flag that looks meaningful. Dropping the key lets
	 * SPPixelId fall back to its own default instead.
	 *
	 * @param string $main_pixel
	 * @param string $main_pixel_options
	 * @return array
	 */
	public function normalizeSPOptions( $main_pixel, $main_pixel_options ) {

		$options = parent::normalizeSPOptions( $main_pixel, $main_pixel_options );

		unset( $options[ 'is_fire_signal' ] );

		return $options;
	}

	/**
	 * @return array
	 */
	public function getPixelOptions() {

		$options = [
			'pixelIds'         => $this->getAllPixels(),
			'serverApiEnabled' => $this->isServerApiEnabled(),
			'debug'            => (bool) $this->getOption( 'debug_enabled' ),
			'opt_out'          => $this->getConsentMode(),
		];

		if ( $this->getOption( 'advanced_matching_enabled' ) ) {
			$advanced_matching = $this->getAdvancedMatchingParams();

			if ( !empty( $advanced_matching ) ) {
				$options[ 'advanced_matching' ] = $advanced_matching;
			}
		}

		if ( isSuperPackActive( '3.3.1' )
			&& SuperPack()->getOption( 'enabled' )
			&& SuperPack()->getOption( 'enable_hide_this_tag_by_tags' ) ) {
			$options[ 'hide_pixels' ] = $this->getHideInfoPixels();
		}

		return $options;
	}

	/**
	 * How many values each matching field may carry.
	 */
	const MATCHING_LIMITS = array(
		'email_sha256'        => 3,
		'phone_number_sha256' => 2,
		'external_id_sha256'  => 1,
		'first_name_sha256'   => 1,
		'last_name_sha256'    => 1,
		'country'             => 1,
		'city'                => 1,
		'region'              => 1,
		'postal_code'         => 1,
	);

	/**
	 * User data for oaiq("init", { user: ... }): one value per field.
	 *
	 * @param int|null $wooOrder Explicit Woo order id, from trusted internal code.
	 * @param int|null $eddOrder Explicit EDD payment id, from trusted internal code.
	 * @return array
	 */
	public function getAdvancedMatchingParams( $wooOrder = null, $eddOrder = null ) {
		return $this->flattenMatchingValues( $this->getMatchingValues( $wooOrder, $eddOrder ) );
	}

	/**
	 * One value per field, as the Pixel takes them, with the public filter
	 * applied.
	 *
	 * @param array $lists Field => ordered values.
	 * @return array
	 */
	private function flattenMatchingValues( $lists ) {

		$params = array();

		foreach ( $lists as $field => $values ) {
			if ( !empty( $values ) ) {
				$params[ $field ] = reset( $values );
			}
		}

		return apply_filters( 'pys_openai_advanced_matching', $params );
	}

	/**
	 * The matching values for the Conversions API copy: lists, reconciled with
	 * whatever `pys_openai_advanced_matching` decided.
	 *
	 * @param int|null $wooOrder Explicit Woo order id, from trusted internal code.
	 * @param int|null $eddOrder Explicit EDD payment id, from trusted internal code.
	 * @return array<string, array<int, string>>
	 */
	public function getServerMatchingValues( $wooOrder = null, $eddOrder = null ) {

		$lists = $this->getMatchingValues( $wooOrder, $eddOrder );
		$flat  = $this->flattenMatchingValues( $lists );

		$out = array();

		foreach ( $lists as $field => $values ) {

			// The filter removed the field: it does not travel, in either copy.
			if ( !isset( $flat[ $field ] ) || '' === $flat[ $field ] ) {
				continue;
			}

			$leading = (string) $flat[ $field ];
			$values  = array_values( array_diff( $values, array( $leading ) ) );

			array_unshift( $values, $leading );

			$out[ $field ] = array_slice( $values, 0, self::MATCHING_LIMITS[ $field ] );
		}

		// A field the filter ADDED has no list of its own; it still travels.
		foreach ( $flat as $field => $value ) {
			if ( !isset( $out[ $field ] ) && is_scalar( $value ) && '' !== (string) $value ) {
				$out[ $field ] = array( (string) $value );
			}
		}

		return $out;
	}

	/**
	 * Every matching value this request knows about, normalised, hashed where it
	 * has to be, de-duplicated and capped -- keyed by the Pixel's field name.
	 *
	 * @param int|null $wooOrder Explicit Woo order id, from trusted internal code.
	 * @param int|null $eddOrder Explicit EDD payment id, from trusted internal code.
	 * @return array<string, array<int, string>>
	 */
	public function getMatchingValues( $wooOrder = null, $eddOrder = null ) {

		$sources = $this->collectMatchingSources( $wooOrder, $eddOrder );

		$resolved = get_persistence_user_data(
			$this->firstMatchingValue( $sources[ 'email' ] ),
			$this->firstMatchingValue( $sources[ 'first_name' ] ),
			$this->firstMatchingValue( $sources[ 'last_name' ] ),
			$this->firstMatchingValue( $sources[ 'phone' ] )
		);

		$typed = get_persistence_user_data( '', '', '', '' );

		$candidates = array(
			'email_sha256'        => array_merge( array( $resolved[ 'em' ] ?? '' ), $sources[ 'email' ], array( $typed[ 'em' ] ?? '' ) ),
			'phone_number_sha256' => array_merge( array( $resolved[ 'tel' ] ?? '' ), $sources[ 'phone' ], array( $typed[ 'tel' ] ?? '' ) ),
			'first_name_sha256'   => array_merge( array( $resolved[ 'fn' ] ?? '' ), $sources[ 'first_name' ], array( $typed[ 'fn' ] ?? '' ) ),
			'last_name_sha256'    => array_merge( array( $resolved[ 'ln' ] ?? '' ), $sources[ 'last_name' ], array( $typed[ 'ln' ] ?? '' ) ),
			'external_id_sha256'  => array(),
			'country'             => $sources[ 'country' ],
			'city'                => $sources[ 'city' ],
			'region'              => $sources[ 'region' ],
			'postal_code'         => $sources[ 'postal_code' ],
		);

		if ( EventsManager::isTrackExternalId() ) {
			$external_id = $this->getExternalId( $wooOrder, $eddOrder );

			if ( !empty( $external_id ) ) {
				$candidates[ 'external_id_sha256' ] = array( hash( 'sha256', (string) $external_id ) );
			}
		}

		$rules = array(
			'email_sha256'        => 'PixelYourSite\OpenAI\Helpers\pys_openai_hash_email',
			'phone_number_sha256' => 'PixelYourSite\OpenAI\Helpers\pys_openai_hash_phone',
			'first_name_sha256'   => 'PixelYourSite\OpenAI\Helpers\pys_openai_hash_name',
			'last_name_sha256'    => 'PixelYourSite\OpenAI\Helpers\pys_openai_hash_name',
			'external_id_sha256'  => null,
			'country'             => 'PixelYourSite\OpenAI\Helpers\pys_openai_normalize_country',
			'city'                => 'PixelYourSite\OpenAI\Helpers\pys_openai_normalize_city',
			'region'              => 'PixelYourSite\OpenAI\Helpers\pys_openai_normalize_region',
			'postal_code'         => 'PixelYourSite\OpenAI\Helpers\pys_openai_normalize_postal_code',
		);

		$values = array();

		foreach ( $rules as $field => $rule ) {

			$limit = self::MATCHING_LIMITS[ $field ];
			$kept  = array();

			foreach ( (array) $candidates[ $field ] as $raw ) {

				if ( count( $kept ) >= $limit ) {
					break;
				}

				$value = ( null === $rule ) ? (string) $raw : call_user_func( $rule, (string) $raw );

				if ( $value !== '' && !in_array( $value, $kept, true ) ) {
					$kept[] = $value;
				}
			}

			$values[ $field ] = $kept;
		}

		return apply_filters( 'pys_openai_matching_values', $values, $wooOrder, $eddOrder );
	}

	/**
	 * The raw values each source has, per dimension, strongest source first.
	 *
	 * @param int|null $wooOrder Explicit Woo order id, from trusted internal code.
	 * @param int|null $eddOrder Explicit EDD payment id, from trusted internal code.
	 * @return array<string, array<int, string>>
	 */
	private function collectMatchingSources( $wooOrder = null, $eddOrder = null ) {

		$sources = array(
			'email'       => array(),
			'phone'       => array(),
			'first_name'  => array(),
			'last_name'   => array(),
			'country'     => array(),
			'city'        => array(),
			'region'      => array(),
			'postal_code' => array(),
		);

		/**
		 * Append a source's values, skipping the gaps it has.
		 *
		 * @param array $sources
		 * @param array $row Dimension => raw value.
		 * @return void
		 */
		$add = function ( &$sources, $row ) {
			foreach ( $row as $dimension => $value ) {
				if ( is_scalar( $value ) && trim( (string) $value ) !== '' ) {
					$sources[ $dimension ][] = (string) $value;
				}
			}
		};

		// --- the WooCommerce order -------------------------------------------
		if ( isWooCommerceActive() ) {

			if ( $wooOrder ) {
				$orderId = (int) $wooOrder;
			} else {
				$orderId = wooGetOrderIdFromRequest();

				if ( $orderId > 0 && !pysWooRequestCanAccessOrder( $orderId, 'pii' ) ) {
					$orderId = -1;
				}
			}

			if ( $orderId > 0 ) {

				$order = wc_get_order( $orderId );

				if ( $order ) {
					$add( $sources, array(
						'email'       => $order->get_billing_email(),
						'phone'       => $order->get_billing_phone(),
						'first_name'  => $order->get_billing_first_name(),
						'last_name'   => $order->get_billing_last_name(),
						'country'     => $order->get_billing_country(),
						'city'        => $order->get_billing_city(),
						'region'      => $order->get_billing_state(),
						'postal_code' => $order->get_billing_postcode(),
					) );
				}
			}
		}

		// --- the EDD payment -------------------------------------------------
		if ( isEddActive() ) {

			if ( $eddOrder ) {
				$order_id = (int) $eddOrder;
			} else {
				$payment_key = getEddPaymentKey();
				$order_id = (int) edd_get_purchase_id_by_key( $payment_key );
			}

			if ( $order_id ) {

				$userEdd = edd_get_payment_meta_user_info( $order_id );
				$address = isset( $userEdd[ 'address' ] ) ? (array) $userEdd[ 'address' ] : array();

				// EDD core collects no phone number, so there is nothing to read.
				$add( $sources, array(
					'email'       => isset( $userEdd[ 'email' ] ) ? $userEdd[ 'email' ] : '',
					'first_name'  => isset( $userEdd[ 'first_name' ] ) ? $userEdd[ 'first_name' ] : '',
					'last_name'   => isset( $userEdd[ 'last_name' ] ) ? $userEdd[ 'last_name' ] : '',
					'country'     => isset( $address[ 'country' ] ) ? $address[ 'country' ] : '',
					'city'        => isset( $address[ 'city' ] ) ? $address[ 'city' ] : '',
					'region'      => isset( $address[ 'state' ] ) ? $address[ 'state' ] : '',
					'postal_code' => isset( $address[ 'zip' ] ) ? $address[ 'zip' ] : '',
				) );
			}
		}

		// --- the WordPress profile -------------------------------------------
		$user = wp_get_current_user();

		if ( $user && $user->ID ) {

			$add( $sources, array(
				'email'       => $user->get( 'user_email' ),
				'first_name'  => $user->first_name,
				'last_name'   => $user->last_name,
				'phone'       => get_user_meta( $user->ID, 'billing_phone', true ),
				'country'     => get_user_meta( $user->ID, 'billing_country', true ),
				'city'        => get_user_meta( $user->ID, 'billing_city', true ),
				'region'      => get_user_meta( $user->ID, 'billing_state', true ),
				'postal_code' => get_user_meta( $user->ID, 'billing_postcode', true ),
			) );
		}

		return $sources;
	}

	/**
	 * The first value a dimension has, or an empty string.
	 *
	 * @param array $values
	 * @return string
	 */
	private function firstMatchingValue( $values ) {
		return empty( $values ) ? '' : (string) reset( $values );
	}

	/**
	 * The stable pseudonymous customer identifier backing external_id_sha256.
	 *
	 * Same source the other platforms already use for external_id, so a visitor
	 * keeps one identity across destinations. Returned unhashed — callers hash it.
	 *
	 * @param int|null $wooOrder Explicit Woo order id, from trusted internal code.
	 * @param int|null $eddOrder Explicit EDD payment id, from trusted internal code.
	 * @return string
	 */
	public function getExternalId( $wooOrder = null, $eddOrder = null ) {

		if ( $wooOrder && isWooCommerceActive() ) {
			$order = wc_get_order( (int) $wooOrder );

			if ( $order && $order->get_meta( 'external_id' ) ) {
				return (string) $order->get_meta( 'external_id' );
			}
		}

		if ( $eddOrder && isEddActive() ) {
			$external_id = edd_get_payment_meta( (int) $eddOrder, 'external_id', true );

			if ( !empty( $external_id ) ) {
				return (string) $external_id;
			}
		}

		$user = wp_get_current_user();

		if ( $user && $user->ID && $user->get( 'external_id' ) ) {
			return (string) $user->get( 'external_id' );
		}

		$pbid = PYS()->get_pbid();

		return $pbid ? (string) $pbid : '';
	}

	/**
	 * Create pixel events and fill them.
	 *
	 * @param SingleEvent $event
	 * @return array
	 */
	public function generateEvents( $event ) {

		$pixelEvents = [];

		if ( !$this->configured() ) {
			return [];
		}

		$disabledPixel = $this->getDisabledPixels();

		if ( in_array( '1', $disabledPixel, true ) || in_array( 'all', $disabledPixel, true ) ) {
			return [];
		}

		// Advanced Purchase Tracking marks which pixels already got the order
		// server-side, so the browser copy must skip them.
		if ( ( $event->getId() === 'woo_purchase' || $event->getId() === 'edd_purchase' )
			&& !empty( $event->payload[ 'send_server_event' ][ $this->getSlug() ] ) ) {
			$disabledPixel = array_merge( $disabledPixel, $event->payload[ 'send_server_event' ][ $this->getSlug() ] );
		}

		$pixelIds = $this->getAllPixelsForEvent( $event );

		if ( !empty( $disabledPixel ) ) {
			$pixelIds = array_values( array_filter( $pixelIds, static function ( $pixel ) use ( $disabledPixel ) {
				return !in_array( $pixel, $disabledPixel, true );
			} ) );
		}

		// Super Pack can restrict each pixel to its own slice of the catalogue, so
		// pixels whose slice differs need their own event: contents[] and amount are
		// built together and would otherwise disagree.
		//
		// The empty-recipients check belongs to the unfiltered path only. In the
		// filtered path the recipients come from the product filter, and $pixelIds
		// has already had the display conditions applied — bailing out on it here
		// would drop every category-scoped pixel from orders.
		$productsByPixel = $this->getProductsPerPixel( $event, $disabledPixel );

		if ( $productsByPixel === null ) {

			if ( count( $pixelIds ) == 0 ) {
				return [];
			}

			$pixelEvent = clone $event;

			if ( $this->addParamsToEvent( $pixelEvent ) ) {
				$pixelEvent->addPayload( [ 'pixelIds' => $pixelIds ] );
				$pixelEvents[] = $pixelEvent;
			}

			return $pixelEvents;
		}

		foreach ( $this->groupPixelsByProducts( $productsByPixel ) as $group ) {
			$products = $productsByPixel[ $group[ 0 ] ];

			// A pixel whose filter matches nothing gets no event at all rather than
			// an order with an empty basket.
			if ( empty( $products ) ) {
				continue;
			}

			$pixelEvent = clone $event;
			$pixelEvent->args[ 'products' ] = $products;

			if ( $this->addParamsToEvent( $pixelEvent ) ) {
				$pixelEvent->addPayload( [ 'pixelIds' => $group ] );
				$pixelEvents[] = $pixelEvent;
			}
		}

		return $pixelEvents;
	}

	/**
	 * Product list each pixel should report for this event.
	 *
	 * Candidates are gated by isValidForEvent() only — enable switch, is_fire_*
	 * and language — deliberately not by the display conditions. For an event that
	 * carries a product list the conditions ARE the product filter: a pixel scoped
	 * to a category still receives the order, reporting just that category's lines.
	 * Gating on the display-condition-filtered recipient list instead would drop
	 * such a pixel from purchases entirely, because a product-level condition never
	 * matches the order-received page. This mirrors Facebook, which is the reference
	 * behaviour here.
	 *
	 * @param SingleEvent $event
	 * @param array       $disabledPixel
	 * @return array|null Null when the event carries no product list to filter.
	 */
	private function getProductsPerPixel( $event, $disabledPixel ) {

		if ( !isSuperPackActive( '3.0.0' ) || !SuperPack()->getOption( 'enabled' ) ) {
			return null;
		}

		$wooEventsWithProducts = array(
			'woo_purchase', 'woo_initiate_checkout',
			'woo_add_to_cart_on_checkout_page', 'woo_add_to_cart_on_cart_page',
		);
		$eddEventsWithProducts = array(
			'edd_purchase', 'edd_initiate_checkout', 'edd_add_to_cart_on_checkout_page',
		);

		$isWoo = in_array( $event->getId(), $wooEventsWithProducts, true );
		$isEdd = in_array( $event->getId(), $eddEventsWithProducts, true );

		if ( !$isWoo && !$isEdd ) {
			return null;
		}

		$main_pixel = $this->getPixelIDs();
		$candidates = array();

		if ( !empty( $main_pixel ) ) {
			$candidates[] = SuperPack\SPPixelId::fromArray( $this->getMainPixelOptions( $main_pixel ) );
		}

		$candidates = array_merge( $candidates, $this->getAdditionalPixels() );

		$allProducts = ( is_array( $event->args ) && isset( $event->args[ 'products' ] ) )
			? $event->args[ 'products' ]
			: array();

		$productsByPixel = array();

		foreach ( $candidates as $_pixel ) {

			if ( !$_pixel->isValidForEvent( $event ) || in_array( $_pixel->pixel, $disabledPixel, true ) ) {
				continue;
			}

			$filter = $isWoo ? $_pixel->getWooFilter() : $_pixel->getEddFilter();

			if ( $filter === null ) {
				$productsByPixel[ $_pixel->pixel ] = $allProducts;
				continue;
			}

			// "all" means the whole catalogue, which is the same as no filtering.
			$containsAll = array_filter( $filter, function ( $item ) {
				return isset( $item[ 'filter' ] ) && $item[ 'filter' ] == 'all';
			} );

			if ( $containsAll ) {
				$productsByPixel[ $_pixel->pixel ] = $allProducts;
				continue;
			}

			$productsByPixel[ $_pixel->pixel ] = $isWoo
				? EventsWoo()->filterEventProductsBy( $event, $filter, $_pixel )
				: EventsEdd()->filterEventProductsBy( $event, $filter, $_pixel );
		}

		return empty( $productsByPixel ) ? null : $productsByPixel;
	}

	/**
	 * Collapse pixels that end up with the same products into one event each.
	 *
	 * @param array $productsByPixel
	 * @return array List of pixel-id groups.
	 */
	private function groupPixelsByProducts( $productsByPixel ) {

		$groups    = array();
		$processed = array();

		foreach ( $productsByPixel as $pixel => $products ) {

			if ( in_array( $pixel, $processed, true ) ) {
				continue;
			}

			$ids   = array_column( is_array( $products ) ? $products : array(), 'product_id' );
			$group = array( (string) $pixel );

			foreach ( $productsByPixel as $other_pixel => $other_products ) {
				if ( $pixel === $other_pixel || in_array( $other_pixel, $processed, true ) ) {
					continue;
				}

				$other_ids = array_column( is_array( $other_products ) ? $other_products : array(), 'product_id' );

				if ( $ids === $other_ids ) {
					$group[]     = (string) $other_pixel;
					$processed[] = $other_pixel;
				}
			}

			$groups[]    = $group;
			$processed[] = $pixel;
		}

		return $groups;
	}

	/**
	 * Pixel ids Super Pack wants suppressed for this platform on this request.
	 *
	 * @return array
	 */
	private function getDisabledPixels() {

		$disabled = apply_filters( 'pys_pixel_disabled', array(), $this->getSlug() );

		if ( !is_array( $disabled ) ) {
			$disabled = array( $disabled );
		}

		if ( isSuperPackActive() && version_compare( SuperPack()->getPluginVersion(), '3.1.1.1', '>=' ) ) {
			$hidden = apply_filters( 'hide_pixels', array() );

			if ( is_array( $hidden ) ) {
				$disabled = array_merge( $disabled, $hidden );
			}
		}

		return $disabled;
	}
	/**
	 * Translate a generic SingleEvent into OpenAI's closed event taxonomy.
	 *
	 * Event mapping is filled in the Woo/EDD stages. Automatic events are out of
	 * scope for OpenAI by design and never get a case here.
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function addParamsToEvent( &$event ) {

		$isActive = false;

		switch ( $event->getId() ) {

			case 'init_event':
				$isActive = $this->addPageViewParams( $event );
				break;

			case 'custom_event':
				$isActive = $this->add_custom_event_params( $event );
				break;

			case 'woo_view_content':
				$isActive = $this->addWooViewContentParams( $event );
				break;

			case 'woo_add_to_cart_on_button_click':
				$isActive = $this->addWooAddToCartParams( $event );
				break;

			case 'woo_add_to_cart_on_cart_page':
			case 'woo_add_to_cart_on_checkout_page':
				$isActive = $this->addWooAddToCartOnCartParams( $event );
				break;

			case 'woo_initiate_checkout':
				$isActive = $this->addWooInitiateCheckoutParams( $event );
				break;

			case 'woo_purchase':
				$isActive = $this->addWooPurchaseParams( $event );
				break;

			case 'woo_subscription_created':
				$isActive = $this->addWooPlanEnrollmentParams( $event, 'subscription_created' );
				break;

			case 'woo_start_trial':
				$isActive = $this->addWooPlanEnrollmentParams( $event, 'trial_started' );
				break;

			// Easy Digital Downloads. Same 1:1 rule as WooCommerce — refunds, cart
			// removals, category views, customer-value tiers and the whole EDD
			// licence family have no counterpart in OpenAI's taxonomy.
			case 'edd_view_content':
				$isActive = $this->addEddContentsEvent( $event, 'contents_viewed', 'edd_view_content_enabled' );
				break;

			case 'edd_add_to_cart_on_button_click':
				$isActive = $this->addEddAddToCartOnButtonParams( $event );
				break;

			case 'edd_add_to_cart_on_checkout_page':
				$isActive = $this->addEddContentsEvent( $event, 'items_added', 'edd_add_to_cart_enabled' );
				break;

			case 'edd_initiate_checkout':
				$isActive = $this->addEddContentsEvent( $event, 'checkout_started', 'edd_initiate_checkout_enabled' );
				break;

			case 'edd_purchase':
				$isActive = $this->addEddContentsEvent( $event, 'order_created', 'edd_purchase_enabled' );
				break;

			case 'edd_subscription_created':
				$isActive = $this->addEddPlanEnrollmentParams( $event, 'subscription_created' );
				break;

			case 'edd_start_trial':
				$isActive = $this->addEddPlanEnrollmentParams( $event, 'trial_started' );
				break;

			default:
				break;
		}

		if ( $isActive && $this->isServerApiEnabled() ) {
			$event->payload[ 'event_id' ] = PixelYourSite\pys_generate_token();
		}

		return $isActive;
	}

	/**
	 * Base page view. Unconditional — it fires whenever the module is enabled, the
	 * same way Meta's PageView does, so it has no per-event toggle.
	 *
	 * PYS sends the generic, page-agnostic variant: `type` only, no contents[].
	 * OpenAI's schema would allow naming the page in contents[], but a bare
	 * page_viewed keeps the event surface predictable.
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function addPageViewParams( &$event ) {

		if ( !get_post_type() ) {
			return false;
		}

		$event->addPayload( [ 'name' => 'page_viewed' ] );
		$event->addParams( [ 'data' => [ 'type' => 'contents' ] ] );

		return true;
	}

	/**
	 * Attach an OpenAI event to a SingleEvent.
	 *
	 * Every payload the module ever sends goes through here, so the shape rules
	 * live in one place: `type` is mandatory, `currency` is mandatory whenever
	 * `amount` is present, `amount` is always integer minor units, and no field
	 * outside the documented set is ever added.
	 *
	 * @param SingleEvent $event
	 * @param string      $name     OpenAI standard event name.
	 * @param string      $type     Data shape: contents, customer_action, plan_enrollment, custom.
	 * @param mixed       $amount   Decimal amount, converted to minor units here.
	 * @param string      $currency
	 * @param array       $contents contents[] items, already built.
	 * @param string      $plan_id  plan_enrollment only.
	 * @return bool
	 */
	private function attachEvent( &$event, $name, $type, $amount = null, $currency = '', $contents = array(), $plan_id = '' ) {

		$data = array( 'type' => $type );

		if ( in_array( $type, array( 'plan_enrollment', 'custom' ), true ) && $plan_id !== '' && $plan_id !== null ) {
			$data[ 'plan_id' ] = is_array( $plan_id ) ? $plan_id : (string) $plan_id;
		}

		$minor_units = Helpers\pys_openai_to_minor_units( $amount, $currency );

		if ( $minor_units !== null ) {

			if ( Helpers\pys_openai_is_valid_currency( $currency ) ) {
				$data[ 'amount' ]   = $minor_units;
				$data[ 'currency' ] = $currency;
			} elseif ( $currency !== '' && $currency !== null ) {
				$this->getLog()->debug( 'OpenAI: the amount was dropped, OpenAI does not accept this currency', array(
					'event'    => $name,
					'currency' => is_scalar( $currency ) ? (string) $currency : gettype( $currency ),
				) );
			}
		}

		$item_fields = PYS_Event_Definitions::get_openai_content_item_fields();

		$contents = array_values( array_filter( (array) $contents, function ( $item ) use ( $item_fields ) {
			return is_array( $item ) && !empty( array_intersect( array_keys( $item ), $item_fields ) );
		} ) );

		if ( !empty( $contents ) && $type !== 'customer_action' ) {
			$data[ 'contents' ] = $contents;
		}

		$event->addPayload( array( 'name' => $name ) );
		$event->addParams( array( 'data' => $data ) );

		return true;
	}

	/**
	 * A user-configured event.
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function add_custom_event_params( &$event ) {

		global $post;

		/**
		 * @var CustomEvent $customEvent
		 */
		$customEvent = $event->args;

		if ( !$customEvent instanceof CustomEvent || !$customEvent->isOpenAIEnabled() ) {
			return false;
		}

		$name = $customEvent->getOpenAIEventType();

		if ( empty( $name ) ) {
			$this->getLog()->debug( 'OpenAI custom event skipped - no usable event name', array(
				'event' => $customEvent->getTitle(),
			) );

			return false;
		}

		$event_type = $customEvent->openai_event_type;
		$data_type  = CustomEvent::getOpenAIDataType( $event_type );

		$params = $customEvent->getOpenAIParams();

		if ( $customEvent->openai_params_enabled ) {
			// SuperPack Dynamic Params, as every other platform gets them.
			$params = (array) apply_filters( 'pys_superpack_dynamic_params', $params, 'openai' );
		}

		$amount   = $this->customEventAmount( $params, $customEvent );
		$currency = $this->customEventCurrency( $params, $customEvent );
		$plan_id  = $data_type === 'plan_enrollment' || $data_type === 'custom'
			? $this->customEventValue( $params, 'plan_id' )
			: '';

		$contents = $this->customEventContents( $params, $currency );

		// What the visitor actually did outranks what the form guessed at.
		$woo = $this->customEventWooData( $event, $customEvent, $data_type );

		if ( $woo[ 'amount' ] !== null ) {
			$amount   = $woo[ 'amount' ];
			$currency = $woo[ 'currency' ] !== '' ? $woo[ 'currency' ] : $currency;
		} elseif ( !empty( $woo[ 'contents' ] ) && ( $amount === null || $amount === '' ) ) {
			$currency = $woo[ 'currency' ] !== '' ? $woo[ 'currency' ] : $currency;
		}

		if ( !empty( $woo[ 'contents' ] ) ) {
			$contents = $woo[ 'contents' ];
		}

		// customer_action has no contents[] at all.
		if ( $data_type === 'customer_action' ) {
			$contents = array();
		}

		$event->addPayload( array( 'delay' => $customEvent->getDelay() ) );

		$attached = $this->attachEvent(
			$event, $event_type === 'custom' ? 'custom' : $name, $data_type,
			$amount, $currency, $contents, $plan_id
		);

		if ( $attached && $event_type === 'custom' ) {
			$event->addParams( array( 'custom_event_name' => $name ) );
		}

		return $attached;
	}

	/**
	 * One configured parameter, as a plain value.
	 *
	 * @param array  $params
	 * @param string $key
	 * @return mixed
	 */
	private function customEventValue( $params, $key ) {

		if ( !isset( $params[ $key ] ) ) {
			return '';
		}

		$param = $params[ $key ];

		if ( !is_array( $param ) ) {
			return $param;
		}

		if ( !empty( $param[ 'dynamic' ] ) && !empty( $param[ 'selector' ] ) ) {
			return $param;
		}

		return isset( $param[ 'value' ] ) ? $param[ 'value' ] : '';
	}

	/**
	 * The configured amount, or null.
	 *
	 * @param array       $params
	 * @param CustomEvent $customEvent
	 * @return float|int|string|null
	 */
	private function customEventAmount( $params, $customEvent ) {

		if ( !isset( $params[ 'amount' ] ) ) {
			return null;
		}

		$amount = $params[ 'amount' ];

		if ( is_array( $amount ) ) {

			if ( !empty( $amount[ 'dynamic' ] ) && !empty( $amount[ 'selector' ] ) ) {
				$this->getLog()->debug( 'OpenAI custom event: a dynamic amount cannot be converted to minor units, so it was not sent', array(
					'event'    => $customEvent->getTitle(),
					'selector' => $amount[ 'selector' ],
				) );

				return null;
			}

			$amount = isset( $amount[ 'value' ] ) ? $amount[ 'value' ] : null;
		}

		return ( $amount === '' || $amount === null ) ? null : $amount;
	}

	/**
	 * The configured currency, or ''.
	 *
	 * @param array       $params
	 * @param CustomEvent $customEvent
	 * @return string
	 */
	private function customEventCurrency( $params, $customEvent ) {

		$currency = $this->customEventValue( $params, 'currency' );

		if ( is_array( $currency ) ) {
			$this->getLog()->debug( 'OpenAI custom event: a currency cannot be read from the page, so it was not sent', array(
				'event'    => $customEvent->getTitle(),
				'selector' => isset( $currency[ 'selector' ] ) ? $currency[ 'selector' ] : '',
			) );

			return '';
		}

		return (string) $currency;
	}

	/**
	 * The single contents[] item the editor can describe, if any.
	 *
	 * @param array  $params
	 * @param string $currency
	 * @return array
	 */
	private function customEventContents( $params, $currency ) {

		$fields = array(
			'id'           => $this->customEventValue( $params, 'content_id' ),
			'name'         => $this->customEventValue( $params, 'content_name' ),
			'content_type' => $this->customEventValue( $params, 'content_type' ),
			'quantity'     => $this->customEventValue( $params, 'quantity' ),
		);

		$dynamic    = false;
		$configured = false;

		foreach ( $fields as $value ) {
			if ( is_array( $value ) ) {
				$dynamic    = true;
				$configured = true;
				continue;
			}

			if ( $value !== '' && $value !== null ) {
				$configured = true;
			}
		}

		if ( !$configured ) {
			return array();
		}

		if ( !$dynamic ) {
			return array(
				Helpers\pys_openai_content_item(
					$fields[ 'id' ],
					$fields[ 'name' ],
					$fields[ 'content_type' ],
					$fields[ 'quantity' ],
					null,
					$currency
				),
			);
		}

		$item = array();

		if ( $fields[ 'id' ] !== '' && $fields[ 'id' ] !== null ) {
			$item[ 'id' ] = $fields[ 'id' ];
		}

		if ( $fields[ 'name' ] !== '' && $fields[ 'name' ] !== null ) {
			$item[ 'name' ] = $fields[ 'name' ];
		}

		if ( $fields[ 'content_type' ] !== '' && $fields[ 'content_type' ] !== null ) {
			$item[ 'content_type' ] = $fields[ 'content_type' ];
		}

		if ( $fields[ 'quantity' ] !== '' && $fields[ 'quantity' ] !== null ) {
			$item[ 'quantity' ] = $fields[ 'quantity' ];
		}

		return array( $item );
	}

	/**
	 * What WooCommerce knows about this event, when the user asked for it.
	 *
	 * @param SingleEvent $event
	 * @param CustomEvent $customEvent
	 * @param string      $data_type
	 * @return array{amount: mixed, currency: string, contents: array}
	 */
	private function customEventWooData( $event, $customEvent, $data_type ) {

		global $post;

		$result = array( 'amount' => null, 'currency' => '', 'contents' => array() );

		if ( !isWooCommerceActive() ) {
			return $result;
		}

		$track_value = false;

		foreach ( $customEvent->getTriggers() as $trigger ) {
			$trigger_type = $trigger->getTriggerType();

			if ( in_array( $trigger_type, array( 'purchase', 'add_to_cart' ), true ) && $trigger->getTrackValueAndCurrency() ) {
				$track_value = $trigger_type;
			}
		}

		if ( $track_value === 'purchase' ) {

			$order = EventsWoo()->getOrder();

			if ( $order ) {
				$result[ 'amount' ]   = $order->get_total();
				$result[ 'currency' ] = $order->get_currency();
			}

		} elseif ( $track_value === 'add_to_cart' && $event->getPayloadValue( 'productId' ) ) {

			$product_id = $event->getPayloadValue( 'productId' );
			$quantity   = $event->getPayloadValue( 'quantity' ) ?: 1;
			$product    = wc_get_product( $product_id );

			if ( $product ) {
				$unit_price = getWooProductPriceToDisplay( $product_id, 1 );

				$result[ 'amount' ]   = getWooProductPriceToDisplay( $product_id, $quantity );
				$result[ 'currency' ] = get_woocommerce_currency();

				if ( $data_type !== 'customer_action' ) {
					$result[ 'contents' ] = array(
						Helpers\pys_openai_content_item(
							Helpers\getOpenAiWooProductContentId( Helpers\getOpenAiWooVariableToSimpleProductId( $product ) ?: $product_id ),
							$product->get_name(),
							'product',
							$quantity,
							$unit_price,
							$result[ 'currency' ]
						),
					);
				}
			}
		}

		if ( $data_type === 'customer_action' ) {
			return $result;
		}

		// The two switches, which describe the page rather than the trigger.
		if ( $customEvent->openai_track_single_woo_data && is_product()
			&& ( ( $post && $post->post_type === 'product' ) || $event->getPayloadValue( 'productId' ) ) ) {

			$product_id = $event->getPayloadValue( 'productId' ) ?: ( $post ? $post->ID : 0 );
			$quantity   = $event->getPayloadValue( 'quantity' ) ?: 1;
			$product    = $product_id ? wc_get_product( $product_id ) : null;

			if ( $product ) {
				$currency = get_woocommerce_currency();
				$result[ 'amount' ]   = getWooProductPriceToDisplay( $product_id, $quantity );
				$result[ 'currency' ] = $currency;
				$result[ 'contents' ] = array(
					Helpers\pys_openai_content_item(
						Helpers\getOpenAiWooProductContentId( Helpers\getOpenAiWooVariableToSimpleProductId( $product ) ?: $product_id ),
						$product->get_name(),
						'product',
						$quantity,
						getWooProductPriceToDisplay( $product_id, 1 ),
						$currency
					),
				);
			}

		} elseif ( $customEvent->openai_track_cart_woo_data ) {

			$order = EventsWoo()->getOrder();
			$source = $order
				? EventsWoo()->getEvent( 'woo_purchase', false )
				: EventsWoo()->getEvent( 'woo_initiate_checkout' );

			if ( $source ) {
				$cart = $this->buildWooCartContents( $source );

				if ( !empty( $cart[ 'contents' ] ) ) {
					$result[ 'contents' ] = $cart[ 'contents' ];
					$result[ 'currency' ] = $cart[ 'currency' ] ?? get_woocommerce_currency();
					$result[ 'amount' ]   = $this->wooSourceTotal( $source );
				}
			}
		}

		return $result;
	}

	/**
	 * woo_view_content -> contents_viewed
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function addWooViewContentParams( &$event ) {

		if ( !$this->getOption( 'woo_view_content_enabled' ) ) {
			return false;
		}

		if ( !isset( $event->args[ 'id' ] ) ) {
			return false;
		}

		$product = wc_get_product( $event->args[ 'id' ] );

		if ( !$product ) {
			return false;
		}

		$quantity = isset( $event->args[ 'quantity' ] ) ? (int) $event->args[ 'quantity' ] : 1;
		$currency = get_woocommerce_currency();

		if ( $this->getOption( 'woo_variable_data_select_product' ) && !$this->getOption( 'woo_variable_as_simple' ) ) {
			$product_id = getVariableIdByAttributes( $product );
		} else {
			$product_id = Helpers\getOpenAiWooVariableToSimpleProductId( $product );
		}

		$product_id = $product_id ?: $product->get_id();
		$content_id = Helpers\getOpenAiWooProductContentId( $product_id );

		$unit_price = getWooProductPriceToDisplay( $product_id, 1, getWfcProductSalePrice( $product, $event->args ) );

		$amount = null;

		if ( PYS()->getOption( 'woo_view_content_value_enabled' ) ) {
			$amount = getWooProductValue( array(
				'valueOption' => PYS()->getOption( 'woo_view_content_value_option' ),
				'global'      => PYS()->getOption( 'woo_view_content_value_global', 0 ),
				'percent'     => PYS()->getOption( 'woo_view_content_value_percent', 100 ),
				'product_id'  => $product_id,
				'qty'         => $quantity,
			) );
		}

		$contents = array(
			Helpers\pys_openai_content_item( $content_id, $product->get_name(), 'product', $quantity, $unit_price, $currency ),
		);

		return $this->attachEvent( $event, 'contents_viewed', 'contents', $amount, $currency, $contents );
	}

	/**
	 * woo_add_to_cart_on_button_click -> items_added
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function addWooAddToCartParams( &$event ) {

		if ( ! PYS()->getOption( 'woo_add_to_cart_enabled' ) || ! $this->getOption( 'woo_add_to_cart_enabled' ) ) {
			return false;
		}

		// This event is registered twice: once during the generic dynamic-event pass
		// with no args, which only has to place a slot in options.dynamicEvents, and
		// again per product when the page renders pysWooProductData. Returning false
		// on the arg-less pass would leave the client with no slot to fire into, so
		// the placeholder carries the bare shape instead.
		if ( !isset( $event->args[ 'productId' ] ) ) {
			return $this->attachEvent( $event, 'items_added', 'contents' );
		}

		$product = wc_get_product( $event->args[ 'productId' ] );

		if ( !$product ) {
			return $this->attachEvent( $event, 'items_added', 'contents' );
		}

		$quantity   = isset( $event->args[ 'quantity' ] ) ? (int) $event->args[ 'quantity' ] : 1;
		$currency   = get_woocommerce_currency();
		$product_id = Helpers\getOpenAiWooVariableToSimpleProductId( $product );
		$content_id = Helpers\getOpenAiWooProductContentId( $product_id );

		$unit_price = getWooProductPriceToDisplay( $product_id, 1, getWfcProductSalePrice( $product, $event->args ) );

		$amount = null;

		if ( PYS()->getOption( 'woo_add_to_cart_value_enabled' ) ) {
			$amount = getWooProductValue( array(
				'valueOption' => PYS()->getOption( 'woo_add_to_cart_value_option' ),
				'global'      => PYS()->getOption( 'woo_add_to_cart_value_global', 0 ),
				'percent'     => PYS()->getOption( 'woo_add_to_cart_value_percent', 100 ),
				'product_id'  => $product_id,
				'qty'         => $quantity,
			) );
		}

		$contents = array(
			Helpers\pys_openai_content_item( $content_id, $product->get_name(), 'product', $quantity, $unit_price, $currency ),
		);

		return $this->attachEvent( $event, 'items_added', 'contents', $amount, $currency, $contents );
	}

	/**
	 * woo_add_to_cart_on_cart_page / _on_checkout_page -> items_added
	 *
	 * All three add-to-cart catch methods are one logical action for OpenAI, so
	 * they share the woo_add_to_cart_enabled toggle.
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function addWooAddToCartOnCartParams( &$event ) {

		if ( !$this->getOption( 'woo_add_to_cart_enabled' ) ) {
			return false;
		}

		$built = $this->buildWooCartContents( $event );

		if ( $built === null ) {
			return false;
		}

		$amount = null;

		if ( PYS()->getOption( 'woo_add_to_cart_value_enabled' ) ) {
			$amount = getWooEventValueProducts(
				PYS()->getOption( 'woo_add_to_cart_value_option' ),
				PYS()->getOption( 'woo_add_to_cart_value_global', 0 ),
				PYS()->getOption( 'woo_add_to_cart_value_percent', 100 ),
				getWooEventCartSubtotal( $event ),
				$event->args
			);
		}

		return $this->attachEvent( $event, 'items_added', 'contents', $amount, $built[ 'currency' ], $built[ 'contents' ] );
	}

	/**
	 * woo_initiate_checkout -> checkout_started
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function addWooInitiateCheckoutParams( &$event ) {

		if ( !$this->getOption( 'woo_initiate_checkout_enabled' ) ) {
			return false;
		}

		$built = $this->buildWooCartContents( $event );

		if ( $built === null ) {
			return false;
		}

		$amount = null;

		if ( PYS()->getOption( 'woo_initiate_checkout_value_enabled' ) ) {
			$amount = getWooEventValueProducts(
				PYS()->getOption( 'woo_initiate_checkout_value_option' ),
				PYS()->getOption( 'woo_initiate_checkout_value_global', 0 ),
				PYS()->getOption( 'woo_initiate_checkout_value_percent', 100 ),
				getWooEventCartSubtotal( $event ),
				$event->args
			);
		}

		// Meta's num_items has no OpenAI field: it is implicit in contents[] length.
		return $this->attachEvent( $event, 'checkout_started', 'contents', $amount, $built[ 'currency' ], $built[ 'contents' ] );
	}

	/**
	 * woo_purchase -> order_created
	 *
	 * The order id is not a content field on either platform — it travels as the
	 * dedup event_id. woo_purchase is deliberately not duplicated into a second
	 * event the way TikTok mirrors it into woo_complete_payment: OpenAI has no
	 * equivalent of CompletePayment.
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function addWooPurchaseParams( &$event ) {

		if ( !$this->getOption( 'woo_purchase_enabled' ) ) {
			return false;
		}

		if ( empty( $event->args[ 'products' ] ) ) {
			return false;
		}

		$currency = get_woocommerce_currency();
		$contents = array();

		foreach ( $event->args[ 'products' ] as $product_data ) {
			$product_id = Helpers\getOpenAiWooProductDataId( $product_data );
			$content_id = Helpers\getOpenAiWooProductContentId( $product_id );

			$contents[] = Helpers\pys_openai_content_item(
				$content_id,
				$product_data[ 'name' ] ?? '',
				'product',
				$product_data[ 'quantity' ] ?? 1,
				getWooProductPrice( $product_id ),
				$currency
			);
		}

		$amount = getWooEventValueProducts(
			PYS()->getOption( 'woo_purchase_value_option' ),
			PYS()->getOption( 'woo_purchase_value_global', 0 ),
			PYS()->getOption( 'woo_purchase_value_percent', 100 ),
			getWooEventOrderTotal( $event ),
			$event->args
		);

		return $this->attachEvent( $event, 'order_created', 'contents', $amount, $currency, $contents );
	}

	/**
	 * woo_subscription_created -> subscription_created, woo_start_trial -> trial_started
	 *
	 * Both use the plan_enrollment shape, whose plan_id has no Meta equivalent —
	 * it is sourced the same way content ids are.
	 *
	 * @param SingleEvent $event
	 * @param string      $name
	 * @return bool
	 */
	private function addWooPlanEnrollmentParams( &$event, $name ) {

		if ( !$this->getOption( 'woo_track_subscriptions' ) ) {
			return false;
		}

		if ( empty( $event->args ) ) {
			return false;
		}

		$currency = $event->args[ 'currency' ] ?? get_woocommerce_currency();
		$contents = array();
		$plan_id  = '';

		if ( !empty( $event->args[ 'products' ] ) ) {
			$product_data = $event->args[ 'products' ][ 0 ];
			$product_id   = Helpers\getOpenAiWooProductDataId( $product_data );
			$plan_id      = Helpers\getOpenAiWooProductContentId( $product_id );

			$contents[] = Helpers\pys_openai_content_item(
				$plan_id,
				$product_data[ 'name' ] ?? '',
				'plan',
				$product_data[ 'quantity' ] ?? 1,
				getWooProductPrice( $product_id ),
				$currency
			);
		}

		$amount = $event->args[ 'value' ] ?? ( $name === 'trial_started' ? 0 : null );

		return $this->attachEvent( $event, $name, 'plan_enrollment', $amount, $currency, $contents, $plan_id );
	}

	/**
	 * What the cart or the order is worth, in major units.
	 *
	 * @param SingleEvent $source
	 * @return float|null
	 */
	private function wooSourceTotal( $source ) {

		if ( empty( $source->args[ 'products' ] ) ) {
			return null;
		}

		$total = 0;

		foreach ( $source->args[ 'products' ] as $product ) {
			$price    = isset( $product[ 'price' ] ) ? (float) $product[ 'price' ] : 0;
			$quantity = isset( $product[ 'quantity' ] ) ? (int) $product[ 'quantity' ] : 1;

			$total += $price * $quantity;
		}

		return $total > 0 ? $total : null;
	}

	/**
	 * contents[] for the whole cart, shared by items_added and checkout_started.
	 *
	 * @param SingleEvent $event
	 * @return array|null Null when the cart carries nothing to report.
	 */
	private function buildWooCartContents( $event ) {

		if ( empty( $event->args[ 'products' ] ) ) {
			return null;
		}

		$currency = get_woocommerce_currency();
		$contents = array();

		foreach ( $event->args[ 'products' ] as $product ) {
			$product_id = Helpers\getOpenAiWooCartProductId( $product );
			$content_id = Helpers\getOpenAiWooProductContentId( $product_id );

			$contents[] = Helpers\pys_openai_content_item(
				$content_id,
				$product[ 'name' ] ?? '',
				'product',
				$product[ 'quantity' ] ?? 1,
				$product[ 'price' ] ?? null,
				$currency
			);
		}

		if ( empty( $contents ) ) {
			return null;
		}

		return array(
			'contents' => $contents,
			'currency' => $currency,
		);
	}

	/**
	 * Every EDD event that uses the `contents` shape: contents_viewed, items_added,
	 * checkout_started and order_created. They differ only by name, toggle and which
	 * core value settings drive the amount.
	 *
	 * @param SingleEvent $event
	 * @param string      $name   OpenAI standard event name.
	 * @param string      $option Module option gating the event.
	 * @return bool
	 */
	private function addEddContentsEvent( &$event, $name, $option ) {

		if ( !$this->getOption( $option ) ) {
			return false;
		}

		if ( empty( $event->args[ 'products' ] ) ) {
			return false;
		}

		$currency   = edd_get_currency();
		$is_purchase = $event->getId() === 'edd_purchase';
		$contents   = array();
		$total      = 0;
		$total_as_is = 0;

		foreach ( $event->args[ 'products' ] as $product ) {

			$download_id = (int) $product[ 'product_id' ];
			$price_index = $product[ 'price_index' ] ?? null;
			$quantity    = $product[ 'quantity' ] ?? 1;

			// Single source of truth for EDD ids, unlike Woo's per-platform copies.
			$content_id = getEddContentId( $this, $download_id, $price_index );
			$unit_price = getEddDownloadPrice( $download_id, $price_index );

			$contents[] = Helpers\pys_openai_content_item(
				$content_id,
				$product[ 'name' ] ?? '',
				'product',
				$quantity,
				$unit_price,
				$currency
			);

			if ( $is_purchase ) {
				if ( PYS()->getOption( 'edd_tax_option' ) == 'included' ) {
					$total += ( $product[ 'subtotal' ] ?? 0 ) + ( $product[ 'tax' ] ?? 0 ) - ( $product[ 'discount' ] ?? 0 );
				} else {
					$total += ( $product[ 'subtotal' ] ?? 0 ) - ( $product[ 'discount' ] ?? 0 );
				}
				$total_as_is += $product[ 'price' ] ?? 0;
			} else {
				$total += $unit_price * $quantity;
				if ( isset( $product[ 'cart_item_key' ] ) ) {
					$total_as_is += edd_get_cart_item_final_price( $product[ 'cart_item_key' ] );
				} else {
					$total_as_is += floatval( edd_get_download_final_price( $download_id, array() ) );
				}
			}
		}

		$fee     = $event->args[ 'fee' ] ?? 0;
		$fee_tax = $event->args[ 'fee_tax' ] ?? 0;

		if ( PYS()->getOption( 'edd_event_value' ) == 'custom' ) {
			$total += PYS()->getOption( 'edd_tax_option' ) == 'included' ? $fee + $fee_tax : $fee;
		} else {
			$total_as_is += edd_prices_include_tax() ? $fee + $fee_tax : $fee;
		}

		$amount = null;
		$value_settings = $this->getEddValueSettings( $event->getId() );

		if ( $value_settings[ 'enabled' ] ) {
			$base = PYS()->getOption( 'edd_event_value' ) == 'custom' ? $total : $total_as_is;
			$amount = getEddEventValue( $value_settings[ 'option' ], $base, $value_settings[ 'global' ], $value_settings[ 'percent' ] );
		}

		return $this->attachEvent( $event, $name, 'contents', $amount, $currency, $contents );
	}

	/**
	 * edd_add_to_cart_on_button_click -> items_added
	 *
	 * This one arrives as a bare download id rather than a products array, and the
	 * id may carry the variable price index as "<download_id>_<price_index>".
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	private function addEddAddToCartOnButtonParams( &$event ) {

		if ( !$this->getOption( 'edd_add_to_cart_enabled' ) ) {
			return false;
		}

		// Same two-pass registration as the Woo button-click event: the arg-less pass
		// only needs to reserve the slot in options.dynamicEvents, and the real
		// payload is substituted from pysEddProductData at click time.
		if ( empty( $event->args ) ) {
			return $this->attachEvent( $event, 'items_added', 'contents' );
		}

		$download_id = $event->args;
		$price_index = null;

		if ( is_array( $download_id ) ) {
			$price_index = $download_id[ 'price_index' ] ?? null;
			$download_id = $download_id[ 'product_id' ] ?? null;
		} elseif ( strpos( (string) $download_id, '_' ) !== false ) {
			list( $download_id, $price_index ) = explode( '_', (string) $download_id, 2 );
		}

		$download_id = (int) $download_id;

		if ( !$download_id ) {
			return $this->attachEvent( $event, 'items_added', 'contents' );
		}

		$currency   = edd_get_currency();
		$content_id = getEddContentId( $this, $download_id, $price_index );
		$unit_price = getEddDownloadPrice( $download_id, $price_index );

		$amount = null;

		if ( PYS()->getOption( 'edd_add_to_cart_value_enabled' ) ) {
			$amount = getEddEventValue(
				PYS()->getOption( 'edd_add_to_cart_value_option' ),
				$unit_price,
				PYS()->getOption( 'edd_add_to_cart_value_global', 0 ),
				PYS()->getOption( 'edd_add_to_cart_value_percent', 100 )
			);
		}

		$contents = array(
			Helpers\pys_openai_content_item( $content_id, get_the_title( $download_id ), 'product', 1, $unit_price, $currency ),
		);

		return $this->attachEvent( $event, 'items_added', 'contents', $amount, $currency, $contents );
	}

	/**
	 * edd_subscription_created -> subscription_created, edd_start_trial -> trial_started
	 *
	 * edd_start_trial carries neither products nor a value — only subscription id
	 * and name — so plan_id and contents[] are simply absent there, and the amount
	 * is the 0 a free trial actually costs.
	 *
	 * @param SingleEvent $event
	 * @param string      $name
	 * @return bool
	 */
	private function addEddPlanEnrollmentParams( &$event, $name ) {

		if ( !$this->getOption( 'edd_track_subscriptions' ) ) {
			return false;
		}

		if ( empty( $event->args ) ) {
			return false;
		}

		$currency = $event->args[ 'currency' ] ?? edd_get_currency();
		$contents = array();
		$plan_id  = '';

		if ( !empty( $event->args[ 'products' ] ) ) {
			$product     = $event->args[ 'products' ][ 0 ];
			$download_id = (int) $product[ 'product_id' ];
			$price_index = $product[ 'price_index' ] ?? null;
			$plan_id     = getEddContentId( $this, $download_id, $price_index );

			$contents[] = Helpers\pys_openai_content_item(
				$plan_id,
				$product[ 'name' ] ?? '',
				'plan',
				$product[ 'quantity' ] ?? 1,
				getEddDownloadPrice( $download_id, $price_index ),
				$currency
			);
		}

		$amount = $event->args[ 'value' ] ?? ( $name === 'trial_started' ? 0 : null );

		return $this->attachEvent( $event, $name, 'plan_enrollment', $amount, $currency, $contents, $plan_id );
	}

	/**
	 * Core value settings for an EDD event, matching what the other modules read.
	 *
	 * @param string $event_id
	 * @return array
	 */
	private function getEddValueSettings( $event_id ) {

		$map = array(
			'edd_view_content'                => 'edd_view_content',
			'edd_add_to_cart_on_checkout_page' => 'edd_add_to_cart',
			'edd_initiate_checkout'           => 'edd_initiate_checkout',
			'edd_purchase'                    => 'edd_purchase',
		);

		$prefix = $map[ $event_id ] ?? 'edd_purchase';

		return array(
			'enabled' => PYS()->getOption( $prefix . '_value_enabled', $prefix === 'edd_purchase' ),
			'option'  => PYS()->getOption( $prefix . '_value_option' ),
			'global'  => PYS()->getOption( $prefix . '_value_global', 0 ),
			'percent' => PYS()->getOption( $prefix . '_value_percent', 100 ),
		);
	}

	/**
	 * Image Tag fallback for visitors without JavaScript.
	 *
	 * Only page_viewed is emitted: a static image tag loads with the page and
	 * cannot observe anything that happens later, so commerce events have nothing
	 * to report here. The endpoint accepts pid, event, data[...], event_id and
	 * oppref and rejects everything else — in particular it has no user object,
	 * and OpenAI's docs forbid putting personal data in the query string, so no
	 * Advanced Matching is attached.
	 *
	 * The event_id is the one the browser and the Conversions API use, so if the
	 * page later runs JS the two firings deduplicate against each other.
	 */
	public function outputNoScriptEvents() {

		if ( !$this->configured() || !Consent()->checkConsent( 'openai' ) ) {
			return;
		}

		$eventsManager = PYS()->getEventsManager();

		if ( !$eventsManager ) {
			return;
		}

		$staticEvents = $eventsManager->getStaticEvents( $this->getSlug() );

		if ( empty( $staticEvents ) ) {
			return;
		}

		$oppref = Helpers\pys_openai_get_click_id();

		foreach ( $staticEvents as $events ) {
			foreach ( $events as $event ) {

				if ( ( $event[ 'name' ] ?? '' ) !== 'page_viewed' ) {
					continue;
				}

				$data = $event[ 'params' ][ 'data' ] ?? array();

				if ( empty( $data[ 'type' ] ) ) {
					continue;
				}

				foreach ( (array) ( $event[ 'pixelIds' ] ?? array() ) as $pixelID ) {

					$args = array(
						'pid'   => $pixelID,
						'event' => $event[ 'name' ],
					);

					foreach ( $data as $field => $value ) {
						// contents[] has to travel as a JSON array in one parameter;
						// bracketed sub-parameters are rejected as unknown.
						$args[ 'data[' . $field . ']' ] = is_array( $value ) ? wp_json_encode( $value ) : $value;
					}

					if ( !empty( $event[ 'eventID' ] ) ) {
						$args[ 'event_id' ] = $event[ 'eventID' ];
					}

					if ( $oppref !== '' ) {
						$args[ 'oppref' ] = $oppref;
					}

					$src = 'https://bzr.openai.com/v1/sdk/events?' . http_build_query( $args, '', '&', PHP_QUERY_RFC3986 );

					echo '<noscript><img height="1" width="1" style="display:none" alt="" src="' . esc_url( $src ) . '"></noscript>' . "\r\n";
				}
			}
		}
	}


	/**
	 * Is the pixel in OpenAI's restricted mode — firing, but opted out of
	 * user-level personalisation?
	 *
	 * @return bool
	 */
	public function getConsentMode() {
		return (bool) apply_filters( 'pys_openai_consent_mode', false );
	}

	/**
	 * @return bool
	 */
	public function isServerApiEnabled() {
		return (bool) $this->getOption( 'use_server_api' );
	}

	/**
	 * Does the server copy of this event have to come from the browser?
	 *
	 * @param SingleEvent $event
	 * @return bool
	 */
	public function serverCopyNeedsBrowser( $event ) {

		if ( !$this->isServerApiEnabled() || !PYS()->getOption( 'server_event_use_ajax' ) ) {
			return false;
		}

		return $this->hasDynamicValue( $event->params );
	}

	/**
	 * Is there a {value, selector, dynamic} anywhere in here?
	 *
	 * @param mixed $value
	 * @return bool
	 */
	private function hasDynamicValue( $value ) {

		if ( !is_array( $value ) ) {
			return false;
		}

		if ( !empty( $value[ 'dynamic' ] ) && !empty( $value[ 'selector' ] ) ) {
			return true;
		}

		foreach ( $value as $nested ) {
			if ( $this->hasDynamicValue( $nested ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Conversions API keys, indexed by pixel id.
	 *
	 * @return array
	 */
	public function getApiTokens() {

		$tokens = array();
		$pixel_ids = (array) $this->getOption( 'pixel_id' );

		if ( count( $pixel_ids ) > 0 && $this->isServerApiEnabled() ) {
			$server_tokens = (array) $this->getOption( 'server_access_api_token' );
			$tokens[ $pixel_ids[ 0 ] ] = reset( $server_tokens );
		}

		// Each additional pixel is a separate ad account with its own Conversions
		// API key, kept in SPPixelId's declared server_access_api_token field — the
		// slot the OpenAI Super Pack UI renders. extensions['api_token'] is a
		// Facebook-only convention and is read only as a fallback, so a value there
		// can never shadow what the UI shows.
		foreach ( $this->getAdditionalPixels() as $_pixel ) {

			if ( !$_pixel->isUseServerApi ) {
				continue;
			}

			if ( !empty( $_pixel->server_access_api_token ) ) {
				$tokens[ $_pixel->pixel ] = $_pixel->server_access_api_token;
			} elseif ( is_array( $_pixel->extensions ) && !empty( $_pixel->extensions[ 'api_token' ] ) ) {
				$tokens[ $_pixel->pixel ] = $_pixel->extensions[ 'api_token' ];
			}
		}

		return $tokens;
	}

	/**
	 * Send events with validate_only, so OpenAI checks the payload without storing it.
	 *
	 * @return bool
	 */
	public function isValidateOnly() {
		return (bool) $this->getOption( 'server_validate_only' );
	}

	public function getLog() {
		return $this->logger;
	}
}

/**
 * @return OpenAI
 */
function OpenAI() {
	return OpenAI::instance();
}

OpenAI();
