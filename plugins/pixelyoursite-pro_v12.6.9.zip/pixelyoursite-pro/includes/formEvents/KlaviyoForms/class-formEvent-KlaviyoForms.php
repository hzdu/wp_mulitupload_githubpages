<?php
namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Klaviyo sign-up forms as a form trigger.
 *
 * Klaviyo forms are rendered and submitted by Klaviyo's own script: WordPress
 * never sees the submission, so there is no server-side hook here and no
 * FormSubmissionHandler entry. The front end listens for the `klaviyoForms`
 * window event (type 'submit') in public.js and fires from there.
 *
 * The forms themselves are not stored in WordPress either. Klaviyo serves every
 * live form of an account from a public, unauthenticated endpoint keyed by the
 * account's public key -- the same key klaviyo.js is loaded with, which the
 * Klaviyo plugin keeps in its own option. getForms() reads that list so the
 * trigger offers a normal select. The endpoint is undocumented, so when it
 * fails the trigger degrades to typing the six-character form ID by hand
 * (the select accepts free text for this plugin).
 */
class FormEventKlaviyoForms extends Settings implements FormEventsFactory {

    const FORMS_ENDPOINT = 'https://static-forms.klaviyo.com/forms/api/v7/%s/full-forms';

    /** A good answer is kept for an hour: the admin page is the only reader. */
    const CACHE_TTL = 3600;

    /**
     * A failed fetch is remembered briefly, so an outage does not add a
     * 5-second remote call to every load of the event editor.
     */
    const CACHE_TTL_ERROR = 300;

    private static $_instance;

    public static function instance() {

        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }

        return self::$_instance;

    }

    public function __construct() {
        parent::__construct( 'KlaviyoForms' );

        $this->locateOptions(
            PYS_PATH . '/includes/formEvents/options_fields.json',
            PYS_PATH . '/includes/formEvents/options_defaults.json'
        );

        if ( $this->isActivePlugin() ) {
            add_filter( "pys_form_event_factory", [ $this, "register" ] );
        }
    }

    function register( $list ) {
        $list[] = $this;
        return $list;
    }

    public function getSlug() {
        return "klaviyo_forms";
    }

    public function getName() {
        return "Klaviyo Forms";
    }

    function isEnabled() {
        return $this->getOption( 'enabled' );
    }

    function isActivePlugin() {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        }

        return is_plugin_active( 'klaviyo/klaviyo.php' );
    }

    /**
     * The account's public key (Klaviyo also calls it the Site ID): six
     * alphanumerics, read from the Klaviyo plugin's own option so the two can
     * never disagree. Anything else -- including a private key pasted into the
     * wrong field -- is treated as "no key" and never leaves the server.
     *
     * @return string '' when there is no usable key.
     */
    public static function getPublicKey() {
        $settings = get_option( 'klaviyo_settings' );
        $key = is_array( $settings ) && isset( $settings['klaviyo_public_api_key'] )
            ? trim( (string) $settings['klaviyo_public_api_key'] )
            : '';

        return preg_match( '/^[A-Za-z0-9]{6}$/', $key ) ? $key : '';
    }

    /**
     * Live forms of the account: id => label. Empty without a key, and empty
     * (briefly cached) when Klaviyo does not answer -- the select then still
     * accepts a typed form ID.
     *
     * @return array<string, string>
     */
    function getForms() {
        $key = self::getPublicKey();

        if ( '' === $key ) {
            return array();
        }

        $cache_key = 'pys_klaviyo_forms_' . $key;
        $cached    = get_transient( $cache_key );

        if ( is_array( $cached ) ) {
            return $cached;
        }

        $forms = array();
        $ttl   = self::CACHE_TTL_ERROR;

        $response = wp_safe_remote_get( sprintf( self::FORMS_ENDPOINT, rawurlencode( $key ) ), array(
            'timeout' => 5,
        ) );

        if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
            $parsed = self::parseFormsResponse( wp_remote_retrieve_body( $response ) );

            if ( null !== $parsed ) {
                $forms = $parsed;
                $ttl   = self::CACHE_TTL;
            }
        }

        set_transient( $cache_key, $forms, $ttl );

        return $forms;
    }

    /**
     * Turns the full-forms body into id => label. Only forms with a live
     * version are listed: a draft is never rendered by klaviyo.js, so it can
     * never fire. The label carries the form type because an account usually
     * has the same sign-up as an embed and as a popup under two IDs.
     *
     * @param string $body Raw response body.
     * @return array<string, string>|null null when the body is not the
     *                                    expected shape (as opposed to an
     *                                    account with no live forms).
     */
    public static function parseFormsResponse( $body ) {
        $data = json_decode( (string) $body, true );

        if ( ! is_array( $data ) || ! isset( $data['full_forms'] ) || ! is_array( $data['full_forms'] ) ) {
            return null;
        }

        $forms = array();

        foreach ( $data['full_forms'] as $form ) {
            if ( ! is_array( $form ) || empty( $form['form_id'] ) || ! preg_match( '/^[A-Za-z0-9]{6}$/', (string) $form['form_id'] ) ) {
                continue;
            }

            if ( empty( $form['live_form_versions'] ) || ! is_array( $form['live_form_versions'] ) ) {
                continue;
            }

            $name = isset( $form['name'] ) && '' !== trim( (string) $form['name'] ) ? trim( (string) $form['name'] ) : 'Klaviyo form';
            $type = '';

            foreach ( $form['live_form_versions'] as $version ) {
                if ( is_array( $version ) && ! empty( $version['form_type'] ) ) {
                    $type = ucfirst( strtolower( (string) $version['form_type'] ) );
                    break;
                }
            }

            $forms[ (string) $form['form_id'] ] = '' !== $type ? $name . ' (' . $type . ')' : $name;
        }

        return $forms;
    }

    /**
     * A form ID the trigger may hold even when getForms() does not list it:
     * the list lags Klaviyo by up to an hour and is empty without a key, while
     * the ID is right there in the embed code. Same rule the typed entries of
     * the admin select follow; MCP asks this before accepting an unlisted ID.
     *
     * @param mixed $id
     * @return bool
     */
    public function isValidFormId( $id ) {
        return (bool) preg_match( '/^[A-Za-z0-9]{6}$/', (string) $id );
    }

    /**
     * A trigger with no forms selected fires for every Klaviyo form. The IDs
     * are opaque and most accounts have one or two forms, so "all" is the
     * common case rather than a mistake.
     *
     * @return bool
     */
    public function allowsEmptyForms() {
        return true;
    }

    /**
     * Klaviyo never reloads the page, so 'reload_only' can never fire and is
     * not offered; the admin panel hides the choice, MCP rejects it.
     *
     * @return string[]
     */
    public function getFormSubmitModes() {
        return array( 'both', 'ajax_only' );
    }

    /**
     * What an integrator (the MCP client) needs to know about this list.
     *
     * @return string
     */
    public function getFormListNote() {
        $key = self::getPublicKey();

        return ( '' !== $key
                ? 'Published forms of the Klaviyo account ' . $key . ' (public key from the Klaviyo plugin settings), refreshed hourly.'
                : 'The Klaviyo plugin has no public API key yet, so the account forms cannot be listed.' )
            . ' Any six-character form ID (the XXXXXX in the embed code klaviyo-form-XXXXXX) is accepted even when not listed.'
            . ' An empty `forms` list means every Klaviyo form.'
            . ' The event fires when Klaviyo reports a successful submission; there is no page reload, so `reload_only` is not a valid form_submit_mode.';
    }

    function getOptions() {
        return array(
            "name"          => $this->getName(),
            "enabled"       => $this->getOption( "enabled" ),
            "form_ID_event" => $this->getOption( "form_ID_event" )
        );
    }

    /**
     * Klaviyo renders its inputs without names, so there is nothing for the
     * blur-based advanced-matching capture to match. The submit listener in
     * public.js takes email and phone from the event's metaData instead.
     */
    function getDefaultMatchingInput() {
        return array(
            "first_name" => array(),
            "last_name"  => array(),
            "tel"        => array()
        );
    }
}

/**
 * @return FormEventKlaviyoForms
 */
function FormEventKlaviyoForms() {
    return FormEventKlaviyoForms::instance();
}

FormEventKlaviyoForms();
