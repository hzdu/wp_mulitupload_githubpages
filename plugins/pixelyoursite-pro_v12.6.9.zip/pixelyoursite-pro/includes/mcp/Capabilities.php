<?php
/**
 * Capability checks for MCP tools (pure reads): `isPro()`, `isReadOnly()`,
 * `isWriteAllowed()` (= isPro && !isReadOnly) and the external-access gate
 * (`isAccessAllowedInThisContext()`). Used by ability permission callbacks,
 * the error envelopes, and the settings UI.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

use function PixelYourSite\PYS;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class Capabilities {

	/**
	 * PYS Settings option key for the read-only toggle. Stored in
	 * `wp_pys_options` like every other PYS setting and registered in
	 * `McpServer::boot()` on `init` priority 11 (after PYS loads its schema).
	 */
	public const OPTION_READ_ONLY_ENABLED = 'mcp_read_only_enabled';

	/**
	 * PYS Settings option key for the "Other MCP servers" toggle: may abilities
	 * be used outside our own MCP endpoint? Default off. Registered alongside
	 * the read-only option.
	 */
	public const OPTION_EXTERNAL_ACCESS_ENABLED = 'mcp_external_access_enabled';

	/**
	 * WP capability every ability requires from the current user — the same
	 * one that gates the PYS admin pages and the site-profile REST routes.
	 */
	public const REQUIRED_CAPABILITY = 'manage_pys';

	/** WP capability for WooCommerce/EDD reports data, on top of the one above. */
	public const REPORTS_CAPABILITY = 'manage_pys_reports';

	/**
	 * Does the current user hold the capability every ability requires?
	 * On our own endpoint `Auth::verify()` sets the token owner as the current
	 * user, but when external access is allowed abilities are also usable by
	 * other MCP servers on the site and by the core abilities REST API, whose
	 * transports only require `read`. The capability therefore has to be
	 * enforced here, in the ability itself.
	 *
	 * @return bool
	 */
	public static function currentUserCanManage(): bool {
		return is_user_logged_in() && current_user_can( self::REQUIRED_CAPABILITY );
	}

	/**
	 * Are we running as the Pro variant? True when PYS Pro is loaded and PYS
	 * Free is not active. Wrapped in one place so future tier checks extend
	 * here rather than scattering across write tools.
	 *
	 * @return bool
	 */
	public static function isPro(): bool {
		if ( !defined( 'PYS_PRO_PLUGIN_FILE' ) ) {
			return false;
		}
		if ( function_exists( 'isPysFreeActive' ) && \isPysFreeActive() ) {
			return false;
		}

		return true;
	}

	/**
	 * Has the admin enabled read-only mode? When on, read tools work and
	 * write tools return the `Read-only mode is enabled.` envelope, letting a
	 * site owner run audit-only sessions. Default false — the per-field write
	 * guards already cover the irreversible cases.
	 *
	 * @return bool
	 */
	public static function isReadOnly(): bool {
		if ( !function_exists( '\\PixelYourSite\\PYS' ) ) {
			return false;
		}

		return self::toBool( \PixelYourSite\PYS()->getOption( self::OPTION_READ_ONLY_ENABLED, false ) );
	}

	/**
	 * Toggle read-only mode via `PYS()->updateOptions()`. Returns false if
	 * PYS Pro isn't loaded (defensive — the AJAX handler is already gated).
	 *
	 * @param bool $enabled Whether read-only mode should be on.
	 * @return bool True on success, false if PYS isn't loaded.
	 */
	public static function setReadOnly( bool $enabled ): bool {
		if ( !function_exists( '\\PixelYourSite\\PYS' ) ) {
			return false;
		}
		\PixelYourSite\PYS()->updateOptions( array( self::OPTION_READ_ONLY_ENABLED => $enabled ) );

		return true;
	}

	/**
	 * Has the admin allowed abilities to be used outside our own MCP endpoint
	 * (the official MCP Adapter, other plugins' MCP servers, the core
	 * abilities REST API)? Fails closed: false when PYS isn't loaded or the
	 * option is missing.
	 *
	 * @return bool
	 */
	public static function isExternalAccessAllowed(): bool {
		if ( !function_exists( '\\PixelYourSite\\PYS' ) ) {
			return false;
		}

		return self::toBool( PYS()->getOption( self::OPTION_EXTERNAL_ACCESS_ENABLED, false ) );
	}

	/**
	 * Toggle external access via `PYS()->updateOptions()`. Returns false if
	 * PYS Pro isn't loaded.
	 *
	 * @param bool $enabled Whether other MCP servers may use the abilities.
	 * @return bool True on success, false if PYS isn't loaded.
	 */
	public static function setExternalAccessAllowed( bool $enabled ): bool {
		if ( !function_exists( '\\PixelYourSite\\PYS' ) ) {
			return false;
		}
		PYS()->updateOptions( array( self::OPTION_EXTERNAL_ACCESS_ENABLED => $enabled ) );

		return true;
	}

	/**
	 * Is the current ability call coming through a channel PYS controls?
	 *  - our MCP endpoint: `Auth::verify()` ran and set the active token;
	 *  - WP-CLI: an operator-level shell (`wp ability run`, `wp mcp`).
	 * Everything else is external: the official MCP Adapter, other plugins'
	 * MCP servers, the `wp-abilities/v1` REST API, admin-ajax, cron and
	 * direct PHP calls.
	 *
	 * @return bool
	 */
	public static function isTrustedContext(): bool {
		if ( null !== Auth::activeTokenId() ) {
			return true;
		}

		return defined( 'WP_CLI' ) && WP_CLI;
	}

	/**
	 * May an ability call proceed in the current context at all? Checked
	 * first by every ability's permission callback.
	 *
	 * @return bool
	 */
	public static function isAccessAllowedInThisContext(): bool {
		return self::isTrustedContext() || self::isExternalAccessAllowed();
	}

	/**
	 * Are writes allowed in the current call? Used by every write-ability's
	 * `permission_callback`; false makes the adapter return the `Pro
	 * required.` envelope.
	 *
	 * @return bool
	 */
	public static function isWriteAllowed(): bool {
		return self::isPro() && !self::isReadOnly();
	}

	/**
	 * Normalize raw option value to boolean. wp_pys_options stores checkbox
	 * values as `'1'` / `'0'` strings; some callers may pass real booleans.
	 *
	 * @param mixed $value Raw option value.
	 * @return bool
	 */
	private static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === $value;
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}
