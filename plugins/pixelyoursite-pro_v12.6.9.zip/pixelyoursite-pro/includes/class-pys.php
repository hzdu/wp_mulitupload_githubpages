<?php

namespace PixelYourSite;
use Jaybizzle\CrawlerDetect\CrawlerDetect;
use function PixelYourSite\Events\getGaPixels;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * PixelYourSite Core class.
 */
final class PYS extends Settings implements Plugin {

    private static $_instance;

    private $form_track;

    /** @var $eventsManager EventsManager */
    private $eventsManager;

    /** @var $registeredPixels array Registered pixels */
    private $registeredPixels = array();

    /** @var $registeredPlugins array Registered plugins */
    private $registeredPlugins = array();

    /** @var $updateCheckersRegistered bool Update checkers are registered once per request */
    private $updateCheckersRegistered = false;

    private $adminPagesSlugs = array();

    private $externalId;
    /**
     * @var PYS_Logger
     */
    private $logger;

    private $containers;

    private $crawlerDetect;

	public $general_domain = '';

    private $pixels_loaded = false;

	public static function instance() {

        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }

        return self::$_instance;

    }

    public function getPluginName() {
        return PYS_PLUGIN_NAME;
    }

    public function getPluginFile() {
        return PYS_PRO_PLUGIN_FILE;
    }

    public function getPluginVersion() {
        return PYS_VERSION;
    }

    public function getPluginIcon() {
        return PYS_PLUGIN_ICON;
    }

    public function __construct() {

        add_filter( 'plugin_row_meta', array( $this, 'pluginRowMeta' ), 10, 2 );
        // initialize settings
        parent::__construct( 'core' );

        /**
         * Update checks must be registered outside of the admin context as well.
         * Hooked on 'admin_init' they never ran under WP-CLI ("wp plugin list",
         * "wp plugin update") nor during WordPress background auto-updates (wp-cron),
         * so our plugins looked like they had no updates available there.
         *
         * Priority 10 on 'init': self::init() runs at priority 9 and fires
         * 'pys_register_plugins', so $registeredPlugins is filled by then.
         */
        add_action( 'init', array( $this, 'updatePlugin' ), 10 );

        /**
         * REST API requests (remote management tools read the list of updates over
         * them) can not be told apart from front-end ones on 'init': the route is
         * only resolved on 'parse_request'. Priority 9 because rest_api_loaded()
         * serves the request at priority 10 and dies.
         */
        add_action( 'parse_request', array( $this, 'updatePlugin' ), 9 );
        add_action( 'admin_init', 'PixelYourSite\manageAdminPermissions' );
        add_action( 'admin_init', 'PixelYourSite\pys_add_privacy_policy_content' );

        /**
         * Priority 9 used because on some events, like EDD's CompleteRegistration, are fired on 'init' action
         * with default (10) priority and PYS should be initialized before it.
         *
         * 3rd party extensions, like Pinterest addon, should be loaded with lower priority.
         */
        add_action( 'wp', array( $this, 'controllSessionStart'), 10);
        // set_pbid() is NOT hooked separately: it reads plugin options, so it must
        // run after init() has called locateOptions(). It is called from init().
        add_action( 'init', array( $this, 'init' ), 9 );
        add_action( 'init', array( $this, 'afterInit' ), 11 );

        add_action( 'admin_menu', array( $this, 'adminMenu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'adminEnqueueScripts' ) );
        add_action( 'admin_notices', 'PixelYourSite\adminRenderNotices' );
        // Registered as a closure on purpose. Easy Digital Downloads hooks
        // EDD_Notices::remove_notices() on `admin_notices` at priority 0 and strips
        // every callback whose function is a plain name without "edd" in it, and it
        // counts the WordPress Dashboard as one of its own admin pages. A closure is
        // not a named callback, so the domain block notice survives there.
        add_action( 'admin_notices', function () {
            pys_render_domain_block_admin_notices();
        } );
        add_action( 'admin_init', array( $this, 'adminProcessRequest' ), 11 );
        add_action('admin_init', function () {

            // Activate only on PixelYourSite pages
            if (
                isset($_GET['page']) &&
                strpos($_GET['page'], 'pixelyoursite') !== false
            ) {
                ob_start(function ($html) {

                    // Remove all integrity and crossorigin attributes
                    $html = preg_replace('/\s+integrity="[^"]*"/i', '', $html);
                    $html = preg_replace('/\s+crossorigin="[^"]*"/i', '', $html);

                    return $html;
                });
            }
        });

        add_action( 'woocommerce_init', array( $this, 'init_tracking_type_logic' ) );

        // run Events Manager
        add_action( 'template_redirect', array( $this, 'managePixels' ), 1);

        // REST endpoint for dynamic (user-specific) pysOptions — registered early
        // so it is available for REST API requests (before template_redirect fires).
        add_action( 'rest_api_init', array( $this, 'register_dynamic_options_route' ) );
        $this->prevent_cron_spawn_on_dynamic_options();

        // track user registrations
        add_action( 'user_register', array( $this, 'userRegisterHandler' ) );

        // track user login event
        add_action('wp_login', [$this,'userLogin'], 10, 2);

        // permission options custom sanitization functions
        add_filter( 'pys_core_settings_sanitize_admin_permissions_field', array( $this, 'sanitizeAdminPermissionsField' ) );
        add_filter( 'pys_core_settings_sanitize_woo_edd_reports_permissions_field', array( $this, 'sanitizeReportsPermissionsField' ) );
        add_filter( 'pys_core_settings_sanitize_woo_edd_export_permissions_field', array( $this, 'sanitizeExportPermissionsField' ) );

        // redirect template for generate file
        add_action( 'admin_init', array($this,'generate_event_export_json') );
        add_action( 'wp_ajax_pys_import_events', array( $this, 'import_custom_events' ) );

        add_action( 'wp_ajax_pys_get_gdpr_filters_values', array( $this, 'ajaxGetGdprFiltersValues' ) );
        add_action( 'wp_ajax_nopriv_pys_get_gdpr_filters_values', array( $this, 'ajaxGetGdprFiltersValues' ) );

        add_action( 'wp_ajax_pys_get_pbid', array( $this, 'get_pbid_ajax' ) );
        add_action( 'wp_ajax_nopriv_pys_get_pbid', array( $this, 'get_pbid_ajax' ) );

        add_action('wp_ajax_get_variation_info', array( $this, 'get_variation_info'));
        add_action('wp_ajax_nopriv_get_variation_info', array( $this, 'get_variation_info'));


        /*
         * Restore settings after COG plugin
         * */
        add_action( 'deactivate_pixel-cost-of-goods/pixel-cost-of-goods.php',array($this,"restoreSettingsAfterCog"));

        /**
         * For Woo
         */
        add_action("woocommerce_checkout_order_processed",array($this,'woo_checkout_process'),10,3);
        // Classic hook for checkout page
        add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'saveExternalIDInOrder' ), 10, 1 );
        // Hook for Store API (passes WC_Order object instead of order_id)
        add_action( 'woocommerce_store_api_checkout_update_order_meta', array( $this, 'saveExternalIDInOrder' ), 10, 1 );
        // The buyer's Consent Mode choice, for the order's server events
        add_action( 'woocommerce_checkout_update_order_meta', __NAMESPACE__ . '\pys_save_consent_in_woo_order', 10, 1 );
        add_action( 'woocommerce_store_api_checkout_update_order_meta', __NAMESPACE__ . '\pys_save_consent_in_woo_order', 10, 1 );

        /*
         * Remember which orders this visitor created, so the purchase event still
         * fires when a payment gateway returns them without the order key.
         * See pysWooRequestCanAccessOrder() in includes/functions-woo.php.
         */
        add_action( 'woocommerce_checkout_order_processed', array( $this, 'woo_remember_session_order' ), 10, 1 );
        add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'woo_remember_session_order' ), 10, 1 );
        add_action( 'woocommerce_new_order', array( $this, 'woo_remember_session_order' ), 10, 1 );

        /**
         * For EDD
         */
        // Hook for EDD payment insertion to save external_id
        add_action( 'edd_insert_payment', array( $this, 'saveExternalIDInEddOrder' ), 10, 2 );
        add_action( 'edd_insert_payment', __NAMESPACE__ . '\pys_save_client_signals_in_edd_order', 10, 1 );
        add_action( 'edd_anonymize_payment', __NAMESPACE__ . '\pys_anonymize_edd_order_snapshots', 10, 1 );
        add_action( 'edd_insert_payment', __NAMESPACE__ . '\pys_save_consent_in_edd_order', 10, 1 );

        /**
         * Send Server Events
         * Note: Server events are now handled by ServerEventsManager class
         * @see includes/server/class-server-events-manager.php
         */

        // Defer cron event scheduling until full initialization
        add_action( 'init', function() {
            if( ! wp_next_scheduled( 'license_check_event' ) ) {
                wp_schedule_event( time(), 'daily', 'license_check_event');
            }
        }, 20);
        add_action('license_check_event', array( $this, 'cronCheckLicense'));
        add_action( 'woocommerce_checkout_create_order_line_item', array( $this,'add_list_name_to_order_items'), 10, 4 );

        // Filter to remove PYS metadata from WooCommerce REST API order responses
        add_filter( 'woocommerce_rest_prepare_shop_order_object', array( $this, 'remove_pys_metadata_from_rest_api' ), 10, 3 );

        $this->logger = new PYS_Logger();
        $this->crawlerDetect = new CrawlerDetect();
        $this->containers = new gtmContainers();

        // $general_domain is NOT resolved here: it needs
        // getOption( 'track_cookie_for_subdomains' ), and options only have
        // their defaults after locateOptions() runs inside init(). Assigned on
        // 'init' priority 20; prefer pys_cookie_domain() over the property.
    }

    public function init() {
        $this->logger->init();

        if (current_user_can( 'manage_pys' ) ) {

            $loggers = [
                'general' => [$this->logger, 'downloadLogFile'],
                'meta' => [Facebook()->getLog(), 'downloadLogFile'],
                'ga' => [GA()->getLog(), 'downloadLogFile'],
                'tiktok' => [Tiktok()->getLog(), 'downloadLogFile'],
                'openai' => [OpenAI()->getLog(), 'downloadLogFile'],
            ];


            $clearLoggers = [
                'clear_general_logs' => [$this->logger, 'remove'],
                'clear_meta_logs' => [Facebook()->getLog(), 'remove'],
                'clear_ga_logs' => [GA()->getLog(), 'remove'],
                'clear_tiktok_logs' => [Tiktok()->getLog(), 'remove'],
                'clear_openai_logs' => [OpenAI()->getLog(), 'remove']
            ];

            if (isPinterestActive() && class_exists('PixelYourSite\Pinterest')){
                $loggers['pinterest'] = [Pinterest()->getLog(), 'downloadLogFile'];
                $clearLoggers['clear_pinterest_logs'] = [Pinterest()->getLog(), 'remove'];
            }

            if (isset($_GET['download_logs']) && array_key_exists($_GET['download_logs'], $loggers)) {
                if (!isset($_GET['_wpnonce_download_logs']) || !wp_verify_nonce($_GET['_wpnonce_download_logs'], 'download_logs_nonce')) {
                    wp_die(__('Invalid nonce', 'pys'));
                }
                $logger = $loggers[$_GET['download_logs']];
                if (is_callable($logger)) {
                    call_user_func($logger);
                } elseif (is_callable([$logger[0], $logger[1]])) {
                    call_user_func([$logger[0], $logger[1]]);
                }
            }

            foreach ($clearLoggers as $key => $logger) {
                if (isset($_GET[$key]) && (is_callable($logger) || (is_callable([$logger[0], $logger[1]]) && method_exists($logger[0], $logger[1])))) {
                   if (!isset($_GET['_wpnonce_clear_logs']) || !wp_verify_nonce($_GET['_wpnonce_clear_logs'], 'clear_logs_nonce')) {
                        wp_die(__('Invalid nonce', 'pys'));
                    }
                    if (is_callable($logger)) {
                        call_user_func($logger);
                    } else {
                        call_user_func([$logger[0], $logger[1]]);
                    }
                    $actual_link = pys_get_request_protocol() . "$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                    wp_redirect(remove_query_arg($key, $actual_link));
                    exit;
                }
            }

            if (isset($_GET['download_container'])) {
                if (!isset($_GET['_wpnonce_template_logs']) || !wp_verify_nonce($_GET['_wpnonce_template_logs'], 'download_template_nonce')) {
                    wp_die(__('Invalid nonce', 'pys'));
                }
                $this->containers->downloadContainerFile($_GET['download_container']);
            }
        }

        $db = new \PixelYourSite\DataBaseManager();
        $db->create_table();

        register_post_type( 'pys_event', array(
            'public' => false,
            'supports' => array( 'title' )
        ) );

        // initialize options
        $this->locateOptions(
            PYS_PATH . '/includes/options_fields.json',
            PYS_PATH . '/includes/options_defaults.json'
        );

        // $general_domain is kept for backwards compatibility only. Populated
        // on 'init' priority 20, not here, so a pys_cookie_domain_override
        // filter registered on 'init' still applies before the resolver
        // memoises its answer.
        add_action( 'init', function () {
            $this->general_domain = pys_cookie_domain();
        }, 20 );

        // Agency Mode: at 20, so the add-ons loaded on 'init' at 10 have already
        // registered the relays this takes over.
        add_action( 'init', 'PixelYourSite\\pys_close_addon_event_relays', 20 );

        // Meta wants the param builder initialised before fbevents.js, so the
        // pixel finds _fbp already present instead of minting its own. No-op
        // unless the pys_use_capi_param_builder filter turns it on.
        add_action( 'init', array( 'PixelYourSite\ParamBuilderAdapter', 'boot' ), 21 );

        // Opt-in (Meta setting first_request_cookies): _fbp / _fbc in the first
        // HTML response, for anything that reads them before our script runs.
        add_action( 'init', array( 'PixelYourSite\ServerEventHelper', 'writeFirstRequestCookies' ), 22 );

        // external_id must be resolved as early as possible, but only once the
        // options above are available, otherwise send_external_id reads as null.
        $this->set_pbid();

        // register pixels and plugins (add-ons)
        do_action( 'pys_register_pixels', $this );
        do_action( 'pys_register_plugins', $this );

        // load dummy Pinterest plugin for admin UI
        if ( ! array_key_exists( 'pinterest', $this->registeredPlugins ) ) {
            /** @noinspection PhpIncludeInspection */
            require_once PYS_PATH . '/modules/pinterest/pinterest.php';
        }

        // load dummy Bing plugin for admin UI
        if ( ! array_key_exists( 'bing', $this->registeredPlugins ) ) {
            /** @noinspection PhpIncludeInspection */
            require_once PYS_PATH . '/modules/bing/bing.php';
        }

	    // load dummy Reddit plugin for admin UI
	    if ( ! array_key_exists( 'reddit', $this->registeredPlugins ) ) {
		    /** @noinspection PhpIncludeInspection */
		    require_once PYS_PATH . '/modules/reddit/reddit.php';
	    }

        // maybe disable Facebook for WooCommerce pixel output
        if ( isWooCommerceActive()
            && array_key_exists( 'facebook', $this->registeredPixels ) && Facebook()->configured() ) {
            add_filter( 'facebook_for_woocommerce_integration_pixel_enabled', '__return_false' );
        }



        if(Facebook()->getOption('test_api_event_code_expiration_at'))
        {
            foreach (Facebook()->getOption('test_api_event_code_expiration_at') as $key => $test_code_expiration_at)
            {
                if(time() >= $test_code_expiration_at)
                {
                    Facebook()->updateOptions(array("test_api_event_code" => array()));
                    Facebook()->updateOptions(array("test_api_event_code_expiration_at" => array()));
                }
            }
        }

        if(Tiktok()->getOption('test_api_event_code_expiration_at'))
        {
            foreach (Tiktok()->getOption('test_api_event_code_expiration_at') as $test_code_expiration_at)
            {
                if(time() >= $test_code_expiration_at)
                {
                    Tiktok()->updateOptions(array("test_api_event_code" => array()));
                    Tiktok()->updateOptions(array("test_api_event_code_expiration_at" => array()));
                }
            }
        }

        if(isWPMLActive()){
            foreach ($this->getRegisteredPixels() as $pixel) {
                if($pixel->issetOption('woo_wpml_language') &&  empty($pixel->getOption('woo_wpml_language'))){
                    if (function_exists('wpml_get_default_language')) {
                        $default_language = wpml_get_default_language();
                    } else {
                        $default_language = apply_filters('wpml_default_language', NULL);
                    }
                    $pixel->updateOptions(array('woo_wpml_language' => $default_language));
                }
            }
        }

        $eventsFormFactory = apply_filters("pys_form_event_factory",[]);
        if(!$eventsFormFactory)
        {
            // Check current option value before updating to avoid unnecessary database updates
            $current_value = $this->getOption('enable_success_send_form');
            if($current_value !== false)
            {
                $options = array(
                    'enable_success_send_form'     => false
                );
                PYS()->updateOptions($options);
            }
        }

        if (isRealCookieBannerPluginActivated()) {

            add_action('RCB/Templates/TechnicalHandlingIntegration', function ( $integration ) {

                $this->handle_rcb_integration($integration, Facebook()->configured(), 'facebook-pixel', PYS_PRO_PLUGIN_FILE);
                $this->handle_rcb_integration($integration, GA()->configured(), 'google-analytics-analytics-4', PYS_PRO_PLUGIN_FILE);
                $this->handle_rcb_integration($integration, Ads()->configured(), 'google-ads-conversion-tracking', PYS_PRO_PLUGIN_FILE);
                $this->handle_rcb_integration($integration, Tiktok()->configured(), 'tik-tok-pixel', PYS_PRO_PLUGIN_FILE);
                if(isPinterestActive()){
                    $this->handle_rcb_integration($integration, Pinterest()->configured(), 'pinterest-tag', PYS_PINTEREST_PLUGIN_FILE);
                }
                if(isBingActive()){
                    $this->handle_rcb_integration($integration, Bing()->configured(), 'bing-ads', PYS_BING_PLUGIN_FILE);
                }



            });
        }
        EnrichOrder()->init();
        AjaxHookEventManager()->addHooks();
        new FormSubmissionHandler();
    }
    private function handle_rcb_integration( $integration, $is_active, $type, $plugin_dir) {

        if (
            $is_active
            && $integration->integrate($plugin_dir, $type)
        ) {
            $integration->setCodeOptIn('');
            $integration->setCodeOptOut('');
        }
    }
	function controllSessionStart(){

        if(PYS()->getOption('session_disable') || $this->is_user_agent_bot()) return;

        if (is_admin() || PHP_SAPI === 'cli' || session_status() === PHP_SESSION_DISABLED) return;

        // Nothing on these requests renders the PYS front end or reads the visit
        // data, so a session there would only cost a PHPSESSID cookie — which some
        // page caches take as a reason to stop serving cached pages — and a session
        // file nobody ever looks at.
        if ($this->shouldSkipSession()) return;

        // Another plugin already opened the session — reuse it, exactly as before.
        if (session_status() === PHP_SESSION_ACTIVE) {
            $this->populateSessionVisitData();
            return;
        }

        if (headers_sent()) return;

        if ($this->shouldOpenSessionReadOnly()) {
            /*
             * PHP holds an exclusive lock on the session for the whole request,
             * and this hook runs on 'wp', which fires for ?wc-ajax= requests too
             * (WooCommerce dispatches those on 'template_redirect'). A slow
             * request therefore serialised every other AJAX call on the page —
             * on a FunnelKit checkout that showed up as seconds of "session lock"
             * while an order bump was being added.
             *
             * read_and_close loads the data and releases the lock immediately:
             * $_SESSION stays populated for reading, so every consumer below
             * behaves the same, and session_status() goes back to NONE, so any
             * plugin that needs to write can open the session itself.
             *
             * Writing is deliberately skipped here: it would not persist. The
             * visit data is written on the page request that opened the session,
             * and every reader has a cookie fallback anyway.
             */
            @session_start(array('read_and_close' => true));
            return;
        }

        if (!session_start()) return;
        if (session_status() !== PHP_SESSION_ACTIVE) return;

        $this->populateSessionVisitData();
    }

    /**
     * Should the session be opened read-only for this request?
     *
     * True for requests we do not own and only ever read from: WooCommerce's
     * ?wc-ajax= endpoints, admin-ajax, and the REST API.
     *
     * @return bool
     */
    private function shouldOpenSessionReadOnly() {

        $read_only = false;

        if (!empty($_GET['wc-ajax'])) {
            $read_only = true;
        } elseif (defined('WC_DOING_AJAX') && WC_DOING_AJAX) {
            $read_only = true;
        } elseif (defined('REST_REQUEST') && REST_REQUEST) {
            $read_only = true;
        } elseif (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
            $read_only = true;
        }

        /**
         * filter pys_session_read_only
         * Escape hatch for setups that need the session writable on AJAX.
         *
         * @param bool $read_only
         */
        return (bool) apply_filters('pys_session_read_only', $read_only);
    }

    /**
     * Requests that never render the PYS front end, so nothing on them needs the
     * session at all.
     *
     * @return bool
     */
    private function shouldSkipSession() {

        $skip = is_robots()
                || is_feed()
                || is_trackback()
                || ( function_exists('is_favicon') && is_favicon() )
                || (bool) get_query_var('sitemap');

        /**
         * filter pys_skip_session
         *
         * @param bool $skip
         */
        return (bool) apply_filters('pys_skip_session', $skip);
    }

    /**
     * May this request's URL become the visitor's landing page?
     *
     * Only a page the visitor actually navigated to may. The browser fetches
     * /favicon.ico on its own and WordPress answers it; a broken <img> path falls
     * through to a WordPress 404; feed readers and oEmbed iframes are not
     * navigation either. Without this check the first such request won the
     * LandingPage slot for the whole session — populateSessionVisitData() only ever
     * writes once — and every server-side event and every order for that visitor
     * then reported it as the entry point. Verified: a bare /favicon.ico request
     * was enough to make it the landing page.
     *
     * A 404 is excluded on purpose. It is a real navigation, so the URL is not
     * meaningless, but on a standard WordPress rewrite every missing asset path
     * also ends up here, and those outnumber the genuine broken inbound links.
     * Use the filter below to record them anyway.
     *
     * @return bool
     */
    private function shouldRecordVisitData() {

        $record = ! is_404()
                  && ! is_embed()
                  && ! $this->shouldSkipSession()
                  && ( ! isset($_SERVER['REQUEST_METHOD'])
                       || strtoupper((string) $_SERVER['REQUEST_METHOD']) === 'GET' );

        /**
         * filter pys_record_visit_data
         * Escape hatch for setups where an excluded request type really is an entry
         * point (a feed-only funnel, a 404 URL used as a campaign landing page).
         *
         * @param bool $record
         */
        return (bool) apply_filters('pys_record_visit_data', $record);
    }

    /**
     * Store the visit data we keep in the PHP session.
     * Requires an active, writable session.
     */
    private function populateSessionVisitData() {

        if (!$this->shouldRecordVisitData()) return;

        if (empty($_SESSION['TrafficSource'])) {
            $_SESSION['TrafficSource'] = getTrafficSource(PYS()->getOption('visit_data_model') === "last_visit");
        }
        if (empty($_SESSION['LandingPage'])) {
            $_SESSION['LandingPage'] = pys_get_current_page_url();
        }
        if (empty($_SESSION['TrafficUtms'])) {
            $_SESSION['TrafficUtms'] = getUtms(false,PYS()->getOption('visit_data_model') === "last_visit");
        }
        if (empty($_SESSION['TrafficUtmsId'])) {
            $_SESSION['TrafficUtmsId'] = getUtmsId(false, PYS()->getOption('visit_data_model') === "last_visit");
        }
    }

	function get_pbid(){
		return $this->externalId;
	}
    function set_pbid() {
        if ( ! EventsManager::isTrackExternalId() ) {
            return;
        }

        $user = wp_get_current_user();
        if ( $user ) {
            $userExternalId = $user->get( 'external_id' );
            if ( ! empty( $userExternalId ) ) {
                $this->externalId = $userExternalId;
                return;
            }
        }

        if ( ! empty( $_COOKIE['pbid'] ) ) {
            $this->externalId = sanitize_text_field( wp_unslash( $_COOKIE['pbid'] ) );
            return;
        }

        // No cookie yet (or ever): derive the id from the request itself, so
        // the page render, the dynamic-options reply, pys_get_pbid and the
        // server events all name this browser the same way on its first
        // page view. Replaces the random mint and the IP-keyed transient,
        // which handed one id to everyone behind one address.
        $this->externalId = pys_visitor_key();
    }

    public function get_pbid_ajax(){
        if ( ! defined('DOING_AJAX') || ! DOING_AJAX ) {
            return;
        }

        if ( ! EventsManager::isTrackExternalId() ) {
            wp_send_json_error( array( 'reason' => 'external_id_disabled' ) );
        }

        // Defensive: external_id is normally set in init(), but never leave the
        // request without a reply — the caller would get admin-ajax's bare "0".
        if ( empty( $this->externalId ) ) {
            $this->set_pbid();
        }

        if ( empty( $this->externalId ) ) {
            wp_send_json_error( array( 'reason' => 'no_external_id' ) );
        }

        wp_send_json_success( array( 'pbid' => $this->externalId ) );
    }
    public function add_list_name_to_order_items( $item, $cart_item_key, $values, $order ) {

        if ( array_key_exists('item_list_name', $values )) {
            $item_list_name = $values['item_list_name'];
            $item->update_meta_data('item_list_name', $item_list_name );
        }
        if ( array_key_exists('item_list_id', $values )) {
            $item_list_id = $values['item_list_id'];
            $item->update_meta_data('item_list_id', $item_list_id );
        }
    }

    public function cronCheckLicense(){
        checkLicense();
    }
    /**
     * Extend options after post types are registered
     */
    public function afterInit() {

        // add available public custom post types to settings
        foreach ( get_post_types( array( 'public' => true, '_builtin' => false ), 'objects' ) as $post_type ) {

            // skip product post type when WC is active
            if ( isWooCommerceActive() && $post_type->name == 'product' ) {
                continue;
            }

            // skip download post type when EDD is active
            if ( isEddActive() && $post_type->name == 'download' ) {
                continue;
            }

        }

    }

    public function import_custom_events() {
        if ( ! $this->adminSecurityCheck()
            || !wp_verify_nonce($_REQUEST['_wpnonce'],"import_events_file_nonce")
        ) {
            return;
        }
        if(isset($_FILES["import_events_file"])) {
            if($_FILES["import_events_file"]['size'] == 0) {
                wp_send_json_error("File is empty ");
                return;
            }
            if( $_FILES["import_events_file"]['type'] != "application/json") {
                wp_send_json_error("File has wrong format ".$_FILES["import_events_file"]['type']);
                return;
            }
            $content = file_get_contents($_FILES["import_events_file"]['tmp_name']);
            $data = json_decode($content,true);

            if(!isset($data['events'])) {
                wp_send_json_error("Events not found");
                return;
            }

            // replace new site url
            $oldSiteUrl = str_replace("/","\/",$data["site_url"]);
            $siteUrl = str_replace("/","\/",site_url());
            $content = str_replace($oldSiteUrl,$siteUrl,$content);

            $data = json_decode(  $content,true);

            // create custom events
            foreach ($data['events'] as $event) {
                CustomEventFactory::import($event);
            }
            wp_send_json_success("OK");
        } else {
            wp_send_json_error("File not found");
        }
    }

    public function generate_event_export_json() {
        if($this->adminSecurityCheck()
            && isset($_GET['tab']) && $_GET['tab'] == "events"
            && isset($_GET['action']) && $_GET['action'] == 'export'
            && wp_verify_nonce($_REQUEST['_wpnonce'],"export_events_file_nonce")
        ) {
            include "views/html-main-events-export.php";
            die();
        }
    }

    /**
     * @param Pixel|Settings $pixel
     */
    public function registerPixel( &$pixel ) {
        // Agency Mode Hard block for this specific add-on's license (e.g. Bing,
        // Pinterest, Super Pack): keep its pixel off the front end while leaving
        // core and every other pixel — and wp-admin — untouched.
        if ( ! is_admin() && is_hard_blocked( $pixel->getSlug() ) ) {
            return;
        }
        if(!is_admin() && !PYS()->getOption('enable_all_tracking_ids') && $pixel->getSlug() != 'gtm'){
            return;
        }
	    switch ($pixel->getSlug()) {
		    case 'pinterest':
			    if(!isPinterestVersionIncompatible()){
				    $this->registeredPixels[ $pixel->getSlug() ] = $pixel;
			    }
                else{
                    $minVersion = PYS_PINTEREST_MIN_VERSION;
	                add_action( 'wp_head', function() use ($minVersion) {
		                echo "<script type='application/javascript' id='pys-pinterest-version-incompatible'>console.warn('You are using incompatible version of PixelYourSite Pinterest Add-On. PixelYourSite PRO requires at least PixelYourSite Pinterest Add-On $minVersion. Please, update to latest version.');</script>\r\n";
	                } );
                }
			    break;
		    case 'bing' :
			    if(!isBingVersionIncompatible()){
				    $this->registeredPixels[ $pixel->getSlug() ] = $pixel;
			    }
			    else{
				    $minVersion = PYS_BING_MIN_VERSION;
				    add_action( 'wp_head', function() use ($minVersion) {
					    echo "<script type='application/javascript' id='pys-bing-version-incompatible'>console.warn('You are using incompatible version of PixelYourSite Bing Add-On. PixelYourSite PRO requires at least PixelYourSite Bing Add-On $minVersion. Please, update to latest version.');</script>\r\n";
				    } );
			    }
			    break;
		    case 'superpack' :
			    if(!isSuperPackVersionIncompatible()){
				    $this->registeredPixels[ $pixel->getSlug() ] = $pixel;
			    }
			    else{
				    $minVersion = PYS_SUPER_PACK_MIN_VERSION;
				    add_action( 'wp_head', function() use ($minVersion) {
					    echo "<script type='application/javascript' id='pys-super-pack-version-incompatible'>console.warn('You are using incompatible version of PixelYourSite Super Pack Add-On. PixelYourSite PRO requires at least PixelYourSite Super Pack Add-On $minVersion. Please, update to latest version.');</script>\r\n";
				    } );
			    }
			    break;
		    default :
			    $this->registeredPixels[ $pixel->getSlug() ] = $pixel;
			    break;
	    }
    }

    /**
     * Return array of registered pixels
     *
     * @return Pixel[]
     */
    public function getRegisteredPixels() {
        return $this->registeredPixels;
    }

    /**
     * Return a single registered pixel by its slug, or null when that pixel is
     * not registered (add-on missing or an incompatible version).
     *
     * @param string $slug
     *
     * @return Pixel|Settings|null
     */
    public function getRegisteredPixel( $slug ) {
        return $this->registeredPixels[ $slug ] ?? null;
    }

    /**
     * @param Pixel|Settings $plugin
     */
    public function registerPlugin( &$plugin ) {
        $this->registeredPlugins[ $plugin->getSlug() ] = $plugin;
    }

    /**
     * Return array of registered plugins
     *
     * @return array
     */
    public function getRegisteredPlugins() {
        return $this->registeredPlugins;
    }

    /**
     * Get admin pages slugs
     *
     * @return array
     */
    public function getAdminPagesSlugs() {
        return $this->adminPagesSlugs;
    }

    /**
     * Add admin page slug
     * 
     * Usage:
     * PYS()->addAdminPageSlug('my-custom-page');
     *
     * @param string $slug
     */
    public function addAdminPageSlug( $slug ) {
        if ( ! in_array( $slug, $this->adminPagesSlugs ) ) {
            $this->adminPagesSlugs[] = $slug;
        }
    }

    /**
     * Remove admin page slug
     * 
     * Usage:
     * PYS()->removeAdminPageSlug('my-custom-page');
     *
     * @param string $slug
     */
    public function removeAdminPageSlug( $slug ) {
        $key = array_search( $slug, $this->adminPagesSlugs );
        if ( $key !== false ) {
            unset( $this->adminPagesSlugs[ $key ] );
            $this->adminPagesSlugs = array_values( $this->adminPagesSlugs );
        }
    }

    /**
     * Set admin pages slugs
     * 
     * Usage:
     * PYS()->setAdminPagesSlugs(['page1', 'page2', 'page3']);
     *
     * @param array $slugs
     */
    public function setAdminPagesSlugs( $slugs ) {
        $this->adminPagesSlugs = $slugs;
    }

    /**
     * Front-end entry point
     */
    /**
     * Fire the custom events tied to a form this visitor just submitted.
     * See the comment at the call site in managePixels() for why the marker
     * is read here and deleted only once the page has printed its events.
     */
    private function trackFormAfterReload() {
        if ( ! $this->eventsManager ) {
            return;
        }
        if ( is_404() || is_feed() || is_robots() || is_embed() || is_trackback() ) {
            return;
        }
        if ( isset( $_GET['wc-ajax'] ) || wp_doing_cron() || wp_is_json_request() ) {
            return;
        }

        $key      = FormSubmissionHandler::transientKey();
        $formData = get_transient( $key );

        if ( ! $formData ) {
            return;
        }

        $this->eventsManager->trackFormAfterReload( $formData );

        add_action( 'wp_enqueue_scripts', function () use ( $key ) {
            delete_transient( $key );
        }, 16 );
    }

    public function managePixels() {

        if ( $this->pixels_loaded ) {
            return;
        }
        $this->pixels_loaded = true;

        if (defined('DOING_AJAX') && DOING_AJAX) {
            return;
        }

        // disable Events Manager on Customizer and preview mode
        if (is_admin() || is_customize_preview() || is_preview()) {
            return;
        }

        if(isset( $_GET['pys_est'] ) && $_GET['pys_est'] === '1' && current_user_can( 'manage_pys' )){
            // Conditionally enqueue Event Setup Tool bundle on public pages
            wp_enqueue_style( 'pys_est_css', PYS_URL . '/dist/scripts/est.min.css', array(), PYS_VERSION );
            wp_enqueue_script( 'pys_est', PYS_URL . '/dist/scripts/est.min.js', array(), PYS_VERSION, true );

            // Localize script with plugin data
            wp_localize_script( 'pys_est', 'pysEstData', array(
                'pluginUrl' => PYS_URL,
                'apiUrl' => rest_url( 'pys-est/v1/' ),
                'nonce' => wp_create_nonce( 'pys_event_setup_tool' ),
                'videoScanNonce' => wp_create_nonce( 'pys_update_event' ),
                'saveEventNonce' => wp_create_nonce( 'pys_save_est_event' ),
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            ) );

            return;
        }

        // Note: We intentionally DON'T disable Events Manager for bots
        // Reasons:
        // 1. Bots don't execute JavaScript, so no actual tracking happens for them
        // 2. If we disable Events Manager for bots, cached pages won't have tracking scripts
        // 3. Real users would then get cached pages WITHOUT tracking (critical issue!)
        // 4. It's better to include tracking scripts in HTML (even for bots) to ensure
        //    cached pages always have tracking for real users
        // 5. The minimal overhead of including scripts in HTML for bots is acceptable
        //    compared to the risk of breaking tracking for real users


        // disable Events Manager on Elementor editor
        if (did_action('elementor/preview/init')
            || did_action('elementor/editor/init')
            || (isset( $_GET['action'] ) && $_GET['action'] == 'piotnetforms') // skip preview for piotnet forms plugin
        ) {
            return;
        }

        // Disable Events Manager on Divi Builder
        if (function_exists('et_core_is_fb_enabled') && et_core_is_fb_enabled()) {
            return;
        }

        if(PYS()->getOption( 'block_ip_enabled') && in_array($this->get_user_ip(), PYS()->getOption('blocked_ips')))
        {
            return;
        }

        $theme = wp_get_theme(); // gets the current theme
        if ( ('Bricks' == $theme->name || 'Bricks' == $theme->parent_theme) && isset($_GET['bricks']) && $_GET['bricks']=='run') {
            return;
        }

        // Agency Mode Hard block on the core license: stop all core front-end
        // output — including the debug console lines below. wp-admin is unaffected.
        if ( is_hard_blocked( PYS()->getSlug() ) ) {
            return;
        }

        // output debug info
        if(!PYS()->getOption( 'hide_version_plugin_in_console'))
        {
            add_action( 'wp_head', function() {
                echo "<script type='application/javascript' id='pys-version-script'>console.log('PixelYourSite PRO version " . PYS_VERSION . "');</script>\r\n";
            }, 1 );
        }

        if ( isDisabledForCurrentRole() ) {
            return;
        }

        foreach ( PYS()->getRegisteredPixels() as $pixel ) {
            /** @var Pixel|Settings $pixel */
            if ( $pixel->configured() ) {
                $pixel->checkHidePixel();
            }
        }
        // setup events
        $this->eventsManager = new EventsManager();

        // A form plugin left a marker for this visitor (FormSubmissionHandler):
        // the page that follows the submit fires the custom events tied to that
        // form. Only a page the visitor actually sees may take the marker.
        //
        // This used to run right here, on 'init', and deleted the transient as
        // soon as it read it. 'init' also fires for REST calls (our own server
        // event copies sent with sendBeacon on the submit click), wc-ajax, the
        // 404 for a missing asset and so on — whichever of those arrived first
        // consumed the marker, its events went into a response nobody renders,
        // and the Purchase never reached the thank-you page.
        //
        // Now the marker is read here, on template_redirect, where the query is
        // known, and it is deleted only after the events have been printed:
        // outputData() runs on wp_enqueue_scripts at 15, the delete at 16. A
        // REST call never reaches template_redirect, wc-ajax exits at priority
        // 0, a redirecting gate page never gets to wp_enqueue_scripts — so the
        // marker survives all of them for the real page.
        $this->trackFormAfterReload();

        if ( ! Facebook()->configured() && ! GA()->configured() && ! Ads()->configured()
            && ! Pinterest()->configured() && ! Bing()->configured() && ! Tiktok()->configured() ) {
            if(!PYS()->getOption( 'hide_version_plugin_in_console')) {
                add_action('wp_head', function () {
                    echo "<script type='application/javascript' id='pys-config-warning-script'>console.warn('PixelYourSite PRO: no pixel configured.');</script>\r\n";
                });
            }
            return;

        }



    }

    /**
     * The visitor's address, for local bookkeeping.
     *
     * Resolved by pys_resolve_client_ip() (see functions-client-ip.php). A
     * private address is fine here: the callers are blocked_ips and
     * rate-limit keys. Anything sent to an ad platform as client_ip_address
     * must use pys_client_ip_for_capi(), which returns '' instead of an
     * address that cannot match. The visitor id (pys_visitor_key()) reads
     * pys_resolve_client_ip() directly.
     *
     * @return string
     */
    function get_user_ip() {
        $ip = pys_resolve_client_ip( $_SERVER, false );

        if ( '' === $ip ) {
            return (string) apply_filters( 'pys_client_ip', '127.0.0.1', 'fallback' );
        }

        /**
         * Filters the resolved client IP address.
         *
         * Allows site owners to override IP detection, e.g. to validate that
         * CF-Connecting-IP was received through a real Cloudflare node.
         *
         * @param string $ip     Resolved IP address.
         * @param string $header Kept for backwards compatibility; now always 'resolved'.
         */
        return (string) apply_filters( 'pys_client_ip', $ip, 'resolved' );
    }

    function is_user_agent_bot(){
        if (!PYS()->getOption('block_robot_enabled')) {
            return false;
        }
	    if (!empty($_SERVER['HTTP_USER_AGENT'])) {

            $userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
            $excludedRobots = PYS()->getOption('exclude_blocked_robots');
            $excludedRobots = array_filter($excludedRobots, function($robot) {
                return trim($robot) !== '';
            });
            if (!empty($excludedRobots)) {
                foreach ($excludedRobots as $robot) {
                    if (stripos($userAgent, strtolower($robot)) !== false) {
                        return false;
                    }
                }
            }

            $options = array(
	            'YandexBot', 'YandexAccessibilityBot', 'YandexMobileBot', 'YandexDirectDyn', 'YandexScreenshotBot',
	            'YandexImages', 'YandexVideo', 'YandexVideoParser', 'YandexMedia', 'YandexBlogs',
	            'YandexFavicons', 'YandexWebmaster', 'YandexPagechecker', 'YandexImageResizer', 'YandexAdNet',
	            'YandexDirect', 'YaDirectFetcher', 'YandexCalendar', 'YandexSitelinks', 'YandexMetrika',
	            'YandexNews', 'YandexNewslinks', 'YandexCatalog', 'YandexAntivirus', 'YandexMarket',
	            'YandexVertis', 'YandexForDomain', 'YandexSpravBot', 'YandexSearchShop', 'YandexMedianaBot',
	            'YandexOntoDB', 'YandexOntoDBAPI', 'Googlebot', 'Googlebot-Image', 'Googlebot-News',
	            'Googlebot-Video', 'Mediapartners-Google', 'AdsBot-Google', 'Chrome-Lighthouse', 'Lighthouse',
	            'Mail.RU_Bot', 'bingbot', 'Accoona', 'ia_archiver', 'Ask Jeeves', 'OmniExplorer_Bot',
	            'W3C_Validator', 'WebAlta', 'YahooFeedSeeker', 'Yahoo!', 'Ezooms', 'Tourlentabot', 'MJ12bot',
	            'AhrefsBot', 'SearchBot', 'SiteStatus', 'Nigma.ru', 'Baiduspider', 'Statsbot', 'SISTRIX',
	            'AcoonBot', 'findlinks', 'proximic', 'OpenindexSpider', 'statdom.ru', 'Exabot', 'Spider',
	            'SeznamBot', 'oBot', 'C-T bot', 'Updownerbot', 'Snoopy', 'heritrix', 'Yeti', 'DomainVader',
	            'DCPbot', 'PaperLiBot', 'APIs-Google', 'AdsBot-Google-Mobile', 'AdsBot-Google-Mobile-Apps',
	            'FeedFetcher-Google', 'Google-Read-Aloud', 'DuplexWeb-Google', 'Storebot-Google',
	            'ClaudeBot', 'SeekportBot', 'GPTBot', 'Applebot',
	            'DuckDuckBot', 'Sogou', 'facebookexternalhit', 'Swiftbot', 'Slurp', 'CCBot', 'Go-http-client',
	            'Sogou Spider', 'Facebot', 'Alexa Crawler', 'Cốc Cốc Bot', 'Majestic-12', 'SemrushBot',
	            'DotBot', 'Qwantify', 'Pinterestbot', 'Pinterest/0.', 'GrapeshotCrawler', 'archive.org_bot', 'LinkpadBot',
	            'uptimebot', 'Wget', 'curl', 'Google-Structured-Data-Testing-Tool', 'Google-PageSpeed Insights',
	            'Google-Site-Verification', 'BingPreview', 'Slackbot', 'TelegramBot', 'DiscordBot', 'WhatsApp',
	            'RedditBot', 'Yahoo! Slurp', 'Tumblr/14.', 'PetalBot', 'FlipboardProxy', 'LinkedInBot',
	            'SkypeUriPreview', 'Google-Firebase-Storage', 'BitlyBot', 'FeedlyBot', 'AppleNewsBot',
	            'ZyBorg', 'ia_archiver-web.archive.org', 'Mediatoolkitbot', 'DeuSu', 'SMTBot', 'MegaIndex.ru',
	            'Seomoz', 'BLEXBot', 'YisouSpider', '360Spider', 'AddThis', 'TweetmemeBot', 'ContextAd Bot',
	            'Screaming Frog SEO Spider', 'Nutch', 'Baiduspider-image', 'Panscient.com', 'Twitterbot',
	            'YoudaoBot', 'OpenSiteExplorer', 'Linkfluence', 'YaK', 'ContentKing', 'Spinn3r', 'PhantomJS',
	            'HeadlessChrome', 'snapchat_preview', 'Snap URL Preview', 'Pingdom', 'Googlebot-Mobile', 'Barkrowler',
	            // CrawlerDetect does not flag a bare "meta-externalads/1.1".
	            'meta-externalads', 'meta-externalagent'
            );

            foreach($options as $row) {
                if (stripos($userAgent, strtolower($row)) !== false) {
                    return true;
                }
            }
        }

        return $this->crawlerDetect->isCrawler();
    }

    public function ajaxGetGdprFiltersValues() {

        wp_send_json_success( array(
            'all_disabled_by_api'       => apply_filters( 'pys_disable_by_gdpr', false ),
            'facebook_disabled_by_api'  => apply_filters( 'pys_disable_facebook_by_gdpr', false ),
            'tiktok_disabled_by_api'  => apply_filters( 'pys_disable_tiktok_by_gdpr', false ),
            'openai_disabled_by_api'  => apply_filters( 'pys_disable_openai_by_gdpr', false ),
            'awin_disabled_by_api'  => apply_filters( 'pys_disable_awin_by_gdpr', false ),
            'analytics_disabled_by_api' => apply_filters( 'pys_disable_analytics_by_gdpr', false ),
            'google_ads_disabled_by_api' => apply_filters( 'pys_disable_google_ads_by_gdpr', false ),
            'pinterest_disabled_by_api' => apply_filters( 'pys_disable_pinterest_by_gdpr', false ),
            'bing_disabled_by_api' => apply_filters( 'pys_disable_bing_by_gdpr', false ),
            'reddit_disabled_by_api' => apply_filters( 'pys_disable_reddit_by_gdpr', false ),
            'externalID_disabled_by_api' => apply_filters( 'pys_disable_externalID_by_gdpr', false ),
            'disabled_all_cookie'       => apply_filters( 'pys_disable_all_cookie', false ),
            'disabled_start_session_cookie' => apply_filters( 'pys_disabled_start_session_cookie', false ),
            'disabled_advanced_form_data_cookie' => pys_advanced_form_data_cookie_disabled(),
            'advanced_form_data_expire'          => pys_advanced_form_data_cookie_days(),
            'disabled_landing_page_cookie'  => apply_filters( 'pys_disable_landing_page_cookie', false ),
            'disabled_first_visit_cookie'  => apply_filters( 'pys_disable_first_visit_cookie', false ),
            'disabled_trafficsource_cookie' => apply_filters( 'pys_disable_trafficsource_cookie', false ),
            'disabled_utmTerms_cookie' => apply_filters( 'pys_disable_utmTerms_cookie', false ),
            'disabled_utmId_cookie' => apply_filters( 'pys_disable_utmId_cookie', false ),
        ) );

    }

    public function userRegisterHandler( $user_id ) {

        if ( PYS()->getOption( 'automatic_event_signup_enabled' )
        ) {
            update_user_meta( $user_id, 'pys_complete_registration', true );
        }

    }

    /**
     * Hook
     * @param String $user_login
     * @param \WP_User $user
     */
	function userLogin( $user_login, $user ) {
		// Rotate the anonymous browser id on login, so the visitor is not
		// reported under the identifier their pre-login session used.
		//
		// Deleted at BOTH scopes: our JS writes pbid at the domain the browser
		// accepted, while pys_cookie_domain() answers host-only until pys_cd
		// comes back, and a deletion at one scope does not touch the other. The
		// miss is self-perpetuating — the front end only mints a pbid when
		// there is none at all, so the stale one would survive indefinitely.
		// The scoped call is skipped when there is no scope to state.
		$pbid_domain = pys_cookie_domain();
		setcookie( 'pbid', '', time() - 3600, '/' );
		if ( '' !== $pbid_domain ) {
			setcookie( 'pbid', '', time() - 3600, '/', $pbid_domain );
		}
		// Delete all existing rows first (clears accumulated duplicates for any role,
		// including excluded roles whose cleanup never fires via the event pipeline).
		// Then insert a single unique row to prevent race-condition duplicates.
		delete_user_meta( $user->ID, 'pys_just_login' );
		add_user_meta( $user->ID, 'pys_just_login', true, true );
		if ( !$user->get( 'external_id' ) ) {
			update_user_meta( $user->ID, 'external_id', $this->externalId );
		}
		// update advance matching user data
		update_advance_matching_user_data( $user->first_name, $user->last_name, $user->user_email, '' );
	}

    /**
     * @param $order_id
     * @param $posted_data
     * @param \WC_Order $order
     */
	/**
	 * Remember an order created by the current visitor.
	 *
	 * Lets the purchase event fire for gateways and funnel plugins that return
	 * the buyer without the order key, without opening the order-received page
	 * up to order-ID enumeration.
	 *
	 * @param int|\WC_Order $order Order ID or order object, depending on the hook.
	 */
	public function woo_remember_session_order( $order ) {

		if ( is_admin() && ! wp_doing_ajax() ) {
			return; // orders created in wp-admin belong to a shop manager, not to a visitor
		}

		if ( $order instanceof \WC_Order ) {
			$order_id = $order->get_id();
		} else {
			$order_id = absint( $order );
		}

		pysWooRecordSessionOrder( $order_id );

	}

	public function woo_checkout_process( $order_id, $posted_data, $order ) {

		// update advance matching user data
		$first_name = $order->get_billing_first_name();
		$last_name = $order->get_billing_last_name();
		$email = $order->get_billing_email();
		$phone = $order->get_billing_phone();
		$phone = preg_replace( '/[^0-9.]+/', '', $phone );

		update_advance_matching_user_data( $first_name, $last_name, $email, $phone );
	}

    public function getEventsManager() {
        return $this->eventsManager;
    }

    /**
     * WordPress spawns cron on the 'init' hook, before the REST router gets a
     * chance to dispatch. With ALTERNATE_WP_CRON enabled, spawn_cron() answers
     * the current request with a 302 to the same URL + ?doing_wp_cron=... and
     * runs cron inline, so the front-end fetch() for dynamic-options receives a
     * redirect where it expects JSON (and every page load pays for a synchronous
     * cron run plus an extra round trip). Cron has plenty of other requests to
     * piggyback on, so skip spawning it for this one route. Core does the same
     * for the customizer, see WP_Customize_Manager::setup_theme().
     */
    private function prevent_cron_spawn_on_dynamic_options() {

        if ( ! defined( 'ALTERNATE_WP_CRON' ) || ! ALTERNATE_WP_CRON ) {
            return;
        }

        if ( empty( $_SERVER['REQUEST_URI'] ) ) {
            return;
        }

        $route = 'pys/v1/dynamic-options';
        $path  = untrailingslashit( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) );

        // Pretty permalinks give /wp-json/pys/v1/dynamic-options, plain ones
        // give /?rest_route=/pys/v1/dynamic-options.
        $is_route = substr( $path, - strlen( $route ) ) === $route
            || ( isset( $_GET['rest_route'] ) && trim( wp_unslash( $_GET['rest_route'] ), '/' ) === $route );

        if ( $is_route ) {
            remove_action( 'init', 'wp_cron' );
        }

    }

    /**
     * Open the visitor's session read-only for the dynamic-options request.
     *
     * controllSessionStart() cannot do this: it hangs on 'wp', and 'wp' never fires
     * for a REST request — rest_api_loaded() serves the route and dies inside
     * parse_request(), before WP::main() gets that far. Without this the endpoint
     * sees no visit data at all on a site where PYS is the only consumer of the
     * session, and the landing page it reports comes back empty.
     *
     * Read-only on purpose: this request only reads. The visit data is written on the
     * page view that opened the session, and read_and_close releases the lock at once
     * instead of holding it for the whole request.
     *
     * @return void
     */
    private function openSessionForRead() {

        if ( PYS()->getOption( 'session_disable' ) || $this->is_user_agent_bot() ) {
            return;
        }

        if ( PHP_SAPI === 'cli' || session_status() !== PHP_SESSION_NONE || headers_sent() ) {
            return;
        }

        // Read an existing session, never start a new one. session_start() would hand
        // out a PHPSESSID to a visitor who has none — a cookie for nothing, and one
        // that some page caches treat as a reason to stop serving cached pages.
        $session_cookie = session_name();
        if ( empty( $session_cookie ) || empty( $_COOKIE[ $session_cookie ] ) ) {
            return;
        }

        @session_start( array( 'read_and_close' => true ) );
    }

    public function register_dynamic_options_route() {
        register_rest_route( 'pys/v1', '/dynamic-options', array(
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => array( $this, 'serve_dynamic_options' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function serve_dynamic_options( $request ) {

        // Before anything else, so the visit data below has something to read.
        $this->openSessionForRead();

        nocache_headers();

        // WordPress resets the current user to 0 for any REST request that
        // does not carry an X-WP-Nonce / _wpnonce (see rest_cookie_check_errors
        // in wp-includes/rest-api.php). Because this endpoint is called from a
        // cached page that intentionally has no nonce in the HTML, we must
        // restore the user manually by re-validating the auth cookie ourselves.
        if ( ! is_user_logged_in() ) {
            $cookie_user_id = wp_validate_auth_cookie( '', 'logged_in' );
            if ( $cookie_user_id ) {
                wp_set_current_user( $cookie_user_id );
            }
        }

        $user = wp_get_current_user();
        if ( isDisabledForUserRole( $user ) || $this->is_user_agent_bot() ) {
            return new \WP_REST_Response( array(), 200 );
        }

        $pys_analytics_storage_mode  = has_filter( 'pys_analytics_storage_mode' );
        $pys_ad_storage_mode         = has_filter( 'pys_ad_storage_mode' );
        $pys_ad_user_data_mode       = has_filter( 'pys_ad_user_data_mode' );
        $pys_ad_personalization_mode = has_filter( 'pys_ad_personalization_mode' );

        $dynamic = array(
            'ajax_event'   => wp_create_nonce( 'ajax-event-nonce' ),
            'user_id'      => GA()->enabled() && GA()->getOption( 'track_user_id' )
                                  ? get_current_user_id() : 0,
            'cache_bypass' => time(),

            /*
             * Landing page, traffic source and UTMs DO travel here, unlike in the
             * HTML, where they stay empty (see the note in EventsManager::
             * outputData()). This response is per visitor and carries
             * nocache_headers(), so it is the one channel where the server may hand
             * over the session copy without a page cache turning it into everybody's
             * data.
             *
             * That matters for visitors who never got a cookie: with a consent
             * manager gating Utils.manageCookies(), the front end has nothing of its
             * own until consent is given, while the PHP session recorded the visit
             * all along. The front end prefers its own cookie, falls back to these,
             * and only then to the current URL.
             *
             * An empty value is the "nothing to say" signal the front end skips over,
             * which is exactly what the HTML copy always sends.
             */
            'tracking_analytics' => array(
                'TrafficLanding'             => sanitize_url( explode( '?',
                    $_SESSION['LandingPage'] ?? $_COOKIE['pys_landing_page'] ?? '' )[0] ),
                'TrafficSource'              => sanitize_text_field(
                    $_SESSION['TrafficSource'] ?? $_COOKIE['pysTrafficSource'] ?? '' ),
                'TrafficUtms'                => getUtms(),
                'TrafficUtmsId'              => getUtmsId(),
                'userDataEnable'             => GA()->getOption( 'send_user_provided_data' ),
                'userData'                   => getUserData(),
                'use_encoding_provided_data' => GA()->getOption( 'use_encoding_provided_data' ),
                'use_multiple_provided_data' => GA()->getOption( 'use_multiple_provided_data' ),
            ),

            'gdpr_dynamic' => array(
                'all_disabled_by_api'        => apply_filters( 'pys_disable_by_gdpr', false ),
                'facebook_disabled_by_api'   => apply_filters( 'pys_disable_facebook_by_gdpr', false ),
                'tiktok_disabled_by_api'     => apply_filters( 'pys_disable_tiktok_by_gdpr', false ),
                'openai_disabled_by_api'     => apply_filters( 'pys_disable_openai_by_gdpr', false ),
                'awin_disabled_by_api'       => apply_filters( 'pys_disable_awin_by_gdpr', false ),
                'analytics_disabled_by_api'  => apply_filters( 'pys_disable_analytics_by_gdpr', false ),
                'google_ads_disabled_by_api' => apply_filters( 'pys_disable_google_ads_by_gdpr', false ),
                'pinterest_disabled_by_api'  => apply_filters( 'pys_disable_pinterest_by_gdpr', false ),
                'bing_disabled_by_api'       => apply_filters( 'pys_disable_bing_by_gdpr', false ),
                'reddit_disabled_by_api'     => apply_filters( 'pys_disable_reddit_by_gdpr', false ),
                'externalID_disabled_by_api' => apply_filters( 'pys_disable_externalID_by_gdpr', false ),
                'analytics_storage_value'    => $pys_analytics_storage_mode
                    ? ( apply_filters( 'pys_analytics_storage_mode', true ) ? 'granted' : 'denied' ) : null,
                'ad_storage_value'           => $pys_ad_storage_mode
                    ? ( apply_filters( 'pys_ad_storage_mode', true ) ? 'granted' : 'denied' ) : null,
                'ad_user_data_value'         => $pys_ad_user_data_mode
                    ? ( apply_filters( 'pys_ad_user_data_mode', true ) ? 'granted' : 'denied' ) : null,
                'ad_personalization_value'   => $pys_ad_personalization_mode
                    ? ( apply_filters( 'pys_ad_personalization_mode', true ) ? 'granted' : 'denied' ) : null,
            ),

            'cookie' => array(
                'disabled_all_cookie'                => apply_filters( 'pys_disable_all_cookie', false ),
                'disabled_start_session_cookie'      => apply_filters( 'pys_disabled_start_session_cookie', false ),
                'disabled_advanced_form_data_cookie' => pys_advanced_form_data_cookie_disabled(),
                'advanced_form_data_expire'          => pys_advanced_form_data_cookie_days(),
                'disabled_landing_page_cookie'       => apply_filters( 'pys_disable_landing_page_cookie', false ),
                'disabled_first_visit_cookie'        => apply_filters( 'pys_disable_first_visit_cookie', false ),
                'disabled_trafficsource_cookie'      => apply_filters( 'pys_disable_trafficsource_cookie', false ),
                'disabled_utmTerms_cookie'           => apply_filters( 'pys_disable_utmTerms_cookie', false ),
                'disabled_utmId_cookie'              => apply_filters( 'pys_disable_utmId_cookie', false ),
                'disabled_google_alternative_id'     => apply_filters( 'pys_disable_google_alternative_id', false ),
            ),
        );

        /*
         * Per-pixel user data (advanced matching) that outputData() emptied out of
         * the cached HTML. The values are re-read from getPixelOptions() so they
         * are byte-identical to what the page would have printed, which also means
         * add-ons need no changes to take part — they only have to appear in
         * getDynamicUserDataKeys().
         *
         * Only the PII keys from that map are taken. Everything else the pixel
         * returns is deliberately ignored: this request's URL is the endpoint, not
         * the page, so context-dependent values (WPML language for pixelIds, order
         * data, SuperPack tag rules) would not be trustworthy here.
         */
        $pixels = array();

        foreach ( getDynamicUserDataKeys() as $slug => $keys ) {

            $pixel = $this->getRegisteredPixel( $slug );
            if ( ! $pixel || ! $pixel->configured() ) {
                continue;
            }

            $pixel_options = $pixel->getPixelOptions();

            foreach ( $keys as $key ) {
                // Ship a key only when there is something in it. An empty value
                // would overwrite the inline data on pages we never stripped.
                if ( ! empty( $pixel_options[ $key ] ) ) {
                    $pixels[ $slug ][ $key ] = $pixel_options[ $key ];
                }
            }
        }

        if ( ! empty( $pixels ) ) {
            $dynamic['pixels'] = $pixels;
        }

        $response = new \WP_REST_Response( $dynamic, 200 );
        $response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
        $response->header( 'Pragma', 'no-cache' );
        $response->header( 'X-Robots-Tag', 'noindex' );
        /*
         * This response is identity-specific: never let a shared cache key it by
         * URL alone. Origin is listed too because setting a header on the response
         * replaces any same-named one, and REST CORS handling may have sent
         * 'Vary: Origin' — we must not drop it.
         */
        $response->header( 'Vary', 'Cookie, Origin' );
        return $response;
    }

    public function adminMenu() {
        global $submenu;

        $main_page_hook = add_menu_page( 'PixelYourSite', 'PixelYourSite', 'manage_pys', 'pixelyoursite',
            array( $this, 'adminPageMain' ), PYS_URL . '/dist/images/pys-logo.png' );

        if ( ! current_user_can( 'manage_pys_data_export' ) ) {
            add_action( 'load-' . $main_page_hook, array( $this, 'sendLogsDeniedStatus' ) );
        }
        add_submenu_page( 'pixelyoursite', 'Global Settings', 'Global Settings',
            'manage_pys', 'pixelyoursite_settings', array( $this, 'adminSinglePage' ), 2 );
        add_submenu_page('pixelyoursite',__('Queue Settings', 'pys'),__('Queue Settings', 'pys'),
            'manage_pys','pixelyoursite_queue_settings',array($this, 'adminSinglePage'),3);
        PysStatistic()->adminMenu();

        add_submenu_page( 'pixelyoursite', 'UTM Builder', 'UTM Builder',
            'manage_pys', 'pixelyoursite_utm', array( $this, 'adminSinglePage' ), 6 );

        add_submenu_page( 'pixelyoursite', 'Licenses', 'Licenses',
            'manage_pys', 'pixelyoursite_licenses', array( $this, 'adminSinglePage' ), 7 );

        add_submenu_page( 'pixelyoursite', 'System Report', 'System Report',
            'manage_pys', 'pixelyoursite_report', array( $this, 'adminSinglePage' ), 8 );


        // core admin pages
        $this->setAdminPagesSlugs(array(
            'pixelyoursite',
            'pixelyoursite_settings',
            'pixelyoursite_queue_settings',
            'pixelyoursite_licenses',
            'pixelyoursite_report',
            'pixelyoursite_woo_reports',
            'pixelyoursite_edd_reports',
            'pixelyoursite_utm',
        ));

        // rename first submenu item
        if ( isset( $submenu['pixelyoursite'] ) ) {
            $submenu['pixelyoursite'][0][0] = 'Dashboard';
        }

        $this->adminSaveSettings();

    }

    public function adminEnqueueScripts() {

        wp_enqueue_style( 'pys_notice', PYS_URL . '/dist/styles/notice.min.css', array(), PYS_VERSION );
        if ( in_array( getCurrentAdminPage(), $this->adminPagesSlugs ) ) {


            wp_register_style( 'select2_css', PYS_URL . '/dist/styles/select2.min.css', array(), PYS_VERSION);
            wp_register_script( 'select2_js', PYS_URL . '/dist/scripts/select2.min.js',array( 'jquery' ), PYS_VERSION );

            wp_deregister_script( 'jquery' );
            wp_deregister_script( 'jquery-core' ); // prevent duplicate

            wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), '4.7.0' );

            wp_enqueue_script( 'jquery', '//cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js' );

            wp_enqueue_script( 'popper', PYS_URL . '/dist/scripts/popper.min.js', 'jquery' );
            wp_enqueue_script( 'tippy', PYS_URL . '/dist/scripts/tippy.min.js', 'jquery' );
            wp_enqueue_script( 'bootstrap', PYS_URL . '/dist/scripts/bootstrap.min.js', 'jquery','popper' );

            wp_enqueue_style( 'pys_css', PYS_URL . '/dist/styles/admin.min.css', array( 'select2_css' ), PYS_VERSION );

            /*
             * We ship Font Awesome 4. When another plugin loads Font Awesome 5/6
             * in wp-admin (e.g. Addify's all.min.css), its `.fa` rule overrides
             * our `font-family` and FA4-only glyphs such as `fa-trash-o` render
             * wrong or blank. Force our icons back to the FA4 face, scoped to the
             * PYS admin wrapper (#pys) so we win the cascade whatever the load order.
             */
            wp_add_inline_style( 'pys_css', '#pys .fa{font-family:"FontAwesome" !important;font-weight:normal !important;font-style:normal !important;}' );


            wp_enqueue_script( 'pys_js', PYS_URL . '/dist/scripts/admin.js', array( 'jquery', 'select2_js', 'popper',
                'bootstrap' ), PYS_VERSION );

	        $admin_data = $this->get_admin_data();
	        wp_localize_script( 'pys_js', 'pysAdmin', $admin_data );
	        // Lets admin.js detect and store the site's cookie domain once.
	        wp_localize_script( 'pys_js', 'pysCookieDomainDetect', pys_cookie_domain_detect_data() );

            if( isset($_GET['page'])
                && $_GET['page'] == "pixelyoursite"
                && isset($_GET['tab'])
                && ($_GET['tab'] == 'woo' || $_GET['tab'] == 'edd')
            ) {
                wp_enqueue_script( 'jquery-ui-datepicker' );
                wp_enqueue_style( 'pys_calendar', PYS_URL . '/dist/styles/calendar.css', array(  ), PYS_VERSION );
                wp_enqueue_script( 'pys_js_offline_export', PYS_URL . '/dist/scripts/admin_offline_events.js', array( 'pys_js' ), PYS_VERSION );
                wp_enqueue_script( 'pys_js_customer_export', PYS_URL . '/dist/scripts/admin_export_customer.js', array( 'pys_js' ), PYS_VERSION );
            }
            if( (isset($_GET['page']) && $_GET['page'] == "pixelyoursite" && isset($_GET['tab']) && ($_GET['tab'] == 'events')) ||
                ( isset($_GET['page']) && (( $_GET['page'] == "pixelyoursite_woo_reports" ) || $_GET['page'] == "pixelyoursite_edd_reports" )) ||
                ( isset($_GET['page']) && $_GET['page'] == "pixelyoursite_settings") ||
                ( isset($_GET['page']) && $_GET['page'] == "pixelyoursite_mcp") ||
                ( isset($_GET['page']) && $_GET['page'] == "pixelyoursite_mcp_log") ||
                ( isset($_GET['page']) && $_GET['page'] == "pixelyoursite_import_export")
            ){
                wp_enqueue_style( 'pys_confirm_style', PYS_URL . '/dist/scripts/confirm/jquery-confirm.min.css', array(  ), PYS_VERSION );
                wp_enqueue_style( 'pys_confirm_style_theme', PYS_URL . '/dist/scripts/confirm/bs3.css', array(  ), PYS_VERSION );
                wp_enqueue_script( 'pys_confirm_script', PYS_URL . '/dist/scripts/confirm/jquery-confirm.min.js', array( 'pys_js' ), PYS_VERSION );
                wp_enqueue_script( 'pys_custom_confirm_script', PYS_URL . '/dist/scripts/confirm/custom-confirm.js', array( 'pys_js' ), PYS_VERSION );
            }



        }



    }

    public function adminPageMain() {
        $this->adminExportCustomAudiences();

        include 'views/html-wrapper-main.php';

    }

    public function adminSinglePage()
    {
        $this->adminResetSettings();
        include 'views/html-wrapper-single-page.php';
    }

// Add a new column to the list of orders
    function add_tracking_type_column($columns) {
        $columns['tracking_type'] = 'Tracking type';
        return $columns;
    }


// Fill the new column with data from the order metafield
    function fill_tracking_type($column) {

        if ('tracking_type' === $column) {
            $tracking_type = 'Not tracked';
            if(get_post_meta( get_the_ID(), '_pys_advance_purchase_event_fired', true)){
                $tracking_type = 'Advanced Purchase Tracking (APT)';
            }elseif(get_post_meta( get_the_ID(), '_pys_purchase_event_fired', true)){
                $tracking_type = 'Tag or API';
            }
            echo $tracking_type;
        }


    }

	function fill_tracking_type_hpos($column, $order) {

		if ('tracking_type' === $column) {
			$tracking_type = 'Not tracked';
			if($order->get_meta('_pys_advance_purchase_event_fired', true)){
				$tracking_type = 'Advanced Purchase Tracking (APT)';
			}elseif($order->get_meta('_pys_purchase_event_fired', true)){
				$tracking_type = 'Tag or API';
			}
			echo $tracking_type;
		}


	}

    public function adminProcessRequest() {
        $this->adminCheckLicense();
        $this->adminUpdateCustomEvents();
        $this->adminEnableGdprAjax();
        OfflineEvents();


        if(isset($_GET['page']) && ($_GET['page'] == 'pixelyoursite_woo_reports' || $_GET['page'] == 'pixelyoursite_edd_reports')) {
            // Security check: verify user has permission to export reports
            if ( ! current_user_can( 'manage_pys_reports' ) ) {
                return;
            }

            if ( isset($_REQUEST['export_csw']) && $_REQUEST['export_csw'] == 'woo_report' ) {
                PysStatistic()->globalWooReport();
                exit;
            }

            if ( isset($_REQUEST['export_csw']) && $_REQUEST['export_csw'] == 'woo_single_report' ) {
                PysStatistic()->singleWooReport();
                exit;
            }
            if ( isset($_REQUEST['export_csw']) && $_REQUEST['export_csw'] == 'edd_report' ) {
                PysStatistic()->globalEddReport();
                exit;
            }
            if ( isset($_REQUEST['export_csw']) && $_REQUEST['export_csw'] == 'edd_single_report' ) {
                PysStatistic()->singleEddReport();
                exit;
            }
        }
    }
    public function init_tracking_type_logic() {
        if ( ! is_admin() || ! function_exists( 'wc_get_container' ) ) {
            return false;
        }
        if(PYS()->getOption('woo_enabled_show_tracking_type')){
            if(isWooUseHPStorage()){
                add_filter('woocommerce_shop_order_list_table_columns', array($this,'add_tracking_type_column'));
                add_action('woocommerce_shop_order_list_table_custom_column', array($this,'fill_tracking_type_hpos'), 20, 2 );
            }
            else{
                add_filter('manage_edit-shop_order_columns', array($this,'add_tracking_type_column'));
                add_action('manage_shop_order_posts_custom_column', array($this,'fill_tracking_type'));
            }

        }
    }
    private function adminCheckLicense() {

        $is_dashboard = isset( $_REQUEST['page'] ) && $_REQUEST['page'] == 'pixelyoursite';
        $license_status = $this->getOption( 'license_status' );

        // redirect to license page in case if license was never activated
        if ( $is_dashboard && empty( $license_status ) ) {
            wp_safe_redirect( buildAdminUrl( 'pixelyoursite_licenses' ) );
            exit;
        }

    }

    public function adminUpdateLicense() {

        if ( ! $this->adminSecurityCheck() ) {
            return;
        }

        updateLicense( $this );

    }

    /**
     * Should the update checker be registered for the current request?
     *
     * Front-end page views are skipped on purpose: nothing there reads the
     * update_plugins transient, and building the updater may trigger a
     * blocking request to our licensing API on a visitor's page load.
     *
     * @return bool
     */
    private function shouldCheckPluginUpdates() {

        // wp-admin, including admin-ajax.php
        if ( is_admin() ) {
            return true;
        }

        // WordPress background auto-updates (wp_doing_cron() is WP 4.8+)
        if ( function_exists( 'wp_doing_cron' ) ) {
            if ( wp_doing_cron() ) {
                return true;
            }
        } elseif ( defined( 'DOING_CRON' ) && DOING_CRON ) {
            return true;
        }

        // "wp plugin list", "wp plugin update", etc.
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            return true;
        }

        // REST API. The query var is what rest_api_loaded() itself goes by,
        // REST_REQUEST is not defined yet when we are called on 'parse_request'.
        $rest_route = isset( $GLOBALS['wp'] ) && ! empty( $GLOBALS['wp']->query_vars['rest_route'] )
            ? (string) $GLOBALS['wp']->query_vars['rest_route']
            : '';

        if ( $rest_route !== '' ) {
            // Our own routes (pys/v1, pys-facebook/v1, ...) are requested on visitors'
            // page views, and nobody reads the list of updates through them.
            return ! preg_match( '#^/?pys[/-]#i', $rest_route );
        }

        return defined( 'REST_REQUEST' ) && REST_REQUEST;

    }

    public function updatePlugin() {

        // hooked more than once, see the constructor
        if ( $this->updateCheckersRegistered || ! $this->shouldCheckPluginUpdates() ) {
            return;
        }

        $this->updateCheckersRegistered = true;

        foreach ( $this->registeredPlugins as $slug => $plugin ) {

            if ( $slug == 'head_footer' ) {
                continue;
            }

            updatePlugin( $plugin );

        }

        updatePlugin( $this );

    }

    public function adminSecurityCheck() {

        // verify user access
        if ( ! current_user_can( 'manage_pys' ) ) {
            return false;
        }

        // nonce filed are required request
        if ( ! isset( $_REQUEST['_wpnonce'] ) || !$_REQUEST['_wpnonce'] ) {
            return false;
        }

        return true;

    }

    private function adminEnableGdprAjax() {

        if ( ! $this->adminSecurityCheck() ) {
            return;
        }
	// Verify nonce specifically for GDPR AJAX action
	    if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'pys_enable_gdpr_ajax' ) ) {
		    return;
	    }
        if ( isset( $_REQUEST['pys']['enable_gdpr_ajax'] ) ) {
            $this->updateOptions( array(
                'gdpr_ajax_enabled' => true,
                'gdpr_cookie_law_info_integration_enabled' => true,
                'consent_magic_integration_enabled' => true,
            ) );

            add_action( 'admin_notices', 'PixelYourSite\adminGdprAjaxEnabledNotice' );
            purgeCache();
        }

    }

    private function adminUpdateCustomEvents() {

        if ( ! $this->adminSecurityCheck() ) {
            return;
        }

        /**
         * Single Custom Event Actions
         */
        if ( isset( $_REQUEST['pys']['event'] ) && isset( $_REQUEST['action']) && is_array($_REQUEST['pys']['event'])  ) {

            $nonce   = isset( $_REQUEST['_wpnonce'] ) ? $_REQUEST['_wpnonce'] : null;
            $action  = $_REQUEST['action'];
            if(isset( $_REQUEST['pys']['event']['post_id'] )) {
                $post_id = sanitize_key( $_REQUEST['pys']['event']['post_id']) ;
            } else {
                $post_id =  false;
            }


            if ( $action == 'update' && wp_verify_nonce( $nonce, 'pys_update_event' ) ) {

                $pys_event = $_REQUEST['pys']['event'];

                if ( $post_id ) {
                    $event = CustomEventFactory::getById( $post_id );
                    $event->update( $pys_event );
                } else {
                    $event = CustomEventFactory::create( $pys_event );
                }

                purgeCache();

            } elseif ( $action == 'enable' && $post_id && wp_verify_nonce( $nonce, 'pys_enable_event' ) ) {

                $event = CustomEventFactory::getById( $post_id );
                $event->enable();

            } elseif ( $action == 'disable' && $post_id && wp_verify_nonce( $nonce, 'pys_disable_event' ) ) {

                $event = CustomEventFactory::getById( $post_id );
                $event->disable();

            } elseif ( $action == 'remove' && $post_id && wp_verify_nonce( $nonce, 'pys_remove_event' ) ) {

                CustomEventFactory::remove( $post_id );

            }

            purgeCache();

            // redirect to events tab
            wp_safe_redirect( buildAdminUrl( 'pixelyoursite', 'events' ) );
            exit;

        }

        /**
         * Bulk Custom Events Actions
         */
        if ( isset( $_REQUEST['pys']['bulk_event_action'], $_REQUEST['pys']['selected_events'] )
            && isset( $_REQUEST['pys']['bulk_event_action_nonce'] )
            && wp_verify_nonce( $_REQUEST['pys']['bulk_event_action_nonce'], 'bulk_event_action' )
            && is_array( $_REQUEST['pys']['selected_events'] ) ) {

            foreach ( $_REQUEST['pys']['selected_events'] as $event_id ) {

                $event_id = (int) $event_id;

                switch ( $_REQUEST['pys']['bulk_event_action'] ) {
                    case 'enable':
                        $event = CustomEventFactory::getById( $event_id );
                        $event->enable();
                        break;

                    case 'disable':
                        $event = CustomEventFactory::getById( $event_id );
                        $event->disable();
                        break;

                    case 'clone':
                        CustomEventFactory::makeClone( $event_id );
                        break;

                    case 'delete':
                        CustomEventFactory::remove( $event_id );
                        break;
                }

            }

            purgeCache();

            // redirect to events tab
            wp_safe_redirect( buildAdminUrl( 'pixelyoursite', 'events' ) );
            exit;

        }

    }

    /**
     * Show row meta on the plugin screen.
     *
     * @param mixed $links Plugin Row Meta.
     * @param mixed $file  Plugin Base file.
     *
     * @return array
     */
    public function pluginRowMeta( $links, $file ) {

        if ( PYS_PRO_PLUGIN_BASENAME === $file ) {
            $links[] = '<a href="https://www.pixelyoursite.com/docs">Help</a>';
        }

        return (array) $links;

    }

    public function sendLogsDeniedStatus() {
        if ( 'logs' === getCurrentAdminTab() ) {
            status_header( 403 );
        }
    }

    /**
     * Only site administrators may change who can use the plugin.
     *
     * @return bool
     */
    public function canEditPermissions() {
        return current_user_can( 'manage_options' );
    }

    /**
     * Sanitize the general plugin access list.
     *
     * @param mixed $value Submitted field value.
     *
     * @return array
     */
    public function sanitizeAdminPermissionsField( $value ) {

        if ( ! $this->canEditPermissions() ) {
            return (array) $this->getOption( 'admin_permissions', array( 'administrator' ) );
        }

        $value = is_array( $value ) ? $value : array();

        // "administrator" always should be allowed
        if ( ! in_array( 'administrator', $value ) ) {
            $value[] = 'administrator';
        }

        manageAdminPermissions();

        return $this->sanitize_multi_select_field( $value );

    }

    /**
     * @param mixed $value Submitted field value.
     *
     * @return array
     */
    public function sanitizeReportsPermissionsField( $value ) {
        return $this->sanitizeScopedPermissionsField( 'woo_edd_reports_permissions', $value );
    }

    /**
     * @param mixed $value Submitted field value.
     *
     * @return array
     */
    public function sanitizeExportPermissionsField( $value ) {
        return $this->sanitizeScopedPermissionsField( 'woo_edd_export_permissions', $value );
    }

    /**
     * Sanitize a role list that narrows general plugin access, keeping it
     * within the roles allowed by "admin_permissions".
     *
     * @param string $key   Option key.
     * @param mixed  $value Submitted field value.
     *
     * @return array
     */
    private function sanitizeScopedPermissionsField( $key, $value ) {

        if ( ! $this->canEditPermissions() ) {
            return (array) $this->getOption( $key, array( 'administrator' ) );
        }

        $value = is_array( $value ) ? $value : array();
        $value = array_intersect( $value, $this->getSubmittedAdminPermissions() );

        // "administrator" always should be allowed
        if ( ! in_array( 'administrator', $value ) ) {
            $value[] = 'administrator';
        }

        manageAdminPermissions();

        return $this->sanitize_multi_select_field( array_values( $value ) );

    }

    /**
     * Roles holding general plugin access for the current request; the
     * submitted value wins because the stored one is still the previous value.
     *
     * @return array
     */
    private function getSubmittedAdminPermissions() {

        if ( isset( $_POST['pys']['core']['admin_permissions'] ) && is_array( $_POST['pys']['core']['admin_permissions'] ) ) {
            $permissions = array_map( 'sanitize_text_field', wp_unslash( $_POST['pys']['core']['admin_permissions'] ) );
        } else {
            $permissions = (array) $this->getOption( 'admin_permissions', array( 'administrator' ) );
        }

        // the field posts an empty hidden value
        $permissions = array_filter( $permissions );

        if ( ! in_array( 'administrator', $permissions ) ) {
            $permissions[] = 'administrator';
        }

        return $permissions;

    }

    private function adminSaveSettings() {

        if ( ! $this->adminSecurityCheck() ) {
            return;
        }

        if ( wp_verify_nonce( $_REQUEST['_wpnonce'], 'pys_save_settings' ) ) {

            if(isset( $_POST['pys']['core'] ) && is_array($_POST['pys']['core'])) {
                $core_options =  $_POST['pys']['core'];
            } else {
                $core_options =  array();
            }

            // Capture old content ID settings before saving
            $pixels_to_check = [ 'facebook', 'gatags', 'gtm', 'tiktok', 'openai', 'awin', 'reddit', 'pinterest', 'bing' ];
            $old_content_id_settings = [];
            foreach ( $pixels_to_check as $slug ) {
                $pixel = $this->registeredPixels[ $slug ] ?? null;
                if ( ! $pixel ) {
                    continue;
                }
                $old_content_id_settings[ $slug ] = [
                    'mode'  => $pixel->getOption( 'woo_content_id' ),
                    'field' => $pixel->getOption( 'woo_content_id_custom_field_name' ),
                ];
            }


            $gdpr_ajax_enabled = isset( $core_options['gdpr_ajax_enabled'] )
                ? $core_options['gdpr_ajax_enabled']        // value from form data
                : $this->getOption('gdpr_ajax_enabled');    // previous value

            // allow 3rd party plugins to by-pass option value
            $core_options['gdpr_ajax_enabled'] = apply_filters( 'pys_gdpr_ajax_enabled', $gdpr_ajax_enabled );

            if (isPixelCogActive() ) {
                if (isset($core_options['woo_purchase_value_option'])) {
                    $core_options = $this->updateDefaultNoCogOption($core_options,'woo_purchase_value_option','woo_purchase_value_cog');
                }
                if (isset($core_options['woo_view_content_value_option'])) {
                    $core_options = $this->updateDefaultNoCogOption($core_options,'woo_view_content_value_option','woo_content_value_cog');
                }
                if (isset($core_options['woo_add_to_cart_value_option'])) {
                    $core_options = $this->updateDefaultNoCogOption($core_options,'woo_add_to_cart_value_option','woo_add_to_cart_value_cog');
                }
                if (isset($core_options['woo_initiate_checkout_value_option'])) {
                    $core_options = $this->updateDefaultNoCogOption($core_options,'woo_initiate_checkout_value_option','woo_initiate_checkout_value_cog');
                }
            }

            // update core options
            $this->updateOptions( $core_options );


            $objects = array_merge( $this->registeredPixels, $this->registeredPlugins );

            // update plugins and pixels options
            foreach ( $objects as $obj ) {
                /** @var Plugin|Pixel|Settings $obj */
                if($obj->getSlug() === 'head_footer' && (!current_user_can('manage_pys') || !current_user_can('unfiltered_html'))){
                    continue;
                }
                $obj->updateOptions();
            }
            GATags()->updateOptions();
            purgeCache();
            delete_transient( 'pys_product_meta_keys' );
            if ( class_exists( 'PixelYourSite\FeedIdCheck' ) ) {
                FeedIdCheck::refreshState();
            }

            // Trigger background scan if custom_field mode was enabled or field name changed
            foreach ( $pixels_to_check as $slug ) {
                $new_mode  = sanitize_key( $_POST['pys'][ $slug ]['woo_content_id'] ?? '' );
                $new_field = sanitize_text_field( $_POST['pys'][ $slug ]['woo_content_id_custom_field_name'] ?? '' );
                if ( $new_mode !== 'custom_field' ) {
                    continue;
                }
                $old = $old_content_id_settings[ $slug ] ?? [];
                if ( ( $old['mode'] ?? '' ) !== 'custom_field' || ( $old['field'] ?? '' ) !== $new_field ) {
                    PysContentIdScanner::startScan( $slug, $new_field );
                }
            }

        }

    }

    private function updateDefaultNoCogOption($core_options,$optionName,$defaultOptionName) {
        $val = $core_options[$optionName];
        $currentVal = $this->getOption($optionName);
        if($val != 'cog') {
            $core_options[$defaultOptionName] = $val;
        } elseif ( $currentVal != 'cog' ) {
            $core_options[$defaultOptionName] = $currentVal;
        }
        return $core_options;
    }

    private function adminResetSettings() {
        if ( ! $this->adminSecurityCheck() ) {
            return;
        }
        if ( wp_verify_nonce( $_REQUEST['_wpnonce'], 'pys_save_settings' ) && isset( $_REQUEST['pys']['reset_settings'] ) ) {

            if ( isSuperPackActive() ) {

                $old_options = array(
                    'license_key'     => SuperPack()->getOption( 'license_key' ),
                    'license_status'  => SuperPack()->getOption( 'license_status' ),
                    'license_expires' => SuperPack()->getOption( 'license_expires' ),
                );

                SuperPack()->resetToDefaults();
                SuperPack()->updateOptions( $old_options );

            }

            if ( isPinterestActive() ) {

                $old_options = array(
                    'license_key'     => Pinterest()->getOption( 'license_key' ),
                    'license_status'  => Pinterest()->getOption( 'license_status' ),
                    'license_expires' => Pinterest()->getOption( 'license_expires' ),
                    'pixel_id'        => Pinterest()->getPixelIDs(),
                );

                Pinterest()->resetToDefaults();
                Pinterest()->updateOptions( $old_options );

            }

	        if ( isRedditActive() ) {
		        $old_options = array(
			        'license_key'     => Reddit()->getOption( 'license_key' ),
			        'license_status'  => Reddit()->getOption( 'license_status' ),
			        'license_expires' => Reddit()->getOption( 'license_expires' ),
			        'pixel_id'        => Reddit()->getPixelIDs(),
		        );

		        Reddit()->resetToDefaults();
		        Reddit()->updateOptions( $old_options );
	        }

            // Core
            $old_options = array(
                'license_key'     => $this->getOption( 'license_key' ),
                'license_status'  => $this->getOption( 'license_status' ),
                'license_expires' => $this->getOption( 'license_expires' ),
            );

            PYS()->resetToDefaults();
            PYS()->updateOptions( $old_options );

            // Facebook
            $old_options = array(
                'pixel_id' => Facebook()->getPixelIDs(),
            );

            Facebook()->resetToDefaults();
            Facebook()->updateOptions( $old_options );

            // Google Analytics
            $old_options = array(
                'tracking_id' => GA()->getPixelIDs(),
            );

            GA()->resetToDefaults();
            GA()->updateOptions( $old_options );

            // Google Analytics
            $old_options = array(
                'ads_ids' => Ads()->getPixelIDs(),
                'woo_purchase_conversion_labels' => Ads()->getOption( 'woo_purchase_conversion_labels' ),
                'woo_initiate_checkout_conversion_labels' => Ads()->getOption( 'woo_initiate_checkout_conversion_labels' ),
                'woo_add_to_cart_conversion_labels' => Ads()->getOption( 'woo_add_to_cart_conversion_labels' ),
                'woo_view_content_conversion_labels' => Ads()->getOption( 'woo_view_content_conversion_labels' ),
                'woo_view_category_conversion_labels' => Ads()->getOption( 'woo_view_category_conversion_labels' ),
                'edd_purchase_conversion_labels' => Ads()->getOption( 'edd_purchase_conversion_labels' ),
                'edd_initiate_checkout_conversion_labels' => Ads()->getOption( 'edd_initiate_checkout_conversion_labels' ),
                'edd_add_to_cart_conversion_labels' => Ads()->getOption( 'edd_add_to_cart_conversion_labels' ),
                'edd_view_content_conversion_labels' => Ads()->getOption( 'edd_view_content_conversion_labels' ),
                'edd_view_category_conversion_labels' => Ads()->getOption( 'edd_view_category_conversion_labels' ),
            );
            Ads()->resetToDefaults();
            Ads()->updateOptions( $old_options );

            //HeadFooter()->resetToDefaults();

            // do redirect
            wp_safe_redirect( buildAdminUrl( 'pixelyoursite_settings' ) );
            exit;

        }

    }

    private function adminExportCustomAudiences() {

        if ( ! $this->adminSecurityCheck() ) {
            return;
        }

        if ( isset( $_REQUEST['pys']['export_custom_audiences'] )
            && wp_verify_nonce( $_REQUEST['_wpnonce'], 'pys_save_settings' ) ) {

            if ( ! current_user_can( 'manage_pys_data_export' ) ) {
                return;
            }

            if ( $_REQUEST['pys']['export_custom_audiences'] == 'woo' && isWooCommerceActive() ) {
                wooExportCustomAudiences();
            } elseif ( $_REQUEST['pys']['export_custom_audiences'] == 'edd' ) {
                eddExportCustomAudiences();
            }

        }

    }

    public function restoreSettingsAfterCog() {
        $params = array();
        $oldPurchase = $this->getOption("woo_purchase_value_cog");
        $oldContent = $this->getOption("woo_content_value_cog");
        $oldAddCart = $this->getOption("woo_add_to_cart_value_cog");
        $oldInitCheckout = $this->getOption("woo_initiate_checkout_value_cog");

        if($this->getOption('woo_purchase_value_option') == 'cog') {
            if(!empty($oldPurchase)) $params['woo_purchase_value_option'] = $oldPurchase;
            else $params['woo_purchase_value_option'] = "price";
        }
        if($this->getOption('woo_view_content_value_option') == 'cog') {
            if(!empty($oldContent)) $params['woo_view_content_value_option'] = $oldContent;
            else $params['woo_view_content_value_option'] = "price";
        }
        if($this->getOption('woo_add_to_cart_value_option') == 'cog') {
            if(!empty($oldAddCart)) $params['woo_add_to_cart_value_option'] = $oldAddCart;
            else $params['woo_add_to_cart_value_option'] = "price";
        }
        if($this->getOption('woo_initiate_checkout_value_option') == 'cog') {
            if(!empty($oldInitCheckout)) $params['woo_initiate_checkout_value_option'] = $oldInitCheckout;
            else $params['woo_initiate_checkout_value_option'] = "price";
        }

        $params['woo_purchase_value_cog'] = '';
        $params['woo_content_value_cog'] = '';
        $params['woo_add_to_cart_value_cog'] = '';
        $params['woo_initiate_checkout_value_cog'] = '';

        $this->updateOptions($params);
    }

    public function getLog() {
        return $this->logger;
    }

    /**
     * @deprecated Moved to ServerEventsManager
     * @see ServerEventsManager::edd_completed_purchase()
     */
    function edd_completed_purchase( $payment_id ) {
        // This method has been moved to ServerEventsManager class
        // Keeping this stub for backward compatibility
    }
    /**
     * @deprecated Moved to ServerEventsManager
     * @see ServerEventsManager::edd_refund_order()
     */
    function edd_refund_order( $payment_id, $refund_id, $all_refunded ) {
        // This method has been moved to ServerEventsManager class
        // Keeping this stub for backward compatibility
    }
    /**
     * @deprecated Moved to ServerEventsManager
     * @see ServerEventsManager::edd_recurring_payment()
     */
    function edd_recurring_payment( $payment_id, $parent_payment_id, $amount, $transaction_id ) {
        // This method has been moved to ServerEventsManager class
        // Keeping this stub for backward compatibility
    }
    /**
     * @deprecated Moved to ServerEventsManager
     * @see ServerEventsManager::woo_completed_purchase()
     */
    function woo_completed_purchase( $order_id ) {
        // This method has been moved to ServerEventsManager class
        // Keeping this stub for backward compatibility
    }
    /**
     * @deprecated Moved to ServerEventsManager
     * @see ServerEventsManager::woo_refund_order()
     */
    function woo_refund_order( $order_id ) {
        // This method has been moved to ServerEventsManager class
        // Keeping this stub for backward compatibility
    }
    function woo_is_order_received_page() {
        if ( ! isWooCommerceActive() ) {
            return false;
        }

        if(is_order_received_page()) return true;
        global $post;
        $ids = PYS()->getOption("woo_checkout_page_ids");
        if(!empty($ids)) {
            if($post && in_array($post->ID,$ids)) {
                return true;
            }
        }
        if (did_action( 'elementor/loaded' )) {
            if ($post) {
                $elementor_page_id = get_option('elementor_woocommerce_purchase_summary_page_id');
                if ($elementor_page_id == $post->ID) return true;
            }
        }

        if(function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-received')){
            return true;
        }

        return false;
    }

    public function isCachePreload() {
        if(!empty($_SERVER['HTTP_USER_AGENT'])){
	        $options = array('WP Rocket/Preload', 'WP-Rocket-Preload', 'WP Rocket/Homepage_Preload', 'lscache_runner', 'LiteSpeed Cache', 'LiteSpeed-Cache');
	        foreach($options as $row) {
		        if (stripos(strtolower($_SERVER['HTTP_USER_AGENT']), strtolower($row)) !== false) {
			        return true;
		        }
	        }
        }
        return false;
    }
	public function getCurrentUrl() {
		return pys_get_current_page_url();
	}

	/**
	 * The cookie domain for this request.
	 *
	 * @deprecated Use pys_cookie_domain(). Kept as a thin alias because this
	 *             method is public and may be called from add-ons or site code.
	 *
	 * It used to build a parent domain from the last two host labels, which
	 * yields a public suffix on hosts like shop.example.co.uk (".co.uk"), and
	 * browsers reject those — so PHP's write was dropped while our JS wrote at
	 * a different scope. It also ignored track_cookie_for_subdomains.
	 *
	 * @return string Domain to pass to setcookie(), '' for host-only.
	 */
	public function get_wp_cookie_domain() {
		return pys_cookie_domain();
	}

    public function get_variation_info() {
        if (!empty($_POST['attributes']) && !empty($_POST['product_id'])) {
            $product_id = absint($_POST['product_id']);
            $attributes = $_POST['attributes'];

            $product = wc_get_product($product_id);

            if (!$product || !$product->is_type('variable')) {
                wp_send_json_error('Invalid product or not a variable product');
            }

            $variation_id = $this->find_matching_variation($product, $attributes);

            if (!$variation_id) {
                wp_send_json_error('No matching variation found');
            }

            // Get the variation object
            $variation = wc_get_product($variation_id);
            if (!$variation) {
                wp_send_json_error('Variation not found');
            }

            $standardParams = getStandardParams();
            $this->eventsManager = new EventsManager();
            global $product;
            $product = wc_get_product($variation_id);
            // Set the global $post variable
            global $post;
            $post = get_post($variation_id);

            // Form data for pixels
            $events = [];
            $eventId = EventIdGenerator::guidv4();

            foreach ($this->getRegisteredPixels() as $pixel) {
                $tmp_pixel = $pixel;
                if (in_array($pixel->getSlug(), ['ga', 'google_ads'])) {
                    $tmp_pixel = GATags();
                }
                // Facebook's option does not apply under the extension's ID logic; the other pixels
                // read theirs as stored.
                $asSimple = $pixel->getSlug() === 'facebook'
                    ? Facebook\Helpers\facebookVariableAsSimple()
                    : $tmp_pixel->getOption('woo_variable_as_simple');
                if (!$tmp_pixel->getOption('woo_variable_data_select_product') || $asSimple) {
                    continue;
                }

                $view_content_event = new SingleEvent('woo_view_content', EventTypes::$TRIGGER, EventsWoo()->getSlug());
                $view_content_event->args = [
                    "id" => $variation_id,
                    "quantity" => 1,
                    "attributes" => $attributes // Pass variation attributes
                ];

                $pixel_view_content_event = $pixel->generateEvents($view_content_event);
                if (!empty($pixel_view_content_event)) {
                    $event = $pixel_view_content_event[0];
                    $event->addPayload(['eventID' => $eventId]);
	                $slug = $pixel->getSlug();
	                if( $slug !== "tiktok" && $slug !== "reddit" && $slug !== "openai" && $slug !== "awin" ) {
                        $event->addParams($standardParams);
                    }

                    $eventData = EventsManager::filterEventParams($event->getData(), "woo", [
                        'event_id' => $event->getId(),
                        'pixel' => $pixel->getSlug(),
                        'product_id' => $variation_id
                    ]);

                    $events[$pixel->getSlug()]['woo_view_content'] = $eventData;
                }
            }

            wp_send_json_success($events);
        } else {
            wp_send_json_error('Missing attributes or product ID');
        }
    }

    /**
     * The variation matching an explicit attribute set, for the get_variation_info AJAX.
     *
     * The caller already knows the attributes, so there was never a reason to build every
     * variation's display data to find them — see pysGetSelectedVariationId() for what
     * that cost on a theme that filters variation data.
     *
     * @param \WC_Product $product    Parent product.
     * @param array       $attributes Attribute map, with or without the attribute_ prefix.
     *
     * @return int|false Variation id, or false.
     */
    private function find_matching_variation($product, $attributes) {
        if (!is_object($product) || !method_exists($product, 'is_type') || !$product->is_type('variable')) {
            return false;
        }

        $match = array();
        foreach ((array) $attributes as $name => $value) {
            if (!is_scalar($value)) {
                continue;
            }
            $name = (string) $name;
            if (strpos($name, 'attribute_') !== 0) {
                $name = 'attribute_' . $name;
            }
            $match[$name] = wc_clean(wp_unslash((string) $value));
        }

        if (empty($match)) {
            return false;
        }

        // The same two steps as pysGetSelectedVariationId(): the cheap exact query, its
        // match filtered the way get_available_variations() filtered (a hidden or, under
        // "hide out of stock", unavailable variation is not on screen and must not be
        // reported), then the loose scan for what the store cannot answer.
        $id = pysFindMatchingVariation($product, $match);

        if ($id && !pysWooVariationIsListable(wc_get_product($id))) {
            $id = 0;
        }

        if (!$id) {
            $id = pysFindMatchingVariationLoosely($product, $match);
        }

        return $id > 0 ? $id : false;
    }

    public function saveExternalIDInOrder($order_param) {
        // Determine whether the WC_Order object or order ID is passed
        if ( $order_param instanceof WC_Order ) {
            // If the order object is transferred
            $order = $order_param;
        } else {
            // If order_id is passed
            $order = wc_get_order( $order_param );
        }
        if (!$order && empty($order_param)) return;

        $external_id = PYS()->get_pbid();

        if (isWooCommerceVersionGte('3.0.0') && !empty($order)) {
            // WooCommerce >= 3.0
            $order->update_meta_data("external_id", $external_id);
            $order->save();
        } elseif ( ! empty( $order_param ) ) {
            // WooCommerce < 3.0
            update_post_meta($order_param, 'external_id', $external_id);
        }

    }

    public function saveExternalIDInEddOrder($payment_id, $payment_data) {
        if ( ! pys_edd_order_snapshot_allowed( $payment_id ) ) {
            return;
        }

        $external_id = PYS()->get_pbid();

        if ( ! empty( $external_id ) ) {
            edd_update_payment_meta( $payment_id, 'external_id', $external_id );
        }
    }

    /**
     * Filters the WooCommerce REST API order response to remove complex metadata
     * from PixelYourSite Pro that causes JSON parsing issues in third-party integrations.
     *
     * @param \WP_REST_Response $response The response object.
     * @param \WC_Order         $object   The order object.
     * @param \WP_REST_Request  $request  The request object.
     * @return \WP_REST_Response
     */
    public function remove_pys_metadata_from_rest_api( $response, $object, $request ) {
        // Check if the option is enabled
        if ( ! $this->getOption( 'woo_hide_pys_meta_from_rest_api' ) ) {
            return $response;
        }

        // Get the response data
        $data = $response->get_data();

        if ( ! empty( $data['meta_data'] ) ) {
            // Filter out metadata with keys containing 'pys' (case-insensitive)
            $filtered_meta = array_filter( $data['meta_data'], function( $meta ) {
                // Handle both object and array formats
                $key = is_object( $meta ) ? $meta->key : ( isset( $meta['key'] ) ? $meta['key'] : '' );
                // Exclude meta items where the key contains 'pys'
                return stripos( $key, 'pys' ) === false;
            } );

            // Update the meta_data in the response and reset array indexes
            $data['meta_data'] = array_values( $filtered_meta );
            $response->set_data( $data );
        }

        return $response;
    }

	private function get_admin_data(): array {
		$options                 = getGaPixels();
		$merged_options          = call_user_func_array( 'array_merge', array_values( $options ) );
		$merged_options[ 'all' ] = 'All pixels';

		return array(
			'ga'         => array(
				'trackingIds' => $options[ 'ga' ]
			),
			'google_ads' => array(
				'conversion_ids' => $options[ 'ads' ]
			),
			'ga_merged'  => array(
				'ids' => $merged_options
			)
		);
	}
}

/**
 * @return PYS
 */
function PYS() {
    return PYS::instance();
}