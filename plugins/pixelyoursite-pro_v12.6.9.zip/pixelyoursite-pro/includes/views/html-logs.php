<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
$clear_nonce = wp_create_nonce('clear_logs_nonce');
$download_nonce = wp_create_nonce('download_logs_nonce');
?>
<div class="cards-wrapper cards-wrapper-style2 gap-24 logs-wrapper">
    <div class="card card-style3 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center logs_enable">
                <?php PYS()->render_switcher_input( 'logs_enable' ); ?>
                <h4 class="secondary_heading_type2 switcher-label"><?php _e('General plugin logs', 'pys');?></h4>
            </div>
            <div class="head-button-block">
                <div class="d-flex align-items-center logs-lines">
                    <span class="font-medium mr-8"><?php _e( 'Lines to show', 'pys' ); ?></span>
                    <?php PYS()->render_number_input( 'logs_lines_general', '', false, 100000, 100, 100 ); ?>
                </div>
                <a class="btn btn-small btn-gray font-medium ico-button ico-trash" href="<?php echo esc_url( add_query_arg(['clear_general_logs' => 'true', '_wpnonce_clear_logs' => $clear_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>">
                    <span>Clear General logs</span>
                </a>
                <a class="btn btn-small btn-gray font-medium ico-button ico-download" href="<?php echo esc_url( add_query_arg(['download_logs' => 'general', '_wpnonce_download_logs' => $download_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>" target="_blank" download>
                    <span>Download General logs</span>
                </a>
            </div>
        </div>
        <div class="card-body">
        <textarea readonly <?php disabled( !PYS()->getOption('logs_enable') ); ?>><?php
            // Cap an already-oversized file before reading it, even with logging off.
            PYS()->getLog()->maybe_trim();
            echo htmlspecialchars(PYS()->getLog()->getLogs( max( 100, (int) PYS()->getOption( 'logs_lines_general' ) ) ));
            ?></textarea>
        </div>
    </div>
    <?php if ( Facebook()->enabled() ) : ?>
        <div class="card card-style3 card-static">
            <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center logs_enable">
                    <?php Facebook()->render_switcher_input( 'logs_enable' ); ?>
                    <h4 class="secondary_heading_type2 switcher-label">Meta API logs</h4>
                </div>
                <div class="head-button-block">
                    <div class="d-flex align-items-center logs-lines">
                        <span class="font-medium mr-8"><?php _e( 'Lines to show', 'pys' ); ?></span>
                        <?php PYS()->render_number_input( 'logs_lines_meta', '', false, 100000, 100, 100 ); ?>
                    </div>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-trash" href="<?php echo esc_url( add_query_arg(['clear_meta_logs' => 'true', '_wpnonce_clear_logs' => $clear_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>">
                        <span>Clear Meta API logs</span>
                    </a>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-download" href="<?php echo esc_url( add_query_arg(['download_logs' => 'meta', '_wpnonce_download_logs' => $download_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>" target="_blank" download>
                        <span>Download Meta API logs</span>
                    </a>
                </div>
            </div>
            <div class="card-body">
            <textarea readonly <?php disabled( !Facebook()->getOption('logs_enable') ); ?>><?php
                // Cap an already-oversized file before reading it, even with logging off.
                Facebook()->getLog()->maybe_trim();
                echo htmlspecialchars(Facebook()->getLog()->getLogs( max( 100, (int) PYS()->getOption( 'logs_lines_meta' ) ) ));
                ?></textarea>
            </div>
        </div>
    <?php endif; ?>
    <?php if ( GA()->enabled() ) : ?>
        <div class="card card-style3 card-static">
            <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center logs_enable">
                    <?php GA()->render_switcher_input( 'logs_enable' ); ?>
                    <h4 class="secondary_heading_type2 switcher-label">Google API Logs</h4>
                </div>
                <div class="head-button-block">
                    <div class="d-flex align-items-center logs-lines">
                        <span class="font-medium mr-8"><?php _e( 'Lines to show', 'pys' ); ?></span>
                        <?php PYS()->render_number_input( 'logs_lines_ga', '', false, 100000, 100, 100 ); ?>
                    </div>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-trash"
                       href="<?php echo esc_url( add_query_arg(['clear_ga_logs' => 'true', '_wpnonce_clear_logs' => $clear_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>">
                        <span>Clear Google API Logs</span>
                    </a>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-download"
                       href="<?php echo esc_url( add_query_arg(['download_logs' => 'ga', '_wpnonce_download_logs' => $download_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>" target="_blank" download>
                        <span>Download Google API Logs</span>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <textarea readonly <?php disabled( !GA()->getOption('logs_enable') ); ?>><?php
                    // Cap an already-oversized file before reading it, even with logging off.
                    GA()->getLog()->maybe_trim();
                    echo htmlspecialchars(GA()->getLog()->getLogs( max( 100, (int) PYS()->getOption( 'logs_lines_ga' ) ) ));
                    ?></textarea>
            </div>
        </div>
    <?php endif; ?>

    <?php if ( Tiktok()->enabled() ) : ?>
        <div class="card card-style3 card-static">
            <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center logs_enable">
                    <?php Tiktok()->render_switcher_input( 'logs_enable' ); ?>
                    <h4 class="secondary_heading_type2 switcher-label">TikTok API Logs</h4>
                </div>
                <div class="head-button-block">
                    <div class="d-flex align-items-center logs-lines">
                        <span class="font-medium mr-8"><?php _e( 'Lines to show', 'pys' ); ?></span>
                        <?php PYS()->render_number_input( 'logs_lines_tiktok', '', false, 100000, 100, 100 ); ?>
                    </div>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-trash"
                       href="<?php echo esc_url( add_query_arg(['clear_tiktok_logs' => 'true', '_wpnonce_clear_logs' => $clear_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>">
                        <span>Clear TikTok API </span>
                    </a>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-download"
                       href="<?php echo esc_url( add_query_arg(['download_logs' => 'tiktok', '_wpnonce_download_logs' => $download_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>" target="_blank" download>
                        <span>Download TikTok API Logs</span>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <textarea readonly <?php disabled( !Tiktok()->getOption('logs_enable') ); ?>><?php
                    // Cap an already-oversized file before reading it, even with logging off.
                    Tiktok()->getLog()->maybe_trim();
                    echo htmlspecialchars(Tiktok()->getLog()->getLogs( max( 100, (int) PYS()->getOption( 'logs_lines_tiktok' ) ) ));
                    ?></textarea>
            </div>
        </div>
    <?php endif; ?>

    <?php if ( OpenAI()->enabled() ) : ?>
        <div class="card card-style3 card-static">
            <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center logs_enable">
                    <?php OpenAI()->render_switcher_input( 'logs_enable' ); ?>
                    <h4 class="secondary_heading_type2 switcher-label">OpenAI API Logs</h4>
                </div>
                <div class="head-button-block">
                    <div class="d-flex align-items-center logs-lines">
                        <span class="font-medium mr-8"><?php _e( 'Lines to show', 'pys' ); ?></span>
                        <?php PYS()->render_number_input( 'logs_lines_openai', '', false, 100000, 100, 100 ); ?>
                    </div>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-trash"
                       href="<?php echo esc_url( add_query_arg(['clear_openai_logs' => 'true', '_wpnonce_clear_logs' => $clear_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>">
                        <span>Clear OpenAI API Logs</span>
                    </a>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-download"
                       href="<?php echo esc_url( add_query_arg(['download_logs' => 'openai', '_wpnonce_download_logs' => $download_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>" target="_blank" download>
                        <span>Download OpenAI API Logs</span>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <textarea readonly <?php disabled( !OpenAI()->getOption('logs_enable') ); ?>><?php
                    // Cap an already-oversized file before reading it, even with logging off.
                    OpenAI()->getLog()->maybe_trim();
                    echo htmlspecialchars(OpenAI()->getLog()->getLogs( max( 100, (int) PYS()->getOption( 'logs_lines_openai' ) ) ));
                    ?></textarea>
            </div>
        </div>
    <?php endif; ?>

    <?php if ( isPinterestActive() && Pinterest()->enabled() && method_exists(Pinterest(), 'getLog') ) : ?>
        <div class="card card-style3 card-static">
            <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center logs_enable">
                    <?php Pinterest()->render_switcher_input( 'logs_enable' ); ?>
                    <h4 class="secondary_heading_type2 switcher-label">Pinterest API Logs</h4>
                </div>
                <div class="head-button-block">
                    <div class="d-flex align-items-center logs-lines">
                        <span class="font-medium mr-8"><?php _e( 'Lines to show', 'pys' ); ?></span>
                        <?php PYS()->render_number_input( 'logs_lines_pinterest', '', false, 100000, 100, 100 ); ?>
                    </div>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-trash"
                       href="<?php echo esc_url( add_query_arg(['clear_pinterest_logs' => 'true', '_wpnonce_clear_logs' => $clear_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>">
                        <span>Clear Pinterest API Logs</span>
                    </a>
                    <a class="btn btn-small btn-gray font-medium ico-button ico-download"
                       href="<?php echo esc_url( add_query_arg(['download_logs' => 'pinterest', '_wpnonce_download_logs' => $download_nonce],buildAdminUrl( 'pixelyoursite', 'logs' ))); ?>" target="_blank" download>
                        <span>Download Pinterest API Logs</span>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <textarea readonly <?php disabled( !Pinterest()->getOption('logs_enable') ); ?>><?php
                    // Cap an already-oversized file before reading it, even with logging off.
                    Pinterest()->getLog()->maybe_trim();
                    echo htmlspecialchars(Pinterest()->getLog()->getLogs( max( 100, (int) PYS()->getOption( 'logs_lines_pinterest' ) ) ));
                    ?></textarea>
            </div>
        </div>
    <?php endif; ?>
</div>


