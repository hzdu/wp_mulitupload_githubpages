<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * What the Awin conversion needs from a store order.
 */
interface AwinOrder {

	/**
	 * @return string woo|edd
	 */
	public function getStore();

	/**
	 * @return int
	 */
	public function getOrderId();

	/**
	 * The reference the customer sees; the same value in every Awin call.
	 *
	 * @return string
	 */
	public function getOrderRef();

	/**
	 * @return string ISO 4217
	 */
	public function getCurrency();

	/**
	 * Order lines after discounts, before tax. The line ID follows the
	 * store's ID settings.
	 *
	 * @return array<int, array{id: string, name: string, quantity: int, total: float, sku: string, category: string}>
	 */
	public function getLines();

	/**
	 * Sum of the negative fees (a discount booked as a fee), zero or less.
	 *
	 * @return float
	 */
	public function getNegativeFeesTotal();

	/**
	 * @return string[]
	 */
	public function getCouponCodes();

	/**
	 * @return bool|null Null when unknown.
	 */
	public function isNewCustomer();

	/**
	 * The Awin click kept with the order when it was placed.
	 *
	 * @return array{awc?: string, awc_sn?: string, source?: string}
	 */
	public function getClickData();

	/**
	 * @return array|null
	 */
	public function getSnapshot();

	/**
	 * @param array $snapshot
	 */
	public function saveSnapshot( array $snapshot );
}
