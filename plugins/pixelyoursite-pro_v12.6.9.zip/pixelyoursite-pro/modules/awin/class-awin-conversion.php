<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * The single place an Awin sale is computed. The browser tags and the
 * fallback pixel both send what this returns, so they cannot disagree on the
 * reference or the amount.
 */
class AwinConversion {

	const ORDER_REF_MAX = 50;
	const PLT_ID_MAX    = 75;
	const PLT_TEXT_MAX  = 100;

	const FALLBACK_PIXEL     = 'https://www.awin1.com/sread.img';
	const FALLBACK_PIXEL_MAX = 7500;

	/**
	 * @param AwinOrder $order
	 * @return array
	 */
	public static function build( AwinOrder $order ) {

		$awin  = Awin();
		$store = $order->getStore();
		$group = $awin->getCommissionGroup( $store );
		$lines = $order->getLines();

		// Subtotal after discounts, before tax, shipping and fees. A negative
		// fee is a discount and lowers it; the amount never goes below zero.
		$group_totals = array( $group => 0.0 );

		foreach ( $lines as $line ) {
			$group_totals[ $group ] += $line[ 'total' ];
		}

		$group_totals[ $group ] = max( 0.0, $group_totals[ $group ] + $order->getNegativeFeesTotal() );

		// Round each part first: Awin requires the parts to add up to the amount.
		$parts  = array();
		$amount = 0.0;

		foreach ( $group_totals as $code => $total ) {
			$rounded = round( $total, 2 );
			$parts[] = $code . ':' . self::money( $rounded );
			$amount += $rounded;
		}

		$coupons = $awin->getOption( "{$store}_voucher_enabled" ) ? $order->getCouponCodes() : array();
		$consent = Consent()->checkConsent( 'awin' );

		// The click kept with the order, else what this visit still carries.
		$click = array_merge(
			array( 'awc' => '', 'awc_sn' => '', 'source' => '' ),
			array_filter( $awin->getClickCapture()->current( Consent()->hasExplicitConsent( 'awin' ) ) ),
			array_filter( array_intersect_key( $order->getClickData(), array( 'awc' => 1, 'awc_sn' => 1, 'source' => 1 ) ) )
		);

		$data = array(
			'advertiserId' => $awin->getAdvertiserId(),
			'orderRef'     => self::limit( $order->getOrderRef(), self::ORDER_REF_MAX ),
			'amount'       => self::money( $amount ),
			'parts'        => implode( '|', $parts ),
			'currency'     => $order->getCurrency(),
			'voucher'      => isset( $coupons[ 0 ] ) ? (string) $coupons[ 0 ] : '',
			'channel'      => $awin->getChannel( (string) $click[ 'source' ] ),
			'test'         => $awin->isTestMode() ? '1' : '0',
			'custom'       => array(
				'PixelYourSite ' . PYS_VERSION,
				implode( ',', array_slice( $coupons, 1 ) ),
			),
			'consent'      => $consent,
			'click'        => $click,
			'cks'          => implode( ',', array_unique( array_filter( array( $click[ 'awc_sn' ], $consent ? $click[ 'awc' ] : '' ) ) ) ),
			'store'        => $store,
			'orderId'      => $order->getOrderId(),
			'createdAt'    => time(),
		);

		if ( $awin->getOption( "{$store}_customer_acquisition_enabled" ) ) {
			$is_new = $order->isNewCustomer();

			if ( null !== $is_new ) {
				$data[ 'customerAcquisition' ] = $is_new ? 'NEW' : 'RETURNING';
			}
		}

		if ( $awin->getOption( "{$store}_plt_enabled" ) ) {
			$data[ 'plt' ] = array();

			foreach ( $lines as $line ) {
				$data[ 'plt' ][] = array(
					'id'       => self::limit( $line[ 'id' ], self::PLT_ID_MAX ),
					'name'     => self::limit( $line[ 'name' ], self::PLT_TEXT_MAX ),
					'price'    => self::money( round( $line[ 'total' ] / $line[ 'quantity' ], 2 ) ),
					'quantity' => (int) $line[ 'quantity' ],
					'sku'      => $line[ 'sku' ],
					'group'    => $group,
					'category' => self::limit( $line[ 'category' ], self::PLT_TEXT_MAX ),
				);
			}
		}

		return $data;
	}

	/**
	 * One "AW:P|..." line, as the basket form and the fallback pixel carry it.
	 *
	 * The pixel puts the line into its URL as it is, so the values are encoded
	 * there. The MasterTag encodes the basket form itself: encoded values in
	 * the form would reach Awin twice encoded.
	 *
	 * @param array $data    Result of build().
	 * @param array $line    One element of $data['plt'].
	 * @param bool  $encoded URL-encode the values.
	 * @return string
	 */
	public static function formatPltLine( array $data, array $line, $encoded = true ) {

		$fields = array(
			$data[ 'advertiserId' ],
			$data[ 'orderRef' ],
			$line[ 'id' ],
			$line[ 'name' ],
			$line[ 'price' ],
			$line[ 'quantity' ],
			$line[ 'sku' ],
			$line[ 'group' ],
			$line[ 'category' ],
		);

		return 'AW:P|' . implode( '|', array_map( function ( $value ) use ( $encoded ) {
			// Pipes separate the fields, so none may survive inside a value.
			$value = str_replace( '|', '', self::clean( (string) $value ) );

			return $encoded ? rawurlencode( $value ) : $value;
		}, $fields ) );
	}

	/**
	 * The basket form content: one "AW:P|..." line per order line.
	 *
	 * @param array $data Result of build().
	 * @return string
	 */
	public static function basketText( array $data ) {

		$lines = array();

		foreach ( ( isset( $data[ 'plt' ] ) && is_array( $data[ 'plt' ] ) ) ? $data[ 'plt' ] : array() as $line ) {
			$lines[] = self::formatPltLine( $data, $line, false );
		}

		return implode( "\r\n", $lines );
	}

	/**
	 * The fallback image pixel URL, the same sale as the Conversion Tag.
	 *
	 * @param array  $data    Result of build().
	 * @param bool   $consent The visitor's consent right now.
	 * @param string $cks     Comma-joined click IDs, may be empty.
	 * @return string
	 */
	public static function fallbackPixelUrl( array $data, $consent, $cks = '' ) {

		$query = array(
			'tt'       => 'ns',
			'tv'       => '2',
			'merchant' => (string) $data[ 'advertiserId' ],
			'amount'   => (string) $data[ 'amount' ],
			'ch'       => (string) $data[ 'channel' ],
			'parts'    => (string) $data[ 'parts' ],
			'ref'      => (string) $data[ 'orderRef' ],
			'cr'       => (string) $data[ 'currency' ],
			'vc'       => isset( $data[ 'voucher' ] ) ? (string) $data[ 'voucher' ] : '',
			'testmode' => (string) $data[ 'test' ],
		);

		if ( !empty( $data[ 'customerAcquisition' ] ) ) {
			$query[ 'customeracquisition' ] = (string) $data[ 'customerAcquisition' ];
		}

		foreach ( ( isset( $data[ 'custom' ] ) && is_array( $data[ 'custom' ] ) ) ? $data[ 'custom' ] : array() as $index => $value ) {
			$query[ 'p' . ( (int) $index + 1 ) ] = (string) $value;
		}

		if ( $cks !== '' ) {
			$query[ 'cks' ] = $cks;
		}

		$query[ 'cons' ] = $consent ? '1' : '0';

		$url = self::FALLBACK_PIXEL . '?' . http_build_query( $query, '', '&', PHP_QUERY_RFC3986 );

		// Product lines go last and only while the URL stays under Awin's limit.
		foreach ( ( isset( $data[ 'plt' ] ) && is_array( $data[ 'plt' ] ) ) ? array_values( $data[ 'plt' ] ) : array() as $index => $line ) {
			$part = '&bd[' . $index . ']=' . self::formatPltLine( $data, $line );

			if ( strlen( $url ) + strlen( $part ) > self::FALLBACK_PIXEL_MAX ) {
				break;
			}

			$url .= $part;
		}

		return $url;
	}

	/**
	 * @param float $value
	 * @return string
	 */
	public static function money( $value ) {
		return number_format( (float) $value, 2, '.', '' );
	}

	/**
	 * @param string $value
	 * @return string
	 */
	private static function clean( $value ) {
		return trim( (string) preg_replace( '/[\x00-\x1F\x7F]+/u', ' ', $value ) );
	}

	/**
	 * @param string $value
	 * @param int    $max
	 * @return string
	 */
	private static function limit( $value, $max ) {

		$value = self::clean( (string) $value );

		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $max ) : substr( $value, 0, $max );
	}
}
