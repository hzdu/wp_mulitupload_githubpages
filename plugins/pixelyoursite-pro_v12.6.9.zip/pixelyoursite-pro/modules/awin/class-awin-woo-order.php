<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * WooCommerce order adapter for the Awin conversion.
 */
class AwinWooOrder implements AwinOrder {

	const SNAPSHOT_META = '_pys_awin_conversion';

	/** @var \WC_Order */
	private $order;

	/**
	 * @param \WC_Order $order
	 */
	public function __construct( $order ) {
		$this->order = $order;
	}

	public function getStore() {
		return 'woo';
	}

	public function getOrderId() {
		return (int) $this->order->get_id();
	}

	/**
	 * Not part of AwinOrder: only Woo orders have a key.
	 *
	 * @return string
	 */
	public function getOrderKey() {
		return $this->order->get_order_key();
	}

	public function getOrderRef() {
		return (string) $this->order->get_order_number();
	}

	public function getCurrency() {
		return (string) $this->order->get_currency();
	}

	public function getLines() {

		$lines = array();

		foreach ( $this->order->get_items( 'line_item' ) as $item ) {
			/** @var \WC_Order_Item_Product $item */
			$quantity = (int) $item->get_quantity();

			if ( $quantity <= 0 ) {
				continue;
			}

			$product    = $item->get_product();
			$product_id = (int) $item->get_product_id();
			$sku        = $product ? (string) $product->get_sku() : '';

			$lines[] = array(
				'id'       => Awin()->getWooProductId( $product_id, (int) $item->get_variation_id() ),
				'name'     => html_entity_decode( (string) $item->get_name(), ENT_QUOTES, 'UTF-8' ),
				'quantity' => $quantity,
				'total'    => (float) $item->get_total(),
				'sku'      => $sku,
				'category' => $this->getCategoryName( $product_id ),
			);
		}

		return $lines;
	}

	public function getNegativeFeesTotal() {

		$total = 0.0;

		foreach ( $this->order->get_fees() as $fee ) {
			$amount = (float) $fee->get_total();

			if ( $amount < 0 ) {
				$total += $amount;
			}
		}

		return $total;
	}

	public function getCouponCodes() {
		return array_values( array_filter( array_map( 'strval', $this->order->get_coupon_codes() ) ) );
	}

	public function isNewCustomer() {

		EventsWoo()->setNewCustomer( $this->getOrderId() );

		return EventsWoo()->getNewCustomer();
	}

	public function getClickData() {
		$click = $this->order->get_meta( AwinClickCapture::ORDER_META, true );

		return is_array( $click ) ? $click : array();
	}

	public function getSnapshot() {
		$snapshot = $this->order->get_meta( self::SNAPSHOT_META, true );

		return is_array( $snapshot ) && !empty( $snapshot ) ? $snapshot : null;
	}

	public function saveSnapshot( array $snapshot ) {
		$this->order->update_meta_data( self::SNAPSHOT_META, $snapshot );
		self::saveMeta( $this->order );
	}

	/**
	 * Writes the pending meta of an order without saving the order itself.
	 *
	 * A full save fires the order update hooks ("Order updated" webhooks,
	 * ERP/CRM syncs); Awin writes its meta on page views, so it must not.
	 *
	 * @param \WC_Order $order
	 */
	public static function saveMeta( \WC_Order $order ) {

		// HPOS saves the whole order after a meta change unless told not to.
		$skip_save = function () {
			return false;
		};

		add_filter( 'woocommerce_orders_table_datastore_should_save_after_meta_change', $skip_save, PHP_INT_MAX );

		try {
			$order->save_meta_data();
		} finally {
			remove_filter( 'woocommerce_orders_table_datastore_should_save_after_meta_change', $skip_save, PHP_INT_MAX );
		}
	}

	/**
	 * @param int $product_id Parent product ID.
	 * @return string
	 */
	private function getCategoryName( $product_id ) {

		$terms = get_the_terms( $product_id, 'product_cat' );

		if ( empty( $terms ) || is_wp_error( $terms ) ) {
			return '';
		}

		$term = reset( $terms );

		return html_entity_decode( (string) $term->name, ENT_QUOTES, 'UTF-8' );
	}
}
