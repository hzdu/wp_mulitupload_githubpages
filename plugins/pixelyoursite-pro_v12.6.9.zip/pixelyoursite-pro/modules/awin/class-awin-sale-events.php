<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * The Awin Sale on the order confirmation page.
 *
 * Finds the order on its own, so the sale does not depend on the PixelYourSite
 * Purchase event: its toggle, "fire once per transaction" and value filters.
 * Repeats are stopped by the sale's own firedAt mark.
 */
class AwinSaleEvents extends EventsFactory {

	/** Orders that never turn into a sale. */
	const WOO_SKIPPED_STATUSES = array( 'failed', 'cancelled', 'refunded', 'checkout-draft' );

	const EDD_SKIPPED_STATUSES = array( 'failed', 'abandoned', 'refunded', 'revoked' );

	public function __construct() {
		add_filter( 'pys_event_factory', array( $this, 'register' ) );
	}

	/**
	 * @param EventsFactory[] $list
	 * @return EventsFactory[]
	 */
	public function register( $list ) {
		$list[] = $this;

		return $list;
	}

	static function getSlug() {
		return 'awin';
	}

	function getCount() {
		return 0;
	}

	function isEnabled() {
		return Awin()->configured();
	}

	function getEvents() {
		return array( 'woo_purchase', 'edd_purchase' );
	}

	/**
	 * @param string $event
	 * @return bool
	 */
	function isReadyForFire( $event ) {

		switch ( $event ) {
			case 'woo_purchase':
				return Awin()->getOption( 'woo_purchase_enabled' )
					&& isWooCommerceActive()
					&& PYS()->woo_is_order_received_page()
					&& empty( $_REQUEST[ 'wc-api' ] )
					&& wooGetOrderIdFromRequest() > 0;

			case 'edd_purchase':
				return Awin()->getOption( 'edd_purchase_enabled' )
					&& isEddActive()
					&& function_exists( 'edd_get_order' )
					&& edd_is_success_page();
		}

		return false;
	}

	/**
	 * @param string $event
	 * @return SingleEvent|null
	 */
	function getEvent( $event ) {

		switch ( $event ) {
			case 'woo_purchase':
				$order = $this->getWooOrder();
				break;

			case 'edd_purchase':
				$order = $this->getEddOrder();
				break;

			default:
				return null;
		}

		if ( null === $order ) {
			return null;
		}

		$sale_event       = new SingleEvent( $event, EventTypes::$STATIC, $order->getStore() );
		$sale_event->args = array(
			'order_id'   => $order->getOrderId(),
			'awin_order' => $order,
		);

		// The order binding the purchase events carry.
		if ( $order instanceof AwinWooOrder ) {
			$sale_event->addPayload( array(
				'woo_order' => $order->getOrderId(),
				'order_key' => $order->getOrderKey(),
			) );
		} else {
			$sale_event->addPayload( array( 'edd_order' => $order->getOrderId() ) );
		}

		return $sale_event;
	}

	/**
	 * Only Awin gets these events: the other pixels have their own Purchase.
	 *
	 * @return array
	 */
	function generateEvents() {

		if ( !$this->isEnabled() ) {
			return array();
		}

		$events_list = array();

		foreach ( $this->getEvents() as $event_name ) {

			if ( !$this->isReadyForFire( $event_name ) ) {
				continue;
			}

			$event = $this->getEvent( $event_name );

			if ( null === $event ) {
				continue;
			}

			foreach ( Awin()->generateEvents( $event ) as $pixel_event ) {
				$events_list[ 'awin' ][] = $pixel_event;
			}
		}

		return $events_list;
	}

	/**
	 * @return AwinOrder|null
	 */
	private function getWooOrder() {

		if ( !isWooCommerceActive() ) {
			return null;
		}

		$order_id = (int) apply_filters( 'pys_woo_checkout_order_id', wooGetOrderIdFromRequest() );
		$order    = $order_id > 0 ? wc_get_order( $order_id ) : false;

		if ( !$order instanceof \WC_Order || $order->has_status( self::WOO_SKIPPED_STATUSES ) ) {
			return null;
		}

		return new AwinWooOrder( $order );
	}

	/**
	 * @return AwinOrder|null
	 */
	private function getEddOrder() {

		if ( !isEddActive() || !function_exists( 'edd_get_order' ) ) {
			return null;
		}

		$order_id = (int) EventsEdd()->getEddOrderId();
		$order    = $order_id > 0 ? edd_get_order( $order_id ) : false;

		if ( !$order instanceof \EDD\Orders\Order || in_array( $order->status, self::EDD_SKIPPED_STATUSES, true ) ) {
			return null;
		}

		return new AwinEddOrder( $order );
	}
}
