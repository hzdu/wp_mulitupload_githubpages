<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require_once PYS_PATH . '/modules/awin/interface-awin-order.php';
require_once PYS_PATH . '/modules/awin/class-awin-woo-order.php';
require_once PYS_PATH . '/modules/awin/class-awin-edd-order.php';
require_once PYS_PATH . '/modules/awin/class-awin-conversion.php';
require_once PYS_PATH . '/modules/awin/class-awin-click-capture.php';
require_once PYS_PATH . '/modules/awin/class-awin-sale-events.php';

/**
 * Awin affiliate tracking module.
 *
 * Client-side stack: MasterTag, Conversion Tag (AWIN.Tracking.Sale), fallback
 * image pixel and Product Level Tracking. Purchase is the only event.
 * One Advertiser ID per request: the MasterTag keeps its state in a single
 * global, so Awin has no multi-pixel mode.
 */
class Awin extends Settings implements Pixel {

	private static $_instance;

	private $moduleName = 'Awin';

	/** @var AwinOrder[] Sales handed to the browser on this request. */
	private $pageSales = array();

	/** @var AwinClickCapture */
	private $clickCapture;

	/** @var AwinSaleEvents */
	private $saleEvents;

	const STORES = array( 'woo', 'edd' );

	const WOO_CONTENT_ID_SOURCES = array( 'product_id', 'product_sku', 'custom_field' );

	const EDD_CONTENT_ID_SOURCES = array( 'download_id', 'download_sku' );

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function getModuleName() {
		return $this->moduleName;
	}

	public function __construct() {
		parent::__construct( 'awin' );
		$this->locateOptions(
			PYS_PATH . '/modules/awin/options_fields.json',
			PYS_PATH . '/modules/awin/options_defaults.json'
		);

		add_action( 'pys_register_pixels', function ( $core ) {
			/** @var PYS $core */
			$core->registerPixel( $this );
		} );

		add_action( 'wp_footer', array( $this, 'outputSaleTags' ), 9 );

		$this->clickCapture = new AwinClickCapture();

		$this->saleEvents = new AwinSaleEvents();

		add_filter( 'pys_awin_settings_sanitize_pixel_id_field', array( $this, 'sanitizeAdvertiserIds' ) );
		add_filter( 'pys_awin_settings_sanitize_default_channel_field', array( $this, 'sanitizeChannel' ) );

		foreach ( self::STORES as $store ) {
			add_filter( "pys_awin_settings_sanitize_{$store}_commission_group_default_field", array( $this, 'sanitizeCommissionGroup' ) );
		}

		add_filter( 'pys_awin_settings_sanitize_woo_content_id_field', array( $this, 'sanitizeWooContentId' ) );
		add_filter( 'pys_awin_settings_sanitize_edd_content_id_field', array( $this, 'sanitizeEddContentId' ) );
	}

	public function enabled() {
		return (bool) $this->getOption( 'main_pixel_enabled' );
	}

	public function configured() {

		$license_status = PYS()->getOption( 'license_status' );

		return !empty( $license_status )
			&& count( $this->getPixelIDs() ) > 0
			&& $this->enabled();
	}

	/**
	 * The Advertiser ID (MID) for this request, as a one-element list.
	 *
	 * @return array
	 */
	public function getPixelIDs() {

		$stored = (array) $this->getOption( 'pixel_id' );
		$id     = isset( $stored[ 0 ] ) ? (string) $stored[ 0 ] : '';

		// Lets a site pick the programme per language, domain or currency.
		$id = (string) apply_filters( 'pys_awin_advertiser_id', $id );

		return self::isValidAdvertiserId( $id ) ? array( $id ) : array();
	}

	/**
	 * @return string
	 */
	public function getAdvertiserId() {
		$ids = $this->getPixelIDs();

		return empty( $ids ) ? '' : $ids[ 0 ];
	}

	/**
	 * The official "Awin - Advertiser Tracking for WooCommerce" plugin reports
	 * the same sale a second time.
	 *
	 * @return bool
	 */
	public static function isOfficialPluginActive() {

		if ( !function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( 'awin-advertiser-tracking/awin-advertiser-tracking.php' );
	}

	public function isTestMode() {
		return (bool) $this->getOption( 'test_mode' );
	}

	/**
	 * Awin's own consent model: the tags run without consent and carry
	 * AdvertiserConsent=false / cons=0, so Awin sets no cookies itself.
	 * Off means the PYS model: no consent, no Awin at all.
	 *
	 * @return bool
	 */
	public function loadsBeforeConsent() {
		return (bool) apply_filters( 'pys_awin_consent_mode', (bool) $this->getOption( 'load_before_consent' ) );
	}

	/**
	 * @return array
	 */
	public function getPixelOptions() {
		return array(
			'advertiserId'      => $this->getAdvertiserId(),
			'testMode'          => $this->isTestMode(),
			'loadBeforeConsent' => $this->loadsBeforeConsent(),
			'excluded'          => $this->isExcludedPage(),
		);
	}

	/**
	 * Awin keeps its tags off pages that show or process payment data. The
	 * order confirmation page is not one of them: it needs the MasterTag.
	 *
	 * @return bool
	 */
	public function isExcludedPage() {

		$excluded = false;

		if ( isWooCommerceActive() && function_exists( 'is_checkout' ) ) {
			$excluded = ( is_checkout() && !is_wc_endpoint_url( 'order-received' ) )
				|| is_wc_endpoint_url( 'order-pay' );
		}

		if ( !$excluded && isEddActive() && function_exists( 'edd_is_checkout' ) ) {
			$excluded = edd_is_checkout() && !( function_exists( 'edd_is_success_page' ) && edd_is_success_page() );
		}

		return (bool) apply_filters( 'pys_awin_excluded_page', $excluded );
	}

	/**
	 * Last-click channel sent with every sale.
	 *
	 * @return string
	 */
	public function getChannel( $source = '' ) {

		$channel = (string) $this->getOption( 'default_channel' );
		$channel = $channel !== '' ? $channel : 'aw';

		if ( $source !== '' && $this->getOption( 'source_param_enabled' ) ) {
			$channel = $source;
		}

		return $this->sanitizeChannel( apply_filters( 'pys_awin_channel', $channel, $source ) );
	}

	/**
	 * The commission group code for a store, safe to put into parts. Read
	 * through the sanitiser: an imported Site Profile writes options raw.
	 *
	 * @param string $store woo|edd
	 * @return string
	 */
	public function getCommissionGroup( $store ) {
		return $this->sanitizeCommissionGroup( $this->getOption( "{$store}_commission_group_default" ) );
	}

	/**
	 * The product ID sent in a WooCommerce PLT line, per the Awin ID settings.
	 * A product without the chosen SKU or custom field falls back to its ID.
	 *
	 * @param int $product_id   Parent product ID.
	 * @param int $variation_id Variation ID, 0 for a simple product.
	 * @return string
	 */
	public function getWooProductId( $product_id, $variation_id = 0 ) {

		$product_id = (int) $product_id;
		$id         = ( $variation_id > 0 && !$this->getOption( 'woo_variable_as_simple' ) ) ? (int) $variation_id : $product_id;

		if ( isWPMLActive() ) {
			$id = (int) getWPMLProductId( $id, $this );
		}

		$source = $this->sanitizeWooContentId( $this->getOption( 'woo_content_id' ) );
		$value  = '';

		if ( 'product_sku' === $source ) {
			$product = wc_get_product( $id );
			$value   = $product ? (string) $product->get_sku() : '';

			if ( '' === $value && $product && $product->is_type( 'variation' ) ) {
				$parent = wc_get_product( $product->get_parent_id() );
				$value  = $parent ? (string) $parent->get_sku() : '';
			}
		} elseif ( 'custom_field' === $source ) {
			$field = trim( (string) $this->getOption( 'woo_content_id_custom_field_name' ) );

			if ( '' !== $field ) {
				$value = (string) get_post_meta( $id, $field, true );

				if ( '' === $value && $id !== $product_id ) {
					$value = (string) get_post_meta( $product_id, $field, true );
				}

				if ( '' === $value ) {
					PysContentIdScanner::logMissingProduct( 'awin', $id );
				}
			}
		}

		if ( '' === $value ) {
			$value = (string) $id;
		}

		$prefix = trim( (string) $this->getOption( 'woo_content_id_prefix' ) );
		$suffix = trim( (string) $this->getOption( 'woo_content_id_suffix' ) );

		return $prefix . $value . $suffix;
	}

	/**
	 * The download ID sent in an EDD PLT line, per the Awin ID settings.
	 *
	 * @param int      $download_id
	 * @param int|null $price_id Price option, null for a download without variable prices.
	 * @return string
	 */
	public function getEddDownloadId( $download_id, $price_id = null ) {
		return (string) getEddContentId( $this, (int) $download_id, $price_id );
	}

	/**
	 * @return AwinClickCapture
	 */
	public function getClickCapture() {
		return $this->clickCapture;
	}

	/**
	 * @return AwinSaleEvents
	 */
	public function getSaleEvents() {
		return $this->saleEvents;
	}

	/**
	 * The Sale is the only event Awin tracks. It comes from AwinSaleEvents,
	 * not from the PixelYourSite Purchase event.
	 *
	 * @param SingleEvent $event
	 * @return array
	 */
	public function generateEvents( $event ) {

		if ( !$this->configured() ) {
			return array();
		}

		$order = is_array( $event->args ) && isset( $event->args[ 'awin_order' ] ) ? $event->args[ 'awin_order' ] : null;

		if ( !$order instanceof AwinOrder ) {
			return array();
		}

		$sale = $this->getSale( $order );

		// Awin gets each order once, whatever the purchase event settings.
		if ( empty( $sale ) || !empty( $sale[ 'firedAt' ] ) ) {
			return array();
		}

		$this->pageSales[ $order->getStore() . ':' . $order->getOrderId() ] = $order;

		$pixelEvent = clone $event;
		$pixelEvent->addPayload( array(
			'name'     => 'Sale',
			'pixelIds' => array( $sale[ 'advertiserId' ] ),
		) );
		$pixelEvent->addParams( array( 'sale' => $sale ) );

		return array( $pixelEvent );
	}

	/**
	 * The sale for an order: computed on first sight, then reused, so every
	 * later render sends exactly the same values.
	 *
	 * @param AwinOrder $order
	 * @return array
	 */
	public function getSale( AwinOrder $order ) {

		$sale = $order->getSnapshot();

		if ( null === $sale ) {
			$sale = (array) apply_filters( 'pys_awin_conversion_data', AwinConversion::build( $order ), $order );
			$order->saveSnapshot( $sale );
		}

		return $sale;
	}

	/**
	 * The fallback pixel is not a noscript tag: outputSaleTags() prints it
	 * next to the Conversion Tag.
	 */
	public function outputNoScriptEvents() {
	}

	/**
	 * The basket form and the fallback pixel for the sales of this page.
	 *
	 * Runs on wp_footer before the footer scripts, so the form is in the DOM
	 * before the MasterTag reads it. Printing the pixel is what marks the order
	 * as sent: a render that never reaches the footer does not use it up.
	 */
	public function outputSaleTags() {

		foreach ( $this->pageSales as $key => $order ) {
			unset( $this->pageSales[ $key ] );

			$sale = $this->getSale( $order );

			if ( !empty( $sale[ 'firedAt' ] ) ) {
				continue;
			}

			$basket = AwinConversion::basketText( $sale );

			if ( $basket !== '' ) {
				?>
				<form style="display:none;" name="aw_basket_form"><textarea wrap="physical" id="aw_basket"><?php echo esc_textarea( $basket ); ?></textarea></form>
				<?php
			}

			$may_fire       = Consent()->mayFire( 'awin' );
			$incentive_only = !$may_fire && $this->sendsIncentiveWithoutConsent( $sale );

			if ( !$may_fire && !$incentive_only ) {
				continue;
			}

			$consent = $may_fire && Consent()->checkConsent( 'awin' );

			$url = (string) apply_filters( 'pys_awin_fallback_pixel_url',
				AwinConversion::fallbackPixelUrl( $sale, $consent, $this->getClickIds( $consent, $sale ) ), $sale );
			?>
			<img src="<?php echo esc_url( $url ); ?>" width="0" height="0" border="0" alt="" style="display:none;" loading="eager" decoding="async" data-no-lazy="1" data-skip-lazy="1" class="skip-lazy">
			<?php

			$sale[ 'firedAt' ] = time();
			$order->saveSnapshot( $sale );
		}
	}

	/**
	 * Whether a sale may go out without consent: it carries a cashback click
	 * and the site has not switched this off.
	 *
	 * @param array $sale
	 * @return bool
	 */
	private function sendsIncentiveWithoutConsent( array $sale ) {

		if ( $this->getClickIds( false, $sale ) === '' ) {
			return false;
		}

		return (bool) apply_filters( 'pys_awin_incentive_without_consent', true, $sale );
	}

	/**
	 * Awin click IDs as the pixel's cks value: the click kept with the order
	 * first, then the visitor's cookies. The incentive (sn) click is strictly
	 * necessary and needs no consent; the normal click does.
	 *
	 * @param bool  $consent
	 * @param array $sale Result of getSale(), may be empty.
	 * @return string
	 */
	public function getClickIds( $consent, array $sale = array() ) {

		$mid    = $this->getAdvertiserId();
		$stored = isset( $sale[ 'click' ] ) && is_array( $sale[ 'click' ] ) ? $sale[ 'click' ] : array();

		$values = array(
			isset( $stored[ 'awc_sn' ] ) ? (string) $stored[ 'awc_sn' ] : '',
			$this->cookieValue( AwinClickCapture::COOKIE_INCENTIVE ),
			$this->cookieValue( '_aw_sn_' . $mid ),
		);

		if ( $consent ) {
			$values[] = isset( $stored[ 'awc' ] ) ? (string) $stored[ 'awc' ] : '';
			$values[] = $this->cookieValue( AwinClickCapture::COOKIE_CLICK );
			$values[] = $this->cookieValue( '_aw_m_' . $mid );
		}

		$ids = array_values( array_unique( array_filter( $values, array( AwinClickCapture::class, 'isValidClick' ) ) ) );

		return implode( ',', array_unique( (array) apply_filters( 'pys_awin_click_ids', $ids, $consent ) ) );
	}

	/**
	 * @param string $name
	 * @return string
	 */
	private function cookieValue( $name ) {
		return isset( $_COOKIE[ $name ] ) ? (string) wp_unslash( $_COOKIE[ $name ] ) : '';
	}

	public static function isValidAdvertiserId( $id ) {
		return is_string( $id ) && preg_match( '/^\d{1,12}$/', $id ) === 1;
	}

	/**
	 * Keeps the first valid numeric ID only.
	 *
	 * @param mixed $values
	 * @return array
	 */
	public function sanitizeAdvertiserIds( $values ) {

		foreach ( (array) $values as $value ) {
			$value = is_scalar( $value ) ? trim( (string) $value ) : '';

			if ( self::isValidAdvertiserId( $value ) ) {
				return array( $value );
			}
		}

		return array();
	}

	/**
	 * @param mixed $value
	 * @return string
	 */
	public function sanitizeChannel( $value ) {

		$value = is_scalar( $value ) ? strtolower( trim( (string) $value ) ) : '';
		$value = substr( preg_replace( '/[^a-z0-9_-]/', '', $value ), 0, 50 );

		return $value !== '' ? $value : 'aw';
	}

	/**
	 * Awin accepts upper-case letters, digits, "_", "." and "-" in a code.
	 *
	 * @param mixed $value
	 * @return string
	 */
	public function sanitizeCommissionGroup( $value ) {

		$value = is_scalar( $value ) ? strtoupper( trim( (string) $value ) ) : '';
		$value = substr( preg_replace( '/[^A-Z0-9_.\-]/', '', $value ), 0, 50 );

		return $value !== '' ? $value : 'DEFAULT';
	}

	/**
	 * @param mixed $value
	 * @return string
	 */
	public function sanitizeWooContentId( $value ) {

		$value = is_scalar( $value ) ? (string) $value : '';

		return in_array( $value, self::WOO_CONTENT_ID_SOURCES, true ) ? $value : self::WOO_CONTENT_ID_SOURCES[ 0 ];
	}

	/**
	 * @param mixed $value
	 * @return string
	 */
	public function sanitizeEddContentId( $value ) {

		$value = is_scalar( $value ) ? (string) $value : '';

		return in_array( $value, self::EDD_CONTENT_ID_SOURCES, true ) ? $value : self::EDD_CONTENT_ID_SOURCES[ 0 ];
	}
}

/**
 * @return Awin
 */
function Awin() {
	return Awin::instance();
}

Awin();
