<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Easy Digital Downloads (3.x) order adapter for the Awin conversion.
 */
class AwinEddOrder implements AwinOrder {

	const SNAPSHOT_META = '_pys_awin_conversion';

	/** @var \EDD\Orders\Order */
	private $order;

	/**
	 * @param \EDD\Orders\Order $order
	 */
	public function __construct( $order ) {
		$this->order = $order;
	}

	public function getStore() {
		return 'edd';
	}

	public function getOrderId() {
		return (int) $this->order->id;
	}

	public function getOrderRef() {
		return (string) $this->order->get_number();
	}

	public function getCurrency() {
		return (string) $this->order->currency;
	}

	public function getLines() {

		$lines = array();

		foreach ( $this->order->get_items() as $item ) {
			/** @var \EDD\Orders\Order_Item $item */
			$quantity = (int) $item->quantity;

			if ( $quantity <= 0 ) {
				continue;
			}

			$download_id = (int) $item->product_id;
			$sku         = function_exists( 'edd_get_download_sku' ) ? (string) edd_get_download_sku( $download_id ) : '';

			// EDD reports a missing SKU as "-".
			if ( '-' === $sku ) {
				$sku = '';
			}

			// A price option is "{download}-{price}", as in the other pixels and the feeds.
			$price_id = ( null !== $item->price_id && function_exists( 'edd_has_variable_prices' ) && edd_has_variable_prices( $download_id ) )
				? (int) $item->price_id : null;

			$lines[] = array(
				'id'       => Awin()->getEddDownloadId( $download_id, $price_id ),
				'name'     => html_entity_decode( (string) $item->product_name, ENT_QUOTES, 'UTF-8' ),
				'quantity' => $quantity,
				// The subtotal is before tax even with tax-inclusive prices.
				'total'    => (float) $item->subtotal - (float) $item->discount,
				'sku'      => $sku,
				'category' => $this->getCategoryName( $download_id ),
			);
		}

		return $lines;
	}

	public function getNegativeFeesTotal() {

		$total = 0.0;

		foreach ( $this->getFees() as $fee ) {
			$amount = (float) $fee->subtotal;

			if ( $amount < 0 ) {
				$total += $amount;
			}
		}

		return $total;
	}

	public function getCouponCodes() {

		$codes = array();

		foreach ( edd_get_order_adjustments( array(
			'object_id'   => $this->getOrderId(),
			'object_type' => 'order',
			'type'        => 'discount',
			'orderby'     => 'id',
			'order'       => 'ASC',
			'number'      => 100,
		) ) as $discount ) {
			if ( (string) $discount->description !== '' ) {
				$codes[] = (string) $discount->description;
			}
		}

		return $codes;
	}

	public function isNewCustomer() {

		EventsEdd()->setNewCustomer( $this->getOrderId() );

		return EventsEdd()->getNewCustomer();
	}

	public function getClickData() {
		$click = edd_get_order_meta( $this->getOrderId(), AwinClickCapture::ORDER_META, true );

		return is_array( $click ) ? $click : array();
	}

	public function getSnapshot() {
		$snapshot = edd_get_order_meta( $this->getOrderId(), self::SNAPSHOT_META, true );

		return is_array( $snapshot ) && !empty( $snapshot ) ? $snapshot : null;
	}

	public function saveSnapshot( array $snapshot ) {
		edd_update_order_meta( $this->getOrderId(), self::SNAPSHOT_META, $snapshot );
	}

	/**
	 * Order-level fees and the fees attached to single items.
	 *
	 * @return array
	 */
	private function getFees() {

		$query = array(
			'type'   => 'fee',
			'number' => 100,
		);

		$fees = edd_get_order_adjustments( $query + array(
			'object_id'   => $this->getOrderId(),
			'object_type' => 'order',
		) );

		foreach ( $this->order->get_items() as $item ) {
			$fees = array_merge( $fees, edd_get_order_adjustments( $query + array(
				'object_id'   => (int) $item->id,
				'object_type' => 'order_item',
			) ) );
		}

		return $fees;
	}

	/**
	 * @param int $download_id
	 * @return string
	 */
	private function getCategoryName( $download_id ) {

		$terms = get_the_terms( $download_id, 'download_category' );

		if ( empty( $terms ) || is_wp_error( $terms ) ) {
			return '';
		}

		$term = reset( $terms );

		return html_entity_decode( (string) $term->name, ENT_QUOTES, 'UTF-8' );
	}
}
