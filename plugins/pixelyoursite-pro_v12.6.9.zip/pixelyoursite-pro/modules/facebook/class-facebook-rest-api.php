<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Facebook REST API handler
 *
 * Extends AbstractRestAPI to handle Facebook server events via REST API
 */
class Facebook_REST_API extends AbstractRestAPI {

    /**
     * Get the REST API namespace
     *
     * @return string
     */
    protected function getRestNamespace() {
        return 'pys-facebook/v1';
    }

    /**
     * Get the server instance for Facebook
     *
     * @return FacebookServer
     */
    protected function getServerInstance() {
        return FacebookServer();
    }

    /**
     * Get the pixel instance for Facebook
     *
     * @return Facebook
     */
    protected function getPixelInstance() {
        return Facebook();
    }

    /**
     * Check if Facebook server API is enabled
     *
     * @return bool
     */
    protected function isServerApiEnabled() {
        return Facebook()->isServerApiEnabled();
    }

    /**
     * Get the localized script variable name
     *
     * @return string
     */
    protected function getScriptVariableName() {
        return 'pysFacebookRest';
    }

    /**
     * Extend abstract args with Facebook-specific `referrer_url`.
     * Kept here (not in AbstractRestAPI) to avoid affecting TikTok/Pinterest.
     */
    protected function get_event_args() {
        $args = parent::get_event_args();
        $args['referrer_url'] = [
            'required'          => false,
            'type'              => 'string',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ];
        $args['event_source_url'] = [
            'required'          => false,
            'type'              => 'string',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ];
        return $args;
    }

    /**
     * Override to capture `referrer_url` from the request payload and attach
     * it to the SingleEvent before dispatch. ServerEventHelper reads this
     * value from the payload when building CustomData for Meta CAPI.
     */
    public function handle_event( $request ) {
        $this->getPixelInstance()->getLog()->debug(
            'handleEvent send to ' . ucfirst( $this->getPlatformName() ) . ' server from REST API'  .
            ' event: ' . $request->get_param( 'event' ) .
            ' eventID: ' . $request->get_param( 'eventID' )
        );

        $event        = $request->get_param( 'event' );
        $data         = $request->get_param( 'data' ) ?: [];
        $ids          = $request->get_param( 'ids' );
        $event_id     = $request->get_param( 'eventID' );
        $woo_order    = $request->get_param( 'woo_order' );
        $edd_order    = $request->get_param( 'edd_order' );
        $event_slug   = $request->get_param( 'event_slug' );
        $referrer_url = $request->get_param( 'referrer_url' );
        $event_source_url = $request->get_param( 'event_source_url' );

        // Variant B fallback: when the browser did not send an explicit page
        // URL, use this REST request's Referer header. For a fetch/sendBeacon
        // fired from the visitor's page, Referer IS that page URL — which is
        // what Meta expects for event_source_url (never the REST endpoint).
        if ( empty( $event_source_url ) ) {
            $referer = $request->get_header( 'referer' );
            if ( ! empty( $referer ) ) {
                $event_source_url = esc_url_raw( $referer );
            }
        }

        if ( empty( $event ) || empty( $ids ) ) {
            return new \WP_Error(
                'missing_parameters',
                'Missing mandatory parameters: event and ids',
                [ 'status' => 400 ]
            );
        }

        if ( $event === 'hCR' ) {
            $event = 'CompleteRegistration';
        }

        $single_event = $this->data_to_single_event(
            $event, $data, $event_id, $ids, $woo_order, $edd_order, $event_slug
        );

        if ( ! empty( $referrer_url ) && pys_is_valid_public_url( $referrer_url ) ) {
            $single_event->addPayload( [ 'referrer_url' => $referrer_url ] );
        }

        if ( ! empty( $event_source_url ) && pys_is_valid_public_url( $event_source_url ) ) {
            $single_event->addPayload( [ 'event_source_url' => $event_source_url ] );
        }

        // Authentication and the send both run inside the task: the user is needed
        // while the payload is built in sendEventsNow(), and it may run after the
        // response (see pys_run_after_rest_response()).
        $use_queue = $this->server_instance->isQueueEnabled() && PYS()->getOption( 'queue_use_for_ajax' );
        $send      = function () use ( $single_event, $use_queue ) {
            $authenticated = false;
            try {
                $authenticated = $this->authenticateVisitor();
                if ( $use_queue ) {
                    $this->server_instance->sendEventsToQueue( [ $single_event ] );
                } else {
                    $this->server_instance->sendEventsNow( [ $single_event ] );
                }
            } catch ( \Throwable $e ) {
                $this->getPixelInstance()->getLog()->error( ucfirst( $this->getPlatformName() ) . ' REST event send failed', $e );
            } finally {
                if ( $authenticated ) {
                    // Back to the state this request had before us: anonymous.
                    wp_set_current_user( 0 );
                }
            }
        };

        // The queue write is already fast, so it stays synchronous.
        if ( $use_queue ) {
            $send();
        } else {
            // Headers are already sent at shutdown, so _fbp/_fbc can only be
            // set now; the send then finds them in the statics.
            $this->mintCookiesBeforeDeferral( $data, $woo_order, $edd_order );
            pys_run_after_rest_response( $send );
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    /**
     * The cookie step of ServerEventHelper::mapEventToServerEvent(), run while
     * the response headers can still be sent. The deferred send runs at
     * shutdown, when they are gone: _fbp/_fbc would no longer be minted. After
     * this the statics are set, so the send does not mint a second time.
     */
    private function mintCookiesBeforeDeferral( $params, $woo_order, $edd_order ) {
        $order = null;
        if ( $woo_order && isWooCommerceActive() ) {
            $order = \wc_get_order( $woo_order ) ?: null;
        }
        $order_bound = $order || ! empty( $edd_order );

        $signal_order = $order;
        if ( ! $signal_order && $edd_order && isEddActive() ) {
            $signal_order = pys_edd_order_signal_source( $edd_order );
        }
        $signals = pys_event_client_signals(
            $signal_order,
            pys_client_ip_for_capi(),
            ! empty( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : null,
            pys_is_admin_page_request()
        );

        // Same conditions as the send path.
        if ( ! $signals['request_cookies'] ) {
            return;
        }
        if ( ParamBuilderAdapter::is_enabled() ) {
            ParamBuilderAdapter::for_request()->flush_cookies();
        } elseif ( Consent()->checkConsent( 'facebook' ) ) {
            ServerEventHelper::mintBrowserCookies( is_array( $params ) ? $params : array(), $order_bound );
        }
    }
}

/**
 * Accessor function for Facebook REST API
 *
 * @return Facebook_REST_API
 */
function Facebook_REST_API() {
    static $instance = null;
    if ( $instance === null ) {
        $instance = new Facebook_REST_API();
    }
    return $instance;
}
