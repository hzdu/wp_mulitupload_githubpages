<?php

namespace PixelYourSite\TikTok\Helpers;

use PixelYourSite;
use function PixelYourSite\wooGetOrderIdFromRequest;
use function PixelYourSite\wooIsRequestContainOrderId;
use function PixelYourSite\isWPMLActive;
use function PixelYourSite\getWPMLProductId;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * @param string $product_id
 *
 * @return array
 */
function getTikTokWooProductContentId( $product_id ) {
    return PixelYourSite\getWooProductItemId( $product_id, PixelYourSite\Tiktok(), true );
}

/**
 * Group ID for a variable product (TikTok `product_group` events):
 * the parent's post ID with the TikTok prefix and suffix.
 *
 * @param int $product_id Parent or variation post ID.
 *
 * @return string
 */
function getTikTokWooProductGroupId( $product_id ) {
    return PixelYourSite\getWooProductGroupId( $product_id, PixelYourSite\Tiktok(), true );
}

function getTikTokWooProductDataId( $item ) {

    if($item['type'] == 'variation') {
        if(PixelYourSite\Tiktok()->getOption( 'woo_variable_as_simple' ) ) {
            $product_id = $item['parent_id'];
        } else {
            $product_id = $item['product_id'];
        }
    } else {
        $product_id = $item['product_id'];
    }

    return $product_id;

}

function getTikTokWooCartProductId( $product ) {

    $product_id = $product['product_id'];

    if ( PixelYourSite\Tiktok()->getOption( 'woo_variable_as_simple' )
        && isset( $product['parent_id'] ) && $product['parent_id'] !== 0 ) {
        $product_id = $product['parent_id'];
    }

    return $product_id;
}

/**@deprecated use getFacebookWooCartProductId
 * @param $item
 * @return int|mixed
 */
function getTikTokWooCartItemId( $item ) {

    if ( ! PixelYourSite\Tiktok()->getOption( 'woo_variable_as_simple' ) && isset( $item['variation_id'] ) && $item['variation_id'] !== 0 ) {
        $product_id = $item['variation_id'];
    } else {
        $product_id = $item['product_id'];
    }


    return $product_id;
}

function get_tt_plugin_retailer_id( $woo_product ) {
    if(!$woo_product) return "";
    $woo_id = $woo_product->get_id();

    // Call $woo_product->get_id() instead of ->id to account for Variable
    // products, which have their own variant_ids.
    return $woo_product->get_sku() ? $woo_product->get_sku() . '_' .
        $woo_id : 'wc_post_id_'. $woo_id;
}



function getWooSingleAddToCartParams( $product_id, $qty = 1, $is_external = false ) {

	$params = array(
		'post_type'        => 'product',
		'product_id'       => getTikTokWooProductContentId($product_id),
		'quantity' => $qty,
	);

	//@todo: track "product_variant_id"

	// content_name, category_name, tags
	$params['tags'] = implode( ', ', PixelYourSite\getObjectTerms( 'product_tag', $product_id ) );
	$params = array_merge( $params, getWooCustomAudiencesOptimizationParams( $product_id ) );

	// set option names
	$value_enabled_option = $is_external ? 'woo_affiliate_value_enabled' : 'woo_add_to_cart_value_enabled';
	$value_option_option  = $is_external ? 'woo_affiliate_value_option' : 'woo_add_to_cart_value_option';
	$value_global_option  = $is_external ? 'woo_affiliate_value_global' : 'woo_add_to_cart_value_global';
	$value_percent_option = $is_external ? '' : 'woo_add_to_cart_value_percent';

	// currency, value
	if ( PixelYourSite\PYS()->getOption( $value_enabled_option ) ) {

		$value_option   = PixelYourSite\PYS()->getOption( $value_option_option );
		$global_value   = PixelYourSite\PYS()->getOption( $value_global_option, 0 );
		$percents_value = PixelYourSite\PYS()->getOption( $value_percent_option, 100 );

		$params['value']    = PixelYourSite\getWooEventValue( $value_option, $global_value, $percents_value,$product_id,$qty );
		$params['currency'] = get_woocommerce_currency();

	}

	$params['price'] = PixelYourSite\getWooProductPriceToDisplay( $product_id );

	if ( $is_external ) {
		$params['action'] = 'affiliate button click';
	}

	return $params;

}

function getWooCustomAudiencesOptimizationParams( $post_id ) {

	$post = get_post( $post_id );

	$params = array(
		'content_name'  => '',
		'category_name' => '',
	);

	if ( ! $post ) {
		return $params;
	}

	if ( $post->post_type == 'product_variation' ) {
		$post_id = $post->post_parent; // get terms from parent
	}

	$params['content_name']  = $post->post_title;
	$params['category_name'] = implode( ', ', PixelYourSite\getObjectTerms( 'product_cat', $post_id ) );

	return $params;

}

function getTikTokWooVariableToSimpleProductId ( $product ) {
	if ( PixelYourSite\Tiktok()->getOption( 'woo_variable_as_simple' ) && $product->get_type() == 'variation' ) {
		$product_id = $product->get_parent_id();
	} else {
		$product_id = $product->get_id();
	}

	return $product_id;
}
/**
 * Name of the first-party cookie PYS uses to persist the TikTok click id.
 *
 * Deliberately not `ttclid`: the TikTok pixel SDK owns a cookie of that name on
 * our own domain, and its stored format is TikTok's to change. We read theirs
 * first and only fall back to ours, so the two never fight over one value.
 */
const TTCLID_COOKIE = 'pys_ttclid';

/**
 * Read the ad click identifier off the current request URL.
 *
 * Kept separate from the stored value on purpose: reading the URL is what turns
 * a bare ad click into tracking data, so only the consent-gated capture path may
 * call it - exactly how ServerEventHelper reaches for `fbclid`.
 *
 * Unlike Meta's fbc, the Events API expects the bare click id, with no
 * `tt.1.<timestamp>.` style prefix, so the value is returned as-is.
 *
 * @return string Empty string when the URL carries no click id.
 */
function getTtclidFromUrl() {

	if ( empty( $_GET[ 'ttclid' ] ) || ! is_string( $_GET[ 'ttclid' ] ) ) {
		return '';
	}

	return sanitize_text_field( wp_unslash( $_GET[ 'ttclid' ] ) );
}

/**
 * Read the stored ad click identifier.
 *
 * The TikTok SDK's own cookie is preferred over ours; a cookie only exists in
 * the first place because consent was given when it was written.
 *
 * @return string Empty string when no click id is stored.
 */
function getTtclidFromCookie() {

	$candidates = array(
		$_COOKIE[ 'ttclid' ] ?? '',
		$_COOKIE[ TTCLID_COOKIE ] ?? '',
	);

	foreach ( $candidates as $candidate ) {

		if ( ! is_string( $candidate ) ) {
			continue;
		}

		$candidate = sanitize_text_field( wp_unslash( $candidate ) );

		// The SDK stores its cookie as `<ttclid>.<millisecond timestamp>`,
		// which is its internal format, not the click id — the Events API
		// wants the URL value. Seen live: the URL carried TT_LIVE_A and the
		// events went out as TT_LIVE_A.1790773488869.
		$candidate = preg_replace( '/\.\d{13}$/', '', $candidate );

		if ( $candidate !== '' ) {
			return $candidate;
		}
	}

	return '';
}

/**
 * Read the click id from our own cookie only.
 *
 * getTtclidFromCookie() prefers the SDK's `ttclid`, which is right for reading
 * but wrong for deciding whether ours needs refreshing: a fresh SDK cookie
 * would mask a stale value of ours until it expires, and ours is the one that
 * survives.
 *
 * @return string Empty string when our cookie is absent.
 */
function getStoredTtclid() {

	$stored = $_COOKIE[ TTCLID_COOKIE ] ?? '';

	return is_string( $stored ) ? sanitize_text_field( wp_unslash( $stored ) ) : '';
}

/**
 * How long to keep the TikTok click id, in seconds.
 *
 * 90 days: TikTok asks integrators to store the click id with a TTL of "28
 * days or more" and expires it on their side per the attribution window, so
 * anything past 28 is safe — and 90 matches what `_fbp`/`_fbc` now get.
 * `pys_tiktok_cookie_lifetime_days` is the way to change it.
 *
 * @return int Seconds.
 */
function ttclidCookieLifetime() {
	$days = PixelYourSite\pys_cookie_lifetime_days(
		apply_filters( 'pys_tiktok_cookie_lifetime_days', 90 ),
		90
	);

	return $days * DAY_IN_SECONDS;
}

/**
 * Persist a click id in our own first-party cookie.
 *
 * The caller decides whether writing is allowed at all (consent, and whether the
 * URL carries a click id that differs from the stored one). Only our own
 * `pys_ttclid` is ever written, never the SDK's `ttclid` cookie.
 *
 * @param string $ttclid
 * @return bool Whether the cookie was written.
 */
function setTtclidCookie( $ttclid ) {

	if ( ! is_string( $ttclid ) || $ttclid === '' || headers_sent() ) {
		return false;
	}

	// The site switched every PYS cookie off. The click id still reaches this
	// request's events; it is only not stored.
	if ( PixelYourSite\pys_cookie_domain_cookies_disabled() ) {
		return false;
	}

	return setcookie(
		TTCLID_COOKIE,
		$ttclid,
		time() + ttclidCookieLifetime(),
		'/',
		PixelYourSite\pys_cookie_domain()
	);
}

/**
 * Read the TikTok cookie the pixel SDK writes for browser-side identity.
 *
 * @return string Empty string when the cookie is absent.
 */
function getTtp() {

	if ( empty( $_COOKIE[ '_ttp' ] ) || ! is_string( $_COOKIE[ '_ttp' ] ) ) {
		return '';
	}

	return sanitize_text_field( wp_unslash( $_COOKIE[ '_ttp' ] ) );
}

/**
 * Put the client IP and user agent on a TikTok context.
 *
 * $signals comes from pys_event_client_signals(): '' / null mean the event
 * should carry none, and an empty value is worse than an absent one for
 * TikTok's matching.
 *
 * @param \stdClass $userData
 * @param array     $signals
 * @return \stdClass
 */
function applyClientSignals( $userData, $signals ) {

	if ( isset( $signals[ 'ip' ] ) && '' !== $signals[ 'ip' ] ) {
		$userData->ip = $signals[ 'ip' ];
	}

	if ( isset( $signals[ 'user_agent' ] ) && null !== $signals[ 'user_agent' ] ) {
		$userData->user_agent = $signals[ 'user_agent' ];
	}

	return $userData;
}

/**
 * Fill ttp / ttclid from the live request, where the request is the visitor's.
 *
 * In wp-admin the cookies are the administrator's, so nothing is read. Values
 * already on the context (order snapshot, browser payload) are never replaced.
 *
 * @param \stdClass $userData
 * @param bool      $request_cookies pys_event_client_signals()['request_cookies']
 * @param string    $ttclid          Click id known to this request, '' when none.
 * @return \stdClass
 */
function applyRequestIdentifiers( $userData, $request_cookies, $ttclid ) {

	if ( ! $request_cookies ) {
		return $userData;
	}

	if ( empty( $userData->user->ttp ) ) {
		$ttp = getTtp();
		if ( $ttp !== '' ) {
			$userData->user->ttp = $ttp;
		}
	}

	if ( empty( $userData->user->ttclid ) && $ttclid !== '' ) {
		$userData->user->ttclid = $ttclid;
	}

	return $userData;
}
