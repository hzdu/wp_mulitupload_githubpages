<?php

namespace Objectiv\Plugins\Checkout;

use Objectiv\Plugins\Checkout\Features\AbandonedCartRecovery;
use Objectiv\Plugins\Checkout\Features\ABTesting;
use Objectiv\Plugins\Checkout\Features\LocalPickup;

/**
 * Runs the plugin activation steps if the paid features were never set up.
 *
 * Activating the paid plugin while CheckoutWC Lite is loaded skips its activation hook: the main file returns early because Lite already defined CFW_VERSION.
 * That leaves no abandoned cart table and no A/B test, recovery email or pickup location capabilities.
 *
 * @since 11.5.0
 */
final class PremiumInstall {

	/** @var string option set once the check has run */
	private const CHECKED_OPTION = '_cfw_premium_install_checked';

	/**
	 * Runs the activation steps once, if the abandoned cart table or the feature capabilities are missing.
	 *
	 * @since 11.5.0
	 *
	 * @return void
	 */
	public function maybe_install() : void {
		if ( get_option( self::CHECKED_OPTION ) ) {
			return;
		}

		// Set first, so a concurrent request doesn't run the activation steps again.
		update_option( self::CHECKED_OPTION, CFW_VERSION, true );

		if ( $this->is_installed() ) {
			return;
		}

		/** This action is documented in checkout-for-woocommerce.php */
		do_action( 'cfw_do_plugin_activation' );
	}

	/**
	 * Determines whether the abandoned cart table exists and administrators can edit the paid feature post types.
	 *
	 * @since 11.5.0
	 *
	 * @return bool
	 */
	private function is_installed() : bool {
		global $wpdb;

		$table = AbandonedCartRecovery::get_table_name();

		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) !== $table ) {
			return false;
		}

		$administrator = get_role( 'administrator' );

		if ( ! $administrator ) {
			return true;
		}

		foreach ( [ AbandonedCartRecovery::get_post_type(), ABTesting::get_post_type(), LocalPickup::get_post_type() ] as $post_type ) {
			// Matches the edit_posts capability that get_post_type_capabilities() maps for the post type.
			if ( ! $administrator->has_cap( "edit_{$post_type}s" ) ) {
				return false;
			}
		}

		return true;
	}

}
