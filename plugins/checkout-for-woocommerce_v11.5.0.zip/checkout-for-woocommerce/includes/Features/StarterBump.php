<?php

declare( strict_types = 1 );

namespace Objectiv\Plugins\Checkout\Features;

use Objectiv\Plugins\Checkout\Managers\SettingsManager;
use Objectiv\Plugins\Checkout\Model\Bumps\BumpAbstract;
use WC_Product;

/**
 * Suggests a first order bump from the store's own sales and creates it as a draft.
 *
 * @since 11.5.0
 */
final class StarterBump {

	/** @var string */
	public const DISMISSED_META_KEY = 'cfw_starter_bump_dismissed';

	/** @var string */
	private const SUGGESTION_TRANSIENT = 'cfw_starter_bump_suggestion';

	/** @var int */
	private const CANDIDATE_LIMIT = 20;

	/** @var int */
	private const SALES_WINDOW_DAYS = 90;

	/**
	 * Returns the product to suggest for the first order bump, or 0 for none.
	 *
	 * This is the only place the rule lives: published, simple, in-stock, purchasable products priced above 0 that are not already a bump offer, ranked by units sold alongside another product in the last 90 days, falling back to total sales.
	 *
	 * @since 11.5.0
	 *
	 * @return int
	 */
	public function suggest_product_id(): int {
		$product_id   = get_transient( self::SUGGESTION_TRANSIENT );
		$excluded_ids = null;

		// The cached product may no longer qualify, for example if it went out of stock or became a bump offer.
		if ( false !== $product_id && absint( $product_id ) > 0 ) {
			$excluded_ids = $this->get_bump_offer_product_ids();

			if ( 0 === $this->find_eligible_product_id( [ absint( $product_id ) ], $excluded_ids ) ) {
				$product_id = false;
			}
		}

		if ( false === $product_id ) {
			$excluded_ids = $excluded_ids ?? $this->get_bump_offer_product_ids();
			$product_id   = $this->find_eligible_product_id( $this->get_co_purchase_product_ids(), $excluded_ids );

			if ( 0 === $product_id ) {
				$product_id = $this->find_eligible_product_id( $this->get_best_selling_product_ids( $excluded_ids ), $excluded_ids );
			}

			set_transient( self::SUGGESTION_TRANSIENT, $product_id, 12 * HOUR_IN_SECONDS );
		}

		/**
		 * Filters the product suggested for the merchant's first order bump.
		 *
		 * Return 0 to suggest no product.
		 *
		 * @since 11.5.0
		 *
		 * @param int $product_id the suggested product ID, or 0 for none
		 */
		return absint( apply_filters( 'cfw_starter_bump_product_id', absint( $product_id ) ) );
	}

	/**
	 * Creates a draft order bump at full price for the given product and returns its ID.
	 *
	 * Pass 0 to create the draft with no offer product.
	 *
	 * @since 11.5.0
	 *
	 * @param int $product_id
	 * @return int the new bump ID, or 0 on failure
	 */
	public function create_draft( int $product_id ): int {
		$product = $product_id > 0 ? wc_get_product( $product_id ) : null;
		$product = $product instanceof WC_Product ? $product : null;
		$name    = $product ? $product->get_name() : '';

		$bump_id = wp_insert_post(
			[
				'post_type'   => BumpAbstract::get_post_type(),
				'post_status' => 'draft',
				'post_title'  => $product
					/* translators: %s: Product name */
					? sprintf( __( '%s: add-on at checkout', 'checkout-wc' ), $name )
					: __( 'Add-on at checkout', 'checkout-wc' ),
			],
			true
		);

		if ( is_wp_error( $bump_id ) || ! $bump_id ) {
			return 0;
		}

		$meta = [
			'cfw_ob_offer_product_v9'  => $product ? [
				[
					'key'   => $product->get_id(),
					'label' => $name,
				],
			] : [],
			'cfw_ob_discount_type'     => 'percent',
			'cfw_ob_offer_discount'    => '0',
			'cfw_ob_display_location'  => $this->get_display_location(),
			'cfw_ob_display_for'       => 'all_products',
			'cfw_ob_rules'             => [],
			'cfw_ob_auto_add'          => 'no',
			/* translators: %s: Product name */
			'cfw_ob_offer_heading'     => $product ? sprintf( __( 'Add %s to your order', 'checkout-wc' ), $name ) : '',
			'cfw_ob_offer_subheading'  => __( 'A popular pick with other customers', 'checkout-wc' ),
			'cfw_ob_offer_description' => __( 'Add it now and we\'ll include it with this order.', 'checkout-wc' ),
		];

		foreach ( $meta as $key => $value ) {
			update_post_meta( $bump_id, $key, $value );
		}

		return (int) $bump_id;
	}

	/**
	 * Determines whether the store has any merchant order bump, in any status except trash.
	 *
	 * System-managed bumps (e.g. the Side Cart free gift) don't count.
	 *
	 * @since 11.5.0
	 *
	 * @return bool
	 */
	public function store_has_bumps(): bool {
		$bump_ids = get_posts(
			[
				'post_type'   => BumpAbstract::get_post_type(),
				'post_status' => [ 'publish', 'draft', 'pending', 'private', 'future' ],
				'numberposts' => 1,
				'fields'      => 'ids',
				'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					[
						'key'     => '_cfw_managed_by',
						'compare' => 'NOT EXISTS',
					],
				],
			]
		);

		return ! empty( $bump_ids );
	}

	/**
	 * Returns the first candidate that can be offered as a bump, or 0 for none.
	 *
	 * @since 11.5.0
	 *
	 * @param int[] $candidate_ids product IDs, best first
	 * @param int[] $excluded_ids product IDs that are already a bump offer
	 * @return int
	 */
	private function find_eligible_product_id( array $candidate_ids, array $excluded_ids ): int {
		foreach ( $candidate_ids as $candidate_id ) {
			if ( in_array( $candidate_id, $excluded_ids, true ) ) {
				continue;
			}

			$product = wc_get_product( $candidate_id );

			if (
				$product instanceof WC_Product
				&& $product->is_type( 'simple' )
				&& 'publish' === $product->get_status()
				&& $product->is_in_stock()
				&& $product->is_purchasable()
				&& (float) $product->get_price() > 0
			) {
				return $product->get_id();
			}
		}

		return 0;
	}

	/**
	 * Returns product IDs ranked by units sold alongside at least one other product in the same order in the last 90 days.
	 *
	 * @since 11.5.0
	 *
	 * @return int[]
	 */
	private function get_co_purchase_product_ids(): array {
		global $wpdb;

		$table = $wpdb->prefix . 'wc_order_product_lookup';
		$since = gmdate( 'Y-m-d H:i:s', time() - self::SALES_WINDOW_DAYS * DAY_IN_SECONDS );

		// The derived table de-duplicates line items, so an order with several other products doesn't multiply the quantity.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The table name is built from $wpdb->prefix; the result is cached in a transient by the caller.
		$product_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT line.product_id
				FROM {$table} AS line
				INNER JOIN (
					SELECT DISTINCT item.order_item_id
					FROM {$table} AS item
					INNER JOIN {$table} AS other ON other.order_id = item.order_id AND other.product_id <> item.product_id
					WHERE item.date_created >= %s
				) AS co_purchased ON co_purchased.order_item_id = line.order_item_id
				GROUP BY line.product_id
				HAVING SUM( line.product_qty ) > 0
				ORDER BY SUM( line.product_qty ) DESC, line.product_id ASC
				LIMIT %d",
				$since,
				self::CANDIDATE_LIMIT
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return array_map( 'absint', is_array( $product_ids ) ? $product_ids : [] );
	}

	/**
	 * Returns eligible-looking product IDs ranked by their all-time total sales.
	 *
	 * @since 11.5.0
	 *
	 * @param int[] $excluded_ids product IDs that are already a bump offer
	 * @return int[]
	 */
	private function get_best_selling_product_ids( array $excluded_ids ): array {
		$product_ids = wc_get_products(
			[
				'status'       => 'publish',
				'type'         => 'simple',
				'stock_status' => 'instock',
				'exclude'      => $excluded_ids,
				'limit'        => self::CANDIDATE_LIMIT,
				'meta_key'     => 'total_sales', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'orderby'      => [
					'meta_value_num' => 'DESC',
					'ID'             => 'ASC',
				],
				'return'       => 'ids',
			]
		);

		return array_map( 'absint', is_array( $product_ids ) ? $product_ids : [] );
	}

	/**
	 * Returns the IDs of products that are already the offer product of an existing bump.
	 *
	 * @since 11.5.0
	 *
	 * @return int[]
	 */
	private function get_bump_offer_product_ids(): array {
		$bump_ids = get_posts(
			[
				'post_type'   => BumpAbstract::get_post_type(),
				'post_status' => 'any',
				'numberposts' => -1,
				'fields'      => 'ids',
				'meta_key'    => 'cfw_ob_offer_product_v9', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			]
		);

		$product_ids = [];

		foreach ( $bump_ids as $bump_id ) {
			$offer = get_post_meta( (int) $bump_id, 'cfw_ob_offer_product_v9', true );

			foreach ( is_array( $offer ) ? $offer : [] as $ref ) {
				if ( is_array( $ref ) && ! empty( $ref['key'] ) ) {
					$product_ids[] = absint( $ref['key'] );
				}
			}
		}

		return array_values( array_unique( $product_ids ) );
	}

	/**
	 * Gets the starter bump's display location: checkout and side cart when the side cart shows order bumps, otherwise the checkout slot after the cart summary items.
	 *
	 * Without the side cart, the combined location would be a locked item in the Checkout Editor that the slot doesn't count.
	 *
	 * @since 11.5.0
	 *
	 * @return string
	 */
	private function get_display_location(): string {
		$settings = SettingsManager::instance();

		if ( 'yes' === $settings->get_setting( 'enable_side_cart' ) && 'yes' === $settings->get_setting( 'enable_order_bumps_on_side_cart' ) ) {
			return 'below_cart_items';
		}

		return 'after_cart_summary_items';
	}
}
