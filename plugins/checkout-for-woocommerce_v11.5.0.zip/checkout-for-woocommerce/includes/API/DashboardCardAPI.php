<?php

declare( strict_types = 1 );

namespace Objectiv\Plugins\Checkout\API;

use Objectiv\Plugins\Checkout\Admin\DashboardCardEvent;
use Objectiv\Plugins\Checkout\Admin\Pages\General;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * REST route behind the Dashboard card links and the feature cards' Dismiss: records the click, and saves a feature card's dismissal.
 *
 * The starter order bump's Create and Dismiss go through StarterBumpAPI.
 *
 * @since 11.5.0
 */
final class DashboardCardAPI {

	/** @var array<string, string[]> the actions each card accepts here */
	private const CARD_ACTIONS = [
		'starter_bump'         => [ 'choose_product' ],
		'turnstile'            => [ 'setup', 'dismiss' ],
		'address_autocomplete' => [ 'setup', 'dismiss' ],
	];

	/**
	 * Hooks the route registration.
	 *
	 * @since 11.5.0
	 */
	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Registers the route.
	 *
	 * @internal
	 *
	 * @since 11.5.0
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			'checkoutwc/v1',
			'dashboard-card',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'handle' ],
				'permission_callback' => [ $this, 'check_permissions' ],
			]
		);
	}

	/**
	 * Saves a feature card's dismissal for the current user, then reports the action.
	 *
	 * @internal
	 *
	 * @since 11.5.0
	 *
	 * @param WP_REST_Request $request the request
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle( $request ) {
		$card     = (string) $request->get_param( 'card' );
		$action   = (string) $request->get_param( 'action' );
		$location = (string) $request->get_param( 'location' );

		if ( ! in_array( $action, self::CARD_ACTIONS[ $card ] ?? [], true ) || ! DashboardCardEvent::is_valid( $card, $action, $location ) ) {
			return new WP_Error( 'cfw_dashboard_card_invalid', __( 'Unknown card action.', 'checkout-wc' ), [ 'status' => 400 ] );
		}

		if ( 'dismiss' === $action ) {
			update_user_meta( get_current_user_id(), General::FEATURE_CARD_DISMISSED_META[ $card ], '1' );
		}

		DashboardCardEvent::fire( $card, $action, $location );

		return new WP_REST_Response( null, 204 );
	}

	/**
	 * Allows the request when the REST nonce is valid and the user can see the card.
	 *
	 * @internal
	 *
	 * @since 11.5.0
	 *
	 * @param WP_REST_Request $request the request
	 *
	 * @return bool
	 */
	public function check_permissions( $request ) {
		if ( ! $request instanceof WP_REST_Request ) {
			return false;
		}

		$nonce      = (string) $request->get_header( 'X-WP-Nonce' );
		$capability = 'starter_bump' === $request->get_param( 'card' ) ? 'cfw_manage_order_bumps' : 'cfw_manage_general';

		return '' !== $nonce && false !== wp_verify_nonce( $nonce, 'wp_rest' ) && current_user_can( $capability );
	}
}
