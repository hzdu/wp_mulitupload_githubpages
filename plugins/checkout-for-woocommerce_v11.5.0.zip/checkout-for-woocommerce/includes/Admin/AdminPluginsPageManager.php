<?php

namespace Objectiv\Plugins\Checkout\Admin;

use Objectiv\Plugins\Checkout\Managers\UpdatesManager;

/**
 * Handles Pro-specific plugin page functionality (license nag, settings link, license fields for survey).
 *
 * Note: The deactivation survey itself is now handled by DeactivationSurvey class
 * which is initialized in init.php for both Pro and Lite versions.
 *
 * @since 11.0.1 Survey functionality moved to DeactivationSurvey class
 */
class AdminPluginsPageManager {
	protected $cfw_admin_url;

	/** @var string URL of the Dashboard's Your plan card, where the license key is entered */
	protected $license_url;

	/**
	 * Constructor.
	 *
	 * @since 11.5.0 Added the `$license_url` parameter.
	 *
	 * @param string $cfw_admin_url URL of the Dashboard
	 * @param string $license_url URL of the Dashboard's Your plan card
	 */
	public function __construct( string $cfw_admin_url, string $license_url = '' ) {
		$this->cfw_admin_url = $cfw_admin_url;
		$this->license_url   = $license_url;
	}

	public function init() {
		$plugin_basename = plugin_basename( CFW_MAIN_FILE );

		add_action( 'after_plugin_row_' . $plugin_basename, [ $this, 'add_key_nag' ], 10, 2 );
		add_filter(
			'plugin_action_links_' . $plugin_basename,
			[
				$this,
				'add_action_link',
			],
			10,
			1
		);

		// Add license-specific fields to the deactivation survey
		add_filter( 'cfw_deactivation_form_fields', [ $this, 'add_license_fields_to_survey' ] );
	}

	public function add_action_link( $links ): array {
		$settings_link = [
			'<a href="' . $this->cfw_admin_url . '">' . __( 'Settings', 'checkout-wc' ) . '</a>',
		];

		return array_merge( $settings_link, $links );
	}

	/**
	 * Shows the license nag under the plugin's row, unless WordPress is already showing an update row there.
	 *
	 * @since 11.5.0 Added the `$plugin_file` parameter.
	 *
	 * @param string $plugin_file Plugin basename, passed by `after_plugin_row_{$plugin_file}`.
	 *
	 * @return void
	 */
	public function add_key_nag( string $plugin_file = '' ) {
		$key_status = UpdatesManager::instance()->get_field_value( 'key_status' );

		if ( empty( $key_status ) ) {
			return;
		}

		if ( 'valid' === $key_status ) {
			return;
		}

		$current = get_site_transient( 'update_plugins' );
		if ( isset( $current->response[ $plugin_file ] ) ) {
			return;
		}

		if ( is_network_admin() || ! is_multisite() ) {
			$wp_list_table = _get_list_table( 'WP_Plugins_List_Table' );
			echo '<tr class="plugin-update-tr"><td colspan="' . sanitize_key( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange"><div class="update-message">';
			echo '<span style="color:red">' . esc_html__( "You're missing out on important updates because your license key is missing, invalid, or expired.", 'checkout-wc' ) . '</span>';

			if ( $this->license_url ) {
				echo ' <a href="' . esc_url( $this->license_url ) . '">' . esc_html__( 'Manage your license', 'checkout-wc' ) . '</a>';
			}

			echo '</div></td></tr>';
		}
	}

	/**
	 * Add license-specific fields to the deactivation survey.
	 *
	 * These fields are only added for Pro version where UpdatesManager is available.
	 *
	 * @since 11.0.1
	 * @param array $fields The existing form fields.
	 * @return array
	 */
	public function add_license_fields_to_survey( array $fields ): array {
		$license_data = get_option( 'cfw_license_data', false );

		$fields[] = [
			'id'          => 'price_id',
			'label'       => '',
			'type'        => 'hidden',
			'name'        => 'price_id',
			'value'       => UpdatesManager::instance()->get_license_price_id(),
			'required'    => '',
			'extra-class' => '',
		];

		$fields[] = [
			'id'          => 'license_status',
			'label'       => '',
			'type'        => 'hidden',
			'name'        => 'license_status',
			'value'       => $license_data ? $license_data->license : '',
			'required'    => '',
			'extra-class' => '',
		];

		return $fields;
	}
}
