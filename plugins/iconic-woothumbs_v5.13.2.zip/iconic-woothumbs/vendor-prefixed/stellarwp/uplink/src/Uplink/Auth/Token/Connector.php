<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified by James Kemp on 23-February-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */ declare( strict_types=1 );

namespace Iconic_WooThumbs_NS\StellarWP\Uplink\Auth\Token;

use Iconic_WooThumbs_NS\StellarWP\Uplink\Auth\Token\Contracts\Token_Manager;
use Iconic_WooThumbs_NS\StellarWP\Uplink\Auth\Token\Exceptions\InvalidTokenException;
use Iconic_WooThumbs_NS\StellarWP\Uplink\Resources\Resource;

final class Connector {

	/**
	 * @var Token_Manager
	 */
	private $token_manager;

	/**
	 * @param  Token_Manager  $token_manager The Token Manager.
	 */
	public function __construct(
		Token_Manager $token_manager
	) {
		$this->token_manager = $token_manager;
	}

	/**
	 * Store a token if the user is allowed to.
	 *
	 * @throws InvalidTokenException
	 */
	public function connect( string $token, Resource $plugin ): bool {
		if ( ! $this->token_manager->validate( $token ) ) {
			throw new InvalidTokenException( 'Invalid token format' );
		}

		return $this->token_manager->store( $token, $plugin );
	}

}
