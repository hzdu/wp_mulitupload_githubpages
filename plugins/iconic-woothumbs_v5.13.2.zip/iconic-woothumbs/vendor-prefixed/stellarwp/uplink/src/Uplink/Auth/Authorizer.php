<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified by James Kemp on 23-February-2026 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */ declare( strict_types=1 );

namespace Iconic_WooThumbs_NS\StellarWP\Uplink\Auth;

use Iconic_WooThumbs_NS\StellarWP\Uplink\Config;

/**
 * Determines if the current site will allow the user to use the authorize button.
 */
final class Authorizer {

	/**
	 * Checks if the current user can perform an action.
	 *
	 * @throws \RuntimeException
	 *
	 * @return bool
	 */
	public function can_auth(): bool {
		/**
		 * Filters if the current user can perform an action.
		 *
		 * @since 2.0.0
		 *
		 * @param bool $can_auth Whether the current user can perform an action.
		 */
		return (bool) apply_filters(
			'stellarwp/uplink/' . Config::get_hook_prefix() . '/auth/can_auth',
			is_super_admin()
		);
	}

}
