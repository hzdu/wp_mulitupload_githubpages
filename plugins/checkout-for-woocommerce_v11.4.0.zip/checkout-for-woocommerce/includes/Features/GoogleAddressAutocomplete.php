<?php

namespace Objectiv\Plugins\Checkout\Features;

use Objectiv\Plugins\Checkout\Admin\Pages\AdminPagesRegistry;

/**
 * @link checkoutwc.com
 * @since 5.0.0
 */
class GoogleAddressAutocomplete extends FeaturesAbstract {

	protected function run_if_cfw_is_enabled() {
		add_action( 'cfw_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_filter( 'cfw_event_object', [ $this, 'add_localized_settings' ] );
		add_filter( 'cfw_enable_zip_autocomplete', '__return_false' );
	}

	public function enqueue_scripts() {
		if ( ! cfw_is_checkout() ) {
			return;
		}

		/**
		 * Whether to enable Google Maps compatibility mode
		 *
		 * @since 4.3.7
		 * @param bool $compatibility_mode Whether to enable Google Maps compatibility mode
		 */
		if ( apply_filters( 'cfw_google_maps_compatibility_mode', false ) ) {
			return;
		}

		$language = $this->get_language_code();

		$google_api_key = $this->settings_getter->get_setting( 'google_places_api_key' );

		wp_enqueue_script(
			'cfw-google-places',
			"https://maps.googleapis.com/maps/api/js?key={$google_api_key}&libraries=places&language={$language}&callback=cfw_google_maps_loaded&loading=async",
			[ 'woocommerce' ],
			CFW_VERSION,
			[
				'in_footer' => true,
			]
		);
	}

	/**
	 * Get the Google Maps language code
	 *
	 * @since 11.3.1
	 *
	 * @return string
	 */
	private function get_language_code(): string {
		$locale        = get_locale();
		$parsed_locale = strstr( $locale, '_', true );
		$language      = $parsed_locale ? $parsed_locale : $locale;

		/**
		 * Filter Google Maps language code
		 *
		 * @since 4.3.7
		 * @param string $lanugage_code Google Maps language code
		 */
		return (string) apply_filters( 'cfw_google_maps_language_code', $language );
	}

	/**
	 * Resolve a stored Google Places API version to the one that will actually be used
	 *
	 * Anything other than an explicit opt in to Places API (New) falls back to the legacy API, so an unrecognized or missing value can never change behavior for a merchant who is already set up. Shared with the admin so the setting can never display something other than what the checkout does.
	 *
	 * @since 11.3.1
	 *
	 * @param mixed $stored_value The saved setting value.
	 * @return string
	 */
	public static function normalize_api_version( $stored_value ): string {
		return 'new' === $stored_value ? 'new' : 'legacy';
	}

	/**
	 * Get the Google Places API version to use for address autocomplete
	 *
	 * @since 11.3.1
	 *
	 * @return string
	 */
	private function get_api_version(): string {
		return self::normalize_api_version( $this->settings_getter->get_setting( 'google_places_api_version' ) );
	}

	/**
	 * Add localized settings
	 *
	 * @param array $event_data The event data.
	 * @return array
	 */
	public function add_localized_settings( array $event_data ): array {
		$event_data['settings']['enable_address_autocomplete'] = true;

		$event_data['settings']['google_places_api_version'] = $this->get_api_version();

		// The legacy widget is localized by the script URL. Places API (New) takes the language per
		// request, so it needs the same value in JS to keep the two paths consistent.
		$event_data['settings']['google_places_language'] = $this->get_language_code();

		/**
		 * Filter list of shipping country restrictions for Google Maps address autocomplete
		 *
		 * @since 3.0.0
		 *
		 * @param array $address_autocomplete_shipping_countries List of country restrictions for Google Maps address autocomplete
		 */
		$event_data['settings']['address_autocomplete_shipping_countries'] = apply_filters( 'cfw_address_autocomplete_shipping_countries', [] );

		/**
		 * Filter Google address autocomplete type
		 *
		 * @since 7.3.0
		 *
		 * @param string $autocomplete_type Google address autocomplete type
		 */
		$event_data['settings']['google_address_autocomplete_type'] = apply_filters( 'cfw_google_address_autocomplete_type', 'geocode|establishment' );

		return $event_data;
	}

	public function init() {
		parent::init();

		add_action( 'admin_enqueue_scripts', [ $this, 'add_admin_js_object' ], 1002 );
	}

	public function add_admin_js_object() {
		wp_localize_script(
			'cfw-admin-settings',
			'cfw_google_address_autocomplete',
			[
				'google_api_key_settings_page_url' => AdminPagesRegistry::get( 'integrations' )->get_url(),
			]
		);
	}
}
