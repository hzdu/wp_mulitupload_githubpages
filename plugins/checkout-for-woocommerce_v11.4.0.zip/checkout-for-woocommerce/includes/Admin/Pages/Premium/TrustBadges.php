<?php

namespace Objectiv\Plugins\Checkout\Admin\Pages\Premium;

use Objectiv\Plugins\Checkout\Admin\Pages\PageAbstract;
use Objectiv\Plugins\Checkout\Managers\SettingsManager;
use Objectiv\Plugins\Checkout\Managers\SlotManager;

/**
 * @link checkoutwc.com
 * @since 5.0.0
 * @package Objectiv\Plugins\Checkout\Admin\Pages
 */
class TrustBadges extends PageAbstract {
	public function __construct() {
		parent::__construct( __( 'Trust Badges', 'checkout-wc' ), 'cfw_manage_trust_badges', 'trust-badges' );
	}

	public function output() {
		?>
		<div id="cfw-new-trust-badge-settings-page"></div>
		<?php
	}

	public function maybe_set_script_data() {
		if ( ! $this->is_current_page() ) {
			return;
		}

		// IDs are already stable — cfw_get_trust_badges() backfills one only where a badge has none.
		$trust_badges = cfw_get_trust_badges( false );

		// Seed each badge's current slot so the settings dropdown pre-selects it.
		//
		// Collections are skipped: this page does not list them, so there is no dropdown for the merchant
		// to have touched. Seeding one anyway would round-trip a value that goes stale the moment the
		// collection is moved in the editor, and reconcile_trust_badge_slots() would then move it back
		// on the next save of a page that never showed it.
		$slot_assignments = SlotManager::instance()->get_trust_badge_slot_assignments( $trust_badges );
		foreach ( $trust_badges as $index => $badge ) {
			if ( ( $badge['template'] ?? '' ) === 'collection' ) {
				continue;
			}

			$trust_badges[ $index ]['slot'] = $slot_assignments[ $badge['id'] ] ?? '';
		}

		// Slot ID → label map for the dropdown options (checkout slots only).
		$slot_definitions = [];
		foreach ( SlotManager::get_slot_hook_map() as $slot_id => $config ) {
			$slot_definitions[ $slot_id ] = $config['label'];
		}

		$this->set_script_data(
			[
				'slot_definitions' => $slot_definitions,
				'settings'         => [
					'enable_trust_badges'     => SettingsManager::instance()->get_setting( 'enable_trust_badges' ) === 'yes',
					'trust_badge_position'    => SettingsManager::instance()->get_setting( 'trust_badge_position' ),
					'trust_badges_title'      => SettingsManager::instance()->get_setting( 'trust_badges_title' ),
					'trust_badges'            => array_values( $trust_badges ),
					'enable_wc_review_badges' => SettingsManager::instance()->get_setting( 'enable_wc_review_badges' ) === 'yes',
					'wc_review_source'        => SettingsManager::instance()->get_setting( 'wc_review_source' ),
					'wc_review_min_rating'    => SettingsManager::instance()->get_setting( 'wc_review_min_rating' ),
					'wc_review_limit'         => (int) SettingsManager::instance()->get_setting( 'wc_review_limit' ),
					'reviewbird_available'    => function_exists( 'reviewbird_get_product_reviews' )
						&& function_exists( 'reviewbird_get_store_id' )
						&& reviewbird_get_store_id(),
				],
				'plan'             => $this->get_plan_data(),
			]
		);
	}
}
