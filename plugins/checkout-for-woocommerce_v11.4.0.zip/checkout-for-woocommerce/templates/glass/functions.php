<?php

use Objectiv\Plugins\Checkout\Managers\SettingsManager;

wc_maybe_define_constant( 'CFW_BUILD_PROCESS', 2 );

add_action( 'cfw_checkout_before_main_container', 'cfw_glass_checked_input_colors' );

function cfw_glass_checked_input_colors() {
	$template_slug    = basename( __DIR__ );
	$settings_manager = SettingsManager::instance();
	$button_color     = $settings_manager->get_setting( 'button_color', [ $template_slug ] );
	?>
	<style type="text/css">
		input[type="checkbox"]:checked {
			box-shadow: 0 0 0 10px <?php echo wp_kses_post( $button_color ); ?> inset !important;
		}

		input[type="radio"]:checked:after {
			background-color: <?php echo wp_kses_post( $button_color ); ?> !important;
		}
	</style>
	<?php
}

add_action( 'cfw_cart_html_before_cart_container', 'cfw_glass_cart_heading', 21 );

function cfw_glass_cart_heading() {
	if ( ! is_checkout() ) {
		return;
	}

	?>
	<tr>
		<td colspan="5">
			<h3>
				<?php esc_html_e( 'Your Cart', 'checkout-wc' ); ?>
			</h3>
		</td>
	</tr>
	<?php
}

// The cart card holds everything from the free shipping & rewards bar (32) through the cart items
// (40), so that anything a merchant places in the "Before Cart Summary Items" slot (35) sits inside
// the card with them rather than bare on the glass background.
add_action( 'cfw_checkout_cart_summary', 'cfw_glass_cart_wrap_open', 31 );
add_action( 'cfw_checkout_cart_summary', 'cfw_glass_cart_wrap_close', 41 );

/**
 * Opens the cart card.
 *
 * @return void
 */
function cfw_glass_cart_wrap_open() {
	echo '<div class="cfw-glass-cart-wrap">';
}

/**
 * Closes the cart card.
 *
 * @return void
 */
function cfw_glass_cart_wrap_close() {
	echo '</div>';
}

// Move notices inside container
remove_action( 'cfw_order_pay_main_container_start', 'cfw_wc_print_notices_with_wrap', 10 );
add_action( 'cfw_order_pay_before_order_review', 'cfw_wc_print_notices_with_wrap', 0 );

remove_action( 'cfw_checkout_main_container_start', 'cfw_wc_print_notices_with_wrap', 10 );
add_action( 'cfw_checkout_before_order_review', 'cfw_wc_print_notices', 0 );

add_filter(
	'cfw_active_theme_color_settings',
	function( $color_settings, $template ) {
		// Only expose the accent color control when Glass is the template being edited.
		if ( $template && 'glass' === $template->get_slug() ) {
			$color_settings['accent_color'] = __( 'Accent Color', 'checkout-wc' );
		}

		return $color_settings;
	},
	10,
	2
);

add_filter(
	'cfw_custom_css_properties',
	function( $properties ) {
		$settings_manager = SettingsManager::instance();
		$active_theme     = cfw_get_active_template()->get_slug();
		$accent_color     = $settings_manager->get_setting( 'accent_color', [ $active_theme ] );

		if ( ! empty( $accent_color ) ) {
			$properties['--cfw-active-theme-colors-accent-color'] = $accent_color;
		}

		return $properties;
	}
);

add_filter( 'cfw_breadcrumbs', 'cfw_glass_remove_cart_breadcrumb' );

function cfw_glass_remove_cart_breadcrumb( $breadcrumbs ) {
	unset( $breadcrumbs['cart'] );

	return $breadcrumbs;
}
