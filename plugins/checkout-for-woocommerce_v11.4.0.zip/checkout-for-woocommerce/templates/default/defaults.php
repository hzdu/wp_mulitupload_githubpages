<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * The default colors for this theme
 */
$defaults = [
	'body_background_color'             => '#ffffff',
	'body_text_color'                   => '#333333',
	'header_background_color'           => '#ffffff',
	'footer_background_color'           => '#ffffff',
	'header_text_color'                 => '#2b2b2b',
	'footer_color'                      => '#333333',
	'link_color'                        => '#0073aa',
	'button_color'                      => '#333333',
	'button_text_color'                 => '#ffffff',
	'button_hover_color'                => '#555555',
	'button_text_hover_color'           => '#ffffff',
	'secondary_button_color'            => '#999999',
	'summary_background_color'          => '#ffffff',
	'summary_mobile_background_color'   => '#f4f4f4',
	'summary_text_color'                => '#333333',
	'summary_link_color'                => '#0073aa',
	'secondary_button_text_color'       => '#ffffff',
	'secondary_button_hover_color'      => '#666666',
	'secondary_button_text_hover_color' => '#ffffff',
	'cart_item_quantity_color'          => '#7f7f7f',
	'cart_item_quantity_text_color'     => '#ffffff',
	'breadcrumb_completed_text_color'   => '#7f7f7f',
	'breadcrumb_current_text_color'     => '#333333',
	'breadcrumb_next_text_color'        => '#7f7f7f',
	'breadcrumb_completed_accent_color' => '#333333',
	'breadcrumb_current_accent_color'   => '#333333',
	'breadcrumb_next_accent_color'      => '#333333',
	'body_font'                         => 'inter-cfw',
	'heading_font'                      => 'inter-cfw',
];
