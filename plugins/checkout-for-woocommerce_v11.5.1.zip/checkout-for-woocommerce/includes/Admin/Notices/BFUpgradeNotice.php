<?php

declare( strict_types = 1 );

namespace Objectiv\Plugins\Checkout\Admin\Notices;

use DateTimeImmutable;
use DateTimeZone;
use Exception;
use Objectiv\Plugins\Checkout\Managers\PlanManager;
use Objectiv\Plugins\Checkout\Managers\UpdatesManager;

/**
 * Black Friday weekend upgrade notice for the paid build, with an offer that depends on the licence.
 *
 * @since 11.5.0
 */
class BFUpgradeNotice extends NoticeAbstract {

	/** @var string when the notice starts showing (America/New_York) */
	private const CAMPAIGN_START = '2026-11-27 00:00:00';

	/** @var string when the notice stops showing (America/New_York) */
	private const CAMPAIGN_END = '2026-11-30 23:59:59';

	/** @var string the notice ID */
	private const NOTICE_ID = 'cfw_black_friday_2026_upgrade';

	/** @var int the 1 Site - Lifetime - 2026 price ID */
	private const LIFETIME_PRICE_ID = 18;

	/** @var int the Hosting Plan - Convesio price ID, provided by a hosting partner */
	private const HOSTING_PLAN_PRICE_ID = 14;

	/** @var int[] the monthly price IDs in CFW_PREMIUM_PLAN_IDS */
	private const MONTHLY_PRICE_IDS = [ 4, 5, 6, 8 ];

	/** @var int the activation limit from which the larger plans are offered */
	private const MIN_SITES_FOR_LARGER_PLANS = 10;

	/** @var int the activation limit from which only the 50 site plan is larger */
	private const MIN_SITES_FOR_LARGEST_PLAN = 25;

	/** @var string[] the key statuses of an expired, disabled or invalid licence, as stored by UpdatesManager */
	private const UNLICENSED_KEY_STATUSES = [ '', 'disabled', 'expired', 'invalid', 'nolicensekey' ];

	/** @var string[] the key statuses of a key for another product, as stored by UpdatesManager from the licence server's check */
	private const GENUINE_KEY_STATUSES = [ 'key_mismatch', 'item_name_mismatch' ];

	/**
	 * Adds the notice with the offer for the licence.
	 *
	 * @since 11.5.0
	 *
	 * @param string $id      Unused; the notice sets its own ID.
	 * @param string $title   Unused; the notice sets its own title.
	 * @param string $message Unused; the notice sets its own message.
	 * @param array  $options Unused; the notice sets its own options.
	 * @return void
	 */
	public function maybe_add( string $id = '', string $title = '', string $message = '', array $options = [] ) {
		$segment = self::get_unlicensed_segment();

		if ( '' === $segment ) {
			$segment = self::get_segment( UpdatesManager::instance()->get_license_price_id(), intval( get_option( 'cfw_license_activation_limit', 0 ) ) );
		}

		if ( '' === $segment ) {
			return;
		}

		if ( 'genuine' === $segment ) {
			$message  = '<p>' . esc_html__( "This copy isn't connected to a valid licence, so it isn't getting updates, security fixes or support. Every plan now includes every CheckoutWC feature.", 'checkout-wc' ) . '</p>';
			$message .= BFOfferCards::get_html( 'plugin', 'paidnotice-genuine' );
			$message .= '<p>' . esc_html__( 'Ends November 30th.', 'checkout-wc' ) . '</p>';

			$this->add_notice( $message, __( 'Get a genuine CheckoutWC licence', 'checkout-wc' ) );

			return;
		}

		if ( 'both' === $segment || 'unlicensed' === $segment ) {
			$message  = BFOfferCards::get_html( 'plugin', 'paidnotice-' . $segment );
			$message .= '<p>' . esc_html__( 'Ends November 30th.', 'checkout-wc' ) . '</p>';

			$this->add_notice( $message );

			return;
		}

		$codes = [
			'monthly'  => 'BF40',
			'sites'    => 'BF40',
			'sites50'  => 'BF40',
			'lifetime' => 'LIFETIMESPECIAL',
		];

		$offers = [
			/* translators: %s: discount code. */
			'monthly'  => __( 'Every plan now includes every CheckoutWC feature. Save 40%% when you switch to a new annual plan with code %s. Ends November 30th.', 'checkout-wc' ),
			/* translators: %s: discount code. */
			'sites'    => __( 'Every plan now includes every CheckoutWC feature. Move up to a 25 or 50 site plan at 40%% off with code %s. Ends November 30th.', 'checkout-wc' ),
			/* translators: %s: discount code. */
			'sites50'  => __( 'Every plan now includes every CheckoutWC feature. Move up to the 50 site plan at 40%% off with code %s. Ends November 30th.', 'checkout-wc' ),
			/* translators: %s: discount code. */
			'lifetime' => __( 'Our first-ever Lifetime deal: get every CheckoutWC feature for life on one site, $100 off with code %s. Pay once, with no renewals. Ends November 30th.', 'checkout-wc' ),
		];

		$message = '<p>' . sprintf( $offers[ $segment ], '<strong>' . $codes[ $segment ] . '</strong>' ) . '</p>';

		$message .= sprintf(
			'<p><a href="%s" target="_blank" class="button button-primary">%s</a></p>',
			add_query_arg(
				[
					'utm_source'   => 'checkoutwc',
					'utm_medium'   => 'app',
					'utm_campaign' => 'plugin',
					'utm_content'  => 'paidnotice-' . $segment,
					// EDD applies a discount passed in the URL.
					'discount'     => $codes[ $segment ],
				],
				'https://www.checkoutwc.com/black-friday-cyber-monday/'
			),
			__( 'See the upgrade offer', 'checkout-wc' )
		);

		$this->add_notice( $message );
	}

	/**
	 * Adds the notice with a message.
	 *
	 * @since 11.5.0
	 *
	 * @param string $message the notice message
	 * @param string $title the notice title, if not the upgrade title
	 * @return void
	 */
	private function add_notice( string $message, string $title = '' ): void {
		parent::maybe_add(
			self::NOTICE_ID,
			'' !== $title ? $title : __( 'Black Friday: upgrade your CheckoutWC plan', 'checkout-wc' ),
			$message,
			[
				'type'        => 'info',
				'dismissible' => true,
			]
		);
	}

	/**
	 * Shows the notice to valid paid licences and to installs without a licence, on CheckoutWC screens and WooCommerce Orders, during the campaign.
	 *
	 * @since 11.5.0
	 *
	 * @return bool
	 */
	protected function should_add(): bool {
		// Paid build only: Lite doesn't define the plan IDs.
		if ( ! defined( 'CFW_PREMIUM_PLAN_IDS' ) ) {
			return false;
		}

		$page = sanitize_text_field( wp_unslash( $_GET['page'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		// The dismiss request has no page, but needs the notice to dismiss it.
		if ( 'wc-orders' !== $page && stripos( $page, 'cfw-' ) === false && ! $this->is_dismiss_request( self::NOTICE_ID ) ) {
			return false;
		}

		// No licence, or a valid licence, activated on this site, with a known plan.
		if ( '' === self::get_unlicensed_segment() && PlanManager::get_user_plan_level() < 1 ) {
			return false;
		}

		try {
			return static::is_campaign_active( new DateTimeImmutable( 'now', new DateTimeZone( 'America/New_York' ) ) );
		} catch ( Exception $e ) {
			return false;
		}
	}

	/**
	 * Checks whether a moment falls inside the campaign window.
	 *
	 * @since 11.5.0
	 *
	 * @param DateTimeImmutable $now the moment to check
	 * @return bool
	 * @throws Exception If the campaign dates can't be parsed.
	 */
	protected static function is_campaign_active( DateTimeImmutable $now ): bool {
		$timezone = new DateTimeZone( 'America/New_York' );
		$start    = new DateTimeImmutable( self::CAMPAIGN_START, $timezone );
		$end      = new DateTimeImmutable( self::CAMPAIGN_END, $timezone );

		return $now >= $start && $now <= $end;
	}

	/**
	 * Gets the offer for an install without a valid licence: unlicensed (no key, or an expired, disabled or invalid one), genuine (a key for another product), or an empty string for neither.
	 *
	 * Keys that aren't activated on this site don't count, as they get InactiveLicenseNotice instead.
	 *
	 * @since 11.5.0
	 *
	 * @return string
	 */
	private static function get_unlicensed_segment(): string {
		if ( empty( UpdatesManager::instance()->get_field_value( 'license_key' ) ) ) {
			return 'unlicensed';
		}

		$key_status = (string) UpdatesManager::instance()->get_field_value( 'key_status' );

		if ( in_array( $key_status, self::UNLICENSED_KEY_STATUSES, true ) ) {
			return 'unlicensed';
		}

		if ( in_array( $key_status, self::GENUINE_KEY_STATUSES, true ) ) {
			return 'genuine';
		}

		return '';
	}

	/**
	 * Gets the offer for a licence: monthly, sites, sites50, lifetime, both (annual and Lifetime), or an empty string for none.
	 *
	 * Agency, Lifetime and hosting partner licences get no offer. An activation limit of 0 means unlimited sites. Licences for 2 to 9 sites get both offers, so they aren't only offered a 1 site Lifetime.
	 * Licences for 25 or more sites are only offered the 50 site plan, the one plan larger than theirs.
	 *
	 * @since 11.5.0
	 *
	 * @param int $price_id the licence price ID
	 * @param int $activation_limit the licence activation limit
	 * @return string
	 */
	private static function get_segment( int $price_id, int $activation_limit ): string {
		if ( in_array( $price_id, [ self::LIFETIME_PRICE_ID, self::HOSTING_PLAN_PRICE_ID ], true ) ) {
			return '';
		}

		if ( defined( 'CFW_PREMIUM_PLAN_IDS' ) && in_array( $price_id, CFW_PREMIUM_PLAN_IDS['agency'], true ) ) {
			return '';
		}

		if ( in_array( $price_id, self::MONTHLY_PRICE_IDS, true ) ) {
			return 'monthly';
		}

		if ( $activation_limit >= self::MIN_SITES_FOR_LARGEST_PLAN ) {
			return 'sites50';
		}

		if ( 0 === $activation_limit || $activation_limit >= self::MIN_SITES_FOR_LARGER_PLANS ) {
			return 'sites';
		}

		if ( 1 === $activation_limit ) {
			return 'lifetime';
		}

		return 'both';
	}
}
