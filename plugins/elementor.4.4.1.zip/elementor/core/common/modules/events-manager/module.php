<?php

namespace Elementor\Core\Common\Modules\EventsManager;

use Elementor\Core\Base\Module as BaseModule;
use Elementor\Core\Common\Modules\Connect\Apps\Base_App;
use Elementor\Core\Common\Modules\Connect\Apps\Common_App;
use Elementor\Core\Common\Modules\EventsManager\RestApi\Events_Proxy_REST_API;
use Elementor\Core\Experiments\Manager as Experiments_Manager;
use Elementor\Includes\EditorAssetsAPI;
use Elementor\Utils;
use Elementor\Modules\EditorOne\Classes\Menu_Data_Provider;
use Elementor\Plugin;
use Elementor\Tracker;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Module extends BaseModule {

	const EXPERIMENT_NAME = 'editor_events';
	const DEFAULT_SESSION_RECORDING_PERCENT = 0;
	const REMOTE_MIXPANEL_CONFIG_URL = 'https://assets.elementor.com/mixpanel/v1/mixpanel.json';

	const API_UPSTREAM_HOST = 'https://api-eu.mixpanel.com';
	const LIBS_UPSTREAM_HOST = 'https://cdn.mxpnl.com/libs';

	public function __construct() {
		parent::__construct();

		( new Events_Proxy_REST_API() )->register_hooks();
	}

	public function get_name() {
		return 'events-manager';
	}

	public static function get_editor_events_config() {
		$can_send_events = self::can_send_events();

		$is_flags_enabled = false;
		$session_recording_percent = self::DEFAULT_SESSION_RECORDING_PERCENT;
		$debug = ( defined( 'ELEMENTOR_EDITOR_EVENTS_DEBUG' ) && ELEMENTOR_EDITOR_EVENTS_DEBUG ) ?? false;

		if ( $can_send_events ) {
			$mixpanel_config = self::get_remote_mixpanel_config();
			$has_config = EditorAssetsAPI::has_valid_nested_array( $mixpanel_config, [ 0 ] );

			if ( $has_config ) {
				$is_flags_enabled = (bool) ( $mixpanel_config[0]['flags'] ?? false );

				$session_replays = $mixpanel_config[0]['sessionReplays'] ?? [];
				$session_recording_percent = $session_replays['recordSessionsPercent'] ?? null;
			}
		}

		$settings = [
			'can_send_events' => $can_send_events,
			'debug' => $debug,
			'elementor_version' => ELEMENTOR_VERSION,
			'site_url' => hash( 'sha256', get_site_url() ),
			'wp_version' => get_bloginfo( 'version' ),
			'user_agent' => esc_html( Utils::get_super_global_value( $_SERVER, 'HTTP_USER_AGENT' ) ),
			'site_language' => get_locale(),
			'site_key' => get_option( Base_App::OPTION_CONNECT_SITE_KEY ),
			'subscription_id' => self::get_subscription_id(),
			'subscription' => self::get_subscription(),
			'token' => ELEMENTOR_EDITOR_EVENTS_MIXPANEL_TOKEN,
			'proxy_api_host' => rest_url( Events_Proxy_REST_API::API_NAMESPACE . '/' . Events_Proxy_REST_API::API_BASE . '/api' ),
			'proxy_lib_base_path' => rest_url( Events_Proxy_REST_API::API_NAMESPACE . '/' . Events_Proxy_REST_API::API_BASE . '/libs/' ),
			'flags_enabled' => $is_flags_enabled,
			'user_id' => self::get_user_id(),
			'session_recording_percent' => $session_recording_percent,
		];

		$settings['menuEventIds'] = Menu_Data_Provider::instance()->get_event_ids_by_slug();

		return $settings;
	}

	public static function dispatch_event( string $event_name, array $properties = [] ): void {
		if ( ! self::can_send_events() ) {
			return;
		}

		try {
			$user_id = self::get_user_id();

			$context = [
				'user_id' => $user_id,
				'distinct_id' => $user_id,
				'subscription_id' => self::get_subscription_id(),
				'site_key' => get_option( Base_App::OPTION_CONNECT_SITE_KEY ),
				'app_version' => ELEMENTOR_VERSION,
				'wp_version' => get_bloginfo( 'version' ),
				'site_language' => get_locale(),
				'source' => 'server',
			];

			Server_Events_Client::track( $event_name, array_merge( $properties, $context ) );
		} catch ( \Throwable $e ) {
			return;
		}
	}

	public static function get_experimental_data(): array {
		return [
			'name' => static::EXPERIMENT_NAME,
			'title' => esc_html__( 'Elementor Editor Events', 'elementor' ),
			'description' => esc_html__( 'Editor events processing', 'elementor' ),
			'hidden' => true,
			'release_status' => Experiments_Manager::RELEASE_STATUS_ALPHA,
			'default' => Experiments_Manager::STATE_INACTIVE,
			'new_site' => [
				'default_active' => true,
				'minimum_installation_version' => '3.32.0',
			],
		];
	}

	private static function can_send_events(): bool {
		return ! empty( ELEMENTOR_EDITOR_EVENTS_MIXPANEL_TOKEN ) &&
			Tracker::is_allow_track() &&
			! Tracker::has_terms_changed() &&
			Plugin::$instance->experiments->is_feature_active( self::EXPERIMENT_NAME );
	}

	private static function get_subscription_id() {
		$subscription = self::get_subscription();

		return $subscription['subscription_id'] ?? null;
	}

	private static function get_subscription() {
		if ( ! Utils::has_pro() ) {
			return null;
		}

		$license_data = get_option( '_elementor_pro_license_v2_data' );
		if ( ! isset( $license_data['value'] ) ) {
			return null;
		}

		return json_decode( $license_data['value'], true );
	}

	private static function get_remote_mixpanel_config() {
		$editor_assets_api = new EditorAssetsAPI( [
			EditorAssetsAPI::ASSETS_DATA_URL => static::REMOTE_MIXPANEL_CONFIG_URL,
			EditorAssetsAPI::ASSETS_DATA_TRANSIENT_KEY => '_elementor_mixpanel_config',
			EditorAssetsAPI::ASSETS_DATA_KEY => 'mixpanel',
		] );

		return $editor_assets_api->get_assets_data();
	}

	public static function get_mixpanel_api_host() {
		$mixpanel_config = self::get_remote_mixpanel_config();

		return wp_http_validate_url( $mixpanel_config[0]['apiHost'] ?? static::API_UPSTREAM_HOST );
	}

	public static function get_mixpanel_lib_host() {
		$mixpanel_config = self::get_remote_mixpanel_config();

		return wp_http_validate_url( $mixpanel_config[0]['libHost'] ?? static::LIBS_UPSTREAM_HOST );
	}

	private static function get_user_id() {
		$user_common_data = get_user_option( Common_App::OPTION_CONNECT_COMMON_DATA_KEY );

		if ( ! is_array( $user_common_data ) ) {
			return null;
		}

		return Common_App::get_connect_user_id_from_access_token( $user_common_data['access_token'] ?? null );
	}
}
