<?php

/**
 * Initialize license client on 'wcdc_pro_init' hook.
 * This hook is fired BEFORE the Pro plugin decides whether to initialize,
 * allowing the license client to verify license status first.
 *
 * @since 3.3.7
 */
add_action(
	'wcdc_pro_init',
	function () {
		global $qlwcdc_license_client;

		if ( ! isset( $qlwcdc_license_client ) ) {

			$qlwcdc_license_client = new QuadLayers\WP_License_Client\Load(
				array(
					'api_url'           => 'https://quadlayers.com/wp-json/wc/wlm/',
					'product_key'       => '16cb9ea2107b1ac236800dd5168c3c0f',
					'plugin_file'       => QLWCDC_PRO_PLUGIN_FILE,
					'parent_menu_slug'  => 'wc-settings',
					'license_menu_slug' => 'qlwcdc_license',
					'license_key_url'   => 'https://quadlayers.com/account/licenses/?utm_source=qlwcdc_plugin_pro&utm_medium=dashboard_notice&utm_campaign=license&utm_content=license_key_link',
					'support_url'       => 'https://quadlayers.com/account/support/?utm_source=qlwcdc_plugin_pro&utm_medium=dashboard_notice&utm_campaign=support&utm_content=support_link',
					'activation_delete_url' => 'https://quadlayers.com/account/support/?utm_source=qlwcdc_plugin_pro&utm_medium=dashboard_notice&utm_campaign=support&utm_content=support_link',
				)
			);
		}

		return $qlwcdc_license_client;
	},
	5 // Priority 5: Execute BEFORE the Pro plugin's callback (default priority 10).
);