<?php

if ( class_exists( 'QuadLayers\\WP_Plugin_Table_Links\\Load' ) ) {
	add_action('init', function() {
		new \QuadLayers\WP_Plugin_Table_Links\Load(
			QLWCDC_PRO_PLUGIN_FILE,
			array(
				array(
					'text' => esc_html__( 'Support', 'perfect-woocommerce-brands-pro' ),
					'url'  => 'https://quadlayers.com/account/support/?utm_source=qlwcdc_plugin_pro&utm_medium=plugin_table&utm_campaign=support&utm_content=support_link',
				),
				array(
					'text' => esc_html__( 'License', 'perfect-woocommerce-brands-pro' ),
					'url'  => 'https://quadlayers.com/account/licenses/?utm_source=qlwcdc_plugin_pro&utm_medium=plugin_table&utm_campaign=license&utm_content=license_link',
				),
			)
		);
	});

}
