<?php
/**
 * Woocommerce-direct-checkout-pro
 *
 * @package  WooCommerce Direct Checkout PRO
 * @since    1.0.0
 */

namespace QuadLayers\WCDC_PRO;

use QuadLayers\WCDC_PRO\Controllers\Archives;
use QuadLayers\WCDC_PRO\Controllers\Checkout;
use QuadLayers\WCDC_PRO\Controllers\General;
use QuadLayers\WCDC_PRO\Controllers\License;
use QuadLayers\WCDC_PRO\Controllers\Products;

/**
 * Plugin Main class
 *
 * @class Plugin
 * @version 1.0.0
 */
final class Plugin {

	/**
	 * The single instance of the class.
	 *
	 * @var WCDC_PRO
	 */
	protected static $instance;

	/**
	 * Construct
	 */
	private function __construct() {

		/**
		 * Load plugin textdomain.
		 */
		add_action( 'init', array( $this, 'load_textdomain' ), 1 );

		add_action(
			'wcdc_init',
			function () {

				/**
				 * Fires before initializing premium features.
				 * Allows license client to verify license status.
				 *
				 * @since 3.3.7
				 */
				do_action( 'wcdc_pro_init' );

				// Defer premium features initialization to ensure license client is fully loaded.
				// The license client initializes its models (activation, user_data) on 'init'.
				// We need to wait until after 'init' to access these properties safely.
				add_action(
					'wp_loaded',
					function () {

						new License();

						if ( ! $this->is_premium_enabled() ) {
							return;
						}

						/**
						 * Remove premium CSS
						 */
						remove_action( 'admin_footer', array( 'QuadLayers\\WCDC\\Plugin', 'add_premium_style' ) );
						/**
						 * Remove premium menu
						 */
						remove_action( 'qlwcdc_sections_header', array( 'QuadLayers\\WCDC\\Controller\\Premium', 'add_header' ) );
						remove_action( 'admin_menu', array( 'QuadLayers\\WCDC\\Controller\\Premium', 'add_menu' ) );
						/**
						 * Load classes
						 */
						new General();
						new Archives();
						new Products();
						new Checkout();
					}
				);
			}
		);
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'woocommerce-direct-checkout-pro', false, dirname( QLWCDC_PRO_PLUGIN_BASENAME ) . '/languages' );
	}

	/**
	 * Checks if premium features are enabled based on license status.
	 *
	 * @since 3.3.7
	 * @return bool True if license allows premium features.
	 */
	private function is_premium_enabled() {
		global $qlwcdc_license_client;

		if ( ! isset( $qlwcdc_license_client ) ) {
			return false;
		}

		if ( ! isset( $qlwcdc_license_client->activation ) ) {
			return false;
		}

		$status = $qlwcdc_license_client->activation->status();

		return 'valid' === $status;
	}

	/**
	 * Register scripts
	 */
	public function register_scripts() {
		wp_register_style( 'qlwcdc-pro', plugins_url( '/assets/frontend/qlwcdc-pro' . self::instance()->is_min() . '.css', QLWCDC_PRO_PLUGIN_FILE ), array(), QLWCDC_PRO_PLUGIN_VERSION, 'all' );

		wp_register_script( 'qlwcdc-pro', plugins_url( '/assets/frontend/qlwcdc-pro' . self::instance()->is_min() . '.js', QLWCDC_PRO_PLUGIN_FILE ), array( 'jquery', 'wc-add-to-cart-variation' ), QLWCDC_PRO_PLUGIN_VERSION, false );

		wp_localize_script(
			'qlwcdc-pro',
			'qlwcdc',
			array(
				'nonce'   => wp_create_nonce( 'qlwcdc' ),
				'delay'   => 200,
				'timeout' => null,
			)
		);
	}

	/**
	 * Is min
	 */
	public function is_min() {
		if ( ! defined( 'SCRIPT_DEBUG' ) || ! SCRIPT_DEBUG ) {
			return '.min';
		}
	}

	/**
	 * Instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}

add_action(
	'plugins_loaded',
	function () {
		Plugin::instance();
	}
);
