(function($) {
	'use strict';

	var BoosterOnboarding = {
		modal: null,
		currentGoal: null,

		init: function() {
			this.modal = $( '#booster-onboarding-modal' );
			this.bindEvents();
			this.setupAccessibility();
			this.loadCompletedGoals();
			this.initSearch();
		},

		loadCompletedGoals: function() {
			if (typeof boosterOnboarding.completedGoals !== 'undefined') {
				boosterOnboarding.completedGoals.forEach(
					function(goalId) {
						this.markGoalApplied( goalId );
					}.bind( this )
				);
			}
		},

		markGoalApplied: function(goalId) {
			if ( ! goalId) {
				return;
			}

			if (typeof boosterOnboarding.completedGoals === 'undefined' || ! Array.isArray( boosterOnboarding.completedGoals )) {
				boosterOnboarding.completedGoals = [];
			}

			if (boosterOnboarding.completedGoals.indexOf( goalId ) === -1) {
				boosterOnboarding.completedGoals.push( goalId );
			}

			var tile = $( '.booster-goal-tile[data-goal="' + goalId + '"]' );
			tile.attr( 'aria-pressed', 'true' );
			if (tile.length && !tile.find( '.applied-chip' ).length) {
				tile.prepend( '<span class="applied-chip">' + boosterOnboarding.strings.applied + '</span>' );
			}
		},

		bindEvents: function() {
			var self = this;

			$( document ).on(
				'click',
				'#launch-onboarding-modal',
				function() {
					self.showModal();
				}
			);

			$( document ).on(
				'click',
				'.booster-modal-close, .booster-modal-overlay',
				function() {
					self.closeModal();
				}
			);

			$( document ).on(
				'click',
				'.booster-goal-tile',
				function() {
					var goalId = $( this ).data( 'goal' );
					self.selectGoal( goalId );
				}
			);

			$( document ).on(
				'keydown',
				'.booster-goal-tile',
				function(e) {
					self.handleTileKeyboardNav( e, $( this ) );
				}
			);

			$( document ).on(
				'click',
				'.back-button, .cancel-button, .pick-another-goal-button, .close-button',
				function() {
					self.showGoalsScreen();
				}
			);

			$( document ).on(
				'click',
				'.apply-button',
				function() {
					self.applyGoal();
				}
			);

			$( document ).on(
				'click',
				'.undo-goal',
				function() {
					var goalId = $( this ).data( 'goal' );
					self.undoGoal( goalId );
				}
			);

			$( document ).on(
				'keydown',
				function(e) {
					if (e.keyCode === 27 && self.modal.is( ':visible' )) {
						self.closeModal();
					}
				}
			);
		},

		handleTileKeyboardNav: function(e, tile) {
			var keyCode = e.keyCode || e.which;

			if (keyCode === 13 || keyCode === 32) {
				e.preventDefault();
				tile.trigger( 'click' );
				return;
			}

			if (keyCode !== 37 && keyCode !== 38 && keyCode !== 39 && keyCode !== 40) {
				return;
			}

			e.preventDefault();

			var visibleTiles = this.modal.find( '.booster-goal-tile:visible' );
			var currentIndex = visibleTiles.index( tile );
			var nextIndex = currentIndex;

			if (keyCode === 37 || keyCode === 38) {
				nextIndex = currentIndex - 1;
			} else if (keyCode === 39 || keyCode === 40) {
				nextIndex = currentIndex + 1;
			}

			if (nextIndex >= 0 && nextIndex < visibleTiles.length) {
				visibleTiles.eq( nextIndex ).focus();
			}
		},

		updateProgress: function(step) {
			var progressIndicator = this.modal.find( '.booster-progress-indicator' );
			progressIndicator.attr( 'aria-valuenow', step );

			progressIndicator.find( '.progress-step' ).each(
				function() {
					var stepNum = parseInt( $( this ).data( 'step' ), 10 );
					$( this ).removeClass( 'active completed' );

					if (stepNum === step) {
						$( this ).addClass( 'active' );
					} else if (stepNum < step) {
						$( this ).addClass( 'completed' );
					}
				}
			);
		},

		setupAccessibility: function() {
			var self = this;

			this.modal.on(
				'keydown',
				function(e) {
					if (e.keyCode === 9) { // Tab key.
						var focusableElements = self.modal.find( 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])' );
						var firstElement      = focusableElements.first();
						var lastElement       = focusableElements.last();

						if (e.shiftKey) {
							if ($( document.activeElement ).is( firstElement )) {
								e.preventDefault();
								lastElement.focus();
							}
						} else {
							if ($( document.activeElement ).is( lastElement )) {
								e.preventDefault();
								firstElement.focus();
							}
						}
					}
				}
			);
		},

		showModal: function() {
			this.modal.show();
			this.logEvent( 'modal_open', {} );
			this.showGoalsScreen();

			setTimeout(
				function() {
					$( '.booster-goal-tile:visible' ).first().focus();
				},
				100
			);
		},

		closeModal: function() {
			this.modal.hide();
			this.currentGoal = null;
			this.resetSearch();
			this.logEvent( 'modal_close', {} );
		},

		showGoalsScreen: function() {
			this.modal.find( '.booster-goals-screen' ).addClass( 'active' );
			this.modal.find( '.booster-review-screen, .booster-success-screen, .booster-loading-screen' ).removeClass( 'active' );
			this.updateProgress( 1 );
			this.loadCompletedGoals();
		},

		showReviewScreen: function() {
			this.modal.find( '.booster-review-screen' ).addClass( 'active' );
			this.modal.find( '.booster-goals-screen, .booster-success-screen, .booster-loading-screen' ).removeClass( 'active' );
			this.updateProgress( 2 );
		},

		showSuccessScreen: function() {
			this.modal.find( '.booster-success-screen' ).addClass( 'active' );
			this.modal.find( '.booster-goals-screen, .booster-review-screen, .booster-loading-screen' ).removeClass( 'active' );
			this.updateProgress( 3 );
		},

		showLoadingScreen: function() {
			this.modal.find( '.booster-loading-screen' ).addClass( 'active' );
			this.modal.find( '.booster-goals-screen, .booster-review-screen, .booster-success-screen' ).removeClass( 'active' );
		},

		selectGoal: function(goalId) {
			if ( boosterOnboarding.goals[goalId] && boosterOnboarding.goals[goalId].setup_url ) {
				window.location.assign( boosterOnboarding.goals[goalId].setup_url );
				return;
			}
			if ( ! boosterOnboarding.goals[goalId]) {
				return;
			}

			this.currentGoal = goalId;
			var goal         = boosterOnboarding.goals[goalId];
			$( '.booster-goal-tile' ).attr( 'aria-pressed', 'false' );
			$( '.booster-goal-tile[data-goal="' + goalId + '"]' ).attr( 'aria-pressed', 'true' );

			$( '#review-goal-title' ).text( goal.title );

			var modulesList = $( '#modules-list' );
			modulesList.empty();
			goal.modules.forEach(
				function(module) {
					var moduleName = module.name || module.id.replace( /_/g, ' ' ).replace(
						/\b\w/g,
						function(letter) {
							return letter.toUpperCase();
						}
					);
					modulesList.append( '<li>' + moduleName + '</li>' );
				}
			);

			var settingsList = $( '#settings-list' );
			settingsList.empty();
			goal.modules.forEach(
				function(module) {
					Object.keys( module.settings ).forEach(
						function(key) {
							if (key === 'create_demo_draft') {
								settingsList.append( '<li>' + boosterOnboarding.strings.create_demo_draft + '</li>' );
							} else if (key === 'add_one_extra') {
								settingsList.append( '<li>' + boosterOnboarding.strings.add_one_extra + '</li>' );
							} else {
								var value = module.settings[key];
								if (typeof value === 'object') {
									value = JSON.stringify( value );
								}
								settingsList.append( '<li>' + key + ': ' + value + '</li>' );
							}
						}
					);
				}
			);

			this.logEvent( 'goal_select', { goal_id: goalId } );
			this.showReviewScreen();
		},

		applyGoal: function() {
			if ( ! this.currentGoal) {
				return;
			}

			var self           = this;
			var createSnapshot = $( '#create-snapshot' ).is( ':checked' );

			this.showLoadingScreen();
			$( '#loading-message' ).text( boosterOnboarding.strings.applying );

			$.ajax(
				{
					url: boosterOnboarding.ajaxUrl,
					type: 'POST',
					data: {
						action: 'booster_apply_goal',
						goal_id: this.currentGoal,
						create_snapshot: createSnapshot,
						nonce: boosterOnboarding.nonce
					},
					success: function(response) {
						if (response.success) {
							self.logEvent( 'goal_apply_success', { goal_id: self.currentGoal } );
							$( '#success-message' ).text( response.data.message );

							if (response.data.next_steps && response.data.next_steps.length > 0) {
								var nextStepsList = $( '#next-steps-list' );
								nextStepsList.empty();
								response.data.next_steps.forEach(
									function(step) {
										nextStepsList.append( '<li>' + step + '</li>' );
									}
								);
								$( '.success-next-steps' ).show();
							} else {
								$( '.success-next-steps' ).hide();
							}

							if (response.data.next_step_text && response.data.next_step_link) {
								$( '#next-step-text' ).text( response.data.next_step_text );
								$( '.next-step-button' ).attr( 'href', response.data.next_step_link ).show();
							} else {
								$( '.next-step-button' ).hide();
							}

							self.showSuccessScreen();
							self.markGoalApplied( self.currentGoal );
							self.logEvent( 'goal_completed', { goal_id: self.currentGoal } );
						} else {
							alert( response.data.message || boosterOnboarding.strings.error );
							self.showReviewScreen();
							self.logEvent( 'goal_apply_error', { goal_id: self.currentGoal, error: response.data.message } );
						}
					},
					error: function() {
						alert( boosterOnboarding.strings.error );
						self.showReviewScreen();
						self.logEvent( 'goal_apply_error', { goal_id: self.currentGoal, error: 'ajax_error' } );
					}
				}
			);
		},

		undoGoal: function(goalId) {
			var self = this;

			if ( ! confirm( boosterOnboarding.strings.confirmUndo )) {
				return;
			}

			var button       = $( '.undo-goal[data-goal="' + goalId + '"]' );
			var originalText = button.text();
			button.text( boosterOnboarding.strings.undoing ).prop( 'disabled', true );

			$.ajax(
				{
					url: boosterOnboarding.ajaxUrl,
					type: 'POST',
					data: {
						action: 'booster_undo_goal',
						goal_id: goalId,
						nonce: boosterOnboarding.nonce
					},
					success: function(response) {
						if (response.success) {
							alert( response.data.message );
							self.logEvent( 'goal_undo_success', { goal_id: goalId } );
							window.location.reload();
						} else {
							alert( response.data.message || boosterOnboarding.strings.error );
							button.text( originalText ).prop( 'disabled', false );
							self.logEvent( 'goal_undo_error', { goal_id: goalId, error: response.data.message } );
						}
					},
					error: function() {
						alert( boosterOnboarding.strings.error );
						button.text( originalText ).prop( 'disabled', false );
						self.logEvent( 'goal_undo_error', { goal_id: goalId, error: 'ajax_error' } );
					}
				}
			);
		},

		logEvent: function(eventType, eventData) {
			$.ajax(
				{
					url: boosterOnboarding.ajaxUrl,
					type: 'POST',
					data: {
						action: 'booster_log_onboarding_event',
						event_type: eventType,
						event_data: eventData,
						nonce: boosterOnboarding.nonce
					}
				}
			);
		},

		initSearch: function() {
			var self = this;
			var searchInput = $( '#booster-goal-search' );
			var clearButton = $( '.booster-search-clear' );
			var noResults = $( '.booster-no-results' );
			var debounceTimer = null;

			if (searchInput.length === 0) {
				return;
			}

			searchInput.on(
				'input',
				function() {
					var query = $( this ).val().toLowerCase().trim();

					if (query.length > 0) {
						clearButton.show();
					} else {
						clearButton.hide();
					}

					clearTimeout( debounceTimer );
					debounceTimer = setTimeout(
						function() {
							self.filterGoals( query );
						},
						150
					);
				}
			);

			clearButton.on(
				'click',
				function() {
					searchInput.val( '' ).trigger( 'input' ).focus();
				}
			);

			$( document ).on(
				'click',
				'.booster-modal-close, .booster-modal-overlay, .back-button, .cancel-button, .pick-another-goal-button, .close-button',
				function() {
					self.resetSearch();
				}
			);
		},

		resetSearch: function() {
			$( '#booster-goal-search' ).val( '' );
			$( '.booster-search-clear' ).hide();
			$( '.booster-no-results' ).hide();
			$( '.booster-goal-tile' ).show();
		},

		filterGoals: function(query) {
			var goalTiles = $( '.booster-goal-tile' );
			var noResults = $( '.booster-no-results' );
			var visibleCount = 0;

			if (query === '') {
				goalTiles.show();
				noResults.hide();
				return;
			}

			goalTiles.each(
				function() {
					var tile = $( this );
					var title = tile.find( 'h3' ).text().toLowerCase();
					var subtitle = tile.find( 'p' ).text().toLowerCase();
					var modules = [];

					tile.find( '.module-tag' ).each(
						function() {
							modules.push( $( this ).text().toLowerCase() );
						}
					);

					var searchText = title + ' ' + subtitle + ' ' + modules.join( ' ' );

					if (searchText.indexOf( query ) !== -1) {
						tile.show();
						visibleCount++;
					} else {
						tile.hide();
					}
				}
			);

			if (visibleCount === 0) {
				noResults.show();
			} else {
				noResults.hide();
			}

			this.logEvent( 'goal_search', { query: query, results_count: visibleCount } );
		}
	};

	$( document ).ready(
		function() {
			BoosterOnboarding.init();
		}
	);

	window.BoosterOnboarding = BoosterOnboarding;

})( jQuery );

jQuery( document ).ready(
	function() {
		// Agar URL me hash #launch-onboarding-modal hai.
		if (window.location.hash === '#launch-onboarding-modal') {
			if (typeof window.BoosterOnboarding !== 'undefined') {
				window.BoosterOnboarding.showModal();
			}
		}

		// Agar URL me ?modal=onboarding hai.
		var urlParams = new URLSearchParams( window.location.search );
		if (urlParams.get( 'modal' ) === 'onboarding') {
			if (typeof window.BoosterOnboarding !== 'undefined') {
				window.BoosterOnboarding.showModal();
			}
		}
	}
);
