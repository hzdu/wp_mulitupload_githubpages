<?php
/**
 * Booster for WooCommerce - Onboarding Controller
 *
 * @version 7.4.0
 * @author  Pluggabl LLC.
 * @package Booster_Plus_For_WooCommerce/admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Booster_Onboarding' ) ) :

	/**
	 * Booster_Onboarding.
	 */
	class Booster_Onboarding {

		/**
		 * Starter invoice journey.
		 *
		 * @var WCJ_Invoice_Setup
		 */
		private $invoice_setup;

		/**
		 * Onboarding map data
		 *
		 * @var array
		 */
		private $onboarding_map;

		/**
		 * Option key for storing onboarding state
		 *
		 * @var string
		 */
		private $option_key = 'booster_plus_onboarding';

		/**
		 * Constructor.
		 */
		public function __construct() {
			require_once __DIR__ . '/class-wcj-invoice-setup.php';
			$this->invoice_setup  = new WCJ_Invoice_Setup( $this->option_key );
			$this->onboarding_map = include WCJ_PLUGIN_PATH . '/includes/admin/onboarding-map.php';

			if ( ! did_action( 'init' ) ) {
				wcj_init_presentation(
					function () {
						if ( ! is_array( $this->onboarding_map ) ) {
							return;
						}

						if (
							isset( $this->onboarding_map['professional_invoices'] ) &&
							is_array( $this->onboarding_map['professional_invoices'] ) &&
							isset( $this->onboarding_map['professional_invoices']['title'] ) &&
							'Branded document setup' === $this->onboarding_map['professional_invoices']['title']
						) {
							$this->onboarding_map['professional_invoices']['title'] = __( 'Branded document setup', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['professional_invoices'] ) &&
							is_array( $this->onboarding_map['professional_invoices'] ) &&
							isset( $this->onboarding_map['professional_invoices']['subtitle'] ) &&
							'Create a starter sample, rehearse an attachment and activate only after review.' === $this->onboarding_map['professional_invoices']['subtitle']
						) {
							$this->onboarding_map['professional_invoices']['subtitle'] = __( 'Create a starter sample, rehearse an attachment and activate only after review.', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['professional_invoices'] ) &&
							is_array( $this->onboarding_map['professional_invoices'] ) &&
							isset( $this->onboarding_map['professional_invoices']['next_step_text'] ) &&
							'Open starter document guide' === $this->onboarding_map['professional_invoices']['next_step_text']
						) {
							$this->onboarding_map['professional_invoices']['next_step_text'] = __( 'Open starter document guide', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['grow_sales'] ) &&
							is_array( $this->onboarding_map['grow_sales'] ) &&
							isset( $this->onboarding_map['grow_sales']['title'] ) &&
							'Grow sales now' === $this->onboarding_map['grow_sales']['title']
						) {
							$this->onboarding_map['grow_sales']['title'] = __( 'Grow sales now', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['grow_sales'] ) &&
							is_array( $this->onboarding_map['grow_sales'] ) &&
							isset( $this->onboarding_map['grow_sales']['subtitle'] ) &&
							'Enable sales notifications and prepare frequently bought together bundles' === $this->onboarding_map['grow_sales']['subtitle']
						) {
							$this->onboarding_map['grow_sales']['subtitle'] = __( 'Enable sales notifications and prepare frequently bought together bundles', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['grow_sales'] ) &&
							is_array( $this->onboarding_map['grow_sales'] ) &&
							isset( $this->onboarding_map['grow_sales']['next_step_text'] ) &&
							'Create first bundle' === $this->onboarding_map['grow_sales']['next_step_text']
						) {
							$this->onboarding_map['grow_sales']['next_step_text'] = __( 'Create first bundle', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['faster_checkout'] ) &&
							is_array( $this->onboarding_map['faster_checkout'] ) &&
							isset( $this->onboarding_map['faster_checkout']['title'] ) &&
							'Faster checkout' === $this->onboarding_map['faster_checkout']['title']
						) {
							$this->onboarding_map['faster_checkout']['title'] = __( 'Faster checkout', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['faster_checkout'] ) &&
							is_array( $this->onboarding_map['faster_checkout'] ) &&
							isset( $this->onboarding_map['faster_checkout']['subtitle'] ) &&
							'Set up one-page checkout with a draft page' === $this->onboarding_map['faster_checkout']['subtitle']
						) {
							$this->onboarding_map['faster_checkout']['subtitle'] = __( 'Set up one-page checkout with a draft page', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['faster_checkout'] ) &&
							is_array( $this->onboarding_map['faster_checkout'] ) &&
							isset( $this->onboarding_map['faster_checkout']['next_step_text'] ) &&
							'Configure checkout page' === $this->onboarding_map['faster_checkout']['next_step_text']
						) {
							$this->onboarding_map['faster_checkout']['next_step_text'] = __( 'Configure checkout page', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['work_smarter'] ) &&
							is_array( $this->onboarding_map['work_smarter'] ) &&
							isset( $this->onboarding_map['work_smarter']['title'] ) &&
							'Work smarter (backend)' === $this->onboarding_map['work_smarter']['title']
						) {
							$this->onboarding_map['work_smarter']['title'] = __( 'Work smarter (backend)', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['work_smarter'] ) &&
							is_array( $this->onboarding_map['work_smarter'] ) &&
							isset( $this->onboarding_map['work_smarter']['subtitle'] ) &&
							'Enable sequential order numbers and admin enhancements' === $this->onboarding_map['work_smarter']['subtitle']
						) {
							$this->onboarding_map['work_smarter']['subtitle'] = __( 'Enable sequential order numbers and admin enhancements', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['work_smarter'] ) &&
							is_array( $this->onboarding_map['work_smarter'] ) &&
							isset( $this->onboarding_map['work_smarter']['next_step_text'] ) &&
							'Configure order numbers' === $this->onboarding_map['work_smarter']['next_step_text']
						) {
							$this->onboarding_map['work_smarter']['next_step_text'] = __( 'Configure order numbers', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['go_global'] ) &&
							is_array( $this->onboarding_map['go_global'] ) &&
							isset( $this->onboarding_map['go_global']['title'] ) &&
							'Go global (starter)' === $this->onboarding_map['go_global']['title']
						) {
							$this->onboarding_map['go_global']['title'] = __( 'Go global (starter)', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['go_global'] ) &&
							is_array( $this->onboarding_map['go_global'] ) &&
							isset( $this->onboarding_map['go_global']['subtitle'] ) &&
							'Add additional currency support' === $this->onboarding_map['go_global']['subtitle']
						) {
							$this->onboarding_map['go_global']['subtitle'] = __( 'Add additional currency support', 'woocommerce-jetpack' );
						}

						if (
							isset( $this->onboarding_map['go_global'] ) &&
							is_array( $this->onboarding_map['go_global'] ) &&
							isset( $this->onboarding_map['go_global']['next_step_text'] ) &&
							'Configure currencies' === $this->onboarding_map['go_global']['next_step_text']
						) {
							$this->onboarding_map['go_global']['next_step_text'] = __( 'Configure currencies', 'woocommerce-jetpack' );
						}
					}
				);
			}

			add_action( 'admin_menu', array( $this, 'add_getting_started_menu' ), 100 );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
			add_action( 'wp_ajax_booster_apply_goal', array( $this, 'ajax_apply_goal' ) );
			add_action( 'wp_ajax_booster_undo_goal', array( $this, 'ajax_undo_goal' ) );
			add_action( 'wp_ajax_booster_log_onboarding_event', array( $this, 'ajax_log_onboarding_event' ) );

			add_action( 'admin_notices', array( $this, 'maybe_show_onboarding_modal' ) );
		}

		/**
		 * Add Getting Started menu item
		 */
		public function add_getting_started_menu() {
			global $submenu;

			// Only add submenu if parent menu exists.
			if ( isset( $submenu['wcj-dashboard'] ) ) {
				add_submenu_page(
					'wcj-dashboard',
					__( 'Getting Started', 'woocommerce-jetpack' ),
					__( 'Getting Started', 'woocommerce-jetpack' ),
					'manage_woocommerce', // phpcs:ignore
					'wcj-getting-started',
					array( $this, 'getting_started_page' )
				);
			} else {
				// Retry a bit later if parent menu not found.
				add_action( 'admin_menu', array( $this, 'add_getting_started_menu' ), 110 );
			}
		}

		/**
		 * Enqueue scripts and styles for the Getting Started page or onboarding modal.
		 *
		 * @param string $hook The current admin page hook suffix.
		 *
		 * @return void
		 */
		public function enqueue_scripts( $hook ) {
			if ( strpos( $hook, 'wcj-getting-started' ) !== false || $this->should_show_modal() ) {
				$onboarding_state = get_option( $this->option_key, array() );
				$completed_goals  = $this->invoice_display_goals( isset( $onboarding_state['completed_goals'] ) ? (array) $onboarding_state['completed_goals'] : array() );

				wp_enqueue_style(
					'booster-onboarding',
					wcj_plugin_url() . '/assets/css/admin/booster-onboarding.css',
					array(),
					time()
				);

				wp_enqueue_script(
					'booster-onboarding',
					wcj_plugin_url() . '/assets/js/admin/booster-onboarding.js',
					array( 'jquery' ),
					WCJ()->version,
					true
				);

				wp_localize_script(
					'booster-onboarding',
					'boosterOnboarding',
					array(
						'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
						'nonce'          => wp_create_nonce( 'booster_onboarding_nonce' ),
						'goals'          => $this->onboarding_map,
						'completedGoals' => $completed_goals,
						'strings'        => array(
							'applying'          => __( 'Applying...', 'woocommerce-jetpack' ),
							'undoing'           => __( 'Undoing...', 'woocommerce-jetpack' ),
							'success'           => __( 'Success!', 'woocommerce-jetpack' ),
							'error'             => __( 'Error occurred. Please try again.', 'woocommerce-jetpack' ),
							'close'             => __( 'Close', 'woocommerce-jetpack' ),
							'confirmUndo'       => __( 'Are you sure you want to undo this goal?', 'woocommerce-jetpack' ),
							'applied'           => __( 'Applied', 'woocommerce-jetpack' ),
							'create_demo_draft' => __( 'Create a demo draft page', 'woocommerce-jetpack' ),
							'add_one_extra'     => __( 'Add one extra currency', 'woocommerce-jetpack' ),
						),
					)
				);
			}
		}

		/**
		 * Check if modal should be shown
		 */
		private function should_show_modal() {
			$onboarding_state = get_option( $this->option_key, array() );
			return empty( $onboarding_state['last_prompted_at'] );
		}

		/**
		 * Maybe show onboarding modal on first run
		 */
		public function maybe_show_onboarding_modal() {
			// phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this commerce capability; retain least-privilege access.
			if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore
				return;
			}

			if ( $this->should_show_modal() ) {
				include WCJ_PLUGIN_PATH . '/includes/admin/views/onboarding-modal.php';
			}
		}

		/**
		 * Present only proved invoice completion, without rewriting legacy state.
		 *
		 * @param array $goals Existing completed goal IDs.
		 * @return array Presentation-only goal IDs.
		 */
		private function invoice_display_goals( $goals ) {
			$goals = array_values( array_diff( (array) $goals, array( 'professional_invoices', 'professional_docs_pro' ) ) );
			// phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this commerce capability; retain least-privilege access.
			if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore
				return $goals;
			}
			try {
				if ( $this->invoice_setup->is_active() ) {
					$goals[] = isset( $this->onboarding_map['professional_docs_pro'] ) ? 'professional_docs_pro' : 'professional_invoices';
				}
			} catch ( Throwable $error ) {
				// Invalid or conflicting setup state is never displayed as completion.
				return $goals;
			}
			return $goals;
		}

		/**
		 * Getting Started page content
		 */
		public function getting_started_page() {
			if ( isset( $_GET['wcj-invoice-setup'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only view.
				$this->invoice_setup->render();
				return;
			}
			echo '<p><a class="button" href="' . esc_url( WCJ_Invoice_Setup::url() ) . '">' . esc_html__( 'Create a branded starter invoice', 'woocommerce-jetpack' ) . '</a></p>';
			$onboarding_state = get_option( $this->option_key, array() );
			$completed_goals  = $this->invoice_display_goals( isset( $onboarding_state['completed_goals'] ) ? $onboarding_state['completed_goals'] : array() );
			$snapshots        = isset( $onboarding_state['snapshots'] ) ? $onboarding_state['snapshots'] : array();

			echo '<div class="wrap">';
			echo '<h1>' . esc_html__( 'Getting Started with Booster', 'woocommerce-jetpack' ) . '</h1>';

			echo '<div class="booster-getting-started">';
			echo '<p>' . esc_html__( 'Welcome to Booster! Get started quickly by choosing one of these goals:', 'woocommerce-jetpack' ) . '</p>';

			echo '<button type="button" class="button button-primary" id="launch-onboarding-modal">';
			echo esc_html__( 'Open onboarding', 'woocommerce-jetpack' );
			echo '</button>';

			if ( ! empty( $completed_goals ) ) {
				echo '<h2>' . esc_html__( 'Completed Goals', 'woocommerce-jetpack' ) . '</h2>';
				echo '<div class="completed-goals">';

				foreach ( $completed_goals as $goal_id ) {
					if ( isset( $this->onboarding_map[ $goal_id ] ) ) {
						$goal = $this->onboarding_map[ $goal_id ];
						echo '<div class="goal-item completed">';
						echo '<div class="goal-item-content">';
						echo '<span class="dashicons ' . esc_attr( $goal['icon'] ) . '"></span>';
						echo '<strong>' . esc_html( $goal['title'] ) . '</strong>';
						echo '<p>' . esc_html( $goal['subtitle'] ) . '</p>';
						echo '</div>';

						if ( in_array( $goal_id, array( 'professional_invoices', 'professional_docs_pro' ), true ) ) {
							echo '<a class="button" href="' . esc_url( WCJ_Invoice_Setup::url() ) . '">' . esc_html__( 'Review or undo starter settings', 'woocommerce-jetpack' ) . '</a>';
						} elseif ( isset( $snapshots[ $goal_id ] ) ) {
							echo '<div class="goal-item-actions">';
							echo '<span class="applied-chip">' . esc_html__( 'Applied', 'woocommerce-jetpack' ) . '</span>';
							echo '<button type="button" class="button undo-goal" data-goal="' . esc_attr( $goal_id ) . '">';
							echo esc_html__( 'Undo', 'woocommerce-jetpack' );
							echo '</button>';
							echo '</div>';
						}
						echo '</div>';
					}
				}
				echo '</div>';
			}

			echo '</div>';
			echo '</div>';

			include WCJ_PLUGIN_PATH . '/includes/admin/views/onboarding-modal.php';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( isset( $_GET['modal'] ) && 'onboarding' === $_GET['modal'] ) : ?>
		<script>
		window.addEventListener("load", function() {
			const btn = document.getElementById("launch-onboarding-modal");
			if (btn) {
				console.log("Auto-opening onboarding modal");
				btn.click();

				// Clean URL
				if (window.history.replaceState) {
					const url = new URL(window.location);
					url.searchParams.delete('modal');
					window.history.replaceState({}, document.title, url);
				}
			}
		});
		</script>
				<?php
		endif;
		}

		/**
		 * AJAX handler for applying a goal
		 */
		public function ajax_apply_goal() {
			check_ajax_referer( 'booster_onboarding_nonce', 'nonce' );

			// phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this commerce capability; retain least-privilege access.
			if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore
				wp_die( esc_html__( 'Insufficient permissions.', 'woocommerce-jetpack' ) );
			}

			$goal_id         = isset( $_POST['goal_id'] ) ? sanitize_text_field( wp_unslash( $_POST['goal_id'] ) ) : '';
			$create_snapshot = isset( $_POST['create_snapshot'] ) && 'true' === $_POST['create_snapshot'];

			if ( ! isset( $this->onboarding_map[ $goal_id ] ) ) {
				wp_send_json_error( array( 'message' => __( 'Invalid goal ID.', 'woocommerce-jetpack' ) ) );
			}

			$result = $this->apply_goal( $goal_id, $create_snapshot );

			if ( $result['success'] ) {
				do_action( 'booster_onboarding_goal_applied', $goal_id );
				wp_send_json_success( $result );
			} else {
				wp_send_json_error( $result );
			}
		}

		/**
		 * AJAX handler for undoing a goal.
		 *
		 * @return void
		 */
		public function ajax_undo_goal() {
			check_ajax_referer( 'booster_onboarding_nonce', 'nonce' );

			// phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this commerce capability; retain least-privilege access.
			if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore
				wp_die( esc_html__( 'Insufficient permissions.', 'woocommerce-jetpack' ) );
			}

			$goal_id = isset( $_POST['goal_id'] ) ? sanitize_text_field( wp_unslash( $_POST['goal_id'] ) ) : '';

			if ( ! isset( $this->onboarding_map[ $goal_id ] ) ) {
				wp_send_json_error( array( 'message' => __( 'Invalid goal ID.', 'woocommerce-jetpack' ) ) );
			}

			$result = $this->undo_goal( $goal_id );

			if ( $result['success'] ) {
				do_action( 'booster_onboarding_undo', $goal_id );
				wp_send_json_success( $result );
			} else {
				wp_send_json_error( $result );
			}
		}

		/**
		 * Apply a goal.
		 *
		 * @param array|string $goal_id The goal ID to apply.
		 * @param bool         $create_snapshot Whether to create a snapshot before applying changes.
		 *
		 * @return array
		 */
		public function apply_goal( $goal_id, $create_snapshot = true ) {
			if ( in_array( $goal_id, array( 'professional_invoices', 'professional_docs_pro' ), true ) ) {
				WCJ_Invoice_Setup::authorize();
				return array(
					'success'   => false,
					'message'   => __( 'Open the branded document guide, generate a sample and review before activating settings.', 'woocommerce-jetpack' ),
					'setup_url' => WCJ_Invoice_Setup::url(),
				);
			}
			if ( ! isset( $this->onboarding_map[ $goal_id ] ) ) {
				return array(
					'success' => false,
					'message' => __( 'Invalid goal ID.', 'woocommerce-jetpack' ),
				);
			}

			$goal            = $this->onboarding_map[ $goal_id ];
			$snapshot_before = array();

			if ( $create_snapshot ) {
				$snapshot_before = $this->create_snapshot( $goal );
			}

			$snapshot_after = array();

			foreach ( $goal['modules'] as $module ) {
				$apply_result = $this->apply_module_settings( $module );
				if ( ! $apply_result['success'] ) {
					return $apply_result;
				}
				$snapshot_after = array_merge( $snapshot_after, $apply_result['settings'] );
			}

			$onboarding_state = get_option( $this->option_key, array() );

			if ( ! isset( $onboarding_state['completed_goals'] ) ) {
				$onboarding_state['completed_goals'] = array();
			}

			if ( ! in_array( $goal_id, $onboarding_state['completed_goals'], true ) ) {
				$onboarding_state['completed_goals'][] = $goal_id;
			}

			if ( $create_snapshot ) {
				$onboarding_state['snapshots'][ $goal_id ] = array(
					'before'     => $snapshot_before,
					'after'      => $snapshot_after,
					'created_at' => current_time( 'c' ),
				);
			}

			$onboarding_state['last_prompted_at'] = current_time( 'c' );

			$this->log_analytics_event(
				'goal_applied',
				$goal_id,
				array(
					'modules_enabled'  => array_column( $goal['modules'], 'id' ),
					'snapshot_created' => $create_snapshot,
				)
			);

			$this->log_analytics_event(
				'goal_completed',
				$goal_id,
				array(
					'first_win_check_met' => $this->check_first_win( $goal_id ),
				)
			);

			update_option( $this->option_key, $onboarding_state );

			$next_step_link = '';
			if ( isset( $goal['next_step_link'] ) ) {
				$next_step_link = admin_url( $goal['next_step_link'] . wp_create_nonce( 'wcj-cat-nonce' ) );
			}

			$next_steps = $this->get_goal_next_steps( $goal_id );

			return array(
				'success'        => true,
				'message'        => __( 'Goal applied successfully!', 'woocommerce-jetpack' ),
				'next_step_text' => isset( $goal['next_step_text'] ) ? $goal['next_step_text'] : '',
				'next_step_link' => $next_step_link,
				'next_steps'     => $next_steps,
			);
		}

		/**
		 * Create a snapshot of current settings before applying changes.
		 *
		 * @param string $goal The goal ID for which to create the snapshot.
		 *
		 * @return array The snapshot of current settings.
		 */
		private function create_snapshot( $goal ) {
			$snapshot = array();

			foreach ( $goal['modules'] as $module ) {
				foreach ( $module['settings'] as $option_key => $value ) {
					if ( 'create_demo_draft' === $option_key || 'add_one_extra' === $option_key ) {
						continue;
					}
					$snapshot[ $option_key ] = get_option( $option_key, null );
				}
			}

			return $snapshot;
		}

		/**
		 * Apply module settings
		 *
		 * @param array $module The module configuration.
		 *
		 * @return array Result of applying the module settings.
		 */
		private function apply_module_settings( $module ) {
			$module_id        = $module['id'];
			$settings         = $module['settings'];
			$applied_settings = array();

			switch ( $module_id ) {
				case 'sales_notifications':
					return $this->apply_sales_notifications( $settings );

				case 'one_page_checkout':
					return $this->apply_one_page_checkout( $settings );

				case 'reviews':
					return $this->apply_reviews( $settings );

				case 'order_numbers':
					return $this->apply_order_numbers( $settings );

				case 'currency':
					return $this->apply_currency( $settings );

				case 'frequently_bought_together':
					return $this->apply_frequently_bought_together( $settings );

				case 'admin_orders_list':
					return $this->apply_admin_orders_list( $settings );

				default:
					foreach ( $settings as $option_key => $value ) {
						if ( in_array( $option_key, array( 'create_demo_draft', 'add_one_extra' ), true ) ) {
							continue;
						}
						update_option( $option_key, $value );
						$applied_settings[ $option_key ] = $value;
					}
					break;
			}

			return array(
				'success'  => true,
				'settings' => $applied_settings,
			);
		}

		/**
		 * Apply sales notifications settings
		 *
		 * @param array $settings The settings to apply.
		 *
		 * @return array Result of applying the settings.
		 */
		private function apply_sales_notifications( $settings ) {
			$applied_settings = array();

			foreach ( $settings as $option_key => $value ) {
				if ( 'wcj_sale_msg_styling' === $option_key ) {
					update_option( $option_key, $value );
				} else {
					update_option( $option_key, $value );
				}
				$applied_settings[ $option_key ] = $value;
			}

			return array(
				'success'  => true,
				'settings' => $applied_settings,
			);
		}

		/**
		 * Apply one page checkout settings
		 *
		 * @param array $settings The settings to apply.
		 *
		 * @return array Result of applying the settings.
		 */
		private function apply_one_page_checkout( $settings ) {
			$applied_settings = array();

			foreach ( $settings as $option_key => $value ) {
				if ( 'create_demo_draft' === $option_key && $value ) {
					$this->create_one_page_checkout_draft();
				} else {
					update_option( $option_key, $value );
					$applied_settings[ $option_key ] = $value;
				}
			}

			return array(
				'success'  => true,
				'settings' => $applied_settings,
			);
		}

		/**
		 * Create draft page for one page checkout
		 */
		private function create_one_page_checkout_draft() {
			$query = new WP_Query(
				array(
					'post_type'              => 'page',
					'title'                  => 'Quick Checkout (Draft)',
					'post_status'            => 'all',
					'posts_per_page'         => 1,
					'no_found_rows'          => true,
					'ignore_sticky_posts'    => true,
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
				)
			);

			if ( $query->have_posts() ) {
				return;
			}

			$page_data = array(
				'post_title'   => 'Quick Checkout (Draft)',
				'post_content' => '[wcj_one_page_checkout]',
				'post_status'  => 'draft',
				'post_type'    => 'page',
				'post_author'  => get_current_user_id(),
			);

			wp_insert_post( $page_data );
		}

		/**
		 * Apply reviews settings
		 *
		 * @param array $settings The settings to apply.
		 *
		 * @return array Result of applying the settings.
		 */
		private function apply_reviews( $settings ) {
			$applied_settings = array();

			foreach ( $settings as $option_key => $value ) {
				update_option( $option_key, $value );
				$applied_settings[ $option_key ] = $value;
			}

			return array(
				'success'  => true,
				'settings' => $applied_settings,
			);
		}

		/**
		 * Apply order numbers settings
		 *
		 * @param array $settings The settings to apply.
		 *
		 * @return array Result of applying the settings.
		 */
		private function apply_order_numbers( $settings ) {
			$applied_settings = array();

			foreach ( $settings as $option_key => $value ) {
				update_option( $option_key, $value );
				$applied_settings[ $option_key ] = $value;
			}

			return array(
				'success'  => true,
				'settings' => $applied_settings,
			);
		}

		/**
		 * Apply currency settings
		 *
		 * @param array $settings The settings to apply.
		 *
		 * @return array Result of applying the settings.
		 */
		private function apply_currency( $settings ) {
			$applied_settings = array();

			foreach ( $settings as $option_key => $value ) {
				if ( 'add_one_extra' === $option_key && $value ) {
					$this->add_extra_currency();
				} else {
					update_option( $option_key, $value );
					$applied_settings[ $option_key ] = $value;
				}
			}

			return array(
				'success'  => true,
				'settings' => $applied_settings,
			);
		}

		/**
		 * Add one extra currency (EUR as default)
		 */
		private function add_extra_currency() {
			$current_currency = get_woocommerce_currency();
			if ( 'EUR' !== $current_currency ) {
				update_option( 'wcj_currency_EUR', '€' );
			} elseif ( 'USD' !== $current_currency ) {
				update_option( 'wcj_currency_USD', '$' );
			}
		}

		/**
		 * Apply frequently bought together settings
		 *
		 * @param array $settings The settings to apply.
		 *
		 * @return array Result of applying the settings.
		 */
		private function apply_frequently_bought_together( $settings ) {
			$applied_settings = array();

			foreach ( $settings as $option_key => $value ) {
				update_option( $option_key, $value );
				$applied_settings[ $option_key ] = $value;
			}

			return array(
				'success'  => true,
				'settings' => $applied_settings,
			);
		}

		/**
		 * Apply admin orders list settings
		 *
		 * @param array $settings The settings to apply.
		 *
		 * @return array Result of applying the settings.
		 */
		private function apply_admin_orders_list( $settings ) {
			$applied_settings = array();

			foreach ( $settings as $option_key => $value ) {
				update_option( $option_key, $value );
				$applied_settings[ $option_key ] = $value;
			}

			return array(
				'success'  => true,
				'settings' => $applied_settings,
			);
		}

		/**
		 * Undo a goal
		 *
		 * @param string $goal_id The goal ID to undo.
		 *
		 * @return array Result of undoing the goal.
		 */
		public function undo_goal( $goal_id ) {
			if ( in_array( $goal_id, array( 'professional_invoices', 'professional_docs_pro' ), true ) ) {
				return array(
					'success'   => false,
					'message'   => __( 'Use the document guide undo. Legacy snapshots cannot safely overwrite later invoice edits.', 'woocommerce-jetpack' ),
					'setup_url' => WCJ_Invoice_Setup::url(),
				);
			}
			$onboarding_state = get_option( $this->option_key, array() );

			if ( ! isset( $onboarding_state['snapshots'][ $goal_id ] ) ) {
				return array(
					'success' => false,
					'message' => __( 'No snapshot found for this goal.', 'woocommerce-jetpack' ),
				);
			}

			$snapshot        = $onboarding_state['snapshots'][ $goal_id ];
			$before_settings = $snapshot['before'];

			foreach ( $before_settings as $option_key => $value ) {
				if ( null === $value ) {
					delete_option( $option_key );
				} else {
					update_option( $option_key, $value );
				}
			}

			if ( 'faster_checkout' === $goal_id ) {
				$this->remove_one_page_checkout_draft();
			}

			$completed_goals                     = isset( $onboarding_state['completed_goals'] ) ? $onboarding_state['completed_goals'] : array();
			$completed_goals                     = array_diff( $completed_goals, array( $goal_id ) );
			$onboarding_state['completed_goals'] = $completed_goals;

			unset( $onboarding_state['snapshots'][ $goal_id ] );

			update_option( $this->option_key, $onboarding_state );

			return array(
				'success' => true,
				'message' => __( 'Goal undone successfully!', 'woocommerce-jetpack' ),
			);
		}

		/**
		 * Get next steps for a goal.
		 *
		 * @param string $goal_id Goal ID.
		 *
		 * @return array
		 */
		private function get_goal_next_steps( $goal_id ) {
			$next_steps = array();

			switch ( $goal_id ) {
				case 'grow_sales':
					$next_steps = array(
						__( 'Create your first frequently bought together bundle.', 'woocommerce-jetpack' ),
						__( 'Customize sales notification appearance and timing.', 'woocommerce-jetpack' ),
						__( 'Place a test order to verify the flow.', 'woocommerce-jetpack' ),
					);
					break;

				case 'faster_checkout':
					$next_steps = array(
						__( 'Publish your quick checkout draft page.', 'woocommerce-jetpack' ),
						__( 'Test checkout flow with a sample order.', 'woocommerce-jetpack' ),
						__( 'Tune one-page checkout placement if needed.', 'woocommerce-jetpack' ),
					);
					break;

				case 'work_smarter':
					$next_steps = array(
						__( 'Set your preferred order number pattern.', 'woocommerce-jetpack' ),
						__( 'Verify custom order numbers in admin orders list.', 'woocommerce-jetpack' ),
						__( 'Confirm order search works with custom numbers.', 'woocommerce-jetpack' ),
					);
					break;

				case 'go_global':
					$next_steps = array(
						__( 'Add additional currencies for your target markets.', 'woocommerce-jetpack' ),
						__( 'Review currency symbols and formatting.', 'woocommerce-jetpack' ),
						__( 'Check storefront display with a test product.', 'woocommerce-jetpack' ),
					);
					break;
			}

			return apply_filters( 'wcj_onboarding_goal_next_steps', $next_steps, $goal_id );
		}

		/**
		 * Remove one page checkout draft page
		 */
		private function remove_one_page_checkout_draft() {
			$query = new WP_Query(
				array(
					'post_type'      => 'page',
					'title'          => 'Quick Checkout (Draft)',
					'post_status'    => 'draft',
					'posts_per_page' => 1,
					'no_found_rows'  => true,
				)
			);

			if ( $query->have_posts() ) {
				wp_delete_post( $query->posts[0]->ID, true );
			}
		}

		/**
		 * Store onboarding analytics events locally for product analysis.
		 *
		 * @param string $event_type Event type.
		 * @param string $goal_id    Related goal ID.
		 * @param array  $metadata   Optional event metadata.
		 *
		 * @return void
		 */
		private function log_analytics_event( $event_type, $goal_id = '', $metadata = array() ) {
			$analytics = get_option( 'booster_plus_onboarding_analytics', array() );

			$event = array(
				'type'      => $event_type,
				'goal_id'   => $goal_id,
				'metadata'  => $metadata,
				'timestamp' => current_time( 'c' ),
			);

			$analytics[] = $event;
			if ( count( $analytics ) > 100 ) {
				$analytics = array_slice( $analytics, -100 );
			}

			update_option( 'booster_plus_onboarding_analytics', $analytics );
		}

		/**
		 * Sanitize onboarding event payload recursively.
		 *
		 * @param mixed $data Event payload.
		 *
		 * @return mixed
		 */
		private function sanitize_event_data( $data ) {
			if ( is_array( $data ) ) {
				$sanitized = array();
				foreach ( $data as $key => $value ) {
					$sanitized_key               = is_string( $key ) ? sanitize_key( $key ) : $key;
					$sanitized[ $sanitized_key ] = $this->sanitize_event_data( $value );
				}
				return $sanitized;
			}

			if ( is_bool( $data ) || is_int( $data ) || is_float( $data ) || null === $data ) {
				return $data;
			}

			return sanitize_text_field( (string) $data );
		}

		/**
		 * AJAX handler: log onboarding event from UI interactions.
		 *
		 * @return void
		 */
		public function ajax_log_onboarding_event() {
			check_ajax_referer( 'booster_onboarding_nonce', 'nonce' );

			// phpcs:ignore WordPress.WP.Capabilities.Unknown
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_die( esc_html__( 'Insufficient permissions.', 'woocommerce-jetpack' ) );
			}

			$event_type = isset( $_POST['event_type'] ) ? sanitize_key( wp_unslash( $_POST['event_type'] ) ) : '';
			$event_data = isset( $_POST['event_data'] ) ? $this->sanitize_event_data( map_deep( wp_unslash( $_POST['event_data'] ), 'sanitize_text_field' ) ) : array();

			if ( '' === $event_type ) {
				wp_send_json_error( array( 'message' => __( 'Invalid event type.', 'woocommerce-jetpack' ) ) );
			}

			$goal_id = '';
			if ( is_array( $event_data ) && isset( $event_data['goal_id'] ) ) {
				$goal_id = sanitize_text_field( (string) $event_data['goal_id'] );
			}

			$this->log_analytics_event( $event_type, $goal_id, is_array( $event_data ) ? $event_data : array( 'value' => $event_data ) );
			wp_send_json_success( array( 'logged' => true ) );
		}

		/**
		 * Check if first win condition is met
		 *
		 * @param string $goal_id The goal ID to check.
		 *
		 * @return bool True if the first win condition is met, false otherwise.
		 */
		public function check_first_win( $goal_id ) {
			if ( in_array( $goal_id, array( 'professional_invoices', 'professional_docs_pro' ), true ) ) {
				return $this->invoice_setup->is_active();
			}
			if ( ! isset( $this->onboarding_map[ $goal_id ] ) ) {
				return false;
			}

			$goal  = $this->onboarding_map[ $goal_id ];
			$check = $goal['first_win_check'];

			switch ( $check ) {
				case 'sales_notifications_enabled':
					return 'yes' === get_option( 'wcj_sales_notifications_enabled', 'no' );

				case 'frequently_bought_together_enabled':
					return 'yes' === get_option( 'wcj_frequently_bought_together_enabled', 'no' );

				case 'one_page_checkout_draft_page_exists':
					$query = new WP_Query(
						array(
							'post_type'      => 'page',
							'title'          => 'Quick Checkout (Draft)',
							'post_status'    => 'draft',
							'posts_per_page' => 1,
							'no_found_rows'  => true,
						)
					);
					return $query->have_posts();

				case 'reviews_enabled':
					return 'yes' === get_option( 'wcj_reviews_enabled', 'no' );

				case 'order_numbers_enabled':
					return 'yes' === get_option( 'wcj_order_numbers_enabled', 'no' );

				case 'extra_currency_added':
					$current_currency = get_woocommerce_currency();
					return ( 'EUR' !== $current_currency && get_option( 'wcj_currency_EUR' ) ) ||
							( 'USD' !== $current_currency && get_option( 'wcj_currency_USD' ) );

				default:
					return false;
			}
		}
	}

endif;
