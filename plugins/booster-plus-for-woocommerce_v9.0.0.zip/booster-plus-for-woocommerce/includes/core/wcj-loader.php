<?php
/**
 * Booster for WooCommerce - Core - Loader
 *
 * @version 7.2.7
 * @since  1.0.0
 * @author  Pluggabl LLC.
 * @package Booster_Plus_For_WooCommerce/core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Debug Mode.
if ( 'yes' === wcj_get_option( 'wcj_debug_tools_enabled', 'no' ) && 'yes' === wcj_get_option( 'wcj_debuging_enabled', 'no' ) ) {
	error_reporting( E_ALL ); // phpcs:ignore WordPress.PHP
}

if ( ! defined( 'WCJ_PLUGIN_PATH' ) ) {
	/**
	 * WCJ_PLUGIN_PATH.
	 *
	 * @version 6.0.0
	 * @since  1.0.2
	 */
	define( 'WCJ_PLUGIN_PATH', untrailingslashit( realpath( plugin_dir_path( WCJ_PLUGIN_FILE ) ) ) );
}

// Set up localisation using WordPress catalog precedence and locale switching.
require_once 'class-wcj-localization.php';
new WCJ_Localization( WCJ_PLUGIN_FILE );

// Include required core files used in admin and on the frontend.

// Constants.
require_once 'wcj-constants.php';

// Functions.
require_once 'wcj-functions.php';

// Classes.
require_once WCJ_PLUGIN_PATH . '/includes/classes/class-wcj-module.php';
require_once WCJ_PLUGIN_PATH . '/includes/classes/class-wcj-module-product-by-condition.php';
require_once WCJ_PLUGIN_PATH . '/includes/classes/class-wcj-module-shipping-by-condition.php';
require_once WCJ_PLUGIN_PATH . '/includes/classes/class-wcj-invoice.php';
require_once WCJ_PLUGIN_PATH . '/includes/classes/class-wcj-pdf-invoice.php';
require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-product-variation-swatches-term-meta.php';

// Mini Plugin.
require_once WCJ_PLUGIN_PATH . '/includes/mini-plugin/wcj-mini-plugin.php';

// Plus.
if ( 'booster-plus-for-woocommerce.php' === basename( WCJ_PLUGIN_FILE ) && apply_filters( 'wcj_full_pack', true ) ) {
	require_once WCJ_PLUGIN_PATH . '/includes/plus/class-wcj-plus.php';
}

// Tools.
require_once WCJ_PLUGIN_PATH . '/includes/admin/class-wcj-tools.php';

// Compatibility Status.
// Shared fee and payment diagnostics bind wcj_loaded now, before either module path.
require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-rule-explanations.php';

// Shared Returns summary definitions do not construct or read the queue.
require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-returns-summary.php';

if ( is_admin() ) {
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-status-service.php';
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-order-health-service.php';
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-order-health-admin.php';
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-rule-explanations-admin.php';
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-returns-summary-admin.php';
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-compatibility-status.php';
}

// WordPress 6.9+ Abilities API. Older WordPress versions do not load these frontend classes.
if ( isset( $GLOBALS['wp_version'] ) && version_compare( $GLOBALS['wp_version'], '6.9', '>=' ) && function_exists( 'wp_register_ability' ) ) {
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-status-service.php';
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-order-health-service.php';
	require_once WCJ_PLUGIN_PATH . '/includes/class-wcj-abilities.php';
}

// Shortcodes.
require_once 'wcj-shortcodes.php';

// Widgets.
require_once WCJ_PLUGIN_PATH . '/includes/classes/class-wcj-widget.php';
require_once WCJ_PLUGIN_PATH . '/includes/widgets/class-wcj-widget-multicurrency.php';
require_once WCJ_PLUGIN_PATH . '/includes/widgets/class-wcj-widget-country-switcher.php';
require_once WCJ_PLUGIN_PATH . '/includes/widgets/class-wcj-widget-left-to-free-shipping.php';
require_once WCJ_PLUGIN_PATH . '/includes/widgets/class-wcj-widget-selector.php';

// Scripts.
require_once 'class-wcj-scripts.php';

// Modules and Submodules.
if ( 'no' === wcj_get_option( 'wcj_load_modules_on_init', 'no' ) ) {
	require_once 'wcj-modules.php';

	// Add and Manage options.
	require_once 'wcj-options.php';

	// Admin.
	require_once 'class-wcj-admin.php';

	// Settings manager.
	require_once WCJ_PLUGIN_PATH . '/includes/admin/class-wcj-settings-manager.php';

	// Loaded action.
	do_action( 'wcj_loaded' );
} else {
	add_action(
		'plugins_loaded',
		function () {
			require_once 'wcj-modules.php';

			// Add and Manage options.
			require_once 'wcj-options.php';

			// Admin.
			require_once 'class-wcj-admin.php';

			// Settings manager.
			require_once WCJ_PLUGIN_PATH . '/includes/admin/class-wcj-settings-manager.php';

			// Loaded action.
			do_action( 'wcj_loaded' );
		},
		20
	);
}
