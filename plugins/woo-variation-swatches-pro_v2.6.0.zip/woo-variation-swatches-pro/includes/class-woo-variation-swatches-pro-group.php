<?php

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woo_Variation_Swatches_Pro_Group' ) ) {

	class Woo_Variation_Swatches_Pro_Group {

		protected function __construct() {

		}

		public static function instance(): Woo_Variation_Swatches_Pro_Group {
			static $instance;
			if ( null === $instance ) {
				$instance = new self();
			}

			return $instance;
		}

		public function get_id(): string {
			return 'woo_variation_swatches_groups';
		}

		public function delete_all(): bool {
			return delete_option( $this->get_id() );
		}

		public function get_all(): array {
			return (array) get_option( $this->get_id(), array() );
		}

		public function save_all( $data ): bool {
			return update_option( $this->get_id(), $data, false );
		}

		public function get( $slug ) {
			$available_data = (array) get_option( $this->get_id(), array() );
			if ( array_key_exists( $slug, $available_data ) ) {
				return $available_data[ $slug ];
			} else {
				return false;
			}
		}

		public function save( $slug, $new_data ): bool {
			$available_data = (array) get_option( $this->get_id(), array() );

			if ( array_key_exists( $slug, $available_data ) ) {
				return false;
			}

			$data = array_merge( $available_data, $new_data );

			return update_option( $this->get_id(), $data );

		}

		public function update( $slug, $name ): bool {
			$data = (array) get_option( $this->get_id(), array() );

			if ( array_key_exists( $slug, $data ) ) {
				$data[ $slug ] = $name;

				return update_option( $this->get_id(), $data );
			} else {
				return false;
			}
		}

		public function delete( $slug ): bool {

			$available_data = (array) get_option( $this->get_id(), array() );

			if ( array_key_exists( $slug, $available_data ) ) {

				unset( $available_data[ $slug ] );

				return update_option( $this->get_id(), $available_data );
			} else {
				return false;
			}
		}
	}
}
