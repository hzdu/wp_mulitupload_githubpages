<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woo_Variation_Swatches_Pro_Blocks' ) ) {
	class Woo_Variation_Swatches_Pro_Blocks extends Woo_Variation_Swatches_Blocks {

		protected static $instance = null;

		protected function __construct() {
			parent::__construct();
		}

		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		protected function hooks() {
			parent::hooks();
			add_action( 'init', array( $this, 'register_blocks' ) );
			add_action( 'init', array( $this, 'register_script_modules' ) );
			add_filter( 'post_class', array( $this, 'post_class_for_block' ), 20, 3 );
			add_filter( 'render_block_woocommerce/product-button', array(
				$this,
				'render_woocommerce_product_button_block'
			), 10, 3 );
			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
			add_filter( 'block_categories_all', array( $this, 'add_block_category' ), 10, 2 );
		}

		public function add_block_category( $block_categories, $block_editor_context ) {

			$category = array(
				'slug'  => 'getwooplugins',
				'title' => esc_html__( 'GetWooPlugins', 'woo-variation-swatches-pro' ),
				'icon'  => null,
			);

			array_push( $block_categories, $category );

			return $block_categories;
		}

		public function frontend_scripts() {

			$js_file_url = woo_variation_swatches_pro()->pro_build_url() . '/attribute-filter.js';
			$asset_file  = woo_variation_swatches_pro()->pro_build_path() . '/attribute-filter.asset.php';
			$asset       = include $asset_file;

			$filter_query_var_prefix     = defined( '\Automattic\WooCommerce\Blocks\BlockTypes\AttributeFilter::FILTER_QUERY_VAR_PREFIX' ) ? \Automattic\WooCommerce\Blocks\BlockTypes\AttributeFilter::FILTER_QUERY_VAR_PREFIX : 'filter_';
			$query_type_query_var_prefix = defined( '\Automattic\WooCommerce\Blocks\BlockTypes\AttributeFilter::QUERY_TYPE_QUERY_VAR_PREFIX' ) ? \Automattic\WooCommerce\Blocks\BlockTypes\AttributeFilter::QUERY_TYPE_QUERY_VAR_PREFIX : 'query_type_';

			wp_register_script( 'woo-variation-swatches-attribute-filter', $js_file_url, $asset['dependencies'], woo_variation_swatches()->pro_version(), true );
			wp_localize_script( 'woo-variation-swatches-attribute-filter', 'attribute_filter_block_data', array(
				'filter'     => $filter_query_var_prefix,
				'query_type' => $query_type_query_var_prefix
			) );
		}

		public function post_class_for_block( $classes, $css_class = '', $post_id = 0 ) {

			if ( ! $post_id || ! in_array( get_post_type( $post_id ), array(
					'product',
					'product_variation'
				), true ) ) {
				return $classes;
			}

			$product = wc_get_product( $post_id );

			if ( ! $product ) {
				return $classes;
			}

			// @TODO: Variable / Variation

			if ( $product->is_type( 'variable' ) ) {
				$loop_name = wc_get_loop_prop( 'name' );

				//if ( is_archive() || ! empty( $loop_name ) ) {
				$classes[] = 'wvs-archive-product-wrapper';
				//}
			}

			return $classes;
		}

		public function register_blocks() {
			register_block_type( woo_variation_swatches_pro()->pro_build_path() . '/variation-swatches' );
			register_block_type( woo_variation_swatches_pro()->pro_build_path() . '/attribute-filter' );
		}

		/**
		 * Interactivity API store for variable product "woocommerce/product-button" block.
		 */
		public function register_script_modules() {
			wp_register_script_module(
				'woo-variation-swatches-pro/product-button',
				woo_variation_swatches_pro()->pro_assets_url( '/js/product-button-view.js' ),
				array(
					'@wordpress/interactivity',
					array(
						'id'     => '@woocommerce/stores/woocommerce/cart',
						'import' => 'dynamic',
					),
				),
				woo_variation_swatches_pro()->pro_version()
			);
		}

		public function render_woocommerce_product_button_block( $block_content, $block, $WP_Block ) {

			$context = $WP_Block->context;

			$post_id = absint( $context['postId'] );

			$product = wc_get_product( $post_id );

			if ( ! $product ) {
				return $block_content;
			}

			if ( ! $product->is_type( 'variable' ) ) {
				return $block_content;
			}

			if ( $this->is_interactive_product_button() ) {
				return $this->get_interactive_product_button( $block_content, $product );
			}

			$processor = new WP_HTML_Tag_Processor( $block_content );
			$processor->remove_attribute( 'data-wc-interactive' );
			$processor->remove_attribute( 'data-wp-on--click' );

			return $block_content;
		}

		/**
		 * Variable product button can add to cart with Interactivity API, like simple product.
		 *
		 * @return bool
		 */
		public function is_interactive_product_button(): bool {
			$is_interactive = 'yes' === get_option( 'woocommerce_enable_ajax_add_to_cart' )
				&& 'yes' !== get_option( 'woocommerce_cart_redirect_after_add' )
				&& ! wc_string_to_bool( woo_variation_swatches()->get_option( 'enable_catalog_mode', 'no' ) );


			return apply_filters( 'woo_variation_swatches_interactive_product_button', $is_interactive);
		}

		/**
		 * Add Interactivity API directives to variable product "woocommerce/product-button" block.
		 * Selected variation comes from jQuery swatches via "wvs_variation_change" event.
		 *
		 * @param string     $block_content Block content.
		 * @param WC_Product $product       Variable product.
		 *
		 * @return string
		 */
		public function get_interactive_product_button( string $block_content, WC_Product $product ): string {

			$processor = new WP_HTML_Tag_Processor( $block_content );

			// Wrapper div.
			if ( ! $processor->next_tag() ) {
				return $block_content;
			}

			$processor->remove_attribute( 'data-wc-interactive' );
			$processor->set_attribute( 'data-wp-interactive', 'woo-variation-swatches-pro/product-button' );
			$processor->set_attribute( 'data-wp-context', wp_json_encode( array(
				'variationId'            => 0,
				'variation'              => array(),
				'quantityToAdd'          => 1,
				'addToCartText'          => $product->add_to_cart_text(),
				'variationAddToCartText' => '',
				/* translators: %s: product number. */
				'inTheCartText'          => sprintf( __( '%s in cart', 'woo-variation-swatches-pro' ), '###' ),
				'isLoading'              => false,
				'displayViewCart'        => false,
				// Quantity showing on button, synced with cart quantity after slide animation.
				'tempQuantity'           => 0,
				'animationStatus'        => 'IDLE',
			) ) );

			// Button, "wvs-add-to-cart-button" class added by "woocommerce_loop_add_to_cart_args" filter.
			if ( ! $processor->next_tag( array( 'class_name' => 'wvs-add-to-cart-button' ) ) ) {
				return $block_content;
			}

			$processor->set_attribute( 'data-wvs-interactive', 'yes' );
			$processor->set_attribute( 'data-wp-init', 'callbacks.init' );
			$processor->set_attribute( 'data-wp-on--click', 'actions.addToCart' );
			$processor->set_attribute( 'data-wp-on--wvs_variation_change', 'actions.syncVariation' );
			$processor->set_attribute( 'data-wp-class--loading', 'context.isLoading' );
			$processor->set_attribute( 'data-wp-class--added', 'state.isAdded' );

			wp_enqueue_script_module( 'woo-variation-swatches-pro/product-button' );

			// Server side render, no variation selected yet.
			wp_interactivity_state( 'woo-variation-swatches-pro/product-button', array(
				'buttonText'      => function () {
					$context = wp_interactivity_get_context();

					return $context['addToCartText'];
				},
				'isAdded'           => false,
				'displayViewCart'   => false,
				'slideOutAnimation' => false,
				'slideInAnimation'  => false,
			) );

			// Same slide animation as WooCommerce "woocommerce/product-button" block, styles comes from that block.
			$text_html = '<span
				data-wp-text="state.buttonText"
				data-wp-class--wc-block-slide-out="state.slideOutAnimation"
				data-wp-class--wc-block-slide-in="state.slideInAnimation"
				data-wp-on--animationend="actions.handleAnimationEnd"
				data-wp-watch="callbacks.startAnimation"
			>%s</span>';

			$view_cart_html = sprintf( '<span hidden data-wp-bind--hidden="!state.displayViewCart"><a href="%1$s" class="added_to_cart wc_forward" title="%2$s">%2$s</a></span>', esc_url( wc_get_cart_url() ), esc_html__( 'View cart', 'woo-variation-swatches-pro' ) );

			// Wrap button text with span for animation and add view cart link after button.
			return preg_replace_callback( '/(<a\b[^>]*\bdata-wvs-interactive="yes"[^>]*>)(.*?)(<\/a>)/s', static function ( $matches ) use ( $text_html, $view_cart_html ) {
				return $matches[1] . sprintf( $text_html, trim( $matches[2] ) ) . $matches[3] . $view_cart_html;
			}, $processor->get_updated_html() );
		}
	}
}
