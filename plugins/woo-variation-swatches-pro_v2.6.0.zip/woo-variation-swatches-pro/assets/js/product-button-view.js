// ================================================================
// WooCommerce Variation Swatches - Pro
// Interactivity API store for variable product "woocommerce/product-button" block.
// ================================================================

import { store, getContext, getElement, withSyncEvent, withScope } from '@wordpress/interactivity'

// Same lock as WooCommerce "woocommerce/product-button" block uses.
const LOCK = 'I acknowledge that using a private store means my plugin will inevitably break on the next store release.'

// Shared WooCommerce cart state. Mini-Cart / Cart blocks update it, so counts update automatically.
const { state: wooState } = store('woocommerce', {}, { lock: LOCK })

// Same as WooCommerce "woocommerce/product-button" block.
const ANIMATION = {
	IDLE: 'IDLE',
	SLIDE_OUT: 'SLIDE-OUT',
	SLIDE_IN: 'SLIDE-IN',
}

const { state, actions } = store('woo-variation-swatches-pro/product-button', {
	state: {
		get quantity () {
			const { variationId } = getContext()

			if (!variationId) {
				return 0
			}

			// Same as WC()->cart->get_cart_item_quantities(), "any" attribute variations can have many lines.
			return (wooState.cart?.items || [])
				.filter((item) => item.id === variationId)
				.reduce((total, item) => total + item.quantity, 0)
		},

		get buttonText () {
			const context = getContext()

			if (!context.variationId) {
				return context.addToCartText
			}

			// Keep old quantity until slide out finished, then show new quantity with slide in.
			const quantity = context.animationStatus === ANIMATION.SLIDE_IN ? state.quantity : context.tempQuantity

			return quantity > 0 ? context.inTheCartText.replace('###', quantity) : context.variationAddToCartText
		},

		get slideOutAnimation () {
			return getContext().animationStatus === ANIMATION.SLIDE_OUT
		},

		get slideInAnimation () {
			return getContext().animationStatus === ANIMATION.SLIDE_IN
		},

		get isAdded () {
			return state.quantity > 0
		},

		get displayViewCart () {
			return getContext().displayViewCart && state.quantity > 0
		},
	},

	actions: {
		// jQuery swatches set "data-wvs-variation" and dispatch "wvs_variation_change".
		syncVariation () {
			const context = getContext()
			const { ref } = getElement()

			let variation = null

			try {
				variation = JSON.parse(ref.dataset.wvsVariation || 'null')
			} catch (e) {
				variation = null
			}

			context.variationId = variation ? parseInt(variation.variation_id, 10) : 0
			context.variationAddToCartText = variation ? variation.add_to_cart_text : ''
			// Store API format: [{ attribute: 'pa_color', value: 'blue' }]
			context.variation = variation ? Object.entries(variation.attributes || {}).map(([name, value]) => ({
				attribute: name.replace(/^attribute_/, ''),
				value,
			})) : []
			context.displayViewCart = false

			// No animation when variation changes.
			context.tempQuantity = state.quantity
			context.animationStatus = ANIMATION.IDLE
		},

		handleAnimationEnd (event) {
			const context = getContext()

			if ('slideOut' === event.animationName) {
				context.animationStatus = ANIMATION.SLIDE_IN
			}

			if ('slideIn' === event.animationName) {
				context.tempQuantity = state.quantity
				context.animationStatus = ANIMATION.IDLE
			}
		},

		addToCart: withSyncEvent(function* (event) {
			const context = getContext()

			// No variation selected, let the link open product page.
			if (!context.variationId) {
				return
			}

			event.preventDefault()

			if (context.isLoading) {
				return
			}

			context.isLoading = true

			try {
				yield import('@woocommerce/stores/woocommerce/cart')

				const { actions: wooActions } = store('woocommerce', {}, { lock: LOCK })

				yield wooActions.addCartItem({
					id: context.variationId,
					quantityToAdd: context.quantityToAdd,
					variation: context.variation,
				}, { showCartUpdatesNotices: false })

				context.displayViewCart = true
			} finally {
				context.isLoading = false
			}
		}),
	},

	callbacks: {
		// Variation may be selected before hydration. Ex: default attributes.
		init () {
			const { ref } = getElement()

			if (ref.dataset.wvsVariation) {
				actions.syncVariation()
			}
		},

		// Runs when cart quantity changes. Ex: add to cart click, Mini-Cart update.
		startAnimation () {
			const context = getContext()

			if (context.animationStatus !== ANIMATION.IDLE || context.tempQuantity === state.quantity) {
				return
			}

			context.animationStatus = ANIMATION.SLIDE_OUT

			// If animation styles not available, "animationend" never fires.
			setTimeout(withScope(() => {
				if (context.animationStatus !== ANIMATION.IDLE) {
					context.tempQuantity = state.quantity
					context.animationStatus = ANIMATION.IDLE
				}
			}), 1000)
		},
	},
})
