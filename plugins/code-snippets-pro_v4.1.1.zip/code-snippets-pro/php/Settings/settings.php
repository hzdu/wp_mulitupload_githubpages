<?php
/**
 * This file registers the settings.
 *
 * @package Code_Snippets
 */

namespace Code_Snippets\Settings;

use Code_Snippets\Client\Docs_Client;
use Code_Snippets\Client\Welcome_Client;
use Code_Snippets\Controller\Cloud_Search_Controller;
use Code_Snippets\Controller\Cloud_Library_Controller;
use Code_Snippets\Search\Search_Index;
use Code_Snippets\Search\Universal_Search;
use function add_action;
use function Code_Snippets\clean_snippets_cache;
use function Code_Snippets\flush_versioned_cache_groups;
use function Code_Snippets\code_snippets;
use function Code_Snippets\Utils\add_self_option;
use function Code_Snippets\Utils\get_self_option;
use function Code_Snippets\Utils\update_self_option;
use const Code_Snippets\CACHE_GROUP;

const CACHE_KEY = 'code_snippets_settings';
const OPTION_GROUP = 'code-snippets';
const OPTION_NAME = 'code_snippets_settings';

/**
 * Returns 'true' if plugin settings are unified on a multisite installation
 * under the Network Admin settings menu
 *
 * This option is controlled by the "Enable administration menus" setting on the Network Settings menu
 *
 * @return bool
 */
function are_settings_unified(): bool {
	if ( ! is_multisite() ) {
		return false;
	}

	$menu_perms = get_site_option( 'menu_items', [] );
	return empty( $menu_perms['snippets_settings'] );
}

/**
 * Retrieve the setting values from the database.
 *
 * If a setting does not exist in the database, the default value will be returned.
 *
 * @return array<string, array<string, mixed>>
 */
function get_settings_values(): array {
	$settings = wp_cache_get( CACHE_KEY, CACHE_GROUP );
	if ( $settings ) {
		return $settings;
	}

	$settings = Settings_Fields::get_default_values();
	$saved = get_self_option( are_settings_unified(), OPTION_NAME, [] );

	// Deep merge the saved settings with the default values.
	foreach ( $settings as $section => $section_fields ) {
		if ( isset( $saved[ $section ] ) ) {
			$settings[ $section ] = array_replace( $section_fields, $saved[ $section ] );
		}
	}

	wp_cache_set( CACHE_KEY, $settings, CACHE_GROUP );
	return $settings;
}

/**
 * Retrieve an individual setting field value
 *
 * @param string $section ID of the section the setting belongs to.
 * @param string $field   ID of the setting field.
 *
 * @return mixed
 */
function get_setting( string $section, string $field ) {
	$settings = get_settings_values();

	return $settings[ $section ][ $field ] ?? null;
}

/**
 * Update a single setting to a new value.
 *
 * @param string $section   ID of the section the setting belongs to.
 * @param string $field     ID of the setting field.
 * @param mixed  $new_value Setting value. Expected to not be SQL-escaped.
 *
 * @return bool False if value was not updated. True if value was updated.
 */
function update_setting( string $section, string $field, $new_value ): bool {
	$settings = get_settings_values();

	$settings[ $section ][ $field ] = $new_value;

	wp_cache_set( CACHE_KEY, $settings, CACHE_GROUP );
	return update_self_option( are_settings_unified(), OPTION_NAME, $settings );
}

/**
 * Render the fields of a settings section, with group headings.
 *
 * Mirrors the core `do_settings_fields()`, adding a full-width heading row
 * above any field carrying a `group_heading` argument. Tabs are long enough
 * that unbroken rows are hard to scan.
 *
 * @param string $page    Settings page slug.
 * @param string $section Settings section identifier.
 *
 * @return void
 */
function do_settings_fields_with_headings( string $page, string $section ): void {
	global $wp_settings_fields;

	if ( ! isset( $wp_settings_fields[ $page ][ $section ] ) ) {
		return;
	}

	$seen_headings = [];

	foreach ( (array) $wp_settings_fields[ $page ][ $section ] as $field ) {
		$heading = $field['args']['group_heading'] ?? '';

		// A heading is skipped if an identical one has already been drawn, so
		// that a group whose first field is absent does not repeat it.
		if ( $heading && ! in_array( $heading, $seen_headings, true ) ) {
			$seen_headings[] = $heading;
			printf(
				'<tr class="settings-group-heading"><th colspan="2" scope="colgroup">%s</th></tr>',
				esc_html( $heading )
			);
		}

		$class = empty( $field['args']['class'] ) ? '' : ' class="' . esc_attr( $field['args']['class'] ) . '"';
		$anchor = ' id="' . esc_attr( Search_Index::SETTING_ANCHOR_PREFIX . $field['id'] ) . '"';

		echo '<tr' . $anchor . $class . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.

		// A field with no title, such as a notice rendered by a callback, spans
		// the row rather than leaving an empty header cell for a screen reader.
		if ( '' === (string) $field['title'] ) {
			echo '<td colspan="2">';
			call_user_func( $field['callback'], $field['args'] );
			echo '</td></tr>';
			continue;
		}

		if ( ! empty( $field['args']['label_for'] ) ) {
			printf(
				'<th scope="row"><label for="%s">%s</label></th>',
				esc_attr( $field['args']['label_for'] ),
				esc_html( $field['title'] )
			);
		} else {
			printf( '<th scope="row">%s</th>', esc_html( $field['title'] ) );
		}

		echo '<td>';
		call_user_func( $field['callback'], $field['args'] );
		echo '</td></tr>';
	}
}

/**
 * Retrieve the settings sections
 *
 * @return array<string, string> Settings sections.
 */
function get_settings_sections(): array {
	// Tabs are grouped by task rather than by storage section. Values still
	// save into their original sections; see Settings_Layout.
	$sections = Settings_Layout::get_available_tabs();

	return apply_filters( 'code_snippets_settings_sections', $sections );
}

/**
 * Register settings sections, fields, etc
 */
function register_plugin_settings() {
	if ( ! get_self_option( are_settings_unified(), OPTION_NAME ) ) {
		add_self_option( are_settings_unified(), OPTION_NAME, Settings_Fields::get_default_values() );
	}

	$current_settings = get_settings_values();

	// Register the setting.
	register_setting(
		OPTION_GROUP,
		OPTION_NAME,
		[ 'sanitize_callback' => __NAMESPACE__ . '\\sanitize_settings' ]
	);

	// Register settings sections.
	foreach ( get_settings_sections() as $section_id => $section_name ) {
		add_settings_section( $section_id, $section_name, '__return_empty_string', 'code-snippets' );
	}

	// Register settings fields. The tab a field appears under comes from the
	// layout, while the section it saves into stays exactly as it was.
	$definitions = Settings_Fields::get_field_definitions();
	$headings = Settings_Layout::get_group_headings();

	foreach ( get_settings_sections() as $tab_id => $tab_name ) {
		foreach ( Settings_Layout::get_visible_fields( $tab_id, $current_settings ) as $entry ) {
			list( $section_id, $field_id ) = $entry;
			$field = Settings_Layout::apply_description( $definitions[ $section_id ][ $field_id ], $field_id );

			$field_object = new Setting_Field( $section_id, $field_id, $field );

			// Field types that render a single labelable control get their table
			// heading turned into a real <label for>, giving the control an
			// accessible name. Checkboxes render their own labels, and
			// callback/action fields have no single control to point at.
			$labelable_types = [ 'text', 'number', 'select' ];
			$field_args = [];

			if ( isset( $field['type'] ) && in_array( $field['type'], $labelable_types, true ) ) {
				$field_args['label_for'] = $field_object->element_id;
			}

			if ( isset( $headings[ $tab_id ][ $field_id ] ) ) {
				$field_args['group_heading'] = $headings[ $tab_id ][ $field_id ];
			}

			add_settings_field(
				$field_id,
				$field['name'],
				[ $field_object, 'render' ],
				'code-snippets',
				$tab_id,
				$field_args
			);
		}
	}

	$editor_preview = new Editor_Preview();

	// Add editor preview as a field.
	add_settings_field(
		'editor_preview',
		__( 'Editor Preview', 'code-snippets' ),
		[ $editor_preview, 'render' ],
		'code-snippets',
		'editing'
	);

	Version_Switch::init();
}

add_action( 'admin_init', __NAMESPACE__ . '\\register_plugin_settings' );

/**
 * Clear the cached settings once new values are written.
 *
 * Saving runs the values through sanitize_settings(), which caches the
 * previous values before the option is updated.
 *
 * @return void
 */
function clear_settings_cache() {
	wp_cache_delete( CACHE_KEY, CACHE_GROUP );
}

add_action( 'add_option_' . OPTION_NAME, __NAMESPACE__ . '\\clear_settings_cache' );
add_action( 'update_option_' . OPTION_NAME, __NAMESPACE__ . '\\clear_settings_cache' );
add_action( 'add_site_option_' . OPTION_NAME, __NAMESPACE__ . '\\clear_settings_cache' );
add_action( 'update_site_option_' . OPTION_NAME, __NAMESPACE__ . '\\clear_settings_cache' );

/**
 * Determine whether a setting field should be rendered.
 *
 * @param array<string, mixed>                    $field    Field definition.
 * @param array<string, array<string,mixed>>      $settings Current settings values.
 * @param array<string, array<string,mixed>>|null $input    Optional raw input values.
 *
 * @return bool
 */
function should_render_setting_field( array $field, array $settings, ?array $input = null ): bool {
	if ( empty( $field['show_if'] ) || ! is_array( $field['show_if'] ) ) {
		return true;
	}

	$show_if = array_merge(
		[
			'section' => '',
			'field'   => '',
			'value'   => true,
		],
		$field['show_if']
	);

	$section = is_string( $show_if['section'] ) ? $show_if['section'] : '';
	$field_id = is_string( $show_if['field'] ) ? $show_if['field'] : '';
	$expected = $show_if['value'];

	if ( '' === $section || '' === $field_id ) {
		return true;
	}

	$actual = null;

	if ( is_array( $input ) && isset( $input[ $section ] ) && is_array( $input[ $section ] ) && array_key_exists( $field_id, $input[ $section ] ) ) {
		$actual = $input[ $section ][ $field_id ];
	} elseif ( isset( $settings[ $section ] ) && array_key_exists( $field_id, $settings[ $section ] ) ) {
		$actual = $settings[ $section ][ $field_id ];
	}

	if ( is_bool( $expected ) ) {
		if ( is_bool( $actual ) ) {
			return $actual === $expected;
		}

		return ( 'on' === $actual ) === $expected;
	}

	return $actual === $expected;
}

/**
 * Sanitize a single setting value.
 *
 * @param array<string, mixed> $field       Setting field information.
 * @param mixed                $input_value User input setting value, or null if missing.
 *
 * @return mixed Sanitized setting value, or null if unset.
 */
function sanitize_setting_value( array $field, $input_value ) {
	switch ( $field['type'] ) {

		case 'checkbox':
			return 'on' === $input_value;

		case 'number':
			return intval( $input_value );

		case 'select':
			$select_options = array_map( 'strval', array_keys( $field['options'] ) );
			return in_array( strval( $input_value ), $select_options, true ) ? $input_value : null;

		case 'checkboxes':
			$results = [];

			if ( ! empty( $input_value ) ) {
				foreach ( $field['options'] as $option_id => $option_label ) {
					if ( isset( $input_value[ $option_id ] ) && 'on' === $input_value[ $option_id ] ) {
						$results[] = $option_id;
					}
				}
			}

			return $results;

		case 'text':
		case 'hidden':
			return trim( sanitize_text_field( $input_value ) );

		case 'callback':
			return isset( $field['sanitize_callback'] ) && is_callable( $field['sanitize_callback'] ) ?
				call_user_func( $field['sanitize_callback'], $input_value ) :
				null;

		default:
			return null;
	}
}

/**
 * Process settings actions.
 *
 * @param array $input Provided settings input.
 *
 * @return array|null New $input value to return, or null to continue with settings update process.
 */
function process_settings_actions( array $input ): ?array {

	if ( isset( $input['reset_settings'] ) ) {
		add_settings_error(
			OPTION_NAME,
			'settings_reset',
			esc_html__( 'All settings have been reset to their defaults.', 'code-snippets' ),
			'updated'
		);

		delete_option( 'code_snippets_cloud_settings' );
		return [];
	}

	if ( isset( $input['debug']['database_update'] ) ) {
		if ( code_snippets()->db->create_or_upgrade_tables() ) {
			add_settings_error(
				OPTION_NAME,
				'database_update_done',
				esc_html__( 'Successfully performed database table upgrade.', 'code-snippets' ),
				'updated'
			);
		} else {
			global $wpdb;

			/* translators: %s: database error message */
			$error_text = __( 'The database table upgrade did not complete: %s', 'code-snippets' );

			add_settings_error(
				OPTION_NAME,
				'database_update_failed',
				esc_html( sprintf( $error_text, $wpdb->last_error ) ),
			);
		}
	} elseif ( isset( $input['general']['connect_cloud'] ) ) {
		code_snippets()->cloud_auth->init_cloud_connection();

	} elseif ( isset( $input['debug']['disconnect_cloud'] ) ) {
		code_snippets()->cloud_auth->reset_connection();

		add_settings_error(
			OPTION_NAME,
			'snippets_cloud_sync_disconnected',
			__( 'This site has been successfully disconnected from Code Snippets Cloud.', 'code-snippets' ),
			'updated'
		);
	}

	if ( isset( $input['debug']['reset_caches'] ) ) {
		Welcome_Client::clear_cache();
		Cloud_Search_Controller::clear_caches();
		Cloud_Library_Controller::clear_caches();
		Docs_Client::clear_cache();
		Universal_Search::clear_caches();
		clean_snippets_cache( code_snippets()->db->get_table_name( false ) );
		code_snippets()->evaluate_assets->increment_snippets_rev( false );

		if ( is_multisite() ) {
			clean_snippets_cache( code_snippets()->db->get_table_name( true ) );
			code_snippets()->evaluate_assets->increment_snippets_rev( true );
		}

		// Deleting known keys cannot reach data written by a different version
		// of the plugin, which is what needs clearing before a rollback, so the
		// versioned groups (current, previous and legacy) all go too.
		flush_versioned_cache_groups( (string) get_option( 'code_snippets_cache_version', '' ) );

		// Resetting caches before a rollback is also how an administrator checks
		// what the version source is serving now, so the versions are fetched again.
		$available_versions = Version_Switch::refresh_available_versions();
		$refresh_failure = Version_Switch::get_refresh_failure();

		if ( $refresh_failure ) {
			/* translators: %s: reason the plugin versions could not be listed. */
			$message = __( 'Successfully reset snippets caches, but the available plugin versions could not be listed: %s', 'code-snippets' );

			add_settings_error(
				OPTION_NAME,
				'snippet_caches_reset',
				esc_html( sprintf( $message, $refresh_failure ) ),
			);
		} else {
			/* translators: %d: number of plugin versions available to install. */
			$message = _n(
				'Successfully reset snippets caches. %d plugin version is available to install.',
				'Successfully reset snippets caches. %d plugin versions are available to install.',
				count( $available_versions ),
				'code-snippets'
			);

			add_settings_error(
				OPTION_NAME,
				'snippet_caches_reset',
				esc_html( sprintf( $message, count( $available_versions ) ) ),
				'updated'
			);
		}
	}

	return null;
}

/**
 * Validate the settings
 *
 * @param array<string, array<string, mixed>> $input The received settings.
 *
 * @return array<string, array<string, mixed>> The validated settings.
 */
function sanitize_settings( array $input ): array {
	wp_cache_delete( CACHE_KEY, CACHE_GROUP );
	$result = process_settings_actions( $input );

	if ( ! is_null( $result ) ) {
		return $result;
	}

	$settings = get_settings_values();
	$updated = false;

	// Don't directly loop through $input as it does not include as deselected checkboxes.
	foreach ( Settings_Fields::get_field_definitions() as $section_id => $fields ) {
		foreach ( $fields as $field_id => $field ) {
			if ( ! should_render_setting_field( $field, $settings, $input ) ) {
				continue;
			}

			// Fetch the corresponding input value from the posted data.
			$input_value = $input[ $section_id ][ $field_id ] ?? null;
			$stored_value = $settings[ $section_id ][ $field_id ] ?? null;

			// Attempt to sanitize the setting value.
			$sanitized_value = sanitize_setting_value( $field, $input_value );

			if ( ! is_null( $sanitized_value ) && $stored_value !== $sanitized_value ) {
				$settings[ $section_id ][ $field_id ] = $sanitized_value;
				$updated = true;
			}
		}
	}

	// Add an updated message.
	if ( $updated ) {
		add_settings_error(
			OPTION_NAME,
			'settings-saved',
			__( 'Settings saved.', 'code-snippets' ),
			'updated'
		);

		do_action( 'code_snippets/settings_updated', $settings, $input );
	}

	return $settings;
}
