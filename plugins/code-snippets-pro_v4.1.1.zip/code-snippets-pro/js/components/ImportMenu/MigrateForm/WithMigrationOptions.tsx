import React, { useCallback, useState } from 'react'
import { createContextHook } from '../../../utils/bootstrap'
import { fetchQueryParam, updateQueryParams } from '../../../utils/urls'
import type { PropsWithChildren } from 'react'

const IMPORTER_QUERY_PARAM = 'from'

export const sanitizeImporterName = (name: string): string =>
	name.toLowerCase().replace(/[^a-z0-9-]/g, '')

const fetchImporterFromQueryParam = () =>
	sanitizeImporterName(fetchQueryParam(IMPORTER_QUERY_PARAM) ?? '')

export interface MigrationOptionsContext {
	autoAddTags: boolean
	selectedImporter: string
	setAutoAddTags: (value: boolean) => void
	setSelectedImporter: (newImporter: string) => void
	setTagValue: (value: string) => void
	tagValue: string
}

const [Context, useMigrationOptions] = createContextHook<MigrationOptionsContext>('useMigrationOptions')

export const WithMigrationOptions: React.FC<PropsWithChildren> = ({ children }) => {
	const [selectedImporter, setSelectedImporterValue] = useState<string>(fetchImporterFromQueryParam)
	const [autoAddTags, setAutoAddTags] = useState(false)
	const [tagValue, setTagValue] = useState<string>(() => `imported-${selectedImporter}`)

	const setSelectedImporter = useCallback((newImporter: string) => {
		const importer = sanitizeImporterName(newImporter)
		updateQueryParams({ [IMPORTER_QUERY_PARAM]: importer })
		setTagValue(`imported-${importer}`)
		setSelectedImporterValue(importer)
	}, [])

	const value: MigrationOptionsContext = {
		autoAddTags,
		selectedImporter,
		setSelectedImporter,
		setAutoAddTags,
		setTagValue,
		tagValue
	}

	return <Context.Provider value={value}>{children}</Context.Provider>
}

export { useMigrationOptions }
