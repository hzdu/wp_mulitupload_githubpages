[![Coverage Status](https://coveralls.io/repos/github/Yoast/wpseo-video/badge.svg?branch=trunk&t=Vi74c9)](https://coveralls.io/github/Yoast/wpseo-video?branch=trunk)

Video SEO
=========
Requires at least: 6.9
Tested up to: 7.1
Stable tag: 13.9
Requires PHP: 7.4
Depends: Yoast SEO

Video SEO adds Video SEO capabilities to WordPress SEO.

Description
------------

This plugin adds Video XML Sitemaps as well as the necessary OpenGraph markup, Schema.org videoObject markup and mediaRSS for your videos.

This repository uses [the Yoast grunt tasks plugin](https://github.com/Yoast/plugin-grunt-tasks).

Installation
------------

1. Go to Plugins -> Add New.
2. Click "Upload" right underneath "Install Plugins".
3. Upload the zip file that this readme was contained in.
4. Activate the plugin.
5. Go to SEO -> Extensions and enter your license key.
6. Save settings, your license key will be validated. If all is well, you should now see the XML Video Sitemap settings.
7. Make sure to hit the "Re-index videos" button if you have videos in old posts.

Frequently Asked Questions
--------------------------

You can find the [Video SEO FAQ](https://yoast.com/help/video-seo-faq/) in our help center.

Changelog
=========

## 15.3

Release date: 2026-09-15

#### Bugfixes

* Fixes a bug where a crafted YouTube embed block ran JavaScript in the visitor's browser when the YouTube faster embed option was enabled.

#### Other

* Sets the minimum required Yoast SEO version to 28.5.
* Sets the minimum supported WordPress version to 6.9.
* Sets the _WordPress tested up to_ version to 7.1.

## 15.2

Release date: 2026-04-28

#### Other

* Modernizes how translations of the plugin work by removing the unneeded `load_plugin_textdomain()` calls.
* Sets the minimum supported WordPress version to 6.8.
* Sets the _WordPress tested up to_ version to 7.0.
* Updates the description copy of the XML Video Sitemap.

### Earlier versions
For the changelog of earlier versions, please refer to [the changelog on yoast.com](https://yoa.st/video-seo-changelog).
