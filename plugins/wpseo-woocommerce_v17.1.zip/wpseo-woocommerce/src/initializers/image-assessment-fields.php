<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.Files.FileName.InvalidClassFileName -- File name kept for historical reasons; class was renamed.

namespace Yoast\WP\SEO\WooCommerce\Initializers;

use WPSEO_Meta;
use Yoast\WP\SEO\Conditionals\No_Conditionals;
use Yoast\WP\SEO\Initializers\Initializer_Interface;
use Yoast\WP\SEO\Presenters\Admin\Meta_Fields_Presenter;

/**
 * Registers the per-product post meta fields that store image alt text assessment results.
 *
 * Each field stores a comma-separated list of attachment IDs flagged by that assessment
 * (e.g. "42,87,103"), or "" when no images were flagged. The bulk editor reads these to
 * filter products server-side: a non-empty value means at least one image needs work.
 *
 * Fields are never shown in the metabox UI. They are rendered as hidden inputs so that
 * WPSEO_Meta can persist them when the product form is saved. JavaScript populates the
 * inputs after the SEO analysis finishes in the product editor.
 */
class Image_Assessment_Fields implements Initializer_Interface {

	use No_Conditionals;

	/** The WPSEO_Meta group name for these fields. */
	private const GROUP = 'woo_image_alt_assessment';

	/**
	 * The field definitions keyed by field key, in the shape WPSEO_Meta expects.
	 *
	 * @var array<string, array<string, string>>
	 */
	private const FIELD_DEFS = [
		'alt_text_length'             => [
			'type'          => 'hidden',
			'default_value' => '',
		],
		'missing_alt_text'            => [
			'type'          => 'hidden',
			'default_value' => '',
		],
		'duplicate_alt_text'          => [
			'type'          => 'hidden',
			'default_value' => '',
		],
		'redundant_alt_text_phrase'   => [
			'type'          => 'hidden',
			'default_value' => '',
		],
		'non_descriptive_alt_text'    => [
			'type'          => 'hidden',
			'default_value' => '',
		],
		'keyphrase_stuffing_alt_text' => [
			'type'          => 'hidden',
			'default_value' => '',
		],
	];

	/**
	 * Hooks into WordPress to register and handle the image assessment meta fields.
	 *
	 * @return void
	 */
	public function initialize() {
		// add_extra_wpseo_meta_fields fires at plugins_loaded priority 14; this plugin
		// loads at priority 20, so the callback below is registered too late for that pass.
		// Instead we register the group via init, which fires after all plugins_loaded
		// callbacks and well before any admin page renders its metabox.
		\add_action( 'init', [ $this, 'register_wpseo_meta_fields' ] );

		\add_filter( 'add_extra_wpseo_meta_fields', [ self::class, 'register_image_assessment_meta_fields' ] );
		\add_action( 'save_post_product', [ $this, 'save_fields' ], 20, 1 );
		\add_filter( 'wpseo_content_meta_section_content', [ $this, 'add_hidden_inputs' ], 20, 1 );
	}

	/**
	 * Registers our field group directly in WPSEO_Meta::$meta_fields so that
	 * Meta_Fields_Presenter can find it via get_meta_field_defs().
	 *
	 * Called at init: initialize() runs at plugins_loaded priority 20 (before init),
	 * so add_action('init') queued here fires correctly. The group write is safe at
	 * this point because WPSEO_Meta::init() has already completed at priority 14.
	 *
	 * @return void
	 */
	public function register_wpseo_meta_fields(): void {
		WPSEO_Meta::$meta_fields[ self::GROUP ] = self::FIELD_DEFS;
	}

	/**
	 * Add the image assessment meta fields to the WPSEO_Meta::$meta_fields definitions.
	 *
	 * @param array<string, array<string, array<string, string>>> $fields Fields already in place.
	 *
	 * @return array<string, array<string, array<string, string>>>
	 */
	public static function register_image_assessment_meta_fields( $fields ) {
		return WPSEO_Meta::array_merge_recursive_distinct(
			$fields,
			[
				self::GROUP => self::FIELD_DEFS,
			],
		);
	}

	/**
	 * Appends hidden inputs for the image assessment fields to the Yoast SEO metabox.
	 *
	 * Only renders for products: the assessment flags are meaningless for other post types,
	 * and the JavaScript that populates them only runs on the WooCommerce product editor.
	 *
	 * @param string $content The metabox hidden-fields HTML accumulated so far.
	 *
	 * @return string The content with the image assessment inputs appended.
	 */
	public function add_hidden_inputs( string $content ): string {
		$post = \get_post();
		if ( ! $post || $post->post_type !== 'product' ) {
			return $content;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Meta_Fields_Presenter::present() is considered safe.
		$content .= new Meta_Fields_Presenter( $post, self::GROUP, 'product' );

		return $content;
	}

	/**
	 * Saves the image assessment fields when a product is saved.
	 *
	 * Runs after WPSEO_Metabox::save_postdata() (priority 20 vs its default priority),
	 * and only when the Yoast metabox nonce is present and valid, so REST / autosave
	 * requests that don't carry the form are silently skipped.
	 *
	 * @param int $post_id The post ID being saved.
	 *
	 * @return void
	 */
	public function save_fields( int $post_id ) {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Verified below.
		$nonce = \wp_unslash( ( $_POST['yoast_free_metabox_nonce'] ?? '' ) );
		if ( ! \wp_verify_nonce( $nonce, 'yoast_free_metabox' ) ) {
			return;
		}

		foreach ( \array_keys( self::FIELD_DEFS ) as $key ) {
			$field_name = WPSEO_Meta::$form_prefix . $key;
			if ( ! isset( $_POST[ $field_name ] ) ) {
				continue;
			}

			\update_post_meta(
				$post_id,
				WPSEO_Meta::$meta_prefix . $key,
				\sanitize_text_field( \wp_unslash( $_POST[ $field_name ] ) ),
			);
		}
	}
}
