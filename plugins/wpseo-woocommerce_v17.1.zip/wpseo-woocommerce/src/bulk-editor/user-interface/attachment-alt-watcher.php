<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\Bulk_Editor\User_Interface;

use Yoast\WP\SEO\Integrations\Integration_Interface;
use Yoast\WP\SEO\WooCommerce\Conditionals\WooCommerce_Conditional;

/**
 * Keeps the `_yoast_wpseo_missing_alt_text` product meta in sync when an attachment's alt text is
 * changed outside of the product editor (e.g. directly in Media Library).
 *
 * The assessment meta is written when a product is saved or when alt text is saved from the bulk
 * editor. Neither path fires when the image is edited in the media library, so this watcher hooks
 * into WordPress's post-meta lifecycle to patch only the affected products.
 *
 * phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Attachment_Alt_Watcher implements Integration_Interface {

	/**
	 * The meta key WordPress uses to store an attachment's alt text.
	 */
	private const ATTACHMENT_ALT_META_KEY = '_wp_attachment_image_alt';

	/**
	 * The meta key that stores comma-separated attachment IDs with missing alt text on a product.
	 */
	private const MISSING_ALT_META_KEY = '_yoast_wpseo_missing_alt_text';

	/**
	 * Returns the conditionals based on which this loadable should be active.
	 *
	 * @return array<string> The conditionals.
	 */
	public static function get_conditionals(): array {
		return [ WooCommerce_Conditional::class ];
	}

	/**
	 * Registers the hooks.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		\add_action( 'updated_post_meta', [ $this, 'on_attachment_alt_changed' ], 10, 3 );
		\add_action( 'added_post_meta', [ $this, 'on_attachment_alt_changed' ], 10, 3 );
		\add_action( 'deleted_post_meta', [ $this, 'on_attachment_alt_changed' ], 10, 3 );
	}

	/**
	 * Syncs the missing-alt-text product meta whenever an attachment's alt text is added, updated, or deleted.
	 *
	 * @param int|int[] $meta_id_or_ids The meta row ID(s) — ignored; present because all three meta hooks share this position.
	 * @param int       $object_id      The post (attachment) ID.
	 * @param string    $meta_key       The meta key that changed.
	 *
	 * @return void
	 *
	 * @internal Only public because it is registered as an action callback.
	 */
	public function on_attachment_alt_changed( $meta_id_or_ids, int $object_id, string $meta_key ): void {
		if ( $meta_key !== self::ATTACHMENT_ALT_META_KEY ) {
			return;
		}

		$product_ids = $this->find_product_ids( $object_id );
		if ( $product_ids === [] ) {
			return;
		}

		$has_alt = ( (string) \get_post_meta( $object_id, self::ATTACHMENT_ALT_META_KEY, true ) ) !== '';

		foreach ( $product_ids as $product_id ) {
			$this->update_missing_alt_meta( $product_id, $object_id, $has_alt );
		}
	}

	/**
	 * Returns the IDs of all products that use the given attachment as a featured image, gallery image,
	 * variation featured image, or variation gallery image.
	 *
	 * @param int $attachment_id The attachment ID.
	 *
	 * @return array<int> The product IDs, deduplicated.
	 */
	private function find_product_ids( int $attachment_id ): array {
		// 'any' covers every status the bulk editor lists (publish, draft, pending, future) and disabled
		// variations (private), and still leaves out trash and auto-drafts.
		$base_args = [
			'post_status'            => 'any',
			'fields'                 => 'ids',
			'posts_per_page'         => -1,
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		];

		// Products where the attachment is the featured image.
		$from_featured = \get_posts(
			\array_merge(
				$base_args,
				[
					'post_type'  => 'product',
					'meta_key'   => '_thumbnail_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'meta_value' => (string) $attachment_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				],
			),
		);

		// Products where the attachment appears in the gallery CSV.
		// LIKE is used because WP_Meta_Query has no FIND_IN_SET support; the result is validated in PHP
		// to discard false positives (e.g. searching for 12 must not match 123).
		$from_gallery = $this->find_ids_by_gallery_meta( 'product', $attachment_id, $base_args );

		// Variation posts where the attachment is the featured image → parent product.
		$from_variation_featured = $this->find_parent_ids_by_thumbnail( $attachment_id, $base_args );

		// Variation posts where the attachment appears in the variation gallery CSV → parent product.
		$from_variation_gallery = $this->find_parent_ids_by_variation_gallery( $attachment_id, $base_args );

		return \array_values(
			\array_unique(
				\array_map(
					'intval',
					\array_merge(
						(array) $from_featured,
						$from_gallery,
						$from_variation_featured,
						$from_variation_gallery,
					),
				),
			),
		);
	}

	/**
	 * Returns product IDs whose `_product_image_gallery` meta contains the given attachment ID.
	 *
	 * Uses LIKE for the initial filter and PHP validation to discard false positives.
	 *
	 * @param string                                           $post_type     The post type to query.
	 * @param int                                              $attachment_id The attachment ID to search for.
	 * @param array<string, int|string|bool|array<int|string>> $base_args     Shared WP_Query arguments.
	 *
	 * @return array<int> The post IDs.
	 */
	private function find_ids_by_gallery_meta( string $post_type, int $attachment_id, array $base_args ): array {
		$candidates = \get_posts(
			\array_merge(
				$base_args,
				[
					'post_type'  => $post_type,
					'meta_query' => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						[
							'key'     => '_product_image_gallery',
							'value'   => $attachment_id,
							'compare' => 'LIKE',
						],
					],
				],
			),
		);

		return \array_values(
			\array_filter(
				$candidates,
				static function ( $post_id ) use ( $attachment_id ) {
					$gallery = (string) \get_post_meta( $post_id, '_product_image_gallery', true );
					return \in_array( $attachment_id, \array_map( 'intval', \explode( ',', $gallery ) ), true );
				},
			),
		);
	}

	/**
	 * Returns parent product IDs of variations whose `_thumbnail_id` matches the given attachment.
	 *
	 * @param int                                              $attachment_id The attachment ID.
	 * @param array<string, int|string|bool|array<int|string>> $base_args     Shared WP_Query arguments.
	 *
	 * @return array<int> The parent product IDs.
	 */
	private function find_parent_ids_by_thumbnail( int $attachment_id, array $base_args ): array {
		$variations = \get_posts(
			\array_merge(
				$base_args,
				[
					'post_type'  => 'product_variation',
					'meta_key'   => '_thumbnail_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'meta_value' => (string) $attachment_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				],
			),
		);

		if ( $variations === [] ) {
			return [];
		}

		return \array_values(
			\array_filter(
				\array_map( 'wp_get_post_parent_id', $variations ),
				static fn( $id ) => $id > 0,
			),
		);
	}

	/**
	 * Returns parent product IDs of variations whose `_product_image_gallery` contains the given attachment.
	 *
	 * @param int                                              $attachment_id The attachment ID.
	 * @param array<string, int|string|bool|array<int|string>> $base_args     Shared WP_Query arguments.
	 *
	 * @return array<int> The parent product IDs.
	 */
	private function find_parent_ids_by_variation_gallery( int $attachment_id, array $base_args ): array {
		$variation_ids = $this->find_ids_by_gallery_meta( 'product_variation', $attachment_id, $base_args );

		if ( $variation_ids === [] ) {
			return [];
		}

		return \array_values(
			\array_filter(
				\array_map( 'wp_get_post_parent_id', $variation_ids ),
				static fn( $id ) => $id > 0,
			),
		);
	}

	/**
	 * Adds or removes the attachment ID from the product's missing-alt-text meta.
	 *
	 * @param int  $product_id    The product post ID.
	 * @param int  $attachment_id The attachment whose alt text changed.
	 * @param bool $has_alt       Whether the attachment now has alt text.
	 *
	 * @return void
	 */
	private function update_missing_alt_meta( int $product_id, int $attachment_id, bool $has_alt ): void {
		$current = (string) \get_post_meta( $product_id, self::MISSING_ALT_META_KEY, true );
		$ids     = \array_filter( \array_map( 'intval', \explode( ',', $current ) ) );

		if ( $has_alt ) {
			$ids = \array_values( \array_diff( $ids, [ $attachment_id ] ) );
		}
		elseif ( ! \in_array( $attachment_id, $ids, true ) ) {
			$ids[] = $attachment_id;
		}
		else {
			return;
		}

		\update_post_meta( $product_id, self::MISSING_ALT_META_KEY, \implode( ',', $ids ) );
	}
}
