<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\Bulk_Editor\User_Interface;

use WC_Product;
use Yoast\WP\SEO\Integrations\Integration_Interface;
use Yoast\WP\SEO\WooCommerce\Conditionals\WooCommerce_Conditional;

/**
 * Adds product-specific context data to the bulk editor's post context.
 *
 * phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Bulk_Editor_Context_Integration implements Integration_Interface {

	/**
	 * The meta key prefix used by WPSEO_Meta for all Yoast SEO post meta.
	 */
	private const META_PREFIX = '_yoast_wpseo_';

	/**
	 * The image alt assessment field keys. Each becomes a context key (same name) and
	 * is read from post meta as `_yoast_wpseo_<key>`.
	 */
	private const IMAGE_ASSESSMENT_FIELDS = [
		'alt_text_length',
		'missing_alt_text',
		'duplicate_alt_text',
		'redundant_alt_text_phrase',
		'non_descriptive_alt_text',
		'keyphrase_stuffing_alt_text',
	];

	/**
	 * Returns the conditionals based on which this loadable should be active.
	 *
	 * @return array<string> The conditionals.
	 */
	public static function get_conditionals(): array {
		return [ WooCommerce_Conditional::class ];
	}

	/**
	 * Registers the hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		\add_filter( 'wpseo_bulk_editor_post_context', [ $this, 'add_product_context' ], 10, 3 );
		\add_filter( 'wpseo_bulk_editor_needs_improvement_fields', [ $this, 'add_needs_improvement_fields' ] );
		\add_filter( 'wpseo_bulk_editor_needs_improvement_where_extra_clauses', [ $this, 'add_needs_improvement_where_clauses' ], 10, 4 );
	}

	/**
	 * Adds product-specific context to the bulk editor post data.
	 *
	 * For products, this adds:
	 * - the short description so the bulk editor can display it as additional context;
	 * - the image alt assessment meta values (comma-separated flagged attachment IDs per
	 *   assessment) so the frontend can filter products by which assessments need work.
	 *
	 * @param array<string, string> $context      The context data, empty by default.
	 * @param int                   $post_id      The post ID.
	 * @param string                $content_type The post type.
	 *
	 * @return array<string, string> The context data, extended for products.
	 */
	public function add_product_context( $context, $post_id, $content_type ): array {
		if ( $content_type !== 'product' ) {
			return $context;
		}

		$product = \wc_get_product( $post_id );
		if ( ! $product instanceof WC_Product ) {
			return $context;
		}

		$context['short_description'] = $product->get_short_description();

		foreach ( self::IMAGE_ASSESSMENT_FIELDS as $field ) {
			$context[ $field ] = (string) \get_post_meta( $post_id, self::META_PREFIX . $field, true );
		}

		return $context;
	}

	/**
	 * Extends the bulk editor's allowed "needs improvement" field names with the image assessment fields.
	 *
	 * @param array<string> $fields The allowed field names.
	 *
	 * @return array<string> The extended list.
	 */
	public function add_needs_improvement_fields( array $fields ): array {
		return \array_merge( $fields, self::IMAGE_ASSESSMENT_FIELDS );
	}

	/**
	 * Adds server-side "needs improvement" WHERE clauses for the image alt text assessment fields.
	 *
	 * A product matches a field when its `_yoast_wpseo_<field>` meta is non-empty (it stores
	 * comma-separated attachment IDs flagged by the assessment). Unknown fields are skipped.
	 *
	 * The $context parameter determines which column identifies the post:
	 * - 'indexable': the query runs on wp_yoast_indexable, so the post is identified by `object_id`.
	 * - 'post_meta' (default): the query runs on wp_posts, so the post is identified by `wp_posts.ID`.
	 *
	 * @param array<string> $clauses   Existing extra clauses to OR into the query.
	 * @param array<string> $fields    The requested "needs improvement" fields.
	 * @param string        $post_type The post type being queried.
	 * @param string        $context   The collector context: 'indexable' or 'post_meta'.
	 *
	 * @return array<string> The clauses, extended for any image assessment fields in $fields.
	 */
	public function add_needs_improvement_where_clauses( array $clauses, array $fields, string $post_type, string $context = 'post_meta' ): array {
		if ( $post_type !== 'product' ) {
			return $clauses;
		}

		global $wpdb;

		foreach ( $fields as $field ) {
			if ( ! \in_array( $field, self::IMAGE_ASSESSMENT_FIELDS, true ) ) {
				continue;
			}

			$meta_key = self::META_PREFIX . $field;

			if ( $context === 'indexable' ) {
				$clauses[] = $wpdb->prepare(
					'object_id IN ( SELECT post_id FROM %i WHERE meta_key = %s AND meta_value != %s )',
					$wpdb->postmeta,
					$meta_key,
					'',
				);
			}
			else {
				$clauses[] = $wpdb->prepare(
					'%i.ID IN ( SELECT post_id FROM %i WHERE meta_key = %s AND meta_value != %s )',
					$wpdb->posts,
					$wpdb->postmeta,
					$meta_key,
					'',
				);
			}
		}

		return $clauses;
	}
}
