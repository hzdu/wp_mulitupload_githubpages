<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\Bulk_Editor\User_Interface;

use WP_REST_Request;
use WP_REST_Response;
use Yoast\WP\SEO\Main;
use Yoast\WP\SEO\Routes\Route_Interface;
use Yoast\WP\SEO\WooCommerce\Conditionals\WooCommerce_Conditional;

/**
 * Registers a route that persists image alt text assessment results as product post meta.
 *
 * Called fire-and-forget after the bulk editor saves alt text, so the client-side assessment
 * scores are written back to the database without requiring a full product editor save.
 *
 * @internal Not part of the public REST API surface. Requires edit_posts capability.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Save_Image_Assessment_Meta_Route implements Route_Interface {

	/**
	 * The namespace for this route.
	 *
	 * @var string
	 */
	public const ROUTE_NAMESPACE = Main::API_V1_NAMESPACE;

	/**
	 * The prefix for this route.
	 *
	 * @var string
	 */
	public const ROUTE_PREFIX = '/image_assessment_meta';

	/**
	 * The route prefix for the batch endpoint.
	 *
	 * @var string
	 */
	public const BATCH_ROUTE_PREFIX = '/image_assessment_meta/batch';

	/**
	 * Valid assessment field keys. Each maps to the post meta `_yoast_wpseo_<key>`.
	 *
	 * @var string[]
	 */
	private const FIELD_KEYS = [
		'alt_text_length',
		'missing_alt_text',
		'duplicate_alt_text',
		'redundant_alt_text_phrase',
		'non_descriptive_alt_text',
		'keyphrase_stuffing_alt_text',
	];

	/**
	 * The Yoast SEO post meta prefix.
	 *
	 * @var string
	 */
	private const META_PREFIX = '_yoast_wpseo_';

	/**
	 * Returns the conditionals based on which this loadable should be active.
	 *
	 * @return array<string> The conditionals.
	 */
	public static function get_conditionals(): array {
		return [ WooCommerce_Conditional::class ];
	}

	/**
	 * Registers routes with WordPress.
	 *
	 * @return void
	 */
	public function register_routes() {
		\register_rest_route(
			self::ROUTE_NAMESPACE,
			self::ROUTE_PREFIX,
			[
				'methods'             => 'POST',
				'args'                => [
					'post_id' => [
						'required'          => true,
						'type'              => 'integer',
						'minimum'           => 1,
						'sanitize_callback' => 'absint',
					],
					'fields'  => [
						'required'             => true,
						'type'                 => 'object',
						'additionalProperties' => [ 'type' => 'string' ],
					],
				],
				'callback'            => [ $this, 'save_meta' ],
				'permission_callback' => [ $this, 'check_permissions' ],
			],
		);

		\register_rest_route(
			self::ROUTE_NAMESPACE,
			self::BATCH_ROUTE_PREFIX,
			[
				'methods'             => 'POST',
				'args'                => [
					'products' => [
						'required' => true,
						'type'     => 'array',
						'maxItems' => 20,
						'items'    => [
							'type'       => 'object',
							'properties' => [
								'post_id' => [
									'type'    => 'integer',
									'minimum' => 1,
								],
								'fields'  => [
									'type'                 => 'object',
									'additionalProperties' => [ 'type' => 'string' ],
								],
							],
						],
					],
				],
				'callback'            => [ $this, 'save_meta_batch' ],
				'permission_callback' => [ $this, 'check_permissions' ],
			],
		);
	}

	/**
	 * Saves the assessment field values as post meta for the given product.
	 *
	 * Only writes keys that appear in FIELD_KEYS; unknown keys in the payload are silently
	 * ignored so a mismatch between JS and PHP versions never causes a fatal error.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response.
	 */
	public function save_meta( WP_REST_Request $request ): WP_REST_Response {
		$post_id = $request->get_param( 'post_id' );
		$fields  = $request->get_param( 'fields' );

		$post = \get_post( $post_id );
		if ( ! $post || $post->post_type !== 'product' ) {
			return new WP_REST_Response(
				[
					'success' => false,
					'message' => 'Not a product',
				],
				400,
			);
		}

		if ( ! \current_user_can( 'edit_post', $post_id ) ) {
			return new WP_REST_Response(
				[
					'success' => false,
					'message' => 'Forbidden',
				],
				403,
			);
		}

		$this->write_meta( $post_id, $fields );

		return new WP_REST_Response( [ 'success' => true ], 200 );
	}

	/**
	 * Saves assessment field values for multiple products in a single request.
	 *
	 * Processes entries in order and stops at the first invalid one: returns 400 if an entry
	 * is not a product, 403 if the current user cannot edit it.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response.
	 */
	public function save_meta_batch( WP_REST_Request $request ): WP_REST_Response {
		$products = ( $request->get_param( 'products' ) ?? [] );

		foreach ( $products as $product_data ) {
			$post_id = \absint( ( $product_data['post_id'] ?? 0 ) );
			$fields  = ( $product_data['fields'] ?? [] );

			$post = \get_post( $post_id );
			if ( ! $post || $post->post_type !== 'product' ) {
				return new WP_REST_Response(
					[
						'success' => false,
						'message' => 'Not a product',
					],
					400,
				);
			}

			if ( ! \current_user_can( 'edit_post', $post_id ) ) {
				return new WP_REST_Response(
					[
						'success' => false,
						'message' => 'Forbidden',
					],
					403,
				);
			}

			$this->write_meta( $post_id, $fields );
		}

		return new WP_REST_Response( [ 'success' => true ], 200 );
	}

	/**
	 * Writes assessment field values as post meta for a single product.
	 * Empty values delete the meta key; non-empty values update it.
	 *
	 * @param int                  $post_id The product post ID.
	 * @param array<string,string> $fields  The assessment fields to write.
	 *
	 * @return void
	 */
	private function write_meta( int $post_id, array $fields ): void {
		foreach ( self::FIELD_KEYS as $key ) {
			if ( ! \array_key_exists( $key, $fields ) ) {
				continue;
			}
			$value = \sanitize_text_field( $fields[ $key ] );
			if ( $value === '' ) {
				\delete_post_meta( $post_id, self::META_PREFIX . $key );
			}
			else {
				\update_post_meta( $post_id, self::META_PREFIX . $key, $value );
			}
		}
	}

	/**
	 * Verifies the current user can edit products.
	 *
	 * @return bool Whether the current user may edit products.
	 */
	public function check_permissions(): bool {
		$user = \wp_get_current_user();
		if ( ! $user || $user->ID < 1 ) {
			return false;
		}

		$post_type_object = \get_post_type_object( 'product' );
		if ( ! $post_type_object ) {
			return false;
		}

		return \user_can( $user, $post_type_object->cap->edit_posts );
	}
}
