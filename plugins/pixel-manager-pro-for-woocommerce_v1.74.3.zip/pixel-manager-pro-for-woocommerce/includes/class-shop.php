<?php

namespace SweetCode\Pixel_Manager;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Environment;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Platforms\Order_Data;

defined('ABSPATH') || exit; // Exit if accessed directly

class Shop {

	/**
	 * Paid orders per billing email, memoized for the request.
	 *
	 * @var array<string, array>
	 * @since 1.63.1 Keyed by email address.
	 */
	private static $clv_orders_by_billing_email = [];
	private static $pmw_ist_order_received_page;
	private static $order;
	private static $order_resolved = false;

	/**
	 * Order IDs resolved from an order key, memoized for the request.
	 *
	 * @var array<string, int>
	 * @since 1.64.1
	 */
	private static $order_ids_by_order_key = [];

	/**
	 * The order the order received URL points at, memoized for the request.
	 *
	 * @var \WC_Order|\WC_Order_Refund|bool|null
	 * @since 1.64.1
	 */
	private static $order_from_query_vars;
	private static $transient_identifiers;

	/**
	 * Determine if the user should be tracked.
	 *
	 * This function implements role-based tracking restrictions to prevent certain user types
	 * (e.g., administrators, shop managers) from being tracked by analytics pixels. This helps
	 * maintain data accuracy by filtering out internal traffic and test orders.
	 *
	 * Logic flow:
	 * 1. Anonymous visitors (user_id = 0) are always tracked
	 * 2. If a user_id is provided, retrieve that specific user object
	 * 3. If no user_id is provided but the user is logged in, retrieve the current user
	 * 4. Check if any of the user's roles match the roles configured to be excluded from tracking
	 *    in the plugin settings (shop->disable_tracking_for option)
	 * 5. Return false if the user has a restricted role, true otherwise
	 *
	 * @param int|null $user_id The user ID to check. If null, the current user will be used.
	 *                          If 0, the user is considered anonymous.
	 * @return bool True if the user should be tracked, false otherwise.
	 */
	public static function track_user( $user_id = null ) {

		$user = null;

		if (0 === $user_id) {                                    // If anonymous visitor then track
			return true;
		} elseif ($user_id && 0 <= $user_id) {                   // If user ID is known, get the user
			$user = get_user_by('id', $user_id);
		} elseif (null === $user_id && is_user_logged_in()) {    // If user id is not given, but the user is logged in, get the user
			$user = wp_get_current_user();
		}

		// Find out if the user has a role that is restricted from tracking
		if ($user) {

			foreach ($user->roles as $role) {
				if (in_array($role, Options::get_options_obj()->shop->disable_tracking_for, true)) {
					return false;
				}
			}
		}

		return true;
	}

	public static function do_not_track_user( $user_id = null ) {
		return !self::track_user($user_id);
	}

	/**
	 * Get the user ID from the order.
	 *
	 * @param $order
	 * @return int
	 */
	public static function get_order_user_id( $order ) {

		if ($order->meta_exists('_wpm_customer_user')) {
			return (int) $order->get_meta('_wpm_customer_user', true);
		}

		return (int) $order->get_meta('_customer_user', true);
	}

	/**
	 * Return the filtered order total value that is being used for paid ads order total tracking.
	 * It can output different values depending on the order total tracking type.
	 * And it can be filtered for custom order value calculations.
	 *
	 * The apply_multipliers bool is used to distinguish if the multipliers should be applied or not.
	 * For the browser pixel output on the purchase confirmation page we need the multipliers to be applied.
	 * But, for instance for the customer lifetime value calculation we don't want the multipliers to be applied,
	 * because the CLV is calculated based on all existing and effective orders.
	 *
	 * @return float
	 */
	public static function get_order_value_total_marketing( $order, $apply_multipliers = false ) {

		$order_total = $order->get_total();

		if (in_array(Options::get_options_obj()->shop->order_total_logic, [ '0', 'order_subtotal' ], true)) {

			// Order subtotal
			// get_subtotal() sums the product line items only, before discounts and excluding
			// tax, shipping and fee lines. So only the product share of the refunds and the
			// payment processor fees may be deducted from it. Anything else would be deducted
			// twice, since WooCommerce never added it to the subtotal in the first place.
			$order_total = $order->get_subtotal() - $order->get_total_discount() - self::get_order_fees($order) - self::get_product_refund_total($order);

		} elseif (in_array(Options::get_options_obj()->shop->order_total_logic, [ '1', 'order_total' ], true)) {

			// Order total
			$order_total = $order->get_total() - $order->get_total_refunded();

		} elseif (in_array(Options::get_options_obj()->shop->order_total_logic, [ '2', 'order_profit_margin' ], true)) {

			// Order profit margin
			$order_total = Profit_Margin::get_order_profit_margin($order);
		}

		// Apply multipliers
		if (wpm_fs()->can_use_premium_code__premium_only()) {
			if ($apply_multipliers) {
				$order_total = self::apply_subscription_multiplier__premium_only($order_total, $order);
			}
		}

		// Third-party callbacks always receive the platform-native order, never the
		// neutral wrapper the server-side purchase path works with. See Order_Data::unwrap().
		$filter_order = Order_Data::unwrap($order);

		// deprecated filters to adjust the order value
		$order_total = apply_filters_deprecated('wgact_conversion_value_filter', [ $order_total, $filter_order ], '1.10.2', 'pmw_marketing_conversion_value_filter');
		$order_total = apply_filters_deprecated('wooptpm_conversion_value_filter', [ $order_total, $filter_order ], '1.13.0', 'pmw_marketing_conversion_value_filter');
		$order_total = apply_filters_deprecated('wpm_conversion_value_filter', [ $order_total, $filter_order ], '1.31.2', 'pmw_marketing_conversion_value_filter');

		/**
		 * Filter to adjust the order value.
		 *
		 * @since 1.31.2
		 */
		$order_total = apply_filters('pmw_marketing_conversion_value_filter', $order_total, $filter_order);

		// A conversion value can never be negative. The ad platforms either reject a negative
		// value or misinterpret it, so it is floored here. This happens after the filter on
		// purpose, so that a custom calculation cannot send a negative value out either.
		$order_total = max(0, (float) $order_total);

		return (float) Helpers::format_decimal((float) $order_total, 2);
	}

	/**
	 * Return the filtered order total value for statistics pixels.
	 *
	 * @param $order
	 * @return float
	 *
	 * @since 1.43.4
	 */
	public static function get_order_value_total_statistics( $order ) {

		$order_total = $order->get_total();
		/**
		 * Filters Order value total statistics.
		 *
		 * @since 1.58.5
		 */
		$order_total = apply_filters('pmw_order_value_total_statistics', $order_total, Order_Data::unwrap($order));

		return (float) Helpers::format_decimal((float) $order_total, 2);
	}

	/**
	 * Return the filtered order subtotal value for statistics pixels.
	 *
	 * @param $order
	 * @return float
	 *
	 * @since 1.43.4
	 */
	public static function get_order_value_subtotal_statistics( $order ) {

		$order_subtotal = $order->get_subtotal();
		/**
		 * Filters Order value subtotal statistics.
		 *
		 * @since 1.58.5
		 */
		$order_subtotal = apply_filters('pmw_order_value_subtotal_statistics', $order_subtotal, Order_Data::unwrap($order));

		return (float) Helpers::format_decimal((float) $order_subtotal, 2);
	}

	public static function is_backend_manual_order( $order ) {

		$is_backend_manual = false;

		// Classic admin-created orders: WooCommerce sets `_created_via` to 'admin'
		// when an order is created through the WP Admin order editor.
		if ($order->meta_exists('_created_via') && 'admin' === $order->get_meta('_created_via', true)) {
			$is_backend_manual = true;
		}

		// WooCommerce Order Attribution (core, enabled by default since WC 8.5) also
		// marks admin-created orders with an 'admin' source type. This catches orders
		// created programmatically via `wc_create_order()` in custom quote, push-cart,
		// or pay-for-order flows where `_created_via` is not set.
		// @since 1.58.10
		if (!$is_backend_manual && 'admin' === $order->get_meta('_wc_order_attribution_source_type', true)) {
			$is_backend_manual = true;
		}

		/**
		 * Filters whether an order is considered a backend manual order.
		 *
		 * Return true for custom order-creation flows (quote-to-order, push-cart,
		 * B2B pay-for-order, etc.) that neither set `_created_via = 'admin'` nor
		 * trigger WooCommerce Order Attribution, so PMW re-captures the customer's
		 * current browser identifiers when they pay for the order.
		 *
		 * @since 1.58.10
		 *
		 * @param bool      $is_backend_manual Whether PMW considers this a backend manual order.
		 * @param \WC_Order $order             The order being evaluated.
		 */
		return (bool) apply_filters('pmw_is_backend_manual_order', $is_backend_manual, Order_Data::unwrap($order));
	}

	public static function conversion_pixels_already_fired_html() {
		?>

		<!--	----------------------------------------------------------------------------------------------------
				The conversion pixels have not been fired. Possible reasons:
					- The user role has been disabled for tracking.
					- The order payment has failed.
					- The pixels have already been fired. To prevent double counting, the pixels are only fired once.

				If you want to test the order you have two options:
					- Turn off order duplication prevention in the advanced settings
					- Add the '&nodedupe' parameter to the order confirmation URL like this:
						https://example.test/checkout/order-received/123/?key=wc_order_123abc&nodedupe

				More info on testing: <?php echo esc_html(Documentation::get_link('test_order')); ?>
				----------------------------------------------------------------------------------------------------
		-->
		<?php
	}

	public static function is_nodedupe_parameter_set() {

		$_get = Helpers::get_input_vars(INPUT_GET);

		// Deliberately not gated on a capability: support debugs shops from the
		// outside by having the merchant, or the support engineer, open the
		// confirmation URL with this parameter, without a login on that shop.
		// The holder of a confirmation URL can re-fire that one order; that is
		// an accepted trade-off for a working debugging path. Decided 2026-09-21.
		return isset($_get['nodedupe']);
	}

	public static function has_conversion_pixel_already_fired( $order ) {

		if (wpm_fs()->can_use_premium_code__premium_only()) {

			if ($order->meta_exists('_wpm_conversion_pixel_fired')) {
				return true;
			}

			if ($order->meta_exists('_wooptpm_conversion_pixel_fired')) {
				return true;
			}

			return false;
		}

		return false;
	}

	/**
	 * Meta key recording that the GA4 purchase event was sent from the browser.
	 *
	 * The GA4 browser pixel and the GA4 Measurement Protocol are mutually
	 * exclusive transports: the browser purchase is suppressed while the MP
	 * API secret is set. Each transport used to track its own "already sent"
	 * state, so an order paid while the secret was empty was tracked from the
	 * browser without leaving any marker the MP could see. Re-enabling the
	 * secret then made the next paid-status transition send that same order
	 * a second time.
	 *
	 * This key closes that gap. It is written on the order confirmation only
	 * while the MP is inactive, and the MP purchase gate honors it.
	 *
	 * Note: it is deliberately NOT the same as _wpm_conversion_pixel_fired.
	 * That flag is written on every order confirmation regardless of consent
	 * and regardless of which pixels actually ran, so it cannot gate the MP.
	 *
	 * Known imprecision: the order confirmation cannot tell whether the GA4
	 * browser purchase was itself suppressed by denied statistics consent, so
	 * the marker is set for those orders too. That only matters for shops
	 * running always_send_s2s, which would otherwise send such an order once
	 * the MP is enabled. Not resending a historical order is the safer default.
	 *
	 * @return string
	 * @since 1.63.1
	 */
	public static function get_ga4_browser_purchase_key() {
		return '_pmw_ga4_browser_purchase_sent';
	}

	/**
	 * Whether the GA4 purchase event for this order was already sent from the browser.
	 *
	 * @param \WC_Order $order The order.
	 * @return bool
	 * @since 1.63.1
	 */
	public static function was_ga4_purchase_sent_from_browser( $order ) {
		return $order->meta_exists(self::get_ga4_browser_purchase_key());
	}

	/**
	 * Whether the order confirmation should record a browser-sent GA4 purchase.
	 *
	 * True only when GA4 is configured and the Measurement Protocol is inactive,
	 * which is exactly the situation in which the browser sends the purchase.
	 *
	 * @return bool
	 * @since 1.63.1
	 */
	public static function should_record_ga4_browser_purchase() {
		return Options::is_ga4_enabled() && !Options::is_ga4_mp_active();
	}

	public static function is_order_confirmation_allowed_status( $order ) {

		if (
			$order->has_status('failed')
			|| $order->has_status('cancelled')
			|| $order->has_status('refunded')
		) {
			return false;
		}

		return true;
	}

	public static function is_order_confirmation_not_allowed_status( $order ) {
		return !self::is_order_confirmation_allowed_status($order);
	}

	public static function can_order_confirmation_be_processed( $order ) {
		return null === self::get_order_confirmation_block_reason($order);
	}

	/**
	 * Whether the order confirmation is held back only because the conversion
	 * pixels already fired for this order, which the order duplication
	 * prevention does to avoid double counting.
	 *
	 * The library logs this on the order confirmation page, together with the
	 * nodedupe parameter that lets a merchant test the purchase again. Without
	 * it, a merchant reloading a confirmation page saw a page view and nothing
	 * else and took the purchase tracking for broken.
	 *
	 * @param \WC_Order|object $order The order.
	 * @return bool
	 *
	 * @since 1.71.1
	 */
	public static function is_order_confirmation_suppressed_as_already_fired( $order ) {
		return 'already_fired' === self::get_order_confirmation_block_reason($order);
	}

	/**
	 * Why the order confirmation may not be processed, or null when it may.
	 *
	 * @param \WC_Order|object $order The order.
	 * @return string|null One of 'status', 'renewal', 'user', 'filter', 'already_fired', or null.
	 *
	 * @since 1.71.1
	 */
	private static function get_order_confirmation_block_reason( $order ) {

		$filter_order = Order_Data::unwrap($order);

		$conversion_prevention = apply_filters_deprecated('wgact_conversion_prevention', [ false, $filter_order ], '1.10.2', 'pmw_conversion_prevention');
		$conversion_prevention = apply_filters_deprecated('wooptpm_conversion_prevention', [ $conversion_prevention, $filter_order ], '1.13.0', 'pmw_conversion_prevention');
		$conversion_prevention = apply_filters_deprecated('wpm_conversion_prevention', [ $conversion_prevention, $filter_order ], '1.31.2', 'pmw_conversion_prevention');

		/**
		 * If the conversion prevention filter is set to true, the order confirmation will not be processed.
		 *
		 * @since 1.31.2
		 */
		$conversion_prevention = apply_filters('pmw_conversion_prevention', $conversion_prevention, $filter_order);

		// If order is in failed, cancelled or refunded status, skip the order confirmation
		if (self::is_order_confirmation_not_allowed_status($order)) {
			return 'status';
		}

		// If this user role is not allowed to be tracked, skip the order confirmation
		if (self::do_not_track_user()) {
			return 'user';
		}

		// If the conversion prevention filter is set to true, skip the order confirmation
		if ($conversion_prevention) {
			return 'filter';
		}

		// A manual renewal is paid through the checkout, so unlike an automatic one it
		// does reach the purchase confirmation page and fires the browser pixels. The
		// renewal opt-out covers those too, and with them the Automatic Conversion
		// Recovery, which would otherwise recover exactly the conversions the shop
		// asked us not to report. @since 1.67.1
		if (self::do_not_track_subscription_renewal() && self::is_wcs_renewal_order($order)) {
			return 'renewal';
		}

		// If the order deduplication is deactivated, either through the setting or through
		// the &nodedupe URL parameter, the order confirmation may be processed again.
		//
		// This waives the "has this pixel already fired" check below and nothing else. The
		// order status, the excluded user role and the conversion prevention filter above are
		// deliberate suppressions, so they have to be evaluated first. Returning early here
		// used to skip them, which fired conversions for orders a shop had suppressed through
		// the pmw_conversion_prevention filter, and for orders in a not-allowed status.
		//
		// @since 1.64.1
		if (self::is_order_duplication_prevention_disabled()) {
			return null;
		}

		// if the conversion pixels have not been fired yet, we can process the order confirmation
		if (self::has_conversion_pixel_already_fired($order) !== true) {
			return null;
		}

		return 'already_fired';
	}

	public static function is_order_duplication_prevention_disabled() {

		if (Options::is_order_duplication_prevention_option_disabled()) {
			return true;
		}

		if (self::is_nodedupe_parameter_set()) {
			return true;
		}

		return false;
	}

	public static function is_order_duplication_prevention_active() {
		return !self::is_order_duplication_prevention_disabled();
	}

	public static function is_browser_on_shop() {

		$_server = Helpers::get_input_vars(INPUT_SERVER);

//      error_log(print_r($_server, true));
//      error_log(print_r($_server['HTTP_HOST'], true));
//      error_log('get_site_url(): ' . parse_url(get_site_url(), PHP_URL_HOST));
//      error_log('parse url https://www.exampel.com : ' . parse_url('https://www.exampel.com', PHP_URL_HOST));

		// Servers like Siteground don't seem to always provide $_server['HTTP_HOST']
		// In that case we need to pretend that we're on the same server
		if (!isset($_server['HTTP_HOST'])) {
			return true;
		}

		if (wp_parse_url(get_site_url(), PHP_URL_HOST) === $_server['HTTP_HOST']) {
			return true;
		} else {
			return false;
		}
	}

	public static function was_order_created_while_pmw_premium_was_active( $order ) {
		if ($order->meta_exists('_wpm_premium_active')) {
			return true;
		} else {
			return false;
		}
	}

	public static function was_order_created_while_pmw_was_active( $order ) {
		return (bool) $order->meta_exists('_wpm_process_through_wpm');
	}

	public static function is_backend_subscription_renewal_order( $order ) {

		// Only continue if this is a back-end order
		if ($order->meta_exists('_created_via') && 'subscription' === $order->get_meta('_created_via', true)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Whether an order should be counted in the tracking accuracy statistics.
	 *
	 * Only orders placed through a customer browser checkout (classic checkout
	 * or the Store API used by the block checkout) can ever reach the purchase
	 * confirmation page, so only those may be counted. Everything else
	 * (admin-created orders, subscription renewals, migration imports, REST
	 * orders, upsell child orders with a custom created_via) would only
	 * deflate the per-gateway accuracy because PMW can never measure them.
	 *
	 * @param \WC_Order $order
	 * @return bool
	 * @since 1.61.2
	 */
	public static function should_count_order_for_tracking_accuracy( $order ) {

		$should_count = in_array($order->get_created_via(), self::get_tracking_accuracy_created_via_allowlist(), true);

		// Orders where the visitor denied all consent categories can't fire any
		// pixel on the purchase confirmation page, so counting them would only
		// deflate the accuracy with a loss that says nothing about the gateway.
		// If at least one category was granted, some pixels can still fire and
		// the measurement stays meaningful.
		//
		// This holds regardless of always_send_s2s. That setting keeps the
		// server-side events flowing for these orders, but this report measures
		// the browser-side confirmation per gateway, so a consent-denied order
		// is noise for that question either way. The exclusion note in the
		// report tells the shop which of the two cases it is in.
		if ($should_count) {
			$snapshot = $order->get_meta('_pmw_consent_snapshot', true);
			if (is_array($snapshot) && empty($snapshot['marketing']) && empty($snapshot['statistics'])) {
				$should_count = false;
			}
		}

		/**
		 * Filters whether an order counts toward the tracking accuracy statistics.
		 *
		 * Return false for orders that are created without a customer browser
		 * session, e.g. renewal orders of third-party subscription plugins that
		 * PMW cannot detect generically, so they don't deflate the payment
		 * gateway accuracy report. Return true to force-include orders from a
		 * custom checkout flow that uses its own created_via value but does
		 * reach the purchase confirmation page.
		 *
		 * @since 1.61.2
		 *
		 * @param bool      $should_count Whether the order counts toward tracking accuracy.
		 * @param \WC_Order $order        The order being evaluated.
		 */
		return (bool) apply_filters('pmw_count_order_for_tracking_accuracy', $should_count, Order_Data::unwrap($order));
	}

	/**
	 * The created_via values of orders placed through a customer browser checkout.
	 *
	 * 'checkout' is the classic shortcode checkout, 'store-api' is the block
	 * checkout. These are the only order sources that reach the purchase
	 * confirmation page, so they are the only ones the tracking accuracy
	 * statistics may count.
	 *
	 * @return array
	 * @since 1.62.0
	 */
	public static function get_tracking_accuracy_created_via_allowlist() {
		return [ 'checkout', 'store-api' ];
	}

	// https://wordpress.stackexchange.com/a/95440/68337
	// https://wordpress.stackexchange.com/a/31435/68337
	// https://developer.wordpress.org/reference/functions/get_the_title/
	// https://codex.wordpress.org/Data_Validation#Output_Sanitation
	// https://developer.wordpress.org/reference/functions/wp_specialchars_decode/
	public static function pmw_get_the_title( $post = 0 ) {

		$post  = get_post($post);
		$title = isset($post->post_title) ? $post->post_title : '';

		// Decoding is safe here because the value is always JSON-encoded before output.
		return wp_specialchars_decode($title);
	}

	// Removed in 1.63.1: get_all_order_ids(), get_count_of_all_order_ids(),
	// get_all_order_ids_by_billing_email() and
	// get_count_of_order_ids_by_billing_email(). They fetched every paid order
	// ID in the shop with limit => -1 purely to count() the result, and their
	// only caller was the commented-out guard in can_ltv_be_processed_on_order()
	// below. Should that guard ever be revived, count the orders with
	// wc_get_orders(['limit' => 1, 'paginate' => true])->total instead of
	// hydrating the full ID list.

	public static function can_ltv_be_processed_on_order( $order ) {

		if (!Options::is_order_level_ltv_calculation_active()) {
			return false;
		}

		if (Environment::cannot_run_action_scheduler()) {
			Logger::debug('can_ltv_be_processed is not available in this environment. The active Action Scheduler version is ' . Environment::get_action_scheduler_version() . ' and the minimum required version is ' . Environment::get_action_scheduler_minimum_version());
			return false;
		}

		// Abort if is not a valid email
		if (!Helpers::is_email($order->get_billing_email())) {
			return false;
		}

		// Abort if the wc_get_orders query doesn't properly accept the 'billing_email' parameter
		// In that case a count filtered by billing email would return all orders of the shop
//      if (self::get_count_of_all_order_ids() === self::get_count_of_order_ids_by_billing_email($order->get_billing_email())) {
//          return false;
//      }

		return true;
	}

	public static function get_all_paid_orders_by_billing_email( $billing_email ) {

		$email = sanitize_email($billing_email);

		// Keyed by email. The previous single-slot cache returned the first
		// looked-up customer's orders for every subsequent email in the same
		// request, which silently reported the wrong customer lifetime value
		// whenever more than one email was resolved (and an isset() check
		// rather than a truthy one so a customer with no paid orders is not
		// re-queried on every call). @since 1.63.1
		if (isset(self::$clv_orders_by_billing_email[$email])) {
			return self::$clv_orders_by_billing_email[$email];
		}

		$orders = wc_get_orders([
			'billing_email' => $email,
			'post_status'   => wc_get_is_paid_statuses(),
			'limit'         => -1,
			//                                      'return'        => 'ids',
		]);

		self::$clv_orders_by_billing_email[$email] = $orders;

		return $orders;
	}

	public static function get_clv_value_filtered_by_billing_email( $billing_email ) {

		$orders = self::get_all_paid_orders_by_billing_email($billing_email);

		$value = 0;

		foreach ($orders as $order) {
			$value += (float) self::get_order_value_total_marketing($order);
		}

		return Helpers::format_decimal($value, 2);
	}

	// https://github.com/woocommerce/woocommerce/wiki/wc_get_orders-and-WC_Order_Query
	// https://github.com/woocommerce/woocommerce/blob/5d7f6acbcb387f1d51d51305bf949d07fa3c4b08/includes/data-stores/class-wc-customer-data-store.php#L401
	public static function get_clv_order_total_by_billing_email( $billing_email ) {

		$orders = self::get_all_paid_orders_by_billing_email($billing_email);

		$value = 0;

		foreach ($orders as $order) {
			$value += $order->get_total();
		}

		return Helpers::format_decimal($value, 2);
	}

	/**
	 * Don't count in the current order
	 * https://stackoverflow.com/a/46216073/4688612
	 * https://github.com/woocommerce/woocommerce/wiki/wc_get_orders-and-WC_Order_Query#description
	 */
	public static function is_existing_customer( $order ) {

		$query_arguments = [
			'return'      => 'ids',
			'exclude'     => [ $order->get_id() ],
			'post_status' => wc_get_is_paid_statuses(),
			'limit'       => 1,
		];

		if (is_user_logged_in()) {
			$current_user                = wp_get_current_user();
			$query_arguments['customer'] = sanitize_email($current_user->user_email);

		} else {
			$query_arguments['billing_email'] = sanitize_email($order->get_billing_email());
		}

		$orders = wc_get_orders($query_arguments);

		return count($orders) > 0;
	}

	public static function is_new_customer( $order ) {
		return !self::is_existing_customer($order);
	}

	public static function woocommerce_3_and_above() {

		global $woocommerce;

		if (version_compare($woocommerce->version, 3.0, '>=')) {
			return true;
		} else {
			return false;
		}
	}

	public static function get_order_currency( $order ) {

		// use the right function to get the currency depending on the WooCommerce version
		return self::woocommerce_3_and_above() ? $order->get_currency() : $order->get_order_currency();
	}

	/**
	 * As security measure always check for the order key and only return the order if there is a match.
	 *
	 * @return bool|\WC_Order|\WC_Order_Refund
	 */
	public static function get_order_from_order_received_page() {

		$order_key = self::get_order_key_from_url();

		if ($order_key) {

			$order_by_order_key  = wc_get_order(self::get_order_id_by_order_key($order_key));
			$order_by_query_vars = self::get_order_from_query_vars();

			// If there is an $order_by_query_vars, then we can compare the order IDs.
			// If they don't match, then we return null.
			// Otherwise, we return the $order_by_order_key.
			if (
				$order_by_query_vars
				&& $order_by_order_key
			) {
				if ($order_by_order_key->get_id() == $order_by_query_vars->get_id()) {
					return $order_by_order_key;
				}

				return null;
			}

			if ($order_by_order_key) {
				return $order_by_order_key;
			}

			return null;

		} else {

			// get current page, including query string

			$_server = Helpers::get_input_vars(INPUT_SERVER);

			if (isset($_server['REQUEST_URI'])) {
				$page = esc_url_raw($_server['REQUEST_URI']);
			} else {
				$page = '';
			}

			Logger::debug("WooCommerce couldn't retrieve the order ID from order key in the URL: " . $page);

			return false;
		}
	}

	public static function get_order_from_query_vars() {

		/**
		 * Both the order key resolution and the order received page lookup read this,
		 * so a resolved order is memoized for the request.
		 *
		 * Only the positive result is cached. PMW checks for the order received page as
		 * early as init, where the query vars aren't parsed yet, and a cached miss would
		 * stay wrong for the rest of the request.
		 *
		 * @since 1.64.1
		 */
		if (self::$order_from_query_vars) {
			return self::$order_from_query_vars;
		}

		self::$order_from_query_vars = self::resolve_order_from_query_vars();

		return self::$order_from_query_vars;
	}

	private static function resolve_order_from_query_vars() {

		global $wp;

		if (!isset($wp->query_vars['order-received'])) {
			return false;
		}

		$order_id = absint($wp->query_vars['order-received']);

		$order = $order_id ? wc_get_order($order_id) : false;

		if ($order) {
			return $order;
		}

		Logger::debug('WooCommerce couldn\'t retrieve the order ID from $wp->query_vars[\'order-received\']: ' . print_r($wp->query_vars, true));

		return false;
	}

	/**
	 * Read the order key from the URL.
	 *
	 * Parameter key is for WooCommerce
	 * Parameter wcf-key is for CartFlows
	 * Parameter ctp_order_key is for StoreApps Custom Thankyou Page
	 *
	 * @since 1.64.1
	 * @return string|null
	 */
	public static function get_order_key_from_url() {

		$_get = Helpers::get_input_vars(INPUT_GET);

		if (isset($_get['key'])) {
			return $_get['key'];    // for WooCommerce
		}

		if (isset($_get['wcf-key'])) {
			return $_get['wcf-key'];    // for CartFlows
		}

		if (isset($_get['ctp_order_key'])) {
			return $_get['ctp_order_key'];    // for StoreApps Custom Thankyou Page
		}

		return null;
	}

	/**
	 * Resolve an order key to an order ID, at most once per key and request.
	 *
	 * On shops that still use the legacy post storage wc_get_order_id_by_order_key()
	 * scans wp_postmeta on meta_value, which WordPress doesn't index. On a large shop
	 * that takes seconds, and the order received page used to pay for it twice: once
	 * to validate the key in the URL, and once to load the order. HPOS reads an
	 * indexed column and is cheap either way.
	 *
	 * @since 1.64.1
	 * @param string $order_key
	 * @return int The order ID, or 0 if the key doesn't belong to an order.
	 */
	public static function get_order_id_by_order_key( $order_key ) {

		$order_key = (string) $order_key;

		if (isset(self::$order_ids_by_order_key[ $order_key ])) {
			return self::$order_ids_by_order_key[ $order_key ];
		}

		/**
		 * On a standard WooCommerce order received page the order ID is already in the
		 * URL. If the key of that order matches the key in the URL, the key is resolved
		 * without the database lookup, while the key still authorizes the read.
		 */
		$order = self::get_order_from_query_vars();

		if (
			$order
			&& method_exists($order, 'get_order_key')
			&& hash_equals((string) $order->get_order_key(), $order_key)
		) {
			self::$order_ids_by_order_key[ $order_key ] = $order->get_id();

			return self::$order_ids_by_order_key[ $order_key ];
		}

		self::$order_ids_by_order_key[ $order_key ] = (int) wc_get_order_id_by_order_key($order_key);

		return self::$order_ids_by_order_key[ $order_key ];
	}

	public static function is_valid_order_key_in_url() {

		$order_key = self::get_order_key_from_url();

		if (!$order_key) {
			return false;
		}

		if (!self::is_plausible_order_key($order_key)) {
			return false;
		}

		if (self::is_request_context_that_cannot_confirm_an_order()) {
			return false;
		}

		return (bool) self::get_order_id_by_order_key($order_key);
	}

	/**
	 * Whether a string has the shape of a WooCommerce order key.
	 *
	 * WooCommerce generates wc_order_ followed by 13 random characters, and a
	 * filter may change the prefix. On shops that still use the post storage the
	 * lookup scans an unindexed column, so nothing that cannot be a key is
	 * looked up at all.
	 *
	 * @param mixed $order_key
	 * @return bool
	 *
	 * @since 1.69.1
	 */
	public static function is_plausible_order_key( $order_key ) {
		return is_string($order_key) && (bool) preg_match('/^[A-Za-z0-9_-]{8,64}\z/', $order_key);
	}

	/**
	 * Whether the current request is a page that can never be an order
	 * confirmation: the front page, the blog index, an archive, a search or a
	 * 404. WooCommerce's endpoint and custom thank-you pages are singular pages.
	 * A visitor could append an order key to any URL, and the plugin used to
	 * treat the home page as the confirmation of that order and print its
	 * customer data into a page that caches are most likely to store.
	 *
	 * @return bool
	 *
	 * @since 1.69.1
	 */
	private static function is_request_context_that_cannot_confirm_an_order() {

		// Before the main query is parsed the conditionals are not usable.
		if (!did_action('wp')) {
			return false;
		}

		if (function_exists('is_order_received_page') && is_order_received_page()) {
			return false;
		}

		return is_front_page() || is_home() || is_archive() || is_search() || is_404();
	}

	public static function add_parent_category_id( $category, $list_suffix ) {

		if ($category->parent > 0) {

			$parent_category = get_term_by('id', $category->parent, 'product_cat');
			$list_suffix     = '.' . $parent_category->slug . $list_suffix;
			$list_suffix     = self::add_parent_category_id($parent_category, $list_suffix);
		}

		return $list_suffix;
	}

	public static function get_list_id_suffix() {

		$list_suffix = '';

		if (is_product_category()) {
			$category    = get_queried_object();
			$list_suffix = '.' . $category->slug;
			$list_suffix = self::add_parent_category_id($category, $list_suffix);
		} elseif (is_product_tag()) {
			$tag         = get_queried_object();
			$list_suffix = '.' . $tag->slug;
		}

		return $list_suffix;
	}

	public static function add_parent_category_name( $category, $list_suffix ) {

		if ($category->parent > 0) {

			$parent_category = get_term_by('id', $category->parent, 'product_cat');
			$list_suffix     = ' | ' . wp_specialchars_decode($parent_category->name) . $list_suffix;
			$list_suffix     = self::add_parent_category_name($parent_category, $list_suffix);
		}

		return $list_suffix;
	}

	public static function get_list_name_suffix() {

		$list_suffix = '';

		if (is_product_category()) {

			$category    = get_queried_object();
			$list_suffix = ' | ' . wp_specialchars_decode($category->name);
			$list_suffix = self::add_parent_category_name($category, $list_suffix);
		} elseif (is_product_tag()) {
			$tag         = get_queried_object();
			$list_suffix = ' | ' . wp_specialchars_decode($tag->name);
		}

		return $list_suffix;
	}

	/**
	 * Calculate and return the payment processor fees of an order.
	 *
	 * These are the fees the payment processor keeps out of the payout. They are a merchant
	 * cost, the customer never pays them, and they are part of no WooCommerce order figure at
	 * all. That is why they have to be read from the order meta that the gateways write.
	 * Then provide a filter to allow shop managers to calculate and add their own fees.
	 *
	 * Customer facing fee lines (WC_Order_Item_Fee, for instance a gift wrap, COD or deposit
	 * surcharge) are deliberately not included here. WooCommerce adds those to the order total
	 * but never to $order->get_subtotal(), which only sums the product line items. Subtracting
	 * them from that subtotal would therefore remove them a second time and push the value
	 * below the actual product revenue, or even below zero when the fee line is the whole order.
	 *
	 * @param $order
	 * @return float
	 */
	public static function get_order_fees( $order ) {

		$order_fees = 0;

		// Add Stripe fees
		// because Stripe doesn't save the fee on the order fees
		$order_fees += self::get_stripe_fee_in_order_currency($order);

		// Add _paypal_transaction_fee
		// because PayPal doesn't save the fee on the order fees
		// https://stackoverflow.com/a/56129332/4688612
		$order_fees += self::get_fee_by_postmeta_key($order, '_paypal_transaction_fee');

		// Add ppcp_paypal_fees
		// because PayPal doesn't save the fee on the order fees
		if ($order->meta_exists('_ppcp_paypal_fees')) {
			$ppcp_paypal_fees = $order->get_meta('_ppcp_paypal_fees', true);

			// PayPal reports this fee in the currency of the transaction, which is the order
			// currency. Should it ever come in another one, it can't be converted from here,
			// and subtracting it unconverted would distort the value far more than leaving it out.
			if (
				!empty($ppcp_paypal_fees['paypal_fee']['value'])
				&& (
					empty($ppcp_paypal_fees['paypal_fee']['currency_code'])
					|| strtoupper((string) $ppcp_paypal_fees['paypal_fee']['currency_code']) === strtoupper((string) $order->get_currency())
				)
			) {
				$order_fees += (float) $ppcp_paypal_fees['paypal_fee']['value'];
			}
		}

		/**
		 * Filters Order fees.
		 *
		 * @since 1.58.5
		 */
		return (float) apply_filters('pmw_order_fees', $order_fees, Order_Data::unwrap($order));
	}

	/**
	 * Return the share of the refunded amount that belongs to the product line items, excluding tax.
	 *
	 * $order->get_total_refunded() covers the entire order: product lines, shipping, fee lines
	 * and tax. The subtotal branch of get_order_value_total_marketing() works on a base that
	 * holds the product line items only, excluding tax and shipping, so everything that is not
	 * product revenue has to be taken back out before the refund can be subtracted from it.
	 *
	 * Refunds that were entered as a plain amount instead of per line item carry no breakdown.
	 * Nothing can be attributed in that case, so the full amount stays in and the reported
	 * value errs on the low side.
	 *
	 * @param $order
	 * @return float
	 */
	public static function get_product_refund_total( $order ) {

		// get_total_tax_refunded() covers the tax of the product lines and of the shipping,
		// so the shipping cost is the only shipping share left to remove.
		$product_refund_total = (float) $order->get_total_refunded()
				- (float) $order->get_total_tax_refunded()
				- (float) $order->get_total_shipping_refunded()
				- self::get_fee_refund_total($order);

		return (float) max(0, $product_refund_total);
	}

	/**
	 * Return the refunded amount that no line item of the order accounts for, excluding tax.
	 *
	 * A refund entered per line item records which items, shipping and fees it applies to. A
	 * refund entered as a plain amount records nothing but the amount, so any calculation that
	 * works per item cannot see it at all.
	 *
	 * The subtotal and the order total branch of get_order_value_total_marketing() work off the
	 * refund totals and cover both kinds. The profit margin branch has to work per item, because
	 * reversing the cost of goods needs the refunded quantity, so it needs this remainder to
	 * account for the rest.
	 *
	 * @param $order
	 * @return float
	 */
	public static function get_unattributed_refund_total( $order ) {

		$attributed_refund_total = (float) $order->get_total_tax_refunded()
				+ (float) $order->get_total_shipping_refunded()
				+ self::get_fee_refund_total($order)
				+ self::get_line_item_refund_total($order);

		return (float) max(0, (float) $order->get_total_refunded() - $attributed_refund_total);
	}

	/**
	 * Return the refunded amount that belongs to the order's product line items, excluding tax.
	 *
	 * @param $order
	 * @return float
	 */
	private static function get_line_item_refund_total( $order ) {

		$line_item_refund_total = 0;

		foreach ($order->get_items() as $item_id => $item) {
			$line_item_refund_total += (float) $order->get_total_refunded_for_item($item_id);
		}

		return (float) $line_item_refund_total;
	}

	/**
	 * Return the refunded amount that belongs to the order's fee lines, excluding tax.
	 *
	 * @param $order
	 * @return float
	 */
	private static function get_fee_refund_total( $order ) {

		$fee_refund_total = 0;

		foreach ($order->get_fees() as $fee_id => $fee) {
			$fee_refund_total += (float) $order->get_total_refunded_for_item($fee_id, 'fee');
		}

		return (float) $fee_refund_total;
	}

	/**
	 * Return the Stripe fee of an order, converted to the order currency.
	 *
	 * WooCommerce Stripe stores the fee and the net amount in the currency of the Stripe
	 * balance the charge settled into (_stripe_currency), not in the order currency. A shop
	 * that charges EUR and settles in AED therefore holds an AED fee on a EUR order, and
	 * subtracting it unconverted under-reports the order value, down to zero on small orders.
	 *
	 * Fee plus net is what Stripe settled for the part of the charge that has not been
	 * refunded, because WooCommerce Stripe adds each refund's balance transaction to both.
	 * Setting that against the part of the order total that has not been refunded gives
	 * the exchange rate Stripe applied to this very charge, with no rate lookup needed.
	 *
	 * Without a currency on the order (gateway versions that didn't store one) the fee is
	 * taken to be in the order currency, as before. If the currencies differ and no rate can
	 * be derived, the fee is left out: a slightly high value is the lesser error.
	 *
	 * @param $order
	 * @return float
	 *
	 * @since 1.69.3
	 */
	private static function get_stripe_fee_in_order_currency( $order ) {

		$stripe_fee = self::get_fee_by_postmeta_key($order, '_stripe_fee');

		if ($stripe_fee <= 0) {
			return 0;
		}

		$stripe_currency = strtoupper((string) $order->get_meta('_stripe_currency', true));

		if ('' === $stripe_currency || strtoupper((string) $order->get_currency()) === $stripe_currency) {
			return $stripe_fee;
		}

		// Without a positive net amount, fee plus net is no settled amount to take a rate
		// from. A missing net would even make the fee look like the whole charge.
		$stripe_net       = (float) $order->get_meta('_stripe_net', true);
		$order_total_left = (float) $order->get_total() - (float) $order->get_total_refunded();

		if ($stripe_net <= 0 || $order_total_left <= 0) {
			return 0;
		}

		return (float) ( $stripe_fee / ( $stripe_fee + $stripe_net ) * $order_total_left );
	}

	/**
	 * Get the fee from the order meta.
	 *
	 * @param $order
	 * @param $postmeta_key
	 * @return float
	 */
	private static function get_fee_by_postmeta_key( $order, $postmeta_key ) {

		$fee = $order->get_meta($postmeta_key, true);

		if (empty($fee)) {
			return 0;
		}

		return (float) $fee;
	}

	/**
	 * Get the order from the order received page.
	 *
	 * Cache the order in a static variable to avoid multiple database queries.
	 *
	 * @return WC_Order|bool
	 */
	public static function pmw_get_current_order() {

		/**
		 * Cache the negative result too. Otherwise every caller repeats the lookup
		 * on pages where the order can't be resolved.
		 *
		 * @since 1.64.1
		 */
		if (self::$order_resolved) {
			return self::$order;
		}

		self::$order_resolved = true;
		self::$order          = self::get_order_from_order_received_page();

		return self::$order;
	}

	/**
	 * PMW uses its own function to check if a visitor is on the order received page.
	 * There are various plugins which modify the checkout workflow and/or the
	 * order received page, which is why we can't only rely on the WooCommerce function.
	 *
	 * @return bool
	 */
	public static function pmw_is_order_received_page() {

		/**
		 * Get cached value if available.
		 *
		 * There are several places in the code where we check if we are on the order received page.
		 * And the function is quite expensive when checking the database, so we cache the result.
		 */
		if (is_bool(self::$pmw_ist_order_received_page)) {
			return self::$pmw_ist_order_received_page;
		}

		// if woocommerce is deactivated return false
		if (!Environment::is_woocommerce_active()) {
			self::$pmw_ist_order_received_page = false;
			return false;
		}

		/**
		 * If a purchase order was created by a shop manager
		 * and the customer is viewing the PO page
		 * don't fire the conversion pixels.
		 * (order key is available in the URL, but
		 * it's not a completed order yet)
		 **/
		if (is_checkout_pay_page()) {
			self::$pmw_ist_order_received_page = false;
			return false;
		}

		// For safety, check if valid order key is in the URL
		self::$pmw_ist_order_received_page = self::is_valid_order_key_in_url();

		return self::$pmw_ist_order_received_page;
	}

	/**
	 * PMW uses its own function to check if a visitor is on the cart page.
	 *
	 * Some checkout builders make is_cart() true on the checkout route as well
	 * (CheckoutWC in Distraction Free Portal mode, for example). Since PMW
	 * evaluates the cart before the checkout, such a shop would classify its
	 * checkout as a cart page and lose every checkout page event. WooCommerce
	 * core resolves the same ambiguity checkout-first in wc_body_class().
	 *
	 * @since 1.65.2
	 *
	 * @return bool
	 */
	public static function pmw_is_cart_page() {

		if (!function_exists('is_cart') || !is_cart()) {
			return false;
		}

		// Only the cart claims this request. Nothing to resolve.
		if (!function_exists('is_checkout') || !is_checkout()) {
			return true;
		}

		/**
		 * Both claim the request. Let the configured pages decide,
		 * with the checkout taking precedence, like WooCommerce core does.
		 */
		$checkout_page_id = wc_get_page_id('checkout');

		if ($checkout_page_id > 0 && is_page($checkout_page_id)) {
			return false;
		}

		$cart_page_id = wc_get_page_id('cart');

		if ($cart_page_id > 0 && is_page($cart_page_id)) {
			return true;
		}

		// Neither page matches. Follow WooCommerce core and resolve to the checkout.
		return false;
	}

	/**
	 * Apply a subscription modifier if one or more subscriptions are in the order.
	 *
	 * @return float|int
	 */
	public static function apply_subscription_multiplier__premium_only( $order_total, $order ) {

		// Return if the multiplier is 1
		if (self::get_subscription_value_multiplier() == 1) {
			return $order_total;
		}

		/**
		 * Find the percentage of the order total that is subscription
		 * and apply the multiplier to that percentage. Then find out
		 * how much the order total would increase by if we added the
		 * subscription percentage to the order total. Then return that
		 * modified order total.
		 *
		 * Doing all of that with relative values makes this function work globally,
		 * no matter if we are processing the order total, subtotal, profit margin, etc.
		 */

		$value_subscription = 0;
		$value_rest         = 0;

		foreach ($order->get_items() as $item) {

			// error log the product type

			$product = $item->get_product();

			// Treat order items whose product no longer exists as non-subscription items.
			if (Product::is_not_wc_product($product)) {
				$value_rest += $item->get_total();
				continue;
			}

			if ($product->get_type() == 'subscription') {
				$value_subscription += $item->get_total();
			} else {
				$value_rest += $item->get_total();
			}
		}

		// To avoid a division by zero error,
		// we return early if the subscription value is zero.
		if (0 === $value_subscription + $value_rest) {
			return $order_total;
		}

		return $order_total * ( ( $value_subscription * self::get_subscription_value_multiplier() + $value_rest ) / ( $value_subscription + $value_rest ) );
	}

	private static function get_subscription_value_multiplier() {
		return Options::get_options_obj()->shop->subscription_value_multiplier;
	}

	/**
	 * Whether the order is a WooCommerce Subscriptions renewal.
	 *
	 * WooCommerce Subscriptions only recognises its own order object: it runs
	 * `is_a($order, 'WC_Abstract_Order')` and, failing that, `wc_get_order()`,
	 * which cannot resolve our neutral wrapper and returns false. The server-side
	 * purchase path hands the payload builders an Order_Data (see
	 * SSP_Purchase_Proxy::handle_purchase_event), so without unwrapping first,
	 * every renewal reported itself as a regular order and the renewal opt-outs
	 * had no effect on that path. @since 1.67.1
	 *
	 * @param \WC_Abstract_Order|\SweetCode\Pixel_Manager\Platforms\Order_Data $order
	 * @return bool
	 */
	public static function is_wcs_renewal_order( $order ) {
		return function_exists('wcs_order_contains_renewal') && wcs_order_contains_renewal(Order_Data::unwrap($order));
	}

	/**
	 * The IDs of the WooCommerce Subscriptions an order created.
	 *
	 * Parent orders only: a renewal order returns an empty array, because the
	 * subscription it pays for is not new.
	 *
	 * @param \WC_Order $order
	 * @return int[]
	 *
	 * @since 1.67.1
	 */
	public static function get_subscription_ids_for_order( $order ) {

		if (!function_exists('wcs_get_subscriptions_for_order')) {
			return [];
		}

		$subscriptions = wcs_get_subscriptions_for_order($order, [ 'order_type' => 'parent' ]);

		if (!is_array($subscriptions) || empty($subscriptions)) {
			return [];
		}

		return array_values(array_map('intval', array_keys($subscriptions)));
	}


	/**
	 * Disable tracking of subscription renewals.
	 *
	 * @return bool
	 */
	public static function track_subscription_renewal() {
		/**
		 * Filters Subscription renewal tracking.
		 *
		 * @since 1.58.5
		 */
		return apply_filters('pmw_subscription_renewal_tracking', true);
	}

	/**
	 * Check if tracking of subscription renewals disabled.
	 *
	 * @return bool
	 */
	public static function do_not_track_subscription_renewal() {
		return !self::track_subscription_renewal();
	}

	public static function get_user_id() {

		if (is_user_logged_in() && !is_admin()) {
			return (string) get_current_user_id();
		}

		// If we're on the purchase confirmation page, we can get the user ID from the order and return it
		if (self::pmw_is_order_received_page()) {
			// Through pmw_get_current_order() so this shares the cached order.
			$order = self::pmw_get_current_order();
			if ($order) {

				$user_id = $order->get_user_id();

				// If the $user_id is 0 (for guest) or 1 (for admin), we return null
				if (0 == $user_id || 1 == $user_id) {
					return null;
				}

				return (string) $user_id;
			}
		}

		return null;
	}

	/**
	 * Fetches the active order statuses.
	 * Initially sets a base array of statuses, then includes all statuses returned by wc_get_is_paid_statuses() function.
	 * The returned array is passed through a WordPress filter 'pmw_active_order_statuses' allowing developers to modify the active statuses.
	 *
	 * @return array Modified array of order statuses.
	 *
	 * @since 1.35.1
	 */
	public static function get_active_order_statuses() {

		$active_order_statuses = [
			'completed',
			'processing',
			'on-hold',
			'pending',
		];

		// Add all statuses from the array returned by wc_get_is_paid_statuses()
		$active_order_statuses = array_merge($active_order_statuses, wc_get_is_paid_statuses());

		// Remove duplicates
		$active_order_statuses = array_unique($active_order_statuses);

		/**
		 * Filters Active order statuses.
		 *
		 * @since 1.58.5
		 */
		return apply_filters('pmw_active_order_statuses', $active_order_statuses);
	}

	/**
	 * Retrieves the active order statuses with the 'wc-' prefix for each status.
	 *
	 * This method first invokes the `get_active_order_statuses` method to get the list of active order statuses.
	 * Then it returns the array of these statuses prefixed with 'wc-' which is suitable for database operations in WooCommerce.
	 *
	 * @return array An array of active order statuses prefixed with 'wc-'.
	 *
	 * @see   Helpers::get_active_order_statuses
	 *
	 * @since 1.35.1
	 */
	public static function get_active_order_statuses_for_db_queries() {

		$active_order_statuses = self::get_active_order_statuses();

		// Add the 'wc-' prefix to each status
		return array_map(function ( $status ) {
			return 'wc-' . $status;
		}, $active_order_statuses);
	}

	public static function has_order_been_partially_refunded( $order ) {

		$refunded_amount = $order->get_total_refunded();

		if (0 < $refunded_amount) {
			return true;
		}

		return false;
	}

	public static function view_item_list_trigger_settings() {

		$settings = [
			'test_mode'          => false,
			'background_color'   => 'green',
			'opacity'            => 0.5,
			'repeat'             => true,
			'timeout'            => 1000,
			'threshold'          => 0.8,
			// Group the products detected in a list into one event per list
			'batching'           => true,
			'batch_idle_timeout' => 1500,
			'batch_max_wait'     => 10000,
			'batch_max_items'    => 25,
		];

		$settings = apply_filters_deprecated('wooptpm_view_item_list_trigger_settings', [ $settings ], '1.13.0', 'pmw_view_item_list_trigger_settings');
		$settings = apply_filters_deprecated('wpm_view_item_list_trigger_settings', [ $settings ], '1.31.2', 'pmw_view_item_list_trigger_settings');

		/**
		 * Filters View item list trigger settings.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_view_item_list_trigger_settings', $settings);
	}

	// https://woocommerce.github.io/code-reference/files/woocommerce-includes-class-wc-order.html#source-view.364
	public static function get_order_paid_statuses() {

		// WooCommerce can be active without having loaded, for example after an
		// incomplete update. Calling its function then would be a fatal error that
		// takes the whole site down, so fall back to WooCommerce's own defaults.
		if (function_exists('wc_get_is_paid_statuses')) {
			$statuses = wc_get_is_paid_statuses();
		} else {
			$statuses = (array) apply_filters('woocommerce_order_is_paid_statuses', [ 'processing', 'completed' ]);
		}

		// Add additional custom order statuses to trigger the Measurement Protocol purchase hit
		return apply_filters_deprecated('wpm_register_custom_order_confirmation_statuses', [ $statuses ], '1.30.3', 'Use the woocommerce_order_is_paid_statuses filter instead');
	}

	public static function is_woocommerce_session_active() {

		// If WC() not available, return false
		if (!function_exists('WC')) {
			return false;
		}

		// If WC()->session not available, return false
		if (!isset(WC()->session)) {
			return false;
		}

		// If WC()->session->has_session() not available, return false
		if (!method_exists(WC()->session, 'has_session')) {
			return false;
		}

		return WC()->session->has_session();
	}

	/**
	 * Take this request out of the WooCommerce session's write path.
	 *
	 * WooCommerce counts an admin-ajax request as a frontend request, so it
	 * loads the cart and the session into memory and arms
	 * WC_Session_Handler::save_data() on shutdown. That save rewrites the
	 * entire session row, cart included, from the snapshot the request read
	 * when it started.
	 *
	 * A tracking request that only reads therefore carries a loaded weapon: it
	 * runs at the same moment as the shopper's own add to cart, and if
	 * anything in the same request marks the session dirty - a currency
	 * switcher, a geo plugin, a payment gateway, WooCommerce's own customer
	 * save - the shutdown write reverts the item that was added in between.
	 * The shopper sees the product silently disappear from the cart.
	 *
	 * Removing both shutdown saves makes that impossible: this request can
	 * read the cart, but it can no longer persist anything. Whatever another
	 * plugin wanted to store is written again on the next request that has a
	 * reason to.
	 *
	 * @return void
	 *
	 * @since 1.69.0
	 */
	public static function keep_woocommerce_session_read_only() {

		if (!function_exists('WC')) {
			return;
		}

		if (isset(WC()->session) && is_object(WC()->session)) {
			remove_action('shutdown', [ WC()->session, 'save_data' ], 20);
		}

		if (isset(WC()->customer) && is_object(WC()->customer)) {
			remove_action('shutdown', [ WC()->customer, 'save' ], 10);
		}
	}

	/**
	 * Bring the cart held in this request's session snapshot up to date.
	 *
	 * For the one endpoint that has to write to the session, the snapshot it
	 * writes must not be the cart as it looked when the request started. A
	 * shopper can add a product while the request is in flight, and since
	 * WooCommerce serializes the whole session in one go, our write would put
	 * the older cart back.
	 *
	 * Re-reading the stored row costs one query and closes that window. The
	 * object cache entry is dropped first, because a request that loaded the
	 * session at its start holds the old value there.
	 *
	 * Skipped where WooCommerce saves only the keys a request changed
	 * (WooCommerce 11.4+, woocommerce/woocommerce#46483). There our write no
	 * longer touches the cart, and refreshing it would make the cart one of
	 * our changes, so a product added between the refresh and our save would
	 * be dropped again.
	 *
	 * @return void
	 *
	 * @since 1.69.0
	 */
	public static function refresh_cart_in_session_snapshot() {

		if (!self::is_woocommerce_session_active()) {
			return;
		}

		$session = WC()->session;

		if (self::session_saves_only_changed_keys($session)) {
			return;
		}

		if (!method_exists($session, 'get_session') || !method_exists($session, 'get_customer_id')) {
			return;
		}

		$customer_id = $session->get_customer_id();

		if (empty($customer_id)) {
			return;
		}

		if (class_exists('WC_Cache_Helper') && defined('WC_SESSION_CACHE_GROUP')) {
			wp_cache_delete(
				\WC_Cache_Helper::get_cache_prefix(WC_SESSION_CACHE_GROUP) . $customer_id,
				WC_SESSION_CACHE_GROUP
			);
		}

		$stored = $session->get_session($customer_id);

		if (!is_array($stored)) {
			return;
		}

		// The totals belong to the cart they were calculated from, so they
		// travel together. WC_Session::set() compares before it writes, so an
		// unchanged cart does not mark the session dirty here.
		foreach ([ 'cart', 'cart_totals' ] as $key) {

			if (!array_key_exists($key, $stored)) {
				continue;
			}

			$session->set($key, maybe_unserialize($stored[ $key ]));
		}
	}

	/**
	 * Whether the session handler merges a request's changed keys into the
	 * stored session instead of overwriting it with the whole snapshot.
	 *
	 * Both WooCommerce handlers do since 11.4. A third-party handler that does
	 * not extend them keeps the full overwrite, so it is treated as not merging.
	 *
	 * @param object $session The WooCommerce session.
	 *
	 * @return bool
	 *
	 * @since 1.71.1
	 */
	private static function session_saves_only_changed_keys( $session ) {

		if (!class_exists('Automattic\WooCommerce\Internal\Session\SessionDataWriter')) {
			return false;
		}

		return $session instanceof \WC_Session_Handler
			|| $session instanceof \Automattic\WooCommerce\StoreApi\SessionHandler;
	}

	public static function get_value_from_woocommerce_session( $key, $default = null ) {

		if (!self::is_woocommerce_session_active()) {
			return $default;
		}

		return WC()->session->get($key, $default);
	}

	public static function get_transient_identifiers_from_session() {

		if (self::$transient_identifiers) {
			return self::$transient_identifiers;
		}

		self::$transient_identifiers = self::get_value_from_woocommerce_session(self::get_transient_identifiers_key(), []);

		return (array) self::$transient_identifiers;
	}

	public static function get_transient_identifiers_key() {
		return 'pmw_transient_session_identifiers';
	}

	/**
	 * Retrieves the custom order parameters for a given order.
	 *
	 * This function retrieves and returns the custom order parameters for a given order.
	 * These parameters are filtered through the 'pmw_custom_order_parameters'
	 * filter hook which allows for modification or addition of custom parameters.
	 *
	 * @param $order
	 * @return array
	 *
	 * @since 1.44.0
	 */
	public static function get_custom_order_parameters( $order ) {
		/**
		 * Filters Custom order parameters.
		 *
		 * @since 1.58.5
		 */
		return (array) apply_filters('pmw_custom_order_parameters', [], Order_Data::unwrap($order));
	}

	/**
	 * Retrieves the custom order item parameters for a given order item.
	 * This function retrieves and returns the custom order item parameters for a given order item.
	 * These parameters are filtered through the 'pmw_custom_order_item_parameters' filter hook
	 * which allows for modification or addition of custom parameters.
	 *
	 * @param $order_item
	 * @param $order
	 * @return array
	 *
	 * @since 1.44.0
	 */
	public static function get_custom_order_item_parameters( $order_item, $order ) {
		/**
		 * Filters Custom order item parameters.
		 *
		 * @since 1.58.5
		 */
		return (array) apply_filters('pmw_custom_order_item_parameters', [], $order_item, Order_Data::unwrap($order));
	}

	/**
	 * Get the order value in the base currency.
	 *
	 * This function is used to convert the order value to the base currency
	 * when using multi-currency plugins.
	 *
	 * @param $order
	 * @param $value
	 * @return float|mixed
	 *
	 * @since 1.49.0
	 */
	public static function get_order_value_in_base_currency( $order, $value ) {

		// Price Based on Country for WooCommerce
		// https://wordpress.org/plugins/woocommerce-product-price-based-on-countries/
		// If the meta key _wcpbc_base_exchange_rate exists, then we need to use the base exchange rate
		$base_exchange_rate = $order->get_meta('_wcpbc_base_exchange_rate');
		if ($base_exchange_rate && is_numeric($base_exchange_rate) && $base_exchange_rate > 0) {
			return $value * $base_exchange_rate;
		}

		// For WOOCS - WooCommerce Currency Switcher
		// https://wordpress.org/plugins/woocommerce-currency-switcher/
		// TODO - Untested, please report if this doesn't work
		$woocs_order_rate = $order->get_meta('_woocs_order_rate');
		if ($woocs_order_rate && is_numeric($woocs_order_rate) && $woocs_order_rate > 0) {
			return $value / $woocs_order_rate;
		}

		// For Currency Switcher for WooCommerce by WP Wham
		// https://wordpress.org/plugins/currency-switcher-woocommerce/
		// TODO - Untested, please report if this doesn't work
		$alg_currency_rate = $order->get_meta('_alg_wc_currency_rate');
		if ($alg_currency_rate && is_numeric($alg_currency_rate) && $alg_currency_rate > 0) {
			return $value / $alg_currency_rate;
		}

		// For Aelia Currency Switcher
		// https://aelia.co/shop/currency-switcher-woocommerce/
		// TODO - Untested, please report if this doesn't work
		$aelia_order_exchange_rate = $order->get_meta('_order_exchange_rate');
		if ($aelia_order_exchange_rate && is_numeric($aelia_order_exchange_rate) && $aelia_order_exchange_rate > 0) {
			return $value / $aelia_order_exchange_rate;
		}

		return $value;
	}
}
