<?php

namespace SweetCode\Pixel_Manager;

use SweetCode\Pixel_Manager\Pixels\Google\Google_DMA;
use SweetCode\Pixel_Manager\Pixels\Google\Google_MP_GA4;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Reconciles the refund state of the destinations when WooCommerce deletes a
 * refund that was already reported.
 *
 * Gateways create the WooCommerce refund as soon as the gateway accepts the
 * request, so the refund hooks fire and the refund goes out. Some gateway
 * refunds fail or are canceled later, and the gateway then deletes the
 * WooCommerce refund again: Stripe does it from its refund webhook,
 * WooPayments from its failed refund handler, and a shop manager can delete
 * a refund by hand.
 *
 * Nothing listens to woocommerce_refund_deleted here on purpose. Stripe
 * passes its own re_ ID to that hook instead of the WooCommerce refund ID,
 * and WooPayments does not fire it at all. The refund is captured right
 * before it is deleted instead, where every path still has the WooCommerce
 * refund with its parent order and amount, and handled once the deletion went
 * through.
 *
 * What each destination can do about it differs, see the handlers:
 * Google_MP_GA4::handle_deleted_refund() and Google_DMA::handle_deleted_refund().
 *
 * @since 1.71.1
 */
class Refund_Deletions {

	private static $instance;

	/**
	 * Refunds about to be deleted in this request, keyed by refund ID.
	 *
	 * @var array<int, array{order_id: int, amount: float}>
	 */
	private static $pending = [];

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		// WooCommerce 8.1 and newer, both order storages. Runs last, so a
		// filter that vetoes the deletion has already had its say.
		add_filter('woocommerce_pre_delete_order_refund', [ __CLASS__, 'capture_refund' ], PHP_INT_MAX, 2);

		// Older WooCommerce versions, which only store orders as posts.
		add_action('before_delete_post', [ __CLASS__, 'capture_refund_post' ], 10, 1);

		add_action('woocommerce_delete_order_refund', [ __CLASS__, 'handle_deleted_refund' ], 10, 1);
	}

	/**
	 * Whether any destination this class reconciles is active.
	 *
	 * @return bool
	 */
	public static function is_active() {
		return Options::is_ga4_mp_active() || self::is_google_dma_active();
	}

	private static function is_google_dma_active() {
		return Options::is_google_ads_dm_active();
	}

	/**
	 * Remembers a refund right before WooCommerce deletes it.
	 *
	 * @param mixed $check  Null to go ahead with the deletion.
	 * @param mixed $refund The refund about to be deleted.
	 * @return mixed The unchanged $check.
	 */
	public static function capture_refund( $check, $refund ) {

		if (null === $check && $refund instanceof \WC_Order_Refund) {
			self::remember($refund);
		}

		return $check;
	}

	/**
	 * Remembers a refund stored as a post right before it is deleted.
	 *
	 * @param int $post_id The post ID.
	 * @return void
	 */
	public static function capture_refund_post( $post_id ) {

		if (isset(self::$pending[(int) $post_id]) || 'shop_order_refund' !== get_post_type($post_id)) {
			return;
		}

		$refund = wc_get_order($post_id);

		if ($refund instanceof \WC_Order_Refund) {
			self::remember($refund);
		}
	}

	/**
	 * Hands a deleted refund to the destinations that may have reported it.
	 *
	 * @param int $refund_id The WooCommerce refund ID.
	 * @return void
	 */
	public static function handle_deleted_refund( $refund_id ) {

		$refund_id = (int) $refund_id;

		if (!isset(self::$pending[$refund_id])) {
			return;
		}

		$deleted = self::$pending[$refund_id];
		unset(self::$pending[$refund_id]);

		// Stripe deletes the refund without touching the parent order, so its
		// refund totals can still be cached for this request.
		self::flush_refund_caches($deleted['order_id']);

		$order = wc_get_order($deleted['order_id']);

		if (!$order instanceof \WC_Order) {
			return;
		}

		if (Options::is_ga4_mp_active()) {
			Google_MP_GA4::handle_deleted_refund($order, $refund_id, $deleted['amount']);
		}

		if (self::is_google_dma_active()) {
			Google_DMA::handle_deleted_refund($order, $refund_id);
		}
	}

	private static function remember( $refund ) {

		$parent_id = (int) $refund->get_parent_id();

		if (!$refund->get_id() || !$parent_id) {
			return;
		}

		self::$pending[(int) $refund->get_id()] = [
			'order_id' => $parent_id,
			'amount'   => abs((float) $refund->get_total()),
		];
	}

	private static function flush_refund_caches( $order_id ) {

		if (!class_exists('WC_Cache_Helper')) {
			return;
		}

		$prefix = \WC_Cache_Helper::get_cache_prefix('orders');

		foreach ([ 'refund_ids', 'total_refunded', 'total_tax_refunded', 'total_qty_refunded' ] as $key) {
			wp_cache_delete($prefix . $key . $order_id, 'orders');
		}
	}
}
