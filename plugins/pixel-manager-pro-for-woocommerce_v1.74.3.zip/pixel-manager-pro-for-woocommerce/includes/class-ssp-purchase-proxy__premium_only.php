<?php
/**
 * SSP Server-Side Event Proxy
 *
 * Routes server-side conversion events (purchase + GA4 refunds) through the
 * SweetCode Cloud (SSP) proxy instead of sending them directly to each ad
 * platform / analytics provider. Collects event data from all active S2S
 * classes, bundles them into a single HTTP request, and sends it to the SSP
 * /v1/sync/purchase-events endpoint.
 *
 * Falls back to direct per-platform sends if the SSP request fails.
 *
 * @since 1.57.0
 */

namespace SweetCode\Pixel_Manager;

use SweetCode\Pixel_Manager\Admin\Environment;
use SweetCode\Pixel_Manager\Platforms\Platform_Manager;
use SweetCode\Pixel_Manager\Pixels\Facebook\Facebook_CAPI;
use SweetCode\Pixel_Manager\Pixels\Google\Google_DMA;
use SweetCode\Pixel_Manager\Pixels\Google\Google_MP_GA4;
use SweetCode\Pixel_Manager\Pixels\TikTok\TikTok_EAPI;
use SweetCode\Pixel_Manager\Pixels\Pinterest\Pinterest_APIC;
use SweetCode\Pixel_Manager\Pixels\Snapchat\Snapchat_CAPI;
use SweetCode\Pixel_Manager\Pixels\Reddit\Reddit_CAPI;
use SweetCode\Pixel_Manager\Pixels\OpenAI\OpenAI_CAPI;
use SweetCode\Pixel_Manager\Pixels\Nextdoor\Nextdoor_CAPI;
use SweetCode\Pixel_Manager\Pixels\Spotify\Spotify_CAPI;
use SweetCode\Pixel_Manager\Pixels\AppLovin\AppLovin_CAPI;
use SweetCode\Pixel_Manager\Pixels\Bing\Bing_CAPI;
use SweetCode\Pixel_Manager\Pixels\Mixpanel\Mixpanel_API;
use SweetCode\Pixel_Manager\Pixels\Klaviyo\Klaviyo_API;

defined('ABSPATH') || exit; // Exit if accessed directly

class SSP_Purchase_Proxy {

	/**
	 * Outcome of one dispatch attempt against the SSP.
	 *
	 * The distinction that matters is REJECTED vs UNKNOWN. Both mean "no
	 * success reply", but only REJECTED means the SSP provably forwarded
	 * nothing, which is what makes the direct-send fallback safe. Collapsing
	 * the two into a single false was the defect: PMW's POST blocks for 15s
	 * while an SSP fan-out that hits one slow destination runs to ~33s (10s per
	 * attempt, three attempts, backoff), so a perfectly healthy dispatch times
	 * out here and the fallback re-sends every destination directly. Each
	 * platform then receives the purchase twice.
	 *
	 * REJECTED is reserved for evidence, never for the absence of it: a token
	 * the SSP refused, a 4xx decided before any destination was touched, or a
	 * status probe that answered and had no record of the bundle. A probe that
	 * could not be answered at all stays UNKNOWN, because "we could not ask"
	 * and "we asked and nothing went out" are not the same fact, and GA4 uses
	 * the difference to decide whether a direct send can be duplicate-free
	 * (sharpened in 1.68.0; before that an unanswerable probe also counted
	 * as REJECTED).
	 *
	 * @since 1.66.0
	 */
	const DISPATCH_OK       = 'dispatched';
	const DISPATCH_REJECTED = 'rejected';
	const DISPATCH_UNKNOWN  = 'unknown';

	/**
	 * Action Scheduler hook for the single retry of a bundle whose fate we
	 * could not establish. The SSP recognises the retry by its dispatch key
	 * and answers from its record instead of delivering twice, so the retry
	 * is safe even when the first attempt did arrive after all.
	 *
	 * @since 1.68.0
	 */
	const RETRY_HOOK = 'pmw_ssp_dispatch_retry';

	/**
	 * How long to wait before that retry. Long enough for a transient network
	 * fault to clear, short enough to stay well inside GA4's 72h backdating
	 * window so the purchase still lands on its real date.
	 *
	 * @since 1.68.0
	 */
	const RETRY_DELAY_SECONDS = 15 * MINUTE_IN_SECONDS;

	/**
	 * Order meta listing the bundles that already had their one retry.
	 *
	 * @since 1.68.0
	 */
	const RETRY_MARKER_KEY = '_pmw_ssp_dispatch_retried';

	private static $instance;

	/**
	 * Map of SSP destination keys to their S2S class names.
	 *
	 * @var array<string, string>
	 */
	private static $destination_map = [
		'facebook'   => Facebook_CAPI::class,
		'tiktok'     => TikTok_EAPI::class,
		'pinterest'  => Pinterest_APIC::class,
		'snapchat'   => Snapchat_CAPI::class,
		'reddit'     => Reddit_CAPI::class,
		'openai'     => OpenAI_CAPI::class,
		'nextdoor'   => Nextdoor_CAPI::class,
		'bing'       => Bing_CAPI::class,
		'google_ga4' => Google_MP_GA4::class,
		'google_dma' => Google_DMA::class,
		'mixpanel'   => Mixpanel_API::class,
		'klaviyo'    => Klaviyo_API::class,
		'spotify'    => Spotify_CAPI::class,
		'applovin'   => AppLovin_CAPI::class,
	];

	/**
	 * Map of SSP destination keys to the Options helper that decides
	 * whether the integration is currently active.
	 *
	 * @var array<string, string>
	 */
	private static $active_checks = [
		'facebook'   => 'is_facebook_capi_active',
		'tiktok'     => 'is_tiktok_eapi_active',
		'pinterest'  => 'is_pinterest_apic_active',
		'snapchat'   => 'is_snapchat_capi_active',
		'reddit'     => 'is_reddit_capi_active',
		'openai'     => 'is_openai_capi_active',
		'nextdoor'   => 'is_nextdoor_capi_active',
		'bing'       => 'is_bing_capi_active',
		'google_ga4' => 'is_ga4_mp_active',
		'google_dma' => 'is_google_ads_dm_active',
		'mixpanel'   => 'is_mixpanel_ingestion_api_active',
		// Events API configured AND standalone mode. With the Klaviyo plugin
		// installed, Klaviyo produces Placed Order itself, so no purchase leaves
		// here in takeover or gap-fill mode.
		'klaviyo'    => 'is_klaviyo_purchase_dispatch_active',
		'spotify'    => 'is_spotify_capi_active',
		'applovin'   => 'is_applovin_capi_active',
	];

	/**
	 * Destination key => S2S class, for code outside the proxy that keeps
	 * per-destination state under the same keys.
	 *
	 * @return array<string, string>
	 * @since 1.71.1
	 */
	public static function get_destination_map() {
		return self::$destination_map;
	}

	/**
	 * Whether the shop has configured this destination's server-side API,
	 * regardless of whether purchases go through the SSP or directly.
	 *
	 * @param string $key Destination key from $destination_map.
	 *
	 * @return bool
	 * @since 1.71.1
	 */
	public static function is_destination_configured( $key ) {
		return isset( self::$active_checks[ $key ] ) && (bool) call_user_func( [ Options::class, self::$active_checks[ $key ] ] );
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Hook into the WooCommerce order status hooks that the S2S classes use,
	 * plus the WooCommerce refund hooks (currently only GA4 MP contributes
	 * refund payloads, but the bundle structure is forward-compatible).
	 *
	 * We register with a lower priority (20) so that identifier capture
	 * and per-class default handlers (hooked at priority 10) complete first.
	 * The purchase hooks only queue the dispatch; the queue keeps that order
	 * when it runs at the end of the request.
	 *
	 * @since 1.57.0
	 */
	private function register_hooks() {

		if ( ! Environment::is_woocommerce_active() ) {
			return;
		}

		foreach ( S2S::get_purchase_trigger_hooks() as $hook ) {
			add_action( $hook, [ $this, 'defer_purchase_event' ], 20 );
		}

		// Refund hooks (priority 20 so per-class handlers can early-return at priority 10).
		// @since 1.58.12
		add_action( 'woocommerce_order_fully_refunded', [ $this, 'handle_full_refund_event' ], 20, 2 );
		add_action( 'woocommerce_order_partially_refunded', [ $this, 'handle_partial_refund_event' ], 20, 2 );

		// @since 1.68.0
		add_action( self::RETRY_HOOK, [ $this, 'retry_dispatch' ], 10, 4 );
	}

	/**
	 * Trigger-hook callback: queue the bundled purchase dispatch for the end of the request.
	 *
	 * The gateway that marked the order paid may still be writing order meta
	 * when the trigger hooks fire (WooCommerce PayPal Payments stores the
	 * transaction fee only after payment_complete() returns), and the marketing
	 * value deducts that fee. See S2S::$deferred_purchase_dispatches.
	 *
	 * @param int|\WC_Order $order_id_or_order Order ID or order object.
	 * @return void
	 * @since 1.66.1
	 */
	public function defer_purchase_event( $order_id_or_order ) {
		S2S::defer_purchase_dispatch( $order_id_or_order, [ $this, 'handle_purchase_event' ], self::class );
	}

	/**
	 * Handle a purchase event by collecting data from all active CAPI classes
	 * and sending them bundled to the SSP.
	 *
	 * @param int|\WC_Order $order_id_or_order Order ID or order object.
	 *
	 * @since 1.57.0
	 */
	public function handle_purchase_event( $order_id_or_order ) {

		$order = $order_id_or_order instanceof \WC_Order
			? $order_id_or_order
			: wc_get_order( $order_id_or_order );

		// Hand the platform-neutral order surface to the payload builders
		// (docs/PLATFORM-CONTRACT.md section 3). On WooCommerce this wraps
		// the WC_Order one-to-one; FluentCart/SureCart providers build the
		// same surface from their own orders.
		$order = Platform_Manager::get_provider()->get_order_data( $order );

		if ( ! $order ) {
			return;
		}

		// Check if the customer's IP is on the exclusion list
		if ( self::is_order_ip_excluded( $order ) ) {
			Logger::debug( 'SSP Purchase Proxy: Skipping purchase event for order ' . $order->get_id() . ' — IP is on exclusion list' );
			return;
		}

		$destinations = $this->collect_destination_payloads( $order );

		if ( empty( $destinations ) ) {
			return;
		}

		$payload = [
			'event'        => 'purchase',
			'order_id'     => $order->get_id(),
			'destinations' => $destinations,
		];

		$dispatch_key = self::build_dispatch_key( $payload );
		$outcome      = $this->dispatch( $payload, $order, $dispatch_key );

		if ( self::DISPATCH_OK === $outcome ) {
			$this->mark_hits_sent( $order, array_keys( $destinations ) );
		} else {
			// Fallback: send directly to each platform
			$this->fallback_direct_send( $order, array_keys( $destinations ), $outcome, $dispatch_key );
		}
	}

	/**
	 * Dispatch a bundle to the SSP and resolve what actually happened.
	 *
	 * Wraps send_to_ssp() with the one thing the raw call cannot do: tell a
	 * dispatch that failed from a dispatch whose *answer* was lost. On an
	 * inconclusive attempt it asks the SSP directly, keyed on the dispatch key
	 * the POST carried, and only reports failure when the SSP confirms it
	 * forwarded nothing (or cannot be reached at all, which is where we were
	 * before this existed).
	 *
	 * @param array     $payload
	 * @param \WC_Order $order
	 * @param string    $dispatch_key The bundle's key, when the caller needs to
	 *                                keep it (a retry has to ask about this
	 *                                exact attempt later). Built here otherwise.
	 *
	 * @return string One of the DISPATCH_* constants. OK means the SSP has the
	 *                event; REJECTED and UNKNOWN both send the caller into the
	 *                fallback, and they differ in what the fallback may do
	 *                there (see fallback_direct_send).
	 * @since 1.66.0
	 */
	private function dispatch( $payload, $order, $dispatch_key = '' ) {

		$dispatch_key = empty( $dispatch_key ) ? self::build_dispatch_key( $payload ) : $dispatch_key;
		$result       = $this->send_to_ssp( $payload, $order, $dispatch_key );

		if ( self::DISPATCH_UNKNOWN === $result ) {
			$result = $this->resolve_ambiguous_dispatch( $dispatch_key, $payload );
		}

		return $result;
	}

	/**
	 * Ask the SSP whether it already dispatched this bundle.
	 *
	 * The SSP records the dispatch key before it starts fanning out, so a
	 * "no" is trustworthy: nothing went out and the caller is free to fall
	 * back. A "yes" means at least one destination already has the event, and
	 * sending it again would produce the duplicate server-side event this whole
	 * mechanism exists to prevent.
	 *
	 * A probe that cannot be answered (SSP unreachable, malformed reply) stays
	 * UNKNOWN. The paid-channel fallback runs on that too, because for those a
	 * possible duplicate beats a lost conversion and their per-order dedup id
	 * collapses the copy anyway. GA4 has no such id on the Measurement
	 * Protocol, so it treats UNKNOWN as "do not send" and takes the scheduled
	 * retry instead.
	 *
	 * @param string $dispatch_key
	 * @param array  $payload Used for log context only.
	 *
	 * @return string One of the DISPATCH_* constants.
	 * @since 1.66.0
	 */
	private function resolve_ambiguous_dispatch( $dispatch_key, $payload ) {

		$sync_token = Options::get_ssp_sync_token();

		// No key and no token both mean the POST never carried anything the SSP
		// could have recorded, which is the same provable nothing a 4xx is.
		if ( empty( $dispatch_key ) || empty( $sync_token ) ) {
			return self::DISPATCH_REJECTED;
		}

		$response = wp_remote_get(
			add_query_arg( 'key', rawurlencode( $dispatch_key ), Options::get_ssp_dispatch_status_url() ),
			[
				'headers' => [ 'Authorization' => 'Bearer ' . $sync_token ],
				// Deliberately short. This is a single KV lookup on the SSP,
				// and it runs after a request that already blocked for 15s, and
				// the purchase hook can be running inside the customer's own
				// checkout request.
				'timeout' => 5,
			]
		);

		if ( is_wp_error( $response ) ) {
			Logger::warning( 'SSP Purchase Proxy: Dispatch status probe failed: ' . $response->get_error_message() );
			return self::DISPATCH_UNKNOWN;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== wp_remote_retrieve_response_code( $response ) || empty( $body['success'] ) ) {
			Logger::warning( 'SSP Purchase Proxy: Dispatch status probe returned ' . wp_remote_retrieve_response_code( $response ) . ', falling back.' );
			return self::DISPATCH_UNKNOWN;
		}

		if ( ! empty( $body['data']['dispatched'] ) ) {
			Logger::info(
				'SSP Purchase Proxy: ' . $payload['event'] . ' for order ' . $payload['order_id']
				. ' was already dispatched by the SSP (' . $dispatch_key . '); skipping the direct fallback.'
			);
			return self::DISPATCH_OK;
		}

		Logger::info(
			'SSP Purchase Proxy: SSP has no record of ' . $dispatch_key . '; the dispatch did not happen.'
		);

		return self::DISPATCH_REJECTED;
	}

	/**
	 * Build the dispatch key for one bundle.
	 *
	 * Identifies a (event, order, refund, destination set) tuple, so a retry of
	 * the same bundle is recognised while a genuinely different bundle for the
	 * same order (a later hook covering the destinations a partial dispatch
	 * missed) gets its own key and is not wrongly suppressed.
	 *
	 * Kept inside the SSP's accepted charset ([A-Za-z0-9._:-]) and well under
	 * its 128-character limit.
	 *
	 * @param array $payload
	 *
	 * @return string
	 * @since 1.66.0
	 */
	private static function build_dispatch_key( $payload ) {

		$parts = [
			isset( $payload['event'] ) ? $payload['event'] : 'purchase',
			(string) $payload['order_id'],
		];

		if ( ! empty( $payload['refund_id'] ) ) {
			$parts[] = 'r' . (int) $payload['refund_id'];
		}

		$destination_keys = array_keys( $payload['destinations'] );
		sort( $destination_keys );
		$parts[] = substr( md5( implode( ',', $destination_keys ) ), 0, 8 );

		return preg_replace( '/[^A-Za-z0-9._:-]/', '', implode( '-', $parts ) );
	}

	/**
	 * Iterate over all active CAPI classes and collect their event data.
	 *
	 * Each class's build_ssp_purchase_event_data() returns null if the order
	 * shouldn't be processed for that platform (already sent, missing config, etc.).
	 *
	 * @param \WC_Order $order
	 *
	 * @return array<string, array> Keyed by destination name.
	 * @since 1.57.0
	 */
	private function collect_destination_payloads( $order ) {

		$destinations = [];

		foreach ( self::$destination_map as $key => $class ) {

			// Check if the integration is active
			if ( ! self::is_destination_active( $key, $class ) ) {
				continue;
			}

			// Check if the purchase hit was already sent for this order
			$hit_key = $class::get_purchase_hit_key();
			if ( $order->get_meta( $hit_key ) ) {
				continue;
			}

			$event_data = $class::build_ssp_purchase_event_data( $order );

			if ( $event_data ) {
				$destinations[ $key ] = $event_data;
			}
		}

		return $destinations;
	}

	/**
	 * Send the bundled purchase payload to the SSP.
	 *
	 * Uses a blocking request so we can determine success/failure
	 * and decide whether to fall back to direct sends.
	 *
	 * @param array     $payload
	 * @param \WC_Order $order        The order being processed (used to source the SSP session_id).
	 * @param string    $dispatch_key Idempotency key for this bundle, sent so the
	 *                                SSP can recognise a retry (see build_dispatch_key).
	 *
	 * @return string One of the DISPATCH_* constants. UNKNOWN means the SSP may
	 *                or may not have forwarded the event; see resolve_ambiguous_dispatch().
	 * @since 1.57.0
	 */
	private function send_to_ssp( $payload, $order, $dispatch_key = '' ) {

		$sync_token = Options::get_ssp_sync_token();

		if ( empty( $sync_token ) ) {
			Logger::warning( 'SSP Purchase Proxy: No sync token available.' );
			return self::DISPATCH_REJECTED;
		}

		$url = Options::get_ssp_purchase_events_url();

		// SSP session_id, used by the SSP to look up the customer's real
		// client IP (cached from browser PMW events) and inject it into
		// outgoing Facebook user_data when this server can't resolve one.
		// Prefer the value persisted on the order (captured from the real
		// browser at checkout time) over the live WC session value, which
		// may be empty or belong to a different visitor when the purchase
		// hook fires from a webhook/cron context.
		// @since 1.58.10
		$session_id = $order->get_meta( 'pmw_ssp_session_id', true );
		if ( empty( $session_id ) ) {
			$session_id = Options::get_ssp_session_id();
		}

		// PMW build metadata (version, distro, tier) is sent on the
		// configuration sync and persisted on the SSP domain row, so per-event
		// headers and a custom User-Agent are no longer needed here.
		// @since 1.58.12
		$headers = [
			'Authorization' => 'Bearer ' . $sync_token,
			'Content-Type'  => 'application/json',
		];

		if ( ! empty( $session_id ) ) {
			$headers['X-SSP-Session'] = $session_id;
		}

		// Lets the SSP recognise a retry of this exact bundle and answer it
		// from its record instead of dispatching a second time.
		// @since 1.66.0
		if ( ! empty( $dispatch_key ) ) {
			$headers['X-SSP-Dispatch-Key'] = $dispatch_key;
		}

		$response = wp_remote_post(
			$url,
			[
				'headers'  => $headers,
				'body'     => wp_json_encode( $payload ),
				'timeout'  => 15,
				'blocking' => true,
			]
		);

		// A transport error is the ambiguous case that matters most: a timeout
		// fires here after 15s while the SSP fan-out may still be delivering,
		// or may already have delivered everything.
		if ( is_wp_error( $response ) ) {
			Logger::warning( 'SSP Purchase Proxy: Request failed — ' . $response->get_error_message() );
			return self::DISPATCH_UNKNOWN;
		}

		$code = wp_remote_retrieve_response_code( $response );

		if ( 200 !== $code ) {
			$body = wp_remote_retrieve_body( $response );
			Logger::warning( 'SSP Purchase Proxy: HTTP ' . $code . ' — ' . $body );

			// 4xx is the SSP refusing the bundle up front (bad token, inactive
			// subscription, quota, malformed payload), all decided before any
			// destination is touched, so nothing was forwarded. A 5xx or a
			// gateway error can land after deliveries have gone out.
			return ( $code >= 400 && $code < 500 ) ? self::DISPATCH_REJECTED : self::DISPATCH_UNKNOWN;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body['success'] ) ) {
			Logger::warning( 'SSP Purchase Proxy: Unexpected response — ' . wp_json_encode( $body ) );
			return self::DISPATCH_UNKNOWN;
		}

		Logger::info(
			'SSP Purchase Proxy: Successfully dispatched ' . ( isset( $payload['event'] ) ? $payload['event'] : 'event' )
			. ' for order ' . $payload['order_id']
			. ' (' . ( isset( $body['data']['dispatched'] ) ? $body['data']['dispatched'] : '?' ) . ' destinations)'
			. ( empty( $body['data']['deduplicated'] ) ? '' : ' [already dispatched under ' . $dispatch_key . ']' )
		);

		return self::DISPATCH_OK;
	}

	/**
	 * Mark order meta for each destination that was successfully dispatched
	 * through the SSP.
	 *
	 * @param \WC_Order    $order
	 * @param array<string> $destination_keys
	 *
	 * @since 1.57.0
	 */
	private function mark_hits_sent( $order, $destination_keys ) {

		foreach ( $destination_keys as $key ) {
			if ( isset( self::$destination_map[ $key ] ) ) {
				$class   = self::$destination_map[ $key ];
				$hit_key = $class::get_purchase_hit_key();
				$order->update_meta_data( $hit_key, true );
			}
		}

		$order->save();
	}

	/**
	 * Fallback: send purchase events directly to each platform
	 * using the original S2S send_purchase_hit() methods.
	 *
	 * This bypasses the S2S base class guard (send_purchase_hit_order_id)
	 * by calling send_purchase_hit() directly on each CAPI class.
	 *
	 * @param \WC_Order    $order
	 * @param array<string> $destination_keys Keys of destinations that had payloads.
	 *
	 * @since 1.57.0
	 */
	/**
	 * Check if the order's customer IP is on the exclusion list.
	 *
	 * Resolves the IP from the order using WooCommerce's built-in method
	 * and the current request IP as fallback.
	 *
	 * @param \WC_Order $order The order to check.
	 *
	 * @return bool True if the IP is on the exclusion list.
	 * @since 1.57.1
	 */
	private static function is_order_ip_excluded( $order ) {

		$exclusion_list = Geolocation::get_ip_exclusion_list();

		if ( empty( $exclusion_list ) ) {
			return false;
		}

		// Try WooCommerce's built-in customer IP first
		$ip = $order->get_customer_ip_address();

		// Fallback to current request IP
		if ( empty( $ip ) ) {
			$ip = (string) Geolocation::get_user_ip();
		}

		if ( empty( $ip ) ) {
			return false;
		}

		return Geolocation::is_ip_excluded( $ip, $exclusion_list );
	}

	/**
	 * Whether a destination should be bundled into SSP events.
	 *
	 * Combines the Options-level active check with per-destination gates:
	 * the experimental Google Ads Data Manager upload only routes through
	 * the SSP while the experiment flag is on, and never in broker auth
	 * mode (the SSP worker holds no broker credentials, so broker-mode
	 * shops send directly from PHP).
	 *
	 * @param string $key   The SSP destination key.
	 * @param string $class The S2S class name.
	 *
	 * @return bool
	 * @since 1.66.0
	 */
	private static function is_destination_active( $key, $class ) {

		if ( ! self::is_destination_configured( $key ) ) {
			return false;
		}

		if ( 'google_dma' === $key && ! $class::is_handled_by_ssp() ) {
			return false;
		}

		return true;
	}

	private function fallback_direct_send( $order, $destination_keys, $outcome = self::DISPATCH_UNKNOWN, $dispatch_key = '' ) {

		Logger::info( 'SSP Purchase Proxy: Falling back to direct sends for order ' . $order->get_id() );

		foreach ( $destination_keys as $key ) {

			if ( ! isset( self::$destination_map[ $key ] ) ) {
				continue;
			}

			// GA4 MP is the one destination whose Measurement Protocol payload
			// carries no per-order dedup id, so a direct send that races an SSP
			// delivery shows up in GA4 as a second purchase. DD-008 therefore
			// had it fail and log rather than fall back at all.
			// Since 1.66.0 the dispatch-status probe can tell a bundle the SSP
			// never recorded from one whose fate is merely unknown, and on a
			// provable miss the direct send cannot duplicate anything. Only
			// the unknown case still drops, and that one now gets a retry.
			// @since 1.58.12, revised 1.68.0
			if ( 'google_ga4' === $key && ! self::ga4_direct_send_is_duplicate_free( $outcome ) ) {
				Logger::warning( 'SSP Purchase Proxy: Dropped GA4 MP purchase for order ' . $order->get_id() . ': the SSP dispatch could not be confirmed either way, so a direct send could duplicate it. Scheduling a retry.' );
				$this->schedule_retry( $order->get_id(), 'purchase', 0, $dispatch_key );
				continue;
			}

			$class = self::$destination_map[ $key ];

			try {
				$class::send_purchase_hit( $order );
			} catch ( \Exception $e ) {
				Logger::warning(
					'SSP Purchase Proxy: Fallback send for ' . $key
					. ' failed: ' . $e->getMessage()
				);
			}
		}
	}

	/**
	 * Whether a direct GA4 send can no longer duplicate an SSP delivery.
	 *
	 * True only on evidence that the SSP forwarded nothing: a bundle it
	 * refused outright, or one its dispatch-status record has never seen.
	 * An attempt whose outcome we could not establish is not evidence, and
	 * GA4's Measurement Protocol offers no per-order dedup id to fall back
	 * on, so those take the retry instead.
	 *
	 * @param string $outcome One of the DISPATCH_* constants.
	 *
	 * @return bool
	 * @since 1.68.0
	 */
	private static function ga4_direct_send_is_duplicate_free( $outcome ) {
		return self::DISPATCH_REJECTED === $outcome;
	}

	/**
	 * Queue the one retry a bundle gets when its fate could not be established.
	 *
	 * Safe to run even if the first attempt did arrive: the retry re-asks the
	 * SSP about that attempt's dispatch key before building anything, and a key
	 * the SSP has since recorded ends the retry instead of sending again. The
	 * probe is the whole point of waiting: it answers 15 minutes later, when
	 * whatever swallowed the first request has usually passed.
	 *
	 * One retry only, tracked on the order, because a retry that keeps failing
	 * is a network fault nobody is served by hammering. Without Action
	 * Scheduler (WooCommerce ships it, but a hard-stripped install may not)
	 * the behaviour is what it was before: the event is dropped and logged.
	 *
	 * @param int    $order_id
	 * @param string $event        'purchase' | 'refund' | 'partial_refund'.
	 * @param int    $refund_id    Refund the bundle belongs to, 0 for a purchase.
	 * @param string $dispatch_key Key of the attempt whose fate is unresolved.
	 *
	 * @return void
	 * @since 1.68.0
	 */
	private function schedule_retry( $order_id, $event, $refund_id = 0, $dispatch_key = '' ) {

		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		$marker  = $event . '-' . (int) $refund_id;
		$retried = (array) $order->get_meta( self::RETRY_MARKER_KEY, true );

		if ( in_array( $marker, $retried, true ) ) {
			return;
		}

		$retried[] = $marker;
		$order->update_meta_data( self::RETRY_MARKER_KEY, $retried );
		$order->save();

		as_schedule_single_action(
			time() + self::RETRY_DELAY_SECONDS,
			self::RETRY_HOOK,
			[ (int) $order_id, (string) $event, (int) $refund_id, (string) $dispatch_key ],
			'pmw_ssp'
		);

		Logger::info( 'SSP Purchase Proxy: Scheduled one retry of the ' . $event . ' bundle for order ' . $order_id . ' in ' . ( self::RETRY_DELAY_SECONDS / MINUTE_IN_SECONDS ) . ' minutes.' );
	}

	/**
	 * Action Scheduler callback: settle the dropped bundle.
	 *
	 * First it asks the SSP about the original attempt. The retry exists
	 * because that attempt's fate was unknown, and this is the first chance to
	 * establish it against a network that has had 15 minutes to recover:
	 *
	 * - the SSP has the key: the first attempt did arrive and fan out. Mark the
	 *   bundle sent and stop, which is what keeps GA4 from counting the
	 *   purchase twice.
	 * - the SSP has no record: nothing was ever delivered. Run the event again
	 *   from the top, a fresh bundle under a fresh key.
	 * - still unanswerable: stop. Two failed conversations with the SSP are a
	 *   network fault, and guessing at this point is how duplicates are made.
	 *
	 * Re-running the event re-runs every gate, so a destination that reached
	 * its platform directly in the meantime carries its hit key and is left out
	 * of the new bundle. With all of them marked the collection comes back
	 * empty and the retry is a no-op.
	 *
	 * @param int    $order_id
	 * @param string $event
	 * @param int    $refund_id
	 * @param string $dispatch_key Key of the attempt that was dropped.
	 *
	 * @return void
	 * @since 1.68.0
	 */
	public function retry_dispatch( $order_id, $event = 'purchase', $refund_id = 0, $dispatch_key = '' ) {

		$order_id = (int) $order_id;

		if ( ! empty( $dispatch_key ) ) {

			$verdict = $this->resolve_ambiguous_dispatch(
				$dispatch_key,
				[ 'event' => $event, 'order_id' => $order_id ]
			);

			if ( self::DISPATCH_OK === $verdict ) {
				$this->mark_retried_bundle_sent( $order_id, $event, $refund_id );
				return;
			}

			if ( self::DISPATCH_UNKNOWN === $verdict ) {
				Logger::warning(
					'SSP Purchase Proxy: The retry of the ' . $event . ' bundle for order ' . $order_id
					. ' still could not establish whether the SSP received it; giving up rather than risk a duplicate.'
				);
				return;
			}
		}

		Logger::info( 'SSP Purchase Proxy: Retrying the ' . $event . ' bundle for order ' . $order_id );

		if ( 'refund' === $event ) {
			$this->handle_full_refund_event( $order_id, (int) $refund_id );
			return;
		}

		if ( 'partial_refund' === $event ) {
			$this->handle_partial_refund_event( $order_id, (int) $refund_id );
			return;
		}

		$this->handle_purchase_event( $order_id );
	}

	/**
	 * Mark the bundle a retry found already dispatched.
	 *
	 * The destinations still missing their hit key are exactly the ones the
	 * dropped bundle carried: everything else was marked when it was sent.
	 * Rebuilding the payloads to learn the key set is more work than reading a
	 * list, but it is the one path that cannot drift from what the dispatch
	 * itself collects.
	 *
	 * @param int    $order_id
	 * @param string $event
	 * @param int    $refund_id
	 *
	 * @return void
	 * @since 1.68.0
	 */
	private function mark_retried_bundle_sent( $order_id, $event, $refund_id ) {

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		if ( 'refund' === $event ) {
			$keys = array_keys( $this->collect_refund_destination_payloads( $order, 'build_ssp_full_refund_event_data' ) );
			$this->mark_full_refund_hits_sent( $order, $keys );
		} elseif ( 'partial_refund' === $event ) {
			$keys = array_keys( $this->collect_refund_destination_payloads( $order, 'build_ssp_partial_refund_event_data', $refund_id ) );
			$this->mark_partial_refund_hits_sent( $order, $keys, $refund_id );
		} else {
			$order = Platform_Manager::get_provider()->get_order_data( $order );

			if ( ! $order ) {
				return;
			}

			$keys = array_keys( $this->collect_destination_payloads( $order ) );
			$this->mark_hits_sent( $order, $keys );
		}

		Logger::info(
			'SSP Purchase Proxy: The SSP had already dispatched the ' . $event . ' bundle for order ' . $order_id
			. '; marking it sent instead of sending it again.'
		);
	}

	/**
	 * Handle a full refund: bundle refund payloads from every destination
	 * that declares supports_refund_events() and implements
	 * build_ssp_full_refund_event_data(), and dispatch to the SSP. Today only
	 * GA4 MP qualifies; the bundle structure is forward-compatible with
	 * future refund-aware adapters.
	 *
	 * @param int $order_id
	 * @param int $refund_id The refund order ID created by WooCommerce.
	 *
	 * @since 1.58.12
	 */
	public function handle_full_refund_event( $order_id, $refund_id = 0 ) {

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		$destinations = $this->collect_refund_destination_payloads( $order, 'build_ssp_full_refund_event_data' );

		if ( empty( $destinations ) ) {
			return;
		}

		$payload = [
			'event'        => 'refund',
			'order_id'     => $order->get_id(),
			'refund_id'    => (int) $refund_id,
			'destinations' => $destinations,
		];

		$dispatch_key = self::build_dispatch_key( $payload );
		$outcome      = $this->dispatch( $payload, $order, $dispatch_key );

		if ( self::DISPATCH_OK === $outcome ) {
			$this->mark_full_refund_hits_sent( $order, array_keys( $destinations ) );
		} else {
			$this->fallback_refund_send( $order, array_keys( $destinations ), $outcome, 'refund', $refund_id, $dispatch_key );
		}
	}

	/**
	 * Handle a partial refund. Same bundling pattern as handle_full_refund_event,
	 * but each destination builder receives the refund_id so it can attach the
	 * refunded line items / amount.
	 *
	 * @param int $order_id
	 * @param int $refund_id
	 *
	 * @since 1.58.12
	 */
	public function handle_partial_refund_event( $order_id, $refund_id ) {

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		$destinations = $this->collect_refund_destination_payloads( $order, 'build_ssp_partial_refund_event_data', $refund_id );

		if ( empty( $destinations ) ) {
			return;
		}

		$payload = [
			'event'        => 'partial_refund',
			'order_id'     => $order->get_id(),
			'refund_id'    => (int) $refund_id,
			'destinations' => $destinations,
		];

		$dispatch_key = self::build_dispatch_key( $payload );
		$outcome      = $this->dispatch( $payload, $order, $dispatch_key );

		if ( self::DISPATCH_OK === $outcome ) {
			$this->mark_partial_refund_hits_sent( $order, array_keys( $destinations ), $refund_id );
		} else {
			$this->fallback_refund_send( $order, array_keys( $destinations ), $outcome, 'partial_refund', $refund_id, $dispatch_key );
		}
	}

	/**
	 * Refund counterpart of fallback_direct_send.
	 *
	 * GA4 MP is the only destination contributing refund payloads today, and
	 * it follows the same rule its purchase does: a direct send only when the
	 * SSP provably forwarded nothing, a retry when its fate is unknown. A
	 * refund that reaches GA4 twice subtracts the revenue twice, so the
	 * asymmetry between the two cases matters more here, not less.
	 *
	 * @param \WC_Order     $order
	 * @param array<string> $destination_keys
	 * @param string        $outcome          The resolved DISPATCH_* state.
	 * @param string        $event            'refund' | 'partial_refund'.
	 * @param int           $refund_id
	 * @param string        $dispatch_key     Key of the attempt being fallen back from.
	 *
	 * @return void
	 * @since 1.68.0
	 */
	private function fallback_refund_send( $order, $destination_keys, $outcome, $event, $refund_id, $dispatch_key = '' ) {

		$label = 'refund' === $event ? 'full refund' : 'partial refund ' . (int) $refund_id;

		foreach ( $destination_keys as $key ) {

			if ( 'google_ga4' !== $key || ! isset( self::$destination_map[ $key ] ) ) {
				continue;
			}

			if ( ! self::ga4_direct_send_is_duplicate_free( $outcome ) ) {
				Logger::warning( 'SSP Purchase Proxy: Dropped ' . $label . ' for order ' . $order->get_id() . ': the SSP dispatch could not be confirmed either way, so a direct send could duplicate it. Scheduling a retry.' );
				$this->schedule_retry( $order->get_id(), $event, $refund_id, $dispatch_key );
				continue;
			}

			$class = self::$destination_map[ $key ];

			try {
				if ( 'refund' === $event ) {
					$class::send_full_refund_hit( $order );
				} else {
					$class::send_partial_refund_hit( $order, $refund_id );
				}

				Logger::info( 'SSP Purchase Proxy: Sent the ' . $label . ' for order ' . $order->get_id() . ' directly; the SSP had no record of the bundle.' );
			} catch ( \Exception $e ) {
				Logger::warning(
					'SSP Purchase Proxy: Direct ' . $label . ' send for order ' . $order->get_id()
					. ' failed: ' . $e->getMessage()
				);
			}
		}
	}

	/**
	 * Collect refund payloads from each active destination that declares
	 * refund support and implements the given builder method
	 * ($builder_method).
	 *
	 * @param \WC_Order $order
	 * @param string    $builder_method 'build_ssp_full_refund_event_data' | 'build_ssp_partial_refund_event_data'
	 * @param int|null  $refund_id      Passed as second arg to the builder when set.
	 *
	 * @return array<string, array>
	 * @since 1.58.12
	 */
	private function collect_refund_destination_payloads( $order, $builder_method, $refund_id = null ) {

		$destinations = [];

		foreach ( self::$destination_map as $key => $class ) {

			if ( ! self::is_destination_active( $key, $class ) ) {
				continue;
			}

			// Two independent conditions, both required, because the reason a
			// destination gets no refund matters. supports_refund_events() is
			// the decision: most ad platforms have no refund event at all, and
			// Meta is the documented case (see S2S::supports_refund_events).
			// The builder check is the mechanics. Asserting only the latter
			// made "Facebook receives no refunds" look like an oversight
			// rather than a decision, and cost two investigations.
			if ( ! $class::supports_refund_events() || ! method_exists( $class, $builder_method ) ) {
				continue;
			}

			// Don't send a refund for a purchase that was consent-suppressed.
			// The builders check this themselves too (GA4), but future
			// refund-capable destinations get the guard here as well.
			$suppressed = (array) $order->get_meta( S2S::get_consent_suppressed_key(), true );
			if ( in_array( $class::get_purchase_hit_key(), $suppressed, true )
				&& ! $order->meta_exists( $class::get_purchase_hit_key() ) ) {
				Logger::debug( 'SSP: Refund destination ' . $key . ' skipped for order ' . $order->get_id() . ' - purchase was consent-suppressed' );
				continue;
			}

			$event_data = null === $refund_id
				? $class::{$builder_method}( $order )
				: $class::{$builder_method}( $order, $refund_id );

			if ( $event_data ) {
				$destinations[ $key ] = $event_data;
			}
		}

		return $destinations;
	}

	/**
	 * Marks full refund hits as sent for the given destinations.
	 *
	 * @param \WC_Order     $order
	 * @param array<string> $destination_keys
	 * @since 1.58.12
	 */
	private function mark_full_refund_hits_sent( $order, $destination_keys ) {

		foreach ( $destination_keys as $key ) {

			if ( ! isset( self::$destination_map[ $key ] ) ) {
				continue;
			}

			$class = self::$destination_map[ $key ];

			if ( method_exists( $class, 'mark_ssp_full_refund_sent' ) ) {
				$class::mark_ssp_full_refund_sent( $order );
			}
		}
	}

	/**
	 * Marks partial refund hits as sent for the given destinations.
	 *
	 * @param \WC_Order     $order
	 * @param array<string> $destination_keys
	 * @param int           $refund_id
	 * @since 1.58.12
	 */
	private function mark_partial_refund_hits_sent( $order, $destination_keys, $refund_id ) {

		foreach ( $destination_keys as $key ) {

			if ( ! isset( self::$destination_map[ $key ] ) ) {
				continue;
			}

			$class = self::$destination_map[ $key ];

			if ( method_exists( $class, 'mark_ssp_partial_refund_sent' ) ) {
				$class::mark_ssp_partial_refund_sent( $order, $refund_id );
			}
		}
	}
}
