<?php

/**
 * Abstract Server 2 Server class
 */

namespace SweetCode\Pixel_Manager;

use RuntimeException;
use SweetCode\Pixel_Manager\Admin\Environment;
use SweetCode\Pixel_Manager\Platforms\Order_Data;

defined('ABSPATH') || exit; // Exit if accessed directly

abstract class S2S {

	/**
	 * Order objects whose identifier meta has been mutated but not yet persisted.
	 *
	 * Every active server-to-server destination hooks its own
	 * set_identifiers_on_order() onto the order-created actions. Each of those
	 * used to call $order->save() itself, so a shop running seven S2S
	 * destinations performed seven full order writes during checkout.
	 *
	 * WooCommerce hands the very same $order instance to every callback on
	 * those actions, so all destinations can stamp their meta onto that one
	 * object and a single save() at the end persists all of it.
	 *
	 * Keyed by spl_object_hash() rather than order ID on purpose: some entry
	 * points (maybe_capture_identifiers_on_thankyou) load a separate order
	 * instance per destination, and each of those instances carries only its
	 * own meta changes. Keying by object identity keeps one pending save per
	 * distinct instance, so those paths behave exactly as before instead of
	 * silently dropping the other destinations' meta.
	 *
	 * The property is declared only here, so all subclasses share one registry.
	 *
	 * @var array<string, \WC_Order>
	 * @since 1.63.1
	 */
	private static $pending_order_saves = [];

	/**
	 * Whether the deferred-save flush callbacks have been registered.
	 *
	 * @var bool
	 * @since 1.63.1
	 */
	private static $flush_hooks_registered = false;

	/**
	 * Purchase dispatches waiting for the end of the request.
	 *
	 * WooCommerce fires the paid-status and payment-complete hooks from inside
	 * WC_Order::payment_complete(), before the gateway plugin that called it gets
	 * control back. WooCommerce PayPal Payments writes the transaction fee onto
	 * the order only after that call returns, so a server-side purchase sent
	 * straight from those hooks deducts no fee, while the browser event on the
	 * confirmation page a few seconds later does, and the two channels report
	 * different values for the same order. Every server-side destination
	 * therefore queues its purchase here and sends at the end of the request,
	 * once all the order meta the gateway writes is in place.
	 *
	 * Keyed by "<dispatcher>:<order ID>" so an order that trips several trigger
	 * hooks in one request (payment_complete plus the status transition)
	 * dispatches once per destination. Insertion order is kept, which preserves
	 * the per-class handlers running before the SSP purchase proxy.
	 *
	 * @var array<string, array{0: callable, 1: int}>
	 * @since 1.66.1
	 */
	private static $deferred_purchase_dispatches = [];

	/**
	 * Whether the end-of-request flush for deferred purchase dispatches has been registered.
	 *
	 * @var bool
	 * @since 1.66.1
	 */
	private static $deferred_purchase_flush_registered = false;

	/**
	 * Seconds a purchase send waits for another request to finish the same order.
	 *
	 * The lock is held only for one build, send and marker save. A blocking
	 * send times out after 5 seconds, so 10 covers the slowest normal case.
	 *
	 * @var int
	 * @since 1.69.3
	 */
	const PURCHASE_HIT_LOCK_TIMEOUT = 10;

	protected static function get_identifiers_key() {
		// Check if the method has been overridden in the subclass
		if (static::class === self::class) {
			throw new RuntimeException('The method get_identifiers_key must be overridden in the subclass.');
		}
	}

	public static function get_purchase_hit_key() {
		// Check if the method has been overridden in the subclass
		if (static::class === self::class) {
			throw new RuntimeException('The method get_purchase_hit_key must be overridden in the subclass.');
		}
	}

	public static function get_consent_snapshot_key() {
		return '_pmw_consent_snapshot';
	}

	public static function get_consent_suppressed_key() {
		return '_pmw_s2s_purchase_consent_suppressed';
	}

	/**
	 * The consent category this destination is gated on.
	 *
	 * Ad platforms (Facebook, TikTok, Snapchat, Pinterest, Reddit, OpenAI)
	 * inherit 'marketing'. Analytics destinations override with 'statistics'
	 * (Google_MP_GA4).
	 *
	 * @return string
	 * @since 1.62.0
	 */
	public static function get_consent_category() {
		return 'marketing';
	}

	/**
	 * Whether the server-side purchase event for this destination must be
	 * suppressed because the visitor denied the relevant consent category.
	 *
	 * The consent snapshot is captured in the browser during the cart and
	 * checkout pages and stamped onto the order, because at purchase-hook
	 * time (webhook, cron, delayed payments) no browser context exists.
	 *
	 * Orders without a snapshot (admin orders, marketplace imports, orders
	 * created before this feature) are sent as before. The
	 * pmw_s2s_require_consent_snapshot filter allows strict setups to
	 * suppress those too.
	 *
	 * @param \WC_Order $order The order.
	 * @return bool True when the purchase event must be suppressed.
	 * @since 1.62.0
	 */
	protected static function is_purchase_suppressed_by_consent( $order ) {

		$snapshot = $order->get_meta(self::get_consent_snapshot_key(), true);

		if (!is_array($snapshot) || empty($snapshot)) {

			/**
			 * No consent snapshot is available on this order. By default the
			 * purchase event is sent (legacy behavior). Return true to
			 * suppress purchase events for orders with unknown consent state.
			 *
			 * @param bool      $require Whether a snapshot is required. Default false.
			 * @param \WC_Order $order   The WooCommerce order.
			 * @param string    $context The pixel class name.
			 *
			 * @since 1.62.0
			 */
			return (bool) apply_filters('pmw_s2s_require_consent_snapshot', false, Order_Data::unwrap($order), static::class);
		}

		/**
		 * The shop manager chose to always send server-side events,
		 * regardless of the visitor's consent state. That setting is global,
		 * so this filter is what narrows it to some destinations.
		 *
		 * Return false for a destination and the consent gate applies to it
		 * again, while every other destination keeps sending. The case this
		 * exists for is a shop that wants its Conversions API destinations to
		 * keep receiving denied orders, but not the Google Ads conversion
		 * upload, or the reverse. Without it the choice is all or nothing.
		 *
		 * Has no effect while "Always send server-side events" is off, and
		 * none on orders that carry no consent snapshot at all, which are
		 * decided by pmw_s2s_require_consent_snapshot above.
		 *
		 * @param bool      $applies Whether the always-send override applies to this destination. Default true.
		 * @param \WC_Order $order   The WooCommerce order.
		 * @param string    $context The pixel class name.
		 *
		 * @since 1.69.0
		 */
		if (Options::is_always_send_s2s_active() && (bool) apply_filters('pmw_s2s_always_send_override', true, Order_Data::unwrap($order), static::class)) {
			return false;
		}

		return empty($snapshot[static::get_consent_category()]);
	}

	/**
	 * Save the identifiers into the session.
	 *
	 * @return void
	 */
	public static function set_identifiers_on_session() {

		// Don't run if WC has not initialized a session yet
		if (!Shop::is_woocommerce_session_active()) {
			Logger::debug('S2S set_identifiers_on_session [' . static::class . ']: WC session not active, skipping');
			return;
		}

		$identifiers = self::get_current_identifiers();

		/**
		 * Write only when the identifiers actually changed.
		 *
		 * A session write marks the entire WooCommerce session dirty, and
		 * WC_Session_Handler::save_data() then re-serializes the whole session,
		 * cart included, on shutdown. Current WooCommerce versions skip a write
		 * of an unchanged value themselves, older ones don't, so without this
		 * check every cart and checkout page load rewrote the session row of a
		 * visitor whose identifiers hadn't moved at all.
		 *
		 * @since 1.64.1
		 */
		if (WC()->session->get(static::get_identifiers_key()) === $identifiers) {
			Logger::debug('S2S set_identifiers_on_session [' . static::class . ']: identifiers unchanged, skipping the session write');
			return;
		}

		Logger::debug('S2S set_identifiers_on_session [' . static::class . ']: fbp ' . ( isset($identifiers['fbp']) ? 'present (' . $identifiers['fbp'] . ')' : 'absent' ) . ', identifiers keys: ' . implode(', ', array_keys($identifiers)));

		WC()->session->set(static::get_identifiers_key(), $identifiers);
	}

	public static function set_identifiers_on_order( $order ) {

//      Don't run if we already have set the user identifiers into the order
//      if ($order->meta_exists(static::get_identifiers_key())) {
//          return;
//      }

		$identifiers = static::get_current_identifiers();
		$identifiers = static::set_additional_identifiers_on_order($identifiers);

		Logger::debug('S2S set_identifiers_on_order [' . static::class . '] order #' . $order->get_id() . ': fbp ' . ( isset($identifiers['fbp']) ? 'present' : 'absent' ) . ', identifiers keys: ' . implode(', ', array_keys($identifiers)));

		$order->update_meta_data(static::get_identifiers_key(), $identifiers);

		// Persist the SSP session_id so the server-side purchase event can
		// send the matching X-SSP-Session header. The SSP uses it to look
		// up the customer's real client IP (captured from browser PMW
		// events) and inject it into outgoing destination payloads when
		// the WP server can't resolve a public IP behind a proxy chain.
		// Stored once per order — the first S2S class that runs writes it,
		// the others find it already set.
		// @since 1.58.10
		if ( ! $order->meta_exists( 'pmw_ssp_session_id' ) ) {
			$ssp_session_id = Options::get_ssp_session_id();
			if ( ! empty( $ssp_session_id ) ) {
				$order->update_meta_data( 'pmw_ssp_session_id', $ssp_session_id );
			}
		}

		// Persist the visitor's consent snapshot so the server-side purchase
		// event can honor the visitor's consent choice, even when the order
		// is paid out-of-band (webhook, cron) with no browser context.
		// Stored once per order, the first S2S class that runs writes it.
		// @since 1.62.0
		//
		// Read from the consent cookie this request carries before the
		// WooCommerce session, because a concurrent checkout request can
		// revert the session copy (DD-045).
		// @since 1.69.3
		if ( ! $order->meta_exists( self::get_consent_snapshot_key() ) ) {
			$consent = Click_Ids::get_current_consent();
			if ( ! empty( $consent ) ) {
				Logger::debug('S2S set_identifiers_on_order [' . static::class . '] order #' . $order->get_id() . ': consent snapshot from the ' . ( isset($consent['source']) ? $consent['source'] : 'session' ));
				$order->update_meta_data( self::get_consent_snapshot_key(), $consent );
			}
		}

		self::defer_order_save($order);
	}

	/**
	 * Queue the order for a single deferred save.
	 *
	 * Collapses the one-save-per-active-destination pattern into a single write
	 * per order instance. See $pending_order_saves for the reasoning.
	 *
	 * @param \WC_Order $order The order carrying unsaved identifier meta.
	 * @return void
	 * @since 1.63.1
	 */
	private static function defer_order_save( $order ) {

		self::$pending_order_saves[spl_object_hash($order)] = $order;

		self::register_order_save_flush_hooks();
	}

	/**
	 * Register the callbacks that persist deferred order saves.
	 *
	 * The flush runs on the same actions that trigger the identifier setters,
	 * one priority step after them, so the order is written within the same
	 * action it was mutated in and the window in which our in-memory order
	 * object can go stale stays as small as it was before batching.
	 *
	 * 'shutdown' is a last-resort safety net for callers that stamp
	 * identifiers outside of those actions, so queued meta can never be
	 * silently dropped.
	 *
	 * @return void
	 * @since 1.63.1
	 */
	private static function register_order_save_flush_hooks() {

		if (self::$flush_hooks_registered) {
			return;
		}

		self::$flush_hooks_registered = true;

		// The identifier setters run at the default priority 10 on these two.
		add_action('woocommerce_checkout_order_created', [ self::class, 'flush_pending_order_saves' ], 11);
		add_action('woocommerce_store_api_checkout_order_processed', [ self::class, 'flush_pending_order_saves' ], 11);

		// maybe_capture_identifiers_on_thankyou() runs at priority 5.
		add_action('woocommerce_thankyou', [ self::class, 'flush_pending_order_saves' ], 6);

		add_action('shutdown', [ self::class, 'flush_pending_order_saves' ], 0);
	}

	/**
	 * Persist every order queued by defer_order_save().
	 *
	 * @return void
	 * @since 1.63.1
	 */
	public static function flush_pending_order_saves() {

		if (empty(self::$pending_order_saves)) {
			return;
		}

		$pending = self::$pending_order_saves;

		// Clear first so a save() that re-enters this code path (via any
		// woocommerce_update_order listener) can't loop or double-write.
		self::$pending_order_saves = [];

		foreach ($pending as $pending_order) {
			$pending_order->save();
		}

		Logger::debug('S2S flush_pending_order_saves: persisted ' . count($pending) . ' order object(s) in one batch');
	}

	/**
	 * Get the current identifiers from the session and the browser.
	 *
	 * Merges browser identifiers with session identifiers,
	 * giving priority to session values for duplicate keys.
	 *
	 * Session values take priority because they were captured from the real browser
	 * during cart/checkout page visits (via template_redirect hooks).
	 * When purchase hooks fire from webhook/cron/IPN contexts,
	 * browser values contain server-side defaults
	 * (e.g. "WordPress/6.x" as user agent, gateway IP as IP address)
	 * which must not overwrite the real customer data stored in the session.
	 *
	 * New browser identifiers that don't exist in the session are still added.
	 *
	 * Identifiers listed by get_volatile_identifier_keys() are exempt from that
	 * precedence: they expire on their own schedule, so a stored copy goes
	 * wrong with age and the live browser value must win. See that method for
	 * why this is safe in webhook and cron contexts.
	 *
	 * @return array
	 *
	 * @since 1.58.1
	 * @since 1.64.1 Volatile identifiers are refreshed from the browser.
	 */
	private static function get_current_identifiers() {

		$identifiers_from_session = [];
		if (Shop::is_woocommerce_session_active()) {
			$identifiers_from_session = WC()->session->get(static::get_identifiers_key(), []);
		}

		$identifiers_from_browser = static::get_identifiers_from_browser();

		$identifiers = array_merge($identifiers_from_browser, $identifiers_from_session);

		foreach (static::get_volatile_identifier_keys() as $key) {
			if (isset($identifiers_from_browser[$key])) {
				$identifiers[$key] = $identifiers_from_browser[$key];
			}
		}

		return $identifiers;
	}

	/**
	 * Identifier keys that must always be taken from the live browser request.
	 *
	 * The session-wins rule above protects the real customer's data from being
	 * overwritten with server-side defaults when a purchase hook fires from a
	 * webhook, cron or IPN context. That is the right default for identifiers
	 * that never expire, but it freezes the ones that do: the first value
	 * written into the WooCommerce session is then reused for the whole life of
	 * that session, which is up to 47h for guests and open-ended for logged-in
	 * customers whose session row keeps being extended.
	 *
	 * Only cookie-derived identifiers belong here. They exist in
	 * $identifiers_from_browser exclusively when the request actually carried
	 * the cookie, so a webhook or cron run contributes nothing and the stored
	 * session value survives untouched. Server-derived fields (ip_address,
	 * user_agent, referrer) must never be listed: those are populated with
	 * server-side values in exactly those contexts.
	 *
	 * @return string[]
	 * @since 1.64.1
	 */
	protected static function get_volatile_identifier_keys() {
		return [];
	}

	public static function set_additional_identifiers_on_order( $identifiers ) {
		return $identifiers;
	}

	/**
	 * Get the identifiers from the browser
	 *
	 * @return array
	 */
	private static function get_identifiers_from_browser() {

		// Prevent reading out from an iframe
		// This can be an issue on payment gateway iframes that are not on the same domain.
		if (Helpers::is_iframe()) {
			Logger::debug('S2S get_identifiers_from_browser [' . static::class . ']: skipped (iframe detected)');
			return [];
		}

		$_server = Helpers::get_input_vars(INPUT_SERVER);

		$identifiers = [];

		// Add user IP
		if (Geolocation::get_user_ip()) {
			$identifiers['ip_address'] = Geolocation::get_user_ip();
		}
		// Note: No logging for missing IP - this is expected in iframe/health check scenarios

		// Add user agent
		if (isset($_server['HTTP_USER_AGENT'])) {
			$identifiers['user_agent'] = $_server['HTTP_USER_AGENT'];
		}

		// Add referrer
		if (isset($_server['HTTP_REFERER'])) {
			$identifiers['referrer'] = $_server['HTTP_REFERER'];
		}

		return (array) static::add_pixel_specific_identifiers($identifiers);
	}

	/**
	 * If an admin created an order in the back-end,
	 * for a customer to be paid on the front-end,
	 * we need to update the identifiers when the customer pays.
	 * Else return the identifiers from the order.
	 * If the identifiers are not set on the order, return the identifiers from the browser.
	 *
	 * @param $order
	 * @return array
	 */
	protected static function get_identifiers_from_order( $order ) {

		// If customer wants to pay order that has been created in the back-end
		// we need to update the identifiers when the customer pays.
		if (!is_admin() && Shop::is_backend_manual_order($order)) {
			$identifiers = self::get_current_identifiers();
			self::update_identifiers_on_order($order, $identifiers);
			return $identifiers;
		}

		$identifiers = $order->get_meta(static::get_identifiers_key(), true);
		$identifiers = is_array($identifiers) ? $identifiers : self::get_current_identifiers();

		// Defense-in-depth: enrich with WooCommerce-native order data
		// if the primary identifiers are missing or contain server-side values for user_agent or ip_address.
		// WooCommerce stores these on the order at checkout time (via OrderController::update_order_from_cart()),
		// so they reflect the real customer browser even in webhook/cron contexts.
		// When a server-side UA is detected, the IP is also wrong (it's the payment gateway's IP,
		// not the customer's), so we use the UA as a context signal for both fields.
		// @since 1.58.1
		// @since 1.58.4 Also detect server-side user agents (e.g. WordPress/6.x, Stripe/) and fall back to WC order data for both UA and IP
		$is_server_side_context = !empty($identifiers['user_agent']) && self::is_server_side_user_agent($identifiers['user_agent']);

		if ( ( empty($identifiers['user_agent']) || $is_server_side_context ) && $order->get_customer_user_agent() ) {
			$identifiers['user_agent'] = $order->get_customer_user_agent();
		}

		if ( ( empty($identifiers['ip_address']) || $is_server_side_context ) && $order->get_customer_ip_address() ) {
			$identifiers['ip_address'] = $order->get_customer_ip_address();
		}

		// Click IDs: the universal snapshot (Click_Ids) is written on every
		// order at checkout time, independent of which destinations were
		// active back then. A destination that was activated later - or a
		// backfill - would otherwise have no click ID for historical orders,
		// which is exactly what made backfilled uploads match far worse than
		// live ones. Values already in this destination's own identifiers
		// win; the snapshot only fills gaps. @since 1.66.0
		$identifiers = self::add_click_ids_from_snapshot($order, $identifiers);

		// Diagnostic: when no usable IP could be resolved at all, emit a
		// structured log line so we can tell whether the request reached
		// PHP without an IP-bearing header (proxy chain swallowed it),
		// only carried a private/loopback address (datacenter-internal),
		// or whether WC also failed to record one at checkout time.
		// No raw IP/UA values are logged — only classifications.
		// @since 1.58.10
		if ( empty( $identifiers['ip_address'] ) ) {
			self::log_missing_ip_diagnostic( $order, $is_server_side_context );
		}

		return $identifiers;
	}

	/**
	 * Fills missing click IDs from the universal per-order snapshot.
	 *
	 * Subclasses name the keys they consume through
	 * get_click_id_snapshot_map(): snapshot key => identifier key, because
	 * the platforms label the same concept differently (Meta stores fbclid
	 * as fbc, Snapchat scid, ...).
	 *
	 * @param \WC_Order $order       The order.
	 * @param array     $identifiers The identifiers resolved so far.
	 * @return array
	 * @since 1.66.0
	 */
	private static function add_click_ids_from_snapshot( $order, $identifiers ) {

		$map = static::get_click_id_snapshot_map();

		if (empty($map)) {
			return $identifiers;
		}

		foreach ($map as $snapshot_key => $identifier_key) {

			if (!empty($identifiers[$identifier_key])) {
				continue;
			}

			$click_id = Click_Ids::get_click_id_from_order($order, $snapshot_key);

			if ('' !== $click_id) {
				$identifiers[$identifier_key] = $click_id;
				Logger::debug('S2S [' . static::class . '] order #' . $order->get_id() . ': recovered ' . $identifier_key . ' from the click ID snapshot');
			}
		}

		return $identifiers;
	}

	/**
	 * Which click IDs of the universal snapshot this destination consumes,
	 * as snapshot key => identifier key. Empty by default (analytics
	 * destinations need none).
	 *
	 * @return array<string, string>
	 * @since 1.66.0
	 */
	protected static function get_click_id_snapshot_map() {
		return [];
	}

	/**
	 * Emit a diagnostic log line classifying *why* no client IP could be
	 * resolved for the order. Strictly classification-only — no raw IPs,
	 * UAs, or other PII enter the log.
	 *
	 * Helps distinguish between:
	 *   - "no_headers"     → request reached PHP with no IP-bearing header
	 *   - "private_only"   → an IP arrived but it was private/reserved
	 *   - "filtered_out"   → REMOTE_ADDR present but failed validation
	 *
	 * @param \WC_Order $order
	 * @param bool      $is_server_side_context
	 *
	 * @return void
	 * @since 1.58.10
	 */
	private static function log_missing_ip_diagnostic( $order, $is_server_side_context ) {

		$_server = Helpers::get_input_vars( INPUT_SERVER );

		// Classify each candidate IP-bearing header without exposing values.
		$ip_header_keys = [
			'HTTP_CF_CONNECTING_IP',
			'HTTP_X_SUCURI_CLIENTIP',
			'HTTP_TRUE_CLIENT_IP',
			'HTTP_INCAP_CLIENT_IP',
			'HTTP_FASTLY_CLIENT_IP',
			'HTTP_X_FORWARDED_FOR',
			'HTTP_X_REAL_IP',
			'REMOTE_ADDR',
		];

		$headers_present = [];
		foreach ( $ip_header_keys as $key ) {
			if ( ! empty( $_server[ $key ] ) ) {
				$headers_present[] = $key;
			}
		}

		// Classify REMOTE_ADDR: public / private / loopback / missing / invalid
		$remote_addr_class = 'missing';
		if ( ! empty( $_server['REMOTE_ADDR'] ) ) {
			$remote = (string) $_server['REMOTE_ADDR'];
			if ( false !== filter_var( $remote, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				$remote_addr_class = 'public';
			} elseif ( false !== filter_var( $remote, FILTER_VALIDATE_IP ) ) {
				// Valid IP but private/reserved/loopback range
				$remote_addr_class = '127.' === substr( $remote, 0, 4 ) || '::1' === $remote ? 'loopback' : 'private';
			} else {
				$remote_addr_class = 'invalid';
			}
		}

		// XFF chain length (just the count, not the IPs)
		$xff_chain_length = 0;
		if ( ! empty( $_server['HTTP_X_FORWARDED_FOR'] ) ) {
			$xff_chain_length = count( array_filter( array_map( 'trim', explode( ',', (string) $_server['HTTP_X_FORWARDED_FOR'] ) ) ) );
		}

		// Classify the IP that Geolocation::get_user_ip() found (if any) before
		// the public-only filter ran — explains "header arrived, was private".
		$raw_ip            = method_exists( Geolocation::class, 'get_ip_address' ) ? (string) Geolocation::get_ip_address() : '';
		$browser_ip_status = 'no_headers';
		if ( '' !== $raw_ip ) {
			if ( false !== filter_var( $raw_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				$browser_ip_status = 'public';   // Should not happen here (we wouldn't be in this branch), but log if it does
			} elseif ( false !== filter_var( $raw_ip, FILTER_VALIDATE_IP ) ) {
				$browser_ip_status = 'private_only';
			} else {
				$browser_ip_status = 'filtered_out';
			}
		}

		// Classify the IP WooCommerce stored on the order at checkout
		$wc_ip               = (string) $order->get_customer_ip_address();
		$wc_order_ip_status  = 'missing';
		if ( '' !== $wc_ip ) {
			if ( false !== filter_var( $wc_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				$wc_order_ip_status = 'present_public';
			} else {
				$wc_order_ip_status = 'present_private';
			}
		}

		$request_context = 'web';
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			$request_context = 'cli';
		} elseif ( defined( 'DOING_CRON' ) && DOING_CRON ) {
			$request_context = 'cron';
		} elseif ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			$request_context = 'rest';
		} elseif ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			$request_context = 'ajax';
		}

		$payment_method = method_exists( $order, 'get_payment_method' ) ? (string) $order->get_payment_method() : '';

		Logger::warning( sprintf(
			'S2S [%s] order #%d: no client IP resolved — browser_ip_status=%s, headers_present=[%s], remote_addr_class=%s, xff_chain_length=%d, wc_order_ip_status=%s, wc_order_ua_present=%s, is_server_side_context=%s, request_context=%s, payment_method=%s',
			static::class,
			$order->get_id(),
			$browser_ip_status,
			implode( ',', $headers_present ),
			$remote_addr_class,
			$xff_chain_length,
			$wc_order_ip_status,
			$order->get_customer_user_agent() ? 'true' : 'false',
			$is_server_side_context ? 'true' : 'false',
			$request_context,
			$payment_method
		) );
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {
		// Check if the method has been overridden in the subclass
		if (static::class === self::class) {
			throw new RuntimeException('The method add_pixel_specific_identifiers must be overridden in the subclass.');
		}
	}

	/**
	 * Detect server-side / non-browser user agent strings.
	 *
	 * When purchase hooks fire from webhook, cron, or IPN contexts,
	 * $_SERVER['HTTP_USER_AGENT'] contains the requesting service's UA
	 * (e.g. "WordPress/6.9.4; https://example.com") instead of the customer's browser UA.
	 * This method identifies such server-side UAs so the fallback to WC order data can trigger.
	 *
	 * @param string $user_agent The user agent string to check.
	 * @return bool True if the UA appears to be from a server-side context.
	 *
	 * @since 1.58.4
	 */
	private static function is_server_side_user_agent( $user_agent ) {

		$server_side_patterns = [
			'WordPress/',        // WordPress HTTP API (webhooks, cron, loopback)
			'WooCommerce/',      // WooCommerce REST API callbacks
			'Stripe/',           // Stripe webhook deliveries
			'PayPal',            // PayPal IPN/webhook
			'wp-cron',           // WP-Cron requests
			'Mollie/',           // Mollie payment webhooks
			'Adyen/',            // Adyen webhooks
			'Square/',           // Square webhooks
			'klarna',            // Klarna push notifications
		];

		foreach ($server_side_patterns as $pattern) {
			if (stripos($user_agent, $pattern) !== false) {
				return true;
			}
		}

		return false;
	}

	protected static function update_identifiers_on_order( $order, $identifiers ) {

		$data = $order->get_meta(static::get_identifiers_key(), true);
		// get_meta() returns an empty string when no identifiers meta exists yet
		// (e.g. on a freshly created subscription renewal order). Guard against the
		// string so array_merge() does not fatal. @since 1.59.0
		$data = is_array($data) ? $data : [];
		$data = array_merge($data, $identifiers);
		$order->update_meta_data(static::get_identifiers_key(), $data);
		$order->save();
	}

	public static function hook_into_generic_events() {

		if (Environment::is_woocommerce_active()) {
			self::hook_into_order_created_events();
			self::hook_into_purchase_events();
		}
	}

	public static function hook_into_purchase_events() {
		foreach (static::get_purchase_trigger_hooks() as $hook) {
			add_action($hook, [ static::class, 'defer_purchase_hit_order_id' ]);
		}
	}

	// Save the session identifiers on the order so that we can use them later when the order gets paid or completed
	// https://woocommerce.github.io/code-reference/files/woocommerce-includes-class-wc-checkout.html#source-view.403
	public static function hook_into_order_created_events() {

		// Registered up front, before any of these actions can fire, so the
		// batched save never relies on a hook being added while the action it
		// belongs to is already being dispatched. Idempotent across subclasses.
		// @since 1.63.1
		self::register_order_save_flush_hooks();

		// Classic checkout (WC_Checkout)
		add_action('woocommerce_checkout_order_created', [ static::class, 'set_identifiers_on_order' ]);

		// Blocks / Store API checkout (used by express checkout: Apple Pay, Google Pay, Stripe Link, etc.)
		// This hook fires during the browser's HTTP request, so $_SERVER['HTTP_USER_AGENT'] is the real browser UA.
		// @since 1.58.4
		add_action('woocommerce_store_api_checkout_order_processed', [ static::class, 'set_identifiers_on_order' ]);

		// Pay-for-order / quote / push-cart flows: the customer skips the normal checkout pipeline
		// and lands directly on the purchase confirmation page after paying a backend-manual order,
		// so none of the checkout hooks above fire. Snapshot identifiers from the real customer
		// browser here so the server-side purchase event (which may fire immediately for marketing
		// pixels or later on a paid-state transition for GA4 MP) carries the correct context.
		// @since 1.58.10
		add_action('woocommerce_thankyou', [ static::class, 'maybe_capture_identifiers_on_thankyou' ], 5);
	}

	/**
	 * Capture browser identifiers on the purchase confirmation page for backend-manual orders.
	 *
	 * This covers pay-for-order flows (admin creates the order and sends the customer a payment
	 * link) where the normal checkout hooks never fire. Runs for every active server-side pixel.
	 *
	 * Skipped when the page is viewed by a shop manager or admin (to avoid poisoning the order
	 * with a staff member's session while previewing the payment link before sending it to the customer).
	 *
	 * @since 1.58.10
	 *
	 * @param int $order_id
	 * @return void
	 */
	public static function maybe_capture_identifiers_on_thankyou( $order_id ) {

		if (!$order_id || current_user_can('manage_woocommerce')) {
			return;
		}

		$order = wc_get_order($order_id);

		if (!$order instanceof \WC_Order) {
			return;
		}

		if (!Shop::is_backend_manual_order($order)) {
			return;
		}

		static::set_identifiers_on_order($order);
	}

	public static function get_purchase_trigger_hooks() {

		$hooks = [];

		foreach (Shop::get_order_paid_statuses() as $status) {
			$hooks[] = 'woocommerce_order_status_' . $status;
		}

		// Used for marketing pixels mainly
		$hooks[] = 'woocommerce_payment_complete';
		$hooks[] = 'woocommerce_order_status_on-hold';

		return $hooks;
	}

	public static function send_purchase_hit_order_id( $order_id ) {

		// When the SSP is active, purchase events for SSP-handled pixels are routed
		// through SSP_Purchase_Proxy. Pixels not handled by SSP (e.g. GA4 Measurement
		// Protocol) continue to send purchase hits directly.
		if ( Options::should_process_server_events_via_ssp() && static::is_handled_by_ssp() ) {
			return;
		}

		$order = wc_get_order($order_id);

		// Same reason maybe_capture_identifiers_on_thankyou() checks: wc_get_order()
		// returns false whenever its lookup comes up empty, and the whole send path
		// from here on calls methods on the order.
		if (!$order instanceof \WC_Abstract_Order) {
			Logger::warning('S2S [' . static::class . ']: no order behind ID ' . (int) $order_id . ', skipping the purchase hit');
			return;
		}

		static::send_purchase_hit($order);
	}

	/**
	 * Trigger-hook callback: queue this destination's purchase hit for the end of the request.
	 *
	 * See $deferred_purchase_dispatches for why the hit is not sent right away.
	 *
	 * @param int $order_id
	 * @return void
	 * @since 1.66.1
	 */
	public static function defer_purchase_hit_order_id( $order_id ) {
		self::defer_purchase_dispatch($order_id, [ static::class, 'send_purchase_hit_order_id' ], static::class);
	}

	/**
	 * Queue a purchase dispatch for the end of the request.
	 *
	 * A dispatch queued for a different order flushes everything already pending
	 * first. Within one request a gateway finishes writing an order before
	 * anything moves on to the next one, so by the time a second order is
	 * triggered the first one's meta is complete. Bulk jobs (renewal batches,
	 * imports, WP-CLI status updates) therefore keep sending as they go, one
	 * order behind, instead of piling every send up at shutdown.
	 *
	 * @param int|\WC_Order $order_id The order the dispatch belongs to.
	 * @param callable      $callback Receives the order ID when the queue is flushed.
	 * @param string        $key      Identifies the dispatcher, so the same dispatcher
	 *                                queued twice for one order runs once.
	 * @return void
	 * @since 1.66.1
	 */
	public static function defer_purchase_dispatch( $order_id, $callback, $key ) {

		$order_id = $order_id instanceof \WC_Order ? $order_id->get_id() : (int) $order_id;

		if (!$order_id) {
			return;
		}

		foreach (self::$deferred_purchase_dispatches as $pending) {
			if ($pending[1] !== $order_id) {
				self::flush_deferred_purchase_dispatches();
				break;
			}
		}

		self::$deferred_purchase_dispatches[$key . ':' . $order_id] = [ $callback, $order_id ];

		if (!self::$deferred_purchase_flush_registered) {
			self::$deferred_purchase_flush_registered = true;

			// After flush_pending_order_saves() at priority 0, so identifier meta
			// stamped earlier in the request is persisted before any hit reads the order.
			add_action('shutdown', [ self::class, 'flush_deferred_purchase_dispatches' ], 5);
		}
	}

	/**
	 * Run every queued purchase dispatch, in the order it was queued.
	 *
	 * Entries are taken off the queue one at a time, so a dispatch that queues
	 * another one while running (a status transition inside a send) is picked
	 * up by this same loop instead of being left behind after shutdown.
	 *
	 * A dispatch that throws is logged and skipped. This runs on shutdown of the
	 * request that took the payment, so an uncaught error here appends a PHP fatal
	 * to the checkout response the gateway already succeeded in: the customer reads
	 * that as a failed payment and orders again. Tracking one destination must
	 * never cost a shop the checkout, nor the remaining destinations.
	 *
	 * @return void
	 * @since 1.66.1
	 */
	public static function flush_deferred_purchase_dispatches() {

		while (!empty(self::$deferred_purchase_dispatches)) {

			$dispatch = array_shift(self::$deferred_purchase_dispatches);

			try {
				call_user_func($dispatch[0], $dispatch[1]);
			} catch (\Throwable $e) {
				Logger::error(
					'Purchase dispatch for order ' . (int) $dispatch[1] . ' failed: '
					. $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine()
				);
			}
		}
	}

	/**
	 * Whether this pixel's purchase events are handled by the SSP Purchase Proxy.
	 *
	 * Subclasses that are routed through SSP_Purchase_Proxy override this to
	 * return true. Pixels that send purchase events directly (e.g. GA4 MP)
	 * inherit the default false so they are not blocked by the SSP guard.
	 *
	 * @return bool
	 * @since 1.57.1
	 */
	public static function is_handled_by_ssp() {
		return false;
	}

	/**
	 * Whether this destination has an event that can carry a refund.
	 *
	 * Default false, because most ad platforms have no refund, return or
	 * cancellation event at all. The Meta Conversions API is the case that
	 * made this explicit: its 17 standard events contain nothing that
	 * expresses "this purchase was partly refunded", and a custom event
	 * does not reduce an already attributed Purchase conversion value, so
	 * sending one would not produce net ROAS either. Meta's "Returns API"
	 * belongs to Commerce Platform order management, not the Conversions
	 * API, so it is no route for this. Facebook therefore stays on the
	 * default and receives no refund events.
	 *
	 * Destinations whose API models a refund override this and implement
	 * build_ssp_full_refund_event_data() / build_ssp_partial_refund_event_data().
	 * Both are required: this declares the intent, those do the work.
	 *
	 * @return bool
	 * @since 1.65.2
	 */
	public static function supports_refund_events() {
		return false;
	}

	public static function send_s2s_event( $event_data ) {

		if (!static::is_pixel_s2s_active()) {
			return;
		}

		if (!$event_data) {
			wp_send_json_error();
		}

		static::send_event_hit($event_data);
	}

	public static function is_pixel_s2s_active() {
		// Check if the method has been overridden in the subclass
		if (static::class === self::class) {
			throw new RuntimeException('The method is_pixel_s2s_active must be overridden in the subclass.');
		}
	}

	/**
	 * Let a shop change a server-side purchase payload before it is sent.
	 *
	 * Purchase events are built from the order, never relayed from the
	 * browser, so the pmw_server_event_payload_* chain does not see them (the
	 * relay endpoints refuse 'purchase'). These two filters are the supported
	 * way to enrich or adjust the purchase itself. Every destination's builder
	 * calls this on its result, which covers both the direct send and the
	 * SweetCode Cloud bundle, because both go through that builder.
	 *
	 * The payload is in the destination's own format, exactly as it would be
	 * sent. Anything other than a non-empty array returned by a callback is
	 * ignored, so a broken callback cannot drop a purchase. To stop a purchase
	 * from being sent, use pmw_skip_s2s_purchase_event instead.
	 *
	 * @param string    $destination Destination key, as in the SweetCode Cloud bundle (e.g. 'facebook', 'tiktok', 'google_ga4').
	 * @param array|null $payload     The purchase payload the builder produced, or null when it skipped the order.
	 * @param \WC_Order  $order       The order the purchase is for.
	 *
	 * @return array|null
	 * @since 1.70.1
	 */
	protected static function filter_purchase_payload( $destination, $payload, $order ) {

		if (empty($payload)) {
			return $payload;
		}

		/**
		 * Filters the server-side purchase payload of every destination.
		 *
		 * @since 1.70.1
		 */
		$filtered = apply_filters('pmw_server_purchase_payload', $payload, $destination, $order);
		$payload  = self::accept_filtered_purchase_payload($filtered, $payload, 'pmw_server_purchase_payload', $order);

		/**
		 * Filters the server-side purchase payload of one destination.
		 *
		 * @since 1.70.1
		 */
		$filtered = apply_filters("pmw_server_purchase_payload_{$destination}", $payload, $order);

		return self::accept_filtered_purchase_payload($filtered, $payload, "pmw_server_purchase_payload_{$destination}", $order);
	}

	/**
	 * Keep a filter's result only if it is still a payload.
	 *
	 * Checked after each of the two filters, so a broken callback on the
	 * generic filter cannot hand a non-array to the destination's own callbacks.
	 *
	 * @param mixed     $filtered The filter's result.
	 * @param array     $payload  The payload that went into the filter.
	 * @param string    $hook     The filter name, for the log.
	 * @param \WC_Order $order    The order the purchase is for.
	 *
	 * @return array
	 * @since 1.70.1
	 */
	private static function accept_filtered_purchase_payload( $filtered, $payload, $hook, $order ) {

		if (is_array($filtered) && !empty($filtered)) {
			return $filtered;
		}

		Logger::warning('The ' . $hook . ' filter returned no payload on order #' . $order->get_id() . ', so its change was discarded. Use pmw_skip_s2s_purchase_event to stop a purchase.');

		return $payload;
	}

	public static function send_purchase_hit( $order ) {
		// Check if the method has been overridden in the subclass
		if (static::class === self::class) {
			throw new RuntimeException('The method send_event_hit must be overridden in the subclass.');
		}
	}

	public static function send_event_hit( $event_data ) {
		// Check if the method has been overridden in the subclass
		if (static::class === self::class) {
			throw new RuntimeException('The method send_event_hit must be overridden in the subclass.');
		}
	}

	protected static function can_process_order( $order ) {

		/**
		 * Allow merchants and third-party plugins to skip the server-side
		 * purchase event for a specific order. Returning true prevents the
		 * purchase hit from being sent to any S2S/CAPI platform (including
		 * via the SSP Purchase Proxy) and also excludes the order from the
		 * Google Ads Conversion Adjustments feed.
		 *
		 * @param bool      $skip    Whether to skip the purchase event. Default false.
		 * @param \WC_Order $order   The WooCommerce order.
		 * @param string    $context The pixel class name (e.g. Facebook_CAPI::class)
		 *                           or a feed identifier like 'conversion_adjustments_feed'.
		 *
		 * @since 1.58.10
		 */
		if (apply_filters('pmw_skip_s2s_purchase_event', false, Order_Data::unwrap($order), static::class)) {
			return false;
		}

		/**
		 * Don't continue if the shop switched subscription renewal tracking off.
		 *
		 * The pmw_subscription_renewal_tracking opt-out is documented for every
		 * pixel, but it used to be read by Facebook CAPI and GA4 alone, so a
		 * renewal still reached Google Ads, TikTok, Pinterest, Snapchat, Reddit,
		 * OpenAI, Nextdoor, Microsoft Advertising, Mixpanel and Triple Whale.
		 * Every destination's payload builder passes through here, so the opt-out
		 * now covers all of them. Facebook and GA4 keep their own filter on top
		 * for shops that want to switch off a single platform. @since 1.67.1
		 *
		 * The cheap filter is asked first: resolving a renewal costs WooCommerce
		 * Subscriptions a lookup per order, and this runs once per destination.
		 */
		if (Shop::do_not_track_subscription_renewal() && Shop::is_wcs_renewal_order($order)) {
			Logger::debug('S2S: Skipping purchase event for order ' . $order->get_id() . ' - it is a subscription renewal and renewal tracking is disabled [' . static::class . ']');
			return false;
		}

		// Don't continue if it's a user that we don't want to track
		if (Shop::do_not_track_user(Shop::get_order_user_id($order))) {
			return false;
		}

		// Don't continue if the customer's IP is on the exclusion list
		if (self::is_order_ip_excluded($order)) {
			Logger::debug('S2S: Skipping purchase event for order ' . $order->get_id() . ' — IP is on exclusion list');
			return false;
		}

		// Don't continue if the purchase hit has already been sent
		if ($order->meta_exists(static::get_purchase_hit_key())) {
			return false;
		}

		// Don't continue if the order was placed before this destination was
		// switched on. Its browser purchase fired back then, so a server
		// purchase sent when the order reaches a paid status later lands
		// outside the platform's deduplication window and counts twice.
		if (static::is_order_created_before_destination_activation($order)) {
			Logger::info('S2S: Skipping purchase event for order ' . $order->get_id() . ' - it was created before this server-side destination was activated [' . static::class . ']');
			return false;
		}

		// Don't continue if the visitor denied consent for this destination's
		// category. The purchase-hit key is deliberately NOT written here:
		// enabling always_send_s2s later must still be able to send the
		// purchase on a subsequent status transition. The suppression marker
		// is consumed by the refund gate and the tracking accuracy exclusion.
		// Note: the Google Ads Conversion Adjustments feed is intentionally
		// not consent-gated in this version, only S2S purchase destinations are.
		if (static::is_purchase_suppressed_by_consent($order)) {
			$suppressed = (array) $order->get_meta(self::get_consent_suppressed_key(), true);
			if (!in_array(static::get_purchase_hit_key(), $suppressed, true)) {
				$suppressed[] = static::get_purchase_hit_key();
				$order->update_meta_data(self::get_consent_suppressed_key(), $suppressed);
				$order->save();
				Logger::info('S2S: Consent denied (' . static::get_consent_category() . ') - suppressing purchase event for order ' . $order->get_id() . ' [' . static::class . ']');
			}
			return false;
		}

		return true;
	}

	/**
	 * Check if the order's customer IP is on the exclusion list.
	 *
	 * Resolves the IP from three sources in priority order:
	 * 1. IP stored in order identifiers meta (captured during checkout)
	 * 2. WooCommerce's built-in customer IP on the order
	 * 3. Current request IP via Geolocation (fallback for real-time triggers)
	 *
	 * @param \WC_Order $order The order to check.
	 *
	 * @return bool True if the IP is on the exclusion list.
	 * @since 1.57.1
	 */
	protected static function is_order_ip_excluded( $order ) {

		$exclusion_list = Geolocation::get_ip_exclusion_list();

		if (empty($exclusion_list)) {
			return false;
		}

		$ip = self::resolve_order_ip($order);

		if (empty($ip)) {
			return false;
		}

		return Geolocation::is_ip_excluded($ip, $exclusion_list);
	}

	/**
	 * Resolve the customer IP address for an order.
	 *
	 * Priority:
	 * 1. IP from the order's S2S identifiers meta (most accurate, captured at checkout time)
	 * 2. WooCommerce's built-in customer IP address on the order
	 * 3. Current visitor IP from Geolocation (fallback for real-time order hooks)
	 *
	 * @param \WC_Order $order The order.
	 *
	 * @return string The resolved IP address, or empty string if not available.
	 * @since 1.57.1
	 */
	private static function resolve_order_ip( $order ) {

		// 1. Try IP from identifiers stored on the order
		$identifiers = $order->get_meta(static::get_identifiers_key(), true);
		if (is_array($identifiers) && !empty($identifiers['ip_address'])) {
			return $identifiers['ip_address'];
		}

		// 2. Try WooCommerce's built-in customer IP
		if (method_exists($order, 'get_customer_ip_address')) {
			$wc_ip = $order->get_customer_ip_address();
			if (!empty($wc_ip)) {
				return $wc_ip;
			}
		}

		// 3. Fallback to current request IP
		return (string) Geolocation::get_user_ip();
	}

	protected static function can_not_process_order( $order ) {
		return !self::can_process_order($order);
	}

	/**
	 * Option holding the time each server-side destination was first seen active.
	 *
	 * Keyed by the SSP_Purchase_Proxy destination key. A value of 0 means the
	 * destination was already active when PMW started recording, so its real
	 * activation time is unknown and no order is skipped for it.
	 *
	 * @return string
	 * @since 1.71.1
	 */
	public static function get_activation_times_option_name() {
		return 'pmw_s2s_destination_activation_times';
	}

	/**
	 * Record the first time each server-side destination is active.
	 *
	 * Runs on every request (premium only). The stored option is autoloaded
	 * and written only when a destination appears for the first time, so the
	 * usual cost is one array read and the Options lookups the pixels make
	 * anyway. A timestamp is never moved or cleared: switching a destination
	 * off and on again keeps the first activation (DD-065).
	 *
	 * The very first run on an install stamps destinations that are already
	 * active with 0. Those were set up under an earlier version, when nothing
	 * recorded the time, and stamping them "now" would skip every legitimate
	 * order placed before the update that reaches a paid status afterwards.
	 *
	 * @return void
	 * @since 1.71.1
	 */
	public static function record_destination_activations() {

		$option_name = self::get_activation_times_option_name();
		$stored      = get_option($option_name, null);
		$first_run   = !is_array($stored);
		$times       = $first_run ? [] : $stored;
		$changed     = $first_run;

		foreach (array_keys(SSP_Purchase_Proxy::get_destination_map()) as $key) {

			if (isset($times[ $key ]) || !SSP_Purchase_Proxy::is_destination_configured($key)) {
				continue;
			}

			$times[ $key ] = $first_run ? 0 : time();
			$changed       = true;
		}

		if ($changed) {
			update_option($option_name, $times, true);
		}
	}

	/**
	 * When this destination was first seen active, or 0 if that is unknown.
	 *
	 * @return int Unix timestamp, 0 when unknown.
	 * @since 1.71.1
	 */
	protected static function get_destination_activation_time() {

		$key = array_search(static::class, SSP_Purchase_Proxy::get_destination_map(), true);

		if (false === $key) {
			return 0;
		}

		$times = get_option(self::get_activation_times_option_name(), []);

		return is_array($times) && isset($times[ $key ]) ? (int) $times[ $key ] : 0;
	}

	/**
	 * Whether the order was created before this destination was activated.
	 *
	 * An order like that had its browser purchase tracked when it was placed.
	 * When it reaches a paid status after activation (a bank transfer marked
	 * paid, an old order completed by hand, a bulk status change), the trigger
	 * hooks would send a server purchase days or weeks later, beyond the
	 * platform's event_id deduplication window, and the conversion would be
	 * counted twice.
	 *
	 * @param \WC_Order|Order_Data $order
	 *
	 * @return bool
	 * @since 1.71.1
	 */
	protected static function is_order_created_before_destination_activation( $order ) {

		$activated_at = static::get_destination_activation_time();

		if ($activated_at <= 0) {
			return false;
		}

		$native = Order_Data::unwrap($order);

		if (!is_object($native) || !method_exists($native, 'get_date_created')) {
			return false;
		}

		$created = $native->get_date_created();

		if (!$created instanceof \DateTimeInterface || $created->getTimestamp() >= $activated_at) {
			return false;
		}

		/**
		 * Send the server-side purchase for an order created before the
		 * destination was activated.
		 *
		 * Return false to send it anyway, for example while backfilling orders
		 * whose browser purchase was never tracked. The pmw_skip_s2s_purchase_event
		 * filter is still applied first and can skip any order.
		 *
		 * @param bool      $skip         Whether to skip the purchase. Default true.
		 * @param \WC_Order $order        The WooCommerce order.
		 * @param string    $context      The pixel class name (e.g. Facebook_CAPI::class).
		 * @param int       $activated_at Unix time the destination was first seen active.
		 *
		 * @since 1.71.1
		 */
		return (bool) apply_filters('pmw_s2s_skip_purchase_created_before_activation', true, $native, static::class, $activated_at);
	}

	/**
	 * Run a purchase send while holding a lock for this order and destination.
	 *
	 * The purchase-hit marker is checked, then the hit is sent, then the marker
	 * is written. Two requests that trigger the same order at the same time
	 * (a gateway webhook and the customer's return from the gateway, say) both
	 * passed the check before either wrote the marker, and both sent. The
	 * deferral queue only removes duplicates inside one request.
	 *
	 * A MySQL named lock serialises the sends across requests. It belongs to
	 * the database connection, so a request that dies mid-send cannot leave it
	 * behind. Once it holds the lock, a request reads the marker straight from
	 * the database: the order it carries was loaded before the other request
	 * saved, and its in-memory meta cannot show that save.
	 *
	 * Where the lock cannot be taken at all (a database without GET_LOCK, such
	 * as SQLite), the send runs unlocked, exactly as it did before.
	 *
	 * @param \WC_Order|Order_Data $order    The order.
	 * @param callable             $callback Does the build, send and marker save; receives the order.
	 * @return void
	 * @since 1.69.3
	 */
	protected static function with_purchase_hit_lock( $order, $callback ) {

		global $wpdb;

		// MySQL caps lock names at 64 characters, so the name is hashed.
		$lock_name = 'pmw_' . md5($wpdb->prefix . static::get_purchase_hit_key() . ':' . $order->get_id());

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- a named lock is not data; no WordPress API offers one.
		$acquired = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lock_name, self::PURCHASE_HIT_LOCK_TIMEOUT));

		if ('0' === (string) $acquired) {
			Logger::warning('S2S [' . static::class . ']: order ' . $order->get_id() . ' was still being sent by another request after ' . self::PURCHASE_HIT_LOCK_TIMEOUT . ' seconds, skipping the purchase hit so it cannot go out twice');
			return;
		}

		try {
			if ('1' === (string) $acquired && self::is_purchase_hit_recorded_in_database($order)) {
				Logger::debug('S2S [' . static::class . ']: purchase hit for order ' . $order->get_id() . ' was sent by a concurrent request, skipping');
				return;
			}

			call_user_func($callback, $order);
		} finally {
			if ('1' === (string) $acquired) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
			}
		}
	}

	/**
	 * Write the purchase-hit marker, unless the send never reached the platform.
	 *
	 * A WP_Error from HTTP::post() means the request failed before the platform
	 * saw it (DNS, TLS, a timeout, an unsafe URL). Marking the order anyway
	 * blocked every later paid-status trigger from delivering it, so the order
	 * stays unmarked and the failure is logged instead.
	 *
	 * @param \WC_Order|Order_Data $order    The order.
	 * @param mixed                $response What HTTP::post() returned.
	 * @return bool Whether the marker was written.
	 * @since 1.69.3
	 */
	protected static function mark_purchase_hit_sent( $order, $response ) {

		if (is_wp_error($response)) {
			Logger::warning('S2S [' . static::class . ']: purchase for order ' . $order->get_id() . ' failed to send and was not marked as sent: ' . $response->get_error_message());
			return false;
		}

		$order->update_meta_data(static::get_purchase_hit_key(), true);
		$order->save();

		return true;
	}

	/**
	 * Whether the purchase-hit marker is in the database, whatever the order object says.
	 *
	 * Queried directly on purpose. The order object and WooCommerce's own
	 * read_meta() both answer from cache: HPOS keeps order meta in its
	 * datastore cache, and that cache is what a concurrent request's save
	 * has not reached yet.
	 *
	 * @param \WC_Order|Order_Data $order The order.
	 * @return bool
	 * @since 1.69.3
	 */
	private static function is_purchase_hit_recorded_in_database( $order ) {

		global $wpdb;

		if (Helpers::is_wc_hpos_enabled()) {
			$table  = \Automattic\WooCommerce\Utilities\OrderUtil::get_table_for_order_meta();
			$column = 'order_id';
		} else {
			$table  = $wpdb->postmeta;
			$column = 'post_id';
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- the table and column come from WooCommerce, not from input.
		return null !== $wpdb->get_var($wpdb->prepare("SELECT 1 FROM {$table} WHERE {$column} = %d AND meta_key = %s LIMIT 1", $order->get_id(), static::get_purchase_hit_key()));
	}
}
