<?php

namespace SweetCode\Pixel_Manager;

use SweetCode\Pixel_Manager\Pixels\Google\Google_DMA;
use SweetCode\Pixel_Manager\Pixels\Google\Google_MP_GA4;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Retracts the conversions of orders whose payment failed after the
 * conversion had already been sent.
 *
 * The confirmation page blocks orders that are already failed, but some
 * gateways leave the order pending or on hold at checkout and report the
 * failure hours or days later. By then the conversion is out. This class
 * reverses it where the platform allows it: a Google Ads retraction through
 * the Data Manager API and a GA4 refund event. The Google Ads conversion
 * adjustments CSV feed covers the same orders on its own.
 *
 * WooCommerce lets a customer pay a failed order again, and a retracted
 * Google Ads conversion cannot be restored. So the retraction waits for a
 * grace period and only runs if the order is still failed by then.
 *
 * @since 1.69.3
 */
class Failed_Order_Retractions {

	/** Action Scheduler hook of the delayed retraction. */
	const HOOK = 'pmw_retract_failed_order';

	/** Action Scheduler group. */
	const GROUP = 'pmw';

	/** Grace period, matching the two-day lag of the CSV adjustments feed. */
	const DELAY = 172800; // 2 days

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		add_action('woocommerce_order_status_failed', [ __CLASS__, 'schedule' ], 10, 1);
		add_action(self::HOOK, [ __CLASS__, 'retract' ], 10, 1);
	}

	/**
	 * Whether any destination this class reverses is active.
	 *
	 * @return bool
	 */
	public static function is_active() {
		return self::is_google_dma_active() || Options::is_ga4_mp_active();
	}

	private static function is_google_dma_active() {
		return Options::is_google_ads_dm_active();
	}

	/**
	 * Schedules the retraction when the order turns failed. Orders without
	 * any sign of a sent conversion are not scheduled at all, which keeps the
	 * payments declined at checkout out of the queue.
	 *
	 * @param int $order_id The order ID.
	 * @return void
	 */
	public static function schedule( $order_id ) {

		if (!function_exists('as_schedule_single_action')) {
			return;
		}

		$order = wc_get_order($order_id);

		if (!$order instanceof \WC_Order || !self::was_conversion_sent($order)) {
			return;
		}

		if (function_exists('as_has_scheduled_action') && as_has_scheduled_action(self::HOOK, [ (int) $order_id ], self::GROUP)) {
			return;
		}

		as_schedule_single_action(time() + self::DELAY, self::HOOK, [ (int) $order_id ], self::GROUP);

		Logger::info('Scheduled the conversion retraction for failed order ' . $order_id);
	}

	/**
	 * Runs the retraction once the grace period is over.
	 *
	 * @param int $order_id The order ID.
	 * @return void
	 */
	public static function retract( $order_id ) {

		$order = wc_get_order($order_id);

		if (!$order instanceof \WC_Order) {
			return;
		}

		// The customer paid the order in the meantime, or the shop changed
		// its status: the conversion stands.
		if ('failed' !== $order->get_status()) {
			Logger::debug('Conversion retraction skipped for order ' . $order_id . ' - it is no longer failed but ' . $order->get_status());
			return;
		}

		if (self::is_google_dma_active()) {
			Google_DMA::retract_failed_order($order);
		}

		if (Options::is_ga4_mp_active()) {
			Google_MP_GA4::report_failed_order($order);
		}
	}

	/**
	 * Whether any conversion was sent for the order: the browser
	 * confirmation pixel, the Data Manager upload or the GA4 purchase. Each
	 * destination checks its own evidence again before it reverses anything.
	 *
	 * @param \WC_Order $order The order.
	 * @return bool
	 */
	private static function was_conversion_sent( $order ) {
		return Shop::has_conversion_pixel_already_fired($order)
			|| $order->meta_exists(Google_DMA::get_purchase_hit_key())
			|| $order->meta_exists(Google_MP_GA4::get_purchase_hit_key())
			|| Shop::was_ga4_purchase_sent_from_browser($order);
	}
}
