<?php

namespace SweetCode\Pixel_Manager;

use SweetCode\Pixel_Manager\Admin\Environment;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Universal click ID capture.
 *
 * Every ad platform's server-side path needs the click ID of the visit that
 * produced the order, and the click ID only exists in the browser: in the URL
 * of the landing page and in the first-party cookie the platform's tag writes.
 * Both are gone by the time an order is processed from a webhook, a cron run
 * or a later backfill.
 *
 * Until now each destination captured its own click ID inside its own
 * identifiers meta, which has two consequences:
 *
 *   1. a destination that was not active at checkout time has no click ID for
 *      that order, forever - which is what made backfilled uploads match far
 *      worse than live ones, and
 *   2. the only cross-destination fallback was `_wpm_gclid`, written on the
 *      order-received page, so every order whose customer never reached that
 *      page (gateway redirect, closed tab) looked click-ID-less.
 *
 * This class writes ONE snapshot per order, at checkout time, holding the
 * click IDs of the platforms this shop actually has configured - browser
 * pixel or server-side, both count, because a pixel can gain a server-side
 * path later. Platforms that are not set up contribute nothing.
 *
 * The snapshot is written where the browser is still present (checkout, and
 * the confirmation page as a second chance), so it survives the orders whose
 * customer never reaches the confirmation page: gateway redirects, closed
 * tabs, webhook-completed payments.
 *
 * @since 1.66.0
 */
class Click_Ids {

	/** Order meta key holding the click ID snapshot. */
	const ORDER_META_KEY = '_pmw_click_ids';

	/** WooCommerce session key holding the click IDs seen during the visit. */
	const SESSION_KEY = 'pmw_click_ids';

	/**
	 * First-party fallback cookie holding the click IDs PMW's own JS
	 * harvested from landing page URLs. Written client-side (works on cached
	 * pages, gated on marketing consent, active platforms only) and refreshed
	 * server-side with a long expiry, it survives what nothing else does:
	 * closed tabs (sessionStorage is per-tab), expired WooCommerce sessions,
	 * and platform tags that never ran - and it reaches PHP on every request
	 * for free, with no AJAX round-trip.
	 *
	 * Renamed from _pmw_click_ids in 1.69.3 so that every PMW cookie shares
	 * the pmw_ prefix: a host allow list then needs one rule, and caches that
	 * strip every underscore cookie (meant for _ga and the like) no longer
	 * drop it.
	 */
	const COOKIE_NAME = 'pmw_click_ids';

	/**
	 * The cookie's name before 1.69.3. Still read, so visitors keep the click
	 * IDs it holds, and expired whenever PMW writes or purges the new one.
	 * Safe to remove once its 90-day lifetime has passed for every install
	 * (2027-04 at the earliest).
	 *
	 * @since 1.69.3
	 */
	const LEGACY_COOKIE_NAME = '_pmw_click_ids';

	/** Upper bound for the raw cookie payload; anything larger is ignored. */
	const COOKIE_MAX_LENGTH = 4096;

	/**
	 * First-party cookie holding the visitor's current consent decision, as
	 * PMW's JS normalized it: `m1s0c1` = marketing granted, statistics
	 * denied, visitor has chosen.
	 *
	 * It travels with the request that creates the order, on every checkout
	 * path including express payment buttons, so the order's consent
	 * snapshot no longer depends on the WooCommerce session. That session is
	 * written whole by every request that changed anything, and a concurrent
	 * checkout request can revert the consent PMW stored in it
	 * (woocommerce/woocommerce#46483, DD-045).
	 *
	 * Like every PMW cookie it carries the pmw_ prefix. A host that strips
	 * unknown cookies before PHP (Pantheon does) has to allow it; the session
	 * fallback then applies, as before this cookie existed.
	 *
	 * @since 1.69.3
	 */
	const CONSENT_COOKIE_NAME = 'pmw_consent';

	/**
	 * Option holding the measurement of whether the consent cookie reaches
	 * PHP: how many identifier requests the browser sent with the cookie
	 * set, how many arrived with it, and the verdict once enough arrived.
	 *
	 * @since 1.69.3
	 */
	const COOKIE_DELIVERY_OPTION = 'pmw_cookie_delivery';

	/** Requests a verdict is based on. */
	const COOKIE_DELIVERY_SAMPLE = 10;

	/** How long a verdict stands before the next sample starts. */
	const COOKIE_DELIVERY_TTL = WEEK_IN_SECONDS;

	/**
	 * Order meta key holding the capture provenance: for every click ID of
	 * the snapshot, which layer delivered it (url, platform_cookie,
	 * pmw_cookie, browser_ajax, session), which capture point stamped it onto
	 * the order, and what kind of request that was (wc-ajax:checkout,
	 * wc-ajax:ppc-create-order, rest, page, ...). The request kind is what
	 * identifies the checkout flavor - classic, blocks, an express payment
	 * plugin's own endpoint - without any per-plugin knowledge.
	 */
	const PROVENANCE_META_KEY = '_pmw_click_ids_provenance';

	/** WooCommerce session key holding the layer each session click ID came from. */
	const SESSION_SOURCES_KEY = 'pmw_click_ids_src';

	/**
	 * Option holding the unix timestamp of the first request on which this
	 * shop could capture click IDs. The capture-quality report needs it to
	 * tell "no click IDs captured" apart from "these orders are older than
	 * the feature".
	 */
	const CAPTURE_START_OPTION = 'pmw_click_ids_capture_start';

	/**
	 * Fewest measured orders for which the capture-quality report names the
	 * active platforms without a single captured click ID. Below that, a
	 * platform with few paid clicks has no capture by chance, and the line
	 * would send support after a problem that is not there.
	 *
	 * @since 1.69.3
	 */
	const UNCAPTURED_REPORT_MIN_ORDERS = 30;

	/**
	 * The click IDs PMW can capture, each with the Options check that decides
	 * whether its platform is configured on this shop. Nothing is captured
	 * for a platform that is not active: a click ID is personal data, and
	 * storing identifiers a shop has no destination for would be waste.
	 *
	 * Keys are the names used in the browser's transient session identifiers.
	 *
	 * @var array<string, string>
	 */
	private static $click_id_definitions = [
		'gclid'   => 'is_google_ads_active',
		'wbraid'  => 'is_google_ads_active',
		'gbraid'  => 'is_google_ads_active',
		'fbclid'  => 'is_facebook_active',
		'ttclid'  => 'is_tiktok_active',
		'scid'    => 'is_snapchat_active',
		'epik'    => 'is_pinterest_active',
		'oppref'  => 'is_openai_active',
		'ndclid'  => 'is_nextdoor_active',
		'msclkid' => 'is_bing_active',
		'rdt_cid' => 'is_reddit_active',
		'aleid'   => 'is_applovin_active',
	];

	/**
	 * Click IDs whose URL parameter is spelled differently from the key used
	 * everywhere else. Every other platform names its parameter exactly like
	 * its key, so only the exceptions are listed here.
	 *
	 * Snap's landing parameter is ScCid, and PHP array keys are
	 * case-sensitive: without this map the URL layer looked for a parameter
	 * named "scid" that Snap never sends, so a Snap click could only ever be
	 * captured server-side once the Snap pixel itself had written _scclid -
	 * exactly the consent-blocked case this layer exists to cover.
	 *
	 * @var array<string, string>
	 * @since 1.65.2
	 */
	private static $click_id_url_parameters = [
		'scid' => 'ScCid',
	];

	/**
	 * The URL parameter a click ID arrives in, which is its own key unless
	 * the platform spells it differently.
	 *
	 * @param string $key A key of self::$click_id_definitions.
	 * @return string
	 * @since 1.65.2
	 */
	private static function get_url_parameter_name( $key ) {
		return isset(self::$click_id_url_parameters[$key]) ? self::$click_id_url_parameters[$key] : $key;
	}

	/**
	 * The click ID keys worth capturing on this shop: the ones whose platform
	 * is configured. Memoized per request.
	 *
	 * @return string[]
	 */
	public static function get_active_click_id_keys() {

		static $active = null;

		if (null !== $active) {
			return $active;
		}

		$active = [];

		foreach (self::$click_id_definitions as $key => $active_check) {
			if (method_exists(Options::class, $active_check) && call_user_func([ Options::class, $active_check ])) {
				$active[] = $key;
			}
		}

		return $active;
	}

	/**
	 * Every click ID key PMW knows, whether its platform is configured or not.
	 *
	 * @return string[]
	 * @since 1.69.3
	 */
	public static function get_all_click_id_keys() {
		return array_keys(self::$click_id_definitions);
	}

	/**
	 * The marketing consent of the visitor, as the browser last reported it.
	 *
	 * @param array|null $consent A consent snapshot, or null to read the current one (see get_current_consent()).
	 * @return array{marketing: bool, visitor_has_chosen: bool}|null Null when no snapshot exists yet.
	 * @since 1.69.3
	 */
	public static function get_consent_snapshot( $consent = null ) {

		if (null === $consent) {
			$consent = self::get_current_consent();
		}

		if (!is_array($consent)) {
			return null;
		}

		return [
			'marketing'          => !empty($consent['marketing']),
			'visitor_has_chosen' => !empty($consent['visitor_has_chosen']),
		];
	}

	/**
	 * The visitor's current consent decision, in the shape of the transient
	 * identifiers' `consent` entry.
	 *
	 * The consent cookie wins over the WooCommerce session: the browser
	 * rewrites it on every page and on every consent change, and no
	 * concurrent request can revert it, while the session copy can be
	 * overwritten by any request that saves an older snapshot of the session.
	 * The session stays the fallback for requests that carry no cookie.
	 *
	 * @return array{marketing: bool, statistics: bool, visitor_has_chosen: bool, timestamp: int, source?: string}|null Null when neither holds a decision.
	 * @since 1.69.3
	 */
	public static function get_current_consent() {

		$from_cookie = self::get_consent_from_cookie();

		if (null !== $from_cookie) {
			return $from_cookie;
		}

		$identifiers = Shop::get_transient_identifiers_from_session();

		return isset($identifiers['consent']) && is_array($identifiers['consent']) ? $identifiers['consent'] : null;
	}

	/**
	 * The consent decision carried by this request's consent cookie.
	 *
	 * Ignored on wp-admin page requests, where the cookie would belong to the
	 * shop manager's own storefront visit, not to the order being edited.
	 *
	 * @return array{marketing: bool, statistics: bool, visitor_has_chosen: bool, timestamp: int, source: string}|null
	 * @since 1.69.3
	 */
	public static function get_consent_from_cookie() {

		if (is_admin() && !wp_doing_ajax()) {
			return null;
		}

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		if (!is_array($_cookie) || !isset($_cookie[ self::CONSENT_COOKIE_NAME ])) {
			return null;
		}

		return self::parse_consent_cookie_value($_cookie[ self::CONSENT_COOKIE_NAME ]);
	}

	/**
	 * Record whether this request carried the consent cookie the browser
	 * says it set.
	 *
	 * Some hosts remove every cookie they do not know before the request
	 * reaches WordPress (Pantheon's edge does). The browser has the cookie,
	 * PHP never sees it, and server-side tracking silently falls back to the
	 * session. Only the pairing of "the browser set it" with "PHP did not get
	 * it" proves that, so only requests whose browser reported the cookie
	 * count. Writes stop once a verdict stands, so this costs at most
	 * COOKIE_DELIVERY_SAMPLE option writes a week.
	 *
	 * @return void
	 * @since 1.69.3
	 */
	public static function record_consent_cookie_delivery() {

		$arrived = null !== self::get_consent_from_cookie();
		$state   = self::evaluate_cookie_delivery(get_option(self::COOKIE_DELIVERY_OPTION, []), $arrived, time());

		if (null !== $state) {
			update_option(self::COOKIE_DELIVERY_OPTION, $state, false);
		}
	}

	/**
	 * The next state of the cookie delivery measurement.
	 *
	 * A verdict is reached after COOKIE_DELIVERY_SAMPLE requests and stands
	 * for COOKIE_DELIVERY_TTL. After that a new sample starts while the old
	 * verdict stays in place, so a fixed host clears the warning within a
	 * week and a notice never flickers between samples. "Stripped" needs
	 * fewer than one in five requests to carry the cookie: a logged-in admin
	 * testing the shop may get cookies through on some hosts, a host that
	 * strips them for shoppers is still the one to fix.
	 *
	 * @param mixed $state   The stored state.
	 * @param bool  $arrived Whether this request carried the cookie.
	 * @param int   $now     The current unix timestamp.
	 * @return array|null The new state, or null when nothing needs to be written.
	 * @since 1.69.3
	 */
	public static function evaluate_cookie_delivery( $state, $arrived, $now ) {

		$state = is_array($state) ? $state : [];
		$state = array_merge([ 'verdict' => null, 'decided_at' => 0, 'total' => 0, 'arrived' => 0 ], $state);

		if (null !== $state['verdict'] && $now - (int) $state['decided_at'] < self::COOKIE_DELIVERY_TTL) {
			return null;
		}

		$state['total']   = (int) $state['total'] + 1;
		$state['arrived'] = (int) $state['arrived'] + ( $arrived ? 1 : 0 );

		if ($state['total'] >= self::COOKIE_DELIVERY_SAMPLE) {
			$state['verdict']    = $state['arrived'] * 5 < $state['total'] ? 'stripped' : 'ok';
			$state['decided_at'] = $now;
			$state['total']      = 0;
			$state['arrived']    = 0;
		}

		return $state;
	}

	/**
	 * Whether the measurement found that the host removes PMW's cookies.
	 *
	 * @return bool
	 * @since 1.69.3
	 */
	public static function is_consent_cookie_stripped() {

		$state = get_option(self::COOKIE_DELIVERY_OPTION, []);

		return is_array($state) && isset($state['verdict']) && 'stripped' === $state['verdict'];
	}

	/**
	 * Cookie delivery section of the debug report.
	 *
	 * @return string
	 * @since 1.69.3
	 */
	public static function get_cookie_delivery_debug_info() {

		$state = get_option(self::COOKIE_DELIVERY_OPTION, []);

		if (!is_array($state) || empty($state)) {
			return 'pmw_consent reaches PHP: not measured yet' . PHP_EOL;
		}

		$verdict = isset($state['verdict']) ? $state['verdict'] : null;

		if ('stripped' === $verdict) {
			$line = 'pmw_consent reaches PHP: no, the host removes it (see https://sweetcode.com/docs/pmw/caching-and-optimization#hosts-that-remove-cookies)';
		} elseif ('ok' === $verdict) {
			$line = 'pmw_consent reaches PHP: yes';
		} else {
			$line = 'pmw_consent reaches PHP: measuring';
		}

		$line .= PHP_EOL . 'Current sample: ' . (int) $state['arrived'] . ' of ' . (int) $state['total'] . ' requests carried the cookie';

		if (!empty($state['decided_at'])) {
			$line .= PHP_EOL . 'Verdict from: ' . gmdate('Y-m-d H:i', (int) $state['decided_at']) . ' UTC';
		}

		return $line . PHP_EOL;
	}

	/**
	 * Parses the consent cookie's `m1s0c1` format. Anything else reads as no
	 * cookie, because the value is browser-written data.
	 *
	 * @param mixed $value The raw cookie value.
	 * @return array{marketing: bool, statistics: bool, visitor_has_chosen: bool, timestamp: int, source: string}|null
	 * @since 1.69.3
	 */
	public static function parse_consent_cookie_value( $value ) {

		if (!is_string($value) || !preg_match('/^m([01])s([01])c([01])$/', $value, $matches)) {
			return null;
		}

		return [
			'marketing'          => '1' === $matches[1],
			'statistics'         => '1' === $matches[2],
			'visitor_has_chosen' => '1' === $matches[3],
			'timestamp'          => time(),
			'source'             => 'cookie',
		];
	}

	/**
	 * Whether click IDs may be collected and stored for this visitor.
	 *
	 * A click ID is personal data, and keeping it in the visitor's browser or
	 * in the shop's session is storage that the ePrivacy rules tie to consent.
	 * In Explicit Consent Mode nothing is kept before marketing consent is
	 * granted. In implicit mode the click ID is held until the visitor
	 * decides, because sending is gated separately, but a visitor who denied
	 * marketing gets nothing stored. See DD-043.
	 *
	 * @param array|null $consent A consent snapshot as returned by get_consent_snapshot().
	 * @return bool
	 * @since 1.69.3
	 */
	public static function is_collection_allowed( $consent ) {

		if (is_array($consent) && true === $consent['marketing']) {
			return true;
		}

		if (Options::is_consent_management_explicit_consent_active()) {
			return false;
		}

		return !( is_array($consent) && $consent['visitor_has_chosen'] );
	}

	/**
	 * Removes every click ID PMW stored for this visitor: the WooCommerce
	 * session copy and the first-party fallback cookie. Called when the
	 * visitor denies or withdraws marketing consent.
	 *
	 * Expiring the cookie sends a Set-Cookie header, so this must only run on
	 * an uncached response (the transient-identifier endpoint).
	 *
	 * @since 1.69.3
	 */
	public static function purge() {

		if (Shop::is_woocommerce_session_active()) {
			if (WC()->session->get(self::SESSION_KEY)) {
				WC()->session->set(self::SESSION_KEY, null);
			}

			if (WC()->session->get(self::SESSION_SOURCES_KEY)) {
				WC()->session->set(self::SESSION_SOURCES_KEY, null);
			}
		}

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		foreach ([ self::COOKIE_NAME, self::LEGACY_COOKIE_NAME ] as $cookie_name) {
			if (isset($_cookie[ $cookie_name ]) && !headers_sent()) {
				setcookie($cookie_name, '', time() - HOUR_IN_SECONDS, '/', '', is_ssl(), false);
			}
		}
	}

	/**
	 * Returns the raw value of PMW's click ID cookie, falling back to its
	 * pre-1.69.3 name.
	 *
	 * @param array $_cookie The request cookies.
	 * @return string|null
	 * @since 1.69.3
	 */
	public static function get_own_cookie_raw_value( $_cookie ) {

		if (!is_array($_cookie)) {
			return null;
		}

		if (isset($_cookie[ self::COOKIE_NAME ])) {
			return $_cookie[ self::COOKIE_NAME ];
		}

		if (isset($_cookie[ self::LEGACY_COOKIE_NAME ])) {
			return $_cookie[ self::LEGACY_COOKIE_NAME ];
		}

		return null;
	}

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {

		if (!Environment::is_woocommerce_active()) {
			return;
		}

		self::stamp_capture_start();

		// Session first: a click ID reaches the shop as a URL parameter on the
		// LANDING page, which is usually not the checkout, and the parameter is
		// gone from every later request. Persisting it into the WooCommerce
		// session the moment it is seen is what makes the click ID survive to
		// order creation even when the platform's own cookie never got written
		// (consent not yet given, tag blocked) and regardless of whether the
		// browser's transient-identifier AJAX ran (it is skipped entirely while
		// the SSP is active).
		add_action('template_redirect', [ __CLASS__, 'capture_into_session' ]);

		// Then the order: the same entry points the S2S destinations use, while
		// the real browser request is still in flight. Priority 9 runs before
		// the per-destination capture at the default 10, so a destination can
		// already consult the snapshot in the same request.
		add_action('woocommerce_checkout_order_created', [ __CLASS__, 'capture_on_checkout_order' ], 9);
		add_action('woocommerce_store_api_checkout_order_processed', [ __CLASS__, 'capture_on_store_api_order' ], 9);

		// The moment the WooCommerce session is born: adding the first item
		// creates it, including via AJAX add-to-cart where template_redirect
		// never runs. Capturing here rides an existing request for free and
		// stores the IDs before any cookie could be lost mid-journey.
		add_action('woocommerce_add_to_cart', [ __CLASS__, 'capture_into_session' ], 10, 0);

		// Every remaining creation path: express payment buttons on product
		// pages (PayPal & co. create the order from their own AJAX endpoint
		// while the shopper's browser request is in flight), one-page
		// checkouts and funnel plugins. woocommerce_new_order fires for every
		// programmatic order creation; the handler captures only when a real
		// shopper request is attached, so webhook-, cron- and admin-created
		// orders contribute nothing.
		add_action('woocommerce_new_order', [ __CLASS__, 'capture_on_new_order' ], 9, 2);

		// The pay-for-order page: the order pre-exists, and a redirect
		// gateway may never bring the customer back to the confirmation
		// page, so the moment they OPEN the pay page is the one guaranteed
		// browser contact.
		add_action('before_woocommerce_pay', [ __CLASS__, 'capture_on_pay_page' ]);

		// Pay-for-order and other flows that skip the checkout pipeline: a
		// second chance on the confirmation page, never the only one.
		add_action('woocommerce_thankyou', [ __CLASS__, 'capture_on_thankyou' ], 4);
	}

	/**
	 * Records, once, when click ID capture became active on this shop.
	 *
	 * Every order older than this stamp predates the feature and can never
	 * carry a click ID, which is what the capture-quality report needs to
	 * know before it reports a rate. Reads an autoloaded option, so the
	 * common path (already stamped) costs no query.
	 */
	public static function stamp_capture_start() {

		if (get_option(self::CAPTURE_START_OPTION)) {
			return;
		}

		add_option(self::CAPTURE_START_OPTION, time(), '', 'yes');
	}

	/**
	 * Persists the click IDs of the current request into the WooCommerce
	 * session, so they are still available when the order is created (or paid
	 * later from a webhook), no matter which page the visitor landed on.
	 *
	 * Never creates a session: a visitor who has none has not interacted with
	 * the shop yet, and the platform cookie plus the order-creation capture
	 * cover that case. Writes only when something actually changed, because a
	 * session write re-serializes the whole session including the cart.
	 */
	public static function capture_into_session() {

		if (is_admin() || !Shop::is_woocommerce_session_active()) {
			return;
		}

		if (!self::is_collection_allowed(self::get_consent_snapshot())) {
			return;
		}

		$layers = self::get_click_ids_by_layer();

		$captured = [];
		$sources  = [];

		foreach ($layers as $layer => $values) {
			foreach ($values as $key => $value) {
				if (!isset($captured[$key])) {
					$captured[$key] = $value;
					$sources[$key]  = $layer;
				}
			}
		}

		if (empty($captured)) {
			return;
		}

		$stored = self::get_from_session();

		// First seen wins: the earliest value of the visit is the one closest
		// to the actual ad click.
		$merged = array_merge($captured, $stored);

		if ($merged === $stored) {
			return;
		}

		WC()->session->set(self::SESSION_KEY, $merged);

		// Remember which layer delivered each newly stored key, so the order
		// capture can report the true origin instead of just "session".
		WC()->session->set(
			self::SESSION_SOURCES_KEY,
			array_merge(
				array_intersect_key($sources, array_diff_key($merged, $stored)),
				self::get_sources_from_session()
			)
		);
	}

	/**
	 * The layer each session-stored click ID originally arrived through.
	 *
	 * @return array<string, string>
	 */
	public static function get_sources_from_session() {

		if (!Shop::is_woocommerce_session_active()) {
			return [];
		}

		$stored = WC()->session->get(self::SESSION_SOURCES_KEY, []);

		return is_array($stored) ? $stored : [];
	}

	/**
	 * The click IDs stored in the WooCommerce session during this visit.
	 *
	 * @return array<string, string>
	 */
	public static function get_from_session() {

		if (!Shop::is_woocommerce_session_active()) {
			return [];
		}

		$stored = WC()->session->get(self::SESSION_KEY, []);

		return is_array($stored) ? $stored : [];
	}

	/**
	 * Writes the click ID snapshot onto the order, merging with anything
	 * captured before (a second capture on the confirmation page can only add
	 * IDs, never overwrite a value taken during checkout).
	 *
	 * @param \WC_Order $order The order.
	 */
	public static function capture_on_checkout_order( $order ) {
		self::capture_on_order($order, 'classic_checkout');
	}

	public static function capture_on_store_api_order( $order ) {
		self::capture_on_order($order, 'block_checkout');
	}

	public static function capture_on_order( $order, $capture_point = 'unknown' ) {

		if (!$order instanceof \WC_Order) {
			return;
		}

		// Only a snapshot that says no stops the capture. A checkout that never
		// reported consent (the browser request did not run) still captures,
		// because the platform cookies and PMW's own cookie only exist once
		// consent was granted, and the outbound send is gated on its own.
		$consent = self::get_consent_snapshot();

		if (null !== $consent && !self::is_collection_allowed($consent)) {
			return;
		}

		// The session copy comes first: it was recorded on the landing page,
		// while the request-time values may be a later visit of the same
		// browser. The request only fills what the session never saw.
		$session_sources = self::get_sources_from_session();
		$layers          = array_merge(
			[ 'session' => self::get_from_session() ],
			self::get_click_ids_by_layer()
		);

		$captured = [];
		$sources  = [];

		foreach ($layers as $layer => $values) {
			foreach ($values as $key => $value) {

				if (isset($captured[$key])) {
					continue;
				}

				$captured[$key] = $value;

				// A session-delivered value keeps the layer it originally
				// arrived through, recorded when it entered the session.
				$sources[$key] = ( 'session' === $layer && isset($session_sources[$key]) )
					? $session_sources[$key]
					: $layer;
			}
		}

		if (empty($captured)) {
			return;
		}

		$existing = $order->get_meta(self::ORDER_META_KEY, true);
		$existing = is_array($existing) ? $existing : [];

		// Earlier values win: the checkout request is closer to the click.
		$snapshot = array_merge($captured, $existing);

		if ($snapshot === $existing) {
			return;
		}

		$order->update_meta_data(self::ORDER_META_KEY, $snapshot);

		// Provenance for the keys this capture added: which layer delivered
		// the value, which capture point stamped it, and what kind of request
		// that was. Existing entries are never rewritten - they describe the
		// capture that actually won.
		$provenance = $order->get_meta(self::PROVENANCE_META_KEY, true);
		$provenance = is_array($provenance) ? $provenance : [];

		$request_context = self::get_request_context();

		foreach (array_diff_key($snapshot, $existing) as $key => $value) {
			$provenance[$key] = [
				'layer'   => isset($sources[$key]) ? $sources[$key] : 'unknown',
				'hook'    => $capture_point,
				'request' => $request_context,
			];
		}

		$order->update_meta_data(self::PROVENANCE_META_KEY, $provenance);

		// The S2S destinations batch their own saves; when none of them runs
		// (no server-side pixel configured) the order still needs persisting.
		$order->save();

		Logger::debug('Click IDs captured on order ' . $order->get_id() . ': ' . implode(', ', array_keys($snapshot)));
	}

	/**
	 * Classifies the current request, because the request type is what
	 * identifies the checkout flavor across the ecosystem: the classic
	 * checkout posts to wc-ajax:checkout, the blocks checkout talks to the
	 * Store API, and every express payment plugin creates its order through
	 * its own wc-ajax endpoint, whose name this returns verbatim.
	 *
	 * @return string
	 */
	private static function get_request_context() {

		$_get = Helpers::get_input_vars(INPUT_GET);

		if (is_array($_get) && !empty($_get['wc-ajax'])) {
			return 'wc-ajax:' . Helpers::generic_sanitization($_get['wc-ajax']);
		}

		if (defined('REST_REQUEST') && REST_REQUEST) {
			return 'rest';
		}

		if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
			return 'admin-ajax';
		}

		if (defined('DOING_CRON') && DOING_CRON) {
			return 'cron';
		}

		return 'page';
	}

	/**
	 * Confirmation page capture, for flows where no checkout hook fired
	 * (pay-for-order links, some express checkouts). Skipped for shop
	 * managers so a staff preview cannot stamp its own session onto the order.
	 *
	 * @param int $order_id The order ID.
	 */
	public static function capture_on_thankyou( $order_id ) {

		if (!$order_id || current_user_can('manage_woocommerce')) {
			return;
		}

		self::capture_on_order(wc_get_order($order_id), 'confirmation_page');
	}

	/**
	 * Captures on every programmatic order creation that happens inside a
	 * shopper's own request: express payment buttons (PayPal smart buttons
	 * on product pages create the order via their own AJAX endpoint before
	 * any checkout hook fires), Store API draft orders, funnel builders.
	 *
	 * Orders created without a shopper browser (webhooks, cron, importers)
	 * carry no cookies and no session, so the capture is a natural no-op
	 * there. Admin and staff requests are excluded explicitly, because they
	 * DO carry cookies - the staff member's own - and stamping those onto a
	 * customer's order would corrupt the snapshot.
	 *
	 * @param int            $order_id The order ID.
	 * @param \WC_Order|null $order    The order, when the hook provides it.
	 */
	public static function capture_on_new_order( $order_id, $order = null ) {

		if (is_admin() || current_user_can('manage_woocommerce')) {
			return;
		}

		if (!$order instanceof \WC_Order) {
			$order = wc_get_order($order_id);
		}

		self::capture_on_order($order, 'order_created');
	}

	/**
	 * Captures when a customer opens the pay-for-order page. The order was
	 * created earlier (manually, or by a flow that had no browser), and a
	 * redirect gateway may never bring the customer back to the confirmation
	 * page - this render is the one guaranteed browser contact.
	 *
	 * The order key is verified so a guessed order ID cannot stamp a foreign
	 * session onto someone else's order.
	 */
	public static function capture_on_pay_page() {

		if (current_user_can('manage_woocommerce')) {
			return;
		}

		global $wp;

		$order_id = isset($wp->query_vars['order-pay']) ? absint($wp->query_vars['order-pay']) : 0;

		if (!$order_id) {
			return;
		}

		$_get = Helpers::get_input_vars(INPUT_GET);
		$key  = isset($_get['key']) ? (string) $_get['key'] : '';

		if ('' === $key) {
			return;
		}

		$order = wc_get_order($order_id);

		if (!$order instanceof \WC_Order || !hash_equals($order->get_order_key(), $key)) {
			return;
		}

		self::capture_on_order($order, 'pay_page');
	}

	/**
	 * Reads every click ID available in the current request: the platform
	 * cookies first (they survive a multi-page journey), then the values the
	 * browser shipped into the WooCommerce session, then the URL parameters
	 * of this very request.
	 *
	 * @return array<string, string>
	 */
	public static function get_click_ids_from_browser() {

		$click_ids = [];

		foreach (self::get_click_ids_by_layer() as $values) {
			$click_ids = array_merge($values, $click_ids);
		}

		return $click_ids;
	}

	/**
	 * Every click ID available in the current request, grouped by the layer
	 * that delivered it and ordered by precedence: the platform tags' own
	 * cookies (most durable, canonical), PMW's fallback cookie, the values
	 * the browser shipped into the WooCommerce session, and finally the URL
	 * parameters of this very request. Earlier layers win; each key appears
	 * only in the first layer that holds it.
	 *
	 * @return array<string, array<string, string>>
	 */
	public static function get_click_ids_by_layer() {

		if (Helpers::is_iframe()) {
			return [];
		}

		$active_keys = self::get_active_click_id_keys();

		if (empty($active_keys)) {
			return [];
		}

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);
		$_cookie = is_array($_cookie) ? $_cookie : [];

		$layers = [];

		// 1. Cookies written by the platform tags (most durable).
		$layers['platform_cookie'] = array_intersect_key(
			array_merge(
				Pixels\Google\Google_Helpers::get_click_ids_from_browser__premium_only(),
				self::extract_click_ids_from_platform_cookies($_cookie, $active_keys)
			),
			array_flip($active_keys)
		);

		// 2. PMW's own fallback cookie, written by the browser on the landing
		//    page and refreshed server-side.
		$own_cookie           = self::get_own_cookie_raw_value($_cookie);
		$layers['pmw_cookie'] = null !== $own_cookie
			? self::extract_click_ids_from_own_cookie_value($own_cookie, $active_keys)
			: [];

		// 3. The transient session identifiers the browser posts on cart and
		//    checkout pages (already validated on write).
		$transient_identifiers = Shop::get_transient_identifiers_from_session();
		$layers['browser_ajax'] = [];

		foreach ($active_keys as $key) {
			if (!empty($transient_identifiers[$key])) {
				$layers['browser_ajax'][$key] = $transient_identifiers[$key];
			}
		}

		// 4. URL parameters of the current request (single-page journeys).
		$_get           = Helpers::get_input_vars(INPUT_GET);
		$layers['url'] = [];

		if (is_array($_get)) {
			foreach ($active_keys as $key) {

				$parameter = self::get_url_parameter_name($key);

				// Validated like the cookie layer, so a crafted landing URL cannot park an
				// arbitrary string in the order's click ID snapshot. @since 1.69.1
				if (!empty($_get[$parameter]) && is_string($_get[$parameter]) && self::is_plausible($key, $_get[$parameter])) {
					$layers['url'][$key] = Helpers::generic_sanitization($_get[$parameter]);
				}
			}
		}

		// Deduplicate across layers so each key reports the layer that
		// actually wins, and drop empty values.
		$seen = [];

		foreach ($layers as $layer => $values) {
			$layers[$layer] = array_filter(array_diff_key($values, $seen));
			$seen           = array_merge($seen, $layers[$layer]);
		}

		return $layers;
	}

	/**
	 * Parses PMW's own first-party click ID cookie: URL-encoded JSON written
	 * by the browser. Every entry is checked against the platform's own
	 * validator, so a tampered cookie can never plant an implausible value.
	 *
	 * @param mixed    $raw         Raw cookie value.
	 * @param string[] $active_keys The click ID keys worth extracting.
	 * @return array<string, string>
	 */
	public static function extract_click_ids_from_own_cookie_value( $raw, $active_keys ) {

		if (!is_string($raw) || '' === $raw || strlen($raw) > self::COOKIE_MAX_LENGTH) {
			return [];
		}

		$decoded = json_decode(rawurldecode($raw), true);

		if (!is_array($decoded)) {
			return [];
		}

		$click_ids = [];

		foreach ($active_keys as $key) {
			if (isset($decoded[$key]) && is_string($decoded[$key]) && self::is_plausible($key, $decoded[$key])) {
				$click_ids[$key] = $decoded[$key];
			}
		}

		return $click_ids;
	}

	/**
	 * Whether a value is a plausible click ID for its key, checked with the
	 * same validators the destinations apply at send time.
	 *
	 * @param string $key   A key of self::$click_id_definitions.
	 * @param string $value The candidate value.
	 * @return bool
	 */
	public static function is_plausible( $key, $value ) {

		switch ($key) {
			case 'gclid':
				return Pixels\Google\Google_Helpers::is_valid_gclid($value);
			case 'wbraid':
			case 'gbraid':
				return Pixels\Google\Google_Helpers::is_valid_braid($value);
			case 'fbclid':
				return Pixels\Facebook\Facebook_CAPI::is_valid_fbc($value);
			case 'ttclid':
				return Pixels\TikTok\TikTok_EAPI::is_valid_ttclid($value);
			case 'epik':
				return Pixels\Pinterest\Pinterest_APIC::is_valid_epik($value);
			case 'oppref':
				return Pixels\OpenAI\OpenAI_CAPI::is_valid_oppref($value);
			case 'ndclid':
				return Pixels\Nextdoor\Nextdoor_CAPI::is_valid_ndclid($value);
			case 'msclkid':
				return Pixels\Bing\Bing_CAPI::is_valid_msclkid($value);
			case 'aleid':
				return Pixels\AppLovin\AppLovin_CAPI::is_valid_aleid($value);
			// Snap and Reddit publish no format spec; permissive plausibility bounds.
			case 'scid':
			case 'rdt_cid':
				return (bool) preg_match('/^[A-Za-z0-9._~=-]{5,500}$/', $value);
		}

		return false;
	}

	/**
	 * Re-sends the fallback cookie as an HTTP header with the full 90-day
	 * expiry. Safari's ITP caps JavaScript-written cookies at 7 days; a
	 * server-set cookie is exempt, so this call - made from PMW's own AJAX
	 * endpoint, which is uncached by definition - upgrades the lifetime.
	 *
	 * Never called during regular page renders: a page cache could store the
	 * Set-Cookie header and serve one visitor's click IDs to everyone.
	 *
	 * Requires granted marketing consent, the same rule the browser's cookie
	 * writer follows. Before 1.69.3 this ran regardless of consent and set
	 * the 90-day cookie for visitors who had denied marketing.
	 *
	 * @param array      $click_ids Click IDs to persist, merged over the cookie's current content.
	 * @param array|null $consent   The visitor's consent snapshot (see get_consent_snapshot()).
	 */
	public static function send_refreshed_cookie( $click_ids, $consent = null ) {

		if (headers_sent() || empty($click_ids)) {
			return;
		}

		if (!is_array($consent) || true !== $consent['marketing']) {
			return;
		}

		$active_keys = self::get_active_click_id_keys();

		$_cookie    = Helpers::get_input_vars(INPUT_COOKIE);
		$own_cookie = self::get_own_cookie_raw_value($_cookie);
		$existing   = null !== $own_cookie
			? self::extract_click_ids_from_own_cookie_value($own_cookie, $active_keys)
			: [];

		$merged = array_merge($existing, array_intersect_key($click_ids, array_flip($active_keys)));

		$value = rawurlencode(wp_json_encode($merged));

		if (strlen($value) > self::COOKIE_MAX_LENGTH) {
			return;
		}

		setcookie(self::COOKIE_NAME, $value, time() + 90 * DAY_IN_SECONDS, '/', '', is_ssl(), false);

		// Its content now lives under the new name.
		if (is_array($_cookie) && isset($_cookie[ self::LEGACY_COOKIE_NAME ])) {
			setcookie(self::LEGACY_COOKIE_NAME, '', time() - HOUR_IN_SECONDS, '/', '', is_ssl(), false);
		}
	}

	/**
	 * Extracts the non-Google click IDs out of the platform tags' first-party
	 * cookies. Values are checked with the same validators the destinations
	 * apply at send time, so the snapshot never stores a shape the platform
	 * would reject.
	 *
	 * @param array    $cookies     Cookie name => raw value.
	 * @param string[] $active_keys The click ID keys worth extracting.
	 * @return array<string, string>
	 */
	public static function extract_click_ids_from_platform_cookies( $cookies, $active_keys ) {

		$click_ids = [];

		// Meta: _fbc carries fb.<subdomain>.<timestamp>.<fbclid>. Stored in
		// that same fbc shape, matching the transient identifiers and what
		// Meta's CAPI sends.
		if (in_array('fbclid', $active_keys, true) && !empty($cookies['_fbc'])
			&& Pixels\Facebook\Facebook_CAPI::is_valid_fbc($cookies['_fbc'])) {
			$click_ids['fbclid'] = (string) $cookies['_fbc'];
		}

		if (in_array('ttclid', $active_keys, true) && !empty($cookies['_ttclid'])
			&& Pixels\TikTok\TikTok_EAPI::is_valid_ttclid($cookies['_ttclid'])) {
			$click_ids['ttclid'] = (string) $cookies['_ttclid'];
		}

		// Snap: the pixel persists the ScCid landing parameter into _scclid.
		if (in_array('scid', $active_keys, true) && !empty($cookies['_scclid'])
			&& is_string($cookies['_scclid']) && self::is_plausible('scid', $cookies['_scclid'])) {
			$click_ids['scid'] = (string) $cookies['_scclid'];
		}

		if (in_array('epik', $active_keys, true) && !empty($cookies['_epik'])
			&& Pixels\Pinterest\Pinterest_APIC::is_valid_epik($cookies['_epik'])) {
			$click_ids['epik'] = (string) $cookies['_epik'];
		}

		if (in_array('oppref', $active_keys, true) && !empty($cookies['__oppref'])) {

			$oppref = Pixels\OpenAI\OpenAI_CAPI::normalize_oppref_cookie_value($cookies['__oppref']);

			if (null !== $oppref) {
				$click_ids['oppref'] = $oppref;
			}
		}

		if (in_array('ndclid', $active_keys, true) && !empty($cookies['ndclid'])
			&& Pixels\Nextdoor\Nextdoor_CAPI::is_valid_ndclid($cookies['ndclid'])) {
			$click_ids['ndclid'] = (string) $cookies['ndclid'];
		}

		if (in_array('msclkid', $active_keys, true) && !empty($cookies['_uetmsclkid'])) {

			$msclkid = self::normalize_uet_msclkid($cookies['_uetmsclkid']);

			if ('' !== $msclkid) {
				$click_ids['msclkid'] = $msclkid;
			}
		}

		// Reddit writes its click ID into its own cookie under a different name
		if (in_array('rdt_cid', $active_keys, true) && !empty($cookies['rdtCid'])
			&& is_string($cookies['rdtCid']) && self::is_plausible('rdt_cid', $cookies['rdtCid'])) {
			$click_ids['rdt_cid'] = (string) $cookies['rdtCid'];
		}

		// AppLovin: the pixel copies the aleid landing parameter into _axeid.
		if (in_array('aleid', $active_keys, true) && !empty($cookies['_axeid'])
			&& Pixels\AppLovin\AppLovin_CAPI::is_valid_aleid($cookies['_axeid'])) {
			$click_ids['aleid'] = (string) $cookies['_axeid'];
		}

		return $click_ids;
	}

	/**
	 * Extracts the msclkid out of the _uetmsclkid cookie Microsoft's UET tag
	 * writes. The cookie value is the click ID itself, but UET has shipped it
	 * with a "_uet" prefix and with a "-<n>" freshness marker appended, so
	 * both decorations are stripped before validating.
	 *
	 * @param mixed $value Raw cookie value.
	 * @return string The msclkid, or an empty string when implausible.
	 */
	private static function normalize_uet_msclkid( $value ) {

		if (!is_string($value) || '' === $value) {
			return '';
		}

		if (Pixels\Bing\Bing_CAPI::is_valid_msclkid($value)) {
			return $value;
		}

		if ('_uet' === substr($value, 0, 4)) {
			$value = substr($value, 4);
		}

		$value = preg_replace('/-\d$/', '', $value);

		return Pixels\Bing\Bing_CAPI::is_valid_msclkid($value) ? $value : '';
	}

	/**
	 * The stored snapshot of an order.
	 *
	 * @param \WC_Order $order The order.
	 * @return array<string, string>
	 */
	public static function get_from_order( $order ) {

		$snapshot = $order->get_meta(self::ORDER_META_KEY, true);

		return is_array($snapshot) ? $snapshot : [];
	}

	/**
	 * One click ID of an order, with the destinations' own historical meta as
	 * fallback so orders placed before this snapshot existed still resolve.
	 *
	 * @param \WC_Order $order The order.
	 * @param string    $key   A key of self::$click_id_keys.
	 * @return string The click ID, or an empty string.
	 */
	public static function get_click_id_from_order( $order, $key ) {

		$snapshot = self::get_from_order($order);

		if (!empty($snapshot[$key])) {
			return (string) $snapshot[$key];
		}

		// Historical fallbacks, in order of reach.
		if ('gclid' === $key) {

			$legacy = $order->get_meta('_wpm_gclid', true);

			if (!empty($legacy)) {
				return (string) $legacy;
			}

			// GA4 MP stored the click ID per order at checkout time long
			// before this snapshot existed.
			$measurement_id = Options::get_ga4_measurement_id();

			if (!empty($measurement_id)) {

				$ga4_identifiers = $order->get_meta('google_cid_' . $measurement_id, true);

				if (is_array($ga4_identifiers) && !empty($ga4_identifiers['gclid'])) {
					return (string) $ga4_identifiers['gclid'];
				}
			}
		}

		return '';
	}

	/**
	 * Capture-quality aggregates over the newest orders, for the copy-paste
	 * debug report customers attach to support tickets. Counts only - no
	 * click ID values, no PII - so the section is safe to share and lets us
	 * spot capture patterns across shops over time: which layer delivers the
	 * IDs, through which kind of checkout request, and how often the capture
	 * still succeeds when the browser pixel never fired.
	 *
	 * @return string Empty when there is nothing to report.
	 */
	public static function get_debug_info() {

		if (!function_exists('wc_get_orders')) {
			return '';
		}

		$orders = wc_get_orders([
			'limit'   => 250,
			'orderby' => 'date',
			'order'   => 'DESC',
			'type'    => 'shop_order',
		]);

		if (empty($orders)) {
			return '';
		}

		$rows = [];

		foreach ($orders as $order) {

			$provenance = $order->get_meta(self::PROVENANCE_META_KEY, true);
			$created    = $order->get_date_created();

			$rows[] = [
				'keys'          => array_keys(self::get_from_order($order)),
				'browser_fired' => $order->meta_exists('_wpm_conversion_pixel_fired'),
				'provenance'    => is_array($provenance) ? $provenance : [],
				'created'       => $created ? $created->getTimestamp() : 0,
				'created_via'   => $order->get_created_via(),
			];
		}

		return self::format_capture_quality_report($rows, self::get_capture_start($rows), self::get_active_click_id_keys());
	}

	/**
	 * When click ID capture became possible on this shop.
	 *
	 * Primarily the stamp written on the first request that could capture.
	 * Shops that already ran a capturing version before the stamp existed
	 * have no stamp for that period, so the oldest scanned order that carries
	 * a snapshot lowers it: an order proves capture was running when it was
	 * created.
	 *
	 * @param array $rows One entry per scanned order, as built above.
	 * @return int Unix timestamp, or 0 when nothing tells us.
	 */
	public static function get_capture_start( $rows ) {

		$start = (int) get_option(self::CAPTURE_START_OPTION);

		foreach ($rows as $row) {

			if (empty($row['keys']) || empty($row['created'])) {
				continue;
			}

			if (0 === $start || (int) $row['created'] < $start) {
				$start = (int) $row['created'];
			}
		}

		return $start;
	}

	/**
	 * The armed platforms of which not a single order carries a click ID,
	 * each given as its keys joined with a slash.
	 *
	 * A platform with several keys counts as captured as soon as one of them
	 * is: Google's wbraid and gbraid only appear on iOS app and web-to-app
	 * clicks, so a zero on them next to a healthy gclid count is normal and
	 * flagging it would train support to ignore the line.
	 *
	 * @param string[]           $active_keys The click ID keys armed on this shop.
	 * @param array<string, int> $key_counts  Orders per key.
	 * @return string[]
	 * @since 1.69.3
	 */
	private static function get_uncaptured_platform_keys( $active_keys, $key_counts ) {

		$platforms = [];

		foreach ($active_keys as $key) {

			if (!isset(self::$click_id_definitions[$key])) {
				continue;
			}

			$platforms[self::$click_id_definitions[$key]][] = $key;
		}

		$uncaptured = [];

		foreach ($platforms as $keys) {

			$captured = 0;

			foreach ($keys as $key) {
				$captured += isset($key_counts[$key]) ? (int) $key_counts[$key] : 0;
			}

			if (0 === $captured) {
				$uncaptured[] = implode('/', $keys);
			}
		}

		return $uncaptured;
	}

	/**
	 * Renders the capture-quality aggregates. Split from the order scan so
	 * the formatting is testable without WooCommerce.
	 *
	 * The scan reaches back 250 orders, which on most shops is months of
	 * history, while capture only exists since 1.66.0. Orders older than that
	 * can never carry a click ID, so counting them reports a capture rate of
	 * 0% on every shop that just updated - indistinguishable from capture
	 * being broken. The aggregates therefore run over the orders created
	 * since capture became active, and the report says which date that is.
	 *
	 * @param array    $rows          One entry per order: keys, browser_fired, provenance, created, created_via.
	 * @param int      $capture_start Unix timestamp of when capture became active, 0 when unknown.
	 * @param string[] $active_keys   The click ID keys armed on this shop. Those without a single capture are
	 *                                listed, and named from UNCAPTURED_REPORT_MIN_ORDERS measured orders on,
	 *                                see get_uncaptured_platform_keys(). @since 1.69.3
	 * @return string
	 */
	public static function format_capture_quality_report( $rows, $capture_start = 0, $active_keys = [] ) {

		if (0 === count($rows)) {
			return '';
		}

		$capture_start = (int) $capture_start;
		$created       = [];

		foreach ($rows as $row) {
			if (!empty($row['created'])) {
				$created[] = (int) $row['created'];
			}
		}

		$range = empty($created)
			? ''
			: ' (' . gmdate('Y-m-d', min($created)) . ' to ' . gmdate('Y-m-d', max($created)) . ')';

		$html = 'Orders scanned (newest first):     ' . count($rows) . $range . PHP_EOL;

		$scoped = $rows;

		if ($capture_start > 0) {

			$scoped = [];

			foreach ($rows as $row) {

				// An order without a creation date cannot be placed on either
				// side of the line, so it stays in rather than skewing the rate.
				if (empty($row['created']) || (int) $row['created'] >= $capture_start) {
					$scoped[] = $row;
				}
			}

			$html .= 'Click ID capture active since:     ' . gmdate('Y-m-d', $capture_start) . PHP_EOL;
			$html .= 'Orders created since then:         ' . count($scoped) . PHP_EOL;
		}

		if (empty($scoped)) {
			return $html
				. 'No order was created after click ID capture became active on this shop,' . PHP_EOL
				. 'so there is nothing to measure yet. Check again once orders come in.' . PHP_EOL;
		}

		$total            = count($scoped);
		$with_ids         = 0;
		$browser_missed   = 0;
		$missed_covered   = 0;
		$missed_off_store = 0;
		$off_storefront   = 0;
		$key_counts       = [];
		$layer_counts     = [];
		$capture_counts   = [];
		$origin_counts    = [];
		$storefront       = Shop::get_tracking_accuracy_created_via_allowlist();

		foreach ($scoped as $row) {

			$has_ids = !empty($row['keys']);

			if ($has_ids) {
				$with_ids++;
			}

			// An order that did not come through a browser checkout has no
			// browser event by design, so it has to be countable separately
			// from one that should have had a browser event and lost it.
			// An order whose origin WooCommerce never recorded proves neither,
			// so it counts towards nothing but the breakdown.
			$origin        = empty($row['created_via']) ? 'unknown' : (string) $row['created_via'];
			$off_store_row = 'unknown' !== $origin && !in_array($origin, $storefront, true);

			$origin_counts[$origin] = isset($origin_counts[$origin]) ? $origin_counts[$origin] + 1 : 1;

			if ($off_store_row) {
				$off_storefront++;
			}

			if (empty($row['browser_fired'])) {
				$browser_missed++;
				if ($has_ids) {
					$missed_covered++;
				}
				if ($off_store_row) {
					$missed_off_store++;
				}
			}

			foreach ($row['keys'] as $key) {
				$key_counts[$key] = isset($key_counts[$key]) ? $key_counts[$key] + 1 : 1;
			}

			foreach ($row['provenance'] as $entry) {

				if (!is_array($entry)) {
					continue;
				}

				$layer = isset($entry['layer']) ? $entry['layer'] : 'unknown';
				$point = ( isset($entry['hook']) ? $entry['hook'] : 'unknown' )
					. ' via ' . ( isset($entry['request']) ? $entry['request'] : 'unknown' );

				$layer_counts[$layer]   = isset($layer_counts[$layer]) ? $layer_counts[$layer] + 1 : 1;
				$capture_counts[$point] = isset($capture_counts[$point]) ? $capture_counts[$point] + 1 : 1;
			}
		}

		arsort($key_counts);
		arsort($layer_counts);
		arsort($capture_counts);
		arsort($origin_counts);

		$pct = function ( $part, $whole ) {
			return $whole > 0 ? round(( $part / $whole ) * 100) . '%' : 'n/a';
		};

		$html .= 'With at least one click ID:        ' . $with_ids . ' (' . $pct($with_ids, $total) . ')' . PHP_EOL;
		$html .= 'Browser conversion pixel missed:   ' . $browser_missed . PHP_EOL;
		$html .= '  of those, with a click ID:       ' . $missed_covered . ( $browser_missed > 0 ? ' (' . $pct($missed_covered, $browser_missed) . ')' : '' ) . PHP_EOL;

		/**
		 * Without this line the section reads as a defect on any shop that takes
		 * orders from anywhere but its own checkout. "Browser conversion pixel
		 * missed: 201" next to a Payment Gateway Tracking Accuracy of 95% looks
		 * like a contradiction, and it is not: the two count different order
		 * populations. This one counts every scanned order, that one counts only
		 * the storefront checkout. An order created over the REST API, in the
		 * admin, or by a subscription renewal never loads a purchase confirmation
		 * page, so it can neither fire a browser pixel nor carry a click ID.
		 *
		 * It also explains a server-to-browser event ratio well above 1 in an ad
		 * platform's reporting, because the server-side purchase runs for every
		 * paid order whatever its origin. Ticket 3448373394.
		 */
		$html .= '  of those, not storefront orders: ' . $missed_off_store . ( $browser_missed > 0 ? ' (' . $pct($missed_off_store, $browser_missed) . ')' : '' ) . PHP_EOL;
		$html .= str_pad('Not from the storefront checkout:', 35) . $off_storefront . ' (' . $pct($off_storefront, $total) . ')' . PHP_EOL;

		/**
		 * An armed key that was never captured used to be absent from this line,
		 * and an absent key reads as "not relevant here" rather than as "broken".
		 * A shop running Microsoft Ads whose msclkid capture fails therefore got
		 * a report that looked healthy. Every armed key is listed, zeros
		 * included, and from 30 measured orders on a platform without a single
		 * capture is named below.
		 */
		$active_keys = is_array($active_keys) ? $active_keys : [];

		foreach ($active_keys as $key) {
			if (!isset($key_counts[$key])) {
				$key_counts[$key] = 0;
			}
		}

		if (!empty($key_counts)) {
			$parts = [];
			foreach ($key_counts as $key => $count) {
				$parts[] = $key . ' ' . $count;
			}
			$html .= 'Click IDs by key:                  ' . implode(', ', $parts) . PHP_EOL;
		}

		// Worded neutrally and without a marker: no capture over a few dozen
		// orders is just as often a platform without paid clicks as a broken
		// capture, so the line states the fact and both readings.
		$uncaptured = $total >= self::UNCAPTURED_REPORT_MIN_ORDERS
			? self::get_uncaptured_platform_keys($active_keys, $key_counts)
			: [];

		if (!empty($uncaptured)) {
			$html .= 'No click ID captured for:          ' . implode(', ', $uncaptured)
				. ' (none in ' . $total . ' orders: either no paid clicks from '
				. ( count($uncaptured) > 1 ? 'these platforms' : 'this platform' )
				. ', or capture is failing)' . PHP_EOL;
		}

		if (!empty($origin_counts)) {
			$html .= 'Order origin (created_via):' . PHP_EOL;
			foreach ($origin_counts as $origin => $count) {
				$html .= '  ' . str_pad($origin . ': ', 33) . $count
					. ( in_array($origin, $storefront, true) ? ' (storefront)' : '' ) . PHP_EOL;
			}
		}

		if (!empty($layer_counts)) {
			$html .= 'Capture layer (per click ID):' . PHP_EOL;
			foreach ($layer_counts as $layer => $count) {
				$html .= '  ' . str_pad($layer . ': ', 33) . $count . PHP_EOL;
			}
		}

		if (!empty($capture_counts)) {
			$html .= 'Capture point (per click ID):' . PHP_EOL;
			foreach ($capture_counts as $point => $count) {
				$html .= '  ' . str_pad($point . ': ', 33) . $count . PHP_EOL;
			}
		}

		return $html;
	}
}
