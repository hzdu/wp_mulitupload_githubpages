<?php

// TODO move script for copying debug info into a proper .js enqueued file, or switch tabs to JavaScript switching and always save all settings at the same time

namespace SweetCode\Pixel_Manager\Admin;

use SweetCode\Pixel_Manager\Admin\Notifications\Notifications;
use SweetCode\Pixel_Manager\Admin\Notifications\Trial_Promotion_Notification;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunities;
use SweetCode\Pixel_Manager\First_Event_Confirmation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Optimizely_Security;
use SweetCode\Pixel_Manager\Pixels\Google\Google_Helpers;
use SweetCode\Pixel_Manager\Pixels\Pixel_Manager;
use SweetCode\Pixel_Manager\Shop;
use SweetCode\Pixel_Manager\Social_Login;
use SweetCode\Pixel_Manager\Tracking_Accuracy_DB;
use WP_Post;

defined('ABSPATH') || exit; // Exit if accessed directly

class Admin {

	private static $did_init = false;

	public static function init() {

		if (self::$did_init) {
			return;
		}

		self::$did_init = true;

		self::init_admin();
	}

	public static function init_admin() {

		add_action('admin_enqueue_scripts', [ __CLASS__, 'wpm_admin_scripts' ]);

		add_action('admin_enqueue_scripts', [ __CLASS__, 'pmw_edit_order_scripts' ]);

		add_action('admin_enqueue_scripts', [ __CLASS__, 'wpm_admin_css' ]);

		// add the admin options page
		add_action('admin_menu', [ __CLASS__, 'plugin_admin_add_page' ], 99);

		// add the WordPress dashboard overview widget
		Dashboard_Widget::init();

		// Clear the retired per-user interface choice (before output).
		add_action('admin_init', [ __CLASS__, 'clean_up_legacy_theme_choice' ]);

		// install a settings page in the admin console
		add_action('admin_init', [ __CLASS__, 'plugin_admin_init' ]);

		add_action('admin_init', [ __CLASS__, 'add_order_extra_details' ]);

		// add admin scripts to plugins.php page
		add_action('load-plugins.php', [ __CLASS__, 'freemius_load_deactivation_button_js' ]);

		// DeleteIf(wcMarketFree)
		wpm_fs()->add_filter('templates/checkout.php', [ __CLASS__, 'fs_inject_additional_scripts' ]);
		wpm_fs()->add_filter('checkout/purchaseCompleted', [ __CLASS__, 'fs_after_purchase_js' ]);
		// endDeleteIf(wcMarketFree)

		// Load textdomain
		add_action('init', [ __CLASS__, 'load_plugin_textdomain' ]);
		// end __construct

		if (wpm_fs()->can_use_premium_code__premium_only()) {

			// if self::google->is_ga4_data_api_active() is not true or if Options::is_order_level_ltv_calculation_active() is not true then don't add the meta box
			if (Helpers::can_order_modal_be_shown()) {
				// add the meta box to the order page

				// https://stackoverflow.com/a/45617265/4688612
				// https://stackoverflow.com/a/37780501/4688612
				add_action('add_meta_boxes', function () {

					$screen = Helpers::is_wc_hpos_enabled() && wc_get_container()->get(\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class)->custom_orders_table_usage_is_enabled()
						? wc_get_page_screen_id('shop-order')
						: 'shop_order';

					add_meta_box(
						'pixel-manager-order-modal',
						esc_html__('Pixel Manager', 'woocommerce-google-adwords-conversion-tracking-tag') . self::html_beta(),
						[ __CLASS__, 'pmw_order_modal__premium_only' ],
						$screen,
						'side',
						'core'
					);
				});
			}
		}

		add_action('admin_head', [ __CLASS__, 'output_cody_availability' ]);

		// output some info into the pmwDataLayer object in the header
		add_action('admin_head', [ __CLASS__, 'wpm_data_layer' ]);
	}

	/**
	 * Outputs a JavaScript variable indicating the availability of the Pixie chat widget.
	 *
	 * This function checks the accessibility of the chat widget URL and sets the `pmw_cody`
	 * JavaScript variable with the availability and URL. It only executes on the PMW settings page.
	 *
	 * @return void This method does not return a value, as it outputs directly to the page.
	 *
	 * @since 1.45.1
	 */
	public static function output_cody_availability() {

		$chat_url = 'https://engadin.sweetcode.com/chat?agent=sweetcode&embed=1';

		// Only run on PMW settings pages
		if (!Environment::is_pmw_settings_page()) {
			return;
		}

		$is_available = Helpers::is_url_accessible($chat_url);

		// Cache the result for the admin-menu badge (Onboarding::get_open_steps_count()),
		// which runs on every admin page and must not perform a remote check itself.
		set_transient(Onboarding::$cody_available_transient, $is_available ? 'yes' : 'no', DAY_IN_SECONDS);

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON for an inline script, escaped by Helpers::json_encode_for_script()
		?>
		<script>
			var pmw_cody = {
				available: <?php echo esc_html($is_available ? 'true' : 'false'); ?>,
				url      : <?php echo Helpers::json_encode_for_script($chat_url); ?>,
			};
		</script>
		<?php
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped

		// Output the floating chatbot widget button
		if ($is_available) :
			?>
			<div id="pmw-chatbot-widget" style="display: none;">
				<button type="button" id="pmw-chatbot-toggle" class="pmw-chatbot-toggle" aria-label="<?php esc_attr_e('Open chat', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="28" height="28">
						<path d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z"/>
						<path d="M12 5l-1.5 3-3.5.5 2.5 2.5-.5 3.5 3-1.5 3 1.5-.5-3.5 2.5-2.5-3.5-.5z" opacity="0.6"/>
					</svg>
				</button>
			</div>

			<!-- Chatbot Side Panel -->
			<div id="pmw-chatbot-panel" class="pmw-chatbot-panel">
				<div class="pmw-chatbot-panel-header">
					<h3><?php esc_html_e('Chat with Pixie', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h3>
					<button type="button" id="pmw-chatbot-close" class="pmw-chatbot-close" aria-label="<?php esc_attr_e('Close chat', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
							<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/>
						</svg>
					</button>
				</div>
				<div class="pmw-chatbot-panel-content">
					<iframe id="pmw-chatbot-iframe" src="" frameborder="0" allow="microphone"></iframe>
				</div>
			</div>
			<?php
		endif;
	}

	public static function wpm_data_layer() {

		$data['version'] = Helpers::get_version_info();

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON for an inline script, escaped by Helpers::json_encode_for_script()
		?>
		<script>
			var pmwDataLayer = <?php echo Helpers::json_encode_for_script($data); ?>;
		</script>
		<?php
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public static function pmw_order_modal__premium_only( $post_or_order_object ) {

		$order
			= ( $post_or_order_object instanceof WP_Post )
			? wc_get_order($post_or_order_object->ID)
			: $post_or_order_object;
		?>
		<div class="pmw order-modal">
			<?php if (Options::is_ga4_data_api_active()) : ?>
				<div class="section">
					<div class="title">
						<h1><?php esc_html_e('GA4 Attribution', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h1>
						<?php self::get_documentation_html_by_key('ga4_data_api'); ?>
					</div>
					<div class="data" id="order-attribution-data"
						data-order-id="<?php echo (int) $order->get_id(); ?>">
						<span>fetching data...</span>
					</div>
				</div>
			<?php endif; ?>
			<?php if (LTV::get_total_ltv_from_order($order)) : ?>
				<div class="section">
					<div class="title">
						<h1><?php esc_html_e('Lifetime Value', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h1>
						<?php self::get_documentation_html_by_key('order_modal_ltv'); ?>
					</div>
					<div class="data" id="order-modal-ltv-data">
						<h4><?php esc_html_e('by total order value', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h4>
						<span><?php echo wp_kses_post(wc_price(Shop::get_order_value_in_base_currency($order, LTV::get_total_ltv_from_order($order)))); ?></span>
						<h4><?php esc_html_e('by marketing order value', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h4>
						<span><?php echo wp_kses_post(wc_price(Shop::get_order_value_in_base_currency($order, LTV::get_marketing_ltv_from_order($order)))); ?></span>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// This function is only called when our plugin's page loads!
	public static function freemius_load_deactivation_button_js() {
		add_action('admin_enqueue_scripts', [ __CLASS__, 'freemius_enqueue_deactivation_button_js' ]);
	}


	public static function freemius_enqueue_deactivation_button_js() {
		wp_enqueue_script(
			'freemius-enqueue-deactivation-button',
			PMW_PLUGIN_DIR_PATH . 'js/admin/pmw-admin-freemius.p1.min.js',
			[ 'jquery' ],
			PMW_CURRENT_VERSION,
			true
		);
	}


	/**
	 * This returns a JavaScript function that is called after a purchase is made.
	 *
	 * @param $js_function
	 * @return string
	 */
	public static function fs_after_purchase_js( $js_function ) {
		return "function (response) => {

		let product_name = 'Pixel Manager for WooCommerce';

		let trial_conversion_percentage = 0.52;

		let is_trial = (null != response.purchase.trial_ends),
			is_subscription = (null != response.purchase.initial_amount),
			pre_total = Number(is_subscription ? response.purchase.initial_amount : response.purchase.gross).toFixed(2),
			trial_total = is_trial ? (pre_total * trial_conversion_percentage).toFixed(2) : pre_total,
			total = is_trial ? trial_total : pre_total,
			currency = response.purchase.currency.toUpperCase(),
			transaction_id = response.purchase.id.toString(),
			store_name = window.location.hostname;

		window.dataLayer = window.dataLayer || [];

		dataLayer.push({
			event: 'purchase',
			transaction_id: transaction_id,
			transaction_value: total,
			transaction_currency: currency,
			transaction_coupon: response.purchase.coupon_id,
			transaction_affiliation: store_name,
			user: response.user,
			items: [
				{
					item_name: product_name,
					item_id: response.purchase.plan_id.toString(),
					item_category: 'Plugin',
					price: response.purchase.initial_amount.toString(),
					quantity: 1,
					currency: currency,
					affiliation: store_name,
				},
			],
			freemius_data: response,
		});

		(function (w, d, s, l, i) {
			w[l] = w[l] || []; w[l].push({
				'gtm.start':
					new Date().getTime(), event: 'gtm.js'
			}); var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
					'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-NZ8WQ6QS');
	}";
	}

	// DeleteIf(wcMarketFree)
	// phpcs:disable
	public static function fs_inject_additional_scripts( $html ) {
		return '<script async src="https://www.googletagmanager.com/gtag/js?id=UA-39746956-10"></script>' . $html;
	}
	// phpcs:enable
	// endDeleteIf(wcMarketFree)

	public static function wpm_admin_css( $hook_suffix ) {

		// Only output the css on PMW pages and the order page
		if (
			!( strpos($hook_suffix, 'page_pmw')
				|| Helpers::is_orders_page()
				|| Helpers::is_edit_order_page()
				|| Helpers::is_dashboard()
			)
		) {
			return;
		}

		wp_enqueue_style(
			'pmw-admin',
			PMW_PLUGIN_DIR_PATH . 'css/admin.css',
			[],
			PMW_CURRENT_VERSION
		);
	}

	public static function wpm_admin_scripts( $hook_suffix ) {

		// Only output the remaining scripts on PMW settings page
		if (!strpos($hook_suffix, 'page_pmw')) {
			return;
		}

		// Skip classic admin scripts when an alternative admin UI is active.
		if ('classic' !== self::get_active_admin_theme()) {
			return;
		}

		wp_enqueue_script(
			'pmw-admin',
			PMW_PLUGIN_DIR_PATH . 'js/admin/pmw-admin.p1.min.js',
			[ 'jquery' ],
			PMW_CURRENT_VERSION,
			false
		);

		wp_localize_script(
			'pmw-admin',
			'pmwAdminApi',
			[
				'root'     => esc_url_raw(rest_url()),
				'nonce'    => wp_create_nonce('wp_rest'),
				'timezone' => [
					'string' => wp_timezone_string(),
					'offset' => wp_timezone()->getOffset(new \DateTime()) / 3600, // Hours offset from UTC
				],
			]
		);

		//        wp_enqueue_script('pmw-script-blocker-warning', WPM_PLUGIN_DIR_PATH . 'js/admin/script-blocker-warning.js', ['jquery'], WPM_CURRENT_VERSION, false);
		//        wp_enqueue_script('pmw-admin-helpers', WPM_PLUGIN_DIR_PATH . 'js/admin/helpers.js', ['jquery'], WPM_CURRENT_VERSION, false);
		//        wp_enqueue_script('pmw-admin-tabs', WPM_PLUGIN_DIR_PATH . 'js/admin/tabs.js', ['jquery'], WPM_CURRENT_VERSION, false);

		wp_enqueue_script(
			'pmw-selectWoo',
			PMW_PLUGIN_DIR_PATH . 'js/admin/selectWoo.full.min.js',
			[ 'jquery' ],
			PMW_CURRENT_VERSION,
			false
		);

		wp_enqueue_style(
			'pmw-selectWoo',
			PMW_PLUGIN_DIR_PATH . 'css/selectWoo.min.css',
			[],
			PMW_CURRENT_VERSION
		);

		// enqueue https://fast.wistia.com/assets/external/E-v1.js
		wp_enqueue_script(
			'wistia',
			'https://fast.wistia.com/assets/external/E-v1.js',
			[],
			PMW_CURRENT_VERSION,
			false
		);
	}

	public static function add_order_extra_details() {

		if (!Options::is_order_extra_details_active()) {
			return;
		}

		add_action('woocommerce_admin_order_data_after_order_details', function ( $order ) {
			?>
			<div class="form-field form-field-wide">
				<h4><?php esc_html_e('Pixel Manager Order Details', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h4>
				<div>
					<p>
						<strong><a href="<?php echo esc_url($order->get_checkout_order_received_url() . '&nodedupe&pmwloggeron'); ?>"><?php esc_html_e('order URL', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></a></strong>
					</p>
				</div>
			</div>
			<?php
		});
	}

	public static function pmw_edit_order_scripts( $hook_suffix ) {

		//      error_log('hook_suffix: ' . $hook_suffix);
		//      error_log('get_current_screen: ' . get_current_screen()->id);
		//      error_log('pmw_edit_order_scripts');

		// Only output the remaining scripts on PMW settings page
		if (!Helpers::is_edit_order_page()) {
			return;
		}

		if (!wpm_fs()->can_use_premium_code__premium_only()) {
			return;
		}

		if (!Options::is_ga4_data_api_active()) {
			return;
		}

		wp_enqueue_script(
			'pmw-edit-order',
			PMW_PLUGIN_DIR_PATH . 'js/admin/edit-order-page.js',
			[ 'jquery' ],
			PMW_CURRENT_VERSION,
			false
		);

		wp_localize_script(
			'pmw-edit-order',
			'pmwAdminApi',
			[
				'root'  => esc_url_raw(rest_url()),
				'nonce' => wp_create_nonce('wp_rest'),
			]
		);
	}

	// Load text domain function
	public static function load_plugin_textdomain() {
		load_plugin_textdomain(
			'woocommerce-google-adwords-conversion-tracking-tag',
			false,
			dirname(plugin_basename(__FILE__)) . '/languages/'
		);
	}

	// add the admin options page
	public static function plugin_admin_add_page() {
		//add_options_page('WPM Plugin Page', 'WPM Plugin Menu', 'manage_options', 'wpm', array($this, 'wpm_plugin_options_page'));

		$menu_title = esc_html__('Pixel Manager', 'woocommerce-google-adwords-conversion-tracking-tag');

		// Add a notification badge for open opportunities plus, on fresh
		// installs, the remaining getting-started steps: without the checklist
		// share, a fresh install has ~0 opportunities and nothing would pull an
		// interrupted user back to finish the setup.
		// Use the .menu-counter markup (same as core's Site Health submenu badge,
		// styled by core since WP 5.2). Unlike .awaiting-mod, .menu-counter is
		// never repainted by the current/hover menu rules — in WP 7 those rules
		// turn .awaiting-mod near-black inside the open flyout, while
		// .menu-counter keeps the admin accent colour in every state.
		// Cached: this runs on every admin page load. @since 1.63.1
		$attention_count = Opportunities::get_active_opportunities_count_cached() + Onboarding::get_open_steps_count();
		if ($attention_count > 0) {
			$count        = number_format_i18n($attention_count);
			$menu_title  .= ' <span class="menu-counter count-' . absint($attention_count) . '">'
				. '<span class="count">' . esc_html($count) . '</span>'
				. '</span>';
		}

		add_submenu_page(
			self::get_submenu_parent_slug(),
			esc_html__('Pixel Manager', 'woocommerce-google-adwords-conversion-tracking-tag'),
			$menu_title,
			Environment::get_user_edit_capability(),
			'pmw',
			[ __CLASS__, 'plugin_options_page' ]
		);
	}

	private static function get_submenu_parent_slug() {

		if (Environment::is_woocommerce_active()) {
			return 'woocommerce';
		} else {
			return 'options-general.php';
		}
	}

	// add the admin settings and such
	public static function plugin_admin_init() {

		register_setting(
			'wpm_plugin_options_group',
			'wgact_plugin_options',
			[ '\SweetCode\Pixel_Manager\Admin\Validations', 'options_validate' ]
		);

		// don't load the UX if we are not on the plugin UX page
		if (!Environment::is_pmw_settings_page()) {
			return;
		}

		$tabs = self::get_admin_tabs();

		foreach ($tabs as $tab) {
			if (isset($tab['add_section_callback']) && is_callable($tab['add_section_callback'])) {
				call_user_func($tab['add_section_callback']);
			}
		}
	}

	/**
	 * Get the registered admin tabs, sorted by priority.
	 *
	 * Add-ons can use the 'pmw_admin_tabs' filter to register their own tabs.
	 *
	 * Each tab array should contain:
	 * - 'slug'                (string) Unique tab identifier
	 * - 'title'               (string) Display title
	 * - 'priority'            (int)    Sort order (lower = earlier)
	 * - 'show_save_button'    (bool)   Whether the save button is shown for this tab
	 * - 'add_section_callback' (callable) Function that registers the tab's settings sections and fields
	 * - 'option_name'         (string) Optional. The wp_options key this tab saves to (for add-on tabs)
	 * - 'sanitize_callback'   (callable) Optional. Validation/sanitize function for add-on tab data
	 *
	 * @return array Sorted array of tab configurations.
	 *
	 * @since 1.57.0
	 */
	public static function get_admin_tabs() {

		$tabs = [
			[
				'slug'                => 'main',
				'priority'            => 10,
				'show_save_button'    => true,
				'add_section_callback' => [ __CLASS__, 'add_section_main' ],
			],
			[
				'slug'                => 'advanced',
				'priority'            => 20,
				'show_save_button'    => true,
				'add_section_callback' => [ __CLASS__, 'add_section_advanced' ],
			],
		];

		if (Environment::is_woocommerce_active()) {
			$tabs[] = [
				'slug'                => 'shop',
				'priority'            => 30,
				'show_save_button'    => true,
				'add_section_callback' => [ __CLASS__, 'add_section_shop' ],
			];
		}

		// SSE tab — requires active pro license
		if ( Helpers::is_pmw_pro_version_active() || Options::is_pro_version_demo_active() ) {
			$tabs[] = [
				'slug'                 => 'sse',
				'priority'             => 25,
				'show_save_button'     => true,
				'add_section_callback' => [ __CLASS__, 'add_section_sse__premium_only' ],
			];
		}

		$tabs[] = [
			'slug'                => 'consent-management',
			'priority'            => 40,
			'show_save_button'    => true,
			'add_section_callback' => [ __CLASS__, 'add_section_consent_management' ],
		];

		$tabs[] = [
			'slug'                => 'opportunities',
			'priority'            => 70,
			'show_save_button'    => false,
			'add_section_callback' => [ __CLASS__, 'add_section_opportunities' ],
		];

		if (Environment::is_woocommerce_active()) {
			$tabs[] = [
				'slug'                => 'diagnostics',
				'priority'            => 80,
				'show_save_button'    => false,
				'add_section_callback' => [ __CLASS__, 'add_section_diagnostics' ],
			];
		}

		$tabs[] = [
			'slug'                => 'support',
			'priority'            => 90,
			'show_save_button'    => false,
			'add_section_callback' => [ __CLASS__, 'add_section_support' ],
		];

		$tabs[] = [
			'slug'                => 'logger',
			'priority'            => 100,
			'show_save_button'    => true,
			'add_section_callback' => [ __CLASS__, 'add_section_logs' ],
		];

		/**
		 * Filter the admin settings tabs.
		 *
		 * Add-ons can use this filter to register their own tabs with custom
		 * priority, rendering, and save handling.
		 *
		 * @param array $tabs Array of tab configuration arrays.
		 *
		 * @since 1.57.0
		 */
		$tabs = apply_filters('pmw_admin_tabs', $tabs);

		// Sort by priority
		usort($tabs, function ( $a, $b ) {
			return ( isset($a['priority']) ? $a['priority'] : 50 ) - ( isset($b['priority']) ? $b['priority'] : 50 );
		});

		return $tabs;
	}

	public static function add_section_main() {
		$section_ids = [
			'title'         => esc_html__('Main', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'slug'          => 'main',
			'settings_name' => 'wpm_plugin_main_section',
		];

		self::output_section_data_field($section_ids);

		add_settings_section(
			$section_ids['settings_name'],
			esc_html($section_ids['title']),
			[ __CLASS__, 'plugin_section_main_description' ],
			'wpm_plugin_options_page'
		);

		self::add_section_main_subsection_marketing($section_ids);
		self::add_section_main_subsection_statistics($section_ids);

		// pro version
		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			self::add_section_main_subsection_attribution($section_ids);
			self::add_section_main_subsection_optimization($section_ids);
		}
	}

	public static function add_subsection_div( $section_ids, $sub_section_ids ) {
		add_settings_field(
			'wpm_plugin_subsection_' . $sub_section_ids['slug'] . '_opening_div',
			esc_html($sub_section_ids['title']),
			function () use ( $section_ids, $sub_section_ids ) {
				self::subsection_generic_opening_div_html($section_ids, $sub_section_ids);
			},
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_main_subsection_statistics( $section_ids ) {

		/**
		 * Set up the subsection
		 */

		// configuration
		$sub_section_ids = [
			'title' => esc_html__(
				'Statistics',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'slug'  => 'statistics',
		];

		// add the subsection div
		self::add_subsection_div($section_ids, $sub_section_ids);

		/**
		 * Add the settings fields
		 */

		add_settings_field(
			'wpm_plugin_analytics_4_measurement_id',
			esc_html__(
				'Google Analytics 4',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_google_analytics_4_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add the field for the Hotjar pixel
		add_settings_field(
			'wpm_plugin_hotjar_site_id',
			esc_html__(
				'Hotjar site ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_hotjar_site_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add the field for the CrazyEgg pixel (Pro feature)
		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			add_settings_field(
				'wpm_plugin_crazyegg_account_number',
				esc_html__(
					'CrazyEgg account number',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'option_html_crazyegg_account_number' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		// add the field for the Contentsquare pixel (Pro feature)
		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			add_settings_field(
				'pmw_plugin_contentsquare_tag_id',
				esc_html__(
					'Contentsquare tag ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_contentsquare_tag_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		// add the field for the Microsoft Clarity pixel (Pro feature)
		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			add_settings_field(
				'pmw_plugin_clarity_project_id',
				esc_html__(
					'Microsoft Clarity project ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_clarity_project_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		// add the field for the Mixpanel pixel (Pro feature)
		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			add_settings_field(
				'pmw_plugin_mixpanel_project_token',
				esc_html__(
					'Mixpanel project token',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_mixpanel_project_token' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		// add the field for the Klaviyo pixel (Pro feature)
		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			add_settings_field(
				'pmw_plugin_klaviyo_public_api_key',
				esc_html__(
					'Klaviyo public API key',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_klaviyo_public_api_key' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}
	}

	public static function add_section_main_subsection_marketing( $section_ids ) {

		/**
		 * Set up the subsection
		 */

		// configuration
		$sub_section_ids = [
			'title' => esc_html__(
				'Marketing',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'slug'  => 'marketing',
		];

		// add the subsection div
		self::add_subsection_div($section_ids, $sub_section_ids);

		/**
		 * Add the settings fields
		 */

		// add the field for the Google Ads conversion id
		add_settings_field(
			'wpm_plugin_conversion_id',
			esc_html__(
				'Google Ads Conversion ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_google_ads_conversion_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		if (Environment::is_woocommerce_active()) {

			// add the field for the conversion label
			add_settings_field(
				'wpm_plugin_conversion_label',
				esc_html__(
					'Google Ads Purchase Conversion Label',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'option_html_google_ads_conversion_label' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		// add the field for the conversion label
		add_settings_field(
			'wpm_plugin_facebook_pixel_id',
			esc_html__(
				'Meta (Facebook) pixel ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_facebook_pixel_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		/**
		 * Browser pixels with a Pro server-side counterpart. The tag itself is
		 * free; the Conversions API / Events API fields sit in the guarded
		 * advanced subsections below.
		 */

		// add the field for the Bing Ads UET tag ID
		add_settings_field(
			'wpm_plugin_bing_uet_tag_id',
			esc_html__(
				'Microsoft Advertising UET tag ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_bing_uet_tag_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the OpenAI pixel
		add_settings_field(
			'pmw_plugin_openai_pixel_id',
			esc_html__(
				'OpenAI pixel ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::html_beta(),
			[ __CLASS__, 'option_html_openai_pixel_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Pinterest pixel
		add_settings_field(
			'pmw_plugin_pinterest_pixel_id',
			esc_html__(
				'Pinterest pixel ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_pinterest_pixel_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Reddit Ads pixel
		add_settings_field(
			'plugin_reddit_pixel_id',
			esc_html__(
				'Reddit pixel ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_reddit_pixel_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add the field for the Snapchat pixel
		add_settings_field(
			'wpm_plugin_snapchat_pixel_id',
			esc_html__(
				'Snapchat pixel ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_snapchat_pixel_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add the field for the TikTok pixel
		add_settings_field(
			'wpm_plugin_tiktok_pixel_id',
			esc_html__(
				'TikTok pixel ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_tiktok_pixel_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		/**
		 * Pro version only
		 */

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {

			// Add the field for the Adroll advertiser ID
			add_settings_field(
				'pmw_adroll_advertiser_id',
				esc_html__(
					'Adroll advertiser ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_adroll_advertiser_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add the field for the Adroll pixel ID
			add_settings_field(
				'pmw_adroll_pixel_id',
				esc_html__(
					'Adroll pixel ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_adroll_pixel_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add the field for the Criteo pixel
			add_settings_field(
				'pmw_plugin_criteo_account_id',
				esc_html__(
					'Criteo account ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_criteo_account_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add the field for the Nextdoor pixel
			add_settings_field(
				'pmw_plugin_nextdoor_pixel_id',
				esc_html__(
					'Nextdoor pixel ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_nextdoor_pixel_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add the field for the Spotify Ads pixel
			add_settings_field(
				'pmw_plugin_spotify_pixel_id',
				esc_html__(
					'Spotify Ads pixel ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_spotify_pixel_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add the field for the AppLovin pixel
			add_settings_field(
				'pmw_plugin_applovin_event_key',
				esc_html__(
					'AppLovin event key',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_applovin_event_key' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add the field for the GroundTruth pixel
			add_settings_field(
				'pmw_plugin_groundtruth_gtid',
				esc_html__(
					'GroundTruth GTID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_groundtruth_gtid' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add the fields for the Rumble Ads pixel
			add_settings_field(
				'pmw_plugin_rumble_tag_id',
				esc_html__(
					'Rumble Ads tag ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_rumble_tag_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			add_settings_field(
				'pmw_plugin_rumble_conversion_id_purchase',
				esc_html__(
					'Rumble Ads purchase conversion action ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_rumble_conversion_id_purchase' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			add_settings_field(
				'pmw_plugin_rumble_conversion_id_add_to_cart',
				esc_html__(
					'Rumble Ads add to cart conversion action ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_rumble_conversion_id_add_to_cart' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add the field for the LinkedIn partner ID
			add_settings_field(
				'pmw_linkedin_partner_id',
				esc_html__(
					'LinkedIn partner ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'option_html_linkedin_partner_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);


			// add the field for the Outbrain pixel
			add_settings_field(
				'pmw_plugin_outbrain_advertiser_id',
				esc_html__(
					'Outbrain advertiser ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_outbrain_advertiser_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);






			// Add the field for the Taboola pixel
			add_settings_field(
				'pmw_plugin_taboola_account_id',
				esc_html__(
					'Taboola account ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'option_html_taboola_account_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);


			// add the field for the X (Twitter) pixel
			add_settings_field(
				'wpm_plugin_twitter_pixel_id',
				esc_html__(
					'X (Twitter) pixel ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'option_html_twitter_pixel_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}
	}

	public static function add_section_main_subsection_attribution( $section_ids ) {

		/**
		 * Set up the subsection
		 */

		// configuration
		$sub_section_ids = [
			'title' => esc_html__(
				'Attribution',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'slug'  => 'attribution',
		];

		// add the subsection div
		self::add_subsection_div($section_ids, $sub_section_ids);

		/**
		 * Add the settings fields
		 */

		add_settings_field(
			'pmw_plugin_triple_whale_enabled',
			esc_html__(
				'Triple Whale',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::html_beta(),
			[ __CLASS__, 'option_html_triple_whale_enabled' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Hyros product hash
		add_settings_field(
			'pmw_plugin_hyros_product_hash',
			esc_html__(
				'Hyros product hash',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::html_beta(),
			[ __CLASS__, 'option_html_hyros_product_hash' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_main_subsection_optimization( $section_ids ) {

		/**
		 * Set up the subsection
		 */

		// configuration
		$sub_section_ids = [
			'title' => esc_html__(
				'Optimization',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'slug'  => 'optimization',
		];

		// add the subsection div
		self::add_subsection_div($section_ids, $sub_section_ids);

		/**
		 * Add the settings fields
		 */

		add_settings_field(
			'pmw_plugin_ab_tasty_account_id',
			esc_html__(
				'AB Tasty',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::html_beta(),
			[ __CLASS__, 'option_html_ab_tasty_account_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		add_settings_field(
			'pmw_plugin_optimizely_project_id',
			esc_html__(
				'Optimizely',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::html_beta(),
			[ __CLASS__, 'option_html_optimizely_project_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		add_settings_field(
			'pmw_plugin_vwo_account_id',
			esc_html__(
				'VWO',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::html_beta(),
			[ __CLASS__, 'option_html_vwo_account_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced() {
		$section_ids = [
			'title'         => esc_html__(
				'Advanced',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'slug'          => 'advanced',
			'settings_name' => 'wpm_plugin_advanced_section',
		];

		add_settings_section(
			$section_ids['settings_name'],
			esc_html($section_ids['title']),
			[ __CLASS__, 'plugin_section_advanced_description' ],
			'wpm_plugin_options_page'
		);

		self::output_section_data_field($section_ids);

		self::add_section_advanced_subsection_general($section_ids);
		self::add_section_advanced_subsection_google($section_ids);

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			self::add_section_advanced_subsection_facebook($section_ids);
			if (Environment::is_woocommerce_active()) {
				self::add_section_advanced_subsection_bing($section_ids);
				self::add_section_advanced_subsection_linkedin($section_ids);
			}
			self::add_section_advanced_subsection_pinterest($section_ids);
			self::add_section_advanced_subsection_snapchat($section_ids);
			self::add_section_advanced_subsection_reddit($section_ids);
			self::add_section_advanced_subsection_openai($section_ids);
			self::add_section_advanced_subsection_criteo($section_ids);
			self::add_section_advanced_subsection_mixpanel($section_ids);
			self::add_section_advanced_subsection_klaviyo($section_ids);
			self::add_section_advanced_subsection_nextdoor($section_ids);
			self::add_section_advanced_subsection_spotify($section_ids);
			self::add_section_advanced_subsection_applovin($section_ids);
			self::add_section_advanced_subsection_hyros($section_ids);
			self::add_section_advanced_subsection_tiktok($section_ids);
			if (Environment::is_woocommerce_active()) {
				self::add_section_advanced_subsection_twitter($section_ids);
			}
		}
	}

	public static function add_section_advanced_subsection_general( $section_ids ) {
		$sub_section_ids = [
			'title' => 'General',
			'slug'  => 'general',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {

			// add checkbox for disabling tracking for user roles
			add_settings_field(
				'wpm_setting_disable_tracking_for_user_roles',
				esc_html__(
					'Disable Tracking for User Roles',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_disable_tracking_for_user_roles' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
			// Add checkbox for the scroll tracker
			add_settings_field(
				'pmw_setting_scroll_tracker_thresholds',
				esc_html__(
					'Scroll Tracker',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'info_html_scroll_tracker_thresholds' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add option for lazy loading PMW
			add_settings_field(
				'pmw_setting_lazy_load_pmw',
				esc_html__(
					'Lazy Load PMW',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'html_lazy_load_pmw' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		// Add checkbox for loading deprecated functions module
		add_settings_field(
			'pmw_setting_load_deprecated_functions',
			esc_html__(
				'Load Deprecated Functions',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'html_load_deprecated_functions' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}


	public static function add_section_shop() {

		$section_ids = [
			'title'         => esc_html__('Shop', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'slug'          => 'shop',
			'settings_name' => 'wpm_plugin_shop_section',
		];

		self::output_section_data_field($section_ids);

		add_settings_section(
			'wpm_plugin_shop_section',
			esc_html__('Shop', 'woocommerce-google-adwords-conversion-tracking-tag'),
			[ __CLASS__, 'plugin_section_shop_html' ],
			'wpm_plugin_options_page'
		);

		// add fields for the marketing value logic
		add_settings_field(
			'pmw_plugin_marketing_value_logic',
			esc_html__(
				'Marketing Value Logic',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::get_documentation_html_e(Documentation::get_link('marketing_value_logic')),
			[ __CLASS__, 'html_marketing_value_logic' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add field for sending the profit as a separate field next to the marketing value
		add_settings_field(
			'pmw_plugin_send_profit_separately',
			esc_html__(
				'Send Profit as a Separate Field',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'html_send_profit_separately' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add info about dynamic remarketing
		add_settings_field(
			'wpm_plugin_option_dynamic_remarketing',
			esc_html__(
				'Dynamic Remarketing',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_dynamic_remarketing' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add fields for the product identifier
		add_settings_field(
			'wpm_plugin_option_product_identifier',
			esc_html__(
				'Product Identifier',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'plugin_option_product_identifier' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add checkbox for variations output
		add_settings_field(
			'wpm_plugin_option_variations_output',
			esc_html__(
				'Variations output',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_variations_output' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			// google_business_vertical
			add_settings_field(
				'wpm_plugin_google_business_vertical',
				esc_html__(
					'Google Business Vertical',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'plugin_option_google_business_vertical' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		// add checkbox for order duplication prevention
		add_settings_field(
			'wpm_setting_order_duplication_prevention',
			esc_html__(
				'Order Duplication Prevention',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_order_duplication_prevention' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {

			// add info for ACR
			add_settings_field(
				'wpm_setting_acr',
				esc_html__(
					'ACR',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'info_html_acr' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		// add checkbox for order list info
		add_settings_field(
			'pmw_setting_order_list_info',
			esc_html__(
				'Order List Info',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'info_html_order_list_info' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {

			// Add a subscription value multiplier
			add_settings_field(
				'pmw_setting_subscription_value_multiplier',
				esc_html__(
					'Subscription Value Multiplier',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'html_subscription_value_multiplier' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// Add a button to enable the lifetime calculation on orders
			add_settings_field(
				'pmw_setting_ltv_on_orders',
				esc_html__(
					'Lifetime Value Calculation on Orders',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'html_ltv_calculation_on_orders' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// The "Automatic Lifetime Value Recalculation" field was removed in 1.63.1.
			// The automatic drift detection it advertised had been disabled long
			// before that because it caused performance problems on large shops, so
			// the setting controlled nothing. A full recalculation is a manual
			// operation now; see the field below. Details in LTV::calculate_pmw_order_values().

			// Add a button to schedule a lifetime value recalculation
			add_settings_field(
				'pmw_setting_ltv_manual_recalculation',
				esc_html__(
					'Manual Lifetime Value Recalculation',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'ltv_manual_recalculation' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		add_settings_field(
			'pmw_setting_order_extra_details_output',
			esc_html__(
				'Order Extra Details Output',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::html_beta(),
			[ __CLASS__, 'order_extra_details_output' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_google( $section_ids ) {
		$sub_section_ids = [
			'title' => 'Google',
			'slug'  => 'google',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		if (Environment::is_woocommerce_active()) {

			// Add the field for the Google tag ID
			add_settings_field(
				'pmw_plugin_google_tag_id',
				esc_html__(
					'Google Tag ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'plugin_setting_google_tag_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// add the field for the aw_merchant_id
			add_settings_field(
				'pmw_google_tag_gateway_measurement_path',
				esc_html__(
					'Google Tag Gateway Measurement Path',
					'woocommerce-google-adwords-conversion-tracking-tag'
				) . self::html_beta(),
				[ __CLASS__, 'plugin_setting_google_gateway_measurement_path' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// add the field for the aw_merchant_id
			add_settings_field(
				'wpm_plugin_aw_merchant_id',
				esc_html__(
					'Conversion Cart Data',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'plugin_setting_aw_merchant_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// add fields for the Google enhanced e-commerce
			add_settings_field(
				'wpm_setting_google_analytics_eec',
				esc_html__(
					'Enhanced E-Commerce',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'info_html_google_analytics_eec' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {


				// add fields for the Google GA4 API secret
				add_settings_field(
					'wpm_setting_google_analytics_4_api_secret',
					esc_html__(
						'GA4 API secret',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					[ __CLASS__, 'setting_html_google_analytics_4_api_secret' ],
					'wpm_plugin_options_page',
					$section_ids['settings_name']
				);

				// Add fields for the GA4 Data API property ID
				add_settings_field(
					'pmw_setting_ga4_property_id',
					esc_html__(
						'GA4 Property ID',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					[ __CLASS__, 'setting_html_ga4_property_id' ],
					'wpm_plugin_options_page',
					$section_ids['settings_name']
				);

				// Add fields for the GA4 Data API credentials upload
				add_settings_field(
					'pmw_setting_ga4_data_api_credentials',
					esc_html__(
						'GA4 Data API Credentials',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					[ __CLASS__, 'setting_html_g4_data_api_credentials' ],
					'wpm_plugin_options_page',
					$section_ids['settings_name']
				);
			}
		}

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			// Add fields for the GA4 Page Load Time Tracking
			add_settings_field(
				'pmw_setting_ga4_page_load_time_tracking',
				esc_html__(
					'GA4 Page Load Time Tracking',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_g4_page_load_time_tracking' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			// add user_id for the Google
			add_settings_field(
				'wpm_setting_google_user_id',
				esc_html__(
					'Google User ID',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_google_user_id' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			if (Environment::is_woocommerce_active()) {

				// Add Google Enhanced Conversions
				add_settings_field(
					'pmw_setting_google_enhanced_conversions',
					esc_html__(
						'Google Enhanced Conversions',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					[ __CLASS__, 'setting_html_google_enhanced_conversions' ],
					'wpm_plugin_options_page',
					$section_ids['settings_name']
				);
			}
		}

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			// add fields for the Google Ads phone conversion number
			add_settings_field(
				'wpm_plugin_google_ads_phone_conversion_number',
				esc_html__(
					'Google Ads Phone Conversion Number',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_google_ads_phone_conversion_number' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// add fields for the Google Ads phone conversion label
			add_settings_field(
				'wpm_plugin_google_ads_phone_conversion_label',
				esc_html__(
					'Google Ads Phone Conversion Label',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_google_ads_phone_conversion_label' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			if (Environment::is_woocommerce_active()) {

				// add fields for the Google Ads Conversion Adjustments Conversion Name
				add_settings_field(
					'pmw_plugin_google_ads_conversion_adjustments_conversion_name',
					esc_html__(
						'Google Ads Conversion Adjustments: Conversion Name',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					[ __CLASS__, 'setting_html_google_ads_conversion_adjustments_conversion_name' ],
					'wpm_plugin_options_page',
					$section_ids['settings_name']
				);

				// add fields for the Google Ads Conversion Adjustments Feed
				add_settings_field(
					'pmw_plugin_google_ads_conversion_adjustments_feed',
					esc_html__(
						'Google Ads Conversion Adjustments: Feed',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					[ __CLASS__, 'setting_html_google_ads_conversion_adjustments_feed' ],
					'wpm_plugin_options_page',
					$section_ids['settings_name']
				);
			}
		}

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {

			// add info for automatic email link click tracking
			add_settings_field(
				'pmw_info_automatic_email_link_tracking',
				esc_html__(
					'Automatic Email Link Tracking',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'info_html_automatic_email_link_tracking' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);

			// add info for automatic phone link click tracking
			add_settings_field(
				'pmw_info_automatic_phone_link_click_tracking',
				esc_html__(
					'Automatic Phone Link Click Tracking',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'info_html_automatic_phone_link_click_tracking' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}
	}

	public static function add_section_advanced_subsection_facebook( $section_ids ) {
		$sub_section_ids = [
			'title' => 'Meta (Facebook)',
			'slug'  => 'facebook',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// add field for the Facebook CAPI token
		add_settings_field(
			'wpm_setting_facebook_capi_token',
			esc_html__(
				'Meta (Facebook) CAPI: token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_facebook_capi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the Facebook CAPI test event code
		add_settings_field(
			'pmw_setting_facebook_capi_test_event_code',
			esc_html__(
				'Meta (Facebook) CAPI: test event code',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_facebook_capi_test_event_code' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add field for the Facebook CAPI user transparency send additional client identifiers
		add_settings_field(
			'wpm_setting_facebook_capi_user_transparency_send_additional_client_identifiers',
			esc_html__(
				'Meta (Facebook): Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_facebook_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add field for sending the Facebook app-scoped login ID with CAPI events
		add_settings_field(
			'wpm_setting_facebook_capi_send_fb_login_id',
			esc_html__(
				'Meta (Facebook): Send Facebook Login ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_facebook_send_fb_login_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add field for the domain verification meta tag
		add_settings_field(
			'wpm_setting_facebook_domain_verification_meta_tag_id',
			esc_html__(
				'Meta (Facebook): Domain Verification Meta Tag ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			) . self::html_beta(),
			[ __CLASS__, 'setting_html_facebook_domain_verification_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_pinterest( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Pinterest',
			'slug'  => 'pinterest',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add field for the Pinterest ad account ID token
		add_settings_field(
			'pmw_setting_pinterest_ad_account_id',
			esc_html__(
				'Pinterest Ad Account ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_pinterest_ad_account_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the Pinterest APIC token
		add_settings_field(
			'pmw_setting_pinterest_apic_token',
			esc_html__(
				'Pinterest Events API: token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_pinterest_apic_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add the field for the Pinterest enhanced match
		add_settings_field(
			'wpm_plugin_pinterest_enhanced_match',
			esc_html__(
				'Pinterest Enhanced Match',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_pinterest_enhanced_match' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add field for the Pinterest Advanced Matching
		add_settings_field(
			'pmw_setting_pinterest_user_transparency_advanced_matching',
			esc_html__(
				'Pinterest: Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_pinterest_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_snapchat( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Snapchat',
			'slug'  => 'snapchat',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the Snapchat CAPI token
		add_settings_field(
			'plugin_snapchat_capi_token',
			esc_html__(
				'Snapchat CAPI Token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_snapchat_capi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Snapchat advanced matching
		add_settings_field(
			'plugin_snapchat_advanced_matching',
			esc_html__(
				'Snapchat Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_snapchat_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_reddit( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Reddit',
			'slug'  => 'reddit',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the Reddit CAPI token
		add_settings_field(
			'pmw_setting_reddit_capi_token',
			esc_html__(
				'Reddit Conversions API: token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_reddit_capi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Reddit CAPI test event code
		add_settings_field(
			'pmw_setting_reddit_capi_test_event_code',
			esc_html__(
				'Reddit Conversions API: test event code',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_reddit_capi_test_event_code' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Reddit advanced matching
		add_settings_field(
			'plugin_reddit_advanced_matching',
			esc_html__(
				'Reddit Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_reddit_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_openai( $section_ids ) {

		$sub_section_ids = [
			'title' => 'OpenAI',
			'slug'  => 'openai',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the OpenAI CAPI token
		add_settings_field(
			'pmw_setting_openai_capi_token',
			esc_html__(
				'OpenAI Conversions API: token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_openai_capi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the OpenAI advanced matching
		add_settings_field(
			'plugin_openai_advanced_matching',
			esc_html__(
				'OpenAI Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_openai_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}


	public static function add_section_advanced_subsection_criteo( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Criteo',
			'slug'  => 'criteo',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the Criteo advanced matching
		add_settings_field(
			'pmw_plugin_criteo_advanced_matching',
			esc_html__(
				'Criteo Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_criteo_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	/**
	 * Hyros advanced settings subsection
	 *
	 * @since 1.63.1
	 *
	 * @param array $section_ids
	 * @return void
	 */
	public static function add_section_advanced_subsection_hyros( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Hyros',
			'slug'  => 'hyros',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the Hyros application tag
		add_settings_field(
			'pmw_plugin_hyros_application_tag',
			esc_html__(
				'Hyros application tag',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_hyros_application_tag' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	/**
	 * Mixpanel advanced settings subsection
	 *
	 * @since 1.64.1
	 *
	 * @param array $section_ids
	 * @return void
	 */
	public static function add_section_advanced_subsection_mixpanel( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Mixpanel',
			'slug'  => 'mixpanel',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the Mixpanel data residency region
		add_settings_field(
			'pmw_plugin_mixpanel_data_residency',
			esc_html__(
				'Mixpanel data residency',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_mixpanel_data_residency' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Mixpanel Ingestion API
		add_settings_field(
			'pmw_plugin_mixpanel_ingestion_api',
			esc_html__(
				'Mixpanel Ingestion API',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_mixpanel_ingestion_api' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Mixpanel session replay
		add_settings_field(
			'pmw_plugin_mixpanel_session_recording',
			esc_html__(
				'Mixpanel session replay and heatmaps',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_mixpanel_session_recording' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Mixpanel autocapture
		add_settings_field(
			'pmw_plugin_mixpanel_autocapture',
			esc_html__(
				'Mixpanel autocapture',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_mixpanel_autocapture' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Mixpanel user identification
		add_settings_field(
			'pmw_plugin_mixpanel_user_identification',
			esc_html__(
				'Mixpanel user identification',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_mixpanel_user_identification' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	/**
	 * Klaviyo advanced settings subsection
	 *
	 * @since 1.68.0
	 *
	 * @param array $section_ids
	 * @return void
	 */
	public static function add_section_advanced_subsection_klaviyo( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Klaviyo',
			'slug'  => 'klaviyo',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the coexistence with the official Klaviyo plugin
		add_settings_field(
			'pmw_plugin_klaviyo_coexistence',
			esc_html__(
				'Klaviyo plugin coexistence',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_klaviyo_coexistence' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the customer identification
		add_settings_field(
			'pmw_plugin_klaviyo_identify_customers',
			esc_html__(
				'Klaviyo customer identification',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_klaviyo_identify_customers' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Events API private key
		add_settings_field(
			'pmw_plugin_klaviyo_events_api_token',
			esc_html__(
				'Klaviyo Events API private key',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_klaviyo_events_api_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_nextdoor( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Nextdoor',
			'slug'  => 'nextdoor',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the Nextdoor Conversion API token
		add_settings_field(
			'pmw_plugin_nextdoor_capi_token',
			esc_html__(
				'Nextdoor Conversion API: token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_nextdoor_capi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Nextdoor Conversion API test event code
		add_settings_field(
			'pmw_plugin_nextdoor_capi_test_event_code',
			esc_html__(
				'Nextdoor Conversion API: test event code',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_nextdoor_capi_test_event_code' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Nextdoor advanced matching
		add_settings_field(
			'pmw_plugin_nextdoor_advanced_matching',
			esc_html__(
				'Nextdoor Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_nextdoor_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_applovin( $section_ids ) {

		$sub_section_ids = [
			'title' => 'AppLovin',
			'slug'  => 'applovin',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the AppLovin Conversion API key
		add_settings_field(
			'pmw_plugin_applovin_capi_token',
			esc_html__(
				'AppLovin Conversion API: key',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_applovin_capi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the AppLovin advanced matching
		add_settings_field(
			'pmw_plugin_applovin_advanced_matching',
			esc_html__(
				'AppLovin Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_applovin_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_spotify( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Spotify Ads',
			'slug'  => 'spotify',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the Spotify Conversions API connection ID
		add_settings_field(
			'pmw_plugin_spotify_capi_connection_id',
			esc_html__(
				'Spotify Conversions API: connection ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_spotify_capi_connection_id' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Spotify Conversions API token
		add_settings_field(
			'pmw_plugin_spotify_capi_token',
			esc_html__(
				'Spotify Conversions API: token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_spotify_capi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Spotify advanced matching
		add_settings_field(
			'pmw_plugin_spotify_advanced_matching',
			esc_html__(
				'Spotify Ads Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_spotify_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_tiktok( $section_ids ) {
		$sub_section_ids = [
			'title' => 'TikTok',
			'slug'  => 'tiktok',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add field for the TikTok Events API token
		add_settings_field(
			'pmw_setting_tiktok_eapi_token',
			esc_html__(
				'TikTok Events API: token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_tiktok_eapi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the TikTok EAPI test event code
		add_settings_field(
			'pmw_setting_tiktok_eapi_test_event_code',
			esc_html__(
				'TikTok EAPI: test event code',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_tiktok_eapi_test_event_code' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add field for the TikTok Advanced Matching
		add_settings_field(
			'pmw_setting_tiktok_eapi_user_transparency_advanced_matching',
			esc_html__(
				'TikTok: Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_tiktok_advanced_matching' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_bing( $section_ids ) {

		$sub_section_ids = [
			'title' => 'Microsoft',
			'slug'  => 'microsoft',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add the field for the Microsoft Advertising Conversions API token
		add_settings_field(
			'pmw_plugin_bing_capi_token',
			esc_html__(
				'Microsoft Conversions API: token',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_bing_capi_token' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add the field for the Microsoft Enhanced Conversions matching
		add_settings_field(
			'plugin_microsoft_enhanced_conversions',
			esc_html__(
				'Microsoft Enhanced Conversions',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'option_html_bing_enhanced_conversions' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}


	/**
	 * Info:
	 * Since the Lead events can be sent using the shortcodes,
	 * we don't need to add those ase fields to the advanced settings page.
	 *
	 * @param $section_ids
	 * @return void
	 */
	public static function add_section_advanced_subsection_linkedin( $section_ids ) {

		// Configuration for the LinkedIn section
		$sub_section_ids = [
			'title' => 'LinkedIn',
			'slug'  => 'linkedin',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add field for the LinkedIn view_content event
		add_settings_field(
			'pmw_setting_linkedin_view_content',
			esc_html__(
				'View Content event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_linkedin_view_content' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the LinkedIn add_to_cart event
		add_settings_field(
			'pmw_setting_linkedin_add_to_cart',
			esc_html__(
				'Add-to-cart event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_linkedin_add_to_cart' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the LinkedIn purchase event
		add_settings_field(
			'pmw_setting_linkedin_purchase',
			esc_html__(
				'Purchase event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_linkedin_purchase' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_advanced_subsection_twitter( $section_ids ) {

		// configuration for the Twitter section
		$sub_section_ids = [
			'title' => 'X (Twitter)',
			'slug'  => 'twitter',
		];

		self::add_subsection_div($section_ids, $sub_section_ids);

		// Add field for the Twitter event add_to_cart
		add_settings_field(
			'pmw_setting_twitter_add_to_cart',
			esc_html__(
				'Add To Cart Event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_twitter_add_to_cart' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the Twitter event add_to_wishlist
		add_settings_field(
			'pmw_setting_twitter_add_to_wishlist',
			esc_html__(
				'Add To Wishlist Event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_twitter_add_to_wishlist' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the Twitter event view_content
		add_settings_field(
			'pmw_setting_twitter_view_content',
			esc_html__(
				'Content View Event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_twitter_view_content' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the Twitter event search
		add_settings_field(
			'pmw_setting_twitter_search',
			esc_html__(
				'Search Event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_twitter_search' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the Twitter event initiate_checkout
		add_settings_field(
			'pmw_setting_twitter_initiate_checkout',
			esc_html__(
				'Checkout Initiated Event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_twitter_initiate_checkout' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the Twitter event add_payment_info
		add_settings_field(
			'pmw_setting_twitter_add_payment_info',
			esc_html__(
				'Add Payment Info Event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_twitter_add_payment_info' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add field for the Twitter event purchase
		add_settings_field(
			'pmw_setting_twitter_purchase',
			esc_html__(
				'Purchase Event ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_twitter_purchase' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	public static function add_section_consent_management() {
		$section_ids = [
			'title'         => esc_html__('Consent Management', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'slug'          => 'consent-management',
			'settings_name' => 'wpm_plugin_consent_management_section',
		];

		self::output_section_data_field($section_ids);

		add_settings_section(
			'wpm_plugin_consent_management_section',
			esc_html__('Consent Management', 'woocommerce-google-adwords-conversion-tracking-tag'),
			[ __CLASS__, 'plugin_section_consent_management_html' ],
			'wpm_plugin_options_page'
		);

		// Add fields for the Google Consent Mode
		add_settings_field(
			'wpm_setting_google_consent_mode_active',
			esc_html__(
				'Google Consent Mode v2',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_google_consent_mode_active' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add fields for the Microsoft Ads Consent Mode. The UET tag is a free
		// pixel, so the consent mode that governs it is free as well.
		add_settings_field(
			'setting_microsoft_ads_consent_mode_active',
			esc_html__(
				'Microsoft Ads Consent Mode',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_microsoft_ads_consent_mode_active' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// add fields for explicit cookie consent mode
		add_settings_field(
			'setting_explicit_consent_mode',
			esc_html__(
				'Explicit Consent Mode',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_explicit_consent_mode' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		// Add fields for the explicit consent regions
		add_settings_field(
			'setting_explicit_consent_regions',
			esc_html__(
				'Explicit Consent Regions',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'setting_html_explicit_consent_regions' ],
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);

		if (wpm_fs()->can_use_premium_code__premium_only() || Options::is_pro_version_demo_active()) {
			// add fields for the Google TCF support
			add_settings_field(
				'setting_google_tcf_support',
				esc_html__(
					'Google TCF Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_google_tcf_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (Environment::is_cookiebot_active()) {
			// add fields for the Cookiebot support
			add_settings_field(
				'wpm_setting_cookiebot_support',
				esc_html__(
					'Cookiebot Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_cookiebot_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (Environment::is_complianz_active()) {
			// add fields for the Complianz GDPR support
			add_settings_field(
				'wpm_setting_complianz_support',
				esc_html__(
					'Complianz GDPR Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_complianz_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (Environment::is_cookie_notice_active()) {
			// add fields for the Cookie Notice by hu-manity.co support
			add_settings_field(
				'wpm_setting_cookie_notice_support',
				esc_html__(
					'Cookie Notice Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_cookie_notice_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (Environment::is_cookie_script_active()) {
			// add fields for the Cookie Script support
			add_settings_field(
				'wpm_setting_cookie_script_support',
				esc_html__(
					'Cookie Script Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_cookie_script_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (Environment::is_moove_gdpr_active()) {
			// add fields for the GDPR Cookie Compliance support
			add_settings_field(
				'wpm_setting_moove_gdpr_support',
				esc_html__(
					'GDPR Cookie Compliance Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_moove_gdpr_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (Environment::is_cookieyes_active()) {
			// Add fields for the CookieYes support
			add_settings_field(
				'wpm_setting_cookieyes_support',
				esc_html__(
					'CookieYes Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_cookieyes_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (Environment::is_termly_active()) {
			// add fields for the GDPR Cookie Consent support
			add_settings_field(
				'wpm_setting_cookie_law_info_support',
				esc_html__(
					'Termly CMP Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_termly_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}

		if (Environment::is_faz_cookie_manager_active()) {
			// Add fields for the FAZ Cookie Manager support
			add_settings_field(
				'wpm_setting_faz_cookie_manager_support',
				esc_html__(
					'FAZ Cookie Manager Support',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'setting_html_faz_cookie_manager_support' ],
				'wpm_plugin_options_page',
				$section_ids['settings_name']
			);
		}
	}

	// Add a tab for the logs
	public static function add_section_logs() {

		$section_ids = [
			'title'         => esc_html__(
				'Logs',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'slug'          => 'logger',
			'settings_name' => 'wpm_plugin_log_section',
		];

		self::output_section_data_field($section_ids);

		// Add section for the logs
		add_settings_section(
			'wpm_plugin_log_section',
			esc_html__(
				'Logs',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'plugin_section_logger' ],
			'wpm_plugin_options_page'
		);

		// add checkbox for logger
		add_settings_field(
			'wpm_plugin_option_logger',
			esc_html__(
				'Logger',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'html_logger_activation' ],
			'wpm_plugin_options_page',
			'wpm_plugin_log_section'
		);

		// add dropdown for log level
		add_settings_field(
			'wpm_plugin_option_log_level',
			esc_html__(
				'Log Level',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'html_log_level' ],
			'wpm_plugin_options_page',
			'wpm_plugin_log_section'
		);

		// add option to log outgoing http requests
		add_settings_field(
			'wpm_plugin_option_log_http_requests',
			esc_html__(
				'Log HTTP Requests',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			[ __CLASS__, 'html_log_outgoing_http_requests' ],
			'wpm_plugin_options_page',
			'wpm_plugin_log_section'
		);

		// The log files are only easily accessible in the user interface
		// if WooCommerce is active.
		if (Environment::is_woocommerce_active()) {
			// add dropdown for log level
			add_settings_field(
				'wpm_plugin_option_log_files',
				esc_html__(
					'Log Files',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				[ __CLASS__, 'html_log_files' ],
				'wpm_plugin_options_page',
				'wpm_plugin_log_section'
			);
		}
	}

	public static function add_section_diagnostics() {
		$section_ids = [
			'title'         => esc_html__('Diagnostics', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'slug'          => 'diagnostics',
			'settings_name' => 'wpm_plugin_diagnostics_section',
		];

		self::output_section_data_field($section_ids);

		add_settings_section(
			'wpm_plugin_diagnostics_section',
			esc_html__('Diagnostics', 'woocommerce-google-adwords-conversion-tracking-tag'),
			[ __CLASS__, 'plugin_section_diagnostics_html' ],
			'wpm_plugin_options_page'
		);
	}

	public static function add_section_opportunities() {

		$section_ids = [
			'title'         => esc_html__('Opportunities', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'slug'          => 'opportunities',
			'settings_name' => 'wpm_plugin_opportunities_section',
			'badge_count'   => Opportunities::get_active_opportunities_count(),
		];

		self::output_section_data_field($section_ids);

		add_settings_section(
			'wpm_plugin_opportunities_section',
			esc_html__('Opportunities', 'woocommerce-google-adwords-conversion-tracking-tag'),
			[ __CLASS__, 'plugin_section_opportunities_html' ],
			'wpm_plugin_options_page'
		);
	}

	/**
	 * Render the SSP (Server Side Proxy) admin tab.
	 *
	 * Displays setup wizard, sync token field, status panel,
	 * and action buttons for proxy management.
	 *
	 * @since 1.57.0
	 */
	public static function add_section_sse__premium_only() {

		$section_ids = [
			'title'         => 'SSE',
			'slug'          => 'sse',
			'settings_name' => 'wpm_plugin_sse_section',
		];

		self::output_section_data_field($section_ids);

		add_settings_section(
			'wpm_plugin_sse_section',
			esc_html__('Server-Side Events', 'woocommerce-google-adwords-conversion-tracking-tag'),
			[ __CLASS__, 'plugin_section_sse_description__premium_only' ],
			'wpm_plugin_options_page'
		);
	}

	/**
	 * Render the SSE (Server-Side Events) section description and UI.
	 *
	 * Contains two sections:
	 * 1. General — generic S2S settings (skip empty events, PageView S2S)
	 * 2. Server-Side Proxy — SSP-specific connection and settings
	 *
	 * @since 1.57.0
	 */
	public static function plugin_section_sse_description__premium_only() {

		$options = Options::get_options();
		$ssp     = isset($options['ssp']) ? $options['ssp'] : [];

		$has_token              = !empty($ssp['sync_token']);
		$is_enabled             = !empty($ssp['enabled']);
		$requires_reauth        = !empty($ssp['requires_reauth']);
		$requires_reauth_reason = isset($ssp['requires_reauth_reason']) ? (string) $ssp['requires_reauth_reason'] : '';
		$routing_status         = isset($ssp['routing_status']) ? $ssp['routing_status'] : '';
		$config_status          = isset($ssp['config_status']) ? $ssp['config_status'] : '';
		$proxy_hostname         = isset($ssp['proxy_hostname']) ? $ssp['proxy_hostname'] : '';
		$last_sync_at           = isset($ssp['last_sync_at']) ? $ssp['last_sync_at'] : 0;
		$last_sync_error        = isset($ssp['last_sync_error']) ? $ssp['last_sync_error'] : '';
		$is_active              = Options::is_ssp_active();
		$proxy_failure_behavior = Options::get_ssp_proxy_failure_behavior();

		$plan_name             = isset($ssp['plan_name']) ? $ssp['plan_name'] : '';
		$subscription_status   = isset($ssp['subscription_status']) ? $ssp['subscription_status'] : '';
		$usage_percent         = isset($ssp['usage_percent']) ? $ssp['usage_percent'] : 0;
		$monthly_request_limit = isset($ssp['monthly_request_limit']) ? $ssp['monthly_request_limit'] : 0;
		$billable_this_period  = isset($ssp['billable_this_period']) ? $ssp['billable_this_period'] : 0;

		?>
		<p class="pmw-section-description">
			<?php esc_html_e('Configure server-side event processing. General settings apply to all server-side events, whether they are processed by your WooCommerce server or routed through the Server-Side Proxy.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</p>

		<div class="pmw-sse-card">
			<h3><?php esc_html_e('General', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h3>
			<p class="pmw-sse-card-description">
				<?php esc_html_e('These settings apply to all server-side events, regardless of whether they are sent through the WooCommerce server or the Server-Side Proxy.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>

			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row">
							<?php esc_html_e('Track PageView Events Server-to-Server', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
						</th>
						<td>
							<?php self::html_track_pageview_events_s2s(); ?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<?php esc_html_e('Always Send Server-Side Events', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
						</th>
						<td>
							<?php self::html_always_send_s2s(); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div><!-- /.pmw-sse-card General -->

		<?php if ( !Helpers::is_pmw_wcm_distro() ) : ?>

		<div class="pmw-sse-card pmw-ssp-container">

			<h3>
				<?php esc_html_e('Server-Side Proxy', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</h3>

			<p class="pmw-sse-card-description">
				<?php esc_html_e('Boost tracking accuracy and page speed — route conversion events through Cloudflare\'s edge network, bypass ad blockers, and offload server-side API calls from your WooCommerce server.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>

			<p class="pmw-sse-card-description">
				<?php
				printf(
					/* translators: %1$s: link to sweetcode.cloud product page, %2$s: link to SSP dashboard domains page */
					esc_html__('Visit %1$s to learn more about the Server-Side Proxy, or go to the %2$s to manage your domains and configuration.', 'woocommerce-google-adwords-conversion-tracking-tag'),
					'<a href="https://sweetcode.cloud/" target="_blank" rel="noopener noreferrer">sweetcode.cloud</a>',
					'<a href="https://portal.sweetcode.cloud/domains" target="_blank" rel="noopener noreferrer">SSP Dashboard</a>'
				);
				?>
			</p>

			<?php if ( !$has_token ) : ?>
			<div class="pmw-ssp-quick-start" style="background: #f8f9fa; border: 1px solid #ddd; border-radius: 6px; padding: 16px; margin-bottom: 16px;">
				<p style="margin: 0 0 8px; font-weight: 600;"><?php esc_html_e('Quick Start', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></p>
				<ol style="margin: 0; padding-left: 20px; line-height: 1.8;">
					<li>
						<?php
						printf(
							/* translators: %s: link to SSP portal */
							esc_html__('Go to %s and sign in with your email', 'woocommerce-google-adwords-conversion-tracking-tag'),
							'<a href="https://portal.sweetcode.cloud/login" target="_blank" rel="noopener noreferrer">portal.sweetcode.cloud</a>'
						);
						?>
					</li>
					<li><?php esc_html_e('Navigate to Domains and click Add Domain', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></li>
					<li><?php esc_html_e('Set up the DNS CNAME record as shown in the portal', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></li>
					<li><?php esc_html_e('Copy the sync token, paste it below, and click Activate', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></li>
				</ol>
				<p style="margin: 8px 0 0; font-size: 12px; color: #666;">
					<?php esc_html_e('After activating, your configured destinations (Meta, TikTok, etc.) are synced automatically — no manual entry needed in the SSP Dashboard.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</p>
			</div>
			<?php endif; ?>

			<!-- Setup Wizard — hidden for now; will be re-used with the new UI -->
			<?php if ( false ) : ?>
			<div class="pmw-ssp-wizard">
				<h3><?php esc_html_e('Setup', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h3>

				<div class="pmw-ssp-steps">
					<div class="pmw-ssp-step <?php echo $has_token ? 'completed' : 'current'; ?>">
						<div class="pmw-ssp-step-indicator">
							<?php echo $has_token ? '✓' : '1'; ?>
						</div>
						<div class="pmw-ssp-step-content">
							<strong><?php esc_html_e('Create an account', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></strong>
							<p>
								<?php
								printf(
									/* translators: %s: link to sweetcode.cloud */
									esc_html__('Go to %s and create an account.', 'woocommerce-google-adwords-conversion-tracking-tag'),
									'<a href="https://sweetcode.cloud" target="_blank" rel="noopener noreferrer">sweetcode.cloud</a>'
								);
								?>
							</p>
						</div>
					</div>

					<div class="pmw-ssp-step <?php echo $has_token ? 'completed' : ( $has_token ? '' : 'pending' ); ?>">
						<div class="pmw-ssp-step-indicator">
							<?php echo $has_token ? '✓' : '2'; ?>
						</div>
						<div class="pmw-ssp-step-content">
							<strong><?php esc_html_e('Set up your domain', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></strong>
							<p><?php esc_html_e('Create a domain entry in the SSP portal and configure the DNS CNAME record.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></p>
						</div>
					</div>

					<div class="pmw-ssp-step <?php echo $has_token ? 'completed' : 'pending'; ?>">
						<div class="pmw-ssp-step-indicator">
							<?php echo $has_token ? '✓' : '3'; ?>
						</div>
						<div class="pmw-ssp-step-content">
							<strong><?php esc_html_e('Get the sync token', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></strong>
							<p><?php esc_html_e('Copy the domain sync token from the SSP portal.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></p>
						</div>
					</div>

					<div class="pmw-ssp-step <?php echo $has_token && $is_active ? 'completed' : ( $has_token ? 'current' : 'pending' ); ?>">
						<div class="pmw-ssp-step-indicator">
							<?php echo ( $has_token && $is_active ) ? '✓' : '4'; ?>
						</div>
						<div class="pmw-ssp-step-content">
							<strong><?php esc_html_e('Save the sync token', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></strong>
							<p><?php esc_html_e('Paste the sync token below and activate the connection.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></p>
						</div>
					</div>

					<div class="pmw-ssp-step <?php echo $is_active ? 'completed' : 'pending'; ?>">
						<div class="pmw-ssp-step-indicator">
							<?php echo $is_active ? '✓' : '5'; ?>
						</div>
						<div class="pmw-ssp-step-content">
							<strong><?php esc_html_e('Flush caches', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></strong>
							<p><?php esc_html_e('Flush all server-side frontend caches (page cache, object cache) so the new proxy settings take effect.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></p>
						</div>
					</div>

					<div class="pmw-ssp-step <?php echo $is_active ? 'completed' : 'pending'; ?>">
						<div class="pmw-ssp-step-indicator">
							<?php echo $is_active ? '✓' : '6'; ?>
						</div>
						<div class="pmw-ssp-step-content">
							<strong><?php esc_html_e('Done', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></strong>
							<p><?php esc_html_e('Your server-side proxy is active. Events will be routed through the proxy.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></p>
						</div>
					</div>
				</div>
			</div>

			<hr style="border: none; height: 1px; color: #ddd; background-color: #ddd; margin: 24px 0;">
			<?php endif; ?>

			<!-- Sync Token Input -->
			<div class="pmw-ssp-token-section">
				<h3><?php esc_html_e('Connection', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h3>

				<?php if ( $requires_reauth ) : ?>
					<div class="notice notice-error inline" style="margin: 0 0 16px;">
						<p>
							<strong><?php esc_html_e('Sync token rejected by SSP.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></strong>
							<?php esc_html_e('The stored token no longer authenticates against the proxy, so SSP has been automatically disabled to prevent silent failures. Regenerate the sync token in the SSP portal and paste the new value below to re-activate.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							<?php if ( '' !== $requires_reauth_reason ) : ?>
								<br><em><?php echo esc_html( $requires_reauth_reason ); ?></em>
							<?php endif; ?>
						</p>
					</div>
				<?php endif; ?>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row">
								<label for="pmw-ssp-sync-token"><?php esc_html_e('Sync Token', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></label>
							</th>
							<td>
								<div id="pmw-ssp-token-row" style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
									<?php
									$sync_token_value = isset($ssp['sync_token']) ? (string) $ssp['sync_token'] : '';
									if ( $has_token ) {
										$token_last4  = strlen( $sync_token_value ) >= 4
											? substr( $sync_token_value, -4 )
											: $sync_token_value;
										$masked_token = str_repeat( "\xE2\x80\xA2", 8 ) . '...' . $token_last4;
									}
									?>
									<?php if ( $has_token ) : ?>
										<input
											type="text"
											id="pmw-ssp-sync-token"
											value="<?php echo esc_attr( $masked_token ); ?>"
											style="width: 160px; font-family: monospace;"
											disabled
											readonly
											autocomplete="off"
										/>
									<?php else : ?>
										<input
											type="password"
											id="pmw-ssp-sync-token"
											class="regular-text"
											value=""
											placeholder="<?php esc_attr_e('Paste your domain sync token here', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>"
											autocomplete="off"
										/>
									<?php endif; ?>
									<?php if ($has_token && $is_enabled) : ?>
										<button type="button" id="pmw-ssp-disable-btn" class="button">
											<?php esc_html_e('Disable', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
										</button>
									<?php elseif ($has_token && !$is_enabled) : ?>
										<button type="button" id="pmw-ssp-reactivate-btn" class="button button-primary">
											<?php esc_html_e('Re-activate', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
										</button>
									<?php else : ?>
										<button type="button" id="pmw-ssp-activate-btn" class="button button-primary">
											<?php esc_html_e('Activate', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
										</button>
									<?php endif; ?>
									<?php if ($has_token) : ?>
										<button type="button" id="pmw-ssp-replace-btn" class="button">
											<?php esc_html_e('Replace token', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
										</button>
										<span class="pmw-ssp-badge pmw-ssp-badge--<?php echo $is_enabled ? 'active' : 'inactive'; ?>">
											<?php
											echo $is_enabled
												? esc_html__('Enabled', 'woocommerce-google-adwords-conversion-tracking-tag')
												: esc_html__('Disabled', 'woocommerce-google-adwords-conversion-tracking-tag');
											?>
										</span>
									<?php endif; ?>
								</div>

								<?php if ($has_token) : ?>
									<div id="pmw-ssp-replace-row" style="display: none; align-items: center; gap: 8px; flex-wrap: wrap; margin-top: 8px;">
										<input
											type="password"
											id="pmw-ssp-replace-input"
											class="regular-text"
											value=""
											placeholder="<?php esc_attr_e('Paste the new sync token from the SSP portal', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>"
											autocomplete="off"
										/>
										<button type="button" id="pmw-ssp-replace-save-btn" class="button button-primary">
											<?php esc_html_e('Save new token', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
										</button>
										<button type="button" id="pmw-ssp-replace-cancel-btn" class="button">
											<?php esc_html_e('Cancel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
										</button>
									</div>
								<?php endif; ?>

								<span id="pmw-ssp-toggle-status" style="margin-top: 4px; display: inline-block;"></span>
								<p class="description">
									<?php if ( $has_token ) : ?>
										<?php esc_html_e('The stored sync token cannot be edited in place. To rotate it, click "Replace token" and paste the new value from the SSP portal.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
									<?php else : ?>
										<?php esc_html_e('The domain sync token from your SSP portal. This authenticates the connection between your store and the proxy.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
									<?php endif; ?>
								</p>
								<div id="pmw-ssp-activate-status" style="margin-top: 8px;"></div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<?php if ($has_token) : ?>

			<hr style="border: none; height: 1px; color: #ddd; background-color: #ddd; margin: 24px 0;">

			<!-- Status Panel -->
			<div class="pmw-ssp-status-section">
				<h3><?php esc_html_e('Status', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h3>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><?php esc_html_e('Proxy Hostname', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<td>
								<code id="pmw-ssp-hostname"><?php echo esc_html( $proxy_hostname ? $proxy_hostname : '—' ); ?></code>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('Routing Status', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<td>
								<span id="pmw-ssp-routing-status" class="pmw-ssp-badge pmw-ssp-badge--<?php echo esc_attr( $routing_status ? $routing_status : 'unknown' ); ?>">
									<?php echo esc_html(self::ssp_status_label($routing_status)); ?>
								</span>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('Config Status', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<td>
								<span id="pmw-ssp-config-status" class="pmw-ssp-badge pmw-ssp-badge--<?php echo esc_attr( $config_status ? $config_status : 'unknown' ); ?>">
									<?php echo esc_html(self::ssp_status_label($config_status)); ?>
								</span>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('Last Sync', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<td>
								<span id="pmw-ssp-last-sync">
									<?php
									if ($last_sync_at) {
										echo esc_html(
											wp_date(
												get_option('date_format') . ', ' . get_option('time_format'),
												$last_sync_at
											)
										);
									} else {
										echo '—';
									}
									?>
								</span>
							</td>
						</tr>
						<?php if (!empty($last_sync_error)) : ?>
						<tr>
							<th scope="row"><?php esc_html_e('Last Error', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<td>
								<span id="pmw-ssp-last-error" class="pmw-ssp-error-text">
									<?php echo esc_html($last_sync_error); ?>
								</span>
							</td>
						</tr>
						<?php endif; ?>
						<tr>
							<th scope="row"><?php esc_html_e('Plan', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<td>
								<span id="pmw-ssp-plan-name">
									<?php
									if ($plan_name) {
										echo esc_html($plan_name);
										if ($subscription_status && 'active' !== $subscription_status) {
											echo ' <span class="pmw-ssp-badge pmw-ssp-badge--inactive">' . esc_html(ucfirst($subscription_status)) . '</span>';
										}
									} else {
										echo '—';
									}
									?>
								</span>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('Usage', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<td>
								<span id="pmw-ssp-usage">
									<?php
									if ($monthly_request_limit > 0) {
										printf(
											/* translators: 1: billable events, 2: monthly limit, 3: usage percentage */
											esc_html__('%1$s / %2$s events (%3$s%%)', 'woocommerce-google-adwords-conversion-tracking-tag'),
											esc_html(number_format_i18n($billable_this_period)),
											esc_html(number_format_i18n($monthly_request_limit)),
											esc_html($usage_percent)
										);
									} else {
										echo '—';
									}
									?>
								</span>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('Overall', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<td>
								<?php if ($is_active) : ?>
									<span class="pmw-ssp-badge pmw-ssp-badge--active">
										<?php esc_html_e('Active', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
									</span>
								<?php else : ?>
									<span class="pmw-ssp-badge pmw-ssp-badge--inactive">
										<?php esc_html_e('Inactive', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
									</span>
								<?php endif; ?>
							</td>
						</tr>
					</tbody>
				</table>

				<!-- Action Buttons -->
				<div class="pmw-ssp-actions" style="margin-top: 16px;">
					<button type="button" id="pmw-ssp-sync-btn" class="button">
						<?php esc_html_e('Sync Now', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</button>
					<button type="button" id="pmw-ssp-test-btn" class="button" style="margin-left: 8px;">
						<?php esc_html_e('Test Connection', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</button>
					<button type="button" id="pmw-ssp-diagnostics-btn" class="button" style="margin-left: 8px;">
						<?php esc_html_e('Copy Diagnostic Info', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</button>
					<span id="pmw-ssp-action-status" style="margin-left: 12px;"></span>
					<span id="pmw-ssp-diagnostics-status" style="margin-left: 12px;"></span>
					<p class="description" style="margin-top: 8px;">
						<?php esc_html_e('"Copy Diagnostic Info" puts a paste-ready snapshot (plugin version, SSP status, latest error code + request ID, sync token redacted) on your clipboard. Paste it into your support ticket so we can debug faster.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</p>
				</div>
			</div>

			<hr style="border: none; height: 1px; color: #ddd; background-color: #ddd; margin: 24px 0;">

			<!-- Settings -->
			<div class="pmw-ssp-settings-section">
				<h3><?php esc_html_e('Settings', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h3>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row">
								<label for="pmw-ssp-failure-behavior"><?php esc_html_e('Proxy Failure Behavior', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></label>
							</th>
							<td>
								<select id="pmw-ssp-failure-behavior">
									<option value="fallback_to_wc" <?php selected($proxy_failure_behavior, 'fallback_to_wc'); ?>>
										<?php esc_html_e('Fall back to PMW internal event router', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
									</option>
									<option value="drop_events" <?php selected($proxy_failure_behavior, 'drop_events'); ?>>
										<?php esc_html_e('Drop server-side events', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
									</option>
								</select>
								<span id="pmw-ssp-failure-behavior-status" style="margin-left: 12px;"></span>
								<p class="description">
									<?php esc_html_e('What to do when the SSP proxy is unreachable for a visitor. This is evaluated per visitor session — each new visitor gets a fresh check.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
								</p>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<hr style="border: none; height: 1px; color: #ddd; background-color: #ddd; margin: 24px 0;">

			<!-- Disconnect -->
			<div class="pmw-ssp-disconnect-section">
				<h3><?php esc_html_e('Disconnect', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h3>

				<p class="description" style="margin-bottom: 12px;">
					<?php esc_html_e('Permanently remove the sync token and all connection data. You will need to re-enter the token from the SSP portal to reconnect.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</p>

				<button type="button" id="pmw-ssp-disconnect-btn" class="button" style="color: #dc3545; border-color: #dc3545;">
					<?php esc_html_e('Disconnect', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</button>
				<span id="pmw-ssp-disconnect-status" style="margin-left: 12px;"></span>
			</div>

			<?php endif; ?>

		</div><!-- /.pmw-sse-card SSP -->

		<?php endif; // is_pmw_wcm_distro ?>
		<?php
	}

	/**
	 * Convert an SSP status slug to a human-readable label.
	 *
	 * @param string $status
	 *
	 * @return string
	 * @since 1.57.0
	 */
	private static function ssp_status_label( $status ) {
		$labels = [
			'active'         => __('Active', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'pending_dns'    => __('Pending DNS', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'disabled'       => __('Disabled', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'deleted'        => __('Deleted', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'waiting_config' => __('Waiting for Config', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'synced'         => __('Synced', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'sync_error'     => __('Sync Error', 'woocommerce-google-adwords-conversion-tracking-tag'),
		];

		return isset($labels[$status]) ? $labels[$status] : __('Unknown', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	public static function add_section_support() {
		$section_ids = [
			'title'         => esc_html__('Support', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'slug'          => 'support',
			'settings_name' => 'wpm_plugin_support_section',
		];

		self::output_section_data_field($section_ids);

		add_settings_section(
			'wpm_plugin_support_section',
			esc_html__('Support', 'woocommerce-google-adwords-conversion-tracking-tag'),
			[ __CLASS__, 'plugin_section_support_description' ],
			'wpm_plugin_options_page'
		);
	}

	private static function output_section_data_field( array $section_ids ) {
		add_settings_field(
			'wgact_plugin_section_' . $section_ids['slug'] . '_opening_div',
			'',
			function () use ( $section_ids ) {
				self::section_generic_opening_div_html($section_ids);
			},
			'wpm_plugin_options_page',
			$section_ids['settings_name']
		);
	}

	/**
	 * Render the section marker div with data attributes for JS tab rendering.
	 *
	 * The priority and show-save-button attributes are looked up from the
	 * registered tabs configuration. If no matching tab is found, defaults
	 * are used (priority=50, show-save-button=true).
	 *
	 * @param array $section_ids Section configuration array with 'title', 'slug', and optional 'badge_count'.
	 *
	 * @since 1.57.0
	 */
	public static function section_generic_opening_div_html( $section_ids ) {
		$badge_count      = isset($section_ids['badge_count']) ? $section_ids['badge_count'] : 0;
		$priority         = 50;
		$show_save_button = true;

		// Look up priority and show_save_button from the registered tabs
		$tabs = self::get_admin_tabs();
		foreach ($tabs as $tab) {
			if ($tab['slug'] === $section_ids['slug']) {
				$priority         = isset($tab['priority']) ? $tab['priority'] : 50;
				$show_save_button = isset($tab['show_save_button']) ? $tab['show_save_button'] : true;
				break;
			}
		}

		echo '<div class="section"'
			. ' data-section-title="' . esc_attr($section_ids['title']) . '"'
			. ' data-section-slug="' . esc_attr($section_ids['slug']) . '"'
			. ' data-badge-count="' . esc_attr($badge_count) . '"'
			. ' data-priority="' . esc_attr($priority) . '"'
			. ' data-show-save-button="' . esc_attr($show_save_button ? '1' : '0') . '"'
			. '></div>';
	}

	public static function subsection_generic_opening_div_html( $section_ids, $sub_section_ids ) {
		echo '<div class="subsection" data-section-slug="' . esc_attr($section_ids['slug']) . '" data-subsection-title="' . esc_attr($sub_section_ids['title']) . '" data-subsection-slug="' . esc_attr($sub_section_ids['slug']) . '"></div>';
	}

	// display the admin options page
	public static function plugin_options_page() {

		// ─── Admin UI: Nova (default) with a Classic fallback ───────────
		if (self::is_wp_admin_active()) {
			self::render_wp_admin();
			return;
		}

		$freemius_data = [
			'active' => Environment::is_freemius_active(),
			'tabs'   => [
				'contact' => esc_html__('Contact', 'woocommerce-google-adwords-conversion-tracking-tag'),
				'account' => esc_html__('Account', 'woocommerce-google-adwords-conversion-tracking-tag'),
			],
		];
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON for an inline script, escaped by Helpers::json_encode_for_script()
		?>

		<script>
			const pmwFreemius = <?php echo Helpers::json_encode_for_script($freemius_data); ?>;
		</script>
		<?php
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped

		if (
			wpm_fs()->is__premium_only()
			&& !defined('WP_FS__SKIP_EMAIL_ACTIVATION')
		) {
			add_action('admin_notices', function () {
				Notifications::license_expired_warning__premium_only();
			});
		}

		?>

		<div id="script-blocker-notice"
			class="notice notice-error pmw script-blocker-notice"
			style="display: none; padding: 12px 16px; flex-direction: row; justify-content: space-between; align-items: flex-start; border-left-color: #dc3545;">
			<div>
				<div style="color: black; margin-bottom: 8px;">
					<strong style="font-size: 14px;">
						<?php esc_html_e('⚠️ Script Blocker Detected', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</strong>
				</div>
				<div style="color: #444; margin-bottom: 10px;">
					<?php esc_html_e('It looks like you are using an ad- or script-blocker in your browser which is blocking the script and CSS files of this plugin.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</div>

				<div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px;">
					<span style="display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 3px; font-size: 12px; font-weight: 500; background: #fde8e8; border: 1px solid #f56565; color: #c53030;">
						<?php esc_html_e('Plugin functionality may be impaired', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
				</div>

				<div style="color: #444; margin-bottom: 12px;">
					<?php esc_html_e('Please disable the script blocker for this site to ensure the plugin works correctly.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</div>

				<a href="<?php echo esc_url(Documentation::get_link('script_blockers')); ?>"
					target="_blank"
					style="text-decoration: none; box-shadow: none;">
					<div class="button button-primary" style="margin: 0;">
						<?php esc_html_e('Learn more', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</div>
				</a>
			</div>
		</div>

		<script>
			// Detect if PMW admin script is blocked.
			// Wait for window.load (all resources finished), then check if the script set its flag.
			window.addEventListener('load', function() {
				setTimeout(function() {
					if (!window.pmwAdminScriptLoaded) {
						var notice = document.getElementById('script-blocker-notice');
						if (notice) {
							notice.style.display = 'flex';
						}
					}
				}, 500);
			});
		</script>

		<div style="width:90%; margin: 5px">

			<?php
			// Only run if WooCommerce is active,
			// otherwise the settings_errors() function will be run twice.
			if (Environment::is_woocommerce_active()) {
				settings_errors();
			}
			?>

			<h2 class="nav-tab-wrapper"></h2>

			<form id="pmw_settings_form" method="post" autocomplete="off">

				<?php

				// Keep nonce for REST save validation
				wp_nonce_field('pmw_settings_save', 'pmw_settings_nonce');

				do_settings_sections('wpm_plugin_options_page');

				/**
				 * Fires after PMW's own settings sections have been rendered,
				 * but before the submit button. Add-on plugins should use
				 * this hook to output their settings fields.
				 *
				 * @since 1.57.0
				 */
				do_action('pmw_admin_settings_after_sections');

				submit_button();

				self::inject_developer_banner();
				?>
			</form>
		</div>
		<?php
	}

	private static function inject_developer_banner() {

		if (Helpers::is_pmw_wcm_distro()) {
			return;
		}

		?>

		<div class="pmw dev-banner">
			<div class="text left">
				<?php esc_html_e('Profit Driven Marketing by SweetCode', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</div>
			<?php
			if (
				!wpm_fs()->can_use_premium_code__premium_only()
				&& !Environment::is_on_playground_wordpress_net()
			) :
				?>
				<div class="text center" id="divTooltip"
					data-tooltip="<?php esc_html_e("Enabling this will show you the pro settings in the user interface. It won't actually enable the pro features. If you want to try out the pro features head over to sweetcode.com and sign up for a trial.", 'woocommerce-google-adwords-conversion-tracking-tag'); ?>">
					<div style="padding-right: 6px">
						<?php esc_html_e('Show Pro version settings:', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>

					</div>
					<div>

						<label class="switch" id="pmw-pro-version-demo">

							<input type="hidden" value="0" name="wgact_plugin_options[general][pro_version_demo]">
							<input type="checkbox"
									value="1"
									name="wgact_plugin_options[general][pro_version_demo]"
								<?php checked(Options::is_pro_version_demo_active()); ?>
							/>

							<span class="slider round"></span>

						</label>

					</div>
				</div>

			<?php endif; ?>
			<div class="text right">
				<span style="padding-right: 6px">
					<?php esc_html_e('Visit us here:', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</span>
				<span>
					<a href="https://sweetcode.com/?utm_source=plugin&utm_medium=banner&utm_campaign=wpm"
						target="_blank">https://sweetcode.com</a>
				</span>
			</div>
		</div>


		<?php
	}


	// ─── Admin UI theme helpers ───────────

	/**
	 * Clear the retired per-user interface choice.
	 *
	 * Up to 1.71.0 a user could switch back to the Classic interface, kept in
	 * pmw_admin_theme user meta (and before 1.62.0 in a session cookie). Since
	 * 1.71.1 every user is on Nova and the only way back to Classic is the
	 * pmw_use_classic_admin_interface filter, so neither is read any more. Both
	 * are removed here when the user opens the settings page.
	 *
	 * Runs on admin_init (before output) so the cookie can still be expired.
	 *
	 * @since 1.71.1
	 */
	public static function clean_up_legacy_theme_choice() {

		// Only relevant on the PMW settings page.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if (!isset($_GET['page']) || 'pmw' !== sanitize_text_field(wp_unslash($_GET['page']))) {
			return;
		}

		// Expire the pre-1.62.0 session cookie. Use WordPress's own admin cookie
		// path (site path + 'wp-admin') so the deletion also works on
		// subdirectory installs and subdirectory multisite networks.
		if (isset($_COOKIE['pmw_admin_theme'])) {
			$cookie_path = defined('ADMIN_COOKIE_PATH') ? ADMIN_COOKIE_PATH : '/wp-admin/';
			setcookie('pmw_admin_theme', '', time() - HOUR_IN_SECONDS, $cookie_path);
		}

		$user_id = get_current_user_id();

		if ($user_id && '' !== get_user_meta($user_id, 'pmw_admin_theme', true)) {
			delete_user_meta($user_id, 'pmw_admin_theme');
		}
	}

	/**
	 * Resolve which admin design system is active: 'wp' (Nova) | 'classic'.
	 *
	 * Nova for everyone. The pmw_use_classic_admin_interface filter is the
	 * escape hatch for a shop that hits a problem in Nova; there is no UI
	 * switch any more. Nova falls back to Classic if the WordPress version is
	 * too old or its build output is missing.
	 *
	 * @return string
	 *
	 * @since 1.59.0
	 */
	private static function get_active_admin_theme() {

		/**
		 * Render the legacy Classic settings interface instead of Nova.
		 *
		 * Usage: add_filter('pmw_use_classic_admin_interface', '__return_true');
		 *
		 * @param bool $use_classic Whether to render the Classic interface. Default false.
		 *
		 * @since 1.71.1
		 */
		if (apply_filters('pmw_use_classic_admin_interface', false)) {
			return 'classic';
		}

		return self::theme_with_build_fallback(self::get_default_admin_theme());
	}

	/**
	 * The default admin design system: Nova, for every install.
	 *
	 * Since 1.62.0 Nova is the default everywhere, including installs that
	 * predate it. Since 1.71.1 it is the only choice in the UI; see
	 * get_active_admin_theme() for the filter override.
	 *
	 * @return string 'wp' | 'classic'
	 *
	 * @since 1.59.0
	 */
	public static function get_default_admin_theme() {
		return 'wp';
	}

	/**
	 * The minimum WordPress version Nova can run on.
	 *
	 * Nova reuses WordPress core's React and component library at runtime
	 * (wp.element / wp.components). wp.element only exposes createRoot since
	 * WordPress 6.2 (the React 18 upgrade), and wp.components gained
	 * SearchControl in 5.9 and didn't exist at all before 5.0. Below this
	 * version the bundle would enqueue but the app could never mount.
	 *
	 * @var string
	 *
	 * @since 1.59.0
	 */
	const NOVA_MIN_WP_VERSION = '6.2';

	/**
	 * Whether this WordPress install ships the core APIs Nova needs.
	 *
	 * @return bool
	 *
	 * @since 1.59.0
	 */
	public static function nova_wp_version_supported() {
		return version_compare(get_bloginfo('version'), self::NOVA_MIN_WP_VERSION, '>=');
	}

	/**
	 * Fall back to the classic UI if the requested theme's build output is absent.
	 *
	 * @param string $theme
	 *
	 * @return string
	 *
	 * @since 1.59.0
	 */
	private static function theme_with_build_fallback( $theme ) {

		// Old WordPress cores always land on Classic.
		if ('wp' === $theme && !self::nova_wp_version_supported()) {
			return 'classic';
		}

		$builds = [
			'wp' => 'js/admin/wp/pmw-admin-wp.js',
		];

		if (isset($builds[ $theme ]) && !file_exists(plugin_dir_path(PMW_PLUGIN_FILE) . $builds[ $theme ])) {
			return 'classic';
		}

		return $theme;
	}

	/**
	 * Whether the WordPress-components admin UI should be rendered.
	 *
	 * @return bool
	 *
	 * @since 1.59.0
	 */
	public static function is_wp_admin_active() {
		return 'wp' === self::get_active_admin_theme();
	}

	/**
	 * Render the WordPress-components admin UI mount point and enqueue its assets.
	 *
	 * Reuses WordPress's bundled React and component library (script handles
	 * react / react-dom / wp-element / wp-components / wp-i18n) rather than
	 * shipping its own copies — see the Vite externals in admin-ui-wp.
	 *
	 * @since 1.59.0
	 */
	private static function render_wp_admin() {

		$base_url  = PMW_PLUGIN_DIR_PATH . 'js/admin/wp/';
		$base_path = plugin_dir_path(PMW_PLUGIN_FILE) . 'js/admin/wp/';
		$js_path   = $base_path . 'pmw-admin-wp.js';
		$css_path  = $base_path . 'pmw-admin-wp.css';

		// Version the build artifacts by file mtime so a fresh build always busts
		// the browser cache (these are generated bundles, not the plugin release).
		$js_version  = file_exists($js_path)  ? (string) filemtime($js_path)  : PMW_CURRENT_VERSION;
		$css_version = file_exists($css_path) ? (string) filemtime($css_path) : PMW_CURRENT_VERSION;

		// WordPress component styles (Card, Panel, controls, …) + dashicons (doc/video icons).
		wp_enqueue_style('wp-components');
		wp_enqueue_style('dashicons');

		// The app's own CSS is only emitted if it imports any stylesheet; enqueue
		// it conditionally so we never link a non-existent file.
		if (file_exists($css_path)) {
			wp_enqueue_style(
				'pmw-admin-wp',
				$base_url . 'pmw-admin-wp.css',
				[ 'wp-components' ],
				$css_version
			);
		}

		// IIFE bundle — depends on WordPress's bundled React + components.
		wp_enqueue_script(
			'pmw-admin-wp',
			$base_url . 'pmw-admin-wp.js',
			[ 'react', 'react-dom', 'wp-element', 'wp-components', 'wp-i18n' ],
			$js_version,
			true
		);

		// Pass data to the React app (same payload as the Nova UI).
		// Use the canonical helper, not an inline wpm_fs() check: the WooCommerce
		// Marketplace builds ship without the Freemius SDK, so function_exists('wpm_fs')
		// is false there and the gulp `can_use_premium_code__premium_only() -> true`
		// rewrite is dead code (it sits inside the guard). is_pmw_pro_version_active()
		// resolves the paid wcm distribution via PMW_PLUGIN_BASENAME, so Pro pixels are
		// correctly unlocked in the WooCommerce Pro build instead of shown as gated.
		$can_use_premium = Helpers::is_pmw_pro_version_active();

		// Expired means: this is the premium code base, but the license no
		// longer validates. The Dashboard shows a prominent renewal card.
		$license_expired = false;
		// Keep the wpm_fs() guard and call on separate lines: the gulp wcm build
		// replaces the method call with a literal, and inside a compound condition
		// the surviving function_exists() guard silently turns the whole expression
		// false on the SDK-less marketplace build.
		if (function_exists('wpm_fs')) {
			if (wpm_fs()->is__premium_only()) {
				$license_expired = !$can_use_premium;
			}
		}

		$ga4_credentials = Options::get_ga4_data_api_credentials();

		wp_localize_script(
			'pmw-admin-wp',
			'pmwAdminApi',
			[
				'root'               => esc_url_raw(rest_url()),
				'nonce'              => wp_create_nonce('wp_rest'),
				'isExperiment'       => Helpers::is_experiment(),
				'canUsePremiumCode'  => $can_use_premium,
				'licenseExpired'        => $license_expired,
				'licenseExpiredDocsUrl' => Documentation::get_link('license_expired_warning'),
				'options'            => Options::get_options(),
				'opportunities'      => self::get_opportunities_for_nova(),
				'opportunitiesCatalogWeight' => self::get_opportunities_catalog_weight_for_nova(),
				'backups'            => self::get_backups_for_wp_admin(),
				'diagnostics'        => self::get_diagnostics_for_wp_admin(),
				'roles'              => self::get_roles_for_wp_admin(),
				'detectedCmps'       => self::get_detected_cmps_for_wp_admin(),
				'consentRegions'     => self::get_consent_regions_for_wp_admin(),
				'sspFailedDestinations' => Options::is_ssp_active() ? Options::get_ssp_failed_destinations() : [],
				'sspQuotaExceeded'         => Options::is_ssp_active() && Options::is_ssp_quota_exceeded(),
				'sspProxyFailureBehavior'  => Options::get_ssp_proxy_failure_behavior(),
				// Server-side conditions that force a settings toggle on (forcedOnWhen.serverFlag in Nova). @since 1.71.1
				'serverFlags'              => [
					'pageviewEventsS2sForced' => Options::is_pageview_events_s2s_active_override(),
				],
				'trialPromotion'           => Trial_Promotion_Notification::get_data_for_nova(),
				'askForRating'             => Ask_For_Rating::get_data_for_nova(),
				'onboarding'               => Onboarding::get_data_for_nova(),
				'serverLoadWarning'        => Server_Load_Warning::get_data_for_nova(),
				// Optimizely re-enable gate after the November 2026 incident. @since 1.74.1
				'optimizelySecurity'       => Optimizely_Security::get_data_for_nova(),
				'gadsConversionAdjustmentsFeedUrl' => get_site_url() . Pixel_Manager::get_instance()->get_google_ads_conversion_adjustments_endpoint(),
				'recentLogUrl'          => (string) Helpers::get_admin_url_link_to_recent_wc_log('pmw'),
				// WooCommerce's own logging state, which can discard PMW's entries. @since 1.69.3
				'wcLogging'             => Logger::get_woocommerce_logging_for_nova(),
				'ga4DataApiClientEmail' => isset($ga4_credentials['client_email']) ? (string) $ga4_credentials['client_email'] : '',
				// Distro-aware commercial links. Always injected for EVERY distribution
				// so the compiled JS bundle never hardcodes a host (it can't be rewritten
				// by the build). Commercial_Links points these at WooCommerce.com for the
				// wcm build and at Freemius/sweetcode.com for the Freemius build.
				'upgradeUrl' => Commercial_Links::upgrade_url(),
				'accountUrl' => Commercial_Links::account_url(),
				'supportUrl' => Commercial_Links::support_url(),
				// Named in the error details a crashed Nova page offers to copy. @since 1.69.3
				'distribution' => Helpers::get_pmw_distro(),
				'pixelRequestUrl' => Commercial_Links::pixel_request_url(),
				'trialUrl'   => Trial_Promotion_Notification::get_available_trial_url(),

				// First-run "it works" confirmation (dashboard strip + celebration).
				'firstEventConfirmation' => First_Event_Confirmation::get_data_for_nova(),
				// Storefront URL for the "Open your shop" action; the admin's own
				// visit is the intended trigger for the pixels-live beacon.
				'shopUrl'    => Environment::is_woocommerce_active() && function_exists('wc_get_page_permalink')
					? wc_get_page_permalink('shop')
					: home_url('/'),
			]
		);

		?>
		<style>
			.wrap > .nav-tab-wrapper { display: none !important; }
			/* The Nova app renders its own modern chat widget; hide the legacy one. */
			#pmw-chatbot-widget, #pmw-chatbot-panel { display: none !important; }
		</style>
		<div id="pmw-wp-root" style="margin: 10px 20px 0 0;"></div>
		<?php
	}

	/**
	 * Lightweight backup list for the WordPress-components admin UI.
	 * The full backup blobs stay server-side; we only expose metadata.
	 *
	 * @return array
	 *
	 * @since 1.59.0
	 */
	public static function get_backups_for_wp_admin() {

		$active_timestamp = (int) Options::get_options_obj()->timestamp;
		$backups          = Options::get_automatic_options_backup();

		$list = [];
		foreach ($backups as $timestamp => $data) {
			$list[] = [
				'timestamp' => (int) $timestamp,
				'dbVersion' => isset($data['db_version']) ? (string) $data['db_version'] : '',
				'active'    => ( (int) $timestamp === $active_timestamp ),
			];
		}

		// Newest first.
		usort($list, function ( $a, $b ) {
			return $b['timestamp'] - $a['timestamp'];
		});

		return $list;
	}

	/**
	 * Cheap environment facts for the Diagnostics tab (no network calls).
	 *
	 * @return array
	 *
	 * @since 1.59.0
	 */
	public static function get_diagnostics_for_wp_admin() {

		return [
			'pmwVersion'      => defined('PMW_CURRENT_VERSION') ? PMW_CURRENT_VERSION : '',
			'wpVersion'       => get_bloginfo('version'),
			'wcVersion'       => defined('WC_VERSION') ? WC_VERSION : ( Environment::is_woocommerce_active() ? 'active' : 'not active' ),
			'phpVersion'      => PHP_VERSION,
			'memoryLimit'     => Environment::get_wp_memory_limit(),
			'multisite'       => is_multisite(),
			'wpDebug'         => ( defined('WP_DEBUG') && WP_DEBUG ),
			'curl'            => function_exists('curl_version'),
			'externalCache'   => wp_using_ext_object_cache(),
			// Set when WordPress dropped the front-end bundle for a missing dependency (jquery, wp-hooks).
			'scriptDependencyWarning' => \SweetCode\Pixel_Manager\Script_Dependencies::get_warning_message(),
			'gatewayAccuracy' => self::get_gateway_accuracy_for_wp_admin(),
		];
	}

	/**
	 * Payment Gateway Tracking Accuracy report data for the WordPress-components
	 * admin UI. Mirrors the Classic Diagnostics report. All reads are cheap —
	 * the analysis itself is generated on a separate scheduled action, here we
	 * only read the cached results (custom DB table or transient).
	 *
	 * The base per-gateway / weighted accuracy report is a FREE feature; only
	 * the Automatic Conversion Recovery (ACR) columns are premium and are
	 * surfaced via the `acr*` keys when a premium license is active.
	 *
	 * @return array
	 *
	 * @since 1.59.0
	 */
	private static function get_gateway_accuracy_for_wp_admin() {

		$transients_enabled = Environment::is_transients_enabled();

		$data = [
			'transientsEnabled' => $transients_enabled,
			// Canonical helper instead of an inline wpm_fs() check; the WooCommerce
			// Marketplace Pro build ships without the Freemius SDK, so a compound
			// function_exists('wpm_fs') && wpm_fs()->...() condition is always false there.
			'canUseAcr'         => Helpers::is_pmw_pro_version_active(),
			'loadingMessage'    => Debug_Info::tracking_accuracy_loading_message(),
			'date'              => null,
			'dataBounds'        => Tracking_Accuracy_DB::get_data_date_bounds(),
			'gateways'          => [],
			'perGateway'        => null,
			'weighted'          => null,
			'blockedBeaconWarning' => null,
		];

		if (!$transients_enabled) {
			return $data;
		}

		$date         = get_transient('pmw_tracking_accuracy_analysis_date');
		$data['date'] = $date ? (string) $date : null;

		// Available payment gateways (id / method_title / class).
		foreach (Debug_Info::get_payment_gateways() as $gateway) {
			$data['gateways'][] = [
				'id'          => (string) $gateway->id,
				'methodTitle' => (string) $gateway->method_title,
				'class'       => get_class($gateway),
			];
		}

		$per_gateway = Debug_Info::get_gateway_analysis_array();
		if (is_array($per_gateway)) {
			$data['perGateway'] = array_map([ __CLASS__, 'map_gateway_accuracy_row' ], $per_gateway);
		}

		$weighted = Debug_Info::get_gateway_analysis_weighted_array();
		if (is_array($weighted)) {
			$data['weighted'] = array_map([ __CLASS__, 'map_gateway_accuracy_row' ], $weighted);
		}

		// On-site gateways at 0% while nothing is measured: the beacon is blocked
		// or the main script does not run on the order received page.
		$blocked_beacon_message = Debug_Info::get_blocked_beacon_message(Debug_Info::detect_blocked_beacon($weighted));
		if ($blocked_beacon_message) {
			$data['blockedBeaconWarning'] = $blocked_beacon_message;
		}

		return $data;
	}

	/**
	 * Normalise a single gateway-analysis row to camelCase keys for the JS UI.
	 *
	 * @param array $row
	 * @return array
	 *
	 * @since 1.59.0
	 */
	private static function map_gateway_accuracy_row( $row ) {

		$out = [
			'gatewayId'  => isset($row['gateway_id']) ? (string) $row['gateway_id'] : '',
			'measured'   => isset($row['order_count_measured']) ? (int) $row['order_count_measured'] : 0,
			'total'      => isset($row['order_count_total']) ? (int) $row['order_count_total'] : 0,
			'percentage' => isset($row['percentage']) ? (int) $row['percentage'] : 0,
		];

		// Premium ACR columns (only present in the weighted array when licensed).
		if (isset($row['acr_recovered'])) {
			$out['acrRecovered']                = (int) $row['acr_recovered'];
			$out['measuredInclAcr']             = isset($row['order_count_measured_including_acr']) ? (int) $row['order_count_measured_including_acr'] : 0;
			$out['percentageInclAcr']           = isset($row['percentage_including_acr_recovered']) ? (int) $row['percentage_including_acr_recovered'] : 0;
			$out['percentageAcrRecovered']      = isset($row['percentage_acr_recovered_conversions']) ? (int) $row['percentage_acr_recovered_conversions'] : 0;
		}

		return $out;
	}

	/**
	 * Editable WordPress roles for the "disable tracking for roles" control.
	 *
	 * @return array  List of { slug, name }.
	 *
	 * @since 1.59.0
	 */
	private static function get_roles_for_wp_admin() {

		if (!function_exists('get_editable_roles')) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
		}

		$roles = [];
		foreach (get_editable_roles() as $slug => $details) {
			$roles[] = [
				'slug' => (string) $slug,
				'name' => isset($details['name']) ? (string) $details['name'] : (string) $slug,
			];
		}

		return $roles;
	}

	/**
	 * Display names of any detected Consent Management Platforms.
	 *
	 * @return array  List of strings.
	 *
	 * @since 1.59.0
	 */
	private static function get_detected_cmps_for_wp_admin() {

		$checks = [
			'Borlabs Cookie'            => 'is_borlabs_cookie_active',
			'Real Cookie Banner'        => 'is_real_cookie_banner_active',
			'Cookiebot'                 => 'is_cookiebot_active',
			'Complianz'                 => 'is_complianz_active',
			'Cookie Notice'             => 'is_cookie_notice_active',
			'Cookie Script'             => 'is_cookie_script_active',
			'GDPR Cookie Consent'       => 'is_wp_cookie_consent_active',
			'GDPR Cookie Compliance (Moove)' => 'is_moove_gdpr_active',
			'CookieYes'                 => 'is_cookieyes_active',
			'Termly'                    => 'is_termly_active',
			'FAZ Cookie Manager'        => 'is_faz_cookie_manager_active',
			'iubenda'                   => 'is_iubenda_active',
			'Usercentrics'              => 'is_usercentrics_cmp_active',
			'CookiePro'                 => 'is_cookiepro_active',
			'Beautiful Cookie Consent'  => 'is_beautiful_cookie_consent_active',
		];

		$detected = [];
		foreach ($checks as $name => $method) {
			if (method_exists(Environment::class, $method) && Environment::$method()) {
				$detected[] = $name;
			}
		}

		return $detected;
	}

	/**
	 * Consent-mode region codes + names for the restricted-regions picker.
	 *
	 * @return array  List of { code, name }.
	 *
	 * @since 1.59.0
	 */
	private static function get_consent_regions_for_wp_admin() {

		$list = [];
		foreach (Consent_Mode_Regions::get_consent_mode_regions() as $code => $name) {
			$list[] = [
				'code' => (string) $code,
				'name' => (string) $name,
			];
		}

		return $list;
	}

	/**
	 * Serialize all available opportunities as a flat JSON-friendly array
	 * for the Nova admin UI.
	 *
	 * @return array
	 *
	 * @since 1.58.8
	 */
	public static function get_opportunities_for_nova() {

		Opportunities::load_all_opportunity_classes_for_nova();

		$classes = get_declared_classes();
		$result  = [];

		foreach ($classes as $class) {
			if (!is_subclass_of($class, 'SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity')) {
				continue;
			}

			if (!$class::available()) {
				continue;
			}

			$card      = $class::display_card_data();
			$dismissed = $class::is_dismissed();

			// card_data() descriptions use esc_html__() which encodes entities
			// for HTML output. The React UI renders plain text, so decode
			// entities and strip any inline HTML tags (e.g. <strong>).
			$description = array_map(function ( $paragraph ) {
				return html_entity_decode(wp_strip_all_tags($paragraph), ENT_QUOTES, 'UTF-8');
			}, isset($card['description']) ? $card['description'] : []);

			// Custom buttons that point at a real URL. The Classic UI also uses
			// them for in-page section jumps ("#" plus a data attribute), which
			// the React app cannot follow, so those are left out here.
			$buttons = [];
			if (isset($card['custom_buttons']) && is_array($card['custom_buttons'])) {
				foreach ($card['custom_buttons'] as $button) {
					if (empty($button['url']) || empty($button['label']) || 0 !== strpos($button['url'], 'http')) {
						continue;
					}
					$buttons[] = [
						'label' => html_entity_decode(wp_strip_all_tags($button['label']), ENT_QUOTES, 'UTF-8'),
						'url'   => $button['url'],
					];
				}
			}

			$result[] = [
				'id'          => isset($card['id']) ? $card['id'] : '',
				'title'       => html_entity_decode(wp_strip_all_tags(isset($card['title']) ? $card['title'] : ''), ENT_QUOTES, 'UTF-8'),
				'description' => $description,
				'impact'      => Opportunities::normalize_impact(isset($card['impact']) ? $card['impact'] : 'low'),
				'setupLink'   => isset($card['setup_link']) ? $card['setup_link'] : '',
				'learnMore'   => isset($card['learn_more_link']) ? $card['learn_more_link'] : '',
				'setupVideo'  => isset($card['setup_video']) ? $card['setup_video'] : '',
				'buttons'     => $buttons,
				'dismissed'   => $dismissed,
			];
		}

		// Sort by impact: high → medium → low
		$impact_order = [ 'high' => 0, 'medium' => 1, 'low' => 2 ];
		usort($result, function ( $a, $b ) use ( $impact_order ) {
			$a_order = isset($impact_order[$a['impact']]) ? $impact_order[$a['impact']] : 2;
			$b_order = isset($impact_order[$b['impact']]) ? $impact_order[$b['impact']] : 2;
			return $a_order - $b_order;
		});

		return $result;
	}

	/**
	 * Total impact weight of all opportunity checks the plugin can run,
	 * regardless of whether they currently apply to this store.
	 *
	 * The Nova UI uses this as the optimization-score denominator. Checks
	 * that pass (already configured, or not applicable) never reach the UI,
	 * so without this the score would only ever count dismissed cards and a
	 * store with a few open opportunities would show 0%.
	 *
	 * Weights match the UI: high = 3, medium = 2, low = 1.
	 *
	 * @return int
	 *
	 * @since 1.59.0
	 */
	private static function get_opportunities_catalog_weight_for_nova() {

		Opportunities::load_all_opportunity_classes_for_nova();

		$weights = [
			'high'   => 3,
			'medium' => 2,
			'low'    => 1,
		];

		$total = 0;

		foreach (get_declared_classes() as $class) {
			if (!is_subclass_of($class, 'SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity')) {
				continue;
			}

			$card   = $class::card_data();
			$impact = Opportunities::normalize_impact(isset($card['impact']) ? $card['impact'] : 'low');
			$total += $weights[$impact];
		}

		return $total;
	}

	private static function get_link_locale() {

		if (substr(get_user_locale(), 0, 2) === 'de') {
			return 'de';
		} else {
			return 'en';
		}
	}

	/*
	 * descriptions
	 */

	public static function plugin_section_main_description() {
		// do nothing
	}

	public static function plugin_section_advanced_description() {
		// do nothing
	}

	public static function plugin_section_add_cart_data_description() {
		//        echo '<div id="beta-description" style="margin-top:20px">';
		//        esc_html_e('Find out more about this new feature: ', 'woocommerce-google-adwords-conversion-tracking-tag');
		//        echo '<a href="https://support.google.com/google-ads/answer/9028254" target="_blank">https://support.google.com/google-ads/answer/9028254</a><br>';
		//        echo '</div>';
	}

	public static function plugin_section_shop_html() {
		// do nothing
	}

	public static function plugin_section_consent_management_html() {
		// do nothing
	}

	public static function plugin_section_logger() {
		// do nothing
	}

	public static function plugin_section_diagnostics_html() {

		// output a text that explains that transients need to be enabled
		// then abort
		if (!Environment::is_transients_enabled()) {

			?>
			<div style="margin-top:20px">
				<h2>
					<?php esc_html_e('Diagnostics', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</h2>
				<div>
					<?php esc_html_e('Transients are disabled on your site. Transients are required for the diagnostics report.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</div>
				<div style="margin-top: 10px">
					<?php esc_html_e('Please enable transients on your site.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</div>
			</div>
			<?php

			return;
		}

		?>
		<div style="margin-top:20px">
			<h2>
				<?php esc_html_e('Payment Gateway Tracking Accuracy Report', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				<div class="pmw-status-icon beta"><?php esc_html_e('beta', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></div>
			</h2>

			<div style="margin-bottom: 20px">
				<?php esc_html_e("What's this? Follow this link to learn more", 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				:
				<?php self::get_documentation_html_by_key('payment_gateway_tracking_accuracy'); ?>
			</div>

			<div>
				<div>

					<b><?php esc_html_e('Available payment gateways', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
						:</b>
				</div>
				<div style="margin-left: 10px; font-family: Courier">
					<table>
						<thead style="align:left">
						<tr>
							<th style="text-align: left"><?php esc_html_e('id', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<th style="text-align: left"><?php esc_html_e('method_title', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
							<th style="text-align: left"><?php esc_html_e('class', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></th>
						</tr>
						</thead>
						<tbody>
						<?php foreach (Debug_Info::get_payment_gateways() as $gateway) : ?>
							<tr>
								<td><?php echo esc_html($gateway->id); ?></td>
								<td><?php echo esc_html($gateway->method_title); ?></td>
								<td><?php echo esc_html(get_class($gateway)); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>

			</div>
			<div style="margin-top: 10px">

				<b><?php esc_html_e('Purchase confirmation page reached per gateway (active and inactive)', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					:</b>

				<?php
				if (Debug_Info::get_gateway_analysis_array() === false) {
					?>
					<br>
					<?php
					echo esc_html(Debug_Info::tracking_accuracy_loading_message());
					$per_gateway_analysis = [];
				} else {
					$per_gateway_analysis = Debug_Info::get_gateway_analysis_array();
				}
				?>

				<div style="margin-left: 10px; font-family: Courier;">
					<table>

						<?php

						$order_count_total    = 0;
						$order_count_measured = 0;
						?>

						<tbody>
						<?php foreach ($per_gateway_analysis as $gateway_analysis) : ?>
							<?php
							$order_count_total    += $gateway_analysis['order_count_total'];
							$order_count_measured += $gateway_analysis['order_count_measured'];
							?>
							<tr>
								<td><?php echo esc_html($gateway_analysis['gateway_id']); ?></td>
								<td><?php echo esc_html($gateway_analysis['order_count_measured']); ?></td>
								<td>of</td>
								<td><?php echo esc_html($gateway_analysis['order_count_total']); ?></td>
								<td>=</td>
								<td><?php echo esc_html($gateway_analysis['percentage']); ?>%</td>
								<td><?php self::get_gateway_accuracy_warning_status($gateway_analysis['percentage'], $gateway_analysis['order_count_total']); ?></td>
							</tr>
						<?php endforeach; ?>

						</tbody>
					</table>
				</div>

			</div>

			<div style="margin-top: 10px">

				<b><?php esc_html_e('Purchase confirmation page reached per gateway (only active), weighted by frequency', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					:</b>

				<?php
				if (Debug_Info::get_gateway_analysis_weighted_array() === false) {
					?>
					<br>
					<?php
					echo esc_html(Debug_Info::tracking_accuracy_loading_message());
					$per_gateway_analysis = [];
				} else {
					$per_gateway_analysis = Debug_Info::get_gateway_analysis_weighted_array();
				}
				?>

				<div style="margin-left: 10px; font-family: Courier;">
					<table>
						<?php

						$order_count_total    = 0;
						$order_count_measured = 0;
						?>

						<tbody>
						<?php foreach ($per_gateway_analysis as $gateway_analysis) : ?>
							<?php
							$order_count_total    += $gateway_analysis['order_count_total'];
							$order_count_measured += $gateway_analysis['order_count_measured'];
							?>
							<tr>
								<td><?php echo esc_html($gateway_analysis['gateway_id']); ?></td>
								<td><?php echo esc_html($gateway_analysis['order_count_measured']); ?></td>
								<td>of</td>
								<td><?php echo esc_html($gateway_analysis['order_count_total']); ?></td>
								<td>=</td>
								<td><?php echo esc_html($gateway_analysis['percentage']); ?>%</td>
								<td><?php self::get_gateway_accuracy_warning_status($gateway_analysis['percentage'], $gateway_analysis['order_count_total']); ?></td>
							</tr>
						<?php endforeach; ?>
						<tr>
							<td>Total</td>
							<td><?php echo esc_html($order_count_measured); ?></td>
							<td>of</td>
							<td><?php echo esc_html($order_count_total); ?></td>
							<td>=</td>
							<td>
								<?php
								$percent = Helpers::get_percentage($order_count_measured, $order_count_total);

								if ($order_count_total > 0) {
									echo esc_html($percent . '%');
								} else {
									echo '0%';
								}
								?>
							</td>
							<td><?php self::get_gateway_accuracy_warning_status($percent, $order_count_total); ?></td>

						</tr>
						</tbody>
					</table>
				</div>
			</div>

		</div>

		<div style="margin-top: 10px">

			<b><?php esc_html_e('Automatic Conversion Recovery (ACR)', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				:</b>
			<?php self::get_documentation_html_by_key('acr'); ?>
			<?php

			if (wpm_fs()->can_use_premium_code__premium_only()) {

				if (Debug_Info::get_gateway_analysis_weighted_array() === false) {
					?>
					<br>
					<?php
					echo esc_html(Debug_Info::tracking_accuracy_loading_message());
					$per_gateway_analysis = [];
				} else {
					$per_gateway_analysis = Debug_Info::get_gateway_analysis_weighted_array();
				}

				?>

				<div style="margin-left: 10px; font-family: Courier;">

					<table>

						<?php

						$order_count_total    = 0;
						$order_count_measured = 0;
						$missing_conversions  = 0;
						$acr_total_recovered  = 0;

						?>

						<tbody>
						<?php foreach ($per_gateway_analysis as $gateway_analysis) : ?>

							<?php

							if (!isset($gateway_analysis['order_count_total'])) {
								// skip
								continue;
							}

							$order_count_total_value = (int) $gateway_analysis['order_count_total'];

							$order_count_measured_including_acr = isset($gateway_analysis['order_count_measured_including_acr'])
								? (int) $gateway_analysis['order_count_measured_including_acr']
								: ( isset($gateway_analysis['order_count_measured'])
									? (int) $gateway_analysis['order_count_measured']
									: 0 );

							$order_count_measured_raw = isset($gateway_analysis['order_count_measured'])
								? (int) $gateway_analysis['order_count_measured']
								: $order_count_measured_including_acr;

							$acr_recovered = isset($gateway_analysis['acr_recovered'])
								? (int) $gateway_analysis['acr_recovered']
								: 0;

							$percentage_including_acr_recovered = isset($gateway_analysis['percentage_including_acr_recovered'])
								? $gateway_analysis['percentage_including_acr_recovered']
								: Helpers::get_percentage($order_count_measured_including_acr, $order_count_total_value);

							$gateway_id = isset($gateway_analysis['gateway_id'])
								? $gateway_analysis['gateway_id']
								: __('Unknown gateway', 'woocommerce-google-adwords-conversion-tracking-tag');

							$order_count_total    += $order_count_total_value;
							$order_count_measured += $order_count_measured_including_acr;
							$missing_conversions  += max($order_count_total_value - $order_count_measured_raw, 0);
							$acr_total_recovered  += $acr_recovered;
							?>
							<tr>
								<td><?php echo esc_html($gateway_id); ?></td>
								<td><?php echo esc_html($order_count_measured_including_acr . ' (' . $acr_recovered . ')'); ?></td>

								<td>of</td>
								<td><?php echo esc_html($order_count_total_value); ?></td>
								<td>=</td>
								<td><?php echo esc_html($percentage_including_acr_recovered); ?>%
								</td>

								<td><?php self::get_gateway_accuracy_warning_status($percentage_including_acr_recovered, $order_count_total_value); ?></td>


							</tr>
						<?php endforeach; ?>
						<tr>
							<td>Total</td>
							<td><?php echo esc_html($order_count_measured); ?>
								(<?php echo esc_html($acr_total_recovered); ?>)
							</td>
							<td>of</td>
							<td><?php echo esc_html($order_count_total); ?></td>
							<td>=</td>
							<td>
								<?php
								$percent = Helpers::get_percentage($order_count_measured, $order_count_total);

								if ($order_count_total > 0) {
									echo esc_html($percent . '%');
								} else {
									echo '0%';
								}
								?>
							</td>
							<td><?php self::get_gateway_accuracy_warning_status($percent, $order_count_total); ?></td>

						</tr>
						</tbody>
					</table>
					<p>
						<b>
							<?php
							// translators: The number and percentage of orders that were recovered by the Automatic Conversion Recovery (ACR).
							esc_html_e(
								sprintf(
								// translators: The number and percentage of orders that were recovered by the Automatic Conversion Recovery (ACR).
									__('ACR recovered %1$s (%2$s%%) out of %3$s missing conversions.', 'woocommerce-google-adwords-conversion-tracking-tag'),
									$acr_total_recovered,
									Helpers::get_percentage($acr_total_recovered, $missing_conversions),
									$missing_conversions
								)
							);
							?>
						</b>
					</p>
				</div>
				<?php
			} else {
				?>

				<div style="margin-top: 10px">

					<div style="margin-left: 10px">
						<p>
							<?php esc_html_e('This feature is only available in the pro version of the plugin. Follow the link to learn more about it:', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							<?php self::get_documentation_html_by_key('acr'); ?></br>
							<?php esc_html_e('Get the pro version of the Pixel Manager for WooCommerce over here', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							: <a href="<?php echo esc_url(Helpers::is_pmw_wcm_distro() ? Commercial_Links::WC_PRODUCT_URL : 'https://sweetcode.com/pricing'); ?>"
								target="_blank"><?php esc_html_e('Go Pro', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></a>
						</p>
					</div>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	}

	public static function plugin_section_opportunities_html() {
		Opportunities::html();
	}

	private static function get_gateway_accuracy_warning_status( $percent, $order_count = 0 ) {
		if (intval($order_count) <= 0) {
			// No orders for this gateway in the period, so there is nothing to judge.
			echo '';
		} elseif (0 === intval($percent)) {
			// Orders exist but none were tracked: the worst case, flag it distinctly.
			echo '<span style="background:#d63638;color:#fff;padding:1px 6px;border-radius:3px">untracked</span>';
		} elseif ($percent > 0 && $percent < 90) {
			echo '<span style="color:red">warning</span>';
		} elseif ($percent >= 90 && $percent < 95) {
			echo '<span style="color:orange">monitor</span>';
		} else {
			echo '<span style="color:green">good</span>';
		}
	}

	public static function plugin_section_support_description() {

		$options_backup_array = Options::get_automatic_options_backup();
		$current_options      = Options::get_options();
		$current_timestamp    = isset($current_options['timestamp']) ? $current_options['timestamp'] : null;

		?>
		<!-- Contacting Support -->
		<div style="margin-top:20px">
			<h2><?php esc_html_e('Contacting Support', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h2>
		</div>
		<?php

		if (PMW_DISTRO == 'fms') {
			self::support_info_for_freemius();
		} elseif (PMW_DISTRO == 'wcm') {
			self::support_info_for_wc_market();
		}

		?>
		<!-- Contacting Support -->

		<hr style="border: none;height: 1px; color: #333; background-color: #333;">

		<!-- Debug Info -->
		<div class="pmw-debug-info-section">
			<h2><?php esc_html_e('Debug Information', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h2>

			<style>
				.pmw-debug-info-section button#debug-info-button {
					min-width: 150px;
					text-align: center;
					padding: 5px 14px;
					height: auto;
					font-weight: 500;
					transition: all 0.2s ease;
					border-radius: 4px;
					box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
				}

				.pmw-debug-info-section button#debug-info-button:hover {
					transform: translateY(-1px);
					box-shadow: 0 3px 5px rgba(0, 0, 0, 0.1);
					background-color: #135e96;
					border-color: #135e96;
				}

				.pmw-debug-info-section .success-message {
					display: inline-flex;
					align-items: center;
					font-weight: 600;
					color: #2e7d32;
					background-color: #f0fff4;
					border: 1px solid #c6e6c9;
					padding: 4px 12px;
					border-radius: 20px;
					font-size: 13px;
					letter-spacing: 0.2px;
					box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
				}
			</style>

			<div>
				<textarea id="debug-info-textarea" class=""
							style="display:block; margin-bottom: 10px; width: 100%;resize: none;color:dimgrey;font-family: Courier;border-radius: 4px;"
							cols="100%" rows="15" readonly
							placeholder="<?php esc_attr_e('Click \'Generate debug info\' to load the report. It runs a few outbound connectivity checks, so it can take a moment.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>"></textarea>
				<button id="debug-info-generate-button" class="button button-primary"
						type="button"><?php esc_html_e('Generate debug info', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></button>
				<button id="debug-info-button" class="button"
						type="button" disabled><?php esc_html_e('Copy to Clipboard', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></button>
				<span id="debug-info-success" class="success-message"
						style="display:none;margin-left: 10px;color: #2e7d32;font-weight: 500;"><?php esc_html_e('Copied!', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></span>
			</div>

		</div>
		<!-- Debug Info -->

		<hr class="pmw-hr">

		<!-- Export Settings -->
		<div class="pmw-export-section">
			<h2><?php esc_html_e('Export settings', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h2>

			<div>
				<textarea id="export-settings-json" class=""
							style="display:block; margin-bottom: 10px; width: 100%;resize: none;color:dimgrey;font-family: monospace;border-radius: 4px;"
							cols="100%" rows="10" readonly><?php echo esc_textarea(wp_json_encode(Options::get_options())); ?>
				</textarea>
				<div class="pmw-export-buttons">
					<button id="export-to-disk-button" class="button button-primary"
							type="button"
							onclick="pmw.saveSettingsToDisk()">
						<?php esc_html_e('Export to disk', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</button>
					<button id="export-copy-clipboard-button" class="button button-primary"
							type="button">
						<?php esc_html_e('Copy to Clipboard', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</button>
					<span id="export-copy-success" class="success-message"
							style="display:none;margin-left: 10px;color: #2e7d32;font-weight: 500;"><?php esc_html_e('Copied!', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></span>
				</div>
			</div>

			<style>
				.pmw-export-section textarea {
					font-size: 13px;
				}

				.pmw-export-buttons {
					display: flex;
					align-items: center;
				}

				.pmw-export-section .button {
					min-width: 150px;
					text-align: center;
					padding: 5px 14px;
					height: auto;
					font-weight: 500;
					transition: all 0.2s ease;
					border-radius: 4px;
					box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
					margin-right: 10px;
				}

				.pmw-export-section .button:hover {
					transform: translateY(-1px);
					box-shadow: 0 3px 5px rgba(0, 0, 0, 0.1);
					background-color: #135e96;
					border-color: #135e96;
				}

				.pmw-export-section .success-message {
					display: inline-flex;
					align-items: center;
					font-weight: 600;
					color: #2e7d32;
					background-color: #f0fff4;
					border: 1px solid #c6e6c9;
					padding: 4px 12px;
					border-radius: 20px;
					font-size: 13px;
					letter-spacing: 0.2px;
					box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
				}
			</style>

			<script>
				document.addEventListener("DOMContentLoaded", function () {
					const exportCopyBtn     = document.getElementById("export-copy-clipboard-button");
					const exportTextarea    = document.getElementById("export-settings-json");
					const exportCopySuccess = document.getElementById("export-copy-success");

					if (exportCopyBtn && exportTextarea) {
						exportCopyBtn.addEventListener("click", function () {
							exportTextarea.select();
							document.execCommand("copy");

							if (exportCopySuccess) {
								exportCopySuccess.style.display = "inline-flex";
								setTimeout(function () {
									exportCopySuccess.style.display = "none";
								}, 2000);
							}
						});
					}
				});
			</script>
		</div>
		<!-- Export Settings -->

		<hr class="pmw-hr">

		<!-- Import Settings -->
		<div class="pmw-import-section">
			<h2 class="pmw-import-heading"><?php esc_html_e('Import settings', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h2>
			<div class="pmw-import-content">
				<div class="pmw-file-upload-container">
					<a href="#" class="pmw-file-upload-button button button-primary">
						<?php esc_html_e('Choose File', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</a>
					<span class="pmw-selected-file-name"></span>
					<input type="file" id="json-settings-file-input" style="display: none;"/>
				</div>

				<pre id="settings-upload-status-success" style="display: none; white-space: pre-line;">
					<span style="color: green; font-weight: bold">
						<?php esc_html_e('Settings imported successfully!', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
					<span>
						<?php esc_html_e('Reloading...(in 1 second)!', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
				</pre>

				<pre id="settings-upload-status-error" style="display: none; white-space: pre-line;">
					<span style="color: red; font-weight: bold">
						<?php esc_html_e('There was an error importing that file! Please try again.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
					<span id="settings-upload-status-error-message" style="color: red; font-weight: bold"></span>
				</pre>
			</div>

			<style>
				.pmw-import-section {
					margin: 20px 0;
					padding: 0;
				}

				.pmw-import-heading {
					margin-bottom: 10px;
					font-size: 1.5em;
					color: #23282d;
				}

				.pmw-import-content {
					margin-bottom: 20px;
				}

				.pmw-file-upload-container {
					display: flex;
					align-items: center;
					margin-bottom: 15px;
					padding-top: 2px;
					padding-bottom: 2px;
				}

				.pmw-file-upload-button {
					min-width: 150px;
					text-align: center;
					padding: 4px 12px;
					height: 30px; /* Explicitly set height */
					line-height: 22px; /* Increase line height for better vertical centering */
					font-size: 13px; /* Standard WordPress button font size */
					font-weight: 500;
					transition: all 0.2s ease;
					border-radius: 4px;
					box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
					background-color: #2271b1;
					border-color: #2271b1;
					color: #fff;
					cursor: pointer;
					display: inline-block; /* Use standard button display */
					box-sizing: border-box; /* Include padding in height calculation */
				}

				.pmw-file-upload-button:hover {
					transform: translateY(-1px);
					box-shadow: 0 3px 5px rgba(0, 0, 0, 0.1);
					background-color: #135e96;
					border-color: #135e96;
				}

				.pmw-selected-file-name {
					margin-left: 10px;
					font-style: italic;
					color: #646970;
				}
			</style>

			<script>
				document.addEventListener("DOMContentLoaded", function () {
					const fileInput       = document.getElementById("json-settings-file-input");
					const fileNameDisplay = document.querySelector(".pmw-selected-file-name");
					const fileButton      = document.querySelector(".pmw-file-upload-button");

					if (fileInput && fileNameDisplay && fileButton) {
						// Handle file selection
						fileInput.addEventListener("change", function () {
							if (this.files && this.files.length > 0) {
								fileNameDisplay.textContent = this.files[0].name;
							} else {
								fileNameDisplay.textContent = "";
							}
						});

						// Trigger file dialog when the button is clicked
						fileButton.addEventListener("click", function (e) {
							e.preventDefault();
							fileInput.click();
						});
					}
				});
			</script>
		</div>
		<!-- Import Settings -->

		<hr class="pmw-hr">

		<!-- Automatic Settings Backup -->
		<div class="pmw-backup-section">
			<h2 class="pmw-backup-heading"><?php esc_html_e('Automatic Settings Backup', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h2>
			<p class="pmw-backup-description"><?php esc_html_e('Manage your settings backups. You can restore previous configurations or download backup files.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></p>

			<div class="pmw-backup-content">
				<?php
				if (empty($options_backup_array)) {
					echo '<div class="pmw-no-backups-message">';
					echo esc_html__('No automatic settings backups available.', 'woocommerce-google-adwords-conversion-tracking-tag');
					echo '</div>';
				} else {
					echo '<div class="pmw-table-container">';
					echo '<table class="pmw-backup-table widefat">';
					echo '<thead><tr>';
					echo '<th>' . esc_html__('ID', 'woocommerce-google-adwords-conversion-tracking-tag') . '</th>';
					echo '<th>' . esc_html__('Date', 'woocommerce-google-adwords-conversion-tracking-tag') . '</th>';
					echo '<th>' . esc_html__('DB Version', 'woocommerce-google-adwords-conversion-tracking-tag') . '</th>';
					echo '<th>' . esc_html__('Status', 'woocommerce-google-adwords-conversion-tracking-tag') . '</th>';
					echo '<th>' . esc_html__('Restore', 'woocommerce-google-adwords-conversion-tracking-tag') . '</th>';
					echo '<th>' . esc_html__('Download', 'woocommerce-google-adwords-conversion-tracking-tag') . '</th>';
					echo '</tr></thead>';
					echo '<tbody>';
					foreach ($options_backup_array as $timestamp => $settings) {
						$date_part     = wp_date(get_option('date_format'), $timestamp);
						$time_part     = wp_date('H:i:s', $timestamp);
						$readable_date = sprintf('%s %s (h:m:s)', $date_part, $time_part);
						$db_version    = isset($settings['db_version']) ? esc_html($settings['db_version']) : esc_html__('Unknown', 'woocommerce-google-adwords-conversion-tracking-tag');

						// Check if this backup is currently active
						$is_active = ( null !== $current_timestamp && $timestamp == $current_timestamp );
						$row_class = $is_active ? ' class="pmw-active-row"' : '';

						echo '<tr' . esc_attr( $row_class ) . '>';
						echo '<td><code class="pmw-timestamp-id">' . esc_html($timestamp) . '</code></td>';
						echo '<td>' . esc_html($readable_date) . '</td>';
						echo '<td><span class="pmw-db-version">' . esc_html($db_version) . '</span></td>';

						// Status column
						if ($is_active) {
							echo '<td><span class="pmw-active-status">' . esc_html__('Active', 'woocommerce-google-adwords-conversion-tracking-tag') . '</span></td>';
						} else {
							echo '<td><span class="pmw-backup-status">' . esc_html__('Backup', 'woocommerce-google-adwords-conversion-tracking-tag') . '</span></td>';
						}

						// Restore button - disabled for active backup
						if ($is_active) {
							echo '<td><button class="button" disabled title="' . esc_attr__('Cannot restore the currently active backup', 'woocommerce-google-adwords-conversion-tracking-tag') . '">' . esc_html__('Active', 'woocommerce-google-adwords-conversion-tracking-tag') . '</button></td>';
						} else {
							echo '<td><button class="button pmw-restore-backup-button" data-timestamp="' . esc_attr($timestamp) . '">' . esc_html__('Restore', 'woocommerce-google-adwords-conversion-tracking-tag') . '</button></td>';
						}

						echo '<td><a href="' . esc_url(self::get_automatic_options_backup_download_link($timestamp)) . '" class="button button-primary">' . esc_html__('Download', 'woocommerce-google-adwords-conversion-tracking-tag') . '</a></td>';
						echo '</tr>';
					}
					echo '</tbody>';
					echo '</table>';
					echo '</div>'; // Close .pmw-table-container
				}
				?>
			</div> <!-- Close .pmw-backup-content -->
		</div>

		<!-- Automatic Settings Backup -->

		<hr class="pmw-hr">

		<!-- Plugin data / uninstall -->
		<div class="pmw-plugin-data-section" style="margin-top:20px">
			<h2><?php esc_html_e('Plugin data', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></h2>
			<label>
				<!-- The hidden input ensures an unchecked box still saves "0" instead of dropping the key -->
				<input type="hidden" value="0" name="wgact_plugin_options[general][delete_plugin_data_on_uninstall]">
				<input type="checkbox"
						id="wpm_plugin_option_delete_plugin_data_on_uninstall"
						name="wgact_plugin_options[general][delete_plugin_data_on_uninstall]"
						value="1"
					<?php checked(Options::is_delete_plugin_data_on_uninstall_active()); ?>
				/>
				<?php esc_html_e('Delete all plugin data on uninstall', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</label>
			<?php self::display_status_icon(Options::is_delete_plugin_data_on_uninstall_active(), true, true); ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('When enabled, deleting the plugin also removes all of its settings, backups, and stored data from the database. Leave it off to keep your configuration if you reinstall later. This only takes effect when you delete (not just deactivate) the plugin.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		</div>
		<!-- Plugin data / uninstall -->

		<?php
	}

	/**
	 * Generates a download link for the automatic options backup.
	 *
	 * @param int $timestamp The timestamp of the backup.
	 * @return string The URL to download the backup.
	 *
	 * @since 1.49.0
	 */
	private static function get_automatic_options_backup_download_link( $timestamp ) {
		// Use the REST API endpoint to download the backup and add the nonce for authentication
		$url = get_rest_url(null, 'pmw/v1/options-backup/' . $timestamp);

		// Add the WordPress REST API nonce to the URL
		return add_query_arg('_wpnonce', wp_create_nonce('wp_rest'), $url);
	}

	private static function support_info_for_freemius() {
		?>
		<div style="margin-bottom: 30px;">
			<ul>

				<?php if (PMW_DISTRO == 'fms') : ?>
					<li id="pmw-chat-li" style="display: none;">
						<div style="display: flex; align-items: center;">
							<div style="margin-right: 10px;"> <!-- Add some margin for spacing -->
								<?php esc_html_e('Chat with our fantastic AI bot Pixie (Pixie knows everything we do!):', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							</div>
							<div>
								<button type="button" class="button button-primary" onclick="pmw.loadAiChatWindow()">
									<?php esc_html_e('Chat', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
								</button>
							</div>
						</div>
					</li>

				<?php endif; ?>
				<li>
					<?php esc_html_e('Post a support request in the WordPress support forum here: ', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					<a href="https://wordpress.org/support/plugin/woocommerce-google-adwords-conversion-tracking-tag/"
						target="_blank">
						<?php esc_html_e('Support forum', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</a>
					&nbsp;
					<span class="dashicons dashicons-info"></span>
					<?php esc_html_e('(Never post the debug or other sensitive information to the support forum. Instead send us the information by email.)', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</li>
				<li>
					<?php esc_html_e('Send us an email to the following address:', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					<a href="mailto:support@sweetcode.com" target="_blank">support@sweetcode.com</a>
				</li>
			</ul>
		</div>

		<?php
	}

	private static function support_info_for_wc_market() {
		?>
		<div style="margin-bottom: 30px;">
			<ul>
				<li>
					<?php esc_html_e('Send us your support request through the WooCommerce.com dashboard: ', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					<a href="https://woocommerce.com/my-account/create-a-ticket/" target="_blank">WooCommerce support
						dashboard</a>
				</li>
			</ul>
		</div>

		<?php
	}

	public static function option_html_google_analytics_4_id() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_analytics_4_measurement_id"
				name="wgact_plugin_options[google][analytics][ga4][measurement_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_ga4_measurement_id()); ?>"
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_ga4_enabled());
		self::get_documentation_html_by_key('google_analytics_4_id');
		self::output_advanced_section_cog_html('google');
		self::wistia_video_icon('rcc3qzb25l');
		echo '<br><br>';
		esc_html_e('The Google Analytics 4 measurement ID looks like this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>G-R912ZZ1MHH0</code>,&nbsp;';
		echo '<code>GT-5DFPXXXX</code>,&nbsp;';
		esc_html_e('or', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>AW-123456789</code>';
	}

	public static function option_html_google_ads_conversion_id() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_conversion_id"
				name="wgact_plugin_options[google][ads][conversion_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_google_ads_conversion_id()); ?>"
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_google_ads_active());
		self::get_documentation_html_by_key('google_ads_conversion_id');
		self::output_advanced_section_cog_html('google');
		self::wistia_video_icon('vcuj59kbm6');
		self::wistia_video_icon('and34arrgg');
		echo '<br><br>';
		esc_html_e('The conversion ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>123456789</code>';
	}

	public static function option_html_google_ads_conversion_label() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_conversion_label"
				name="wgact_plugin_options[google][ads][conversion_label]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_google_ads_conversion_label()); ?>"
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::get_google_ads_conversion_label(), Options::get_google_ads_conversion_id());
		self::get_documentation_html_by_key('google_ads_conversion_label');
		self::output_advanced_section_cog_html('google');
		self::wistia_video_icon('vcuj59kbm6');
		self::wistia_video_icon('and34arrgg');
		echo '<br><br>';
		esc_html_e('The purchase conversion label looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>Xt19CO3axGAX0vg6X3gM</code>';
		if (Options::get_google_ads_conversion_label() && !Options::get_google_ads_conversion_id()) {
			echo '<p><span class="dashicons dashicons-info"></span>';
			esc_html_e('Requires an active Google Ads Conversion ID', 'woocommerce-google-adwords-conversion-tracking-tag');
		}
		echo '</p>';
	}

	public static function option_html_vwo_account_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_vwo_account_id"
				name="wgact_plugin_options[pixels][vwo][account_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_vwo_account_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_vwo_active(), true, true);
		self::get_documentation_html_by_key('vwo_account_id');
		self::wistia_video_icon('9besn6q7h0');
		echo '<br><br>';
		esc_html_e('The VWO account ID looks like this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>737312</code>&nbsp;';
	}

	public static function option_html_optimizely_project_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_optimizely_project_id"
				name="wgact_plugin_options[pixels][optimizely][project_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_optimizely_project_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_optimizely_active(), true, true);
		self::get_documentation_html_by_key('optimizely_project_id');
		echo '<br><br>';
		esc_html_e('The Optimizely project ID looks like this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>20297535627</code>&nbsp;';
	}

	public static function option_html_ab_tasty_account_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_ab_tasty_account_id"
				name="wgact_plugin_options[pixels][ab_tasty][account_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_ab_tasty_account_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_ab_tasty_active(), true, true);
		self::get_documentation_html_by_key('ab_tasty_account_id');
		echo '<br><br>';
		esc_html_e('The AB Tasty account ID looks like this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>3d09baddc21a365b7da5ae4d0aa5cb95</code>&nbsp;';
	}

	public static function option_html_contentsquare_tag_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_contentsquare_tag_id"
				name="wgact_plugin_options[pixels][contentsquare][tag_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_contentsquare_tag_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_contentsquare_active());
		self::get_documentation_html_by_key('contentsquare_tag_id');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('The Contentsquare tag ID looks like this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>b457e22cc0c6e</code>&nbsp;';
	}

	public static function option_html_clarity_project_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_clarity_project_id"
				name="wgact_plugin_options[pixels][clarity][project_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_clarity_project_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_clarity_active());
		self::get_documentation_html_by_key('clarity_project_id');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('The Microsoft Clarity project ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>q9zk3x7p2w</code>&nbsp;';
	}

	/**
	 * Mixpanel project token
	 *
	 * @since 1.64.1
	 *
	 * @return void
	 */
	public static function option_html_mixpanel_project_token() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_mixpanel_project_token"
				name="wgact_plugin_options[pixels][mixpanel][project_token]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_mixpanel_project_token()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_mixpanel_active());
		self::get_documentation_html_by_key('mixpanel_project_token');
		self::output_advanced_section_cog_html('mixpanel');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Enter your Mixpanel project token. You can find it in Mixpanel under Settings > Project Settings > Project Token. It looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>abcd1234abcd1234abcd1234abcd1234</code>';
	}

	/**
	 * Mixpanel data residency region
	 *
	 * Mixpanel does not ingest events that are sent to the wrong region, so the
	 * region has to match the one the project was created in.
	 *
	 * @since 1.64.1
	 *
	 * @return void
	 */
	public static function option_html_mixpanel_data_residency() {

		$regions = [
			'us' => esc_html__('United States (default)', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'eu' => esc_html__('European Union', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'in' => esc_html__('India', 'woocommerce-google-adwords-conversion-tracking-tag'),
		];
		?>
		<select id="pmw_plugin_mixpanel_data_residency"
				name="wgact_plugin_options[pixels][mixpanel][data_residency]"
			<?php echo esc_html(self::disable_if_demo()); ?>
		>
			<?php foreach ($regions as $region_key => $region_label) : ?>
				<option value="<?php echo esc_attr($region_key); ?>"
					<?php selected($region_key, Options::get_mixpanel_data_residency()); ?>
				>
					<?php echo esc_html($region_label); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php self::get_documentation_html_by_key('mixpanel_data_residency'); ?>
		<?php self::html_pro_feature(); ?>
		<?php
		echo '<br><br>';
		esc_html_e('Select the region your Mixpanel project is hosted in. Mixpanel does not ingest events that are sent to the wrong region. Projects hosted in the EU have a Mixpanel URL starting with eu.mixpanel.com, Indian projects with in.mixpanel.com.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Mixpanel Ingestion API
	 *
	 * @since 1.64.1
	 *
	 * @return void
	 */
	public static function option_html_mixpanel_ingestion_api() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][mixpanel][ingestion_api][enabled]">
			<input type="checkbox"
					id="pmw_plugin_mixpanel_ingestion_api"
					name="wgact_plugin_options[pixels][mixpanel][ingestion_api][enabled]"
					value="1"
				<?php checked(Options::is_mixpanel_ingestion_api_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable the Mixpanel Ingestion API', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_mixpanel_ingestion_api_enabled(), Options::is_mixpanel_active(), true);
		self::get_documentation_html_by_key('mixpanel_ingestion_api');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Sends purchases and refunds to Mixpanel server-side. The project token authenticates the requests, so no additional credential is needed.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Mixpanel session replay and heatmaps
	 *
	 * @since 1.64.1
	 *
	 * @return void
	 */
	public static function option_html_mixpanel_session_recording() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][mixpanel][session_recording]">
			<input type="checkbox"
					id="pmw_plugin_mixpanel_session_recording"
					name="wgact_plugin_options[pixels][mixpanel][session_recording]"
					value="1"
				<?php checked(Options::is_mixpanel_session_recording_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Mixpanel session replay and heatmaps', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_mixpanel_session_recording_enabled(), Options::is_mixpanel_active(), true);
		self::get_documentation_html_by_key('mixpanel_session_recording');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Session replay also has to be enabled in the Mixpanel project itself.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Mixpanel autocapture
	 *
	 * @since 1.64.1
	 *
	 * @return void
	 */
	public static function option_html_mixpanel_autocapture() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][mixpanel][autocapture]">
			<input type="checkbox"
					id="pmw_plugin_mixpanel_autocapture"
					name="wgact_plugin_options[pixels][mixpanel][autocapture]"
					value="1"
				<?php checked(Options::is_mixpanel_autocapture_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Mixpanel autocapture', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_mixpanel_autocapture_enabled(), Options::is_mixpanel_active(), true);
		self::get_documentation_html_by_key('mixpanel_autocapture');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Lets Mixpanel capture clicks, form submissions and input changes on its own, on top of the e-commerce events the Pixel Manager sends.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Mixpanel user identification
	 *
	 * @since 1.64.1
	 *
	 * @return void
	 */
	public static function option_html_mixpanel_user_identification() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][mixpanel][user_identification]">
			<input type="checkbox"
					id="pmw_plugin_mixpanel_user_identification"
					name="wgact_plugin_options[pixels][mixpanel][user_identification]"
					value="1"
				<?php checked(Options::is_mixpanel_user_identification_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Mixpanel user identification', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_mixpanel_user_identification_enabled(), Options::is_mixpanel_active(), true);
		self::get_documentation_html_by_key('mixpanel_user_identification');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Identifies logged-in customers by their WordPress user ID and writes their email address, name and phone number to their Mixpanel user profile.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Klaviyo public API key
	 *
	 * @since 1.68.0
	 *
	 * @return void
	 */
	public static function option_html_klaviyo_public_api_key() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_klaviyo_public_api_key"
				name="wgact_plugin_options[pixels][klaviyo][public_api_key]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_klaviyo_public_api_key()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_klaviyo_active());
		self::get_documentation_html_by_key('klaviyo_public_api_key');
		self::output_advanced_section_cog_html('klaviyo');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Enter your Klaviyo public API key, also called the Site ID. It is 6 letters and digits, found in Klaviyo under Settings > Account > API keys.', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '<br>';
		esc_html_e('Enabling it lets the Pixel Manager take over the onsite tracking of the official Klaviyo plugin, with consent handling and reliable checkout events. The Klaviyo plugin keeps handling orders, catalog and profile sync, forms, list consent and abandoned cart links.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Klaviyo plugin coexistence
	 *
	 * @since 1.68.0
	 *
	 * @return void
	 */
	public static function option_html_klaviyo_coexistence() {

		$modes = [
			'auto'     => esc_html__('Automatic (recommended)', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'takeover' => esc_html__('Take over the Klaviyo plugin tracking', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'gap_fill' => esc_html__('Only send events the Klaviyo plugin does not send', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'off'      => esc_html__('Send nothing to Klaviyo', 'woocommerce-google-adwords-conversion-tracking-tag'),
		];

		$resolved = [
			'takeover'   => esc_html__('taking over the Klaviyo plugin tracking', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'gap_fill'   => esc_html__('only sending the events the Klaviyo plugin does not send', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'standalone' => esc_html__('running standalone, the Klaviyo plugin is not active', 'woocommerce-google-adwords-conversion-tracking-tag'),
			'off'        => esc_html__('sending nothing to Klaviyo', 'woocommerce-google-adwords-conversion-tracking-tag'),
		];
		?>
		<select id="pmw_plugin_klaviyo_coexistence"
				name="wgact_plugin_options[pixels][klaviyo][coexistence]"
			<?php echo esc_html(self::disable_if_demo()); ?>
		>
			<?php foreach ($modes as $mode_key => $mode_label) : ?>
				<option value="<?php echo esc_attr($mode_key); ?>"
					<?php selected($mode_key, Options::get_klaviyo_coexistence_setting()); ?>
				>
					<?php echo esc_html($mode_label); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php self::get_documentation_html_by_key('klaviyo_coexistence'); ?>
		<?php self::html_pro_feature(); ?>
		<?php
		echo '<br><br>';
		esc_html_e('The official Klaviyo plugin stays in charge of orders, catalog and profile sync on Klaviyo\'s side, so it remains installed on every shop that uses Klaviyo flows. Automatic takes over its browser tracking when the plugin version has been tested, only fills the gaps when it has not, and runs standalone when the plugin is absent.', 'woocommerce-google-adwords-conversion-tracking-tag');

		if (Options::is_klaviyo_active()) {
			$mode = Options::get_klaviyo_coexistence_mode();
			echo '<br><br>';
			echo esc_html__('Currently:', 'woocommerce-google-adwords-conversion-tracking-tag') . ' <strong>' . esc_html(isset($resolved[ $mode ]) ? $resolved[ $mode ] : $mode) . '</strong>';

			if (Environment::is_klaviyo_plugin_active()) {
				echo ' (' . esc_html__('Klaviyo plugin version', 'woocommerce-google-adwords-conversion-tracking-tag') . ' ' . esc_html(Environment::get_klaviyo_plugin_version()) . ')';
			}
		}
	}

	/**
	 * Klaviyo customer identification
	 *
	 * @since 1.68.0
	 *
	 * @return void
	 */
	public static function option_html_klaviyo_identify_customers() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][klaviyo][identify_customers]">
			<input type="checkbox"
					id="pmw_plugin_klaviyo_identify_customers"
					name="wgact_plugin_options[pixels][klaviyo][identify_customers]"
					value="1"
				<?php checked(Options::is_klaviyo_customer_identification_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Identify known customers to Klaviyo', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_klaviyo_customer_identification_enabled(), Options::is_klaviyo_active(), true);
		self::get_documentation_html_by_key('klaviyo_identify_customers');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Sends the email address, phone number and name of logged-in customers and of shoppers who have entered them at checkout to Klaviyo, so browsing, cart and checkout events attach to their Klaviyo profile. Abandoned cart and browse abandonment flows trigger on exactly these events.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Klaviyo Events API private key
	 *
	 * @since 1.68.0
	 *
	 * @return void
	 */
	public static function option_html_klaviyo_events_api_token() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_klaviyo_events_api_token"
				name="wgact_plugin_options[pixels][klaviyo][events_api][token]"
				size="60"
				type="text"
				value="<?php echo esc_html(Options::get_klaviyo_events_api_token()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_klaviyo_events_api_active(), Options::is_klaviyo_active(), true);
		self::get_documentation_html_by_key('klaviyo_events_api_token');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('A Klaviyo private API key with the Events write scope, created in Klaviyo under Settings > Account > API keys. It starts with pk_.', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '<br>';
		esc_html_e('The Pixel Manager reports purchases and refunds through it server-side, but only while the official Klaviyo plugin is not active. With the plugin active, Klaviyo produces Placed Order from its own order sync, and sending it as well would double every order in Klaviyo.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	public static function option_html_groundtruth_gtid() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_groundtruth_gtid"
				name="wgact_plugin_options[pixels][groundtruth][gtid]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_groundtruth_gtid()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_groundtruth_active());
		self::get_documentation_html_by_key('groundtruth_gtid');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Enter the unique identifier (GTID) provided by your GroundTruth representative. One GTID covers all campaigns of your Ads Manager account.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Classic settings field for the Rumble Ads tag ID.
	 *
	 * @since 1.72.1
	 *
	 * @return void
	 */
	public static function option_html_rumble_tag_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_rumble_tag_id"
				name="wgact_plugin_options[pixels][rumble][tag_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_rumble_tag_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_rumble_active());
		self::get_documentation_html_by_key('rumble_tag_id');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Enter the ID of your Rumble Ads global site tag, in the form AV-1234. One tag ID covers your whole advertiser account.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Classic settings field for the Rumble Ads purchase conversion action ID.
	 *
	 * @since 1.72.1
	 *
	 * @return void
	 */
	public static function option_html_rumble_conversion_id_purchase() {
		self::option_html_rumble_conversion_id('purchase');
		echo '<br><br>';
		esc_html_e('The ID of the Rumble Ads conversion action that counts purchases. Set its value to Dynamic so the order value is recorded.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Classic settings field for the Rumble Ads add to cart conversion action ID.
	 *
	 * @since 1.72.1
	 *
	 * @return void
	 */
	public static function option_html_rumble_conversion_id_add_to_cart() {
		self::option_html_rumble_conversion_id('add_to_cart');
		echo '<br><br>';
		esc_html_e('The ID of the Rumble Ads conversion action that counts add to cart events.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Input for one Rumble Ads conversion action ID.
	 *
	 * @since 1.72.1
	 *
	 * @param string $event purchase or add_to_cart.
	 * @return void
	 */
	private static function option_html_rumble_conversion_id( $event ) {
		?>
		<input class="pmw mono"
				id="pmw_plugin_rumble_conversion_id_<?php echo esc_attr($event); ?>"
				name="wgact_plugin_options[pixels][rumble][conversion_ids][<?php echo esc_attr($event); ?>]"
				size="20"
				type="text"
				value="<?php echo esc_html(Options::get_rumble_conversion_id($event)); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::get_rumble_conversion_id($event), Options::is_rumble_active());
		self::get_documentation_html_by_key('rumble_conversion_ids');
		self::html_pro_feature();
	}

	public static function option_html_criteo_account_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_criteo_account_id"
				name="wgact_plugin_options[pixels][criteo][account_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_criteo_account_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_criteo_active());
		self::get_documentation_html_by_key('criteo_account_id');
		self::output_advanced_section_cog_html('criteo');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Enter your Criteo account ID (also called partner ID). You can find it in Criteo Commerce Growth under Event Tracking, or request it from your Criteo representative. It looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>12345</code>';
	}

	public static function option_html_criteo_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][criteo][advanced_matching]">
			<input type="checkbox"
					id="pmw_plugin_criteo_advanced_matching"
					name="wgact_plugin_options[pixels][criteo][advanced_matching]"
					value="1"
				<?php checked(Options::is_criteo_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Criteo advanced matching', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_criteo_advanced_matching_enabled(), Options::is_criteo_active(), true);
		self::get_documentation_html_by_key('criteo_advanced_matching');
		self::html_pro_feature();
	}

	public static function option_html_nextdoor_pixel_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_nextdoor_pixel_id"
				name="wgact_plugin_options[pixels][nextdoor][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_nextdoor_pixel_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_nextdoor_active());
		self::get_documentation_html_by_key('nextdoor_pixel_id');
		self::output_advanced_section_cog_html('nextdoor');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Enter your Nextdoor pixel ID. You can find it in Nextdoor Ads Manager under Assets > Pixels. It looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>550e8400-e29b-41d4-a716-446655440000</code>';
	}

	public static function option_html_nextdoor_capi_token() {
		?>
		<textarea class="pmw mono"
					id="pmw_plugin_nextdoor_capi_token"
					name="wgact_plugin_options[pixels][nextdoor][capi][token]"
					cols="60"
					rows="6"
					onfocus="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>><?php echo esc_html(Options::get_nextdoor_capi_token()); ?></textarea>
		<?php self::display_status_icon(Options::get_nextdoor_capi_token(), Options::is_nextdoor_active()); ?>
		<?php self::get_documentation_html_by_key('nextdoor_capi_token'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_nextdoor_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the Nextdoor pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_nextdoor_capi_test_event_code() {
		?>
		<input class="pmw mono"
				type="text"
				id="pmw_plugin_nextdoor_capi_test_event_code"
				name="wgact_plugin_options[pixels][nextdoor][capi][test_event_code]"
				value="<?php echo esc_html(Options::get_nextdoor_capi_test_event_code()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php self::display_status_icon(Options::get_nextdoor_capi_test_event_code(), Options::is_nextdoor_active()); ?>
		<?php self::get_documentation_html_by_key('nextdoor_capi_test_event_code'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_nextdoor_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the Nextdoor pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_nextdoor_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][nextdoor][advanced_matching]">
			<input type="checkbox"
					id="pmw_plugin_nextdoor_advanced_matching"
					name="wgact_plugin_options[pixels][nextdoor][advanced_matching]"
					value="1"
				<?php checked(Options::is_nextdoor_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Nextdoor advanced matching', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_nextdoor_advanced_matching_enabled(), Options::is_nextdoor_active(), true);
		self::get_documentation_html_by_key('nextdoor_advanced_matching');
		self::html_pro_feature();
	}

	public static function option_html_applovin_event_key() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_applovin_event_key"
				name="wgact_plugin_options[pixels][applovin][event_key]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_applovin_event_key()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_applovin_active());
		self::get_documentation_html_by_key('applovin_event_key');
		self::output_advanced_section_cog_html('applovin');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Enter your AppLovin event key. You can find it in the AppLovin dashboard under Account > General > Keys.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	public static function option_html_applovin_capi_token() {
		?>
		<textarea class="pmw mono"
					id="pmw_plugin_applovin_capi_token"
					name="wgact_plugin_options[pixels][applovin][capi][token]"
					cols="60"
					rows="6"
					onfocus="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>><?php echo esc_html(Options::get_applovin_capi_token()); ?></textarea>
		<?php self::display_status_icon(Options::get_applovin_capi_token(), Options::is_applovin_active()); ?>
		<?php self::get_documentation_html_by_key('applovin_capi_token'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_applovin_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the AppLovin pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_applovin_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][applovin][advanced_matching]">
			<input type="checkbox"
					id="pmw_plugin_applovin_advanced_matching"
					name="wgact_plugin_options[pixels][applovin][advanced_matching]"
					value="1"
				<?php checked(Options::is_applovin_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable AppLovin advanced matching', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_applovin_advanced_matching_enabled(), Options::is_applovin_active(), true);
		self::get_documentation_html_by_key('applovin_advanced_matching');
		self::html_pro_feature();
	}

	public static function option_html_spotify_pixel_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_spotify_pixel_id"
				name="wgact_plugin_options[pixels][spotify][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_spotify_pixel_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_spotify_active());
		self::get_documentation_html_by_key('spotify_pixel_id');
		self::output_advanced_section_cog_html('spotify');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Enter your Spotify Ad Analytics pixel ID. You can find it under Manage > Your Pixels. It looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>3f0a1c7d9e4b42a8b1c6d5e8f2a9b0c3</code>';
	}

	public static function option_html_spotify_capi_connection_id() {
		?>
		<input class="pmw mono"
				type="text"
				id="pmw_plugin_spotify_capi_connection_id"
				name="wgact_plugin_options[pixels][spotify][capi][connection_id]"
				size="40"
				value="<?php echo esc_html(Options::get_spotify_capi_connection_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php self::display_status_icon(Options::get_spotify_capi_connection_id(), Options::is_spotify_active()); ?>
		<?php self::get_documentation_html_by_key('spotify_capi_connection_id'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_spotify_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the Spotify Ads pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_spotify_capi_token() {
		?>
		<textarea class="pmw mono"
					id="pmw_plugin_spotify_capi_token"
					name="wgact_plugin_options[pixels][spotify][capi][token]"
					cols="60"
					rows="6"
					onfocus="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>><?php echo esc_html(Options::get_spotify_capi_token()); ?></textarea>
		<?php self::display_status_icon(Options::get_spotify_capi_token(), Options::is_spotify_active()); ?>
		<?php self::get_documentation_html_by_key('spotify_capi_token'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_spotify_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the Spotify Ads pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_spotify_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][spotify][advanced_matching]">
			<input type="checkbox"
					id="pmw_plugin_spotify_advanced_matching"
					name="wgact_plugin_options[pixels][spotify][advanced_matching]"
					value="1"
				<?php checked(Options::is_spotify_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Spotify Ads advanced matching', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_spotify_advanced_matching_enabled(), Options::is_spotify_active(), true);
		self::get_documentation_html_by_key('spotify_advanced_matching');
		self::html_pro_feature();
	}

	public static function option_html_triple_whale_enabled() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][triple_whale][enabled]">
			<input type="checkbox"
					id="pmw_plugin_triple_whale_enabled"
					name="wgact_plugin_options[pixels][triple_whale][enabled]"
					value="1"
				<?php checked(Options::is_triple_whale_active()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable the Triple Whale pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_triple_whale_active());
		self::get_documentation_html_by_key('triple_whale');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Adds Triple Whale\'s browser pixel and checkout events to the shop. Triple Whale identifies the shop by its domain, which must match the Shop URL in Triple Whale under Settings > Store; no pixel ID is required.', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '<br><br>';
		esc_html_e('Before you enable this: a WooCommerce store is connected to Triple Whale over the WooCommerce REST API during Triple Whale onboarding. That connection delivers the orders, revenue and refunds, and Triple Whale attributes the orders it imports itself. The Pixel Manager does not replace it; it supplies the browser pixel and the checkout funnel events. Beta, built from Triple Whale\'s public documentation and not certified by Triple Whale.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * The Hyros product hash, the ph value of the Hyros Universal Script.
	 *
	 * @since 1.63.1
	 *
	 * @return void
	 */
	public static function option_html_hyros_product_hash() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_hyros_product_hash"
				name="wgact_plugin_options[pixels][hyros][product_hash]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_hyros_product_hash()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_hyros_active());
		self::get_documentation_html_by_key('hyros_product_hash');
		self::output_advanced_section_cog_html('hyros');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('The product hash is the ph value of the Hyros Universal Script, which you find in Hyros under Tracking > Universal Script. You can paste the whole script snippet here, the product hash is extracted automatically.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * The Hyros application tag, attributed to visitors when they land on a tracked page.
	 *
	 * @since 1.63.1
	 *
	 * @return void
	 */
	public static function option_html_hyros_application_tag() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_hyros_application_tag"
				name="wgact_plugin_options[pixels][hyros][application_tag]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_hyros_application_tag()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::get_documentation_html_by_key('hyros_application_tag');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('Optional. The tag Hyros attributes to a visitor on landing, configured in Hyros under Tracking > Universal Script in the Application Tag field. Leave empty to use the Hyros default:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>!clicked</code>';
	}

	public static function option_html_facebook_pixel_id() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_facebook_pixel_id"
				name="wgact_plugin_options[facebook][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_facebook_pixel_id()); ?>"
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_facebook_active());
		self::get_documentation_html_by_key('facebook_pixel_id');
		self::output_advanced_section_cog_html('facebook');
		echo '<br><br>';
		esc_html_e('The Meta (Facebook) pixel ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>765432112345678</code>';
	}

	public static function option_html_adroll_advertiser_id() {
		?>
		<input class="pmw mono"
				id="pmw_adroll_advertiser_id"
				name="wgact_plugin_options[pixels][adroll][advertiser_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_adroll_advertiser_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_adroll_advertiser_id_set(), Options::is_adroll_pixel_id_set());
		self::get_documentation_html_by_key('adroll_advertiser_id');
		self::wistia_video_icon('xwr0q08bk0');
		self::html_pro_feature();
		echo '<br><br>';

		if (
			Options::is_adroll_advertiser_id_set()
			&& !Options::is_adroll_pixel_id_set()
		) {
			?>
			<p style="margin: 10px 0 10px 0">
				<span class="dashicons dashicons-info" style="padding-right: 10px"></span>
				<?php
				esc_html_e(
					'Requires an active Adroll pixel ID.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				);
				?>
			</p>
			<?php
		}

		esc_html_e('The Adroll advertiser ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>ABCD1EF2GHIJKLMNOPQRS3</code>';
	}

	public static function option_html_adroll_pixel_id() {
		?>
		<input class="pmw mono"
				id="pmw_adroll_pixel_id"
				name="wgact_plugin_options[pixels][adroll][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_adroll_pixel_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_adroll_pixel_id_set(), Options::is_adroll_advertiser_id_set());
		self::get_documentation_html_by_key('adroll_pixel_id');
		self::wistia_video_icon('xwr0q08bk0');
		self::html_pro_feature();
		echo '<br><br>';

		if (
			Options::is_adroll_pixel_id_set()
			&& !Options::is_adroll_advertiser_id_set()
		) {
			?>
			<p style="margin: 10px 0 10px 0">
				<span class="dashicons dashicons-info" style="padding-right: 10px"></span>
				<?php
				esc_html_e(
					'Requires an active Adroll advertiser ID.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				);
				?>
			</p>
			<?php
		}

		esc_html_e('The Adroll pixel ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>ABCD1EFGHIJKLMN2O3PQR</code>';
	}

	public static function option_html_bing_capi_token() {
		?>
		<input class="pmw mono"
				type="text"
				id="pmw_plugin_bing_capi_token"
				name="wgact_plugin_options[bing][capi][token]"
				size="40"
				onfocus="this.select();"
				value="<?php echo esc_html(Options::get_bing_capi_token()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php self::display_status_icon(Options::get_bing_capi_token(), Options::is_bing_active()); ?>
		<?php self::get_documentation_html_by_key('bing_capi_token'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_bing_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the Microsoft Advertising UET tag', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_bing_enhanced_conversions() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[bing][enhanced_conversions]">
			<input type="checkbox"
					id="plugin_microsoft_enhanced_conversions"
					name="wgact_plugin_options[bing][enhanced_conversions]"
					value="1"
				<?php checked(Options::is_bing_enhanced_conversions_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Microsoft Enhanced Conversions', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_bing_enhanced_conversions_enabled(), Options::is_bing_active(), true);
		self::get_documentation_html_by_key('bing_uet_tag_id');
		self::html_pro_feature();
	}

	public static function option_html_linkedin_partner_id() {
		?>
		<input class="pmw mono"
				id="pmw_linkedin_partner_id"
				name="wgact_plugin_options[pixels][linkedin][partner_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_linkedin_partner_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_linkedin_active());
		self::get_documentation_html_by_key('linkedin_partner_id');
		self::output_advanced_section_cog_html('linkedin');
		self::wistia_video_icon('vvyiav46ft');
		self::wistia_video_icon('zrrp8aq4g0');
		self::html_pro_feature();
		echo '<br><br>';

		esc_html_e('The LinkedIn partner ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>1234567</code>';
	}

	public static function setting_linkedin_view_content() {

		$text_length = max(strlen(Options::get_linkedin_conversion_id('view_content')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_linkedin_view_content"
				name="wgact_plugin_options[pixels][linkedin][conversion_ids][view_content]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_linkedin_conversion_id('view_content')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::get_linkedin_conversion_id('view_content'), Options::is_linkedin_active());
		self::get_documentation_html_by_key('linkedin_event_ids');
		self::wistia_video_icon('zrrp8aq4g0');
		self::html_pro_feature();
		echo '<br>';
		esc_html_e('Map to LinkedIn conversion type:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>key_page_view</code>';
	}

	public static function setting_linkedin_add_to_cart() {

		$text_length = max(strlen(Options::get_linkedin_conversion_id('add_to_cart')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_linkedin_add_to_cart"
				name="wgact_plugin_options[pixels][linkedin][conversion_ids][add_to_cart]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_linkedin_conversion_id('add_to_cart')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::get_linkedin_conversion_id('add_to_cart'), Options::is_linkedin_active());
		self::get_documentation_html_by_key('linkedin_event_ids');
		self::wistia_video_icon('zrrp8aq4g0');
		self::html_pro_feature();
		echo '<br>';
		esc_html_e('Map to LinkedIn conversion type:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>add_to_cart</code>';
	}

	public static function setting_linkedin_purchase() {

		$text_length = max(strlen(Options::get_linkedin_conversion_id('purchase')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_linkedin_purchase"
				name="wgact_plugin_options[pixels][linkedin][conversion_ids][purchase]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_linkedin_conversion_id('purchase')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::get_linkedin_conversion_id('purchase'), Options::is_linkedin_active());
		self::get_documentation_html_by_key('linkedin_event_ids');
		self::wistia_video_icon('zrrp8aq4g0');
		self::html_pro_feature();
		echo '<br>';
		esc_html_e('Map to LinkedIn conversion type:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>purchase</code>';
	}

	public static function option_html_bing_uet_tag_id() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_bing_uet_tag_id"
				name="wgact_plugin_options[bing][uet_tag_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_bing_uet_tag_id()); ?>"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::is_bing_active());
		self::get_documentation_html_by_key('bing_uet_tag_id');
		self::output_advanced_section_cog_html('microsoft');
		echo '<br><br>';
		esc_html_e('The Microsoft Advertising UET tag ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>12345678</code>';
	}

	public static function option_html_twitter_pixel_id() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_twitter_pixel_id"
				name="wgact_plugin_options[twitter][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_twitter_pixel_id()); ?>"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::is_twitter_active());
		self::get_documentation_html_by_key('twitter_pixel_id');
		self::output_advanced_section_cog_html('twitter');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('The X (Twitter) pixel ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>a1cde</code>';
	}

	public static function setting_twitter_add_to_cart() {

		$text_length = max(strlen(Options::get_twitter_event_id('add_to_cart')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_twitter_add_to_cart"
				name="wgact_plugin_options[twitter][event_ids][add_to_cart]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_twitter_event_id('add_to_cart')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_twitter_event_id('add_to_cart'), Options::is_twitter_active());
		self::get_documentation_html_by_key('twitter_event_ids');
		self::html_pro_feature();
	}

	public static function setting_twitter_add_to_wishlist() {

		$text_length = max(strlen(Options::get_twitter_event_id('add_to_wishlist')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_twitter_add_to_wishlist"
				name="wgact_plugin_options[twitter][event_ids][add_to_wishlist]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_twitter_event_id('add_to_wishlist')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_twitter_event_id('add_to_wishlist'), Options::is_twitter_active());
		self::get_documentation_html_by_key('twitter_event_ids');
		self::html_pro_feature();
	}

	public static function setting_twitter_view_content() {

		$text_length = max(strlen(Options::get_twitter_event_id('view_content')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_twitter_view_content"
				name="wgact_plugin_options[twitter][event_ids][view_content]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_twitter_event_id('view_content')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_twitter_event_id('view_content'), Options::is_twitter_active());
		self::get_documentation_html_by_key('twitter_event_ids');
		self::html_pro_feature();
	}

	public static function setting_twitter_search() {

		$text_length = max(strlen(Options::get_twitter_event_id('search')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_twitter_search"
				name="wgact_plugin_options[twitter][event_ids][search]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_twitter_event_id('search')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_twitter_event_id('search'), Options::is_twitter_active());
		self::get_documentation_html_by_key('twitter_event_ids');
		self::html_pro_feature();
	}

	public static function setting_twitter_initiate_checkout() {

		$text_length = max(strlen(Options::get_twitter_event_id('initiate_checkout')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_twitter_initiate_checkout"
				name="wgact_plugin_options[twitter][event_ids][initiate_checkout]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_twitter_event_id('initiate_checkout')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_twitter_event_id('initiate_checkout'), Options::is_twitter_active());
		self::get_documentation_html_by_key('twitter_event_ids');
		self::html_pro_feature();
	}

	public static function setting_twitter_add_payment_info() {

		$text_length = max(strlen(Options::get_twitter_event_id('add_payment_info')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_twitter_add_payment_info"
				name="wgact_plugin_options[twitter][event_ids][add_payment_info]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_twitter_event_id('add_payment_info')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_twitter_event_id('add_payment_info'), Options::is_twitter_active());
		self::get_documentation_html_by_key('twitter_event_ids');
		self::html_pro_feature();
	}

	public static function setting_twitter_purchase() {

		$text_length = max(strlen(Options::get_twitter_event_id('purchase')), 14);

		?>
		<input class="pmw mono"
				id="pmw_setting_twitter_purchase"
				name="wgact_plugin_options[twitter][event_ids][purchase]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_twitter_event_id('purchase')); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_twitter_event_id('purchase'), Options::is_twitter_active());
		self::get_documentation_html_by_key('twitter_event_ids');
		self::html_pro_feature();
	}

	public static function option_html_outbrain_advertiser_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_outbrain_advertiser_id"
				name="wgact_plugin_options[pixels][outbrain][advertiser_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_outbrain_advertiser_id()); ?>"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::is_outbrain_active());
		self::get_documentation_html_by_key('outbrain_advertiser_id');
		self::wistia_video_icon('56u98s3rh6');
		self::wistia_video_icon('sj8aig7b6q');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('The Outbrain advertiser ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');

		echo '&nbsp;<code>001a2b3cd4e5fgh6i789j01234k567890l</code>';
	}

	public static function option_html_pinterest_pixel_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_pinterest_pixel_id"
				name="wgact_plugin_options[pinterest][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_pinterest_pixel_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_pinterest_active());
		self::get_documentation_html_by_key('pinterest_pixel_id');
		self::output_advanced_section_cog_html('pinterest');
		echo '<br><br>';
		esc_html_e('The Pinterest pixel ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>1234567890123</code>';
	}

	public static function option_html_pinterest_enhanced_match() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pinterest][enhanced_match]">
			<input type="checkbox"
					id="wpm_plugin_pinterest_enhanced_match"
					name="wgact_plugin_options[pinterest][enhanced_match]"
					value="1"
				<?php checked(Options::is_pinterest_enhanced_match_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>

			<?php
			esc_html_e('Enable Pinterest enhanced match', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_pinterest_enhanced_match_enabled(), Options::is_pinterest_active(), true);
		self::get_documentation_html_by_key('pinterest_enhanced_match');
		self::html_pro_feature();
		?>
		<?php
		//      self::get_documentation_html_by_key('pinterest_enhanced_match');
	}

	public static function option_html_snapchat_pixel_id() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_snapchat_pixel_id"
				name="wgact_plugin_options[snapchat][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_snapchat_pixel_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_snapchat_active());
		self::get_documentation_html_by_key('snapchat_pixel_id');
		self::output_advanced_section_cog_html('snapchat');
		echo '<br><br>';
		esc_html_e('The Snapchat pixel ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');

		echo '&nbsp;<code>1a2345b6-cd78-9012-e345-fg6h7890ij12</code>';
	}

	public static function option_html_taboola_account_id() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_taboola_account_id"
				name="wgact_plugin_options[pixels][taboola][account_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_taboola_account_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_taboola_active());
		self::get_documentation_html_by_key('taboola_account_id');
		self::wistia_video_icon('fw6rwcw1sf');
		self::wistia_video_icon('q3hhvz9mgt');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('The Taboola account ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');

		echo '&nbsp;<code>1234567</code>';
	}

	public static function option_html_tiktok_pixel_id() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_tiktok_pixel_id"
				name="wgact_plugin_options[tiktok][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_tiktok_pixel_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_tiktok_active());
		self::get_documentation_html_by_key('tiktok_pixel_id');
		self::output_advanced_section_cog_html('tiktok');
		echo '<br><br>';
		esc_html_e('The TikTok pixel ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>ABCD1E2FGH3IJK45LMN6</code>';
	}

	public static function option_html_hotjar_site_id() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_hotjar_site_id"
				name="wgact_plugin_options[hotjar][site_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_hotjar_site_id()); ?>"
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_hotjar_enabled());
		self::get_documentation_html_by_key('hotjar_site_id');
		self::wistia_video_icon('z9tjk5eia7');
		echo '<br><br>';
		esc_html_e('The Hotjar site ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>1234567</code>';
	}

	public static function option_html_crazyegg_account_number() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_crazyegg_account_number"
				name="wgact_plugin_options[crazyegg][account_number]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_crazyegg_account_number()); ?>"
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::is_crazyegg_enabled());
		self::get_documentation_html_by_key('crazyegg_account_number');
		echo '<br><br>';
		esc_html_e('The CrazyEgg account number looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>01319772</code>';
		echo '<br>';
		esc_html_e('You can also paste the entire tracking script and the account number will be extracted automatically.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * 2023.09.11: Reddit renamed the advertiser ID to pixel ID.
	 * Don't change the database key, because that would break the plugin for existing users.
	 */
	public static function option_html_reddit_pixel_id() {
		?>
		<input class="pmw mono"
				id="plugin_reddit_pixel_id"
				name="wgact_plugin_options[pixels][reddit][advertiser_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_reddit_advertiser_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php self::display_status_icon(Options::get_reddit_advertiser_id(), true, true); ?>
		<?php self::get_documentation_html_by_key('reddit_advertiser_id'); ?>
		<?php self::output_advanced_section_cog_html('reddit'); ?>
		<?php self::wistia_video_icon('3cr5pwksrf'); ?>
		<p style="margin-top:16px">
			<?php esc_html_e('The Reddit pixel ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php echo '&nbsp;<code>t2_gvnawxpb</code>'; ?>
		</p>
		<?php
	}

	public static function option_html_snapchat_capi_token() {
		?>
		<textarea class="pmw mono"
					id="plugin_snapchat_capi_token"
					name="wgact_plugin_options[snapchat][capi][token]"
					cols="60"
					rows="6"
					onfocus="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>><?php echo esc_html(Options::get_snapchat_capi_token()); ?></textarea>
		<?php self::display_status_icon(Options::get_snapchat_capi_token(), Options::is_snapchat_active()); ?>
		<?php self::get_documentation_html_by_key('snapchat_capi_token'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_snapchat_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the Snapchat pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_snapchat_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[snapchat][advanced_matching]">
			<input type="checkbox"
					id="plugin_snapchat_advanced_matching"
					name="wgact_plugin_options[snapchat][advanced_matching]"
					value="1"
				<?php checked(Options::is_snapchat_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Snapchat Advanced Matching', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_snapchat_advanced_matching_enabled(), Options::is_snapchat_active(), true);
		self::get_documentation_html_by_key('snapchat_advanced_matching');
		self::html_pro_feature();
	}

	public static function option_html_reddit_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][reddit][advanced_matching]">
			<input type="checkbox"
					id="plugin_reddit_advanced_matching"
					name="wgact_plugin_options[pixels][reddit][advanced_matching]"
					value="1"
				<?php checked(Options::is_reddit_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Reddit advanced matching', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_reddit_advanced_matching_enabled(), Options::is_reddit_active(), true);
		self::get_documentation_html_by_key('reddit_advanced_matching');
		self::html_pro_feature();
	}

	public static function option_html_reddit_capi_token() {
		?>
		<textarea class="pmw mono"
					id="plugin_reddit_capi_token"
					name="wgact_plugin_options[pixels][reddit][capi][token]"
					cols="60"
					rows="6"
					onfocus="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>><?php echo esc_html(Options::get_reddit_capi_token()); ?></textarea>
		<?php self::display_status_icon(Options::get_reddit_capi_token(), Options::is_reddit_active()); ?>
		<?php self::get_documentation_html_by_key('reddit_capi_token'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_reddit_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the Reddit pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_reddit_capi_test_event_code() {
		?>
		<input class="pmw mono"
				type="text"
				id="plugin_reddit_capi_test_event_code"
				name="wgact_plugin_options[pixels][reddit][capi][test_event_code]"
				value="<?php echo esc_html(Options::get_reddit_capi_test_event_code()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php self::display_status_icon(Options::get_reddit_capi_test_event_code(), Options::is_reddit_active()); ?>
		<?php self::get_documentation_html_by_key('reddit_capi_test_event_code'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_reddit_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the Reddit pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	public static function option_html_openai_pixel_id() {
		?>
		<input class="pmw mono"
				id="plugin_openai_pixel_id"
				name="wgact_plugin_options[pixels][openai][pixel_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_openai_pixel_id()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php self::display_status_icon(Options::get_openai_pixel_id(), true, true); ?>
		<?php self::get_documentation_html_by_key('openai_pixel_id'); ?>
		<?php self::output_advanced_section_cog_html('openai'); ?>
		<p style="margin-top:16px">
			<?php esc_html_e('Create your OpenAI pixel ID in the conversions tab of OpenAI Ads Manager.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</p>
		<?php
	}

	public static function option_html_openai_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pixels][openai][advanced_matching]">
			<input type="checkbox"
					id="plugin_openai_advanced_matching"
					name="wgact_plugin_options[pixels][openai][advanced_matching]"
					value="1"
				<?php checked(Options::is_openai_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable OpenAI advanced matching', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_openai_advanced_matching_enabled(), Options::is_openai_active(), true);
		self::get_documentation_html_by_key('openai_advanced_matching');
		self::html_pro_feature();
	}

	public static function option_html_openai_capi_token() {
		?>
		<textarea class="pmw mono"
					id="plugin_openai_capi_token"
					name="wgact_plugin_options[pixels][openai][capi][token]"
					cols="60"
					rows="6"
					onfocus="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>><?php echo esc_html(Options::get_openai_capi_token()); ?></textarea>
		<?php self::display_status_icon(Options::get_openai_capi_token(), Options::is_openai_active()); ?>
		<?php self::get_documentation_html_by_key('openai_capi_token'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (!Options::is_openai_active()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('You need to activate the OpenAI pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Toggle for sending the order profit as a separate field next to the marketing value.
	 *
	 * Implied, and shown as locked, when the marketing value logic is the profit margin.
	 *
	 * @since 1.70.1
	 */
	public static function html_send_profit_separately() {

		$implied = in_array((string) Options::get_marketing_value_logic(), [ '2', 'order_profit_margin' ], true);
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0"
					name="wgact_plugin_options[shop][send_profit_separately]">
			<input type="checkbox"
					id="pmw_plugin_send_profit_separately"
					name="wgact_plugin_options[shop][send_profit_separately]"
					value="1"
				<?php checked(Options::is_profit_sent_separately()); ?>
				<?php disabled($implied); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php
			esc_html_e('Send the order profit next to the marketing value where the platform has a field for it (Meta net_revenue), for orders where every product has a cost of goods.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::get_documentation_html_by_key('profit_field');
		self::html_pro_feature();

		if ($implied) {
			echo '<p><span class="dashicons dashicons-info"></span>';
			esc_html_e('On, because the marketing value logic is Profit Margin, so the profit already leaves your server.', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '</p>';
		}
	}

	public static function html_marketing_value_logic() {

		?>
		<label>
			<input type="radio"
					id="pmw_plugin_marketing_value_logic_0"
					name="<?php echo esc_html(Options::get_marketing_value_logic_input_field_name()); ?>"
					value="0"
				<?php echo( checked(0, Options::get_marketing_value_logic(), false) ); ?>
			>
			<?php esc_html_e('Order Subtotal: Doesn\'t include tax, shipping, and if available, fees like PayPal or Stripe fees (default)', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php self::get_documentation_html_by_key('marketing_value_subtotal'); ?>
		</label>
		<br>
		<label>
			<input type="radio"
					id="pmw_plugin_marketing_value_logic_1"
					name="<?php echo esc_html(Options::get_marketing_value_logic_input_field_name()); ?>"
					value="1"
				<?php echo( checked(1, Options::get_marketing_value_logic(), false) ); ?>
			>
			<?php esc_html_e('Order Total: Includes tax and shipping', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php self::get_documentation_html_by_key('marketing_value_total'); ?>

		</label>
		<?php if (wpm_fs()->can_use_premium_code__premium_only() || '2' === Options::get_marketing_value_logic() || Options::is_pro_version_demo_active()) : ?>
			<br>
			<label>
				<input type="radio"
						id="pmw_plugin_marketing_value_logic_2"
						name="<?php echo esc_html(Options::get_marketing_value_logic_input_field_name()); ?>"
						value="2"
					<?php echo( checked(2, Options::get_marketing_value_logic(), false) ); ?>
					<?php if (!Environment::is_a_cog_plugin_active() || !wpm_fs()->can_use_premium_code__premium_only()) : ?>
						disabled
					<?php endif; ?>
				>
				<?php esc_html_e('Profit Margin: Only reports the profit margin. Excludes tax, shipping, and where possible, gateway fees.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				<?php self::get_documentation_html_by_key('marketing_value_profit_margin'); ?>
				<?php self::html_pro_feature(); ?>
			</label>
		<?php endif; ?>
		<div style="margin-top: 10px">
			<div>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('This is the total value reported back to the marketing pixels (such as Google Ads, Meta (Facebook), etc.). It excludes statistics pixels.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				<?php if ( wpm_fs()->can_use_premium_code__premium_only() && !Environment::is_a_cog_plugin_active() ) : ?>
			</div>
			<div style="margin-top: 10px">
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('To use the Profit Margin setting, enable the Cost of Goods Sold feature in WooCommerce → Settings → Advanced → Features, or install a Cost of Goods plugin:', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				<a href="https://woocommerce.com/products/woocommerce-cost-of-goods/" target="_blank">WooCommerce Cost
					of Goods (SkyVerge)</a>
				<?php esc_html_e('or', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				<a href="https://wordpress.org/plugins/cost-of-goods-for-woocommerce/" target="_blank">Cost of Goods for
					WooCommerce (WPFactory)</a>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	private static function get_documentation_html_by_key( $key = 'default' ) {
		return self::get_documentation_html(Documentation::get_link($key));
	}

	private static function get_documentation_html( $path ) {
		//      $html  = '<a class="pmw-documentation-icon" href="' . $path . '" target="_blank">';
		//      $html .= '<span style="vertical-align: top; margin-top: 0px" class="dashicons dashicons-info-outline tooltip"><span class="tooltiptext">';
		//      $html .= esc_html__('open the documentation', 'woocommerce-google-adwords-conversion-tracking-tag');
		//      $html .= '</span></span></a>';
		//
		//      return $html;
		?>
		<a class="pmw-documentation-icon" href="<?php echo esc_url($path); ?>" target="_blank">
			<span style="vertical-align: top; margin-top: 0" class="dashicons dashicons-info-outline pmw-tooltip">
				<span class="tooltiptext">
					<?php esc_html_e('open the documentation', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</span>
			</span>
		</a>

		<?php
	}

	private static function output_advanced_section_cog_html( $subsection ) {
		?>
		<a href="#" class="advanced-section-link pmw-tooltip" data-as-section="advanced"
			data-as-subsection="<?php echo esc_html($subsection); ?>">
			<svg class="advanced-settings-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
				<path d="M14 21h-4l-.551-2.48a6.991 6.991 0 0 1-1.819-1.05l-2.424.763-2-3.464 1.872-1.718a7.055 7.055 0 0 1 0-2.1L3.206 9.232l2-3.464 2.424.763A6.992 6.992 0 0 1 9.45 5.48L10 3h4l.551 2.48a6.992 6.992 0 0 1 1.819 1.05l2.424-.763 2 3.464-1.872 1.718a7.05 7.05 0 0 1 0 2.1l1.872 1.718-2 3.464-2.424-.763a6.99 6.99 0 0 1-1.819 1.052L14 21z"/>
				<circle cx="12" cy="12" r="3"/>
			</svg>
			<span class="tooltiptext">
				<?php esc_html_e('advanced settings', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</span>
		</a>
		<?php
	}

	private static function get_documentation_html_e( $path ) {

		$html  = '<a class="pmw-documentation-icon" href="' . $path . '" target="_blank">';
		$html .= '<span style="vertical-align: top; margin-top: 0px" class="dashicons dashicons-info-outline pmw-tooltip"><span class="tooltiptext">';
		$html .= esc_html__('open the documentation', 'woocommerce-google-adwords-conversion-tracking-tag');
		$html .= '</span></span></a>';

		return $html;
	}

	public static function setting_html_google_consent_mode_active() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[google][consent_mode][active]">
			<input type="checkbox"
					id="wpm_setting_google_consent_mode_active"
					name="wgact_plugin_options[google][consent_mode][active]"
					value="1"
				<?php checked(Options::is_google_consent_mode_active()); ?>
			/>
			<?php esc_html_e('Enable Google Consent Mode v2 with standard settings', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>

		</label>
		<?php self::display_status_icon(Options::is_google_consent_mode_active(), true, true); ?>
		<?php
		self::get_documentation_html_by_key('google_consent_mode');
	}

	public static function setting_html_microsoft_ads_consent_mode_active() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[bing][consent_mode][is_active]">
			<input type="checkbox"
					id="setting_microsoft_ads_consent_mode_active"
					name="wgact_plugin_options[bing][consent_mode][is_active]"
					value="1"
				<?php checked(Options::is_bing_consent_mode_active()); ?>
			/>
			<?php esc_html_e('Enable Microsoft Ads Consent Mode with standard settings', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>

		</label>
		<?php self::display_status_icon(Options::is_bing_consent_mode_active(), true, true); ?>
		<?php
		self::get_documentation_html_by_key('microsoft_ads_consent_mode');
	}

	public static function setting_html_explicit_consent_mode() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden"
					value="0"
					name="<?php echo esc_html(Options::get_cookie_consent_explicit_consent_input_field_name()); ?>"
			>
			<input type="checkbox"
					id="setting_explicit_consent_mode"
					name="<?php echo esc_html(Options::get_cookie_consent_explicit_consent_input_field_name()); ?>"
					value="1"
				<?php checked(Options::is_consent_management_explicit_consent_active()); ?>
				<?php disabled(Options::consent_management_is_explicit_consent_active_override()); ?>
			/>
			<?php
			esc_html_e('Enable Explicit Consent Mode', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php self::display_status_icon(Options::is_consent_management_explicit_consent_active(), true, true); ?>
		<?php if (Options::consent_management_is_explicit_consent_active_override()) : ?>
			<?php self::html_status_icon_override(); ?>
		<?php endif; ?>
		<?php self::get_documentation_html_by_key('explicit_consent_mode'); ?>
		<p style="margin-top:10px">
		<div>

			<?php esc_html_e('While the Explicit Consent Mode is active no pixels will be fired until the visitor gives consent.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<br>
		</div>
		<div style="margin-top: 5px">
			<span class="dashicons dashicons-info"></span>
			<?php esc_html_e("Only activate the Explicit Consent Mode if you are also using a Consent Management Platform (a cookie banner) that is compatible with the Pixel Manager. Here's a list of compatible plugins:", 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<a
					href="https://sweetcode.com/docs/pmw/consent-management/platforms"
					target="_blank"><?php esc_html_e('Compatible Consent Management Platforms (CMPs)', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></a>
			<br>
			<?php esc_html_e('You can also use our Consent API to make your custom cookie banner compatible with the Pixel Manager:', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<a
					href="https://sweetcode.com/docs/pmw/consent-management/api"
					target="_blank"><?php esc_html_e('Consent API', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></a>
		</div>
		</p>
		<?php
	}

	public static function setting_html_explicit_consent_regions() {
		// https://semantic-ui.com/modules/dropdown.html#multiple-selection
		// https://developer.woocommerce.com/2017/08/08/selectwoo-an-accessible-replacement-for-select2/
		// https://github.com/woocommerce/selectWoo
		?>
		<select id="setting_explicit_consent_regions"
				name="wgact_plugin_options[google][consent_mode][regions][]"
				multiple="multiple"
				style="width:350px;"
				data-placeholder="<?php esc_html_e('Choose countries', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>&hellip;"
				aria-label="Country"
				class="wc-enhanced-select"
		>
			<?php foreach (Consent_Mode_Regions::get_consent_mode_regions() as $region_code => $region_name) : ?>
				<option value="<?php echo esc_html($region_code); ?>"
					<?php
					// Rarely Options::get_options_obj()->google->consent_mode->regions is null
					// The reason is a mystery. It happens in very rare cases and can't be reproduced.
					// So we have to check if it is an array before using in_array()
					if (is_array(Options::get_restricted_consent_regions_raw())) {
						echo esc_html(in_array($region_code, Options::get_restricted_consent_regions_raw()) ? 'selected' : '');
					}
					?>
				>
					<?php echo esc_html($region_name); ?>
				</option>
			<?php endforeach; ?>

		</select>
		<script>
			jQuery("#setting_explicit_consent_regions").select2({
				// theme: "classic"
			});
		</script>
		<?php self::get_documentation_html_by_key('restricted_consent_regions'); ?>
		<?php self::display_status_icon(Options::is_consent_management_explicit_consent_active(), true, true); ?>
		<p>
			<?php
			esc_html_e('Regions in which tracking with cookies will only be activated after the visitor gives consent.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
			<br>
		<div style="margin-top: 5px">
			<?php if (!Options::is_consent_management_explicit_consent_active()) : ?>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('Requires the Explicit Consent Mode to be active.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				<br>
			<?php endif; ?>
			<span class="dashicons dashicons-info"></span>
			<?php
			esc_html_e('If no region is set, then the restrictions are enabled worldwide. If you specify one or more regions, then the restrictions only apply for the specified regions. For countries outside of those regions, tracking will work without restrictions until the visitor removes consent.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</div>
		</p>
		<?php
	}

	public static function setting_html_google_tcf_support() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[google][tcf_support]">
			<input type="checkbox"
					id="setting_google_tcf_support"
					name="wgact_plugin_options[google][tcf_support]"
					value="1"
				<?php checked(Options::is_google_tcf_support_active()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php esc_html_e('Enable Google TCF support', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php
		self::display_status_icon(Options::is_google_tcf_support_active(), true, true);
		?>
		<?php
		self::get_documentation_html_by_key('google_tcf_support');
		self::html_pro_feature();
	}

	public static function info_html_google_analytics_eec() {
		esc_html_e('Google Analytics Enhanced E-Commerce is ', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(Options::is_google_analytics_active());
		//      self::get_documentation_html_by_key('eec');
	}

	public static function setting_html_google_analytics_4_api_secret() {
		?>
		<input class="pmw mono"
				id="wpm_setting_google_analytics_4_api_secret"
				name="wgact_plugin_options[google][analytics][ga4][api_secret]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_ga4_mp_api_secret()); ?>"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::is_ga4_mp_active());
		self::get_documentation_html_by_key('google_analytics_4_api_secret');
		self::html_pro_feature();
		echo '<br><br>';
		if (!Options::is_ga4_enabled()) {
			echo '<p></p><span class="dashicons dashicons-info" style="margin-right: 10px"></span>';
			esc_html_e('Google Analytics 4 activation required', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '</p>';
		}
		esc_html_e('If enabled, purchase and refund events will be sent to Google through the measurement protocol for increased accuracy.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	public static function setting_html_ga4_property_id() {
		?>
		<input class="pmw mono"
				id="pmw_setting_ga4_property_id"
				name="wgact_plugin_options[google][analytics][ga4][data_api][property_id]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_ga4_data_api_property_id()); ?>"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_ga4_data_api_property_id(), count(Options::get_ga4_data_api_credentials()) > 0);
		self::get_documentation_html_by_key('ga4_data_api_property_id');
		self::wistia_video_icon('5np5zu7j07');
		self::html_pro_feature();

		if (Options::get_ga4_data_api_property_id() && !isset(Options::get_ga4_data_api_credentials()['client_email'])) {
			echo '<p><span class="dashicons dashicons-info"></span>';
			esc_html_e('GA4 Data API Credentials need to be set.', 'woocommerce-google-adwords-conversion-tracking-tag');
		}
	}

	public static function setting_html_g4_data_api_credentials() {

		$client_email
			= isset(Options::get_ga4_data_api_credentials()['client_email'])
			? Options::get_ga4_data_api_credentials()['client_email']
			: '';

		$text_length = max(strlen($client_email), 80);
		?>
		<div style="margin-top: 5px">

			<input class="pmw mono readonly"
					id="pmw_setting_ga4_data_api_client_email"
					name="pmw_setting_ga4_data_api_client_email"
					size="<?php echo esc_html($text_length); ?>"
					type="text"
					style="width:<?php echo esc_html($text_length); ?>ch"
					value="<?php echo esc_html($client_email); ?>"
					readonly
					onclick="this.select();"
			/>

			<?php self::render_copy_button('pmw_setting_ga4_data_api_client_email'); ?>


			<?php self::display_status_icon(isset(Options::get_ga4_data_api_credentials()['client_email']), Options::get_ga4_data_api_property_id()); ?>
			<?php self::get_documentation_html_by_key('ga4_data_api_credentials'); ?>
			<?php self::wistia_video_icon('sm0n75srdu'); ?>
			<?php self::html_pro_feature(); ?>

			<div style="margin-top: 5px">

				<!-- Import Settings -->
				<div class="button">
					<div>
						<label for="ga4-data-api-credentials-upload-button">
							<?php esc_html_e('Import credentials', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							<input type="file" id="ga4-data-api-credentials-upload-button" style="display: none;"/>
						</label>
					</div>
				</div>
				<!-- Import Settings -->

				<!-- Delete Settings -->
				<div class="button">
					<div>
						<label for="ga4-data-api-credentials-delete-button">
							<?php esc_html_e('Delete credentials', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							<input id="ga4-data-api-credentials-delete-button" style="display: none;"/>
						</label>
					</div>
				</div>
				<!-- Delete Settings -->
			</div>

			<div>
				<pre id="ga4-api-credentials-upload-status-success" style="display: none; white-space: pre-line;">
					<span style="color: green; font-weight: bold">
						<?php esc_html_e('Settings imported successfully!', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
					<span>
						<?php esc_html_e('Reloading...(in 5 seconds)!', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
				</pre>

				<pre id="ga4-api-credentials-upload-status-error" style="display: none; white-space: pre-line;">
					<span style="color: red; font-weight: bold">
						<?php esc_html_e('There was an error importing that file! Please try again.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
					<span id="ga4-api-credentials-upload-status-error-message"
							style="color: red; font-weight: bold"></span>
				</pre>
			</div>
		</div>
		<?php

		if (isset(Options::get_ga4_data_api_credentials()['client_email']) && !Options::get_ga4_data_api_property_id()) {
			echo '<p><span class="dashicons dashicons-info"></span>';
			esc_html_e('The GA4 Property ID needs to be set.', 'woocommerce-google-adwords-conversion-tracking-tag');
		}
	}

	public static function setting_html_g4_page_load_time_tracking() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[google][analytics][ga4][page_load_time_tracking]">
			<input type="checkbox"
					id="pmw_setting_ga4_page_load_time_tracking"
					name="wgact_plugin_options[google][analytics][ga4][page_load_time_tracking]"
					value="1"
				<?php checked(Options::is_ga4_page_load_time_tracking_active()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php
			esc_html_e('GA4 page load time tracking.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_ga4_page_load_time_tracking_active(), true, true);
		self::get_documentation_html_by_key('ga4_page_load_time_tracking');
		self::html_pro_feature();
	}

	public static function setting_html_google_user_id() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[google][user_id]">
			<input type="checkbox"
					id="wpm_setting_google_user_id"
					name="wgact_plugin_options[google][user_id]"
					value="1"
				<?php checked(Options::is_google_user_id_active()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php
			esc_html_e('Enable Google user ID', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_google_user_id_active(), Options::is_google_active(), true);
		self::get_documentation_html_by_key('google_user_id');
		self::html_pro_feature();
		?>
		<?php
		if (!Options::is_google_active()) {
			echo '<p></p><span class="dashicons dashicons-info"></span>';
			esc_html_e('You need to activate GA4 and/or Google Ads', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '</p><br>';
		}
	}

	public static function setting_html_google_enhanced_conversions() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[google][ads][enhanced_conversions]">
			<input type="checkbox"
					id="pmw_setting_google_enhanced_conversions"
					name="wgact_plugin_options[google][ads][enhanced_conversions]"
					value="1"
				<?php checked(Options::is_google_enhanced_conversions_active()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php
			esc_html_e('Enable Enhanced Conversions for Google Ads and GA4', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_google_enhanced_conversions_active(), Options::is_google_active(), false);
		self::get_documentation_html_by_key('google_enhanced_conversions');
		self::wistia_video_icon('73e5op37xg');
		self::html_pro_feature();
		if (!Options::is_google_active()) {
			echo '<p></p><span class="dashicons dashicons-info"></span>';
			esc_html_e('You need to activate Google Ads and or GA4', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '</p><br>';
		}
	}

	public static function setting_html_google_ads_phone_conversion_number() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_google_ads_phone_conversion_number"
				name="wgact_plugin_options[google][ads][phone_conversion_number]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_google_ads_phone_conversion_number()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::get_google_ads_phone_conversion_number(), Options::get_google_ads_phone_conversion_label() && Options::get_google_ads_phone_conversion_number());
		self::get_documentation_html_by_key('google_ads_phone_conversion_number');
		self::html_pro_feature();
		echo '<br><br>';
		esc_html_e('The Google Ads phone conversion number must be in the same format as on the website.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	public static function setting_html_google_ads_phone_conversion_label() {
		?>
		<input class="pmw mono"
				id="wpm_plugin_google_ads_phone_conversion_label"
				name="wgact_plugin_options[google][ads][phone_conversion_label]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_google_ads_phone_conversion_label()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php
		self::display_status_icon(Options::get_google_ads_phone_conversion_label(), Options::get_google_ads_phone_conversion_label() && Options::get_google_ads_phone_conversion_number());
		self::get_documentation_html_by_key('google_ads_phone_conversion_label');
		self::html_pro_feature();
		echo '<br><br>';
		//        esc_html_e('The Google Ads phone conversion label must be in the same format as on the website.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	public static function setting_html_google_ads_conversion_adjustments_conversion_name() {
		?>
		<input class="pmw mono"
				id="pmw_plugin_google_ads_conversion_adjustments_conversion_name"
				name="wgact_plugin_options[google][ads][conversion_adjustments][conversion_name]"
				size="40"
				type="text"
				value="<?php echo esc_html(Options::get_google_ads_conversion_adjustments_conversion_name()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
				onclick="this.select();"
		/>
		<?php self::display_status_icon(Options::is_google_ads_conversion_adjustments_active(), Options::is_google_ads_active()); ?>
		<?php self::get_documentation_html_by_key('google_ads_conversion_adjustments'); ?>
		<?php self::html_pro_feature(); ?>
		<div style="margin-top: 20px">
			<span class="dashicons dashicons-info" style="margin-right: 10px"></span>
			<?php esc_html_e('The conversion name must match the conversion name in Google Ads exactly.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</div>
		<?php

		if (!Options::is_google_ads_conversion_active()) {
			?>
			<span class="dashicons dashicons-info" style="padding-right: 10px"></span>
			<?php
			esc_html_e('Requires an active Google Ads Conversion ID and Conversion Label.', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '<br>';
		}
	}

	public static function setting_html_google_ads_conversion_adjustments_feed() {

		$feed_url    = get_site_url() . Pixel_Manager::get_instance()->get_google_ads_conversion_adjustments_endpoint();
		$text_length = strlen($feed_url);
		?>
		<div style="margin-top: 5px">

			<input class="pmw mono readonly"
					id="pmw_plugin_google_ads_conversion_adjustments_feed"
					name="pmw_plugin_google_ads_conversion_adjustments_feed"
					size="<?php echo esc_html($text_length); ?>"
					type="text"
					style="width:<?php echo esc_html($text_length); ?>ch"
					value="<?php echo esc_url($feed_url); ?>"
					readonly
					onclick="this.select();"
			/>
			<script>
				const pmwCopyToClipboardCA = () => {

					// const feedUrlElement = document.getElementById("pmw_plugin_google_ads_conversion_adjustments_feed")
					// feedUrlElement.select()
					// feedUrlElement.setSelectionRange(0, 99999)
					navigator.clipboard.writeText(document.getElementById("pmw_plugin_google_ads_conversion_adjustments_feed").value);

					const pmwCaFeedTooltip     = document.getElementById("myPmwCaTooltip");
					pmwCaFeedTooltip.innerHTML = "<?php esc_html_e('Copied feed URL to clipboard', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>";
				};

				const resetCaCopyButton = () => {
					const pmwCaFeedTooltip     = document.getElementById("myPmwCaTooltip");
					pmwCaFeedTooltip.innerHTML = "<?php esc_html_e('Copy to clipboard', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>";
				};
			</script>
			<div class="pmwCaTooltip">
				<a href="javascript:void(0)" class="pmw-copy-icon pmwCaTooltip" onclick="pmwCopyToClipboardCA()"
					onmouseout="resetCaCopyButton()"></a>
				<span class="pmwCaTooltiptext"
						id="myPmwCaTooltip"><?php esc_html_e('Copy to clipboard', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></span>
			</div>
			<?php self::display_status_icon(Options::is_google_ads_conversion_adjustments_active(), Options::is_google_ads_active()); ?>
			<?php self::get_documentation_html_by_key('google_ads_conversion_adjustments'); ?>
			<?php self::html_pro_feature(); ?>
			<div style="margin-top: 20px">
				<?php if (!Options::is_google_ads_conversion_adjustments_active()) : ?>
					<span class="dashicons dashicons-info" style="padding-right: 10px"></span>
					<?php esc_html_e('The Conversion Name must be set.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	public static function info_html_automatic_email_link_tracking() {
		esc_html_e('Automatic email link click tracking is ', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(Options::is_ga4_enabled());
		self::html_pro_feature();
	}

	public static function info_html_automatic_phone_link_click_tracking() {
		esc_html_e('Automatic phone link click tracking is ', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(Options::is_ga4_enabled());
		self::html_pro_feature();
	}

	public static function setting_html_cookiebot_support() {
		esc_html_e('Cookiebot detected. Automatic support is:', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true, true, true);
	}

	public static function setting_html_complianz_support() {
		esc_html_e('Complianz GDPR detected. Automatic support is:', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true, true, true);
	}

	public static function setting_html_cookie_notice_support() {
		esc_html_e('Cookie Notice (by hu-manity.co) detected. Automatic support is:', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true, true, true);
	}

	public static function setting_html_cookie_script_support() {
		esc_html_e('Cookie Script (by cookie-script.com) detected. Automatic support is:', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true, true, true);
	}

	public static function setting_html_moove_gdpr_support() {
		esc_html_e('GDPR Cookie Compliance (by Moove Agency) detected. Automatic support is:', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true, true, true);
	}

	public static function setting_html_cookieyes_support() {
		esc_html_e('CookieYes detected. Automatic support is', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true, true, true);
	}

	public static function setting_html_termly_support() {
		esc_html_e('Termly CMP detected. Automatic support is:', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true, true, true);
	}

	/**
	 * Outputs the FAZ Cookie Manager support status row in the settings UI.
	 *
	 * @since 1.58.12
	 */
	public static function setting_html_faz_cookie_manager_support() {
		esc_html_e('FAZ Cookie Manager detected. Automatic support is:', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true, true, true);
	}


	public static function setting_html_facebook_capi_token() {
		?>
		<textarea class="pmw mono"
					id="wpm_setting_facebook_capi_token"
					name="wgact_plugin_options[facebook][capi][token]"
					cols="60"
					rows="5"
					onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>><?php echo esc_html(Options::get_facebook_capi_token()); ?></textarea>
		<?php
		self::display_status_icon(Options::get_facebook_capi_token(), Options::is_facebook_active());
		self::get_documentation_html_by_key('facebook_capi_token');
		self::html_pro_feature();
		if (!Options::is_facebook_active()) {
			echo '<p></p><span class="dashicons dashicons-info"></span>';
			esc_html_e('You need to activate the Meta (Facebook) pixel', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '</p><br>';
		}
		//        echo self::get_documentation_html('/wgact/?utm_source=woocommerce-plugin&utm_medium=documentation-link&utm_campaign=pixel-manager-for-woocommerce-docs&utm_content=google-ads-conversion-id#/pixels/google-ads?id=configure-the-plugin');
		echo '<br><br>';
		//        esc_html_e('The conversion ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		//        echo '&nbsp;<code>123456789</code>';
	}

	public static function setting_html_facebook_capi_test_event_code() {

		$text_length = max(strlen(Options::get_facebook_capi_test_event_code()), 9);
		?>
		<input class="pmw mono"
				id="pmw_setting_facebook_capi_test_event_code"
				name="wgact_plugin_options[facebook][capi][test_event_code]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				style="width:<?php echo esc_html($text_length); ?>ch"
				value="<?php echo esc_html(Options::get_facebook_capi_test_event_code()); ?>"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php self::display_status_icon(Options::get_facebook_capi_test_event_code(), Options::get_facebook_capi_token() && Options::get_facebook_capi_test_event_code(), true); ?>
		<?php
		//      self::get_documentation_html_by_key('facebook_capi_test_event_code');
		?>
		<?php self::html_pro_feature(); ?>
		<div style="margin-top: 20px">
			<span class="dashicons dashicons-info" style="margin-right: 10px"></span>
			<?php esc_html_e("The test event code automatically rotates frequently within Facebook. If you don't see the server events flowing in, first make sure that you've set the latest test event code.", 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</div>
		<?php
	}

	public static function setting_facebook_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0"
					name="wgact_plugin_options[facebook][capi][user_transparency][send_additional_client_identifiers]">
			<input type="checkbox"
					id="wpm_setting_facebook_capi_user_transparency_send_additional_client_identifiers"
					name="wgact_plugin_options[facebook][capi][user_transparency][send_additional_client_identifiers]"
					value="1"
				<?php checked(Options::is_facebook_capi_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php
			esc_html_e('Send events with additional visitor identifiers, such as email and phone number, if available.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_facebook_capi_advanced_matching_enabled(), Options::is_facebook_active(), true);
		self::get_documentation_html_by_key('facebook_advanced_matching');
		self::html_pro_feature();
		if (Options::is_facebook_capi_advanced_matching_enabled() && !Options::is_facebook_active()) {
			echo '<p></p><span class="dashicons dashicons-info"></span>';
			esc_html_e('You need to activate the Meta (Facebook) pixel', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '</p><br>';
		}
	}

	/**
	 * Toggle for sending the Facebook app-scoped login ID with CAPI events.
	 *
	 * The ID is read from a third party social login plugin, so the setting is
	 * only actionable when one of those is installed.
	 *
	 * @since 1.64.1
	 */
	public static function setting_facebook_send_fb_login_id() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0"
					name="wgact_plugin_options[facebook][capi][send_fb_login_id]">
			<input type="checkbox"
					id="wpm_setting_facebook_capi_send_fb_login_id"
					name="wgact_plugin_options[facebook][capi][send_fb_login_id]"
					value="1"
				<?php checked(Options::is_facebook_send_fb_login_id_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php
			esc_html_e('Send the Facebook Login ID (fb_login_id) for customers who signed in with Facebook.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_facebook_send_fb_login_id_enabled(), Options::is_facebook_active(), true);
		self::get_documentation_html_by_key('facebook_login_id');
		self::html_pro_feature();

		if (Options::is_facebook_send_fb_login_id_enabled()) {

			$social_login_plugin = Social_Login::get_active_plugin_name();

			if ($social_login_plugin) {
				echo '<p><span class="dashicons dashicons-info"></span>';
				printf(
					/* translators: %s: name of the detected social login plugin */
					esc_html__('%s detected. Meta can only match the ID if that plugin\'s Facebook app is in the same Business Manager as this pixel.', 'woocommerce-google-adwords-conversion-tracking-tag'),
					esc_html($social_login_plugin)
				);
				echo '</p>';
			} else {
				echo '<p><span class="dashicons dashicons-info"></span>';
				printf(
					/* translators: %s: comma separated list of supported social login plugins */
					esc_html__('No supported social login plugin detected. One of these can supply the Facebook Login ID: %s.', 'woocommerce-google-adwords-conversion-tracking-tag'),
					esc_html(implode(', ', Social_Login::get_supported_plugin_names()))
				);
				echo '</p>';
			}
		}
	}

	public static function setting_html_facebook_domain_verification_id() {
		?>
		<input class="pmw mono"
				type="text"
				id="wpm_setting_facebook_domain_verification_id"
				name="wgact_plugin_options[facebook][domain_verification_id]"
				size="40"
				value="<?php echo esc_html(Options::get_facebook_domain_verification_id()); ?>"
				onclick="this.select();"
		/>
		<?php self::display_status_icon(Options::get_facebook_domain_verification_id()); ?>
		<?php self::get_documentation_html_by_key('facebook_domain_verification_id'); ?>
		<?php self::html_pro_feature(); ?>
		<br><br>
		<?php
		esc_html_e('The Meta domain verification ID. It looks like this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		echo '&nbsp;<code>uk6zwiftxsaywayn14x0aouhz4fhd</code>';
	}

	public static function setting_html_pinterest_ad_account_id() {

		$text_length = max(strlen(Options::get_pinterest_ad_account_id()), 40);

		?>
		<input class="pmw mono"
				id="pmw_setting_pinterest_ad_account_id"
				name="wgact_plugin_options[pinterest][ad_account_id]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_pinterest_ad_account_id()); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_pinterest_ad_account_id(), Options::is_pinterest_active());
		self::get_documentation_html_by_key('pinterest_ad_account_id');
		self::html_pro_feature();
	}

	public static function setting_html_pinterest_apic_token() {

		?>
		<textarea class="pmw mono"
					id="pmw_setting_pinterest_apic_token"
					name="wgact_plugin_options[pinterest][apic][token]"
					cols="50"
					rows="2"
					onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>><?php echo esc_html(Options::get_pinterest_apic_token()); ?></textarea>

		<?php
		self::display_status_icon(Options::get_pinterest_apic_token(), Options::is_pinterest_active());
		self::get_documentation_html_by_key('pinterest_apic_token');
		self::html_pro_feature();
		if (!Options::is_pinterest_active()) {
			?>
			<br><span class="dashicons dashicons-info"></span>
			<?php esc_html_e('You need to activate the Pinterest pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php
		}
	}

	public static function setting_pinterest_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[pinterest][advanced_matching]">
			<input type="checkbox"
					id="pmw_setting_pinterest_user_transparency_advanced_matching"
					name="wgact_plugin_options[pinterest][advanced_matching]"
					value="1"
				<?php checked(Options::is_pinterest_advanced_matching_active()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php
			esc_html_e('Send events with additional visitor identifiers, such as email and phone number, if available.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_pinterest_advanced_matching_active(), Options::is_pinterest_active() && Options::get_pinterest_apic_token(), true);
		self::get_documentation_html_by_key('pinterest_advanced_matching');
		self::html_pro_feature();
		if (Options::is_pinterest_advanced_matching_active() && !Options::is_pinterest_active()) {
			echo '<p></p><span class="dashicons dashicons-info"></span>';
			esc_html_e('You need to activate the Pinterest pixel', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '</p><br>';
		}
	}

	public static function setting_html_tiktok_eapi_token() {

		$text_length = max(strlen(Options::get_tiktok_eapi_token()), 40);

		?>
		<input class="pmw mono"
				id="pmw_setting_tiktok_eapi_token"
				name="wgact_plugin_options[tiktok][eapi][token]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				value="<?php echo esc_html(Options::get_tiktok_eapi_token()); ?>"
				style="width:<?php echo esc_html($text_length); ?>ch"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php
		self::display_status_icon(Options::get_tiktok_eapi_token(), Options::is_tiktok_active());
		self::get_documentation_html_by_key('tiktok_eapi_token');
		self::html_pro_feature();
		if (!Options::is_tiktok_active()) {
			?>
			<br><span class="dashicons dashicons-info"></span>
			<?php esc_html_e('You need to activate the TikTok pixel', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php
		}
		//        echo self::get_documentation_html('/wgact/?utm_source=woocommerce-plugin&utm_medium=documentation-link&utm_campaign=pixel-manager-for-woocommerce-docs&utm_content=google-ads-conversion-id#/pixels/google-ads?id=configure-the-plugin');
		//        esc_html_e('The conversion ID looks similar to this:', 'woocommerce-google-adwords-conversion-tracking-tag');
		//        echo '&nbsp;<code>123456789</code>';
	}

	public static function setting_html_tiktok_eapi_test_event_code() {

		$text_length = max(strlen(Options::get_tiktok_eapi_test_event_code()), 9);

		?>
		<input class="pmw mono"
				id="pmw_setting_tiktok_eapi_test_event_code"
				name="wgact_plugin_options[tiktok][eapi][test_event_code]"
				size="<?php echo esc_html($text_length); ?>"
				type="text"
				style="width:<?php echo esc_html($text_length); ?>ch"
				value="<?php echo esc_html(Options::get_tiktok_eapi_test_event_code()); ?>"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php self::display_status_icon(Options::get_tiktok_eapi_test_event_code(), Options::get_tiktok_eapi_token() && Options::get_tiktok_eapi_test_event_code(), true); ?>

		<?php
		//      self::get_documentation_html_by_key('facebook_capi_test_event_code');
		?>
		<?php self::html_pro_feature(); ?>
		<div style="margin-top: 20px">
			<span class="dashicons dashicons-info" style="margin-right: 10px"></span>
			<?php esc_html_e("The test event code automatically rotates frequently within TikTok. If you don't see the server events flowing in, first make sure that you've set the latest test event code.", 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</div>
		<?php
	}

	public static function setting_tiktok_advanced_matching() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[tiktok][advanced_matching]">
			<input type="checkbox"
					id="pmw_setting_tiktok_advanced_matching"
					name="wgact_plugin_options[tiktok][advanced_matching]"
					value="1"
				<?php checked(Options::is_tiktok_advanced_matching_enabled()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>
			<?php
			esc_html_e('Send events with additional visitor identifiers, such as email and phone number, if available.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_tiktok_advanced_matching_enabled(), Options::is_tiktok_active() && Options::get_tiktok_eapi_token(), true);
		self::get_documentation_html_by_key('tiktok_advanced_matching');
		self::html_pro_feature();
		if (Options::is_tiktok_advanced_matching_enabled() && !Options::is_tiktok_active()) {
			echo '<p></p><span class="dashicons dashicons-info"></span>';
			esc_html_e('You need to activate the TikTok pixel', 'woocommerce-google-adwords-conversion-tracking-tag');
			echo '</p><br>';
		}
	}

	public static function setting_html_order_duplication_prevention() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[shop][order_deduplication]">
			<input type="checkbox"
					id="wpm_setting_order_duplication_prevention"
					name="wgact_plugin_options[shop][order_deduplication]"
					value="1"
				<?php checked(Options::is_order_duplication_prevention_option_active()); ?>
			/>
			<?php
			self::get_order_duplication_prevention_text();
			?>
		</label>
		<?php self::display_status_icon(Options::is_order_duplication_prevention_option_active()); ?>
		<?php self::get_documentation_html_by_key('duplication_prevention'); ?>

		<br>
		<p>
			<span class="dashicons dashicons-info"></span>
			<?php
			esc_html_e('Only disable order duplication prevention for testing.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</p>
		<p>
			<span class="dashicons dashicons-info"></span>
			<?php
			esc_html_e('Automatically reactivates 6 hours after disabling duplication prevention.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</p>
		<?php
	}

	public static function setting_html_disable_tracking_for_user_roles() {
		// https://semantic-ui.com/modules/dropdown.html#multiple-selection
		// https://developer.woocommerce.com/2017/08/08/selectwoo-an-accessible-replacement-for-select2/
		// https://github.com/woocommerce/selectWoo
		?>
		<select id="wpm_setting_disable_tracking_for_user_roles"
				multiple="multiple"
				name="wgact_plugin_options[shop][disable_tracking_for][]"
				style="width:350px; padding-left: 10px"
				data-placeholder="Choose roles&hellip;" aria-label="Roles"
				class="wc-enhanced-select"
			<?php echo esc_html(self::disable_if_demo()); ?>
		>
			<?php foreach (get_editable_roles() as $role => $details) : ?>
				<option value="<?php echo esc_html($role); ?>" <?php echo esc_html(in_array($role, Options::get_excluded_roles(), true) ? 'selected' : ''); ?>><?php echo esc_html($details['name']); ?></option>
			<?php endforeach; ?>

		</select>
		<script>
			jQuery("#wpm_setting_disable_tracking_for_user_roles").select2({
				// theme: "classic"
			});
		</script>
		<?php
		//      self::get_documentation_html_by_key('google_consent_regions');
		self::html_pro_feature();
	}

	public static function info_html_acr() {
		esc_html_e('Automatic Conversion Recovery (ACR) is ', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(wpm_fs()->can_use_premium_code__premium_only());
		self::html_pro_feature();
		self::get_documentation_html_by_key('acr');
	}

	public static function info_html_order_list_info() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[shop][order_list_info]">
			<input type="checkbox"
					id="pmw_setting_order_list_info"
					name="wgact_plugin_options[shop][order_list_info]"
					value="1"
				<?php checked(Options::is_shop_order_list_info_enabled()); ?>
			/>

			<?php
			esc_html_e('Display Pixel Manager related information on the order list page', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_shop_order_list_info_enabled());
		?>
		<?php
		self::get_documentation_html_by_key('order_list_info');
	}

	public static function info_html_scroll_tracker_thresholds() {
		?>
		<input class="pmw mono"
				id="pmw_setting_scroll_tracker_thresholds"
				name="wgact_plugin_options[general][scroll_tracker_thresholds]"
				size="40"
				type="text"
				value="<?php echo esc_html(implode(',', Options::get_scroll_tracking_thresholds())); ?>"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php self::display_status_icon(!empty(Options::get_scroll_tracking_thresholds()), true, true); ?>
		<?php self::get_documentation_html_by_key('scroll_tracker_threshold'); ?>
		<?php self::html_pro_feature(); ?>
		<div style="margin-top: 10px">
			<?php esc_html_e('The Scroll Tracker thresholds. A comma separated list of scroll tracking thresholds in percent where the scroll tracker triggers its events.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</div>
		<?php
	}

	public static function html_subscription_value_multiplier() {

		$field_width = max(strlen(Options::get_subscription_multiplier()), 3);

		?>
		<input class="pmw mono"
				id="pmw_setting_subscription_value_multiplier"
				name="wgact_plugin_options[shop][subscription_value_multiplier]"
				size="<?php echo esc_html($field_width); ?>"
				type="text"
				style="width:<?php echo esc_html($field_width); ?>ch"
				value="<?php echo esc_html(Options::get_subscription_multiplier()); ?>"
				onclick="this.select();"
			<?php echo esc_html(self::disable_if_demo()); ?>
		/>
		<?php self::get_documentation_html_by_key('subscription_value_multiplier'); ?>
		<?php self::html_pro_feature(); ?>
		<div style="margin-top: 10px">
			<?php esc_html_e('The multiplier multiplies the conversion value output for initial subscriptions to match the CLV of a subscription more closely.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</div>
		<?php
	}

	public static function html_ltv_calculation_on_orders() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[shop][ltv][order_calculation][is_active]">
			<input type="checkbox"
					id="pmw_setting_ltv_on_orders"
					name="wgact_plugin_options[shop][ltv][order_calculation][is_active]"
					value="1"
				<?php checked(Options::is_order_level_ltv_calculation_active()); ?>
			/>

			<?php
			esc_html_e('Enable the lifetime value calculation on new orders.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php
		self::display_status_icon(Options::is_order_level_ltv_calculation_active());
		?>
		<?php
		self::get_documentation_html_by_key('ltv_order_calculation');
	}

	// html_ltv_automatic_recalculation() was removed in 1.63.1 together with its
	// settings field. The option key shop.ltv.automatic_recalculation.is_active
	// is intentionally left in the options tree so saved values and options
	// backups stay valid, but nothing reads it any more.

	public static function order_extra_details_output() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[shop][order_extra_details][is_active]">
			<input type="checkbox"
					id="pmw_setting_order_extra_details_output"
					name="wgact_plugin_options[shop][order_extra_details][is_active]"
					value="1"
				<?php checked(Options::is_order_extra_details_active()); ?>
			/>

			<?php
			esc_html_e('Enable the output of extra order details on order pages.', 'woocommerce-google-adwords-conversion-tracking-tag');
			?>
		</label>
		<?php self::display_status_icon(Options::is_order_extra_details_active(), true, true); ?>
		<?php
		self::get_documentation_html_by_key('order_extra_details');
	}

	public static function ltv_manual_recalculation() {

		// Add a button with the text "Schedule LTV recalculation" and a confirmation dialog
		// Add a hidden div, that will be shown after the button is clicked, with a confirmation message
		?>
		<div style="display: flex;">
			<button id="wgact_ltv_recalculation" class="button button-primary" style="margin-top: 0">
				<span id="ltv-schedule-recalculation-button-text"
					class="ltv-button-text"
					data-action="schedule_ltv_recalculation"
				>
				<?php esc_html_e('Schedule LTV recalculation', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</span>
				<span id="ltv-instant-recalculation-button-text"
						class="ltv-button-text"
						style="display: none;"
						data-action="run_ltv_recalculation"
				>
					<?php esc_html_e('Instant LTV recalculation', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
			</button>
			<button id="pmw_stop_ltv_calculation"
					class="button button-primary"
					style="margin-top: 0; margin-left: 10px;"
					data-action="stop_ltv_recalculation"
			>
				<?php esc_html_e('Stop all LTV calculations', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</button>
			<div id="ltv-schedule-recalculation-confirmation-message"
				class="ltv-message"
				style="display: none; margin-left: 10px;"
			>
				<?php esc_html_e('Recalculation has been scheduled for a run over night. Click one more time to start the recalculation immediately.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</div>
			<div id="ltv-running-recalculation-confirmation-message"
				class="ltv-message"
				style="display: none; margin-left: 10px;"
			>
				<?php esc_html_e('The recalculation is running.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</div>
			<div id="ltv-message-error"
				class="ltv-message"
				style="display: none; margin-left: 10px;"
			>
					<span id="ltv-message-error-text">
					</span>
			</div>
			<?php self::get_documentation_html_by_key('ltv_recalculation'); ?>
		</div>
		<?php
	}

	public static function html_lazy_load_pmw() {

		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[general][lazy_load_pmw]">
			<input type="checkbox"
					id="pmw_setting_lazy_load_pmw"
					name="wgact_plugin_options[general][lazy_load_pmw]"
					value="1"
				<?php checked(Options::is_lazy_load_pmw_active()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>

			<?php esc_html_e('Lazy load the Pixel Manager', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php self::display_status_icon(Options::is_lazy_load_pmw_active(), Options::lazy_load_requirements(), true); ?>
		<?php self::get_documentation_html_by_key('lazy_load_pmw'); ?>
		<?php self::html_pro_feature(); ?>
		<?php if (Options::is_lazy_load_pmw_active() && !Options::lazy_load_requirements()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('Google Optimize is active, but the Google Optimize anti flicker snippet is not. You need to activate the Google Optimize anti flicker snippet, or deactivate Google Optimize.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>

		<p>
			<span class="dashicons dashicons-info"></span>
			<?php esc_html_e('Enabling this feature will give you better page speed scores. Please read the documentation to learn more about the full implications while using this feature.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</p>

		<?php
	}

	public static function html_track_pageview_events_s2s() {

		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[general][pageview_events_s2s]">
			<input type="checkbox"
					id="pmw_setting_track_pageview_events_s2s"
					name="wgact_plugin_options[general][pageview_events_s2s]"
					value="1"
				<?php checked(Options::is_pageview_events_s2s_active()); ?>
				<?php disabled(Options::is_pageview_events_s2s_active_override()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>

			<?php esc_html_e('Send PageView events through the server-2-server protocol', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php self::display_status_icon(Options::is_pageview_events_s2s_active(), Options::server_2_server_enabled(), true); ?>
		<?php if (Options::is_pageview_events_s2s_active_override()) : ?>
			<?php self::html_status_icon_override(); ?>
		<?php endif; ?>
		<?php self::get_documentation_html_by_key('pageview_events_s2s'); ?>
		<?php self::html_pro_feature(); ?>

		<?php if (Options::is_pageview_events_s2s_active_override()) : ?>
			<p style="margin-top: 10px">
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('Automatically enabled because the SweetCode Server-Side Proxy is active. PageView events are sent through the proxy without adding load to your WooCommerce server.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php elseif (Options::is_pageview_events_s2s_active() && !Options::server_2_server_enabled()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('For this feature to be used, at least one server-to-server feature, like Facebook CAPI must be enabled.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php if (!Options::is_pageview_events_s2s_active_override()) : ?>
			<p style="margin-top: 10px">
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('Enabling this feature is encouraged by some platforms like Meta (Facebook). But, it will add a lot of stress to your server, because it will have to run on every PageView.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<?php
	}



	/**
	 * HTML output for the always send S2S events toggle.
	 *
	 * When enabled, server-side events are sent to ad platforms even when
	 * browser-side pixels haven't loaded (e.g. due to a consent manager).
	 * Browser-side tracking remains unaffected.
	 *
	 * @since 1.57.0
	 */
	public static function html_always_send_s2s() {

		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[general][always_send_s2s]">
			<input type="checkbox"
					id="pmw_setting_always_send_s2s"
					name="wgact_plugin_options[general][always_send_s2s]"
					value="1"
				<?php checked(Options::is_always_send_s2s_active()); ?>
				<?php echo esc_html(self::disable_if_demo()); ?>
			/>

			<?php esc_html_e('Always send server-side events, even when browser-side pixels have not loaded', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php self::display_status_icon(Options::is_always_send_s2s_active(), Options::always_send_s2s_has_destination(), true); ?>
		<?php self::html_pro_feature(); ?>

		<?php if (Options::is_always_send_s2s_active() && !Options::always_send_s2s_has_destination()) : ?>
			<p>
				<span class="dashicons dashicons-info"></span>
				<?php esc_html_e('For this feature to be used, at least one server-to-server feature, like Facebook CAPI or the GA4 Measurement Protocol must be enabled.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</p>
		<?php endif; ?>
		<p style="margin-top: 10px">
			<span class="dashicons dashicons-info"></span>
			<?php esc_html_e('When enabled, server-side events are sent to ad platforms even when browser-side pixels have not loaded (e.g. due to a consent manager). Browser-side tracking remains unaffected — only server-side events are sent independently. Useful for platforms that support cookieless or limited-data server-side integrations.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</p>
		<?php
	}

	/**
	 * HTML output for the deprecated functions module toggle.
	 *
	 * @since 1.51.0
	 */
	public static function html_load_deprecated_functions() {

		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[general][modules][load_deprecated_functions]">
			<input type="checkbox"
					id="pmw_setting_load_deprecated_functions"
					name="wgact_plugin_options[general][modules][load_deprecated_functions]"
					value="1"
				<?php checked(Options::should_load_deprecated_functions()); ?>
			/>

			<?php esc_html_e('Load deprecated functions for backward compatibility', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php self::display_status_icon(Options::should_load_deprecated_functions(), true, true); ?>
		<?php self::get_documentation_html_by_key('load_deprecated_functions'); ?>

		<p style="margin-top: 10px">
			<span class="dashicons dashicons-info"></span>
			<?php esc_html_e('Deprecated functions provide backward compatibility for older integrations. If you are not using any custom code that relies on deprecated Pixel Manager function names or event names (such as wpmBeginCheckout, wpmAddToCart, etc.), you can safely disable this to reduce the amount of JavaScript loaded.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</p>
		<?php
	}

	private static function get_order_duplication_prevention_text() {
		if (wpm_fs()->can_use_premium_code__premium_only()) {
			esc_html_e('Advanced order duplication prevention is ', 'woocommerce-google-adwords-conversion-tracking-tag');
		} else {
			esc_html_e('Basic order duplication prevention is ', 'woocommerce-google-adwords-conversion-tracking-tag');
		}
	}

	private static function add_to_cart_requirements_fulfilled() {
		if (Options::get_google_ads_conversion_id() && Options::get_google_ads_conversion_label() && Options::get_google_ads_merchant_id()) {
			return true;
		}

		return false;
	}

	public static function option_html_dynamic_remarketing() {

		esc_html_e('Dynamic Remarketing is', 'woocommerce-google-adwords-conversion-tracking-tag');
		self::display_status_icon(true);
		self::get_documentation_html_by_key('dynamic_remarketing');
	}

	public static function html_logger_activation() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[general][logger][is_active]">
			<input type="checkbox"
					id="wpm_plugin_option_logger"
					name="wgact_plugin_options[general][logger][is_active]"
					value="1"
				<?php checked(Options::is_logging_enabled()); ?>
			/>

			<?php esc_html_e('Enable logger', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php self::display_status_icon(Options::is_logging_enabled(), true, true); ?>
		<?php self::get_documentation_html_by_key('logger_activation'); ?>
		<?php // self::wistia_video_icon('7fhtv2s94t'); ?>
		<?php
	}

	public static function html_log_level() {
		?>
		<select id="wpm_plugin_option_log_level" name="wgact_plugin_options[general][logger][level]">
			<?php foreach (Logger::get_log_levels() as $log_level_number => $log_level_name) : ?>
				<option value="<?php echo esc_html($log_level_name); ?>"
					<?php selected($log_level_name, Options::get_log_level()); ?>
				>
					<?php echo esc_html($log_level_number . ' - ' . $log_level_name); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php self::get_documentation_html_by_key('log_level'); ?>
		<?php // self::wistia_video_icon('7fhtv2s94t'); ?>
		<?php
	}

	public static function html_log_outgoing_http_requests() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[general][logger][log_http_requests]">
			<input type="checkbox"
					id="wpm_plugin_option_log_http_requests"
					name="wgact_plugin_options[general][logger][log_http_requests]"
					value="1"
				<?php checked(Options::is_http_request_logging_enabled()); ?>
			/>
			<?php esc_html_e('Enable HTTP request logging', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php self::display_status_icon(Options::is_http_request_logging_enabled(), true, true); ?>
		<?php self::get_documentation_html_by_key('log_http_requests'); ?>
		<?php // self::wistia_video_icon('7fhtv2s94t'); ?>
		<p>

		</p>
		<span class="dashicons dashicons-info"></span>
		<?php esc_html_e("This feature switches web requests from asynchronous (faster, non-blocking) to synchronous (slower, blocking) to record responses. It allows the responses to be analyzed, but also uses more server resources. It's meant for troubleshooting and will turn off automatically after 12 hours. You can extend this time if needed. See the user guide for more details.", 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</p>
		<?php
	}

	public static function html_log_files() {

		$source                       = 'pmw';
		$admin_url_link_recent_wc_log = Helpers::get_admin_url_link_to_recent_wc_log($source);
		?>

		<button id="wgact_show_recent_log_file"
				type="button"
				class="button button-primary"
				style="margin-top: 0"
				onclick="window.open('<?php echo esc_url($admin_url_link_recent_wc_log); ?>')"
			<?php disabled(!$admin_url_link_recent_wc_log); ?>
		>
			<?php if ($admin_url_link_recent_wc_log) : ?>
				<?php esc_html_e('Show recent log file', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php else : ?>
				<?php esc_html_e('No log file found to view', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php endif; ?>

		</button>
		<?php
		// Add a button to download all plugin log files as a zip
		$all_log_files = Helpers::get_all_plugin_log_file_paths($source);
		?>

		<button id="wgact_download_logs_zip"
				type="button"
				class="button button-primary"
				style="margin-top: 0"
				data-source="<?php echo esc_attr($source); ?>"
			<?php disabled(empty($all_log_files)); ?>
		>
			<?php if (!empty($all_log_files)) : ?>
				<?php esc_html_e('Download all log files', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php else : ?>
				<?php esc_html_e('No log files found to download', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<?php endif; ?>
		</button>
		<?php self::get_documentation_html_by_key('log_files'); ?>
		<?php
	}

	public static function option_html_variations_output() {
		// adding the hidden input is a hack to make WordPress save the option with the value zero,
		// instead of not saving it and remove that array key entirely
		// https://stackoverflow.com/a/1992745/4688612
		?>
		<label>
			<input type="hidden" value="0" name="wgact_plugin_options[general][variations_output]">
			<input type="checkbox"
					id="wpm_plugin_option_variations_output"
					name="wgact_plugin_options[general][variations_output]"
					value="1"
				<?php checked(Options::is_shop_variations_output_active()); ?>
			/>
			<?php esc_html_e('Enable variations output', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<?php self::display_status_icon(Options::is_shop_variations_output_active(), true, true); ?>
		<?php self::get_documentation_html_by_key('variations_output'); ?>
		<p>
			<span class="dashicons dashicons-info"></span>
			<?php esc_html_e('In order for this to work you need to upload your product feed including product variations and the item_group_id. Disable it, if you choose only to upload the parent product for variable products.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</p>
		<?php
	}

	public static function plugin_option_google_business_vertical() {
		?>
		<div style="display: inline-block;">

			<label>
				<input type="radio"
						id="wpm_plugin_google_business_vertical_0"
						name="wgact_plugin_options[google][ads][google_business_vertical]"
						value="0"
					<?php echo( checked(0, Options::get_google_ads_business_vertical_id(), false) ); ?>
					<?php echo esc_html(self::disable_if_demo()); ?>
				/>
				<?php esc_html_e('Retail', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</label>
			<br>
			<label>
				<input type="radio"
						id="wpm_plugin_google_business_vertical_1"
						name="wgact_plugin_options[google][ads][google_business_vertical]"
						value="1"
					<?php echo( checked(1, Options::get_google_ads_business_vertical_id(), false) ); ?>
					<?php echo esc_html(self::disable_if_demo()); ?>
				/>
				<?php esc_html_e('Education', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</label>
			<br>
			<label>
				<input type="radio"
						id="wpm_plugin_google_business_vertical_3"
						name="wgact_plugin_options[google][ads][google_business_vertical]"
						value="3"
					<?php echo( checked(3, Options::get_google_ads_business_vertical_id(), false) ); ?>
					<?php echo esc_html(self::disable_if_demo()); ?>
				/>
				<?php esc_html_e('Hotels and rentals', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</label>
			<br>
			<label>
				<input type="radio"
						id="wpm_plugin_google_business_vertical_4"
						name="wgact_plugin_options[google][ads][google_business_vertical]"
						value="4"
					<?php echo( checked(4, Options::get_google_ads_business_vertical_id(), false) ); ?>
					<?php echo esc_html(self::disable_if_demo()); ?>
				/>
				<?php esc_html_e('Jobs', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</label>
			<br>
			<label>
				<input type="radio"
						id="wpm_plugin_google_business_vertical_5"
						name="wgact_plugin_options[google][ads][google_business_vertical]"
						value="5"
					<?php echo( checked(5, Options::get_google_ads_business_vertical_id(), false) ); ?>
					<?php echo esc_html(self::disable_if_demo()); ?>
				/>
				<?php esc_html_e('Local deals', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</label>
			<br>
			<label>
				<input type="radio"
						id="wpm_plugin_google_business_vertical_6"
						name="wgact_plugin_options[google][ads][google_business_vertical]"
						value="6"
					<?php echo( checked(6, Options::get_google_ads_business_vertical_id(), false) ); ?>
					<?php echo esc_html(self::disable_if_demo()); ?>
				/>
				<?php esc_html_e('Real estate', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</label>
			<br>
			<label>
				<input type="radio"
						id="wpm_plugin_google_business_vertical_8"
						name="wgact_plugin_options[google][ads][google_business_vertical]"
						value="8"
					<?php echo( checked(8, Options::get_google_ads_business_vertical_id(), false) ); ?>
					<?php echo esc_html(self::disable_if_demo()); ?>
				/>
				<?php esc_html_e('Custom', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</label>
		</div>

		<div style="display: inline-block;vertical-align: top;">
			<?php self::html_pro_feature(); ?>
		</div>

		<?php
	}

	public static function plugin_setting_google_tag_id() {

		$tag_id = Google_Helpers::get_google_tag_id_information()['active'];

		?>
		<input class="pmw mono readonly"
				type="text"
				id="pmw_plugin_google_tag_id"
				size="40"
				value="<?php echo esc_html($tag_id); ?>"
				readonly
				onclick="this.select();"
		/>

		<?php self::render_copy_button('pmw_plugin_google_tag_id', 'pmwGoogleTagIdTooltip'); ?>
		<?php self::get_documentation_html_by_key('google_tag_id'); ?>
		<br><br>
		<?php
		esc_html_e('Your Google tag ID. This field is read-only but you can click to select and copy the text.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	public static function plugin_setting_google_gateway_measurement_path() {

		$gateway_url_healthy  = get_site_url() . Options::get_google_tag_gateway_measurement_path() . '/healthy';
		$has_measurement_path = !empty(Options::get_google_tag_gateway_measurement_path());

		?>
		<input class="pmw mono"
				type="text"
				id="pmw_google_tag_gateway_measurement_path"
				name="wgact_plugin_options[google][tag_gateway][measurement_path]"
				size="40"
				value="<?php echo esc_html(Options::get_google_tag_gateway_measurement_path()); ?>"
				onclick="this.select();"
		/>
		<?php self::render_copy_button('pmw_google_tag_gateway_measurement_path', 'pmwGoogleTagIdTooltip'); ?>

		<!-- Pre-rendered status icons (initially invisible) -->
		<span id="pmw-status-icon-inactive"
				class="pmw-status-icon inactive <?php echo $has_measurement_path ? 'invisible' : ''; ?>">
			<?php esc_html_e('inactive', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</span>
		<span id="pmw-status-icon-active" class="pmw-status-icon active invisible">
			<?php esc_html_e('active', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</span>
		<span id="pmw-status-icon-partially-active" class="pmw-status-icon partially-active invisible">
			<?php esc_html_e('partially active', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</span>

		<!-- Pre-rendered health check icons (initially invisible) -->
		<span id="pmw-health-check-passed" class="pmw-status-icon active invisible">
			<?php esc_html_e('health check passed', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</span>
		<span id="pmw-health-check-failed" class="pmw-status-icon inactive invisible">
			<?php esc_html_e('health check failed', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</span>
		<span id="pmw-health-check-cloudflare-blocked" class="pmw-status-icon inactive invisible" style="color: #d63638;">
			<?php esc_html_e('blocked by Cloudflare bot challenge - adjust your Cloudflare security settings', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</span>

		<?php self::get_documentation_html_by_key('google_tag_gateway_measurement_path'); ?>
		<?php // self::wistia_video_icon('d3ehc3lurt'); ?>
		<p style="margin-top:10px">
			<?php esc_html_e('Your Google Gateway Measurement Path. It should look like this:', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			<code>/metrics</code>
		</p>

		<?php if ($has_measurement_path) : ?>
			<script>
				document.addEventListener("DOMContentLoaded", function () {
					// Get the gateway URL from PHP
					const gatewayUrlHealthy = '<?php echo esc_js($gateway_url_healthy); ?>';

					// Get the status icon elements
					const inactiveIcon              = document.getElementById("pmw-status-icon-inactive");
					const activeIcon                = document.getElementById("pmw-status-icon-active");
					const partiallyActiveIcon       = document.getElementById("pmw-status-icon-partially-active");
					const healthCheckPassed         = document.getElementById("pmw-health-check-passed");
					const healthCheckFailed         = document.getElementById("pmw-health-check-failed");
					const healthCheckCloudflareBlock = document.getElementById("pmw-health-check-cloudflare-blocked");

					// Function to show the appropriate icons based on health check result
					function updateStatusIcons(isHealthy, isCloudflareBlocked = false) {
						// Hide all icons first
						inactiveIcon.classList.add("invisible");
						activeIcon.classList.add("invisible");
						partiallyActiveIcon.classList.add("invisible");
						healthCheckPassed.classList.add("invisible");
						healthCheckFailed.classList.add("invisible");
						healthCheckCloudflareBlock.classList.add("invisible");

						if (isHealthy) {
							// If health check passes, show active icon and health check passed
							activeIcon.classList.remove("invisible");
							healthCheckPassed.classList.remove("invisible");
						} else if (isCloudflareBlocked) {
							// If blocked by Cloudflare, show specific error
							partiallyActiveIcon.classList.remove("invisible");
							healthCheckCloudflareBlock.classList.remove("invisible");
						} else {
							// If health check fails for other reasons
							partiallyActiveIcon.classList.remove("invisible");
							healthCheckFailed.classList.remove("invisible");
						}
					}

					// Log debug information
					console.log("[PMW Gateway Health Check] Starting health check for:", gatewayUrlHealthy);

					// Fetch the health status from the gateway URL
					fetch(gatewayUrlHealthy, {
						method : "GET",
						headers: {
							"Accept": "application/json",
						},
						cache  : "no-store",
					})
						.then(response => {
							// Get the response body for both success and failure cases
							return response.text().then(text => {
								// Log response details
								console.log("[PMW Gateway Health Check] Response received:");
								console.log("  Status Code:", response.status, response.statusText);
								console.log("  Content-Type:", response.headers.get("content-type"));
								console.log("  Content-Length:", response.headers.get("content-length"));
								console.log("  Cache-Control:", response.headers.get("cache-control"));
								console.log("  Server:", response.headers.get("server"));
								console.log("  Response Body (first 500 chars):", text.substring(0, 500));
								
								// Check for Cloudflare challenge indicators
								const isCloudflareBlocked = text.includes("challenge") || 
															text.includes("cf-chl") || 
															text.includes("cf_captcha_kind") ||
															text.includes("ray_id") ||
															text.includes("Checking your browser");

								if (isCloudflareBlocked) {
									console.warn("[PMW Gateway Health Check] Cloudflare challenge detected in response body");
								}

								if (response.ok) {
									// Check if the response contains "ok" (case-insensitive)
									const isHealthy = text.toLowerCase().includes("ok");
									console.log("[PMW Gateway Health Check] Response OK. Gateway is", isHealthy ? "HEALTHY" : "UNHEALTHY");
									console.log("  Contains 'ok':", isHealthy);
									updateStatusIcons(isHealthy, isCloudflareBlocked && !isHealthy);
								} else {
									// If response is not OK, check if it's Cloudflare blocking
									console.warn("[PMW Gateway Health Check] Response status is not OK (2xx)");
									console.warn("  Cloudflare blocked:", isCloudflareBlocked);
									updateStatusIcons(false, isCloudflareBlocked);
									return Promise.reject("Health check failed with status: " + response.status);
								}
							});
						})
						.catch(error => {
							// If there's an error with the fetch, health check failed
							console.error("[PMW Gateway Health Check] Fetch error occurred:");
							console.error("  Error:", error);
							const errorMessage = (error && typeof error.message === "string") ? error.message : "";
							const isNetworkOrCorsError = errorMessage.toLowerCase().includes("failed to fetch") || errorMessage.toLowerCase().includes("networkerror");
							console.error("  Error type:", isNetworkOrCorsError ? "Network/CORS error" : "Other error");
							updateStatusIcons(false, false);
						});
				});
			</script>
		<?php endif; ?>

		<?php
	}

	public static function plugin_setting_aw_merchant_id() {
		?>
		<input class="pmw mono"
				type="text"
				id="wpm_plugin_aw_merchant_id"
				name="wgact_plugin_options[google][ads][aw_merchant_id]"
				size="40"
				value="<?php echo esc_html(Options::get_google_ads_merchant_id()); ?>"
				onclick="this.select();"
		/>
		<?php self::display_status_icon(Options::get_google_ads_merchant_id()); ?>
		<?php self::get_documentation_html_by_key('aw_merchant_id'); ?>
		<br><br>
		<?php
		esc_html_e('ID of your Google Merchant Center account. It looks like this: 12345678', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	public static function plugin_option_product_identifier() {
		?>
		<label>
			<input type="radio"
					id="wpm_plugin_option_product_identifier_0"
					name="wgact_plugin_options[google][ads][product_identifier]"
					value="0"
				<?php echo( checked(0, Options::get_google_ads_product_identifier(), false) ); ?>
			/>
			<?php esc_html_e('post ID (default)', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></label>
		<br>
		<label>
			<input type="radio"
					id="wpm_plugin_option_product_identifier_2"
					name="wgact_plugin_options[google][ads][product_identifier]"
					value="2"
				<?php echo( checked(2, Options::get_google_ads_product_identifier(), false) ); ?>
			/>
			<?php esc_html_e('SKU', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<br>
		<label>
			<input type="radio"
					id="wpm_plugin_option_product_identifier_1"
					name="wgact_plugin_options[google][ads][product_identifier]"
					value="1"
				<?php echo( checked(1, Options::get_google_ads_product_identifier(), false) ); ?>
			/>
			<?php esc_html_e('ID for the WooCommerce Google Product Feed. Outputs the post ID with woocommerce_gpf_ prefix *', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<br>
		<label>
			<input type="radio"
					id="wpm_plugin_option_product_identifier_3"
					name="wgact_plugin_options[google][ads][product_identifier]"
					value="3"
				<?php echo( checked(3, Options::get_google_ads_product_identifier(), false) ); ?>
			/>
			<?php esc_html_e('ID for the Google for WooCommerce plugin (formerly Google Listings & Ads). Outputs the post ID with gla_ prefix **', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</label>
		<br>
		<p style="margin-top:10px">
			<?php esc_html_e('Choose a product identifier.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</p>
		<br>
		<?php esc_html_e('* This is for users of the WooCommerce Google Product Feed Plugin', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		<a href="https://woocommerce.com/products/google-product-feed/" target="_blank">WooCommerce Google Product Feed
			Plugin</a>
		<br>
		<?php esc_html_e('** This is for users of the Google for WooCommerce plugin (formerly Google Listings & Ads)', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		<a href="https://woocommerce.com/products/google-listings-and-ads/" target="_blank">Google for WooCommerce
			Plugin</a>

		<?php
	}

	private static function html_beta() {
		return '<div class="pmw-status-icon beta">' . esc_html__('beta', 'woocommerce-google-adwords-conversion-tracking-tag') . '</div>';
	}

	private static function html_experiment() {
		return '<div class="pmw-status-icon beta" style="vertical-align: middle; margin-top: -2px">' . esc_html__('beta', 'woocommerce-google-adwords-conversion-tracking-tag') . '</div>';
	}

	private static function html_beta_e( $margin_top = '1px' ) {
		?>
		<div class="pmw-status-icon beta" style="margin-top: <?php echo esc_html($margin_top); ?>">
			<?php esc_html_e('beta', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
		</div>
		<?php
	}

	private static function html_status_icon_active() {
		?>
		<div class="pmw-status-icon active"><?php esc_html_e('active', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></div>
		<?php
	}

	private static function html_status_icon_inactive() {
		?>
		<div class="pmw-status-icon inactive"><?php esc_html_e('inactive', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></div>
		<?php
	}

	private static function html_status_icon_partially_active() {
		?>
		<div class="pmw-status-icon partially-active"><?php esc_html_e('partially active', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></div>
		<?php
	}

	private static function html_status_icon_override() {
		?>
		<div class="pmw-status-icon partially-active"><?php esc_html_e('override', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></div>
		<?php
	}

	private static function html_status_icon_deprecated() {
		?>
		<div class="pmw-status-icon inactive"><?php esc_html_e('deprecated', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></div>
		<?php
	}

	private static function html_status_health_check_passed() {
		?>
		<div class="pmw-status-icon active"><?php esc_html_e('health check passed', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></div>
		<?php
	}

	private static function html_status_health_check_failed() {
		?>
		<div class="pmw-status-icon inactive"><?php esc_html_e('health check failed', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></div>
		<?php
	}

	private static function html_deprecated() {
		return '<div class="pmw-status-icon inactive">' . esc_html__('deprecated', 'woocommerce-google-adwords-conversion-tracking-tag') . '</div>';
	}

	private static function html_pro_feature() {

		if (!Options::is_pro_version_demo_active()) {
			return;
		}

		if ('wcm' === Helpers::get_pmw_distro()) {
			// Affiliate links are not allowed
			$link        = Commercial_Links::WC_PRODUCT_URL;
			$button_text = __('Get Pro', 'woocommerce-google-adwords-conversion-tracking-tag');
		} else {
			$link        = 'https://sweetcode.com/plugins/pmw/?open-checkout=&trial=&billing-cycle=annual&utm_source=plugin&utm_medium=start-free-trial-button&utm_campaign=show-pro-version-settings#pricing-section';
			$button_text = __('Start a free trial', 'woocommerce-google-adwords-conversion-tracking-tag');
		}

		?>
		<span class="pmw-pro-feature">
				<?php esc_html_e('Pro Feature', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
			</span>

		<a href="<?php echo esc_url($link); ?>"
			target="_blank" style="box-shadow: none;">
			<div id="proVersionButton" class="button">
				<?php echo esc_html($button_text); ?>
			</div>
		</a>

		<?php
	}

	private static function display_status_icon( $status, $requirements = true, $inactive_silent = false ) {
		if ($status && $requirements) {
			self::html_status_icon_active();
		} elseif ($status && !$requirements) {
			self::html_status_icon_partially_active();
		} elseif (!$inactive_silent) {
			self::html_status_icon_inactive();
		}
	}

	private static function display_health_status( $status ) {
		if ($status) {
			self::html_status_health_check_passed();
		} else {
			self::html_status_health_check_failed();
		}
	}

	private static function disable_if_demo() {
		if (!wpm_fs()->can_use_premium_code__premium_only() && Options::is_pro_version_demo_active()) {
			return 'disabled';
		} else {
			return '';
		}
	}

	private static function wistia_video_icon( $wistia_id, $tooltip_text = '' ) {
		?>

		<script>
			(function () {
				const video_id = '<?php echo esc_js($wistia_id); ?>';

				// Configure the Wistia player
				window._wq = window._wq || [];
				_wq.push({
					id     : video_id,
					onReady: function (video) {
						// Find the container for this specific video
						const container = document.querySelector(`[data-wistia-id="${video_id}"]`);
						if (container) {
							// Make the video visible when ready
							container.style.display    = "inline-block";
							container.style.position   = "relative";
							container.style.width      = "auto";
							container.style.height     = "auto";
							container.style.visibility = "visible";
						}
					},
				});

				// Load the Wistia script for this video
				const script = document.createElement("script");
				script.async = true;
				script.src   = `https://fast.wistia.com/embed/medias/${video_id}.jsonp`;
				document.getElementsByTagName("head")[0].appendChild(script);
			})();
		</script>

		<!-- Video container - initially hidden via CSS -->
		<div class="pmw wistia_embed wistia_async_<?php echo esc_html($wistia_id); ?> popover=true popoverContent=link videoFoam=false"
			data-wistia-id="<?php echo esc_html($wistia_id); ?>">
			<span class="dashicons dashicons-video-alt3"></span>
		</div>
		<?php
	}

	/**
	 * Output the JavaScript functions for the copy button functionality.
	 * This should be called only once per page.
	 *
	 * @since 1.48.1
	 */
	public static function output_copy_button_js() {
		static $js_output = false;

		// Only output the JavaScript once
		if ($js_output) {
			return;
		}

		$js_output = true;
		?>
		<script>
			const pmwCopyToClipboard = (inputId, tooltipId) => {
				navigator.clipboard.writeText(document.getElementById(inputId).value);
				const pmwCaFeedTooltip     = document.getElementById(tooltipId);
				pmwCaFeedTooltip.innerHTML = "<?php esc_html_e('Copied', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>";
			};

			const pmwResetCopyButton = (tooltipId) => {
				const pmwCaFeedTooltip     = document.getElementById(tooltipId);
				pmwCaFeedTooltip.innerHTML = "<?php esc_html_e('Copy to clipboard', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>";
			};
		</script>
		<?php
	}

	/**
	 * Render a copy button with tooltip for a text input.
	 *
	 * @param string $input_id   The ID of the input element to copy from.
	 * @param string $tooltip_id Optional custom tooltip ID. If not provided, will be generated from the input ID.
	 *
	 * @since 1.48.1
	 */
	public static function render_copy_button( $input_id, $tooltip_id = null ) {
		// Ensure the JavaScript is output
		self::output_copy_button_js();

		// Generate a tooltip ID if not provided
		if (null === $tooltip_id) {
			$tooltip_id = $input_id . 'Tooltip';
		}

		?>
		<div class="pmwCaTooltip">
			<a href="javascript:void(0)" class="pmw-copy-icon pmwCaTooltip"
				onclick="pmwCopyToClipboard('<?php echo esc_attr($input_id); ?>', '<?php echo esc_attr($tooltip_id); ?>')"
				onmouseout="pmwResetCopyButton('<?php echo esc_attr($tooltip_id); ?>')"></a>
			<span class="pmwCaTooltiptext"
					id="<?php echo esc_attr($tooltip_id); ?>"><?php esc_html_e('Copy to clipboard', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></span>
		</div>
		<?php
	}
}
