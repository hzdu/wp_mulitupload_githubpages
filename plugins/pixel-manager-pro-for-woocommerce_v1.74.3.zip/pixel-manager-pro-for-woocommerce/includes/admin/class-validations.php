<?php

namespace SweetCode\Pixel_Manager\Admin;

use SweetCode\Pixel_Manager\Database;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

class Validations {

	/**
	 * Validate a whole options tree from a settings import.
	 *
	 * The import route used to check that a handful of keys exist and then
	 * store the submitted tree as it was. Every other write path validates each
	 * field and refuses paths that are not settings, so the import does the
	 * same now: keys the defaults tree does not know are dropped, every string
	 * leaf runs the validator the settings page uses for that path, booleans
	 * and integers take their type from the default, the schema version must be
	 * one the plugin knows, and on a free tier the Pro-only paths keep the
	 * stored value, as the disabled fields on the settings page do.
	 *
	 * @param array $options The imported tree, already sanitized.
	 * @return array{valid: bool, options: array, errors: string[]} The cleaned
	 *         tree and the dot paths of the values that failed.
	 *
	 * @since 1.69.1
	 */
	public static function validate_imported_options_tree( $options ) {

		$errors = [];
		$clean  = self::intersect_with_defaults((array) $options, Options::get_default_options(), '', $errors);

		if (array_key_exists('db_version', $clean)) {
			$version = is_numeric($clean['db_version']) ? (int) $clean['db_version'] : 0;

			if ($version < 1 || $version > (int) PMW_DB_VERSION) {
				$errors[] = 'db_version';
			} else {
				$clean['db_version'] = $version;
			}
		}

		if (empty($errors)) {
			$clean = self::preserve_premium_only_options($clean);
		}

		return [
			'valid'   => empty($errors),
			'options' => $clean,
			'errors'  => array_values(array_unique($errors)),
		];
	}

	/**
	 * Walk the defaults tree and keep only what the import has for each known key.
	 *
	 * A default that is a non-empty associative array is a branch. Everything
	 * else is a leaf: a list or an empty array accepts any array, a boolean or
	 * an integer coerces the value, and a string runs the field validator.
	 *
	 * @param array    $input    The imported branch.
	 * @param array    $defaults The defaults branch.
	 * @param string   $path     Dot path of the branch.
	 * @param string[] $errors   Collects the dot paths that failed.
	 * @return array
	 *
	 * @since 1.69.1
	 */
	private static function intersect_with_defaults( $input, $defaults, $path, &$errors ) {

		$out = [];

		foreach ($defaults as $key => $default) {

			if (!array_key_exists($key, $input)) {
				continue;
			}

			$value     = $input[ $key ];
			$leaf_path = '' === $path ? (string) $key : $path . '.' . $key;

			if (is_array($default) && !empty($default) && !self::is_list($default)) {
				if (!is_array($value)) {
					$errors[] = $leaf_path;
					continue;
				}
				$out[ $key ] = self::intersect_with_defaults($value, $default, $leaf_path, $errors);
				continue;
			}

			if (is_array($default)) {
				if (!is_array($value)) {
					$errors[] = $leaf_path;
					continue;
				}
				$out[ $key ] = $value;
				continue;
			}

			if (is_bool($default)) {
				$out[ $key ] = filter_var($value, FILTER_VALIDATE_BOOLEAN);
				continue;
			}

			if (is_int($default) || is_float($default)) {
				if (!is_numeric($value)) {
					$errors[] = $leaf_path;
					continue;
				}
				$out[ $key ] = is_int($default) ? (int) $value : (float) $value;
				continue;
			}

			if (null === $default) {
				$out[ $key ] = $value;
				continue;
			}

			if (!is_scalar($value) && null !== $value) {
				$errors[] = $leaf_path;
				continue;
			}

			$result = self::validate_single_option($leaf_path, (string) $value);

			if (!$result['valid']) {
				$errors[] = $leaf_path;
				continue;
			}

			$out[ $key ] = $result['value'];
		}

		return $out;
	}

	/**
	 * Whether an array is a list (0..n-1 keys), as opposed to a keyed branch.
	 *
	 * @param array $array
	 * @return bool
	 *
	 * @since 1.69.1
	 */
	private static function is_list( $array ) {
		return array_keys($array) === range(0, count($array) - 1);
	}

	public static function validate_imported_options( $options ) {

//      error_log('Validating imported options...');
//      error_log(print_r($options, true));

		$options_to_check = [
			'google'     => [
				'ads'          => [
					'conversion_id'    => '',
					'conversion_label' => '',
				],
				'analytics'    => [
					'ga4' => [
						'measurement_id' => '',
					],
				],
				'consent_mode' => [
					'active'  => false,
					'regions' => [],
				],
				'user_id'      => false,
			],
			'facebook'   => [
				'pixel_id' => '',
			],
			'shop'       => [
				'order_total_logic' => 0,
			],
			'general'    => [
				'variations_output' => true,
			],
			'db_version' => PMW_DB_VERSION,
		];

		return self::do_all_keys_exist_recursive($options_to_check, $options);
	}

	private static function do_all_keys_exist_recursive( $partial_array, $full_array ) {

		foreach ($partial_array as $key => $value) {
			if (!array_key_exists($key, $full_array)) {
				Logger::error('key not found: ' . $key);
				return false;
			}
			if (is_array($value)) {
				if (!self::do_all_keys_exist_recursive($value, $full_array[$key])) {
					return false;
				}
			}
		}

		return true;
	}

	// validate the options
	public static function options_validate( $input ) {

		$input = Helpers::generic_sanitization($input);

//      // validate Adroll advertiser ID
		if (isset($input['pixels']['adroll']['advertiser_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['adroll']['advertiser_id'] = Helpers::trim_string($input['pixels']['adroll']['advertiser_id']);

			if (!self::is_adroll_advertiser_id($input['pixels']['adroll']['advertiser_id'])) {
				$input['pixels']['adroll']['advertiser_id']
					= Options::get_adroll_advertiser_id()
					? Options::get_adroll_advertiser_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-adroll-advertiser-id', esc_html__('You have entered an invalid Adroll advertiser ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

//      // validate Adroll pixel ID
		if (isset($input['pixels']['adroll']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['adroll']['pixel_id'] = Helpers::trim_string($input['pixels']['adroll']['pixel_id']);

			if (!self::is_adroll_pixel_id($input['pixels']['adroll']['pixel_id'])) {
				$input['pixels']['adroll']['pixel_id']
					= Options::get_adroll_pixel_id()
					? Options::get_adroll_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-adroll-pixel-id', esc_html__('You have entered an invalid Adroll pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate Google Analytics 4 measurement ID
		if (isset($input['google']['analytics']['ga4']['measurement_id'])) {

			// Trim space, newlines and quotes
			$input['google']['analytics']['ga4']['measurement_id'] = Helpers::trim_string($input['google']['analytics']['ga4']['measurement_id']);

			if (!self::is_google_analytics_4_measurement_id($input['google']['analytics']['ga4']['measurement_id'])) {
				$input['google']['analytics']['ga4']['measurement_id']
					= Options::get_ga4_measurement_id()
					? Options::get_ga4_measurement_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-google-analytics-4-measurement-id', esc_html__('You have entered an invalid Google Analytics 4 measurement ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate Google Analytics 4 API key
		if (isset($input['google']['analytics']['ga4']['api_secret'])) {

			// Trim space, newlines and quotes
			$input['google']['analytics']['ga4']['api_secret'] = Helpers::trim_string($input['google']['analytics']['ga4']['api_secret']);

			if (!self::is_google_analytics_4_api_secret($input['google']['analytics']['ga4']['api_secret'])) {
				$input['google']['analytics']['ga4']['api_secret']
					= Options::get_ga4_mp_api_secret()
					? Options::get_ga4_mp_api_secret()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-google-analytics-4-measurement-id', esc_html__('You have entered an invalid Google Analytics 4 API key.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Google Analytics 4 property ID
		if (isset($input['google']['analytics']['ga4']['data_api']['property_id'])) {

			// Trim space, newlines and quotes
			$input['google']['analytics']['ga4']['data_api']['property_id'] = Helpers::trim_string($input['google']['analytics']['ga4']['data_api']['property_id']);

			if (!self::is_ga4_property_id($input['google']['analytics']['ga4']['data_api']['property_id'])) {
				$input['google']['analytics']['ga4']['data_api']['property_id']
					= Options::get_ga4_data_api_property_id()
					? Options::get_ga4_data_api_property_id()
					: '';
				add_settings_error(
					'wgact_plugin_options',
					'invalid-google-analytics-4-property-id',
					esc_html__('You have entered an invalid GA4 property ID.', 'woocommerce-google-adwords-conversion-tracking-tag')
				);
			}
		}

		// validate ['google]['ads']['conversion_id']
		if (isset($input['google']['ads']['conversion_id'])) {

			// Trim space, newlines and quotes
			$input['google']['ads']['conversion_id'] = Helpers::trim_string($input['google']['ads']['conversion_id']);

			// Remove "AW-" prefix
			$input['google']['ads']['conversion_id'] = preg_replace('/^AW-/', '', $input['google']['ads']['conversion_id']);

			// If there is a slash, remove it and everything after it
			$input['google']['ads']['conversion_id'] = preg_replace('/\/.*$/', '', $input['google']['ads']['conversion_id']);

			if (!self::is_gads_conversion_id($input['google']['ads']['conversion_id'])) {
				$input['google']['ads']['conversion_id']
					= Options::get_google_ads_conversion_id()
					? Options::get_google_ads_conversion_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-conversion-id', esc_html__('You have entered an invalid conversion ID. It only contains 8 to 10 digits.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['google]['ads']['conversion_label']
		if (isset($input['google']['ads']['conversion_label'])) {

			// Trim space, newlines and quotes
			$input['google']['ads']['conversion_label'] = Helpers::trim_string($input['google']['ads']['conversion_label']);

			// If there is a slash, remove it and everything before it
			$input['google']['ads']['conversion_label'] = preg_replace('/^.*\//', '', $input['google']['ads']['conversion_label']);

			if (!self::is_gads_conversion_label($input['google']['ads']['conversion_label'])) {
				$input['google']['ads']['conversion_label']
					= Options::get_google_ads_conversion_label()
					? Options::get_google_ads_conversion_label()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-conversion-label', esc_html__('You have entered an invalid Google Ads conversion label.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['google]['ads']['phone_conversion_label']
		if (isset($input['google']['ads']['phone_conversion_label'])) {

			// Trim space, newlines and quotes
			$input['google']['ads']['phone_conversion_label'] = Helpers::trim_string($input['google']['ads']['phone_conversion_label']);

			if (!self::is_gads_conversion_label($input['google']['ads']['phone_conversion_label'])) {
				$input['google']['ads']['phone_conversion_label']
					= Options::get_google_ads_phone_conversion_label()
					? Options::get_google_ads_phone_conversion_label()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-conversion-label', esc_html__('You have entered an invalid Google Ads conversion label.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['google']['ads']['phone_conversion_number']
		if (isset($input['google']['ads']['phone_conversion_number'])) {

			// Trim space, newlines and quotes
			$input['google']['ads']['phone_conversion_number'] = Helpers::trim_string($input['google']['ads']['phone_conversion_number']);

			if (!self::is_phone_number($input['google']['ads']['phone_conversion_number'])) {
				$input['google']['ads']['phone_conversion_number']
					= Options::get_google_ads_phone_conversion_number()
					? Options::get_google_ads_phone_conversion_number()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-phone-conversion-number', esc_html__('You have entered an invalid phone number for Google Ads phone conversion tracking.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['google]['tag_gateway']['measurement_path']
		if (isset($input['google']['tag_gateway']['measurement_path'])) {

			// Trim space, newlines and quotes
			$input['google']['tag_gateway']['measurement_path'] = Helpers::trim_string($input['google']['tag_gateway']['measurement_path']);

			// Prefix a slash if it doesn't exist
			if ('' !== $input['google']['tag_gateway']['measurement_path'] && '/' !== substr($input['google']['tag_gateway']['measurement_path'], 0, 1)) {
				$input['google']['tag_gateway']['measurement_path'] = '/' . $input['google']['tag_gateway']['measurement_path'];
			}

			if (!self::is_google_tag_gateway_measurement_path($input['google']['tag_gateway']['measurement_path'])) {
				$input['google']['tag_gateway']['measurement_path']
					= Options::get_google_tag_gateway_measurement_path()
					? Options::get_google_tag_gateway_measurement_path()
					: '';
				add_settings_error(
					'wgact_plugin_options',
					'invalid-google-tag-gateway-measurement-path',
					sprintf(
					// Translators: %s is the placeholder for the Google tag gateway measurement path.
						esc_html__('You have entered an invalid Google tag gateway measurement path. It should look like %s', 'woocommerce-google-adwords-conversion-tracking-tag'),
						'<code>/metrics</code>'
					)
				);
			}
		}

		// validate ['google]['ads']['aw_merchant_id']
		if (isset($input['google']['ads']['aw_merchant_id'])) {

			// Trim space, newlines and quotes
			$input['google']['ads']['aw_merchant_id'] = Helpers::trim_string($input['google']['ads']['aw_merchant_id']);

			if (!self::is_gads_aw_merchant_id($input['google']['ads']['aw_merchant_id'])) {
				$input['google']['ads']['aw_merchant_id']
					= Options::get_google_ads_merchant_id()
					? Options::get_google_ads_merchant_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-aw-merchant-id', esc_html__('You have entered an invalid merchant ID. It only contains 6 to 12 digits.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['facebook']['pixel_id']
		if (isset($input['facebook']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['facebook']['pixel_id'] = Helpers::trim_string($input['facebook']['pixel_id']);

			if (!self::is_facebook_pixel_id($input['facebook']['pixel_id'])) {
				$input['facebook']['pixel_id']
					= Options::get_facebook_pixel_id()
					? Options::get_facebook_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-facebook-pixel-id', esc_html__('You have entered an invalid Meta (Facebook) pixel ID. It only contains 12 to 22 digits.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['facebook']['capi']['token']
		if (isset($input['facebook']['capi']['token'])) {

			// Trim space, newlines and quotes
			$input['facebook']['capi']['token'] = Helpers::trim_string($input['facebook']['capi']['token']);

			if (!self::is_facebook_capi_token($input['facebook']['capi']['token'])) {
				$input['facebook']['capi']['token']
					= Options::get_facebook_capi_token()
					? Options::get_facebook_capi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-facebook-pixel-id', esc_html__('You have entered an invalid Meta (Facebook) CAPI token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['facebook']['capi']['test_event_code']
		if (isset($input['facebook']['capi']['test_event_code'])) {

			// Trim space, newlines and quotes
			$input['facebook']['capi']['test_event_code'] = Helpers::trim_string($input['facebook']['capi']['test_event_code']);

			if (!self::is_facebook_capi_test_event_code($input['facebook']['capi']['test_event_code'])) {
				$input['facebook']['capi']['test_event_code']
					= Options::get_facebook_capi_test_event_code()
					? Options::get_facebook_capi_test_event_code()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-facebook-capi-test-event-code', esc_html__('You have entered an invalid Meta (Facebook) CAPI test_event_code.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['facebook']['domain_verification_id']
		if (isset($input['facebook']['domain_verification_id'])) {

			// Trim space, newlines and quotes
			$input['facebook']['domain_verification_id'] = Helpers::trim_string($input['facebook']['domain_verification_id']);

			// The input might look like this <meta name= "facebook-domain-verification" content="uk6zwiftxsaywayn14x04ouhz4fhd" / >
			// or it might look like this uk6zwiftxsaywayn14x04ouhz4fhd
			// or like this  content="uk6zwiftxsaywayn14x04ouhz4fhd"
			// We need to extract the content value
			$input['facebook']['domain_verification_id'] = preg_replace('/^.*content\s*=\s*["\']?([^"\']+?)["\']?\s*\/?\s*>?$/', '$1', $input['facebook']['domain_verification_id']);

			if (!self::is_facebook_domain_verification_id($input['facebook']['domain_verification_id'])) {
				$input['facebook']['domain_verification_id']
					= Options::get_facebook_domain_verification_id()
					? Options::get_facebook_domain_verification_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-meta-domain-verification-id', esc_html__('You have entered an invalid Meta (Facebook) domain verification ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}


		// validate Bing Ads UET tag ID
		if (isset($input['bing']['uet_tag_id'])) {

			// Trim space, newlines and quotes
			$input['bing']['uet_tag_id'] = Helpers::trim_string($input['bing']['uet_tag_id']);

			if (!self::is_bing_uet_tag_id($input['bing']['uet_tag_id'])) {
				$input['bing']['uet_tag_id']
					= Options::get_bing_uet_tag_id()
					? Options::get_bing_uet_tag_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-bing-ads-uet-tag-id', esc_html__('You have entered an invalid Bing Ads UET tag ID. It only contains 7 to 9 digits.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Microsoft Advertising Conversions API token
		if (isset($input['bing']['capi']['token'])) {

			// Trim space, newlines and quotes
			$input['bing']['capi']['token'] = Helpers::trim_string($input['bing']['capi']['token']);

			if (!self::is_bing_capi_token($input['bing']['capi']['token'])) {
				$input['bing']['capi']['token']
					= Options::get_bing_capi_token()
					? Options::get_bing_capi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-bing-capi-token', esc_html__('You have entered an invalid Microsoft Advertising Conversions API token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate LinkedIn partner ID
		if (isset($input['pixels']['linkedin']['partner_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['linkedin']['partner_id'] = Helpers::trim_string($input['pixels']['linkedin']['partner_id']);

			if (!self::is_linkedin_partner_id($input['pixels']['linkedin']['partner_id'])) {
				$input['pixels']['linkedin']['partner_id']
					= Options::get_linkedin_partner_id()
					? Options::get_linkedin_partner_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-linkedin-partner-id', esc_html__('You have entered an invalid LinkedIn partner ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate LinkedIn conversion IDs
		$input = self::validate_linkedin_conversion_id($input, 'view_content');
		$input = self::validate_linkedin_conversion_id($input, 'add_to_cart');
		$input = self::validate_linkedin_conversion_id($input, 'purchase');

		// validate Outbrain advertiser ID
		if (isset($input['pixels']['outbrain']['advertiser_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['outbrain']['advertiser_id'] = Helpers::trim_string($input['pixels']['outbrain']['advertiser_id']);

			if (!self::is_outbrain_account_id($input['pixels']['outbrain']['advertiser_id'])) {
				$input['pixels']['outbrain']['advertiser_id']
					= Options::get_outbrain_advertiser_id()
					? Options::get_outbrain_advertiser_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-outbrain-advertiser-id', esc_html__('You have entered an invalid Outbrain advertiser ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['pinterest']['ad_account_id']
		if (isset($input['pinterest']['ad_account_id'])) {

			// Trim space, newlines and quotes
			$input['pinterest']['ad_account_id'] = Helpers::trim_string($input['pinterest']['ad_account_id']);

			if (!self::is_pinterest_ad_account_id($input['pinterest']['ad_account_id'])) {
				$input['pinterest']['ad_account_id']
					= Options::get_pinterest_ad_account_id()
					? Options::get_pinterest_ad_account_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-pinterest-ad-account-id', esc_html__('You have entered an invalid Pinterest ad account ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate ['pinterest']['apic']['token']
		if (isset($input['pinterest']['apic']['token'])) {

			// Trim space, newlines and quotes
			$input['pinterest']['apic']['token'] = Helpers::trim_string($input['pinterest']['apic']['token']);

			if (!self::is_pinterest_apic_token($input['pinterest']['apic']['token'])) {
				$input['pinterest']['apic']['token']
					= Options::get_pinterest_apic_token()
					? Options::get_pinterest_apic_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-pinterest-apic-token', esc_html__('You have entered an invalid Pinterest API token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate Twitter pixel ID
		if (isset($input['twitter']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['twitter']['pixel_id'] = Helpers::trim_string($input['twitter']['pixel_id']);

			if (!self::is_twitter_pixel_id($input['twitter']['pixel_id'])) {
				$input['twitter']['pixel_id']
					= Options::get_twitter_pixel_id()
					? Options::get_twitter_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-twitter-pixel-id', esc_html__('You have entered an invalid Twitter pixel ID. It only contains 5 to 7 lowercase letters and numbers.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate Twitter event IDs
		$input = self::validate_twitter_event($input, 'add_to_cart');
		$input = self::validate_twitter_event($input, 'add_to_wishlist');
		$input = self::validate_twitter_event($input, 'view_content');
		$input = self::validate_twitter_event($input, 'search');
		$input = self::validate_twitter_event($input, 'initiate_checkout');
		$input = self::validate_twitter_event($input, 'add_payment_info');
		$input = self::validate_twitter_event($input, 'purchase');

		// validate Pinterest pixel ID
		if (isset($input['pinterest']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['pinterest']['pixel_id'] = Helpers::trim_string($input['pinterest']['pixel_id']);

			if (!self::is_pinterest_pixel_id($input['pinterest']['pixel_id'])) {
				$input['pinterest']['pixel_id']
					= Options::get_pinterest_pixel_id()
					? Options::get_pinterest_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-pinterest-pixel-id', esc_html__('You have entered an invalid Pinterest pixel ID. It only contains 13 digits.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate Snapchat pixel ID
		if (isset($input['snapchat']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['snapchat']['pixel_id'] = Helpers::trim_string($input['snapchat']['pixel_id']);

			if (!self::is_snapchat_pixel_id($input['snapchat']['pixel_id'])) {
				$input['snapchat']['pixel_id']
					= Options::get_snapchat_pixel_id()
					? Options::get_snapchat_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-snapchat-pixel-id', esc_html__('You have entered an invalid Snapchat pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate Snapchat CAPI token
		if (isset($input['snapchat']['capi']['token'])) {

			// Trim space, newlines and quotes
			$input['snapchat']['capi']['token'] = Helpers::trim_string($input['snapchat']['capi']['token']);

			if (!self::is_snapchat_capi_token($input['snapchat']['capi']['token'])) {
				$input['snapchat']['capi']['token']
					= Options::get_snapchat_capi_token()
					? Options::get_snapchat_capi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-snapchat-capi-token', esc_html__('You have entered an invalid Snapchat CAPI token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate Taboola account ID
		if (isset($input['pixels']['taboola']['account_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['taboola']['account_id'] = Helpers::trim_string($input['pixels']['taboola']['account_id']);

			if (!self::is_taboola_account_id($input['pixels']['taboola']['account_id'])) {
				$input['pixels']['taboola']['account_id']
					= Options::get_taboola_account_id()
					? Options::get_taboola_account_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-taboola-account-id', esc_html__('You have entered an invalid Taboola account ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate TikTok pixel ID
		if (isset($input['tiktok']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['tiktok']['pixel_id'] = Helpers::trim_string($input['tiktok']['pixel_id']);

			if (!self::is_tiktok_pixel_id($input['tiktok']['pixel_id'])) {
				$input['tiktok']['pixel_id']
					= Options::get_tiktok_pixel_id()
					? Options::get_tiktok_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-tiktok-pixel-id', esc_html__('You have entered an invalid TikTok pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate TikTok Events API access token
		if (isset($input['tiktok']['eapi']['token'])) {

			// Trim space, newlines and quotes
			$input['tiktok']['eapi']['token'] = Helpers::trim_string($input['tiktok']['eapi']['token']);

			if (!self::is_tiktok_eapi_access_token($input['tiktok']['eapi']['token'])) {
				$input['tiktok']['eapi']['token']
					= Options::get_tiktok_eapi_token()
					? Options::get_tiktok_eapi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-tiktok-eapi-access-token', esc_html__('You have entered an invalid TikTok Events API access token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate ['tiktok']['eapi']['test_event_code']
		if (isset($input['tiktok']['eapi']['test_event_code'])) {

			// Trim space, newlines and quotes
			$input['tiktok']['eapi']['test_event_code'] = Helpers::trim_string($input['tiktok']['eapi']['test_event_code']);

			if (!self::is_tiktok_eapi_test_event_code($input['tiktok']['eapi']['test_event_code'])) {
				$input['tiktok']['eapi']['test_event_code']
					= Options::get_tiktok_eapi_test_event_code()
					? Options::get_tiktok_eapi_test_event_code()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-tiktok-eapi-test-event-code', esc_html__('You have entered an invalid TikTok EAPI test_event_code.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// validate Hotjar site ID
		if (isset($input['hotjar']['site_id'])) {

			// Trim space, newlines and quotes
			$input['hotjar']['site_id'] = Helpers::trim_string($input['hotjar']['site_id']);

			if (!self::is_hotjar_site_id($input['hotjar']['site_id'])) {
				$input['hotjar']['site_id']
					= Options::get_hotjar_site_id()
					? Options::get_hotjar_site_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-hotjar-site-id', esc_html__('You have entered an invalid Hotjar site ID. It only contains 6 to 9 digits.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate CrazyEgg account number
		if (isset($input['crazyegg']['account_number'])) {

			// Trim space, newlines and quotes
			$input['crazyegg']['account_number'] = Helpers::trim_string($input['crazyegg']['account_number']);

			// Extract account number from full script tag if pasted
			// Pattern: //script.crazyegg.com/pages/scripts/0131/9772.js -> 01319772
			if (preg_match('/script\.crazyegg\.com\/pages\/scripts\/(\d+)\/(\d+)\.js/', $input['crazyegg']['account_number'], $matches)) {
				$input['crazyegg']['account_number'] = $matches[1] . $matches[2];
			} else {
				// Strip all non-digits (handles formats like 0131/9772 or 0131-9772)
				$input['crazyegg']['account_number'] = preg_replace('/\D/', '', $input['crazyegg']['account_number']);
			}

			if (!self::is_crazyegg_account_number($input['crazyegg']['account_number'])) {
				$input['crazyegg']['account_number']
					= Options::get_crazyegg_account_number()
					? Options::get_crazyegg_account_number()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-crazyegg-account-number', esc_html__('You have entered an invalid CrazyEgg account number. It must be exactly 8 digits.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate Reddit advertiser ID
		if (isset($input['pixels']['reddit']['advertiser_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['reddit']['advertiser_id'] = Helpers::trim_string($input['pixels']['reddit']['advertiser_id']);

			if (!self::is_reddit_advertiser_id($input['pixels']['reddit']['advertiser_id'])) {
				$input['pixels']['reddit']['advertiser_id']
					= Options::get_reddit_advertiser_id()
					? Options::get_reddit_advertiser_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-reddit-advertiser-id', esc_html__('You have entered an invalid Reddit pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate Reddit CAPI token
		if (isset($input['pixels']['reddit']['capi']['token'])) {

			// Trim space, newlines and quotes
			$input['pixels']['reddit']['capi']['token'] = Helpers::trim_string($input['pixels']['reddit']['capi']['token']);

			if (!self::is_reddit_capi_token($input['pixels']['reddit']['capi']['token'])) {
				$input['pixels']['reddit']['capi']['token']
					= Options::get_reddit_capi_token()
					? Options::get_reddit_capi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-reddit-capi-token', esc_html__('You have entered an invalid Reddit CAPI token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate Reddit CAPI test event code
		if (isset($input['pixels']['reddit']['capi']['test_event_code'])) {

			// Trim space, newlines and quotes
			$input['pixels']['reddit']['capi']['test_event_code'] = Helpers::trim_string($input['pixels']['reddit']['capi']['test_event_code']);

			if (!self::is_reddit_capi_test_event_code($input['pixels']['reddit']['capi']['test_event_code'])) {
				$input['pixels']['reddit']['capi']['test_event_code']
					= Options::get_reddit_capi_test_event_code()
					? Options::get_reddit_capi_test_event_code()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-reddit-capi-test-event-code', esc_html__('You have entered an invalid Reddit CAPI test event code.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate OpenAI pixel ID
		if (isset($input['pixels']['openai']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['openai']['pixel_id'] = Helpers::trim_string($input['pixels']['openai']['pixel_id']);

			if (!self::is_openai_pixel_id($input['pixels']['openai']['pixel_id'])) {
				$input['pixels']['openai']['pixel_id']
					= Options::get_openai_pixel_id()
					? Options::get_openai_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-openai-pixel-id', esc_html__('You have entered an invalid OpenAI pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate OpenAI CAPI token
		if (isset($input['pixels']['openai']['capi']['token'])) {

			// Trim space, newlines and quotes
			$input['pixels']['openai']['capi']['token'] = Helpers::trim_string($input['pixels']['openai']['capi']['token']);

			if (!self::is_openai_capi_token($input['pixels']['openai']['capi']['token'])) {
				$input['pixels']['openai']['capi']['token']
					= Options::get_openai_capi_token()
					? Options::get_openai_capi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-openai-capi-token', esc_html__('You have entered an invalid OpenAI CAPI token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the VWO account ID
		if (isset($input['pixels']['vwo']['account_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['vwo']['account_id'] = Helpers::trim_string($input['pixels']['vwo']['account_id']);

			if (!self::is_vwo_account_id($input['pixels']['vwo']['account_id'])) {
				$input['pixels']['vwo']['account_id']
					= Options::get_vwo_account_id()
					? Options::get_vwo_account_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-vwo-account-id', esc_html__('You have entered an invalid VWO account ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Optimizely project ID
		if (isset($input['pixels']['optimizely']['project_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['optimizely']['project_id'] = Helpers::trim_string($input['pixels']['optimizely']['project_id']);

			if (!self::is_optimizely_project_id($input['pixels']['optimizely']['project_id'])) {
				$input['pixels']['optimizely']['project_id']
					= Options::get_optimizely_project_id()
					? Options::get_optimizely_project_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-vwo-account-id', esc_html__('You have entered an invalid Optimizely project ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the AB Tasty account ID
		if (isset($input['pixels']['ab_tasty']['account_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['ab_tasty']['account_id'] = Helpers::trim_string($input['pixels']['ab_tasty']['account_id']);

			if (!self::is_ab_tasty_account_id($input['pixels']['ab_tasty']['account_id'])) {
				$input['pixels']['ab_tasty']['account_id']
					= Options::get_ab_tasty_account_id()
					? Options::get_ab_tasty_account_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-vwo-account-id', esc_html__('You have entered an invalid AB Tasty account ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Contentsquare tag ID
		if (isset($input['pixels']['contentsquare']['tag_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['contentsquare']['tag_id'] = Helpers::trim_string($input['pixels']['contentsquare']['tag_id']);

			if (!self::is_contentsquare_tag_id($input['pixels']['contentsquare']['tag_id'])) {
				$input['pixels']['contentsquare']['tag_id']
					= Options::get_contentsquare_tag_id()
					? Options::get_contentsquare_tag_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-contentsquare-tag-id', esc_html__('You have entered an invalid Contentsquare tag ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Microsoft Clarity project ID
		if (isset($input['pixels']['clarity']['project_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['clarity']['project_id'] = Helpers::trim_string($input['pixels']['clarity']['project_id']);

			if (!self::is_clarity_project_id($input['pixels']['clarity']['project_id'])) {
				$input['pixels']['clarity']['project_id']
					= Options::get_clarity_project_id()
					? Options::get_clarity_project_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-clarity-project-id', esc_html__('You have entered an invalid Microsoft Clarity project ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the GroundTruth GTID
		if (isset($input['pixels']['groundtruth']['gtid'])) {

			// Trim space, newlines and quotes
			$input['pixels']['groundtruth']['gtid'] = Helpers::trim_string($input['pixels']['groundtruth']['gtid']);

			if (!self::is_groundtruth_gtid($input['pixels']['groundtruth']['gtid'])) {
				$input['pixels']['groundtruth']['gtid']
					= Options::get_groundtruth_gtid()
					? Options::get_groundtruth_gtid()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-groundtruth-gtid', esc_html__('You have entered an invalid GroundTruth GTID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Rumble Ads tag ID
		if (isset($input['pixels']['rumble']['tag_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['rumble']['tag_id'] = Helpers::trim_string($input['pixels']['rumble']['tag_id']);

			if (!self::is_rumble_tag_id($input['pixels']['rumble']['tag_id'])) {
				$input['pixels']['rumble']['tag_id']
					= Options::get_rumble_tag_id()
					? Options::get_rumble_tag_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-rumble-tag-id', esc_html__('You have entered an invalid Rumble Ads tag ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Rumble Ads conversion action IDs
		$input = self::validate_rumble_conversion_id($input, 'purchase');
		$input = self::validate_rumble_conversion_id($input, 'add_to_cart');

		// Validate the Criteo account ID
		if (isset($input['pixels']['criteo']['account_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['criteo']['account_id'] = Helpers::trim_string($input['pixels']['criteo']['account_id']);

			if (!self::is_criteo_account_id($input['pixels']['criteo']['account_id'])) {
				$input['pixels']['criteo']['account_id']
					= Options::get_criteo_account_id()
					? Options::get_criteo_account_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-criteo-account-id', esc_html__('You have entered an invalid Criteo account ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Mixpanel project token
		if (isset($input['pixels']['mixpanel']['project_token'])) {

			// Trim space, newlines and quotes
			$input['pixels']['mixpanel']['project_token'] = Helpers::trim_string($input['pixels']['mixpanel']['project_token']);

			if (!self::is_mixpanel_project_token($input['pixels']['mixpanel']['project_token'])) {
				$input['pixels']['mixpanel']['project_token']
					= Options::get_mixpanel_project_token()
					? Options::get_mixpanel_project_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-mixpanel-project-token', esc_html__('You have entered an invalid Mixpanel project token. It must be a 32 character hexadecimal string.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Keep the Mixpanel data residency region within the set of regions Mixpanel offers.
		// Events sent to the wrong region are silently not ingested.
		if (isset($input['pixels']['mixpanel']['data_residency'])) {

			$input['pixels']['mixpanel']['data_residency'] = Helpers::trim_string($input['pixels']['mixpanel']['data_residency']);

			if (!in_array($input['pixels']['mixpanel']['data_residency'], [ 'us', 'eu', 'in' ], true)) {
				$input['pixels']['mixpanel']['data_residency'] = Options::get_mixpanel_data_residency();
			}
		}

		// Validate the Klaviyo public API key
		if (isset($input['pixels']['klaviyo']['public_api_key'])) {

			// Trim space, newlines and quotes
			$input['pixels']['klaviyo']['public_api_key'] = Helpers::trim_string($input['pixels']['klaviyo']['public_api_key']);

			if (!self::is_klaviyo_public_api_key($input['pixels']['klaviyo']['public_api_key'])) {
				$input['pixels']['klaviyo']['public_api_key']
					= Options::get_klaviyo_public_api_key()
					? Options::get_klaviyo_public_api_key()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-klaviyo-public-api-key', esc_html__('You have entered an invalid Klaviyo public API key. It must be the 6 character Site ID, not a private key starting with pk_.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Klaviyo Events API private key
		if (isset($input['pixels']['klaviyo']['events_api']['token'])) {

			$input['pixels']['klaviyo']['events_api']['token'] = Helpers::trim_string($input['pixels']['klaviyo']['events_api']['token']);

			if (!self::is_klaviyo_events_api_token($input['pixels']['klaviyo']['events_api']['token'])) {
				$input['pixels']['klaviyo']['events_api']['token']
					= Options::get_klaviyo_events_api_token()
					? Options::get_klaviyo_events_api_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-klaviyo-events-api-token', esc_html__('You have entered an invalid Klaviyo private API key. It must start with pk_.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Keep the Klaviyo coexistence mode within the known set. An unknown
		// value falls back to auto, which can only under-report, never
		// double-count.
		if (isset($input['pixels']['klaviyo']['coexistence'])) {

			$input['pixels']['klaviyo']['coexistence'] = Helpers::trim_string($input['pixels']['klaviyo']['coexistence']);

			if (!in_array($input['pixels']['klaviyo']['coexistence'], [ 'auto', 'takeover', 'gap_fill', 'off' ], true)) {
				$input['pixels']['klaviyo']['coexistence'] = 'auto';
			}
		}

		// Validate the Nextdoor pixel ID
		if (isset($input['pixels']['nextdoor']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['nextdoor']['pixel_id'] = Helpers::trim_string($input['pixels']['nextdoor']['pixel_id']);

			if (!self::is_nextdoor_pixel_id($input['pixels']['nextdoor']['pixel_id'])) {
				$input['pixels']['nextdoor']['pixel_id']
					= Options::get_nextdoor_pixel_id()
					? Options::get_nextdoor_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-nextdoor-pixel-id', esc_html__('You have entered an invalid Nextdoor pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Nextdoor Conversion API token
		if (isset($input['pixels']['nextdoor']['capi']['token'])) {

			// Trim space, newlines and quotes
			$input['pixels']['nextdoor']['capi']['token'] = Helpers::trim_string($input['pixels']['nextdoor']['capi']['token']);

			if (!self::is_nextdoor_capi_token($input['pixels']['nextdoor']['capi']['token'])) {
				$input['pixels']['nextdoor']['capi']['token']
					= Options::get_nextdoor_capi_token()
					? Options::get_nextdoor_capi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-nextdoor-capi-token', esc_html__('You have entered an invalid Nextdoor Conversion API token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Nextdoor Conversion API test event code
		if (isset($input['pixels']['nextdoor']['capi']['test_event_code'])) {

			// Trim space, newlines and quotes
			$input['pixels']['nextdoor']['capi']['test_event_code'] = Helpers::trim_string($input['pixels']['nextdoor']['capi']['test_event_code']);

			if (!self::is_nextdoor_capi_test_event_code($input['pixels']['nextdoor']['capi']['test_event_code'])) {
				$input['pixels']['nextdoor']['capi']['test_event_code']
					= Options::get_nextdoor_capi_test_event_code()
					? Options::get_nextdoor_capi_test_event_code()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-nextdoor-capi-test-event-code', esc_html__('You have entered an invalid Nextdoor Conversion API test event code.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Spotify Ads pixel ID
		if (isset($input['pixels']['spotify']['pixel_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['spotify']['pixel_id'] = Helpers::trim_string($input['pixels']['spotify']['pixel_id']);

			if (!self::is_spotify_pixel_id($input['pixels']['spotify']['pixel_id'])) {
				$input['pixels']['spotify']['pixel_id']
					= Options::get_spotify_pixel_id()
					? Options::get_spotify_pixel_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-spotify-pixel-id', esc_html__('You have entered an invalid Spotify Ads pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Spotify Conversions API connection ID
		if (isset($input['pixels']['spotify']['capi']['connection_id'])) {

			// Trim space, newlines and quotes
			$input['pixels']['spotify']['capi']['connection_id'] = Helpers::trim_string($input['pixels']['spotify']['capi']['connection_id']);

			if (!self::is_spotify_capi_connection_id($input['pixels']['spotify']['capi']['connection_id'])) {
				$input['pixels']['spotify']['capi']['connection_id']
					= Options::get_spotify_capi_connection_id()
					? Options::get_spotify_capi_connection_id()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-spotify-capi-connection-id', esc_html__('You have entered an invalid Spotify Conversions API connection ID.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Spotify Conversions API token
		if (isset($input['pixels']['spotify']['capi']['token'])) {

			// Trim space, newlines and quotes
			$input['pixels']['spotify']['capi']['token'] = Helpers::trim_string($input['pixels']['spotify']['capi']['token']);

			if (!self::is_spotify_capi_token($input['pixels']['spotify']['capi']['token'])) {
				$input['pixels']['spotify']['capi']['token']
					= Options::get_spotify_capi_token()
					? Options::get_spotify_capi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-spotify-capi-token', esc_html__('You have entered an invalid Spotify Conversions API token.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the AppLovin event key
		if (isset($input['pixels']['applovin']['event_key'])) {

			// Trim space, newlines and quotes
			$input['pixels']['applovin']['event_key'] = Helpers::trim_string($input['pixels']['applovin']['event_key']);

			if (!self::is_applovin_event_key($input['pixels']['applovin']['event_key'])) {
				$input['pixels']['applovin']['event_key']
					= Options::get_applovin_event_key()
					? Options::get_applovin_event_key()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-applovin-event-key', esc_html__('You have entered an invalid AppLovin event key.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the AppLovin Conversion API key
		if (isset($input['pixels']['applovin']['capi']['token'])) {

			// Trim space, newlines and quotes
			$input['pixels']['applovin']['capi']['token'] = Helpers::trim_string($input['pixels']['applovin']['capi']['token']);

			if (!self::is_applovin_capi_token($input['pixels']['applovin']['capi']['token'])) {
				$input['pixels']['applovin']['capi']['token']
					= Options::get_applovin_capi_token()
					? Options::get_applovin_capi_token()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-applovin-capi-token', esc_html__('You have entered an invalid AppLovin Conversion API key.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Hyros product hash
		if (isset($input['pixels']['hyros']['product_hash'])) {

			// Trim space, newlines and quotes, and pull the hash out of a pasted script snippet or URL
			$input['pixels']['hyros']['product_hash'] = self::extract_hyros_product_hash($input['pixels']['hyros']['product_hash']);

			if (!self::is_hyros_product_hash($input['pixels']['hyros']['product_hash'])) {
				$input['pixels']['hyros']['product_hash']
					= Options::get_hyros_product_hash()
					? Options::get_hyros_product_hash()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-hyros-product-hash', esc_html__('You have entered an invalid Hyros product hash.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Validate the Hyros application tag
		if (isset($input['pixels']['hyros']['application_tag'])) {

			// Trim space, newlines and quotes
			$input['pixels']['hyros']['application_tag'] = Helpers::trim_string($input['pixels']['hyros']['application_tag']);

			if (!self::is_hyros_application_tag($input['pixels']['hyros']['application_tag'])) {
				$input['pixels']['hyros']['application_tag']
					= Options::get_hyros_application_tag()
					? Options::get_hyros_application_tag()
					: '';
				add_settings_error('wgact_plugin_options', 'invalid-hyros-application-tag', esc_html__('You have entered an invalid Hyros application tag.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		// Sanitize and validate scroll tracker thresholds
		if (isset($input['general']['scroll_tracker_thresholds'])) {

			if (is_string($input['general']['scroll_tracker_thresholds'])) {

				$scroll_tracker_thresholds = $input['general']['scroll_tracker_thresholds'];

				// remove all spaces
				$scroll_tracker_thresholds = str_replace(' ', '', $scroll_tracker_thresholds);

				// remove leading and trailing commas
				$scroll_tracker_thresholds = trim($scroll_tracker_thresholds, ',');

				// remove duplicate commas and replace with single comma
				$scroll_tracker_thresholds = preg_replace('/,+/', ',', $scroll_tracker_thresholds);

				// remove quotes
				$scroll_tracker_thresholds = str_replace('"', '', $scroll_tracker_thresholds);

				// remove single quotes
				$scroll_tracker_thresholds = str_replace("'", '', $scroll_tracker_thresholds);

				if (!self::is_scroll_tracker_thresholds($scroll_tracker_thresholds)) {
					$input['general']['scroll_tracker_thresholds']
						= Options::get_scroll_tracking_thresholds()
						? Options::get_scroll_tracking_thresholds()
						: '';
					add_settings_error('wgact_plugin_options', 'invalid-scroll-tracker-thresholds', esc_html__('You have entered the Scroll Tracker thresholds in the wrong format. It must be a list of comma separated percentages, like this "25,50,75,100"', 'woocommerce-google-adwords-conversion-tracking-tag'));
				} elseif ('' !== $scroll_tracker_thresholds) { // If $scroll_tracker_thresholds not empty string
					$input['general']['scroll_tracker_thresholds'] = explode(',', $scroll_tracker_thresholds);
				} else {
					$input['general']['scroll_tracker_thresholds'] = [];
				}
			} else {
				Logger::debug('Scroll Tracker Thresholds is not a string: ' . print_r($input['general']['scroll_tracker_thresholds'], true));
			}
		}

		// Validate the subscription value multiplier
		if (isset($input['shop']['subscription_value_multiplier'])) {

			// Trim space, newlines and quotes
			$input['shop']['subscription_value_multiplier'] = Helpers::trim_string($input['shop']['subscription_value_multiplier']);

			if (!self::is_subscription_value_multiplier($input['shop']['subscription_value_multiplier'])) {

				$input['shop']['subscription_value_multiplier']
					= Options::get_subscription_multiplier()
					? Options::get_subscription_multiplier()
					: 1;

				add_settings_error('wgact_plugin_options', 'invalid-subscription-value-multiplier', esc_html__('You have entered an invalid subscription value multiplier. It must be a number and at least 1.00', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}

			// Count decimal places
			$decimal_places = strlen(substr(strrchr($input['shop']['subscription_value_multiplier'], '.'), 1));

			$input['shop']['subscription_value_multiplier'] = Helpers::format_decimal($input['shop']['subscription_value_multiplier'], max($decimal_places, 2));
		}

		// Validate the Google Ads Conversion Adjustments Conversion Name
		if (isset($input['google']['ads']['conversion_adjustments']['conversion_name'])) {

			// Trim space, newlines and quotes
			$input['google']['ads']['conversion_adjustments']['conversion_name'] = Helpers::trim_string($input['google']['ads']['conversion_adjustments']['conversion_name']);

			if (!self::is_valid_conversion_adjustments_conversion_name($input['google']['ads']['conversion_adjustments']['conversion_name'])) {

				$input['google']['ads']['conversion_adjustments']['conversion_name']
					= Options::get_google_ads_conversion_adjustments_conversion_name()
					? Options::get_google_ads_conversion_adjustments_conversion_name()
					: '';

				add_settings_error('wgact_plugin_options', 'invalid-conversion-adjustments-conversion-name', esc_html__('You have entered an invalid conversion adjustments conversion name. Special characters, quotes and single quotes are not allowed due to security reasons.', 'woocommerce-google-adwords-conversion-tracking-tag'));
			}
		}

		self::schedule_duplication_prevention_activation($input);
		self::schedule_http_request_logging_deactivation($input);

		/**
		 * Merging with the existing options and overwriting old values
		 * since disabling a checkbox doesn't send a value,
		 * we need to set one to overwrite the old value
		 */
		$input = array_replace_recursive(self::non_form_keys($input), $input);

		/**
		 * Preserve the saved premium-only settings while Pro features are unavailable.
		 *
		 * Without a valid license (and outside the Pro demo) the premium form fields
		 * are not rendered, so they are not part of the submitted form data and would
		 * be reset to their defaults a few lines below. Carrying the saved values over
		 * makes sure that an expired license only deactivates the Pro features, but
		 * never wipes their configuration. Once the license is reactivated, everything
		 * is still in place.
		 */
		$input = self::preserve_premium_only_options($input);

		// Set the timestamp for the options update
		$input['timestamp'] = time();

		// Add default values to missing options
		// Because when saving the options, the form fields that are not set
		// will not set in the $input array
		$input = Options::update_with_defaults($input, Options::get_default_options());

		// Create automatic backup before processing options
		Options::save_automatic_options_backup_with_timestamp($input['timestamp'], $input);

		return $input;
	}

	private static function validate_twitter_event( $input, $event ) {

		if (isset($input['twitter']['event_ids'][$event])) {

			// Trim space, newlines and quotes
			$input['twitter']['event_ids'][$event] = Helpers::trim_string($input['twitter']['event_ids'][$event]);

			if (!self::is_twitter_event_id($input['twitter']['event_ids'][$event])) {
				$input['twitter']['event_ids'][$event]
					= Options::get_twitter_event_id($event)
					? Options::get_twitter_event_id($event)
					: '';
				add_settings_error(
					'wgact_plugin_options',
					'invalid-twitter-event-id',
					esc_html__('You have entered an invalid Twitter event ID.', 'woocommerce-google-adwords-conversion-tracking-tag')
				);
				return $input;
			}

			return $input;
		}

		return $input;
	}

	/**
	 * Validate one Rumble Ads conversion action ID of the submitted options.
	 *
	 * @since 1.72.1
	 *
	 * @param array  $input The submitted options.
	 * @param string $event purchase or add_to_cart.
	 * @return array
	 */
	private static function validate_rumble_conversion_id( $input, $event ) {

		if (!isset($input['pixels']['rumble']['conversion_ids'][$event])) {
			return $input;
		}

		// Trim space, newlines and quotes
		$input['pixels']['rumble']['conversion_ids'][$event] = Helpers::trim_string($input['pixels']['rumble']['conversion_ids'][$event]);

		if (!self::is_rumble_conversion_id($input['pixels']['rumble']['conversion_ids'][$event])) {
			$input['pixels']['rumble']['conversion_ids'][$event]
				= Options::get_rumble_conversion_id($event)
				? Options::get_rumble_conversion_id($event)
				: '';
			add_settings_error(
				'wgact_plugin_options',
				'invalid-rumble-conversion-id',
				esc_html__('You have entered an invalid Rumble Ads conversion action ID.', 'woocommerce-google-adwords-conversion-tracking-tag')
			);
		}

		return $input;
	}

	private static function validate_linkedin_conversion_id( $input, $event ) {

		if (isset($input['pixels']['linkedin']['conversion_ids'][$event])) {

			// Trim space, newlines and quotes
			$input['pixels']['linkedin']['conversion_ids'][$event] = Helpers::trim_string($input['pixels']['linkedin']['conversion_ids'][$event]);

			if (!self::is_linkedin_conversion_id($input['pixels']['linkedin']['conversion_ids'][$event])) {
				$input['pixels']['linkedin']['conversion_ids'][$event]
					= Options::get_linkedin_conversion_id($event)
					? Options::get_linkedin_conversion_id($event)
					: '';
				add_settings_error(
					'wgact_plugin_options',
					'invalid-linkedin-conversion-id',
					esc_html__('You have entered an invalid LinkedIn conversion ID.', 'woocommerce-google-adwords-conversion-tracking-tag')
				);
				return $input;
			}

			return $input;
		}

		return $input;
	}

	private static function schedule_duplication_prevention_activation( $input ) {

		// If action scheduler is not active, return
		if (!Environment::is_action_scheduler_active()) {
			return;
		}

		// If $input['shop']['order_deduplication'] is not set, return
		if (!isset($input['shop']['order_deduplication'])) {
			return;
		}

		// If pmw_reactivate_duplication_prevention action is already scheduled, unschedule it.
		// If the order duplication has been reactivated manually, we don't need to schedule the reactivation.
		// If the order duplication has been deactivated manually, and there is already a scheduled reactivation, we need to reset the time delay.
		as_unschedule_all_actions('pmw_reactivate_duplication_prevention');

		// If the order duplication is active, we don't need to do anything
		if ($input['shop']['order_deduplication']) {
			return;
		}

		// Schedule pmw_reactivate_duplication_prevention action
		as_schedule_single_action(time() + 6 * HOUR_IN_SECONDS, 'pmw_reactivate_duplication_prevention');
	}

	private static function schedule_http_request_logging_deactivation( $input ) {

		// If action scheduler is not active, return
		if (!Environment::is_action_scheduler_active()) {
			return;
		}

		// If $input['general']['logger']['log_http_requests'] is not set, return
		if (!isset($input['general']['logger']['log_http_requests'])) {
			return;
		}

		// If pmw_deactivate_log_http_requests action is already scheduled, unschedule it.
		// If http request logging has been deactivated manually, we don't need to schedule the deactivation.
		// If http request logging has been activated manually, and there is already a scheduled deactivation, we need to reset the time delay.
		as_unschedule_all_actions('pmw_deactivate_log_http_requests');

		// If $input['general']['logger']['log_http_requests'] is false, return
		// We only want to schedule the deactivation of http request logging if it is active
		if (!$input['general']['logger']['log_http_requests']) {
			return;
		}

		/**
		 * Set delay to 12 hours.
		 *
		 * @since 1.58.5
		 */
		$delay = apply_filters('pmw_http_request_log_auto_off_delay', 12 * HOUR_IN_SECONDS);

		// schedule pmw_deactivate_log_http_requests action
		as_schedule_single_action(time() + $delay, 'pmw_deactivate_log_http_requests');
	}

	/**
	 * Re-apply the auto-revert scheduling side effects for the settings that
	 * carry them, for the per-field/Nova save path.
	 *
	 * The Classic form save runs these inside options_validate(); the granular
	 * PATCH path does not, so toggling order de-duplication or HTTP-request
	 * logging through Nova would otherwise skip the timer that re-enables dedup
	 * after 6 hours / turns logging back off. Only the paths that actually
	 * changed are processed, to avoid resetting an existing timer on every save.
	 *
	 * @param array $options       The full, updated options tree.
	 * @param array $changed_paths Dot-notation paths included in this save.
	 *
	 * @return void
	 *
	 * @since 1.59.0
	 */
	public static function apply_setting_change_side_effects( $options, $changed_paths ) {

		if (in_array('shop.order_deduplication', $changed_paths, true)) {
			self::schedule_duplication_prevention_activation($options);
		}

		if (in_array('general.logger.log_http_requests', $changed_paths, true)) {
			self::schedule_http_request_logging_deactivation($options);
		}
	}

	/**
	 * Place here what could be overwritten when a form field is missing
	 * and what should not be re-set to the default value
	 * but should be preserved
	 */
	private static function non_form_keys( $input ) {

		$non_form_keys = [
			'db_version' => Options::get_options()['db_version'],
			'shop'       => [
				'disable_tracking_for' => [],
			],
			'google'     => [
				'analytics' => [
					'ga4' => [
						'data_api' => [
							'credentials' => Options::get_ga4_data_api_credentials(),
						],
					],
				],
			],
			'ssp'        => isset(Options::get_options()['ssp']) ? Options::get_options()['ssp'] : [],
		];

		// in case the form field input is missing
//        if (!array_key_exists('google_business_vertical', $input['google']['ads'])) {
//            $non_form_keys['google']['ads']['google_business_vertical'] = Options::get_google_ads_business_vertical_id();
//        }

		return $non_form_keys;
	}

	/**
	 * Copies the saved values of all premium-only settings into the submitted
	 * input while Pro features are unavailable.
	 *
	 * The form only submits fields that have been rendered. While the license is
	 * expired or missing (and the Pro demo is off), the premium-only fields are
	 * not rendered, so their keys are missing from the input and would otherwise
	 * be reset to their default values on every save.
	 *
	 * While Pro features are available (valid license or demo), the fields are
	 * rendered and submitted, and the input must win, so nothing is preserved.
	 *
	 * @param array $input The submitted options.
	 *
	 * @return array The input with the saved premium-only settings restored.
	 *
	 * @since 1.59.0
	 */
	private static function preserve_premium_only_options( $input ) {

		// The premium-only fields are rendered, the submitted values are authoritative.
		if (Helpers::is_pmw_pro_version_active() || Options::is_pro_version_demo_active()) {
			return $input;
		}

		$saved_options = Options::get_options();

		foreach (self::premium_only_option_paths() as $path) {

			$saved_value = self::get_nested_value($saved_options, $path);

			if (null === $saved_value) {
				continue;
			}

			$input = self::set_nested_value($input, $path, $saved_value);
		}

		return $input;
	}

	/**
	 * The dot notation paths of all settings whose form fields are only rendered
	 * while Pro features are available (valid license or active Pro demo).
	 *
	 * Keep this list in sync with every setting the UI renders as premium-only:
	 * the Nova admin pixel registry (src/admin-ui-wp/src/shared/data/pixels.ts —
	 * a pixel flagged `premium` locks ALL its fields, including the primary ID,
	 * plus individually `premium` fields on the free pixels) and the Classic
	 * admin's license-gated add_settings_field / HTML output callbacks. Custom
	 * components with their own gated endpoints (e.g. the GA4 Data API
	 * credentials import) are intentionally excluded — they never go through the
	 * generic options patch.
	 *
	 * This gates the REST options patch (class-admin-rest.php), preserves saved
	 * premium values on downgrade (preserve_premium_only_options), and is consumed
	 * by the Abilities API settings catalog to flag premium-only settings for AI agents.
	 *
	 * @return array The premium-only option paths.
	 *
	 * @since 1.59.0
	 */
	public static function premium_only_option_paths() {

		return [

			// Bing / Microsoft Ads. The UET tag and its consent mode are free,
			// the Conversions API and Enhanced Conversions are Pro.
			'bing.capi.token',
			'bing.enhanced_conversions',

			// CrazyEgg
			'crazyegg.account_number',

			// Facebook / Meta
			'facebook.capi.send_fb_login_id',
			'facebook.capi.test_event_code',
			'facebook.capi.token',
			'facebook.capi.user_transparency.send_additional_client_identifiers',
			'facebook.domain_verification_id',

			// General
			'general.always_send_s2s',
			'general.lazy_load_pmw',
			'general.pageview_events_s2s',
			'general.scroll_tracker_thresholds',

			// Google
			'google.ads.conversion_adjustments.conversion_name',
			'google.ads.data_manager.conversion_action_id',
			'google.ads.data_manager.conversion_action_name',
			'google.ads.data_manager.login_account_id',
			'google.ads.data_manager.operating_account_id',
			'google.ads.enhanced_conversions',
			'google.ads.google_business_vertical',
			'google.ads.phone_conversion_label',
			'google.ads.phone_conversion_number',
			'google.analytics.ga4.api_secret',
			'google.analytics.ga4.data_api.property_id',
			'google.analytics.ga4.page_load_time_tracking',
			'google.tcf_support',
			'google.user_id',

			// Pinterest. The tag ID is free, the API for Conversions and the
			// matching features are Pro.
			'pinterest.ad_account_id',
			'pinterest.advanced_matching',
			'pinterest.apic.token',
			'pinterest.enhanced_match',

			// Various pixels
			'pixels.ab_tasty.account_id',
			'pixels.adroll.advertiser_id',
			'pixels.adroll.pixel_id',
			'pixels.clarity.project_id',
			'pixels.contentsquare.tag_id',
			'pixels.criteo.account_id',
			'pixels.criteo.advanced_matching',
			'pixels.groundtruth.gtid',
			'pixels.hyros.application_tag',
			'pixels.hyros.product_hash',
			'pixels.linkedin.conversion_ids.add_to_cart',
			'pixels.linkedin.conversion_ids.purchase',
			'pixels.linkedin.conversion_ids.view_content',
			'pixels.linkedin.partner_id',
			'pixels.mixpanel.autocapture',
			'pixels.mixpanel.data_residency',
			'pixels.mixpanel.ingestion_api.enabled',
			'pixels.mixpanel.project_token',
			'pixels.mixpanel.session_recording',
			'pixels.mixpanel.user_identification',
			'pixels.klaviyo.coexistence',
			'pixels.klaviyo.events_api.token',
			'pixels.klaviyo.identify_customers',
			'pixels.klaviyo.public_api_key',
			'pixels.nextdoor.advanced_matching',
			'pixels.nextdoor.capi.test_event_code',
			'pixels.nextdoor.capi.token',
			'pixels.nextdoor.pixel_id',
			'pixels.optimizely.project_id',
			'pixels.outbrain.advertiser_id',
			'pixels.openai.advanced_matching',
			'pixels.openai.capi.token',
			'pixels.reddit.advanced_matching',
			'pixels.reddit.capi.test_event_code',
			'pixels.reddit.capi.token',
			'pixels.rumble.conversion_ids.add_to_cart',
			'pixels.rumble.conversion_ids.purchase',
			'pixels.rumble.tag_id',
			'pixels.applovin.advanced_matching',
			'pixels.applovin.capi.token',
			'pixels.applovin.event_key',
			'pixels.spotify.advanced_matching',
			'pixels.spotify.capi.connection_id',
			'pixels.spotify.capi.token',
			'pixels.spotify.pixel_id',
			'pixels.taboola.account_id',
			'pixels.triple_whale.enabled',
			'pixels.vwo.account_id',

			// Shop
			'shop.disable_tracking_for',
			'shop.ltv.order_calculation.is_active',
			'shop.send_profit_separately',
			'shop.subscription_value_multiplier',

			// Snapchat. The pixel ID is free, the Conversions API is Pro.
			'snapchat.advanced_matching',
			'snapchat.capi.token',

			// TikTok. The pixel ID is free, the Events API is Pro.
			'tiktok.advanced_matching',
			'tiktok.eapi.test_event_code',
			'tiktok.eapi.token',

			// Twitter / X
			'twitter.event_ids.add_payment_info',
			'twitter.event_ids.add_to_cart',
			'twitter.event_ids.add_to_wishlist',
			'twitter.event_ids.initiate_checkout',
			'twitter.event_ids.purchase',
			'twitter.event_ids.search',
			'twitter.event_ids.view_content',
			'twitter.pixel_id',
		];
	}

	/**
	 * Get a nested array value using a dot notation path.
	 *
	 * @param array  $array The array to read from.
	 * @param string $path  Dot notation path (e.g. "facebook.capi.token").
	 *
	 * @return mixed The value, or null if the path does not exist.
	 *
	 * @since 1.59.0
	 */
	private static function get_nested_value( $array, $path ) {

		$current = $array;

		foreach (explode('.', $path) as $key) {

			if (!is_array($current) || !array_key_exists($key, $current)) {
				return null;
			}

			$current = $current[$key];
		}

		return $current;
	}

	/**
	 * Set a nested array value using a dot notation path.
	 *
	 * @param array  $array The array to modify.
	 * @param string $path  Dot notation path (e.g. "facebook.capi.token").
	 * @param mixed  $value The value to set.
	 *
	 * @return array The modified array.
	 *
	 * @since 1.59.0
	 */
	private static function set_nested_value( $array, $path, $value ) {

		$keys    = explode('.', $path);
		$current = &$array;

		foreach ($keys as $i => $key) {

			if (count($keys) - 1 === $i) {
				$current[$key] = $value;
			} else {

				if (!isset($current[$key]) || !is_array($current[$key])) {
					$current[$key] = [];
				}

				$current = &$current[$key];
			}
		}

		return $array;
	}

	public static function validate_ga4_data_api_credentials( $credentials ) {

		$result = self::validate_google_service_account_credentials($credentials);

		if (true !== $result) {
			wp_send_json_error([ 'message' => $result ]);
		}

		return true;
	}

	/**
	 * Validates the shape of a Google Cloud service account credentials JSON
	 * (as pasted by the merchant). Used by the GA4 Data API credential import.
	 *
	 * @param array $credentials The decoded credentials JSON.
	 *
	 * @return true|string True when valid, otherwise the error message.
	 *
	 * @since 1.66.0
	 */
	public static function validate_google_service_account_credentials( $credentials ) {

		// If $credentials is an empty array (thus the default empty value), return true
		if (empty($credentials)) {
			return true;
		}

		if (isset($credentials['type']) && 'service_account' !== $credentials['type']) {
			return 'type is not service_account';
		}

		// Abort if $credentials['project_id'] is not regular string
		if (isset($credentials['project_id']) && !is_string($credentials['project_id'])) {
			return 'project_id is not a string';
		}

		// Abort if $credentials['private_key_id'] is not a private key ID
		if (isset($credentials['private_key_id']) && !is_string($credentials['private_key_id'])) {
			return 'private_key_id is not a string';
		}

		// Abort if $credentials['private_key'] is not a private key
		if (isset($credentials['private_key']) && !is_string($credentials['private_key'])) {
			return 'private_key is not a string';
		}

		// Abort if $credentials['client_email'] is not a client email
		if (isset($credentials['client_email']) && !Helpers::is_email($credentials['client_email'])) {
			return 'client_email is not an email';
		}

		// Abort if $credentials['client_id'] is not empty and not only numbers
		if (
			!empty($credentials['client_id'])
			&& !is_numeric($credentials['client_id'])
		) {
			return 'client_id is not numeric';
		}

		// Abort if $credentials['auth_uri'] is not a valid URL
		if (isset($credentials['auth_uri']) && !Helpers::is_url($credentials['auth_uri'])) {
			return 'auth_uri is not a valid URL';
		}

		// Abort if $credentials['token_uri'] is not a valid URL
		if (isset($credentials['token_uri']) && !Helpers::is_url($credentials['token_uri'])) {
			return 'token_uri is not a valid URL';
		}

		// Abort if $credentials['auth_provider_x509_cert_url'] is not a valid URL
		if (
			isset($credentials['auth_provider_x509_cert_url'])
			&& !Helpers::is_url($credentials['auth_provider_x509_cert_url'])
		) {
			return 'auth_provider_x509_cert_url is not a valid URL';
		}

		// Abort if $credentials['client_x509_cert_url'] is not a valid URL
		if (
			isset($credentials['client_x509_cert_url'])
			&& !Helpers::is_url($credentials['client_x509_cert_url'])
		) {
			return 'client_x509_cert_url is not a valid URL';
		}

		return true;
	}

	/**
	 * Regex validations
	 */

	public static function is_adroll_advertiser_id( $string ) {

		$re = '/^[A-Z0-9]{22}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_adroll_pixel_id( $string ) {

		$re = '/^[A-Z0-9]{22}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_gads_conversion_id( $string ) {

		$re = '/^\d{8,11}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_gads_customer_id( $string ) {

		$re = '/^\d{8,12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_gads_conversion_action_id( $string ) {

		$re = '/^\d{4,16}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_hotjar_site_id( $string ) {

		$re = '/^\d{6,9}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_crazyegg_account_number( $string ) {

		$re = '/^\d{8}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_reddit_advertiser_id( $string ) {

		$re = '/^(a2_|t2_)[a-z0-9]{4,12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_reddit_capi_token( $string ) {

		// Reddit CAPI token is a JWT token with three Base64URL-encoded parts separated by dots
		$re = '/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_reddit_capi_test_event_code( $string ) {

		// Reddit test event code format: t2_ followed by alphanumeric characters
		$re = '/^t2_[a-z0-9]{4,12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_openai_pixel_id( $string ) {

		// OpenAI does not publish a strict pixel ID format. Keep the validation
		// permissive so valid IDs are never rejected, while still blocking
		// obviously malformed input (whitespace, markup, control characters).
		$re = '/^[A-Za-z0-9._-]{6,64}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_openai_capi_token( $string ) {

		// OpenAI Conversions API key (Bearer token). Format is not strictly
		// published, so validate permissively while excluding whitespace/markup.
		$re = '/^[A-Za-z0-9._-]{20,500}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_vwo_account_id( $string ) {

		$re = '/^\d{4,10}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_optimizely_project_id( $string ) {

		$re = '/^\d{8,14}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_ab_tasty_account_id( $string ) {

		$re = '/^[\da-z]{26,38}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_contentsquare_tag_id( $string ) {

		// Contentsquare tag ID format: alphanumeric string like b457e22cc0c6e
		$re = '/^[a-z0-9]{10,20}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_clarity_project_id( $string ) {

		// Microsoft Clarity project ID format: lowercase base36 string, typically
		// 10 characters (e.g. q9zk3x7p2w). Kept slightly permissive so valid IDs
		// are never rejected, while still blocking whitespace, markup and control characters.
		$re = '/^[a-z0-9]{8,15}$/';

		return self::validate_with_regex($re, $string);
	}

	/**
	 * Validate a Mixpanel project token
	 *
	 * Mixpanel project tokens are 32 character hexadecimal strings, taken from
	 * Settings > Project Settings > Project Token in Mixpanel.
	 *
	 * @since 1.64.1
	 *
	 * @param string $string
	 * @return bool
	 */
	public static function is_mixpanel_project_token( $string ) {

		$re = '/^[a-f0-9]{32}$/';

		return self::validate_with_regex($re, $string);
	}

	/**
	 * Validate a Klaviyo public API key
	 *
	 * The public API key, which Klaviyo also calls the Site ID or company ID,
	 * is 6 letters and digits. It is the same pattern the official Klaviyo
	 * plugin validates against.
	 *
	 * @since 1.68.0
	 *
	 * @param string $string
	 * @return bool
	 */
	public static function is_klaviyo_public_api_key( $string ) {

		$re = '/^[a-zA-Z0-9]{6}$/';

		return self::validate_with_regex($re, $string);
	}

	/**
	 * Validate a Klaviyo private API key
	 *
	 * Private keys start with pk_ followed by 34 hex characters. Newer keys
	 * carry a label between the prefix and the hex part. The pattern is the one
	 * the official Klaviyo plugin uses to recognize a private key.
	 *
	 * @since 1.68.0
	 *
	 * @param string $string
	 * @return bool
	 */
	public static function is_klaviyo_events_api_token( $string ) {

		$re = '/^pk_(?:[0-9a-f]{34}|[A-Za-z0-9]+_[0-9a-f]{34})$/';

		return self::validate_with_regex($re, $string);
	}

	/**
	 * Rumble Ads global site tag ID, in the form AV-1234.
	 *
	 * @since 1.72.1
	 *
	 * @param string $string
	 * @return bool
	 */
	public static function is_rumble_tag_id( $string ) {

		// Rumble documents the ID as AV-XXXX. It ends up in the tag URL, so
		// only the prefix plus letters and digits are accepted.
		$re = '/^AV-[A-Za-z0-9]{1,20}$/';

		return self::validate_with_regex($re, $string);
	}

	/**
	 * Rumble Ads conversion action ID, a number.
	 *
	 * @since 1.72.1
	 *
	 * @param string $string
	 * @return bool
	 */
	public static function is_rumble_conversion_id( $string ) {

		$re = '/^\d{1,12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_groundtruth_gtid( $string ) {

		// GroundTruth GTIDs are opaque identifiers. The regex mirrors the validation
		// in GroundTruth's own pixel script (pixel.v2.js), so valid GTIDs are never
		// rejected, while whitespace, markup and control characters are blocked.
		$re = '/^[a-zA-Z0-9_\-]{3,50}$/';

		return self::validate_with_regex($re, $string);
	}

	/**
	 * Pull the Hyros product hash out of whatever the shop pasted into the field.
	 *
	 * Hyros hands out the product hash as the ph query parameter of the Universal
	 * Script, so shops routinely paste the whole script snippet or the script URL
	 * instead of the bare hash. Both are accepted, an empty string is returned when
	 * no hash can be found.
	 *
	 * @since 1.63.1
	 *
	 * @param string $string
	 * @return string
	 */
	public static function extract_hyros_product_hash( $string ) {

		$string = Helpers::trim_string($string);

		if (preg_match('/[?&]ph=([a-zA-Z0-9_\-]+)/', $string, $matches)) {
			return $matches[1];
		}

		return $string;
	}

	/**
	 * Hyros product hashes are opaque identifiers. The regex is kept permissive so
	 * valid hashes are never rejected, while whitespace, markup and control
	 * characters are blocked.
	 *
	 * @since 1.63.1
	 *
	 * @param string $string
	 * @return bool
	 */
	public static function is_hyros_product_hash( $string ) {

		$re = '/^[a-zA-Z0-9_\-]{10,200}$/';

		return self::validate_with_regex($re, $string);
	}

	/**
	 * Hyros application tags are free-form labels, conventionally prefixed with an
	 * exclamation mark (!clicked). They travel in a query string, so only characters
	 * that survive that unescaped are allowed.
	 *
	 * @since 1.63.1
	 *
	 * @param string $string
	 * @return bool
	 */
	public static function is_hyros_application_tag( $string ) {

		$re = '/^[a-zA-Z0-9_!\-]{1,50}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_scroll_tracker_thresholds( $string ) {

		// https://regex101.com/r/4haInV/1
		$re = '/^([\d]|[\d][\d]|100)(,([\d]|[\d][\d]|100))*$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_facebook_capi_token( $string ) {

		$re = '/^[a-zA-Z\d_-]{150,250}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_facebook_capi_test_event_code( $string ) {

		$re = '/^TEST\d{3,7}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_facebook_domain_verification_id( $string ) {

		$re = '/^[a-zA-Z\d]{20,40}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_gads_conversion_label( $string ) {

		$re = '/^[-a-zA-Z_0-9]{17,20}$/';

		return self::validate_with_regex($re, $string);
	}

	//is_google_tag_gateway_measurement_path
	public static function is_google_tag_gateway_measurement_path( $string ) {

		// Create a regex that matches any type of URL path and starts with a slash
		// It may not exceed 100 characters
		// It may not be the root path /
		// It may not contain dashes
		// It may only contain letters, numbers
		// example: /metrics
		// An empty value is valid — it clears the path and disables the gateway.
		if ('' === $string) {
			return true;
		}

		$re = '/^\/[a-zA-Z0-9]{1,100}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_gads_aw_merchant_id( $string ) {

		$re = '/^\d{6,12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_phone_number( $string ) {

		// Accepts various phone number formats:
		// +1-555-555-5555, +1 555 555 5555, +1.555.555.5555, +15555555555
		// (555) 555-5555, 555-555-5555, 555.555.5555, 5555555555
		// International formats with country codes
		$re = '/^[\+]?[\d\s\-\.\(\)]{7,20}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_google_optimize_measurement_id( $string ) {

		$re = '/^(GTM|OPT)-[A-Z0-9]{6,8}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_google_analytics_4_measurement_id( $string ) {

		$re = '/^(G|GT|AW)-[A-Z0-9]{8,12}$/';

		return self::validate_with_regex($re, $string);
	}


	public static function is_google_analytics_4_api_secret( $string ) {

		$re = '/^[a-zA-Z\d_-]{18,26}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_ga4_property_id( $string ) {

		$re = '/^\d{6,12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_facebook_pixel_id( $string ) {

		$re = '/^\d{12,22}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_bing_uet_tag_id( $string ) {

		$re = '/^\d{7,9}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_bing_capi_token( $string ) {

		// The Microsoft Advertising Conversions API token is an opaque bearer
		// token generated in Microsoft Advertising or through the Campaign
		// Management API, so this is deliberately permissive.
		$re = '/^[A-Za-z0-9._~+\/=-]{10,4096}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_linkedin_partner_id( $string ) {

		$re = '/^\d{5,10}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_linkedin_conversion_id( $string ) {

		$re = '/^\d{6,12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_outbrain_account_id( $string ) {

		$re = '/^[\da-z]{30,38}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_pinterest_ad_account_id( $string ) {

		$re = '/^\d{12,13}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_pinterest_apic_token( $string ) {

		$re = '/^pina_[A-Z0-9]{96}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_twitter_pixel_id( $string ) {

		$re = '/^[a-z0-9]{5,7}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_twitter_event_id( $string ) {

		$re = '/^tw-[a-z0-9]{5}-[a-z0-9]{5}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_pinterest_pixel_id( $string ) {

		$re = '/^\d{13}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_snapchat_pixel_id( $string ) {

		$re = '/^[a-z0-9\-]*$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_snapchat_capi_token( $string ) {

		$re = '/^[a-zA-Z0-9\.\-_]{200,600}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_taboola_account_id( $string ) {

		$re = '/^[\d]{4,10}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_criteo_account_id( $string ) {

		// Criteo account IDs (partner IDs) are numeric.
		$re = '/^[\d]{3,10}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_nextdoor_pixel_id( $string ) {

		// Nextdoor pixel IDs are UUIDs.
		$re = '/^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_nextdoor_capi_token( $string ) {

		// The Nextdoor Conversion API token is an opaque bearer token generated
		// in Nextdoor Ads Manager, so this is deliberately permissive.
		$re = '/^[A-Za-z0-9._~+\/=-]{10,4096}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_nextdoor_capi_test_event_code( $string ) {

		// Nextdoor test event identifiers are short alphanumeric flags (e.g. TEST1234).
		$re = '/^[A-Za-z0-9_-]{2,64}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_applovin_event_key( $string ) {

		// AppLovin publishes no format for the event key, which is also the
		// Conversion API's pixel_id. Deliberately permissive: URL-safe
		// characters, sane length.
		$re = '/^[A-Za-z0-9_-]{8,128}$/m';

		return self::validate_with_regex($re, $string);
	}

	public static function is_applovin_capi_token( $string ) {

		// The Conversion API key is an opaque key from the Keys page of the
		// AppLovin dashboard, so this is deliberately permissive.
		$re = '/^[A-Za-z0-9._~+\/=-]{10,4096}$/m';

		return self::validate_with_regex($re, $string);
	}

	public static function is_spotify_pixel_id( $string ) {

		// Spotify Ad Analytics pixel IDs are 32 lowercase hexadecimal characters.
		$re = '/^[a-f0-9]{32}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_spotify_capi_connection_id( $string ) {

		// The Spotify Conversions API connection ID is a UUID.
		$re = '/^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_spotify_capi_token( $string ) {

		// The Spotify Conversions API token is an opaque long-lived bearer token
		// generated in Spotify Ads Manager, so this is deliberately permissive.
		$re = '/^[A-Za-z0-9._~+\/=-]{10,4096}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_tiktok_pixel_id( $string ) {

		$re = '/^[A-Z0-9]{20,20}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function is_tiktok_eapi_access_token( $string ) {

		$re = '/^[\da-z]{30,50}$/';

		return self::validate_with_regex($re, $string);
	}


	public static function is_tiktok_eapi_test_event_code( $string ) {

		$re = '/^TEST\d{3,7}$/';

		return self::validate_with_regex($re, $string);
	}

	public static function validate_with_regex( $re, $string ) {

		if (empty($string)) {
			return true;
		}

		// Validate if string matches the regex $re
		if (preg_match($re, $string)) {
			return true;
		}

		return false;
	}

	/**
	 * Validate if string is a valid conversion name for conversion adjustments.
	 *
	 * It must be a string and not contain any special characters, quotes or single quotes.
	 * Dashes, underscores, spaces, numbers, slashes and letters are allowed.
	 *
	 * @param string $string
	 *
	 * @return bool
	 */
	public static function is_valid_conversion_adjustments_conversion_name( $string ) {

		// Return true if $string is empty
		// To be able to save empty conversion names
		if (empty($string)) {
			return true;
		}

		// Return false if $string is not a string
		if (!is_string($string)) {
			return false;
		}

		// Return false if $string contains any special characters, quotes or single quotes
		if (preg_match('/[^a-zA-Z0-9_\-\/\s]/', $string)) {
			return false;
		}

		return true;
	}

	public static function is_subscription_value_multiplier( $string ) {

		// Return true if $string is a float or integer
		if (!is_numeric($string)) {
			return false;
		}

		// The value must be at least 1.00
		if (floatval($string) < 1.00) {
			return false;
		}

		return true;
	}

	// ─── Single-field validation for REST PATCH ───────────

	/**
	 * Validate and preprocess a single option value by dot-notation path.
	 *
	 * Used by the Nova admin REST PATCH endpoint to apply the same
	 * trim / preprocessing / regex validation that options_validate() does
	 * for the classic form POST.
	 *
	 * @param string $path  Dot-notation path (e.g. "facebook.pixel_id").
	 * @param mixed  $value The value to validate.
	 *
	 * @return array { valid: bool, value: mixed, message?: string }
	 *
	 * @since 1.58.7
	 */
	public static function validate_single_option( $path, $value ) {

		// The value must have the shape of the setting's default. Without this
		// an array sent for a string setting skipped the validator below and
		// was stored as is. @since 1.70.1
		$type_check = self::check_value_type_against_default($path, $value);

		if (!$type_check['valid']) {
			return $type_check;
		}

		$value = $type_check['value'];

		if (0 === strpos($path, 'paused_pixels.')) {
			return [ 'valid' => true, 'value' => self::normalize_pixel_pause_value($value) ];
		}

		// Only validate string values. Booleans, integers and arrays pass through.
		if (!is_string($value)) {
			return [ 'valid' => true, 'value' => $value ];
		}

		// Trim whitespace, quotes, etc.
		$value = Helpers::trim_string($value);

		// Apply path-specific preprocessing (strip prefixes, extract IDs, etc.)
		$value = self::preprocess_value_for_path($path, $value);

		// Look up the validator for this path
		$validators = self::get_field_validators();

		if (!isset($validators[$path])) {
			return [ 'valid' => true, 'value' => $value ];
		}

		$method = $validators[$path][0];
		$error  = $validators[$path][1];

		if (!call_user_func([ self::class, $method ], $value)) {
			return [
				'valid'   => false,
				'value'   => $value,
				'message' => $error,
			];
		}

		return [ 'valid' => true, 'value' => $value ];
	}

	/**
	 * Turn a submitted pause value into the stored Unix timestamp.
	 *
	 * The admin interface sends the time of the pause. An agent or a snippet
	 * may send true or 1 instead, which stamps the current time, and anything
	 * empty or false resumes the pixel. A timestamp in the future is clamped
	 * to now, so the "paused since" reminder can never count backwards.
	 *
	 * @param mixed $value Submitted value.
	 *
	 * @return int Unix timestamp, 0 to resume.
	 *
	 * @since 1.71.1
	 */
	private static function normalize_pixel_pause_value( $value ) {

		if (true === $value) {
			return time();
		}

		if (!is_numeric($value)) {
			return 0;
		}

		$value = (int) $value;

		if ($value <= 0) {
			return 0;
		}

		// 1 and other small numbers mean "pause now", not a date in 1970.
		if ($value < 1000000000) {
			return time();
		}

		return min($value, time());
	}

	/**
	 * Check a value against the type of the setting's default.
	 *
	 * A string setting takes a string, and an integer or float is turned into
	 * its string form so the field validator still runs on it. A boolean or
	 * number setting takes a scalar. A list or empty array setting takes an
	 * array. A branch (a keyed group of settings) is never a single value, so
	 * a caller that writes one must validate it leaf by leaf instead. Paths the
	 * defaults tree does not know are left to the caller.
	 *
	 * @param string $path  Dot-notation path.
	 * @param mixed  $value The value to check.
	 *
	 * @return array { valid: bool, value: mixed, message?: string }
	 *
	 * @since 1.70.1
	 */
	private static function check_value_type_against_default( $path, $value ) {

		$default = self::get_option_default($path, $found);

		if (!$found || null === $default) {
			return [ 'valid' => true, 'value' => $value ];
		}

		$invalid = [
			'valid'   => false,
			'value'   => $value,
			'message' => __('The value has the wrong type for this setting.', 'woocommerce-google-adwords-conversion-tracking-tag'),
		];

		if (self::is_option_branch($default)) {
			return $invalid;
		}

		if (is_array($default)) {
			return is_array($value) ? [ 'valid' => true, 'value' => $value ] : $invalid;
		}

		if (is_string($default)) {

			if (is_int($value) || is_float($value)) {
				$value = (string) $value;
			}

			return is_string($value) ? [ 'valid' => true, 'value' => $value ] : $invalid;
		}

		// Booleans and numbers.
		return is_scalar($value) ? [ 'valid' => true, 'value' => $value ] : $invalid;
	}

	/**
	 * Look up the default of a setting by dot-notation path.
	 *
	 * @param string $path  Dot-notation path.
	 * @param bool   $found Set to whether the path exists in the defaults tree.
	 *
	 * @return mixed The default, or null when the path is unknown.
	 *
	 * @since 1.70.1
	 */
	public static function get_option_default( $path, &$found = null ) {

		$found = false;
		$node  = Options::get_default_options();

		foreach (explode('.', (string) $path) as $key) {
			if (!is_array($node) || !array_key_exists($key, $node)) {
				return null;
			}
			$node = $node[ $key ];
		}

		$found = true;

		return $node;
	}

	/**
	 * Whether a default is a branch: a keyed group of settings rather than a
	 * single value. Lists and empty arrays are values.
	 *
	 * @param mixed $default The default from the defaults tree.
	 *
	 * @return bool
	 *
	 * @since 1.70.1
	 */
	public static function is_option_branch( $default ) {
		return is_array($default) && !empty($default) && !self::is_list($default);
	}

	/**
	 * Apply path-specific preprocessing to a value before regex validation.
	 *
	 * Mirrors the inline preprocessing in options_validate().
	 *
	 * @param string $path  Dot-notation path.
	 * @param string $value Trimmed string value.
	 *
	 * @return string Preprocessed value.
	 *
	 * @since 1.58.7
	 */
	private static function preprocess_value_for_path( $path, $value ) {

		if ('' === $value) {
			return $value;
		}

		switch ($path) {
			case 'google.ads.conversion_id':
				// Strip "AW-" prefix and everything after a slash
				$value = preg_replace('/^AW-/', '', $value);
				$value = preg_replace('/\/.*$/', '', $value);
				break;

			case 'google.ads.conversion_label':
				// If pasted as full tag, extract label after the slash
				$value = preg_replace('/^.*\//', '', $value);
				break;

			case 'google.ads.data_manager.operating_account_id':
			case 'google.ads.data_manager.login_account_id':
				// Google Ads customer IDs are usually displayed as 123-456-7890
				$value = str_replace('-', '', $value);
				break;

			case 'facebook.domain_verification_id':
				// Extract content value from meta tag if pasted
				$value = preg_replace('/^.*content\s*=\s*["\']?([^"\']+?)["\']?\s*\/?\s*>?$/', '$1', $value);
				break;

			case 'crazyegg.account_number':
				// Extract from script URL or strip non-digits
				if (preg_match('/script\.crazyegg\.com\/pages\/scripts\/(\d+)\/(\d+)\.js/', $value, $matches)) {
					$value = $matches[1] . $matches[2];
				} else {
					$value = preg_replace('/\D/', '', $value);
				}
				break;

			case 'pixels.hyros.product_hash':
				// Pull the hash out of a pasted Universal Script snippet or script URL
				$value = self::extract_hyros_product_hash($value);
				break;

			case 'google.tag_gateway.measurement_path':
				// Prefix a slash if missing — but leave an empty value empty so the
				// field can be cleared (an empty path disables the gateway).
				if ('' !== $value && '/' !== substr($value, 0, 1)) {
					$value = '/' . $value;
				}
				break;
		}

		return $value;
	}

	/**
	 * Map of dot-notation paths to their [validator_method, error_message] pairs.
	 *
	 * Also consumed by the Abilities API settings catalog, which surfaces the
	 * error messages as format hints for AI agents.
	 *
	 * @return array<string, array{0: string, 1: string}>
	 *
	 * @since 1.58.7
	 */
	public static function get_field_validators() {

		return [
			// Google Ads
			'google.ads.conversion_id'                          => [ 'is_gads_conversion_id', __('Invalid conversion ID. It should contain 8 to 11 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.ads.conversion_label'                       => [ 'is_gads_conversion_label', __('Invalid Google Ads conversion label.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.ads.aw_merchant_id'                         => [ 'is_gads_aw_merchant_id', __('Invalid Merchant Center ID. It should contain 6 to 12 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.ads.phone_conversion_label'                 => [ 'is_gads_conversion_label', __('Invalid Google Ads conversion label.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.ads.phone_conversion_number'                => [ 'is_phone_number', __('Invalid phone number.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.ads.conversion_adjustments.conversion_name' => [ 'is_valid_conversion_adjustments_conversion_name', __('Invalid conversion name. Special characters and quotes are not allowed.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.ads.data_manager.operating_account_id'      => [ 'is_gads_customer_id', __('Invalid Google Ads customer ID. It should contain 8 to 12 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.ads.data_manager.login_account_id'          => [ 'is_gads_customer_id', __('Invalid Google Ads customer ID. It should contain 8 to 12 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.ads.data_manager.conversion_action_id'      => [ 'is_gads_conversion_action_id', __('Invalid conversion action ID. It should contain only digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Google Analytics 4
			'google.analytics.ga4.measurement_id'               => [ 'is_google_analytics_4_measurement_id', __('Invalid Google Analytics 4 measurement ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.analytics.ga4.api_secret'                   => [ 'is_google_analytics_4_api_secret', __('Invalid Google Analytics 4 API key.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'google.analytics.ga4.data_api.property_id'         => [ 'is_ga4_property_id', __('Invalid GA4 property ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Google Tag Gateway
			'google.tag_gateway.measurement_path'               => [ 'is_google_tag_gateway_measurement_path', __('Invalid measurement path. It should start with / and contain only letters and numbers.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Shop
			'shop.subscription_value_multiplier'                => [ 'is_subscription_value_multiplier', __('Invalid subscription value multiplier. It must be a number and at least 1.00.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Meta (Facebook)
			'facebook.pixel_id'                                 => [ 'is_facebook_pixel_id', __('Invalid Meta (Facebook) pixel ID. It should contain 12 to 22 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'facebook.capi.token'                               => [ 'is_facebook_capi_token', __('Invalid Meta (Facebook) CAPI token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'facebook.capi.test_event_code'                     => [ 'is_facebook_capi_test_event_code', __('Invalid Meta (Facebook) CAPI test event code.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'facebook.domain_verification_id'                   => [ 'is_facebook_domain_verification_id', __('Invalid Meta (Facebook) domain verification ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// TikTok
			'tiktok.pixel_id'                                   => [ 'is_tiktok_pixel_id', __('Invalid TikTok pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'tiktok.eapi.token'                                 => [ 'is_tiktok_eapi_access_token', __('Invalid TikTok Events API access token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'tiktok.eapi.test_event_code'                       => [ 'is_tiktok_eapi_test_event_code', __('Invalid TikTok EAPI test event code.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Microsoft Advertising
			'bing.uet_tag_id'                                   => [ 'is_bing_uet_tag_id', __('Invalid Microsoft Advertising UET tag ID. It should contain 7 to 9 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'bing.capi.token'                                   => [ 'is_bing_capi_token', __('Invalid Microsoft Advertising Conversions API token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// LinkedIn
			'pixels.linkedin.partner_id'                        => [ 'is_linkedin_partner_id', __('Invalid LinkedIn partner ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.linkedin.conversion_ids.view_content'       => [ 'is_linkedin_conversion_id', __('Invalid LinkedIn conversion ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.linkedin.conversion_ids.add_to_cart'        => [ 'is_linkedin_conversion_id', __('Invalid LinkedIn conversion ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.linkedin.conversion_ids.purchase'           => [ 'is_linkedin_conversion_id', __('Invalid LinkedIn conversion ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Pinterest
			'pinterest.pixel_id'                                => [ 'is_pinterest_pixel_id', __('Invalid Pinterest pixel ID. It should contain 13 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pinterest.ad_account_id'                           => [ 'is_pinterest_ad_account_id', __('Invalid Pinterest ad account ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pinterest.apic.token'                              => [ 'is_pinterest_apic_token', __('Invalid Pinterest API token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Snapchat
			'snapchat.pixel_id'                                 => [ 'is_snapchat_pixel_id', __('Invalid Snapchat pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'snapchat.capi.token'                               => [ 'is_snapchat_capi_token', __('Invalid Snapchat CAPI token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// X (Twitter)
			'twitter.pixel_id'                                  => [ 'is_twitter_pixel_id', __('Invalid X (Twitter) pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'twitter.event_ids.add_to_cart'                     => [ 'is_twitter_event_id', __('Invalid X (Twitter) event ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'twitter.event_ids.add_to_wishlist'                 => [ 'is_twitter_event_id', __('Invalid X (Twitter) event ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'twitter.event_ids.view_content'                    => [ 'is_twitter_event_id', __('Invalid X (Twitter) event ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'twitter.event_ids.search'                          => [ 'is_twitter_event_id', __('Invalid X (Twitter) event ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'twitter.event_ids.initiate_checkout'               => [ 'is_twitter_event_id', __('Invalid X (Twitter) event ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'twitter.event_ids.add_payment_info'                => [ 'is_twitter_event_id', __('Invalid X (Twitter) event ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'twitter.event_ids.purchase'                        => [ 'is_twitter_event_id', __('Invalid X (Twitter) event ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Reddit
			'pixels.reddit.advertiser_id'                       => [ 'is_reddit_advertiser_id', __('Invalid Reddit advertiser ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.reddit.capi.token'                          => [ 'is_reddit_capi_token', __('Invalid Reddit CAPI token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.reddit.capi.test_event_code'                => [ 'is_reddit_capi_test_event_code', __('Invalid Reddit CAPI test event code.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// OpenAI
			'pixels.openai.pixel_id'                            => [ 'is_openai_pixel_id', __('Invalid OpenAI pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.openai.capi.token'                          => [ 'is_openai_capi_token', __('Invalid OpenAI CAPI token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Hotjar
			'hotjar.site_id'                                    => [ 'is_hotjar_site_id', __('Invalid Hotjar site ID. It should contain 6 to 9 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// CrazyEgg
			'crazyegg.account_number'                           => [ 'is_crazyegg_account_number', __('Invalid CrazyEgg account number. It must be exactly 8 digits.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// AdRoll
			'pixels.adroll.advertiser_id'                       => [ 'is_adroll_advertiser_id', __('Invalid AdRoll advertiser ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.adroll.pixel_id'                            => [ 'is_adroll_pixel_id', __('Invalid AdRoll pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Outbrain
			'pixels.outbrain.advertiser_id'                     => [ 'is_outbrain_account_id', __('Invalid Outbrain advertiser ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Taboola
			'pixels.taboola.account_id'                         => [ 'is_taboola_account_id', __('Invalid Taboola account ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// AB Tasty
			'pixels.ab_tasty.account_id'                        => [ 'is_ab_tasty_account_id', __('Invalid AB Tasty account ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Optimizely
			'pixels.optimizely.project_id'                      => [ 'is_optimizely_project_id', __('Invalid Optimizely project ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// VWO
			'pixels.vwo.account_id'                             => [ 'is_vwo_account_id', __('Invalid VWO account ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Contentsquare
			'pixels.contentsquare.tag_id'                       => [ 'is_contentsquare_tag_id', __('Invalid Contentsquare tag ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Microsoft Clarity
			'pixels.clarity.project_id'                         => [ 'is_clarity_project_id', __('Invalid Microsoft Clarity project ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// GroundTruth
			'pixels.groundtruth.gtid'                           => [ 'is_groundtruth_gtid', __('Invalid GroundTruth GTID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Rumble Ads
			'pixels.rumble.tag_id'                              => [ 'is_rumble_tag_id', __('Invalid Rumble Ads tag ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.rumble.conversion_ids.purchase'             => [ 'is_rumble_conversion_id', __('Invalid Rumble Ads conversion action ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.rumble.conversion_ids.add_to_cart'          => [ 'is_rumble_conversion_id', __('Invalid Rumble Ads conversion action ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Criteo
			'pixels.criteo.account_id'                          => [ 'is_criteo_account_id', __('Invalid Criteo account ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Nextdoor
			'pixels.nextdoor.pixel_id'                          => [ 'is_nextdoor_pixel_id', __('Invalid Nextdoor pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.nextdoor.capi.token'                        => [ 'is_nextdoor_capi_token', __('Invalid Nextdoor Conversion API token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.nextdoor.capi.test_event_code'              => [ 'is_nextdoor_capi_test_event_code', __('Invalid Nextdoor Conversion API test event code.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.applovin.event_key'                         => [ 'is_applovin_event_key', __('Invalid AppLovin event key.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.applovin.capi.token'                        => [ 'is_applovin_capi_token', __('Invalid AppLovin Conversion API key.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.spotify.pixel_id'                           => [ 'is_spotify_pixel_id', __('Invalid Spotify Ads pixel ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.spotify.capi.connection_id'                 => [ 'is_spotify_capi_connection_id', __('Invalid Spotify Conversions API connection ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.spotify.capi.token'                         => [ 'is_spotify_capi_token', __('Invalid Spotify Conversions API token.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Mixpanel
			'pixels.mixpanel.project_token'                     => [ 'is_mixpanel_project_token', __('Invalid Mixpanel project token. It must be a 32 character hexadecimal string.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Klaviyo
			'pixels.klaviyo.public_api_key'                     => [ 'is_klaviyo_public_api_key', __('Invalid Klaviyo public API key. It must be the 6 character Site ID.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.klaviyo.events_api.token'                   => [ 'is_klaviyo_events_api_token', __('Invalid Klaviyo private API key. It must start with pk_.', 'woocommerce-google-adwords-conversion-tracking-tag') ],

			// Hyros
			'pixels.hyros.product_hash'                         => [ 'is_hyros_product_hash', __('Invalid Hyros product hash.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
			'pixels.hyros.application_tag'                      => [ 'is_hyros_application_tag', __('Invalid Hyros application tag. Only letters, digits, underscores, dashes and the leading exclamation mark are allowed.', 'woocommerce-google-adwords-conversion-tracking-tag') ],
		];
	}
}
