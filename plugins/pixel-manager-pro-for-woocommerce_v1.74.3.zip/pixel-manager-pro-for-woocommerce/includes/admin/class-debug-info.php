<?php

namespace SweetCode\Pixel_Manager\Admin;

use Exception;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Pixels\Facebook\Facebook;
use SweetCode\Pixel_Manager\Pixels\Google\GTG_Monitor;
use SweetCode\Pixel_Manager\Pixels\Pixel_Manager;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\Social_Login;
use SweetCode\Pixel_Manager\Split_Payments;
use SweetCode\Pixel_Manager\Tracking_Accuracy_DB;
use WC_Payment_Gateways;

defined('ABSPATH') || exit; // Exit if accessed directly

class Debug_Info {

	/**
	 * Minimum orders an on-site gateway needs before the blocked beacon check fires.
	 *
	 * @since 1.71.1
	 */
	const BLOCKED_BEACON_MINIMUM_ORDERS = 10;

	public static function get_debug_info() {

		try {
			if (Environment::is_woocommerce_active()) {
				global $woocommerce;
			}

			global $wp_version, $current_user, $hook_suffix;

			$html = '### Debug Information ###' . PHP_EOL . PHP_EOL;

			$html .= '## Pixel Manager Info ##' . PHP_EOL . PHP_EOL;

			$html .= 'Version: ' . PMW_CURRENT_VERSION . PHP_EOL;

			$tier = wpm_fs()->can_use_premium_code__premium_only() ? 'pro' : 'free';

			$html .= 'Tier:    ' . $tier . PHP_EOL;
			$html .= 'Distro:  ' . PMW_DISTRO . PHP_EOL;
			$html .= 'Plugin basename: ' . PMW_PLUGIN_BASENAME . PHP_EOL;

			$script_dependency_warning = \SweetCode\Pixel_Manager\Script_Dependencies::get_warning_message();
			if ($script_dependency_warning) {
				$html .= self::show_warning(true) . 'Front-end script not output: ' . $script_dependency_warning . PHP_EOL;
			}


			// if Freemius is active, show the debug info
			$html = self::add_freemius_account_details($html);

			$html .= PHP_EOL . '## System Environment ##' . PHP_EOL . PHP_EOL;

			$html .= 'WordPress version:   ' . $wp_version . PHP_EOL;
			if (Environment::is_woocommerce_active()) {
				$html .= 'WooCommerce version: ' . $woocommerce->version . PHP_EOL;
			}
			$html .= 'PHP version:         ' . phpversion() . PHP_EOL;
			$html .= PHP_EOL;
			$html .= 'Server max execution time: ' . ini_get('max_execution_time') . ' seconds' . PHP_EOL;

			// show the php.ini file that is being used with full path location
//          $html .= 'php.ini file: ' . php_ini_loaded_file() . PHP_EOL;

			$html .= 'WordPress memory limit:    ' . Environment::get_wp_memory_limit() . PHP_EOL;

			$curl_available        = Environment::is_curl_active() ? 'yes' : 'no';
			$html                 .= 'curl available:                            ' . $curl_available . PHP_EOL;
			$transients_enabled    = Environment::is_transients_enabled();
			$transients_warning    = $transients_enabled ? '' : ' <--------- !!!!! TRANSIENTS DISABLED !!!!!';
			$html                 .= 'Transients enabled:                        ' . ( $transients_enabled ? 'yes' : 'no' ) . $transients_warning . PHP_EOL;
			$external_object_cache = Environment::get_external_object_cache();
			$html                 .= 'External object cache (Redis/Memcached):   ' . $external_object_cache . PHP_EOL;


			// Which of the two REST URL forms the shop serves. The query form
			// (?rest_route=) means the shop runs without pretty permalinks, which
			// WooCommerce doesn't recognize as a REST request, so it boots the
			// session and the cart for plain tracking calls.
			$rest_url      = rest_url();
			$rest_url_form = false !== strpos($rest_url, 'rest_route=') ? 'query string (no pretty permalinks)' : 'path (pretty permalinks)';
			$html         .= 'REST API root:                             ' . $rest_url . PHP_EOL;
			$html         .= 'REST API URL form:                         ' . $rest_url_form . PHP_EOL;

			$html .= PHP_EOL;

			$html .= 'wp_remote_get to Cloudflare:           ' . self::pmw_remote_get_response('https://www.cloudflare.com/cdn-cgi/trace') . PHP_EOL;
//          $html .= 'wp_remote_get to Google Analytics API: ' . self::pmw_remote_get_response('https://www.google-analytics.com/debug/collect') . PHP_EOL;
			$html .= 'wp_remote_post to GA4 Measurement Protocol API: ' . self::pmw_remote_post_response('https://www.google-analytics.com/mp/collect') . PHP_EOL;
			$html .= 'wp_remote_get to Facebook Graph API:   ' . self::pmw_remote_get_response('https://graph.facebook.com/facebook/picture?redirect=false') . PHP_EOL;
//        $html           .= 'wp_remote_post to Facebook Graph API: ' . self::wp_remote_get_response('https://graph.facebook.com/') . PHP_EOL;

			$html .= PHP_EOL;

			// is server behind Cloudflare
			$is_server_behind_cloudflare = Environment::is_server_behind_cloudflare() ? 'yes' : 'no';
			$html                       .= 'Server is behind Cloudflare: ' . $is_server_behind_cloudflare . PHP_EOL;

			$html .= PHP_EOL;

			$multisite_enabled = is_multisite() ? 'yes' : 'no';
			$html             .= 'Multisite enabled:            ' . $multisite_enabled . PHP_EOL;

			$wp_debug = 'no';
			if (defined('WP_DEBUG') && true === WP_DEBUG) {
				$wp_debug = 'yes';
			}

			$html .= 'WordPress debug mode enabled: ' . $wp_debug . PHP_EOL;

//        wp_get_current_user();
			$html .= 'Logged in user login name:    ' . $current_user->user_login . PHP_EOL;
			$html .= 'Logged in user display name:  ' . $current_user->display_name . PHP_EOL;

			$html .= 'hook_suffix:                  ' . $hook_suffix . PHP_EOL;

			$html .= PHP_EOL;

			$html .= 'Hosting provider: ' . Environment::get_hosting_provider() . PHP_EOL;

			// Other plugins that track the same shop explain double or missing
			// events faster than any log. @since 1.69.3
			$other_tracking_plugins = self::get_other_tracking_plugins();
			$html                  .= PHP_EOL . 'Other tracking plugins active: ' . ( empty($other_tracking_plugins) ? 'none detected' : implode(', ', $other_tracking_plugins) ) . PHP_EOL;

			// PMW writes through WooCommerce's logger, so an empty log can be
			// WooCommerce's doing: logging switched off, a level threshold, or
			// a database handler. @since 1.69.3
			$html .= PHP_EOL . '## Logging ##' . PHP_EOL . PHP_EOL . Logger::get_debug_info();

			$html = self::add_facebook_event_setup_info($html);

			$html = self::add_facebook_restricted_events_info($html);

			$html = self::add_facebook_capi_gateway_info($html);

			if (Environment::is_woocommerce_active()) {

				$html .= PHP_EOL . '## WooCommerce ##' . PHP_EOL . PHP_EOL;

				$html .= 'Default currency: ' . get_woocommerce_currency() . PHP_EOL . PHP_EOL;
				$html .= 'Shop URL:         ' . get_home_url() . PHP_EOL;
				$html .= 'Cart URL:         ' . wc_get_cart_url() . PHP_EOL;
				$html .= 'Checkout URL:     ' . wc_get_checkout_url() . PHP_EOL;

				$html .= PHP_EOL;

				$html .= 'Purchase confirmation endpoint: /' . user_trailingslashit(self::get_order_received_endpoint_slug()) . PHP_EOL;

				$order_received_page_url = self::build_order_received_url(wc_get_checkout_url());
				$html                   .= 'is_order_received_page():       ' . $order_received_page_url . PHP_EOL . PHP_EOL;

				if (Environment::does_one_order_exist()) {

					$last_order_url = Environment::get_last_order_url();
					$html          .= 'Last order URL:   ' . $last_order_url . '&nodedupe&pmwloggeron' . PHP_EOL;
					$html          .= 'Last order email: ' . Environment::get_last_order()->get_billing_email() . PHP_EOL;

					$html .= PHP_EOL;


					$last_order_url_contains_order_received_page_url = self::is_url_under_order_received_url($last_order_url, $order_received_page_url) ? 'yes' : 'no';
					$html .= 'Purchase confirmation uses is_order_received(): ' . $last_order_url_contains_order_received_page_url . PHP_EOL;

					$redirect_report = self::get_purchase_confirmation_redirect_report($last_order_url);

					$redirect_hops = [];
					foreach ($redirect_report['chain'] as $hop) {
						$redirect_hops[] = $hop['code'];
					}

					if ($redirect_report['error']) {
						$html .= 'Purchase confirmation page redirect:            could not be tested (' . $redirect_report['error'] . ')' . PHP_EOL;
					} elseif (empty($redirect_report['chain'])) {
						if (200 === $redirect_report['final_code']) {
							$html .= 'Purchase confirmation page redirect:            200 (OK)' . PHP_EOL;
						} else {
							$html .= self::show_warning(true) . 'Purchase confirmation page HTTP status:         ' . $redirect_report['final_code'] . ' (ERROR)' . PHP_EOL;
							$html .= 'Note: Tested server side. Firewalls and bot protection (for example Cloudflare) often block server requests, so verify in a private browser window before concluding that customers get this status.' . PHP_EOL;
						}
					} elseif (
						200 === $redirect_report['final_code']
						&& self::is_order_confirmation_url($redirect_report['final_url'], Environment::get_last_order())
					) {
						$html .= 'Purchase confirmation page redirect:            ' . implode(' -> ', $redirect_hops) . ' -> ' . $redirect_report['final_code'] . ' (OK, ends on the order confirmation page)' . PHP_EOL;
						$html .= 'Final URL:                                      ' . $redirect_report['final_url'] . PHP_EOL;
					} else {
						$html .= self::show_warning(true) . 'Purchase confirmation page redirect:            ' . implode(' -> ', $redirect_hops) . ' -> ' . $redirect_report['final_code'] . ' (ERROR, redirects away from the order confirmation page)' . PHP_EOL;
						$html .= self::show_warning(true) . 'Redirect URL:                                   ' . $redirect_report['final_url'] . PHP_EOL;
						$html .= 'Note: Tested server side. Verify in a private browser window before concluding that customers get redirected.' . PHP_EOL;
					}
				}

				if (wpm_fs()->can_use_premium_code__premium_only()) {
					$html .= PHP_EOL . 'Google Ads Conversion Adjustments feed URL: ' . get_home_url() . Pixel_Manager::get_instance()->get_google_ads_conversion_adjustments_endpoint() . PHP_EOL;
				}

				$split_payments_info = Split_Payments::get_debug_info();

				if ($split_payments_info) {
					$html .= PHP_EOL . '## Split Payments ##' . PHP_EOL . PHP_EOL . $split_payments_info;
				}

				$social_login_info = Social_Login::get_debug_info();

				if ($social_login_info) {
					$html .= PHP_EOL . '## Social Login (Facebook Login ID) ##' . PHP_EOL . PHP_EOL . $social_login_info;
				}

				if (wpm_fs()->can_use_premium_code__premium_only()) {

					$click_id_capture_info = \SweetCode\Pixel_Manager\Click_Ids::get_debug_info();

					if ($click_id_capture_info) {
						$html .= PHP_EOL . '## Click ID Capture Quality ##' . PHP_EOL . PHP_EOL . $click_id_capture_info;
					}

					$html .= PHP_EOL . '## Cookie Delivery ##' . PHP_EOL . PHP_EOL . \SweetCode\Pixel_Manager\Click_Ids::get_cookie_delivery_debug_info();

					$google_dma_info = \SweetCode\Pixel_Manager\Pixels\Google\Google_DMA::get_debug_info();

					if ($google_dma_info) {
						$html .= PHP_EOL . '## Google Ads Conversion Upload ##' . PHP_EOL . PHP_EOL . $google_dma_info;
					}
				}

//        $html                                .= 'wc_get_page_permalink(\'checkout\'): ' . wc_get_page_permalink('checkout') . PHP_EOL;

				$html .= PHP_EOL . '## WooCommerce Payment Gateways ##' . PHP_EOL . PHP_EOL;
				$html .= 'Available payment gateways: ' . PHP_EOL;

				$pg = self::get_payment_gateways();

				// Get the longest string from the array of payment gateways
				$len_id           = strlen('id:');
				$len_method_title = strlen('method_title:');
				$len_class_name   = strlen('class_name:');

				foreach ($pg as $p) {
					$len_id           = max(strlen($p->id), $len_id);
					$len_method_title = max(strlen($p->method_title), $len_method_title);
					$len_class_name   = max(strlen(get_class($p)), $len_class_name);
				}

				$len_id           = $len_id + 2;
				$len_method_title = $len_method_title + 2;
				$len_class_name   = $len_class_name + 2;

				$html .= '  ';
				$html .= str_pad('id:', $len_id);
				$html .= str_pad('method_title:', $len_method_title);
				$html .= str_pad('class:', $len_class_name);
				$html .= PHP_EOL;

				foreach (self::get_payment_gateways() as $gateway) {
					$html .= '  ';
					$html .= str_pad($gateway->id, $len_id);
					$html .= str_pad($gateway->method_title, $len_method_title);
					$html .= str_pad(get_class($gateway), $len_class_name);
					$html .= PHP_EOL;
				}

				$html .= PHP_EOL . 'Purchase confirmation page reached per gateway (active and inactive):' . PHP_EOL;
				$html .= self::get_gateway_analysis_for_debug_info();

				$html .= PHP_EOL . 'Purchase confirmation page reached per gateway only active and weighted by frequency:' . PHP_EOL;
				$html .= self::get_gateway_analysis_weighted_for_debug_info();

				$blocked_beacon_message = self::get_blocked_beacon_message(self::get_blocked_beacon_gateways());
				if ($blocked_beacon_message) {
					$html .= PHP_EOL . self::show_warning(true) . 'Purchase confirmation beacon likely blocked:' . PHP_EOL;
					$html .= wordwrap($blocked_beacon_message, 100, PHP_EOL) . PHP_EOL;
				}

				if (wpm_fs()->can_use_premium_code__premium_only()) {
					$html .= PHP_EOL . 'Automatic Conversion Recovery (ACR):' . PHP_EOL;
					$html .= self::get_acr_analysis_for_debug_info__premium_only() . PHP_EOL;
				}

				if (Environment::is_transients_enabled()) {

					// Time it took to run the payment gateway analysis
					if (get_transient('pmw_tracking_accuracy_analysis_date')) {
						$html .= 'Date of the last payment gateway analysis run: ' . get_transient('pmw_tracking_accuracy_analysis_date') . PHP_EOL;
					}

					// Time it took to run the payment gateway analysis
					if (get_transient('pmw_tracking_accuracy_analysis_time')) {
						$html .= 'Time to generate the payment gateway analysis: ' . round(get_transient('pmw_tracking_accuracy_analysis_time'), 2) . ' seconds' . PHP_EOL;
					}
				}
			}

//        $html .= PHP_EOL;

			$html .= PHP_EOL . '## Google Connection (setup assistant) ##' . PHP_EOL . PHP_EOL;
			$html .= Broker_Client::get_debug_info_text();

			$html .= PHP_EOL . '## Google Tag Gateway ##' . PHP_EOL . PHP_EOL;

			$measurement_path = Options::get_google_tag_gateway_measurement_path();
			$html            .= 'Measurement path:                          ' . ( $measurement_path ? $measurement_path : 'not configured' ) . PHP_EOL;
			$html            .= GTG_Monitor::get_stats_for_debug_info();

			$html .= PHP_EOL . '## Theme ##' . PHP_EOL . PHP_EOL;

			$is_child_theme = is_child_theme() ? 'yes' : 'no';
			$html          .= 'Is child theme:      ' . $is_child_theme . PHP_EOL;
			$theme_support  = current_theme_supports('woocommerce') ? 'yes' : 'no';
			$html          .= 'WooCommerce support: ' . $theme_support . PHP_EOL;

			$html .= PHP_EOL;

			// using the double check prevents problems with some themes that have not implemented
			// the child state correctly
			// https://wordpress.org/support/topic/debug-error-33/
			$theme_description_prefix = ( is_child_theme() && wp_get_theme()->parent() ) ? 'Child theme ' : 'Theme ';

			$html .= $theme_description_prefix . 'Name:       ' . wp_get_theme()->get('Name') . PHP_EOL;
			$html .= $theme_description_prefix . 'ThemeURI:   ' . wp_get_theme()->get('ThemeURI') . PHP_EOL;
			$html .= $theme_description_prefix . 'Author:     ' . wp_get_theme()->get('Author') . PHP_EOL;
			$html .= $theme_description_prefix . 'AuthorURI:  ' . wp_get_theme()->get('AuthorURI') . PHP_EOL;
			$html .= $theme_description_prefix . 'Version:    ' . wp_get_theme()->get('Version') . PHP_EOL;
			$html .= $theme_description_prefix . 'Template:   ' . wp_get_theme()->get('Template') . PHP_EOL;
			$html .= $theme_description_prefix . 'Status:     ' . wp_get_theme()->get('Status') . PHP_EOL;
			$html .= $theme_description_prefix . 'TextDomain: ' . wp_get_theme()->get('TextDomain') . PHP_EOL;
			$html .= $theme_description_prefix . 'DomainPath: ' . wp_get_theme()->get('DomainPath') . PHP_EOL;

			$html .= PHP_EOL;

			// using the double check prevents problems with some themes that have not implemented
			// the child state correctly
			if (is_child_theme() && wp_get_theme()->parent()) {
				$html .= 'Parent theme Name:       ' . wp_get_theme()->parent()->get('Name') . PHP_EOL;
				$html .= 'Parent theme ThemeURI:   ' . wp_get_theme()->parent()->get('ThemeURI') . PHP_EOL;
				$html .= 'Parent theme Author:     ' . wp_get_theme()->parent()->get('Author') . PHP_EOL;
				$html .= 'Parent theme AuthorURI:  ' . wp_get_theme()->parent()->get('AuthorURI') . PHP_EOL;
				$html .= 'Parent theme Version:    ' . wp_get_theme()->parent()->get('Version') . PHP_EOL;
				$html .= 'Parent theme Template:   ' . wp_get_theme()->parent()->get('Template') . PHP_EOL;
				$html .= 'Parent theme Status:     ' . wp_get_theme()->parent()->get('Status') . PHP_EOL;
				$html .= 'Parent theme TextDomain: ' . wp_get_theme()->parent()->get('TextDomain') . PHP_EOL;
				$html .= 'Parent theme DomainPath: ' . wp_get_theme()->parent()->get('DomainPath') . PHP_EOL;
			}

			// TODO maybe add all active plugins

			$html .= PHP_EOL . PHP_EOL . '### End of Information ###';

			return $html;
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	/**
	 * Other Google Analytics, Google Tag Manager and ad pixel plugins that are
	 * active on the site, network-activated ones included. Any of them can send
	 * the same events a second time, or hold back or rewrite the Pixel
	 * Manager's, which is the first thing support needs to know about a shop.
	 *
	 * @return string[] "Name (plugin file)" per active plugin.
	 * @since 1.69.3
	 */
	public static function get_other_tracking_plugins() {

		if (!function_exists('is_plugin_active')) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		// Plugin file => name. Environment's own checks are used where they exist.
		$plugins = [
			'google-analytics-for-wordpress/googleanalytics.php'                                         => 'MonsterInsights',
			'google-analytics-premium/googleanalytics-premium.php'                                       => 'MonsterInsights Pro',
			'google-analytics-dashboard-for-wp/gadwp.php'                                                => 'ExactMetrics',
			'exactmetrics-premium/exactmetrics-premium.php'                                              => 'ExactMetrics Pro',
			'ga-google-analytics/ga-google-analytics.php'                                                => 'GA Google Analytics',
			'duracelltomi-google-tag-manager/duracelltomi-google-tag-manager-for-wordpress.php'          => 'GTM4WP',
			'duracelltomi-google-tag-manager-for-wordpress/duracelltomi-google-tag-manager-for-wordpress.php' => 'GTM4WP',
			'pixelyoursite/facebook-pixel-master.php'                                                    => 'PixelYourSite',
			'pixelyoursite-pro/pixelyoursite-pro.php'                                                    => 'PixelYourSite Pro',
			'google-listings-and-ads/google-listings-and-ads.php'                                        => 'Google for WooCommerce',
			'woocommerce-google-analytics-integration/woocommerce-google-analytics-integration.php'      => 'Google Analytics for WooCommerce',
			'google-site-kit/google-site-kit.php'                                                        => 'Site Kit by Google',
			'facebook-for-woocommerce/facebook-for-woocommerce.php'                                      => 'Facebook for WooCommerce',
			'tiktok-for-business/tiktok-for-woocommerce.php'                                             => 'TikTok for WooCommerce',
			'pinterest-for-woocommerce/pinterest-for-woocommerce.php'                                    => 'Pinterest for WooCommerce',
			'reddit-for-woocommerce/reddit-for-woocommerce.php'                                          => 'Reddit for WooCommerce',
			'enhanced-e-commerce-for-woocommerce-store/enhanced-ecommerce-google-analytics.php'          => 'Conversios',
			'actionable-google-analytics/actionable-google-analytics.php'                                => 'Tatvic Actionable Google Analytics',
			'woocommerce-conversion-tracking/conversion-tracking.php'                                    => 'WooCommerce Conversion Tracking',
			'woocommerce-conversion-tracking-pro/woocommerce-conversion-tracking-pro.php'                => 'WooCommerce Conversion Tracking Pro',
			'facebook-conversion-pixel/facebook-conversion-pixel.php'                                    => 'Pixel Cat',
		];

		$helpers = [
			'google-site-kit/google-site-kit.php'            => [ Environment::class, 'is_google_site_kit_active' ],
			'tiktok-for-business/tiktok-for-woocommerce.php' => [ Environment::class, 'is_tiktok_for_woocommerce_active' ],
		];

		$active = [];

		foreach ($plugins as $file => $name) {

			// is_plugin_active() covers network-activated plugins as well.
			$is_active = isset($helpers[$file]) ? call_user_func($helpers[$file]) : is_plugin_active($file);

			if ($is_active) {
				$active[] = $name . ' (' . $file . ')';
			}
		}

		return $active;
	}

	private static function add_freemius_account_details( $html ) {

		try {

			if (!function_exists('wpm_fs')) {
				return $html;
			}

			global $fs_active_plugins;

			$html .= PHP_EOL . '## Freemius ##' . PHP_EOL . PHP_EOL;

			if (method_exists(wpm_fs(), 'get_user')) {

				$fs_user    = wpm_fs()->get_user();
				$fs_user_id = is_object($fs_user) && property_exists($fs_user, 'id') ? $fs_user->id : 'not found';

				$html .= 'Freemius User ID:     ' . $fs_user_id . PHP_EOL;
			}

			if (method_exists(wpm_fs(), 'get_site')) {

				$fs_site    = wpm_fs()->get_site();
				$fs_site_id = is_object($fs_site) && property_exists($fs_site, 'id') ? $fs_site->id : 'not found';

				$html .= 'Freemius Site ID:     ' . $fs_site_id . PHP_EOL;
			}

			$fs_sdk_bundled_version = property_exists(wpm_fs(), 'version') ? wpm_fs()->version : 'not found';
			$html                  .= 'Freemius SDK bundled: ' . $fs_sdk_bundled_version . PHP_EOL;

			$fs_sdk_active_version = property_exists($fs_active_plugins, 'newest') && property_exists($fs_active_plugins->newest, 'version') ? $fs_active_plugins->newest->version : 'not found';
			$html                 .= 'Freemius SDK active:  ' . $fs_sdk_active_version . PHP_EOL;

			$html .= 'api.freemius.com:     ' . self::try_connect_to_server('https://api.freemius.com') . PHP_EOL;
			$html .= 'wp.freemius.com:      ' . self::try_connect_to_server('https://wp.freemius.com') . PHP_EOL;

			$html .= self::get_freemius_dashboard_page_state();

			return $html;

		} catch (Exception $e) {
			$html .= PHP_EOL . 'Freemius error: ' . $e->getMessage() . PHP_EOL;
		}

		return $html;
	}

	/**
	 * Report whether Freemius' in-dashboard Account page exists on this install.
	 *
	 * The SDK drops that page whenever it sits in activation mode or the install
	 * is white-labelled, and a premium install falls into activation mode on its
	 * own whenever a license activation could not be completed (a site that cannot
	 * reach api.freemius.com, for one), even though the stored license still
	 * unlocks the premium code. Commercial_Links then hands out a fallback URL, so
	 * the "Account & billing" link leaves WordPress and the shop admin loses the
	 * route to their license and to the beta-releases opt-in.
	 *
	 * Nothing about that state is visible from the outside, which is why the
	 * resolved link target is printed next to it.
	 *
	 * Reference: https://secure.helpscout.net/conversation/3435856296
	 *
	 * @return string
	 * @since 1.66.1
	 */
	private static function get_freemius_dashboard_page_state() {

		$fs = wpm_fs();

		$html  = 'Registered:           ' . ( method_exists($fs, 'is_registered') && $fs->is_registered() ? 'yes' : 'no' ) . PHP_EOL;
		$html .= 'Premium code active:  ' . ( Helpers::is_pmw_pro_version_active() ? 'yes' : 'no' ) . PHP_EOL;

		// The sticky flag behind most unexpected activation modes. The SDK raises it
		// when the premium version is activated without an enabled license, and only
		// clears it once a license activation actually goes through.
		$requires_license_activation = 'unknown';

		if (method_exists($fs, 'get_storage')) {
			$storage                     = $fs->get_storage();
			$requires_license_activation = empty($storage->require_license_activation) ? 'no' : 'yes';
		}

		$activation_mode = method_exists($fs, 'is_activation_mode') && $fs->is_activation_mode();

		$html .= 'Activation mode:      ' . ( $activation_mode ? 'yes' : 'no' ) . ' (license activation required: ' . $requires_license_activation . ')' . PHP_EOL;
		$html .= 'Whitelabeled:         ' . ( method_exists($fs, 'is_whitelabeled') && $fs->is_whitelabeled() ? 'yes' : 'no' ) . PHP_EOL;
		$html .= 'Account page:         ' . ( Commercial_Links::has_freemius_dashboard_pages() ? 'available' : 'NOT available' ) . PHP_EOL;
		$html .= 'Account link:         ' . Commercial_Links::account_url() . PHP_EOL;

		return $html;
	}


	/**
	 * Add a report about Meta Event Setup Tool rules to the debug info.
	 *
	 * Meta stores point-and-click Event Setup Tool rules server-side on the
	 * pixel and delivers them to every browser through the public signals
	 * config file. Active rules fire additional events without an event ID
	 * and usually without a value, which corrupts event counts and purchase
	 * values because they cannot be deduplicated against the events the
	 * Pixel Manager sends.
	 *
	 * Reference: https://secure.helpscout.net/conversation/3309525073
	 *
	 * @param string $html
	 * @return string
	 * @since 1.63.1
	 */
	private static function add_facebook_event_setup_info( $html ) {

		try {

			$pixel_ids = Facebook::get_pixel_ids();

			if (empty($pixel_ids)) {
				return $html;
			}

			$html .= PHP_EOL . '## Meta Event Setup Tool ##' . PHP_EOL . PHP_EOL;

			// Meta's automatic configuration can be switched off per pixel. It
			// does not stop the Event Setup Tool rules, which carry their own
			// opt-in, but it is the neighbouring question when reading this
			// section, so report the state here.
			foreach ($pixel_ids as $pixel_id) {

				/**
				 * Filters whether Meta's automatic configuration stays enabled for a pixel.
				 *
				 * @since 1.66.1
				 */
				if (!apply_filters('pmw_facebook_auto_config', true, $pixel_id)) {
					$html .= 'Pixel ' . $pixel_id . ': autoConfig disabled through the pmw_facebook_auto_config filter' . PHP_EOL;
				}
			}

			$results = Facebook_Event_Setup_Scan::get_scan_results(true);

			if (!is_array($results) || empty($results['pixels'])) {
				$html .= 'Scan disabled or no results available.' . PHP_EOL;
				return $html;
			}

			$findings_detected = false;

			foreach ($results['pixels'] as $pixel_id => $pixel) {

				if (!empty($pixel['error'])) {
					$html .= 'Pixel ' . $pixel_id . ': could not be scanned (' . $pixel['error'] . ')' . PHP_EOL;
					continue;
				}

				$event_names     = Facebook_Event_Setup_Scan::get_active_rule_event_names($pixel);
				$extractor_names = Facebook_Event_Setup_Scan::get_extractor_event_names($pixel);

				if (empty($event_names) && empty($extractor_names)) {
					$html .= 'Pixel ' . $pixel_id . ': OK (no active Event Setup Tool rules found)' . PHP_EOL;
					continue;
				}

				$findings_detected = true;

				if (!empty($event_names)) {
					$html .= self::show_warning(true) . 'Pixel ' . $pixel_id . ': ' . count($pixel['active_rules']) . ' active Event Setup Tool rule(s) firing: ' . implode(', ', $event_names) . PHP_EOL;

					// One line per rule, because Meta support needs the rule ID
					// to remove a rule that survived its deletion.
					foreach ($pixel['active_rules'] as $rule) {
						$rule_id = !empty($rule['rule_id']) ? $rule['rule_id'] : 'unknown ID';
						$html   .= '  Rule ' . $rule_id . ' -> ' . $rule['event'] . PHP_EOL;
					}
				}

				if (!empty($extractor_names)) {
					$html .= self::show_warning(true) . 'Pixel ' . $pixel_id . ': Event Setup Tool value extractors configured for: ' . implode(', ', $extractor_names) . PHP_EOL;

					foreach ($pixel['iwl_extractors'] as $extractor) {
						$extractor_id = !empty($extractor['extractor_id']) ? $extractor['extractor_id'] : 'unknown ID';
						$html        .= '  Extractor ' . $extractor_id . ' -> ' . $extractor['event'];
						$html        .= !empty($extractor['url']) ? ' on ' . $extractor['url'] : '';
						$html        .= PHP_EOL;
					}
				}
			}

			if ($findings_detected) {
				$html .= PHP_EOL;
				$html .= 'These rules fire additional browser events without deduplication and mostly without values,' . PHP_EOL;
				$html .= 'which corrupts event counts and purchase values in Meta. Remove them in the Meta Events Manager:' . PHP_EOL;
				$html .= 'Data sources -> select the pixel -> Settings -> Event setup -> Manage' . PHP_EOL;
				$html .= 'The list there is filtered by the URL the Event Setup Tool is opened on, so open it on the' . PHP_EOL;
				$html .= 'URL a rule or extractor is scoped to. Meta also keeps delivering rules that were already' . PHP_EOL;
				$html .= 'deleted. If a rule listed above no longer shows up in the Events Manager, only Meta support' . PHP_EOL;
				$html .= 'can remove it, and they need the IDs above.' . PHP_EOL;
				$html .= 'More information: ' . Documentation::get_link('facebook_event_setup_tool') . PHP_EOL;
			}

			if (!empty($results['scanned_at'])) {
				$html .= 'Scan date: ' . gmdate('Y-m-d H:i:s', $results['scanned_at']) . ' UTC' . PHP_EOL;
			}

			return $html;

		} catch (Exception $e) {
			$html .= PHP_EOL . 'Meta Event Setup Tool scan error: ' . $e->getMessage() . PHP_EOL;
		}

		return $html;
	}

	/**
	 * Add Meta business category event restrictions to the debug info.
	 *
	 * Meta pixels in restricted business categories (e.g. health and wellness)
	 * carry an eventValidation entry with restrictedEventNames in their public
	 * signals config. fbevents.js silently drops those events client-side (no
	 * request to facebook.com/tr) and Meta filters them on the Conversion API
	 * too, while PageView and ViewContent keep working. Merchants then suspect
	 * the Pixel Manager because only the lower funnel events are missing.
	 *
	 * Reference: averyalert.com support case, 2026-07-24
	 *
	 * @param string $html
	 * @return string
	 * @since 1.63.1
	 */
	private static function add_facebook_restricted_events_info( $html ) {

		try {

			$pixel_ids = Facebook::get_pixel_ids();

			if (empty($pixel_ids)) {
				return $html;
			}

			$html .= PHP_EOL . '## Meta Business Category Event Restrictions ##' . PHP_EOL . PHP_EOL;

			$results = Facebook_Event_Setup_Scan::get_scan_results(true);

			if (!is_array($results) || empty($results['pixels'])) {
				$html .= 'Scan disabled or no results available.' . PHP_EOL;
				return $html;
			}

			$restrictions_detected = false;

			foreach ($results['pixels'] as $pixel_id => $pixel) {

				if (!empty($pixel['error'])) {
					$html .= 'Pixel ' . $pixel_id . ': could not be scanned (' . $pixel['error'] . ')' . PHP_EOL;
					continue;
				}

				$restricted_events = !empty($pixel['restricted_events']) ? $pixel['restricted_events'] : [];

				if (empty($restricted_events)) {
					$html .= 'Pixel ' . $pixel_id . ': OK (no restricted events)' . PHP_EOL;
					continue;
				}

				$restrictions_detected = true;

				$html .= self::show_warning(true) . 'Pixel ' . $pixel_id . ': Meta blocks these events for this pixel: ' . implode(', ', $restricted_events) . PHP_EOL;
			}

			if ($restrictions_detected) {
				$html .= PHP_EOL;
				$html .= 'Meta restricts these events because of the business category of the pixel (e.g. health and wellness).' . PHP_EOL;
				$html .= 'fbevents.js silently drops them in the browser and Meta also filters them on the Conversion API,' . PHP_EOL;
				$html .= 'while PageView and ViewContent keep working. This is enforced by Meta and not caused by the Pixel Manager.' . PHP_EOL;
				$html .= 'Review the business category in the Meta Events Manager (Data sources -> select the pixel -> Settings ->' . PHP_EOL;
				$html .= 'Manage data source categories, and Manage event blocking) and request a review if the categorization is wrong.' . PHP_EOL;
				$html .= 'More information: ' . Documentation::get_link('facebook_restricted_events') . PHP_EOL;
			}

			return $html;

		} catch (Exception $e) {
			$html .= PHP_EOL . 'Meta business category restrictions scan error: ' . $e->getMessage() . PHP_EOL;
		}

		return $html;
	}

	/**
	 * Report whether Meta's own Conversions API Gateway (OpenBridge) is connected.
	 *
	 * The gateway is a Meta-hosted relay that copies every event the browser
	 * pixel fires and forwards it to Meta as a second, server-side event. It
	 * runs entirely on Meta's side, so it shows up nowhere in WordPress and
	 * survives removing the plugin that configured it. Together with the Pixel
	 * Manager's Conversions API it puts two server-side senders on one pixel,
	 * which is the standard explanation for a server intake that is roughly
	 * twice the browser intake in Meta Events Manager. It does not double count,
	 * because the mirror carries the browser event's own event ID.
	 *
	 * Reference: https://secure.helpscout.net/conversation/3405785588
	 *
	 * @param string $html
	 * @return string
	 * @since 1.66.0
	 */
	private static function add_facebook_capi_gateway_info( $html ) {

		try {

			$pixel_ids = Facebook::get_pixel_ids();

			if (empty($pixel_ids)) {
				return $html;
			}

			$html .= PHP_EOL . '## Meta Conversions API Gateway ##' . PHP_EOL . PHP_EOL;

			$results = Facebook_Event_Setup_Scan::get_scan_results(true);

			if (!is_array($results) || empty($results['pixels'])) {
				$html .= 'Scan disabled or no results available.' . PHP_EOL;
				return $html;
			}

			$pmw_capi_active = Options::is_facebook_capi_active();
			$gateway_found   = false;

			foreach ($results['pixels'] as $pixel_id => $pixel) {

				if (!empty($pixel['error'])) {
					$html .= 'Pixel ' . $pixel_id . ': could not be scanned (' . $pixel['error'] . ')' . PHP_EOL;
					continue;
				}

				if (empty($pixel['openbridge']['active'])) {
					$html .= 'Pixel ' . $pixel_id . ': OK (no gateway connected)' . PHP_EOL;
					continue;
				}

				$gateway_found = true;

				$html .= self::show_warning(true) . 'Pixel ' . $pixel_id . ': Meta Conversions API Gateway connected' . PHP_EOL;
				$html .= '  Endpoints: ' . implode(', ', $pixel['openbridge']['endpoints']) . PHP_EOL;
				$html .= '  Mirrored events: ' . (
					!empty($pixel['openbridge']['mirrored_events'])
						? implode(', ', $pixel['openbridge']['mirrored_events'])
						: 'none of the events the Pixel Manager sends'
				) . PHP_EOL;
			}

			$pmw_capi_state = $pmw_capi_active ? 'active' : 'inactive';

			$html .= PHP_EOL . 'Pixel Manager Conversions API: ' . $pmw_capi_state . PHP_EOL;

			if ($gateway_found) {
				$html .= PHP_EOL;

				if ($pmw_capi_active) {
					$html .= 'Two server-side senders are active on this pixel. Every browser event is mirrored by the' . PHP_EOL;
					$html .= 'gateway into the server channel, so the raw server intake in Events Manager is roughly twice' . PHP_EOL;
					$html .= 'the browser intake. Conversions are NOT double counted: the mirror carries the browser' . PHP_EOL;
					$html .= 'event\'s own event ID, so Meta deduplicates the pair (verify under Event match quality ->' . PHP_EOL;
					$html .= 'Additional conversions reported).' . PHP_EOL;
				} else {
					$html .= 'The gateway is the only server-side sender here, because the Pixel Manager\'s Conversions API' . PHP_EOL;
					$html .= 'is not active. It only mirrors events the browser pixel already sent, so orders where the' . PHP_EOL;
					$html .= 'browser pixel was blocked are not covered.' . PHP_EOL;
				}

				$html .= PHP_EOL;
				$html .= 'Disconnect it in the Meta Events Manager (Data sources -> select the pixel -> Settings ->' . PHP_EOL;
				$html .= 'Conversions API Gateway) and keep the Pixel Manager\'s Conversions API, which sends once per' . PHP_EOL;
				$html .= 'paid order from the server and therefore also covers blocked browsers.' . PHP_EOL;
				$html .= 'More information: ' . Documentation::get_link('facebook_capi_gateway') . PHP_EOL;
			}

			return $html;

		} catch (Exception $e) {
			$html .= PHP_EOL . 'Meta Conversions API Gateway scan error: ' . $e->getMessage() . PHP_EOL;
		}

		return $html;
	}

	public static function run_tracking_accuracy_analysis() {

		// Skip the nightly batch when the event-driven DB table has data
		if (Tracking_Accuracy_DB::has_data()) {
			return;
		}

		// Start measuring time
		$start_time = microtime(true);

		$maximum_orders_to_analyze = self::get_maximum_orders_to_analyze();

		// We want to at least analyze the count of active gateways * 100, or at least all orders in the past 30 days, whichever is larger.
		// And we don't want to exceed the maximum orders to analyze (default 6000).
		$amount_of_orders_to_analyze = min(
			$maximum_orders_to_analyze,
			max(
				count(self::get_active_payment_gateway_ids()) * 100,
				self::get_count_of_pmw_tracked_orders_for_one_month()
			)
		);

		$analysis_stored = self::generate_gateway_analysis( $amount_of_orders_to_analyze );

		// set transient with date
		set_transient('pmw_tracking_accuracy_analysis_date', gmdate('Y-m-d H:i:s'), MONTH_IN_SECONDS);

		// End measuring time
		$end_time = microtime(true);
		set_transient('pmw_tracking_accuracy_analysis_time', ( $end_time - $start_time ), MONTH_IN_SECONDS);

		// Only clear the running guard if the analysis results were persisted successfully.
		// If transient storage failed, keep the guard set so the next run retries with a reduced cap.
		if ( $analysis_stored ) {
			delete_transient('pmw_tracking_accuracy_analysis_running');
		}
	}

	// If the analysis runs into a timout we lower the amount of orders to analyze.
	protected static function get_maximum_orders_to_analyze() {

		if (get_transient('pmw_tracking_accuracy_analysis_running')) { // If available means that last run failed or timed out.
			$last_maximum_orders_to_analyze = get_transient('pmw_tracking_accuracy_analysis_max_orders') ? get_transient('pmw_tracking_accuracy_analysis_max_orders') : self::get_default_maximum_orders_to_analyse();
			$maximum_orders_to_analyze      = max(intval($last_maximum_orders_to_analyze * 0.8), 100);
		} elseif (get_transient('pmw_tracking_accuracy_analysis_max_orders')) {

			/**
			 * We are increasing the max amount with every run a little
			 * in order to counteract possible bailouts due to other reasons than timeouts,
			 * that otherwise would only lower the max amount with each error until
			 * the max amount reaches the minimum and stays at the minimum forever.
			 * */

			$maximum_orders_to_analyze = min(
				intval(get_transient('pmw_tracking_accuracy_analysis_max_orders') * 1.01),
				self::get_default_maximum_orders_to_analyse()
			);
		} else {
			// Default value
			$maximum_orders_to_analyze = self::get_default_maximum_orders_to_analyse();
		}

		$maximum_orders_to_analyze = min(
			/**
			 * Use the smaller of the two values. Either the user override or the calculated value.
			 *
			 * @since 1.58.5
			 */
			apply_filters('pmw_tracking_accuracy_analysis_max_order_amount', $maximum_orders_to_analyze),
			$maximum_orders_to_analyze
		);

		// Set the running lock with 60-minute expiration to prevent permanent locks
		// if the analysis crashes or times out, while giving enough headroom for
		// large shops with slow databases.
		set_transient('pmw_tracking_accuracy_analysis_running', true, HOUR_IN_SECONDS);

		// Store max orders with expiration to match the analysis data lifecycle
		set_transient('pmw_tracking_accuracy_analysis_max_orders', $maximum_orders_to_analyze, MONTH_IN_SECONDS);

		return $maximum_orders_to_analyze;
	}

	protected static function get_default_maximum_orders_to_analyse() {
		return 3000;
	}

	public static function get_gateway_analysis_for_debug_info() {

		if (!Environment::is_transients_enabled()) {
			return PHP_EOL . self::return_transients_deactivated_text() . PHP_EOL;
		}

		if (self::get_gateway_analysis_array() === false) {
			return self::tracking_accuracy_loading_message() . PHP_EOL;
		}

		$per_gateway_analysis = self::get_gateway_analysis_array();

		$html = '';

		$order_count_total    = 0;
		$order_count_measured = 0;

		foreach ($per_gateway_analysis as $analysis) {

			$order_count_total    += $analysis['order_count_total'];
			$order_count_measured += $analysis['order_count_measured'];

			$html .= '  ';
			$html .= str_pad($analysis['order_count_measured'], 3) . ' of ';
			$html .= str_pad($analysis['order_count_total'], 3) . ' = ';
			$html .= str_pad(Helpers::get_percentage($analysis['order_count_measured'], $analysis['order_count_total']) . '%', 5);
			$html .= 'for ' . $analysis['gateway_id'];

			$html .= PHP_EOL;
		}

		return $html;
	}

	public static function get_gateway_analysis_weighted_for_debug_info() {

		if (!Environment::is_transients_enabled()) {
			return PHP_EOL . self::return_transients_deactivated_text() . PHP_EOL;
		}

		if (self::get_gateway_analysis_weighted_array() === false) {
			return self::tracking_accuracy_loading_message() . PHP_EOL;
		}

		$per_gateway_analysis = self::get_gateway_analysis_weighted_array();

		$html = '';

		$order_count_total    = 0;
		$order_count_measured = 0;

		foreach ($per_gateway_analysis as $analysis) {

			$order_count_total    += $analysis['order_count_total'];
			$order_count_measured += $analysis['order_count_measured'];

			$html .= '  ';
			$html .= str_pad($analysis['order_count_measured'], 4) . ' of ';
			$html .= str_pad($analysis['order_count_total'], 4) . ' = ';
			$html .= str_pad($analysis['percentage'] . '%', 4);
			$html .= ' for ' . $analysis['gateway_id'];
			$html .= PHP_EOL;
		}

		$html .= '  ' . str_pad($order_count_measured, 4) . ' of ' . str_pad($order_count_total, 4) . ' = ';

		$html .= Helpers::get_percentage($order_count_measured, $order_count_total) . '%' . str_pad('', 6) . 'total';

		$html .= PHP_EOL;

		return $html;
	}

	public static function get_acr_analysis_for_debug_info__premium_only() {

		if (!Environment::is_transients_enabled()) {
			return PHP_EOL . self::return_transients_deactivated_text() . PHP_EOL;
		}

		if (self::get_gateway_analysis_weighted_array() === false) {
			return self::tracking_accuracy_loading_message() . PHP_EOL;
		}

		$per_gateway_analysis = self::get_gateway_analysis_weighted_array();

		$order_count_total    = 0;
		$order_count_measured = 0;
		$missing_conversions  = 0;
		$acr_total_recovered  = 0;

		$html = '';

		foreach ($per_gateway_analysis as $gateway_analysis) {

			// if $gateway_analysis['order_count_measured_including_acr'] or $gateway_analysis['percentage_including_acr_recovered'] are not set
			// return following text in the HTML "collecting data..."
			if (!isset($gateway_analysis['order_count_measured_including_acr']) || !isset($gateway_analysis['percentage_including_acr_recovered'])) {
				return 'collecting data...' . PHP_EOL;
			}

			$order_count_total    += $gateway_analysis['order_count_total'];
			$order_count_measured += $gateway_analysis['order_count_measured_including_acr'];
			$missing_conversions  += $gateway_analysis['order_count_total'] - $gateway_analysis['order_count_measured'];
			$acr_total_recovered  += $gateway_analysis['acr_recovered'];

			$html .= '  ';
			$html .= str_pad($gateway_analysis['order_count_measured_including_acr'] . ' (' . $gateway_analysis['acr_recovered'] . ')', 8) . ' of ';
			$html .= str_pad($gateway_analysis['order_count_total'], 4) . ' = ';
			$html .= str_pad($gateway_analysis['percentage_including_acr_recovered'] . '%', 4);
			$html .= ' for ' . $gateway_analysis['gateway_id'];

			$html .= PHP_EOL;
		}

		$html .= '  ';
		$html .= str_pad($order_count_measured . ' (' . $acr_total_recovered . ')', 8);
		$html .= ' of ';
		$html .= str_pad($order_count_total, 4);
		$html .= ' = ';
		$html .= str_pad(Helpers::get_percentage($order_count_measured, $order_count_total) . '%', 4);
		$html .= '     total';

		$html .= PHP_EOL . PHP_EOL . '  ACR recovered ' . $acr_total_recovered . ' (' . Helpers::get_percentage($acr_total_recovered, $missing_conversions) . '%) out of ' . $missing_conversions . ' missing conversions.';

		$html .= PHP_EOL;

		return $html;
	}

	public static function get_gateway_analysis_array() {

		// Prefer the custom DB table when it has data
		if (Tracking_Accuracy_DB::has_data()) {
			$rows = Tracking_Accuracy_DB::get_accuracy_data(30);

			if (!empty($rows)) {
				$result = [];

				foreach ($rows as $row) {
					$measured = $row['orders_measured'] + $row['orders_acr'];

					$result[] = [
						'gateway_id'           => $row['gateway_id'],
						'order_count_total'    => $row['orders_total'],
						'order_count_measured' => $measured,
						'percentage'           => floor(Helpers::get_percentage($measured, $row['orders_total'])),
					];
				}

				return $result;
			}
		}

		// Fall back to transient during transition period
		if (get_transient('pmw_tracking_accuracy_analysis')) {
			return get_transient('pmw_tracking_accuracy_analysis');
		}

		return false;
	}

	public static function generate_gateway_analysis_array() {
		// Legacy method — now handled by generate_gateway_analysis()
		// Kept as no-op for backward compatibility if called externally
	}

	public static function get_gateway_analysis_weighted_array() {

		// Prefer the custom DB table when it has data
		if (Tracking_Accuracy_DB::has_data()) {
			$enabled_ids = self::get_active_payment_gateway_ids();

			if (!empty($enabled_ids)) {
				$rows = Tracking_Accuracy_DB::get_accuracy_data(30, $enabled_ids);

				if (!empty($rows)) {
					$result = [];

					foreach ($rows as $row) {
						$entry = [
							'gateway_id'           => $row['gateway_id'],
							'order_count_total'    => $row['orders_total'],
							'order_count_measured' => $row['orders_measured'],
							'percentage'           => floor(Helpers::get_percentage($row['orders_measured'], $row['orders_total'])),
						];

						if (wpm_fs()->can_use_premium_code__premium_only()) {
							$measured_including_acr = $row['orders_measured'] + $row['orders_acr'];
							$missing                = $row['orders_total'] - $row['orders_measured'];

							$entry['acr_recovered']                        = $row['orders_acr'];
							$entry['order_count_measured_including_acr']   = $measured_including_acr;
							$entry['percentage_including_acr_recovered']   = floor(Helpers::get_percentage($measured_including_acr, $row['orders_total']));
							$entry['percentage_acr_recovered_conversions'] = floor(Helpers::get_percentage($row['orders_acr'], $missing));
							$entry['acr_total_time_to_recovery']           = 0;
						}

						$result[] = $entry;
					}

					return $result;
				}
			}
		}

		// Fall back to transient during transition period
		if (get_transient('pmw_tracking_accuracy_analysis_weighted')) {
			return get_transient('pmw_tracking_accuracy_analysis_weighted');
		}

		return false;
	}

	/**
	 * IDs of payment gateways that take the payment on the shop's own checkout.
	 *
	 * The customer never leaves the shop, so a missing return redirect cannot
	 * explain an order that never reached the purchase confirmation page.
	 * Cards and wallets only: the redirect methods of the same plugins
	 * (stripe_ideal, woocommerce_payments_bancontact, ...) are left out.
	 *
	 * @return string[]
	 * @since 1.71.1
	 */
	public static function get_onsite_payment_gateway_ids() {

		$ids = [
			'bacs',
			'cheque',
			'cod',
			'stripe',
			'stripe_cc',
			'stripe_applepay',
			'stripe_googlepay',
			'woocommerce_payments',
			'ppcp-credit-card-gateway',
			'square_credit_card',
			'braintree_credit_card',
			'authorize_net_cim_credit_card',
		];

		/**
		 * Filters the payment gateway IDs that are treated as on-site gateways
		 * by the blocked confirmation beacon check in the tracking accuracy report.
		 *
		 * @param string[] $ids Gateway IDs.
		 * @since 1.71.1
		 */
		return (array) apply_filters('pmw_onsite_payment_gateway_ids', $ids);
	}

	/**
	 * Detect a blocked purchase confirmation beacon from the accuracy rows.
	 *
	 * Fires when at least one on-site gateway has BLOCKED_BEACON_MINIMUM_ORDERS
	 * or more orders and none of them was measured, while no active gateway
	 * measured a single order. A redirect cannot explain that, because the
	 * customer of an on-site gateway never leaves the shop. What remains is the
	 * beacon request being blocked, or the main script never running on the
	 * order received page. One gateway at 0% while others measure points at a
	 * gateway specific problem instead, so that case does not fire.
	 *
	 * Uses the beacon-only count (order_count_measured), not the count including
	 * conversions recovered by ACR, because ACR succeeds without the beacon.
	 *
	 * @param array $rows Weighted gateway analysis rows (see get_gateway_analysis_weighted_array()).
	 * @return array List of affected rows ([ 'gateway_id', 'order_count_total' ]), empty when the check does not fire.
	 * @since 1.71.1
	 */
	public static function detect_blocked_beacon( $rows ) {

		if (!is_array($rows) || empty($rows)) {
			return [];
		}

		$onsite_ids = self::get_onsite_payment_gateway_ids();
		$affected   = [];

		foreach ($rows as $row) {

			if (!isset($row['gateway_id'], $row['order_count_total'], $row['order_count_measured'])) {
				continue;
			}

			// The beacon worked at least once in the window, so it is not blocked.
			if ((int) $row['order_count_measured'] > 0) {
				return [];
			}

			if (
				in_array($row['gateway_id'], $onsite_ids, true)
				&& (int) $row['order_count_total'] >= self::BLOCKED_BEACON_MINIMUM_ORDERS
			) {
				$affected[] = [
					'gateway_id'        => (string) $row['gateway_id'],
					'order_count_total' => (int) $row['order_count_total'],
				];
			}
		}

		return $affected;
	}

	/**
	 * Affected on-site gateways when the confirmation beacon looks blocked.
	 *
	 * @return array See detect_blocked_beacon().
	 * @since 1.71.1
	 */
	public static function get_blocked_beacon_gateways() {

		if (!Environment::is_transients_enabled()) {
			return [];
		}

		return self::detect_blocked_beacon(self::get_gateway_analysis_weighted_array());
	}

	/**
	 * Plain text explanation of a blocked confirmation beacon.
	 *
	 * Shared by the debug info, the Diagnostics tab and the accuracy opportunity
	 * card so that all three say the same thing.
	 *
	 * @param array $affected Rows returned by detect_blocked_beacon().
	 * @return string Empty when nothing is affected.
	 * @since 1.71.1
	 */
	public static function get_blocked_beacon_message( $affected ) {

		if (empty($affected)) {
			return '';
		}

		$gateways = [];
		foreach ($affected as $row) {
			$gateways[] = $row['gateway_id'] . ' (0 of ' . $row['order_count_total'] . ')';
		}

		return sprintf(
			/* translators: 1: list of payment gateways with their order counts, 2: REST route of the beacon, 3: admin-ajax action of the fallback */
			__(
				'Not a single order was measured on the purchase confirmation page, including orders paid with on-site payment gateways: %1$s. With these gateways the customer never leaves the shop, so a payment redirect cannot explain the gap. The likely cause is that the order confirmation beacon (%2$s, with the admin-ajax fallback %3$s) is blocked by a firewall (WAF), bot protection or cache rule, or that the main Pixel Manager script does not execute on the order received page, for example because it is served with a wrong content type or encoding, or an optimization plugin breaks it. Place a test order and check in the browser developer tools on the order received page that the Pixel Manager scripts load without errors and that the beacon request returns HTTP 200.',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			implode(', ', $gateways),
			'/wp-json/pmw/v1/pixels-fired/',
			'pmw_purchase_pixels_fired'
		);
	}


	/**
	 * Generate both unweighted and weighted gateway analysis in a single pass.
	 *
	 * Fetches order IDs (not full objects) and bulk-loads only the meta fields
	 * needed for the analysis. Computes per-gateway stats for:
	 * - Unweighted: all gateways (active + inactive) with up to 100 orders each
	 * - Weighted: only currently enabled gateways, all orders
	 *
	 * @param int $limit Maximum number of orders to analyze.
	 * @return void
	 * @since 1.58.5
	 */
	public static function generate_gateway_analysis( $limit ) {

		$enabled_ids = self::get_active_payment_gateway_ids();

		// Initialize weighted analysis for active gateways (enabled, or with recent orders)
		$weighted = [];
		foreach ( $enabled_ids as $gateway_id ) {
			$weighted[ $gateway_id ] = [
				'gateway_id'           => $gateway_id,
				'order_count_measured' => 0,
				'order_count_total'    => 0,
				'percentage'           => 0,
			];

			if ( wpm_fs()->can_use_premium_code__premium_only() ) {
				$weighted[ $gateway_id ]['acr_recovered']                        = 0;
				$weighted[ $gateway_id ]['order_count_measured_including_acr']   = 0;
				$weighted[ $gateway_id ]['percentage_including_acr_recovered']   = 0;
				$weighted[ $gateway_id ]['percentage_acr_recovered_conversions'] = 0;
				$weighted[ $gateway_id ]['acr_total_time_to_recovery']           = 0;
			}
		}

		// Initialize unweighted analysis — tracks per-gateway counts capped at 100
		$unweighted        = [];
		$unweighted_counts = []; // tracks how many orders counted per gateway for the 100-cap

		// Get order IDs (not full objects)
		$order_ids = self::get_pmw_tracked_orders( $limit );

		// Bulk-fetch all required meta in one query
		$orders_meta = self::get_bulk_order_meta( $order_ids );

		// Single pass over all orders
		foreach ( $order_ids as $order_id ) {

			if ( ! isset( $orders_meta[ $order_id ] ) ) {
				continue;
			}

			$meta           = $orders_meta[ $order_id ];
			$payment_method = $meta['payment_method'];

			if ( empty( $payment_method ) ) {
				continue;
			}

			// --- Weighted analysis (enabled gateways only) ---
			if ( in_array( $payment_method, $enabled_ids, true ) ) {

				++$weighted[ $payment_method ]['order_count_total'];

				if ( $meta['conversion_pixel_fired'] ) {
					++$weighted[ $payment_method ]['order_count_measured'];

					if ( wpm_fs()->can_use_premium_code__premium_only() ) {
						++$weighted[ $payment_method ]['order_count_measured_including_acr'];

						if (
							null !== $meta['conversion_pixel_trigger']
							&& 'thankyou_page' !== $meta['conversion_pixel_trigger']
						) {
							++$weighted[ $payment_method ]['acr_recovered'];
							--$weighted[ $payment_method ]['order_count_measured'];
						}
					}
				}
			}

			// --- Unweighted analysis (all gateways, capped at 100 per gateway) ---
			if ( ! isset( $unweighted_counts[ $payment_method ] ) ) {
				$unweighted_counts[ $payment_method ] = 0;
				$unweighted[ $payment_method ]        = [
					'gateway_id'           => $payment_method,
					'order_count_total'    => 0,
					'order_count_measured' => 0,
					'percentage'           => 0,
				];
			}

			if ( $unweighted_counts[ $payment_method ] < 100 ) {
				++$unweighted[ $payment_method ]['order_count_total'];
				++$unweighted_counts[ $payment_method ];

				if ( $meta['conversion_pixel_fired'] ) {
					++$unweighted[ $payment_method ]['order_count_measured'];
				}
			}
		}

		// Calculate percentages for weighted
		foreach ( $weighted as $gateway_id => $data ) {
			$weighted[ $gateway_id ]['percentage'] = floor( Helpers::get_percentage( $data['order_count_measured'], $data['order_count_total'] ) );

			if ( wpm_fs()->can_use_premium_code__premium_only() ) {
				$weighted[ $gateway_id ]['percentage_including_acr_recovered']
					= floor( Helpers::get_percentage( $data['order_count_measured_including_acr'], $data['order_count_total'] ) );

				$weighted[ $gateway_id ]['percentage_acr_recovered_conversions']
					= floor( Helpers::get_percentage(
					$data['acr_recovered'],
					$data['order_count_total'] - $data['order_count_measured']
				) );
			}
		}

		// Sort weighted by order_count_total descending
		usort( $weighted, function ( $a, $b ) {
			return $b['order_count_total'] - $a['order_count_total'];
		} );

		// Calculate percentages for unweighted
		foreach ( $unweighted as $gateway_id => $data ) {
			$unweighted[ $gateway_id ]['percentage'] = floor( Helpers::get_percentage( $data['order_count_measured'], $data['order_count_total'] ) );
		}

		// Convert unweighted to indexed array
		$unweighted = array_values( $unweighted );

		$result_unweighted = self::set_transient_with_verification( 'pmw_tracking_accuracy_analysis', $unweighted, MONTH_IN_SECONDS );
		$result_weighted   = self::set_transient_with_verification( 'pmw_tracking_accuracy_analysis_weighted', $weighted, MONTH_IN_SECONDS );

		// If either transient failed to persist, keep the running guard set so the
		// next scheduled run treats this as a failure and retries.
		if ( ! $result_unweighted || ! $result_weighted ) {
			return false;
		}

		return true;
	}

	/**
	 * Generate gateway analysis weighted array.
	 *
	 * @deprecated 1.58.5 Use generate_gateway_analysis() instead. Kept for backward compatibility.
	 */
	public static function generate_gateway_analysis_weighted_array( $limit ) {
		self::generate_gateway_analysis( $limit );
	}

	/**
	 * Possible way to use a proxy if necessary
	 * https://deliciousbrains.com/php-curl-how-wordpress-makes-http-requests/
	 * possible proxy list
	 * https://www.us-proxy.org/
	 * https://freemius.com/help/documentation/wordpress-sdk/license-activation-issues/#isp_blockage
	 *
	 * Google and Facebook might block free proxy requests
	 */

	private static function pmw_remote_get_response( $url ) {
		$response = wp_remote_get($url, [
			'timeout'             => 4,
			'sslverify'           => HTTP::should_verify_ssl(),
			'limit_response_size' => 5000,
			'blocking'            => true,    // We need to wait to see if we get a server response 200
			'redirection'         => 0,      // We don't want to follow redirects
		]);

		if (is_wp_error($response)) {
			return self::show_warning(true) . $response->get_error_message();
		} else {
			$response_code = wp_remote_retrieve_response_code($response);

			if (200 === $response_code) {
				return $response_code;
			} else {
				return self::show_warning(true) . $response_code;
			}
		}
	}

	/**
	 *  Test if a server is reachable, no matter what response code, using wp_remote_post
	 *
	 * @param $url
	 * @return int|string
	 */
	private static function pmw_remote_post_response( $url ) {
		$response = wp_remote_post($url, [
			'timeout'             => 4,
			'sslverify'           => HTTP::should_verify_ssl(),
			'limit_response_size' => 5000,
			'blocking'            => true,    // We need to wait to see if we get a server response 200
			'redirection'         => 0,      // We don't want to follow redirects
		]);

		if (is_wp_error($response)) {
			return self::show_warning(true) . $response->get_error_message();
		}

		$response_code = wp_remote_retrieve_response_code($response);

		if ($response_code >= 200 && $response_code < 300) {
			return $response_code;
		}

		return self::show_warning(true) . $response_code;
	}

	/**
	 * Follow the redirect chain of the purchase confirmation URL hop by hop.
	 *
	 * The request mimics a regular browser (user agent, Accept headers, the shop locale)
	 * because WAFs, bot protection and language plugins answer redirects to the default
	 * WordPress user agent that real visitors never see.
	 *
	 * @param string $url
	 * @return array {
	 *     error:      string  Error message if the test could not be completed, empty otherwise.
	 *     chain:      array   One entry per redirect hop: [ 'code' => int, 'to' => string ].
	 *     final_url:  string  The last URL that was requested.
	 *     final_code: int     The HTTP status code of the final response, 0 on error.
	 * }
	 */
	private static function get_purchase_confirmation_redirect_report( $url ) {

		$report = [
			'error'      => '',
			'chain'      => [],
			'final_url'  => $url,
			'final_code' => 0,
		];

		$max_hops    = 5;
		$current_url = $url;

		for ($hop = 0; $hop <= $max_hops; $hop++) {

			$response = wp_remote_get($current_url, [
				'timeout'             => 4,
				'sslverify'           => HTTP::should_verify_ssl(),
				'limit_response_size' => 5000,
				'blocking'            => true,    // We need to wait to see if we get a server response 200
				'redirection'         => 0,       // Follow redirects manually so we can inspect each hop
				'user-agent'          => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
				'headers'             => [
					'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
					'Accept-Language' => str_replace('_', '-', get_locale()),
				],
			]);

			if (is_wp_error($response)) {
				$report['error']     = $response->get_error_message();
				$report['final_url'] = $current_url;
				return $report;
			}

			$response_code = wp_remote_retrieve_response_code($response);

			if ($response_code >= 300 && $response_code < 400) {

				$location = wp_remote_retrieve_header($response, 'location');

				if (is_array($location)) {
					$location = end($location);
				}

				if (!$location) {
					// Redirect status without a Location header, nothing to follow
					$report['final_url']  = $current_url;
					$report['final_code'] = $response_code;
					return $report;
				}

				$location = \WP_Http::make_absolute_url($location, $current_url);

				$report['chain'][] = [
					'code' => $response_code,
					'to'   => $location,
				];

				$current_url = $location;
				continue;
			}

			$report['final_url']  = $current_url;
			$report['final_code'] = $response_code;
			return $report;
		}

		$report['error']     = 'too many redirects (more than ' . $max_hops . ' hops)';
		$report['final_url'] = $current_url;
		return $report;
	}

	/**
	 * Check if a URL still points to the order confirmation page of the given order.
	 *
	 * Canonical redirects (http to https, www to non-www, trailing slash, language
	 * prefixes) keep the order key or the order-received endpoint in the URL. Only
	 * a redirect that loses both actually moves the customer off the confirmation
	 * page and breaks purchase tracking.
	 *
	 * @param string        $url
	 * @param \WC_Order|false $order
	 * @return bool
	 */
	private static function is_order_confirmation_url( $url, $order ) {

		if (!$url || !$order) {
			return false;
		}

		$order_key = $order->get_order_key();

		if ($order_key && false !== strpos($url, $order_key)) {
			return true;
		}

		$endpoint = self::get_order_received_endpoint_slug();

		if (false !== strpos($url, '/' . $endpoint . '/' . $order->get_id())) {
			return true;
		}

		return false;
	}

	/**
	 * Get the slug of the WooCommerce order-received endpoint.
	 *
	 * Shops can rename it under WooCommerce > Settings > Advanced. An empty
	 * setting falls back to the default, like wc_get_endpoint_url() does.
	 *
	 * @return string
	 *
	 * @since 1.74.3
	 */
	public static function get_order_received_endpoint_slug() {

		$endpoint = get_option('woocommerce_checkout_order_received_endpoint', 'order-received');

		if (!is_string($endpoint) || '' === $endpoint) {
			return 'order-received';
		}

		return $endpoint;
	}

	/**
	 * Build the URL of the order-received endpoint below the checkout page.
	 *
	 * Mirrors wc_get_endpoint_url() with the checkout URL as permalink, so the
	 * result is right whether or not the checkout URL ends with a slash, with a
	 * query string on the checkout URL (language parameters) and with plain
	 * permalinks. Concatenating the two parts, as before 1.74.3, produced
	 * ".../checkoutorder-received" on shops without a trailing slash.
	 *
	 * @param string      $checkout_url The checkout page URL.
	 * @param string|null $endpoint     The endpoint slug, defaults to the shop's setting.
	 * @return string
	 *
	 * @since 1.74.3
	 */
	public static function build_order_received_url( $checkout_url, $endpoint = null ) {

		$checkout_url = (string) $checkout_url;

		if (null === $endpoint || '' === $endpoint) {
			$endpoint = self::get_order_received_endpoint_slug();
		}

		// Plain permalinks: the endpoint is a query argument.
		if (!get_option('permalink_structure')) {
			return add_query_arg($endpoint, '', $checkout_url);
		}

		$query_string = '';

		if (false !== strpos($checkout_url, '?')) {
			$parts        = explode('?', $checkout_url, 2);
			$checkout_url = $parts[0];
			$query_string = '?' . $parts[1];
		}

		return trailingslashit($checkout_url) . user_trailingslashit($endpoint) . $query_string;
	}

	/**
	 * Check if a URL sits under the given order-received endpoint URL.
	 *
	 * With pretty permalinks only the paths are compared, on a segment boundary,
	 * so the order ID and key that follow the endpoint, a query string on the
	 * checkout URL and the trailing slash style do not matter. With plain
	 * permalinks the endpoint is a query argument that the order URL continues
	 * with "=<order id>".
	 *
	 * @param string $url                The URL to test, usually the last order's confirmation URL.
	 * @param string $order_received_url The expected endpoint URL from build_order_received_url().
	 * @return bool
	 *
	 * @since 1.74.3
	 */
	public static function is_url_under_order_received_url( $url, $order_received_url ) {

		$url                = (string) $url;
		$order_received_url = (string) $order_received_url;

		if ('' === $url || '' === $order_received_url) {
			return false;
		}

		if (!get_option('permalink_structure')) {
			return false !== strpos($url, $order_received_url);
		}

		$url_parts      = explode('?', $url, 2);
		$expected_parts = explode('?', $order_received_url, 2);

		return false !== strpos(trailingslashit($url_parts[0]), trailingslashit($expected_parts[0]));
	}

	private static function show_warning( $test = false ) {
		if ($test) {
			return '❗ ';
		} else {
			return '';
		}
	}

//  private static function try_connect_to_server( $server ) {
//      if ($socket = @ fsockopen($server, 80)) {
//          @fclose($socket);
//          return 'online';
//      } else {
//          return 'offline';
//      }
//  }

	/**
	 * Test if a server is reachable, no matter what response code, using wp_remote_get
	 *
	 * @param $server
	 * @return string
	 */
	private static function try_connect_to_server( $server ) {

		$response = wp_remote_get($server, [
			'timeout'             => 4,
			'sslverify'           => HTTP::should_verify_ssl(),
			'limit_response_size' => 5000,
			'blocking'            => true,    // We need to wait to see if we get a server response 200
			'redirection'         => 0,      // We don't want to follow redirects
		]);

		if (is_wp_error($response)) {
			return 'offline';
		} else {
			return 'online';
		}
	}

	/**
	 * Look-back window for get_recent_order_payment_method_ids(), matching the
	 * 30 day window of the accuracy report.
	 */
	const ACTIVE_GATEWAY_ORDER_DAYS = 30;

	/**
	 * Upper bound of orders read when the accuracy table has no data yet.
	 */
	const ACTIVE_GATEWAY_FALLBACK_ORDER_LIMIT = 500;

	/**
	 * Per-request cache for get_recent_order_payment_method_ids().
	 *
	 * @var string[]|null
	 */
	private static $recent_order_payment_method_ids = null;

	/**
	 * IDs of the payment gateways the tracking accuracy report treats as active:
	 * the enabled, available gateways plus every gateway ID that received orders
	 * in the last 30 days.
	 *
	 * The second part covers gateway IDs that a plugin still writes to new orders
	 * although no gateway object with that ID is enabled, for example legacy
	 * Stripe IDs such as stripe_cc while the official Stripe gateway processes
	 * the payment. Without it their orders dropped out of the active view and the
	 * weighted report (Verdict #89).
	 *
	 * @return string[]
	 * @since 1.71.1
	 */
	public static function get_active_payment_gateway_ids() {

		$ids = [];

		foreach (self::get_enabled_payment_gateways() as $gateway) {
			$ids[] = (string) $gateway->id;
		}

		$ids = array_merge($ids, self::get_recent_order_payment_method_ids());

		return array_values(array_unique(array_filter($ids, 'strlen')));
	}

	/**
	 * Payment method IDs of orders created in the last ACTIVE_GATEWAY_ORDER_DAYS days.
	 *
	 * Reads the aggregate accuracy table when it has data (bounded by days times
	 * gateways). Before the table is filled it reads the payment method of at most
	 * ACTIVE_GATEWAY_FALLBACK_ORDER_LIMIT recent orders through wc_get_orders()
	 * and one bulk meta query, which works with HPOS and the posts table alike.
	 *
	 * @return string[]
	 * @since 1.71.1
	 */
	public static function get_recent_order_payment_method_ids() {

		if (null !== self::$recent_order_payment_method_ids) {
			return self::$recent_order_payment_method_ids;
		}

		if (Tracking_Accuracy_DB::has_data()) {
			self::$recent_order_payment_method_ids = Tracking_Accuracy_DB::get_gateway_ids_with_orders(self::ACTIVE_GATEWAY_ORDER_DAYS);

			return self::$recent_order_payment_method_ids;
		}

		$ids = [];

		if (function_exists('wc_get_orders')) {
			$order_ids = wc_get_orders([
				'limit'        => self::ACTIVE_GATEWAY_FALLBACK_ORDER_LIMIT,
				'type'         => 'shop_order',
				'orderby'      => 'ID',
				'order'        => 'DESC',
				'status'       => [ 'completed', 'processing', 'on-hold' ],
				'date_created' => '>' . ( time() - self::ACTIVE_GATEWAY_ORDER_DAYS * DAY_IN_SECONDS ),
				'return'       => 'ids',
			]);

			foreach (self::get_bulk_order_meta(is_array($order_ids) ? $order_ids : []) as $meta) {
				if ('' !== (string) $meta['payment_method']) {
					$ids[ (string) $meta['payment_method'] ] = true;
				}
			}
		}

		self::$recent_order_payment_method_ids = array_keys($ids);

		return self::$recent_order_payment_method_ids;
	}

	/**
	 * Reset the per-request cache of get_recent_order_payment_method_ids(), for tests.
	 *
	 * @return void
	 * @since 1.71.1
	 */
	public static function reset_recent_order_payment_method_ids_cache() {
		self::$recent_order_payment_method_ids = null;
	}

	public static function get_enabled_payment_gateways() {

		if (!function_exists('WC') || !WC() || empty(WC()->payment_gateways)) {
			return [];
		}

		$gateways = WC()->payment_gateways->get_available_payment_gateways();

		$enabled_gateways = [];

		if ($gateways) {
			foreach ($gateways as $gateway) {

				if ('yes' == $gateway->enabled) {
					$enabled_gateways[] = $gateway;
				}
			}
		}

		return $enabled_gateways;
	}

	/**
	 * Get all payment gateways
	 *
	 * In rare cases, if a payment gateway is not following the WooCommerce standards,
	 * it might not be available in the WC_Payment_Gateways class.
	 *
	 * Reference: https://secure.helpscout.net/conversation/2748380728/3697/
	 *
	 * @return array
	 */
	public static function get_payment_gateways() {

		if (!class_exists('WC_Payment_Gateways')) {
			return [];
		}

		$gateways = ( new WC_Payment_Gateways() )->get_available_payment_gateways();

		return is_array($gateways) ? $gateways : [];
	}

	private static function get_pmw_tracked_orders( $limit ) {
		// Get most recent order IDs in date descending order.

		// TODO include custom order statutes that have been added with a pmw filter

		return wc_get_orders([
			'limit'        => $limit,
			'type'         => 'shop_order',
			'orderby'      => 'ID',
			'order'        => 'DESC',
			'status'       => [ 'completed', 'processing', 'on-hold', 'pending' ],
			'created_via'  => 'checkout',                                            // Don't track admin orders
			'meta_key'     => '_wpm_process_through_wpm',
			'meta_value'   => true,
			'meta_compare' => '=',
			'return'       => 'ids',
		]);
	}

	private static function get_count_of_pmw_tracked_orders_for_one_month() {
		$result = wc_get_orders([
			'type'         => 'shop_order',
			'limit'        => 1,
			'date_created' => '>' . ( time() - MONTH_IN_SECONDS ),
			'status'       => [ 'completed', 'processing', 'on-hold', 'pending' ],
			'created_via'  => 'checkout',
			'meta_key'     => '_wpm_process_through_wpm',
			'meta_value'   => true,
			'meta_compare' => '=',
			'return'       => 'ids',
			'paginate'     => true,
		]);

		return $result->total;
	}

	/**
	 * Fetch payment method and tracking meta for a batch of order IDs in bulk.
	 *
	 * Returns an associative array keyed by order ID:
	 * [
	 *   order_id => [
	 *     'payment_method'              => string,
	 *     'conversion_pixel_fired'      => bool,
	 *     'conversion_pixel_trigger'    => string|null,
	 *   ],
	 * ]
	 *
	 * @param int[] $order_ids Array of order IDs.
	 * @return array
	 * @since 1.58.5
	 */
	private static function get_bulk_order_meta( $order_ids ) {
		global $wpdb;

		if ( empty( $order_ids ) ) {
			return [];
		}

		$result = [];

		// Process in chunks to avoid excessively long IN clauses
		$chunks = array_chunk( $order_ids, 500 );

		foreach ( $chunks as $chunk ) {
			$placeholders = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );

			if ( Helpers::is_wc_hpos_enabled() ) {

				// HPOS: payment_method is a column on wc_orders, meta is in wc_orders_meta
				// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$rows = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT o.id AS order_id,
								o.payment_method,
								MAX(CASE WHEN om.meta_key = '_wpm_conversion_pixel_fired' THEN om.meta_value END) AS pixel_fired,
								MAX(CASE WHEN om.meta_key = '_wpm_conversion_pixel_trigger' THEN om.meta_value END) AS pixel_trigger
						FROM {$wpdb->prefix}wc_orders o
						LEFT JOIN {$wpdb->prefix}wc_orders_meta om
							ON o.id = om.order_id
							AND om.meta_key IN ('_wpm_conversion_pixel_fired', '_wpm_conversion_pixel_trigger')
						WHERE o.id IN ({$placeholders})
						GROUP BY o.id, o.payment_method",
						...$chunk
					)
				);
				// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			} else {

				// Legacy postmeta
				// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$rows = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT p.ID AS order_id,
								MAX(CASE WHEN pm.meta_key = '_payment_method' THEN pm.meta_value END) AS payment_method,
								MAX(CASE WHEN pm.meta_key = '_wpm_conversion_pixel_fired' THEN pm.meta_value END) AS pixel_fired,
								MAX(CASE WHEN pm.meta_key = '_wpm_conversion_pixel_trigger' THEN pm.meta_value END) AS pixel_trigger
						FROM {$wpdb->posts} p
						INNER JOIN {$wpdb->postmeta} pm
							ON p.ID = pm.post_id
							AND pm.meta_key IN ('_payment_method', '_wpm_conversion_pixel_fired', '_wpm_conversion_pixel_trigger')
						WHERE p.ID IN ({$placeholders})
						GROUP BY p.ID",
						...$chunk
					)
				);
				// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}

			foreach ( $rows as $row ) {
				$result[ $row->order_id ] = [
					'payment_method'           => isset( $row->payment_method ) ? $row->payment_method : '',
					'conversion_pixel_fired'   => ! empty( $row->pixel_fired ),
					'conversion_pixel_trigger' => isset( $row->pixel_trigger ) ? $row->pixel_trigger : null,
				];
			}
		}

		return $result;
	}

	public static function tracking_accuracy_loading_message() {

		if (!Environment::is_action_scheduler_active()) {
			return esc_html__("The Pixel Manager wasn't able to generate the analysis because the Action Scheduler could not be loaded.", 'woocommerce-google-adwords-conversion-tracking-tag');
		}

		return __('The analysis is being generated. Please check back in 5 minutes.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	private static function return_transients_deactivated_text() {
		return __('Transients are deactivated. Please activate them to use this feature.', 'woocommerce-google-adwords-conversion-tracking-tag');
	}

	/**
	 * Set a transient with verification that it was stored correctly.
	 *
	 * This is important for sites using external object caches (Redis/Memcached)
	 * where transients might fail to store due to:
	 * - Memory limits being exceeded
	 * - Data size limits per key
	 * - Cache eviction policies
	 * - Serialization issues with complex data
	 *
	 * If verification fails, we log the error for debugging purposes.
	 *
	 * @param string $transient  Transient name.
	 * @param mixed  $value      Transient value.
	 * @param int    $expiration Time until expiration in seconds.
	 *
	 * @return bool True if the transient was set and verified, false otherwise.
	 *
	 * @since 1.47.0
	 */
	private static function set_transient_with_verification( $transient, $value, $expiration ) {

		// Attempt to set the transient
		$result = set_transient($transient, $value, $expiration);

		if (!$result) {
			Logger::debug('Failed to set transient: ' . $transient);
			return false;
		}

		// Verify the transient was actually stored by reading it back
		$stored_value = get_transient($transient);

		if (false === $stored_value) {
			Logger::debug(sprintf(
				'Transient verification failed for %s. External object cache (Redis/Memcached) may have rejected the data. Cache type: %s',
				$transient,
				Environment::get_external_object_cache()
			));
			return false;
		}

		// For arrays, verify the count matches as a sanity check
		// This helps detect partial data corruption
		if (is_array($value) && is_array($stored_value)) {
			if (count($value) !== count($stored_value)) {
				Logger::debug(sprintf(
					'Transient data mismatch for %s. Expected %d items, got %d. Possible data corruption.',
					$transient,
					count($value),
					count($stored_value)
				));
				return false;
			}
		}

		return true;
	}
}
