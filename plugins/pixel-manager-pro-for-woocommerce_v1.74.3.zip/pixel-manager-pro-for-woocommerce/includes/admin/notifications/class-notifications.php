<?php

namespace SweetCode\Pixel_Manager\Admin\Notifications;

use SweetCode\Pixel_Manager\Admin\Admin;
use SweetCode\Pixel_Manager\Admin\Commercial_Links;
use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Environment;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunities;
use SweetCode\Pixel_Manager\Helpers;

defined('ABSPATH') || exit; // Exit if accessed directly

class Notifications {

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {

		add_action('admin_enqueue_scripts', [ __CLASS__, 'inject_admin_scripts' ]);

		add_action('admin_enqueue_scripts', [ __CLASS__, 'wpm_admin_css' ]);

		add_action('admin_notices', function () {
			if (Environment::is_allowed_notification_page() || Environment::is_pmw_settings_page()) {
				// The Nova admin UI renders the opportunities summary inside its own
				// Dashboard, so suppress the top-of-page banner there.
				if (!Admin::is_wp_admin_active()) {
					self::opportunities_notification();
				}
				self::show_notifications();
			}

			if (wpm_fs()->is__premium_only()) {
				self::license_expired_warning__premium_only();
			}
		});
	}

	/**
	 * Whether this admin screen can render any PMW notification.
	 *
	 * Mirrors the conditions in the admin_notices callback registered in the
	 * constructor: the opportunities notice and the notification list render on
	 * the WordPress dashboard and on the PMW settings pages, and the
	 * license-expired warning is limited to those same screens. Every other
	 * admin screen renders nothing, so it needs neither the script nor the
	 * stylesheet.
	 *
	 * @return bool
	 * @since 1.63.1
	 */
	private static function needs_notification_assets() {
		return Environment::is_allowed_notification_page() || Environment::is_pmw_settings_page();
	}

	public static function inject_admin_scripts() {

		// Was previously enqueued on every admin screen. @since 1.63.1
		if (!self::needs_notification_assets()) {
			return;
		}

		wp_enqueue_script(
			'pmw-notifications',
			PMW_PLUGIN_DIR_PATH . 'js/admin/notifications.js',
			[ 'jquery' ],
			PMW_CURRENT_VERSION,
			true
		);

		wp_localize_script(
			'pmw-notifications',
			'pmwNotificationsApi',
			[
				'root'  => esc_url_raw(rest_url()),
				'nonce' => wp_create_nonce('wp_rest'),
			]
		);
	}

	public static function wpm_admin_css( $hook_suffix ) {

		// Only output the css on screens that can actually show a notification.
		// The order-list column icons are styled by admin.css, not by this
		// stylesheet, so gating here does not affect them. @since 1.63.1
		if (!self::needs_notification_assets()) {
			return;
		}

		// Only output the css on PMW pages and the order page
//      if (self::is_not_allowed_to_show_pmw_notification()) {
//          return;
//      }

		wp_enqueue_style(
			'pmw-notifications-css',
			PMW_PLUGIN_DIR_PATH . 'css/notifications.css',
			[],
			PMW_CURRENT_VERSION
		);
	}

	public static function dismiss_notification( $opportunity_id ) {

		$option = get_option(PMW_DB_NOTIFICATIONS_NAME);

		if (empty($option)) {
			$option = [];
		}

		$option[$opportunity_id]['dismissed'] = time();

		update_option(PMW_DB_NOTIFICATIONS_NAME, $option);
	}

	private static function show_notifications() {

		foreach (self::get_notifications() as $notification) {
			if ($notification::is_not_dismissed()) {
				$notification::output_notification();
			}
		}
	}

	private static function get_notifications() {

		self::load_all_notification_classes();

		$classes = get_declared_classes();

		$notifications = [];

		foreach ($classes as $class) {
			if (is_subclass_of($class, 'SweetCode\Pixel_Manager\Admin\Notifications\Notification')) {
				$notifications[] = $class;
			}
		}

		return $notifications;
	}

	// Don't make public, as this could be used for file inclusion attacks.
	private static function load_all_notification_classes() {

		$scan = glob(__DIR__ . '/*');
		foreach ($scan as $path) {
			if (preg_match('/\.php$/', $path)) {
				require_once $path;
			}
		}
	}

	// Only show the notification on the dashboard and on the PMW settings page
	private static function is_not_allowed_to_show_pmw_notification() {
		return !self::is_allowed_to_show_pmw_notification();
	}

	private static function is_allowed_to_show_pmw_notification() {

		if (!self::can_current_page_show_pmw_notification()) {
			return false;
		}

		// Only show the notifications to admins and shop managers
		$user = wp_get_current_user();
		if (!in_array('administrator', $user->roles, true) && !in_array('shop_manager', $user->roles, true)) {
			return false;
		}

		return true;
	}

	public static function can_current_page_show_pmw_notification() {

		global $hook_suffix;

		$allowed_pages = [ 'page_pmw', 'index.php', 'dashboard' ];

		/**
		 * We can't use in_array because woocommerce_page_wpm
		 * is malformed on certain installs, but the substring
		 * page_wpm is fine. So we need to search for partial
		 * matches.
		 * */
		foreach ($allowed_pages as $allowed_page) {
			if (strpos($hook_suffix, $allowed_page) !== false) {
				return true;
			}
		}

		return false;
	}

	public static function payment_gateway_accuracy_warning() {

		// Only show the warning on the dashboard and on the PMW settings page
		if (self::is_not_allowed_to_show_pmw_notification()) {
			return;
		}

		$pg_report = get_transient('pmw_tracking_accuracy_analysis_weighted');

		// Only run if the weighted payment gateway analysis has been created
		if (!$pg_report) {
			return;
		}

		// Only run if the total of the PGs is in status warning

		// Only run if the user has not dismissed the notification for a specific time period

		?>
		<div class="pmw-payment-gateway-notification notice notice-error is-dismissible">
			<p>
				<?php
				esc_html_e('Payment Gateway Accuracy Warning', 'woocommerce-google-adwords-conversion-tracking-tag');
				?>
			</p>
		</div>
		<?php
	}

	public static function license_expired_warning__premium_only() {

		if (wpm_fs()->can_use_premium_code__premium_only()) {
			return;
		}

		// Show on WordPress dashboard and PMW settings page
		if (!Helpers::is_dashboard() && !Environment::is_pmw_settings_page()) {
			return;
		}

		// The Nova admin UI renders its own license-expired card on the
		// Dashboard, so suppress the top-of-page banner there.
		if (Environment::is_pmw_settings_page() && Admin::is_wp_admin_active()) {
			return;
		}

		$saved_notifications = get_option(PMW_DB_NOTIFICATIONS_NAME);

		// If saved date is in the future, then don't show
		if (
			isset($saved_notifications['dashboard-license-expired-message-dismissed'])
			&& $saved_notifications['dashboard-license-expired-message-dismissed'] > time() - MONTH_IN_SECONDS * 6
		) {
			return;
		}

		?>
		<div id="license-expired-warning"
			class="notice notice-error pmw license-expired-warning"
			style="background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #d63638; border-radius: 4px; box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08); padding: 16px 20px; display: flex; flex-direction: row; justify-content: space-between; align-items: flex-start; gap: 16px;">
			<div>
				<div style="color: #1d2327; margin-bottom: 8px;">
					<strong style="font-size: 14px;">
						<?php esc_html_e('⚠️ License Expired', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</strong>
				</div>
				<div style="color: #50575e; margin-bottom: 12px;">
					<?php esc_html_e('Your Pixel Manager license has expired or been removed. Automatic updates and premium features are now disabled.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					<a href="<?php echo esc_url(Documentation::get_link('license_expired_warning')); ?>"
						target="_blank"
						style="margin-left: 4px;">
						<?php esc_html_e('Learn more', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</a>
				</div>

				<div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 14px;">
					<span style="display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 9999px; font-size: 12px; font-weight: 500; background: #fcf0f1; border: 1px solid #d63638; color: #b32d2e;">
						<?php esc_html_e('Premium features disabled', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
					<span style="display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 9999px; font-size: 12px; font-weight: 500; background: #fcf0f1; border: 1px solid #d63638; color: #b32d2e;">
						<?php esc_html_e('No automatic updates', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</span>
				</div>

				<a href="<?php echo esc_url_raw(Helpers::is_pmw_wcm_distro() ? Commercial_Links::WC_PRODUCT_URL : 'https://sweetcode.com/pricing'); ?>"
					target="_blank"
					style="text-decoration: none; box-shadow: none;">
					<div class="button button-primary" style="margin: 0;">
						<?php esc_html_e('Renew License', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</div>
				</a>
			</div>

			<div style="text-align: right; display: flex; flex-direction: column; flex-shrink: 0;">
				<div id="pmw-dismiss-license-expiry-message-button"
					class="button pmw-notification-dismiss-button"
					style="white-space: normal; margin-bottom: 6px; text-align: center;"
					data-notification-id="dashboard-license-expired-message-dismissed"
				><?php esc_html_e('Dismiss', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</div>
			</div>
		</div>

		<?php
	}

	public static function dismiss_expired_license_warning__premium_only() {

		$saved_notifications                                 = get_option(PMW_DB_NOTIFICATIONS_NAME);
		$saved_notifications['show_license_expired_warning'] = time() + MONTH_IN_SECONDS * 6;
		update_option(PMW_DB_NOTIFICATIONS_NAME, $saved_notifications);
		wp_send_json_success();
	}

	private static function can_show_dashboard_opportunities_message() {

		$saved_notifications = get_option(PMW_DB_NOTIFICATIONS_NAME);

		$dismissed_time = self::get_opportunities_notification_dismissed_time( $saved_notifications );

		// If dismissed within the cooldown period, only re-show if new opportunities
		// have been added since the dismissal.
		if (
			$dismissed_time
			&& $dismissed_time > time() - MONTH_IN_SECONDS * 3
			&& ! Opportunities::has_opportunities_newer_than( $dismissed_time )
		) {
			return false;
		}

		if (!Opportunities::active_opportunities_available()) {
			return false;
		}

		return true;
	}

	/**
	 * Get the timestamp when the dashboard opportunities notification was dismissed.
	 *
	 * Handles both the current storage format (array with 'dismissed' key)
	 * and any legacy format (direct timestamp).
	 *
	 * @param mixed $saved_notifications The saved notifications option value.
	 *
	 * @return int|false The dismissed timestamp, or false if never dismissed.
	 * @since 1.57.1
	 */
	private static function get_opportunities_notification_dismissed_time( $saved_notifications ) {

		if ( empty( $saved_notifications ) || ! isset( $saved_notifications['dashboard-opportunities-message-dismissed'] ) ) {
			return false;
		}

		$value = $saved_notifications['dashboard-opportunities-message-dismissed'];

		// Current format: ['dismissed' => timestamp]
		if ( is_array( $value ) && isset( $value['dismissed'] ) ) {
			return (int) $value['dismissed'];
		}

		// Legacy format: direct timestamp
		if ( is_numeric( $value ) ) {
			return (int) $value;
		}

		return false;
	}

	public static function notification_html( $notification_data ) {

		wp_enqueue_script(
			'wistia',
			'https://fast.wistia.com/assets/external/E-v1.js',
			[],
			PMW_CURRENT_VERSION,
			false
		);

		?>
		<div class="notice notice-info pmw notification">

			<div id="pmw-notification-<?php echo esc_html($notification_data['id']); ?>">

				<!-- Pixel Manager title -->
				<div class="notification-title">
					<b><?php esc_html_e('Pixel Manager', 'woocommerce-google-adwords-conversion-tracking-tag'); ?></b>

					<!-- Dismiss Link -->
					<?php if (empty($notification_data['dismissed'])) : ?>
						<a class="notification-card-button-link" href="#">
							<div class="notification-dismiss"
								data-notification-id="<?php echo esc_html($notification_data['id']); ?>">
								<!-- Replace 'Dismiss' text with 'X' -->
								<span class="notification-dismiss-cross">&times;</span>
							</div>
						</a>
					<?php endif; ?>
					<!-- Dismiss Link end -->
				</div>

				<hr class="notification-card-hr">

				<!-- notification title -->
				<div class="notification-top">
					<div>
						<?php echo esc_html($notification_data['title']); ?>
					</div>
					<div class="importance-info">
						<span><?php esc_html_e('Importance', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>:</span>
						<span class="notification-card-top-impact-level">
							<?php echo esc_html($notification_data['importance']); ?>
						</span>
					</div>
				</div>

				<hr class="notification-card-hr">

				<!-- description -->
				<div class="notification-card-middle">

					<?php if (!empty($custom_middle_html)) : ?>
						<?php echo esc_html($custom_middle_html); ?>
					<?php else : ?>
						<?php foreach ($notification_data['description'] as $description) : ?>
							<p class="notification-card-description">
								<?php echo esc_html($description); ?>
							</p>
						<?php endforeach; ?>
					<?php endif; ?>

				</div>

				<hr class="notification-card-hr">

				<!-- bottom -->
				<div class="notification-card-bottom">

					<!-- Video Link -->
					<?php if (isset($notification_data['video_id'])) : ?>
						<div class="notification-video-link">
							<script>
								var script   = document.createElement("script")
								script.async = true
								script.src   = 'https://fast.wistia.com/embed/medias/<?php echo esc_js($notification_data['video_id']); ?>.jsonp'
								document.getElementsByTagName("head")[0].appendChild(script)
							</script>

							<div class="wistia_embed wistia_async_<?php echo esc_html($notification_data['video_id']); ?> popover=true popoverContent=link videoFoam=false"
								>
								<span class="dashicons dashicons-video-alt3"></span>
							</div>
						</div>
					<?php endif; ?>
					<!-- Video Link end -->

					<!-- Learn More Link -->
					<?php if (isset($notification_data['learn_more_link'])) : ?>
						<a class="notification-card-button-link"
							href="<?php echo esc_url($notification_data['learn_more_link']); ?>"
							target="_blank"
						>
							<div class="notification-card-bottom-button">
								<?php esc_html_e('Learn more', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							</div>
						</a>
					<?php endif; ?>
					<!-- Learn More Link end -->

					<!-- Settings Link -->
					<?php if (isset($notification_data['settings_link'])) : ?>
						<a class="notification-card-button-link"
							href="<?php echo esc_url($notification_data['settings_link']); ?>"
							target="_blank"
						>
							<div class="notification-card-bottom-button">
								<?php esc_html_e('Settings', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							</div>
						</a>
					<?php endif; ?>
					<!-- Settings Link end -->

					<!-- Portal Link -->
					<?php if (isset($notification_data['portal_link'])) : ?>
						<a class="notification-card-button-link"
							href="<?php echo esc_url($notification_data['portal_link']); ?>"
							target="_blank"
						>
							<div class="notification-card-bottom-button">
								<?php esc_html_e('SSP Portal', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
							</div>
						</a>
					<?php endif; ?>
					<!-- Portal Link end -->

				</div>
				<!-- bottom end -->

			</div>
		</div>
		<?php
	}

	private static function cannot_show_dashboard_opportunities_message() {
		return !self::can_show_dashboard_opportunities_message();
	}

	public static function opportunities_notification() {

		if (self::cannot_show_dashboard_opportunities_message()) {
			return;
		}

		$total_count      = Opportunities::get_active_opportunities_count();
		$counts_by_impact = Opportunities::get_active_opportunities_by_impact();

		?>
		<div id="active-opportunities-notification"
			class="notice notice-info pmw active-opportunities-notification"
			style="padding: 12px 16px;display: flex;flex-direction: row;justify-content: space-between;align-items: flex-start;">
			<div>
				<div style="color:black;margin-bottom: 8px;">
					<strong style="font-size: 14px;">
						<?php
						printf(
							/* translators: %d: number of opportunities */
							esc_html(_n(
								'🚀 %d Opportunity Detected!',
								'🚀 %d Opportunities Detected!',
								$total_count,
								'woocommerce-google-adwords-conversion-tracking-tag'
							)),
							absint( $total_count )
						);
						?>
					</strong>
				</div>
				<div style="color:#444;margin-bottom: 10px;">
					<?php esc_html_e('The Pixel Manager has detected opportunities to improve your tracking and campaign performance.', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</div>

				<div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px;">
					<?php if ($counts_by_impact['high'] > 0) : ?>
						<span class="pmw-opportunity-badge pmw-opportunity-badge-high" style="display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 3px; font-size: 12px; font-weight: 500; background: #f3e8ff; border: 1px solid #8b5cf6; color: #5b21b6;">
							<span style="background: #fff; border-radius: 3px; margin-right: 6px; font-size: 11px; line-height: 1; font-weight: 600; border: 1px solid #8b5cf6; min-width: 18px; height: 18px; display: inline-flex; align-items: center; justify-content: center; text-align: center; box-sizing: border-box; padding: 0 4px;"><?php echo esc_html($counts_by_impact['high']); ?></span>
							<?php esc_html_e('High Impact', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
						</span>
					<?php endif; ?>

					<?php if ($counts_by_impact['medium'] > 0) : ?>
						<span class="pmw-opportunity-badge pmw-opportunity-badge-medium" style="display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 3px; font-size: 12px; font-weight: 500; background: #dbeafe; border: 1px solid #3b82f6; color: #1e40af;">
							<span style="background: #fff; border-radius: 3px; margin-right: 6px; font-size: 11px; line-height: 1; font-weight: 600; border: 1px solid #3b82f6; min-width: 18px; height: 18px; display: inline-flex; align-items: center; justify-content: center; text-align: center; box-sizing: border-box; padding: 0 4px;"><?php echo esc_html($counts_by_impact['medium']); ?></span>
							<?php esc_html_e('Medium Impact', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
						</span>
					<?php endif; ?>

					<?php if ($counts_by_impact['low'] > 0) : ?>
						<span class="pmw-opportunity-badge pmw-opportunity-badge-low" style="display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 3px; font-size: 12px; font-weight: 500; background: #ccfbf1; border: 1px solid #14b8a6; color: #0f766e;">
							<span style="background: #fff; border-radius: 3px; margin-right: 6px; font-size: 11px; line-height: 1; font-weight: 600; border: 1px solid #14b8a6; min-width: 18px; height: 18px; display: inline-flex; align-items: center; justify-content: center; text-align: center; box-sizing: border-box; padding: 0 4px;"><?php echo esc_html($counts_by_impact['low']); ?></span>
							<?php esc_html_e('Low Impact', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
						</span>
					<?php endif; ?>
				</div>

				<a href="<?php echo( esc_url_raw('/wp-admin/admin.php?page=pmw&section=opportunities') ); ?>"
					style="text-decoration: none;box-shadow: none;">
					<div class="button button-primary" style="margin: 0;">
						<?php esc_html_e('View Opportunities', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
					</div>
				</a>
			</div>

			<div style="text-align: right;display: flex;flex-direction: column;">
				<div id="pmw-dismiss-opportunities-message-button"
					class="button pmw-notification-dismiss-button"
					style="white-space:normal;margin-bottom: 6px;text-align: center;"
					data-notification-id="dashboard-opportunities-message-dismissed"
				><?php esc_html_e('Dismiss', 'woocommerce-google-adwords-conversion-tracking-tag'); ?>
				</div>
			</div>
		</div>

		<?php
	}
}
