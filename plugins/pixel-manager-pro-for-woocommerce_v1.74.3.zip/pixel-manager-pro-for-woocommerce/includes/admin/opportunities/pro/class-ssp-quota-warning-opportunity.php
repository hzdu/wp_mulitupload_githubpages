<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: SSP Quota Warning
 *
 * Shows when SSP usage reaches 80% of the monthly quota,
 * prompting the store owner to upgrade before events start
 * falling back or being dropped.
 *
 * Only shows when quota is NOT yet fully exceeded (the
 * SSP Quota Exceeded notification handles the 100% case).
 *
 * @since 1.57.0
 */
class SSP_Quota_Warning extends Opportunity {

	/**
	 * Check if the opportunity is available.
	 *
	 * Requirements:
	 * - SSP is active
	 * - Usage is at 80% or above
	 * - Quota is NOT yet fully exceeded (notification handles that)
	 *
	 * @return bool
	 * @since 1.57.0
	 */
	public static function available() {

		// SSP is only available on the SweetCode.com distribution
		if ( Helpers::is_pmw_wcm_distro() ) {
			return false;
		}

		// SSP must be active
		if ( ! Options::is_ssp_active() ) {
			return false;
		}

		// Don't show warning if quota is already fully exceeded
		// (the notification handles that case)
		if ( Options::is_ssp_quota_exceeded() ) {
			return false;
		}

		$options = Options::get_options();

		// Usage must be at 80% or above
		$usage_percent = isset($options['ssp']['usage_percent']) ? $options['ssp']['usage_percent'] : 0;
		if ( $usage_percent < 80 ) {
			return false;
		}

		return true;
	}

	/**
	 * Get the opportunity card data.
	 *
	 * @return array
	 * @since 1.57.0
	 */
	public static function card_data() {

		$options       = Options::get_options();
		$usage_percent = isset($options['ssp']['usage_percent']) ? $options['ssp']['usage_percent'] : 0;

		return [
			'id'              => 'ssp-quota-warning',
			'title'           => esc_html__(
				'SweetCode Cloud – Quota Running Low',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description'     => [
				sprintf(
					/* translators: %d: current usage percentage */
					esc_html__(
						'Your SweetCode Cloud (SSP) proxy has used %d%% of its monthly request quota.',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					$usage_percent
				),
				esc_html__(
					'When the quota is fully consumed, server-side tracking events will either fall back to your WooCommerce server or be dropped, depending on your settings.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Consider upgrading your plan to avoid interruptions in server-side tracking.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'          => 'high',
			'setup_link'      => 'https://portal.sweetcode.cloud',
			'custom_buttons'  => [
				[
					'label'  => esc_html__( 'SSP Settings', 'woocommerce-google-adwords-conversion-tracking-tag' ),
					'url'    => admin_url( 'admin.php?page=pmw&section=sse' ),
				],
			],
			'learn_more_link' => 'https://sweetcode.cloud',
			'since'           => 1739750400, // 2025-02-17 00:00:00 UTC
			'repeat_interval' => WEEK_IN_SECONDS, // Re-show weekly if still near limit
		];
	}
}
