<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Spotify Ads Advanced Matching
 *
 * @since 1.69.0
 */
class Spotify_Advanced_Matching extends Opportunity {

	public static function available() {

		// Spotify Ads must be active
		if (!Options::is_spotify_active()) {
			return false;
		}

		// Advanced Matching must be disabled
		if (Options::is_spotify_advanced_matching_enabled()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'spotify-advanced-matching',
			'title'       => esc_html__(
				'Spotify Ads Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Spotify Ads pixel is enabled but Advanced Matching is not active.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Advanced Matching sends the hashed email address of logged-in customers and purchasers to Spotify through the alias event, improving conversion attribution and audience matching, especially when cookies are blocked or users switch devices.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'medium',
			'setup_link'  => Documentation::get_link('spotify_advanced_matching'),
			'since'       => 1789344000, // timestamp: September 14, 2026
		];
	}
}
