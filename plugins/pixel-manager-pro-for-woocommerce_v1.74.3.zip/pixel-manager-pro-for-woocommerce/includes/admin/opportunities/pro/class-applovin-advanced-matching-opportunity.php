<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: AppLovin Advanced Matching
 *
 * @since 1.69.3
 */
class AppLovin_Advanced_Matching extends Opportunity {

	public static function available() {

		// AppLovin must be active
		if (!Options::is_applovin_active()) {
			return false;
		}

		// Advanced Matching must be disabled
		if (Options::is_applovin_advanced_matching_enabled()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'applovin-advanced-matching',
			'title'       => esc_html__(
				'AppLovin Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The AppLovin pixel is enabled but Advanced Matching is not active.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Advanced Matching sends the hashed email address, phone number and user ID of logged-in customers and purchasers to AppLovin, which AppLovin requires on purchase events and uses to attribute conversions when cookies are blocked or users switch devices.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'medium',
			'setup_link'  => Documentation::get_link('applovin_advanced_matching'),
			'since'       => 1791072000, // timestamp: October 4, 2026
		];
	}
}
