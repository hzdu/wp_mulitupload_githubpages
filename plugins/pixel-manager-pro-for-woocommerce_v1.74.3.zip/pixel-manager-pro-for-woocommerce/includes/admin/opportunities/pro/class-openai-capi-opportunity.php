<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: OpenAI CAPI
 *
 * @since 1.60.0
 */
class OpenAI_CAPI extends Opportunity {

	public static function available() {

		// OpenAI pixel must be enabled
		if (!Options::is_openai_active()) {
			return false;
		}

		// OpenAI CAPI must be disabled
		if (Options::is_openai_capi_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'openai-capi',
			'title'       => esc_html__(
				'OpenAI Conversions API',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the OpenAI pixel is enabled, but the OpenAI Conversions API has yet to be enabled.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Enabling the OpenAI Conversions API will improve conversion tracking accuracy and help you track more conversions that otherwise might get lost due to ad blockers or browser restrictions.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('openai_capi_token'),
			'since'       => time(), // timestamp
		];
	}
}
