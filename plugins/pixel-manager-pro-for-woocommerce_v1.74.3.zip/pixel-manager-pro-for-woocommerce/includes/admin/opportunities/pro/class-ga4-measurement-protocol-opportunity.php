<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Google Analytics 4 Measurement Protocol
 *
 * @since 1.65.2
 */
class GA4_Measurement_Protocol extends Opportunity {

	public static function available() {

		// Google Analytics 4 must be enabled
		if (!Options::is_ga4_enabled()) {
			return false;
		}

		// The Measurement Protocol must be disabled
		if (Options::is_ga4_mp_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'              => 'ga4-measurement-protocol',
			'title'           => esc_html__(
				'Google Analytics 4 Measurement Protocol',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description'     => [
				esc_html__(
					'The Pixel Manager detected that Google Analytics 4 is enabled, but the Measurement Protocol has yet to be enabled. It only needs an API secret, which you create in the same GA4 data stream.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'With the Measurement Protocol active, purchases are sent to Google Analytics 4 from your server instead of the browser, which recovers purchases lost to ad blockers and browser restrictions, records them on their order date, and reports refunds that Google Analytics 4 would otherwise never see.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'          => 'high',
			'setup_link'      => Documentation::get_link('google_analytics_4_api_secret'),
			'learn_more_link' => 'https://developers.google.com/analytics/devguides/collection/protocol/ga4',
			'since'           => 1787097600, // timestamp: August 19, 2026
		];
	}
}
