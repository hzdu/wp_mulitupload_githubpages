<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: OpenAI Advanced Matching
 *
 * @since 1.60.0
 */
class OpenAI_Advanced_Matching extends Opportunity {

	public static function available() {

		// OpenAI must be active
		if (!Options::is_openai_active()) {
			return false;
		}

		// Advanced Matching must be disabled
		if (Options::is_openai_advanced_matching_enabled()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'              => 'openai-advanced-matching',
			'title'           => esc_html__(
				'OpenAI Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description'     => [
				esc_html__(
					'OpenAI pixel is enabled but Advanced Matching is not active.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Advanced Matching sends hashed customer data (email, phone, name, customer ID) and the billing region to OpenAI, improving conversion attribution and audience matching, especially when cookies are blocked or users switch devices.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'          => 'medium',
			'setup_link'      => Documentation::get_link('openai_advanced_matching'),
			'since'           => time(), // timestamp
		];
	}
}
