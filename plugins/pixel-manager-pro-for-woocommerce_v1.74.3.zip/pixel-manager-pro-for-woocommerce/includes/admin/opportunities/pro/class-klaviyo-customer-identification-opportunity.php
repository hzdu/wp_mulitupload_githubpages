<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Klaviyo customer identification
 *
 * @since 1.68.0
 */
class Klaviyo_Customer_Identification extends Opportunity {

	public static function available() {

		// The Klaviyo pixel must be enabled and sending events
		if (!Options::is_klaviyo_active() || 'off' === Options::get_klaviyo_coexistence_mode()) {
			return false;
		}

		// Customer identification must be disabled
		if (Options::is_klaviyo_customer_identification_enabled()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'klaviyo-customer-identification',
			'title'       => esc_html__(
				'Klaviyo customer identification',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the Klaviyo pixel is enabled, but customer identification has yet to be enabled.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Klaviyo only attaches onsite events to a profile it can identify. Identifying logged-in customers and shoppers who enter their email at checkout is what lets abandoned cart and browse abandonment flows trigger for them.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'medium',
			'setup_link'  => Documentation::get_link('klaviyo_identify_customers'),
			'since'       => time(), // timestamp
		];
	}
}
