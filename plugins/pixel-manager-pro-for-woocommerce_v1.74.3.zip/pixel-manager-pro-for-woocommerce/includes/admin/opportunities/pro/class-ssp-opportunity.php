<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Enable SweetCode Cloud (SSP)
 *
 * Shows when the shop has at least one active server-to-server (S2S/CAPI)
 * pixel integration but has not yet enabled the SweetCode Cloud proxy.
 * Encourages admins to offload S2S tracking from their WooCommerce server
 * to Cloudflare's edge network for better performance and tracking accuracy.
 *
 * @since 1.57.1
 */
class SSP extends Opportunity {

	/**
	 * Check if the opportunity is available.
	 *
	 * Requirements:
	 * - SSP is NOT active
	 * - At least one pixel has active S2S/CAPI tracking
	 *
	 * @return bool
	 * @since 1.57.1
	 */
	public static function available() {

		// SSP is only available on the SweetCode.com distribution
		if ( Helpers::is_pmw_wcm_distro() ) {
			return false;
		}

		// SSP must NOT be active — the opportunity is to enable it
		if ( Options::is_ssp_active() ) {
			return false;
		}

		// At least one S2S/CAPI pixel must be active
		if ( empty( Options::pixels_with_active_s2s() ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Get the opportunity card data.
	 *
	 * @return array
	 * @since 1.57.1
	 */
	public static function card_data() {

		$active_s2s_pixels = Options::pixels_with_active_s2s();
		$pixel_names       = array_map( [ __CLASS__, 'get_pixel_display_name' ], $active_s2s_pixels );
		$pixel_list        = implode( ', ', $pixel_names );

		return [
			'id'              => 'ssp-enable',
			'title'           => esc_html__(
				'Offload Server-Side Tracking with SweetCode Cloud',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description'     => [
				sprintf(
					/* translators: %s: comma-separated list of active S2S pixel names (e.g. "Meta (Facebook), TikTok, Pinterest") */
					esc_html__(
						'You have server-side tracking (S2S/CAPI) enabled for: %s. These conversion API calls are currently processed by your WooCommerce server, adding CPU load and latency to every tracked event.',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					'<strong>' . esc_html( $pixel_list ) . '</strong>'
				),
				esc_html__(
					'SweetCode Cloud offloads this processing to Cloudflare\'s edge network through a first-party subdomain on your store. This reduces your server load, improves tracking reliability, and bypasses browser-side ad blockers — typically recovering additional conversions that server-only tracking misses.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'          => 'high',
			'setup_link'      => 'https://portal.sweetcode.cloud',
			'learn_more_link' => Documentation::get_link( 'ssp' ),
			'since'           => 1772236800, // 2026-02-28 00:00:00 UTC
		];
	}

	/**
	 * Get a human-readable display name for a pixel slug.
	 *
	 * @param string $pixel_slug The internal pixel identifier.
	 *
	 * @return string
	 * @since 1.57.1
	 */
	private static function get_pixel_display_name( $pixel_slug ) {

		$names = [
			'facebook'  => 'Meta (Facebook)',
			'tiktok'    => 'TikTok',
			'pinterest' => 'Pinterest',
			'snapchat'  => 'Snapchat',
			'reddit'    => 'Reddit',
			'openai'    => 'OpenAI',
		];

		return isset( $names[ $pixel_slug ] ) ? $names[ $pixel_slug ] : ucfirst( $pixel_slug );
	}
}
