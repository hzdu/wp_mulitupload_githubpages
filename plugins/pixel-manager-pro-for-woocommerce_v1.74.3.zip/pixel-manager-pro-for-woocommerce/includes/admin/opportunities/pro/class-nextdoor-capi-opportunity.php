<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Nextdoor Conversion API
 *
 * @since 1.65.2
 */
class Nextdoor_CAPI extends Opportunity {

	public static function available() {

		// The Nextdoor Universal Pixel must be enabled
		if (!Options::is_nextdoor_active()) {
			return false;
		}

		// The Nextdoor Conversion API must be disabled
		if (Options::is_nextdoor_capi_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'nextdoor-capi',
			'title'       => esc_html__(
				'Nextdoor Conversion API',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the Nextdoor Universal Pixel is enabled, but the Nextdoor Conversion API has yet to be enabled.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Enabling the Nextdoor Conversion API will improve conversion tracking accuracy and help you track more conversions that otherwise might get lost due to ad blockers or browser restrictions.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('nextdoor_capi_token'),
			'since'       => 1787097600, // timestamp: August 19, 2026
		];
	}
}
