<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Social_Login;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Meta (Facebook) Login ID
 *
 * Only offered when the shop already runs a social login plugin PMW can read
 * the Facebook app-scoped user ID from. Without one there is nothing to send,
 * so suggesting it would be noise.
 *
 * @since 1.64.1
 */
class Meta_Fb_Login_Id extends Opportunity {

	public static function available() {

		// Facebook CAPI must be active, since the ID travels on CAPI events.
		if (!Options::is_facebook_capi_active()) {
			return false;
		}

		// Already enabled, nothing to suggest.
		if (Options::is_facebook_send_fb_login_id_enabled()) {
			return false;
		}

		// Pointless without a plugin that can supply the ID.
		if (!Social_Login::is_supported_plugin_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'              => 'meta-fb-login-id',
			'title'           => esc_html__(
				'Meta (Facebook) Login ID',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description'     => [
				sprintf(
					/* translators: %s: name of the detected social login plugin */
					esc_html__(
						'%s is installed, so PMW can send the Facebook Login ID (fb_login_id) with your Conversions API events.',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					esc_html((string) Social_Login::get_active_plugin_name())
				),
				esc_html__(
					'The Facebook Login ID is a deterministic identifier for customers who signed in with Facebook, which can improve your Event Match Quality score. Meta can only match it if that plugin\'s Facebook app is in the same Business Manager as this pixel.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'          => 'low',
			'learn_more_link' => 'https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/customer-information-parameters',
			'since'           => 1786147200, // timestamp: August 8, 2026
		];
	}
}
