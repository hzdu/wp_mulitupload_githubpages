<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Nextdoor Advanced Matching
 *
 * @since 1.65.2
 */
class Nextdoor_Advanced_Matching extends Opportunity {

	public static function available() {

		// Nextdoor must be active
		if (!Options::is_nextdoor_active()) {
			return false;
		}

		// Advanced Matching must be disabled
		if (Options::is_nextdoor_advanced_matching_enabled()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'nextdoor-advanced-matching',
			'title'       => esc_html__(
				'Nextdoor Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Nextdoor Universal Pixel is enabled but Advanced Matching is not active.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Advanced Matching sends the hashed email address of logged-in customers and purchasers to Nextdoor, improving conversion attribution and audience matching, especially when cookies are blocked or users switch devices.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'medium',
			'setup_link'  => Documentation::get_link('nextdoor_advanced_matching'),
			'since'       => 1787097600, // timestamp: August 19, 2026
		];
	}
}
