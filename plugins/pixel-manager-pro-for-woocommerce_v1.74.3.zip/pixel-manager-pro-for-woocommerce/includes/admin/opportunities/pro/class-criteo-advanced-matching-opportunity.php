<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Criteo Advanced Matching
 *
 * @since 1.65.2
 */
class Criteo_Advanced_Matching extends Opportunity {

	public static function available() {

		// Criteo must be active
		if (!Options::is_criteo_active()) {
			return false;
		}

		// Advanced Matching must be disabled
		if (Options::is_criteo_advanced_matching_enabled()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'criteo-advanced-matching',
			'title'       => esc_html__(
				'Criteo Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Criteo OneTag is enabled but Advanced Matching is not active.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Advanced Matching sends the hashed email address of logged-in customers and purchasers to Criteo, improving conversion attribution and audience matching, especially when cookies are blocked or users switch devices.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'medium',
			'setup_link'  => Documentation::get_link('criteo_advanced_matching'),
			'since'       => 1787097600, // timestamp: August 19, 2026
		];
	}
}
