<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Pinterest API for Conversions
 *
 * @since 1.65.2
 */
class Pinterest_APIC extends Opportunity {

	public static function available() {

		// The Pinterest Tag must be enabled
		if (!Options::is_pinterest_active()) {
			return false;
		}

		// The Pinterest API for Conversions must be disabled
		if (Options::is_pinterest_apic_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'              => 'pinterest-apic',
			'title'           => esc_html__(
				'Pinterest API for Conversions',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description'     => [
				esc_html__(
					'The Pixel Manager detected that the Pinterest Tag is enabled, but the Pinterest API for Conversions has yet to be enabled. It needs both the Pinterest ad account ID and the API for Conversions token.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Enabling the Pinterest API for Conversions will improve conversion tracking accuracy and help you track more conversions that otherwise might get lost due to ad blockers or browser restrictions.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'          => 'high',
			'setup_link'      => Documentation::get_link('pinterest_apic_token'),
			'learn_more_link' => 'https://help.pinterest.com/en/business/article/the-pinterest-api-for-conversions',
			'since'           => 1787097600, // timestamp: August 19, 2026
		];
	}
}
