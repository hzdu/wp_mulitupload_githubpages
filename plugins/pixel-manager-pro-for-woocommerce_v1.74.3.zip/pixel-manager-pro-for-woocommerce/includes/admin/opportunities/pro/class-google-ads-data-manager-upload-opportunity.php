<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Tracking_Accuracy_DB;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Google Ads server-side conversion upload (Data Manager API)
 *
 * Shown while Google Ads purchase tracking runs in the browser only. On a free
 * install it carries the Pro note automatically (it lives in opportunities/pro/,
 * DD-088); on Pro it means the Google account is not connected yet, so the
 * upload, which activates on connect, is not running.
 *
 * @since 1.73.1
 */
class Google_Ads_Data_Manager_Upload extends Opportunity {

	/** Look-back window for the missed-orders sentence, matching the Google card. */
	const WINDOW_DAYS = 30;

	/** Below these the count would mislead (new shop, tracking just started). */
	const MIN_ORDERS  = 10;
	const MIN_TRACKED = 1;

	public static function available() {

		// Google Ads purchase conversion tracking must be configured
		if (!Options::is_google_ads_conversion_active()) {
			return false;
		}

		// The server-side upload must not be running already
		if (Options::is_google_ads_dm_active()) {
			return false;
		}

		return true;
	}

	/**
	 * Orders from the window whose confirmation page never ran the purchase
	 * tracking, read from the free tracking-accuracy table. Same arithmetic as
	 * the Payment Gateway Accuracy report: consent-denied orders are already
	 * outside orders_total, measured + acr were tracked in the browser.
	 *
	 * @return array|null { total: int, missed: int }, or null when not meaningful.
	 *
	 * @since 1.73.1
	 */
	public static function get_missed_orders() {
		return self::summarize_missed_orders(Tracking_Accuracy_DB::get_accuracy_data(self::WINDOW_DAYS));
	}

	/**
	 * The arithmetic behind get_missed_orders(), on rows shaped like
	 * Tracking_Accuracy_DB::get_accuracy_data() returns them.
	 *
	 * @param array $rows Each: { orders_total, orders_measured, orders_acr }.
	 * @return array|null
	 *
	 * @since 1.73.1
	 */
	public static function summarize_missed_orders( $rows ) {

		$total   = 0;
		$tracked = 0;
		$missed  = 0;

		foreach ((array) $rows as $row) {
			$row_tracked = (int) $row['orders_measured'] + (int) $row['orders_acr'];
			$total      += (int) $row['orders_total'];
			$tracked    += $row_tracked;
			$missed     += max(0, (int) $row['orders_total'] - $row_tracked);
		}

		if ($total < self::MIN_ORDERS || $tracked < self::MIN_TRACKED || $missed < 1) {
			return null;
		}

		return [
			'total'  => $total,
			'missed' => $missed,
		];
	}

	public static function card_data() {

		$description = [
			esc_html__(
				'Google Ads purchase conversions are currently reported by the browser only. Customers who pay in an app and never return to the order confirmation page, ad blockers and closed tabs keep those purchases from Google Ads, so campaigns look weaker than they are and Smart Bidding learns from fewer conversions.',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
		];

		$missed = self::get_missed_orders();

		if ($missed) {
			$description[] = sprintf(
				/* translators: 1: number of days, 2: missed orders, 3: all orders */
				esc_html__(
					'In the last %1$d days, %2$s of your %3$s orders never reached a tracked order confirmation page.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				self::WINDOW_DAYS,
				esc_html(number_format_i18n($missed['missed'])),
				esc_html(number_format_i18n($missed['total']))
			);
		}

		$description[] = esc_html__(
			'Connect your Google account with the Google setup assistant on the Google card (Tracking Pixels tab). Every paid order is then also uploaded to Google Ads server-side through the Data Manager API, into the same conversion action, and Google deduplicates the two sources by order number.',
			'woocommerce-google-adwords-conversion-tracking-tag'
		);

		return [
			'id'          => 'google-ads-data-manager-upload',
			'title'       => esc_html__(
				'Google Ads Server-Side Conversion Upload',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => $description,
			'impact'      => 'high',
			'setup_link'  => admin_url('admin.php?page=pmw#pixels'),
			'since'       => 1794787200, // 2026-11-16 00:00:00 UTC
		];
	}
}
