<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Environment;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: the Klaviyo plugin is installed but not connected to Klaviyo
 *
 * Placed Order, catalog and profile sync all come from Klaviyo polling the
 * shop through the WooCommerce REST API and the webhooks Klaviyo registers
 * when the integration is connected. A shop with the plugin active but no
 * such webhook is sending Klaviyo no orders at all. The same scan the Klaviyo
 * plugin runs to find its webhook secret tells the two states apart.
 *
 * The scan reads every registered webhook, so it runs at most once a day and
 * never on the frontend.
 *
 * @since 1.68.0
 */
class Klaviyo_Integration_Disconnected extends Opportunity {

	const TRANSIENT_KEY = 'pmw_klaviyo_integration_webhook_present';

	const MAX_WEBHOOKS_TO_SCAN = 10000;

	public static function available() {

		if (!Options::is_klaviyo_active()) {
			return false;
		}

		if (!Environment::is_klaviyo_plugin_active()) {
			return false;
		}

		return !self::is_integration_webhook_present();
	}

	/**
	 * Whether a WooCommerce webhook delivering to Klaviyo's WooCommerce
	 * integration endpoint exists.
	 *
	 * @return bool
	 * @since 1.68.0
	 */
	public static function is_integration_webhook_present() {

		$cached = get_transient(self::TRANSIENT_KEY);

		if (false !== $cached) {
			return 'yes' === $cached;
		}

		$present = self::scan_webhooks();

		set_transient(self::TRANSIENT_KEY, $present ? 'yes' : 'no', DAY_IN_SECONDS);

		return $present;
	}

	/**
	 * Look for a webhook whose delivery URL points at Klaviyo's WooCommerce
	 * integration. Mirrors the check in the Klaviyo plugin's webhook service.
	 *
	 * @return bool
	 * @since 1.68.0
	 */
	private static function scan_webhooks() {

		if (!class_exists('WC_Data_Store') || !function_exists('wc_get_webhook')) {
			// Without WooCommerce there is nothing to connect. Treat it as present
			// so the card stays quiet rather than nagging about a state that
			// cannot be fixed here.
			return true;
		}

		try {
			$data_store  = \WC_Data_Store::load('webhook');
			$webhook_ids = $data_store->get_webhooks_ids();
		} catch (\Exception $e) {
			return true;
		}

		foreach (array_slice((array) $webhook_ids, 0, self::MAX_WEBHOOKS_TO_SCAN) as $webhook_id) {

			$webhook = wc_get_webhook($webhook_id);

			if (!$webhook || 'active' !== $webhook->get_status()) {
				continue;
			}

			if (self::is_klaviyo_webhook_url($webhook->get_delivery_url())) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a webhook delivery URL is Klaviyo's WooCommerce integration endpoint.
	 *
	 * @param string $delivery_url
	 * @return bool
	 * @since 1.68.0
	 */
	public static function is_klaviyo_webhook_url( $delivery_url ) {

		$host = wp_parse_url($delivery_url, PHP_URL_HOST);
		$path = wp_parse_url($delivery_url, PHP_URL_PATH);

		if (!$host || !$path) {
			return false;
		}

		$is_klaviyo_host = 'klaviyo.com' === $host || '.klaviyo.com' === substr($host, -12);
		$is_integration  = false !== strpos($path, '/api/webhook/integration/woocommerce');

		return $is_klaviyo_host && $is_integration;
	}

	public static function card_data() {

		return [
			'id'          => 'klaviyo-integration-disconnected',
			'title'       => esc_html__(
				'Klaviyo is not receiving your orders',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Klaviyo plugin is active, but no webhook connecting this shop to Klaviyo\'s WooCommerce integration exists. Klaviyo gets Placed Order, Ordered Product, catalog and customer data by syncing the shop through that connection, so without it your Klaviyo account is receiving no orders.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Connect the WooCommerce integration in Klaviyo under Integrations. The Pixel Manager deliberately does not send orders while the Klaviyo plugin is active, because Klaviyo would count every order twice once the integration is connected.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('klaviyo_integration_disconnected'),
			'since'       => time(), // timestamp
		];
	}
}
