<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: AppLovin Conversion API
 *
 * @since 1.69.3
 */
class AppLovin_CAPI extends Opportunity {

	public static function available() {

		// The AppLovin pixel must be enabled
		if (!Options::is_applovin_active()) {
			return false;
		}

		// The AppLovin Conversion API must be disabled
		if (Options::is_applovin_capi_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'applovin-capi',
			'title'       => esc_html__(
				'AppLovin Conversion API',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the AppLovin pixel is enabled, but the AppLovin Conversion API has yet to be enabled.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Enabling the AppLovin Conversion API will improve conversion tracking accuracy and help you track more conversions that otherwise might get lost due to ad blockers or browser restrictions.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('applovin_capi_token'),
			'since'       => 1791072000, // timestamp: October 4, 2026
		];
	}
}
