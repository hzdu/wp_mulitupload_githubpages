<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Klaviyo Events API
 *
 * Only offered in standalone mode. Whenever the official Klaviyo plugin is
 * installed, Klaviyo produces Placed Order from its own order sync, and the
 * Events API would not add anything a merchant should turn on.
 *
 * @since 1.68.0
 */
class Klaviyo_Events_API extends Opportunity {

	public static function available() {

		// The Klaviyo pixel must be enabled and running without the Klaviyo plugin
		if (!Options::is_klaviyo_standalone_active()) {
			return false;
		}

		// The Events API must not be configured yet
		if (Options::is_klaviyo_events_api_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'klaviyo-events-api',
			'title'       => esc_html__(
				'Klaviyo Events API',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the Klaviyo pixel is enabled and the official Klaviyo plugin is not active, so nothing reports orders to Klaviyo server-side yet.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Adding a Klaviyo private API key lets the Pixel Manager send Placed Order, Ordered Product and Refunded Order events to Klaviyo server-side, which survives ad blockers and browser restrictions and gives your Klaviyo flows the order data they trigger on.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('klaviyo_events_api_token'),
			'since'       => time(), // timestamp
		];
	}
}
