<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Meta CAPI
 *
 * @since 1.29.2
 */
class Meta_CAPI extends Opportunity {

	public static function available() {

		// Facebook Pixel must be enabled
		if (!Options::is_facebook_active()) {
			return false;
		}

		// Facebook CAPI must be disabled
		if (Options::is_facebook_capi_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'meta-capi',
			'title'       => esc_html__(
				'Meta (Facebook) CAPI',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the Meta (Facebook) Pixel is enabled, but Meta (Facebook) CAPI has yet to be enabled.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Enabling Meta (Facebook) CAPI will improve conversion tracking accuracy overall.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('facebook_capi_token'),
			//              'learn_more_link' => '#',
			'since'       => 1673553471, // timestamp
		];
	}
}
