<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Environment;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: the Klaviyo takeover is blocked by an untested plugin version
 *
 * In automatic mode the Pixel Manager only takes over the Klaviyo plugin's
 * tracking for plugin versions the takeover was verified against. Outside
 * that range it falls back to filling the gaps, which means the plugin's own
 * tracking, without consent handling, is running again. The merchant should
 * know that, and can force the takeover after checking that it still works.
 *
 * @since 1.68.0
 */
class Klaviyo_Takeover_Blocked extends Opportunity {

	public static function available() {

		if (!Options::is_klaviyo_active()) {
			return false;
		}

		// Only automatic mode degrades. A forced mode is the merchant's decision.
		if ('auto' !== Options::get_klaviyo_coexistence_setting()) {
			return false;
		}

		if (!Environment::is_klaviyo_plugin_active()) {
			return false;
		}

		return !Environment::is_klaviyo_plugin_version_supported();
	}

	public static function card_data() {

		return [
			'id'          => 'klaviyo-takeover-blocked',
			'title'       => esc_html__(
				'Klaviyo tracking is running without consent handling',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				sprintf(
					/* translators: %s: the version of the Klaviyo plugin */
					esc_html__(
						'The installed Klaviyo plugin version %s has not been verified with the Pixel Manager yet, so the Pixel Manager is not taking over its tracking and only sends the events the Klaviyo plugin does not send.',
						'woocommerce-google-adwords-conversion-tracking-tag'
					),
					Environment::get_klaviyo_plugin_version()
				),
				esc_html__(
					'The Klaviyo plugin loads its tracking without any consent handling and detects checkouts through fragile selectors. Update the Pixel Manager once a version verified for this Klaviyo release is available, or set the coexistence mode to take over the tracking after confirming it works on your shop.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('klaviyo_coexistence'),
			'since'       => time(), // timestamp
		];
	}
}
