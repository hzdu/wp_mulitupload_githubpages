<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Microsoft Advertising Conversions API
 *
 * @since 1.65.2
 */
class Microsoft_Ads_CAPI extends Opportunity {

	public static function available() {

		// The Microsoft Advertising UET tag must be enabled
		if (!Options::is_bing_active()) {
			return false;
		}

		// The Microsoft Advertising Conversions API must be disabled
		if (Options::is_bing_capi_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'microsoft-ads-capi',
			'title'       => esc_html__(
				'Microsoft Advertising Conversions API',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the Microsoft Advertising UET tag is enabled, but the Microsoft Advertising Conversions API has yet to be enabled.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Enabling the Microsoft Advertising Conversions API will improve conversion tracking accuracy and help you track more conversions that otherwise might get lost due to ad blockers or browser restrictions.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('bing_capi_token'),
			'since'       => time(), // timestamp
		];
	}
}
