<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Mixpanel Ingestion API
 *
 * @since 1.64.1
 */
class Mixpanel_Ingestion_API extends Opportunity {

	public static function available() {

		// The Mixpanel pixel must be enabled
		if (!Options::is_mixpanel_active()) {
			return false;
		}

		// The Mixpanel Ingestion API must be disabled
		if (Options::is_mixpanel_ingestion_api_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'mixpanel-ingestion-api',
			'title'       => esc_html__(
				'Mixpanel Ingestion API',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the Mixpanel pixel is enabled, but the Mixpanel Ingestion API has yet to be enabled.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Enabling the Mixpanel Ingestion API sends purchases to Mixpanel server-side, which recovers orders that otherwise get lost to ad blockers and browser restrictions. It also reports refunds, which Mixpanel never sees from the browser at all.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'No additional credential is needed. The Mixpanel project token authenticates the server-side requests as well.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('mixpanel_ingestion_api'),
			'since'       => time(), // timestamp
		];
	}
}
