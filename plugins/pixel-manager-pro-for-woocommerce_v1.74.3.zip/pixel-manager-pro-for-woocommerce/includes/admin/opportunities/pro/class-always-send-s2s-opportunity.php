<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Always send server-side events
 *
 * Since server-side purchase events honor the visitor's consent choice,
 * shops with explicit consent management lose the server-side purchase
 * events of visitors who deny consent. Shop managers who determine that
 * they are allowed to send those events can enable the always_send_s2s
 * setting to send server-side events regardless of the consent state.
 *
 * @since 1.62.0
 */
class Always_Send_S2S extends Opportunity {

	/**
	 * Check if the opportunity is available.
	 *
	 * Requirements:
	 * - The always_send_s2s setting is NOT enabled
	 * - At least one pixel has active S2S/CAPI tracking
	 *
	 * @return bool
	 * @since 1.62.0
	 */
	public static function available() {

		// The setting must NOT be active, the opportunity is to enable it
		if ( Options::is_always_send_s2s_active() ) {
			return false;
		}

		// At least one S2S/CAPI pixel must be active
		if ( empty( Options::pixels_with_active_s2s() ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Get the opportunity card data.
	 *
	 * @return array
	 * @since 1.62.0
	 */
	public static function card_data() {

		return [
			'id'              => 'always-send-s2s',
			'title'           => esc_html__(
				'Keep Server-Side Purchase Tracking Complete',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description'     => [
				esc_html__(
					'Server-side purchase events (S2S/CAPI) honor the consent choice visitors make in your consent banner. When a visitor denies consent, the purchase event is not sent to the ad and analytics platforms.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'If you have determined that you are permitted to send server-side events independently of the visitor\'s consent choice, enable the "Always send server-side events" setting in the general settings. The legal assessment is yours to make for your shop and jurisdiction.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'          => 'medium',
			'setup_link'      => Documentation::get_link( 'always_send_s2s' ),
			'learn_more_link' => Documentation::get_link( 'always_send_s2s' ),
			'since'           => 1782950400, // 2026-07-02 00:00:00 UTC
		];
	}
}
