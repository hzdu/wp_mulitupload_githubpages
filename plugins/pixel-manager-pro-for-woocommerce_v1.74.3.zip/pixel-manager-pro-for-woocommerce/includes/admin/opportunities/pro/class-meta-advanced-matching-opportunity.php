<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Free;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Meta (Facebook) Advanced Matching
 *
 * @since 1.58.1
 */
class Meta_Advanced_Matching extends Opportunity {

	public static function available() {

		// Facebook CAPI must be active (CAPI is a prerequisite for advanced matching)
		if (!Options::is_facebook_capi_active()) {
			return false;
		}

		// Advanced Matching must be disabled
		if (Options::is_facebook_capi_advanced_matching_enabled()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'              => 'meta-advanced-matching',
			'title'           => esc_html__(
				'Meta (Facebook) Advanced Matching',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description'     => [
				esc_html__(
					'Meta (Facebook) CAPI is enabled but Advanced Matching is not active.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Advanced Matching sends hashed customer data (e.g. email, phone, name) to Meta, improving conversion attribution and audience matching, especially when cookies are blocked or users switch devices.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'          => 'medium',
			'setup_link'      => Documentation::get_link('facebook_advanced_matching'),
			'learn_more_link' => 'https://developers.facebook.com/docs/meta-pixel/advanced/advanced-matching',
			'since'           => 1741046400, // timestamp: March 4, 2025
		];
	}
}
