<?php

namespace SweetCode\Pixel_Manager\Admin\Opportunities\Pro;

use SweetCode\Pixel_Manager\Admin\Documentation;
use SweetCode\Pixel_Manager\Admin\Opportunities\Opportunity;
use SweetCode\Pixel_Manager\Options;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Opportunity: Spotify Conversions API
 *
 * @since 1.69.0
 */
class Spotify_CAPI extends Opportunity {

	public static function available() {

		// The Spotify Ad Analytics pixel must be enabled
		if (!Options::is_spotify_active()) {
			return false;
		}

		// The Spotify Conversions API must be disabled
		if (Options::is_spotify_capi_active()) {
			return false;
		}

		return true;
	}

	public static function card_data() {

		return [
			'id'          => 'spotify-capi',
			'title'       => esc_html__(
				'Spotify Conversions API',
				'woocommerce-google-adwords-conversion-tracking-tag'
			),
			'description' => [
				esc_html__(
					'The Pixel Manager detected that the Spotify Ads pixel is enabled, but the Spotify Conversions API has yet to be enabled.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
				esc_html__(
					'Enabling the Spotify Conversions API will improve conversion tracking accuracy and help you track more conversions that otherwise might get lost due to ad blockers or browser restrictions.',
					'woocommerce-google-adwords-conversion-tracking-tag'
				),
			],
			'impact'      => 'high',
			'setup_link'  => Documentation::get_link('spotify_capi_token'),
			'since'       => 1789344000, // timestamp: September 14, 2026
		];
	}
}
