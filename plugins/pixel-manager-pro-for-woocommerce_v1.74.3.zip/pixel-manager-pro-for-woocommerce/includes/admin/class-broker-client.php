<?php

namespace SweetCode\Pixel_Manager\Admin;

use SweetCode\Pixel_Manager\Helpers;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Client for the PMW connection broker (https://pmw.sweetcode.com).
 *
 * The broker lets a shop manager connect their Google account once and then
 * pick or create a Google Ads purchase conversion action (and a GA4 web data
 * stream) without copy-pasting IDs. The merchant's Google refresh token is
 * stored encrypted on the broker and never reaches this site; this class only
 * holds the per-site bearer token issued during enrollment.
 *
 * The Google routes are public since 1.73.1: Google verified the OAuth
 * consent screen for the adwords, analytics.edit and datamanager scopes on
 * 2026-11-16, so any shop can connect, not only members of the Cloud project.
 * The Meta routes stay behind Helpers::is_experiment() (EXPERIMENTAL_PMW /
 * PMW_EXPERIMENTS in wp-config.php) until Meta App Review grants Advanced
 * Access. The manual conversion ID and label fields remain the primary path
 * and always win.
 *
 * Flow (see pmw-web docs/oauth-broker-design.md):
 *  1. enroll: the broker issues a challenge, this site serves it on a public
 *     endpoint, the broker verifies it and issues the per-site token.
 *  2. connect: browser redirect to the broker -> Google consent -> back to
 *     wp-admin with pmw_connected=1 or pmw_connect_error=<code>.
 *  3. configure: authenticated proxy calls to list/create conversion actions
 *     and data streams; the resulting IDs are saved through the normal
 *     settings pipeline.
 *
 * @since 1.63.0
 */
class Broker_Client {

	private static $instance;

	protected static $rest_namespace = 'pmw/v1';

	/**
	 * Option holding the broker enrollment state:
	 * [ 'site_id' => string, 'site_token' => string, 'enrolled_at' => int ]
	 * Not autoloaded; the token is only needed on broker proxy calls.
	 */
	const OPTION_KEY = 'pmw_broker';

	/** Transient holding the broker-issued enrollment challenge (10 min). */
	const CHALLENGE_TRANSIENT = 'pmw_broker_challenge';

	/**
	 * The shape of a broker-issued site token: 64 hex characters. The broker
	 * has never issued anything else and rejects anything else, so a stored
	 * value failing this pattern is not a credential, whatever it is.
	 */
	const TOKEN_PATTERN = '/^[0-9a-f]{64}\\z/';

	/**
	 * How many rejections in a row (HTTP 401) write the stored token off.
	 *
	 * A credential the broker refuses does not become valid by being sent
	 * again, so the answer to the second refusal cannot be a third attempt.
	 * More than one is required because a single 401 does not prove the token
	 * is at fault: a proxy or security layer that strips the Authorization
	 * header for one request produces the same status, and that must not cost
	 * the site its enrollment.
	 *
	 * Deliberately below the broker's own per-address allowance (5 rejected
	 * credentials a day, after which it stops answering each one individually):
	 * a plugin that stops on its own never reaches the point where the broker
	 * has to stop it.
	 */
	const AUTH_REJECTION_LIMIT = 3;

	/**
	 * Option holding VERIFIED reconnect incidents per provider:
	 * [ 'google' => [ 'flagged_at' => int, 'notified' => bool, 'dismissed' => bool ], 'meta' => ... ]
	 * An entry only exists while the broker reports needs_reconnect, which it
	 * flags exclusively on definitive auth failures (Google invalid_grant,
	 * Meta OAuthException/expiry). Transient errors never create an incident.
	 */
	const HEALTH_OPTION = 'pmw_broker_health';

	/**
	 * The most recent failed enrollment, kept for the debug report, so support
	 * sees why a shop could not connect without asking for screenshots.
	 *
	 * @since 1.74.2
	 */
	const ENROLL_ERROR_OPTION = 'pmw_broker_enroll_error';

	/** Daily WP-Cron hook polling the broker for verified reconnect flags. */
	const HEALTH_CRON_HOOK = 'pmw_broker_health_check';

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		add_action('rest_api_init', [ $this, 'register_routes' ]);
		add_action(self::HEALTH_CRON_HOOK, [ __CLASS__, 'run_health_check' ]);
		add_action('admin_init', [ __CLASS__, 'manage_health_cron_schedule' ]);
		add_action('admin_init', [ __CLASS__, 'handle_notice_dismissal' ]);
		add_action('admin_notices', [ __CLASS__, 'render_reconnect_notices' ]);
	}

	/**
	 * The broker base URL.
	 *
	 * @return string
	 */
	public static function get_broker_url() {

		/**
		 * Filters the broker base URL, so dev setups can point at a local broker.
		 *
		 * @param string $broker_url The broker base URL.
		 *
		 * @since 1.62.1
		 */
		return untrailingslashit(apply_filters('pmw_broker_url', 'https://pmw.sweetcode.com'));
	}

	// Extracted the code because the QIT semgrep rule was triggered
	public function can_current_user_edit_options() {
		return Environment::can_current_user_edit_options();
	}

	/**
	 * Permission callback for the public /broker/challenge endpoint.
	 *
	 * Public BY DESIGN (ACME http-01 style): the challenge is a broker-generated
	 * one-time value that only exists for the ~10 minutes of an enrollment
	 * started by an admin of this site, and reading it proves nothing.
	 * Named method instead of an inline closure because the QIT semgrep rule
	 * rest-route.permission-callback.return-true flags inline callbacks.
	 *
	 * @return bool
	 */
	public function is_challenge_endpoint_public() {
		return true;
	}

	public function register_routes() {

		/**
		 * Public enrollment challenge endpoint. Public BY DESIGN: the value is
		 * generated by the broker for one specific enrollment attempt, so
		 * reading it proves nothing (ACME http-01 style). It exists only for
		 * the ~10 minutes of an enrollment started by an admin of this site.
		 */
		register_rest_route(self::$rest_namespace, '/broker/challenge', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => function () {

				$challenge = get_transient(self::CHALLENGE_TRANSIENT);

				if (!$challenge) {
					return new \WP_REST_Response([ 'challenge' => null ], 404);
				}

				return new \WP_REST_Response([ 'challenge' => $challenge ], 200);
			},
			'permission_callback' => [ $this, 'is_challenge_endpoint_public' ],
		]);

		// All routes below are admin-only proxies to the broker.

		register_rest_route(self::$rest_namespace, '/broker/status', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'handle_status' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/connect/start', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'handle_connect_start' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/disconnect', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'handle_disconnect' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ads/customers', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'handle_ads_customers' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ads/customers/(?P<cid>\d+)/conversions', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'handle_ads_conversions_list' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ads/conversions', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'handle_ads_conversions_create' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ads/select', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'handle_ads_select' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(
			self::$rest_namespace,
			'/broker/ads/customers/(?P<cid>\d+)/conversions/(?P<id>\d+)/label',
			[
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => [ $this, 'handle_ads_label' ],
				'permission_callback' => [ $this, 'can_current_user_edit_options' ],
			]
		);

		register_rest_route(self::$rest_namespace, '/broker/ads/datamanager/status', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'handle_ads_datamanager_status' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ga4/accounts', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'handle_ga4_accounts' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ga4/properties', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'handle_ga4_properties_create' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ga4/properties/(?P<id>\d+)/streams', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ $this, 'handle_ga4_streams_list' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ga4/streams', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'handle_ga4_streams_create' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		register_rest_route(self::$rest_namespace, '/broker/ga4/select', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'handle_ga4_select' ],
			'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		// Meta connect is experiment-gated independently of Google's assistant
		// (Meta App Review must pass before its public release), so it keeps
		// its own gate for when the outer one lifts.
		if (Helpers::is_experiment()) {

			register_rest_route(self::$rest_namespace, '/broker/meta/status', [
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => [ $this, 'handle_meta_status' ],
				'permission_callback' => [ $this, 'can_current_user_edit_options' ],
			]);

			register_rest_route(self::$rest_namespace, '/broker/meta/connect/start', [
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'handle_meta_connect_start' ],
				'permission_callback' => [ $this, 'can_current_user_edit_options' ],
			]);

			register_rest_route(self::$rest_namespace, '/broker/meta/disconnect', [
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'handle_meta_disconnect' ],
				'permission_callback' => [ $this, 'can_current_user_edit_options' ],
			]);

			register_rest_route(self::$rest_namespace, '/broker/meta/pixels', [
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => [ $this, 'handle_meta_pixels' ],
				'permission_callback' => [ $this, 'can_current_user_edit_options' ],
			]);

			register_rest_route(self::$rest_namespace, '/broker/meta/select', [
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'handle_meta_select' ],
				'permission_callback' => [ $this, 'can_current_user_edit_options' ],
			]);
		}
	}

	// ─── Enrollment state ───────────

	private static function get_state() {
		$state = get_option(self::OPTION_KEY);
		return is_array($state) ? $state : [];
	}

	private static function save_state( $state ) {
		update_option(self::OPTION_KEY, $state, false);
	}

	/**
	 * Whether this site holds a credential the broker can be expected to
	 * accept, not merely whether some string is stored. Every caller either
	 * proxies a request to the broker or tells the UI the site is set up, and
	 * both are wrong for a credential that is already dead.
	 *
	 * Two states are written off:
	 *
	 *  - A token that is not the broker's 64-hex shape. It can never
	 *    authenticate, so sending it is pure noise. Seen live: an install
	 *    holding a 17-character token called /v1/status and /v1/meta/status on
	 *    every settings-page render for days, collecting a 401 each time,
	 *    until the broker throttled the address, while showing a connection
	 *    error where the Connect button belonged.
	 *  - A well-formed token the broker has rejected AUTH_REJECTION_LIMIT
	 *    times in a row, which is what a rotated-out token or a site removed
	 *    broker-side looks like from here.
	 *
	 * Both resolve the same way, and resolve themselves: the site counts as
	 * not enrolled, the status routes answer locally instead of calling out,
	 * the UI offers Connect, and that button re-enrolls. Re-enrollment
	 * re-proves control of the domain and replaces the token, so the Google or
	 * Meta connection the broker still holds for this site URL survives it.
	 *
	 * @return bool
	 */
	public static function is_enrolled() {
		return self::has_usable_token(self::get_state());
	}

	/**
	 * Whether the stored state carries a credential worth presenting.
	 *
	 * @param array $state
	 * @return bool
	 */
	private static function has_usable_token( $state ) {

		if (empty($state['site_token']) || !is_string($state['site_token'])) {
			return false;
		}

		if (!preg_match(self::TOKEN_PATTERN, $state['site_token'])) {
			return false;
		}

		return self::rejection_count($state) < self::AUTH_REJECTION_LIMIT;
	}

	/**
	 * How many times in a row the broker has refused the stored token.
	 *
	 * @param array $state
	 * @return int
	 */
	private static function rejection_count( $state ) {
		return isset($state['auth_rejections']) ? (int) $state['auth_rejections'] : 0;
	}

	/**
	 * Count a rejection of the stored token. Only the broker's verdict on the
	 * credential itself counts (HTTP 401); a 429, a 5xx or an unreachable
	 * broker says nothing about it. The count is consecutive (any accepted
	 * response clears it), so only a token that is genuinely finished reaches
	 * the limit.
	 */
	private static function record_auth_rejection() {

		$state = self::get_state();

		if (empty($state['site_token'])) {
			return;
		}

		$count = self::rejection_count($state);

		if ($count >= self::AUTH_REJECTION_LIMIT) {
			return;
		}

		$state['auth_rejections'] = $count + 1;
		self::save_state($state);
	}

	/** Forget the rejections: the broker accepted this token after all. */
	private static function clear_auth_rejections() {

		$state = self::get_state();

		if (0 === self::rejection_count($state)) {
			return;
		}

		unset($state['auth_rejections']);
		self::save_state($state);
	}

	/**
	 * Whether the site's Google account is currently CONNECTED on the broker,
	 * as of the last broker response this site saw. Enrollment survives a
	 * disconnect by design, so features that need a working Google grant
	 * (the Data Manager upload, refund adjustments) must check this, never
	 * is_enrolled(). Sites enrolled before this flag existed fall back to
	 * is_enrolled() until the next status response records the real state.
	 *
	 * @return bool
	 */
	public static function is_google_connected() {

		// A credential the broker will not accept cannot carry an upload
		// either: the Data Manager calls gated on this answer travel with the
		// very token that was refused.
		if (!self::is_enrolled()) {
			return false;
		}

		$state = self::get_state();

		if (!array_key_exists('google_connected', $state)) {
			return true;
		}

		return !empty($state['google_connected']);
	}

	/** Record the connection state carried by a broker response. */
	private static function set_google_connected( $connected ) {

		$state = self::get_state();

		if (empty($state['site_token'])) {
			return;
		}

		$connected = (bool) $connected;

		if (array_key_exists('google_connected', $state) && $state['google_connected'] === $connected) {
			return;
		}

		$state['google_connected'] = $connected;
		self::save_state($state);
	}

	/**
	 * The site base URL the broker enrolls: the frontend home URL, https,
	 * no trailing slash. Must match where /wp-json/pmw/v1/broker/challenge
	 * is publicly reachable.
	 *
	 * @return string
	 */
	private static function get_site_base_url() {
		return untrailingslashit(home_url());
	}

	// ─── Connection health: verified reconnect alerts ───────────
	//
	// Two detection channels feed the same incident state:
	//  1. Inline: any broker response carrying code NEEDS_RECONNECT (server-to-
	//     server uploads, wizard calls) flags the incident the moment the first
	//     call fails.
	//  2. Daily WP-Cron: polls the broker status endpoints, which reflect the
	//     broker's own daily credential verification, so revocation on an
	//     otherwise idle site is caught within a day.
	// One email per incident to the site admin, plus a dismissible admin
	// notice. The incident clears itself as soon as a status check sees the
	// connection healthy again (immediately after a reconnect).

	private static function get_health() {
		$health = get_option(self::HEALTH_OPTION);
		return is_array($health) ? $health : [];
	}

	private static function save_health( $health ) {

		if (empty($health)) {
			delete_option(self::HEALTH_OPTION);
		} else {
			update_option(self::HEALTH_OPTION, $health, false);
		}
	}

	/**
	 * Keep the daily health check scheduled exactly while the site is
	 * enrolled. Runs on admin_init; the check is cheap (one option read).
	 */
	public static function manage_health_cron_schedule() {

		$active    = self::is_enrolled();
		$scheduled = wp_next_scheduled(self::HEALTH_CRON_HOOK);

		if ($active && !$scheduled) {
			wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::HEALTH_CRON_HOOK);
		} elseif (!$active && $scheduled) {
			wp_unschedule_event($scheduled, self::HEALTH_CRON_HOOK);
		}
	}

	/**
	 * Daily cron: sync incident state with the broker. Only OK responses
	 * change anything; an unreachable broker must never raise (or clear)
	 * an alert.
	 */
	public static function run_health_check() {

		if (!self::is_enrolled()) {
			self::save_health([]);
			return;
		}

		$google = self::broker_request('GET', '/v1/status');

		if ($google['ok']) {
			self::set_google_connected(!empty($google['body']['connected']));

			if (!empty($google['body']['needsReconnect'])) {
				self::flag_reconnect_incident('google');
			} else {
				self::clear_reconnect_incident('google');
			}

			/**
			 * Fires after the daily status sync with the connection service.
			 *
			 * The status carries more than connection health: it is also where
			 * the service asks this shop to do work only the shop can do, such
			 * as re-sending uploads that failed. An action rather than a direct
			 * call, because the listeners live in premium-only classes this
			 * file must not name.
			 *
			 * @since 1.71.1
			 *
			 * @param array $status The decoded /v1/status response body.
			 */
			do_action('pmw_broker_status_synced', $google['body']);
		}

		$meta = self::broker_request('GET', '/v1/meta/status');

		if ($meta['ok']) {
			if (!empty($meta['body']['needsReconnect'])) {
				self::flag_reconnect_incident('meta');
			} else {
				self::clear_reconnect_incident('meta');
			}
		}
	}

	/**
	 * Record a verified reconnect incident and email the site admin once.
	 * Idempotent: a provider that is already flagged is left untouched, so
	 * repeated failing calls never send repeated emails.
	 *
	 * @param string $provider 'google' or 'meta'.
	 */
	private static function flag_reconnect_incident( $provider ) {

		// A verified dead Google grant also deactivates everything that
		// depends on the connection, so uploads stop retrying against it.
		if ('google' === $provider) {
			self::set_google_connected(false);
		}

		$health = self::get_health();

		if (isset($health[ $provider ])) {
			return;
		}

		$health[ $provider ] = [
			'flagged_at' => time(),
			'notified'   => false,
			'dismissed'  => false,
		];

		$health[ $provider ]['notified'] = self::send_reconnect_email($provider);

		self::save_health($health);
	}

	private static function clear_reconnect_incident( $provider ) {

		$health = self::get_health();

		if (!isset($health[ $provider ])) {
			return;
		}

		unset($health[ $provider ]);
		self::save_health($health);
	}

	private static function get_provider_label( $provider ) {
		return 'meta' === $provider ? 'Meta' : 'Google';
	}

	/** Settings page deep link that opens the provider's card (pmw_open). */
	private static function get_reconnect_url( $provider ) {
		return admin_url('admin.php?page=pmw&pmw_open=' . rawurlencode($provider) . '#pixels');
	}

	/**
	 * One-time incident email to the site admin.
	 *
	 * @param string $provider 'google' or 'meta'.
	 *
	 * @return bool Whether wp_mail accepted the message.
	 */
	private static function send_reconnect_email( $provider ) {

		$to = get_option('admin_email');

		if (!$to || !is_email($to)) {
			return false;
		}

		$label     = self::get_provider_label($provider);
		$site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);

		$subject = sprintf(
		/* translators: 1: site name, 2: provider name (Google or Meta) */
			esc_html__('[%1$s] Action needed: reconnect your %2$s account in the Pixel Manager', 'woocommerce-google-adwords-conversion-tracking-tag'),
			$site_name,
			$label
		);

		$message = sprintf(
		/* translators: 1: provider name (Google or Meta), 2: site name */
			esc_html__('The Pixel Manager connection to your %1$s account on %2$s is no longer valid and needs to be re-authorized. This happens when the authorization is revoked, the password is reset with a global sign-out, or the account that granted access is closed.', 'woocommerce-google-adwords-conversion-tracking-tag'),
			$label,
			$site_name
		)
			. "\n\n"
			. esc_html__('Features that depend on this connection will not work until it is reconnected. Reconnecting takes one click plus a login:', 'woocommerce-google-adwords-conversion-tracking-tag')
			. "\n\n"
			. self::get_reconnect_url($provider)
			. "\n\n"
			. esc_html__('You will only receive this email once per incident.', 'woocommerce-google-adwords-conversion-tracking-tag');

		return (bool) wp_mail($to, $subject, $message);
	}

	/**
	 * Red admin notice per open incident, for users who can fix it.
	 * Dismissible per incident: a new incident shows the notice again.
	 */
	public static function render_reconnect_notices() {

		if (!Environment::can_current_user_edit_options()) {
			return;
		}

		$health = self::get_health();

		foreach ([ 'google', 'meta' ] as $provider) {

			if (empty($health[ $provider ]) || !empty($health[ $provider ]['dismissed'])) {
				continue;
			}

			$dismiss_url = wp_nonce_url(
				add_query_arg('pmw_broker_dismiss', $provider),
				'pmw_broker_dismiss_' . $provider
			);

			echo '<div class="notice notice-error"><p><strong>'
				. sprintf(
				/* translators: %s: provider name (Google or Meta) */
					esc_html__('Pixel Manager: The connection to your %s account needs to be re-authorized.', 'woocommerce-google-adwords-conversion-tracking-tag'),
					esc_html(self::get_provider_label($provider))
				)
				. '</strong> '
				. esc_html__('Features that depend on it will not work until you reconnect.', 'woocommerce-google-adwords-conversion-tracking-tag')
				. ' <a href="' . esc_url(self::get_reconnect_url($provider)) . '">'
				. esc_html__('Reconnect now', 'woocommerce-google-adwords-conversion-tracking-tag')
				. '</a> | <a href="' . esc_url($dismiss_url) . '">'
				. esc_html__('Dismiss', 'woocommerce-google-adwords-conversion-tracking-tag')
				. '</a></p></div>';
		}
	}

	/** Handle the notice's Dismiss link (nonce-checked, per provider). */
	public static function handle_notice_dismissal() {

		if (!isset($_GET['pmw_broker_dismiss'])) {
			return;
		}

		$provider = sanitize_key(wp_unslash($_GET['pmw_broker_dismiss']));

		if (!in_array($provider, [ 'google', 'meta' ], true)) {
			return;
		}

		if (!Environment::can_current_user_edit_options()) {
			return;
		}

		check_admin_referer('pmw_broker_dismiss_' . $provider);

		$health = self::get_health();

		if (isset($health[ $provider ])) {
			$health[ $provider ]['dismissed'] = true;
			self::save_health($health);
		}

		wp_safe_redirect(remove_query_arg([ 'pmw_broker_dismiss', '_wpnonce' ]));
		exit;
	}

	// ─── Route handlers ───────────

	/**
	 * GET /broker/status: enrollment + per-provider readiness. Cheap local
	 * answer when not enrolled; otherwise proxied to the broker.
	 */
	public function handle_status() {

		if (!self::is_enrolled()) {
			return new \WP_REST_Response(
				[
					'ok'        => true,
					'enrolled'  => false,
					'connected' => false,
					'ga4'       => 'not_connected',
					'ads'       => 'not_connected',
				],
				200
			);
		}

		$result = self::broker_request('GET', '/v1/status');

		if (!$result['ok']) {
			return self::error_response($result);
		}

		$body             = $result['body'];
		$body['enrolled'] = true;

		self::set_google_connected(!empty($body['connected']));

		// A healthy status clears an open incident immediately, so the admin
		// notice disappears right after a reconnect (the settings page calls
		// this endpoint on load).
		if (!empty($body['connected']) && empty($body['needsReconnect'])) {
			self::clear_reconnect_incident('google');
		}

		return new \WP_REST_Response($body, 200);
	}

	/**
	 * A URL the broker may send the browser back to: one on this site's host.
	 * The broker redirects to it after the connect, so an off-site value would
	 * turn the flow into an open redirect. @since 1.69.1
	 *
	 * @param mixed $url
	 * @return string The URL, or an empty string.
	 */
	public static function same_site_url( $url ) {

		$url = esc_url_raw((string) $url);

		if ('' === $url) {
			return '';
		}

		$host = wp_parse_url($url, PHP_URL_HOST);
		$home = wp_parse_url(home_url(), PHP_URL_HOST);

		return ( $host && $home && strtolower($host) === strtolower($home) ) ? $url : '';
	}

	/**
	 * POST /broker/connect/start: begin the Google connect. Enrolls the site
	 * first when needed (one button does both). Returns the redirect URL the
	 * browser must navigate to (top-level redirect, not a popup).
	 */
	public function handle_connect_start( $request ) {

		$params     = $request->get_json_params();
		$return_url = ( is_array($params) && isset($params['returnUrl']) ) ? self::same_site_url($params['returnUrl']) : '';

		if (!$return_url) {
			return new \WP_REST_Response(
				[
					'ok'      => false,
					'code'    => 'BAD_REQUEST',
					'message' => 'returnUrl is required.',
				],
				400
			);
		}

		if (!self::is_enrolled()) {
			$enroll = self::enroll();

			if (!$enroll['ok']) {
				return self::error_response($enroll);
			}
		}

		$result = self::broker_request('POST', '/v1/connect/start', [ 'returnUrl' => $return_url ]);

		// A stale or replaced token cannot start a connect. Re-enroll once
		// (re-proves site control, replaces the token) and retry.
		if (!$result['ok'] && 401 === $result['status']) {
			$enroll = self::enroll();

			if ($enroll['ok']) {
				$result = self::broker_request('POST', '/v1/connect/start', [ 'returnUrl' => $return_url ]);
			}
		}

		if (!$result['ok']) {
			return self::error_response($result);
		}

		return new \WP_REST_Response($result['body'], 200);
	}

	/**
	 * POST /broker/disconnect: revoke at Google and purge the broker-side
	 * credentials. The enrollment (site token) survives so reconnecting is
	 * one click.
	 */
	public function handle_disconnect() {

		if (!self::is_enrolled()) {
			return new \WP_REST_Response([ 'ok' => true ], 200);
		}

		$result = self::broker_request('POST', '/v1/disconnect');

		if (!$result['ok']) {
			return self::error_response($result);
		}

		// The Google grant is gone: everything that depends on it deactivates
		// (Data Manager upload, refund adjustments), the stale last-upload
		// record disappears from the UI, and a pending reconnect incident is
		// moot because the disconnect was deliberate.
		self::set_google_connected(false);
		self::clear_reconnect_incident('google');
		delete_option('pmw_google_dma_last_upload');

		return new \WP_REST_Response($result['body'], 200);
	}

	public function handle_ads_customers() {
		return self::proxy('GET', '/v1/ads/customers');
	}

	public function handle_ads_conversions_list( $request ) {

		$path  = '/v1/ads/customers/' . rawurlencode($request['cid']) . '/conversions';
		$query = [];
		$login = $request->get_param('login');

		if ($login && preg_match('/^\d+$/', $login)) {
			$query[] = 'login=' . rawurlencode($login);
		}

		// all=1 includes unlabeled actions (imports, GA4 imports) so the Data
		// Manager upload's conversion action picker can offer and classify them.
		if ('1' === $request->get_param('all')) {
			$query[] = 'all=1';
		}

		if (!empty($query)) {
			$path .= '?' . implode('&', $query);
		}

		return self::proxy('GET', $path);
	}

	public function handle_ads_conversions_create( $request ) {
		return self::proxy('POST', '/v1/ads/conversions', self::pick_params($request, [ 'customerId', 'name', 'loginCustomerId' ]));
	}

	public function handle_ads_select( $request ) {
		return self::proxy('POST', '/v1/ads/select', self::pick_params($request, [ 'customerId', 'conversionActionId', 'loginCustomerId' ]));
	}

	public function handle_ads_label( $request ) {

		$path = '/v1/ads/customers/' . rawurlencode($request['cid'])
			. '/conversions/' . rawurlencode($request['id']) . '/label';

		$login = $request->get_param('login');

		if ($login && preg_match('/^\d+$/', $login)) {
			$path .= '?login=' . rawurlencode($login);
		}

		return self::proxy('GET', $path);
	}

	/**
	 * GET /broker/ads/datamanager/status: whether the site's stored Google
	 * grant includes the Data Manager API scope. The Nova UI uses this to
	 * decide whether the broker auth method can be offered for the
	 * experimental Google Ads Data Manager upload.
	 */
	public function handle_ads_datamanager_status() {

		if (!self::is_enrolled()) {
			return new \WP_REST_Response(
				[
					'ok'                      => true,
					'enrolled'                => false,
					'datamanagerScopeGranted' => false,
				],
				200
			);
		}

		$result = self::broker_request('GET', '/v1/ads/datamanager/status');

		if (!$result['ok']) {
			return self::error_response($result);
		}

		$body             = $result['body'];
		$body['enrolled'] = true;

		return new \WP_REST_Response($body, 200);
	}

	/**
	 * Server-to-server: forward a Data Manager API events:ingest request to
	 * the broker, which exchanges its stored Google grant for an access token
	 * and relays the request to Google. Used by the experimental Google Ads
	 * Data Manager upload when the auth method is set to broker.
	 *
	 * @param array $payload     The full events:ingest request body.
	 * @param bool  $is_backfill Whether this recovers an upload that failed
	 *                           earlier, rather than carrying a live purchase.
	 *
	 * @return array { success: bool, code: int, request_id: string, error_message: string, field_warnings: array[] }
	 *
	 * @since 1.66.0
	 */
	public static function datamanager_ingest( $payload, $is_backfill = false ) {

		// The broker holds a daily allowance per site with a reserve for live
		// conversions. A backfill says so, so recovering an old order can
		// never be the reason a new purchase fails to upload. @since 1.71.1
		$headers = $is_backfill ? [ 'X-PMW-DMA-Backfill' => '1' ] : [];

		$result = self::broker_request('POST', '/v1/ads/datamanager/ingest', $payload, true, $headers);

		$error_message = '';

		if (!$result['ok'] && isset($result['body']['message'])) {
			$error_message = (string) $result['body']['message'];
		}

		$request_id = '';

		if (isset($result['body']['requestId']) && is_string($result['body']['requestId'])) {
			$request_id = $result['body']['requestId'];
		} elseif (!empty($result['requestId'])) {
			$request_id = $result['requestId'];
		}

		return [
			'success'        => $result['ok'],
			'code'           => (int) $result['status'],
			'request_id'     => $request_id,
			'error_message'  => $error_message,
			'field_warnings' => self::sanitize_field_warnings(isset($result['body']['fieldWarnings']) ? $result['body']['fieldWarnings'] : []),
		];
	}

	/**
	 * Keeps the well-formed entries of the fieldWarnings list Google attaches
	 * to an accepted events:ingest upload (Data Manager API v1.8+). Each one
	 * names a field Google dropped while still recording the conversion.
	 *
	 * @param mixed $warnings The fieldWarnings value relayed by the broker.
	 *
	 * @return array[] List of { reason: string, field: string, description: string }.
	 *
	 * @since 1.69.3
	 */
	public static function sanitize_field_warnings( $warnings ) {

		if (!is_array($warnings)) {
			return [];
		}

		$sanitized = [];

		foreach ($warnings as $warning) {

			if (!is_array($warning) || empty($warning['reason']) || !is_string($warning['reason'])) {
				continue;
			}

			$sanitized[] = [
				'reason'      => substr(sanitize_text_field($warning['reason']), 0, 100),
				'field'       => isset($warning['field']) && is_string($warning['field']) ? substr(sanitize_text_field($warning['field']), 0, 200) : '',
				'description' => isset($warning['description']) && is_string($warning['description']) ? substr(sanitize_text_field($warning['description']), 0, 300) : '',
			];

			if (count($sanitized) >= 20) {
				break;
			}
		}

		return $sanitized;
	}

	/**
	 * Server-to-server: every non-removed conversion action of a Google Ads
	 * account, with type/category, for the Data Manager upload verification
	 * (checking an entered conversion action ID against the chosen upload
	 * mode). Returns null when the list cannot be fetched - verification is
	 * best effort and must never block an upload.
	 *
	 * @param string $customer_id       The Google Ads customer ID, digits only.
	 * @param string $login_customer_id Optional manager (MCC) customer ID.
	 *
	 * @return array|null List of { id, name, type, status, category, conversionLabel } or null.
	 *
	 * @since 1.66.0
	 */
	public static function list_all_ads_conversion_actions( $customer_id, $login_customer_id = '' ) {

		if (!preg_match('/^\d+$/', (string) $customer_id)) {
			return null;
		}

		$path = '/v1/ads/customers/' . rawurlencode($customer_id) . '/conversions?all=1';

		if ($login_customer_id && preg_match('/^\d+$/', (string) $login_customer_id)) {
			$path .= '&login=' . rawurlencode($login_customer_id);
		}

		$result = self::broker_request('GET', $path);

		if (!$result['ok'] || !isset($result['body']['conversions']) || !is_array($result['body']['conversions'])) {
			return null;
		}

		return $result['body']['conversions'];
	}

	/**
	 * Server-to-server: relay a conversion adjustment (refund handling for
	 * the Data Manager upload). Adjustments run through the Google Ads API on
	 * the broker, which holds the developer token.
	 *
	 * @param array $payload { customerId, loginCustomerId?, conversionActionId,
	 *                         orderId, adjustmentType, adjustmentDateTime,
	 *                         adjustedValue?, currencyCode? }
	 *
	 * @return array { success: bool, code: int, error_message: string, reason: string }
	 *
	 * @since 1.66.0
	 */
	public static function datamanager_adjust( $payload ) {

		$result = self::broker_request('POST', '/v1/ads/datamanager/adjust', $payload);

		$error_message = '';

		if (!$result['ok'] && isset($result['body']['message'])) {
			$error_message = (string) $result['body']['message'];
		}

		return [
			'success'       => $result['ok'],
			'code'          => (int) $result['status'],
			'error_message' => $error_message,
			// A finer cause next to the error code, e.g. CONVERSION_NOT_FOUND
			// when Google never recorded a conversion for the order. @since 1.74.3
			'reason'        => ( !$result['ok'] && isset($result['body']['reason']) ) ? (string) $result['body']['reason'] : '',
		];
	}

	public function handle_ga4_accounts() {
		return self::proxy('GET', '/v1/ga4/accounts');
	}

	/**
	 * POST /broker/ga4/properties: create a GA4 property (the account-has-no-
	 * properties onboarding path). The shop's locale details are injected
	 * server-side so the wizard needs no timezone/currency inputs.
	 */
	public function handle_ga4_properties_create( $request ) {

		$params = self::pick_params($request, [ 'account', 'displayName' ]);

		if (empty($params['displayName'])) {
			$params['displayName'] = get_bloginfo('name');
		}

		// GA4 requires an IANA zone; WP offset-style settings ("+02:00") cannot
		// be mapped cleanly, so those fall back to UTC.
		$timezone = function_exists('wp_timezone_string') ? wp_timezone_string() : '';

		if (!$timezone || preg_match('/^[+-]/', $timezone)) {
			$timezone = 'UTC';
		}

		$params['timeZone']     = $timezone;
		$params['currencyCode'] = function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'USD';

		return self::proxy('POST', '/v1/ga4/properties', $params);
	}

	public function handle_ga4_streams_list( $request ) {
		return self::proxy('GET', '/v1/ga4/properties/' . rawurlencode($request['id']) . '/streams');
	}

	public function handle_ga4_streams_create( $request ) {
		return self::proxy('POST', '/v1/ga4/streams', self::pick_params($request, [ 'propertyId', 'displayName', 'defaultUri' ]));
	}

	public function handle_ga4_select( $request ) {
		return self::proxy('POST', '/v1/ga4/select', self::pick_params($request, [ 'propertyId', 'streamId' ]));
	}

	// ─── Meta (experiment-gated) ───────────

	/**
	 * GET /broker/meta/status: Meta connection readiness. Same cheap local
	 * answer as the Google status when the site is not enrolled yet.
	 */
	public function handle_meta_status() {

		if (!self::is_enrolled()) {
			return new \WP_REST_Response(
				[
					'ok'        => true,
					'enrolled'  => false,
					'connected' => false,
				],
				200
			);
		}

		$result = self::broker_request('GET', '/v1/meta/status');

		if (!$result['ok']) {
			return self::error_response($result);
		}

		$body             = $result['body'];
		$body['enrolled'] = true;

		// A healthy status clears an open incident immediately (see handle_status).
		if (!empty($body['connected']) && empty($body['needsReconnect'])) {
			self::clear_reconnect_incident('meta');
		}

		return new \WP_REST_Response($body, 200);
	}

	/**
	 * POST /broker/meta/connect/start: begin the Meta connect (Facebook Login
	 * for Business). Mirrors the Google connect including the enroll-on-demand
	 * and single re-enroll retry on a stale site token.
	 */
	public function handle_meta_connect_start( $request ) {

		$params     = $request->get_json_params();
		$return_url = ( is_array($params) && isset($params['returnUrl']) ) ? self::same_site_url($params['returnUrl']) : '';

		if (!$return_url) {
			return new \WP_REST_Response(
				[
					'ok'      => false,
					'code'    => 'BAD_REQUEST',
					'message' => 'returnUrl is required.',
				],
				400
			);
		}

		if (!self::is_enrolled()) {
			$enroll = self::enroll();

			if (!$enroll['ok']) {
				return self::error_response($enroll);
			}
		}

		$result = self::broker_request('POST', '/v1/meta/connect/start', [ 'returnUrl' => $return_url ]);

		if (!$result['ok'] && 401 === $result['status']) {
			$enroll = self::enroll();

			if ($enroll['ok']) {
				$result = self::broker_request('POST', '/v1/meta/connect/start', [ 'returnUrl' => $return_url ]);
			}
		}

		if (!$result['ok']) {
			return self::error_response($result);
		}

		return new \WP_REST_Response($result['body'], 200);
	}

	/**
	 * POST /broker/meta/disconnect: revoke the Meta login and purge the
	 * broker-side token. Enrollment survives, like the Google disconnect.
	 */
	public function handle_meta_disconnect() {

		if (!self::is_enrolled()) {
			return new \WP_REST_Response([ 'ok' => true ], 200);
		}

		$result = self::broker_request('POST', '/v1/meta/disconnect');

		if (!$result['ok']) {
			return self::error_response($result);
		}

		return new \WP_REST_Response($result['body'], 200);
	}

	public function handle_meta_pixels() {
		return self::proxy('GET', '/v1/meta/pixels');
	}

	public function handle_meta_select( $request ) {
		return self::proxy('POST', '/v1/meta/select', self::pick_params($request, [ 'pixelId' ]));
	}

	// ─── Enrollment ───────────

	/**
	 * Run the challenge enrollment: begin -> publish challenge -> complete.
	 * Returns a broker_request-shaped array.
	 *
	 * @return array
	 */
	private static function enroll() {

		$begin = self::broker_request(
			'POST',
			'/v1/enroll/begin',
			[ 'siteUrl' => self::get_site_base_url() ],
			false
		);

		if (!$begin['ok']) {
			return $begin;
		}

		$body          = $begin['body'];
		$enrollment_id = isset($body['enrollmentId']) ? $body['enrollmentId'] : '';
		$challenge     = isset($body['challenge']) ? $body['challenge'] : '';

		if (!$enrollment_id || !$challenge) {
			return [
				'ok'        => false,
				'status'    => 502,
				'body'      => [
					'ok'      => false,
					'code'    => 'UPSTREAM_ERROR',
					'message' => 'The broker returned an incomplete enrollment.',
				],
				'requestId' => $begin['requestId'],
			];
		}

		// Publish the challenge, then have the broker verify it. The public
		// challenge route reads this transient.
		set_transient(self::CHALLENGE_TRANSIENT, $challenge, 10 * MINUTE_IN_SECONDS);

		$complete = self::broker_request(
			'POST',
			'/v1/enroll/complete',
			[
				'enrollmentId' => $enrollment_id,
				'distro'       => defined('PMW_DISTRO') ? PMW_DISTRO : '',
				'version'      => defined('PMW_CURRENT_VERSION') ? PMW_CURRENT_VERSION : '',
				// When a firewall or CDN keeps the broker from reading the
				// challenge route (Cloudflare's bot check, Basic Auth), enroll
				// as an unverified site instead of failing. An unverified site
				// can never replace a verified one for the same URL (pmw-web
				// design doc §6.1). @since 1.74.2
				'fallback'     => 'unverified',
			],
			false
		);

		delete_transient(self::CHALLENGE_TRANSIENT);

		if (!$complete['ok']) {
			self::record_enroll_error($complete);
			return $complete;
		}

		delete_option(self::ENROLL_ERROR_OPTION);

		$body = $complete['body'];

		if (empty($body['siteId']) || empty($body['siteToken'])) {
			return [
				'ok'        => false,
				'status'    => 502,
				'body'      => [
					'ok'      => false,
					'code'    => 'UPSTREAM_ERROR',
					'message' => 'The broker returned an incomplete enrollment token.',
				],
				'requestId' => $complete['requestId'],
			];
		}

		self::save_state([
			'site_id'        => $body['siteId'],
			'site_token'     => $body['siteToken'],
			'enrolled_at'    => time(),
			// false when the broker could not read the challenge route and
			// enrolled the site unverified (shown in the debug report). @since 1.74.2
			'verified'       => !isset($body['verified']) || (bool) $body['verified'],
			'verify_failure' => isset($body['verifyFailure']) ? sanitize_key($body['verifyFailure']) : '',
		]);

		return $complete;
	}

	// ─── Broker HTTP plumbing ───────────

	/**
	 * Whitelist JSON params from the REST request body.
	 *
	 * @param \WP_REST_Request $request
	 * @param array            $keys
	 * @return array
	 */
	private static function pick_params( $request, $keys ) {

		$params = $request->get_json_params();
		$out    = [];

		if (!is_array($params)) {
			return $out;
		}

		foreach ($keys as $key) {
			if (isset($params[$key]) && is_string($params[$key])) {
				$out[$key] = $params[$key];
			}
		}

		return $out;
	}

	/**
	 * Authenticated proxy: run the broker request and map it 1:1 into the
	 * REST response (body, status and the broker's X-Request-Id).
	 *
	 * @param string     $method
	 * @param string     $path
	 * @param array|null $body
	 * @return \WP_REST_Response
	 */
	private static function proxy( $method, $path, $body = null ) {

		$result = self::broker_request($method, $path, $body);

		if (!$result['ok']) {
			return self::error_response($result);
		}

		return new \WP_REST_Response($result['body'], 200);
	}

	/**
	 * One HTTP call to the broker.
	 *
	 * @param string     $method    GET|POST
	 * @param string     $path      e.g. /v1/status
	 * @param array|null $body      JSON body for POSTs.
	 * @param bool       $with_auth Attach the per-site bearer token.
	 * @return array {
	 *     ok:        bool  True on HTTP 2xx with ok!==false.
	 *     status:    int   HTTP status (0 on network error).
	 *     body:      array Decoded JSON body (with code/message on errors).
	 *     requestId: string|null The broker's X-Request-Id for support lookups.
	 * }
	 */
	private static function broker_request( $method, $path, $body = null, $with_auth = true, $extra_headers = [] ) {

		$headers = [
			'Accept'        => 'application/json',
			'X-PMW-Version' => defined('PMW_CURRENT_VERSION') ? PMW_CURRENT_VERSION : '',
		];

		if ($with_auth) {
			$state = self::get_state();

			// Not "is a token stored" but "is it one the broker can accept":
			// an unusable credential is answered here, so a site that cannot
			// authenticate stops calling instead of polling out a 401 per
			// settings-page render. @see is_enrolled()
			if (!self::has_usable_token($state)) {
				return [
					'ok'        => false,
					'status'    => 409,
					'body'      => [
						'ok'      => false,
						'code'    => 'NOT_ENROLLED',
						'message' => 'This site is not enrolled with the connection service yet.',
					],
					'requestId' => null,
				];
			}

			$headers['Authorization'] = 'Bearer ' . $state['site_token'];

			if (!empty($state['site_id'])) {
				$headers['X-PMW-Site'] = $state['site_id'];
			}
		}

		$args = [
			'method'  => $method,
			'timeout' => 20,
			'headers' => array_merge($headers, (array) $extra_headers),
		];

		// Always JSON-typed, even on body-less POSTs (disconnect): the broker's
		// Astro CSRF check rejects untyped POSTs as cross-site form submissions.
		if ('GET' !== $method) {
			$args['headers']['Content-Type'] = 'application/json';
			$args['body']                    = wp_json_encode(is_null($body) ? new \stdClass() : $body);
		}

		/**
		 * Some optimization and security plugins clamp EVERY outbound request
		 * to the WordPress default of 5 seconds through the http_request_args
		 * filter, which overrides the explicit timeout above. Seen live: a
		 * Data Manager relay that the broker completed in 11.6 seconds died
		 * shop-side with "cURL error 28: Operation timed out after 5002
		 * milliseconds". Re-assert the timeout after all other filters, for
		 * this one request only.
		 */
		$broker_url      = self::get_broker_url();
		$enforce_timeout = static function ( $parsed_args, $url ) use ( $broker_url ) {
			if (is_string($url) && 0 === strpos($url, $broker_url)) {
				$parsed_args['timeout'] = 20;
			}
			return $parsed_args;
		};

		add_filter('http_request_args', $enforce_timeout, PHP_INT_MAX, 2);

		$response = wp_remote_request($broker_url . $path, $args);

		remove_filter('http_request_args', $enforce_timeout, PHP_INT_MAX);

		if (is_wp_error($response)) {
			return [
				'ok'        => false,
				'status'    => 0,
				'body'      => [
					'ok'      => false,
					'code'    => 'NETWORK_ERROR',
					'message' => 'Could not reach the connection service: ' . $response->get_error_message(),
				],
				'requestId' => null,
			];
		}

		$status     = (int) wp_remote_retrieve_response_code($response);
		$request_id = wp_remote_retrieve_header($response, 'x-request-id');
		$decoded    = json_decode(wp_remote_retrieve_body($response), true);

		if (!is_array($decoded)) {
			$decoded = [
				'ok'      => false,
				'code'    => 'UPSTREAM_ERROR',
				'message' => 'The connection service returned an unexpected response (' . $status . ').',
			];
		}

		$ok = $status >= 200 && $status < 300 && ( !isset($decoded['ok']) || false !== $decoded['ok'] );

		// Only a request that actually presented the stored token says anything
		// about it, and only a 401 is the broker's verdict on the credential
		// itself; everything else is about the request, the route or the
		// network. Enough of them in a row and the token is written off, which
		// turns the next settings-page render into a Connect button instead of
		// another rejected call. @see AUTH_REJECTION_LIMIT
		if ($with_auth) {
			if (401 === $status) {
				self::record_auth_rejection();
			} elseif ($ok) {
				self::clear_auth_rejections();
			}
		}

		// Inline incident detection: the broker returns NEEDS_RECONNECT only on
		// VERIFIED dead credentials (Google invalid_grant, Meta OAuthException),
		// so the very first failing call, wizard or server-to-server upload,
		// raises the alert without waiting for the daily health check.
		if (!$ok && isset($decoded['code']) && 'NEEDS_RECONNECT' === $decoded['code']) {
			self::flag_reconnect_incident(0 === strpos($path, '/v1/meta') ? 'meta' : 'google');
		}

		return [
			'ok'        => $ok,
			'status'    => $status,
			'body'      => $decoded,
			'requestId' => is_string($request_id) && '' !== $request_id ? $request_id : null,
		];
	}

	/**
	 * Map a failed broker_request into the REST response. The broker's
	 * request id rides along so support tickets carry the exact log key.
	 *
	 * @param array $result
	 * @return \WP_REST_Response
	 */
	/**
	 * Remember why the last enrollment failed, for the debug report.
	 *
	 * @param array $result A broker_request() result that is not ok.
	 * @return void
	 *
	 * @since 1.74.2
	 */
	private static function record_enroll_error( $result ) {

		$body = is_array($result['body']) ? $result['body'] : [];

		update_option(
			self::ENROLL_ERROR_OPTION,
			[
				'time'       => time(),
				'status'     => (int) $result['status'],
				'code'       => isset($body['code']) ? sanitize_text_field((string) $body['code']) : '',
				'message'    => isset($body['message']) ? sanitize_text_field(substr((string) $body['message'], 0, 300)) : '',
				'request_id' => $result['requestId'] ? sanitize_text_field((string) $result['requestId']) : '',
			],
			false
		);
	}

	/**
	 * The Google connection section of the debug report.
	 *
	 * @return string
	 *
	 * @since 1.74.2
	 */
	public static function get_debug_info_text() {

		$state = self::get_state();
		$text  = '';

		if (self::is_enrolled()) {
			$verified = !isset($state['verified']) || $state['verified'];
			$text    .= 'Enrolled with the connection service: yes' . PHP_EOL;
			$text    .= 'Site ID: ' . ( isset($state['site_id']) ? $state['site_id'] : '' ) . PHP_EOL;
			$text    .= 'Site verified: ' . ( $verified ? 'yes' : 'no, the site check was blocked (' . ( !empty($state['verify_failure']) ? $state['verify_failure'] : 'unknown' ) . ')' ) . PHP_EOL;
			$text    .= 'Google account connected: ' . ( self::is_google_connected() ? 'yes' : 'no' ) . PHP_EOL;
		} else {
			$text .= 'Enrolled with the connection service: no' . PHP_EOL;
		}

		$text .= 'Site check address: ' . self::get_site_base_url() . '/wp-json/' . self::$rest_namespace . '/broker/challenge' . PHP_EOL;

		$error = get_option(self::ENROLL_ERROR_OPTION);

		if (is_array($error) && !empty($error['time'])) {
			$text .= 'Last failed connection attempt: ' . gmdate('Y-m-d H:i', (int) $error['time']) . ' UTC, HTTP ' . (int) $error['status']
				. ( !empty($error['code']) ? ', ' . $error['code'] : '' )
				. ( !empty($error['request_id']) ? ', Support ID ' . $error['request_id'] : '' ) . PHP_EOL;

			if (!empty($error['message'])) {
				$text .= '  ' . $error['message'] . PHP_EOL;
			}
		}

		return $text;
	}

	private static function error_response( $result ) {

		$body = $result['body'];

		if ($result['requestId']) {
			$body['requestId'] = $result['requestId'];
		}

		// Never hand the browser a 5xx. Cloudflare, nginx and many hosts swap
		// the body of a 5xx for their own error page, so the broker's message
		// and Support ID never reached the merchant, who saw only "Connection
		// service error (502)". 424 (Failed Dependency) says the same thing,
		// a service this request depends on failed, and survives those layers.
		// The original status stays in the body for diagnosis. @since 1.74.2
		$upstream_status        = (int) $result['status'];
		$body['upstreamStatus'] = $upstream_status;

		$status = ( $upstream_status >= 400 && $upstream_status < 500 ) ? $upstream_status : 424;

		return new \WP_REST_Response($body, $status);
	}
}
