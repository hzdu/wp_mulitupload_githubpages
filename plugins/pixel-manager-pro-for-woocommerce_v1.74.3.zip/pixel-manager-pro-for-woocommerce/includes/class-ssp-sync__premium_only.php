<?php
/**
 * SSP (Server Side Proxy) Sync class
 *
 * Handles synchronization of CAPI tokens and configuration
 * from WooCommerce / Pixel Manager to the SweetCode SSP proxy.
 *
 * @since 1.57.0
 */

namespace SweetCode\Pixel_Manager;

use SweetCode\Pixel_Manager\Admin\Environment;
use SweetCode\Pixel_Manager\Pixels\Facebook\Facebook;

defined('ABSPATH') || exit; // Exit if accessed directly

class SSP_Sync {

	private static $instance;

	/**
	 * SSP API base URL (production default).
	 * Override locally with: define( 'PMW_SSP_API_BASE', 'http://localhost:8787' );
	 */
	const SSP_API_BASE = 'https://ssp.sweetcode.cloud';

	/**
	 * Get the effective SSP API base URL.
	 *
	 * Checks for a PMW_SSP_API_BASE constant (set in wp-config.php) first,
	 * which allows pointing the plugin at a local wrangler dev server.
	 *
	 * @return string
	 * @since 1.57.0
	 */
	private static function get_api_base() {
		if ( defined( 'PMW_SSP_API_BASE' ) ) {
			return PMW_SSP_API_BASE;
		}
		return self::SSP_API_BASE;
	}

	/**
	 * Action Scheduler hook for daily sync
	 */
	const DAILY_SYNC_HOOK = 'pmw_ssp_daily_sync';

	/**
	 * Target time for daily sync (24-hour format).
	 */
	const DAILY_SYNC_TIME = '3:15am';

	/**
	 * Action Scheduler hook for settings-changed sync.
	 *
	 * Separate from DAILY_SYNC_HOOK so we can distinguish
	 * "settings changed" from "daily cron" in audit logs.
	 *
	 * @since 1.59.0
	 */
	const SETTINGS_CHANGED_SYNC_HOOK = 'pmw_ssp_settings_sync';

	/**
	 * Transient key prefix for sync cooldown.
	 *
	 * @since 1.59.0
	 */
	const SYNC_COOLDOWN_TRANSIENT = 'pmw_ssp_sync_cooldown';

	/**
	 * Minimum interval between non-forced syncs in seconds.
	 *
	 * @since 1.59.0
	 */
	const SYNC_COOLDOWN_SECONDS = 60;

	/**
	 * Action Scheduler hook for activation retry with backoff.
	 *
	 * @since 1.58.1
	 */
	const ACTIVATION_RETRY_HOOK = 'pmw_ssp_activation_retry';

	/**
	 * Transient key that throttles the destination-config hash check.
	 *
	 * @since 1.64.0
	 */
	const CONFIG_HASH_CHECK_TRANSIENT = 'pmw_ssp_config_hash_checked';

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Get the next future occurrence of the daily sync time.
	 *
	 * Returns today's timestamp if the time hasn't passed yet,
	 * otherwise returns tomorrow's. This prevents Action Scheduler
	 * from treating a newly created recurring action as overdue
	 * and running it immediately.
	 *
	 * @return int Unix timestamp for the next daily sync run.
	 * @since 1.58.4
	 */
	private static function get_next_daily_sync_timestamp() {
		$today = Helpers::datetime_string_to_unix_timestamp_in_local_timezone( 'today ' . self::DAILY_SYNC_TIME );

		if ( $today > time() ) {
			return $today;
		}

		return Helpers::datetime_string_to_unix_timestamp_in_local_timezone( 'tomorrow ' . self::DAILY_SYNC_TIME );
	}

	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register hooks for automatic syncing.
	 *
	 * @since 1.57.0
	 */
	private function register_hooks() {

		// Auto-sync when PMW options are updated
		add_action('update_option_' . PMW_DB_OPTIONS_NAME, [ $this, 'on_options_updated' ], 10, 2);

		// Daily sync via Action Scheduler
		add_action(self::DAILY_SYNC_HOOK, [ __CLASS__, 'daily_sync_handler' ]);

		// Settings-changed sync via Action Scheduler (separate hook for source tracking)
		add_action(self::SETTINGS_CHANGED_SYNC_HOOK, [ __CLASS__, 'settings_changed_sync_handler' ]);

		// Activation retry with backoff
		add_action(self::ACTIVATION_RETRY_HOOK, [ __CLASS__, 'handle_activation_retry' ]);

		// Force a config sync after PMW is updated so the SSP receives the
		// new pluginVersion (and any other build-level metadata) immediately
		// instead of waiting up to 24h for the daily cron.
		add_action( 'upgrader_process_complete', [ __CLASS__, 'on_plugin_upgrade' ], 20, 2 );

		// Schedule daily sync if SSP is active and not already scheduled
		add_action('init', [ $this, 'maybe_schedule_daily_sync' ], 20);

		// Detect destination-config changes that don't go through the options
		// table, e.g. pixels added via the pmw_facebook_pixel_identifiers filter
		add_action('init', [ $this, 'maybe_sync_on_config_change' ], 30);
	}

	/**
	 * Schedule the daily sync task if SSP is configured.
	 *
	 * Uses is_ssp_configured() instead of is_ssp_active() so that the
	 * daily sync keeps running while DNS is propagating or config is
	 * pending. The sync itself will fetch updated routing_status and
	 * config_status from the SSP, allowing the statuses to self-heal.
	 *
	 * @since 1.57.0
	 */
	public function maybe_schedule_daily_sync() {

		if (!Options::is_ssp_configured()) {

			// Unschedule if SSP is no longer configured
			if (
				function_exists('as_has_scheduled_action')
				&& as_has_scheduled_action(self::DAILY_SYNC_HOOK)
			) {
				as_unschedule_all_actions(self::DAILY_SYNC_HOOK);
			}

			return;
		}

		if (
			function_exists('as_has_scheduled_action')
			&& !as_has_scheduled_action(self::DAILY_SYNC_HOOK)
		) {
			as_schedule_recurring_action(
				self::get_next_daily_sync_timestamp(),
				DAY_IN_SECONDS,
				self::DAILY_SYNC_HOOK,
				[],
				'pmw_ssp',
				true
			);
		}
	}

	/**
	 * Handle the daily sync Action Scheduler task.
	 *
	 * Uses is_ssp_configured() so that the sync runs even when
	 * routing_status or config_status haven't reached their final
	 * states yet, allowing push_config_to_ssp() to pick up the
	 * updated statuses from the SSP response.
	 *
	 * @since 1.57.0
	 */
	public static function daily_sync_handler() {

		// Self-healing: purge any stale pending settings-changed async actions
		// that may have accumulated due to rapid option saves.
		self::purge_stale_settings_sync_actions();

		if (Options::is_ssp_configured()) {
			self::push_config_to_ssp( null, 'daily_cron', true );
		}
	}

	/**
	 * Handle the settings-changed sync Action Scheduler task.
	 *
	 * Separate from daily_sync_handler() so audit logs can
	 * distinguish settings-triggered syncs from daily cron syncs.
	 *
	 * @since 1.59.0
	 */
	public static function settings_changed_sync_handler() {
		if (Options::is_ssp_configured()) {
			self::push_config_to_ssp( null, 'settings_changed' );
		}
	}

	/**
	 * Force an SSP config sync after PMW itself has been updated.
	 *
	 * Fires from the WordPress `upgrader_process_complete` hook. Bypasses
	 * the cooldown so the new pluginVersion (and any other build-level
	 * metadata) reaches SweetCode Cloud right away instead of waiting
	 * for the next daily cron run.
	 *
	 * @param \WP_Upgrader $upgrader_object
	 * @param array        $options
	 *
	 * @since 1.58.12
	 */
	public static function on_plugin_upgrade( $upgrader_object, $options ) {

		if ( ! isset( $options['type'] ) || 'plugin' !== $options['type'] ) {
			return;
		}

		if ( empty( $options['plugins'] ) || ! is_array( $options['plugins'] ) ) {
			return;
		}

		if ( ! defined( 'PMW_PLUGIN_BASENAME' ) || ! in_array( PMW_PLUGIN_BASENAME, $options['plugins'], true ) ) {
			return;
		}

		if ( ! Options::is_ssp_configured() ) {
			return;
		}

		self::push_config_to_ssp( null, 'plugin_upgrade', true );
	}

	/**
	 * Purge stale pending sync actions from Action Scheduler.
	 *
	 * Cleans up both:
	 * - SETTINGS_CHANGED_SYNC_HOOK: from rapid option saves
	 * - DAILY_SYNC_HOOK one-off actions: legacy backlog from pre-1.58.1 where
	 *   on_options_updated() enqueued daily_sync actions instead of settings_changed
	 *
	 * Uses as_unschedule_all_actions() for the daily hook to nuke everything
	 * (including the recurring cron), then lets maybe_schedule_daily_sync()
	 * re-create the single recurring action on the next init.
	 *
	 * @since 1.59.0
	 */
	private static function purge_stale_settings_sync_actions() {

		if ( ! function_exists( 'as_get_scheduled_actions' ) || ! function_exists( 'as_unschedule_all_actions' ) ) {
			return;
		}

		// Count pending daily_sync actions — if more than 1, there's a backlog
		$pending_daily = as_get_scheduled_actions( [
			'hook'     => self::DAILY_SYNC_HOOK,
			'status'   => \ActionScheduler_Store::STATUS_PENDING,
			'per_page' => 5,
		] );

		if ( count( $pending_daily ) > 1 ) {
			Logger::info( 'SSP: Detected stale "' . self::DAILY_SYNC_HOOK . '" backlog. Unscheduling all and re-registering recurring cron.' );

			// Nuclear option: remove ALL actions for this hook (pending, in-progress, etc.)
			as_unschedule_all_actions( self::DAILY_SYNC_HOOK );

			// Re-register the recurring daily cron — it will be picked up on next init
			// but schedule it now so there's no gap.
			as_schedule_recurring_action(
				self::get_next_daily_sync_timestamp(),
				DAY_IN_SECONDS,
				self::DAILY_SYNC_HOOK,
				[],
				'pmw_ssp',
				true
			);
		}

		// Also purge any stale settings-changed actions (lighter cleanup)
		$pending_settings = as_get_scheduled_actions( [
			'hook'     => self::SETTINGS_CHANGED_SYNC_HOOK,
			'status'   => \ActionScheduler_Store::STATUS_PENDING,
			'per_page' => 5,
		] );

		if ( count( $pending_settings ) > 1 ) {
			Logger::info( 'SSP: Purging stale "' . self::SETTINGS_CHANGED_SYNC_HOOK . '" actions.' );
			as_unschedule_all_actions( self::SETTINGS_CHANGED_SYNC_HOOK );
		}
	}

	/**
	 * Start the activation retry schedule.
	 *
	 * Stores the current timestamp as the retry start time and schedules
	 * the first retry in 10 minutes. Uses chained single actions: each
	 * execution of handle_activation_retry() schedules the next action
	 * at the appropriate backoff interval.
	 *
	 * Schedule:
	 * - Phase 1: Every 10 minutes for 2 hours
	 * - Phase 2: Every 2 hours for 1 week
	 * - Phase 3: Every 24 hours indefinitely
	 *
	 * @since 1.58.1
	 */
	public static function schedule_activation_retry() {

		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}

		// Clear any existing retry actions
		as_unschedule_all_actions( self::ACTIVATION_RETRY_HOOK );

		// Store the retry start timestamp
		$options = get_option( PMW_DB_OPTIONS_NAME );

		$options['ssp']['activation_retry_start'] = time();

		remove_action( 'update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10 );
		update_option( PMW_DB_OPTIONS_NAME, $options );
		add_action( 'update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2 );

		Options::invalidate_cache();

		// Schedule first retry in 10 minutes
		as_schedule_single_action(
			time() + 10 * MINUTE_IN_SECONDS,
			self::ACTIVATION_RETRY_HOOK,
			[],
			'pmw_ssp',
			true
		);

		Logger::info( 'SSP: Activation retry schedule started (next retry in 10 minutes).' );
	}

	/**
	 * Handle an activation retry action.
	 *
	 * Pushes config to SSP and checks whether the domain is now active.
	 * If active, clears the retry state. Otherwise, schedules the next
	 * retry at the appropriate backoff interval based on elapsed time.
	 *
	 * @since 1.58.1
	 */
	public static function handle_activation_retry() {

		if ( ! Options::is_ssp_configured() ) {
			self::cancel_activation_retry();
			return;
		}

		// Push config — this updates routing_status and config_status from SSP response
		self::push_config_to_ssp( null, 'activation_retry' );

		// Re-read options after push (statuses may have changed)
		$options = Options::get_options();

		$routing_status = isset( $options['ssp']['routing_status'] ) ? $options['ssp']['routing_status'] : '';
		$config_status  = isset( $options['ssp']['config_status'] ) ? $options['ssp']['config_status'] : '';

		// Success: domain is fully active
		if ( 'active' === $routing_status && 'synced' === $config_status ) {
			self::cancel_activation_retry();
			Logger::info( 'SSP: Domain is now active. Activation retry schedule stopped.' );
			return;
		}

		// Determine next retry interval based on elapsed time
		$retry_start = isset( $options['ssp']['activation_retry_start'] ) ? (int) $options['ssp']['activation_retry_start'] : 0;

		if ( 0 === $retry_start ) {
			// Safety fallback: no start time recorded, use 2-hour interval
			$retry_start = time();
		}

		$elapsed = time() - $retry_start;

		if ( $elapsed < 2 * HOUR_IN_SECONDS ) {
			// Phase 1: Every 10 minutes for the first 2 hours
			$interval = 10 * MINUTE_IN_SECONDS;
			$phase    = '10 minutes (phase 1: aggressive)';
		} elseif ( $elapsed < 7 * DAY_IN_SECONDS ) {
			// Phase 2: Every 2 hours for the next week
			$interval = 2 * HOUR_IN_SECONDS;
			$phase    = '2 hours (phase 2: standard)';
		} else {
			// Phase 3: Every 24 hours indefinitely
			$interval = DAY_IN_SECONDS;
			$phase    = '24 hours (phase 3: maintenance)';
		}

		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action(
				time() + $interval,
				self::ACTIVATION_RETRY_HOOK,
				[],
				'pmw_ssp',
				true
			);
		}

		Logger::info( 'SSP: Domain not yet active. Next retry in ' . $phase . '.' );
	}

	/**
	 * Cancel the activation retry schedule and clear state.
	 *
	 * @since 1.58.1
	 */
	public static function cancel_activation_retry() {

		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::ACTIVATION_RETRY_HOOK );
		}

		$options = get_option( PMW_DB_OPTIONS_NAME );

		if ( isset( $options['ssp']['activation_retry_start'] ) && 0 !== $options['ssp']['activation_retry_start'] ) {
			$options['ssp']['activation_retry_start'] = 0;

			remove_action( 'update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10 );
			update_option( PMW_DB_OPTIONS_NAME, $options );
			add_action( 'update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2 );

			Options::invalidate_cache();
		}
	}

	/**
	 * Callback for when PMW options are updated.
	 * Compares old and new values for CAPI-related fields and triggers sync if they changed.
	 *
	 * @param array $old_value Old option value.
	 * @param array $new_value New option value.
	 *
	 * @since 1.57.0
	 */
	public function on_options_updated( $old_value, $new_value ) {

		// Only sync if SSP is active
		if (empty($new_value['ssp']['enabled']) || empty($new_value['ssp']['sync_token'])) {
			return;
		}

		// Check if any CAPI-related settings changed
		$capi_keys = self::get_capi_option_paths();
		$changed   = false;

		foreach ($capi_keys as $path) {
			$old_val = self::array_get_nested($old_value, $path);
			$new_val = self::array_get_nested($new_value, $path);

			if ($old_val !== $new_val) {
				$changed = true;
				break;
			}
		}

		if ($changed) {

			Logger::info('SSP: CAPI settings changed, triggering config sync.');

			// Fire async so we don't block the options save.
			// Uses a dedicated hook (SETTINGS_CHANGED_SYNC_HOOK) so audit logs
			// can distinguish settings-triggered syncs from daily cron syncs.
			// Only enqueue if no pending action already exists (deduplication).
			if (function_exists('as_enqueue_async_action')) {
				if ( ! function_exists( 'as_next_scheduled_action' ) || ! as_next_scheduled_action( self::SETTINGS_CHANGED_SYNC_HOOK, [], 'pmw_ssp' ) ) {
					as_enqueue_async_action( self::SETTINGS_CHANGED_SYNC_HOOK, [], 'pmw_ssp' );
				} else {
					Logger::debug( 'SSP: Settings sync already pending, skipping duplicate enqueue.' );
				}
			} else {
				self::push_config_to_ssp( null, 'settings_changed' );
			}
		}
	}

	/**
	 * Detect destination-config changes that bypass the options table.
	 *
	 * The on_options_updated() hook only sees changes to stored settings.
	 * Filter-driven config, like extra pixels added with the
	 * pmw_facebook_pixel_identifiers filter in a code snippet, changes the
	 * destination configs without touching any option. This check hashes the
	 * effective destination configs and triggers a sync when the hash no
	 * longer matches the one stored on the last successful push.
	 *
	 * Throttled with a transient so the hash is computed at most once every
	 * five minutes.
	 *
	 * @since 1.64.0
	 */
	public function maybe_sync_on_config_change() {

		if (get_transient(self::CONFIG_HASH_CHECK_TRANSIENT)) {
			return;
		}

		$options = Options::get_options();

		// Only check if SSP is active
		if (empty($options['ssp']['enabled']) || empty($options['ssp']['sync_token'])) {
			return;
		}

		set_transient(self::CONFIG_HASH_CHECK_TRANSIENT, 1, 5 * MINUTE_IN_SECONDS);

		$stored_hash = isset($options['ssp']['config_hash']) ? $options['ssp']['config_hash'] : '';

		// No hash yet, e.g. right after the plugin update that introduced it.
		// The next regular sync will store one.
		if (!$stored_hash) {
			return;
		}

		$current_hash = md5(wp_json_encode(self::get_destination_configs($options)));

		if ($current_hash === $stored_hash) {
			return;
		}

		Logger::info('SSP: Destination config changed outside of settings (e.g. via filter), triggering config sync.');

		if (function_exists('as_enqueue_async_action')) {
			if (!function_exists('as_next_scheduled_action') || !as_next_scheduled_action(self::SETTINGS_CHANGED_SYNC_HOOK, [], 'pmw_ssp')) {
				as_enqueue_async_action(self::SETTINGS_CHANGED_SYNC_HOOK, [], 'pmw_ssp');
			}
		} else {
			self::push_config_to_ssp(null, 'settings_changed');
		}
	}

	/**
	 * Returns an array of dot-notation paths to CAPI-related option fields.
	 *
	 * @return string[]
	 * @since 1.57.0
	 */
	private static function get_capi_option_paths() {
		return [
			'facebook.pixel_id',
			'facebook.capi.token',
			'facebook.capi.test_event_code',
			'tiktok.pixel_id',
			'tiktok.eapi.token',
			'tiktok.eapi.test_event_code',
			'pinterest.pixel_id',
			'pinterest.ad_account_id',
			'pinterest.apic.token',
			'snapchat.pixel_id',
			'snapchat.capi.token',
			'pixels.reddit.advertiser_id',
			'pixels.reddit.capi.token',
			'pixels.reddit.capi.test_event_code',
			'pixels.openai.pixel_id',
			'pixels.openai.capi.token',
			'pixels.nextdoor.pixel_id',
			'pixels.nextdoor.capi.token',
			'pixels.nextdoor.capi.test_event_code',
			'pixels.spotify.pixel_id',
			'pixels.spotify.capi.connection_id',
			'pixels.spotify.capi.token',
			'pixels.applovin.event_key',
			'pixels.applovin.capi.token',
			'bing.uet_tag_id',
			'bing.capi.token',
			'google.analytics.ga4.measurement_id',
			'google.analytics.ga4.api_secret',
			'pixels.mixpanel.project_token',
			'pixels.mixpanel.data_residency',
			'pixels.mixpanel.ingestion_api.enabled',
			'pixels.klaviyo.public_api_key',
			'pixels.klaviyo.events_api.token',
			'pixels.klaviyo.coexistence',
			// Pausing or resuming a pixel adds or removes its destination.
			'paused_pixels',
		];
	}

	/**
	 * Get a nested value from an array using dot notation.
	 *
	 * @param array  $array The array to traverse.
	 * @param string $path  Dot-notation path (e.g. "facebook.capi.token").
	 *
	 * @return mixed|null
	 * @since 1.57.0
	 */
	private static function array_get_nested( $array, $path ) {
		$keys = explode('.', $path);

		foreach ($keys as $key) {
			if (!is_array($array) || !isset($array[$key])) {
				return null;
			}
			$array = $array[$key];
		}

		return $array;
	}

	/**
	 * Normalize a shop domain by stripping a leading "www." prefix and lowercasing.
	 *
	 * @param string $domain The domain to normalize (e.g. "www.myshop.com").
	 *
	 * @return string Normalized domain (e.g. "myshop.com").
	 * @since 1.57.1
	 */
	private static function normalize_shop_domain( $domain ) {
		$domain = strtolower(trim($domain));
		if (strpos($domain, 'www.') === 0) {
			$domain = substr($domain, 4);
		}
		return $domain;
	}

	/**
	 * Extract the shop domain portion from a proxy hostname.
	 *
	 * Given a hostname like "ssp.myshop.com", returns "myshop.com"
	 * (everything after the first dot).
	 *
	 * @param string $hostname The proxy hostname (e.g. "ssp.myshop.com").
	 *
	 * @return string The shop domain portion (e.g. "myshop.com").
	 * @since 1.57.1
	 */
	private static function extract_shop_domain_from_hostname( $hostname ) {
		$dot_pos = strpos($hostname, '.');
		if (false === $dot_pos) {
			return $hostname;
		}
		return substr($hostname, $dot_pos + 1);
	}

	/**
	 * Parse an SSP API error response into a structured array.
	 *
	 * SSP returns errors as `{ error: { code, message, requestId? } }`. This
	 * helper extracts those fields and falls back gracefully when older Worker
	 * versions omit `code` or when the response isn't valid JSON.
	 *
	 * @param mixed $body        Decoded JSON body (or null).
	 * @param int   $http_status HTTP status code.
	 *
	 * @return array{code: string, message: string, request_id: string, http_status: int}
	 * @since 1.58.12
	 */
	private static function parse_ssp_error_response( $body, $http_status ) {

		$error_node = is_array($body) && isset($body['error']) && is_array($body['error'])
			? $body['error']
			: [];

		$code       = isset($error_node['code']) ? (string) $error_node['code'] : '';
		$message    = isset($error_node['message']) ? (string) $error_node['message'] : '';
		$request_id = '';
		if ( isset($error_node['requestId']) ) {
			$request_id = (string) $error_node['requestId'];
		} elseif ( isset($error_node['request_id']) ) {
			$request_id = (string) $error_node['request_id'];
		}

		if ('' === $message) {
			$message = 'Unknown error (HTTP ' . $http_status . ')';
		}

		return [
			'code'        => $code,
			'message'     => $message,
			'request_id'  => $request_id,
			'http_status' => (int) $http_status,
		];
	}

	/**
	 * Map a parsed SSP error to a user-facing actionable message.
	 *
	 * Returns the original SSP message verbatim for codes where the server
	 * already provides enough context (e.g. SHOP_ORIGIN_MISMATCH names the
	 * expected shop). Adds an actionable hint for opaque codes like
	 * UNAUTHORIZED. Falls back to the SSP message when the code is unknown
	 * or missing, so older Workers degrade gracefully.
	 *
	 * @param array $parsed Output of parse_ssp_error_response().
	 *
	 * @return string User-facing message.
	 * @since 1.58.12
	 */
	private static function user_message_for_ssp_error( array $parsed ) {

		$code = $parsed['code'];

		// Worker code constants live in @ssp/shared/constants → ERROR_CODES.
		// Keep the strings in sync (lowercase, underscore) with that package.
		switch ($code) {
			case 'unauthorized':
			case 'invalid_token':
			case 'token_expired':
				return 'Sync token is invalid or has expired. Regenerate it in the SweetCode Cloud portal and paste the new value.';

			case 'shop_origin_mismatch':
				// Server message already names the expected shop — render verbatim.
				return $parsed['message'];

			default:
				return $parsed['message'];
		}
	}

	/**
	 * Build the `data` payload attached to SSP-related WP_Error responses.
	 *
	 * Surfacing the SSP error code and request ID in the REST response lets
	 * the admin JS render an actionable error chip and lets support tickets
	 * include a request ID for cross-referencing in Worker logs.
	 *
	 * @param array $parsed       Output of parse_ssp_error_response().
	 * @param array $extra        Additional fields to merge into data.
	 *
	 * @return array
	 * @since 1.58.12
	 */
	private static function ssp_error_data( array $parsed, array $extra = [] ) {
		return array_merge(
			[
				'status'         => $parsed['http_status'] ? $parsed['http_status'] : 500,
				'ssp_error_code' => $parsed['code'],
				'ssp_request_id' => $parsed['request_id'],
				'ssp_message'    => $parsed['message'],
				'http_status'    => $parsed['http_status'],
			],
			$extra
		);
	}

	/**
	 * Persist the most recent SSP error to options so support tickets and
	 * the diagnostics snapshot can reference it without tailing the log.
	 *
	 * Pass null to clear.
	 *
	 * @param array|null $parsed Output of parse_ssp_error_response(), or null to clear.
	 * @param string     $source Identifier for the API call that failed (e.g. 'domain_info', 'config_push').
	 *
	 * @since 1.58.12
	 */
	private static function record_last_error( $parsed, $source = '' ) {

		$options = get_option(PMW_DB_OPTIONS_NAME);
		if (!is_array($options)) {
			return;
		}
		if (!isset($options['ssp']) || !is_array($options['ssp'])) {
			$options['ssp'] = [];
		}

		if (null === $parsed) {
			$options['ssp']['last_sync_error_code']        = '';
			$options['ssp']['last_sync_error_request_id']  = '';
			$options['ssp']['last_sync_error_http_status'] = 0;
			$options['ssp']['last_sync_error_source']      = '';
			$options['ssp']['last_sync_error_at']          = 0;
		} else {
			$options['ssp']['last_sync_error_code']        = $parsed['code'];
			$options['ssp']['last_sync_error_request_id']  = $parsed['request_id'];
			$options['ssp']['last_sync_error_http_status'] = $parsed['http_status'];
			$options['ssp']['last_sync_error_source']      = $source;
			$options['ssp']['last_sync_error_at']          = time();
		}

		remove_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10);
		update_option(PMW_DB_OPTIONS_NAME, $options);
		add_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2);

		Options::invalidate_cache();
	}

	/**
	 * Mark the saved sync token as no longer valid.
	 *
	 * Called when SSP returns 401 to a sync request, which means the stored
	 * token no longer matches any active domain hash on the server. Flips
	 * `ssp.enabled` to false and sets `ssp.requires_reauth` so the admin UI
	 * can surface a "re-paste your sync token" prompt instead of silently
	 * retrying forever. Also unschedules the daily sync to stop hammering
	 * SSP with credentials that will never authenticate.
	 *
	 * The sync token itself is intentionally preserved so the customer (and
	 * support) can compare its first-4/last-4 against the token currently
	 * shown in the SSP portal to confirm divergence.
	 *
	 * @param string $reason Human-readable reason from the SSP error response.
	 * @since 1.58.12
	 */
	private static function mark_token_invalid( $reason = '' ) {

		$options = get_option(PMW_DB_OPTIONS_NAME);
		if (!is_array($options)) {
			return;
		}
		if (!isset($options['ssp']) || !is_array($options['ssp'])) {
			$options['ssp'] = [];
		}

		// Already marked? Don't churn the option or re-log.
		if (!empty($options['ssp']['requires_reauth']) && empty($options['ssp']['enabled'])) {
			return;
		}

		$options['ssp']['enabled']                = false;
		$options['ssp']['requires_reauth']        = true;
		$options['ssp']['requires_reauth_reason'] = (string) $reason;
		$options['ssp']['requires_reauth_at']     = time();

		remove_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10);
		update_option(PMW_DB_OPTIONS_NAME, $options);
		add_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2);

		Options::invalidate_cache();

		// Stop daily/retry crons; they would only generate more 401s.
		if (function_exists('as_unschedule_all_actions')) {
			as_unschedule_all_actions(self::DAILY_SYNC_HOOK);
			as_unschedule_all_actions(self::ACTIVATION_RETRY_HOOK);
		}

		Logger::warning('SSP: Sync token rejected by server (401). Disabled SSP and flagged for re-authentication.');
	}

	/**
	 * Fetch domain info from the SSP using the sync token.
	 *
	 * Calls GET /v1/sync/domain-info on the SSP API.
	 *
	 * @param string $sync_token The domain sync token.
	 *
	 * @return array|\WP_Error Response data array on success, WP_Error on failure.
	 * @since 1.57.0
	 */
	public static function fetch_domain_info( $sync_token ) {

		$response = wp_remote_get(
			self::get_api_base() . '/v1/sync/domain-info',
			[
				'headers' => [
					'Authorization' => 'Bearer ' . $sync_token,
					'Content-Type'  => 'application/json',
				],
				'timeout' => 15,
			]
		);

		if (is_wp_error($response)) {
			Logger::error('SSP: Failed to fetch domain info: ' . $response->get_error_message());
			return $response;
		}

		$code = wp_remote_retrieve_response_code($response);
		$body = json_decode(wp_remote_retrieve_body($response), true);

		if (200 !== $code) {
			$parsed       = self::parse_ssp_error_response($body, $code);
			$user_message = self::user_message_for_ssp_error($parsed);

			Logger::error(sprintf(
				'SSP: Failed to fetch domain info — code=%s http=%d request_id=%s message=%s',
				$parsed['code'] ? $parsed['code'] : '(none)',
				$parsed['http_status'],
				$parsed['request_id'] ? $parsed['request_id'] : '(none)',
				$parsed['message']
			));

			self::record_last_error($parsed, 'domain_info');

			return new \WP_Error(
				'ssp_api_error',
				$user_message,
				self::ssp_error_data($parsed)
			);
		}

		// Unwrap the {success, data: {...}} envelope
		return isset($body['data']) ? $body['data'] : $body;
	}

	/**
	 * Register the callback URL with the SSP.
	 *
	 * Calls POST /v1/sync/register-callback on the SSP API.
	 *
	 * @param string $sync_token            The domain sync token.
	 * @param string $hostname              The proxy hostname.
	 * @param string $callback_url          The callback URL for resync.
	 * @param string $resync_callback_token The resync callback token.
	 *
	 * @return true|\WP_Error True on success, WP_Error on failure.
	 * @since 1.57.0
	 */
	public static function register_callback( $sync_token, $hostname, $callback_url, $resync_callback_token ) {

		$response = wp_remote_post(
			self::get_api_base() . '/v1/sync/register-callback',
			[
				'headers' => [
					'Authorization' => 'Bearer ' . $sync_token,
					'Content-Type'  => 'application/json',
				],
				'body'    => wp_json_encode([
					'hostname'            => $hostname,
					'callbackUrl'         => $callback_url,
					'resyncCallbackToken' => $resync_callback_token,
				]),
				'timeout' => 15,
			]
		);

		if (is_wp_error($response)) {
			Logger::error('SSP: Failed to register callback: ' . $response->get_error_message());
			return $response;
		}

		$code = wp_remote_retrieve_response_code($response);

		if ($code < 200 || $code >= 300) {
			$body         = json_decode(wp_remote_retrieve_body($response), true);
			$parsed       = self::parse_ssp_error_response($body, $code);
			$user_message = self::user_message_for_ssp_error($parsed);

			Logger::error(sprintf(
				'SSP: Failed to register callback — code=%s http=%d request_id=%s message=%s',
				$parsed['code'] ? $parsed['code'] : '(none)',
				$parsed['http_status'],
				$parsed['request_id'] ? $parsed['request_id'] : '(none)',
				$parsed['message']
			));

			self::record_last_error($parsed, 'register_callback');

			return new \WP_Error(
				'ssp_callback_error',
				$user_message,
				self::ssp_error_data($parsed)
			);
		}

		return true;
	}

	/**
	 * Build the steady-state metadata fields included in every SSP config sync payload.
	 *
	 * These fields describe the PMW build and host environment. They are sent at
	 * sync time only (not on per-event requests) so SweetCode Cloud can correlate
	 * destination behavior to the originating plugin context without paying
	 * per-event header bandwidth.
	 *
	 * Plugin version is included so the upgrade-triggered sync keeps the SSP's
	 * record of the deployed PMW build current.
	 *
	 * @return array<string, mixed>
	 * @since 1.58.12
	 */
	private static function get_sync_metadata_fields() {

		return [
			'pluginVersion'   => PMW_CURRENT_VERSION,
			'distro'          => PMW_DISTRO,
			'tier'            => Helpers::is_pmw_pro_version_active() ? 'pro' : 'free',
			'multisite'       => is_multisite(),
			'locale'          => get_locale(),
			'siteEnvironment' => function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : '',
			'timezone'        => wp_timezone_string(),
		];
	}

	/**
	 * Push the current CAPI configuration to the SSP.
	 *
	 * Calls POST /v1/sync/domain-config on the SSP API.
	 *
	 * @param string|null $sync_token Optional. Override the stored sync token.
	 * @param string      $source     Identifies what triggered this sync (e.g. 'daily_cron', 'manual_pmw', 'settings_changed').
	 * @param bool        $force      If true, bypasses the cooldown. Used for daily cron, manual sync, and activation.
	 *
	 * @return true|\WP_Error True on success, WP_Error on failure.
	 * @since 1.57.0
	 */
	public static function push_config_to_ssp( $sync_token = null, $source = 'unknown', $force = false ) {

		// Cooldown: prevent excessive syncing (e.g. accumulated Action Scheduler backlog).
		// Only non-forced syncs are subject to cooldown.
		if ( ! $force ) {
			$cooldown_key = self::SYNC_COOLDOWN_TRANSIENT;
			if ( get_transient( $cooldown_key ) ) {
				Logger::debug( 'SSP: Sync skipped — cooldown active (source: ' . $source . ').' );
				return true;
			}
			set_transient( $cooldown_key, 1, self::SYNC_COOLDOWN_SECONDS );
		}

		$options = Options::get_options();

		if (is_null($sync_token)) {
			$sync_token = isset($options['ssp']['sync_token']) ? $options['ssp']['sync_token'] : '';
		}

		if (empty($sync_token)) {
			return new \WP_Error('ssp_no_token', 'No SSP sync token configured.');
		}

		$hostname = isset($options['ssp']['proxy_hostname']) ? $options['ssp']['proxy_hostname'] : '';

		if (empty($hostname)) {
			return new \WP_Error('ssp_no_hostname', 'No SSP proxy hostname configured.');
		}

		$destinations = self::get_destination_configs($options);

		// Use only the origin (scheme + host) from site_url().
		// WordPress subdirectory installs return a path (e.g. /store),
		// but HTTP Origin headers never include paths.
		$site_url_parts = wp_parse_url( site_url() );
		$shop_origin    = $site_url_parts['scheme'] . '://' . $site_url_parts['host'];

		$payload = array_merge(
			[
				'hostname'     => $hostname,
				'shopOrigin'   => $shop_origin,
				'destinations' => $destinations,
				'syncSource'   => $source,
			],
			self::get_sync_metadata_fields()
		);

		$response = wp_remote_post(
			self::get_api_base() . '/v1/sync/domain-config',
			[
				'headers' => [
					'Authorization' => 'Bearer ' . $sync_token,
					'Content-Type'  => 'application/json',
				],
				'body'    => wp_json_encode($payload),
				'timeout' => 15,
			]
		);

		if (is_wp_error($response)) {
			Logger::error('SSP: Config push failed: ' . $response->get_error_message());
			self::update_sync_status(null, $response->get_error_message());
			return $response;
		}

		$code = wp_remote_retrieve_response_code($response);

		if ($code < 200 || $code >= 300) {
			$body         = json_decode(wp_remote_retrieve_body($response), true);
			$parsed       = self::parse_ssp_error_response($body, $code);
			$user_message = self::user_message_for_ssp_error($parsed);

			Logger::error(sprintf(
				'SSP: Config push failed — code=%s http=%d request_id=%s message=%s',
				$parsed['code'] ? $parsed['code'] : '(none)',
				$parsed['http_status'],
				$parsed['request_id'] ? $parsed['request_id'] : '(none)',
				$parsed['message']
			));

			self::record_last_error($parsed, 'config_push');

			// A 401 here means the sync token we hold no longer authenticates
			// against SSP — the customer has regenerated it in the portal,
			// the domain row was rotated by support, or the saved token was
			// corrupted client-side. Whatever the cause, every subsequent
			// push will keep failing silently until the user pastes a fresh
			// token. Disable the integration so the admin UI prompts for
			// re-activation instead of pretending we're still connected.
			//
			// We deliberately keep `sync_token` in storage (rather than
			// clearing it) so support can compare its first-4/last-4 against
			// the value currently in SSP to confirm divergence.
			//
			// @since 1.58.12
			if (401 === $code) {
				self::mark_token_invalid($user_message);
			}

			self::update_sync_status(null, $user_message);

			return new \WP_Error(
				'ssp_config_push_error',
				$user_message,
				self::ssp_error_data($parsed)
			);
		}

		// Capture domain token + plan/usage data from response
		$response_body = json_decode(wp_remote_retrieve_body($response), true);
		$data          = isset($response_body['data']) ? $response_body['data'] : [];

		$options = Options::get_options();
		$updated = false;

		// Read domainToken (new), fall back to verificationKey (old SSP versions)
		$domain_token = ! empty( $data['domainToken'] ) ? $data['domainToken'] : ( ! empty( $data['verificationKey'] ) ? $data['verificationKey'] : '' );
		if ( ! empty( $domain_token ) ) {
			$options['ssp']['domain_token'] = $domain_token;
			$updated                        = true;
			Logger::info('SSP: Domain token updated.');
		}

		// Update routing and config status from the SSP
		if (isset($data['routingStatus'])) {
			$options['ssp']['routing_status'] = $data['routingStatus'];
			$updated                          = true;
		}

		if (isset($data['configStatus'])) {
			$options['ssp']['config_status'] = $data['configStatus'];
			$updated                         = true;
		}

		// Store plan and usage info returned by the SSP
		if (isset($data['planName'])) {
			$options['ssp']['plan_name']             = $data['planName'];
			$options['ssp']['subscription_status']   = isset($data['subscriptionStatus']) ? $data['subscriptionStatus'] : '';
			$options['ssp']['usage_percent']         = isset($data['usagePercent']) ? $data['usagePercent'] : 0;
			$options['ssp']['monthly_request_limit'] = isset($data['monthlyRequestLimit']) ? $data['monthlyRequestLimit'] : 0;
			$options['ssp']['billable_this_period']  = isset($data['billableThisPeriod']) ? $data['billableThisPeriod'] : 0;
			$options['ssp']['quota_exceeded']        = ! empty( $data['quotaExceeded'] );
			$updated                                 = true;
		}

		// Store per-destination credential-validation results returned by the SSP.
		// On every sync the SSP fires a test event against each destination and
		// reports back which ones passed. We persist this so the admin UI can
		// surface a non-blocking partial-sync warning when one destination has
		// bad credentials while all others keep working.
		//
		// @since 1.59.0
		if (isset($data['destinationResults']) && is_array($data['destinationResults'])) {
			$results = [];
			foreach ($data['destinationResults'] as $result) {
				if (! is_array($result) || empty($result['type'])) {
					continue;
				}
				$results[] = [
					'type'        => (string) $result['type'],
					'ok'          => ! empty($result['ok']),
					'status_code' => isset($result['statusCode']) ? (int) $result['statusCode'] : null,
					'error'       => isset($result['error']) ? (string) $result['error'] : '',
				];
			}
			$options['ssp']['destination_results']         = $results;
			$options['ssp']['destination_results_checked'] = time();
			$updated                                       = true;
		}

		// Store the hash of the pushed destination configs. The periodic check in
		// maybe_sync_on_config_change() compares against it so changes that come
		// from filters (e.g. pmw_facebook_pixel_identifiers in a snippet) trigger
		// a re-push even though no PMW setting changed.
		//
		// @since 1.64.0
		$options['ssp']['config_hash'] = md5(wp_json_encode($destinations));
		$updated                       = true;

		if ($updated) {
			// Use direct update to avoid triggering our own hook
			remove_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10);
			update_option(PMW_DB_OPTIONS_NAME, $options);
			add_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2);
			Options::invalidate_cache();
		}

		Logger::info('SSP: Config push successful (source: ' . $source . ').');
		self::update_sync_status(time(), '');
		self::record_last_error(null);

		// Push config to additional SSP domains (multi-domain support)
		self::push_config_to_additional_domains( $options, $source );

		return true;
	}

	/**
	 * Push CAPI config and register callbacks for additional SSP domains.
	 *
	 * Iterates over domains registered via the pmw_ssp_additional_domains filter
	 * and pushes the same destination configs to each domain's SSP endpoint using
	 * that domain's own sync token and shop origin. Also registers resync callbacks.
	 *
	 * Failures on additional domains are logged but non-fatal.
	 *
	 * @param array  $options PMW options array.
	 * @param string $source  Sync source identifier forwarded to the SSP audit log.
	 *
	 * @since 1.57.1
	 */
	private static function push_config_to_additional_domains( $options, $source = 'unknown' ) {

		$additional_domains = Options::get_ssp_additional_domains();

		if ( empty( $additional_domains ) ) {
			return;
		}

		$destinations = self::get_destination_configs( $options );
		$updated      = false;

		foreach ( $additional_domains as $domain ) {

			$hostname   = $domain['proxy_hostname'];
			$sync_token = $domain['sync_token'];

			// Build payload with domain-specific shopOrigin.
			// Strip any path from shop_origin — HTTP Origin headers never include paths.
			$origin_parts = wp_parse_url( $domain['shop_origin'] );
			$clean_origin = $origin_parts['scheme'] . '://' . $origin_parts['host'];

			$payload = array_merge(
				[
					'hostname'     => $hostname,
					'shopOrigin'   => $clean_origin,
					'destinations' => $destinations,
					'syncSource'   => $source,
				],
				self::get_sync_metadata_fields()
			);

			$response = wp_remote_post(
				self::get_api_base() . '/v1/sync/domain-config',
				[
					'headers' => [
						'Authorization' => 'Bearer ' . $sync_token,
						'Content-Type'  => 'application/json',
					],
					'body'    => wp_json_encode( $payload ),
					'timeout' => 15,
				]
			);

			if ( is_wp_error( $response ) ) {
				Logger::warning( 'SSP: Additional domain config push failed for ' . $hostname . ': ' . $response->get_error_message() );
				continue;
			}

			$code = wp_remote_retrieve_response_code( $response );

			if ( $code < 200 || $code >= 300 ) {
				$body    = json_decode( wp_remote_retrieve_body( $response ), true );
				$message = isset( $body['error']['message'] ) ? $body['error']['message'] : 'Unknown error (HTTP ' . $code . ')';
				Logger::warning( 'SSP: Additional domain config push failed for ' . $hostname . ': ' . $message );
				continue;
			}

			Logger::info( 'SSP: Additional domain config push successful for ' . $hostname );

			// Store domain token from response
			$response_body = json_decode( wp_remote_retrieve_body( $response ), true );
			$data          = isset( $response_body['data'] ) ? $response_body['data'] : [];

			// Read domainToken (new), fall back to verificationKey (old SSP versions)
			$domain_token = ! empty( $data['domainToken'] ) ? $data['domainToken'] : ( ! empty( $data['verificationKey'] ) ? $data['verificationKey'] : '' );
			if ( ! empty( $domain_token ) ) {
				if ( ! isset( $options['ssp']['additional_domain_keys'][ $hostname ] ) ) {
					$options['ssp']['additional_domain_keys'][ $hostname ] = [];
				}
				$options['ssp']['additional_domain_keys'][ $hostname ]['domain_token'] = $domain_token;
				$updated = true;
			}

			// Register resync callback for this additional domain
			$resync_token    = wp_generate_password( 64, false );
			$callback_url    = rest_url( 'pmw/v1/ssp/resync' );
			$callback_result = self::register_callback( $sync_token, $hostname, $callback_url, $resync_token );

			if ( is_wp_error( $callback_result ) ) {
				Logger::warning( 'SSP: Additional domain callback registration failed for ' . $hostname . ': ' . $callback_result->get_error_message() );
			} else {
				if ( ! isset( $options['ssp']['additional_domain_keys'][ $hostname ] ) ) {
					$options['ssp']['additional_domain_keys'][ $hostname ] = [];
				}
				$options['ssp']['additional_domain_keys'][ $hostname ]['resync_callback_token'] = $resync_token;
				$updated = true;
				Logger::info( 'SSP: Additional domain callback registered for ' . $hostname );
			}
		}

		if ( $updated ) {
			// Use direct update to avoid triggering our own hook
			remove_action( 'update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10 );
			update_option( PMW_DB_OPTIONS_NAME, $options );
			add_action( 'update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2 );
			Options::invalidate_cache();
		}
	}

	/**
	 * Build the destination configuration array from PMW options.
	 *
	 * Maps each pixel's CAPI tokens to the SSP destination format.
	 *
	 * @param array $options PMW options array.
	 *
	 * @return array Array of destination config objects.
	 * @since 1.57.0
	 */
	public static function get_destination_configs( $options ) {
		$destinations = [];

		// Facebook CAPI
		if (!empty($options['facebook']['capi']['token']) && !empty($options['facebook']['pixel_id'])) {
			$dest = [
				'type'   => 'facebook',
				'config' => [
					'accessToken' => $options['facebook']['capi']['token'],
					'pixelId'     => $options['facebook']['pixel_id'],
				],
			];

			if (!empty($options['facebook']['capi']['test_event_code'])) {
				$dest['config']['testEventCode'] = $options['facebook']['capi']['test_event_code'];
			}

			// Additional pixels added with the pmw_facebook_pixel_identifiers filter.
			// The legacy single-pixel keys above stay in place because older SSP
			// versions strip the unknown pixels key and fall back to them.
			$capi_pixels = Facebook::get_capi_pixel_identifiers();

			if (count($capi_pixels) > 1) {

				$dest['config']['pixels'] = [];

				foreach ($capi_pixels as $capi_pixel) {

					$pixel_config = [
						'pixelId'     => $capi_pixel['pixel_id'],
						'accessToken' => $capi_pixel['capi_token'],
					];

					if ($capi_pixel['test_event_code']) {
						$pixel_config['testEventCode'] = $capi_pixel['test_event_code'];
					}

					$dest['config']['pixels'][] = $pixel_config;
				}
			}

			$destinations[] = $dest;
		}

		// TikTok EAPI
		if (!empty($options['tiktok']['eapi']['token']) && !empty($options['tiktok']['pixel_id'])) {
			$dest = [
				'type'   => 'tiktok',
				'config' => [
					'accessToken' => $options['tiktok']['eapi']['token'],
					'pixelId'     => $options['tiktok']['pixel_id'],
				],
			];

			if (!empty($options['tiktok']['eapi']['test_event_code'])) {
				$dest['config']['testEventCode'] = $options['tiktok']['eapi']['test_event_code'];
			}

			$destinations[] = $dest;
		}

		// Pinterest APIC
		if (!empty($options['pinterest']['apic']['token']) && !empty($options['pinterest']['pixel_id'])) {
			$dest = [
				'type'   => 'pinterest',
				'config' => [
					'accessToken' => $options['pinterest']['apic']['token'],
					'pixelId'     => $options['pinterest']['pixel_id'],
				],
			];

			if (!empty($options['pinterest']['ad_account_id'])) {
				$dest['config']['adAccountId'] = $options['pinterest']['ad_account_id'];
			}

			$destinations[] = $dest;
		}

		// Snapchat CAPI
		if (!empty($options['snapchat']['capi']['token']) && !empty($options['snapchat']['pixel_id'])) {
			$destinations[] = [
				'type'   => 'snapchat',
				'config' => [
					'accessToken' => $options['snapchat']['capi']['token'],
					'pixelId'     => $options['snapchat']['pixel_id'],
				],
			];
		}

		// Reddit CAPI
		if (!empty($options['pixels']['reddit']['capi']['token']) && !empty($options['pixels']['reddit']['advertiser_id'])) {
			$dest = [
				'type'   => 'reddit',
				'config' => [
					'accessToken' => $options['pixels']['reddit']['capi']['token'],
					'pixelId'     => $options['pixels']['reddit']['advertiser_id'],
				],
			];

			if (!empty($options['pixels']['reddit']['capi']['test_event_code'])) {
				$dest['config']['testEventCode'] = $options['pixels']['reddit']['capi']['test_event_code'];
			}

			$destinations[] = $dest;
		}

		// OpenAI Conversions API
		if (!empty($options['pixels']['openai']['capi']['token']) && !empty($options['pixels']['openai']['pixel_id'])) {
			$destinations[] = [
				'type'   => 'openai',
				'config' => [
					'accessToken' => $options['pixels']['openai']['capi']['token'],
					'pixelId'     => $options['pixels']['openai']['pixel_id'],
				],
			];
		}

		// Nextdoor Conversion API
		if (!empty($options['pixels']['nextdoor']['capi']['token']) && !empty($options['pixels']['nextdoor']['pixel_id'])) {
			$dest = [
				'type'   => 'nextdoor',
				'config' => [
					'accessToken' => $options['pixels']['nextdoor']['capi']['token'],
					'pixelId'     => $options['pixels']['nextdoor']['pixel_id'],
				],
			];

			if (!empty($options['pixels']['nextdoor']['capi']['test_event_code'])) {
				$dest['config']['testEventCode'] = $options['pixels']['nextdoor']['capi']['test_event_code'];
			}

			$destinations[] = $dest;
		}

		// Spotify Conversions API.
		// The connection ID identifies the data source the events are attributed
		// to, so it is required alongside the token before the destination can
		// be synced. The pixel ID is passed along for reporting only.
		if (!empty($options['pixels']['spotify']['capi']['token']) && !empty($options['pixels']['spotify']['capi']['connection_id'])) {
			$dest = [
				'type'   => 'spotify',
				'config' => [
					'accessToken'  => $options['pixels']['spotify']['capi']['token'],
					'connectionId' => $options['pixels']['spotify']['capi']['connection_id'],
				],
			];

			if (!empty($options['pixels']['spotify']['pixel_id'])) {
				$dest['config']['pixelId'] = $options['pixels']['spotify']['pixel_id'];
			}

			$destinations[] = $dest;
		}

		// AppLovin Conversion API.
		// The event key doubles as the Conversion API's pixel_id query
		// parameter, so both values are required before the destination can be
		// synced.
		if (!empty($options['pixels']['applovin']['capi']['token']) && !empty($options['pixels']['applovin']['event_key'])) {
			$destinations[] = [
				'type'   => 'applovin',
				'config' => [
					'apiKey'  => $options['pixels']['applovin']['capi']['token'],
					'pixelId' => $options['pixels']['applovin']['event_key'],
				],
			];
		}

		// Microsoft Advertising Conversions API.
		// The UET tag ID is part of the endpoint path, so both values are
		// required before the destination can be synced.
		if (!empty($options['bing']['capi']['token']) && !empty($options['bing']['uet_tag_id'])) {
			$destinations[] = [
				'type'   => 'bing',
				'config' => [
					'accessToken' => $options['bing']['capi']['token'],
					'pixelId'     => $options['bing']['uet_tag_id'],
				],
			];
		}

		// Google Analytics 4 Measurement Protocol.
		// When MP is configured (measurement_id + api_secret), route GA4
		// server events (purchase, refund) through the SSP for unified
		// event logging. PMW skips its direct call to /mp/collect when
		// the SSP is active; the worker forwards the pre-built MP payload
		// to https://www.google-analytics.com/mp/collect.
		if (
			!empty($options['google']['analytics']['ga4']['measurement_id']) &&
			!empty($options['google']['analytics']['ga4']['api_secret'])
		) {
			$destinations[] = [
				'type'   => 'google_ga4',
				'config' => [
					'measurementId' => $options['google']['analytics']['ga4']['measurement_id'],
					'apiSecret'     => $options['google']['analytics']['ga4']['api_secret'],
				],
			];
		}

		// The Google Ads Data Manager upload never routes through the SSP: it
		// authenticates through the connect broker, whose credentials the SSP
		// worker does not hold. It always sends directly from PHP.

		// Mixpanel Ingestion API.
		// Mixpanel authenticates with the project token in the event payload, so
		// the token doubles as the credential and there is nothing else to sync
		// besides the data residency region, which decides the API host the
		// worker posts to.
		if (
			!empty($options['pixels']['mixpanel']['project_token']) &&
			!empty($options['pixels']['mixpanel']['ingestion_api']['enabled'])
		) {
			$destinations[] = [
				'type'   => 'mixpanel',
				'config' => [
					'projectToken'  => $options['pixels']['mixpanel']['project_token'],
					'dataResidency' => Options::get_mixpanel_data_residency(),
				],
			];
		}

		// Klaviyo Events API.
		// Synced only while the Pixel Manager actually dispatches purchases, that
		// is with a private key and without the official Klaviyo plugin. With the
		// plugin installed, Klaviyo produces Placed Order itself and a synced
		// destination would only ever sit idle.
		if (Options::is_klaviyo_purchase_dispatch_active()) {
			$destinations[] = [
				'type'   => 'klaviyo',
				'config' => [
					'publicApiKey'  => $options['pixels']['klaviyo']['public_api_key'],
					'privateApiKey' => $options['pixels']['klaviyo']['events_api']['token'],
				],
			];
		}

		return self::remove_paused_destinations($destinations, $options);
	}

	/**
	 * Drop the destinations of paused pixels.
	 *
	 * A paused pixel keeps its settings but must not receive anything, so its
	 * destination leaves the SSP config until the pixel is resumed. Reads the
	 * pause from the passed options, not the cached ones, because the
	 * settings-change sync runs with the options that are being saved.
	 *
	 * @param array $destinations Destination configs.
	 * @param array $options      PMW options array.
	 *
	 * @return array
	 * @since 1.71.1
	 */
	private static function remove_paused_destinations( $destinations, $options ) {

		if (empty($options['paused_pixels']) || !is_array($options['paused_pixels'])) {
			return $destinations;
		}

		// SSP destination type => pixel ID. Every other type is named after its pixel.
		$pixel_by_type = [
			'google_ga4' => 'ga4',
		];

		return array_values(array_filter($destinations, function ( $destination ) use ( $options, $pixel_by_type ) {

			$type  = isset($destination['type']) ? $destination['type'] : '';
			$pixel = isset($pixel_by_type[ $type ]) ? $pixel_by_type[ $type ] : $type;

			return empty($options['paused_pixels'][ $pixel ]);
		}));
	}


	/**
	 * Update the SSP sync status in options.
	 *
	 * @param int|null    $timestamp Unix timestamp of last successful sync, or null on failure.
	 * @param string      $error     Error message, empty on success.
	 *
	 * @since 1.57.0
	 */
	private static function update_sync_status( $timestamp, $error ) {
		$options = get_option(PMW_DB_OPTIONS_NAME);

		if (!$options) {
			return;
		}

		if (!is_null($timestamp)) {
			$options['ssp']['last_sync_at']  = $timestamp;
			$options['ssp']['config_status'] = 'synced';
		}

		if (!empty($error)) {
			$options['ssp']['config_status'] = 'sync_error';
		}

		$options['ssp']['last_sync_error'] = $error;

		// Use direct update to avoid triggering our own hook
		remove_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10);
		update_option(PMW_DB_OPTIONS_NAME, $options);
		add_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2);

		Options::invalidate_cache();
	}

	/**
	 * Run the full SSP activation flow.
	 *
	 * 1. Fetch domain info from SSP
	 * 2. Generate resync callback token
	 * 3. Register callback with SSP
	 * 4. Push config to SSP
	 * 5. Store all SSP options
	 *
	 * @param string $sync_token The domain sync token.
	 *
	 * @return array|\WP_Error Domain info array on success, WP_Error on failure.
	 * @since 1.57.0
	 */
	public static function activate( $sync_token ) {

		// Step 1: Fetch domain info
		$domain_info = self::fetch_domain_info($sync_token);

		if (is_wp_error($domain_info)) {
			return $domain_info;
		}

		if (empty($domain_info['domain']['hostname'])) {
			return new \WP_Error('ssp_invalid_response', 'Invalid domain info response from SSP.');
		}

		$hostname = $domain_info['domain']['hostname'];

		// Step 1b: Validate that the domain hostname belongs to this shop
		$shop_domain = self::normalize_shop_domain(wp_parse_url(site_url(), PHP_URL_HOST));

		// Prefer explicit shopDomain from SSP response, fall back to extracting from hostname
		$domain_shop_domain = ! empty($domain_info['domain']['shopDomain'])
			? self::normalize_shop_domain($domain_info['domain']['shopDomain'])
			: self::normalize_shop_domain(self::extract_shop_domain_from_hostname($hostname));

		if ($shop_domain !== $domain_shop_domain) {

			$mismatch_parsed = [
				'code'        => 'shop_origin_mismatch',
				'message'     => sprintf(
					'This sync token belongs to a domain for "%s", but this shop is "%s". Please use the correct sync token for this shop.',
					$domain_shop_domain,
					$shop_domain
				),
				'request_id'  => '',
				'http_status' => 403,
			];

			Logger::error(sprintf(
				'SSP: Activation rejected — local shop_origin_mismatch (expected=%s received=%s hostname=%s).',
				$shop_domain,
				$domain_shop_domain,
				$hostname
			));

			self::record_last_error($mismatch_parsed, 'activation_domain_mismatch');

			return new \WP_Error(
				'ssp_domain_mismatch',
				$mismatch_parsed['message'],
				self::ssp_error_data(
					$mismatch_parsed,
					[
						'expected_shop'   => $shop_domain,
						'received_shop'   => $domain_shop_domain,
						'received_hostname' => $hostname,
						'detected_by'     => 'plugin',
					]
				)
			);
		}

		// Step 2: Generate resync callback token
		$resync_callback_token = wp_generate_password(64, false);

		// Step 3: Register callback with SSP
		$callback_url = rest_url('pmw/v1/ssp/resync');
		$result       = self::register_callback($sync_token, $hostname, $callback_url, $resync_callback_token);

		if (is_wp_error($result)) {
			return $result;
		}

		// Step 4: Store SSP options
		$options = get_option(PMW_DB_OPTIONS_NAME);

		$options['ssp']['sync_token']            = $sync_token;
		$options['ssp']['enabled']               = true;
		$options['ssp']['proxy_hostname']        = $hostname;
		$options['ssp']['domain_id']             = isset($domain_info['domain']['id']) ? $domain_info['domain']['id'] : '';
		$options['ssp']['routing_status']        = isset($domain_info['domain']['routingStatus']) ? $domain_info['domain']['routingStatus'] : '';
		$options['ssp']['config_status']         = isset($domain_info['domain']['configStatus']) ? $domain_info['domain']['configStatus'] : '';
		$options['ssp']['resync_callback_token'] = $resync_callback_token;

		// Clear any prior re-auth flag \u2014 we just successfully authenticated.
		$options['ssp']['requires_reauth']        = false;
		$options['ssp']['requires_reauth_reason'] = '';
		$options['ssp']['requires_reauth_at']     = 0;

		// Store plan and usage info from SSP
		$options['ssp']['plan_name']             = isset($domain_info['domain']['planName']) ? $domain_info['domain']['planName'] : '';
		$options['ssp']['subscription_status']   = isset($domain_info['domain']['subscriptionStatus']) ? $domain_info['domain']['subscriptionStatus'] : '';
		$options['ssp']['usage_percent']         = isset($domain_info['domain']['usagePercent']) ? $domain_info['domain']['usagePercent'] : 0;
		$options['ssp']['monthly_request_limit'] = isset($domain_info['domain']['monthlyRequestLimit']) ? $domain_info['domain']['monthlyRequestLimit'] : 0;
		$options['ssp']['billable_this_period']  = isset($domain_info['domain']['billableThisPeriod']) ? $domain_info['domain']['billableThisPeriod'] : 0;

		// Use direct update to avoid triggering our own hook
		remove_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10);
		update_option(PMW_DB_OPTIONS_NAME, $options);
		add_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2);

		Options::invalidate_cache();

		// Verify the sync token actually persisted. update_option() returns
		// false on a no-op (value already identical) AND on a real write
		// failure (DB error, conflicting pre_update_option filter, object
		// cache desync), so its return value alone is unreliable. Re-read
		// the options fresh from the DB and compare. A silent mismatch here
		// is exactly the failure mode that leaves a customer's PMW pointing
		// at a token whose hash no longer exists in SSP \u2014 every future
		// sync would 401 with no diagnosable cause.
		//
		// @since 1.58.12
		wp_cache_delete(PMW_DB_OPTIONS_NAME, 'options');
		$reread      = get_option(PMW_DB_OPTIONS_NAME);
		$saved_token = isset($reread['ssp']['sync_token']) ? $reread['ssp']['sync_token'] : '';

		if ($saved_token !== $sync_token) {
			Logger::error(sprintf(
				'SSP: Token save verification failed. Expected length=%d, saved length=%d. Aborting activation.',
				strlen($sync_token),
				strlen($saved_token)
			));

			return new \WP_Error(
				'ssp_token_save_failed',
				'Failed to persist the sync token to WordPress options. This is usually caused by a database error, an object-cache misconfiguration, or another plugin filtering update_option. Please contact support.',
				[ 'status' => 500 ]
			);
		}

		// Step 5: Push config to SSP
		$push_result = self::push_config_to_ssp( $sync_token, 'activation', true );

		if (is_wp_error($push_result)) {
			// Non-fatal: domain is connected but config push failed
			Logger::warning('SSP: Activation succeeded but initial config push failed: ' . $push_result->get_error_message());
		}

		// Start activation retry schedule if domain is not yet fully active
		$routing = isset($options['ssp']['routing_status']) ? $options['ssp']['routing_status'] : '';
		$config  = isset($options['ssp']['config_status']) ? $options['ssp']['config_status'] : '';

		if ( 'active' !== $routing || 'synced' !== $config ) {
			self::schedule_activation_retry();
		}

		return $domain_info;
	}

	/**
	 * Disable SSP without clearing connection state.
	 *
	 * Sets enabled to false and unschedules the daily sync task,
	 * but preserves the sync token, proxy hostname, domain ID, and
	 * all other connection data so it can be re-enabled without
	 * re-entering the token.
	 *
	 * @since 1.57.0
	 */
	public static function disable() {

		$options = get_option(PMW_DB_OPTIONS_NAME);

		$options['ssp']['enabled'] = false;

		// Use direct update to avoid triggering our own hook
		remove_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10);
		update_option(PMW_DB_OPTIONS_NAME, $options);
		add_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2);

		Options::invalidate_cache();

		// Unschedule daily sync and activation retry
		if (function_exists('as_unschedule_all_actions')) {
			as_unschedule_all_actions(self::DAILY_SYNC_HOOK);
			as_unschedule_all_actions(self::ACTIVATION_RETRY_HOOK);
		}

		Logger::info('SSP: Disabled (connection state preserved).');
	}

	/**
	 * Re-enable SSP using the preserved connection state.
	 *
	 * Sets enabled back to true and re-schedules the daily sync.
	 * If routing/config status are still valid, SSP becomes active
	 * immediately. If statuses are stale, triggers a config re-sync.
	 *
	 * @return true|\WP_Error True on success, WP_Error if no token is stored.
	 * @since 1.57.0
	 */
	public static function enable() {

		$options = get_option(PMW_DB_OPTIONS_NAME);

		if ( empty( $options['ssp']['sync_token'] ) ) {
			return new \WP_Error(
				'ssp_no_token',
				'Cannot enable SSP: no sync token is stored. Please activate with a sync token first.',
				[ 'status' => 400 ]
			);
		}

		$options['ssp']['enabled'] = true;

		// Use direct update to avoid triggering our own hook
		remove_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10);
		update_option(PMW_DB_OPTIONS_NAME, $options);
		add_action('update_option_' . PMW_DB_OPTIONS_NAME, [ self::get_instance(), 'on_options_updated' ], 10, 2);

		Options::invalidate_cache();

		// Re-schedule daily sync
		self::get_instance()->maybe_schedule_daily_sync();

		Logger::info('SSP: Enabled.');

		// If statuses look stale, trigger a config re-sync
		$routing = isset($options['ssp']['routing_status']) ? $options['ssp']['routing_status'] : '';
		$config  = isset($options['ssp']['config_status']) ? $options['ssp']['config_status'] : '';

		if ( 'active' !== $routing || 'synced' !== $config ) {
			Logger::info('SSP: Statuses may be stale, triggering config re-sync.');
			self::push_config_to_ssp( null, 're_enable', true );

			// Resume activation retry if domain is still not active
			$options = Options::get_options();
			$routing = isset($options['ssp']['routing_status']) ? $options['ssp']['routing_status'] : '';
			$config  = isset($options['ssp']['config_status']) ? $options['ssp']['config_status'] : '';

			if ( 'active' !== $routing || 'synced' !== $config ) {
				self::schedule_activation_retry();
			}
		}

		return true;
	}

	/**
	 * Fully disconnect SSP and clear all stored state.
	 *
	 * Removes the sync token and all connection data. The user will
	 * need to re-enter the token from the SSP portal to reconnect.
	 *
	 * @since 1.57.0
	 */
	public static function disconnect() {

		$options = get_option(PMW_DB_OPTIONS_NAME);

		// Notify the SSP to clear callback data (best-effort, don't block on failure)
		$sync_token = isset($options['ssp']['sync_token']) ? $options['ssp']['sync_token'] : '';
		if (!empty($sync_token)) {
			self::notify_ssp_disconnect($sync_token);
		}

		$options['ssp'] = [
			'sync_token'              => '',
			'enabled'                 => false,
			'proxy_hostname'          => '',
			'domain_id'               => '',
			'routing_status'          => '',
			'config_status'           => '',
			'last_sync_at'            => 0,
			'last_sync_error'         => '',
			'resync_callback_token'   => '',
			'verification_key'        => '',
			'proxy_failure_behavior'  => 'fallback_to_wc',
			'activation_retry_start'  => 0,
			'plan_name'               => '',
			'subscription_status'     => '',
			'usage_percent'           => 0,
			'monthly_request_limit'   => 0,
			'billable_this_period'    => 0,
		];

		update_option(PMW_DB_OPTIONS_NAME, $options);
		Options::invalidate_cache();

		// Unschedule daily sync and activation retry
		if (function_exists('as_unschedule_all_actions')) {
			as_unschedule_all_actions(self::DAILY_SYNC_HOOK);
			as_unschedule_all_actions(self::ACTIVATION_RETRY_HOOK);
		}

		Logger::info('SSP: Disconnected and cleared all SSP settings.');
	}

	/**
	 * Notify the SSP that this shop is disconnecting.
	 *
	 * Calls POST /v1/sync/disconnect to clear callback data on the domain.
	 * This is best-effort — failure is logged but does not block the disconnect.
	 *
	 * @param string $sync_token The domain sync token.
	 *
	 * @since 1.57.1
	 */
	private static function notify_ssp_disconnect( $sync_token ) {

		$response = wp_remote_post(
			self::get_api_base() . '/v1/sync/disconnect',
			[
				'headers' => [
					'Authorization' => 'Bearer ' . $sync_token,
					'Content-Type'  => 'application/json',
				],
				'body'    => '{}',
				'timeout' => 10,
			]
		);

		if (is_wp_error($response)) {
			Logger::warning('SSP: Failed to notify SSP of disconnect: ' . $response->get_error_message());
			return;
		}

		$code = wp_remote_retrieve_response_code($response);

		if ($code < 200 || $code >= 300) {
			Logger::warning('SSP: SSP disconnect notification returned HTTP ' . $code);
		}
	}

	/**
	 * Deactivate SSP and clear all stored state.
	 *
	 * @deprecated 1.57.0 Use disconnect() instead.
	 * @since 1.57.0
	 */
	public static function deactivate() {
		self::disconnect();
	}

	/**
	 * Test the SSP proxy connectivity.
	 *
	 * @return array|\WP_Error Health check result or error.
	 * @since 1.57.0
	 */
	public static function test_connection() {

		$hostname = Options::get_ssp_proxy_hostname();

		if (empty($hostname)) {
			return new \WP_Error('ssp_no_hostname', 'No SSP proxy hostname configured.');
		}

		// In dev, use the overridden events URL; in production, use the proxy hostname
		$url = defined( 'PMW_SSP_EVENTS_URL' )
			? PMW_SSP_EVENTS_URL
			: 'https://' . $hostname . '/v1/events';

		$response = wp_remote_get(
			$url,
			[
				'timeout' => 10,
				'headers' => [
					'Accept' => 'application/json',
				],
			]
		);

		if (is_wp_error($response)) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code($response);

		// The OPTIONS/GET to the events endpoint should respond (even with 405 Method Not Allowed)
		// A response means the proxy is reachable
		return [
			'reachable'   => $code > 0,
			'status_code' => $code,
			'hostname'    => $hostname,
		];
	}

	/**
	 * Get the current SSP status for the admin UI.
	 *
	 * @return array
	 * @since 1.57.0
	 */
	public static function get_status() {

		$options = Options::get_options();
		$ssp     = isset($options['ssp']) ? $options['ssp'] : [];

		$last_sync_at = isset($ssp['last_sync_at']) ? $ssp['last_sync_at'] : 0;

		return [
			'enabled'                 => !empty($ssp['enabled']),
			'has_token'               => !empty($ssp['sync_token']),
			'proxy_hostname'          => isset($ssp['proxy_hostname']) ? $ssp['proxy_hostname'] : '',
			'domain_id'               => isset($ssp['domain_id']) ? $ssp['domain_id'] : '',
			'routing_status'          => isset($ssp['routing_status']) ? $ssp['routing_status'] : '',
			'config_status'           => isset($ssp['config_status']) ? $ssp['config_status'] : '',
			'last_sync_at'            => $last_sync_at,
			'last_sync_at_formatted'  => $last_sync_at
				? wp_date(get_option('date_format') . ', ' . get_option('time_format'), $last_sync_at)
				: '',
			'last_sync_error'             => isset($ssp['last_sync_error']) ? $ssp['last_sync_error'] : '',
			'last_sync_error_code'        => isset($ssp['last_sync_error_code']) ? $ssp['last_sync_error_code'] : '',
			'last_sync_error_request_id' => isset($ssp['last_sync_error_request_id']) ? $ssp['last_sync_error_request_id'] : '',
			'last_sync_error_http_status' => isset($ssp['last_sync_error_http_status']) ? (int) $ssp['last_sync_error_http_status'] : 0,
			'last_sync_error_source'      => isset($ssp['last_sync_error_source']) ? $ssp['last_sync_error_source'] : '',
			'last_sync_error_at'          => isset($ssp['last_sync_error_at']) ? (int) $ssp['last_sync_error_at'] : 0,
			'requires_reauth'             => !empty($ssp['requires_reauth']),
			'requires_reauth_reason'      => isset($ssp['requires_reauth_reason']) ? $ssp['requires_reauth_reason'] : '',
			'requires_reauth_at'          => isset($ssp['requires_reauth_at']) ? (int) $ssp['requires_reauth_at'] : 0,
			'is_active'                   => Options::is_ssp_active(),
			'proxy_failure_behavior'      => Options::get_ssp_proxy_failure_behavior(),
			'quota_exceeded'              => Options::is_ssp_quota_exceeded(),
			'plan_name'                   => isset($ssp['plan_name']) ? $ssp['plan_name'] : '',
			'subscription_status'         => isset($ssp['subscription_status']) ? $ssp['subscription_status'] : '',
			'usage_percent'               => isset($ssp['usage_percent']) ? $ssp['usage_percent'] : 0,
			'monthly_request_limit'       => isset($ssp['monthly_request_limit']) ? $ssp['monthly_request_limit'] : 0,
			'billable_this_period'        => isset($ssp['billable_this_period']) ? $ssp['billable_this_period'] : 0,
			'failed_destinations'         => Options::get_ssp_failed_destinations(),
		];
	}

	/**
	 * Build a paste-ready diagnostic snapshot for support tickets.
	 *
	 * Includes plugin/environment metadata, SSP connection state, and the
	 * most recent SSP error (code + request ID) so support can cross-reference
	 * the failure in Worker logs without a back-and-forth round trip.
	 *
	 * The sync token is redacted to first-4/last-4 chars — enough for the
	 * customer and support to confirm they're talking about the same token
	 * without exposing the secret. The Authorization header itself is never
	 * included.
	 *
	 * Returns both a structured `fields` array and a pre-rendered `text` block
	 * so the JS can pick whichever fits the UI.
	 *
	 * @return array
	 * @since 1.58.12
	 */
	public static function get_diagnostic_info() {

		global $wp_version;

		$options = Options::get_options();
		$ssp     = isset($options['ssp']) ? $options['ssp'] : [];

		$sync_token = isset($ssp['sync_token']) ? (string) $ssp['sync_token'] : '';
		if (strlen($sync_token) >= 12) {
			$sync_token_redacted = substr($sync_token, 0, 4) . '…' . substr($sync_token, -4) . ' (' . strlen($sync_token) . ' chars)';
		} elseif ('' !== $sync_token) {
			$sync_token_redacted = '(set, ' . strlen($sync_token) . ' chars)';
		} else {
			$sync_token_redacted = '(not set)';
		}

		$site_url_parts = wp_parse_url(site_url());
		$shop_origin    = isset($site_url_parts['scheme'], $site_url_parts['host'])
			? $site_url_parts['scheme'] . '://' . $site_url_parts['host']
			: site_url();

		$last_sync_at       = isset($ssp['last_sync_at']) ? (int) $ssp['last_sync_at'] : 0;
		$last_sync_error_at = isset($ssp['last_sync_error_at']) ? (int) $ssp['last_sync_error_at'] : 0;

		$fields = [
			'generated_at'                 => gmdate('c'),
			'pmw_version'                  => defined('PMW_CURRENT_VERSION') ? PMW_CURRENT_VERSION : '',
			'pmw_distro'                   => defined('PMW_DISTRO') ? PMW_DISTRO : '',
			'pmw_tier'                     => Helpers::is_pmw_pro_version_active() ? 'pro' : 'free',
			'wp_version'                   => $wp_version,
			'php_version'                  => PHP_VERSION,
			'multisite'                    => is_multisite(),
			'locale'                       => get_locale(),
			'timezone'                     => wp_timezone_string(),
			'site_url'                     => site_url(),
			'shop_origin'                  => $shop_origin,
			'ssp_enabled'                  => !empty($ssp['enabled']),
			'ssp_is_active'                => Options::is_ssp_active(),
			'ssp_sync_token_redacted'      => $sync_token_redacted,
			'ssp_proxy_hostname'           => isset($ssp['proxy_hostname']) ? $ssp['proxy_hostname'] : '',
			'ssp_domain_id'                => isset($ssp['domain_id']) ? $ssp['domain_id'] : '',
			'ssp_routing_status'           => isset($ssp['routing_status']) ? $ssp['routing_status'] : '',
			'ssp_config_status'            => isset($ssp['config_status']) ? $ssp['config_status'] : '',
			'ssp_plan_name'                => isset($ssp['plan_name']) ? $ssp['plan_name'] : '',
			'ssp_subscription_status'      => isset($ssp['subscription_status']) ? $ssp['subscription_status'] : '',
			'ssp_last_sync_at'             => $last_sync_at ? gmdate('c', $last_sync_at) : '',
			'ssp_last_sync_error'          => isset($ssp['last_sync_error']) ? $ssp['last_sync_error'] : '',
			'ssp_last_sync_error_code'     => isset($ssp['last_sync_error_code']) ? $ssp['last_sync_error_code'] : '',
			'ssp_last_sync_error_request_id' => isset($ssp['last_sync_error_request_id']) ? $ssp['last_sync_error_request_id'] : '',
			'ssp_last_sync_error_http'     => isset($ssp['last_sync_error_http_status']) ? (int) $ssp['last_sync_error_http_status'] : 0,
			'ssp_last_sync_error_source'   => isset($ssp['last_sync_error_source']) ? $ssp['last_sync_error_source'] : '',
			'ssp_last_sync_error_at'       => $last_sync_error_at ? gmdate('c', $last_sync_error_at) : '',
			'ssp_api_base'                 => self::get_api_base(),
		];

		// Pre-render as a paste-ready plain-text block. Stable ordering so
		// support can scan the same lines across tickets.
		$lines = [ '--- PMW SSP diagnostic snapshot ---' ];
		foreach ($fields as $key => $value) {
			if (is_bool($value)) {
				$value = $value ? 'true' : 'false';
			}
			$lines[] = $key . ': ' . ( '' === $value || null === $value ? '(empty)' : $value );
		}
		$lines[] = '--- end ---';

		return [
			'fields' => $fields,
			'text'   => implode("\n", $lines),
		];
	}
}
