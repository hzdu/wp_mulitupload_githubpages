<?php
/**
 * Answers a request before its slow work runs.
 *
 * A browser-relayed server event used to hold the visitor's connection and a
 * PHP worker until every outbound vendor request had returned. Where the
 * server API can close the client connection early (PHP-FPM, LiteSpeed), the
 * success response is sent first and the outbound requests run afterwards.
 * Where it cannot, nothing is sent here and the caller answers after the
 * work, as before. See DD-094.
 *
 * @package SweetCode\Pixel_Manager
 * @since 1.74.3
 */

namespace SweetCode\Pixel_Manager;

defined('ABSPATH') || exit; // Exit if accessed directly

class Early_Response {

	/**
	 * Sends the JSON success response, releases the client connection where
	 * the server allows it, then runs the work.
	 *
	 * @param callable $work The slow part of the request.
	 * @return bool True when the response has already been sent, so the caller
	 *              must not send another one. False when the caller still has
	 *              to answer the request.
	 *
	 * @since 1.74.3
	 */
	public function json_success_then( $work ) {

		$sent = $this->send_json_success_and_release();

		call_user_func($work);

		return $sent;
	}

	/**
	 * Sends the JSON success response and closes the client connection.
	 *
	 * Does nothing when no finish-request function exists or the headers are
	 * already out, so the caller keeps the old order (work, then response).
	 *
	 * @return bool True when the response was sent.
	 *
	 * @since 1.74.3
	 */
	public function send_json_success_and_release() {

		$finish_function = $this->get_finish_function();

		if (null === $finish_function || $this->headers_sent()) {
			return false;
		}

		$this->prepare_for_background_work();
		$this->emit_json_success();

		// The body is out either way. If the server refuses to close the
		// connection early, it is flushed when the request ends.
		call_user_func($finish_function);

		return true;
	}

	/**
	 * The first finish-request function this server offers.
	 *
	 * @return string|null
	 *
	 * @since 1.74.3
	 */
	public function get_finish_function() {

		foreach ($this->get_finish_function_candidates() as $candidate) {
			if (function_exists($candidate)) {
				return $candidate;
			}
		}

		return null;
	}

	/**
	 * Finish-request functions in order of preference.
	 *
	 * @return string[]
	 *
	 * @since 1.74.3
	 */
	protected function get_finish_function_candidates() {
		return [
			'fastcgi_finish_request',   // PHP-FPM
			'litespeed_finish_request', // LiteSpeed SAPI
		];
	}

	/**
	 * Whether the response headers are already out.
	 *
	 * @return bool
	 *
	 * @since 1.74.3
	 */
	protected function headers_sent() {
		return headers_sent();
	}

	/**
	 * Keeps the work alive after the visitor is gone and frees a native PHP
	 * session, whose lock would otherwise queue the visitor's next requests
	 * behind the outbound sends.
	 *
	 * @return void
	 *
	 * @since 1.74.3
	 */
	protected function prepare_for_background_work() {

		ignore_user_abort(true);

		if (function_exists('session_status') && PHP_SESSION_ACTIVE === session_status()) {
			session_write_close();
		}
	}

	/**
	 * Writes the same response wp_send_json_success() would, without dying.
	 *
	 * @return void
	 *
	 * @since 1.74.3
	 */
	protected function emit_json_success() {

		status_header(200);
		header('Content-Type: application/json; charset=' . get_option('blog_charset'));

		echo wp_json_encode([ 'success' => true ]);
	}
}
