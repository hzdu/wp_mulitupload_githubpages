<?php

/**
 * HTTP request class
 *
 * For Dependency Injection
 *
 * Can get, gan post
 *
 * @since 1.42.6
 */

namespace SweetCode\Pixel_Manager;

defined('ABSPATH') || exit; // Exit if accessed directly

class HTTP {

	private $request_args;

	/**
	 * Upper bound, in seconds, for the timeout of every POST while it is set.
	 *
	 * @var float|int|null
	 * @since 1.74.3
	 */
	private static $timeout_cap = null;

	/**
	 * Caps the timeout of every POST sent from now on, or lifts the cap.
	 *
	 * The CAPI classes build their HTTP object once and reuse it, so a
	 * timeout for one code path cannot be set at construction. The relay of
	 * browser events sets the cap around its sends and lifts it afterwards;
	 * purchase sends never run under it. See DD-094.
	 *
	 * @param float|int|null $seconds Null lifts the cap.
	 * @return void
	 *
	 * @since 1.74.3
	 */
	public static function set_timeout_cap( $seconds ) {
		self::$timeout_cap = null === $seconds ? null : max(1, $seconds);
	}

	/**
	 * Applies the timeout cap to a set of request args.
	 *
	 * The cap is skipped while S2S requests are sent blocking (the debug
	 * logging mode), where the full response is the point.
	 *
	 * @param array $request_args
	 * @return array
	 *
	 * @since 1.74.3
	 */
	public static function apply_timeout_cap( $request_args ) {

		if (null === self::$timeout_cap || !empty($request_args['blocking'])) {
			return $request_args;
		}

		if (!isset($request_args['timeout']) || $request_args['timeout'] > self::$timeout_cap) {
			$request_args['timeout'] = self::$timeout_cap;
		}

		return $request_args;
	}

	public function __construct( $request_args_override = [] ) {

		// Set the default options and allow these to be overridden upon instantiation
		$this->request_args = array_merge([
			'body'        => '',
			'timeout'     => 5,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking'    => Helpers::should_all_s2s_requests_be_sent_blocking(),
			'headers'     => [],
			'cookies'     => [],
			'sslverify'   => self::should_verify_ssl(),
		], $request_args_override);

		$this->request_args = array_merge($this->request_args, $this->filter_options());
	}

	/**
	 * Whether outbound requests verify the remote TLS certificate.
	 *
	 * Decided from the server environment only. It used to follow
	 * Geolocation::is_localhost(), which reads the visitor's IP from
	 * client-settable headers such as CF-Connecting-IP, so any storefront
	 * request could switch verification off for the S2S calls that carry
	 * access tokens and hashed customer data. Only a site that declares
	 * itself a local install (WP_ENVIRONMENT_TYPE 'local') skips the
	 * check, for self-signed development certificates. See DD-058.
	 *
	 * @return bool
	 * @since 1.70.1
	 */
	public static function should_verify_ssl() {

		if (function_exists('wp_get_environment_type') && 'local' === wp_get_environment_type()) {
			return false;
		}

		return true;
	}

	/**
	 * Add and/or override the request args (partially or completely)
	 *
	 * @param array $request_args
	 */
	public function set_request_args( $request_args ) {
		$this->request_args = array_merge($this->request_args, $request_args);
	}

	/**
	 * Filter the options
	 *
	 * @return array
	 */
	private function filter_options() {
		$this->request_args = apply_filters_deprecated('wooptpm_http_post_request_args', [ $this->request_args ], '1.13.0', 'pmw_http_post_request_args');
		$this->request_args = apply_filters_deprecated('wpm_http_post_request_args', [ $this->request_args ], '1.31.2', 'pmw_http_post_request_args');

		/**
		 * Filters Http post request args.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_http_post_request_args', $this->request_args);
	}

	/**
	 * Send a POST request.
	 *
	 * @param string $url
	 * @param mixed  $payload               Encoded as JSON when set.
	 * @param array  $request_args_override
	 * @return array|\WP_Error The wp_safe_remote_post() response (returned @since 1.69.3).
	 */
	public function post( $url, $payload = null, $request_args_override = [] ) {

		if ($payload) {

			if (!isset($this->request_args['headers']['Content-Type'])) {
				$this->request_args['headers']['Content-Type'] = 'application/json';
			}

			$this->request_args['body'] = wp_json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		}

		$this->request_args = array_merge($this->request_args, $request_args_override);

		$response = wp_safe_remote_post($url, self::apply_timeout_cap($this->request_args));

		if (Options::is_http_request_logging_enabled()) {
			$this->log_request($url, $response, $payload, $request_args_override);
		}

		return $response;
	}

	public function get( $url ) {

		$response = wp_safe_remote_get($url, $this->request_args);

		if (Options::is_http_request_logging_enabled()) {
			$this->log_request($url, $response);
		}
	}

	private function log_request( $url, $response, $payload = null, $request_args_override = [] ) {

		// Several APIs carry their credential in the query string (Meta and
		// Snapchat as `access_token`, GA4 as `api_secret`), so the URL is masked
		// against an allow list before it reaches the log.
		Logger::debug('request url: ' . Logger::redact_url($url));

		if ($payload) {
			Logger::debug('payload: ' . print_r($payload, true));
			Logger::debug('json payload: ' . wp_json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
		}

		if ($request_args_override) {
			Logger::debug('request args override: ' . print_r($request_args_override, true));
		}

		$response_code = wp_remote_retrieve_response_code($response);

		if (200 <= $response_code && 300 > $response_code) {
			Logger::debug('request successful with response code: ' . $response_code);
		}

		$response_body = wp_remote_retrieve_body($response);

		if ($response_body) {
			Logger::debug('response body: ' . $response_body);
		}

		if (is_wp_error($response)) {
			Logger::error('response error message: ' . $response->get_error_message());
		}
	}
}
