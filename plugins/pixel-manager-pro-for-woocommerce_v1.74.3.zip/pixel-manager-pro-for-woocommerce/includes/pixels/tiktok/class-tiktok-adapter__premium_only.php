<?php

namespace SweetCode\Pixel_Manager\Pixels\TikTok;

use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Adapter;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Registry;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * TikTok Events API adapter for server-side event processing
 *
 * Handles filtering and sending events to TikTok Events API. The pixel's
 * descriptor lives in the free TikTok_Descriptor, so the registry knows the
 * browser pixel on every tier; this adapter only exists on Pro builds.
 *
 * @package SweetCode\Pixel_Manager\Pixels\Adapters\TikTok
 * @since 1.51.0
 */
class TikTok_Adapter extends Abstract_Pixel_Adapter {

	/**
	 * Constructor - auto-registers this adapter
	 */
	public function __construct() {
		Pixel_Registry::register( $this );
	}

	/**
	 * Get the pixel name
	 *
	 * @return string
	 */
	public function get_pixel_name() {
		return 'tiktok';
	}

	/**
	 * Check if TikTok EAPI is available
	 *
	 * @return bool
	 */
	public function is_available() {
		return \SweetCode\Pixel_Manager\Options::is_tiktok_eapi_active();
	}

	/**
	 * Send event data to TikTok Events API
	 *
	 * @param array $pixel_data Filtered event data ready to send
	 * @return void
	 */
	protected function send( $pixel_data ) {
		TikTok_EAPI::send_s2s_event( $pixel_data );
	}
}

// Auto-register the adapter
new TikTok_Adapter();
