<?php

namespace SweetCode\Pixel_Manager\Pixels;

use SweetCode\Pixel_Manager\Admin\Environment;
use SweetCode\Pixel_Manager\Click_Ids;
use SweetCode\Pixel_Manager\Admin\LTV;
use SweetCode\Pixel_Manager\Admin\Order_Columns;
use SweetCode\Pixel_Manager\Admin\Validations;
use SweetCode\Pixel_Manager\Data\GA4_Data_API;
use SweetCode\Pixel_Manager\Pixels\ABTasty\AB_Tasty;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Registry;
use SweetCode\Pixel_Manager\Platforms\Order_Data;
use SweetCode\Pixel_Manager\Platforms\Platform_Manager;
use SweetCode\Pixel_Manager\Pixels\Facebook\Facebook;
use SweetCode\Pixel_Manager\Pixels\Facebook\Facebook_CAPI;
use SweetCode\Pixel_Manager\Pixels\Google\Google_DMA;
use SweetCode\Pixel_Manager\Pixels\Google\Google_MP_GA4;
use SweetCode\Pixel_Manager\Pixels\Google\Google_Helpers;
use SweetCode\Pixel_Manager\Pixels\Google\GTG_Proxy;
use SweetCode\Pixel_Manager\Pixels\Google\GTG_Config;
use SweetCode\Pixel_Manager\Pixels\Optimizely\Optimizely;
use SweetCode\Pixel_Manager\Pixels\TikTok\TikTok_EAPI;
use SweetCode\Pixel_Manager\Pixels\Pinterest\Pinterest_APIC;
use SweetCode\Pixel_Manager\Pixels\Snapchat\Snapchat_CAPI;
use SweetCode\Pixel_Manager\Pixels\Reddit\Reddit_CAPI;
use SweetCode\Pixel_Manager\Pixels\OpenAI\OpenAI_CAPI;
use SweetCode\Pixel_Manager\Pixels\Nextdoor\Nextdoor_CAPI;
use SweetCode\Pixel_Manager\Pixels\Spotify\Spotify_CAPI;
use SweetCode\Pixel_Manager\Pixels\AppLovin\AppLovin_CAPI;
use SweetCode\Pixel_Manager\Pixels\Bing\Bing_CAPI;
use SweetCode\Pixel_Manager\Pixels\TripleWhale\Triple_Whale;
use SweetCode\Pixel_Manager\Pixels\Mixpanel\Mixpanel_API;
use SweetCode\Pixel_Manager\Pixels\Klaviyo\Klaviyo_API;
use SweetCode\Pixel_Manager\Pixels\Klaviyo\Klaviyo_Takeover;
use SweetCode\Pixel_Manager\Pixels\VWO\VWO;
use SweetCode\Pixel_Manager\Early_Response;
use SweetCode\Pixel_Manager\Failed_Order_Retractions;
use SweetCode\Pixel_Manager\Refund_Deletions;
use SweetCode\Pixel_Manager\First_Event_Confirmation;
use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\Server_Event_Processor;
use SweetCode\Pixel_Manager\Shop;
use SweetCode\Pixel_Manager\Split_Payments;
use SweetCode\Pixel_Manager\Tracking_Accuracy_DB;
use WP_Error;

defined('ABSPATH') || exit; // Exit if accessed directly

class Pixel_Manager {

	private $rest_namespace                    = 'pmw/v1';
	private $gads_conversion_adjustments_route = '/google-ads/conversion-adjustments.csv';

	/**
	 * Cart item keys whose data layer script has already been printed in this request.
	 *
	 * Keeps the mini cart from printing the same item twice when a theme fires both
	 * mini cart hooks. See woocommerce_after_cart_item_name().
	 *
	 * @var array<string, bool>
	 * @since 1.64.1
	 */
	private $printed_cart_item_keys = [];

	private static $instance;

	/**
	 * Seconds a tracking accuracy count waits for a concurrent count of the same order.
	 *
	 * @since 1.71.1
	 */
	const TRACKING_ACCURACY_LOCK_TIMEOUT = 10;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Initializes the class and sets up options, states, additional classes, and pixel managers. Also registers actions and filters.
	 */
	private function __construct() {

		/**
		 * Initialize Google Tag Gateway Proxy
		 *
		 * This enables proxying Google Tag requests through WordPress
		 * to Google's First-Party Servers (FPS).
		 * Only active when a measurement path is configured.
		 *
		 * @since 1.53.0
		 */
		if (Options::get_google_tag_gateway_measurement_path()) {
			GTG_Proxy::init();
		}

		/**
		 * Inject PMW snippets in head
		 */

		// Prepare Litespeed ESI injection
		if (Environment::is_litespeed_esi_active()) {
			add_action(
					'litespeed_esi_load-pmw_data_layer',
					[ $this, 'inject_data_layer_through_litespeed_esi' ]
			);
		}

		add_action('wp_head', function () {

			self::inject_pmw_opening();

			// Inject Meta domain verification ID
			if (
					wpm_fs()->can_use_premium_code__premium_only() &&
					Options::get_facebook_domain_verification_id()
			) {
				?>
				<meta name="facebook-domain-verification"
						content="<?php echo esc_attr(Options::get_facebook_domain_verification_id()); ?>"/>
				<?php
			}

			// Add products to data layer from page transient
			if (get_transient('pmw_products_for_datalayer_' . get_the_ID())) {
				$products = get_transient('pmw_products_for_datalayer_' . get_the_ID());
				$this->inject_products_from_transient_into_datalayer($products);
			}

			// If user is logged in then run the following code
			// https://docs.litespeedtech.com/lscache/lscwp/api/#esi
			if (
					is_user_logged_in()
					&& Environment::is_litespeed_esi_active()
			) {
				$this->inject_data_layer_litespeed_esi();
			} else {
				$this->inject_data_layer();
			}
		});

		/**
		 * Initialize all pixels
		 */

		/**
		 * Load pixel descriptor infrastructure
		 * 
		 * This enables the unified pixel registry system that supports both
		 * server-side adapters and browser-side descriptors.
		 */
		require_once __DIR__ . '/core/interface-pixel-descriptor.php';
		require_once __DIR__ . '/core/abstract-pixel-descriptor.php';
		require_once __DIR__ . '/core/class-pixel-registry.php';

		if (wpm_fs()->can_use_premium_code__premium_only()) {

			// Ensure the adapter infrastructure is loaded before initializing adapters
			// The autoloader can't properly resolve the Pixel_Adapter interface, so we load it manually
			require_once __DIR__ . '/core/interface-pixel-adapter.php';
			require_once __DIR__ . '/core/abstract-pixel-adapter.php';

			// Load all S2S adapter classes unconditionally so they can auto-register
			// Each adapter's is_available() method determines if it's actually usable
			// This allows Options::server_2_server_enabled() to dynamically detect all S2S integrations
			class_exists('SweetCode\Pixel_Manager\Pixels\Facebook\Facebook_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\TikTok\TikTok_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\Pinterest\Pinterest_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\Snapchat\Snapchat_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\Reddit\Reddit_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\OpenAI\OpenAI_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\Nextdoor\Nextdoor_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\Bing\Bing_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\Mixpanel\Mixpanel_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\Klaviyo\Klaviyo_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\Spotify\Spotify_Adapter');
			class_exists('SweetCode\Pixel_Manager\Pixels\AppLovin\AppLovin_Adapter');

			// Universal click ID snapshot on every order, independent of which
			// destinations are configured: a pixel activated later (or a
			// backfill) still finds the click ID of the original visit.
			Click_Ids::get_instance();

			// Initialize the actual S2S pixel implementations based on configuration
			if (Options::is_ga4_mp_active()) {
				Google_MP_GA4::get_instance();
			}

			// Google Ads conversion upload through the Data Manager API
			if (Options::is_google_ads_dm_active()) {
				Google_DMA::get_instance();
			}

			// Retract conversions of orders whose payment failed late
			// @since 1.69.3
			if (Failed_Order_Retractions::is_active()) {
				Failed_Order_Retractions::get_instance();
			}

			// Reconcile refunds that a gateway deletes after they were reported
			// @since 1.71.1
			if (Refund_Deletions::is_active()) {
				Refund_Deletions::get_instance();
			}

			if (Options::is_facebook_capi_active()) {
				Facebook_CAPI::get_instance();
			}

			if (Options::is_tiktok_eapi_active()) {
				TikTok_EAPI::get_instance();
			}

			if (Options::is_pinterest_apic_active()) {
				Pinterest_APIC::get_instance();
			}

			if (Options::is_snapchat_capi_active()) {
				Snapchat_CAPI::get_instance();
			}

			if (Options::is_reddit_capi_active()) {
				Reddit_CAPI::get_instance();
			}

			if (Options::is_openai_capi_active()) {
				OpenAI_CAPI::get_instance();
			}

			if (Options::is_nextdoor_capi_active()) {
				Nextdoor_CAPI::get_instance();
			}

			if (Options::is_spotify_capi_active()) {
				Spotify_CAPI::get_instance();
			}

			if (Options::is_applovin_capi_active()) {
				AppLovin_CAPI::get_instance();
			}

			if (Options::is_bing_capi_active()) {
				Bing_CAPI::get_instance();
			}


			if (Options::is_mixpanel_ingestion_api_active()) {
				Mixpanel_API::get_instance();
			}

			if (Options::is_klaviyo_purchase_dispatch_active()) {
				Klaviyo_API::get_instance();
			}

			// Take over the Klaviyo plugin's onsite tracking. Runs on every
			// request type, because the plugin's Added to Cart hook fires on the
			// AJAX and Store API add-to-cart requests as well.
			if (Options::is_klaviyo_takeover_active()) {
				Klaviyo_Takeover::get_instance();
			}
		}

		/**
		 * Load all pixel descriptors
		 * 
		 * Each descriptor auto-registers with the Pixel_Registry on instantiation.
		 * The autoloader handles file loading - we just trigger it via class_exists().
		 * 
		 * When adding a new pixel descriptor, add its class name to the array below.
		 */
		$descriptors = [
			// Google pixels
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Google\Google_Ads_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Google\GA4_Descriptor',
			
			// Marketing pixels
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Twitter_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\LinkedIn_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\AdRoll_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Outbrain_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Taboola_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\GroundTruth_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Rumble_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Criteo_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Klaviyo_Descriptor',

			// Browser pixels whose server-side counterpart is a Pro adapter.
			// The descriptor is free so the registry knows the pixel on every
			// tier; the adapter registers separately on Pro builds only.
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Bing_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\OpenAI_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Pinterest_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Reddit_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Snapchat_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\TikTok_Descriptor',

			// Statistics pixels
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Hotjar_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Crazyegg_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Clarity_Descriptor',
			
			// Attribution pixels
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Hyros_Descriptor',
			// Pro only: the file carries the __premium_only suffix, so on the free
			// build class_exists() finds nothing and the pixel stays unknown there.
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Triple_Whale_Descriptor',

			// Optimization pixels
			'SweetCode\Pixel_Manager\Pixels\Descriptors\VWO_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\Optimizely_Descriptor',
			'SweetCode\Pixel_Manager\Pixels\Descriptors\AB_Tasty_Descriptor',
		];

		foreach ( $descriptors as $descriptor_class ) {
			class_exists( $descriptor_class );
		}

		/**
		 * Allow third-party plugins to register custom pixel descriptors
		 */
		Pixel_Registry::init_third_party_pixels();

		add_action('wp_head', function () {
			$this->inject_pmw_closing();
		});

		/**
		 * Front-end script section
		 */
		if (Shop::track_user()) {
			add_action('wp_enqueue_scripts', [ $this, 'front_end_scripts' ]);

			// Report when WordPress drops the bundle for a missing dependency such as jquery.
			\SweetCode\Pixel_Manager\Script_Dependencies::init();
		}

		/**
		 * Enqueue CSS for Elementor Pro
		 *
		 * This fixes an issue where Elementor widgets would show the PMW scripts as visible outputs.
		 */
		if (Environment::is_elementor_pro_active()) {
			add_action('wp_enqueue_scripts', [ $this, 'front_end_styles_elementor_fix' ]);
		}

		add_action('wp_ajax_pmw_get_cart_items', [ $this, 'ajax_pmw_get_cart_items' ]);
		add_action('wp_ajax_nopriv_pmw_get_cart_items', [ $this, 'ajax_pmw_get_cart_items' ]);

		add_action('wp_ajax_pmw_get_product_ids', [ $this, 'ajax_pmw_get_product_ids' ]);
		add_action('wp_ajax_nopriv_pmw_get_product_ids', [ $this, 'ajax_pmw_get_product_ids' ]);

		add_action('wp_ajax_pmw_purchase_pixels_fired', [ $this, 'ajax_purchase_pixels_fired_handler' ]);
		add_action('wp_ajax_nopriv_pmw_purchase_pixels_fired', [ $this, 'ajax_purchase_pixels_fired_handler' ]);

		// Experimental filter ! Can be removed without further notification
		if ($this->experimental_defer_scripts_activation()) {
			add_filter('script_loader_tag', [ $this, 'experimental_defer_scripts' ], 10, 2);
		}

		/**
		 * Inject pixel snippets after <body> tag
		 */
		if (did_action('wp_body_open')) {
			add_action('wp_body_open', function () {
				self::inject_body_pixels();
			});
		}

		/**
		 * Inject pixel snippets into wp_footer
		 */
		add_action('wp_footer', [ $this, 'pmw_wp_footer' ]);

		/**
		 * Process short codes
		 */

		Shortcodes::init();

		if (Environment::is_woocommerce_active()) {

			add_action('woocommerce_after_shop_loop_item', [ $this, 'action_woocommerce_after_shop_loop_item' ], 10, 1);
			add_filter('woocommerce_blocks_product_grid_item_html', [ $this, 'wc_add_data_to_gutenberg_block' ], 10, 3);
			add_filter('render_block', [ $this, 'collect_product_collection_products' ], 10, 2);
			add_action('wp_head', [ $this, 'woocommerce_inject_product_data_on_product_page' ]);
			// The cart item scripts feed the front-end bundle, so they follow the same
			// user gate the bundle does above. Excluded user roles used to receive the
			// scripts inside every cart fragment with no Pixel Manager JavaScript on the
			// page to read them. @since 1.64.1
			if (Shop::track_user()) {
				// do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key );
				add_action('woocommerce_after_cart_item_name', [ $this, 'woocommerce_after_cart_item_name' ], 10, 2);
				add_action('woocommerce_after_mini_cart_item_name', [ $this, 'woocommerce_after_cart_item_name' ], 10, 2);
				add_action('woocommerce_mini_cart_contents', [ $this, 'woocommerce_mini_cart_contents' ]);
			}

			add_action('woocommerce_new_order', [ $this, 'pmw_woocommerce_new_order' ], 10, 2);

			// Bucket orders_total against the *final* payment gateway, not the gateway at order creation.
			// Some gateways (Affirm, wallets) overwrite payment_method between creation and payment, which
			// would otherwise inflate the destination gateway's percentage above 100% and deflate the source
			// gateway's percentage. The handler below is idempotent via order meta `_wpm_orders_total_counted`.
			// @since 1.58.10
			add_action('woocommerce_payment_complete', [ __CLASS__, 'pmw_count_order_total_on_payment_finalized' ]);
			add_action('woocommerce_order_status_processing', [ __CLASS__, 'pmw_count_order_total_on_payment_finalized' ]);
			add_action('woocommerce_order_status_completed', [ __CLASS__, 'pmw_count_order_total_on_payment_finalized' ]);
			add_action('woocommerce_order_status_on-hold', [ __CLASS__, 'pmw_count_order_total_on_payment_finalized' ]);

			if (wpm_fs()->can_use_premium_code__premium_only()) {
				add_action('woocommerce_created_customer', [ $this, 'set_account_created_flag__premium_only' ]);
			}

			add_action('woocommerce_order_status_processing', [ $this, 'maybe_increase_conversion_count_for_ratings_on_status' ], 10, 1);
			add_action('woocommerce_order_status_completed', [ $this, 'maybe_increase_conversion_count_for_ratings_on_status' ], 10, 1);
		}

		/**
		 * Run background processes
		 */

		add_action('template_redirect', [ $this, 'run_background_processes' ]);

		// A page the plugin treats as the order confirmation carries the
		// customer's order and billing data in its data layer. WooCommerce's own
		// endpoint is never cached, but a custom thank-you page, or any URL that
		// carries an order key, is only as safe as the page cache in front of it.
		// @since 1.69.1
		add_action('template_redirect', function () {
			if (Shop::pmw_is_order_received_page()) {
				nocache_headers();
			}
		}, 1);

		/**
		 * Register REST API endpoints
		 */

		if (wpm_fs()->can_use_premium_code__premium_only()) {
			add_filter('rest_pre_serve_request', [ $this, 'prepare_custom_rest_handlers' ], 10, 4);
		}

		add_action('rest_api_init', [ $this, 'register_rest_routes' ]);

		// Keep WordPress core's Application Passwords out of the Basic Auth
		// on the Google Ads conversion adjustments feed. See
		// self::bypass_core_basic_auth_for_gads_csv().
		if (wpm_fs()->can_use_premium_code__premium_only()) {
			add_filter('rest_authentication_errors', [ $this, 'bypass_core_basic_auth_for_gads_csv' ], 5);
		}

		/**
		 * Register wp-ajax fallback for REST API endpoints
		 */

		if (wpm_fs()->can_use_premium_code__premium_only()) {

			// Gate the S2S AJAX fallback the same way as the REST /sse/ route:
			// when SSP handles every browser event (active + no WC fallback)
			// the endpoint is dead code, so don't expose it. @since 1.58.10
			$ssp_handles_all_browser_events = Options::is_ssp_active()
					&& 'fallback_to_wc' !== Options::get_ssp_proxy_failure_behavior();

			if (!$ssp_handles_all_browser_events) {
				add_action('wp_ajax_pmw_server_to_server_event', [ $this, 'capture_ajax_server_to_server_event__premium_only' ]);
				add_action('wp_ajax_nopriv_pmw_server_to_server_event', [ $this, 'capture_ajax_server_to_server_event__premium_only' ]);
			}

			add_action('wp_ajax_pmw_process_transient_session_identifiers', [ $this, 'pmw_process_transient_session_identifiers__premium_only' ]);
			add_action('wp_ajax_nopriv_pmw_process_transient_session_identifiers', [ $this, 'pmw_process_transient_session_identifiers__premium_only' ]);
		}

		if (wpm_fs()->can_use_premium_code__premium_only()) {

			/**
			 * Automatic Conversion Recovery
			 */

			// Classic checkout (WC_Checkout)
			add_action('woocommerce_checkout_order_created', [ $this, 'acr_set_cookie__premium_only' ]);

			// Blocks / Store API checkout (used by express checkout: Apple Pay, Google Pay, Stripe Link, etc.)
			//
			// The Store API deliberately does not fire woocommerce_checkout_order_created, it runs the
			// equivalent steps itself, so without this hook the recovery cookie was never written on
			// block checkout and ACR could not recover a single order on those shops.
			//
			// @since 1.64.1
			add_action('woocommerce_store_api_checkout_order_processed', [ $this, 'acr_set_cookie__premium_only' ]);

			add_action('wp_ajax_get_acr_order_data_ajax', [ $this, 'get_acr_order_data_ajax__premium_only' ]);
			add_action('wp_ajax_nopriv_get_acr_order_data_ajax', [ $this, 'get_acr_order_data_ajax__premium_only' ]);
		}

		// When updating a page, delete any transient data set by the Pixel Manager
		add_action('save_post', [ $this, 'delete_pmw_products_transient' ], 10, 3);
	}

	private function experimental_defer_scripts_activation() {

		$defer_scripts = apply_filters_deprecated('wpm_experimental_defer_scripts', [ false ], '1.31.2', 'pmw_experimental_defer_scripts');

		/**
		 * Filters Experimental defer scripts.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_experimental_defer_scripts', $defer_scripts);
	}

	public function delete_pmw_products_transient( $post_id, $post, $update ) {

		if ($update) {
			delete_transient('pmw_products_for_datalayer_' . $post_id);
		}
	}

	public function inject_products_from_transient_into_datalayer( $products ) {

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON for an inline script, escaped by Helpers::json_encode_for_script()
		?>
		<script<?php echo wp_kses(Helpers::get_opening_script_string(), Helpers::get_script_string_allowed_html()); ?>>
			(window.pmwDataLayer = window.pmwDataLayer || {}).products = window.pmwDataLayer.products || {};
			window.pmwDataLayer.products                               = Object.assign(window.pmwDataLayer.products, <?php echo Helpers::json_encode_for_script((object) $products); ?>);
		</script>
		<?php
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function acr_set_cookie__premium_only( $order ) {

		// Runs on both the classic and the Store API checkout, so don't assume either
		// what the hook hands over or that the cookie can still be written.
		// @since 1.64.1
		if (!$order instanceof \WC_Order || headers_sent()) {
			return;
		}

		$data = [
				'order_id'  => $order->get_id(),
				'order_key' => $order->get_order_key(),
		];

		$cookie_options = [
				'expires'  => time() + ( 90 * 24 * 60 * 60 ), // 90 days
				'path'     => '/',
				'secure'   => true,
				'samesite' => 'Strict',
		];

		// Named _pmw_automatic_conversion_recovery before 1.69.3; the browser
		// still reads and removes that name.
		setcookie('pmw_automatic_conversion_recovery', wp_json_encode($data), $cookie_options);
	}

	public function get_google_ads_conversion_adjustments_endpoint() {
		/**
		 * The regular /wp-json/ endpoint doesn't work if pretty permalinks are disabled.
		 * https://developer.wordpress.org/rest-api/key-concepts/#routes-endpoints
		 */
		return '/?rest_route=/' . $this->rest_namespace . $this->gads_conversion_adjustments_route;
	}

	/**
	 * Prepares custom REST API handlers for specific routes.
	 *
	 * This function is used to short-circuit the default REST API behavior for specific routes.
	 * In this case, it is used to output a CSV file for the Google Ads conversion adjustments.
	 *
	 * Input: https://wordpress.stackexchange.com/a/377954/68337
	 *
	 * @param bool|array       $served  The served result, used to short-circuit the default REST API behavior.
	 * @param WP_REST_Response $result  The original result to be served by the REST endpoint.
	 * @param WP_REST_Request  $request The current request instance containing request data.
	 * @param WP_REST_Server   $server  The REST server instance for serving responses and managing headers.
	 * @return bool|array  Returns the original $served result if the route doesn't match. Otherwise, processes the request and exits.
	 */
	public function prepare_custom_rest_handlers( $served, $result, $request, $server ) {

		// If $request->get_route() is not /pmw/v1/google-ads/conversion-adjustments then return $served
		if (strpos($request->get_route(), $this->rest_namespace . $this->gads_conversion_adjustments_route) === false) {
			return $served;
		}

		// If $result->get_data() is an array, return $served
		// This is to prevent buggy behavior created by some third-party plugins
		// https://secure.helpscout.net/conversation/2827410362/4097/
		if (is_array($result->get_data())) {
			return $served;
		}

		// For production
		$server->send_header('Content-Type', 'text/csv');

		// For testing
//      $server->send_header('Content-Type', 'text/html');
//      $server->send_header('Content-Type', 'text/xml');
//      $server->send_header('Content-Type', 'application/xml');

		// Echo the XML that's returned by smg_feed().
		echo esc_html($result->get_data());

		exit;
	}

	/**
	 * Permission callback for REST API routes that require the user to have the capability to edit options.
	 *
	 * This function checks if the current user has the 'edit_options' capability, which is typically required
	 * for managing plugin settings. It is used as a permission callback for protected REST API routes.
	 * 
	 * Extracted the code because the QIT semgrep rule was triggered
	 * 
	 * @return bool Returns true if the current user can edit options, false otherwise.
	 */
	public function can_current_user_edit_options() {
		return Environment::can_current_user_edit_options();
	}

	public function register_rest_routes() {

		register_rest_route($this->rest_namespace, '/settings/', [
				'methods'             => 'POST',
				'callback'            => [ $this, 'pmw_save_imported_settings' ],
				'permission_callback' => [ $this, 'can_current_user_edit_options' ],
		]);

		/**
		 * No nonce verification required as we only request public data
		 * from the server.
		 */
		// nosemgrep: audit.php.wp.security.rest-route.permission-callback.return-true
		register_rest_route($this->rest_namespace, '/products/', [
				'methods'             => 'POST',
				'callback'            => function ( $request ) {

					$request_decoded = $request->get_json_params();

					$this->get_products_for_datalayer($request_decoded);
				},
				'permission_callback' => function () {
					return true;
				},
		]);

		// nosemgrep: audit.php.wp.security.rest-route.permission-callback.return-true
		register_rest_route($this->rest_namespace, '/pixels-fired/', [
				'methods'             => 'POST',
				'callback'            => function ( $request ) {

					$data = $request->get_json_params();

					// Nonce verification is intentionally skipped: some merchants cache parts of the purchase
					// confirmation page (which makes nonces fail), and the order_key check downstream is
					// sufficient since the key is only known to the customer who placed the order.
					$data = Helpers::generic_sanitization($data);

					self::process_conversion_pixel_status($data['order_id'], $data['order_key'], $data['source']);
				},
				'permission_callback' => function () {
					return true;
				},
		]);

		/**
		 * One-shot first-run beacon: the storefront reports which pixels
		 * loaded, once, while the onboarding checklist is waiting for its
		 * "pixels are live" confirmation. Only registered while that state
		 * can still occur (fresh install, nothing confirmed yet), and the
		 * handler re-checks before writing, so the write-once semantic
		 * holds even across races and cached pages. No nonce for the same
		 * cache-tolerance reason as /pixels-fired/; the payload is reduced
		 * to a validated slug list before it touches the option.
		 */
		if (First_Event_Confirmation::is_beacon_needed()) {
			// nosemgrep: audit.php.wp.security.rest-route.permission-callback.return-true
			register_rest_route($this->rest_namespace, '/onboarding/pixels-live/', [
					'methods'             => 'POST',
					'callback'            => function ( $request ) {

						$data = Helpers::generic_sanitization($request->get_json_params());

						if (First_Event_Confirmation::record_pixels_live(is_array($data) ? $data : [])) {
							wp_send_json_success();
						}

						wp_send_json_error('Confirmation not accepted');
					},
					'permission_callback' => function () {
						return true;
					},
			]);
		}

		if (wpm_fs()->can_use_premium_code__premium_only()) {

			/**
			 * Public route for sever-to-server events.
			 * No nonce verification required, as this route is only passing through data
			 * to third party server-to-server endpoints.
			 *
			 * Hardening (since 1.58.10):
			 *  - Not registered when SSP is active and the merchant has set the
			 *    proxy failure behavior to 'drop_events' (no WC fallback path).
			 *  - Per-IP rate limit (protects outbound API quota).
			 *  - Reject purchase events (always sent server-side from the actual order).
			 *  - Reconcile client_ip_address (kept only when it adds an IP family the
			 *    server cannot see, e.g. dual-stack IPv6 behind an IPv4 proxy) and
			 *    replace client_user_agent with the request's own user agent, which
			 *    is authoritative and cannot be forged through the request body.
			 */
			$ssp_handles_all_browser_events = Options::is_ssp_active()
					&& 'fallback_to_wc' !== Options::get_ssp_proxy_failure_behavior();

			if (!$ssp_handles_all_browser_events) {
				// nosemgrep: audit.php.wp.security.rest-route.permission-callback.return-true
				register_rest_route($this->rest_namespace, '/sse/', [
						'methods'             => 'POST',
						'callback'            => function ( $request ) {

							if (self::is_rate_limited('sse')) {
								wp_send_json_error('Too many requests', 429);
							}

							$data = $request->get_json_params();
							$data = Helpers::generic_sanitization($data);

							if (!is_array($data)) {
								wp_send_json_error('No valid data array provided.');
							}

							if (self::is_purchase_like_sse_payload($data)) {
								wp_send_json_error('Event type not allowed on this endpoint.', 400);
							}

							$data = self::reconcile_client_identifiers_in_sse_payload($data);

							$this->answer_then_relay_server_to_server_event__premium_only($data);
						},
						'permission_callback' => function () {
							return true;
						},
				]);
			}

			/**
			 * Public route to request order details of a past order that a specific user has made
			 * and who is identified by a cookie.
			 * We don't use nonce verification as we only request data from the server specific to that user.
			 */
			// nosemgrep: audit.php.wp.security.rest-route.permission-callback.return-true
			register_rest_route($this->rest_namespace, '/acr/order/', [
					'methods'             => 'POST',
					'callback'            => function ( $request ) {

						$data = $request->get_json_params();

						if (!is_array($data)) {
							wp_send_json_error('No valid data array provided.');
						}

						$this->get_order_details_for_acr($data);
					},
					'permission_callback' => function () {
						return true;
					},
			]);

			// Public route for Google Ads conversion adjustment CSV.
			//
			// Optionally protected with HTTP Basic Auth via the
			// `pmw_google_ads_conversion_adjustments_credentials` filter — see
			// self::is_gads_csv_auth_ok(). When the filter is not registered,
			// the route stays publicly readable for backwards compatibility.
			//
			// Always rate-limited to dampen scraping of refund metadata.
			// @since 1.58.10
			// nosemgrep: audit.php.wp.security.rest-route.permission-callback.return-true
			register_rest_route($this->rest_namespace, $this->gads_conversion_adjustments_route, [
					'methods'             => 'GET',
					'callback'            => function ( $request ) {
						if (!Options::is_google_ads_conversion_adjustments_conversion_name_set()) {
							return 'The Google Ads Conversion Adjustments Conversion Name has not been set';
						}

						return $this->get_google_ads_conversion_adjustments__premium_only();
					},
					// nosemgrep -- permission_callback only ever returns true, false, or WP_Error; see explicit branches below. Helper self::is_gads_csv_auth_ok() returns true|WP_Error.
					'permission_callback' => function () {

						if (self::is_rate_limited('gads_csv', 30)) {
							// nosemgrep
							return new WP_Error(
									'rest_too_many_requests',
									esc_html__('Too many requests', 'woocommerce-google-adwords-conversion-tracking-tag'),
									[ 'status' => 429 ]
							);
						}

						$auth = self::is_gads_csv_auth_ok();

						if (true === $auth) {
							return true;
						}

						if ($auth instanceof WP_Error) {
							// nosemgrep
							return $auth;
						}

						return false;
					},
			]);

			register_rest_route($this->rest_namespace, '/ga4/data-api/credentials/', [
					'methods'             => 'POST',
					'callback'            => [ $this, 'pwm_save_ga4_data_api_credentials__premium_only' ],
					'permission_callback' => [ __CLASS__, 'protected_rest_route_permission_callback' ],
			]);

			register_rest_route($this->rest_namespace, '/ga4/data-api/get-order-attribution-data/', [
					'methods'             => 'POST',
					'callback'            => [ $this, 'pwm_save_ga4_data_api_get_order_attribution_data__premium_only' ],
					'permission_callback' => [ __CLASS__, 'protected_rest_route_permission_callback' ],
			]);

			// Google Ads Data Manager API conversion upload feedback
			register_rest_route($this->rest_namespace, '/google/data-manager/test-upload/', [
					'methods'             => 'POST',
					'callback'            => [ $this, 'pmw_google_dm_test_upload__premium_only' ],
					'permission_callback' => [ __CLASS__, 'protected_rest_route_permission_callback' ],
			]);

			register_rest_route($this->rest_namespace, '/google/data-manager/upload-status/', [
					'methods'             => 'GET',
					'callback'            => [ $this, 'pmw_google_dm_upload_status__premium_only' ],
					'permission_callback' => [ __CLASS__, 'protected_rest_route_permission_callback' ],
			]);

			register_rest_route($this->rest_namespace, '/google/data-manager/diagnostics/', [
					'methods'             => 'GET',
					'callback'            => [ $this, 'pmw_google_dm_diagnostics__premium_only' ],
					'permission_callback' => [ __CLASS__, 'protected_rest_route_permission_callback' ],
			]);

			register_rest_route($this->rest_namespace, '/google/data-manager/backfill/', [
					'methods'             => 'POST',
					'callback'            => [ $this, 'pmw_google_dm_backfill__premium_only' ],
					'permission_callback' => [ __CLASS__, 'protected_rest_route_permission_callback' ],
			]);

		}
	}

	/**
	 * Callback function for the protected REST route permission check.
	 *
	 * This function checks if the current user has permission to access the protected route.
	 * If the user does not have permission, it returns a WP_Error with a 401 status code.
	 * If the user has permission, it returns true.
	 *
	 * @return /WP_Error|bool Returns a WP_Error if the user does not have permission, or true if they do.
	 *
	 * @since  1.49.0
	 */
	public static function protected_rest_route_permission_callback() {

		if (Environment::can_current_user_edit_options()) {
			return true;
		}

		return new WP_Error('rest_forbidden', esc_html__('You can not view private data.', 'woocommerce-google-adwords-conversion-tracking-tag'), [ 'status' => 401 ]);
	}

	private function get_products_for_datalayer( $data ) {

		// Per-IP rate limit. Prevents an unauthenticated client from flooding
		// the server with bogus page_id values that would each create a
		// long-lived transient row. @since 1.58.10
		if (self::is_rate_limited('products')) {
			wp_send_json_error('Too many requests', 429);
		}

		$product_ids = Helpers::generic_sanitization($data['product_ids']);

		if (!$product_ids) {
			wp_send_json_error('No product IDs provided.');
		}

		if (!is_array($product_ids)) {
			wp_send_json_error('Product IDs must be an array.');
		}

		// if $data['page_id'] is not set, return error
		if (!isset($data['page_id'])) {
			wp_send_json_error('No page ID provided');
		}

		// if $data['page_type'] is not set, return error
		if (!isset($data['page_type'])) {
			wp_send_json_error('No page type provided');
		}

		// Validate page_id resolves to a real WP post. The legitimate value
		// always originates from get_the_ID() server-side, so anything that
		// doesn't resolve is either stale or attacker-supplied. Without this
		// an attacker could create an unbounded number of long-lived
		// transients by POSTing random IDs. @since 1.58.10
		$page_id = (int) $data['page_id'];

		if ($page_id <= 0 || !get_post($page_id)) {
			wp_send_json_error('Invalid page ID');
		}

		// Prevent server overload if too many products are requested
		$product_ids = count($product_ids) > 50 ? array_slice($product_ids, 0, 50) : $product_ids;

		$products = $this->get_products_for_datalayer_by_product_ids($product_ids);

		// Check if a data layer products transient for this page exists
		// If it does, add the products from the transient to $products
		if (get_transient('pmw_products_for_datalayer_' . $page_id)) {
			$products_in_transient = get_transient('pmw_products_for_datalayer_' . $page_id);

			// Filter out products that no longer exist or are not published
			$products_in_transient = array_filter($products_in_transient, function ( $product_data ) {
				// Skip if no product ID
				if (!isset($product_data['id'])) {
					return false;
				}

				$product = wc_get_product($product_data['id']);

				// Remove if product doesn't exist or is not published
				if (Product::is_not_wc_product($product) || 'publish' !== $product->get_status()) {
					return false;
				}

				return true;
			});

			// Merge the associative arrays with nested arrays $products and $products_in_transient preserving the keys
			$products = array_replace_recursive($products, $products_in_transient);
		}

		// The entry is printed into every visitor's data layer on that page, and
		// page_id can be any post on the site. Without a bound, repeated requests
		// with new product IDs grew one page's entry, and its HTML, without limit.
		// The products just requested come first in the merge, so they survive.
		// @since 1.69.1
		if (count($products) > 50) {
			$products = array_slice($products, 0, 50, true);
		}

		// Set transient with products for $page_id.
		// TTL is one week: long enough to keep the cache useful for returning
		// visitors hitting the same page across days, short enough to bound
		// storage growth and pick up product updates that don't otherwise
		// invalidate the entry. @since 1.58.10 (was MONTH_IN_SECONDS)
		if (
				'cart' !== $data['page_type']
				&& 'checkout' !== $data['page_type']
				&& 'order_received_page' !== $data['page_type']
		) {
			set_transient('pmw_products_for_datalayer_' . $page_id, $products, WEEK_IN_SECONDS);
		}

		wp_send_json_success($products);
	}

	/**
	 * Retrieves order attribution data from the GA4 Data API and returns it in an HTML table format.
	 *
	 * @param WP_REST_Request $request The request object containing necessary data such as order ID.
	 * @return void Responds with JSON success or error messages.
	 */
	public function pwm_save_ga4_data_api_get_order_attribution_data__premium_only( $request ) {

		// Verify nonce
		if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
			return Helpers::rest_envelope(false, 'Invalid nonce');
		}

		$data = $request->get_json_params();

		if (!isset($data['order_id'])) {
			return Helpers::rest_envelope(false, 'No order ID provided');
		}

		$order_id = Helpers::generic_sanitization($data['order_id']);
		$order    = wc_get_order($order_id);

		if (is_bool($order)) {
			return Helpers::rest_envelope(false, 'Order not found');
		}

		$data = GA4_Data_API::get_instance()->get_order_attribution_data($order);

		if (is_wp_error($data)) {
			return Helpers::rest_envelope(false, $data->get_error_message() . ' ' . esc_html__('Try going through the setup process again.', 'woocommerce-google-adwords-conversion-tracking-tag'));
		}

		if (isset($data['error'])) {
			return Helpers::rest_envelope(false, $data['error']['message']);
		}

		if (!isset($data['rows'])) {

			$error_message = 'No rows returned from GA4 Data API.';

			// If order creation date is not older than 1 day, append the message "GA4 can take up to 24 hours to process order attribution."
			if (strtotime($order->get_date_created()) > strtotime('-48 hours')) {
				$error_message .= '</br>GA4 can take up to 24 hours to process order attribution.';
			}

			return Helpers::rest_envelope(false, $error_message);
		}

		$total_value = 0;

		foreach ($data['rows'] as $row) {
			$total_value += $row['metricValues'][0]['value'];
		}

		// create html table using output buffer
		ob_start();
		?>
		<table>
			<tr>
				<th style="text-align: left">Channel</th>
				<th class="pmw-ga4-attr-values">Attr. Value</th>
				<th class="pmw-ga4-attr-values">Attr. %</th>
			</tr>
			<?php foreach ($data['rows'] as $row) : ?>
				<tr>
					<td><?php echo esc_html($row['dimensionValues'][0]['value']); ?></td>
					<td class="pmw-ga4-attr-values"><?php echo esc_html(Helpers::format_decimal(floatval($row['metricValues'][0]['value']), 2)); ?></td>
					<td class="pmw-ga4-attr-values"><?php echo esc_html(round($row['metricValues'][0]['value'] / $total_value * 100, 2)); ?>
						%
					</td>
				</tr>
			<?php endforeach; ?>
			<tr>
				<td>
					<b>Total</b>
				</td>
				<td class="pmw-ga4-attr-values">
					<b><?php echo esc_html(Helpers::format_decimal($total_value, 2)); ?></b>
				</td>
				<td class="pmw-ga4-attr-values">
					<b>100%</b>
				</td>
			</tr>
		</table>

		<?php
		$html = ob_get_clean();

		return Helpers::rest_envelope(true, $html);
	}

	/**
	 * Generates a CSV containing Google Ads conversion adjustments based on cancelled orders, failed orders and refunds
	 * within a specific time range. The adjustments include order ID, conversion name, adjustment time,
	 * adjustment type, adjusted value, and currency.
	 *
	 * Source: https://support.google.com/google-ads/answer/7686280
	 * Source: Timezone http://goo.gl/T1C5Ov
	 * CSV template https://www.gstatic.com/conversiontracking/conversion-adjustment-template-oid.csv
	 *
	 * @return string A CSV string representing the Google Ads conversion adjustments data.
	 */
	private function get_google_ads_conversion_adjustments__premium_only() {

		$conversion_name = Options::get_google_ads_conversion_adjustments_conversion_name();

		$title_row = [
				'Order ID',
				'Conversion Name',
				'Adjustment Time',
				'Adjustment Type',
				'Adjusted Value',
				'Adjusted Value Currency',
		];

		$csv = implode(',', $title_row) . PHP_EOL;

		// For production
		$date_before = wp_date('Y-m-d H:i:s', strtotime('-2 days'));
		// For testing
//      $date_before = wp_date('Y-m-d H:i:s');

		// get php date format eg. 2012-08-14T13:00:00-0100
		$date_format = 'Y-m-d\TH:i:sP';

		$date_after = wp_date('Y-m-d H:i:s', strtotime('-3 days'));

		/**
		 * Get all cancelled orders that were cancelled within a time range
		 * and retract them
		 */
		$orders = wc_get_orders([
				'limit'         => -1,
				'status'        => 'cancelled',
				'date_modified' => $date_after . '...' . $date_before,
				//                                  'date_modified' => '>' . $date_after,
		]);

		$csv .= $this->get_conversion_adjustments_retraction_rows__premium_only($orders, 'cancelled', $conversion_name, $date_format);

		/**
		 * Get all orders whose payment failed within the time range and
		 * retract those whose conversion was already sent. Some gateways
		 * leave the order pending or on hold at checkout, so the conversion
		 * fires, and only report the failure hours or days later.
		 *
		 * The feed's two-day lag doubles as the grace period for customers
		 * who pay the failed order again: only orders that are still failed
		 * are retracted.
		 *
		 * @since 1.69.3
		 */
		$orders = wc_get_orders([
				'limit'         => -1,
				'status'        => 'failed',
				'date_modified' => $date_after . '...' . $date_before,
		]);

		$csv .= $this->get_conversion_adjustments_retraction_rows__premium_only($orders, 'failed', $conversion_name, $date_format);

		/**
		 * Get all refunds from within a time range
		 */
		$refunds = wc_get_orders([
				'type'        => 'shop_order_refund',
				'status'      => 'completed',
				'date_after'  => $date_after,
				//                                   'date_after' => gmdate('Y-m-d H:i:s', strtotime('-3 days')),
				'date_before' => $date_before,
		]);

		foreach ($refunds as $refund) {

			$parent_order = wc_get_order($refund->get_parent_id());

			if (!$parent_order) {
				continue;
			}

			/**
			 * This filter is documented in includes/class-s2s__premium_only.php
			 *
			 * @since 1.58.10
			 */
			if (apply_filters('pmw_skip_s2s_purchase_event', false, $parent_order, 'conversion_adjustments_feed')) {
				continue;
			}

			// This refund was already adjusted through the Data Manager
			// upload's API path against the same conversion action - a feed
			// row would only add duplicate-import noise in Google Ads.
			if (Google_DMA::was_refund_adjusted_via_api($parent_order, $refund->get_id())) {
				continue;
			}

			// Get the order ID
			$order_id = $parent_order->get_order_number();

			// Get the refund date
			$adjustment_time = $refund->get_date_created();
			$adjustment_time = $adjustment_time->format($date_format);

			// Get adjustment type

			// Get parent order status
			$parent_order_status = $parent_order->get_status();

			if ('refunded' === $parent_order_status || 'cancelled' === $parent_order_status) {
				$adjustment_type         = 'RETRACT';
				$adjusted_value          = null;
				$adjusted_value_currency = null;
			} else {
				$adjustment_type = 'RESTATE';

				// Get the total value of the parent order
				$adjusted_value          = $this->get_order_value_after_refunds($parent_order);
				$adjusted_value_currency = $refund->get_currency();
			}

			// Compile the row
			$row = [
					'order_id'        => $order_id,
					'conversion_name' => $conversion_name,
					'adjustment_time' => $adjustment_time,
					'adjustment_type' => $adjustment_type,
					'adjusted_value'  => $adjusted_value,
					'currency'        => $adjusted_value_currency,
			];

			/**
			 * This filter is documented above in this method.
			 *
			 * @since 1.60.1
			 */
			$row = apply_filters('pmw_conversion_adjustments_feed_row', $row, $parent_order, 'refund');

			if (empty($row)) {
				continue;
			}

			$csv .= $this->compile_conversion_adjustments_feed_row($row) . PHP_EOL;
		}

		return $csv;
	}

	/**
	 * Builds the RETRACT rows of the conversion adjustments feed for cancelled
	 * or failed orders.
	 *
	 * Cancelled orders are retracted unconditionally. Failed orders only when
	 * a conversion was actually sent for them: most failed orders are payments
	 * declined at checkout that never fired anything, and retracting those
	 * would only fill the Google Ads import report with errors.
	 *
	 * @param \WC_Order[] $orders          The orders to retract.
	 * @param string      $type            'cancelled' or 'failed'.
	 * @param string      $conversion_name The conversion name.
	 * @param string      $date_format     The adjustment time format.
	 * @return string The CSV lines, each with a trailing newline.
	 * @since 1.69.3
	 */
	private function get_conversion_adjustments_retraction_rows__premium_only( $orders, $type, $conversion_name, $date_format ) {

		$csv = '';

		foreach ($orders as $order) {

			if ('failed' === $type && !$this->was_google_ads_conversion_sent_for_order__premium_only($order)) {
				continue;
			}

			/**
			 * This filter is documented in includes/class-s2s__premium_only.php
			 *
			 * @since 1.58.10
			 */
			if (apply_filters('pmw_skip_s2s_purchase_event', false, Order_Data::unwrap($order), 'conversion_adjustments_feed')) {
				continue;
			}

			// Already retracted through the Data Manager upload's API
			// adjustment against the same conversion action - a feed row
			// would only add duplicate-import noise in Google Ads.
			if (Google_DMA::was_refund_adjusted_via_api($order)) {
				continue;
			}

			// Get the modified date
			$adjustment_time = $order->get_date_modified();
			$adjustment_time = $adjustment_time->format($date_format);

			// Compile the row
			$row = [
					'order_id'        => $order->get_order_number(),
					'conversion_name' => $conversion_name,
					'adjustment_time' => $adjustment_time,
					'adjustment_type' => 'RETRACT',
					'adjusted_value'  => null,
					'currency'        => null,
			];

			/**
			 * Filter a single Google Ads conversion adjustments feed row.
			 *
			 * Return an empty value (null, false or []) to drop the row from
			 * the feed, for example to exclude orders that did not originate
			 * from a Google Ads click (marketplace imports, etc.). Fields may
			 * also be modified; the plugin re-applies its own validation
			 * afterwards so the feed stays within Google's spec.
			 *
			 * @param array     $row   Associative row data with keys: order_id,
			 *                         conversion_name, adjustment_time,
			 *                         adjustment_type (RETRACT|RESTATE),
			 *                         adjusted_value, currency.
			 * @param \WC_Order $order The order being adjusted.
			 * @param string    $type  Adjustment source: 'cancelled', 'failed'
			 *                         (since 1.69.3) or 'refund'.
			 *
			 * @since 1.60.1
			 */
			$row = apply_filters('pmw_conversion_adjustments_feed_row', $row, Order_Data::unwrap($order), $type);

			if (empty($row)) {
				continue;
			}

			$csv .= $this->compile_conversion_adjustments_feed_row($row) . PHP_EOL;
		}

		return $csv;
	}

	/**
	 * Whether a Google Ads conversion was sent for this order: the browser
	 * confirmation pixel fired, or the Data Manager upload recorded it.
	 *
	 * @param \WC_Order $order The order.
	 * @return bool
	 * @since 1.69.3
	 */
	private function was_google_ads_conversion_sent_for_order__premium_only( $order ) {
		return Shop::has_conversion_pixel_already_fired($order) || $order->meta_exists(Google_DMA::get_purchase_hit_key());
	}

	/**
	 * Serialize a single conversion adjustments feed row into a CSV line.
	 *
	 * Runs after the `pmw_conversion_adjustments_feed_row` filter so PMW's own
	 * normalization (clamping negative values to 0, enforcing the column order
	 * Google expects) is always applied, even when a filter callback modified
	 * the row.
	 *
	 * @param array $row Associative row data.
	 * @return string The CSV line, without a trailing newline.
	 */
	private function compile_conversion_adjustments_feed_row( $row ) {

		// Clamp negative adjusted values to 0 (Google rejects negative values).
		if (isset($row['adjusted_value']) && $row['adjusted_value'] < 0) {
			$row['adjusted_value'] = 0;
		}

		// Always serialize in the exact column order Google expects.
		$ordered = [
				isset($row['order_id']) ? $row['order_id'] : '',
				isset($row['conversion_name']) ? $row['conversion_name'] : '',
				isset($row['adjustment_time']) ? $row['adjustment_time'] : '',
				isset($row['adjustment_type']) ? $row['adjustment_type'] : '',
				isset($row['adjusted_value']) ? $row['adjusted_value'] : '',
				isset($row['currency']) ? $row['currency'] : '',
		];

		return implode(',', $ordered);
	}

	/**
	 * Return the corrected conversion value of an order for a RESTATE adjustment.
	 *
	 * Google Ads expects the new total value of the conversion, not the refunded delta.
	 * Shop::get_order_value_total_marketing() already accounts for refunds in each of the three
	 * marketing value logic modes: the subtotal branch deducts the product share of the refunds,
	 * the order total branch deducts get_total_refunded(), and the profit margin branch works off
	 * the refunded quantity per item. So the refund must not be applied a second time here.
	 *
	 * @param $order
	 * @return float
	 */
	private function get_order_value_after_refunds( $order ) {
		return Helpers::format_decimal(Shop::get_order_value_total_marketing($order, true), 2);
	}

	private function get_order_details_for_acr( $data ) {

		// If order ID or order key is not provided, return error
		if (!isset($data['order_id']) || !isset($data['order_key'])) {
			wp_send_json_error('No order ID or order key provided');
		}

		$data = Helpers::generic_sanitization($data);

		$order_id  = $data['order_id'];
		$order_key = $data['order_key'];

		$order = wc_get_order($order_id);

		// if order is not found, return error
		if (!$order) {
			wp_send_json_error('Order not found');
		}

		// If order key doesn't match, return error
		if (!is_string($order_key) || !hash_equals((string) $order->get_order_key(), $order_key)) {
			wp_send_json_error('Order key does not match');
		}

		// Deposit plugins: recover the sale from the order that represents it, or not
		// at all (see Split_Payments). The key above was validated against the order
		// the recovery cookie was written for.
		$order = Split_Payments::resolve_order_for_purchase($order);

		if (!$order) {
			wp_send_json_error('Order is not eligible for ACR');
		}

		if (!$this->is_order_eligible_for_acr($order)) {
			wp_send_json_error('Order is not eligible for ACR');
		}

		// Return the order details for the pmwDataLayer with the provided ID
		wp_send_json_success($this->get_order_data($order));
	}

	private function is_order_eligible_for_acr( $order ) {

		/**
		 * If the order is not in a paid state, return false.
		 *
		 * It seems to be better to check for paid statuses instead of not-paid statuses,
		 * as there are shops that may add unpaid statuses to the status list. Those statuses
		 * then can trigger the ACR, which they shouldn't. Using wc_get_is_paid_statuses()
		 * will make sure that only paid statuses are checked, even additional paid statuses
		 * added through the filter in wc_get_is_paid_statuses().
		 *
		 * https://stackoverflow.com/a/59869889
		 */
		if (!in_array($order->get_status(), wc_get_is_paid_statuses())) {
			return false;
		}

		// If order has already fired the conversion pixel, return false
		if (Shop::has_conversion_pixel_already_fired($order)) {
			return false;
		}

		if (!Shop::can_order_confirmation_be_processed($order)) {
			return false;
		}

		return true;
	}

	/**
	 * Read the payload of the admin-ajax S2S fallback.
	 *
	 * The library posts the payload as one JSON string in data, so it keeps
	 * the same types as on the REST and SweetCode Cloud paths. Form encoding
	 * turned every number into a string ("12.5", "1700000000"), and strict
	 * APIs (OpenAI, Pinterest, Snapchat, Reddit) rejected those events. A
	 * library cached from before 1.69.3 still posts data as a form-encoded
	 * array, which is accepted as before.
	 *
	 * The JSON is decoded from the raw value and sanitized afterwards, the
	 * same way the REST /sse/ route does it. Sanitizing the encoded string
	 * would escape its quotes and break the decode.
	 *
	 * @return array|null The payload, or null when the request carries none.
	 *
	 * @since 1.69.3
	 */
	private static function get_ajax_server_to_server_payload__premium_only() {

		$_post_raw = Helpers::get_input_vars(INPUT_POST, true);
		$data      = isset($_post_raw['data']) ? $_post_raw['data'] : null;

		if (is_string($data)) {
			$data = json_decode($data, true);
		}

		if (!is_array($data)) {
			return null;
		}

		return Helpers::generic_sanitization($data);
	}

	public function capture_ajax_server_to_server_event__premium_only() {

		// This endpoint only reads. Keep it out of the session's write path,
		// so it can never revert a cart change a shopper makes while it runs.
		Shop::keep_woocommerce_session_read_only();

		if (self::is_rate_limited('sse')) {
			wp_send_json_error('Too many requests', 429);
		}

		$data = self::get_ajax_server_to_server_payload__premium_only();

		if (!is_array($data)) {
			wp_send_json_error('No valid data array provided.');
		}

		if (self::is_purchase_like_sse_payload($data)) {
			wp_send_json_error('Event type not allowed on this endpoint.', 400);
		}

		$data = self::reconcile_client_identifiers_in_sse_payload($data);

		$this->answer_then_relay_server_to_server_event__premium_only($data);
	}

	/**
	 * Process transient session identifiers and store them in the WooCommerce session.
	 *
	 * @return void
	 */
	public function pmw_process_transient_session_identifiers__premium_only() {

		// If WooCommerce is not active, return error
		if (!Environment::is_woocommerce_active()) {
			wp_send_json_error('WooCommerce not active');
		}

		if (!Shop::is_woocommerce_session_active()) {
			wp_send_json_error('WooCommerce session not active');
		}

		$_post = Helpers::get_input_vars(INPUT_POST);

		// If the session identifiers are not set, return error
		if (!isset($_post['data'])) {
			wp_send_json_error('No session identifiers provided');
		}

		// The browser reports whether it holds the consent cookie, so the
		// server can tell a host that removes PMW's cookies from a browser
		// that blocks cookies (DD-045). Not stored in the session.
		// @since 1.69.3
		if (is_array($_post['data']) && !empty($_post['data']['consent_cookie_set']) && filter_var($_post['data']['consent_cookie_set'], FILTER_VALIDATE_BOOLEAN)) {
			Click_Ids::record_consent_cookie_delivery();
		}

		$data = self::sanitize_new_transient_session_identifiers__premium_only($_post['data']);

		Logger::debug('Processing transient session identifiers: ' . wp_json_encode($data));

		$stored_session_identifiers = Shop::get_transient_identifiers_from_session();
		$merged_session_identifiers = array_merge($stored_session_identifiers, $data);

		/**
		 * Click IDs follow marketing consent (DD-043). In Explicit Consent Mode
		 * none is stored before marketing is granted, and in either mode a
		 * visitor who denied or withdrew it has every stored click ID removed:
		 * from these identifiers, from the click ID session copy and from the
		 * fallback cookie. The browser purges its own copy on the same decision.
		 *
		 * @since 1.69.3
		 */
		$consent = Click_Ids::get_consent_snapshot(
			isset($merged_session_identifiers['consent']) ? $merged_session_identifiers['consent'] : null
		);

		if (!Click_Ids::is_collection_allowed($consent)) {
			$merged_session_identifiers = array_diff_key(
				$merged_session_identifiers,
				array_flip(Click_Ids::get_all_click_id_keys())
			);

			Click_Ids::purge();
		}

		/**
		 * Write only when the identifiers actually changed.
		 *
		 * This runs once per cart and checkout page load, and it usually carries
		 * the very values the session already holds (the same referrer, the same
		 * click IDs, the same consent state). A session write marks the entire
		 * WooCommerce session dirty, and WooCommerce then re-serializes the whole
		 * session, cart included, on shutdown, so an unchanged write meant
		 * rewriting the cart for nothing.
		 *
		 * @since 1.64.1
		 */
		if ($merged_session_identifiers === $stored_session_identifiers) {
			Logger::debug('Transient session identifiers unchanged, skipping the session write');
		} else {

			/**
			 * The write below persists the whole session, so the cart in it has
			 * to be the cart as it stands now, not as it stood when this
			 * request started. A shopper who adds a product while this request
			 * is in flight would otherwise find it gone again.
			 *
			 * @since 1.69.0
			 */
			Shop::refresh_cart_in_session_snapshot();

			// Set the session identifiers in the WooCommerce session
			WC()->session->set(Shop::get_transient_identifiers_key(), $merged_session_identifiers);
		}

		// Refresh PMW's first-party fallback cookie with a server-set header:
		// Safari caps JavaScript-written cookies at 7 days, a server-set one
		// keeps the full 90. Safe here because this AJAX response is uncached
		// by definition - never do this on a page render, where a page cache
		// could store the Set-Cookie header and serve one visitor's click IDs
		// to everyone. Only with granted marketing consent, like the browser's
		// own cookie writer.
		Click_Ids::send_refreshed_cookie(
			array_intersect_key(
				$merged_session_identifiers,
				array_flip(Click_Ids::get_active_click_id_keys())
			),
			$consent
		);

		// Same reasoning for AppLovin's visitor ID: a server-set copy of the
		// pixel's _axwrt cookie outlives the browser's cap on script-written
		// cookies. @since 1.69.3
		if (Options::is_applovin_active()) {
			AppLovin_CAPI::maybe_mirror_axwrt_cookie($consent);
		}

		wp_send_json_success([
				'session_identifiers' => $data,
				'message'             => 'Session identifiers stored in server session',
		]);
	}

	/**
	 * Sanitize new transient session identifiers
	 *
	 * @param array $data
	 * @return array
	 */
	private static function sanitize_new_transient_session_identifiers__premium_only( $data ) {

		$allowed_keys = [
				'referrer',
				'gclid',
				'gbraid',
				'wbraid',
				'fbclid',
				'ttclid',
				'scid',
				'epik',
				'oppref',
				'ndclid',
				'msclkid',
				'rdt_cid',
				'aleid',
				'consent',
				'ga4_hit_delivery',
		];

		// Remove all keys that are not allowed
		$data = array_intersect_key($data, array_flip($allowed_keys));

		if (isset($data['referrer'])) {
			// The session row is rewritten with this value on every call, so it
			// is bounded like every other identifier here. @since 1.69.1
			if (
				!is_string($data['referrer'])
				|| strlen($data['referrer']) > 2048
				|| !filter_var($data['referrer'], FILTER_VALIDATE_URL)
				|| !in_array(strtolower((string) wp_parse_url($data['referrer'], PHP_URL_SCHEME)), [ 'http', 'https' ], true)
			) {
				unset($data['referrer']);
			}
		}

		if (isset($data['gclid'])) {
			if (!Google_Helpers::is_valid_gclid($data['gclid'])) {
				unset($data['gclid']);
			}
		}

		if (isset($data['gbraid'])) {
			if (!Google_Helpers::is_valid_braid($data['gbraid'])) {
				unset($data['gbraid']);
			}
		}

		if (isset($data['wbraid'])) {
			if (!Google_Helpers::is_valid_braid($data['wbraid'])) {
				unset($data['wbraid']);
			}
		}

		if (isset($data['fbclid'])) {
			if (!Facebook_CAPI::is_valid_fbc($data['fbclid'])) {
				unset($data['fbclid']);
			}
		}

		if (isset($data['ttclid'])) {
			if (!TikTok_EAPI::is_valid_ttclid($data['ttclid'])) {
				unset($data['ttclid']);
			}
		}

		if (isset($data['scid'])) {
			// The transient scid is the ScCid landing parameter, not the _scid cookie.
			if (!Snapchat_CAPI::is_valid_sc_click_id($data['scid'])) {
				unset($data['scid']);
			}
		}

		if (isset($data['epik'])) {
			if (!Pinterest_APIC::is_valid_epik($data['epik'])) {
				unset($data['epik']);
			}
		}

		if (isset($data['oppref'])) {
			if (!OpenAI_CAPI::is_valid_oppref($data['oppref'])) {
				unset($data['oppref']);
			}
		}

		if (isset($data['ndclid'])) {
			if (!Nextdoor_CAPI::is_valid_ndclid($data['ndclid'])) {
				unset($data['ndclid']);
			}
		}

		if (isset($data['msclkid'])) {
			if (!Bing_CAPI::is_valid_msclkid($data['msclkid'])) {
				unset($data['msclkid']);
			}
		}

		if (isset($data['rdt_cid'])) {
			// Reddit publishes no format spec; same plausibility bounds as ndclid.
			if (!is_string($data['rdt_cid']) || !preg_match('/^[A-Za-z0-9._~=-]{5,500}$/', $data['rdt_cid'])) {
				unset($data['rdt_cid']);
			}
		}

		if (isset($data['aleid'])) {
			if (!AppLovin_CAPI::is_valid_aleid($data['aleid'])) {
				unset($data['aleid']);
			}
		}

		if (isset($data['ga4_hit_delivery'])) {
			// Diagnostics only, and a closed vocabulary, so anything else is
			// dropped rather than stored. A failure carries the HTTP status
			// with it as "failed:502", because which error it was decides
			// what to look at. See the probe module for what each state
			// means. @since 1.69.0
			if (!is_string($data['ga4_hit_delivery']) || !preg_match('/^(confirmed|sent|blocked|no_tag|unsupported|failed:[1-5][0-9]{2})$/', $data['ga4_hit_delivery'])) {
				unset($data['ga4_hit_delivery']);
			}
		}

		if (isset($data['consent'])) {
			if (is_array($data['consent'])) {
				$data['consent'] = [
						'marketing'          => filter_var(isset($data['consent']['marketing']) ? $data['consent']['marketing'] : false, FILTER_VALIDATE_BOOLEAN),
						'statistics'         => filter_var(isset($data['consent']['statistics']) ? $data['consent']['statistics'] : false, FILTER_VALIDATE_BOOLEAN),
						'visitor_has_chosen' => filter_var(isset($data['consent']['visitor_has_chosen']) ? $data['consent']['visitor_has_chosen'] : false, FILTER_VALIDATE_BOOLEAN),
						'timestamp'          => time(),
				];
			} else {
				unset($data['consent']);
			}
		}

		return $data;
	}

	public function get_acr_order_data_ajax__premium_only() {

		// This endpoint only reads. Keep it out of the session's write path,
		// so it can never revert a cart change a shopper makes while it runs.
		Shop::keep_woocommerce_session_read_only();

		$_post = Helpers::get_input_vars(INPUT_POST);
		$this->get_order_details_for_acr($_post['data']);
	}

	/**
	 * Answers a browser-relayed server event, then sends it to the vendors.
	 *
	 * On PHP-FPM and LiteSpeed the success response goes out first and the
	 * visitor's connection is closed, so the browser no longer waits for the
	 * outbound requests. Elsewhere the old order stays: send, then answer.
	 * Everything that can reject the request (rate limit, payload checks)
	 * has to run before this method. See DD-094.
	 *
	 * @param array $data The sanitized, reconciled event payload.
	 * @return void Ends the request.
	 *
	 * @since 1.74.3
	 */
	private function answer_then_relay_server_to_server_event__premium_only( $data ) {

		$already_answered = ( new Early_Response() )->json_success_then(function () use ( $data ) {
			$this->process_server_to_server_event__premium_only($data);
		});

		if ($already_answered) {
			exit;
		}

		wp_send_json_success();
	}

	/**
	 * Sends a browser-relayed server event to the active vendors.
	 *
	 * Closing the visitor's connection early does not free the PHP worker,
	 * which stays busy until the last outbound request returns. So these
	 * low-value relayed events get a shorter outbound timeout than the 5
	 * seconds a purchase gets. See DD-094.
	 *
	 * @param array $data
	 * @return void
	 */
	public function process_server_to_server_event__premium_only( $data ) {

		/**
		 * Filters the outbound timeout, in seconds, for each vendor request
		 * of a browser-relayed server event. A value below 1 lifts the cap.
		 *
		 * @since 1.74.3
		 */
		$timeout = (float) apply_filters('pmw_sse_relay_timeout', 2);

		HTTP::set_timeout_cap($timeout >= 1 ? $timeout : null);

		try {
			// Process event through the server-side filter pipeline
			Server_Event_Processor::process_event($data);
		} finally {
			HTTP::set_timeout_cap(null);
		}
	}

	/**
	 * Whether the current REST request targets the Google Ads conversion
	 * adjustments CSV feed, under either REST URL form.
	 *
	 * @return bool
	 *
	 * @since 1.66.1
	 */
	private function is_gads_csv_request() {

		if (!isset($GLOBALS['wp']->query_vars['rest_route']) || !is_string($GLOBALS['wp']->query_vars['rest_route'])) {
			return false;
		}

		$route = '/' . ltrim(untrailingslashit($GLOBALS['wp']->query_vars['rest_route']), '/');

		$expected_route = '/' . $this->rest_namespace . $this->gads_conversion_adjustments_route;

		return $expected_route === $route;
	}

	/**
	 * Filter callback for rest_authentication_errors.
	 *
	 * WordPress core reads every Basic Auth header on a REST request as an
	 * Application Password login (wp_validate_application_password(), hooked
	 * on determine_current_user). When the username is not a WordPress user,
	 * or the password is not one of that user's application passwords, core
	 * records a WP_Error and rest_application_password_check_errors() turns
	 * it into a 401 "invalid_username" / "incorrect_password" response before
	 * the route's permission_callback is ever consulted.
	 *
	 * The credentials a merchant returns from the
	 * `pmw_google_ads_conversion_adjustments_credentials` filter are feed
	 * credentials, not a WordPress login, so on an HTTPS shop every fetch by
	 * Google Ads with the correct credentials was rejected by core with
	 * "invalid credentials". Returning true here for the feed route tells the
	 * REST server that authentication has been dealt with, and leaves the
	 * actual check to self::is_gads_csv_auth_ok() in the route's
	 * permission_callback. The route is public unless the filter is
	 * registered, so nothing is opened up that was not open before.
	 *
	 * Every other route is left untouched.
	 *
	 * @param WP_Error|null|true $result Authentication result so far.
	 * @return WP_Error|null|true
	 *
	 * @since 1.66.1
	 */
	public function bypass_core_basic_auth_for_gads_csv( $result ) {

		if (!empty($result)) {
			return $result;
		}

		if (!$this->is_gads_csv_request()) {
			return $result;
		}

		return true;
	}

	/**
	 * Permission check for the Google Ads conversion adjustments CSV route.
	 *
	 * Returns true (publicly readable) unless the merchant has registered the
	 * `pmw_google_ads_conversion_adjustments_credentials` filter to require
	 * HTTP Basic Auth. This matches the HTTPS data source in Google Ads Data
	 * Manager, which asks for a Username and Password for the source URL.
	 *
	 * WordPress core would otherwise claim the same Basic Auth header for
	 * Application Passwords and reject the request before this check runs;
	 * self::bypass_core_basic_auth_for_gads_csv() keeps core out of the way.
	 *
	 * The filter must return either:
	 *   - null / empty / non-array → no auth required (default)
	 *   - [ 'user' => 'foo', 'pass' => 'bar' ] → Basic Auth required
	 *
	 * Credentials are compared with hash_equals() to avoid timing leaks.
	 * Falls back to the raw `Authorization` header when PHP_AUTH_USER /
	 * PHP_AUTH_PW are not populated by the SAPI (common on PHP-FPM/FastCGI).
	 *
	 * @return true|WP_Error
	 *
	 * @since 1.58.10
	 */
	private static function is_gads_csv_auth_ok() {

		/**
		 * Filters the credentials required to fetch the Google Ads conversion
		 * adjustments CSV feed.
		 *
		 * Return [ 'user' => '...', 'pass' => '...' ] to enable HTTP Basic
		 * Auth on the feed URL. Return null/empty to keep the feed publicly
		 * readable (default).
		 *
		 * @since 1.58.10
		 *
		 * @param array|null $credentials Default null.
		 */
		$credentials = apply_filters('pmw_google_ads_conversion_adjustments_credentials', null);

		if (empty($credentials) || !is_array($credentials) || empty($credentials['user']) || empty($credentials['pass'])) {
			return true;
		}

		// Resolve incoming credentials, with HTTP_AUTHORIZATION fallback for
		// PHP-FPM/FastCGI environments where PHP_AUTH_USER is not populated.
		$incoming_user = isset($_SERVER['PHP_AUTH_USER']) ? sanitize_text_field(wp_unslash($_SERVER['PHP_AUTH_USER'])) : '';
		$incoming_pass = isset($_SERVER['PHP_AUTH_PW']) ? sanitize_text_field(wp_unslash($_SERVER['PHP_AUTH_PW'])) : '';

		if (( '' === $incoming_user || '' === $incoming_pass ) && !empty($_SERVER['HTTP_AUTHORIZATION'])) {

			$header = sanitize_text_field(wp_unslash($_SERVER['HTTP_AUTHORIZATION']));

			if (0 === stripos($header, 'Basic ')) {
				$decoded = base64_decode(substr($header, 6), true);

				if (is_string($decoded) && false !== strpos($decoded, ':')) {
					list($incoming_user, $incoming_pass) = explode(':', $decoded, 2);
				}
			}
		}

		$user_match = hash_equals((string) $credentials['user'], $incoming_user);
		$pass_match = hash_equals((string) $credentials['pass'], $incoming_pass);

		if ($user_match && $pass_match) {
			return true;
		}

		header('WWW-Authenticate: Basic realm="PMW Conversion Adjustments"');

		return new WP_Error(
				'rest_forbidden',
				esc_html__('Authentication required', 'woocommerce-google-adwords-conversion-tracking-tag'),
				[ 'status' => 401 ]
		);
	}

	/**
	 * Generic per-IP rate limiter for public PMW endpoints.
	 *
	 * Caps each client IP at $max requests per minute within a named bucket
	 * (different buckets are tracked independently) to dampen abuse while
	 * protecting outbound API quota and persistent storage from runaway
	 * unauthenticated writes. Fails open when the IP cannot be resolved so
	 * legit traffic is never silently dropped.
	 *
	 * @param string $bucket Short identifier for the endpoint (e.g. 'sse', 'products').
	 * @param int    $max    Maximum allowed requests per minute per IP.
	 * @return bool True when the current request should be rejected.
	 *
	 * @since 1.58.10
	 */
	private static function is_rate_limited( $bucket, $max = 120 ) {

		// Read from $_SERVER rather than filter_input(INPUT_SERVER), which only
		// sees PHP's request snapshot and is empty under some SAPIs and in tests.
		$remote_addr = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
		$remote_addr = filter_var($remote_addr, FILTER_VALIDATE_IP) ? $remote_addr : '';
		$ip          = Geolocation::get_user_ip();

		if (empty($ip) && empty($remote_addr)) {
			return false;
		}

		/**
		 * The visitor IP comes from proxy headers such as CF-Connecting-IP or
		 * X-Forwarded-For, which any client can set on a site that does not
		 * sit behind that proxy. Rotating the header would hand out a fresh
		 * bucket per request and create a transient row for each one. So the
		 * connecting address, which cannot be forged, is counted first with a
		 * wider limit that covers a whole proxy edge, and the request is over
		 * before it can create a bucket of its own once that limit is reached.
		 * The per-visitor bucket keeps its precision on sites that really are
		 * behind a proxy, where all visitors share a few connecting addresses.
		 *
		 * @since 1.69.1
		 */
		if ('' !== $remote_addr) {
			$behind_proxy = '' !== $ip && $ip !== $remote_addr;
			$shared_limit = $behind_proxy ? $max * 10 : $max;

			if (self::is_rate_limit_bucket_exceeded('pmw_rl_' . $bucket . '_c_' . md5($remote_addr), $shared_limit)) {
				return true;
			}
		}

		if ('' !== $ip && $ip !== $remote_addr) {
			return self::is_rate_limit_bucket_exceeded('pmw_rl_' . $bucket . '_' . md5($ip), $max);
		}

		return false;
	}

	/**
	 * Count one request against a rate limit bucket.
	 *
	 * @param string $key Transient name of the bucket.
	 * @param int    $max Requests allowed per minute.
	 * @return bool True when the bucket was already full.
	 *
	 * @since 1.69.1
	 */
	private static function is_rate_limit_bucket_exceeded( $key, $max ) {

		$count = (int) get_transient($key);

		if ($count >= $max) {
			return true;
		}

		set_transient($key, $count + 1, MINUTE_IN_SECONDS);

		return false;
	}

	/**
	 * Field names that carry an event name in a browser-to-server payload.
	 *
	 * Meta, Pinterest, Snapchat, Reddit and Spotify use event_name, TikTok
	 * uses event, Microsoft Ads uses event_type, and the Google Analytics
	 * Measurement Protocol nests the name as events[].name.
	 *
	 * @var string[]
	 */
	private static $sse_event_name_fields = [ 'event', 'event_name', 'event_type', 'en', 'ev' ];

	/**
	 * Purchase event names across every server-side destination, reduced to
	 * lowercase letters and digits: Meta and Reddit Purchase, TikTok
	 * CompletePayment and PlaceAnOrder, Klaviyo Placed Order and Ordered
	 * Product, GA4, Bing, OpenAI, Nextdoor, Snapchat and Spotify purchase.
	 * Pinterest reports a purchase as checkout, which is matched only under
	 * its own pixel key because Spotify uses the same word for a checkout start.
	 *
	 * @var string[]
	 */
	private static $sse_purchase_event_names = [ 'purchase', 'purchased', 'completepayment', 'placeanorder', 'placedorder', 'orderedproduct' ];

	/**
	 * Whether a browser-to-server payload asks for a purchase to be sent.
	 *
	 * The endpoint forwards each pixel's object to that platform as it is,
	 * and the platform reads the event name from inside that object. A check
	 * on the wrapper's event field alone therefore let an unauthenticated
	 * client post {"facebook":{"event_name":"Purchase","custom_data":{"value":99999}}}
	 * and land a fabricated purchase in the merchant's Conversions API. Every
	 * pixel object is therefore searched for a purchase name at any depth.
	 * Purchases only ever leave through the server-side order hooks.
	 *
	 * The wrapper field is optional. pmw.trackCustomFacebookEvent(), the Meta
	 * branch of the conversion shortcode and documented shop snippets send
	 * only a pixel object, and requiring the wrapper refused all of them
	 * while adding no protection, since a client can set any wrapper value.
	 *
	 * @param mixed $data The decoded request payload.
	 * @return bool
	 *
	 * @since 1.69.1
	 */
	public static function is_purchase_like_sse_payload( $data ) {

		if (!is_array($data)) {
			return true;
		}

		if (isset($data['event']) && !is_string($data['event'])) {
			return true;
		}

		if (isset($data['event']) && self::is_purchase_event_name($data['event'])) {
			return true;
		}

		foreach ($data as $pixel => $pixel_data) {
			if (is_array($pixel_data) && self::array_carries_purchase_event_name($pixel_data, (string) $pixel)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a branch of a pixel payload names a purchase event.
	 *
	 * @param array  $data       A pixel's payload or one of its branches.
	 * @param string $pixel      The top-level pixel key the branch belongs to.
	 * @param string $parent_key The key this branch hangs under.
	 * @param int    $depth      Recursion depth, bounded.
	 * @return bool
	 *
	 * @since 1.69.1
	 */
	private static function array_carries_purchase_event_name( $data, $pixel, $parent_key = '', $depth = 0 ) {

		if ($depth > 8) {
			return false;
		}

		foreach ($data as $key => $value) {

			if (is_array($value)) {
				if (self::array_carries_purchase_event_name($value, $pixel, is_string($key) ? $key : $parent_key, $depth + 1)) {
					return true;
				}
				continue;
			}

			if (!is_string($value) || !is_string($key)) {
				continue;
			}

			$key_lower = strtolower($key);

			// A product's name is not an event name; only GA4's events[].name is.
			$is_ga4_event_name = 'name' === $key_lower && 'events' === $parent_key;
			$is_event_field    = $is_ga4_event_name || in_array($key_lower, self::$sse_event_name_fields, true);

			if ($is_event_field && self::is_purchase_event_name($value, $pixel)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether an event name, as any platform spells it, means a purchase.
	 *
	 * @param string $name  An event name as a platform spells it.
	 * @param string $pixel The pixel key the name was found under.
	 * @return bool
	 *
	 * @since 1.69.1
	 */
	public static function is_purchase_event_name( $name, $pixel = '' ) {

		$normalized = preg_replace('/[^a-z0-9]/', '', strtolower((string) $name));

		if (in_array($normalized, self::$sse_purchase_event_names, true)) {
			return true;
		}

		return 'pinterest' === $pixel && 'checkout' === $normalized;
	}

	/**
	 * Field names our browser bundles use for the visitor's user agent.
	 *
	 * Facebook, Pinterest and Snapchat nest it as `user_data.client_user_agent`,
	 * TikTok and Reddit as `user.user_agent`, and the camelCase spelling is
	 * Microsoft Ads' convention. The reconciliation below matches on the field
	 * name at any depth rather than on a per-pixel path, so a pixel that reuses
	 * any of these conventions is covered the day it is added, without anyone
	 * having to remember this function exists.
	 *
	 * Test_SSE_Client_User_Agent reads the JS sources and fails when a bundle
	 * starts sending the user agent under a name that is not listed here.
	 *
	 * @return string[]
	 *
	 * @since 1.65.2
	 */
	private static function get_client_user_agent_field_names() {
		return [ 'client_user_agent', 'user_agent', 'clientUserAgent' ];
	}

	/**
	 * Replace every client-supplied user agent in an /sse/ payload fragment
	 * with the user agent of the request that carried it.
	 *
	 * Recurses because the field sits inside a per-pixel container whose name
	 * differs by destination, and a payload holds one such container per pixel.
	 *
	 * @param array  $data       Payload or nested fragment.
	 * @param string $user_agent The request's own user agent, '' when absent.
	 * @param int    $depth      Recursion guard.
	 * @return array
	 *
	 * @since 1.65.2
	 */
	private static function reconcile_user_agent_fields( $data, $user_agent, $depth = 0 ) {

		// Payloads are two to three levels deep; the guard is only here so a
		// pathological body cannot turn into unbounded recursion.
		if ($depth > 8) {
			return $data;
		}

		$field_names = self::get_client_user_agent_field_names();

		foreach ($data as $key => $value) {

			if (is_array($value)) {
				$data[ $key ] = self::reconcile_user_agent_fields($value, $user_agent, $depth + 1);
				continue;
			}

			if (!in_array($key, $field_names, true)) {
				continue;
			}

			if ('' === $user_agent) {
				// Nothing authoritative to substitute, so the client's copy is
				// dropped rather than trusted by default.
				unset($data[ $key ]);
				continue;
			}

			$data[ $key ] = $user_agent;
		}

		return $data;
	}

	/**
	 * Reconcile client_ip_address and client_user_agent in an /sse/ payload.
	 *
	 * /sse/ is a public endpoint, so every value in the request body is
	 * attacker-controlled. Both identifiers the browser contributes are
	 * therefore reconciled against what the request itself proves.
	 *
	 * The user agent is replaced with the request's own HTTP_USER_AGENT, which
	 * is authoritative for events fired from the same browser and cannot be
	 * forged through the payload. When the request carries no user agent at all
	 * the field is dropped instead of trusted.
	 *
	 * Between 1.58.10 and 1.65.2 this method only unset the field and left the
	 * substitution to the adapters, which none of Facebook, Pinterest and
	 * Snapchat implemented. Those destinations therefore received an IP with no
	 * user agent for every non-purchase event, which Meta reports as unusable
	 * for matching. The adapters now carry the same fallback (see
	 * Facebook_CAPI::send_event_hit()), so the value is also restored for a
	 * payload that never contained the field.
	 *
	 * The client_ip_address field is kept only when it adds information the
	 * server cannot see, defined as: a valid public IP whose family (IPv4/IPv6)
	 * differs from the server-derived IP. This preserves the legitimate
	 * dual-stack case where the browser detected an IPv6 address that a
	 * IPv4-only proxy chain hides from the server, while preventing an
	 * attacker from impersonating arbitrary IPs in the same family they
	 * already connect from.
	 *
	 * @param array $data /sse/ payload after sanitization.
	 * @return array
	 *
	 * @since 1.58.10
	 * @since 1.65.2 The user agent is substituted instead of only stripped, and
	 *                the substitution reaches every pixel's payload shape.
	 */
	private static function reconcile_client_identifiers_in_sse_payload( $data ) {

		$data = self::reconcile_user_agent_fields($data, Helpers::get_request_user_agent());

		$server_ip      = Geolocation::get_user_ip();
		$server_is_ipv6 = $server_ip && false !== filter_var($server_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6);

		foreach ($data as $pixel_name => $pixel_payload) {

			if (!is_array($pixel_payload) || !isset($pixel_payload['user_data']) || !is_array($pixel_payload['user_data'])) {
				continue;
			}

			// Reconcile client-supplied IP.
			if (!isset($pixel_payload['user_data']['client_ip_address'])) {
				continue;
			}

			$client_ip = $pixel_payload['user_data']['client_ip_address'];

			// Must be a valid public IP, otherwise drop.
			$valid_public = filter_var(
					$client_ip,
					FILTER_VALIDATE_IP,
					FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
			);

			if (false === $valid_public) {
				unset($data[ $pixel_name ]['user_data']['client_ip_address']);
				continue;
			}

			// Keep only when the family differs from the server-derived IP,
			// i.e. when the client is genuinely contributing information the
			// server could not see (typical dual-stack v6 case behind an
			// IPv4-only proxy).
			$client_is_ipv6 = false !== filter_var($client_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6);

			if ($server_ip && $client_is_ipv6 === $server_is_ipv6) {
				unset($data[ $pixel_name ]['user_data']['client_ip_address']);
			}
		}

		return $data;
	}

	/**
	 * Save imported settings from the REST API request.
	 *
	 * @param WP_REST_Request $request The request object containing the settings to be saved.
	 * @return void Responds with JSON success or error messages.
	 */
	public function pmw_save_imported_settings( $request ) {

		// Verify nonce
		if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
			return Helpers::rest_envelope(false, 'Invalid nonce');
		}

		$options = $request->get_params();

		// Sanitize nested array $options
		$options = Helpers::generic_sanitization($options);

		if (!is_array($options)) {
			return Helpers::rest_envelope(false, 'Invalid options. Not an array.');
		}

		// Validate imported options
		if (!Validations::validate_imported_options($options)) {
			return Helpers::rest_envelope(false, [ 'message' => 'Invalid options. Didn\'t pass validation.' ]);
		}

		// Every field runs its own validator, unknown keys are dropped. @since 1.69.1
		$validated = Validations::validate_imported_options_tree($options);

		if (!$validated['valid']) {
			return Helpers::rest_envelope(false, [
				'message' => 'Invalid options. These settings did not pass validation: ' . implode(', ', $validated['errors']),
				'paths'   => $validated['errors'],
			]);
		}

		// All good, save options with timestamp and automatic backup
		Options::save_options_with_timestamp($validated['options'], true);
		return Helpers::rest_envelope(true, [ 'message' => 'Options saved' ]);
	}

	public function pwm_save_ga4_data_api_credentials__premium_only( $request ) {

		// Verify nonce
		if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
			return Helpers::rest_envelope(false, 'Invalid nonce');
		}

		$credentials = $request->get_params();

		// Sanitize nested array $options
		$credentials = Helpers::generic_sanitization($credentials);

		// The validator's own message, as validate_ga4_data_api_credentials()
		// sent it, but returned instead of printed and died on.
		$valid = Validations::validate_google_service_account_credentials($credentials);

		if (true !== $valid) {
			return Helpers::rest_envelope(false, [ 'message' => $valid ]);
		}

		// All good, save options with timestamp and automatic backup
		$options = Options::get_options();
		$options['google']['analytics']['ga4']['data_api']['credentials'] = $credentials;
		Options::save_options_with_timestamp($options, true);
		return Helpers::rest_envelope(true, [ 'message' => 'Options saved' ]);
	}

	/**
	 * Sends a validateOnly test upload built from the latest order, so a
	 * merchant gets Google's verdict on the whole setup (auth, account
	 * access, conversion action, payload) at configuration time instead of
	 * with the first real order.
	 */
	public function pmw_google_dm_test_upload__premium_only( $request ) {

		if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
			return Helpers::rest_envelope(false, 'Invalid nonce');
		}

		if (!Options::is_google_ads_dm_active()) {
			return Helpers::rest_envelope(false, [ 'message' => 'Complete the configuration first: customer ID, conversion action ID and authentication.' ]);
		}

		return Helpers::rest_envelope(true, Google_DMA::send_test_upload());
	}

	/**
	 * The most recent upload outcome plus the local browser-vs-API delta
	 * report, rendered on the settings card.
	 */
	public function pmw_google_dm_upload_status__premium_only( $request ) {

		if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
			return Helpers::rest_envelope(false, 'Invalid nonce');
		}

		$last_upload = get_option(Google_DMA::LAST_UPLOAD_OPTION);
		$active      = Options::is_google_ads_dm_active();

		// Per-order diagnostics and identifier coverage moved to the debug
		// info report (support channel); the card only carries the summary.
		// The active flag is authoritative here: the card must never derive
		// it from a leftover conversion-action option after a disconnect.
		return Helpers::rest_envelope(true, [
			'active'     => $active,
			'lastUpload' => $active && is_array($last_upload) ? $last_upload : null,
			'delta'      => $active ? Google_DMA::get_delta_report() : null,
		]);
	}

	/**
	 * Everything the Diagnostics-page card renders: the daily coverage series
	 * (browser tag vs upload-recovered vs uncovered), the recent per-order
	 * rows with the identifiers each side had, the delta summary, and the
	 * ready-to-share debug text for support tickets.
	 */
	public function pmw_google_dm_diagnostics__premium_only( $request ) {

		if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
			return Helpers::rest_envelope(false, 'Invalid nonce');
		}

		if (!Options::is_google_ads_dm_active()) {
			return Helpers::rest_envelope(true, [ 'active' => false ]);
		}

		$last_upload = get_option(Google_DMA::LAST_UPLOAD_OPTION);

		return Helpers::rest_envelope(true, [
			'active'     => true,
			'actionName' => Options::get_google_ads_dm_conversion_action_name(),
			'actionId'   => Options::get_google_ads_dm_conversion_action_id(),
			'accountId'  => Options::get_google_ads_dm_operating_account_id(),
			'lastUpload' => is_array($last_upload) ? $last_upload : null,
			'delta'      => Google_DMA::get_delta_report(),
			'coverage'   => Google_DMA::get_identifier_coverage_by_day(30),
			'recent'     => Google_DMA::get_recent_upload_diagnostics(12, false),
			'debugText'  => Google_DMA::get_debug_info(),
		]);
	}

	/**
	 * Starts, stops or reports the backfill that re-uploads the orders whose
	 * Data Manager upload failed. Only a rate-limited upload is retried by
	 * the live path, so an upstream outage leaves orders no shop can recover
	 * on its own.
	 */
	public function pmw_google_dm_backfill__premium_only( $request ) {

		if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
			return Helpers::rest_envelope(false, 'Invalid nonce');
		}

		if (!Options::is_google_ads_dm_active()) {
			return Helpers::rest_envelope(false, [ 'message' => 'Complete the configuration first: customer ID, conversion action ID and authentication.' ]);
		}

		$action = (string) $request->get_param('action');

		if ('start' === $action) {
			return Helpers::rest_envelope(true, Google_DMA::start_backfill());
		}

		if ('stop' === $action) {
			return Helpers::rest_envelope(true, Google_DMA::stop_backfill());
		}

		return Helpers::rest_envelope(true, [ 'state' => Google_DMA::get_backfill_state() ]);
	}

	public function run_background_processes() {

		if (wpm_fs()->can_use_premium_code__premium_only() && Environment::is_woocommerce_active()) {

			// @since 1.58.4 Added Reddit_CAPI
			if (is_cart() || is_checkout()) {

				if (Options::is_ga4_mp_active()) {
					Google_MP_GA4::set_identifiers_on_session();
				}

				if (Options::is_facebook_capi_active()) {
					Facebook_CAPI::set_identifiers_on_session();
				}

				if (Options::is_tiktok_eapi_active()) {
					TikTok_EAPI::set_identifiers_on_session();
				}

				if (Options::is_pinterest_apic_active()) {
					Pinterest_APIC::set_identifiers_on_session();
				}

				if (Options::is_snapchat_capi_active()) {
					Snapchat_CAPI::set_identifiers_on_session();
				}

				if (Options::is_reddit_capi_active()) {
					Reddit_CAPI::set_identifiers_on_session();
				}

				if (Options::is_openai_capi_active()) {
					OpenAI_CAPI::set_identifiers_on_session();
				}

				if (Options::is_klaviyo_purchase_dispatch_active()) {
					Klaviyo_API::set_identifiers_on_session();
				}

				if (Options::is_google_ads_dm_active()) {
					Google_DMA::set_identifiers_on_session();
				}
			}

			// TODO: That function should probably not go into the Google_MP_GA4 class
			if (Shop::pmw_is_order_received_page()) {
				if (Shop::pmw_get_current_order()) {
					Google_Helpers::save_gclid_in_order__premium_only(Shop::pmw_get_current_order());
				}
			}
		}
	}

	public function pmw_woocommerce_new_order( $order_id, $order = null ) {

		// WooCommerce passes the order object as the second hook argument. Prefer it over
		// wc_get_order(), which can return false right after order creation when a persistent
		// object cache (e.g. Redis) serves a stale miss in cron contexts, such as
		// WooCommerce Subscriptions renewal order creation. @since 1.61.1
		if (!$order instanceof \WC_Order) {
			$order = wc_get_order($order_id);
		}

		if (!$order instanceof \WC_Order) {
			return;
		}

		/**
		 * All new orders should be marked as long PMW is active,
		 * so that we know we can process them later through PMW,
		 * and so that we know we should not touch orders that were
		 * placed before PMW was active.
		 */
		$order->add_meta_data('_wpm_process_through_wpm', true, true);

		/**
		 * Set a custom user ID on the order
		 * because WC sets 0 on all order created
		 * manually through the back-end.
		 */

		$user_id = 0;

		if (is_user_logged_in()) {
			$user_id = get_current_user_id();
		}

		$order->add_meta_data('_wpm_customer_user', $user_id, true);

		/**
		 * Mark all orders which have been created while the premium version was active
		 */
		if (wpm_fs()->can_use_premium_code__premium_only()) {
			$order->add_meta_data('_wpm_premium_active', true, true);
		}

		$order->save();
	}

	/**
	 * Increments orders_total exactly once per order, bucketed by the payment gateway
	 * that is set at the moment payment is finalized (or the order transitions to a
	 * post-pending status). This ensures that the gateway recorded for the denominator
	 * matches the gateway that will be recorded for the numerator (in
	 * save_conversion_pixels_fired_status), so the per-gateway percentages stay in
	 * the 0–100% range.
	 *
	 * Idempotency is enforced via the `_wpm_orders_total_counted` order meta flag.
	 *
	 * Accepts either an order ID or an order object so it can be invoked from action
	 * callbacks (which pass the ID) and from internal call sites that already have the
	 * order object loaded (e.g. save_conversion_pixels_fired_status).
	 *
	 * @param int|\WC_Order $order_or_id
	 *
	 * @return void
	 * @since 1.58.10
	 */
	public static function pmw_count_order_total_on_payment_finalized( $order_or_id ) {

		$order = is_object($order_or_id) ? $order_or_id : wc_get_order($order_or_id);

		if (!$order) {
			return;
		}

		self::with_tracking_accuracy_lock($order, [ __CLASS__, 'count_order_total' ]);
	}

	/**
	 * The body of pmw_count_order_total_on_payment_finalized(). Callers must
	 * hold the tracking accuracy lock for this order.
	 *
	 * @param \WC_Order $order
	 *
	 * @return void
	 * @since 1.71.1
	 */
	private static function count_order_total( $order ) {

		// Only count orders that PMW was responsible for tracking when they were placed.
		if (!$order->meta_exists('_wpm_process_through_wpm')) {
			return;
		}

		// Orders created without a customer browser session (admin, subscription
		// renewals) and orders where the visitor denied all consent categories
		// can never produce a browser-confirmed purchase and must not deflate
		// the accuracy denominator. A consent-denied order may still have been
		// sent server-side (always_send_s2s); it stays out of this report
		// either way, because the report measures the browser.
		if (!Shop::should_count_order_for_tracking_accuracy($order)) {

			$snapshot = $order->get_meta('_pmw_consent_snapshot', true);
			if (is_array($snapshot) && empty($snapshot['marketing']) && empty($snapshot['statistics'])) {

				$order_changed = false;

				// Make the consent exclusion visible on the order for support, and
				// record whether the conversion still went out server-side. Without
				// that distinction an excluded order reads as a lost one, which is
				// wrong on every shop running always_send_s2s. @since 1.67.1
				if (!$order->meta_exists('_pmw_accuracy_exclusion_reason')) {

					$sent_server_side = Options::is_always_send_s2s_active() && Options::always_send_s2s_has_destination();

					$order->update_meta_data(
						'_pmw_accuracy_exclusion_reason',
						$sent_server_side ? 'consent_denied_sent_server_side' : 'consent_denied'
					);
					$order_changed = true;
					Logger::info(
						'Tracking accuracy: order ' . $order->get_id() . ' excluded - consent denied'
						. ( $sent_server_side ? ' (server-side events were still sent, always_send_s2s is active)' : '' )
					);
				}

				// Count the exclusion so the payment gateway accuracy report can
				// show how many orders were untrackable due to denied consent.
				// Own latch (not _wpm_orders_total_counted): the purchase-trigger
				// hooks re-fire on several status transitions and must not
				// double-count.
				if (!$order->get_meta('_pmw_consent_excluded_counted')) {
					$payment_method = $order->get_payment_method();
					$date_created   = $order->get_date_created();
					if (!empty($payment_method) && $date_created) {
						Tracking_Accuracy_DB::increment_orders_consent_excluded(
							gmdate('Y-m-d', $date_created->getTimestamp()),
							$payment_method
						);
						$order->update_meta_data('_pmw_consent_excluded_counted', true);
						$order_changed = true;
					}
				}

				if ($order_changed) {
					$order->save();
				}
			}

			return;
		}

		// Idempotency guard: only count each order once toward orders_total.
		if ($order->get_meta('_wpm_orders_total_counted')) {
			return;
		}

		$payment_method = $order->get_payment_method();

		if (empty($payment_method)) {
			return;
		}

		$date_created = $order->get_date_created();

		if (!$date_created) {
			return;
		}

		Tracking_Accuracy_DB::increment_orders_total(
			gmdate('Y-m-d', $date_created->getTimestamp()),
			$payment_method
		);

		$order->update_meta_data('_wpm_orders_total_counted', true);

		// Remember the bucket, so the total can follow the order if its payment
		// method changes before the confirmation page reports. @since 1.71.1
		$order->update_meta_data('_pmw_orders_total_gateway', $payment_method);
		$order->save();
	}

	/**
	 * Run a tracking accuracy count while holding a lock for this order.
	 *
	 * Both counters check an order meta latch, count, then write the latch.
	 * Two requests for the same order at the same moment (the confirmation page
	 * loading twice, or a webhook alongside the confirmation beacon) both passed
	 * the check before either saved, and the order was counted twice. A MySQL
	 * named lock serializes them. Once it holds the lock, a request re-reads the
	 * order's meta from the database, because the order object was loaded
	 * before the other request saved. That drops meta changes the caller has
	 * not saved yet, which no caller has.
	 *
	 * The lock belongs to the database connection, so a request that dies
	 * while holding it cannot leave it behind. Where it cannot be taken at all
	 * (a database without GET_LOCK, such as SQLite), the count runs unlocked,
	 * as it did before.
	 *
	 * @param \WC_Order $order    The order.
	 * @param callable  $callback Does the count; receives the order.
	 *
	 * @return void
	 * @since 1.71.1
	 */
	private static function with_tracking_accuracy_lock( $order, $callback ) {

		global $wpdb;

		// MySQL caps lock names at 64 characters, so the name is hashed.
		$lock_name = 'pmw_' . md5($wpdb->prefix . 'tracking_accuracy:' . $order->get_id());

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- a named lock is not data; no WordPress API offers one.
		$acquired = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lock_name, self::TRACKING_ACCURACY_LOCK_TIMEOUT));

		if ('0' === (string) $acquired) {
			Logger::warning('Tracking accuracy: order ' . $order->get_id() . ' was still being counted by another request after ' . self::TRACKING_ACCURACY_LOCK_TIMEOUT . ' seconds, skipping so it cannot be counted twice');
			return;
		}

		try {
			if ('1' === (string) $acquired && method_exists($order, 'read_meta_data')) {
				$order->read_meta_data(true);
			}

			call_user_func($callback, $order);
		} finally {
			if ('1' === (string) $acquired) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
			}
		}
	}

	// Thanks to: https://gist.github.com/mishterk/6b7a4d6e5a91086a5a9b05ace304b5ce#file-mark-wordpress-scripts-as-async-or-defer-php
	public function experimental_defer_scripts( $tag, $handle ) {

		if ('pmw' !== $handle) {
			return $tag;
		}

		return str_replace(' src', ' defer src', $tag); // defer the script
	}

	public function woocommerce_mini_cart_contents() {

		foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
			$this->woocommerce_after_cart_item_name($cart_item, $cart_item_key);
		}
	}

	public function woocommerce_after_cart_item_name( $cart_item, $cart_item_key ) {

		/**
		 * Filter to control output of cart item data inline script.
		 *
		 * Some themes with JavaScript renderers don't properly hide script tags,
		 * causing them to be visible. Use this filter to suppress the output.
		 *
		 * @since 1.54.2
		 *
		 * @param bool   $output         Whether to output the script. Default true.
		 * @param array  $cart_item      Cart item data with product_id and variation_id.
		 * @param string $cart_item_key  Unique cart item key.
		 * @param string $action         Current action: 'woocommerce_after_cart_item_name',
		 *                               'woocommerce_after_mini_cart_item_name', or
		 *                               'woocommerce_mini_cart_contents'.
		 */
		if ( ! apply_filters( 'pmw_output_cart_item_data', true, $cart_item, $cart_item_key, current_action() ) ) {
			return;
		}

		/**
		 * Print each cart item only once per request.
		 *
		 * Both mini cart hooks are registered, because themes ship their own mini
		 * cart templates and fire only one of the two: woocommerce_mini_cart_contents
		 * runs once and loops over the items, woocommerce_after_mini_cart_item_name
		 * runs per item. On a theme that fires both, every item used to be printed
		 * twice. Whichever hook comes first now wins, and the second one finds the
		 * item already printed. The payload is identical either way, so one script
		 * per item is all the data layer needs.
		 *
		 * The check runs after the filter above on purpose: the filter can suppress
		 * a single action (it receives current_action()), and a suppressed call must
		 * not consume the item's one printing chance.
		 *
		 * @since 1.64.1
		 */
		if (isset($this->printed_cart_item_keys[ $cart_item_key ])) {
			return;
		}

		$this->printed_cart_item_keys[ $cart_item_key ] = true;

		$data = [
				'product_id'   => $cart_item['product_id'],
				'variation_id' => $cart_item['variation_id'],
		];

		// The data layer object itself is created here too, not just its
		// cart_item_keys property. This script ships inside the WooCommerce cart
		// fragments, which the browser evaluates on every cart update, and a
		// fragment can land on a page that carries no data layer at all: a consent
		// tool that blocks the Pixel Manager's head script, an HTML optimizer that
		// dropped it, or a theme that pulls the fragment into a page without the
		// Pixel Manager. Assigning into an undefined window.pmwDataLayer threw a
		// TypeError there, in the middle of WooCommerce's fragment replacement.
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON for an inline script, escaped by Helpers::json_encode_for_script()
		?>
		<script>
			(window.pmwDataLayer = window.pmwDataLayer || {}).cart_item_keys            = window.pmwDataLayer.cart_item_keys || {};
			window.pmwDataLayer.cart_item_keys['<?php echo esc_js($cart_item_key); ?>'] = <?php echo Helpers::json_encode_for_script($data); ?>;
		</script>

		<?php
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	// on the product page
	public function woocommerce_inject_product_data_on_product_page() {

		if (!is_product()) {
			return;
		}

		$product = wc_get_product(get_the_id());

		if (Product::is_not_wc_product($product)) {
			Logger::debug('woocommerce_inject_product_data_on_product_page provided no product on a product page: .' . get_the_id());
			return;
		}

		Product::print_product_data_layer_script($product, false, true);

		if ($product->is_type('grouped')) {

			foreach ($product->get_children() as $product_id) {

				$product = wc_get_product($product_id);

				if (Product::is_not_wc_product($product)) {
					Product::log_problematic_product_id($product_id);
					continue;
				}

				Product::print_product_data_layer_script($product, false, true);
			}

		} elseif ($product->is_type('variable')) {
			/**
			 * Stop inspection
			 *
			 * @noinspection PhpPossiblePolymorphicInvocationInspection
			 */

			// Prevent processing of large amounts of variations
			// because get_available_variations() is very slow
			if (64 <= count($product->get_children())) {
				return;
			}

			foreach ($product->get_available_variations() as $key => $variation) {

				$variable_product = wc_get_product($variation['variation_id']);

				if (!is_object($variable_product)) {
					Product::log_problematic_product_id($variation['variation_id']);
					continue;
				}

				Product::print_product_data_layer_script($variable_product, false, true);
			}
		}
	}

	// every product that's generated by the shop loop like shop page or a shortcode
	public function action_woocommerce_after_shop_loop_item() {

		global $product;

		Product::print_product_data_layer_script($product);
	}

	/**
	 * Product views generated by a Gutenberg block (instead of a shortcode)
	 *
	 * @param $html
	 * @param $data
	 * @param $product
	 * @return mixed|string
	 */
	public function wc_add_data_to_gutenberg_block( $html, $data, $product ) {

		// If the cart is empty, early return the html and don't add the additional product data layer.
		// This is to avoid a render blocking issue reported here: https://wordpress.org/support/topic/wc-8-4-empty-cart-error/
		// Also we need safeguards to avoid a bug reported here: https://wordpress.org/support/topic/fatal-error-4590/
		// IMO WooCommerce should not process the woocommerce_blocks_product_grid_item_html hook during a REST API request.
		if (!is_object(WC()->cart)) {
			return $html;
		}

		if (method_exists(WC()->cart, 'is_empty') && WC()->cart->is_empty()) {
			return $html;
		}

		// The new cart block in WC 9.x errors out when emptying the cart
		if (has_block('woocommerce/cart')) {
			return $html;
		}

		return $html . Product::ob_print_get_product_data_layer_script($product);
	}

	/**
	 * Product views generated by the Product Collection block
	 *
	 * Product Collection renders its items through the Product Template block,
	 * which runs none of the classic loop hooks. WooCommerce routes
	 * woocommerce_after_shop_loop_item into those items through its archive
	 * template compatibility layer, but only for collections that inherit the
	 * template query, so only on the shop, search and taxonomy templates. A
	 * collection placed on a page, a curated collection, and a related products
	 * collection all render without any Pixel Manager output, which leaves
	 * view_item_list and select_item blind to them.
	 *
	 * The product IDs are read from the block's own item key, which is the
	 * attribute the Interactivity API diffs the items on and is therefore
	 * present on every rendered item. The data layer entries are printed in the
	 * footer and the .pmwProductId markers injected into the matching items,
	 * which is the same mechanism the deferred output uses for page builders.
	 *
	 * Nothing in the block output is modified.
	 *
	 * @param string $block_content
	 * @param array  $block
	 * @return string
	 * @since 1.65.0
	 */
	public function collect_product_collection_products( $block_content, $block ) {

		if (empty($block['blockName']) || 'woocommerce/product-template' !== $block['blockName']) {
			return $block_content;
		}

		if (empty($block_content)) {
			return $block_content;
		}

		/**
		 * Block renders also happen for the editor and for REST responses,
		 * where wp_footer never runs and the collected products would only pile
		 * up in memory.
		 */
		if (is_admin() || ( defined('REST_REQUEST') && REST_REQUEST )) {
			return $block_content;
		}

		if (!preg_match_all('/data-wp-key="product-item-(\d+)"/', $block_content, $matches)) {
			return $block_content;
		}

		foreach (array_unique($matches[1]) as $product_id) {

			$product = wc_get_product((int) $product_id);

			if (Product::is_not_wc_product($product)) {
				continue;
			}

			Product::defer_product_data_layer_output($product);
		}

		return $block_content;
	}

	public function pmw_wp_footer() {
		// WP footer scripts
	}

	public function inject_data_layer_through_litespeed_esi() {
		/**
		 * Fires Litespeed control set nocache.
		 *
		 * @since 1.58.5
		 */
		do_action('litespeed_control_set_nocache', 'nocache for Pixel the Pixel Manager');
		$this->inject_data_layer();
	}

	/**
	 * Output the uncached data layer through ESI.
	 *
	 * @return void
	 * @since 1.32.6
	 **/
	private function inject_data_layer_litespeed_esi() {

		// The WooCommerce.com build may not echo the unescaped ESI tag, and wp_kses()
		// strips <esi:include> before WordPress 7.2 (core #58921), so it disables the
		// cache for logged-in users instead. See DD-050 for the planned replacement.
		if ('wcm' === PMW_DISTRO) {
			/**
			 * Fires Litespeed control set nocache.
			 *
			 * @since 1.58.5
			 */
			do_action('litespeed_control_set_nocache', 'logged in user: disable cache');
			$this->inject_data_layer();

			return;
		}
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
		/**
		 * Filters Unknown hook.
		 *
		 * @since 1.58.5
		 */
		echo apply_filters(
				'litespeed_esi_url',
				'pmw_data_layer',
				'Inject data layer through ESI block');
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Injects the data layer into the page.
	 *
	 * Source: https://support.cloudflare.com/hc/en-us/articles/200169436-How-can-I-have-Rocket-Loader-ignore-specific-JavaScripts-
	 *
	 * @return void
	 */
	private function inject_data_layer() {

		// We add a script string with additional attributes to the script tag.
		// Those attributes are primarily to exclude the script from being processed
		// by various script loaders and script blockers.
		// Some exclusion techniques use HTML comments, but those comments may be stripped by HTML minifiers.
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON for an inline script, escaped by Helpers::json_encode_for_script()
		?>

		<script<?php echo wp_kses(Helpers::get_opening_script_string(), Helpers::get_script_string_allowed_html()); ?>>

			window.pmwDataLayer = window.pmwDataLayer || {};
			window.pmwDataLayer = Object.assign(window.pmwDataLayer, <?php echo Helpers::json_encode_for_script($this->get_data_for_data_layer()); ?>);
			<?php echo self::get_library_sentinel_js(); ?>

		</script>

		<?php
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * A tiny inline check, printed with the data layer, that warns in the
	 * console when the Pixel Manager library never started on the page.
	 *
	 * A shop served the bundle as raw Brotli bytes without a Content-Encoding
	 * header. The browser threw "Invalid or unexpected token", window.pmw held
	 * only the configuration keys, and nothing tracked, with no hint pointing
	 * at the Pixel Manager. The library itself cannot report a file that never
	 * ran, so the data layer script, which did run, checks after the window
	 * load event, when every script present in the page source has executed.
	 *
	 * It stays quiet when the library script was deliberately held back: its
	 * tag still carries a type that does not execute, which is how lazy
	 * loading, consent tools (text/plain) and "delay JavaScript" optimizers
	 * defer it. It also stays quiet when no tag of the bundle is found, for
	 * example when an optimizer merged it into another file, because a missing
	 * tag cannot tell a failure from a tool that adds the script later.
	 *
	 * Plain ES5, it runs untranspiled. See DD-078 for why this is an inline
	 * check rather than a self-fetch of the bundle in the debug info.
	 *
	 * @return string
	 *
	 * @since 1.71.1
	 */
	public static function get_library_sentinel_js() {

		return <<<'PMW_SENTINEL_JS'
(function () {
	if (window.pmwLibrarySentinel) return;
	window.pmwLibrarySentinel = true;
	var check = function () {
		if (window.pmw && window.pmw.bus) return;
		var runnable = false;
		var scripts = document.getElementsByTagName("script");
		for (var i = 0; i < scripts.length; i++) {
			var script = scripts[i];
			var source = script.getAttribute("src") || "";
			for (var a = 0; a < script.attributes.length; a++) {
				if (/src$/i.test(script.attributes[a].name)) source += " " + script.attributes[a].value;
			}
			if (source.indexOf("pmw-public") === -1) continue;
			var type = (script.getAttribute("type") || "").toLowerCase();
			if (type && !/^(text|application)\/(javascript|ecmascript)$|^module$/.test(type)) return;
			if (script.getAttribute("src") && script.getAttribute("src").indexOf("pmw-public") !== -1) runnable = true;
		}
		if (!runnable) return;
		console.warn("Pixel Manager: the data layer is on this page, but the Pixel Manager library did not start, so nothing is tracked. Its script (pmw-public) failed to load or threw an error: check the console and the network tab. An \"Invalid or unexpected token\" error usually means the server sends the file compressed (Brotli or gzip) without a Content-Encoding header. An ad blocker or a JavaScript optimizer can also stop it.");
	};
	var schedule = function () { setTimeout(check, 0); };
	if (document.readyState === "complete") schedule(); else window.addEventListener("load", schedule);
})();
PMW_SENTINEL_JS;
	}

	/**
	 * Set up the pmwDataLayer
	 *
	 * @return mixed|void
	 */
	private function get_data_for_data_layer() {

		/**
		 * Load and set some defaults.
		 */

		$data = [
				'cart'           => (object) [], // Empty arrays get cast into an array, but we need an object
				'cart_item_keys' => (object) [], // Empty arrays get cast into an array, but we need an object
				'version'        => Helpers::get_version_info(),
		];

		/**
		 * Load the pixels
		 */

		$data['pixels'] = $this->get_pixel_data();

		/**
		 * Load remaining settings
		 */

		if (Environment::is_woocommerce_active()) {
			$data = $this->add_order_data($data);
//          $data         = array_merge($data, $this->get_order_data());
			$data['shop'] = $this->get_shop_data();
		}

		$data['page'] = self::get_page_data();

		$data['general'] = $this->get_general_data();

		// If the free version is active, don't output user data.
		// User data can only be processed with the premium version.
		if (wpm_fs()->can_use_premium_code__premium_only()) {
			$user_data = Helpers::get_user_data();

			if (!empty($user_data)) {
				$data['user'] = $user_data;
			}

			// Check if the current user just created an account
			// and inject the flag into the data layer.
			// The flag is consumed immediately to ensure it only fires once.
			if (is_user_logged_in()) {
				$current_user_id = get_current_user_id();
				if (get_user_meta($current_user_id, '_pmw_account_just_created', true)) {
					$data['user']['account_just_created'] = true;
					delete_user_meta($current_user_id, '_pmw_account_just_created');
				}
			}
		}

		/**
		 * Load the experiment settings
		 */

//      $data['experiments'] = [
//              'ga4_server_and_browser_tracking' => apply_filters('experimental_pmw_ga4_server_and_browser_tracking', false),
//      ];

		$data = apply_filters_deprecated('wpm_experimental_data_layer', [ $data ], '1.31.2', 'pmw_experimental_data_layer');

		/**
		 * Return and optionally modify the pmw data layer.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_experimental_data_layer', $data);
	}

	private function get_pixel_data() {

		$data = [];

		if (Options::is_google_active()) {
			$data['google'] = $this->get_google_pixel_data();
		}

		if (Options::is_facebook_active()) {
			$data['facebook'] = $this->get_facebook_pixel_data();
		}

		if (Options::is_hotjar_enabled()) {
			$data['hotjar'] = $this->get_hotjar_pixel_data();
		}

		// Browser pixels with a Pro server-side counterpart. The browser tag is
		// free; the Conversions API / Events API fields behind each of them are
		// Pro-only settings, so the payload builders report those as inactive
		// on a free install even when a downgraded shop still has a token saved.
		if (Options::is_bing_active()) {
			$data['bing'] = self::get_bing_pixel_data();
		}

		if (Options::is_openai_active()) {
			$data['openai'] = $this->get_openai_pixel_data();
		}

		if (Options::is_pinterest_active()) {
			$data['pinterest'] = $this->get_pinterest_pixel_data();
		}

		if (Options::is_reddit_active()) {
			$data['reddit'] = $this->get_reddit_pixel_data();
		}

		if (Options::is_snapchat_active()) {
			$data['snapchat'] = $this->get_snapchat_pixel_data();
		}

		if (Options::is_tiktok_active()) {
			$data['tiktok'] = $this->get_tiktok_pixel_data();
		}

		// If the premium version is active, load the additional pixels
		if (wpm_fs()->can_use_premium_code__premium_only()) {

			if (Options::is_crazyegg_enabled()) {
				$data['crazyegg'] = $this->get_crazyegg_pixel_data();
			}

			if (Options::is_contentsquare_active()) {
				$data['contentsquare'] = self::get_contentsquare_pixel_data();
			}

			if (Options::is_clarity_active()) {
				$data['clarity'] = self::get_clarity_pixel_data();
			}

			if (Options::is_groundtruth_active()) {
				$data['groundtruth'] = self::get_groundtruth_pixel_data();
			}

			if (Options::is_rumble_active()) {
				$data['rumble'] = self::get_rumble_pixel_data();
			}

			if (Options::is_criteo_active()) {
				$data['criteo'] = self::get_criteo_pixel_data();
			}

			if (Options::is_nextdoor_active()) {
				$data['nextdoor'] = self::get_nextdoor_pixel_data();
			}

			if (Options::is_spotify_active()) {
				$data['spotify'] = self::get_spotify_pixel_data();
			}

			if (Options::is_applovin_active()) {
				$data['applovin'] = self::get_applovin_pixel_data();
			}

			if (Options::is_triple_whale_active()) {
				$data['triple_whale'] = self::get_triple_whale_pixel_data();
			}

			if (Options::is_hyros_active()) {
				$data['hyros'] = self::get_hyros_pixel_data();
			}

			if (Options::is_mixpanel_active()) {
				$data['mixpanel'] = self::get_mixpanel_pixel_data();
			}

			if (Options::is_klaviyo_active() && 'off' !== Options::get_klaviyo_coexistence_mode()) {
				$data['klaviyo'] = self::get_klaviyo_pixel_data();
			}

			if (Options::is_adroll_active()) {
				$data['adroll'] = $this->get_adroll_pixel_data();
			}

			if (Options::is_linkedin_active()) {
				$data['linkedin'] = $this->get_linkedin_pixel_data();
			}

			if (Options::is_outbrain_active()) {
				$data['outbrain'] = self::get_outbrain_pixel_data();
			}

			if (Options::is_taboola_active()) {
				$data['taboola'] = self::get_taboola_pixel_data();
			}

			if (Options::is_twitter_active()) {
				$data['twitter'] = $this->get_twitter_pixel_data();
			}

			if (Options::is_vwo_active()) {
				$data['vwo'] = self::get_vwo_pixel_data();
			}

			if (Options::is_optimizely_active()) {
				$data['optimizely'] = self::get_optimizely_pixel_data();
			}

			if (Options::is_ab_tasty_active()) {
				$data['ab_tasty'] = self::get_ab_tasty_pixel_data();
			}
		}

		return $data;
	}

	private function get_google_pixel_data() {

		$data = [
				'linker'  => [
						'settings' => Google_Helpers::get_google_linker_settings(),
				],
				'user_id' => Options::is_google_user_id_active(),
		];

		if (Options::is_google_ads_active()) {
			$data['ads'] = [
					'conversion_ids'           => (object) Google_Helpers::get_google_ads_conversion_ids(),
					'dynamic_remarketing'      => [
							'status'                      => true, // Has been set be true by default
							'id_type'                     => Product::get_dyn_r_id_type('google_ads'),
							'send_events_with_parent_ids' => $this->send_events_with_parent_ids(),
					],
					'google_business_vertical' => Google_Helpers::get_google_business_vertical_name_by_id(Options::get_google_ads_business_vertical_id()),
					'phone_conversion_number'  => Options::get_google_ads_phone_conversion_number(),
					'phone_conversion_label'   => Options::get_google_ads_phone_conversion_label(),
			];
		}

		if (Options::is_google_analytics_active()) {
			$data['analytics'] = [
					'ga4'     => [
							'measurement_id'          => Options::get_ga4_measurement_id(),
							'parameters'              => (object) Google_Helpers::get_ga4_parameters(Options::get_ga4_measurement_id()),
							'mp_active'               => ( Options::is_ga4_mp_active() && wpm_fs()->can_use_premium_code__premium_only() ),
							'debug_mode'              => Google_Helpers::is_ga4_debug_mode_active(),
							'page_load_time_tracking' => Options::is_ga4_page_load_time_tracking_active(),
					],
					'id_type' => Google_Helpers::get_ga_id_type(),
			];
		}

		$data['tag_id']            = Google_Helpers::get_google_tag_id_information()['active'];
		$data['tag_id_suppressed'] = Google_Helpers::get_google_tag_id_information()['suppressed'];

		$data['tag_gateway']['measurement_path'] = Options::get_google_tag_gateway_measurement_path();

		// Pass handler hint and proxy_url to JavaScript for GTG handler selection.
		//
		// The browser is the source of truth for handler detection (it traverses CDN layers
		// that server-to-server requests bypass). PHP reads the handler from a browser-set
		// cookie. On first visit (no cookie), handler is null — JS does full async detection.
		//
		// Handler hint: Only sent for standalone/wordpress (never external or null).
		// When present, JS Priority 2 trusts it and skips the standalone proxy health check,
		// preventing 503/4xx errors on hosts that block direct PHP file access.
		//
		// proxy_url: Always included when the standalone proxy file exists (no HTTP cost,
		// just file_exists()). This enables JS to discover standalone on first visit and
		// to detect handler transitions (e.g., Cloudflare removed → standalone fallback).
		// Safe because JS Priority 2 (server hint) short-circuits before Priority 3
		// (proxy_url check) — so proxy_url being present does NOT cause 503s when
		// standalone is unavailable and PHP knows it (handler = 'WordPress').
		if ( Options::get_google_tag_gateway_measurement_path() ) {
			$handler = GTG_Config::get_handler();

			// Only pass handler for standalone/wordpress — never for external or null
			if ( null !== $handler && in_array( $handler, [ 'standalone', 'wordpress' ], true ) ) {
				$data['tag_gateway']['handler'] = $handler;
			}

			// Always include proxy_url when the standalone proxy file exists
			// Enables JS to discover standalone on first visit and handle transitions
			$isolated_url = GTG_Proxy::get_isolated_proxy_url();
			if ( $isolated_url ) {
				$data['tag_gateway']['proxy_url'] = $isolated_url;
			}
		}

		$data['tcf_support'] = Options::is_google_tcf_support_active();

		$data['consent_mode'] = [
				'is_active'          => Options::is_google_consent_mode_active(),
				'wait_for_update'    => 500,
				'ads_data_redaction' => Google_Helpers::get_google_consent_mode_ads_data_redaction_setting(),
				'url_passthrough'    => Google_Helpers::get_google_consent_mode_url_passthrough_setting(),
		];

		if (Options::is_google_enhanced_conversions_active()) {
			$data['enhanced_conversions']['is_active'] = Options::is_google_enhanced_conversions_active();
		}

		return $data;
	}

	private function send_events_with_parent_ids() {

		$events_with_parent_ids = apply_filters_deprecated('wooptpm_send_events_with_parent_ids', [ true ], '1.13.0', 'pmw_send_events_with_parent_ids');
		$events_with_parent_ids = apply_filters_deprecated('wpm_send_events_with_parent_ids', [ $events_with_parent_ids ], '1.31.2', 'pmw_send_events_with_parent_ids');

		/**
		 * Filters Send events with parent ids.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_send_events_with_parent_ids', $events_with_parent_ids);
	}

	private function get_adroll_pixel_data() {
		return [
				'advertiser_id'       => Options::get_adroll_advertiser_id(),
				'pixel_id'            => Options::get_adroll_pixel_id(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('adroll'),
				],
		];
	}

	private function get_linkedin_pixel_data() {
		return [
				'partner_id'          => Options::get_linkedin_partner_id(),
				'conversion_ids'      => Options::get_linkedin_conversion_ids(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('linkedin'),
				],
		];
	}

	private static function get_bing_pixel_data() {
		return [
				'uet_tag_id'           => Options::get_bing_uet_tag_id(),
				'enhanced_conversions' => Options::is_bing_enhanced_conversions_enabled() && wpm_fs()->can_use_premium_code__premium_only(),
				'capi'                 => Options::is_bing_capi_active() && wpm_fs()->can_use_premium_code__premium_only(),
				'dynamic_remarketing'  => [
						'id_type' => Product::get_dyn_r_id_type('bing'),
				],
				'consent_mode'         => [
						'is_active' => Options::is_bing_consent_mode_active(),
				],
		];
	}

	private function get_facebook_pixel_data() {

		$data = [
				'pixel_id'            => Options::get_facebook_pixel_id(),
				'pixel_ids'           => Facebook::get_pixel_ids(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('facebook'),
				],
				'capi'                => Options::is_facebook_capi_active(),
				'advanced_matching'   => Options::is_facebook_capi_advanced_matching_enabled(),
				/**
				 * Allow user to add URL patterns that should not be tracked by the Facebook pixel.
				 *
				 * @since 1.58.5
				 */
				'exclusion_patterns'  => apply_filters('pmw_facebook_tracking_exclusion_patterns', []),
		];

		// The standard fbevents.js URL stays out of the inline data layer, because
		// content-matching script blockers would hold the whole configuration back
		// as a Meta pixel. Only a filtered version or URL is output.
		$data = array_merge($data, Helpers::get_facebook_fbevents_data_layer_overrides());

		// Meta's automatic configuration (autoConfig) is the opt-in for the
		// AutomaticSetup feature bundle of fbevents.js: automatic event
		// detection (InferredEvents), the microdata scraping and enrichment,
		// AutomaticParameters, SmartSetup and Meta's regex and AI matching
		// extensions. Opting out before fbq("init") makes the pixel
		// configuration's own opt-in calls no-ops, because they are issued with
		// the "do not override an opt-out" flag. It does NOT stop the
		// configuration from being fetched, nor the Event Setup Tool rules, the
		// CAPI Gateway (openbridge) or Meta's base automatic advanced matching,
		// which carry their own opt-ins. Off by default, since the bundle also
		// carries future Meta pixel features.
		$auto_config_disabled_pixel_ids = [];

		foreach ($data['pixel_ids'] as $pixel_id) {

			/**
			 * Filters whether Meta's automatic configuration stays enabled for a pixel.
			 *
			 * @since 1.66.1
			 */
			if (!apply_filters('pmw_facebook_auto_config', true, $pixel_id)) {
				$auto_config_disabled_pixel_ids[] = $pixel_id;
			}
		}

		if ($auto_config_disabled_pixel_ids) {
			$data['auto_config_disabled_pixel_ids'] = $auto_config_disabled_pixel_ids;
		}

		/**
		 * Filters Facebook mobile bridge app id.
		 *
		 * @since 1.58.5
		 */
		if (apply_filters('pmw_facebook_mobile_bridge_app_id', null)) {
			/**
			 * Filters Facebook mobile bridge app id.
			 *
			 * @since 1.58.5
			 */
			$data['mobile_bridge_app_id'] = apply_filters('pmw_facebook_mobile_bridge_app_id', null);
		}

		return $data;
	}

	private function get_hotjar_pixel_data() {
		return [
				'site_id' => Options::get_hotjar_site_id(),
		];
	}

	private function get_crazyegg_pixel_data() {
		return [
				'account_number' => Options::get_crazyegg_account_number(),
		];
	}

	private static function get_contentsquare_pixel_data() {
		return [
				'tag_id' => Options::get_contentsquare_tag_id(),
		];
	}

	private static function get_clarity_pixel_data() {
		return [
				'project_id' => Options::get_clarity_project_id(),
		];
	}

	private static function get_groundtruth_pixel_data() {
		return [
				'gtid' => Options::get_groundtruth_gtid(),
		];
	}

	/**
	 * Data layer output for the Rumble Ads pixel.
	 *
	 * @since 1.72.1
	 *
	 * @return array
	 */
	private static function get_rumble_pixel_data() {
		return [
				'tag_id'         => Options::get_rumble_tag_id(),
				'conversion_ids' => Options::get_rumble_conversion_ids(),
		];
	}

	private static function get_criteo_pixel_data() {
		return [
				'account_id'          => (int) Options::get_criteo_account_id(),
				'advanced_matching'   => Options::is_criteo_advanced_matching_enabled(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('criteo'),
				],
		];
	}

	private static function get_nextdoor_pixel_data() {
		return [
				'pixel_id'            => Options::get_nextdoor_pixel_id(),
				'advanced_matching'   => Options::is_nextdoor_advanced_matching_enabled(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('nextdoor'),
				],
		];
	}

	/**
	 * Spotify Ads data layer configuration
	 *
	 * @since 1.69.0
	 */
	private static function get_spotify_pixel_data() {
		return [
				'pixel_id'            => Options::get_spotify_pixel_id(),
				'advanced_matching'   => Options::is_spotify_advanced_matching_enabled(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('spotify'),
				],
		];
	}

	/**
	 * AppLovin data layer configuration
	 *
	 * @since 1.69.3
	 */
	private static function get_applovin_pixel_data() {
		return [
				'event_key'           => Options::get_applovin_event_key(),
				'advanced_matching'   => Options::is_applovin_advanced_matching_enabled(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('applovin'),
				],
		];
	}

	/**
	 * Triple Whale data layer configuration
	 *
	 * The platform (plat) is decided here, once, so the browser never guesses
	 * it: the Triple Pixel treats a missing platform as Shopify.
	 */
	private static function get_triple_whale_pixel_data() {
		return [
				'shop' => Triple_Whale::get_shop(),
				'plat' => Triple_Whale::get_platform(),
		];
	}

	/**
	 * Hyros data layer configuration
	 *
	 * The Universal Script URL is assembled in the browser so that the ref_url
	 * parameter carries the actual page URL, the same way the official Hyros
	 * plugin does it.
	 *
	 * @since 1.63.1
	 *
	 * @return array
	 */
	private static function get_hyros_pixel_data() {
		return [
				'product_hash'    => Options::get_hyros_product_hash(),
				'application_tag' => Options::get_hyros_effective_application_tag(),
		];
	}

	/**
	 * Mixpanel data layer configuration
	 *
	 * The api_host is derived from the configured data residency region, because
	 * Mixpanel does not ingest events that reach the wrong region. The remaining
	 * flags drive the mixpanel.init() config in the browser.
	 *
	 * @since 1.64.1
	 *
	 * @return array
	 */
	private static function get_mixpanel_pixel_data() {
		return [
				'project_token'       => Options::get_mixpanel_project_token(),
				'api_host'            => Options::get_mixpanel_api_host(),
				'session_recording'   => Options::is_mixpanel_session_recording_enabled(),
				'autocapture'         => Options::is_mixpanel_autocapture_enabled(),
				'user_identification' => Options::is_mixpanel_user_identification_enabled(),
				'ingestion_api'       => Options::is_mixpanel_ingestion_api_active(),
		];
	}

	/**
	 * Klaviyo data layer configuration
	 *
	 * The resolved coexistence mode decides which events the browser sends and
	 * whether klaviyo.js is loaded at all. The cart rebuild key is only built
	 * where Started Checkout can fire, since building it walks the cart.
	 *
	 * @since 1.68.0
	 *
	 * @return array
	 */
	private static function get_klaviyo_pixel_data() {

		$mode = Options::get_klaviyo_coexistence_mode();

		$data = [
			'public_api_key'     => Options::get_klaviyo_public_api_key(),
			'mode'               => $mode,
			// Klaviyo files metrics by name and integration. This service tag
			// puts every browser event on the WooCommerce integration's metric,
			// the one Klaviyo's own plugin and order sync write to, so existing
			// flows keep working. The library reads it from here to stay
			// platform-agnostic.
			'metric_service'     => 'woocommerce',
			'identify_customers' => Options::is_klaviyo_customer_identification_enabled(),
			// Purchases are reported server-side in standalone mode with the
			// Events API, and by Klaviyo's own order sync whenever the Klaviyo
			// plugin is installed. The browser never sends them.
			'events_api'         => Options::is_klaviyo_purchase_dispatch_active(),
			'takeover_handles'   => [],
			// The Started Checkout event data in the Klaviyo plugin's own shape,
			// including the abandoned cart rebuild key. Only in takeover mode,
			// where the plugin is present to build it and to restore the cart.
			'started_checkout'   => null,
		];

		if ('takeover' === $mode && class_exists('SweetCode\Pixel_Manager\Pixels\Klaviyo\Klaviyo_Takeover')) {

			$data['takeover_handles'] = Klaviyo_Takeover::SCRIPT_HANDLES;

			if (Environment::is_woocommerce_active() && ( is_cart() || is_checkout() )) {
				$data['started_checkout'] = Klaviyo_Takeover::get_started_checkout_event_data();
			}
		}

		return $data;
	}

	private static function get_outbrain_pixel_data() {
		return [
				'advertiser_id'       => Options::get_outbrain_advertiser_id(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('outbrain'),
				],
				'event_names'         => self::get_outbrain_event_name_mapping(),
		];
	}

	private static function get_outbrain_event_name_mapping() {

		$mapping = [
				'search'         => 'search',
				'view_content'   => 'content_view',
				'add_to_cart'    => 'add_to_cart',
				'start_checkout' => 'checkout',
				'purchase'       => 'purchase',
		];

		/**
		 * Filters Outbrain event name mapping.
		 *
		 * @since 1.58.5
		 */
		return (array) apply_filters('pmw_outbrain_event_name_mapping', $mapping);
	}

	private function get_pinterest_pixel_data() {

		$data = [
				'pixel_id'            => Options::get_pinterest_pixel_id(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('pinterest'),
				],
				'advanced_matching'   => Options::is_pinterest_advanced_matching_active() && wpm_fs()->can_use_premium_code__premium_only(),
		];

		$enhanced_match         = Options::is_pinterest_enhanced_match_enabled() && wpm_fs()->can_use_premium_code__premium_only();
		$enhanced_match         = apply_filters_deprecated('wooptpm_pinterest_enhanced_match', [ $enhanced_match ], '1.13.0', 'wpm_pinterest_enhanced_match');
		$data['enhanced_match'] = apply_filters_deprecated('wpm_pinterest_enhanced_match', [ $enhanced_match ], '1.22.0', null, 'There is now an option in the Pinterest settings to enable/disable enhanced match.');

		return $data;
	}

	private function get_reddit_pixel_data() {
		return [
				'advertiser_id'       => Options::get_reddit_advertiser_id(),
				'advanced_matching'   => Options::is_reddit_advanced_matching_enabled() && wpm_fs()->can_use_premium_code__premium_only(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('reddit'),
				],
		];
	}

	private function get_openai_pixel_data() {
		return [
				'pixel_id'            => Options::get_openai_pixel_id(),
				'advanced_matching'   => Options::is_openai_advanced_matching_enabled() && wpm_fs()->can_use_premium_code__premium_only(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('openai'),
				],
		];
	}

	private function get_snapchat_pixel_data() {
		return [
				'pixel_id'            => Options::get_snapchat_pixel_id(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('snapchat'),
				],
				'advanced_matching'   => Options::is_snapchat_advanced_matching_enabled() && wpm_fs()->can_use_premium_code__premium_only(),
		];
	}

	private static function get_taboola_pixel_data() {
		return [
				'account_id'          => (int) Options::get_taboola_account_id(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('taboola'),
				],
				'event_names'         => self::get_taboola_event_name_mapping(),
		];
	}

	private static function get_taboola_event_name_mapping() {

		$mapping = [
				'search'          => 'search',
				'view_content'    => 'view_content',
				'add_to_wishlist' => 'add_to_wishlist',
				'add_to_cart'     => 'add_to_cart',
				'start_checkout'  => 'start_checkout',
				'purchase'        => 'make_purchase',
		];

		/**
		 * Filters Taboola event name mapping.
		 *
		 * @since 1.58.5
		 */
		return (array) apply_filters('pmw_taboola_event_name_mapping', $mapping);
	}

	private function get_tiktok_pixel_data() {
		return [
				'pixel_id'            => Options::get_tiktok_pixel_id(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('tiktok'),
				],
				'eapi'                => Options::is_tiktok_eapi_active() && wpm_fs()->can_use_premium_code__premium_only(),
				'advanced_matching'   => Options::is_tiktok_advanced_matching_enabled() && wpm_fs()->can_use_premium_code__premium_only(),
		];
	}

	private function get_twitter_pixel_data() {
		return [
				'pixel_id'            => Options::get_twitter_pixel_id(),
				'dynamic_remarketing' => [
						'id_type' => Product::get_dyn_r_id_type('twitter'),
				],
				'event_ids'           => Options::get_twitter_event_ids(),
		];
	}

	private static function get_vwo_pixel_data() {
		return [
				'account_id' => Options::get_vwo_account_id(),
		];
	}

	private static function get_optimizely_pixel_data() {
		return [
				'project_id'      => Options::get_optimizely_project_id(),
				// The browser only loads Optimizely when this flag is present, so a
				// page cached before the precaution (DD-091) cannot load it either.
				'loading_allowed' => Options::is_optimizely_loading_allowed(),
		];
	}

	private static function get_ab_tasty_pixel_data() {
		return [
				'account_id' => Options::get_ab_tasty_account_id(),
		];
	}

	private function add_order_data( $data ) {

		if (!Shop::pmw_is_order_received_page()) {
			return array_merge($data, []);
		}

		if (!Shop::pmw_get_current_order()) {
			return array_merge($data, []);
		}

		// Deposit plugins can land the customer on an order that only collects an
		// instalment for a sale that lives on the parent order, or that re-invoices
		// a sale that was already reported. Report the purchase from the order that
		// represents the sale, or not at all. Because the reported order's ID and key
		// go into the data layer, the duplication prevention marker is written on
		// that order too, which keeps every other instalment page from reporting
		// the same sale again.
		$order = Split_Payments::resolve_order_for_purchase(Shop::pmw_get_current_order());

		if (!$order) {
			return array_merge($data, []);
		}

		if (!Shop::can_order_confirmation_be_processed($order)) {

			// Tell the library why no order data follows when the only reason is
			// the order duplication prevention, so it can log that the purchase was
			// already reported and how to test it again (nodedupe). @since 1.71.1
			if (Shop::is_order_confirmation_suppressed_as_already_fired($order)) {
				$data['order_suppressed'] = 'already_fired';
			}

			return array_merge($data, []);
		}

		return array_merge($data, $this->get_order_data($order));
	}

	/**
	 * Get the shop order data.
	 *
	 * @param $order
	 * @return array
	 */
	private function get_order_data( $order ) {

		$data = [];

		if ($order) {
			$data['order'] = [
					'id'                 => (int) $order->get_id(),
					'number'             => (string) $order->get_order_number(),
					'key'                => (string) $order->get_order_key(),
					'affiliation'        => (string) get_bloginfo('name'),
					'currency'           => (string) Shop::get_order_currency($order),
					'value'              => [
							'marketing' => Shop::get_order_value_total_marketing($order, true),
							'total'     => Shop::get_order_value_total_statistics($order),
							'subtotal'  => Shop::get_order_value_subtotal_statistics($order),
					],
					'discount'           => (float) $order->get_total_discount(),
					'tax'                => (float) $order->get_total_tax(),
					'shipping'           => (float) $order->get_shipping_total(),
					'coupon'             => implode(',', $order->get_coupon_codes()),
					'aw_merchant_id'     => Options::get_google_ads_merchant_id() ? Options::get_google_ads_merchant_id() : '',
					'aw_feed_country'    => (string) Geolocation::get_visitor_country(),
					'aw_feed_language'   => Google_Helpers::get_gmc_language(),
					'new_customer'       => Shop::is_new_customer($order),
					'quantity'           => (int) count(Product::pmw_get_order_items($order)),
					'items'              => Product::get_front_end_order_items($order),
					'customer_id'        => $order->get_customer_id(),
					'user_id'            => $order->get_user_id(),
					'payment_type'       => (string) $order->get_payment_method(),
					'payment_type_title' => (string) $order->get_payment_method_title(),
			];

			// Filter to add custom order parameters
			$custom_parameters = Shop::get_custom_order_parameters($order);
			if (!empty($custom_parameters)) {
				$data['order']['custom_parameters'] = $custom_parameters;
			}

			// The WooCommerce Subscriptions this order created (parent orders only),
			// so pixels can report a new subscription next to the purchase.
			$subscriptions = Shop::get_subscription_ids_for_order($order);
			if (!empty($subscriptions)) {
				$data['order']['subscriptions'] = $subscriptions;
			}

			// Process customer lifetime value
			if (Shop::can_ltv_be_processed_on_order($order)) {

				if (!LTV::are_all_pmw_order_values_set($order)) {
					LTV::calculate_pmw_order_values($order);
				}

				$data['order']['value']['ltv']['marketing'] = (float) LTV::get_marketing_ltv_from_order($order);
				$data['order']['value']['ltv']['total']     = (float) LTV::get_total_ltv_from_order($order);
			}

			// set em (email)
			$data['order']['billing_email']        = trim(strtolower($order->get_billing_email()));
			$data['order']['billing_email_hashed'] = hash('sha256', trim(strtolower($order->get_billing_email())));

			if ($order->get_billing_phone()) {

				$phone = $order->get_billing_phone();
				$phone = Helpers::get_e164_formatted_phone_number($phone, $order->get_billing_country());

				$data['order']['billing_phone'] = $phone;
			}

			if ($order->get_billing_first_name()) {
				$data['order']['billing_first_name'] = trim(strtolower($order->get_billing_first_name()));
			}

			if ($order->get_billing_last_name()) {
				$data['order']['billing_last_name'] = trim(strtolower($order->get_billing_last_name()));
			}

			if ($order->get_billing_city()) {
				$data['order']['billing_city'] = str_replace(' ', '', trim(strtolower($order->get_billing_city())));
			}

			if ($order->get_billing_state()) {
				$data['order']['billing_state'] = trim(strtolower($order->get_billing_state()));
			}

			if ($order->get_billing_postcode()) {
				$data['order']['billing_postcode'] = $order->get_billing_postcode();
			}

			if ($order->get_billing_country()) {
				$data['order']['billing_country'] = trim(strtolower($order->get_billing_country()));
			}

			// Add enhanced conversion data for Google Ads
			if (wpm_fs()->can_use_premium_code__premium_only()) {
				if (Options::is_google_enhanced_conversions_active()) {
					$data['order']['google']['enhanced_conversion_data'] = Google_Helpers::get_google_enhanced_conversion_data($order);
				}
			}

			// Profit and predicted LTV for the Meta Purchase. The same helper
			// feeds the CAPI Purchase, so both copies of the deduplicated pair
			// carry identical values. @since 1.70.1
			if (wpm_fs()->can_use_premium_code__premium_only()) {
				if (Options::is_facebook_active()) {
					$facebook_purchase_custom_data = Facebook_CAPI::get_purchase_value_custom_data($order);

					if (!empty($facebook_purchase_custom_data)) {
						$data['order']['facebook']['purchase_custom_data'] = $facebook_purchase_custom_data;
					}
				}
			}

			// Add custom variables for Google Ads
			if (wpm_fs()->can_use_premium_code__premium_only()) {
				$google_ads_custom_variables = $this->get_google_ads_custom_variables($order);

				if (!empty($google_ads_custom_variables)) {
					$data['order']['google']['ads']['custom_variables'] = $google_ads_custom_variables;
				}
			}

			$data['products'] = $this->get_order_products($order);
		}

		return $data;
	}

	/**
	 * Return an array with custom variables for Google Ads.
	 *
	 * @param $order
	 * @return array
	 *
	 * @since 1.43.5
	 */
	private function get_google_ads_custom_variables( $order ) {
		/**
		 * Filters Google ads order custom variables.
		 *
		 * @since 1.58.5
		 */
		return (array) apply_filters('pmw_google_ads_order_custom_variables', [], Order_Data::unwrap($order));
	}

	private function get_order_products( $order ) {

		$order_products = [];

		foreach ((array) Product::pmw_get_order_items($order) as $order_item) {

			$order_item_data = $order_item->get_data();

			if (0 !== $order_item_data['variation_id']) {
				// add variation

				$order_products[$order_item_data['variation_id']] = $this->get_product_data($order_item_data['variation_id']);
			}

			$order_products[$order_item_data['product_id']] = $this->get_product_data($order_item_data['product_id']);
		}

		return $order_products;
	}

	private function get_product_data( $product_id ) {

		$product = wc_get_product($product_id);

		if (Product::is_not_wc_product($product)) {

			Product::log_problematic_product_id($product_id);
			return [];
		}

		$data = [
				'product_id'          => $product->get_id(),
				'name'                => $product->get_name(),
				'type'                => $product->get_type(),
				'dyn_r_ids'           => Product::get_dyn_r_ids($product),
				'brand'               => (string) Product::get_brand_name($product_id),
				'category'            => (array) Product::get_product_category($product_id),
				'variant_description' => (string) ( $product->get_type() === 'variation' ) ? Product::get_formatted_variant_text($product) : '',
		];

		if ($product->get_type() === 'variation') {
			$parent_product       = wc_get_product($product->get_parent_id());
			$data['brand']        = Product::get_brand_name($parent_product->get_id());
			$data['name_variant'] = $data['name'];
			$data['name']         = $parent_product->get_name();
		}

		return $data;
	}

	private static function inject_pmw_opening() {
		echo PHP_EOL . '<!-- START Pixel Manager for WooCommerce -->' . PHP_EOL;
	}

	public function inject_pmw_closing() {

		if (
				Environment::is_woocommerce_active() &&
				Shop::pmw_is_order_received_page() &&
				Shop::pmw_get_current_order()
		) {
			// Count the order that actually reported the purchase (deposit plugins can
			// land the customer on an instalment order, see Split_Payments).
			$reported_order = Split_Payments::resolve_order_for_purchase(Shop::pmw_get_current_order());

			if ($reported_order) {
				$this->increase_conversion_count_for_ratings($reported_order);
			}
		}

		echo PHP_EOL . '<!-- END Pixel Manager for WooCommerce -->' . PHP_EOL;
	}

	private function increase_conversion_count_for_ratings( $order ) {
		$this->maybe_increase_conversion_count_for_ratings($order, true);
	}

	public function maybe_increase_conversion_count_for_ratings_on_status( $order_id ) {
		if (!function_exists('wc_get_order')) {
			return;
		}

		$order = wc_get_order($order_id);
		$this->maybe_increase_conversion_count_for_ratings($order, false);
	}

	private function maybe_increase_conversion_count_for_ratings( $order, $show_duplicate_notice ) {
		if (!$order) {
			return false;
		}

		if ($this->rating_notice_already_counted($order)) {
			return false;
		}

		if (!Shop::can_order_confirmation_be_processed($order)) {
			if ($show_duplicate_notice) {
				Shop::conversion_pixels_already_fired_html();
			}
			return false;
		}

		$ratings = get_option(PMW_DB_RATINGS);

		if (!is_array($ratings)) {
			$ratings = [];
		}

		if (!isset($ratings['conversions_count'])) {
			$ratings['conversions_count'] = 0;
		}

		$ratings['conversions_count'] = $ratings['conversions_count'] + 1;
		update_option(PMW_DB_RATINGS, $ratings);

		$this->mark_rating_notice_counted($order);

		return true;
	}

	private function rating_notice_already_counted( $order ) {
		return $order->meta_exists('_pmw_rating_notice_counted');
	}

	private function mark_rating_notice_counted( $order ) {
		$order->update_meta_data('_pmw_rating_notice_counted', true);
		$order->save();
	}


	public function ajax_pmw_get_cart_items() {

		Logger::debug('ajax_pmw_get_cart_items()');

		// This endpoint only reads. Keep it out of the session's write path,
		// so it can never revert a cart change a shopper makes while it runs.
		Shop::keep_woocommerce_session_read_only();

		global $woocommerce;

		$cart_items = $woocommerce->cart->get_cart();

		$data = [];

		foreach ($cart_items as $cart_item => $value) {

			// Skip bundle/composite child cart items: the bundle is reported once
			// as its container, priced as the configured sum of container + children.
			if (Product::is_container_child_cart_item($value)) {
				continue;
			}

			$product = wc_get_product($value['data']->get_id());

			if (Product::is_not_wc_product($product)) {

				Product::log_problematic_product_id($value['data']->get_id());
				continue;
			}

			// Container products (bundles/composites) don't expose their assembled
			// price via get_price(); use the configured cart line price instead.
			$container_price = Product::maybe_get_container_cart_item_unit_price($value, $cart_items);

			/**
			 * The cart item key map is also printed inline next to every cart item
			 * (see woocommerce_after_cart_item_name), and the front end merges this
			 * response over those inline entries. Both producers therefore have to
			 * emit product_id and variation_id, which is what
			 * pmw.getProductIdByCartItemKeyUrl reads. Without them a cart sync used
			 * to replace every inline entry with a shape the reader knew nothing
			 * about, and remove_from_cart stopped firing. The id / is_variation /
			 * parent_id keys stay for anything that already reads them. @since 1.67.1
			 */
			$data['cart_item_keys'][$cart_item] = [
					'id'           => (string) $product->get_id(),
					'is_variation' => false,
					'product_id'   => (int) $product->get_id(),
					'variation_id' => 0,
			];

			$data['cart'][$product->get_id()] = [
					'id'           => (string) $product->get_id(),
					'dyn_r_ids'    => Product::get_dyn_r_ids($product),
					'name'         => $product->get_name(),
					//                'list_name'     => '',
					'brand'        => Product::get_brand_name($product->get_id()),
					//                'variant'       => '',
					//                'list_position' => '',
					'quantity'     => (int) $value['quantity'],
					'price'        => null !== $container_price ? $container_price : (float) $product->get_price(),
					'is_variation' => false,
			];

			if ('variation' === $product->get_type()) {

				$parent_product = wc_get_product($product->get_parent_id());

				if ($parent_product) {
					$data['cart'][$product->get_id()]['name']                = $parent_product->get_name();
					$data['cart'][$product->get_id()]['parent_id']           = (string) $parent_product->get_id();
					$data['cart'][$product->get_id()]['parent_id_dyn_r_ids'] = Product::get_dyn_r_ids($parent_product);
					$data['cart'][$product->get_id()]['brand']               = Product::get_brand_name($parent_product->get_id());
				} else {
					Logger::debug('Variation ' . $product->get_id() . ' doesn\'t link to a valid parent product.');
				}

				$data['cart'][$product->get_id()]['is_variation'] = true;
				$data['cart'][$product->get_id()]['category']     = Product::get_product_category($product->get_parent_id());

				$variant_text_array = [];

				$attributes = $product->get_attributes();
				if ($attributes) {
					foreach ($attributes as $key => $value) {

						$key_name             = str_replace('pa_', '', $key);
						$variant_text_array[] = ucfirst($key_name) . ': ' . strtolower($value);
					}
				}

				$data['cart'][$product->get_id()]['variant'] = (string) implode(' | ', $variant_text_array);

				$data['cart_item_keys'][$cart_item]['parent_id']    = (string) $product->get_parent_id();
				$data['cart_item_keys'][$cart_item]['is_variation'] = true;
				$data['cart_item_keys'][$cart_item]['product_id']   = (int) $product->get_parent_id();
				$data['cart_item_keys'][$cart_item]['variation_id'] = (int) $product->get_id();

			} else {
				$data['cart'][$product->get_id()]['category'] = Product::get_product_category($product->get_id());
			}
		}

		wp_send_json_success($data);
	}

	public function ajax_pmw_get_product_ids() {

		// This endpoint only reads. Keep it out of the session's write path,
		// so it can never revert a cart change a shopper makes while it runs.
		Shop::keep_woocommerce_session_read_only();

		$data = Helpers::get_input_vars(INPUT_POST);

		// Change product_ids back into an array
		$data['product_ids'] = explode(',', $data['product_ids']);

		$this->get_products_for_datalayer($data);
	}

	public function get_products_for_datalayer_by_product_ids( $product_ids ) {

		$products = [];

		foreach ($product_ids as $key => $product_id) {

			// validate if a valid product ID has been passed in the array
			if (!ctype_digit((string) $product_id)) {
				continue;
			}

			$product = wc_get_product($product_id);

			if (Product::is_not_wc_product($product)) {
				continue;
			}

			// Only expose published products
			if ('publish' !== $product->get_status()) {
				continue;
			}

			$products[$product_id] = Product::get_product_details_for_datalayer($product);
		}

		return $products;
	}

	public function ajax_purchase_pixels_fired_handler() {

		// This endpoint only reads. Keep it out of the session's write path,
		// so it can never revert a cart change a shopper makes while it runs.
		Shop::keep_woocommerce_session_read_only();

		$_post = Helpers::get_input_vars(INPUT_POST);

		// Don't use the nonce check from the admin class, because some plugin users have even partial purchase confirmation pages cached,
		// which means the nonce will be invalid.
//      if (!wp_verify_nonce($_post['nonce_ajax'], 'nonce-pmw-ajax')) {
//          wp_send_json_error('Invalid nonce');
//      }

		self::process_conversion_pixel_status(
			isset($_post['order_id']) ? $_post['order_id'] : null,
			isset($_post['order_key']) ? $_post['order_key'] : null,
			isset($_post['source']) ? $_post['source'] : null
		);
	}

	/**
	 * The triggers our browser bundle reports. The value is stored on the order
	 * and picks the accuracy column, so anything else is refused. @since 1.69.1
	 *
	 * @var string[]
	 */
	private static $conversion_pixel_sources = [ 'thankyou_page', 'acr_full_auto', 'acr_attempted' ];

	private static function process_conversion_pixel_status( $order_id, $order_key, $order_source ) {

		if (
				!$order_id
				|| !$order_key
				|| !$order_source
		) {
			wp_send_json_error('Invalid data. Missing one or several of order_id, order_key or source.');
		}

		if (!is_string($order_source) || !in_array($order_source, self::$conversion_pixel_sources, true)) {
			wp_send_json_error('Invalid source');
		}

		$order = wc_get_order($order_id);

		if (!$order) {
			wp_send_json_error('Invalid order ID');
		}

		if (!is_string($order_key) || !hash_equals((string) $order->get_order_key(), $order_key)) {
			wp_send_json_error('Invalid order key or wrong order ID');
		}

		self::save_conversion_pixels_fired_status($order, $order_source);

		wp_send_json_success('Successfully saved the order status.');
	}

	public static function save_conversion_pixels_fired_status( $order, $source = 'thankyou_page' ) {

		// Serialized per order, so two confirmations arriving together cannot
		// both pass the latch below and count the order twice. @since 1.71.1
		self::with_tracking_accuracy_lock($order, function ( $order ) use ( $source ) {
			self::record_conversion_pixels_fired($order, $source);
		});
	}

	/**
	 * The body of save_conversion_pixels_fired_status(). Callers must hold the
	 * tracking accuracy lock for this order.
	 *
	 * @param \WC_Order $order
	 * @param string    $source
	 *
	 * @return void
	 * @since 1.71.1
	 */
	private static function record_conversion_pixels_fired( $order, $source ) {

		// Guard against double pixel-fire incrementing
		$already_fired = $order->meta_exists('_wpm_conversion_pixel_fired');

		$order->update_meta_data('_wpm_conversion_pixel_trigger', $source);
		$order->update_meta_data('_wpm_conversion_pixel_fired', true);

		// Get the time between when the order was created and now and save it in _wpm_conversion_pixel_fired_delay
		$time_diff = time() - strtotime($order->get_date_created());
		$order->update_meta_data('_wpm_conversion_pixel_fired_delay', $time_diff);

		/**
		 * Record that the GA4 purchase was sent from the browser.
		 *
		 * The browser sends the GA4 purchase only while the Measurement Protocol
		 * is inactive (the adapter suppresses it when mp_active is true). Marking
		 * the order here lets the MP purchase gate recognize orders that were
		 * already tracked browser-side, so switching the MP API secret off and on
		 * again no longer resends them.
		 *
		 * @since 1.63.1
		 */
		if (Shop::should_record_ga4_browser_purchase()) {
			$order->update_meta_data(Shop::get_ga4_browser_purchase_key(), true);
		}

		$order->save();

		// This order just left the "pixels not fired" set, so drop the cached
		// count behind the order-list view link. @since 1.63.1
		if (!$already_fired) {
			delete_transient(Order_Columns::COUNT_TRANSIENT);
		}

		// First-run onboarding: record the very first tracked order once
		// (single get_option() guard in the steady state).
		First_Event_Confirmation::record_first_tracked_order($order->get_id());

		// Orders excluded from the accuracy denominator must also stay out of the
		// numerator, otherwise measured could exceed total for a bucket (e.g. a
		// pay-for-order link on an admin-created order reaching the confirmation page).
		// That includes orders without _wpm_process_through_wpm, which the total
		// counter refuses. @since 1.71.1
		if (
			!$already_fired
			&& $order->meta_exists('_wpm_process_through_wpm')
			&& Shop::should_count_order_for_tracking_accuracy($order)
		) {
			$payment_method = $order->get_payment_method();
			if (!empty($payment_method)) {
				$date_created = $order->get_date_created();
				if ($date_created) {
					$date = gmdate('Y-m-d', $date_created->getTimestamp());

					// Ensure orders_total is bucketed against the same final gateway before
					// recording orders_measured. Idempotent — counts at most once per order.
					// Covers gateways whose status-transition hook may not have fired yet
					// (e.g. delayed webhook/IPN), guaranteeing measured ≤ total per bucket.
					// @since 1.58.10
					self::count_order_total($order);

					self::move_order_total_to_gateway($order, $date, $payment_method);

					Tracking_Accuracy_DB::increment_orders_measured(
						$date,
						$payment_method,
						$source,
						$time_diff
					);
				}
			}
		}
	}

	/**
	 * Move the order's counted total to the gateway the order has now.
	 *
	 * The total is counted under the gateway the order has when payment is
	 * finalized, the tracked count under the one it has when the confirmation
	 * page reports. A gateway that changes payment_method in between (one
	 * payment plugin offering card, wallet and bank payments, for example)
	 * left the total in one row and the tracked count in another, so one
	 * gateway read above 100% and the other read low.
	 *
	 * Orders counted before 1.71.1 carry no stored gateway and stay where
	 * they are.
	 *
	 * @param \WC_Order $order          The order, its total already counted.
	 * @param string    $date           Order creation date in Y-m-d format.
	 * @param string    $payment_method The order's current payment method.
	 *
	 * @return void
	 * @since 1.71.1
	 */
	private static function move_order_total_to_gateway( $order, $date, $payment_method ) {

		$counted_gateway = (string) $order->get_meta('_pmw_orders_total_gateway');

		if ('' === $counted_gateway || $counted_gateway === $payment_method) {
			return;
		}

		Tracking_Accuracy_DB::move_orders_total($date, $counted_gateway, $payment_method);

		Logger::debug('Tracking accuracy: order ' . $order->get_id() . ' changed payment method from ' . $counted_gateway . ' to ' . $payment_method . ' after its total was counted, moved the total');

		$order->update_meta_data('_pmw_orders_total_gateway', $payment_method);
		$order->save();
	}

	public function front_end_scripts() {

		$pmw_dependencies = [
				'jquery',
				'wp-hooks',
		];

		// Pick the entry script from the same tier directory the dynamically
		// imported chunks are served from. Both must agree, otherwise the
		// webpack runtime in the entry script requests chunks with hashes that
		// don't exist in the other tier's directory and every dynamic import 404s.
		//
		// @since 1.58.10
		$tier = Helpers::get_active_assets_tier();

		if ('pro' === $tier) {

			wp_enqueue_script(
					'pmw',
					PMW_PLUGIN_DIR_PATH . 'js/public/pro/pmw-public__premium_only' . $this->get_preset_version() . '.min.js',
					$pmw_dependencies,
					PMW_CURRENT_VERSION,
					$this->move_pmw_script_to_footer()
			);

			if (Helpers::lazy_load_pmw__premium_only()) {
				wp_enqueue_script(
						'pmw-lazy',
						PMW_PLUGIN_DIR_PATH . 'js/public/pro/pmw-lazy__premium_only.js',
						[ 'pmw' ],
						PMW_CURRENT_VERSION,
						$this->move_pmw_script_to_footer()
				);
			}

		} else {

			wp_enqueue_script(
					'pmw',
					PMW_PLUGIN_DIR_PATH . 'js/public/free/pmw-public.p1.min.js',
					$pmw_dependencies,
					PMW_CURRENT_VERSION,
					$this->move_pmw_script_to_footer()
			);
		}

		// The library's configuration. Merged into window.pmw instead of the
		// `var pmw = {...}` that wp_localize_script prints, and carrying the same
		// exclusion attributes as the data layer script (see the filter below).
		//
		// The var form replaces window.pmw wholesale. A consent tool in
		// auto-blocking mode (Cookiebot) or a JavaScript optimizer can hold that
		// line back and run it after the library script, or run it a second
		// time, and every function the library had attached to window.pmw was
		// gone from that moment on: the shop lost its add-to-cart, product click
		// and checkout tracking for that visitor, silently (support #6960). A
		// merge is harmless no matter when or how often it runs, and the
		// attributes keep it from being held back in the first place.
		//
		// @since 1.67.1
		wp_add_inline_script(
				'pmw',
				'window.pmw = Object.assign(window.pmw || {}, ' . Helpers::json_encode_for_script(
						[
								'ajax_url'      => admin_url('admin-ajax.php'),
								'root'          => esc_url_raw(rest_url()),
								'nonce_wp_rest' => wp_create_nonce('wp_rest'),
								'nonce_ajax'    => wp_create_nonce('nonce-pmw-ajax'),
						]
				) . ');',
				'before'
		);

		add_filter('wp_inline_script_attributes', [ $this, 'configuration_script_attributes' ], 10, 2);
	}

	/**
	 * Give the library's configuration script the same exclusion attributes
	 * as the data layer script.
	 *
	 * WordPress prints the inline script registered above with the id
	 * pmw-js-before. Without the attributes, Cookiebot's auto-blocking mode
	 * held it back together with jQuery while the library script itself, which
	 * shops mark as data-cookieconsent="ignore" on Cookiebot's advice, ran
	 * first; the held-back configuration then ran a second later.
	 *
	 * @since 1.67.1
	 *
	 * @param array  $attributes Key-value pairs of the script tag attributes.
	 * @param string $data       The inline script's JavaScript.
	 * @return array
	 */
	public function configuration_script_attributes( $attributes, $data ) {

		if (!isset($attributes['id']) || 'pmw-js-before' !== $attributes['id']) {
			return $attributes;
		}

		foreach (Helpers::get_opening_script_attributes() as $attribute => $values) {
			$attributes[$attribute] = implode(' ', $values);
		}

		return $attributes;
	}

	public function front_end_styles_elementor_fix() {

		wp_enqueue_style(
				'pmw-public-elementor-fix',
				PMW_PLUGIN_DIR_PATH . 'css/public/elementor-fix.css',
				[],
				PMW_CURRENT_VERSION
		);
	}

	private function move_pmw_script_to_footer() {

		$move_pmw_script_to_footer_active = apply_filters_deprecated('wpm_experimental_move_wpm_script_to_footer', [ false ], '1.31.2', 'pmw_experimental_move_pmw_script_to_footer');

		/**
		 * This filter moves the PMW script to the footer.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_experimental_move_pmw_script_to_footer', $move_pmw_script_to_footer_active);
	}

	private function get_preset_version() {

		$version = apply_filters_deprecated('wpm_script_optimization_preset_version', [ 1 ], '1.31.2', 'pmw_script_optimization_preset_version');

		/**
		 * Filters Script optimization preset version.
		 *
		 * @since 1.31.2
		 */
		return '.p' . apply_filters('pmw_script_optimization_preset_version', $version);
	}

	public function inject_order_received_page_dedupe( $order, $order_total, $is_new_customer ) {
		// nothing to do
	}

	private static function inject_body_pixels() {
//        do something
	}

	private function get_shop_data() {

		$data = [];

		if (is_product_category()) {
			$data['list_name'] = 'Product Category' . Shop::get_list_name_suffix();
			$data['list_id']   = 'product_category' . Shop::get_list_id_suffix();
			$data['page_type'] = 'product_category';
		} elseif (is_product_tag()) {
			$data['list_name'] = 'Product Tag' . Shop::get_list_name_suffix();
			$data['list_id']   = 'product_tag' . Shop::get_list_id_suffix();
			$data['page_type'] = 'product_tag';
		} elseif (is_search()) {
			$data['list_name'] = 'Product Search';
			$data['list_id']   = 'search';
			$data['page_type'] = 'search';
		} elseif (is_shop()) {
			$data['list_name'] = 'Shop | page number: ' . $this->get_page_number();
			$data['list_id']   = 'product_shop_page_number_' . $this->get_page_number();
			$data['page_type'] = 'product_shop';
		} elseif (is_product()) {
			$data['list_name']    = 'Product | ' . Shop::pmw_get_the_title();
			$data['list_id']      = 'product_' . sanitize_title(get_the_title());
			$data['page_type']    = 'product';
			$product              = wc_get_product();
			$data['product_type'] = $product->get_type();
		} elseif (is_front_page()) {
			$data['list_name'] = 'Front Page';
			$data['list_id']   = 'front_page';
			$data['page_type'] = 'front_page';
		} elseif (Shop::pmw_is_order_received_page()) {
			$data['list_name'] = 'Order Received Page';
			$data['list_id']   = 'order_received_page';
			$data['page_type'] = 'order_received_page';
		} elseif (Shop::pmw_is_cart_page()) {
			$data['list_name'] = 'Cart';
			$data['list_id']   = 'cart';
			$data['page_type'] = 'cart';
		} elseif (is_checkout()) {
			$data['list_name'] = 'Checkout Page';
			$data['list_id']   = 'checkout';
			$data['page_type'] = 'checkout';
		} elseif (is_page()) {
			$data['list_name'] = 'Page | ' . Shop::pmw_get_the_title();
			$data['list_id']   = 'page_' . sanitize_title(get_the_title());
			$data['page_type'] = 'page';
		} elseif (is_home()) {
			$data['list_name'] = 'Blog Home';
			$data['list_id']   = 'blog_home';
			$data['page_type'] = 'blog_post';
		} elseif ('post' === get_post_type()) {
			$data['list_name'] = 'Blog Post | ' . Shop::pmw_get_the_title();
			$data['list_id']   = 'blog_post_' . sanitize_title(get_the_title());
			$data['page_type'] = 'blog_post';
		} else {
			$data['list_name'] = '';
			$data['list_id']   = '';
			$data['page_type'] = '';
		}

		$data['currency'] = get_woocommerce_currency();

		$data['selectors'] = [
				/**
				 * Filters Add selectors add to cart.
				 *
				 * @since 1.58.5
				 */
				'addToCart'     => (array) apply_filters('pmw_add_selectors_add_to_cart', []),
				/**
				 * Filters Add selectors begin checkout.
				 *
				 * @since 1.58.5
				 */
				'beginCheckout' => (array) apply_filters('pmw_add_selectors_begin_checkout', []),
		];

		// The active shop platform (docs/PLATFORM-CONTRACT.md). The tracking
		// library and its harnesses branch on this, never on plugin checks.
		$data['platform'] = Platform_Manager::get_provider()->get_name();

		$data['order_duplication_prevention'] = Shop::is_order_duplication_prevention_active();
		$data['view_item_list_trigger']       = Shop::view_item_list_trigger_settings();
		$data['variations_output']            = Options::is_shop_variations_output_active();

		/**
		 * Fire a view_item event with the parent product on a variable product
		 * page, on page load.
		 *
		 * With Variations Output enabled the Pixel Manager fires no view_item at
		 * all on a variable product page until the visitor picks a variation: for
		 * dynamic remarketing the reported ID has to match an item in the
		 * uploaded catalog, and that catalog holds the variations, not the parent.
		 * WooCommerce preselects no variation out of the box, so on those shops
		 * the product page view goes unreported altogether and the visitor joins
		 * no remarketing audience for that product.
		 *
		 * Off by default, because a parent ID the catalog does not contain makes
		 * the ad platforms report an unmatched item. A shop whose feed carries
		 * parent products can switch it on and keep variation level reporting
		 * everywhere else; the variation's own view_item still follows once a
		 * variation is selected. The product ID is passed so the decision can be
		 * made per product.
		 *
		 * Replaces the jQuery pmwLoad snippet the Tips & Tricks page used to
		 * document, which broke whenever the tracking library was restructured.
		 *
		 * @since 1.66.1
		 */
		$is_variable_product_page = 'product' === $data['page_type']
			&& isset($data['product_type'])
			&& 'variable' === $data['product_type'];

		$fire_parent_view_item = false;

		if ($is_variable_product_page) {
			/**
			 * Filters whether a variable product page fires a parent view_item.
			 *
			 * @since 1.66.1
			 */
			$fire_parent_view_item = true === apply_filters('pmw_fire_parent_view_item_on_variable_products', false, get_the_id());
		}

		$data['parent_view_item_on_variable_products'] = $fire_parent_view_item;

		/**
		 * Automatically fire the begin_checkout event when the checkout page loads
		 * with a non-empty cart and no begin_checkout has fired for that cart yet.
		 *
		 * Covers flows that reach the checkout page without a "proceed to checkout"
		 * button click: funnel builders (such as CartFlows next-step buttons that add
		 * the product server-side), buy-now buttons, direct checkout links, and
		 * block-based carts whose checkout links don't match the click selectors.
		 *
		 * @since 1.62.1
		 */
		$begin_checkout_on_page_load = true === apply_filters('pmw_fire_begin_checkout_on_checkout_page', true);

		// Not on the order-pay endpoint: is_checkout() is true there too, but that
		// page retries payment for an existing order, and any cart the visitor
		// happens to carry is unrelated to it.
		$data['begin_checkout_on_checkout_page'] = $begin_checkout_on_page_load && !is_wc_endpoint_url('order-pay');

		$data['session_active'] = Shop::is_woocommerce_session_active();

		return $data;
	}

	private static function get_page_data() {
		$data = [];

		$data['id']         = get_the_ID();
		$data['title']      = get_the_title();
		$data['type']       = get_post_type();
		$data['categories'] = get_the_category();
//      $data['template']   = get_page_template_slug();

		$parent_id = wp_get_post_parent_id($data['id']);
		// Parent
		$data['parent'] = [
				'id'         => $parent_id,
				'title'      => get_the_title($parent_id),
				'type'       => get_post_type($parent_id),
				'categories' => get_the_category($parent_id),
		];

		return $data;
	}

	private function get_page_number() {
		return ( get_query_var('paged') ) ? get_query_var('paged') : 1;
	}

	private function get_general_data() {

		$data = [
				'user_logged_in'             => is_user_logged_in(),
				'scroll_tracking_thresholds' => Options::get_scroll_tracking_thresholds(),
				'page_id'                    => get_the_ID(),
				/**
				 * Exclude domains, such as gtm-msr.appspot.com from being tracked and reported.
				 *
				 * @since 1.58.5
				 */
				'exclude_domains'            => apply_filters('pmw_exclude_domains_from_tracking', []),
				'server_2_server'            => [
						'active'                      => Options::server_2_server_enabled(),
						// Always skip empty S2S events (no destination platforms in payload).
						// The UI setting was removed because the SSP doesn't currently offer further
						// processing of empty events. When the SSP gains that capability, re-add
						// the setting via Options::is_skip_empty_s2s_events_active().
						// See class-options.php and class-admin.php git history (removed in 1.57.1).
						'skip_empty_events'           => true,
						'always_send_s2s'             => Options::is_always_send_s2s_active(),
						/**
						 * Exclude user agents from being accepted for server-to-server events.
						 *
						 * @since 1.58.5
						 */
						'user_agent_exclude_patterns' => apply_filters('pmw_exclude_user_agents_from_server_2_server_events', []),
						// IP exclusion list — uses the unified filter (with backward compat)
						'ip_exclude_list'             => Geolocation::get_ip_exclusion_list(),
						'pageview_event_s2s'          => [
								'is_active' => Options::is_pageview_events_s2s_active() && Options::server_2_server_enabled(),
								'pixels'    => Options::pixels_that_require_s2s_pageview_events(),
						],
				],
				'ssp'                        => self::get_ssp_data_layer_config(),
				'consent_management'         => [
						'explicit_consent' => Options::is_consent_management_explicit_consent_active(),
				],
				'lazy_load_pmw'              => Options::is_lazy_load_pmw_active(),
				'chunk_base_path'            => self::get_chunk_base_path(),
				'modules'                    => self::get_modules_config(),

				//          'logger'                   => [
				//              'is_active' => Options::is_logging_enabled(),
				//              'log_level' => Options::get_log_level(),
				//          ],
		];

		if (Options::are_restricted_consent_regions_set()) {
			$data['consent_management']['restricted_regions'] = Options::get_restricted_consent_regions();
		}

		/**
		 * The consent model of the detected CMPs, where it is the same for every
		 * visitor. The browser applies it as the CMP default in implicit consent
		 * mode until the CMP reports a decision. Explicit consent mode denies by
		 * itself and never reads it.
		 *
		 * @since 1.69.3
		 */
		if (!Options::is_consent_management_explicit_consent_active()) {

			$cmp_hints = Environment::get_cmp_consent_hints();

			if (!empty($cmp_hints)) {
				$data['consent_management']['cmp_hints'] = $cmp_hints;
			}
		}

		if (wpm_fs()->can_use_premium_code__premium_only()) {
			// The click ID keys of the platforms configured on this shop. The
			// browser persists ONLY these into the first-party fallback
			// cookie: a click ID is personal data, and a platform without a
			// destination here gets nothing stored.
			$data['click_id_keys'] = Click_Ids::get_active_click_id_keys();
		}

		// First-run onboarding: ask the storefront for a one-shot "pixels are
		// live" report. Only injected on fresh installs until the first
		// confirmation lands, then never again.
		if (First_Event_Confirmation::is_beacon_needed()) {
			$data['first_event_confirmation'] = true;
		}

		return $data;
	}

	/**
	 * Build the SSP data layer config, accounting for additional domains.
	 *
	 * If the current request is served on an additional SSP domain (registered
	 * via the pmw_ssp_additional_domains filter), the events URL and domain
	 * token are swapped to that domain's values.
	 *
	 * @return array SSP config for the pmwDataLayer.
	 * @since 1.57.1
	 */
	private static function get_ssp_data_layer_config() {

		$config = [
			'active'         => Options::is_ssp_active(),
			'events_url'     => Options::get_ssp_events_url(),
			'fallback_to_wc' => Options::get_ssp_proxy_failure_behavior() === 'fallback_to_wc',
			'domain_token'   => Options::get_ssp_domain_token(),
			'session_id'     => Options::get_ssp_session_id(),
			'quota_exceeded' => Options::is_ssp_quota_exceeded(),
		];

		// Check if the current request matches an additional SSP domain
		$additional_domain = Options::get_matching_ssp_additional_domain();

		if ( $additional_domain ) {
			$config['events_url']   = 'https://' . $additional_domain['proxy_hostname'] . '/v1/pmw-events';
			$config['domain_token'] = Options::get_ssp_additional_domain_domain_token( $additional_domain['proxy_hostname'] );
		}

		return $config;
	}

	/**
	 * Retrieves the configuration for optional JavaScript modules.
	 *
	 * This method centralizes the configuration for dynamically loaded JavaScript chunks
	 * that can be toggled on/off by the user. Each module corresponds to a webpack chunk
	 * that will only be loaded if its flag is true.
	 *
	 * When adding a new toggleable module:
	 * 1. Add a default option in Options::get_default_options() under general->modules
	 * 2. Add a helper method in Options class (e.g., should_load_module_name())
	 * 3. Add the flag here in get_modules_config()
	 * 4. Add conditional loading in main.js based on pmwDataLayer.general.modules.module_name
	 * 5. Add admin UI toggle in Admin::add_section_advanced_subsection_general()
	 *
	 * @return array Associative array of module names and their enabled/disabled status.
	 * @since 1.51.0
	 */
	private static function get_modules_config() {
		return [
			'load_deprecated_functions' => Options::should_load_deprecated_functions(),
		];
	}

	/**
	 * Retrieves the base path for the chunk files for the active assets tier.
	 *
	 * Delegates the tier decision to Helpers::get_active_assets_tier() so the
	 * webpack chunk base path always matches the directory the entry script was
	 * enqueued from in front_end_scripts(). If these two ever drift apart, the
	 * entry script's webpack runtime requests chunks with hashes that don't
	 * exist in the other tier's directory and dynamic imports 404.
	 *
	 * @return string The base path for chunk files, either in the 'free' or 'pro' folder.
	 *
	 * @since 1.51.1
	 * @since 1.58.10 Use Helpers::get_active_assets_tier() to keep the entry
	 *                script and chunk path in sync on license downgrade.
	 */
	private static function get_chunk_base_path() {

		return PMW_PLUGIN_DIR_PATH . 'js/public/' . Helpers::get_active_assets_tier() . '/';
	}

	/**
	 * Set a flag on the user meta when an account is created.
	 * This flag is consumed in get_data_for_data_layer() to inject
	 * account_just_created into the data layer for front-end tracking.
	 *
	 * @param int $customer_id The newly created customer ID.
	 *
	 * @since 1.56.1
	 */
	public function set_account_created_flag__premium_only( $customer_id ) {
		update_user_meta($customer_id, '_pmw_account_just_created', true);
	}
}

