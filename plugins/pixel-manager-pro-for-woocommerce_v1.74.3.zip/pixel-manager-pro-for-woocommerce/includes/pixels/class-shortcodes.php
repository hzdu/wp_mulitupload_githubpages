<?php

namespace SweetCode\Pixel_Manager\Pixels;

use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Pixels\Facebook\Facebook;
use SweetCode\Pixel_Manager\Product;

defined('ABSPATH') || exit; // Exit if accessed directly

class Shortcodes {

	private static $did_init = false;

	public static function init() {

		// If already initialized, do nothing
		if (self::$did_init) {
			return;
		}

		self::$did_init = true;

		add_shortcode('view-item', [ __CLASS__, 'view_item' ]);
		add_shortcode('conversion-pixel', [ __CLASS__, 'conversion_pixel' ]);
	}

	public function __construct() {
		self::init();
	}

	/**
	 * The view-item shortcode fires all enabled pixels with their own view-item event,
	 * including all product information.
	 * The shortcode is necessary on custom-made product pages where WooCommerce can't detect that it is a product page
	 * and therefore the Pixel Manager can't automatically inject the necessary scripts for the view-item event.
	 */
	public static function view_item( $attributes ) {

		self::init();

		$shortcode_attributes = shortcode_atts(
			[ 'product-id' => null ],
			$attributes
		);

		if ($shortcode_attributes['product-id']) {

			$product = wc_get_product($shortcode_attributes['product-id']);

			if (Product::is_not_wc_product($product)) {
				Logger::debug('get_product_data_layer_script received an invalid product');
				return;
			}

			Product::print_product_data_layer_script($product, false, false);

			?>

			<script>
				jQuery(document).on("pmw:ready", function () {
					jQuery(document).trigger("pmw:view-item", pmw.getProductDetailsFormattedForEvent(<?php echo intval($shortcode_attributes['product-id']); ?>));
				});
			</script>
			<?php
		}
	}

	public static function conversion_pixel( $attributes ) {

		self::init();

		self::function_exists_script();

		$pairs = [
			'pixel'                 => 'all',
			'gads-conversion-id'    => Options::get_google_ads_conversion_id(),
			'gads-conversion-label' => '',
			'lintrk-event'          => null,
			'meta-event'            => 'Lead',
			'twc-event'             => 'CompleteRegistration',
			'pinc-event'            => 'lead',
			'pinc-lead-type'        => '',
			'ms-ads-event'          => 'submit',
			'ms-ads-event-category' => '',
			'ms-ads-event-label'    => 'lead',
			'ms-ads-event-value'    => 0,
			'outbrain-event'        => '',
			'reddit-event'          => 'Lead',
			'rumble-event'          => '',
			'openai-event'          => 'lead_created',
			'snap-event'            => 'SIGN_UP',
			'spotify-event'         => 'lead',
			'spotify-lead-type'     => '',
			'spotify-lead-category' => '',
			'applovin-event'        => 'generate_lead',
			'applovin-value'        => 0,
			'taboola-event'         => '',
			'tiktok-event'          => 'SubmitForm',
			'contentsquare-event'   => '',
			'mixpanel-event'        => 'Lead Submitted',
			'klaviyo-event'         => 'Submitted Lead',
		];

		$shortcode_attributes = shortcode_atts($pairs, $attributes);

		// If $attributes['fbq-event'] is set, overwrite $attributes['meta-event'] with $attributes['fbq-event']
		// This is to maintain backwards compatibility with the old shortcode
		if (isset($attributes['fbq-event'])) {
			$shortcode_attributes['meta-event'] = $attributes['fbq-event'];
		}

		if (isset($attributes['fbc-event'])) {
			$shortcode_attributes['meta-event'] = $attributes['fbc-event'];
		}

		self::output_tracking_scripts($shortcode_attributes);
	}

	private static function output_tracking_scripts( $shortcode_attributes ) {

		// Google Ads
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'google-ads')
			&& Options::is_google_ads_active()
		) {
			self::conversion_html_google_ads($shortcode_attributes);
		}

		// LinkedIn
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'linkedin')
			&& Options::is_linkedin_active()
		) {
			self::conversion_html_linkedin($shortcode_attributes);
		}

		// Rumble Ads
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'rumble')
			&& Options::is_rumble_active()
		) {
			self::conversion_html_rumble($shortcode_attributes);
		}

		// Meta (Facebook)
		if (
			(
				self::should_tracking_event_be_injected($shortcode_attributes, 'facebook')
				|| self::should_tracking_event_be_injected($shortcode_attributes, 'meta')
			)
			&& Options::is_facebook_active()
		) {
			self::conversion_html_facebook($shortcode_attributes);
		}

		// Microsoft Ads
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'ms-ads')
			&& Options::is_bing_active()
		) {
			self::conversion_html_microsoft_ads($shortcode_attributes);
		}

		// Outbrain
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'outbrain')
			&& Options::is_outbrain_active()
		) {
			self::conversion_html_outbrain($shortcode_attributes);
		}

		// Pinterest
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'pinterest')
			&& Options::is_pinterest_active()
		) {
			self::conversion_html_pinterest($shortcode_attributes);
		}

		// Reddit
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'reddit')
			&& Options::is_reddit_active()
		) {
			self::conversion_html_reddit_ads($shortcode_attributes);
		}

		// OpenAI
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'openai')
			&& Options::is_openai_active()
		) {
			self::conversion_html_openai($shortcode_attributes);
		}

		// Snapchat
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'snapchat')
			&& Options::is_snapchat_active()
		) {
			self::conversion_html_snapchat($shortcode_attributes);
		}

		// Spotify Ads (Premium only)
		if (
			wpm_fs()->can_use_premium_code__premium_only()
			&& self::should_tracking_event_be_injected($shortcode_attributes, 'spotify')
			&& Options::is_spotify_active()
		) {
			self::conversion_html_spotify($shortcode_attributes);
		}

		// AppLovin (Premium only)
		if (
			wpm_fs()->can_use_premium_code__premium_only()
			&& self::should_tracking_event_be_injected($shortcode_attributes, 'applovin')
			&& Options::is_applovin_active()
		) {
			self::conversion_html_applovin($shortcode_attributes);
		}

		// Taboola
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'taboola')
			&& Options::is_taboola_active()
		) {
			self::conversion_html_taboola($shortcode_attributes);
		}

		// TikTok
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'tiktok')
			&& Options::is_tiktok_active()
		) {
			self::conversion_html_tiktok($shortcode_attributes);
		}

		// Twitter
		if (
			self::should_tracking_event_be_injected($shortcode_attributes, 'twitter')
			&& Options::is_twitter_active()
		) {
			self::conversion_html_twitter($shortcode_attributes);
		}

		// Contentsquare (Premium only)
		if (
			wpm_fs()->can_use_premium_code__premium_only()
			&& self::should_tracking_event_be_injected($shortcode_attributes, 'contentsquare')
			&& Options::is_contentsquare_active()
		) {
			self::conversion_html_contentsquare($shortcode_attributes);
		}

		// Mixpanel (Premium only)
		if (
			wpm_fs()->can_use_premium_code__premium_only()
			&& self::should_tracking_event_be_injected($shortcode_attributes, 'mixpanel')
			&& Options::is_mixpanel_active()
		) {
			self::conversion_html_mixpanel($shortcode_attributes);
		}

		// Klaviyo (Premium only)
		if (
			wpm_fs()->can_use_premium_code__premium_only()
			&& self::should_tracking_event_be_injected($shortcode_attributes, 'klaviyo')
			&& Options::is_klaviyo_active()
			&& 'off' !== Options::get_klaviyo_coexistence_mode()
		) {
			self::conversion_html_klaviyo($shortcode_attributes);
		}
	}

	private static function should_tracking_event_be_injected( $shortcode_attributes, $pixel_id = null ) {

		if ('all' === $shortcode_attributes['pixel']) {
			return true;
		}

		if ($pixel_id === $shortcode_attributes['pixel']) {
			return true;
		}

		return false;
	}

	private static function conversion_html_snapchat( $shortcode_attributes ) {

		?>

		<script>
			pmwFunctionExists("snaptr").then(function () {
					snaptr("track", "<?php echo esc_js($shortcode_attributes['snap-event']); ?>");
				},
			);
		</script>
		<?php
	}

	private static function conversion_html_contentsquare( $shortcode_attributes ) {

		if (empty($shortcode_attributes['contentsquare-event'])) {
			return;
		}

		?>

		<script>
			jQuery(document).on("pmw:ready", function () {
				if (typeof window._uxa !== "undefined") {
					window._uxa.push(["trackPageEvent", "<?php echo esc_js($shortcode_attributes['contentsquare-event']); ?>"]);
				}
			});
		</script>
		<?php
	}

	/**
	 * Output the Mixpanel conversion tracking script
	 *
	 * @since 1.64.1
	 *
	 * @param array $shortcode_attributes Sanitized shortcode attributes
	 * @return void
	 */
	private static function conversion_html_mixpanel( $shortcode_attributes ) {

		if (empty($shortcode_attributes['mixpanel-event'])) {
			return;
		}

		?>

		<script>
			jQuery(document).on("pmw:ready", function () {
				if (typeof window.mixpanel !== "undefined" && typeof window.mixpanel.track === "function") {
					window.mixpanel.track("<?php echo esc_js($shortcode_attributes['mixpanel-event']); ?>", {
						$source: "Pixel Manager for WooCommerce",
					});
				}
			});
		</script>
		<?php
	}

	/**
	 * Output the Klaviyo conversion tracking script
	 *
	 * Goes through pmw.klaviyoTrack(), which sends through klaviyo.js when it
	 * is on the page and through Klaviyo's public client endpoint otherwise,
	 * with the same service tag as every other Klaviyo event.
	 *
	 * @since 1.68.0
	 *
	 * @param array $shortcode_attributes Sanitized shortcode attributes
	 * @return void
	 */
	private static function conversion_html_klaviyo( $shortcode_attributes ) {

		if (empty($shortcode_attributes['klaviyo-event'])) {
			return;
		}

		?>

		<script>
			jQuery(document).on("pmw:ready", function () {
				if (typeof pmw !== "undefined" && typeof pmw.klaviyoTrack === "function") {
					pmw.klaviyoTrack("<?php echo esc_js($shortcode_attributes['klaviyo-event']); ?>", {
						$source: "Pixel Manager for WooCommerce",
					});
				}
			});
		</script>
		<?php
	}

	private static function conversion_html_taboola( $shortcode_attributes ) {

		if (empty($shortcode_attributes['taboola-event'])) {
			return;
		}

		?>

		<script>
			pmwFunctionExists("_tfa").then(function () {
					_tfa.push({
						id    : <?php echo (int) Options::get_taboola_account_id(); ?>,
						notify: "event",
						name  : "<?php echo esc_js($shortcode_attributes['taboola-event']); ?>",
					});
				},
			);
		</script>
		<?php
	}

	private static function conversion_html_tiktok( $shortcode_attributes ) {

		?>

		<script>
			pmwFunctionExists("ttq").then(function () {
					ttq.track("<?php echo esc_js($shortcode_attributes['tiktok-event']); ?>");
				},
			);
		</script>
		<?php
	}

	private static function conversion_html_google_ads( $shortcode_attributes ) {

		?>

		<script>
			pmwFunctionExists("gtag").then(function () {
					gtag("event", "conversion", {"send_to": "AW-<?php echo esc_js($shortcode_attributes['gads-conversion-id']); ?>/<?php echo esc_js($shortcode_attributes['gads-conversion-label']); ?>"});
				},
			);
		</script>
		<?php
	}

	private static function conversion_html_linkedin( $shortcode_attributes ) {

		if (empty($shortcode_attributes['lintrk-event'])) {
			return;
		}

		?>

		<script>
			pmwFunctionExists("lintrk").then(function () {
					lintrk("track", {
						conversion_id: <?php echo intval($shortcode_attributes['lintrk-event']); ?>,
					});
				},
			);
		</script>
		<?php
	}

	/**
	 * Output a Rumble Ads conversion for the conversion action ID passed in
	 * the rumble-event attribute. Without the attribute nothing is sent,
	 * because Rumble has no default lead event to fall back on.
	 *
	 * @since 1.72.1
	 *
	 * @param array $shortcode_attributes
	 * @return void
	 */
	private static function conversion_html_rumble( $shortcode_attributes ) {

		if (empty($shortcode_attributes['rumble-event'])) {
			return;
		}

		?>

		<script>
			pmwFunctionExists("ratag").then(function () {
					ratag("conversion", {
						to: <?php echo intval($shortcode_attributes['rumble-event']); ?>,
					});
				},
			);
		</script>
		<?php
	}

	// https://www.facebook.com/business/help/402791146561655?id=1205376682832142
	private static function conversion_html_facebook( $shortcode_attributes ) {

		if (in_array($shortcode_attributes['meta-event'], Facebook::get_standard_event_names())) {
			$track_instruction = 'track';
		} else {
			$track_instruction = 'trackCustom';
		}


		if (Options::is_facebook_capi_active()) {
			?>

			<script>
				jQuery(document).on("pmw:ready", function () {

					let eventId = pmw.getRandomEventId();

					pmwFunctionExists("fbq").then(function () {
							fbq("<?php echo esc_html($track_instruction); ?>", "<?php echo esc_js($shortcode_attributes['meta-event']); ?>", {}, {
								eventID: eventId,
							});
						},
					);

					pmw.sendEventPayloadToServer({
						facebook: {
							event_name      : "<?php echo esc_js($shortcode_attributes['meta-event']); ?>",
							event_id        : eventId,
							user_data       : pmw.getFbUserData(),
							event_source_url: window.location.href,
						},
					});
				});

			</script>
			<?php
		} else {
			?>

			<script>
				pmwFunctionExists("fbq").then(function () {
						fbq("<?php echo esc_html($track_instruction); ?>", "<?php echo esc_js($shortcode_attributes['meta-event']); ?>");
					},
				);
			</script>
			<?php
		}
	}

	// https://business.twitter.com/en/help/campaign-measurement-and-analytics/conversion-tracking-for-websites.html
	private static function conversion_html_twitter( $shortcode_attributes ) {

		?>

		<script>
			pmwFunctionExists("twq").then(function () {
					twq("track", "<?php echo esc_js($shortcode_attributes['twc-event']); ?>");
				},
			);
		</script>
		<?php
	}

	public static function conversion_html_outbrain( $shortcode_attributes ) {

		if (empty($shortcode_attributes['outbrain-event'])) {
			return;
		}

		?>

		<script>
			pmwFunctionExists("obApi").then(function () {
					obApi("track", "<?php echo esc_js($shortcode_attributes['outbrain-event']); ?>");
				},
			);
		</script>
		<?php
	}

	// https://help.pinterest.com/en/business/article/track-conversions-with-pinterest-tag
	// https://help.pinterest.com/en/business/article/add-event-codes
	private static function conversion_html_pinterest( $shortcode_attributes ) {

		if ('' === $shortcode_attributes['pinc-lead-type']) {
			?>

			<script>
				pmwFunctionExists("pintrk").then(function () {
						pintrk("track", "<?php echo esc_js($shortcode_attributes['pinc-event']); ?>");
					},
				);
			</script>
			<?php
		} else {
			?>

			<script>
				pmwFunctionExists("pintrk").then(function () {
						pintrk("track", "<?php echo esc_js($shortcode_attributes['pinc-event']); ?>", {
							lead_type: "<?php echo esc_js($shortcode_attributes['pinc-lead-type']); ?>",
						});
					},
				);
			</script>
			<?php
		}
	}

	// https://bingadsuet.azurewebsites.net/UETDirectOnSite_ReportCustomEvents.html
	private static function conversion_html_microsoft_ads( $shortcode_attributes ) {
		?>

		<script>
			pmwFunctionExists("uetq").then(function () {
					window.uetq = window.uetq || [];
					window.uetq.push("event", "<?php echo esc_js($shortcode_attributes['ms-ads-event']); ?>", {
						"event_category": "<?php echo esc_js($shortcode_attributes['ms-ads-event-category']); ?>",
						"event_label"   : "<?php echo esc_js($shortcode_attributes['ms-ads-event-label']); ?>",
						"event_value"   : "<?php echo esc_js($shortcode_attributes['ms-ads-event-value']); ?>",
					});
				},
			);
		</script>
		<?php
	}

	private static function conversion_html_reddit_ads( $shortcode_attributes ) {
		?>

		<script>
			pmwFunctionExists("rdt").then(function () {
					rdt("track", "<?php echo esc_js($shortcode_attributes['reddit-event']); ?>");
				},
			);
		</script>
		<?php
	}

	private static function conversion_html_openai( $shortcode_attributes ) {
		?>

		<script>
			pmwFunctionExists("oaiq").then(function () {
					oaiq("measure", "<?php echo esc_js($shortcode_attributes['openai-event']); ?>", {type: "customer_action"});
				},
			);
		</script>
		<?php
	}

	/**
	 * Output the Spotify Ads conversion tracking script.
	 *
	 * Spotify's lead event is the one conversion type that fits a shortcode:
	 * the e-commerce events are driven by the shop itself. The type and
	 * category are optional labels the advertiser uses to tell leads apart in
	 * Ad Analytics.
	 *
	 * @param array $shortcode_attributes
	 * @return void
	 * @since 1.69.0
	 */
	private static function conversion_html_spotify( $shortcode_attributes ) {

		// Only Spotify's own conversion type names are accepted, so a typo
		// cannot turn into an event Spotify silently discards.
		$allowed_events = [ 'lead', 'signup', 'product', 'addtocart', 'checkout', 'purchase' ];
		$event_name     = strtolower((string) $shortcode_attributes['spotify-event']);

		if (!in_array($event_name, $allowed_events, true)) {
			$event_name = 'lead';
		}

		?>

		<script>
			pmwFunctionExists("spdt").then(function () {
					spdt("<?php echo esc_js($event_name); ?>", {
						<?php if (!empty($shortcode_attributes['spotify-lead-type'])) : ?>
						type: "<?php echo esc_js($shortcode_attributes['spotify-lead-type']); ?>",
						<?php endif; ?>
						<?php if (!empty($shortcode_attributes['spotify-lead-category'])) : ?>
						category: "<?php echo esc_js($shortcode_attributes['spotify-lead-category']); ?>",
						<?php endif; ?>
					});
				},
			);
		</script>
		<?php
	}

	/**
	 * Output the AppLovin conversion tracking script.
	 *
	 * Only the events a shortcode can stand for are accepted: generate_lead
	 * (the default), sign_up and subscribe. The commerce events are driven by
	 * the shop itself. AppLovin requires a currency and a value on
	 * generate_lead and discounts or excludes leads with a value of 0, so the
	 * shortcode takes the value as an attribute.
	 *
	 * @param array $shortcode_attributes
	 * @return void
	 * @since 1.69.3
	 */
	private static function conversion_html_applovin( $shortcode_attributes ) {

		$allowed_events = [ 'generate_lead', 'sign_up', 'subscribe' ];
		$event_name     = strtolower((string) $shortcode_attributes['applovin-event']);

		if (!in_array($event_name, $allowed_events, true)) {
			$event_name = 'generate_lead';
		}

		$event_data = [];

		// sign_up takes no value; generate_lead and subscribe do.
		if ('sign_up' !== $event_name) {
			$event_data['currency'] = function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : '';
			$event_data['value']    = is_numeric($shortcode_attributes['applovin-value']) ? (float) $shortcode_attributes['applovin-value'] : 0;
		}

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON for an inline script, escaped by Helpers::json_encode_for_script()
		?>

		<script>
			pmwFunctionExists("axon").then(function () {
					axon("track", <?php echo Helpers::json_encode_for_script($event_name); ?>, <?php echo Helpers::json_encode_for_script((object) $event_data); ?>);
				},
			);
		</script>
		<?php
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	protected static function function_exists_script() {
		?>

		<script>
			if (typeof pmwFunctionExists !== "function") {
				window.pmwFunctionExists = function (functionName) {
					return new Promise(function (resolve) {
						(function waitForVar() {
							if (typeof window[functionName] !== "undefined") return resolve();
							setTimeout(waitForVar, 1000);
						})();
					});
				};
			}
		</script>
		<?php
	}
}
