<?php

namespace SweetCode\Pixel_Manager\Pixels\Google;

use SweetCode\Pixel_Manager\Admin\Broker_Client;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Platforms\Order_Data;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Google Ads purchase conversion upload through the Data Manager API.
 *
 * Experimental. Uploads purchase conversions server-side, in addition to the
 * browser conversion tag, into the SAME conversion action the tag fires.
 * Google deduplicates by transactionId, so the upload only ever adds
 * conversions the tag missed. Authenticates exclusively through the connect
 * broker (Google OAuth): the upload activates automatically once the shop
 * has connected its Google account and a conversion action is on record -
 * there is no toggle, no test mode and no service-account path.
 *
 * https://developers.google.com/data-manager/api/devguides/events/send-events
 *
 * @since 1.66.0
 */
class Google_DMA extends S2S {

	const API_ENDPOINT = 'https://datamanager.googleapis.com/v1/events:ingest';

	/** Most recent upload outcome, for the settings page and the failure notification. */
	const LAST_UPLOAD_OPTION = 'pmw_google_dma_last_upload';

	/** Five-minute cache of the browser-vs-API delta report. */
	const DELTA_REPORT_TRANSIENT = 'pmw_google_dma_delta_report';

	/** Action Scheduler hook for a single delayed retry of a rate-limited live upload. */
	const RETRY_HOOK = 'pmw_google_dma_retry_order';

	/** Action Scheduler hook for one batch of the failed-upload backfill. */
	const BACKFILL_HOOK = 'pmw_google_dma_backfill_run';

	/** Backfill progress, so a run survives the gap between two batches. */
	const BACKFILL_OPTION = 'pmw_google_dma_backfill';

	/** Orders examined per batch. Small enough that one batch stays a short request. */
	const BACKFILL_BATCH_SIZE = 25;

	/** How far back the backfill looks for a failed upload. */
	const BACKFILL_MAX_AGE_DAYS = 60;

	/** Runaway guard: the most batches a single run may schedule. */
	const BACKFILL_MAX_BATCHES = 400;

	/** The newest backfill request from the connection service this shop has acted on. */
	const BACKFILL_HANDLED_OPTION = 'pmw_google_dma_backfill_handled';

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		self::hook_into_generic_events();

		add_action(self::RETRY_HOOK, [ __CLASS__, 'retry_order' ]);
		add_action(self::BACKFILL_HOOK, [ __CLASS__, 'run_backfill_batch' ]);

		// The connection service asks for a recovery here, on the daily status
		// sync. It cannot carry one out itself: it relays an upload and keeps
		// no copy, so the only surviving event is this shop's order.
		add_action('pmw_broker_status_synced', [ __CLASS__, 'maybe_start_requested_backfill' ]);

		add_action('woocommerce_order_fully_refunded', [ __CLASS__, 'handle_full_refund' ], 10, 2);
		add_action('woocommerce_order_partially_refunded', [ __CLASS__, 'handle_partial_refund' ], 10, 2);

		// @since 1.69.3
		add_action('woocommerce_order_status_cancelled', [ __CLASS__, 'handle_cancelled_order' ], 10, 1);
	}

	public static function is_pixel_s2s_active() {
		return Options::is_google_ads_dm_active();
	}

	/**
	 * Never routed through the SSP Purchase Proxy: the upload authenticates
	 * through the connect broker, and the SSP worker holds no broker
	 * credentials. The direct send also records the per-order upload outcome
	 * the feedback surfaces need.
	 *
	 * @return bool
	 */
	public static function is_handled_by_ssp() {
		return false;
	}

	protected static function get_identifiers_key() {
		return 'pmw_google_dma_identifiers';
	}

	public static function get_purchase_hit_key() {
		return 'pmw_google_dma_purchase_hit';
	}

	/**
	 * The order meta key that records the outcome of the upload attempt.
	 * This is the data source for the per-shop experiment evaluation.
	 *
	 * @return string
	 */
	public static function get_upload_result_key() {
		return '_pmw_google_dma_upload_result';
	}

	/**
	 * How many retries an order's failed upload has already been given.
	 *
	 * @return string
	 * @since 1.71.1
	 */
	public static function get_retry_attempts_key() {
		return '_pmw_google_dma_retry_attempts';
	}

	/**
	 * The delay before each successive retry of a retryable upload failure.
	 *
	 * The first is six hours, which is what a rate-limited upload always waited:
	 * the allowance it ran into refills daily, so trying again sooner only
	 * spends the shop's own quota on another refusal. The rest stretch out to
	 * cover a multi-day outage at Google - the one in October 2026 ran four and
	 * a half days - and then stop, because an upload still failing after a week
	 * is not waiting for anything.
	 *
	 * @return int[]
	 * @since 1.71.1
	 */
	private static function upload_retry_delays() {
		return [
			6 * HOUR_IN_SECONDS,
			6 * HOUR_IN_SECONDS,
			DAY_IN_SECONDS,
			2 * DAY_IN_SECONDS,
			4 * DAY_IN_SECONDS,
		];
	}

	/**
	 * Click IDs this destination recovers from the universal per-order
	 * snapshot when its own identifiers carry none (historical orders,
	 * a destination activated later, a backfill).
	 *
	 * @return array<string, string>
	 * @since 1.66.0
	 */
	protected static function get_click_id_snapshot_map() {
		return [ 'gclid' => 'gclid', 'wbraid' => 'wbraid', 'gbraid' => 'gbraid' ];
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {

		// Cookies and URL parameters of the live browser request first
		$identifiers = array_merge($identifiers, Google_Helpers::get_click_ids_from_browser__premium_only());

		// Fall back to the click IDs the browser shipped into the WooCommerce
		// session (pmw_transient_session_identifiers, validated on write)
		$transient_identifiers = Shop::get_transient_identifiers_from_session();

		foreach ([ 'gclid', 'wbraid', 'gbraid' ] as $key) {
			if (empty($identifiers[$key]) && !empty($transient_identifiers[$key])) {
				$identifiers[$key] = $transient_identifiers[$key];
			}
		}

		return $identifiers;
	}

	/**
	 * Stamp the checkout time onto the order identifiers so a purchase that is
	 * paid out-of-band (webhook, cron) keeps a conversion timestamp close to
	 * the actual click-to-conversion journey.
	 *
	 * @param array $identifiers The identifiers.
	 * @return array
	 */
	public static function set_additional_identifiers_on_order( $identifiers ) {

		$identifiers['event_time'] = time();

		return $identifiers;
	}

	// Purchase-only destination in this version
	public static function send_event_hit( $event_data ) {
	}

	/**
	 * Build the Data Manager API event object for the purchase.
	 *
	 * Also used by the SSP Purchase Proxy as the raw destination payload.
	 * Returns null when the order must not be processed or when the event
	 * would carry no identification at all (no click ID and no user data),
	 * which the API rejects.
	 *
	 * @param \WC_Order $order The order.
	 * @return array|null
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		return self::filter_purchase_payload('google_dma', self::build_event($order), $order);
	}

	/**
	 * Builds the event object without the processing gates (dedupe, consent,
	 * IP exclusion). Used by the regular purchase path after the gates, and by
	 * the test upload, which must be able to build a payload from an order
	 * that was already uploaded.
	 *
	 * @param \WC_Order $order The order.
	 * @return array|null Null when the event carries no identification at all.
	 */
	private static function build_event( $order ) {

		$identifiers = self::get_identifiers_from_order($order);

		$event = [
			// Must match the transaction_id the browser conversion tag sends
			// (pmwDataLayer.order.number), because Google deduplicates the tag
			// and the API upload by transactionId.
			'transactionId'   => (string) $order->get_order_number(),
			'eventTimestamp'  => self::get_event_timestamp($order, $identifiers),
			'eventSource'     => 'WEB',
			'conversionValue' => (float) Shop::get_order_value_total_marketing($order, true),
			'currency'        => (string) Shop::get_order_currency($order),
		];

		$ad_identifiers = [];

		$gclid = self::get_gclid_for_order($order, $identifiers);

		if (!empty($gclid)) {
			$ad_identifiers['gclid'] = $gclid;
		}

		if (!empty($identifiers['gbraid'])) {
			$ad_identifiers['gbraid'] = $identifiers['gbraid'];
		}

		if (!empty($identifiers['wbraid'])) {
			$ad_identifiers['wbraid'] = $identifiers['wbraid'];
		}

		$device_info = [];

		if (!empty($identifiers['ip_address'])) {
			$device_info['ipAddress'] = $identifiers['ip_address'];
		}

		if (!empty($identifiers['user_agent'])) {
			$device_info['userAgent'] = $identifiers['user_agent'];
		}

		if (!empty($device_info)) {
			$ad_identifiers['landingPageDeviceInfo'] = $device_info;
		}

		if (!empty($ad_identifiers)) {
			$event['adIdentifiers'] = $ad_identifiers;
		}

		$user_data = self::map_enhanced_conversion_data_to_user_data(
			Google_Helpers::get_google_enhanced_conversion_data($order)
		);

		if (!empty($user_data)) {
			$event['userData'] = $user_data;
		}

		// Without any click ID and without user data the event cannot be
		// matched to an ad interaction and the API rejects it.
		if (empty($gclid) && empty($identifiers['gbraid']) && empty($identifiers['wbraid']) && empty($user_data)) {
			Logger::info('Google DMA: Skipping purchase upload for order ' . $order->get_id() . ' because no click ID and no user data are available');
			return null;
		}

		$consent = self::get_consent_for_order($order);

		if (!empty($consent)) {
			$event['consent'] = $consent;
		}

		// New vs returning customer, matching the browser tag's new_customer flag.
		// Deliberately NOT mirrored: the tag's numeric customer_lifetime_value has
		// no counterpart in this API (userProperties only offers the advertiser-
		// assessed LOW/MEDIUM/HIGH customerValueBucket, and inventing thresholds
		// to bucket a number would misreport).
		$event['userProperties'] = [
			'customerType' => Shop::is_new_customer($order) ? 'NEW' : 'RETURNING',
		];

		// The advertiser-defined user ID, matching the tag's user_id parameter
		// (the WordPress user ID of the customer; guests carry none). Sourced
		// from the order because get_current_user_id() is 0 in webhook and
		// cron contexts.
		$user_id = (int) Shop::get_order_user_id($order);

		if ($user_id > 0) {
			$event['userId'] = (string) $user_id;
		}

		// Conversion cart data, under the same condition as the browser tag
		// (Merchant Center ID configured)
		if (Options::is_google_ads_conversion_cart_data_enabled()) {

			$cart_data = self::get_cart_data_for_order($order);

			if (!empty($cart_data)) {
				$event['cartData'] = $cart_data;
			}
		}

		/**
		 * Filters Google ads order custom variables. The Data Manager upload sends
		 * the same custom conversion variables the browser tag does.
		 *
		 * @since 1.58.5
		 */
		$filtered_custom_variables = (array) apply_filters('pmw_google_ads_order_custom_variables', [], Order_Data::unwrap($order));

		$custom_variables = self::map_custom_variables($filtered_custom_variables);

		if (!empty($custom_variables)) {
			$event['customVariables'] = $custom_variables;
		}

		return $event;
	}

	/**
	 * Builds the Data Manager cartData object from the order, mirroring the
	 * conversion cart data the browser tag sends (gtag purchase event with
	 * aw_merchant_id): same Merchant Center ID, same per-item product IDs
	 * (variation vs parent + the product identifier setting), same
	 * tax-excluded unit prices before coupons, same order-level discount.
	 *
	 * The unit price must be the one before coupons: Google defines unitPrice
	 * as excluding any transaction-level discount and takes the
	 * transactionDiscount off the item sum itself, so a post-coupon unit price
	 * next to it deducted every coupon twice.
	 *
	 * One deliberate divergence: the browser tag sends the visitor's
	 * geolocated country as the feed country, which does not exist in
	 * webhook/cron contexts, so the upload uses the billing country. Merchant
	 * Center's default feed labels equal the country code, which is what the
	 * merchantFeedLabel field expects for those feeds.
	 *
	 * Deliberately NOT mirrored: the tag's per-item google_business_vertical.
	 * It is dynamic remarketing metadata and the Data Manager cart item
	 * schema has no such field.
	 *
	 * @param \WC_Order $order The order.
	 * @return array The cartData object, or an empty array when no item resolves.
	 */
	private static function get_cart_data_for_order( $order ) {

		$items = [];

		foreach (Product::pmw_get_order_items($order) as $order_item) {

			$order_item_data = $order_item->get_data();

			$use_variation = Options::is_shop_variations_output_active() && !empty($order_item_data['variation_id']);
			$product       = wc_get_product($use_variation ? $order_item_data['variation_id'] : $order_item_data['product_id']);

			// Skip the single line we cannot resolve rather than dropping the
			// whole cart, matching the browser item builder.
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			$product_id = (string) Product::get_dyn_r_id_for_product_by_pixel_name($product, 'google_ads');

			// itemId AND merchantProductId are both required for Google Ads
			// cart data. PMW has one product identifier (the feed ID the
			// browser tag sends as the item id), so both carry it.
			$items[] = [
				'itemId'            => $product_id,
				'merchantProductId' => $product_id,
				'quantity'          => (int) $order_item_data['quantity'],
				'unitPrice'         => (float) Product::pmw_get_order_item_price_before_discount($order_item, false, $order),
			];
		}

		if (empty($items)) {
			return [];
		}

		$cart_data = [
			'merchantId'               => (string) Options::get_google_ads_merchant_id(),
			'merchantFeedLabel'        => strtoupper((string) $order->get_billing_country()),
			'merchantFeedLanguageCode' => strtolower(Google_Helpers::get_gmc_language()),
			'transactionDiscount'      => (float) $order->get_total_discount(),
			'items'                    => $items,
		];

		$coupon_codes = $order->get_coupon_codes();

		if (!empty($coupon_codes)) {
			$cart_data['couponCodes'] = array_values(array_map('strval', $coupon_codes));
		}

		return $cart_data;
	}

	/**
	 * Maps the pmw_google_ads_order_custom_variables filter output (the same
	 * key => value map the browser tag spreads onto the gtag conversion) to
	 * the Data Manager customVariables shape.
	 *
	 * @param array $custom_variables Key => value map from the filter.
	 * @return array
	 */
	public static function map_custom_variables( $custom_variables ) {

		$mapped = [];

		foreach ($custom_variables as $variable => $value) {

			if (!is_string($variable) || '' === $variable || !is_scalar($value)) {
				continue;
			}

			$mapped[] = [
				'variable' => $variable,
				'value'    => (string) $value,
			];
		}

		return $mapped;
	}

	/**
	 * Wraps events into the full events:ingest request body.
	 *
	 * @param array $events The Data Manager API event objects.
	 * @return array
	 */
	public static function build_ingest_request( $events ) {

		$destination = [
			'operatingAccount'     => [
				'accountType' => 'GOOGLE_ADS',
				'accountId'   => (string) Options::get_google_ads_dm_operating_account_id(),
			],
			'productDestinationId' => (string) Options::get_google_ads_dm_conversion_action_id(),
		];

		$login_account_id = Options::get_google_ads_dm_login_account_id();

		if (!empty($login_account_id)) {
			$destination['loginAccount'] = [
				'accountType' => 'GOOGLE_ADS',
				'accountId'   => (string) $login_account_id,
			];
		}

		$request = [
			'destinations' => [ $destination ],
			'events'       => array_values($events),
			'encoding'     => 'HEX',
		];

		// Mirror the first event's consent on the request level
		if (!empty($events) && isset($events[0]['consent'])) {
			$request['consent'] = $events[0]['consent'];
		}

		return $request;
	}

	/**
	 * Uploads the order's purchase conversion.
	 *
	 * @param \WC_Order $order       The order.
	 * @param bool      $is_backfill Whether this is a backfill of an upload that
	 *                               failed earlier, rather than a live purchase.
	 */
	public static function send_purchase_hit( $order, $is_backfill = false ) {

		// Serialised per order so two overlapping paid triggers cannot both upload it.
		// A failed upload was already left unmarked. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) use ( $is_backfill ) {

			$event = self::build_ssp_purchase_event_data($order);

			if (!$event) {
				return;
			}

			$request  = self::build_ingest_request([ $event ]);
			$response = self::dispatch_ingest_request($request, $is_backfill);

			self::record_upload_result($order, $event, $response);

			if (!$response['success']) {

				if (429 === (int) $response['code']) {
					Logger::info('Google DMA: Purchase upload for order ' . $order->get_id() . ' deferred by the daily allowance: ' . $response['error_message']);
				} else {
					Logger::warning('Google DMA: Purchase upload for order ' . $order->get_id() . ' failed with HTTP ' . $response['code'] . ': ' . $response['error_message']);
				}

				self::schedule_upload_retry($order, $response);

				return;
			}

			$order->update_meta_data(self::get_purchase_hit_key(), true);
			$order->save();

			Logger::info('Google DMA: Purchase upload for order ' . $order->get_id() . ' sent successfully');

			if (!empty($response['field_warnings'])) {
				Logger::warning('Google DMA: Google recorded the upload for order ' . $order->get_id() . ' but dropped fields: ' . self::format_field_warnings($response['field_warnings']));
			}
		});
	}

	/**
	 * Sends the request through the configured transport: the connect broker
	 * or the shop's own service account.
	 *
	 * @param array $request     The events:ingest request body.
	 * @param bool  $is_backfill Whether to spend the broker's backfill allowance
	 *                           instead of the live-conversion reserve.
	 * @return array { success: bool, code: int, request_id: string, error_message: string, field_warnings: array[] }
	 */
	private static function dispatch_ingest_request( $request, $is_backfill = false ) {
		return Broker_Client::datamanager_ingest($request, $is_backfill);
	}

	/**
	 * One line per field Google dropped from an accepted upload, for the log
	 * and the debug info.
	 *
	 * @param array[] $warnings Sanitized field warnings.
	 *
	 * @return string
	 *
	 * @since 1.69.3
	 */
	public static function format_field_warnings( $warnings ) {

		$lines = [];

		foreach ((array) $warnings as $warning) {

			$text = !empty($warning['description']) ? $warning['description'] : $warning['reason'];

			if (!empty($warning['field'])) {
				$text .= ' (' . $warning['field'] . ')';
			}

			$lines[] = $text;
		}

		return implode('; ', $lines);
	}

	/**
	 * Sends a test upload built from the shop's most recent order, with
	 * validateOnly forced on: Google validates authentication, account
	 * access, the conversion action and the full payload without recording
	 * a conversion. Bypasses the regular processing gates so an already
	 * uploaded order can serve as the test subject, and writes no order meta.
	 *
	 * @return array {
	 *     success: bool, code: int, request_id: string, error_message: string,
	 *     order_number?: string, identifiers?: string[]
	 * }
	 */
	public static function send_test_upload() {

		// Best-effort configuration check first: with broker auth the entered
		// conversion action can be verified against the chosen upload mode,
		// which turns Google's generic INVALID_ARGUMENT into an actionable
		// message (wrong action type, wrong account, wrong mode).
		$verification = self::verify_conversion_action_configuration();

		if (is_array($verification) && 'error' === $verification['level']) {
			return [
				'success'       => false,
				'code'          => 0,
				'request_id'    => '',
				'error_message' => $verification['message'],
			];
		}

		$orders = wc_get_orders([
			'limit'   => 1,
			'orderby' => 'date',
			'order'   => 'DESC',
			'type'    => 'shop_order',
		]);

		if (empty($orders)) {
			return [
				'success'       => false,
				'code'          => 0,
				'request_id'    => '',
				'error_message' => 'No order found to build a test upload from. Place a test order first.',
			];
		}

		$order = $orders[0];
		$event = self::build_event($order);

		if (!$event) {
			return [
				'success'       => false,
				'code'          => 0,
				'request_id'    => '',
				'error_message' => 'The latest order (#' . $order->get_order_number() . ') carries no click ID and no customer data, so no test payload could be built.',
			];
		}

		$request                 = self::build_ingest_request([ $event ]);
		$request['validateOnly'] = true;

		$response                 = self::dispatch_ingest_request($request);
		$response['order_number'] = (string) $order->get_order_number();
		$response['identifiers']  = self::get_identifiers_present($event);

		if (is_array($verification) && 'warning' === $verification['level']) {
			$response['config_warning'] = $verification['message'];
		}

		Logger::info(
			'Google DMA: Test upload (validateOnly) for order ' . $order->get_id()
			. ( $response['success'] ? ' validated successfully' : ' failed with HTTP ' . $response['code'] . ': ' . $response['error_message'] )
			. ( !empty($response['field_warnings']) ? ', with dropped fields: ' . self::format_field_warnings($response['field_warnings']) : '' )
		);

		return $response;
	}

	/**
	 * Verifies that the recorded conversion action still exists and is the
	 * web conversion action the shop's browser tag fires - the invariant the
	 * whole deduplication rests on. Best effort: returns null when
	 * verification is not possible, so it can never block a working setup.
	 *
	 * @return array|null { level: 'error'|'warning', message: string } or null when everything checks out or cannot be checked.
	 */
	private static function verify_conversion_action_configuration() {

		$actions = Broker_Client::list_all_ads_conversion_actions(
			Options::get_google_ads_dm_operating_account_id(),
			Options::get_google_ads_dm_login_account_id()
		);

		if (null === $actions) {
			return null;
		}

		$conversion_action_id = (string) Options::get_google_ads_dm_conversion_action_id();
		$action               = null;

		foreach ($actions as $candidate) {
			if (isset($candidate['id']) && (string) $candidate['id'] === $conversion_action_id) {
				$action = $candidate;
				break;
			}
		}

		if (null === $action) {
			return [
				'level'   => 'error',
				'message' => 'The conversion action this shop was connected to (ID ' . $conversion_action_id . ') no longer exists in Google Ads account '
					. Options::get_google_ads_dm_operating_account_id()
					. '. Re-run the Google connection and pick the purchase conversion action your tag fires.',
			];
		}

		$name = isset($action['name']) ? (string) $action['name'] : $conversion_action_id;
		$type = isset($action['type']) ? (string) $action['type'] : '';

		// A client account also lists the cross-account conversion actions of
		// the manager it uses for conversion tracking, so the picker can hand
		// back an action this account can see but does not own. The Data
		// Manager API requires the destination's operating account to BE the
		// owner - unlike the Google Ads API it replaced, it accepts neither a
		// parent nor a descendant - and answers 404
		// INVALID_CONVERSION_ACTION_ID to every upload that gets this wrong.
		// Absent when the broker predates the owner lookup: skip rather than
		// invent a verdict.
		$owner = isset($action['ownerCustomerId']) ? (string) $action['ownerCustomerId'] : '';

		if ('' !== $owner && (string) Options::get_google_ads_dm_operating_account_id() !== $owner) {
			return [
				'level'   => 'error',
				'message' => '"' . $name . '" belongs to Google Ads account ' . $owner . ', not to ' . Options::get_google_ads_dm_operating_account_id()
					. ' which this shop uploads to. It is a cross-account conversion action owned by a manager account, and Google rejects every upload whose target account is not the owner. Either pick a conversion action that belongs to ' . Options::get_google_ads_dm_operating_account_id()
					. ', or set the upload account to ' . $owner . '.',
			];
		}

		if ('WEBPAGE' !== $type) {
			return [
				'level'   => 'error',
				'message' => '"' . $name . '" is a ' . $type . ' conversion action, but the upload must target the web conversion action your browser tag fires - that is what lets Google deduplicate the two sources. Re-run the Google connection and pick the tag\'s purchase conversion action.',
			];
		}

		$action_label     = isset($action['conversionLabel']) ? (string) $action['conversionLabel'] : '';
		$configured_label = (string) Options::get_google_ads_conversion_label();

		if ('' !== $action_label && '' !== $configured_label && $action_label !== $configured_label) {
			return [
				'level'   => 'error',
				'message' => '"' . $name . '" is not the conversion action this shop\'s browser tag fires (the conversion labels differ), so Google would count uploads and tag conversions separately - double counting. Re-run the Google connection and pick the conversion action behind your configured conversion label.',
			];
		}

		$category = isset($action['category']) ? (string) $action['category'] : '';

		if ('' !== $category && !in_array($category, [ 'PURCHASE', 'DEFAULT' ], true)) {
			return [
				'level'   => 'warning',
				'message' => '"' . $name . '" has the category ' . $category . '. Purchase uploads with values and cart data belong in a conversion action with the category Purchase.',
			];
		}

		return null;
	}

	/**
	 * Which matchable identifiers an event carries. Stored with the upload
	 * result and shown in the test-upload feedback.
	 *
	 * @param array $event The event.
	 * @return string[]
	 */
	private static function get_identifiers_present( $event ) {

		$identifiers_present = [];

		if (isset($event['adIdentifiers']['gclid'])) {
			$identifiers_present[] = 'gclid';
		}
		if (isset($event['adIdentifiers']['gbraid'])) {
			$identifiers_present[] = 'gbraid';
		}
		if (isset($event['adIdentifiers']['wbraid'])) {
			$identifiers_present[] = 'wbraid';
		}
		if (isset($event['userData'])) {
			$identifiers_present[] = 'user_data';
		}

		return $identifiers_present;
	}

	/**
	 * Records the upload outcome on the order. This meta is the data source
	 * for comparing the API upload against the browser tag per shop. A copy
	 * of the most recent outcome is kept in a plain option so the settings
	 * page and the failure notification can surface it without an order query.
	 *
	 * @param \WC_Order $order    The order.
	 * @param array     $event    The event that was sent.
	 * @param array     $response The normalized response.
	 */
	private static function record_upload_result( $order, $event, $response ) {

		if (!$response['success']) {
			// A daily-allowance 429 is deliberate throttling, not a failure:
			// the order keeps its missing hit key and is retried, so calling
			// it "failed" misreports a working system as broken.
			$status = 429 === (int) $response['code'] ? 'throttled' : 'error';
		} else {
			$status = 'success';
		}

		$result = [
			'status'      => $status,
			'http_code'   => $response['code'],
			'request_id'  => $response['request_id'],
			'timestamp'   => time(),
			'identifiers' => self::get_identifiers_present($event),
		];

		if (!empty($response['error_message'])) {
			$result['error_message'] = substr($response['error_message'], 0, 300);
		}

		// Recorded, but with fields Google dropped. Kept with the result so
		// the settings card and the debug info can show it. @since 1.69.3
		if (!empty($response['field_warnings'])) {
			$result['field_warnings'] = $response['field_warnings'];
		}

		$order->update_meta_data(self::get_upload_result_key(), $result);
		$order->save();

		update_option(
			self::LAST_UPLOAD_OPTION,
			array_merge($result, [ 'order_id' => $order->get_id(), 'order_number' => (string) $order->get_order_number() ]),
			false
		);
	}

	/**
	 * Schedules the next retry of an upload that failed for a reason that may
	 * not hold next time.
	 *
	 * Until 1.71.1 only a rate limit was retried, so a 500 from Google left
	 * the order unmarked and nothing ever came back for it. That is how a
	 * four-day outage in October 2026 cost 454 orders across three shops: the
	 * uploads were retryable by Google's own guidance, and the plugin simply
	 * never tried again. A merchant should not have to notice that, let alone
	 * act on it.
	 *
	 * No as_has_scheduled_action() guard. The function also matches a RUNNING
	 * action, and the common caller IS a running retry, so the guard would
	 * match itself and silently end the series after the first attempt - which
	 * is what the rate-limit branch did here before. The attempt counter
	 * bounds the series instead, and the per-order lock keeps two sends from
	 * both scheduling.
	 *
	 * @param \WC_Order $order    The order whose upload failed.
	 * @param array     $response The normalized upload response.
	 * @return void
	 * @since 1.71.1
	 */
	private static function schedule_upload_retry( $order, $response ) {

		$code = (int) $response['code'];

		// A 4xx that is not a rate limit is the request itself being wrong -
		// a bad conversion action, a revoked grant, a malformed payload - and
		// it will fail identically next time. Retrying only spends the shop's
		// allowance on the same refusal.
		if (429 !== $code && $code < 500) {
			return;
		}

		if (!function_exists('as_schedule_single_action')) {
			return;
		}

		$delays   = self::upload_retry_delays();
		$attempts = (int) $order->get_meta(self::get_retry_attempts_key(), true);

		if ($attempts >= count($delays)) {
			Logger::warning('Google DMA: Order ' . $order->get_id() . ' has used all ' . count($delays) . ' upload retries and will not be retried again; a backfill can still recover it');
			return;
		}

		$delay = $delays[$attempts];

		as_schedule_single_action(time() + $delay, self::RETRY_HOOK, [ $order->get_id() ], 'pmw_google_dma');

		$order->update_meta_data(self::get_retry_attempts_key(), $attempts + 1);
		$order->save();

		Logger::info('Google DMA: Scheduled retry ' . ( $attempts + 1 ) . ' of ' . count($delays) . ' in ' . human_time_diff(time(), time() + $delay) . ' for order ' . $order->get_id());
	}

	/**
	 * Action Scheduler callback: retries a single failed live upload.
	 * All regular gates apply again (dedupe hit key, consent, IP exclusion).
	 *
	 * @param int $order_id The order ID.
	 */
	public static function retry_order( $order_id ) {

		if (!Options::is_google_ads_dm_active()) {
			return;
		}

		$order = wc_get_order($order_id);

		if (!$order instanceof \WC_Order) {
			return;
		}

		self::send_purchase_hit($order);
	}

	/**
	 * The backfill's progress, with every key present so a caller never has
	 * to guard against a half-written option.
	 *
	 * @return array
	 * @since 1.71.1
	 */
	public static function get_backfill_state() {

		$stored = get_option(self::BACKFILL_OPTION);

		return array_merge(
			[
				'status'      => 'idle',
				'page'        => 1,
				'batches'     => 0,
				'scanned'     => 0,
				'candidates'  => 0,
				'uploaded'    => 0,
				'failed'      => 0,
				'skipped'     => 0,
				'started_at'  => 0,
				'finished_at' => 0,
				'newer_than'  => 0,
				'older_than'  => 0,
				'last_error'  => '',
			],
			is_array($stored) ? $stored : []
		);
	}

	/**
	 * Starts a backfill of the orders whose upload failed.
	 *
	 * Uploads that fail with anything other than a 429 are left unmarked and
	 * nothing picks them up again: the live path only reschedules a
	 * rate-limited order. A multi-day upstream outage therefore leaves a run
	 * of orders that the shop can never recover on its own - which is exactly
	 * what happened between 2026-10-17 and 2026-10-22, when the Data Manager
	 * API answered INTERNAL to 454 uploads across three shops.
	 *
	 * Replaying is safe: Google deduplicates by transactionId, so an order
	 * that did reach Google after all cannot be counted twice, and a rebuilt
	 * event keeps the original order's timestamp.
	 *
	 * @param int $since Unix timestamp: only consider orders from here on.
	 *                   0 falls back to the full window.
	 * @return array { started: bool, message: string, state: array }
	 * @since 1.71.1
	 */
	public static function start_backfill( $since = 0 ) {

		$state = self::get_backfill_state();

		if (!Options::is_google_ads_dm_active()) {
			return [
				'started' => false,
				'message' => 'The Google Ads Data Manager upload is not active on this shop.',
				'state'   => $state,
			];
		}

		if (!function_exists('as_schedule_single_action')) {
			return [
				'started' => false,
				'message' => 'The Action Scheduler is not available, so a backfill cannot be queued.',
				'state'   => $state,
			];
		}

		if ('running' === $state['status']) {

			// A run whose next batch never made it into the queue (a failed
			// action, a cleared Action Scheduler table) would otherwise stay
			// "running" forever and refuse every restart. Pick it up again
			// from where its cursor stands.
			if (!self::backfill_batch_is_queued()) {

				self::schedule_backfill_batch(0);

				Logger::info('Google DMA: Backfill resumed at page ' . $state['page'] . ' after its queue entry went missing');

				return [
					'started' => true,
					'message' => 'The backfill had stalled and was resumed where it left off.',
					'state'   => $state,
				];
			}

			return [
				'started' => false,
				'message' => 'A backfill is already running.',
				'state'   => $state,
			];
		}

		// The window is pinned at the start and never moves. Orders placed
		// while the backfill runs are uploaded by the live path anyway, and
		// letting them into the set would shift the pages under the cursor
		// and skip an order per new purchase.
		$oldest = time() - self::BACKFILL_MAX_AGE_DAYS * DAY_IN_SECONDS;

		// The caller's window names when uploads FAILED; this one selects
		// orders by when they were PLACED. An order can fail well after it was
		// placed (a retry days later, a late payment), so the order window
		// opens a week earlier than the failure window. Being generous costs
		// only a wider scan: only orders with a failed result are re-sent, and
		// Google deduplicates anything that did arrive.
		$newer_than = $since > 0 ? max($oldest, (int) $since - WEEK_IN_SECONDS) : $oldest;

		$state = [
			'status'      => 'running',
			'page'        => 1,
			'batches'     => 0,
			'scanned'     => 0,
			'candidates'  => 0,
			'uploaded'    => 0,
			'failed'      => 0,
			'skipped'     => 0,
			'started_at'  => time(),
			'finished_at' => 0,
			'newer_than'  => $newer_than,
			'older_than'  => time(),
			'last_error'  => '',
		];

		self::save_backfill_state($state);
		self::schedule_backfill_batch(0);

		$days = max(1, (int) round(( time() - $newer_than ) / DAY_IN_SECONDS));

		Logger::info('Google DMA: Backfill started over the last ' . $days . ' days of orders');

		return [
			'started' => true,
			'message' => 'The backfill is queued. It walks the orders of the last ' . $days . ' days and re-uploads the ones whose upload failed.',
			'state'   => $state,
		];
	}

	/**
	 * Starts the backfill the connection service asked for, if it is new.
	 *
	 * The division of labour: the service sees every shop, so a run of
	 * failures spanning days and sites is obvious there and invisible from
	 * inside any one shop. It cannot act on it though, because it relays an
	 * upload and keeps no copy of it, so only the shop still holds the orders.
	 * It therefore decides, and this carries it out. The merchant is told
	 * nothing, because nothing about an outage at Google is theirs to fix.
	 *
	 * The request id is the timestamp it was made. Storing the newest one
	 * handled makes this idempotent across the daily poll: the same request
	 * is acted on once, and asking again for the same window is a new request
	 * because the service stamps it fresh.
	 *
	 * @param array $status The /v1/status body from the connection service.
	 * @return void
	 * @since 1.71.1
	 */
	public static function maybe_start_requested_backfill( $status ) {

		if (!Options::is_google_ads_dm_active()) {
			return;
		}

		$request = isset($status['datamanagerBackfill']) ? $status['datamanagerBackfill'] : null;

		if (!is_array($request) || empty($request['requestedAt']) || empty($request['since'])) {
			return;
		}

		$requested_at = (int) $request['requestedAt'];

		if ($requested_at <= (int) get_option(self::BACKFILL_HANDLED_OPTION, 0)) {
			return;
		}

		// Recorded before the attempt, not after. A backfill that cannot start
		// right now (one already running, no Action Scheduler) must not make
		// every poll from here on try again and log again; the service can
		// always ask once more, and that is a new request.
		update_option(self::BACKFILL_HANDLED_OPTION, $requested_at, false);

		// The service works in milliseconds, this side in seconds.
		$result = self::start_backfill((int) round((int) $request['since'] / 1000));

		Logger::info('Google DMA: The connection service asked for a backfill. ' . $result['message']);
	}

	/**
	 * Cancels a running backfill. Orders already re-uploaded stay uploaded.
	 *
	 * @return array { stopped: bool, message: string, state: array }
	 * @since 1.71.1
	 */
	public static function stop_backfill() {

		$state = self::get_backfill_state();

		if ('running' !== $state['status']) {
			return [
				'stopped' => false,
				'message' => 'No backfill is running.',
				'state'   => $state,
			];
		}

		if (function_exists('as_unschedule_all_actions')) {
			as_unschedule_all_actions(self::BACKFILL_HOOK, [], 'pmw_google_dma');
		}

		$state['status']      = 'stopped';
		$state['finished_at'] = time();

		self::save_backfill_state($state);

		Logger::info('Google DMA: Backfill stopped after ' . $state['uploaded'] . ' recovered orders');

		return [
			'stopped' => true,
			'message' => 'The backfill was stopped.',
			'state'   => $state,
		];
	}

	/**
	 * Action Scheduler callback: one batch of the backfill.
	 *
	 * Each batch walks a page of orders, re-uploads the failed ones and
	 * queues the next batch. The work is split this way so no single request
	 * carries a whole shop's history, and so stopping takes effect between
	 * batches rather than needing to interrupt one.
	 *
	 * @return void
	 * @since 1.71.1
	 */
	public static function run_backfill_batch() {

		$state = self::get_backfill_state();

		// Re-read every time: the status may have been stopped, or the
		// feature disconnected, since this batch was queued.
		if ('running' !== $state['status']) {
			return;
		}

		if (!Options::is_google_ads_dm_active()) {
			self::finish_backfill($state, 'The upload is no longer active.');
			return;
		}

		if ($state['batches'] >= self::BACKFILL_MAX_BATCHES) {
			self::finish_backfill($state, 'Stopped at the batch limit; start another backfill to continue.');
			return;
		}

		$state['batches']++;

		$orders = wc_get_orders([
			'limit'        => self::BACKFILL_BATCH_SIZE,
			'page'         => $state['page'],
			'orderby'      => 'date',
			'order'        => 'DESC',
			'type'         => 'shop_order',
			'date_created' => $state['newer_than'] . '...' . $state['older_than'],
		]);

		if (empty($orders)) {
			self::finish_backfill($state, '');
			return;
		}

		foreach ($orders as $order) {

			$state['scanned']++;

			if (!self::is_backfill_candidate($order)) {
				continue;
			}

			$state['candidates']++;

			$attempted_at = time();

			self::send_purchase_hit($order, true);

			// Read the outcome back from the database rather than from the
			// order object the send worked on, so the result is the one that
			// was actually stored.
			$fresh = wc_get_order($order->get_id());

			if ($fresh instanceof \WC_Order && $fresh->meta_exists(self::get_purchase_hit_key())) {
				$state['uploaded']++;
				continue;
			}

			$result = $fresh instanceof \WC_Order ? $fresh->get_meta(self::get_upload_result_key(), true) : null;

			// No result newer than this attempt means nothing was sent: a gate
			// (consent, IP exclusion) or the per-order lock stopped it before
			// Google. That is not a failed upload, and reading the result of
			// the OLD attempt as this one's would both miscount it and, when
			// that old attempt was a 429, pause the whole run for an hour over
			// an allowance that is no longer exhausted.
			if (!is_array($result) || !isset($result['timestamp']) || (int) $result['timestamp'] < $attempted_at) {
				$state['skipped']++;
				continue;
			}

			$state['failed']++;

			if (!empty($result['error_message'])) {
				$state['last_error'] = (string) $result['error_message'];
			}

			// The daily allowance is gone. Keep the page, stop the batch and
			// come back later: a backfill that burned through the budget in a
			// tight loop would spend the rest of the day failing.
			if (isset($result['http_code']) && 429 === (int) $result['http_code']) {
				$state['last_error'] = 'The daily upload allowance is used up; the backfill resumes later.';
				self::save_backfill_state($state);
				self::schedule_backfill_batch(HOUR_IN_SECONDS);
				Logger::info('Google DMA: Backfill paused for an hour, the daily upload allowance is used up');
				return;
			}
		}

		$state['page']++;

		self::save_backfill_state($state);
		self::schedule_backfill_batch(MINUTE_IN_SECONDS);
	}

	/**
	 * Whether the backfill should re-upload this order: an upload was
	 * attempted, it did not succeed, and no later attempt has since.
	 *
	 * Throttled orders are included. They have their own six-hour retry, but
	 * an order whose retry never ran would otherwise sit unrecovered forever,
	 * and the hit key below keeps a doubled attempt from doubling an upload.
	 *
	 * @param \WC_Order $order The order.
	 * @return bool
	 * @since 1.71.1
	 */
	private static function is_backfill_candidate( $order ) {

		if ($order->meta_exists(self::get_purchase_hit_key())) {
			return false;
		}

		$result = $order->get_meta(self::get_upload_result_key(), true);

		// No result at all means the upload never attempted this order: it
		// predates the feature, or a gate (consent, IP exclusion) stopped it.
		// Those are not failures and the backfill leaves them alone.
		if (!is_array($result) || empty($result['status'])) {
			return false;
		}

		return in_array((string) $result['status'], [ 'error', 'throttled' ], true);
	}

	/**
	 * Marks the run finished and logs what it recovered.
	 *
	 * @param array  $state  The state to finish.
	 * @param string $reason Why it ended early, or '' when it simply ran out of orders.
	 * @return void
	 * @since 1.71.1
	 */
	private static function finish_backfill( $state, $reason ) {

		$state['status']      = 'done';
		$state['finished_at'] = time();

		if ('' !== $reason) {
			$state['last_error'] = $reason;
		}

		self::save_backfill_state($state);

		Logger::info(
			'Google DMA: Backfill finished, scanned ' . $state['scanned'] . ' orders, re-uploaded '
			. $state['uploaded'] . ' of ' . $state['candidates'] . ' failed ones, ' . $state['failed'] . ' still failing'
			. ( '' === $reason ? '' : ' (' . $reason . ')' )
		);
	}

	/**
	 * Persists the backfill's progress.
	 *
	 * @param array $state The state to persist.
	 * @return void
	 * @since 1.71.1
	 */
	private static function save_backfill_state( $state ) {
		update_option(self::BACKFILL_OPTION, $state, false);
	}

	/**
	 * Queues the next batch.
	 *
	 * Deliberately unguarded. as_has_scheduled_action() counts a RUNNING
	 * action as scheduled, so a guard here would match the very batch that is
	 * calling it and the run would stop after its first page. Duplicates
	 * cannot arise instead: this is reached once when a run starts, and once
	 * at the end of each batch.
	 *
	 * @param int $delay Seconds from now.
	 * @return void
	 * @since 1.71.1
	 */
	private static function schedule_backfill_batch( $delay ) {

		if (!function_exists('as_schedule_single_action')) {
			return;
		}

		as_schedule_single_action(time() + max(0, (int) $delay), self::BACKFILL_HOOK, [], 'pmw_google_dma');
	}

	/**
	 * Whether a batch is waiting or running. Either means the run is alive.
	 *
	 * @return bool
	 * @since 1.71.1
	 */
	private static function backfill_batch_is_queued() {

		if (!function_exists('as_has_scheduled_action')) {
			return false;
		}

		return (bool) as_has_scheduled_action(self::BACKFILL_HOOK, [], 'pmw_google_dma');
	}

	/**
	 * Full refund: retract the uploaded conversion. Adjustments live in the
	 * Google Ads API and run through the broker's developer token, and only
	 * for orders whose upload was actually recorded. The Google Ads
	 * adjustment is NOT idempotent, so a marker guards reruns.
	 *
	 * The order-id adjustment also nets out a tag-recorded conversion, so
	 * refunds are covered regardless of which source recorded the original.
	 *
	 * @param int $order_id  The order ID.
	 * @param int $refund_id The refund ID (unused for full refunds).
	 */
	public static function handle_full_refund( $order_id, $refund_id = 0 ) {

		$order = self::get_refund_adjustable_order($order_id);

		if (!$order) {
			return;
		}

		self::send_retraction($order, 'fully refunded');
	}

	/**
	 * Cancelled order: retract the conversion right away. A customer cannot
	 * pay a cancelled order again, and the CSV adjustments feed retracts
	 * cancelled orders without a grace period too.
	 *
	 * @param int $order_id The order ID.
	 * @since 1.69.3
	 */
	public static function handle_cancelled_order( $order_id ) {

		$order = self::get_status_adjustable_order($order_id);

		if (!$order) {
			return;
		}

		self::send_retraction($order, 'cancelled');
	}

	/**
	 * Failed order: retract the conversion of an order whose payment failed
	 * after the conversion had already been sent, which happens with gateways
	 * that only report the failure hours or days after checkout.
	 *
	 * Called by Failed_Order_Retractions after its grace period, once it has
	 * confirmed that the order is still failed.
	 *
	 * @param \WC_Order $order The order.
	 * @since 1.69.3
	 */
	public static function retract_failed_order( $order ) {

		$order = self::get_status_adjustable_order($order->get_id());

		if (!$order) {
			return;
		}

		self::send_retraction($order, 'failed');
	}

	/**
	 * Retracts the order's conversion. The Google Ads adjustment is NOT
	 * idempotent, so the full refund marker guards reruns, and the CSV feed
	 * reads the same marker to skip orders already retracted here.
	 *
	 * @param \WC_Order $order  The order.
	 * @param string    $reason Why the conversion is retracted, for the log.
	 * @since 1.69.3
	 */
	private static function send_retraction( $order, $reason ) {

		if ($order->meta_exists(self::get_full_refund_hit_key())) {
			return;
		}

		$response = Broker_Client::datamanager_adjust(self::build_adjustment_payload($order, 'RETRACTION'));

		self::record_refund_result($order, 'RETRACTION', $response);

		if ($response['success']) {
			$order->update_meta_data(self::get_full_refund_hit_key(), true);
			$order->save();
			Logger::info('Google DMA: Retracted the conversion for ' . $reason . ' order ' . $order->get_id());
		} elseif (self::is_not_ad_conversion($response)) {
			// Handled: there is nothing to retract, and a feed row for the
			// order would be rejected the same way.
			$order->update_meta_data(self::get_full_refund_hit_key(), true);
			$order->save();
			Logger::info('Google DMA: No retraction needed for ' . $reason . ' order ' . $order->get_id() . ', Google Ads recorded no conversion for it (not an ad conversion)');
		} else {
			Logger::warning('Google DMA: Retraction for ' . $reason . ' order ' . $order->get_id() . ' failed with HTTP ' . $response['code'] . ': ' . $response['error_message']);
		}
	}

	/**
	 * Partial refund: restate the conversion to the order's current net
	 * marketing value (the same value logic the purchase used, recomputed
	 * after the refund). One restatement per refund, guarded by markers.
	 *
	 * @param int $order_id  The order ID.
	 * @param int $refund_id The refund ID.
	 */
	public static function handle_partial_refund( $order_id, $refund_id ) {

		$order = self::get_refund_adjustable_order($order_id);

		if (!$order || $order->meta_exists(self::get_full_refund_hit_key())) {
			return;
		}

		$handled = (array) $order->get_meta(self::get_partial_refund_hits_key(), true);

		if (in_array((int) $refund_id, array_map('intval', $handled), true)) {
			return;
		}

		if (self::send_restatement($order, 'partially refunded')) {
			$handled[] = (int) $refund_id;
			$order->update_meta_data(self::get_partial_refund_hits_key(), $handled);
			$order->save();
		}
	}

	/**
	 * A refund was deleted after the conversion had been adjusted for it,
	 * typically a gateway refund that failed or was canceled later (Stripe,
	 * WooPayments). Called by Refund_Deletions.
	 *
	 * A restatement sets an absolute value, so restating the conversion to
	 * the order's current net value undoes the deleted refund. A retraction
	 * cannot be undone: Google Ads does not adjust a retracted conversion
	 * again, and a new upload with the same order ID is dropped as a
	 * duplicate. The full refund marker therefore stays, which also keeps
	 * the adjustments feed from retracting the order a second time.
	 *
	 * @param \WC_Order $order     The parent order.
	 * @param int       $refund_id The deleted WooCommerce refund.
	 * @return void
	 * @since 1.71.1
	 */
	public static function handle_deleted_refund( $order, $refund_id ) {

		$order = self::get_refund_adjustable_order($order->get_id());

		if (!$order) {
			return;
		}

		if ($order->meta_exists(self::get_full_refund_hit_key())) {
			Logger::info('Google DMA: Refund ' . $refund_id . ' of order ' . $order->get_id() . ' was deleted, but the conversion was already retracted, which Google Ads cannot undo');
			return;
		}

		$handled = array_map('intval', (array) $order->get_meta(self::get_partial_refund_hits_key(), true));

		// Every restatement sets the value after all refunds of its time, so
		// any earlier restatement still deducts the deleted refund.
		if (empty($handled)) {
			return;
		}

		if (self::send_restatement($order, 'refund deleted')) {
			$order->update_meta_data(self::get_partial_refund_hits_key(), array_values(array_diff($handled, [ (int) $refund_id ])));
			$order->save();
		}
	}

	/**
	 * Restates the conversion to the order's current net marketing value
	 * (the same value logic the purchase used, recomputed after refunds).
	 *
	 * @param \WC_Order $order  The order.
	 * @param string    $reason Why the conversion is restated, for the log.
	 * @return bool Whether Google accepted the restatement.
	 * @since 1.71.1
	 */
	private static function send_restatement( $order, $reason ) {

		$payload                   = self::build_adjustment_payload($order, 'RESTATEMENT');
		$payload['adjustedValue']  = (float) Shop::get_order_value_total_marketing($order, true);
		$payload['currencyCode']   = (string) Shop::get_order_currency($order);

		$response = Broker_Client::datamanager_adjust($payload);

		self::record_refund_result($order, 'RESTATEMENT', $response);

		if ($response['success']) {
			Logger::info('Google DMA: Restated the conversion for ' . $reason . ' order ' . $order->get_id() . ' to ' . $payload['adjustedValue']);
			return true;
		}

		if (self::is_not_ad_conversion($response)) {
			Logger::info('Google DMA: No restatement needed for ' . $reason . ' order ' . $order->get_id() . ', Google Ads recorded no conversion for it (not an ad conversion)');
			return true;
		}

		Logger::warning('Google DMA: Restatement for order ' . $order->get_id() . ' failed with HTTP ' . $response['code'] . ': ' . $response['error_message']);

		return false;
	}

	/**
	 * Resolves the order for a refund adjustment, or null when adjustments do
	 * not apply: feature inactive, service account mode (no Ads API access;
	 * the conversion adjustments CSV feed remains the path there), or the
	 * purchase upload was never recorded.
	 *
	 * @param int $order_id The order ID.
	 * @return \WC_Order|null
	 */
	private static function get_refund_adjustable_order( $order_id ) {

		$order = self::get_adjustable_order($order_id);

		if (!$order) {
			return null;
		}

		// Never adjust a conversion that was never uploaded. The tag
		// conversion is still netted out by the CSV feed when configured; the
		// API path deliberately stays tied to its own uploads.
		if (!$order->meta_exists(self::get_purchase_hit_key())) {
			return null;
		}

		return $order;
	}

	/**
	 * Resolves the order for a cancellation or failed-payment retraction, or
	 * null when it does not apply.
	 *
	 * Unlike refunds, the conversion of a cancelled or failed order is just as
	 * often one the browser tag recorded on the confirmation page, while the
	 * order was still pending or on hold. The order-id adjustment nets out
	 * that tag conversion as well, so the fired confirmation pixel counts as
	 * evidence too. Orders with no evidence at all (a payment declined at
	 * checkout never fires anything) are left alone, so Google is never asked
	 * to retract a conversion it does not have.
	 *
	 * @param int $order_id The order ID.
	 * @return \WC_Order|null
	 * @since 1.69.3
	 */
	private static function get_status_adjustable_order( $order_id ) {

		$order = self::get_adjustable_order($order_id);

		if (!$order) {
			return null;
		}

		if (!$order->meta_exists(self::get_purchase_hit_key()) && !Shop::has_conversion_pixel_already_fired($order)) {
			return null;
		}

		/**
		 * This filter is documented in includes/class-s2s__premium_only.php
		 *
		 * @since 1.69.3
		 */
		if (apply_filters('pmw_skip_s2s_purchase_event', false, Order_Data::unwrap($order), self::class)) {
			return null;
		}

		return $order;
	}

	/**
	 * Resolves the order for any adjustment, or null when the feature is
	 * inactive or the order does not exist.
	 *
	 * @param int $order_id The order ID.
	 * @return \WC_Order|null
	 * @since 1.69.3
	 */
	private static function get_adjustable_order( $order_id ) {

		if (!Options::is_google_ads_dm_active()) {
			return null;
		}

		$order = wc_get_order($order_id);

		if (!$order instanceof \WC_Order) {
			return null;
		}

		return $order;
	}

	private static function build_adjustment_payload( $order, $adjustment_type ) {

		$payload = [
			'customerId'         => (string) Options::get_google_ads_dm_operating_account_id(),
			'conversionActionId' => (string) Options::get_google_ads_dm_conversion_action_id(),
			'orderId'            => (string) $order->get_order_number(),
			'adjustmentType'     => $adjustment_type,
			'adjustmentDateTime' => gmdate('Y-m-d H:i:s') . '+00:00',
		];

		$login_account_id = Options::get_google_ads_dm_login_account_id();

		if (!empty($login_account_id)) {
			$payload['loginCustomerId'] = (string) $login_account_id;
		}

		return $payload;
	}

	/**
	 * Whether Google answered an adjustment with "no such conversion": the
	 * order never came from an ad click (or fell outside the attribution
	 * window), so there is nothing to adjust. That is the expected outcome for
	 * most refunds, not a failure. Google reports its timing cases under other
	 * codes, so this one cannot succeed on a retry.
	 *
	 * @param array $response A datamanager_adjust() result.
	 * @return bool
	 *
	 * @since 1.74.3
	 */
	private static function is_not_ad_conversion( $response ) {
		return !$response['success'] && isset($response['reason']) && 'CONVERSION_NOT_FOUND' === $response['reason'];
	}

	private static function record_refund_result( $order, $adjustment_type, $response ) {

		if ($response['success']) {
			$status = 'success';
		} elseif (self::is_not_ad_conversion($response)) {
			$status = 'not_ad_conversion';
		} else {
			$status = 'error';
		}

		$result = [
			'type'      => $adjustment_type,
			'status'    => $status,
			'http_code' => $response['code'],
			'timestamp' => time(),
		];

		if (!empty($response['error_message'])) {
			$result['error_message'] = substr($response['error_message'], 0, 300);
		}

		$order->update_meta_data(self::get_refund_result_key(), $result);
		$order->save();
	}

	/**
	 * Whether the API adjustment path already handled this order's refund
	 * against the SAME conversion action the CSV adjustments feed targets.
	 *
	 * The upload, the browser tag and (in the typical setup) the feed's
	 * conversion name all point at the one web conversion action, so a feed
	 * row would duplicate the API adjustment. Duplicates are not
	 * double-counted by Google (a second retraction errors, a restatement
	 * sets an absolute value), but they pollute the import diagnostics.
	 *
	 * @param \WC_Order $order     The parent order.
	 * @param int|null  $refund_id A specific refund, or null for the order-level (cancellation) check.
	 * @return bool
	 */
	public static function was_refund_adjusted_via_api( $order, $refund_id = null ) {

		if (!Options::is_google_ads_dm_active()) {
			return false;
		}

		if ($order->meta_exists(self::get_full_refund_hit_key())) {
			return true;
		}

		if (null !== $refund_id) {
			$handled = (array) $order->get_meta(self::get_partial_refund_hits_key(), true);
			return in_array((int) $refund_id, array_map('intval', $handled), true);
		}

		return false;
	}

	public static function get_full_refund_hit_key() {
		return 'pmw_google_dma_full_refund_hit';
	}

	public static function get_partial_refund_hits_key() {
		return 'pmw_google_dma_partial_refund_hits';
	}

	public static function get_refund_result_key() {
		return '_pmw_google_dma_refund_result';
	}

	/**
	 * Per-day identifier coverage of the uploaded orders: how many carried a
	 * click ID, how many only user data, and how many were skipped for
	 * carrying neither. This explains match-rate drop-offs over time, where
	 * old orders often have no click ID left (the confirmation page was
	 * never loaded, or the visitor arrived without one).
	 *
	 * @param int $days How many days back to report on.
	 * @return array Day (Y-m-d) => counters, newest first.
	 */
	public static function get_identifier_coverage_by_day( $days = 30 ) {

		$orders = wc_get_orders([
			'limit'        => 500,
			'orderby'      => 'date',
			'order'        => 'DESC',
			'type'         => 'shop_order',
			'status'       => Shop::get_order_paid_statuses(),
			'date_created' => '>=' . ( time() - (int) $days * DAY_IN_SECONDS ),
		]);

		$by_day = [];

		foreach ($orders as $order) {

			$date = $order->get_date_created();

			if (!$date) {
				continue;
			}

			$day = $date->date('Y-m-d');

			if (!isset($by_day[$day])) {
				$by_day[$day] = [
					'orders'         => 0,
					'uploaded'       => 0,
					// The value story: the browser tag never fired AND the
					// upload was recorded, so the conversion exists in Google
					// Ads only because of the upload.
					'recovered'      => 0,
					'with_click_id'  => 0,
					'user_data_only' => 0,
					'no_identifiers' => 0,
					'browser_fired'  => 0,
				];
			}

			$by_day[$day]['orders']++;

			$browser_fired = $order->meta_exists('_wpm_conversion_pixel_fired');

			if ($browser_fired) {
				$by_day[$day]['browser_fired']++;
			}

			$result = $order->get_meta(self::get_upload_result_key(), true);

			if (!is_array($result) || empty($result['status'])) {
				continue;
			}

			if ('success' === $result['status']) {
				$by_day[$day]['uploaded']++;

				if (!$browser_fired) {
					$by_day[$day]['recovered']++;
				}
			}

			$identifiers = isset($result['identifiers']) && is_array($result['identifiers']) ? $result['identifiers'] : [];
			$click_ids   = array_intersect($identifiers, [ 'gclid', 'gbraid', 'wbraid' ]);

			if (!empty($click_ids)) {
				$by_day[$day]['with_click_id']++;
			} elseif (in_array('user_data', $identifiers, true)) {
				$by_day[$day]['user_data_only']++;
			} else {
				$by_day[$day]['no_identifiers']++;
			}
		}

		return $by_day;
	}

	/**
	 * Per-order diagnostic for the most recent uploads: what the upload sent
	 * versus what the order actually holds.
	 *
	 * The point is to separate two very different failures that look identical
	 * in the aggregate. "No click ID on the order at all" means the capture
	 * never got one (not an ad click, or the click ID was lost between landing
	 * and checkout). "Click ID on the order but not in the upload" would be
	 * our bug. Google can only attribute an import-action conversion when a
	 * click ID travelled with it, so this is the table that explains a zero.
	 *
	 * @param int $limit How many recent uploaded orders to inspect.
	 * @return array
	 */
	public static function get_recent_upload_diagnostics( $limit = 20, $browser_missed_only = true ) {

		// The browser-missed orders are the ones the upload has to carry
		// alone, so they are the direct readout of how well the click ID
		// capture performs exactly when it matters - the debug report lists
		// only those. The diagnostics card also shows the unfiltered recent
		// rows, where the deduplication with the browser tag is visible. The
		// scan window is wide because browser-missed rows are (hopefully)
		// the rare ones.
		//
		// Paid statuses only, matching the daily coverage query: an order
		// that was refunded or cancelled after its upload leaves this list
		// AND the chart together, because its conversion was retracted - a
		// row here that the chart does not count would read as a bug.
		$orders = wc_get_orders([
			'limit'   => 250,
			'orderby' => 'date',
			'order'   => 'DESC',
			'type'    => 'shop_order',
			'status'  => Shop::get_order_paid_statuses(),
		]);

		$rows = [];

		foreach ($orders as $order) {

			$upload_result = $order->get_meta(self::get_upload_result_key(), true);

			if (!is_array($upload_result) || empty($upload_result['status'])) {
				continue;
			}

			if ($browser_missed_only && $order->meta_exists('_wpm_conversion_pixel_fired')) {
				continue;
			}

			$sent = isset($upload_result['identifiers']) && is_array($upload_result['identifiers'])
				? $upload_result['identifiers']
				: [];

			// What the order itself holds, independent of what was sent.
			$on_order = [];

			foreach ([ 'gclid', 'wbraid', 'gbraid' ] as $key) {
				if (class_exists('SweetCode\Pixel_Manager\Click_Ids')
					&& '' !== (string) \SweetCode\Pixel_Manager\Click_Ids::get_click_id_from_order($order, $key)) {
					$on_order[] = $key;
				}
			}

			$date = $order->get_date_created();

			$rows[] = [
				'order_number'  => (string) $order->get_order_number(),
				'date'          => $date ? $date->date('Y-m-d H:i') : '',
				'status'        => (string) $upload_result['status'],
				'sent'          => array_values($sent),
				'on_order'      => $on_order,
				'browser_fired' => $order->meta_exists('_wpm_conversion_pixel_fired'),
				// The case that would be our fault: the order carries a click
				// ID that the upload did not send.
				'click_id_lost' => !empty($on_order) && empty(array_intersect($sent, [ 'gclid', 'wbraid', 'gbraid' ])),
			];

			if (count($rows) >= (int) $limit) {
				break;
			}
		}

		return $rows;
	}

	/**
	 * Local browser-vs-API comparison over the most recent uploaded orders:
	 * how often the browser conversion pixel actually fired, how often the
	 * upload succeeded, and which orders the upload recovered (upload
	 * succeeded while the browser pixel never fired). Complements the overlap
	 * and uplift estimates Google shows in the conversion Diagnostics tab.
	 *
	 * Cached for five minutes; scanning is bounded to the newest orders.
	 *
	 * @return array
	 */
	public static function get_delta_report() {

		$cached = get_transient(self::DELTA_REPORT_TRANSIENT);

		if (is_array($cached)) {
			return $cached;
		}

		$orders = wc_get_orders([
			'limit'   => 250,
			'orderby' => 'date',
			'order'   => 'DESC',
			'type'    => 'shop_order',
		]);

		$rows = [];

		foreach ($orders as $order) {

			$upload_result = $order->get_meta(self::get_upload_result_key(), true);

			// Only orders the upload actually attempted count, so the report
			// starts with the feature and is not diluted by history.
			if (!is_array($upload_result) || empty($upload_result['status'])) {
				continue;
			}

			$rows[] = [
				'upload_status' => (string) $upload_result['status'],
				'browser_fired' => $order->meta_exists('_wpm_conversion_pixel_fired'),
				'order_number'  => (string) $order->get_order_number(),
				'identifiers'   => isset($upload_result['identifiers']) && is_array($upload_result['identifiers'])
					? $upload_result['identifiers']
					: [],
			];
		}

		$report = self::summarize_delta_rows($rows);

		set_transient(self::DELTA_REPORT_TRANSIENT, $report, 5 * MINUTE_IN_SECONDS);

		return $report;
	}

	/**
	 * Aggregates the per-order rows into the delta report.
	 *
	 * @param array $rows Each: { upload_status: string, browser_fired: bool, order_number: string }.
	 * @return array
	 */
	public static function summarize_delta_rows( $rows ) {

		$report = [
			'attempted'               => count($rows),
			'upload_success'          => 0,
			'upload_validate_only'    => 0,
			'upload_error'            => 0,
			'upload_throttled'        => 0,
			'browser_fired'           => 0,
			'recovered'               => 0,
			'recovered_order_numbers' => [],
			// What Google had to match on. A conversion can only be credited
			// to a campaign when a click ID was present, or when the hashed
			// customer data matches a signed-in Google user who clicked an ad
			// inside the click-through window - so this composition is what
			// explains a low match rate far better than the upload count.
			'with_click_id'           => 0,
			'with_user_data_only'     => 0,
			'without_identifiers'     => 0,
		];

		foreach ($rows as $row) {

			if ('success' === $row['upload_status']) {
				$report['upload_success']++;
			} elseif ('validate_only' === $row['upload_status']) {
				$report['upload_validate_only']++;
			} elseif ('throttled' === $row['upload_status']) {
				$report['upload_throttled']++;
			} else {
				$report['upload_error']++;
			}

			if (!empty($row['browser_fired'])) {
				$report['browser_fired']++;
			}

			$identifiers = isset($row['identifiers']) && is_array($row['identifiers']) ? $row['identifiers'] : [];
			$click_ids   = array_intersect($identifiers, [ 'gclid', 'gbraid', 'wbraid' ]);

			if (!empty($click_ids)) {
				$report['with_click_id']++;
			} elseif (in_array('user_data', $identifiers, true)) {
				$report['with_user_data_only']++;
			} else {
				$report['without_identifiers']++;
			}

			// Recovered: the upload recorded a conversion the browser pixel never sent
			if ('success' === $row['upload_status'] && empty($row['browser_fired'])) {

				$report['recovered']++;

				if (count($report['recovered_order_numbers']) < 10) {
					$report['recovered_order_numbers'][] = $row['order_number'];
				}
			}
		}

		return $report;
	}

	private static function get_event_timestamp( $order, $identifiers ) {

		if (!empty($identifiers['event_time']) && is_numeric($identifiers['event_time'])) {
			$timestamp = (int) $identifiers['event_time'];
		} elseif ($order->get_date_paid()) {
			$timestamp = $order->get_date_paid()->getTimestamp();
		} else {
			$timestamp = time();
		}

		return gmdate('Y-m-d\TH:i:s\Z', $timestamp);
	}

	private static function get_gclid_for_order( $order, $identifiers ) {

		if (!empty($identifiers['gclid'])) {
			return $identifiers['gclid'];
		}

		// Legacy fallback: the gclid that the order-received page stored
		$gclid = $order->get_meta('_wpm_gclid', true);

		if (!empty($gclid) && Google_Helpers::is_valid_gclid($gclid)) {
			return $gclid;
		}

		// Historical fallback for orders placed before this feature existed:
		// GA4 MP has been storing the click ID in its own per-order
		// identifiers meta at checkout time on every order, which reaches
		// much further back than _wpm_gclid (that one is only written when
		// the customer actually loads the order confirmation page).
		$gclid = self::get_gclid_from_ga4_identifiers($order);

		if (!empty($gclid)) {
			return $gclid;
		}

		return '';
	}

	/**
	 * Reads the click ID out of the GA4 MP per-order identifiers meta.
	 *
	 * @param \WC_Order $order The order.
	 * @return string The gclid, or an empty string.
	 */
	private static function get_gclid_from_ga4_identifiers( $order ) {

		$measurement_id = Options::get_ga4_measurement_id();

		if (empty($measurement_id)) {
			return '';
		}

		$ga4_identifiers = $order->get_meta('google_cid_' . $measurement_id, true);

		if (!is_array($ga4_identifiers) || empty($ga4_identifiers['gclid'])) {
			return '';
		}

		$gclid = $ga4_identifiers['gclid'];

		return Google_Helpers::is_valid_gclid($gclid) ? $gclid : '';
	}

	/**
	 * Maps the enhanced conversion data shape (built for the browser tag) to
	 * the Data Manager API userData shape. All hashes are hex encoded SHA-256,
	 * matching the request-level encoding HEX.
	 *
	 * @param array $enhanced_conversion_data From Google_Helpers::get_google_enhanced_conversion_data().
	 * @return array
	 */
	public static function map_enhanced_conversion_data_to_user_data( $enhanced_conversion_data ) {

		// UserData is a single userIdentifiers array whose entries each carry
		// EXACTLY ONE of emailAddress, phoneNumber or address (a protobuf
		// oneof; verified against the live API, which rejects plural container
		// fields with INVALID_ARGUMENT). At most 10 identifiers are allowed.
		$user_identifiers = [];

		if (!empty($enhanced_conversion_data['sha256_email_address'])) {
			$user_identifiers[] = [ 'emailAddress' => $enhanced_conversion_data['sha256_email_address'] ];
		}

		if (!empty($enhanced_conversion_data['sha256_phone_number'])) {
			$user_identifiers[] = [ 'phoneNumber' => $enhanced_conversion_data['sha256_phone_number'] ];
		}

		if (!empty($enhanced_conversion_data['address']) && is_array($enhanced_conversion_data['address'])) {

			foreach ($enhanced_conversion_data['address'] as $address) {

				$mapped = [];

				if (!empty($address['sha256_first_name'])) {
					$mapped['givenName'] = $address['sha256_first_name'];
				}

				if (!empty($address['sha256_last_name'])) {
					$mapped['familyName'] = $address['sha256_last_name'];
				}

				if (!empty($address['sha256_street'])) {
					$mapped['addressLine'] = $address['sha256_street'];
				}

				if (!empty($address['city'])) {
					$mapped['city'] = $address['city'];
				}

				if (!empty($address['region'])) {
					$mapped['administrativeArea'] = $address['region'];
				}

				if (!empty($address['postal_code'])) {
					$mapped['postalCode'] = $address['postal_code'];
				}

				if (!empty($address['country'])) {
					$mapped['regionCode'] = strtoupper($address['country']);
				}

				if (!empty($mapped)) {
					$user_identifiers[] = [ 'address' => $mapped ];
				}
			}
		}

		if (empty($user_identifiers)) {
			return [];
		}

		return [ 'userIdentifiers' => $user_identifiers ];
	}

	/**
	 * Maps the consent snapshot stored on the order to the Data Manager API
	 * consent object. Orders without a snapshot return no consent object,
	 * Google then treats the consent state as unspecified.
	 *
	 * Reads 'marketing' directly rather than through get_consent_category(),
	 * deliberately: adUserData and adPersonalization are advertising signals,
	 * so they follow the marketing category even if the destination were ever
	 * gated on another one. This is not an oversight, do not "fix" it.
	 *
	 * Note that this runs independently of the consent gate in S2S. The gate
	 * decides whether an order is uploaded at all, this decides what Google
	 * is told about the visitor's choice once it is.
	 *
	 * @param \WC_Order $order The order.
	 * @return array
	 */
	private static function get_consent_for_order( $order ) {

		$snapshot = $order->get_meta(self::get_consent_snapshot_key(), true);

		if (!is_array($snapshot) || !array_key_exists('marketing', $snapshot)) {
			return [];
		}

		$state = empty($snapshot['marketing']) ? 'CONSENT_DENIED' : 'CONSENT_GRANTED';

		return [
			'adUserData'        => $state,
			'adPersonalization' => $state,
		];
	}

	/**
	 * Upload health for the copy-paste debug report customers attach to
	 * support tickets: the most recent outcome, the browser-vs-upload delta,
	 * and the per-order rows for orders the browser pixel missed - the ones
	 * the upload carries alone. Counts and identifiers only, no PII.
	 *
	 * @return string Empty when the upload is not active.
	 */
	public static function get_debug_info() {

		if (!Options::is_google_ads_dm_active()) {
			return '';
		}

		$html = 'Conversion action: ' . Options::get_google_ads_dm_conversion_action_name()
			. ' (ID ' . Options::get_google_ads_dm_conversion_action_id()
			. ', account ' . Options::get_google_ads_dm_operating_account_id() . ')' . PHP_EOL;

		$last_upload = get_option(self::LAST_UPLOAD_OPTION);

		if (is_array($last_upload) && isset($last_upload['status'])) {
			$html .= 'Last upload: ' . $last_upload['status']
				. ( isset($last_upload['order_number']) ? ' (order #' . $last_upload['order_number'] . ')' : '' )
				. ( !empty($last_upload['identifiers']) ? ' via ' . implode(', ', (array) $last_upload['identifiers']) : '' )
				. ( !empty($last_upload['error_message']) ? ' - ' . $last_upload['error_message'] : '' )
				. PHP_EOL;

			if (!empty($last_upload['field_warnings'])) {
				$html .= 'Fields Google dropped from the last upload: ' . self::format_field_warnings($last_upload['field_warnings']) . PHP_EOL;
			}
		}

		$delta = self::get_delta_report();

		if (is_array($delta) && !empty($delta['attempted'])) {
			$html .= 'Uploaded orders: ' . $delta['attempted']
				. ', browser pixel fired on ' . $delta['browser_fired']
				. ', recovered by the upload: ' . $delta['recovered']
				. ', failed: ' . $delta['upload_error']
				. ( !empty($delta['upload_throttled']) ? ', deferred: ' . $delta['upload_throttled'] : '' )
				. PHP_EOL;
			$html .= 'Matched on: ' . ( isset($delta['with_click_id']) ? $delta['with_click_id'] : 0 ) . ' with a Google click ID, '
				. ( isset($delta['with_user_data_only']) ? $delta['with_user_data_only'] : 0 ) . ' on customer data only'
				. ( !empty($delta['without_identifiers']) ? ', ' . $delta['without_identifiers'] . ' with neither' : '' )
				. PHP_EOL;
		}

		$rows = self::get_recent_upload_diagnostics();

		if (!empty($rows)) {

			$html .= 'Orders the browser pixel missed (upload carries them alone):' . PHP_EOL;

			foreach ($rows as $row) {
				$html .= '  #' . $row['order_number'] . ' ' . $row['date']
					. ' upload=' . $row['status']
					. ' sent=' . ( empty($row['sent']) ? '-' : implode('+', $row['sent']) )
					. ' on_order=' . ( empty($row['on_order']) ? '-' : implode('+', $row['on_order']) )
					. ( !empty($row['click_id_lost']) ? ' <-- click ID on order but not sent' : '' )
					. PHP_EOL;
			}
		}

		$coverage = self::get_identifier_coverage_by_day(14);

		if (!empty($coverage)) {

			$html .= 'Identifier coverage by day (last 14 days):' . PHP_EOL;

			foreach ($coverage as $day => $counters) {
				$html .= '  ' . $day
					. ' orders=' . $counters['orders']
					. ' click_id=' . $counters['with_click_id']
					. ' user_data_only=' . $counters['user_data_only']
					. ' neither=' . $counters['no_identifiers']
					. ' browser=' . $counters['browser_fired']
					. PHP_EOL;
			}
		}

		return $html;
	}
}
