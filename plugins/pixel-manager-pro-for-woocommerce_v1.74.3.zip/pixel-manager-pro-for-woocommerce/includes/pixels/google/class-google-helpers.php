<?php

namespace SweetCode\Pixel_Manager\Pixels\Google;

use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

class Google_Helpers {

	public static function is_ga4_debug_mode_active() {

		$debug_mode = apply_filters_deprecated('wooptpm_enable_ga_4_mp_event_debug_mode', [ false ], '1.13.0', 'pmw_enable_ga_4_mp_event_debug_mode');
		$debug_mode = apply_filters_deprecated('wpm_enable_ga_4_mp_event_debug_mode', [ $debug_mode ], '1.31.2', 'pmw_enable_ga_4_mp_event_debug_mode');

		/**
		 * Filters Enable ga 4 mp event debug mode.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_enable_ga_4_mp_event_debug_mode', $debug_mode);
	}

	/**
	 * Build the Google item payload for a single order line item.
	 *
	 * @param object                  $order_item
	 * @param \WC_Abstract_Order|null $order The order the item belongs to, when the caller has it.
	 * @return array
	 */
	public static function get_order_item_data( $order_item, $order = null ) {

		$product = $order_item->get_product();

		if (Product::is_not_wc_product($product)) {
			return [];
		}

		$dyn_r_ids = Product::get_dyn_r_ids($product);

		/**
		 * Get the name of the product.
		 * For Variations, fall back to the name in the parent product
		 * because on some installs the name is not saved in the Variation.
		 */
		if ($product->get_type() === 'variation') {
			$parent_product = wc_get_product($product->get_parent_id());

			// Fall back to the variation itself if the parent product no longer exists.
			if (Product::is_wc_product($parent_product)) {
				$name  = $parent_product->get_name();
				$brand = Product::get_brand_name($parent_product->get_id());
			} else {
				$name  = $product->get_name();
				$brand = Product::get_brand_name($product->get_id());
			}
		} else {
			$name  = $product->get_name();
			$brand = Product::get_brand_name($product->get_id());
		}

		return [
			'id'             => (string) $dyn_r_ids[self::get_ga_id_type()],
			'name'           => (string) $name,
			'quantity'       => (int) $order_item['quantity'],
			'affiliation'    => (string) get_bloginfo('name'),
			//            'coupon' => '',
			//            'discount' => 0,
			'brand'          => (string) $brand,
			// https://developers.google.com/analytics/devguides/collection/protocol/v1/parameters#pr_ca
			'category'       => implode(',', Product::get_product_category($product->get_id())),
			'category_array' => Product::get_product_category($product->get_id()),
			'variant'        => (string) ( $product->get_type() === 'variation' ) ? Product::get_formatted_variant_text($product) : '',
			//            'tax'      => 0,
			'price'          => Product::pmw_get_order_item_price($order_item, null, $order),
			//            'list_name' => ,
			//            'currency' => '',
		];
	}

	public static function get_ga_id_type() {

		$ga_id_type = 'post_id';

		$ga_id_type = apply_filters_deprecated('wooptpm_product_id_type_for_google_analytics', [ $ga_id_type ], '1.13.0', 'pmw_product_id_type_for_google_analytics');
		$ga_id_type = apply_filters_deprecated('wpm_product_id_type_for_google_analytics', [ $ga_id_type ], '1.31.2', 'pmw_product_id_type_for_google_analytics');

		/**
		 * Change the output of the product ID type for Google Analytics.
		 *
		 * @since 1.31.2
		 */
		return (string) apply_filters('pmw_product_id_type_for_google_analytics', $ga_id_type);
	}

	public static function add_categories_to_ga4_product_items( $item_details_array, $categories ) {

		// If $categories is not an array, return the $item_details_array as is
		if (!is_array($categories)) {
			return $item_details_array;
		}

		$categories = array_unique($categories);

		// Remove empty categories and reindex the array
		$categories = array_values(array_filter($categories));

		if (count($categories) > 0) {

			$max_categories = 5;

			$item_details_array['item_category'] = $categories[0];

			$max = min(count($categories), $max_categories);

			for ($i = 1; $i < $max; $i++) {
				$item_details_array['item_category' . ( $i + 1 )] = $categories[$i];
			}
		}

		return $item_details_array;
	}

	public static function get_google_business_vertical_name_by_id( $id ) {

		$verticals = [
			0 => 'retail',
			1 => 'education',
			2 => 'flights',
			3 => 'hotel_rental',
			4 => 'jobs',
			5 => 'local',
			6 => 'real_estate',
			7 => 'travel',
			8 => 'custom',
		];

		return $verticals[$id];
	}

	public static function get_google_ads_conversion_ids() {

		$google_ads_conversion_identifiers[Options::get_google_ads_conversion_id()] = Options::get_google_ads_conversion_label();

		$google_ads_conversion_identifiers = apply_filters_deprecated('wgact_google_ads_conversion_identifiers', [ $google_ads_conversion_identifiers ], '1.10.2', 'pmw_google_ads_conversion_identifiers');
		$google_ads_conversion_identifiers = apply_filters_deprecated('wooptpm_google_ads_conversion_identifiers', [ $google_ads_conversion_identifiers ], '1.13.0', 'pmw_google_ads_conversion_identifiers');
		$google_ads_conversion_identifiers = apply_filters_deprecated('wpm_google_ads_conversion_identifiers', [ $google_ads_conversion_identifiers ], '1.31.2', 'pmw_google_ads_conversion_identifiers');

		/**
		 * Filters Google ads conversion identifiers.
		 *
		 * @since 1.31.2
		 */
		$google_ads_conversion_identifiers = apply_filters('pmw_google_ads_conversion_identifiers', $google_ads_conversion_identifiers);

		$formatted_conversion_ids = [];

		foreach ($google_ads_conversion_identifiers as $conversion_id => $conversion_label) {
			$conversion_id = self::extract_google_ads_id($conversion_id);
			if ($conversion_id) {
				$formatted_conversion_ids['AW-' . $conversion_id] = $conversion_label;
			}
		}

		return $formatted_conversion_ids;
	}

	private static function extract_google_ads_id( $string ) {

		$re = '/\d{9,11}/';

		if ($string) {

			preg_match($re, $string, $matches, PREG_OFFSET_CAPTURE, 0);

			if (is_array($matches[0])) {

				return $matches[0][0];
			}
		}

		return '';
	}

	/**
	 * Address (first name, last name, postal code, and country are required).
	 * You can optionally provide street address, city, and region as additional match keys.
	 *
	 * Source: https://support.google.com/google-ads/answer/9888145
	 *
	 * https://support.google.com/google-ads/answer/12785474?hl=en-AU&ref_topic=11337914#zippy=%2Cfind-enhanced-conversions-fields-on-your-conversion-page%2Cidentify-and-define-your-enhanced-conversions-fields
	 *
	 * @param $order
	 * @return array
	 */
	public static function get_google_enhanced_conversion_data( $order ) {

		$customer_data = [];

		if ($order->get_billing_email()) {

			$email = $order->get_billing_email();
			$email = self::normalize_for_enhanced_conversions($email);
			$email = self::reformat_email_for_enhanced_conversions($email);
			$email = self::hash_for_enhanced_conversions($email);

			$customer_data['sha256_email_address'] = $email;
		}

		if ($order->get_billing_phone()) {

			$phone_number = (string) $order->get_billing_phone();
			$phone_number = Helpers::get_e164_formatted_phone_number($phone_number, (string) $order->get_billing_country());
			$phone_number = self::normalize_for_enhanced_conversions($phone_number);
			$phone_number = self::hash_for_enhanced_conversions($phone_number);

			$customer_data['sha256_phone_number'] = $phone_number;
		}

		$billing_address = self::get_billing_address_details($order);

		if (self::address_requirements_are_met($billing_address)) {
			$customer_data['address'][] = $billing_address;
		}

		$shipping_address = self::get_shipping_address_details($order);

		if (self::address_requirements_are_met($shipping_address)) {
			// Check if at least one field is different
			if (array_diff_assoc($shipping_address, $billing_address)) {
				$customer_data['address'][] = $shipping_address;
			}
		}

		return $customer_data;
	}

	// Address (first name, last name, postal code, and country are required).
	private static function address_requirements_are_met( $billing_address ) {

		$required_keys        = [ 'first_name', 'last_name', 'postal_code', 'country' ];
		$required_keys_sha256 = [ 'sha256_first_name', 'sha256_last_name', 'postal_code', 'country' ];

		// If $billing_address contains all keys in $required_keys or in $required_keys_sha256 return true, else false
		return empty(array_diff($required_keys, array_keys($billing_address))) || empty(array_diff($required_keys_sha256, array_keys($billing_address)));
	}

	private static function get_billing_address_details( $order ) {

		$customer_data = [];

		if ($order->get_billing_first_name()) {

			$first_name = (string) $order->get_billing_first_name();
			$first_name = self::normalize_for_enhanced_conversions($first_name);
			$first_name = self::hash_for_enhanced_conversions($first_name);

			$customer_data['sha256_first_name'] = $first_name;
		}

		if ($order->get_billing_last_name()) {

			$last_name = (string) $order->get_billing_last_name();
			$last_name = self::normalize_for_enhanced_conversions($last_name);
			$last_name = self::hash_for_enhanced_conversions($last_name);

			$customer_data['sha256_last_name'] = $last_name;
		}

		if ($order->get_billing_address_1()) {

			$street = (string) $order->get_billing_address_1();
			$street = self::normalize_for_enhanced_conversions($street);
			$street = self::hash_for_enhanced_conversions($street);

			$customer_data['sha256_street'] = $street;
		}

		if ($order->get_billing_city()) {

			$city = (string) $order->get_billing_city();
			$city = self::normalize_for_enhanced_conversions($city);

			$customer_data['city'] = $city;
		}

		if ($order->get_billing_state()) {

			$region = (string) $order->get_billing_state();
			$region = self::normalize_for_enhanced_conversions($region);

			$customer_data['region'] = $region;
		}

		if ($order->get_billing_postcode()) {

			$postal_code = (string) $order->get_billing_postcode();
			$postal_code = self::normalize_for_enhanced_conversions($postal_code);

			$customer_data['postal_code'] = $postal_code;
		}

		if ($order->get_billing_country()) {

			$country = (string) $order->get_billing_country();
			$country = self::normalize_for_enhanced_conversions($country);

			$customer_data['country'] = $country;
		}

		return $customer_data;
	}

	private static function get_shipping_address_details( $order ) {

		$customer_data = [];

		if ($order->get_shipping_first_name()) {

			$first_name = (string) $order->get_shipping_first_name();
			$first_name = self::normalize_for_enhanced_conversions($first_name);
			$first_name = self::hash_for_enhanced_conversions($first_name);

			$customer_data['sha256_first_name'] = $first_name;
		}
		if ($order->get_shipping_last_name()) {

			$last_name = (string) $order->get_shipping_last_name();
			$last_name = self::normalize_for_enhanced_conversions($last_name);
			$last_name = self::hash_for_enhanced_conversions($last_name);

			$customer_data['sha256_last_name'] = $last_name;
		}
		if ($order->get_shipping_address_1()) {

			$street = (string) $order->get_shipping_address_1();
			$street = self::normalize_for_enhanced_conversions($street);
			$street = self::hash_for_enhanced_conversions($street);

			$customer_data['sha256_street'] = $street;
		}
		if ($order->get_shipping_city()) {

			$city = (string) $order->get_shipping_city();
			$city = self::normalize_for_enhanced_conversions($city);

			$customer_data['city'] = $city;
		}
		if ($order->get_shipping_state()) {

			$region = (string) $order->get_shipping_state();
			$region = self::normalize_for_enhanced_conversions($region);

			$customer_data['region'] = $region;
		}
		if ($order->get_shipping_postcode()) {

			$postal_code = (string) $order->get_shipping_postcode();
			$postal_code = self::normalize_for_enhanced_conversions($postal_code);

			$customer_data['postal_code'] = $postal_code;
		}
		if ($order->get_shipping_country()) {

			$country = (string) $order->get_shipping_country();
			$country = self::normalize_for_enhanced_conversions($country);

			$customer_data['country'] = $country;
		}

		return $customer_data;
	}

	public static function get_gmc_language() {
		return strtoupper(substr(get_locale(), 0, 2));
	}

	// https://developers.google.com/gtagjs/devguide/linker
	public static function get_google_linker_settings() {
		$linker_settings = apply_filters_deprecated('wooptpm_google_cross_domain_linker_settings', [ null ], '1.13.0', 'pmw_google_cross_domain_linker_settings');
		$linker_settings = apply_filters_deprecated('wpm_google_cross_domain_linker_settings', [ $linker_settings ], '1.31.2', 'pmw_google_cross_domain_linker_settings');

		/**
		 * Filters Google cross domain linker settings.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_google_cross_domain_linker_settings', $linker_settings);
	}

	public static function get_google_consent_mode_ads_data_redaction_setting() {
		/**
		 * As per Google advise 17.11.2022 (Google Snackable event), don't enable
		 * ads_data_redaction by default while URL passthrough is enabled.
		 */
		$ads_data_redaction = apply_filters_deprecated('wooptpm_google_ads_data_redaction', [ false ], '1.13.0', 'wpm_google_ads_data_redaction');
		$ads_data_redaction = apply_filters_deprecated('wooptpm_google_ads_data_redaction', [ $ads_data_redaction ], '1.31.0', 'pmw_google_ads_data_redaction');
		/**
		 * Filters Google ads data redaction.
		 *
		 * @since 1.31.0
		 */
		return (bool) apply_filters('pmw_google_ads_data_redaction', $ads_data_redaction);
	}

	public static function get_google_consent_mode_url_passthrough_setting() {
		$url_passthrough = apply_filters_deprecated('wooptpm_google_url_passthrough', [ true ], '1.13.0', 'wpm_google_url_passthrough');
		$url_passthrough = apply_filters_deprecated('wpm_google_url_passthrough', [ $url_passthrough ], '1.31.0', 'pmw_google_url_passthrough');
		/**
		 * Filters Google url passthrough.
		 *
		 * @since 1.31.0
		 */
		return (bool) apply_filters('pmw_google_url_passthrough', $url_passthrough);
	}

	public static function get_ga4_parameters( $id ) {

		$ga_4_parameters = [];

		$user_id = Shop::get_user_id();

		if (
			Options::is_google_user_id_active()
			&& null !== $user_id
		) {
			$ga_4_parameters['user_id'] = $user_id;
		}

		$ga_4_parameters = apply_filters_deprecated('wooptpm_ga_4_parameters', [ $ga_4_parameters, $id ], '1.13.0', 'pmw_ga_4_parameters');
		$ga_4_parameters = apply_filters_deprecated('wpm_ga_4_parameters', [ $ga_4_parameters, $id ], '1.31.2', 'pmw_ga_4_parameters');

		/**
		 * Filters Ga 4 parameters.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_ga_4_parameters', $ga_4_parameters, $id);
	}

	public static function get_ga_ua_parameters( $id ) {

		$ga_ua_parameters = [
			'anonymize_ip'     => true, // must be a string for correct output
			'link_attribution' => Options::is_google_link_attribution_active(), // must be a string for correct output
		];

		if (Options::is_google_user_id_active() && is_user_logged_in()) {
			$ga_ua_parameters['user_id'] = get_current_user_id();
		}

		$ga_ua_parameters = apply_filters_deprecated('woopt_pm_analytics_parameters', [ $ga_ua_parameters, $id ], '1.10.10', 'pmw_ga_ua_parameters');
		$ga_ua_parameters = apply_filters_deprecated('wooptpm_ga_ua_parameters', [ $ga_ua_parameters, $id ], '1.13.0', 'pmw_ga_ua_parameters');
		$ga_ua_parameters = apply_filters_deprecated('wpm_ga_ua_parameters', [ $ga_ua_parameters, $id ], '1.31.2', 'pmw_ga_ua_parameters');

		/**
		 * Filters Ga ua parameters.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_ga_ua_parameters', $ga_ua_parameters, $id);
	}

	public static function get_all_refund_products( $refund ) {

		$data       = [];
		$item_index = 1;

		foreach ($refund->get_items() as $item_id => $item) {

//            $product = new WC_Product($refund_item->get_product_id());

			$order_item_data = self::get_order_item_data($item, $refund);

			$data['pr' . $item_index . 'id'] = $order_item_data['id'];
			$data['pr' . $item_index . 'qt'] = -1 * $order_item_data['quantity'];
			$data['pr' . $item_index . 'pr'] = $order_item_data['price'];

			++$item_index;
		}

		return $data;
	}

	/**
	 * Normalize and hash for enhanced conversions
	 * https://support.google.com/google-ads/answer/13258081
	 * https://developers.google.com/google-ads/api/docs/conversions/enhanced-conversions/web#php_2
	 *
	 * @param $string
	 *
	 * @return string
	 * @since 1.32.0
	 */
	private static function normalize_for_enhanced_conversions( $string ) {

		$string = Helpers::trim_string($string);
		return strtolower($string);
	}

	/**
	 * Hash for enhanced conversions
	 *
	 * Source: https://support.google.com/google-ads/answer/13258081
	 *
	 * @param $string
	 *
	 * @return string
	 * @since 1.42.5
	 */
	private static function hash_for_enhanced_conversions( $string ) {
		return Helpers::hash_string($string);
	}

	/**
	 * Prepares an email address for enhanced conversions.
	 * https://docs.google.com/document/d/1NRgJZmaFlAEtZ6S9-rAsiUaiW-ie4rQUca5xjNYL1M8/mobilebasic
	 *
	 * @param string $email
	 *
	 * @return string
	 * @since 1.42.5
	 */
	private static function reformat_email_for_enhanced_conversions( $email ) {
		// If the email is a @gmail or a @googlemail address, we need to remove the dots from the local part.

		$parts = explode('@', $email);

		if (isset($parts[1]) && in_array($parts[1], [ 'gmail.com', 'googlemail.com' ])) {
			$local_part = str_replace('.', '', $parts[0]);
			$local_part = str_replace('+', '', $local_part);
			$email      = $local_part . '@' . $parts[1];
		}

		return $email;
	}

	public static function save_gclid_in_order__premium_only( $order ) {

		// https://developer.wordpress.org/reference/functions/metadata_exists/
		if ($order->meta_exists('_wpm_gclid')) {
			return;
		}

		$gclid = self::get_gclid__premium_only();

		// Without a click ID there is nothing to save. Writing an empty value would
		// cost a full $order->save() on every order that didn't come from a Google
		// Ads click, which is the majority on most shops. @since 1.64.1
		if (empty($gclid)) {
			return;
		}

		$order->update_meta_data('_wpm_gclid', $gclid);
		$order->save();
	}

	private static function get_gclid__premium_only() {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);
		$_get    = Helpers::get_input_vars(INPUT_GET);

		if (isset($_cookie['_gcl_aw'])) {
			return self::extract_gclid_from_string__premium_only($_cookie['_gcl_aw']);
		}

		if (is_array($_get) && array_key_exists('gclid', $_get)) {
			return self::extract_gclid_from_string__premium_only($_get['gclid']);
		}

		return null;
	}

	private static function extract_gclid_from_string__premium_only( $string ) {

		$re = '/[\w-]{20,120}/';

		preg_match($re, $string, $matches, PREG_OFFSET_CAPTURE, 0);

		if (isset($matches[0][0])) {
			return $matches[0][0];
		}

		return null;
	}

	/**
	 * Collects the Google Ads click IDs from the current browser request.
	 *
	 * Reads the gtag first-party cookies first (_gcl_aw carries the gclid,
	 * _gcl_gb carries the wbraid) and falls back to the URL parameters
	 * (gclid, wbraid, gbraid). gbraid has no first-party cookie, so it is
	 * captured from the URL parameter only.
	 *
	 * @return array With any of the keys gclid, wbraid, gbraid. Keys without a valid value are absent.
	 *
	 * @since 1.66.0
	 */
	public static function get_click_ids_from_browser__premium_only() {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);
		$_get    = Helpers::get_input_vars(INPUT_GET);

		$click_ids = [];

		$gclid = self::get_gclid__premium_only();

		if (!empty($gclid) && self::is_valid_gclid($gclid)) {
			$click_ids['gclid'] = $gclid;
		}

		// The _gcl_gb cookie value looks like GCL.<timestamp>.<wbraid>
		if (isset($_cookie['_gcl_gb'])) {

			$parts  = explode('.', (string) $_cookie['_gcl_gb']);
			$wbraid = end($parts);

			if (!empty($wbraid) && self::is_valid_braid($wbraid)) {
				$click_ids['wbraid'] = $wbraid;
			}
		}

		foreach ([ 'wbraid', 'gbraid' ] as $braid_key) {

			if (isset($click_ids[$braid_key]) || !is_array($_get) || empty($_get[$braid_key])) {
				continue;
			}

			if (self::is_valid_braid($_get[$braid_key])) {
				$click_ids[$braid_key] = $_get[$braid_key];
			}
		}

		return $click_ids;
	}

	/**
	 * Check if wbraid or gbraid is valid
	 *
	 * @param $braid
	 * @return bool
	 */
	public static function is_valid_braid( $braid ) {
		// Regular expression pattern for gbraid and wbraid.
		// Braid values are base64url-shaped, so dashes and underscores must pass.
		$pattern = '/^[a-zA-Z0-9_-]{1,128}$/';

		// Check if the braid matches the pattern
		return (bool) preg_match($pattern, $braid);
	}

	/**
	 * Check if gclid is valid
	 *
	 * @param $gclid
	 * @return bool
	 */
	public static function is_valid_gclid( $gclid ) {
		// Regular expression pattern for gclid
		$pattern = '/^[\w-]{20,120}$/';

		// Check if the gclid matches the pattern
		return (bool) preg_match($pattern, $gclid);
	}

	/**
	 * Determine the Google tag ID
	 *
	 * Probes gtag.js for each configured ID from the server and picks the ID
	 * that anchors the gtag.js script tag.
	 *
	 * The probe runs on the shop's server, not in the visitor's browser, so a
	 * failed connection says nothing about whether the browser can load the
	 * tag. Until 1.69.3 a timeout, a DNS failure or a host that blocks
	 * outbound HTTP put the ID on the suppressed list for an hour, and the
	 * browser then skipped the GA4 configuration entirely. Only a definitive
	 * answer from Google (a 400, 404 or 410) suppresses an ID now. Anything
	 * else that is not a 200 leaves the ID usable and is recorded under
	 * `unverified`, so the admin can say what happened.
	 *
	 * @return array{active: string|null, suppressed: string[], unverified: array<string, string>, rejected: array<string, string>}
	 *
	 * @since 1.46.1
	 */
	public static function determine_google_tag_id_information() {

		$tag_id_information = [
			'active'     => null,
			'suppressed' => [], // IDs for which Google refused to serve gtag.js
			'rejected'   => [], // Suppressed ID => reason, for the admin notice
			'unverified' => [], // ID => reason, when the server could not get an answer from Google
		];

		$candidates = [];

		if (Options::is_google_ads_active()) {
			$candidates[] = 'AW-' . Options::get_google_ads_conversion_id();
		}

		if (Options::is_google_analytics_active()) {
			$candidates[] = Options::get_ga4_measurement_id();
		}

		foreach ($candidates as $tag_id) {

			$probe = self::probe_gtag_js($tag_id);

			if ('rejected' === $probe['state']) {
				$tag_id_information['suppressed'][]      = $tag_id;
				$tag_id_information['rejected'][$tag_id] = $probe['reason'];
				Logger::debug('Google did not serve the gtag script for ' . $tag_id . ' (' . $probe['reason'] . '). Please check the ID in the Pixel Manager settings.');
				continue;
			}

			if ('unverified' === $probe['state']) {
				$tag_id_information['unverified'][$tag_id] = $probe['reason'];
				Logger::debug('The server could not check the Google gtag script for ' . $tag_id . ' (' . $probe['reason'] . '). The ID is used anyway, because the visitor\'s browser loads the script, not the server.');
			}

			if (!isset($tag_id_information['active'])) {
				$tag_id_information['active'] = $tag_id;
			}
		}

		return $tag_id_information;
	}

	/**
	 * Ask Google whether it serves gtag.js for a tag ID.
	 *
	 * Returns `ok` on a 200, `rejected` only when Google itself answered that
	 * the ID is bad (400, 404 or 410), and `unverified` for everything else:
	 * connection errors, timeouts, rate limiting, server errors, and status
	 * codes an egress proxy or firewall in front of the shop might produce.
	 *
	 * @param string $tag_id
	 *
	 * @return array{state: string, reason: string}
	 *
	 * @since 1.69.3
	 */
	private static function probe_gtag_js( $tag_id ) {

		$response = wp_remote_get('https://www.googletagmanager.com/gtag/js?id=' . rawurlencode($tag_id));

		if (is_wp_error($response)) {
			return [
				'state'  => 'unverified',
				'reason' => $response->get_error_message(),
			];
		}

		$response_code = (int) wp_remote_retrieve_response_code($response);

		if (200 === $response_code) {
			return [
				'state'  => 'ok',
				'reason' => '',
			];
		}

		return [
			'state'  => in_array($response_code, [ 400, 404, 410 ], true) ? 'rejected' : 'unverified',
			'reason' => 'HTTP ' . $response_code,
		];
	}

	/**
	 * The cached result of the last Google tag probe, without probing.
	 *
	 * For the admin, which must not make outbound requests on page load.
	 * Returns null when nothing is cached.
	 *
	 * @return array|null
	 *
	 * @since 1.69.3
	 */
	public static function get_cached_google_tag_id_information() {

		$google_tag_id_information = get_transient('pmw_google_tag_id_information');

		return is_array($google_tag_id_information) ? $google_tag_id_information : null;
	}

	/**
	 * Get the Google tag ID
	 *
	 * @return array
	 *
	 * @since 1.46.1
	 */
	public static function get_google_tag_id_information() {

		$transient_name = 'pmw_google_tag_id_information';

		/**
		 * The transient only caches the (expensive) Google tag availability probing
		 * done in determine_google_tag_id_information(). The filtered tag id is
		 * intentionally NOT cached, so the `pmw_google_tag_id` filter runs on every
		 * request and can override the tag id even when the cache is warm.
		 */
		$google_tag_id_information = get_transient($transient_name);

		if (false === $google_tag_id_information) {
			$google_tag_id_information = self::determine_google_tag_id_information();
			set_transient($transient_name, $google_tag_id_information, HOUR_IN_SECONDS);
		}

		$google_tag_id_information['active'] = self::filter_google_tag_id($google_tag_id_information['active']);

		return $google_tag_id_information;
	}

	/**
	 * Apply the Google tag id filters.
	 *
	 * Runs on every request (the result is not stored in the transient) so that an
	 * override takes effect immediately, regardless of the cached tag availability
	 * information.
	 *
	 * @param string|null $tag_active
	 *
	 * @return string|null
	 *
	 * @since 1.60.1
	 */
	private static function filter_google_tag_id( $tag_active ) {

		$tag_active = apply_filters_deprecated(
			'pmw_google_tracking_id',
			[ $tag_active ],
			'1.48.0',
			'pmw_google_tag_id'
		);

		$tag_active = apply_filters_deprecated(
			'google_tag_id',
			[ $tag_active ],
			'1.60.1',
			'pmw_google_tag_id'
		);

		/**
		 * Filters the Google tag id.
		 *
		 * @since 1.60.1
		 */
		return apply_filters('pmw_google_tag_id', $tag_active);
	}


	/**
	 * Performs a health check for the Google Tag Gateway by sending a request to the gateway's health check endpoint.
	 *
	 * @return array An array containing the status of the health check and any error messages.
	 *
	 * @since 1.48.0
	 */
	public static function gtag_gateway_health_check() {

		$gateway_url = get_site_url() . Options::get_google_tag_gateway_measurement_path() . '/healthy';

		$response = wp_remote_get($gateway_url, [
			'timeout'   => 3,
			'headers'   => [
				'Accept' => 'application/json',
			],
			'sslverify' => false,
		]);

		if (is_wp_error($response)) {

			Logger::error('Google Tag Gateway Health Check: ' . $gateway_url . ' - ' . $response->get_error_message());

			return [
				'status' => false,
				'error'  => 'Request error: ' . $response->get_error_message(),
			];
		}

		$body = wp_remote_retrieve_body($response);
		$code = wp_remote_retrieve_response_code($response);

		if (200 !== $code) {
			if (strpos($body, 'challenge') !== false) {

				Logger::error('Google Tag Gateway Health Check: ' . $gateway_url . ' - Blocked by Cloudflare');

				return [
					'status' => false,
					'error'  => 'Blocked by Cloudflare.',
					'body'   => $body,
				];
			}

			Logger::error('Google Tag Gateway Health Check: ' . $gateway_url . ' - Unexpected response code: ' . $code);

			return [
				'status' => false,
				'error'  => 'Unexpected response code: ' . $code,
				'body'   => $body,
			];
		}

		if (stripos($body, 'ok') !== false) {
			return [
				'status'  => true,
				'message' => 'Gateway is healthy.',
			];
		}

		Logger::error('Google Tag Gateway Health Check: ' . $gateway_url . ' - Unexpected response body: ' . $body);

		return [
			'status' => false,
			'error'  => 'Unexpected response body.',
			'body'   => $body,
		];
	}
}
