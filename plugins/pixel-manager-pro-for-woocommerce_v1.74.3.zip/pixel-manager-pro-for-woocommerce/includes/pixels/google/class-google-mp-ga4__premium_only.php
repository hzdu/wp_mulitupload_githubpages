<?php

namespace SweetCode\Pixel_Manager\Pixels\Google;

use DateTime;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Platforms\Order_Data;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;
use SweetCode\Pixel_Manager\SSP_Purchase_Proxy;
use WC_Order_Refund;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * On initial order completion
 * woocommerce_order_status_completed
 * woocommerce_payment_complete
 * https://woocommerce.github.io/code-reference/files/woocommerce-includes-class-wc-order.html#source-view.121
 *
 * Subscriptions
 * https://stackoverflow.com/a/55912713/4688612
 * https://stackoverflow.com/a/42798968/4688612
 * https://developer.wordpress.org/plugins/http-api/
 * https://stackoverflow.com/a/42868240/4688612
 * https://stackoverflow.com/a/31861577/4688612
 * WC session storage: https://stackoverflow.com/a/52422613/4688612¿
 * https://developers.google.com/gtagjs/reference/api#get
 */
class Google_MP_GA4 extends S2S {

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		self::$http = $http;

		self::hook_into_generic_events();
		self::hook_into_refund_events();
		self::hook_into_subscriptions_events();
	}

	/*****************************************************************
	 * Getters for constants
	 *****************************************************************/

	public static function is_pixel_s2s_active() {
		return Options::is_ga4_mp_active();
	}

	/**
	 * Mark this pixel as routed through the SSP when the SSP is active.
	 *
	 * The S2S base class consults this flag in send_purchase_hit_order_id()
	 * to skip the direct purchase send so SSP_Purchase_Proxy can collect
	 * and bundle the payload instead.
	 *
	 * @return bool
	 * @since 1.58.12
	 */
	public static function is_handled_by_ssp() {
		return true;
	}

	/**
	 * GA4 has a standard refund event, so refunds are reported to it.
	 *
	 * Documented at
	 * https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference/events#refund
	 *
	 * @return bool
	 * @since 1.65.2
	 */
	public static function supports_refund_events() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'google_cid_' . Options::get_ga4_measurement_id();
	}

	public static function get_purchase_hit_key() {
		return 'wpm_google_analytics_4_mp_purchase_hit';
	}

	/**
	 * GA4 is an analytics destination, so its server-side purchase
	 * events are gated on the statistics consent category, not marketing.
	 *
	 * @since 1.62.0
	 */
	public static function get_consent_category() {
		return 'statistics';
	}

	/**
	 * Whether the purchase event for this order was suppressed because the
	 * visitor denied consent. In that case the refund events must be
	 * suppressed too, so GA4 never receives a refund for a purchase it
	 * never saw.
	 *
	 * Checks the explicit suppression marker, not hit-key absence, so
	 * legacy orders (tracked browser-side only) keep sending refunds as
	 * before. When the purchase was sent later after all (e.g. the shop
	 * manager enabled always_send_s2s), the hit key exists and refunds
	 * flow again.
	 *
	 * @param \WC_Order $order The order.
	 * @return bool
	 * @since 1.62.0
	 */
	private static function was_purchase_suppressed_by_consent( $order ) {

		if ($order->meta_exists(self::get_purchase_hit_key())) {
			return false;
		}

		$suppressed = (array) $order->get_meta(self::get_consent_suppressed_key(), true);

		return in_array(self::get_purchase_hit_key(), $suppressed, true);
	}

	/**
	 * Whether a refund event may be reported to GA4 for this order.
	 *
	 * A refund only makes sense for a purchase GA4 actually received. Both
	 * reasons a purchase never left the shop are therefore checked here as
	 * well, so GA4 is never asked to reverse revenue it never recorded:
	 * a purchase suppressed by the visitor's consent choice, and a purchase
	 * skipped through the pmw_skip_s2s_purchase_event filter, which is what
	 * the split payment integration uses for instalment orders and what shops
	 * use for imported marketplace orders.
	 *
	 * @param \WC_Order $order The order.
	 * @return bool
	 * @since 1.65.2
	 */
	private static function is_refund_reportable( $order ) {

		if (!self::track_google_analytics_refunds()) {
			Logger::debug('S2S: Refund not reported for order ' . $order->get_id() . ' - refund tracking is disabled through the pmw_google_analytics_refund_tracking filter [' . self::class . ']');
			return false;
		}

		// Don't send a refund for a purchase that was consent-suppressed
		if (self::was_purchase_suppressed_by_consent($order)) {
			Logger::info('S2S: Refund suppressed for order ' . $order->get_id() . ' - the purchase event was suppressed by consent [' . self::class . ']');
			return false;
		}

		// Don't send a refund for a renewal whose purchase was never reported. A
		// renewal that went out while renewal tracking was still on keeps its
		// refund: the purchase hit meta proves GA4 has the revenue to reverse.
		// @since 1.67.1
		if (self::can_not_process_subscription_renewal_order($order) && !$order->meta_exists(self::get_purchase_hit_key())) {
			Logger::debug('S2S: Refund not reported for order ' . $order->get_id() . ' - it is a subscription renewal whose purchase was not reported [' . self::class . ']');
			return false;
		}

		/**
		 * Don't send a refund for a purchase the shop asked us to skip.
		 *
		 * @since 1.65.2
		 */
		if (apply_filters('pmw_skip_s2s_purchase_event', false, Order_Data::unwrap($order), self::class)) {
			Logger::debug('S2S: Refund not reported for order ' . $order->get_id() . ' - its server-side purchase event was skipped through the pmw_skip_s2s_purchase_event filter [' . self::class . ']');
			return false;
		}

		return true;
	}

	/**
	 * Whether refunds are reported to Google Analytics at all.
	 *
	 * Server-side refunds carry no session, so Google Analytics files the
	 * reversed revenue under "(not set)". Shops that would rather keep their
	 * attribution reports clean than have Google Analytics net the refunds out
	 * can switch the refund events off with this filter, at the price of a
	 * revenue figure that stays overstated by the refunded amounts.
	 *
	 * @return bool
	 * @since 1.65.2
	 */
	public static function track_google_analytics_refunds() {

		/**
		 * Filters Google Analytics refund tracking.
		 *
		 * @since 1.65.2
		 */
		return (bool) apply_filters('pmw_google_analytics_refund_tracking', true);
	}

	private static function get_full_refund_hit_key() {
		return 'wpm_google_analytics_4_mp_full_refund_hit';
	}

	private static function get_partial_refund_hit_key() {
		return 'wpm_google_analytics_4_mp_partial_refund_hit';
	}

	/**
	 * Refund value GA4 still holds for refunds the shop deleted afterwards.
	 *
	 * @return string
	 * @since 1.71.1
	 */
	private static function get_orphaned_refund_value_key() {
		return 'wpm_google_analytics_4_mp_orphaned_refund_value';
	}

	private static function get_server_base_path( $debug = false ) {

		$server_base_path  = 'https://';
		$server_base_path .= 'www.google-analytics.com';
		$server_base_path .= $debug ? '/debug' : '';
		$server_base_path .= '/mp/collect';
		$server_base_path .= '?measurement_id=';
		$server_base_path .= Options::get_ga4_measurement_id();
		$server_base_path .= '&api_secret=';
		$server_base_path .= Options::get_ga4_mp_api_secret();

		return $server_base_path;
	}

	/*****************************************************************
	 * Hooks
	 *****************************************************************/

	/**
	 * Process the purchase through the GA Measurement Protocol when they are paid, when they change to processing,
	 * or when they are manually set to completed.
	 * https://docs.woocommerce.com/document/managing-orders/
	 *
	 * Maybe also use woocommerce_pre_payment_complete
	 * https://woocommerce.github.io/code-reference/files/woocommerce-includes-class-wc-order.html#source-view.105
	 * */
	public static function get_purchase_trigger_hooks() {

		$hooks = [];

		foreach (Shop::get_order_paid_statuses() as $status) {
			$hooks[] = 'woocommerce_order_status_' . $status;
		}

		$hooks[] = 'woocommerce_payment_complete';

		return $hooks;
	}

	/**
	 * Refund hooks
	 * woocommerce_order_status_refunded
	 * woocommerce_order_refunded
	 * woocommerce_order_partially_refunded
	 * https://github.com/woocommerce/woocommerce/blob/b19500728b4b292562afb65eb3a0c0f50d5859de/includes/wc-order-functions.php#L614
	 *
	 * More refund hooks
	 * woocommerce_order_fully_refunded
	 * https://github.com/woocommerce/woocommerce/blob/b19500728b4b292562afb65eb3a0c0f50d5859de/includes/wc-order-functions.php#L616
	 *
	 * how to tell if order is fully refunded
	 * https://github.com/woocommerce/woocommerce/blob/b19500728b4b292562afb65eb3a0c0f50d5859de/includes/wc-order-functions.php#L774
	 */
	private static function hook_into_refund_events() {
		add_action('woocommerce_order_fully_refunded', [ __CLASS__, 'google_analytics_mp_send_full_refund' ], 10, 2);
		add_action('woocommerce_order_partially_refunded', [ __CLASS__, 'google_analytics_mp_send_partial_refund' ], 10, 2);
	}

	/**
	 * Process WooCommerce Subscription renewals
	 * https://docs.woocommerce.com/document/subscriptions/develop/action-reference/
	 * */
	private static function hook_into_subscriptions_events() {
		add_action('woocommerce_subscription_renewal_payment_complete', [ __CLASS__, 'google_analytics_mp_report_subscription_purchase_renewal' ], 10, 2);
	}

	public static function google_analytics_mp_send_partial_refund( $order_id, $refund_id ) {

		// When the SSP is active, SSP_Purchase_Proxy handles the partial refund
		// bundle at priority 20 on the same hook. Skip the direct send here.
		// @since 1.58.12
		if ( Options::should_process_server_events_via_ssp() ) {
			return;
		}

		$order = wc_get_order($order_id);

		// Abort if no order is found
		if (!$order) {
			return;
		}

		self::send_partial_refund_hit($order, $refund_id);
	}

	public static function google_analytics_mp_send_full_refund( $order_id, $refund_id ) {

		// When the SSP is active, SSP_Purchase_Proxy handles the full refund
		// bundle at priority 20 on the same hook. Skip the direct send here.
		// @since 1.58.12
		if ( Options::should_process_server_events_via_ssp() ) {
			return;
		}

		$order = wc_get_order($order_id);

		// Abort if no order is found
		if (!$order) {
			return;
		}

		self::send_full_refund_hit($order);
	}

	/**
	 * Reverses the GA4 purchase of an order whose payment failed after the
	 * purchase had already been reported, by sending a full refund event.
	 *
	 * Called by Failed_Order_Retractions after its grace period, once it has
	 * confirmed that the order is still failed. Only orders whose purchase
	 * GA4 actually received are reported: a payment declined at checkout
	 * never sent one.
	 *
	 * @param \WC_Order $order The order.
	 * @return void
	 * @since 1.69.3
	 */
	public static function report_failed_order( $order ) {

		if (!$order->meta_exists(self::get_purchase_hit_key()) && !Shop::was_ga4_purchase_sent_from_browser($order)) {
			return;
		}

		self::get_instance();

		if (Options::should_process_server_events_via_ssp()) {
			SSP_Purchase_Proxy::get_instance()->handle_full_refund_event($order->get_id(), 0);
			return;
		}

		self::send_full_refund_hit($order);
	}

	public static function google_analytics_mp_report_subscription_purchase_renewal( $subscription, $renewal_order ) {

		if (!self::track_google_analytics_subscription_renewal()) {
			return;
		}

		$parent_order = $subscription->get_parent();

		// Abort if the order was created manually, and thus no parent order exists.
		if (!$parent_order) {
			return;
		}

		$identifiers = self::get_identifiers_from_order($parent_order);

		self::send_purchase_hit($renewal_order, $identifiers);
	}

	/**
	 * Resolve the GA4 identifiers (client_id, session_id) for a purchase order.
	 *
	 * Subscription renewal orders carry no browser-captured identifiers of their
	 * own — the client_id lives on the subscription's parent order (the original
	 * tracked checkout). The dedicated renewal handler passes those parent
	 * identifiers explicitly, but when the SSP purchase proxy builds the GA4
	 * payload it does so with no identifiers; without this it would fall back to
	 * a random client_id and lose GA4 attribution for the renewal. Resolving the
	 * parent identifiers here means whichever path wins the shared dedup race
	 * uses the same correct client_id.
	 *
	 * @param \WC_Order $order
	 *
	 * @return array
	 * @since 1.59.0
	 */
	private static function get_identifiers_for_purchase_order( $order ) {

		if (Shop::is_wcs_renewal_order($order) && function_exists('wcs_get_subscriptions_for_renewal_order')) {

			// WooCommerce Subscriptions reads the order id off its own order object
			// and cannot resolve the neutral wrapper the server-side path carries.
			$subscriptions = wcs_get_subscriptions_for_renewal_order(Order_Data::unwrap($order));

			if (!empty($subscriptions)) {
				$subscription = reset($subscriptions);
				$parent_order = $subscription->get_parent();

				if ($parent_order) {
					return self::get_identifiers_from_order($parent_order);
				}
			}
		}

		return self::get_identifiers_from_order($order);
	}

	/*****************************************************************
	 * HTTP requests
	 *****************************************************************/

	// We pass the $order and the $cid
	// The $cid is only necessary if it is a subscription renewal order
	// https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference/events#purchase
	public static function send_purchase_hit( $order, $identifiers = null ) {

		// The Measurement Protocol payload has no dedup id Google honours, so two
		// overlapping triggers for one order both counted as purchases. The lock
		// lets only one request through, and the other then sees its marker.
		// @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) use ( $identifiers ) {

			$payload = self::build_ssp_purchase_event_data( $order, $identifiers );

			if ( empty( $payload ) ) {
				return;
			}

			$response = self::$http->post(self::get_server_base_path(), $payload);

			/**
			 * The GA4 Measurement Protocol production endpoint doesn't send error responses,
			 * even if the hit is malformed. So we can't check if the hit was successful.
			 * But we can use the debug endpoint to check if the payload is correct.
			 * https://developers.google.com/analytics/devguides/collection/protocol/ga4/validating-events
			 */

			// A WP_Error means the request never reached Google, so the order stays
			// unmarked and a later paid-status trigger can still send it.
			self::mark_purchase_hit_sent($order, $response);
		});
	}

	/**
	 * Build the GA4 Measurement Protocol payload for a purchase event.
	 *
	 * Returns the same body the direct sender would post to
	 * www.google-analytics.com/mp/collect. Used both by send_purchase_hit()
	 * (direct path) and by SSP_Purchase_Proxy (bundles it with other CAPI
	 * payloads and sends one request to SweetCode Cloud).
	 *
	 * The measurement_id and api_secret are NOT included here: those are
	 * URL query parameters that the SSP adapter (and self::get_server_base_path()
	 * for the direct path) attach to the request.
	 *
	 * @param \WC_Order  $order
	 * @param array|null $identifiers Optional pre-resolved identifiers; resolved from the order when null.
	 *
	 * @return array|null Payload or null if the event should not be sent.
	 * @since 1.58.12
	 */
	public static function build_ssp_purchase_event_data( $order, $identifiers = null ) {

		self::get_instance();

		if (self::can_not_process_subscription_renewal_order($order)) {
			Logger::debug('S2S: Purchase not reported for order ' . $order->get_id() . ' - it is a subscription renewal and renewal tracking is disabled [' . self::class . ']');
			return null;
		}

		if (self::can_not_process_order($order)) {
			return null;
		}

		if (!$identifiers) {
			$identifiers = self::get_identifiers_for_purchase_order($order);
		}

		/**
		 * Only run, if the hit has not been sent already (check in db)
		 * Also run it on subscription renewals,
		 * but not on orders before premium activation (orders missing a cid)
		 */
		if (!self::purchase_hit_can_be_processed($order)) {
			return null;
		}

		$client_id_is_random = false;

		if (isset($identifiers['client_id'])) {
			$client_id = $identifiers['client_id'];
		} else {

			$client_id           = self::get_random_client_id();
			$client_id_is_random = true;

			// No _ga cookie was ever captured for this visitor, so the browser
			// Google tag never ran. The random fallback keeps the revenue in
			// GA4 but cannot be joined to any session, so the order is
			// guaranteed to land under "(not set)".
			// @since 1.64.1
			Logger::debug('GA4 MP purchase order #' . $order->get_id() . ': no _ga cookie was captured, falling back to the random client_id ' . $client_id . '. The browser Google tag did not run for this visitor, so GA4 will report this purchase under "(not set)".' . self::get_consent_note_for_log($order));
		}

		// The client_id is required. The GA4 Measurement Protocol requires
		// `events` to be an array of event objects, even for a single event.
		// https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference?client_type=gtag#payload_post_body
		$payload = [
			'client_id' => $client_id,
			'events'    => [
				[
					'name'   => 'purchase',
					'params' => [
						'transaction_id'     => (string) $order->get_order_number(),
						'value'              => Shop::get_order_value_total_statistics($order),
						'currency'           => (string) $order->get_currency(),
						'tax'                => (float) $order->get_total_tax(),
						'shipping'           => (float) $order->get_shipping_total(),
						'affiliation'        => (string) get_bloginfo('name'),
						'coupon'             => implode(',', $order->get_coupon_codes()),
						'items'              => self::get_all_order_products($order),
						'page_location'      => (string) $order->get_checkout_order_received_url(),
						'payment_type'       => (string) $order->get_payment_method(),
						'payment_type_title' => (string) $order->get_payment_method_title(),
					],
				],
			],
		];

		$custom_parameters = Shop::get_custom_order_parameters($order);

		// If $custom_parameters is not an empty array, merge it with $payload['events'][0]['params']
		if (!empty($custom_parameters)) {
			$payload['events'][0]['params'] = array_merge($payload['events'][0]['params'], $custom_parameters);
		}

		// https://developers.google.com/analytics/devguides/collection/protocol/ga4/sending-events?client_type=gtag#recommended_parameters_for_reports
		// If we have a session id, add it to the payload
		if (isset($identifiers['session_id'])) {

			$payload['events'][0]['params']['session_id'] = $identifiers['session_id'];

			// https://developers.google.com/analytics/devguides/collection/protocol/ga4/sending-events?client_type=gtag#recommended_parameters_for_reports
			$payload['events'][0]['params']['engagement_time_msec'] = 100;

			self::log_session_id_staleness($order, $identifiers['session_id'], isset($identifiers['session_last_hit']) ? $identifiers['session_last_hit'] : null);

		} else {

			// @since 1.64.1
			Logger::debug('GA4 MP purchase order #' . $order->get_id() . ': no GA4 session cookie (_ga_' . self::get_ga4_target_id_suffix(Options::get_ga4_measurement_id()) . ') was captured, so the purchase is sent without a session_id and GA4 will report it under "(not set)". Check that the browser Google tag runs and that the configured measurement ID matches the one setting the cookie.' . self::get_consent_note_for_log($order));
		}

		self::log_attribution_join_record(
			$order,
			$payload['events'][0]['params']['transaction_id'],
			$client_id,
			$client_id_is_random,
			isset($identifiers['session_id']) ? (int) $identifiers['session_id'] : null,
			isset($identifiers['session_last_hit']) ? (int) $identifiers['session_last_hit'] : null,
			isset($identifiers['hit_delivery']) ? $identifiers['hit_delivery'] : null
		);

		/**
		 * Add user_id if it is set in the options and the user is logged in
		 */

		if (Options::is_google_user_id_active()) {

			$user_id = Shop::get_user_id();

			if ($user_id) {
				$payload['user_id'] = $user_id;
			}
		}

		/**
		 * Add user_data if enhanced_conversions is enabled.
		 * The user ID is not mandatory anymore: https://support.google.com/analytics/answer/9164320?hl=en#032024 and https://cln.sh/Wyy1FxKR
		 *
		 * Source: https://developers.google.com/analytics/devguides/collection/ga4/uid-data
		 */
		if (Options::is_google_enhanced_conversions_active()) {
			$payload['user_data'] = Google_Helpers::get_google_enhanced_conversion_data($order);
		}

		/**
		 * Add timestamp_micros (in microseconds) so GA4 attributes the purchase to
		 * the moment the order was placed.
		 * https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference?client_type=gtag#payload_post_body
		 *
		 * The GA4 Measurement Protocol only honors a timestamp up to 72 hours before
		 * Google receives the hit; anything older is silently clamped to the 72h
		 * floor. The purchase hit is dispatched on the paid-status transition, so for
		 * orders that are paid days after they were placed (bank transfer, invoice,
		 * manual confirmation, and similar) backdating to the creation date would
		 * exceed that window and land the order on "received date minus 3 days"
		 * instead of its real date. We therefore only backdate while the order is
		 * still inside the window (with a safety margin for SSP and network transit).
		 * Orders older than the window omit timestamp_micros entirely, so GA4 stamps
		 * them at receive time, which is effectively the payment time.
		 **/
		$ga4_max_backdate_seconds = 71 * HOUR_IN_SECONDS;

		if (!self::is_order_older_than_seconds($order, $ga4_max_backdate_seconds)) {
			$payload['timestamp_micros'] = (int) $order->get_date_created()->getTimestamp() * 1000000;
		}

		if (Google_Helpers::is_ga4_debug_mode_active()) {
			Logger::debug('GA4 event debug mode enabled');
			$payload['events'][0]['params']['debug_mode'] = true;
		}

		// Apply unified filter pipeline
		$payload = self::apply_filters_to_payload($payload, 'purchase', $order);

		// If filters blocked the event, stop processing
		if (empty($payload)) {
			return null;
		}

		return self::filter_purchase_payload('google_ga4', $payload, $order);
	}

	/**
	 * Apply unified filter pipeline to GA4 MP payload
	 *
	 * @param array $payload GA4 MP payload
	 * @param string $event_name Event name (e.g., 'purchase')
	 * @param object $order WC_Order object
	 * @return array|null Filtered payload or null to block event
	 */
	private static function apply_filters_to_payload( $payload, $event_name, $order ) {

		/**
		 * Stage 1: Pixel-specific filter (all events).
		 *
		 * @since 1.58.5
		 */
		$payload = apply_filters('pmw_server_event_payload_google_analytics', $payload, 'google_analytics');

		if (empty($payload)) {
			return null;
		}

		/**
		 * Stage 2: Pixel + Event-specific filter.
		 *
		 * @since 1.58.5
		 */
		$payload = apply_filters("pmw_server_event_payload_google_analytics_{$event_name}", $payload, 'google_analytics', $event_name);

		if (empty($payload)) {
			return null;
		}

		/**
		 * Stage 3: Post-processing filter.
		 *
		 * @since 1.58.5
		 */
		$payload = apply_filters('pmw_server_event_payload_post', $payload, 'google_analytics');

		return $payload;
	}

	// Check if the order is older than two minutes, return true if it is
	private static function is_order_older_than_seconds( $order, $seconds = 10 ) {

		$now        = new DateTime();
		$order_date = $order->get_date_created();

		$diff = $now->getTimestamp() - $order_date->getTimestamp();

		// If the order is older than two minutes, return true
		if ($diff >= $seconds) {
			return true;
		}

		return false;
	}

	/**
	 * Send a full refund hit to GA4.
	 * For full refunds we send the transaction_id together with the original order value
	 * and currency, so GA4 reliably reverses the purchase revenue. The transaction_id on
	 * its own often leaves the GA4 refund amount at 0 and does not deduct the revenue.
	 *
	 * Source: https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference/events#refund
	 *
	 * @param $order
	 * @return void
	 */
	public static function send_full_refund_hit( $order ) {

		$payload = self::build_ssp_full_refund_event_data( $order );

		if ( empty( $payload ) ) {
			return;
		}

		$response = self::$http->post(self::get_server_base_path(), $payload);

		// A WP_Error means the request never left this server. Leave the
		// refund unmarked so a later trigger can still send it. @since 1.69.3
		if (self::refund_dispatch_failed($order, $response, 'full refund')) {
			return;
		}

		self::mark_ssp_full_refund_sent( $order );
	}

	/**
	 * Whether a direct refund request failed before it left this server.
	 *
	 * The refund markers used to be written whatever the request returned, so
	 * a refund that never reached Google was never sent again. A failed
	 * partial refund also counted as reported in the next full refund, which
	 * then reported too little (HS 7063). The purchase sender got the same
	 * check in 1.69.3.
	 *
	 * Requests are non-blocking by default, so only failures raised before
	 * the request leaves the server are caught. A failure on the way to
	 * Google cannot be seen here.
	 *
	 * @param \WC_Order       $order    The order.
	 * @param mixed           $response The HTTP response or WP_Error.
	 * @param string          $what     The refund kind, for the log.
	 * @return bool
	 * @since 1.69.3
	 */
	private static function refund_dispatch_failed( $order, $response, $what ) {

		if (!is_wp_error($response)) {
			return false;
		}

		Logger::warning('GA4 MP ' . $what . ' for order ' . $order->get_id() . ' failed to send and was not marked as sent: ' . $response->get_error_message());

		return true;
	}

	/**
	 * Build the GA4 Measurement Protocol payload for a full refund event.
	 *
	 * Returns null when the hit was already sent for this order or when no
	 * identifiers / order are available. Used by both the direct sender and
	 * SSP_Purchase_Proxy (which bundles refund destinations).
	 *
	 * @param \WC_Order $order
	 *
	 * @return array|null
	 * @since 1.58.12
	 */
	public static function build_ssp_full_refund_event_data( $order ) {

		self::get_instance();

		if (!self::is_refund_reportable($order)) {
			return null;
		}

		// Only run if the hit has not been sent already (check in db)
		if ($order->meta_exists(self::get_full_refund_hit_key())) {
			return null;
		}

		$value = self::get_unreported_refund_value($order);

		// GA4 already holds this refund from a refund the shop deleted later.
		// Sending it again would reverse the revenue twice. @since 1.71.1
		if ($value <= 0 && self::get_orphaned_refund_value($order) > 0) {
			Logger::info('GA4 MP full refund for order ' . $order->get_id() . ' not sent - GA4 still holds the refund of a refund that was deleted later');
			self::mark_ssp_full_refund_sent($order);
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		$payload = [
			'client_id' => isset($identifiers['client_id']) ? $identifiers['client_id'] : self::get_random_client_id(),
			'events'    => [
				[
					'name'   => 'refund',
					'params' => [
						'transaction_id' => $order->get_order_number(),
						'value'          => $value,
						'currency'       => (string) $order->get_currency(),
					],
				],
			],
		];

		if (Google_Helpers::is_ga4_debug_mode_active()) {
			Logger::debug('GA4 event debug mode enabled');
			$payload['events'][0]['params']['debug_mode'] = true;
		}

		// Apply unified filter pipeline
		$payload = self::apply_filters_to_payload($payload, 'refund', $order);

		// If filters blocked the event, stop processing
		if (empty($payload)) {
			return null;
		}

		return $payload;
	}

	/**
	 * Persist the SSP-dispatched full-refund hit so we don't send it twice.
	 *
	 * Called by both the direct sender and SSP_Purchase_Proxy on success.
	 *
	 * @param \WC_Order $order
	 * @return void
	 * @since 1.58.12
	 */
	public static function mark_ssp_full_refund_sent( $order ) {
		$order->update_meta_data(self::get_full_refund_hit_key(), true);
		// GA4 now holds the whole order total, so nothing is left over.
		$order->delete_meta_data(self::get_orphaned_refund_value_key());
		$order->save();
	}

	/**
	 * Send a partial refund hit to GA4
	 * https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference/events#refund
	 *
	 * @param $order
	 * @param $refund_id
	 * @return void
	 */
	public static function send_partial_refund_hit( $order, $refund_id ) {

		$payload = self::build_ssp_partial_refund_event_data( $order, $refund_id );

		if ( empty( $payload ) ) {
			return;
		}

		$response = self::$http->post(self::get_server_base_path(), $payload);

		// Unmarked on failure, so the refund stays in the amount a later full
		// refund reports, and a later trigger can still send it. @since 1.69.3
		if (self::refund_dispatch_failed($order, $response, 'partial refund ' . $refund_id)) {
			return;
		}

		self::mark_ssp_partial_refund_sent( $order, $refund_id );
	}

	/**
	 * Build the GA4 Measurement Protocol payload for a partial refund event.
	 *
	 * Returns null when this specific refund_id was already dispatched.
	 *
	 * @param \WC_Order $order
	 * @param int       $refund_id
	 *
	 * @return array|null
	 * @since 1.58.12
	 */
	public static function build_ssp_partial_refund_event_data( $order, $refund_id ) {

		self::get_instance();

		if (!self::is_refund_reportable($order)) {
			return null;
		}

		// Only run if the hit has not been sent already (check in db)
		if (self::has_partial_refund_hit_already_been_sent($order, $refund_id, self::get_partial_refund_hit_key())) {
			return null;
		}

		// wc_get_order() instead of new WC_Order_Refund(), which throws for a
		// refund that was deleted before a scheduled retry ran. @since 1.71.1
		$refund = wc_get_order($refund_id);

		if (!$refund instanceof WC_Order_Refund) {
			return null;
		}

		$refund_total = abs((float) $refund->get_total());
		$value        = self::get_partial_refund_value_to_report($order, $refund_total);

		// GA4 already holds this refund from a refund the shop deleted later.
		// @since 1.71.1
		if ($value <= 0) {
			Logger::info('GA4 MP partial refund ' . $refund_id . ' for order ' . $order->get_id() . ' not sent - GA4 still holds the refund of a refund that was deleted later');
			self::mark_ssp_partial_refund_sent($order, $refund_id, $refund_total);
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		$params = [
			'transaction_id' => $order->get_order_number(),
			'value'          => $value,
			'currency'       => $order->get_currency(),
		];

		// The line items only match the full refund amount. A refund that is
		// partly covered by a deleted refund reports its value alone.
		if ($value >= (float) Helpers::format_decimal($refund_total, 2)) {
			$params['items'] = self::get_all_order_products($refund);
		}

		$payload = [
			'client_id' => isset($identifiers['client_id']) ? $identifiers['client_id'] : self::get_random_client_id(),
			'events'    => [
				[
					'name'   => 'refund',
					'params' => $params,
				],
			],
		];

		if (Google_Helpers::is_ga4_debug_mode_active()) {
			$payload['events'][0]['params']['debug_mode'] = true;
		}

		// Apply unified filter pipeline
		$payload = self::apply_filters_to_payload($payload, 'refund', $order);

		// If filters blocked the event, stop processing
		if (empty($payload)) {
			return null;
		}

		return $payload;
	}

	/**
	 * Persist the SSP-dispatched partial-refund hit for a specific refund_id.
	 *
	 * The part of the refund that GA4 already held from a deleted refund is
	 * used up here, so the next refund of the order is not reduced again.
	 *
	 * @param \WC_Order  $order
	 * @param int        $refund_id
	 * @param float|null $refund_total The refund amount, looked up when null. @since 1.71.1
	 * @return void
	 * @since 1.58.12
	 */
	public static function mark_ssp_partial_refund_sent( $order, $refund_id, $refund_total = null ) {

		$orphaned = self::get_orphaned_refund_value($order);

		if ($orphaned > 0) {

			if (null === $refund_total) {
				$refund       = wc_get_order($refund_id);
				$refund_total = $refund instanceof WC_Order_Refund ? abs((float) $refund->get_total()) : 0.0;
			}

			self::set_orphaned_refund_value($order, $orphaned - (float) $refund_total);
		}

		self::save_partial_refund_hit_to_db($order, $refund_id, self::get_partial_refund_hit_key());
	}

	/**
	 * The value a partial refund reports, after deducting the refund value
	 * GA4 still holds from refunds the shop deleted afterwards.
	 *
	 * @param \WC_Order $order
	 * @param float     $refund_total The refund amount.
	 * @return float
	 * @since 1.71.1
	 */
	private static function get_partial_refund_value_to_report( $order, $refund_total ) {
		return (float) Helpers::format_decimal(max(0.0, abs((float) $refund_total) - self::get_orphaned_refund_value($order)), 2);
	}

	/**
	 * Reconciles the refund markers after the shop deleted a refund.
	 *
	 * Gateways delete a refund that failed or was canceled after the gateway
	 * first accepted it (Stripe, WooPayments), and shop managers delete
	 * refunds by hand. If the refund event already reached GA4, GA4 keeps it:
	 * the Measurement Protocol has no event that reverses a refund, a second
	 * purchase with the same transaction ID is dropped as a duplicate, and a
	 * negative refund value is not supported. The revenue of the order
	 * therefore stays understated in GA4 until the order is refunded again.
	 *
	 * What this method does make right is the next refund of the order. The
	 * value GA4 still holds for the deleted refund is kept as an orphaned
	 * refund value, and deducted from the next refunds, so the refunds GA4
	 * holds never add up to more than the order. Without this a refund
	 * retried after a failed one reported the amount twice, and a full refund
	 * after a deleted partial refund reported the whole order total again.
	 *
	 * The full refund marker is cleared once the order is no longer fully
	 * refunded, because GA4 then holds the whole order total no matter which
	 * of its refunds was deleted.
	 *
	 * @param \WC_Order $order     The parent order.
	 * @param int       $refund_id The deleted WooCommerce refund.
	 * @param float     $amount    The amount of the deleted refund.
	 * @return void
	 * @since 1.71.1
	 */
	public static function handle_deleted_refund( $order, $refund_id, $amount ) {

		$amount      = abs((float) $amount);
		$partial_ids = $order->get_meta(self::get_partial_refund_hit_key(), true);
		$partial_ids = is_array($partial_ids) ? array_map('intval', $partial_ids) : [];
		$was_partial = in_array((int) $refund_id, $partial_ids, true);
		$had_full    = $order->meta_exists(self::get_full_refund_hit_key());

		// GA4 never received a refund for this order, so it has nothing to undo
		if (!$was_partial && !$had_full) {
			return;
		}

		if ($was_partial) {
			$order->update_meta_data(self::get_partial_refund_hit_key(), array_values(array_diff($partial_ids, [ (int) $refund_id ])));
			self::set_orphaned_refund_value($order, self::get_orphaned_refund_value($order) + $amount);
		}

		if ($had_full && $amount > 0) {
			$order->delete_meta_data(self::get_full_refund_hit_key());

			$order_total = (float) Shop::get_order_value_total_statistics($order);
			self::set_orphaned_refund_value($order, $order_total - self::get_reported_partial_refund_total($order));
		}

		$order->save();

		Logger::info('GA4 MP: Refund ' . $refund_id . ' of order ' . $order->get_id() . ' was deleted after GA4 received it. GA4 cannot reverse a refund, so it keeps ' . self::get_orphaned_refund_value($order) . ' refunded, which is deducted from the next refunds of the order');
	}

	/**
	 * The refund value GA4 still holds from refunds the shop deleted.
	 *
	 * @param \WC_Order $order
	 * @return float
	 * @since 1.71.1
	 */
	private static function get_orphaned_refund_value( $order ) {
		return max(0.0, (float) $order->get_meta(self::get_orphaned_refund_value_key(), true));
	}

	/**
	 * Stores the orphaned refund value, without saving the order.
	 *
	 * @param \WC_Order $order
	 * @param float     $value
	 * @return void
	 * @since 1.71.1
	 */
	private static function set_orphaned_refund_value( $order, $value ) {

		$value = (float) Helpers::format_decimal(max(0.0, (float) $value), 2);

		if ($value <= 0) {
			$order->delete_meta_data(self::get_orphaned_refund_value_key());
			return;
		}

		$order->update_meta_data(self::get_orphaned_refund_value_key(), $value);
	}

	/**
	 * The refund amount the full-refund event has to report.
	 *
	 * WooCommerce fires woocommerce_order_fully_refunded on the refund that
	 * completes the order, which may follow any number of partial refunds we
	 * have already reported. The full-refund event carries no line items, so
	 * Google Analytics books its value on top of those partial refunds instead
	 * of replacing them. Reporting the order total here would therefore reverse
	 * more revenue than was refunded: an order of 100 refunded in two halves
	 * would be reported as 50 + 100. We report the amount that has not been
	 * reported yet instead, so the refunds of an order always add up to its
	 * total. An order refunded in one go is unaffected, because nothing was
	 * reported before it.
	 *
	 * The refund value GA4 still holds from refunds the shop deleted later
	 * counts as reported too (see handle_deleted_refund()). @since 1.71.1
	 *
	 * @param \WC_Order $order
	 * @return float
	 * @since 1.65.2
	 */
	private static function get_unreported_refund_value( $order ) {

		$order_total      = (float) Shop::get_order_value_total_statistics($order);
		$already_reported = self::get_reported_partial_refund_total($order) + self::get_orphaned_refund_value($order);

		if ($already_reported <= 0) {
			return $order_total;
		}

		$value = (float) Helpers::format_decimal(max(0.0, $order_total - $already_reported), 2);

		Logger::debug('GA4 MP full refund order #' . $order->get_id() . ': ' . $already_reported . ' of ' . $order_total . ' was already reported through earlier refund events, so the full refund event reports the remaining ' . $value);

		return $value;
	}

	/**
	 * Sum of the partial refunds of this order that were already reported.
	 *
	 * Only the refunds whose partial refund event was actually dispatched are
	 * counted, so refunds that were never reported (created before the
	 * Measurement Protocol was configured, or dropped by a failed dispatch)
	 * correctly stay in the amount the full refund event still has to report.
	 *
	 * @param \WC_Order $order
	 * @return float
	 * @since 1.65.2
	 */
	private static function get_reported_partial_refund_total( $order ) {

		$refund_ids = $order->get_meta(self::get_partial_refund_hit_key(), true);

		if (!is_array($refund_ids) || empty($refund_ids)) {
			return 0.0;
		}

		$refund_ids = array_map('intval', $refund_ids);
		$total      = 0.0;

		foreach ($order->get_refunds() as $refund) {

			if (!in_array((int) $refund->get_id(), $refund_ids, true)) {
				continue;
			}

			$total += abs((float) $refund->get_total());
		}

		return (float) Helpers::format_decimal($total, 2);
	}

	private static function get_all_order_products( $order ) {

		$items = [];

		// WooCommerce stores refund line items with negative quantities and,
		// depending on the WooCommerce version, negative prices. GA4 refund
		// events require positive item price and quantity, so normalize them.
		$is_refund = $order instanceof WC_Order_Refund;

		foreach (Product::pmw_get_order_items($order) as $item_id => $item) {

			$order_item_data = Google_Helpers::get_order_item_data($item, $order);

			$item_details = [
				'item_id'   => $order_item_data['id'],
				'item_name' => $order_item_data['name'],
				//                'coupon'        => '',
				//                'discount'      => '',
				//                'affiliation'   => '',
				'price'     => $order_item_data['price'],
				//                'currency'      => '',
				'quantity'  => $order_item_data['quantity'],
			];

			if ($is_refund) {
				$item_details = self::normalize_refund_item_values($item_details);
			}

			if (isset($order_item_data['brand'])) {
				$item_details['item_brand'] = $order_item_data['brand'];
			}

			if (isset($order_item_data['variant'])) {
				$item_details['item_variant'] = $order_item_data['variant'];
			}

			$custom_parameters = Shop::get_custom_order_item_parameters($item, $order);

			// If $custom_parameters is not an empty array, merge it with $item_details
			if (!empty($custom_parameters)) {
				$item_details = array_merge($item_details, $custom_parameters);
			}

			$item_details = Google_Helpers::add_categories_to_ga4_product_items($item_details, $order_item_data['category_array']);

			// limit each item to 100 characters
			// This is a GA4 MP limitation
			// https://developers.google.com/analytics/devguides/collection/protocol/ga4/sending-events?client_type=gtag#limitations
			$item_details = array_map(function ( $item ) {
				return substr($item, 0, 100);
			}, $item_details);

			$items[] = $item_details;
		}

		return $items;
	}

	/**
	 * Normalize a refund line item's price and quantity to positive values.
	 *
	 * WooCommerce stores refund line items with negative quantities and,
	 * depending on the WooCommerce version, negative prices. GA4 refund events
	 * require positive item price and quantity (see Google's refund event
	 * reference), so we flip them here. Already-positive values are unchanged.
	 *
	 * @param array $item_details
	 * @return array
	 * @since 1.59.3
	 */
	private static function normalize_refund_item_values( array $item_details ) {

		if (isset($item_details['price'])) {
			$item_details['price'] = abs((float) $item_details['price']);
		}

		if (isset($item_details['quantity'])) {
			$item_details['quantity'] = abs((int) $item_details['quantity']);
		}

		return $item_details;
	}

	/**
	 * Check if the partial refund hit has already been sent
	 *
	 * @param $order
	 * @param $refund_id
	 * @param $mp_partial_refund_hit_key
	 * @return bool
	 */
	private static function has_partial_refund_hit_already_been_sent( $order, $refund_id, $mp_partial_refund_hit_key ) {

		$meta_value = $order->get_meta($mp_partial_refund_hit_key, true);

		if (is_array($meta_value)) {
			return in_array($refund_id, $meta_value);
		}

		return false;
	}

	/**
	 * Save the partial refund hit to the database
	 *
	 * @param $order
	 * @param $refund_id
	 * @param $mp_partial_refund_hit_key
	 */
	private static function save_partial_refund_hit_to_db( $order, $refund_id, $mp_partial_refund_hit_key ) {

		$meta_value = $order->get_meta($mp_partial_refund_hit_key, true);

		if (!is_array($meta_value)) {
			$meta_value = [];
		}

		$meta_value[] = $refund_id;

		$order->update_meta_data($mp_partial_refund_hit_key, $meta_value);
		$order->save();
	}

	/**
	 * The idle time after which this diagnostic reports a session, in seconds.
	 *
	 * This is deliberately NOT the GA4 property session timeout. That timeout
	 * governs when the browser tag starts a new session, not whether GA4 joins
	 * a Measurement Protocol event to the session_id the plugin sends. A shop
	 * that measured its own orders against GA4 found purchases attributed
	 * normally at 31 minutes and at 2 hours of idle time, and unattributed at
	 * 3 and 4 days, so the boundary that matters is counted in days.
	 *
	 * 24 hours sits inside that measured gap. It is not a documented Google
	 * rule, and the log line says what it measured rather than predicting the
	 * outcome.
	 *
	 * @return int
	 * @since 1.69.0
	 */
	private static function get_ga4_session_idle_threshold_in_seconds() {

		/**
		 * Filters the idle time after which a GA4 session is reported in the
		 * session staleness log line, in hours.
		 *
		 * Counted from the last hit the browser Google tag recorded, or from
		 * the start of the session when the cookie carries no last hit. Lower
		 * it to see more of these orders, raise it to see fewer. It only
		 * affects diagnostics, never what is sent.
		 *
		 * @param int $hours The idle threshold in hours. Default 24.
		 *
		 * @since 1.69.0
		 */
		$hours = (int) apply_filters('pmw_ga4_session_idle_threshold_hours', 24);

		if ($hours < 1) {
			$hours = 24;
		}

		return $hours * HOUR_IN_SECONDS;
	}

	/**
	 * Record the identity every GA4 Measurement Protocol purchase is sent with.
	 *
	 * The three warning lines above name the states the shop can prove from
	 * its own request: no _ga cookie, no session cookie, and a session whose
	 * last hit is older than the timeout. Between them they cover every cause
	 * that is visible from here, which is not the same as every cause. A
	 * purchase can carry a client_id and a session_id that both look healthy
	 * and still land under "(not set)", because what decides it is whether
	 * Google holds a session for that client_id, and nothing the shop can read
	 * answers that. The tag refreshes the cookie when it *sends* a hit, not
	 * when Google acknowledges one, so a blocked or failed collect request
	 * leaves a cookie that is indistinguishable from a healthy one.
	 *
	 * The silence of the three lines therefore reads as an all clear that was
	 * never measured. This line exists so it cannot: it records the join keys
	 * for every purchase, whether or not anything looked wrong, so the orders
	 * GA4 reports as "(not set)" can be subtracted from the ones a warning
	 * explains. Whatever is left is a cause none of the checks can see, and
	 * the client_id in this line is what looks it up in GA4.
	 *
	 * @param \WC_Order  $order               The order being sent.
	 * @param string     $transaction_id      The transaction ID the purchase is reported under.
	 * @param string     $client_id           The client_id going into the payload.
	 * @param bool       $client_id_is_random Whether that client_id was synthesized rather than read from the _ga cookie.
	 * @param int|null   $session_id          The GA4 session ID going into the payload, if any.
	 * @param int|null   $session_last_hit    Unix timestamp of the last hit the Google tag recorded, if the cookie carried one.
	 * @return void
	 * @since 1.69.0
	 */
	private static function log_attribution_join_record( $order, $transaction_id, $client_id, $client_id_is_random, $session_id = null, $session_last_hit = null, $hit_delivery = null ) {

		$date_created = $order->get_date_created();

		if (!$date_created) {
			return;
		}

		Logger::debug(self::build_attribution_join_record_message(
			$order->get_id(),
			$transaction_id,
			$client_id,
			$client_id_is_random,
			$session_id,
			$session_last_hit,
			$date_created->getTimestamp(),
			$hit_delivery
		));
	}

	/**
	 * Build the join record line.
	 *
	 * Kept apart from the logging so the wording can be asserted without a
	 * WooCommerce order behind it.
	 *
	 * @param int      $order_id            The order ID.
	 * @param string   $transaction_id      The transaction ID the purchase is reported under.
	 * @param string   $client_id           The client_id going into the payload.
	 * @param bool     $client_id_is_random Whether that client_id was synthesized rather than read from the _ga cookie.
	 * @param int|null $session_id          The GA4 session ID going into the payload, if any.
	 * @param int|null $session_last_hit    Unix timestamp of the last hit the Google tag recorded, if the cookie carried one.
	 * @param int         $order_timestamp     Unix timestamp the order was created at.
	 * @param string|null $hit_delivery        What the browser delivery probe saw, if the order carries a verdict.
	 * @return string
	 * @since 1.69.0
	 */
	private static function build_attribution_join_record_message( $order_id, $transaction_id, $client_id, $client_id_is_random, $session_id, $session_last_hit, $order_timestamp, $hit_delivery = null ) {

		if ($client_id_is_random) {
			$client_note = 'client_id ' . $client_id . ' (random, no _ga cookie)';
		} else {
			$client_note = 'client_id ' . $client_id;
		}

		if (!$session_id) {
			$session_note = 'no session_id';
		} elseif ($session_last_hit && (int) $session_last_hit >= (int) $session_id) {
			$session_note = 'session_id ' . $session_id . ', last tag hit ' . human_time_diff((int) $session_last_hit, $order_timestamp) . ' before the order';
		} else {
			$session_note = 'session_id ' . $session_id . ', no last hit in the cookie';
		}

		// A confirmed delivery rules the usual hidden cause out for this
		// order, so the closing sentence must stop naming it. Turning "the
		// cause is not visible from the shop" into "that cause is ruled out"
		// is the whole point of the probe.
		if ('confirmed' === self::get_hit_delivery_state($hit_delivery)) {
			$closing = ' Look this transaction_id up in GA4: if it reports under "(not set)", the usual cause is ruled out for this order, because the hits did reach Google. What is left sits on the Google side of the join rather than on the shop side.';
		} else {
			$closing = ' Look this transaction_id up in GA4: if it reports under "(not set)" and no warning line above names this order, the cause is not visible from the shop, and the usual one is a browser tag whose hits never reached Google, which refreshes this cookie all the same.';
		}

		// The delivery state is repeated here as a bare key=value token, ahead
		// of the prose. A shop counting its own orders should not have to
		// match on a sentence, and the one that asked for this was parsing
		// these lines by hand across a whole day. "none" is written out
		// rather than omitted, so the absence of a reading stays countable.
		$delivery_field = ' hit_delivery=' . ( '' === self::get_hit_delivery_state($hit_delivery) ? 'none' : $hit_delivery ) . '.';

		return 'GA4 MP purchase order #' . $order_id . ' sent as transaction_id ' . $transaction_id . ' with ' . $client_note . ', ' . $session_note . '.' . $delivery_field . self::get_hit_delivery_note($hit_delivery) . $closing;
	}

	/**
	 * The state of a probe verdict, without the HTTP status a failure carries.
	 *
	 * @param string|null $hit_delivery The verdict as the browser recorded it.
	 * @return string An empty string when there is no verdict.
	 * @since 1.69.0
	 */
	private static function get_hit_delivery_state( $hit_delivery ) {

		if (!is_string($hit_delivery) || '' === $hit_delivery) {
			return '';
		}

		$parts = explode(':', $hit_delivery);

		// Only a state the probe can actually produce counts. The value is
		// already validated on the way in, but it arrives from the browser
		// and ends up in a log line, so anything unrecognised is treated as
		// no reading rather than echoed back.
		if (!in_array($parts[0], [ 'confirmed', 'sent', 'failed', 'blocked', 'no_tag', 'unsupported' ], true)) {
			return '';
		}

		return $parts[0];
	}

	/**
	 * Names what the browser delivery probe saw, where the order carries a verdict.
	 *
	 * Every other line around this one is read off the cookie, and the cookie
	 * is written when the Google tag SENDS a hit, not when Google answers one.
	 * A collect request that an extension, an edge cache or the gateway
	 * swallowed therefore leaves a cookie that looks exactly like a healthy
	 * one, which is the state none of those lines can see. The probe watches
	 * the collect requests themselves in the browser, and this is what it
	 * found.
	 *
	 * One caveat worth knowing before reading a confirmation too broadly:
	 * under Google Consent Mode a denied visitor still sends cookieless pings
	 * to the same endpoint, so "confirmed" proves the network path works, not
	 * that GA4 can join the purchase to a session. The wording says exactly
	 * what was measured and no more.
	 *
	 * @param string|null $hit_delivery The verdict as the browser recorded it.
	 * @return string An empty string unless the order carries a verdict.
	 * @since 1.69.0
	 */
	private static function get_hit_delivery_note( $hit_delivery ) {

		$state = self::get_hit_delivery_state($hit_delivery);

		if ('confirmed' === $state) {
			return ' The browser delivery probe saw a GA4 collect request leave the browser and come back answered, so the hits were not swallowed on the way out.';
		}

		if ('sent' === $state) {
			return ' The browser delivery probe saw GA4 collect requests being made but could not read their outcome, which is what every cross-origin collect looks like from a page: Google sends no Timing-Allow-Origin header on its collection endpoints, so the browser will not disclose the status. What this does establish is that the requests left the browser, so nothing in the browser swallowed them. Note that the Google Tag Gateway does not change this on a shop that also runs Google Ads, because the gateway is anchored on the Ads tag and GA4 keeps collecting on its own domain.';
		}

		if ('failed' === $state) {
			$parts  = explode(':', $hit_delivery);
			$status = isset($parts[1]) ? $parts[1] : '';

			return ' The browser delivery probe saw a GA4 collect request come back with HTTP ' . $status . ', so the hit left the browser and was refused on the way. On a shop running the Google Tag Gateway that points at the gateway or at whatever sits in front of it.';
		}

		if ('blocked' === $state) {
			return ' The browser delivery probe saw the Google tag load and then saw no collect request leave the browser at all. That is the cause the cookie cannot show, and it is what puts a healthy-looking client_id under "(not set)".';
		}

		if ('no_tag' === $state) {
			return ' The browser delivery probe saw the Google tag script itself never load, so no hit was ever built.';
		}

		if ('unsupported' === $state) {
			return ' The browser delivery probe found no resource timing it could read in that browser, so it has nothing to say about this order.';
		}

		return '';
	}

	/**
	 * Log a GA4 session that had been idle for a long time before the order.
	 *
	 * What this measures is the time since the last hit the browser Google tag
	 * recorded, not how long the visit had been running. The _ga_<measurement
	 * id> cookie carries both: the session start, which is the session_id, and
	 * the timestamp of the last hit. Measuring from the session start flags
	 * every long shopping session, including the ones where the shopper was
	 * active the whole time, so the last hit is what this measures against
	 * whenever the cookie carried one.
	 *
	 * What this does NOT do is predict the attribution. GA4 joins the purchase
	 * by the session_id the plugin sends, and a shop that checked its own
	 * orders found them attributed normally at 31 minutes and at 2 hours of
	 * idle time, and unattributed at 3 and 4 days. So a long idle time is one
	 * candidate explanation for a purchase reported under "(not set)", worth
	 * ruling in or out against GA4, and nothing more than that.
	 *
	 * Emitted as a log line because diagnosing this from a support log
	 * otherwise means subtracting Unix timestamps by hand, order by order.
	 *
	 * @param \WC_Order $order            The order being sent.
	 * @param int       $session_id       The GA4 session ID going into the payload.
	 * @param int|null  $session_last_hit Unix timestamp of the last hit the Google tag recorded, if the cookie carried one.
	 * @return void
	 * @since 1.64.1
	 * @since 1.69.0 Measures the idle time since the last hit instead of the age of the session.
	 */
	private static function log_session_id_staleness( $order, $session_id, $session_last_hit = null ) {

		$date_created = $order->get_date_created();

		if (!$date_created) {
			return;
		}

		$message = self::build_session_idle_message(
			$order->get_id(),
			$session_id,
			$session_last_hit,
			$date_created->getTimestamp()
		);

		if (!$message) {
			return;
		}

		Logger::debug($message . self::get_consent_note_for_log($order));
	}

	/**
	 * The session idle log line, or null when the session was not idle long enough.
	 *
	 * Split out from the logging so the threshold decision can be tested
	 * without a logger, the same way the join record is.
	 *
	 * @param int      $order_id         The order ID.
	 * @param int      $session_id       The GA4 session ID going into the payload.
	 * @param int|null $session_last_hit Unix timestamp of the last hit the Google tag recorded, if the cookie carried one.
	 * @param int      $order_timestamp  Unix timestamp the order was created at.
	 * @return string|null
	 * @since 1.69.0
	 */
	private static function build_session_idle_message( $order_id, $session_id, $session_last_hit, $order_timestamp ) {

		$threshold = self::get_ga4_session_idle_threshold_in_seconds();
		$last_hit  = (int) $session_last_hit;

		// A last hit that predates the session start is a cookie the plugin
		// cannot make sense of, so it is treated as absent.
		if ($last_hit >= (int) $session_id && $last_hit > 0) {

			if ($order_timestamp - $last_hit <= $threshold) {
				return null;
			}

			return 'GA4 MP purchase order #' . $order_id . ': the browser Google tag last recorded a hit ' . human_time_diff($last_hit, $order_timestamp) . ' before the order was placed, so the tag was not running while the shopper checked out. GA4 may no longer hold session_id ' . $session_id . ' after an idle time that long, in which case it reports this purchase under "(not set)". Look the transaction_id up in GA4 to tell the two apart, because a long idle time alone does not decide it. Adjust what counts as long through the pmw_ga4_session_idle_threshold_hours filter.';
		}

		// No last hit in the cookie. The age of the session is all that is
		// left to measure, and it says nothing about a shopper who stayed
		// active throughout, so the line says so.
		if ($order_timestamp - (int) $session_id <= $threshold) {
			return null;
		}

		return 'GA4 MP purchase order #' . $order_id . ': session_id ' . $session_id . ' started ' . human_time_diff((int) $session_id, $order_timestamp) . ' before the order was placed and the cookie carried no timestamp of the last hit, so this measures the whole visit rather than the idle time. That GA4 session may have expired, in which case GA4 reports this purchase under "(not set)", or the shopper was simply browsing for that long.';
	}

	/**
	 * Names consent as the reason a Google tag never ran, where the order says so.
	 *
	 * Every one of the log lines around this one reads as a tracking defect,
	 * and on shops that ask for consent most of them are not: the visitor
	 * denied the statistics category and the Google tag was never allowed to
	 * run. Without this note the shop has to look each order up by hand to tell
	 * the two apart, which is exactly the work this diagnostic exists to save.
	 *
	 * @param \WC_Order $order The order being sent.
	 * @return string An empty string unless the order records a denial.
	 * @since 1.69.0
	 */
	private static function get_consent_note_for_log( $order ) {

		$snapshot = $order->get_meta(self::get_consent_snapshot_key(), true);

		if (!is_array($snapshot) || empty($snapshot)) {
			return '';
		}

		if (!empty($snapshot[self::get_consent_category()])) {
			return '';
		}

		return ' The visitor denied the ' . self::get_consent_category() . ' consent category on this order, so the browser Google tag was never allowed to run. That is the expected outcome of the consent setup, not a tracking defect.';
	}

	/**
	 * Getting GA4 session ID from browser
	 * gtag('get', 'GA4_MEASUREMENT_ID', 'session_id', (session_id) => {
	 *    console.log(session_id)
	 * })
	 *
	 * Old format _ga:                  GS1.1.1081496294.1.1.1747830394.0.0.0
	 * New format _ga_MEASUREMENT_ID: GS2.1.s1747821527$o1$g1$t1747821573$j0$l0$h0
	 *
	 * The session ID must be an integer
	 *
	 * @param $target_id
	 * @param $_cookie
	 * @return int|null
	 **/
	private static function get_ga4_session_id_from_cookie( $target_id, $_cookie ) {

		$cookie_parts = self::get_ga4_session_cookie_parts($target_id, $_cookie);

		return isset($cookie_parts['session_id']) ? (int) $cookie_parts['session_id'] : null;
	}

	/**
	 * Get the timestamp of the last hit the Google tag recorded, from the
	 * session cookie.
	 *
	 * GA4 measures its session timeout from the last hit, so this is the only
	 * field that tells a long but active shopping session apart from one that
	 * has gone quiet because the tag stopped running. Both cookie formats carry
	 * it: the `t` field in GS2, the sixth segment in GS1.
	 *
	 * @param string $target_id The GA4 measurement ID.
	 * @param array  $_cookie   The request cookies.
	 * @return int|null
	 * @since 1.69.0
	 */
	private static function get_ga4_session_last_hit_from_cookie( $target_id, $_cookie ) {

		$cookie_parts = self::get_ga4_session_cookie_parts($target_id, $_cookie);

		return isset($cookie_parts['timestamp']) ? (int) $cookie_parts['timestamp'] : null;
	}

	/**
	 * Parse the _ga_<measurement id> cookie into its fields.
	 *
	 * @param string $target_id The GA4 measurement ID.
	 * @param array  $_cookie   The request cookies.
	 * @return array|null
	 * @since 1.69.0
	 */
	private static function get_ga4_session_cookie_parts( $target_id, $_cookie ) {

		// If the cookie is not set in the browser, return null
		if (!isset($_cookie['_ga_' . self::get_ga4_target_id_suffix($target_id)])) {
			return null;
		}

		$cookie = $_cookie['_ga_' . self::get_ga4_target_id_suffix($target_id)];

		if (strpos($cookie, 'GS2') === 0) {
			return self::parse_ga4_gs2_cookie($cookie);
		}

		if (strpos($cookie, 'GS1') === 0) {
			return self::parse_ga4_gs1_cookie($cookie);
		}

		return null;
	}

	/**
	 * Extracts and parses the GS1 cookie into an associative array.
	 *
	 * Example: GA1.1.1081496294.1.1.1747830394.0.0.0
	 *
	 * @param string $cookie The GS1 cookie string.
	 * @return array|null An associative array of parsed fields or null if the cookie is invalid.
	 */
	private static function parse_ga4_gs1_cookie( $cookie ) {

		// Check if the cookie starts with "GS1"
		if (strpos($cookie, 'GS1') !== 0) {
			return null;
		}

		$parts = explode('.', $cookie);
		if (count($parts) < 5) {
			Logger::debug('Invalid GS1 cookie format: ' . $cookie);
			return null;
		}

		$data = [
			'type'               => 'Google Stream',
			'analysis_version'   => (int) substr($parts[0], 2), // Extract the number from GS1
			'domain_level'       => (int) $parts[1],
			'session_id'         => (int) $parts[2],
			'session_count'      => (int) $parts[3],
			'engagement_session' => (int) $parts[4],
		];

		// The trailing segments are read one by one, because a cookie that
		// carries fewer of them than the format usually does must still yield
		// the session ID rather than a PHP notice per missing index.
		$optional_keys = [
			5 => 'timestamp',
			6 => 'countdown',
			7 => 'login_set_user_id',
			8 => 'enhanced_client_id',
		];

		foreach ($optional_keys as $index => $key) {
			if (isset($parts[$index])) {
				$data[$key] = (int) $parts[$index];
			}
		}

		return $data;
	}

	/**
	 * Extracts and parses the GS2 cookie into an associative array.
	 *
	 * Example: GS2.1.s1747821527$o1$g1$t1747821573$j0$l0$h0
	 *
	 * @param string $cookie The GS2 cookie string.
	 * @return array|null An associative array of parsed fields or null if the cookie is invalid.
	 */
	private static function parse_ga4_gs2_cookie( $cookie ) {
		// Check if the cookie starts with "GS2"
		if (strpos($cookie, 'GS2') !== 0) {
			return null;
		}

		$parts = explode('.', $cookie);
		if (count($parts) < 3) {
			Logger::debug('Invalid GS2 cookie format: ' . $cookie);
			return null;
		}

		$data = [
			'type'             => 'Google Stream',
			'analysis_version' => (int) substr($parts[0], 2), // Extract the number from GS2
			'domain_level'     => (int) $parts[1],
		];

		$data = array_merge($data, array_reduce(explode('$', $parts[2]), function ( $carry, $part ) {
			$keyMap = [
				's' => 'session_id',
				'o' => 'session_count',
				'g' => 'engagement_session',
				't' => 'timestamp',
				'j' => 'countdown',
				'l' => 'login_set_user_id',
				'h' => 'enhanced_client_id',
			];
			$key    = substr($part, 0, 1);
			$carry[isset($keyMap[$key]) ? $keyMap[$key] : $key] = substr($part, 1); // Use the mapped key or fallback to the original key.
			return $carry;
		}, []));

		// If anything went wrong, then use the logger to log it and return null.
		if (count($data) < 2) {
			Logger::debug('Invalid GS2 cookie format: ' . $cookie);
			return null;
		}

		return $data;
	}

	private static function get_ga4_target_id_suffix( $target_id ) {

		$re = '/[\dA-Z]{4,}/';

		preg_match($re, $target_id, $matches);

		if (isset($matches[0])) {
			return $matches[0];
		}

		return null;
	}

	/**
	 * The GA4 session_id must never be served from the WooCommerce session.
	 *
	 * GA4 starts a new session after 30 minutes of inactivity, so a stored
	 * session_id is stale almost immediately while the WooCommerce session it
	 * was stored in lives on for days. The Measurement Protocol purchase is
	 * the only purchase GA4 receives while the MP is active (the browser tag
	 * stands down, see Shop::should_record_ga4_browser_purchase()), and it
	 * carries no traffic source of its own, so its attribution depends
	 * entirely on being joined to a live session. A stale session_id lands the
	 * order under "(not set)".
	 *
	 * @return string[]
	 * @since 1.64.1
	 */
	protected static function get_volatile_identifier_keys() {
		return [ 'session_id', 'session_last_hit' ];
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);
		$_get    = Helpers::get_input_vars(INPUT_GET);

		// Add the GA4 client_id
		if (isset($_cookie['_ga'])) {

			$client_id = self::get_ga_client_id_from_ga_cookie($_cookie['_ga']);

			if ($client_id) {
				$identifiers['client_id'] = $client_id;
			}
		}

		// Add the GA4 session_id
		if (isset($_cookie['_ga_' . self::get_ga4_target_id_suffix(Options::get_ga4_measurement_id())])) {

			$session_id = self::get_ga4_session_id_from_cookie(Options::get_ga4_measurement_id(), $_cookie);

			if ($session_id) {
				$identifiers['session_id'] = $session_id;
			}

			// Diagnostics only: the same cookie carries the timestamp of the
			// last hit the Google tag recorded, which is what GA4 measures its
			// session timeout against. It never goes into the payload.
			$session_last_hit = self::get_ga4_session_last_hit_from_cookie(Options::get_ga4_measurement_id(), $_cookie);

			if ($session_last_hit) {
				$identifiers['session_last_hit'] = $session_last_hit;
			}
		}

		// Diagnostics only: what the browser delivery probe saw, captured on
		// the cart and checkout pages and carried in the WooCommerce session.
		// It never goes into the payload.
		//
		// Deliberately NOT a volatile identifier. Unlike the session_id, this
		// must be read from the order at purchase time, because a purchase
		// hook that runs from a webhook or cron has no browser behind it and
		// the shopper's own observation is the one that counts.
		//
		// @since 1.69.0
		$transient_identifiers = Shop::get_transient_identifiers_from_session();

		if (!empty($transient_identifiers['ga4_hit_delivery'])) {
			$identifiers['hit_delivery'] = $transient_identifiers['ga4_hit_delivery'];
		}

		// Get Google Ads click ID
		if (isset($_cookie['_gcl_aw'])) {
			$identifiers['gclid'] = self::get_gclid_from_gcl_aw_cookie($_cookie['_gcl_aw']);
		} elseif (isset($_get['gclid'])) {
			$identifiers['gclid'] = $_get['gclid'];
		}

		// Google Ads Double-Click ID
		if (isset($_cookie['_gcl_dc'])) {
			$identifiers['dclid'] = self::get_gclid_from_gcl_aw_cookie($_cookie['_gcl_dc']);
		}

		return $identifiers;
	}

	/**
	 * Get the cid from the $cookie string
	 *
	 * Cookie name: _ga
	 * Format: GA1.1.171933599.1747821527
	 *
	 * The cid is 639182791.1685507935
	 *
	 * @param $cookie
	 * @return string|null
	 */
	private static function get_ga_client_id_from_ga_cookie( $cookie ) {

		$cookie_parts = explode('.', $cookie);

		if (isset($cookie_parts[2]) && isset($cookie_parts[3])) {
			return $cookie_parts[2] . '.' . $cookie_parts[3];
		}

		return null;
	}

	private static function get_gclid_from_gcl_aw_cookie( $cookie ) {

		preg_match('/(GCL.[\d]*.)(.*)/', $cookie, $matches);

		if (isset($matches[2])) {
			return $matches[2];
		}

		return null;
	}

	private static function purchase_hit_can_be_processed( $order ) {

		/**
		 * Only approve, if the hit has not been sent already (check in db)
		 *
		 * Also approve subscription renewals (cid is missing on order but available as argument),
		 * but don't approve normal orders before premium activation where the cid is missing on the order.
		 */

		// Don't approve if the purchase hit has already been processed
		if (self::check_if_purchase_hit_post_meta_exists_for_ga4($order)) {
			Logger::debug('Purchase hit has already been processed for order ID: ' . $order->get_id());
			return false;
		}

		/**
		 * Don't approve if the GA4 purchase was already sent from the browser.
		 *
		 * The browser only sends it while the Measurement Protocol is inactive,
		 * so this marker means the order was tracked during a window in which
		 * the API secret was empty. Without this check, re-enabling the secret
		 * would resend the order on its next paid-status transition and double
		 * count it in GA4.
		 *
		 * @since 1.63.1
		 */
		if (Shop::was_ga4_purchase_sent_from_browser($order)) {
			Logger::debug('Purchase was already sent from the browser for order ID: ' . $order->get_id() . '. Skipping the Measurement Protocol hit.');
			return false;
		}

		// Process order if it is a backend order, otherwise it will fail in the next test
		if (Shop::is_backend_manual_order($order)) {
			Logger::debug('Order ID: ' . $order->get_id() . ' is a backend manual order. Processing purchase hit.');
			return true;
		}

//      if (Shop::was_order_created_while_wpm_was_active($order->get_id())) {
//          return true;
//      }

//      if (Shop::is_backend_subscription_renewal_order($order->get_id())) {
//          return true;
//      }

		if (Shop::was_order_created_while_pmw_premium_was_active($order)) {
			Logger::debug('Order ID: ' . $order->get_id() . ' was created while PMW was active. Processing purchase hit.');
			return true;
		}

		/**
		 * Don't approve if the order was placed before PMW was active
		 */
		if (!Shop::was_order_created_while_pmw_was_active($order)) {
			Logger::debug('Purchase hit not approved for processing. Order ID: ' . $order->get_id() . ' was placed before PMW was active.');
			return false;
		}

		return true;
	}

	/**
	 * Needed to create this because I changed the key and now some order confirmations get re-sent to GA
	 *
	 * @param $order
	 * @return bool
	 */
	private static function check_if_purchase_hit_post_meta_exists_for_ga4( $order ) {

		/**
		 * List of possible db meta keys:
		 * wpm_google_analytics_4_mp_purchase_hit
		 * wooptpm_google_analytics_4_mp_purchase_hit
		 */

		$meta_keys = [
			'wpm_google_analytics_4_mp_purchase_hit',
			'wooptpm_google_analytics_4_mp_purchase_hit',
		];

		foreach ($meta_keys as $key) {
			if ($order->get_meta($key)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Generate a random client ID
	 *
	 * @return string
	 */
	private static function get_random_client_id() {
		$client_id = mt_rand(1000000000, 9999999999) . '.' . time();
		$prefix    = 'anon_';

		return (string) substr_replace($client_id, $prefix, 0, strlen($prefix));
	}

	/*******************************************************************
	 * Filters
	 *******************************************************************/

	/**
	 * If the order is a subscription renewal, only continue if renewal tracking
	 * is enabled.
	 *
	 * Both the renewal opt-outs used to hang off the dedicated
	 * woocommerce_subscription_renewal_payment_complete handler alone, while a
	 * renewal order also reaches the generic purchase hooks and, since 1.57.0,
	 * the SSP purchase proxy. Those two paths carried no renewal check at all,
	 * so switching renewal tracking off changed nothing: the renewal was
	 * reported all the same, only through another path. The check therefore sits
	 * in the payload builder now, which every path passes through. @since 1.67.1
	 *
	 * @param \WC_Abstract_Order|\SweetCode\Pixel_Manager\Platforms\Order_Data $order
	 * @return bool
	 */
	private static function can_process_subscription_renewal_order( $order ) {

		if (!Shop::is_wcs_renewal_order($order)) {
			return true;
		}

		return self::track_google_analytics_subscription_renewal();
	}

	private static function can_not_process_subscription_renewal_order( $order ) {
		return !self::can_process_subscription_renewal_order($order);
	}

	/**
	 * Disable tracking of subscription renewals in Google Analytics.
	 *
	 * @return bool
	 */
	public static function track_google_analytics_subscription_renewal() {

		// Abort if general subscription renewal tracking is disabled
		if (Shop::do_not_track_subscription_renewal()) {
			return false;
		}

		/**
		 * Filters Google analytics subscription renewal tracking.
		 *
		 * @since 1.58.5
		 */
		return (bool) apply_filters('pmw_google_analytics_subscription_renewal_tracking', true);
	}
}
