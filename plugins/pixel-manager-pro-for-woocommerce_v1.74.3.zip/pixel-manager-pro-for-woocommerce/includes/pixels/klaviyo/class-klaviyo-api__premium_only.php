<?php

/**
 * Klaviyo Events API
 * https://developers.klaviyo.com/en/reference/create_event
 * https://developers.klaviyo.com/en/reference/bulk_create_events
 *
 * Reports purchases and refunds to Klaviyo server-side, authenticated with a
 * private API key. Only active in standalone mode: whenever the official
 * Klaviyo plugin is installed, Klaviyo produces Placed Order from its own
 * order sync, and Klaviyo does not deduplicate our unique_id against that
 * event, so sending it too would double every order in Klaviyo.
 *
 * Every metric carries service "woocommerce", which puts the events on the
 * same Klaviyo metrics its WooCommerce integration uses, so a merchant's flows
 * and segments keep working when the shop later connects that integration.
 *
 * @since 1.68.0
 */

namespace SweetCode\Pixel_Manager\Pixels\Klaviyo;

use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class Klaviyo_API
 */
class Klaviyo_API extends S2S {

	/**
	 * The Klaviyo API revision every request is pinned to.
	 *
	 * @since 1.68.0
	 */
	const API_REVISION = '2026-07-15';

	const EVENTS_ENDPOINT = 'https://a.klaviyo.com/api/events';

	const BULK_EVENTS_ENDPOINT = 'https://a.klaviyo.com/api/event-bulk-create-jobs';

	/**
	 * The metric service that binds an event to Klaviyo's WooCommerce
	 * integration metric instead of a generic API metric.
	 *
	 * @since 1.68.0
	 */
	const METRIC_SERVICE = 'woocommerce';

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		// The credential travels in the Authorization header, set once on the
		// HTTP object. The third argument of HTTP::post() is written to the log
		// when request logging is on, so it must never carry the key.
		$request_args = [
			'headers' => [
				'Content-Type'  => 'application/vnd.api+json',
				'Accept'        => 'application/vnd.api+json',
				'revision'      => self::API_REVISION,
				'Authorization' => 'Klaviyo-API-Key ' . Options::get_klaviyo_events_api_token(),
			],
		];

		$http->set_request_args($request_args);

		self::$http = $http;

		self::hook_into_generic_events();
		self::hook_into_refund_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_klaviyo_purchase_dispatch_active();
	}

	/**
	 * Klaviyo is a marketing destination.
	 *
	 * @return string
	 * @since 1.68.0
	 */
	public static function get_consent_category() {
		return 'marketing';
	}

	/**
	 * Klaviyo purchase events are routed through the SSP Purchase Proxy when
	 * the SSP is active. Non-SSP installs, and installs whose SSP dispatch
	 * failed, send directly via send_purchase_hit().
	 *
	 * @return bool
	 * @since 1.68.0
	 */
	public static function is_handled_by_ssp() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'klaviyo_identifiers_' . Options::get_klaviyo_public_api_key();
	}

	public static function get_purchase_hit_key() {
		return 'pmw_klaviyo_events_api_purchase_hit';
	}

	/**
	 * Report refunds as their own event.
	 *
	 * @return void
	 * @since 1.68.0
	 */
	private static function hook_into_refund_events() {
		add_action('woocommerce_order_refunded', [ __CLASS__, 'send_refund_hit' ], 10, 2);
	}

	/**
	 * Add the Klaviyo browser identity to the identifiers.
	 *
	 * The klaviyo.js library keeps its identity in the first-party cookie
	 * __kla_id, a base64 encoded, URL encoded JSON object whose $exchange_id is
	 * the anonymous profile identifier Klaviyo calls _kx. Reading it here, while
	 * the customer's browser is making the request, is what lets the
	 * server-side purchase land on the same Klaviyo profile as the browsing
	 * session. Without it the purchase would create a separate anonymous
	 * profile, and Klaviyo's attribution and abandoned cart flows would never
	 * see that this visitor bought.
	 *
	 * @param array $identifiers
	 * @return array
	 * @since 1.68.0
	 */
	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$exchange_id = self::get_exchange_id_from_cookie();

		if ($exchange_id) {
			$identifiers['klaviyo_exchange_id'] = $exchange_id;
		}

		return $identifiers;
	}

	/**
	 * The $exchange_id from the __kla_id cookie, or an empty string.
	 *
	 * @return string
	 * @since 1.68.0
	 */
	public static function get_exchange_id_from_cookie() {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		if (empty($_cookie['__kla_id'])) {
			return '';
		}

		$decoded = self::decode_kla_id_cookie(wp_unslash($_cookie['__kla_id']));

		if (empty($decoded['$exchange_id']) || !self::is_valid_exchange_id($decoded['$exchange_id'])) {
			return '';
		}

		return sanitize_text_field($decoded['$exchange_id']);
	}

	/**
	 * Decode the __kla_id cookie.
	 *
	 * The klaviyo.js library writes base64(JSON), the Klaviyo plugin's checkout
	 * script writes base64(encodeURIComponent(JSON)). Both are tried.
	 *
	 * @param string $raw
	 * @return array
	 * @since 1.68.0
	 */
	public static function decode_kla_id_cookie( $raw ) {

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		$json = base64_decode(urldecode((string) $raw), true);

		if (false === $json) {
			return [];
		}

		$decoded = json_decode($json, true);

		if (!is_array($decoded)) {
			$decoded = json_decode(urldecode($json), true);
		}

		return is_array($decoded) ? $decoded : [];
	}

	/**
	 * Check if a Klaviyo exchange ID is plausible.
	 *
	 * The ID is an opaque base64 style token, so this only blocks whitespace,
	 * markup and control characters.
	 *
	 * @param mixed $exchange_id
	 * @return bool
	 * @since 1.68.0
	 */
	public static function is_valid_exchange_id( $exchange_id ) {

		if (!is_string($exchange_id)) {
			return false;
		}

		return (bool) preg_match('/^[A-Za-z0-9=_\-]{8,255}$/', $exchange_id);
	}

	/**
	 * Build the purchase payload for an order.
	 *
	 * One bulk event-create job carrying the Placed Order event plus one
	 * Ordered Product event per line item, all on the customer's profile. That
	 * is the pair Klaviyo's own WooCommerce integration produces, and the pair
	 * its prebuilt flows trigger on.
	 *
	 * Shared by the direct send (send_purchase_hit) and the SSP Purchase Proxy,
	 * which forwards it to the SSP worker's Klaviyo adapter (buildRawRequest).
	 * Returns null if the order should not be processed or has no identifiable
	 * customer, since Klaviyo drops events without a profile identifier.
	 *
	 * unique_id is derived from the order ID, so a retry of the same order can
	 * never be counted twice.
	 *
	 * @param \WC_Order $order
	 * @return array|null
	 * @since 1.68.0
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);
		$profile     = self::get_profile($order, $identifiers);

		if (!$profile) {
			Logger::debug('Klaviyo Events API: order ' . $order->get_id() . ' has no email and no Klaviyo exchange ID, skipping');
			return null;
		}

		$time     = self::get_event_time();
		$currency = $order->get_currency();
		$items    = self::get_items($order);
		$value    = (float) Shop::get_order_value_total_marketing($order, true);

		$placed_order_properties = [
			'$event_id'     => (string) $order->get_id(),
			'$value'        => $value,
			'OrderId'       => (string) $order->get_order_number(),
			'Currency'      => $currency,
			'Categories'    => self::get_order_categories($items),
			'ItemNames'     => array_values(array_map(function ( $item ) {
				return $item['ProductName'];
			}, $items)),
			'Items'         => $items,
			'ItemCount'     => array_sum(array_map(function ( $item ) {
				return $item['Quantity'];
			}, $items)),
			'DiscountCode'  => implode(', ', $order->get_coupon_codes()),
			'DiscountValue' => (float) $order->get_total_discount(),
			'$extra'        => [
				'SubTotal'      => (float) $order->get_subtotal(),
				'ShippingTotal' => (float) $order->get_shipping_total(),
				'TaxTotal'      => (float) $order->get_total_tax(),
				'GrandTotal'    => (float) $order->get_total(),
				'PaymentMethod' => (string) $order->get_payment_method_title(),
				'Status'        => (string) $order->get_status(),
			],
			'$source'       => 'Pixel Manager for WooCommerce',
		];

		$events = [
			self::build_event('Placed Order', $placed_order_properties, 'pmw_' . $order->get_id(), $time, $value, $currency),
		];

		foreach ($items as $item) {
			$events[] = self::build_event(
				'Ordered Product',
				array_merge($item, [
					'$event_id' => (string) $order->get_id() . '_' . $item['ItemId'],
					'$value'    => $item['RowTotal'],
					'OrderId'   => (string) $order->get_order_number(),
					'$source'   => 'Pixel Manager for WooCommerce',
				]),
				'pmw_' . $order->get_id() . '_' . $item['ItemId'],
				$time,
				$item['RowTotal'],
				$currency
			);
		}

		return self::filter_purchase_payload('klaviyo', [
			'data' => [
				'type'       => 'event-bulk-create-job',
				'attributes' => [
					'events-bulk-create' => [
						'data' => [
							[
								'type'       => 'event-bulk-create',
								'attributes' => [
									'profile' => [
										'data' => [
											'type'       => 'profile',
											'attributes' => $profile,
										],
									],
									'events'  => [
										'data' => $events,
									],
								],
							],
						],
					],
				],
			],
		], $order);
	}

	/**
	 * Send the purchase directly to the Klaviyo Events API.
	 *
	 * Used when the SSP is not active, and by the SSP Purchase Proxy as the
	 * fallback when the SSP dispatch failed.
	 *
	 * @param \WC_Order $order
	 * @return void
	 * @since 1.68.0
	 */
	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached Klaviyo. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$payload = self::build_ssp_purchase_event_data($order);

			if (!$payload) {
				return;
			}

			$response = self::$http->post(self::BULK_EVENTS_ENDPOINT, $payload);

			if (self::mark_purchase_hit_sent($order, $response)) {
				Logger::debug('Klaviyo Events API purchase hit sent for order ' . $order->get_id());
			}
		});
	}

	/**
	 * Report a refund to Klaviyo as a Refunded Order event.
	 *
	 * Only runs for orders whose purchase event was sent, so consent
	 * suppression and order exclusions carry over to refunds. Refunds are
	 * always sent directly, since the SSP Purchase Proxy only bundles purchase
	 * events.
	 *
	 * @param int $order_id
	 * @param int $refund_id
	 * @return void
	 * @since 1.68.0
	 */
	public static function send_refund_hit( $order_id, $refund_id ) {

		if (!Options::is_klaviyo_purchase_dispatch_active()) {
			return;
		}

		$order = wc_get_order($order_id);

		if (!$order instanceof \WC_Order) {
			return;
		}

		// Only report refunds for orders whose purchase event was sent.
		if (!$order->meta_exists(self::get_purchase_hit_key())) {
			return;
		}

		$refund = wc_get_order($refund_id);

		if (!$refund) {
			return;
		}

		$identifiers = self::get_identifiers_from_order($order);
		$profile     = self::get_profile($order, $identifiers);

		if (!$profile) {
			return;
		}

		$currency = $order->get_currency();
		// Refund totals are stored as negative values in WooCommerce. The
		// absolute amount is reported.
		$value = abs((float) $refund->get_amount());

		$properties = [
			'$event_id'    => (string) $order->get_id() . '_refund_' . $refund_id,
			'$value'       => $value,
			'OrderId'      => (string) $order->get_order_number(),
			'RefundId'     => (string) $refund_id,
			'Currency'     => $currency,
			'RefundReason' => (string) $refund->get_reason(),
			'OrderValue'   => (float) Shop::get_order_value_total_marketing($order, true),
			'$source'      => 'Pixel Manager for WooCommerce',
		];

		// A single event resource carries its profile inline, unlike the bulk
		// job, where the profile wraps the events.
		$event = self::build_event('Refunded Order', $properties, 'pmw_refund_' . $refund_id, self::get_event_time(), $value, $currency);

		$event['attributes']['profile'] = [
			'data' => [
				'type'       => 'profile',
				'attributes' => $profile,
			],
		];

		self::$http->post(self::EVENTS_ENDPOINT, [ 'data' => $event ]);

		Logger::debug('Klaviyo Events API refund hit sent for order ' . $order->get_id());
	}

	/**
	 * The Klaviyo server-side integration is driven by WooCommerce order
	 * hooks. Onsite events are sent by the browser, which owns the Klaviyo
	 * identity, so events relayed from the browser are not used here.
	 *
	 * @param array $event_data
	 * @return void
	 */
	public static function send_event_hit( $event_data ) {}

	/**
	 * One JSON:API event resource.
	 *
	 * @param string $metric_name
	 * @param array  $properties
	 * @param string $unique_id
	 * @param string $time ISO 8601
	 * @param float  $value
	 * @param string $currency
	 * @return array
	 * @since 1.68.0
	 */
	public static function build_event( $metric_name, $properties, $unique_id, $time, $value, $currency ) {
		return [
			'type'       => 'event',
			'attributes' => [
				'properties'     => $properties,
				'time'           => $time,
				'value'          => round((float) $value, 2),
				'value_currency' => $currency,
				'unique_id'      => $unique_id,
				'metric'         => [
					'data' => [
						'type'       => 'metric',
						'attributes' => [
							'name'    => $metric_name,
							'service' => self::METRIC_SERVICE,
						],
					],
				],
			],
		];
	}

	/**
	 * The event time as ISO 8601, in UTC.
	 *
	 * Stamped with server time, because the event is sent as the order reaches
	 * a paid state and a client clock can never be trusted.
	 *
	 * @return string
	 * @since 1.68.0
	 */
	private static function get_event_time() {
		return gmdate('Y-m-d\TH:i:s+00:00');
	}

	/**
	 * The Klaviyo profile for an order.
	 *
	 * The billing email is the primary identifier. The exchange ID captured
	 * from the __kla_id cookie during checkout is added as _kx, so Klaviyo
	 * merges the anonymous browsing profile into the customer's profile. An
	 * order with neither cannot be attributed and returns null.
	 *
	 * @param \WC_Order $order
	 * @param array     $identifiers
	 * @return array|null
	 * @since 1.68.0
	 */
	private static function get_profile( $order, $identifiers ) {

		$profile = [];

		$email = $order->get_billing_email();

		if ($email && is_email($email)) {
			$profile['email'] = $email;
		}

		if (!empty($identifiers['klaviyo_exchange_id'])) {
			$profile['_kx'] = $identifiers['klaviyo_exchange_id'];
		}

		if (empty($profile)) {
			return null;
		}

		if ($order->get_billing_first_name()) {
			$profile['first_name'] = $order->get_billing_first_name();
		}

		if ($order->get_billing_last_name()) {
			$profile['last_name'] = $order->get_billing_last_name();
		}

		$location = array_filter([
			'address1' => $order->get_billing_address_1(),
			'address2' => $order->get_billing_address_2(),
			'city'     => $order->get_billing_city(),
			'region'   => $order->get_billing_state(),
			'country'  => $order->get_billing_country(),
			'zip'      => $order->get_billing_postcode(),
		]);

		if (!empty($location)) {
			$profile['location'] = $location;
		}

		return $profile;
	}

	/**
	 * The line items of an order, in the property shape of Klaviyo's
	 * WooCommerce integration.
	 *
	 * @param \WC_Order $order
	 * @return array
	 * @since 1.68.0
	 */
	private static function get_items( $order ) {

		$items = [];

		foreach (Product::pmw_get_order_items($order) as $order_item) {

			$product_id = Product::get_variation_or_product_id($order_item->get_data(), Options::is_dynamic_remarketing_variations_output_enabled());
			$product    = wc_get_product($product_id);

			// Only add if WooCommerce retrieves a valid product
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			$quantity  = (int) max(1, (int) round((float) $order_item->get_quantity()));
			$row_total = round((float) $order_item->get_total() + (float) $order_item->get_total_tax(), 2);

			$item = [
				'ItemId'      => (int) $order_item->get_id(),
				'ProductID'   => (int) ( $product->get_parent_id() ? $product->get_parent_id() : $product->get_id() ),
				'VariantID'   => (int) ( $product->get_parent_id() ? $product->get_id() : 0 ),
				'SKU'         => (string) $product->get_sku(),
				'ProductName' => $order_item->get_name(),
				'Quantity'    => $quantity,
				'ItemPrice'   => round($row_total / $quantity, 2),
				'RowTotal'    => $row_total,
				'ProductURL'  => (string) $product->get_permalink(),
				'ImageURL'    => (string) wp_get_attachment_image_url($product->get_image_id(), 'full'),
				'Categories'  => self::get_product_categories($product),
			];

			$items[] = $item;
		}

		return $items;
	}

	/**
	 * The category names of a product. Variations carry their parent's.
	 *
	 * @param \WC_Product $product
	 * @return string[]
	 * @since 1.68.0
	 */
	private static function get_product_categories( $product ) {

		$product_id = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();

		$terms = wc_get_product_terms($product_id, 'product_cat', [ 'fields' => 'names' ]);

		if (is_wp_error($terms) || !is_array($terms)) {
			return [];
		}

		return array_values(array_map('strval', $terms));
	}

	/**
	 * The distinct categories across all items of an order.
	 *
	 * @param array $items
	 * @return string[]
	 * @since 1.68.0
	 */
	private static function get_order_categories( $items ) {

		$categories = [];

		foreach ($items as $item) {
			$categories = array_merge($categories, $item['Categories']);
		}

		return array_values(array_unique($categories));
	}
}
