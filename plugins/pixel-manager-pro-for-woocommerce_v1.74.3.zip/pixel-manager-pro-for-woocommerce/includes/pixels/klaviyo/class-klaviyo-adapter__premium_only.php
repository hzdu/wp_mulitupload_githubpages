<?php

namespace SweetCode\Pixel_Manager\Pixels\Klaviyo;

use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Adapter;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Registry;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Klaviyo Events API adapter for server-side event processing
 *
 * Registers the Klaviyo Events API with the unified pixel registry. The
 * descriptor half of the pixel lives in Klaviyo_Descriptor, so this class only
 * registers the adapter.
 *
 * @package SweetCode\Pixel_Manager\Pixels\Klaviyo
 * @since   1.68.0
 */
class Klaviyo_Adapter extends Abstract_Pixel_Adapter {

	/**
	 * Constructor - auto-registers this adapter
	 */
	public function __construct() {
		Pixel_Registry::register($this);
	}

	/**
	 * Get the pixel name
	 *
	 * @return string
	 */
	public function get_pixel_name() {
		return 'klaviyo';
	}

	/**
	 * Check if the Klaviyo Events API is available
	 *
	 * @return bool
	 */
	public function is_available() {
		return Options::is_klaviyo_events_api_active();
	}

	/**
	 * Send event data to the Klaviyo Events API
	 *
	 * @param array $pixel_data Filtered event data ready to send
	 * @return void
	 */
	protected function send( $pixel_data ) {
		Klaviyo_API::send_s2s_event($pixel_data);
	}
}

// Auto-register the adapter
new Klaviyo_Adapter();
