<?php

/**
 * Klaviyo plugin tracking takeover
 *
 * The official Klaviyo plugin owns the WooCommerce integration on Klaviyo's
 * side: Placed Order, catalog and profile sync all come from Klaviyo polling
 * the shop through the REST routes and webhooks that plugin provides. It also
 * renders the newsletter consent checkbox, the abandoned cart rebuild link
 * handler and the form widgets. All of that stays untouched.
 *
 * What it does badly is the onsite tracking: klaviyo.js loads without any
 * consent handling, Started Checkout hangs on fragile jQuery selectors, and
 * there are no cart, category or search events. This class removes exactly
 * those five tracking registrations, and the Pixel Manager sends the events
 * instead, tagged with service "woocommerce" so they land on the same Klaviyo
 * metrics the plugin's would have.
 *
 * Only instantiated in takeover mode, which the version guard in
 * Environment::is_klaviyo_plugin_version_supported() decides for automatic
 * mode. Every hook and handle name below was verified against the Klaviyo
 * plugin versions in that range; a release that moves one of them can make
 * the plugin's tracking run again, never make anything double-count.
 *
 * @since 1.68.0
 */

namespace SweetCode\Pixel_Manager\Pixels\Klaviyo;

use SweetCode\Pixel_Manager\Logger;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class Klaviyo_Takeover
 */
class Klaviyo_Takeover {

	/**
	 * The script handles the Klaviyo plugin enqueues for tracking.
	 *
	 * Handle                               What it is, and where the plugin enqueues it
	 *
	 * klaviyojs                            klaviyo.js, inc/kla-analytics.php
	 * kl-identify-browser                  identify() for logged-in users, inc/kla-analytics.php
	 * wck_viewed_product                   Viewed Product, includes/wck-viewed-product.php
	 * wck_started_checkout                 Started Checkout, includes/wck-cart-functions.php
	 * wck_anon_backfill                    klaviyo.js identification module on checkout, includes/wck-cart-functions.php
	 * klaviyo-checkout-block-event-script  Started Checkout for the Blocks checkout, includes/blocks/CheckoutIntegration.php
	 *
	 * The Blocks consent checkbox view script (klaviyo-klaviyo-checkout-block-view-script)
	 * is deliberately not on this list: that is the newsletter opt-in, not tracking.
	 *
	 * @since 1.68.0
	 */
	const SCRIPT_HANDLES = [
		'klaviyojs',
		'kl-identify-browser',
		'wck_viewed_product',
		'wck_started_checkout',
		'wck_anon_backfill',
		'klaviyo-checkout-block-event-script',
	];

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {

		// The plugin's function hooks are registered at file load, its class
		// hooks in WPKlaviyo::init() on init priority 0. Removing them on init
		// priority 20 is after both. When init has already run, remove them now.
		if (did_action('init')) {
			self::remove_tracking_hooks();
		} else {
			add_action('init', [ __CLASS__, 'remove_tracking_hooks' ], 20);
		}

		// The klaviyo.js and identify enqueues are instance method callbacks
		// on an object this class has no handle on, and the Blocks event script
		// is enqueued by WooCommerce Blocks when the checkout block renders. So
		// the scripts are dequeued by handle instead, at every point they can
		// still be printed from.
		add_action('wp_enqueue_scripts', [ __CLASS__, 'dequeue_tracking_scripts' ], 999);
		add_action('wp_print_scripts', [ __CLASS__, 'dequeue_tracking_scripts' ], 1);
		add_action('wp_print_footer_scripts', [ __CLASS__, 'dequeue_tracking_scripts' ], 1);
	}

	/**
	 * Remove the Klaviyo plugin's tracking hooks.
	 *
	 * @return void
	 * @since 1.68.0
	 */
	public static function remove_tracking_hooks() {

		// Added to Cart, sent server-side by the plugin on woocommerce_add_to_cart
		remove_action('woocommerce_add_to_cart', 'kl_added_to_cart_event', 25);

		// Viewed Product and Started Checkout script enqueues
		remove_action('wp_enqueue_scripts', 'load_viewed_product', 12);
		remove_action('wp_enqueue_scripts', 'load_started_checkout', 10);

		Logger::debug('Klaviyo takeover: removed the Klaviyo plugin tracking hooks');
	}

	/**
	 * Dequeue and deregister the Klaviyo plugin's tracking scripts.
	 *
	 * Deregistering as well means a later wp_enqueue_script() on the handle,
	 * which WooCommerce Blocks issues for its integration scripts, has no
	 * source to print.
	 *
	 * @return void
	 * @since 1.68.0
	 */
	public static function dequeue_tracking_scripts() {

		foreach (self::SCRIPT_HANDLES as $handle) {
			wp_dequeue_script($handle);
			wp_deregister_script($handle);
		}
	}

	/**
	 * The Started Checkout event data for the current cart, in the Klaviyo
	 * plugin's own shape, or null.
	 *
	 * Built by the plugin's wck_build_cart_data(): the line items with their
	 * URLs, images and categories, the cart totals, and the CartRebuildKey that
	 * Klaviyo's abandoned cart emails link back to the shop with. The plugin's
	 * wck_rebuild_cart() handler on wp_loaded restores the cart from that key,
	 * so its private format never has to be reproduced here, and the flow
	 * templates merchants built for the plugin's Started Checkout keep
	 * rendering. Tags and Quantity are dropped the way the plugin drops them
	 * before sending.
	 *
	 * @return array|null
	 * @since 1.68.0
	 */
	public static function get_started_checkout_event_data() {

		if (!function_exists('wck_build_cart_data') || !function_exists('WC')) {
			return null;
		}

		$cart = WC()->cart;

		if (!$cart || $cart->is_empty()) {
			return null;
		}

		try {
			$event_data = wck_build_cart_data($cart);
		} catch (\Exception $e) {
			Logger::debug('Klaviyo takeover: wck_build_cart_data() failed: ' . $e->getMessage());
			return null;
		}

		if (!is_array($event_data) || empty($event_data['$extra'])) {
			return null;
		}

		unset($event_data['Tags'], $event_data['Quantity']);

		return $event_data;
	}
}
