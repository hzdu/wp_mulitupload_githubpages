<?php

/**
 * Spotify Conversions API
 * https://developer.spotify.com/documentation/ads-api/guides
 *
 * @since 1.69.0
 */

namespace SweetCode\Pixel_Manager\Pixels\Spotify;

use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class Spotify_CAPI
 */
class Spotify_CAPI extends S2S {

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		$request_args = [
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . Options::get_spotify_capi_token(),
			],
		];

		$http->set_request_args($request_args);

		self::$http = $http;

		self::hook_into_generic_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_spotify_capi_active();
	}

	/**
	 * Spotify purchase events are routed through the SSP Purchase Proxy when
	 * the SSP is active. Non-SSP installs continue to send directly via
	 * send_purchase_hit().
	 *
	 * @return bool
	 * @since 1.69.0
	 */
	public static function is_handled_by_ssp() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'spotify_user_identifiers_' . Options::get_spotify_pixel_id();
	}

	public static function get_purchase_hit_key() {
		return 'pmw_spotify_capi_purchase_hit';
	}

	/**
	 * Spotify Conversions API endpoint.
	 *
	 * @return string
	 */
	private static function get_request_url() {
		return 'https://capi.spotify.com/capi-direct/events/';
	}

	/**
	 * Spotify publishes no click ID URL parameter and no web device identifier
	 * the Conversions API accepts, so there is nothing to collect here.
	 * Attribution rests on the hashed email address and the client IP.
	 *
	 * @param array $identifiers
	 * @return array
	 * @since 1.69.0
	 */
	protected static function add_pixel_specific_identifiers( $identifiers ) {
		return $identifiers;
	}

	/**
	 * Map a browser pixel event name onto the Conversions API event enum.
	 *
	 * The browser pixel and the Conversions API name the same conversions
	 * differently (addtocart vs ADD_TO_CART, checkout vs CHECK_OUT), so the
	 * relay from the browser adapter has to be translated rather than
	 * uppercased. An unknown event returns an empty string and is dropped
	 * instead of being sent under a name Spotify would reject.
	 *
	 * @param string $event_name
	 * @return string
	 * @since 1.69.0
	 */
	public static function get_capi_event_name( $event_name ) {

		$map = [
			'view'      => 'VIEW',
			'product'   => 'PRODUCT',
			'addtocart' => 'ADD_TO_CART',
			'checkout'  => 'CHECK_OUT',
			'purchase'  => 'PURCHASE',
			'lead'      => 'LEAD',
			'signup'    => 'SIGN_UP',
		];

		$event_name = strtolower((string) $event_name);

		return isset($map[ $event_name ]) ? $map[ $event_name ] : '';
	}

	/**
	 * Format a timestamp the way the Spotify Conversions API wants it.
	 *
	 * Spotify is the only destination we send an ISO 8601 string to; every
	 * other Conversions API takes a Unix timestamp.
	 *
	 * @param int|null $timestamp
	 * @return string
	 * @since 1.69.0
	 */
	public static function format_event_time( $timestamp = null ) {
		return gmdate('Y-m-d\TH:i:s\.000\Z', is_null($timestamp) ? time() : (int) $timestamp);
	}

	/**
	 * Build the purchase event for an order.
	 *
	 * Shared by the direct send (send_purchase_hit) and the SSP Purchase Proxy,
	 * which bundles this per-destination payload and forwards it to the SSP
	 * worker's Spotify adapter (buildRawRequest). Returns null if the order
	 * should not be processed.
	 *
	 * The event_id mirrors the browser pixel's purchase event ID
	 * ("pmw_" + order ID), so Spotify deduplicates the browser pixel and the
	 * Conversions API purchase against each other.
	 *
	 * @param \WC_Order $order
	 * @return array|null
	 * @since 1.69.0
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		return self::filter_purchase_payload('spotify', [
			'capi_connection_id' => Options::get_spotify_capi_connection_id(),
			'event_name'         => 'PURCHASE',
			'event_id'           => 'pmw_' . $order->get_id(),
			'event_time'         => self::format_event_time(),
			'user_data'          => self::get_user_data_for_order($order, $identifiers),
			'event_details'      => [
				'currency' => $order->get_currency(),
				'amount'   => (float) Shop::get_order_value_total_marketing($order, true),
			],
		], $order);
	}

	/**
	 * Send the purchase event directly to the Spotify Conversions API.
	 *
	 * Used when the SSP is not active (when it is, the SSP Purchase Proxy
	 * handles the event via build_ssp_purchase_event_data() and the base class
	 * skips this direct send).
	 *
	 * @param \WC_Order $order
	 * @return void
	 */
	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached Spotify. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event = self::build_ssp_purchase_event_data($order);

			if (!$event) {
				return;
			}

			$response = self::$http->post(self::get_request_url(), self::wrap_event($event));

			if (self::mark_purchase_hit_sent($order, $response)) {
				Logger::debug('Spotify CAPI purchase hit sent for order ' . $order->get_id());
			}
		});
	}

	/**
	 * Send an S2S event originating from the browser (view, product,
	 * addtocart, checkout). The browser adapter (adapter.js) supplies the
	 * event_id, the pixel event name and the event details; the server adds
	 * the client IP and the hashed email address.
	 *
	 * @param array $event_data Event data from the browser adapter.
	 * @return void
	 */
	public static function send_event_hit( $event_data ) {

		self::get_instance();

		if (!Options::is_spotify_capi_active()) {
			return;
		}

		if (Shop::do_not_track_user(get_current_user_id())) {
			return;
		}

		$event_name = self::get_capi_event_name(isset($event_data['event_name']) ? $event_data['event_name'] : '');
		$event_id   = isset($event_data['event_id']) ? $event_data['event_id'] : '';

		// event_name and event_id are required for the event to be usable.
		// Skip rather than send an event Spotify rejects or cannot deduplicate.
		if (empty($event_name) || empty($event_id)) {
			return;
		}

		$user_data = self::get_user_data_for_browser_event();

		// At least one identifier is required. Without one Spotify has nothing
		// to match the conversion against, so the request is pure noise.
		if (empty($user_data)) {
			return;
		}

		$event = [
			'capi_connection_id' => Options::get_spotify_capi_connection_id(),
			'event_name'         => $event_name,
			'event_id'           => $event_id,
			// Always stamp with server time. The event is being sent in near
			// real time, so server time is accurate and skew-proof. This
			// mirrors the SSP worker, which overwrites the timestamp with
			// server time.
			'event_time'         => self::format_event_time(),
			'user_data'          => $user_data,
			'event_details'      => isset($event_data['event_details']) && is_array($event_data['event_details'])
				? $event_data['event_details']
				: [],
		];

		self::$http->post(self::get_request_url(), self::wrap_event($event));
	}

	/**
	 * Wrap a single event in the Conversions API envelope.
	 *
	 * The connection ID lives on the envelope, not on the event, so it is
	 * lifted out of the event the builders produce. Keeping it on the event
	 * until this point is what lets the SSP Purchase Proxy bundle several
	 * destinations without a special case for Spotify.
	 *
	 * @param array $event
	 * @return array
	 * @since 1.69.0
	 */
	private static function wrap_event( $event ) {

		$connection_id = isset($event['capi_connection_id']) ? $event['capi_connection_id'] : Options::get_spotify_capi_connection_id();

		unset($event['capi_connection_id']);

		return [
			'conversion_events' => [
				'capi_connection_id' => $connection_id,
				'events'             => [ $event ],
			],
		];
	}

	/**
	 * Get the user_data object for an order.
	 *
	 * Unlike the other destinations, the hashed email address is NOT gated
	 * behind the advanced matching setting. Spotify's Conversions API matches
	 * on the email address and has no click ID to fall back on, so gating it
	 * would turn a configured Conversions API into a guaranteed no-op.
	 * Entering a Conversions API token is the explicit opt-in.
	 *
	 * @param \WC_Order $order
	 * @param array     $identifiers
	 * @return array
	 * @since 1.69.0
	 */
	private static function get_user_data_for_order( $order, $identifiers ) {

		$user_data = [];

		if (isset($identifiers['ip_address'])) {
			$user_data['ip_address'] = $identifiers['ip_address'];
		}

		$order_user_data = Helpers::get_user_data($order);

		// Spotify takes a list of hashed email addresses, even for one address.
		if (!empty($order_user_data['email']['sha256'])) {
			$user_data['hashed_emails'] = [ $order_user_data['email']['sha256'] ];
		}

		if (!empty($order_user_data['phone']['sha256']['e164'])) {
			$user_data['hashed_phone_number'] = $order_user_data['phone']['sha256']['e164'];
		}

		return $user_data;
	}

	/**
	 * Get the user_data object for a browser-relayed event.
	 *
	 * @return array
	 * @since 1.69.0
	 */
	private static function get_user_data_for_browser_event() {

		$user_data = [];

		if (Geolocation::get_user_ip()) {
			$user_data['ip_address'] = Geolocation::get_user_ip();
		}

		$current_user_data = Helpers::get_user_data();

		if (!empty($current_user_data['email']['sha256'])) {
			$user_data['hashed_emails'] = [ $current_user_data['email']['sha256'] ];
		}

		if (!empty($current_user_data['phone']['sha256']['e164'])) {
			$user_data['hashed_phone_number'] = $current_user_data['phone']['sha256']['e164'];
		}

		return $user_data;
	}
}
