<?php

/**
 * OpenAI Conversions API
 * https://developers.openai.com/ads/conversions-api
 * https://developers.openai.com/ads/measurement-pixel
 * https://developers.openai.com/ads/supported-events
 *
 * @since 1.60.0
 */

namespace SweetCode\Pixel_Manager\Pixels\OpenAI;

use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class OpenAI_CAPI
 */
class OpenAI_CAPI extends S2S {

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		$request_args = [
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . Options::get_openai_capi_token(),
			],
		];

		$http->set_request_args($request_args);

		self::$http = $http;

		self::hook_into_generic_events();
		self::hook_into_subscriptions_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_openai_capi_active();
	}

	protected static function get_identifiers_key() {
		return 'openai_user_identifiers_' . Options::get_openai_pixel_id();
	}

	public static function get_purchase_hit_key() {
		return 'pmw_openai_capi_purchase_hit';
	}

	/**
	 * OpenAI purchase events are routed through the SSP Purchase Proxy when the
	 * SSP is active. Non-SSP installs continue to send directly via
	 * send_purchase_hit().
	 *
	 * @return bool
	 * @since 1.60.0
	 */
	public static function is_handled_by_ssp() {
		return true;
	}

	/**
	 * OpenAI Conversions API endpoint.
	 * https://developers.openai.com/ads/conversions-api
	 *
	 * @return string
	 */
	private static function get_request_url() {
		return 'https://bzr.openai.com/v1/events?pid=' . rawurlencode(Options::get_openai_pixel_id());
	}

	/**
	 * Stable identifier OpenAI asks integrations to send at the top level of
	 * every Conversions API request (integration_source). It identifies the
	 * software sending the batch and has no effect on authentication.
	 * https://developers.openai.com/ads/conversions-api
	 *
	 * @since 1.66.1
	 */
	const INTEGRATION_SOURCE = 'pixel_manager_for_woocommerce';

	/**
	 * Wrap events into the request body OpenAI expects.
	 *
	 * @param array $events One or more OpenAI events.
	 * @return array
	 * @since 1.66.1
	 */
	public static function get_request_body( $events ) {
		return [
			'integration_source' => self::INTEGRATION_SOURCE,
			'events'             => $events,
		];
	}

	/**
	 * Add the oppref click reference to the identifiers.
	 *
	 * The oppref value is OpenAI's (ChatGPT's) click/user identifier, arriving
	 * as an oppref URL parameter on the landing page. Two sources, in priority order:
	 *
	 * 1. The __oppref first-party cookie the OpenAI SDK (oaiq) writes on the
	 *    landing page (30 days, parent domain, cleared on consent denial).
	 *    Confirmed by OpenAI support, 2026-07-23.
	 * 2. Fallback: PMW's own capture (event_listeners.js), sent to the
	 *    WooCommerce session via the transient identifiers AJAX round-trip on
	 *    cart/checkout pages. Kept because the SDK cookie is not guaranteed:
	 *    OpenAI reports it failing to persist on some sites, and it is absent
	 *    when the SDK never ran on the landing page.
	 *
	 * @param array $identifiers
	 * @return array
	 * @since 1.63.1
	 */
	/**
	 * Click IDs this destination recovers from the universal per-order
	 * snapshot when its own identifiers carry none (historical orders,
	 * a destination activated later, a backfill).
	 *
	 * @return array<string, string>
	 * @since 1.66.0
	 */
	protected static function get_click_id_snapshot_map() {
		return [ 'oppref' => 'oppref' ];
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		if (isset($_cookie['__oppref'])) {
			$oppref = self::normalize_oppref_cookie_value($_cookie['__oppref']);

			if (null !== $oppref) {
				$identifiers['oppref'] = $oppref;
			}
		}

		if (!isset($identifiers['oppref'])) {

			$transient_identifiers = Shop::get_transient_identifiers_from_session();

			if (isset($transient_identifiers['oppref']) && self::is_valid_oppref($transient_identifiers['oppref'])) {
				$identifiers['oppref'] = $transient_identifiers['oppref'];
			}
		}

		// The browser reference the OpenAI SDK stores in its __obref first-party
		// cookie. Unlike oppref it is a user-level field (user.obref) and is
		// forwarded verbatim, unhashed. It is only ever read on a request that
		// carries the cookie, so a purchase completed with marketing consent
		// withdrawn (the SDK never ran) sends none.
		if (isset($_cookie['__obref'])) {
			$obref = self::normalize_obref_cookie_value($_cookie['__obref']);

			if (null !== $obref) {
				$identifiers['obref'] = $obref;
			}
		}

		return $identifiers;
	}

	/**
	 * Normalize the __obref cookie value into a usable browser reference.
	 *
	 * @param mixed $value Raw cookie value.
	 * @return string|null The obref token, or null when implausible.
	 * @since 1.66.1
	 */
	public static function normalize_obref_cookie_value( $value ) {

		if (!is_string($value) || '' === $value) {
			return null;
		}

		if (false !== strpos($value, '%')) {
			$value = rawurldecode($value);
		}

		$value = trim($value);

		return self::is_valid_obref($value) ? $value : null;
	}

	/**
	 * Check if an obref browser reference is plausible.
	 *
	 * OpenAI documents it as an opaque value (their example is a UUID) that
	 * must be passed without modification, so the check is deliberately
	 * permissive: URL-safe characters, sane length, no whitespace.
	 *
	 * @param mixed $obref
	 * @return bool
	 * @since 1.66.1
	 */
	public static function is_valid_obref( $obref ) {

		if (!is_string($obref)) {
			return false;
		}

		return (bool) preg_match('/^[A-Za-z0-9+\/._~=-]{8,256}$/', $obref);
	}

	/**
	 * Normalize the __oppref cookie value into a usable oppref token.
	 *
	 * The SDK stores the token URL-encoded. PHP normally decodes cookie values
	 * while parsing the request, so decode only when encoding residue is still
	 * present. The token itself is opaque and must be forwarded verbatim (per
	 * OpenAI: do not parse or regenerate it).
	 *
	 * @param mixed $value Raw cookie value.
	 * @return string|null The oppref token, or null when implausible.
	 * @since 1.63.1
	 */
	public static function normalize_oppref_cookie_value( $value ) {

		if (!is_string($value) || '' === $value) {
			return null;
		}

		if (false !== strpos($value, '%')) {
			$value = rawurldecode($value);
		}

		return self::is_valid_oppref($value) ? $value : null;
	}

	/**
	 * Check if an oppref click reference is plausible.
	 *
	 * The token is opaque per OpenAI (do not parse or regenerate), so this is
	 * deliberately permissive (like the pixel ID and CAPI token validations):
	 * base64-style characters including the standard alphabet, sane length.
	 * Example from OpenAI support:
	 * "ChABlLt-73tywKHq-Ozm8JW2VEaInDQZfPp2FT2-dZfnsTTZnTbhbo6rM-I7gEIAr-Yq"
	 *
	 * @param mixed $oppref
	 * @return bool
	 * @since 1.63.1
	 */
	public static function is_valid_oppref( $oppref ) {

		if (!is_string($oppref)) {
			return false;
		}

		return (bool) preg_match('/^[A-Za-z0-9+\/._~=-]{10,600}$/', $oppref);
	}

	/**
	 * Wire OpenAI's plan_enrollment events into WooCommerce Subscriptions.
	 *
	 * - trial_started:        a free trial begins (subscription created with a trial).
	 * - subscription_created: a paid subscription starts (first successful payment).
	 *
	 * A trialing subscription fires trial_started at checkout and, when the trial
	 * converts and the first payment completes, subscription_created. A non-trial
	 * subscription fires subscription_created at checkout (payment count === 1).
	 *
	 * https://woocommerce.com/document/subscriptions/develop/action-reference/
	 */
	private static function hook_into_subscriptions_events() {
		add_action('woocommerce_checkout_subscription_created', [ __CLASS__, 'openai_report_trial_started' ], 10, 1);
		add_action('woocommerce_subscription_payment_complete', [ __CLASS__, 'openai_report_subscription_created' ], 10, 1);
	}

	/**
	 * Fire trial_started when a subscription with a free trial is created.
	 *
	 * @param \WC_Subscription $subscription
	 * @return void
	 */
	public static function openai_report_trial_started( $subscription ) {

		if (!self::subscription_has_trial($subscription)) {
			return;
		}

		self::send_subscription_hit('trial_started', $subscription);
	}

	/**
	 * Fire subscription_created on the first successful subscription payment.
	 *
	 * @param \WC_Subscription $subscription
	 * @return void
	 */
	public static function openai_report_subscription_created( $subscription ) {

		// Only the initial payment marks the start of a paid subscription.
		if ($subscription->get_payment_count() !== 1) {
			return;
		}

		self::send_subscription_hit('subscription_created', $subscription);
	}

	/**
	 * Whether the subscription carries a free trial.
	 *
	 * @param \WC_Subscription $subscription
	 * @return bool
	 */
	private static function subscription_has_trial( $subscription ) {

		if (!is_object($subscription) || !method_exists($subscription, 'get_time')) {
			return false;
		}

		return $subscription->get_time('trial_end') > 0;
	}

	/**
	 * Build and send a plan_enrollment event (trial_started / subscription_created).
	 *
	 * @param string           $event_type   OpenAI event name.
	 * @param \WC_Subscription $subscription
	 * @return void
	 */
	public static function send_subscription_hit( $event_type, $subscription ) {

		self::get_instance();

		if (!Options::is_openai_capi_active()) {
			return;
		}

		$parent_order   = method_exists($subscription, 'get_parent') ? $subscription->get_parent() : null;
		$order_for_data = $parent_order ? $parent_order : $subscription;

		if (Shop::do_not_track_user(Shop::get_order_user_id($order_for_data))) {
			return;
		}

		$identifiers = $parent_order ? self::get_identifiers_from_order($parent_order) : [];
		$user_data   = self::get_user_data($order_for_data, $identifiers);

		$currency = $subscription->get_currency();

		// For a free trial, the value is the amount actually charged at signup
		// (the parent order total, typically 0 or a sign-up fee). For a paid
		// subscription start, use the recurring subscription value.
		if ('trial_started' === $event_type) {
			$amount_decimal = $parent_order ? (float) $parent_order->get_total() : 0.0;
		} else {
			$amount_decimal = (float) $subscription->get_total();
		}

		$event = [
			'id'            => 'pmw_' . $event_type . '_' . $subscription->get_id(),
			'type'          => $event_type,
			'timestamp_ms'  => (int) round(microtime(true) * 1000),
			'action_source' => 'web',
			'source_url'    => home_url(),
			'user'          => $user_data,
			'data'          => [
				'type'     => 'plan_enrollment',
				'amount'   => self::to_minor_units($amount_decimal, $currency),
				'currency' => $currency,
				'plan_id'  => (string) self::get_subscription_plan_id($subscription),
				'contents' => self::get_products($subscription),
			],
		];

		// Attach the ChatGPT click reference preserved from the landing page.
		if (isset($identifiers['oppref'])) {
			$event['oppref'] = $identifiers['oppref'];
		}

		self::$http->post(self::get_request_url(), self::get_request_body([ $event ]));

		Logger::debug('OpenAI CAPI ' . $event_type . ' hit sent for subscription ' . $subscription->get_id());
	}

	/**
	 * Resolve a representative plan_id for a subscription.
	 *
	 * @param \WC_Subscription $subscription
	 * @return int|string
	 */
	private static function get_subscription_plan_id( $subscription ) {

		foreach ($subscription->get_items() as $item) {
			$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
			if ($product_id) {
				return $product_id;
			}
		}

		return $subscription->get_id();
	}

	/**
	 * Build the order_created (purchase) event for an order.
	 *
	 * Shared by the direct send (send_purchase_hit) and the SSP Purchase Proxy,
	 * which bundles this per-destination payload and forwards it to the SSP
	 * worker's OpenAI adapter (buildRawRequest). Returns null if the order
	 * should not be processed.
	 *
	 * @param \WC_Order $order
	 * @return array|null
	 * @since 1.60.0
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);
		$user_data   = self::get_user_data($order, $identifiers);

		$currency = $order->get_currency();

		$event = [
			'id'            => 'pmw_' . $order->get_id(),
			'type'          => 'order_created',
			'timestamp_ms'  => self::get_order_timestamp_ms($order),
			'action_source' => 'web',
			'source_url'    => home_url(),
			'user'          => $user_data,
			'data'          => [
				'type'     => 'contents',
				'amount'   => self::to_minor_units((float) Shop::get_order_value_total_marketing($order, true), $currency),
				'currency' => $currency,
				'contents' => self::get_products($order),
			],
		];

		// The oppref click reference traces the visitor from ChatGPT to the
		// purchase. It was captured on the landing page and preserved through
		// checkout in the order's identifiers meta. Top-level event field per
		// the OpenAI CAPI schema; the SSP worker passes it through untouched.
		if (isset($identifiers['oppref'])) {
			$event['oppref'] = $identifiers['oppref'];
		}

		return self::filter_purchase_payload('openai', $event, $order);
	}

	/**
	 * Send the order_created (purchase) event directly to the OpenAI CAPI.
	 *
	 * Used when the SSP is not active (when it is, the SSP Purchase Proxy handles
	 * the event via build_ssp_purchase_event_data() and the base class skips this
	 * direct send).
	 *
	 * @param \WC_Order $order
	 * @return void
	 */
	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached OpenAI. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event = self::build_ssp_purchase_event_data($order);

			if (!$event) {
				return;
			}

			$response = self::$http->post(self::get_request_url(), self::get_request_body([ $event ]));

			if (self::mark_purchase_hit_sent($order, $response)) {
				Logger::debug('OpenAI CAPI purchase hit sent for order ' . $order->get_id());
			}
		});
	}

	/**
	 * Send an S2S event originating from the browser (page_viewed, contents_viewed,
	 * items_added, checkout_started). The browser adapter (adapter.js) supplies the
	 * event_id, event name, OpenAI data object, source_url and any advanced-matching
	 * user data; the server enriches it with the client IP and user agent.
	 *
	 * @param array $event_data Event data from the browser adapter.
	 * @return void
	 */
	public static function send_event_hit( $event_data ) {

		self::get_instance();

		if (!Options::is_openai_capi_active()) {
			return;
		}

		if (Shop::do_not_track_user(get_current_user_id())) {
			return;
		}

		$user = isset($event_data['user']) && is_array($event_data['user']) ? $event_data['user'] : [];

		// The browser sends the Conversions API shape (plural list fields) since
		// 1.66.1. A cached pre-1.66.1 tracking library still sends the pixel's
		// singular field names; bring those into the list shape OpenAI expects.
		$user = self::normalize_user_data_for_capi($user);

		// Add the client IP address
		if (Geolocation::get_user_ip()) {
			$user['ip_address'] = Geolocation::get_user_ip();
		}

		// Add the user agent
		$user_agent = Helpers::get_request_user_agent();
		if ($user_agent) {
			$user['user_agent'] = $user_agent;
		}

		$event = [
			'id'            => isset($event_data['event_id']) ? $event_data['event_id'] : '',
			'type'          => isset($event_data['event_name']) ? $event_data['event_name'] : '',
			// Always stamp with server time. The browser supplies timestamp_ms from
			// the visitor's clock (Date.now()), which OpenAI rejects when it is more
			// than ~7 days old or ~10 minutes in the future. The event is being sent
			// in near real time, so server time is accurate and skew-proof. This
			// mirrors the SSP worker, which overwrites timestamp_ms with server time.
			'timestamp_ms'  => (int) round(microtime(true) * 1000),
			'action_source' => 'web',
			'source_url'    => isset($event_data['source_url']) ? $event_data['source_url'] : '',
			'user'          => $user,
			'data'          => isset($event_data['event_data']) && is_array($event_data['event_data']) ? self::normalize_event_data_types($event_data['event_data']) : [],
		];

		// The ChatGPT click reference, attached at the top level by the browser
		// adapter (getOpenAIBaseData). The SSP path passes it through in
		// buildRawRequest; this mirrors that on the non-SSP path.
		if (isset($event_data['oppref']) && self::is_valid_oppref($event_data['oppref'])) {
			$event['oppref'] = $event_data['oppref'];
		}

		// id, type and source_url are required by the OpenAI API for an
		// action_source of "web". Skip rather than send an event the API rejects.
		if (empty($event['id']) || empty($event['type']) || empty($event['source_url'])) {
			return;
		}

		self::$http->post(self::get_request_url(), self::get_request_body([ $event ]));
	}

	/**
	 * Restore the integer types of a browser event's data object.
	 *
	 * The admin-ajax fallback posts the payload as form data, which turns
	 * every number into a string ("12999", "1"). OpenAI type-checks strictly
	 * and rejects a string amount or quantity with invalid_amount or
	 * invalid_quantity, so the event is lost. The REST and SweetCode Cloud
	 * paths send JSON, where this is a no-op.
	 *
	 * A numeric string becomes an integer; any other value is left alone so
	 * that OpenAI still reports a genuinely malformed payload.
	 *
	 * @param array $data The event's data object.
	 * @return array
	 *
	 * @since 1.69.3
	 */
	public static function normalize_event_data_types( $data ) {

		$to_int = function ( $value ) {
			return is_string($value) && is_numeric($value) ? (int) round((float) $value) : $value;
		};

		if (isset($data['amount'])) {
			$data['amount'] = $to_int($data['amount']);
		}

		if (isset($data['contents']) && is_array($data['contents'])) {
			foreach ($data['contents'] as $key => $content) {
				if (!is_array($content)) {
					continue;
				}

				foreach ([ 'amount', 'quantity' ] as $field) {
					if (isset($content[ $field ])) {
						$content[ $field ] = $to_int($content[ $field ]);
					}
				}

				$data['contents'][ $key ] = $content;
			}

			// Form encoding sends a JS array as an object with keys "0", "1", ...
			// PHP reads it back as a list already, but guard against a sparse one
			// so json_encode() never turns contents into a JSON object.
			$data['contents'] = array_values($data['contents']);
		}

		return $data;
	}

	/**
	 * Get the user data object for an order.
	 * https://developers.openai.com/ads/conversions-api
	 *
	 * The Conversions API takes the matching identifiers as plural list fields
	 * (emails_sha256, phone_numbers_sha256, ...); it uses the first three
	 * unique values of each list. Hashes are lowercase hex SHA-256 of the
	 * normalized value. Geographic values (countries, regions, cities,
	 * postal_codes) are sent raw. Advanced matching gates all of it; the IP
	 * address, user agent and the SDK's obref browser reference are sent
	 * regardless, as they carry no customer profile data.
	 *
	 * @param \WC_Order|\WC_Subscription $order
	 * @param array                      $identifiers
	 * @return array
	 */
	private static function get_user_data( $order, $identifiers ) {

		$user_data = [];

		// Add IP address
		if (isset($identifiers['ip_address'])) {
			$user_data['ip_address'] = $identifiers['ip_address'];
		}

		// Add user agent
		if (isset($identifiers['user_agent'])) {
			$user_data['user_agent'] = $identifiers['user_agent'];
		}

		// The browser reference from the SDK's __obref cookie, captured at checkout
		if (isset($identifiers['obref']) && self::is_valid_obref($identifiers['obref'])) {
			$user_data['obref'] = $identifiers['obref'];
		}

		// Add advanced matching data if enabled
		if (Options::is_openai_advanced_matching_enabled()) {

			$order_user_data = Helpers::get_user_data($order);

			// Email (SHA-256, lowercase hex)
			if (!empty($order_user_data['email']['sha256'])) {
				$user_data['emails_sha256'] = [ $order_user_data['email']['sha256'] ];
			}

			// Phone (SHA-256 of the E.164 digits without + and leading zeroes)
			if (!empty($order_user_data['phone']['openai'])) {
				$user_data['phone_numbers_sha256'] = [ $order_user_data['phone']['openai'] ];
			}

			// External ID (user ID, SHA-256, lowercase hex)
			if (!empty($order_user_data['id']['sha256'])) {
				$user_data['external_ids_sha256'] = [ $order_user_data['id']['sha256'] ];
			}

			// Names (SHA-256 of lowercase, whitespace and ASCII punctuation removed)
			if (!empty($order_user_data['first_name']['openai'])) {
				$user_data['first_names_sha256'] = [ $order_user_data['first_name']['openai'] ];
			}

			if (!empty($order_user_data['last_name']['openai'])) {
				$user_data['last_names_sha256'] = [ $order_user_data['last_name']['openai'] ];
			}

			// Geographic data (raw values)
			if (method_exists($order, 'get_billing_country') && $order->get_billing_country()) {
				$user_data['countries'] = [ strtoupper($order->get_billing_country()) ];
			}

			if (method_exists($order, 'get_billing_state') && $order->get_billing_state()) {
				$country = method_exists($order, 'get_billing_country') ? $order->get_billing_country() : '';
				$region  = Helpers::get_region_name($order->get_billing_state(), $country);

				if ('' !== $region) {
					$user_data['regions'] = [ $region ];
				}
			}

			if (method_exists($order, 'get_billing_city') && $order->get_billing_city()) {
				$user_data['cities'] = [ trim($order->get_billing_city()) ];
			}

			if (method_exists($order, 'get_billing_postcode') && $order->get_billing_postcode()) {
				$user_data['postal_codes'] = [ trim($order->get_billing_postcode()) ];
			}
		}

		return $user_data;
	}

	/**
	 * Map the pixel's singular user fields onto the Conversions API's plural
	 * list fields.
	 *
	 * The browser SDK takes email_sha256, phone_number_sha256, ..., country,
	 * city, region, postal_code, while the Conversions API takes
	 * emails_sha256, phone_numbers_sha256, ..., countries, cities, regions,
	 * postal_codes. A user object that already uses the list fields passes
	 * through untouched; a singular field is folded into the matching list
	 * (deduplicated) and removed. Unknown fields are preserved.
	 *
	 * @param array $user User object in either shape.
	 * @return array User object in the Conversions API shape.
	 * @since 1.66.1
	 */
	public static function normalize_user_data_for_capi( $user ) {

		if (!is_array($user)) {
			return [];
		}

		$singular_to_plural = [
			'email_sha256'        => 'emails_sha256',
			'phone_number_sha256' => 'phone_numbers_sha256',
			'external_id_sha256'  => 'external_ids_sha256',
			'first_name_sha256'   => 'first_names_sha256',
			'last_name_sha256'    => 'last_names_sha256',
			'country'             => 'countries',
			'region'              => 'regions',
			'city'                => 'cities',
			'postal_code'         => 'postal_codes',
			// Never a documented field, but what pre-1.66.1 versions sent.
			'zip_code'            => 'postal_codes',
		];

		foreach ($singular_to_plural as $singular => $plural) {

			if (!array_key_exists($singular, $user)) {
				continue;
			}

			$value = $user[$singular];
			unset($user[$singular]);

			if (!is_scalar($value) || '' === (string) $value) {
				continue;
			}

			$list = [];
			if (isset($user[$plural])) {
				$list = is_array($user[$plural]) ? $user[$plural] : [ (string) $user[$plural] ];
			}

			if (!in_array((string) $value, $list, true)) {
				$list[] = (string) $value;
			}

			$user[$plural] = $list;
		}

		// A list field that arrived as a bare string is wrapped.
		foreach (array_unique(array_values($singular_to_plural)) as $plural) {
			if (isset($user[$plural]) && is_scalar($user[$plural])) {
				$user[$plural] = [ (string) $user[$plural] ];
			}
		}

		// obref is a user-level field that must be a non-blank string.
		if (array_key_exists('obref', $user) && !self::is_valid_obref($user['obref'])) {
			unset($user['obref']);
		}

		return $user;
	}

	/**
	 * Build the OpenAI contents array for an order or subscription.
	 *
	 * @param \WC_Order|\WC_Subscription $order
	 * @return array
	 */
	private static function get_products( $order ) {

		$products = [];
		$currency = method_exists($order, 'get_currency') ? $order->get_currency() : '';

		foreach (Product::pmw_get_order_items($order) as $order_item) {

			$product_id = Product::get_variation_or_product_id($order_item->get_data(), Options::is_dynamic_remarketing_variations_output_enabled());
			$product    = wc_get_product($product_id);

			// Only add if WC retrieves a valid product
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			$content = [
				'id'           => (string) Product::get_dyn_r_id_for_product_by_pixel_name($product, 'openai'),
				'name'         => $product->get_name(),
				'content_type' => 'product',
				'quantity'     => (int) $order_item->get_quantity(),
				// Item-level value: the per-unit price actually paid, in minor units
				'amount'       => self::to_minor_units((float) Product::pmw_get_order_item_price($order_item, null, $order), $currency),
				'currency'     => $currency,
			];

			// A variation reports its parent as the product group, and its
			// attributes as the variant (Conversions API only fields).
			if ($product->is_type('variation') && $product->get_parent_id()) {

				$parent = wc_get_product($product->get_parent_id());

				if (!Product::is_not_wc_product($parent)) {
					$content['group_id'] = (string) Product::get_dyn_r_id_for_product_by_pixel_name($parent, 'openai');
				}

				$variant_dict = self::get_variant_dict($product);

				if (!empty($variant_dict)) {
					$content['variant_dict'] = $variant_dict;
				}
			}

			$products[] = $content;
		}

		return $products;
	}

	/**
	 * Build the variant_dict for a variation: attribute label => chosen value,
	 * both as strings ({"Color": "blue", "Size": "medium"}). Attributes the
	 * variation leaves open ("Any Color") are skipped.
	 *
	 * @param \WC_Product_Variation $product
	 * @return array<string, string>
	 * @since 1.66.1
	 */
	private static function get_variant_dict( $product ) {

		$variant_dict = [];

		if (!method_exists($product, 'get_attributes')) {
			return $variant_dict;
		}

		foreach ((array) $product->get_attributes() as $taxonomy => $value) {

			if (!is_string($value) || '' === $value) {
				continue;
			}

			$label = function_exists('wc_attribute_label') ? wc_attribute_label($taxonomy, $product) : $taxonomy;
			$label = preg_replace('/^pa_/', '', (string) $label);

			if (taxonomy_exists($taxonomy)) {
				$term  = get_term_by('slug', $value, $taxonomy);
				$value = $term && !is_wp_error($term) ? $term->name : $value;
			}

			$variant_dict[(string) $label] = (string) $value;
		}

		return $variant_dict;
	}

	/**
	 * Resolve a millisecond timestamp for the order that stays inside OpenAI's
	 * acceptance window. OpenAI rejects events whose timestamp is older than 7
	 * days, so for delayed-payment orders created outside a safe 6-day margin we
	 * fall back to the current time.
	 *
	 * @param \WC_Order $order
	 * @return int
	 */
	private static function get_order_timestamp_ms( $order ) {

		$now_ms = (int) round(microtime(true) * 1000);

		$created = $order->get_date_created();
		if (!$created) {
			return $now_ms;
		}

		$created_ms = ( (int) $created->getTimestamp() ) * 1000;

		// Keep the real order timestamp when it is comfortably inside OpenAI's
		// 7-day acceptance window (7 days minus a 1 hour buffer for clock skew);
		// otherwise fall back to now so the event is still accepted.
		$safe_window = ( 7 * DAY_IN_SECONDS - HOUR_IN_SECONDS ) * 1000;

		if ($created_ms <= 0 || ( $now_ms - $created_ms ) > $safe_window) {
			return $now_ms;
		}

		return $created_ms;
	}

	/**
	 * ISO 4217 minor-unit exponent for a currency (default 2).
	 *
	 * @param string $currency
	 * @return int
	 */
	private static function currency_exponent( $currency ) {

		$currency = strtoupper((string) $currency);

		$zero_decimal  = [ 'BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF' ];
		$three_decimal = [ 'BHD', 'IQD', 'JOD', 'KWD', 'LYD', 'OMR', 'TND' ];

		if (in_array($currency, $zero_decimal, true)) {
			return 0;
		}

		if (in_array($currency, $three_decimal, true)) {
			return 3;
		}

		return 2;
	}

	/**
	 * Convert a decimal amount into integer ISO 4217 minor units
	 * (e.g. 129.99 USD -> 12999).
	 *
	 * @param float  $amount
	 * @param string $currency
	 * @return int
	 */
	private static function to_minor_units( $amount, $currency ) {
		$exponent = self::currency_exponent($currency);
		return (int) round(( (float) $amount ) * pow(10, $exponent));
	}
}
