<?php

namespace SweetCode\Pixel_Manager\Pixels\OpenAI;

use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Adapter;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Registry;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * OpenAI Conversions API adapter for server-side event processing
 *
 * Handles filtering and sending events to the OpenAI Conversions API. The
 * pixel's descriptor lives in the free OpenAI_Descriptor, so the registry
 * knows the browser pixel on every tier; this adapter only exists on Pro builds.
 *
 * @package SweetCode\Pixel_Manager\Pixels\OpenAI
 * @since   1.60.0
 */
class OpenAI_Adapter extends Abstract_Pixel_Adapter {

	/**
	 * Constructor - auto-registers this adapter
	 */
	public function __construct() {
		Pixel_Registry::register($this);
	}

	/**
	 * Get the pixel name
	 *
	 * @return string
	 */
	public function get_pixel_name() {
		return 'openai';
	}

	/**
	 * Check if the OpenAI Conversions API is available
	 *
	 * @return bool
	 */
	public function is_available() {
		return Options::is_openai_capi_active();
	}

	/**
	 * Send event data to the OpenAI Conversions API
	 *
	 * @param array $pixel_data Filtered event data ready to send
	 * @return void
	 */
	protected function send( $pixel_data ) {
		OpenAI_CAPI::send_s2s_event($pixel_data);
	}
}

// Auto-register the adapter
new OpenAI_Adapter();
