<?php

/**
 * Triple Whale
 *
 * The shop identity the Triple Pixel reports. Triple Whale is a data
 * platform: it attributes an order only once it holds the order record, and
 * for a WooCommerce store that record arrives over the WooCommerce REST API
 * connection made in Triple Whale onboarding. The Pixel Manager supplies the
 * browser pixel and the checkout funnel events, nothing server-side.
 *
 * @since 1.63.0
 * @since 1.67.1 Browser-only. The Orders API sync was removed: Triple Whale
 *               documents its data-in Orders API for Custom Sales Platform
 *               shops only, and every Pixel Manager shop is a WooCommerce
 *               store that Triple Whale connects natively.
 */

namespace SweetCode\Pixel_Manager\Pixels\TripleWhale;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class Triple_Whale
 */
class Triple_Whale {

	/**
	 * The platform a WooCommerce store connected in Triple Whale onboarding
	 * reports to the Triple Pixel. Triple Whale pulls its orders itself.
	 */
	const PLATFORM_WOOCOMMERCE = 'woocommerce';

	/**
	 * The shop identifier (TripleName).
	 *
	 * Triple Whale identifies the shop by its domain. The value must match the
	 * Shop URL configured in Triple Whale under Settings > Store. Mirrors the
	 * derivation used by Triple Whale's own WooCommerce extension: the host,
	 * plus the path with slashes encoded as $fs$ for subdirectory installs.
	 *
	 * @return string
	 * @since 1.63.0
	 */
	public static function get_shop() {

		$blog_info = wp_parse_url(get_bloginfo('url'));

		$host = isset($blog_info['host']) ? $blog_info['host'] : '';
		$path = isset($blog_info['path']) ? $blog_info['path'] : '';

		$shop = $host . str_replace('/', '$fs$', $path);

		/**
		 * Filters the Triple Whale shop identifier (TripleName).
		 *
		 * Use this when the Shop URL configured in Triple Whale under
		 * Settings > Store differs from the WordPress site URL host.
		 *
		 * @param string $shop The derived shop identifier.
		 *
		 * @since 1.63.0
		 */
		return apply_filters('pmw_triple_whale_shop', $shop);
	}

	/**
	 * The platform the Triple Pixel reports (TriplePixelData.plat).
	 *
	 * Always woocommerce: a Pixel Manager shop is a WooCommerce store that
	 * Triple Whale connects natively and whose orders it imports itself. The
	 * filter is the escape hatch for a shop registered in Triple Whale as a
	 * Custom Sales Platform that feeds its orders to Triple Whale on its own;
	 * such a shop returns custom-msp here so the pixel events land on the
	 * same platform as its order records.
	 *
	 * @return string
	 *
	 * @since 1.67.1
	 */
	public static function get_platform() {

		/**
		 * Filters the platform reported to the Triple Pixel.
		 *
		 * @param string $platform woocommerce, or custom-msp for a shop
		 *                         registered as a Custom Sales Platform.
		 *
		 * @since 1.67.1
		 */
		return apply_filters('pmw_triple_whale_platform', self::PLATFORM_WOOCOMMERCE);
	}
}
