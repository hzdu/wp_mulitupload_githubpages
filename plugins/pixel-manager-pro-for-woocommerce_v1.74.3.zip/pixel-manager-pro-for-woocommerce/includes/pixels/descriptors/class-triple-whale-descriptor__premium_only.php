<?php
/**
 * Triple Whale Pixel Descriptor
 *
 * Browser-only pixel descriptor for the Triple Pixel (Pro).
 *
 * @package SweetCode\Pixel_Manager
 * @since 1.67.1
 */

namespace SweetCode\Pixel_Manager\Pixels\Descriptors;

use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Descriptor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Class Triple_Whale_Descriptor
 *
 * Descriptor for the Triple Whale pixel (Pro). Loads the Triple Pixel and
 * sends Triple Whale's checkout funnel events. Orders, refunds and revenue
 * reach Triple Whale over the WooCommerce REST API connection made in Triple
 * Whale onboarding, they are not sent by the pixel.
 */
class Triple_Whale_Descriptor extends Abstract_Pixel_Descriptor {

	/**
	 * Get the pixel's unique identifier
	 *
	 * @return string
	 */
	public function get_name() {
		return 'triple_whale';
	}

	/**
	 * Get the pixel's human-readable label
	 *
	 * @return string
	 */
	public function get_label() {
		return 'Triple Whale';
	}

	/**
	 * Get the pixel's category
	 *
	 * Triple Whale is an attribution platform. Attribution pixels follow the
	 * statistics consent category.
	 *
	 * @return string
	 */
	public function get_category() {
		return 'attribution';
	}

	/**
	 * Check if the pixel is currently active
	 *
	 * @return bool
	 */
	public function is_active() {
		return Options::is_triple_whale_active();
	}
}

// Auto-instantiate to register with the registry
new Triple_Whale_Descriptor();
