<?php
/**
 * Klaviyo Pixel Descriptor
 *
 * Pro-only descriptor for the Klaviyo onsite tracking.
 *
 * @package SweetCode\Pixel_Manager
 * @since 1.68.0
 */

namespace SweetCode\Pixel_Manager\Pixels\Descriptors;

use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Descriptor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Class Klaviyo_Descriptor
 *
 * Klaviyo is an email and SMS marketing platform. The Pixel Manager sends it
 * the onsite events its flows trigger on, alongside the official Klaviyo
 * plugin, which keeps handling orders, catalog and profile sync.
 */
class Klaviyo_Descriptor extends Abstract_Pixel_Descriptor {

	/**
	 * Get the pixel's unique identifier
	 *
	 * @return string
	 */
	public function get_name() {
		return 'klaviyo';
	}

	/**
	 * Get the pixel's human-readable label
	 *
	 * @return string
	 */
	public function get_label() {
		return 'Klaviyo';
	}

	/**
	 * Get the pixel's category
	 *
	 * @return string
	 */
	public function get_category() {
		return 'marketing';
	}

	/**
	 * Check if the pixel is currently active
	 *
	 * @return bool
	 */
	public function is_active() {
		return Options::is_klaviyo_active();
	}

	/**
	 * Check if the pixel has server-side tracking
	 *
	 * @return bool
	 */
	public function has_server_tracking() {
		return Options::is_klaviyo_events_api_active();
	}
}

// Auto-instantiate to register with the registry
new Klaviyo_Descriptor();
