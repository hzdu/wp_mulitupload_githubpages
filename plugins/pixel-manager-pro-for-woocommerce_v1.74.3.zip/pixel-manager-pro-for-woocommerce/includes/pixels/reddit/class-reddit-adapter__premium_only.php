<?php

namespace SweetCode\Pixel_Manager\Pixels\Reddit;

use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Adapter;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Registry;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Reddit CAPI adapter for server-side event processing
 *
 * Handles filtering and sending events to Reddit Conversions API. The pixel's
 * descriptor lives in the free Reddit_Descriptor, so the registry knows the
 * browser pixel on every tier; this adapter only exists on Pro builds.
 *
 * @package SweetCode\Pixel_Manager\Pixels\Adapters\Reddit
 * @since   1.52.0
 */
class Reddit_Adapter extends Abstract_Pixel_Adapter {

	/**
	 * Constructor - auto-registers this adapter
	 */
	public function __construct() {
		Pixel_Registry::register($this);
	}

	/**
	 * Get the pixel name
	 *
	 * @return string
	 */
	public function get_pixel_name() {
		return 'reddit';
	}

	/**
	 * Check if Reddit CAPI is available
	 *
	 * @return bool
	 */
	public function is_available() {
		return \SweetCode\Pixel_Manager\Options::is_reddit_capi_active();
	}

	/**
	 * Send event data to Reddit Conversions API
	 *
	 * @param array $pixel_data Filtered event data ready to send
	 * @return void
	 */
	protected function send( $pixel_data ) {
		Reddit_CAPI::send_s2s_event($pixel_data);
	}
}

// Auto-register the adapter
new Reddit_Adapter();
