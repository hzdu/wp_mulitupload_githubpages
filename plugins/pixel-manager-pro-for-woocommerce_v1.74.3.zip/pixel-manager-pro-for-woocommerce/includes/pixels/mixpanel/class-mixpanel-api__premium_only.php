<?php

/**
 * Mixpanel Ingestion API
 * https://docs.mixpanel.com/reference/track-event
 * https://docs.mixpanel.com/reference/event-deduplication
 *
 * Mixpanel authenticates /track with the project token inside the event
 * properties, so there is no separate credential to configure.
 *
 * @since 1.64.1
 */

namespace SweetCode\Pixel_Manager\Pixels\Mixpanel;

use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class Mixpanel_API
 */
class Mixpanel_API extends S2S {

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		$request_args = [
			'headers' => [
				'Content-Type' => 'application/json',
				'Accept'       => 'text/plain',
			],
		];

		$http->set_request_args($request_args);

		self::$http = $http;

		self::hook_into_generic_events();
		self::hook_into_refund_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_mixpanel_ingestion_api_active();
	}

	/**
	 * Mixpanel is an analytics destination, so its server-side events are gated
	 * on statistics consent instead of marketing consent.
	 *
	 * @return string
	 * @since 1.64.1
	 */
	public static function get_consent_category() {
		return 'statistics';
	}

	/**
	 * Mixpanel purchase events are routed through the SSP Purchase Proxy when
	 * the SSP is active. Non-SSP installs continue to send directly via
	 * send_purchase_hit().
	 *
	 * @return bool
	 * @since 1.64.1
	 */
	public static function is_handled_by_ssp() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'mixpanel_identifiers_' . Options::get_mixpanel_project_token();
	}

	public static function get_purchase_hit_key() {
		return 'pmw_mixpanel_ingestion_api_purchase_hit';
	}

	/**
	 * Mixpanel Ingestion API endpoint for the configured data residency region.
	 *
	 * The verbose=1 parameter makes Mixpanel answer with a JSON body that names
	 * the reason a request failed, instead of a bare 1 or 0.
	 * https://docs.mixpanel.com/reference/track-event
	 *
	 * @return string
	 */
	private static function get_request_url() {
		return Options::get_mixpanel_api_host() . '/track?verbose=1';
	}

	/**
	 * Resend nothing, but report the refund as its own event, so Mixpanel
	 * revenue reports can net refunds out of the order revenue.
	 *
	 * @return void
	 * @since 1.64.1
	 */
	private static function hook_into_refund_events() {
		add_action('woocommerce_order_refunded', [ __CLASS__, 'send_refund_hit' ], 10, 2);
	}

	/**
	 * Add the Mixpanel browser identity to the identifiers.
	 *
	 * The Mixpanel JavaScript SDK keeps its identity in a first-party cookie
	 * named mp_{project_token}_mixpanel, holding a JSON object with the
	 * distinct_id and the $device_id. Reading it here, while the customer's
	 * browser is making the request, is what lets the server-side purchase
	 * event land on the same Mixpanel user as the browser events. Without it,
	 * the purchase would create a separate anonymous user and break every
	 * funnel that ends in a purchase.
	 *
	 * This is also why the browser SDK is initialized with Mixpanel's default
	 * cookie persistence rather than localStorage.
	 *
	 * @param array $identifiers
	 * @return array
	 * @since 1.64.1
	 */
	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		$cookie_name = 'mp_' . Options::get_mixpanel_project_token() . '_mixpanel';

		if (empty($_cookie[ $cookie_name ])) {
			return $identifiers;
		}

		$cookie_value = json_decode(urldecode(wp_unslash($_cookie[ $cookie_name ])), true);

		if (!is_array($cookie_value)) {
			return $identifiers;
		}

		if (!empty($cookie_value['distinct_id']) && self::is_valid_distinct_id($cookie_value['distinct_id'])) {
			$identifiers['mixpanel_distinct_id'] = sanitize_text_field($cookie_value['distinct_id']);
		}

		if (!empty($cookie_value['$device_id']) && self::is_valid_distinct_id($cookie_value['$device_id'])) {
			$identifiers['mixpanel_device_id'] = sanitize_text_field($cookie_value['$device_id']);
		}

		return $identifiers;
	}

	/**
	 * Check if a Mixpanel distinct ID is plausible.
	 *
	 * Mixpanel IDs are opaque and can carry the $device: prefix, so this is
	 * deliberately permissive and only blocks whitespace, markup and control
	 * characters.
	 *
	 * @param mixed $distinct_id
	 * @return bool
	 * @since 1.64.1
	 */
	public static function is_valid_distinct_id( $distinct_id ) {

		if (!is_string($distinct_id)) {
			return false;
		}

		return (bool) preg_match('/^[A-Za-z0-9$:@._~=+\/-]{5,255}$/', $distinct_id);
	}

	/**
	 * Build the purchase event for an order.
	 *
	 * Shared by the direct send (send_purchase_hit) and the SSP Purchase Proxy,
	 * which bundles this per-destination payload and forwards it to the SSP
	 * worker's Mixpanel adapter (buildRawRequest). Returns null if the order
	 * should not be processed.
	 *
	 * $insert_id is derived from the order ID, so a retry of the same order can
	 * never be counted twice.
	 * https://docs.mixpanel.com/reference/event-deduplication
	 *
	 * @param \WC_Order $order
	 * @return array|null
	 * @since 1.64.1
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		$properties = [
			'token'         => Options::get_mixpanel_project_token(),
			'distinct_id'   => self::get_distinct_id($order, $identifiers),
			'$insert_id'    => 'pmw_' . $order->get_id(),
			// Milliseconds since the epoch. Stamped with server time, because the
			// event is sent as the order reaches a paid state and a client clock
			// can never be trusted.
			'time'          => self::get_event_time(),
			'order_id'      => (string) $order->get_id(),
			'revenue'       => (float) Shop::get_order_value_total_marketing($order, true),
			'value'         => (float) Shop::get_order_value_total_marketing($order, true),
			'currency'      => $order->get_currency(),
			'tax'           => (float) $order->get_total_tax(),
			'shipping'      => (float) $order->get_shipping_total(),
			'product_count' => self::get_product_count($order),
			'products'      => self::get_products($order),
			'$source'       => 'Pixel Manager for WooCommerce',
		];

		if ($order->get_payment_method_title()) {
			$properties['payment_method'] = $order->get_payment_method_title();
		}

		$coupons = $order->get_coupon_codes();
		if (!empty($coupons)) {
			$properties['coupon'] = implode(', ', $coupons);
		}

		if (!empty($identifiers['mixpanel_device_id'])) {
			$properties['$device_id'] = $identifiers['mixpanel_device_id'];
		}

		// Mixpanel geolocates the event from the ip property.
		if (!empty($identifiers['ip_address'])) {
			$properties['ip'] = $identifiers['ip_address'];
		}

		return self::filter_purchase_payload('mixpanel', [
			'event'      => 'Order Completed',
			'properties' => $properties,
		], $order);
	}

	/**
	 * Send the purchase event directly to the Mixpanel Ingestion API.
	 *
	 * Used when the SSP is not active (when it is, the SSP Purchase Proxy
	 * handles the event via build_ssp_purchase_event_data() and the base class
	 * skips this direct send).
	 *
	 * @param \WC_Order $order
	 * @return void
	 */
	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached Mixpanel. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event = self::build_ssp_purchase_event_data($order);

			if (!$event) {
				return;
			}

			// The Mixpanel Ingestion API takes an array of events.
			$response = self::$http->post(self::get_request_url(), [ $event ]);

			if (self::mark_purchase_hit_sent($order, $response)) {
				Logger::debug('Mixpanel Ingestion API purchase hit sent for order ' . $order->get_id());
			}
		});
	}

	/**
	 * Report a refund to Mixpanel as its own event.
	 *
	 * Only runs for orders whose purchase event was sent, so consent
	 * suppression and order exclusions carry over to refunds. Refunds are
	 * always sent directly, since the SSP Purchase Proxy only bundles purchase
	 * events.
	 *
	 * @param int $order_id
	 * @param int $refund_id
	 * @return void
	 * @since 1.64.1
	 */
	public static function send_refund_hit( $order_id, $refund_id ) {

		if (!Options::is_mixpanel_ingestion_api_active()) {
			return;
		}

		$order = wc_get_order($order_id);

		if (!$order instanceof \WC_Order) {
			return;
		}

		// Only report refunds for orders whose purchase event was sent.
		if (!$order->meta_exists(self::get_purchase_hit_key())) {
			return;
		}

		$refund = wc_get_order($refund_id);

		if (!$refund) {
			return;
		}

		$identifiers = self::get_identifiers_from_order($order);

		$properties = [
			'token'         => Options::get_mixpanel_project_token(),
			'distinct_id'   => self::get_distinct_id($order, $identifiers),
			'$insert_id'    => 'pmw_refund_' . $refund_id,
			'time'          => self::get_event_time(),
			'order_id'      => (string) $order->get_id(),
			'refund_id'     => (string) $refund_id,
			// Refund totals are stored as negative values in WooCommerce. The
			// absolute amount is reported, so it can be subtracted from revenue
			// in Mixpanel without having to reason about the sign.
			'refund_value'  => abs((float) $refund->get_amount()),
			'currency'      => $order->get_currency(),
			'order_revenue' => (float) Shop::get_order_value_total_marketing($order, true),
			'$source'       => 'Pixel Manager for WooCommerce',
		];

		if ($refund->get_reason()) {
			$properties['refund_reason'] = $refund->get_reason();
		}

		$event = [
			'event'      => 'Order Refunded',
			'properties' => $properties,
		];

		self::$http->post(self::get_request_url(), [ $event ]);

		Logger::debug('Mixpanel Ingestion API refund hit sent for order ' . $order->get_id());
	}

	/**
	 * The Mixpanel server-side integration is driven by WooCommerce order
	 * hooks. Funnel events are sent by the browser SDK, which owns the Mixpanel
	 * identity, so events relayed from the browser are not used here.
	 *
	 * @param array $event_data
	 * @return void
	 */
	public static function send_event_hit( $event_data ) {}

	/**
	 * The event time in milliseconds since the epoch.
	 *
	 * @return int
	 * @since 1.64.1
	 */
	private static function get_event_time() {
		return (int) round(microtime(true) * 1000);
	}

	/**
	 * Resolve the Mixpanel distinct ID for an order.
	 *
	 * In priority order:
	 *
	 * 1. The distinct ID from the Mixpanel cookie, captured while the customer
	 *    was checking out. This keeps the purchase on the same Mixpanel user as
	 *    the browser events.
	 * 2. The WordPress user ID, when user identification is enabled. It matches
	 *    the ID the browser SDK calls mixpanel.identify() with.
	 * 3. A deterministic per-order ID as a last resort, so the revenue still
	 *    reaches Mixpanel rather than being dropped. It shows up as a one-off
	 *    anonymous user.
	 *
	 * @param \WC_Order $order
	 * @param array     $identifiers
	 * @return string
	 * @since 1.64.1
	 */
	private static function get_distinct_id( $order, $identifiers ) {

		if (!empty($identifiers['mixpanel_distinct_id'])) {
			return $identifiers['mixpanel_distinct_id'];
		}

		if (Options::is_mixpanel_user_identification_enabled() && $order->get_user_id()) {
			return (string) $order->get_user_id();
		}

		return 'pmw_order_' . $order->get_id();
	}

	/**
	 * The number of items in the order.
	 *
	 * @param \WC_Order $order
	 * @return int
	 * @since 1.64.1
	 */
	private static function get_product_count( $order ) {

		$count = 0;

		foreach (Product::pmw_get_order_items($order) as $order_item) {
			$count += (int) max(1, (int) round((float) $order_item->get_quantity()));
		}

		return $count;
	}

	/**
	 * The product list for an order, as a Mixpanel event property.
	 *
	 * @param \WC_Order $order
	 * @return array
	 * @since 1.64.1
	 */
	private static function get_products( $order ) {

		$products = [];

		foreach (Product::pmw_get_order_items($order) as $order_item) {

			$product_id = Product::get_variation_or_product_id($order_item->get_data(), Options::is_dynamic_remarketing_variations_output_enabled());
			$product    = wc_get_product($product_id);

			// Only add if WooCommerce retrieves a valid product
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			$quantity = (int) max(1, (int) round((float) $order_item->get_quantity()));

			$product_data = [
				'product_id' => (string) $product_id,
				'name'       => $order_item->get_name(),
				'quantity'   => $quantity,
				'price'      => round(( (float) $order_item->get_total() + (float) $order_item->get_total_tax() ) / $quantity, 2),
			];

			if ($product->get_sku()) {
				$product_data['sku'] = $product->get_sku();
			}

			$products[] = $product_data;
		}

		return $products;
	}
}
