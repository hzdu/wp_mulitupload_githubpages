<?php

namespace SweetCode\Pixel_Manager\Pixels\Mixpanel;

use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Adapter;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Descriptor;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Registry;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Mixpanel Ingestion API adapter for server-side event processing
 *
 * Handles filtering and sending events to the Mixpanel Ingestion API.
 * Also implements Pixel_Descriptor for the unified pixel registry.
 *
 * @package SweetCode\Pixel_Manager\Pixels\Mixpanel
 * @since   1.64.1
 */
class Mixpanel_Adapter extends Abstract_Pixel_Adapter implements Pixel_Descriptor {

	/**
	 * Constructor - auto-registers this adapter and descriptor
	 */
	public function __construct() {
		Pixel_Registry::register($this);
		Pixel_Registry::register_descriptor($this);
	}

	/**
	 * Get the pixel name
	 *
	 * @return string
	 */
	public function get_pixel_name() {
		return 'mixpanel';
	}

	/**
	 * Get the pixel name (Pixel_Descriptor interface)
	 *
	 * @return string
	 */
	public function get_name() {
		return $this->get_pixel_name();
	}

	/**
	 * Get the pixel's human-readable label
	 *
	 * @return string
	 */
	public function get_label() {
		return 'Mixpanel';
	}

	/**
	 * Get the pixel's category
	 *
	 * @return string
	 */
	public function get_category() {
		return 'statistics';
	}

	/**
	 * Check if the pixel is currently active
	 *
	 * @return bool
	 */
	public function is_active() {
		return Options::is_mixpanel_active();
	}

	/**
	 * Check if the pixel has browser-side tracking
	 *
	 * @return bool
	 */
	public function has_browser_tracking() {
		return true;
	}

	/**
	 * Check if the pixel has server-side tracking
	 *
	 * @return bool
	 */
	public function has_server_tracking() {
		return true;
	}

	/**
	 * Get the pixel's configuration schema
	 *
	 * @return array
	 */
	public function get_config_schema() {
		return [];
	}

	/**
	 * Check if the Mixpanel Ingestion API is available
	 *
	 * @return bool
	 */
	public function is_available() {
		return Options::is_mixpanel_ingestion_api_active();
	}

	/**
	 * Send event data to the Mixpanel Ingestion API
	 *
	 * @param array $pixel_data Filtered event data ready to send
	 * @return void
	 */
	protected function send( $pixel_data ) {
		Mixpanel_API::send_s2s_event($pixel_data);
	}
}

// Auto-register the adapter
new Mixpanel_Adapter();
