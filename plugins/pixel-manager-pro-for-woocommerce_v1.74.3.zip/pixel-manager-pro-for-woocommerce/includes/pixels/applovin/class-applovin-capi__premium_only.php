<?php

/**
 * AppLovin Conversion API
 * https://support.applovin.com/en/growth/promoting-your-websites/api/axon-conversion-api
 *
 * @since 1.69.3
 */

namespace SweetCode\Pixel_Manager\Pixels\AppLovin;

use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class AppLovin_CAPI
 */
class AppLovin_CAPI extends S2S {

	private static $http;

	private static $instance;

	/**
	 * The AppLovin event names the Conversion API accepts from the browser
	 * relay. AppLovin uses the same names on the pixel and the API, so the
	 * relay needs no translation, only this allow list: an unknown name is
	 * dropped instead of failing the request. purchase is deliberately absent,
	 * because purchases only ever leave through the order hooks.
	 *
	 * @var string[]
	 */
	private static $event_names = [
		'page_view',
		'view_item',
		'add_to_cart',
		'remove_from_cart',
		'view_cart',
		'begin_checkout',
		'add_payment_info',
		'search',
		'login',
		'sign_up',
		'generate_lead',
		'subscribe',
	];

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		// AppLovin takes the bare key in the Authorization header, without a
		// Bearer prefix.
		$request_args = [
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => Options::get_applovin_capi_token(),
			],
		];

		$http->set_request_args($request_args);

		self::$http = $http;

		self::hook_into_generic_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_applovin_capi_active();
	}

	/**
	 * AppLovin purchase events are routed through the SSP Purchase Proxy when
	 * the SSP is active. Non-SSP installs continue to send directly via
	 * send_purchase_hit().
	 *
	 * @return bool
	 * @since 1.69.3
	 */
	public static function is_handled_by_ssp() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'applovin_user_identifiers_' . Options::get_applovin_event_key();
	}

	public static function get_purchase_hit_key() {
		return 'pmw_applovin_capi_purchase_hit';
	}

	/**
	 * The Conversion API endpoint. The event key is the pixel_id.
	 *
	 * @return string
	 */
	private static function get_request_url() {
		return 'https://b.applovin.com/v1/event?pixel_id=' . rawurlencode(Options::get_applovin_event_key());
	}

	/**
	 * Both identifiers come from AppLovin's own cookies and change on their
	 * own schedule: a new ad click rewrites _axeid. The live browser value has
	 * to win over the copy stored in the WooCommerce session.
	 *
	 * @return string[]
	 * @since 1.69.3
	 */
	protected static function get_volatile_identifier_keys() {
		return [ 'aleid', 'axwrt' ];
	}

	/**
	 * The universal click ID snapshot stores AppLovin's click ID as aleid.
	 *
	 * @return array
	 * @since 1.69.3
	 */
	protected static function get_click_id_snapshot_map() {
		return [ 'aleid' => 'aleid' ];
	}

	/**
	 * Collect AppLovin's browser identifiers.
	 *
	 * - axwrt: the visitor ID the pixel keeps in _axwrt. The axwrt mirror the
	 *   Pixel Manager sets server-side covers browsers that capped the
	 *   pixel's own cookie.
	 * - aleid: the click ID, which the pixel copies from the landing page URL
	 *   into _axeid. The transient session identifiers cover a landing page on
	 *   which the pixel never ran.
	 *
	 * @param array $identifiers
	 * @return array
	 * @since 1.69.3
	 */
	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		foreach ([ '_axwrt', 'axwrt' ] as $cookie_name) {
			if (isset($_cookie[$cookie_name]) && self::is_valid_axwrt($_cookie[$cookie_name])) {
				$identifiers['axwrt'] = (string) $_cookie[$cookie_name];
				break;
			}
		}

		if (isset($_cookie['_axeid']) && self::is_valid_aleid($_cookie['_axeid'])) {
			$identifiers['aleid'] = (string) $_cookie['_axeid'];
		}

		if (!isset($identifiers['aleid'])) {

			$transient_identifiers = Shop::get_transient_identifiers_from_session();

			if (isset($transient_identifiers['aleid']) && self::is_valid_aleid($transient_identifiers['aleid'])) {
				$identifiers['aleid'] = $transient_identifiers['aleid'];
			}
		}

		return $identifiers;
	}

	/**
	 * Check if an AppLovin click ID (aleid) is plausible.
	 *
	 * AppLovin publishes no format, so this is deliberately permissive:
	 * URL-safe characters, sane length.
	 *
	 * @param mixed $aleid
	 * @return bool
	 * @since 1.69.3
	 */
	public static function is_valid_aleid( $aleid ) {
		return is_string($aleid) && (bool) preg_match('/^[A-Za-z0-9._~=-]{5,500}$/', $aleid);
	}

	/**
	 * Check if an AppLovin visitor ID (axwrt) is plausible.
	 *
	 * AppLovin's example is a UUID, but it does not commit to the format, so
	 * this accepts the same permissive shape as the click ID.
	 *
	 * @param mixed $axwrt
	 * @return bool
	 * @since 1.69.3
	 */
	public static function is_valid_axwrt( $axwrt ) {
		return is_string($axwrt) && (bool) preg_match('/^[A-Za-z0-9._~=-]{8,200}$/', $axwrt);
	}

	/**
	 * Whether AppLovin can match the event at all.
	 *
	 * AppLovin requires at least one of client_id, axwrt, alart, user_id,
	 * email or phone, and answers a request without any of them with an
	 * error. The IP address and user agent do not count.
	 *
	 * @param array $user_data
	 * @return bool
	 * @since 1.69.3
	 */
	public static function has_user_identifier( $user_data ) {

		foreach ([ 'client_id', 'axwrt', 'alart', 'user_id', 'email', 'phone' ] as $key) {
			if (!empty($user_data[$key])) {
				return true;
			}
		}

		return false;
	}

	/**
	 * The current Unix time in milliseconds, which is what AppLovin's
	 * event_time takes.
	 *
	 * @return int
	 * @since 1.69.3
	 */
	public static function get_event_time() {
		return (int) round(microtime(true) * 1000);
	}

	/**
	 * Build the purchase event for an order.
	 *
	 * Shared by the direct send (send_purchase_hit) and the SSP Purchase Proxy,
	 * which bundles this per-destination payload and forwards it to the SSP
	 * worker's AppLovin adapter (buildRawRequest). Returns null if the order
	 * should not be processed, or if it carries no identifier AppLovin could
	 * match it on.
	 *
	 * The dedupe_id mirrors the browser pixel's purchase event ID
	 * ("pmw_" + order ID), so AppLovin counts the pixel and the Conversion API
	 * purchase once.
	 *
	 * @param \WC_Order $order
	 * @return array|null
	 * @since 1.69.3
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);
		$user_data   = self::get_user_data_for_order($order, $identifiers);

		if (!self::has_user_identifier($user_data)) {
			Logger::debug('AppLovin CAPI: order #' . $order->get_id() . ' carries no identifier AppLovin can match on, skipping the purchase');
			return null;
		}

		return self::filter_purchase_payload('applovin', [
			'name'             => 'purchase',
			'event_time'       => self::get_event_time(),
			'event_source_url' => $order->get_checkout_order_received_url(),
			'dedupe_id'        => 'pmw_' . $order->get_id(),
			'user_data'        => $user_data,
			'data'             => self::get_purchase_data($order),
		], $order);
	}

	/**
	 * The purchase event's data object.
	 *
	 * The value is the order's marketing value, which AppLovin defines as the
	 * amount before tax and shipping; both go in their own fields, which are
	 * required even when they are zero.
	 *
	 * @param \WC_Order $order
	 * @return array
	 * @since 1.69.3
	 */
	public static function get_purchase_data( $order ) {

		return [
			'currency'        => $order->get_currency(),
			'value'           => round((float) Shop::get_order_value_total_marketing($order, true), 2),
			'tax'             => round((float) $order->get_total_tax(), 2),
			'shipping'        => round((float) $order->get_shipping_total(), 2),
			'transaction_id'  => (string) $order->get_order_number(),
			'is_new_customer' => (bool) Shop::is_new_customer($order),
			'items'           => self::get_items($order),
		];
	}

	/**
	 * The AppLovin item objects of an order.
	 *
	 * The price is the unit price after discounts and before tax, matching the
	 * pre-tax value. The product ID follows the dynamic remarketing ID type,
	 * like the browser pixel, so both match the catalog.
	 *
	 * @param \WC_Order $order
	 * @return array
	 * @since 1.69.3
	 */
	private static function get_items( $order ) {

		$items = [];

		foreach (Product::pmw_get_order_items($order) as $order_item) {

			$product_id = Product::get_variation_or_product_id($order_item->get_data(), Options::is_dynamic_remarketing_variations_output_enabled());
			$product    = wc_get_product($product_id);

			// Only add if WC retrieves a valid product
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			$quantity = (int) max(1, (int) round((float) $order_item->get_quantity()));

			$item = [
				'item_id'   => (string) Product::get_dyn_r_id_for_product_by_pixel_name($product, 'applovin'),
				'item_name' => $product->get_name(),
				'price'     => round((float) $order_item->get_total() / $quantity, 2),
				'quantity'  => $quantity,
			];

			if ($order_item->get_variation_id()) {
				$item['item_variant_id'] = (string) $order_item->get_variation_id();
			}

			$items[] = $item;
		}

		return $items;
	}

	/**
	 * Send the purchase event directly to the AppLovin Conversion API.
	 *
	 * Used when the SSP is not active (when it is, the SSP Purchase Proxy
	 * handles the event via build_ssp_purchase_event_data() and the base class
	 * skips this direct send).
	 *
	 * @param \WC_Order $order
	 * @return void
	 */
	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached AppLovin.
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event = self::build_ssp_purchase_event_data($order);

			if (!$event) {
				return;
			}

			$response = self::$http->post(self::get_request_url(), self::wrap_event($event));

			if (self::mark_purchase_hit_sent($order, $response)) {
				Logger::debug('AppLovin CAPI purchase hit sent for order ' . $order->get_id());
			}
		});
	}

	/**
	 * Send an S2S event originating from the browser (page_view, view_item,
	 * add_to_cart, begin_checkout, ...). The browser adapter (adapter.js)
	 * supplies the event name, the event_id used as dedupe_id, the data object
	 * and AppLovin's browser identifiers; the server adds the client IP, the
	 * user agent and, with advanced matching, the hashed personal data.
	 *
	 * @param array $event_data Event data from the browser adapter.
	 * @return void
	 */
	public static function send_event_hit( $event_data ) {

		self::get_instance();

		if (!Options::is_applovin_capi_active()) {
			return;
		}

		if (Shop::do_not_track_user(get_current_user_id())) {
			return;
		}

		$event_name = isset($event_data['event_name']) ? (string) $event_data['event_name'] : '';
		$event_id   = isset($event_data['event_id']) ? (string) $event_data['event_id'] : '';

		// Skip rather than send an event AppLovin rejects or cannot deduplicate.
		if (!in_array($event_name, self::$event_names, true) || '' === $event_id) {
			return;
		}

		$user_data = self::get_user_data_for_browser_event(
			isset($event_data['user_data']) && is_array($event_data['user_data']) ? $event_data['user_data'] : []
		);

		if (!self::has_user_identifier($user_data)) {
			return;
		}

		$event = [
			'name'             => $event_name,
			// Always stamp with server time. The event is being sent in near
			// real time, so server time is accurate and skew-proof. This
			// mirrors the SSP worker, which overwrites the timestamp with
			// server time.
			'event_time'       => self::get_event_time(),
			'event_source_url' => self::get_event_source_url($event_data),
			'dedupe_id'        => $event_id,
			'user_data'        => $user_data,
			'data'             => isset($event_data['event_data']) && is_array($event_data['event_data'])
				? $event_data['event_data']
				: new \stdClass(),
		];

		self::$http->post(self::get_request_url(), self::wrap_event($event));
	}

	/**
	 * Wrap a single event in the Conversion API envelope.
	 *
	 * @param array $event
	 * @return array
	 * @since 1.69.3
	 */
	private static function wrap_event( $event ) {
		return [
			'events' => [ $event ],
		];
	}

	/**
	 * The page a browser-relayed event happened on.
	 *
	 * The adapter reports it; the referrer of the relay request is the
	 * fallback, because the relay is sent from that page.
	 *
	 * @param array $event_data
	 * @return string
	 * @since 1.69.3
	 */
	private static function get_event_source_url( $event_data ) {

		if (!empty($event_data['event_source_url']) && filter_var($event_data['event_source_url'], FILTER_VALIDATE_URL)) {
			return (string) $event_data['event_source_url'];
		}

		$_server = Helpers::get_input_vars(INPUT_SERVER);

		if (!empty($_server['HTTP_REFERER']) && filter_var($_server['HTTP_REFERER'], FILTER_VALIDATE_URL)) {
			return (string) $_server['HTTP_REFERER'];
		}

		return home_url('/');
	}

	/**
	 * Get the user_data object for an order.
	 *
	 * The AppLovin identifiers, the client IP and the user agent always go
	 * out. The hashed email, phone, user ID, country and postcode only when
	 * the shop enabled advanced matching, like every other Conversions API
	 * the Pixel Manager sends to.
	 *
	 * @param \WC_Order $order
	 * @param array     $identifiers
	 * @return array
	 * @since 1.69.3
	 */
	private static function get_user_data_for_order( $order, $identifiers ) {

		$user_data = [
			'esi' => 'web',
		];

		if (!empty($identifiers['ip_address'])) {
			$user_data['client_ip_address'] = $identifiers['ip_address'];
		}

		if (!empty($identifiers['user_agent'])) {
			$user_data['client_user_agent'] = $identifiers['user_agent'];
		}

		if (!empty($identifiers['axwrt']) && self::is_valid_axwrt($identifiers['axwrt'])) {
			$user_data['axwrt'] = $identifiers['axwrt'];
		}

		if (!empty($identifiers['aleid']) && self::is_valid_aleid($identifiers['aleid'])) {
			$user_data['aleid'] = $identifiers['aleid'];
		}

		if (Options::is_applovin_advanced_matching_enabled()) {
			$user_data = array_merge($user_data, self::get_personal_user_data(Helpers::get_user_data($order)));
		}

		return $user_data;
	}

	/**
	 * Get the user_data object for a browser-relayed event.
	 *
	 * @param array $browser_identifiers The axwrt and aleid the browser adapter read from AppLovin's cookies.
	 * @return array
	 * @since 1.69.3
	 */
	private static function get_user_data_for_browser_event( $browser_identifiers ) {

		$identifiers = self::add_pixel_specific_identifiers([]);

		// The adapter read the cookies in the browser, possibly after this
		// request's cookie header was built, so its values fill the gaps.
		foreach ([ 'axwrt', 'aleid' ] as $key) {
			if (empty($identifiers[$key]) && !empty($browser_identifiers[$key])) {
				$identifiers[$key] = $browser_identifiers[$key];
			}
		}

		$user_data = [
			'esi' => 'web',
		];

		if (Geolocation::get_user_ip()) {
			$user_data['client_ip_address'] = Geolocation::get_user_ip();
		}

		$_server = Helpers::get_input_vars(INPUT_SERVER);

		if (!empty($_server['HTTP_USER_AGENT'])) {
			$user_data['client_user_agent'] = (string) $_server['HTTP_USER_AGENT'];
		}

		if (!empty($identifiers['axwrt']) && self::is_valid_axwrt($identifiers['axwrt'])) {
			$user_data['axwrt'] = $identifiers['axwrt'];
		}

		if (!empty($identifiers['aleid']) && self::is_valid_aleid($identifiers['aleid'])) {
			$user_data['aleid'] = $identifiers['aleid'];
		}

		if (Options::is_applovin_advanced_matching_enabled()) {
			$user_data = array_merge($user_data, self::get_personal_user_data(Helpers::get_user_data()));
		}

		return $user_data;
	}

	/**
	 * The personal identifiers AppLovin matches on, hashed the way AppLovin
	 * documents it.
	 *
	 * @param array $helper_user_data The output of Helpers::get_user_data().
	 * @return array
	 * @since 1.69.3
	 */
	public static function get_personal_user_data( $helper_user_data ) {

		$user_data = [];

		if (!empty($helper_user_data['email']['applovin'])) {
			$user_data['email'] = $helper_user_data['email']['applovin'];
		}

		if (!empty($helper_user_data['phone']['applovin'])) {
			$user_data['phone'] = $helper_user_data['phone']['applovin'];
		}

		// The hashed WordPress user ID: AppLovin wants at least six characters.
		if (!empty($helper_user_data['id']['sha256'])) {
			$user_data['user_id'] = $helper_user_data['id']['sha256'];
		}

		if (!empty($helper_user_data['country']['raw'])) {
			$user_data['country_code'] = strtoupper((string) $helper_user_data['country']['raw']);
		}

		if (!empty($helper_user_data['postcode']['raw'])) {
			$user_data['zip'] = (string) $helper_user_data['postcode']['raw'];
		}

		return $user_data;
	}

	/**
	 * Mirror the pixel's _axwrt cookie into a server-set axwrt cookie.
	 *
	 * AppLovin strongly recommends it: Safari and other browsers cap cookies
	 * written by JavaScript to days, a cookie set in an HTTP response keeps
	 * its full year, so the visitor stays recognisable on a later visit.
	 * AppLovin's spec is one year, the site's domain with a leading dot and
	 * without www, path /, SameSite=Lax and not HttpOnly.
	 *
	 * Called only from the Pixel Manager's own AJAX endpoint, which is
	 * uncached by definition: on a page render a page cache could store the
	 * Set-Cookie header and hand one visitor's ID to everyone. Requires
	 * granted marketing consent, like the pixel itself.
	 *
	 * @param array|null $consent The visitor's consent snapshot (see Click_Ids::get_consent_snapshot()).
	 * @return void
	 * @since 1.69.3
	 */
	public static function maybe_mirror_axwrt_cookie( $consent ) {

		if (headers_sent() || !Options::is_applovin_active()) {
			return;
		}

		if (!is_array($consent) || true !== $consent['marketing']) {
			return;
		}

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		if (empty($_cookie['_axwrt']) || !self::is_valid_axwrt($_cookie['_axwrt'])) {
			return;
		}

		$expires = time() + YEAR_IN_SECONDS;
		$cookie  = 'axwrt=' . $_cookie['_axwrt']
			. '; Expires=' . gmdate('D, d M Y H:i:s', $expires) . ' GMT'
			. '; Max-Age=' . YEAR_IN_SECONDS
			. '; Path=/';

		$domain = self::get_mirror_cookie_domain();

		if ('' !== $domain) {
			$cookie .= '; Domain=' . $domain;
		}

		$cookie .= '; SameSite=Lax';

		if (is_ssl()) {
			$cookie .= '; Secure';
		}

		header('Set-Cookie: ' . $cookie, false);
	}

	/**
	 * The cookie domain for the axwrt mirror: the site's host without www and
	 * with a leading dot, as AppLovin specifies. A host that cannot carry a
	 * domain cookie (localhost, an IP address) gets a host-only cookie.
	 *
	 * @return string
	 * @since 1.69.3
	 */
	public static function get_mirror_cookie_domain() {

		if (defined('COOKIE_DOMAIN') && COOKIE_DOMAIN) {
			return '.' . ltrim((string) COOKIE_DOMAIN, '.');
		}

		$host = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));

		if ('' === $host || false === strpos($host, '.') || filter_var($host, FILTER_VALIDATE_IP)) {
			return '';
		}

		if (0 === strpos($host, 'www.')) {
			$host = substr($host, 4);
		}

		return '.' . $host;
	}
}
