<?php

namespace SweetCode\Pixel_Manager\Pixels\Bing;

use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Adapter;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Registry;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Microsoft Advertising Conversions API adapter for server-side event processing
 *
 * Handles filtering and sending events to the Microsoft Advertising Conversions
 * API. The pixel's descriptor lives in the free Bing_Descriptor, so the
 * registry knows the UET tag on every tier; this adapter only exists on Pro
 * builds.
 *
 * @package SweetCode\Pixel_Manager\Pixels\Bing
 * @since   1.65.2
 */
class Bing_Adapter extends Abstract_Pixel_Adapter {

	/**
	 * Constructor - auto-registers this adapter
	 */
	public function __construct() {
		Pixel_Registry::register($this);
	}

	/**
	 * Get the pixel name
	 *
	 * @return string
	 */
	public function get_pixel_name() {
		return 'bing';
	}

	/**
	 * Check if the Microsoft Advertising Conversions API is available
	 *
	 * @return bool
	 */
	public function is_available() {
		return Options::is_bing_capi_active();
	}

	/**
	 * Send event data to the Microsoft Advertising Conversions API
	 *
	 * @param array $pixel_data Filtered event data ready to send
	 * @return void
	 */
	protected function send( $pixel_data ) {
		Bing_CAPI::send_s2s_event($pixel_data);
	}
}

// Auto-register the adapter
new Bing_Adapter();
