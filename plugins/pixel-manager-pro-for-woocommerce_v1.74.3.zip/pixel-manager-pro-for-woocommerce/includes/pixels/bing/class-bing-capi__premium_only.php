<?php

/**
 * Microsoft Advertising Conversions API (CAPI)
 *
 * Server-side counterpart of the Microsoft Advertising UET tag. The browser
 * pixel and the Conversions API share one UET tag ID and one event ID per
 * event, so Microsoft deduplicates the two channels against each other.
 *
 * https://learn.microsoft.com/en-us/advertising/guides/uet-conversion-api-integration
 *
 * @since 1.65.2
 */

namespace SweetCode\Pixel_Manager\Pixels\Bing;

use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class Bing_CAPI
 */
class Bing_CAPI extends S2S {

	/**
	 * Identifies the Pixel Manager as the sender of the events. Microsoft
	 * requires it for third-party senders and uses it for analysis, debugging
	 * and monitoring on their side.
	 *
	 * @var string
	 */
	const DATA_PROVIDER = 'pixel_manager_for_woocommerce';

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		// The token is set on the HTTP object rather than passed per request,
		// because the third argument of HTTP::post() is written to the log.
		$request_args = [
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . Options::get_bing_capi_token(),
			],
		];

		$http->set_request_args($request_args);

		self::$http = $http;

		self::hook_into_generic_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_bing_capi_active();
	}

	/**
	 * Microsoft Advertising purchase events are routed through the SSP Purchase
	 * Proxy when the SSP is active. Non-SSP installs continue to send directly
	 * via send_purchase_hit().
	 *
	 * @return bool
	 * @since 1.65.2
	 */
	public static function is_handled_by_ssp() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'bing_user_identifiers_' . Options::get_bing_uet_tag_id();
	}

	public static function get_purchase_hit_key() {
		return 'pmw_bing_capi_purchase_hit';
	}

	/**
	 * The _uetvid cookie is written by the UET tag and expires on its own
	 * schedule, so the live browser value must win over a copy frozen in the
	 * WooCommerce session.
	 *
	 * @return string[]
	 * @since 1.65.2
	 */
	protected static function get_volatile_identifier_keys() {
		return [ 'uetvid' ];
	}

	/**
	 * Microsoft Advertising Conversions API endpoint.
	 *
	 * The UET tag ID is part of the path, and the token in the Authorization
	 * header is only valid for that tag.
	 * https://learn.microsoft.com/en-us/advertising/guides/uet-conversion-api-integration#api-endpoint
	 *
	 * @return string
	 */
	private static function get_request_url() {
		return 'https://capi.uet.microsoft.com/v1/' . rawurlencode(Options::get_bing_uet_tag_id()) . '/events';
	}

	/**
	 * Add the Microsoft click ID (msclkid) and the UET visitor ID to the
	 * identifiers.
	 *
	 * The msclkid is appended to the landing page URL after an ad click when
	 * auto-tagging is enabled. Microsoft has no server-readable click ID
	 * cookie of its own that is documented as stable, so the Pixel Manager
	 * captures the URL parameter itself (event_listeners.js) and ships it to
	 * the WooCommerce session through the transient identifiers round-trip on
	 * the cart and checkout pages.
	 *
	 * _uetvid is the first-party visitor ID cookie the UET tag writes. It is
	 * sent as the anonymousId, which is the identifier Microsoft uses to
	 * associate events with a visitor over time.
	 *
	 * @param array $identifiers
	 * @return array
	 * @since 1.65.2
	 */
	/**
	 * Click IDs this destination recovers from the universal per-order
	 * snapshot when its own identifiers carry none (historical orders,
	 * a destination activated later, a backfill).
	 *
	 * @return array<string, string>
	 * @since 1.66.0
	 */
	protected static function get_click_id_snapshot_map() {
		return [ 'msclkid' => 'msclkid' ];
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$transient_identifiers = Shop::get_transient_identifiers_from_session();

		if (isset($transient_identifiers['msclkid']) && self::is_valid_msclkid($transient_identifiers['msclkid'])) {
			$identifiers['msclkid'] = $transient_identifiers['msclkid'];
		}

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		if (isset($_cookie['_uetvid'])) {
			$uetvid = self::normalize_uetvid(sanitize_text_field(wp_unslash($_cookie['_uetvid'])));
			if ($uetvid) {
				$identifiers['uetvid'] = $uetvid;
			}
		}

		return $identifiers;
	}

	/**
	 * Check if a Microsoft click ID (msclkid) is plausible.
	 *
	 * Microsoft documents the msclkid as a UUID and issues it as a 32
	 * character hexadecimal GUID without separators. Both spellings are
	 * accepted and passed through unchanged: rewriting an identifier the
	 * platform issued is riskier than sending it as received.
	 *
	 * @param mixed $msclkid
	 * @return bool
	 * @since 1.65.2
	 */
	public static function is_valid_msclkid( $msclkid ) {

		if (!is_string($msclkid)) {
			return false;
		}

		return (bool) preg_match('/^[0-9a-fA-F]{32}$|^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/', $msclkid);
	}

	/**
	 * Extract the visitor ID out of the _uetvid cookie.
	 *
	 * The cookie is a pipe-delimited composite whose first segment is the
	 * visitor ID, a version 1 UUID with or without separators. While Microsoft
	 * consent mode has ad storage denied, the UET tag writes the placeholder
	 * "null" into that first segment instead, and sending that string as an
	 * anonymousId would associate every consent-denied visitor with one
	 * another. Anything that is not a well-formed ID is dropped rather than
	 * sent, because Microsoft removes malformed optional fields and reports
	 * them as validation warnings.
	 *
	 * @param mixed $uetvid
	 * @return string The visitor ID, or an empty string when there is none.
	 * @since 1.65.2
	 */
	public static function normalize_uetvid( $uetvid ) {

		if (!is_string($uetvid) || '' === $uetvid) {
			return '';
		}

		$visitor_id = explode('|', $uetvid)[0];

		if (!preg_match('/^[0-9a-fA-F]{32}$|^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/', $visitor_id)) {
			return '';
		}

		return $visitor_id;
	}

	/**
	 * Wrap one or more events into the request body the Conversions API
	 * expects.
	 *
	 * Setting continueOnValidationError keeps a single malformed event from taking the
	 * whole request down. Microsoft then returns HTTP 200 with per-event
	 * validation details instead of rejecting everything.
	 *
	 * @param array $events
	 * @return array
	 * @since 1.65.2
	 */
	private static function build_request_body( $events ) {
		return [
			'data'                     => $events,
			'continueOnValidationError' => true,
			'dataProvider'             => self::DATA_PROVIDER,
		];
	}

	/**
	 * Build the purchase event for an order.
	 *
	 * Shared by the direct send (send_purchase_hit) and the SSP Purchase Proxy,
	 * which bundles this per-destination payload and forwards it to the SSP
	 * worker's Microsoft Advertising adapter (buildRawRequest). Returns null if
	 * the order should not be processed.
	 *
	 * The eventId mirrors the browser pixel's purchase event ID
	 * ("pmw_" + order ID) and the eventName matches the one the UET tag pushes,
	 * so Microsoft deduplicates the browser pixel and the Conversions API
	 * purchase against each other.
	 *
	 * @param \WC_Order $order
	 * @return array|null
	 * @since 1.65.2
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		$items    = self::get_items($order);
		$item_ids = array_values(array_filter(array_map(function ( $item ) {
			return isset($item['id']) ? $item['id'] : null;
		}, $items)));

		$order_value = (float) Shop::get_order_value_total_marketing($order, true);

		$custom_data = [
			'transactionId'   => (string) $order->get_id(),
			'pageType'        => 'purchase',
			'value'           => $order_value,
			'ecommTotalValue' => $order_value,
			'currency'        => $order->get_currency(),
		];

		if ($items) {
			$custom_data['items']   = $items;
			$custom_data['itemIds'] = $item_ids;
		}

		$event = [
			'eventType'   => 'custom',
			'eventName'   => 'purchase',
			'eventId'     => 'pmw_' . $order->get_id(),
			// Unix seconds, UTC. Microsoft rejects timestamps older than seven
			// days, and the SSP worker overwrites this with its own server time.
			'eventTime'   => time(),
			'userData'    => self::get_user_data($order, $identifiers),
			'customData'  => $custom_data,
		];

		$source_url = self::get_order_source_url($order);
		if ($source_url) {
			$event['eventSourceUrl'] = $source_url;
		}

		// The referrer captured from the customer's browser at checkout time.
		// Microsoft builds referral remarketing lists from it and drops the
		// field with a validation warning when it is not a valid URL.
		if (!empty($identifiers['referrer']) && filter_var($identifiers['referrer'], FILTER_VALIDATE_URL)) {
			$event['referrerUrl'] = esc_url_raw($identifiers['referrer']);
		}

		$consent = self::get_ad_storage_consent($order);
		if ($consent) {
			$event['adStorageConsent'] = $consent;
		}

		return self::filter_purchase_payload('bing', $event, $order);
	}

	/**
	 * Send the purchase event directly to the Microsoft Advertising Conversions
	 * API.
	 *
	 * Used when the SSP is not active (when it is, the SSP Purchase Proxy
	 * handles the event via build_ssp_purchase_event_data() and the base class
	 * skips this direct send).
	 *
	 * @param \WC_Order $order
	 * @return void
	 */
	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached Microsoft. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event = self::build_ssp_purchase_event_data($order);

			if (!$event) {
				return;
			}

			$response = self::$http->post(self::get_request_url(), self::build_request_body([ $event ]));

			if (self::mark_purchase_hit_sent($order, $response)) {
				Logger::debug('Microsoft Advertising CAPI purchase hit sent for order ' . $order->get_id());
			}
		});
	}

	/**
	 * Send an S2S event originating from the browser (view_item, view_category,
	 * search, add_to_cart and the generic page events). The browser adapter
	 * (adapter.js) supplies the event ID, the UET event name, the Conversions
	 * API custom data, the source URL and any enhanced conversions user data;
	 * the server enriches it with the client IP, the user agent, the msclkid
	 * click ID and the UET visitor ID.
	 *
	 * @param array $event_data Event data from the browser adapter.
	 * @return void
	 */
	public static function send_event_hit( $event_data ) {

		self::get_instance();

		if (!Options::is_bing_capi_active()) {
			return;
		}

		if (Shop::do_not_track_user(get_current_user_id())) {
			return;
		}

		$user_data = isset($event_data['user_data']) && is_array($event_data['user_data']) ? $event_data['user_data'] : [];

		// Add the client IP address
		if (Geolocation::get_user_ip()) {
			$user_data['clientIpAddress'] = Geolocation::get_user_ip();
		}

		// Add the user agent
		$user_agent = Helpers::get_request_user_agent();
		if ($user_agent) {
			$user_data['clientUserAgent'] = $user_agent;
		}

		// This request originates from the visitor's browser, so the UET
		// visitor ID cookie is available here even when the adapter did not
		// send one.
		if (empty($user_data['anonymousId'])) {
			$_cookie = Helpers::get_input_vars(INPUT_COOKIE);
			if (isset($_cookie['_uetvid'])) {
				$uetvid = self::normalize_uetvid(sanitize_text_field(wp_unslash($_cookie['_uetvid'])));
				if ($uetvid) {
					$user_data['anonymousId'] = $uetvid;
				}
			}
		}

		if (isset($user_data['msclkid']) && !self::is_valid_msclkid($user_data['msclkid'])) {
			unset($user_data['msclkid']);
		}

		if (isset($user_data['anonymousId'])) {
			$user_data['anonymousId'] = self::normalize_uetvid($user_data['anonymousId']);
			if (!$user_data['anonymousId']) {
				unset($user_data['anonymousId']);
			}
		}

		// Every event must carry at least one supported identifier, otherwise
		// Microsoft rejects it. Skip rather than send a request that cannot be
		// accepted.
		if (!self::has_supported_identifier($user_data)) {
			return;
		}

		$event = [
			'eventType'  => 'custom',
			// Always stamp with server time. The event is being sent in near
			// real time, so server time is accurate and skew-proof. This
			// mirrors the SSP worker, which overwrites the timestamp with
			// server time.
			'eventTime'  => time(),
			'userData'   => $user_data,
			'customData' => isset($event_data['custom_data']) && is_array($event_data['custom_data']) ? $event_data['custom_data'] : [],
		];

		if (!empty($event_data['event_id'])) {
			$event['eventId'] = sanitize_text_field($event_data['event_id']);
		}

		// The generic ecommerce page events (category, search, everywhere else)
		// carry no UET event name. Microsoft treats eventName as optional, so
		// it is omitted rather than sent empty.
		if (!empty($event_data['event_name'])) {
			$event['eventName'] = sanitize_text_field($event_data['event_name']);
		}

		if (!empty($event_data['source_url'])) {
			$event['eventSourceUrl'] = esc_url_raw($event_data['source_url']);
		}

		// Microsoft drops an invalid referrerUrl with a validation warning, so
		// it is only forwarded when it really is a URL.
		if (!empty($event_data['referrer_url']) && filter_var($event_data['referrer_url'], FILTER_VALIDATE_URL)) {
			$event['referrerUrl'] = esc_url_raw($event_data['referrer_url']);
		}

		if (!empty($event_data['page_title'])) {
			$event['pageTitle'] = sanitize_text_field($event_data['page_title']);
		}

		if (!empty($event_data['ad_storage_consent'])) {
			$event['adStorageConsent'] = 'D' === $event_data['ad_storage_consent'] ? 'D' : 'G';
		}

		self::$http->post(self::get_request_url(), self::build_request_body([ $event ]));
	}

	/**
	 * Whether the user data object carries at least one of the identifiers
	 * Microsoft accepts. Events without one are rejected.
	 *
	 * See https://learn.microsoft.com/en-us/advertising/guides/uet-conversion-api-integration#visitor-id-and-user-id
	 *
	 * @param array $user_data
	 * @return bool
	 * @since 1.65.2
	 */
	private static function has_supported_identifier( $user_data ) {

		foreach ([ 'anonymousId', 'externalId', 'em', 'ph', 'msclkid', 'idfa', 'gaid' ] as $key) {
			if (!empty($user_data[$key])) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get the userData object for an order.
	 *
	 * The click ID, visitor ID, IP address and user agent are sent as raw
	 * values, as the API expects. Email and phone are only sent when
	 * Microsoft Enhanced Conversions are enabled, and always as SHA-256 hashes
	 * of the normalized value, matching what the browser pixel pushes through
	 * uetq "set" pid.
	 *
	 * https://learn.microsoft.com/en-us/advertising/guides/uet-conversion-api-integration#user-data
	 *
	 * @param \WC_Order $order
	 * @param array     $identifiers
	 * @return array
	 * @since 1.65.2
	 */
	private static function get_user_data( $order, $identifiers ) {

		$user_data = [];

		if (isset($identifiers['ip_address'])) {
			$user_data['clientIpAddress'] = $identifiers['ip_address'];
		}

		if (isset($identifiers['user_agent'])) {
			$user_data['clientUserAgent'] = $identifiers['user_agent'];
		}

		if (isset($identifiers['msclkid'])) {
			$user_data['msclkid'] = $identifiers['msclkid'];
		}

		if (isset($identifiers['uetvid'])) {
			$user_data['anonymousId'] = $identifiers['uetvid'];
		}

		if (Options::is_bing_enhanced_conversions_enabled()) {

			$order_user_data = Helpers::get_user_data($order);

			// Email (SHA-256 of the normalized address)
			if (!empty($order_user_data['email']['sha256'])) {
				$user_data['em'] = $order_user_data['email']['sha256'];
			}

			// Phone (SHA-256 of the E.164 formatted number)
			if (!empty($order_user_data['phone']['sha256']['e164'])) {
				$user_data['ph'] = $order_user_data['phone']['sha256']['e164'];
			}

			// External ID (SHA-256 hashed user ID) for signed-in customers
			if (!empty($order_user_data['id']['sha256'])) {
				$user_data['externalId'] = $order_user_data['id']['sha256'];
			}
		}

		return $user_data;
	}

	/**
	 * Translate the consent snapshot stamped onto the order into the
	 * adStorageConsent signal.
	 *
	 * Microsoft processes every event as granted unless told otherwise. An
	 * event only reaches this point with denied marketing consent when the
	 * shop manager enabled "always send server-side events", so flagging it as
	 * denied keeps the shop's own consent choice intact: Microsoft accepts the
	 * event but uses it for no advertising purpose.
	 *
	 * Returns an empty string when no snapshot exists, which leaves the field
	 * out and keeps Microsoft's default.
	 *
	 * https://learn.microsoft.com/en-us/advertising/guides/uet-conversion-api-integration#consent-signals
	 *
	 * @param \WC_Order $order
	 * @return string 'G', 'D' or ''
	 * @since 1.65.2
	 */
	private static function get_ad_storage_consent( $order ) {

		$snapshot = $order->get_meta(self::get_consent_snapshot_key(), true);

		if (!is_array($snapshot) || empty($snapshot)) {
			return '';
		}

		return empty($snapshot[static::get_consent_category()]) ? 'D' : 'G';
	}

	/**
	 * The URL the conversion happened on. Falls back to the shop home URL,
	 * because the purchase hook can fire from a webhook or cron run where no
	 * request URL exists.
	 *
	 * @param \WC_Order $order
	 * @return string
	 * @since 1.65.2
	 */
	private static function get_order_source_url( $order ) {

		$url = $order->get_checkout_order_received_url();

		return $url ? esc_url_raw($url) : esc_url_raw(home_url());
	}

	/**
	 * Get the items array for an order.
	 *
	 * The product IDs must match the id or item_group_id attribute of the feed
	 * submitted to the Microsoft Merchant Center, which is what the dynamic
	 * remarketing ID type resolves to.
	 *
	 * https://learn.microsoft.com/en-us/advertising/guides/uet-conversion-api-integration#items-array
	 *
	 * @param \WC_Order $order
	 * @return array
	 * @since 1.65.2
	 */
	private static function get_items( $order ) {

		$items = [];

		foreach (Product::pmw_get_order_items($order) as $order_item) {

			$product_id = Product::get_variation_or_product_id($order_item->get_data(), Options::is_dynamic_remarketing_variations_output_enabled());
			$product    = wc_get_product($product_id);

			// Only add if WC retrieves a valid product
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			$quantity = (int) max(1, (int) round((float) $order_item->get_quantity()));

			$items[] = [
				'id'       => (string) Product::get_dyn_r_id_for_product_by_pixel_name($product, 'bing'),
				'quantity' => $quantity,
				'price'    => round(( (float) $order_item->get_total() + (float) $order_item->get_total_tax() ) / $quantity, 2),
				'name'     => $product->get_name(),
			];
		}

		return $items;
	}
}
