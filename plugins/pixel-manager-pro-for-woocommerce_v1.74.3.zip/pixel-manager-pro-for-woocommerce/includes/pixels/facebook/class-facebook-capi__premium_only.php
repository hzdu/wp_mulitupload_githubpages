<?php

/**
 * Facebook CAPI Pixel Class
 *
 * Handles server-to-server communication with Facebook CAPI
 *
 * @package Pixel_Manager/Classes/Pixels/Facebook
 */

namespace SweetCode\Pixel_Manager\Pixels\Facebook;

use SweetCode\Pixel_Manager\Admin\LTV;
use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Profit_Margin;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;
use SweetCode\Pixel_Manager\Social_Login;
use SweetCode\Pixel_Manager\Product;

defined('ABSPATH') || exit; // Exit if accessed directly

class Facebook_CAPI extends S2S {

	/**
	 * Events this path records at info level.
	 *
	 * One line per order, which is what somebody goes looking for when the
	 * question is whether the server actually sent the event. Everything else
	 * this class sends fires per page view and would bury it, so it stays at
	 * debug.
	 */
	const LOGGED_EVENTS = [ 'Purchase', 'Subscribe', 'RecurringSubscriptionPayment', 'CancelSubscription' ];

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		self::$http = $http;

		self::hook_into_generic_events();
		self::hook_into_subscriptions_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_facebook_capi_active();
	}

	public static function is_handled_by_ssp() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'facebook_user_identifiers_' . Options::get_facebook_pixel_id();
	}

	public static function get_purchase_hit_key() {
		return 'wpm_facebook_capi_purchase_hit';
	}

	// https://developers.facebook.com/docs/graph-api/changelog/versions
	private static function get_api_version() {

		$api_version = 'v24.0';

		$api_version = apply_filters_deprecated('wooptpm_facebook_capi_api_version', [ $api_version ], '1.13.0', 'pmw_facebook_capi_api_version');
		$api_version = apply_filters_deprecated('wpm_facebook_capi_api_version', [ $api_version ], '1.31.2', 'pmw_facebook_capi_api_version');

		/**
		 * Filter to output the Facebook API version.
		 *
		 * @since 1.31.2
		 */
		return apply_filters('pmw_facebook_capi_api_version', $api_version);
	}

	private static function get_request_url( $pixel_identifier ) {

		$request_url  = 'https://';
		$request_url .= 'graph.facebook.com/';
		$request_url .= self::get_api_version() . '/';
		$request_url .= $pixel_identifier['pixel_id'] . '/';
		$request_url .= 'events';
		$request_url .= '?access_token=' . $pixel_identifier['capi_token'];

		return $request_url;
	}

	/**
	 * Send one event to every Facebook pixel that has a Conversion API token.
	 *
	 * The event payload is identical for all pixels. Only the request URL
	 * (pixel ID plus token) and the test_event_code differ per pixel.
	 *
	 * @param array $event_data The inner event data object.
	 * @return array|\WP_Error|null The first WP_Error when any pixel's request failed,
	 *                              otherwise the last response (null without pixels).
	 *                              Returned @since 1.69.3.
	 *
	 * @since 1.64.0
	 */
	private static function post_event_to_capi_pixels( $event_data ) {

		$pixel_count = 0;
		$result      = null;

		foreach (Facebook::get_capi_pixel_identifiers() as $pixel_identifier) {

			$payload = [
				'data' => [ $event_data ],
			];

			if ($pixel_identifier['test_event_code']) {
				$payload['test_event_code'] = $pixel_identifier['test_event_code'];
			}

			$response = self::$http->post(self::get_request_url($pixel_identifier), $payload);
			++$pixel_count;

			if (!is_wp_error($result)) {
				$result = $response;
			}
		}

		self::log_sent_event($event_data, $pixel_count);

		return $result;
	}

	/**
	 * Record what the direct Conversions API path just sent.
	 *
	 * The Server-Side Proxy writes one line per dispatched purchase, and that
	 * line is how a shop proves a server-side event went out for an order. The
	 * direct path wrote nothing at any level, so a shop that does not run the
	 * proxy could not verify its own server sends, and neither could we: on a
	 * support case that came down to exactly that question, an order's CAPI hit
	 * was invisible in a log captured at info.
	 *
	 * These requests are non-blocking unless the
	 * pmw_send_all_s2s_requests_blocking filter says otherwise, so the line
	 * says what was sent, never what Meta accepted.
	 *
	 * @param array $event_data  The event data object that was posted.
	 * @param int   $pixel_count How many pixels it went to.
	 * @since 1.66.1
	 */
	private static function log_sent_event( $event_data, $pixel_count ) {

		$message = self::sent_event_message($event_data, $pixel_count);

		if ('info' === self::sent_event_log_level($event_data, $pixel_count)) {
			Logger::info($message);
			return;
		}

		Logger::debug($message);
	}

	/**
	 * The log line for one dispatched event.
	 *
	 * The event ID carries the order number for purchases (`pmw_41556`), which
	 * is what makes the line greppable per order the way the proxy's is.
	 *
	 * @param array $event_data
	 * @param int   $pixel_count
	 * @return string
	 * @since 1.66.1
	 */
	private static function sent_event_message( $event_data, $pixel_count ) {

		$event_name = isset($event_data['event_name']) ? $event_data['event_name'] : 'event';
		$event_id   = isset($event_data['event_id']) ? $event_data['event_id'] : 'none';

		return 'Facebook CAPI: sent ' . $event_name
			. ' (event ID ' . $event_id . ')'
			. ' to ' . (int) $pixel_count . ' pixel' . ( 1 === (int) $pixel_count ? '' : 's' );
	}

	/**
	 * Which level one dispatched event is logged at.
	 *
	 * `info` for the once-per-order events, `debug` for everything else. A shop
	 * turns the logger to info to answer "did the server send my order", and a
	 * page-view-frequency event at that level buries the answer.
	 *
	 * @param array $event_data
	 * @param int   $pixel_count Nothing was sent when this is zero, so there is
	 *                           nothing to confirm either.
	 * @return string 'info' or 'debug'
	 * @since 1.66.1
	 */
	private static function sent_event_log_level( $event_data, $pixel_count ) {

		$event_name = isset($event_data['event_name']) ? $event_data['event_name'] : '';

		if ((int) $pixel_count > 0 && in_array($event_name, self::LOGGED_EVENTS, true)) {
			return 'info';
		}

		return 'debug';
	}

	/**
	 * Send the purchase hit to Facebook CAPI
	 *
	 * Source: https://developers.facebook.com/docs/marketing-api/conversions-api/using-the-api#send
	 * Source: https://developers.facebook.com/docs/marketing-api/conversions-api/parameters
	 * Source: https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/server-event#event-name
	 *
	 * @param $order
	 **/
	/**
	 * Build the inner event data for a purchase event.
	 *
	 * Returns the event data object that the SSP's Facebook adapter
	 * expects via buildRawRequest(). Returns null if the order
	 * should not be processed.
	 *
	 * @param $order
	 * @return array|null
	 * @since 1.57.0
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_subscription_renewal_order($order)) {
			return null;
		}

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		Logger::debug('Facebook CAPI build_ssp_purchase_event_data order #' . $order->get_id() . ': fbp ' . ( isset($identifiers['fbp']) ? 'present (' . $identifiers['fbp'] . ')' : 'absent' ) . ', fbc ' . ( isset($identifiers['fbc']) ? 'present' : 'absent' ) . ', payment_method: ' . $order->get_payment_method() . ', user_agent: ' . ( isset($identifiers['user_agent']) ? $identifiers['user_agent'] : 'absent' ) . ', identifiers keys: ' . implode(', ', array_keys($identifiers)));

		$event_data = [
			'event_name'       => 'Purchase',
			'action_source'    => 'website',
			'event_id'         => 'pmw_' . $order->get_id(),
			'event_source_url' => $order->get_checkout_order_received_url(),
			'event_time' => !empty($identifiers['event_time']) ? $identifiers['event_time'] : time(),
			'opt_out'          => self::is_ads_delivery_opt_out_active(),
		];

		$event_data['user_data'] = self::get_user_data($identifiers, $order);

		$event_data['custom_data'] = [
			'content_type' => 'product',
			'value'        => Shop::get_order_value_total_marketing($order, true),
			'currency'     => (string) $order->get_currency(),
			'content_ids'  => Product::get_order_item_ids($order, 'facebook'),
			'order_id'     => (string) $order->get_order_number(),
		];

		$event_data['custom_data'] = array_merge($event_data['custom_data'], self::get_purchase_value_custom_data($order));

		$event_data = self::add_data_processing_options($event_data);

		if (isset($identifiers['referrer_url'])) {
			$event_data['referrer_url'] = Helpers::make_full_url($identifiers['referrer_url']);
		}

		return self::filter_purchase_payload('facebook', $event_data, $order);
	}

	/**
	 * The profit and predicted lifetime value fields of the Meta Purchase.
	 *
	 * Meta reports net_revenue as Profit and predicted_ltv as pLTV, and uses
	 * them for value optimization. Both are sent only when they are real:
	 * net_revenue needs the opt-in setting and a cost of goods for every line
	 * item, because a missing cost would overstate the margin, and
	 * predicted_ltv needs a shop's own model through a filter, because the LTV
	 * the Pixel Manager stores is historical, not predicted. A field that is
	 * not available is left out, never sent as 0.
	 *
	 * The browser Purchase gets the same fields through the data layer, so the
	 * deduplicated pair carries identical values whichever copy Meta keeps.
	 *
	 * @param \WC_Order $order
	 *
	 * @return array<string, float> Zero, one or both of net_revenue and predicted_ltv.
	 * @since 1.70.1
	 */
	public static function get_purchase_value_custom_data( $order ) {

		$custom_data = [];

		if (Options::is_profit_sent_separately() && Profit_Margin::order_has_complete_cogs($order)) {
			$custom_data['net_revenue'] = round((float) Profit_Margin::get_order_profit_margin($order), 2);
		}

		// The LTV lookup can run order queries, so it only runs when somebody
		// actually supplies a predicted LTV.
		if (has_filter('pmw_predicted_customer_ltv')) {

			/**
			 * Filters the predicted lifetime value of the customer who placed the order.
			 *
			 * Return a positive number to send it as predicted_ltv with the
			 * Meta Purchase. Anything else leaves the field out. The third
			 * argument is the customer's historical marketing LTV including
			 * this order, or null when order-level LTV is not available, as a
			 * starting point for the shop's own forecast.
			 *
			 * @since 1.70.1
			 */
			$predicted_ltv = apply_filters('pmw_predicted_customer_ltv', null, $order, self::get_historical_marketing_ltv($order));

			if (is_numeric($predicted_ltv) && (float) $predicted_ltv > 0) {
				$custom_data['predicted_ltv'] = round((float) $predicted_ltv, 2);
			}
		}

		return $custom_data;
	}

	/**
	 * The customer's historical marketing LTV through this order, or null if
	 * order-level LTV is not available for it.
	 *
	 * Calculated on demand when the order's values are not stored yet, the
	 * same way the purchase confirmation page does it, so an early server-side
	 * send does not see a 0.
	 *
	 * @param \WC_Order $order
	 *
	 * @return float|null
	 * @since 1.70.1
	 */
	private static function get_historical_marketing_ltv( $order ) {

		if (!Shop::can_ltv_be_processed_on_order($order)) {
			return null;
		}

		if (!LTV::are_all_pmw_order_values_set($order)) {
			LTV::calculate_pmw_order_values($order);
		}

		return (float) LTV::get_marketing_ltv_from_order($order);
	}

	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when any pixel's request never reached Meta. The retry
		// then goes to every pixel again, and Meta drops the copies that had
		// already arrived by event_id and event_name. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event_data = self::build_ssp_purchase_event_data($order);

			if (!$event_data) {
				return;
			}

			$response = self::post_event_to_capi_pixels($event_data);

			self::mark_purchase_hit_sent($order, $response);
		});
	}

	public static function send_event_hit( $event_data ) {

		self::get_instance();

		if (!Options::is_facebook_capi_active()) {
			return;
		}

		if (Shop::do_not_track_user(get_current_user_id())) {
			return;
		}

		$event_data['action_source'] = 'website';
		$event_data['event_time']    = time();
		$event_data['opt_out']       = self::is_ads_delivery_opt_out_active();

		// Only set client_ip_address if not already provided in the event data (e.g., from frontend)
		if (!isset($event_data['user_data']['client_ip_address']) || empty($event_data['user_data']['client_ip_address'])) {
			if (Geolocation::get_user_ip()) {
				$event_data['user_data']['client_ip_address'] = Geolocation::get_user_ip();
			}
		}

		// Same for the user agent. Meta treats an IP without a user agent as
		// unusable for matching and reports it in Events Manager, so the two
		// have to be filled in together. Events on this path are fired from the
		// visitor's browser, which makes the request's own user agent the
		// authoritative one.
		if (empty($event_data['user_data']['client_user_agent'])) {
			$user_agent = Helpers::get_request_user_agent();
			if ($user_agent) {
				$event_data['user_data']['client_user_agent'] = $user_agent;
			}
		}

		// data processing options
		$event_data = self::add_data_processing_options($event_data);

		self::post_event_to_capi_pixels($event_data);
	}

	// https://developers.facebook.com/docs/marketing-api/conversions-api/subscription-lifecycle-events/
	public static function send_subscription_hit( $life_cycle_event, $subscription, $parent_order, $renewal_order = null, $reactivation = false ) {

		self::get_instance();

		// Abort if the $parent_order is not an object
		if (!is_object($parent_order)) {
			Logger::debug('aborting Meta CAPI Subscribe hit because parent order is not an object');
			return;
		}

		if (Shop::do_not_track_user(Shop::get_order_user_id($parent_order))) {
			Logger::debug('send_subscription_hit | Do not track user for $life_cycle_event ' . $life_cycle_event . ' on subscription ' . $subscription->get_id() . ' and parent order ' . $parent_order->get_id());
			return;
		}

		$identifiers = self::get_identifiers_from_order($parent_order);

		// Add event data
		$event_data = [
			'event_name' => $life_cycle_event,
			//          'event_time' => $facebook_identifiers['event_time'], // try to match browser event_time
			'event_time' => time(), // FB can't process timestamps in the past
			//          'event_id'         => (string) $order->get_id(),
			'opt_out'    => self::is_ads_delivery_opt_out_active(),
			//          'action_source'    => 'website',
			//          'event_source_url' => $order->get_checkout_order_received_url(),
		];

		// Add user data
		$event_data['user_data'] = self::get_user_data($identifiers, $parent_order);

		// Add the subscription ID to the custom data
		$event_data['user_data']['subscription_id'] = $subscription->get_id();

		/**
		 * Get the order data and add it to the subscription hit if it is a new subscription,
		 * or if it is a subscription renewal.
		 *
		 * In all other cases omit adding the order data.
		 */

		$order = null;

		if ('Subscribe' === $life_cycle_event && false === $reactivation) {
			$order = $parent_order;
		} elseif ('RecurringSubscriptionPayment' === $life_cycle_event) {
			$order = $renewal_order;
		}

		// add order data
		if ($order) {
			$event_data['custom_data'] = [
				'value'    => Shop::get_order_value_total_marketing($order),
				'currency' => (string) $order->get_currency(),
				//          'content_ids'  => (array) Product::get_order_item_ids($order, 'facebook'),
				//          'content_type' => 'product'
			];
		}

		// data processing options
		$event_data = self::add_data_processing_options($event_data);

		self::post_event_to_capi_pixels($event_data);

		// Now we let the server know, that the hit has already been successfully sent.
//      update_post_meta($order->get_id(), self::get_purchase_hit_key(), true);
	}

	/**
	 * Process WooCommerce Subscription renewals
	 * https://docs.woocommerce.com/document/subscriptions/develop/action-reference/
	 * https://github.com/wp-premium/woocommerce-subscriptions/blob/master/includes/class-wc-subscription.php
	 * https://developers.facebook.com/docs/marketing-api/conversions-api/subscription-lifecycle-events/
	 * */
	private static function hook_into_subscriptions_events() {

		add_action('woocommerce_subscription_payment_complete', [ __CLASS__, 'facebook_capi_report_subscription_payment_complete' ], 10, 1);
		add_action('woocommerce_subscription_status_cancelled', [ __CLASS__, 'facebook_capi_report_subscription_cancellation' ], 10, 1);
		add_action('woocommerce_subscription_status_updated', [ __CLASS__, 'facebook_capi_report_subscription_update' ], 10, 3);

		if (self::track_facebook_capi_subscription_renewal()) {
			add_action('woocommerce_subscription_renewal_payment_complete', [ __CLASS__, 'facebook_capi_report_subscription_purchase_renewal' ], 10, 2);
		}
	}

	/**
	 * Subscription initial order
	 */
	public static function facebook_capi_report_subscription_payment_complete( $subscription ) {

		// Only process if this is the initial subscription payment
		if ($subscription->get_payment_count() !== 1) {
			Logger::debug('aborting Meta CAPI Subscribe hit because this is not the initial payment for subscription ' . $subscription->get_id());
			return;
		}

		self::send_subscription_hit('Subscribe', $subscription, $subscription->get_parent());
	}

	/**
	 * Subscription renewal
	 */
	public static function facebook_capi_report_subscription_purchase_renewal( $subscription, $renewal_order ) {

		$parent_order = $subscription->get_parent();

		// Abort if the order was created manually, and thus the parent order is missing.
		if (!$parent_order) {
			Logger::debug('aborting Meta CAPI RenewSubscription hit because parent order is missing for subscription ' . $subscription->get_id() . ' and renewal order ' . $renewal_order->get_id());
			return;
		}

		self::send_subscription_hit('RecurringSubscriptionPayment', $subscription, $parent_order, $renewal_order);
	}

	/**
	 * Subscription cancellation
	 */
	public static function facebook_capi_report_subscription_cancellation( $subscription ) {

		$parent_order = $subscription->get_parent();

		// Abort if the order was created manually, and thus no parent order exists.
		if (!$parent_order) {
			Logger::debug('aborting Meta CAPI CancelSubscription hit because parent order is missing for subscription ' . $subscription->get_id());
			return;
		}

		self::send_subscription_hit('CancelSubscription', $subscription, $parent_order);
	}

	/**
	 * Subscription update
	 *
	 * There is one use case that is not ideal: When the customer manually renews a subscription, it will be cancelled and reactivated.
	 */
	public static function facebook_capi_report_subscription_update( $subscription, $new_status, $old_status ) {

//      error_log('old status: ' . $old_status . ' new status: ' . $new_status);

		$parent_order = $subscription->get_parent();

		// Abort if the order was created manually, and thus no parent order exists.
		if (!$parent_order) {
			return;
		}

		/**
		 * Don't process on-hold status because it triggered by essentially every order simply when the payment is pending:
		 * https://woocommerce.com/document/managing-orders/#visual-diagram-to-illustrate-order-statuses
		 */

		// Putting a subscription on hold
//      if ('active' === $old_status && 'on-hold' === $new_status) {
//          self::send_subscription_hit('CancelSubscription', $subscription, $parent_order);
//      }
//
//      // Only run if we are reactivating a subscription which is on hold
//      if ('on-hold' === $old_status && 'active' === $new_status) {
//          self::send_subscription_hit('Subscribe', $subscription, $parent_order, null, true);
//      }
	}

	public static function track_facebook_capi_subscription_renewal() {

		// If Shop::track_subscription_renewal is false, return false.
		if (Shop::do_not_track_subscription_renewal()) {
			return false;
		}

		/**
		 * Filters Facebook subscription renewal tracking.
		 *
		 * @since 1.58.5
		 */
		return (bool) apply_filters('pmw_facebook_subscription_renewal_tracking', true);
	}

	public static function do_not_track_facebook_capi_subscription_renewal() {
		return !self::track_facebook_capi_subscription_renewal();
	}

	/**
	 * Filter to enable the Facebook CAPI ads delivery opt-out
	 *
	 * @return bool
	 */
	private static function is_ads_delivery_opt_out_active() {

		$opt_out = apply_filters_deprecated('wooptpm_facebook_capi_ads_delivery_opt_out', [ false ], '1.13.0', 'pmw_facebook_capi_ads_delivery_opt_out');
		$opt_out = apply_filters_deprecated('wpm_facebook_capi_ads_delivery_opt_out', [ $opt_out ], '1.31.2', 'pmw_facebook_capi_ads_delivery_opt_out');

		/**
		 * Filters Facebook capi ads delivery opt out.
		 *
		 * @since 1.31.2
		 */
		return (bool) apply_filters('pmw_facebook_capi_ads_delivery_opt_out', $opt_out);
	}

	/**
	 * If the order is a subscription renewal,
	 * only continue if renewal tracking is enabled.
	 *
	 * @param $order
	 * @return bool
	 */
	private static function can_process_subscription_renewal_order( $order ) {

		// If the order is not a subscription renewal, we can process it.
		if (!Shop::is_wcs_renewal_order($order)) {
			return true;
		}

		// If the order is a subscription renewal,
		// we can process it if the shop owner allows it.
		if (self::track_facebook_capi_subscription_renewal()) {
			return true;
		}

		// If the order is a subscription renewal,
		// and the shop owner doesn't allow it,
		// we can't process it.
		return false;
	}

	private static function can_not_process_subscription_renewal_order( $order ) {
		return !self::can_process_subscription_renewal_order($order);
	}

	// https://developers.facebook.com/docs/marketing-apis/data-processing-options
	// https://developers.facebook.com/docs/marketing-apis/data-processing-options#conversions-api-and-offline-conversions-api
	private static function add_data_processing_options( $capi_event_data ) {

		$processing_options = apply_filters_deprecated('wooptpm_facebook_capi_data_processing_options', [ [] ], '1.13.0', 'pmw_facebook_capi_data_processing_options');
		$processing_options = apply_filters_deprecated('wpm_facebook_capi_data_processing_options', [ $processing_options ], '1.31.2', 'pmw_facebook_capi_data_processing_options');

		// The filter result is cast to (array) so a third-party callback returning
		// a non-array cannot fatal array_merge(). @since 1.59.0
		/**
		 * Filters Facebook capi data processing options.
		 *
		 * @since 1.31.2
		 */
		return array_merge($capi_event_data, (array) apply_filters('pmw_facebook_capi_data_processing_options', $processing_options));
	}

	private static function get_user_data( $identifiers, $order ) {

		$user_data = [];

		// If fbp exists we set all real data
		// If fbp doesn't exist, we only set required fields with random data
		if (isset($identifiers['fbp'])) {
			$user_data['fbp'] = $identifiers['fbp'];
		}

		// Set fbc
		if (isset($identifiers['fbc'])) {
			$user_data['fbc'] = $identifiers['fbc'];
		}

		if (isset($identifiers['user_agent'])) {
			$user_data['client_user_agent'] = $identifiers['user_agent'];
		}

		// Set client_ip_address (always, regardless of advanced matching)
		// Required for baseline matching when fbp/fbc cookies are absent.
		// https://developers.facebook.com/docs/marketing-api/conversions-api/best-practices/#req-rec-params
		if (isset($identifiers['client_ip_address'])) {
			$user_data['client_ip_address'] = $identifiers['client_ip_address'];
		} elseif (isset($identifiers['ip_address'])) {
			$user_data['client_ip_address'] = $identifiers['ip_address'];
		}

		// https://developers.facebook.com/docs/marketing-api/conversions-api/parameters
		// https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/customer-information-parameters
		// https://developers.facebook.com/docs/marketing-api/audiences/guides/custom-audiences/#example_sha256
		if (Options::is_facebook_capi_advanced_matching_enabled()) {

			$user_details = Helpers::get_user_data($order);

			// https://developers.facebook.com/docs/meta-pixel/advanced/advanced-matching
			if (isset($user_details['id']['sha256'])) {
				$user_data['external_id'] = $user_details['id']['sha256'];
			}

			// The Facebook app-scoped user ID, read from whichever social login
			// plugin the shop runs. Not hashed, Meta expects it raw.
			//
			// The user ID is resolved from the order first and only falls back
			// to the current session, which is also what
			// Helpers::get_user_data() now returns in ['id']['raw']. It used to
			// fill that from get_current_user_id() even when the identity came
			// from the order, so it was 0 on every event emitted from a
			// background job rather than a page request.
			//
			// https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/customer-information-parameters
			if (Options::is_facebook_send_fb_login_id_enabled()) {

				$user_id = $order && $order->get_user_id() ? $order->get_user_id() : get_current_user_id();

				$facebook_login_id = Social_Login::get_facebook_login_id($user_id);

				if ($facebook_login_id) {
					$user_data['fb_login_id'] = $facebook_login_id;
				}
			}

			if (isset($user_details['email']['facebook'])) {
				$user_data['em'] = $user_details['email']['facebook'];
			}

			if (isset($user_details['phone']['facebook'])) {
				$user_data['ph'] = $user_details['phone']['facebook'];
			}

			if (isset($user_details['first_name']['facebook'])) {
				$user_data['fn'] = $user_details['first_name']['facebook'];
			}

			if (isset($user_details['last_name']['facebook'])) {
				$user_data['ln'] = $user_details['last_name']['facebook'];
			}

			if (isset($user_details['city']['facebook'])) {
				$user_data['ct'] = $user_details['city']['facebook'];
			}

			if (isset($user_details['state']['facebook'])) {
				$user_data['st'] = $user_details['state']['facebook'];
			}

			if (isset($user_details['postcode']['facebook'])) {
				$user_data['zp'] = $user_details['postcode']['facebook'];
			}

			if (isset($user_details['country']['facebook'])) {
				$user_data['country'] = $user_details['country']['facebook'];
			}
		}

		return $user_data;
	}

	/**
	 * Click IDs this destination recovers from the universal per-order
	 * snapshot when its own identifiers carry none (historical orders,
	 * a destination activated later, a backfill).
	 *
	 * @return array<string, string>
	 * @since 1.66.0
	 */
	protected static function get_click_id_snapshot_map() {
		return [ 'fbclid' => 'fbc' ];
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		if (isset($_cookie['_fbp']) && self::is_valid_fbp($_cookie['_fbp'])) {
			$identifiers['fbp'] = $_cookie['_fbp'];
		}

		if (isset($_cookie['_fbc']) && self::is_valid_fbc($_cookie['_fbc'])) {
			$identifiers['fbc'] = $_cookie['_fbc'];
		}

		$cookie_count = 0;
		if (is_array($_cookie)) {
			$cookie_count = count($_cookie);
		}

		Logger::debug('Facebook CAPI add_pixel_specific_identifiers: _fbp cookie ' . ( isset($_cookie['_fbp']) ? 'present' : 'absent' ) . ', _fbc cookie ' . ( isset($_cookie['_fbc']) ? 'present' : 'absent' ) . ', cookie count: ' . $cookie_count . ', is_iframe: ' . ( Helpers::is_iframe() ? 'yes' : 'no' ));

		if (isset($identifiers['ip_address'])) {
			$identifiers['client_ip_address'] = $identifiers['ip_address'];
		}

		if (isset($identifiers['user_agent'])) {
			$identifiers['client_user_agent'] = $identifiers['user_agent'];
		}

		/**
		 * Enrich the data with transient session data
		 */

		$transient_identifiers = Shop::get_transient_identifiers_from_session();

		if (isset($transient_identifiers['referrer'])) {
			$identifiers['referrer_url'] = $transient_identifiers['referrer'];
		}

		// If the _fbc cookie is not set,
		// but the fbclid transient is set,
		// we set the fbc to the fbclid.
		if (!isset($_cookie['_fbc']) && isset($transient_identifiers['fbclid'])) {
			$identifiers['fbc'] = $transient_identifiers['fbclid'];
		}

		return $identifiers;
	}

	public static function set_additional_identifiers_on_order( $identifiers ) {
		$identifiers['event_time'] = time();
		return $identifiers;
	}

	// https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/fbp-and-fbc/
	public static function is_valid_fbp( $fbp ) {
		return (bool) preg_match('/^fb\.[0-2]\.\d{13}\.\d{8,20}$/', $fbp);
	}

	// https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/fbp-and-fbc/
	public static function is_valid_fbc( $fbc ) {
		return (bool) preg_match('/^fb\.[0-2]\.\d{13}\.[\da-zA-Z_-]{8,}/', $fbc);
	}
}
