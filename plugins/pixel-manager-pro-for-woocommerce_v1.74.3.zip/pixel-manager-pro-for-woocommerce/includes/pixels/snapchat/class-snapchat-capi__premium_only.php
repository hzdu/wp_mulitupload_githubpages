<?php

/**
 * Snapchat Conversions API
 * https://businesshelp.snapchat.com/s/article/conversions-api
 * https://docs.snap.com/api/marketing-api/Conversions-API/UsingTheAPI
 */

namespace SweetCode\Pixel_Manager\Pixels\Snapchat;

use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class Snapchat_CAPI
 * https://snap.com/en-US/privacy/cookie-information
 */
class Snapchat_CAPI extends S2S {

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		self::$http = $http;

		self::hook_into_generic_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_snapchat_capi_active();
	}

	public static function is_handled_by_ssp() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'snapchat_user_identifiers_' . Options::get_snapchat_pixel_id();
	}

	public static function get_purchase_hit_key() {
		return 'pmw_snapchat_capi_purchase_hit';
	}

	private static function get_api_version() {
		return 'v3';
	}

	// https://docs.snap.com/api/marketing-api/Conversions-API/UsingTheAPI
	private static function get_request_url( $debug = false ) {

		$url  = 'https://';
		$url .= 'tr.snapchat.com/';
		$url .= self::get_api_version() . '/';
		$url .= Options::get_snapchat_pixel_id();
		$url .= '/events';

		if ($debug) {
			$url .= '/validate';
		}

		$url .= '?access_token=' . Options::get_snapchat_capi_token();

		return $url;
	}

	/**
	 * Add identifiers specific to Snapchat CAPI
	 *
	 * @param $identifiers
	 * @return mixed
	 */
	/**
	 * Click IDs this destination recovers from the universal per-order
	 * snapshot when its own identifiers carry none (historical orders,
	 * a destination activated later, a backfill).
	 *
	 * @return array<string, string>
	 * @since 1.66.0
	 */
	protected static function get_click_id_snapshot_map() {
		return [ 'scid' => 'sc_click_id' ];
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		/**
		 * Snap asks for both identifiers whenever both are available:
		 * sc_cookie1 is the Snap pixel's first-party user cookie (_scid, a
		 * UUID), and sc_click_id is the ScCid landing parameter. They are two
		 * different identifiers of two different things.
		 *
		 * _scid_r is the companion cookie newer scevent.min.js builds write
		 * alongside _scid; it is only consulted when _scid itself is missing.
		 */
		$sc_cookie1 = self::normalize_scid_cookie_value(
			isset($_cookie['_scid']) ? $_cookie['_scid'] : ( isset($_cookie['_scid_r']) ? $_cookie['_scid_r'] : '' )
		);

		if ('' !== $sc_cookie1) {
			$identifiers['sc_cookie1'] = $sc_cookie1;
		}

		/**
		 * Enrich the data with transient session data
		 */

		$transient_identifiers = Shop::get_transient_identifiers_from_session();

		if (isset($transient_identifiers['scid'])) {
			$identifiers['sc_click_id'] = $transient_identifiers['scid'];
		}

		return $identifiers;
	}

	/**
	 * Build the inner event data for a purchase event.
	 *
	 * Returns the event data object that the SSP's Snapchat adapter
	 * expects via buildRawRequest(). Returns null if the order
	 * should not be processed.
	 *
	 * @param $order
	 * @return array|null
	 * @since 1.57.0
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		return self::filter_purchase_payload('snapchat', [
			'event_name'       => 'PURCHASE',
			'event_time'       => strtotime($order->get_date_created()),
			'event_source_url' => (string) $order->get_checkout_order_received_url(),
			'event_id'         => 'pmw_' . $order->get_id(),
			'action_source'    => 'WEB',
			'integration'      => 'pmw',
			'user_data'        => self::get_user_data($order, $identifiers),
			'custom_data'      => [
				'content_category' => self::get_content_category($order),
				'content_ids'      => self::get_content_ids($order),
				'content_name'     => $order->get_checkout_order_received_url(),
				'content_type'     => 'product',
				'contents'         => self::get_contents($order),
				'currency'         => $order->get_currency(),
				'num_items'        => $order->get_item_count(),
				'order_id'         => $order->get_id(),
				'value'            => Shop::get_order_value_total_marketing($order, true),
				'brands'           => self::get_brands($order),
			],
		], $order);
	}

	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached Snapchat. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event_data = self::build_ssp_purchase_event_data($order);

			if (!$event_data) {
				return;
			}

			$payload = [
				'data' => [ $event_data ],
			];

			$response = self::$http->post(self::get_request_url(), $payload);

			if (Options::is_http_request_logging_enabled()) {
				Logger::debug('Sending Snapchat purchase hit through the debug endpoint.');
				self::$http->post(self::get_request_url(true), $payload);
			}

			// Only the production request decides the marker; the debug copy counts nothing.
			self::mark_purchase_hit_sent($order, $response);
		});
	}

	public static function send_event_hit( $event_data ) {

		self::get_instance();

		if (!Options::is_snapchat_capi_active()) {
			return;
		}

		if (Shop::do_not_track_user(get_current_user_id())) {
			return;
		}

		$user_ip = Geolocation::get_user_ip();

		if ($user_ip) {
			$event_data['user_data']['client_ip_address'] = $user_ip;
		}

		// Snapchat pairs the IP with the user agent for match-key fallback, so
		// the user agent has to be filled in alongside the IP. Events on this
		// path are fired from the visitor's browser, which makes the request's
		// own user agent the authoritative one.
		if (empty($event_data['user_data']['client_user_agent'])) {
			$user_agent = Helpers::get_request_user_agent();
			if ($user_agent) {
				$event_data['user_data']['client_user_agent'] = $user_agent;
			}
		}

		$payload = [
			'data' => [ $event_data ],
		];

		self::$http->post(self::get_request_url(), $payload);

		if (Options::is_http_request_logging_enabled()) {
			Logger::debug('Sending Snapchat purchase hit through the debug endpoint.');
			self::$http->post(self::get_request_url(true), $payload);
		}
	}

	/**
	 * Returns a unique array of all the category names of the products in the order
	 */
	private static function get_content_category( $order ) {
		$category_names = [];

		foreach (Product::pmw_get_order_items($order) as $item) {
			$product = $item->get_product();

			if ($product) {

				$category_ids = $product->get_category_ids();

				foreach ($category_ids as $category_id) {

					$term = get_term($category_id);

					if (is_wp_error($term)) {
						Logger::error('Snapchat CAPI: get_content_category: ' . $term->get_error_message());
						continue;
					}

					$category_names[] = $term->name;
				}
			}
		}

		// Re-index after array_unique so JSON encodes as a sequential array.
		// array_unique preserves keys, which can yield sparse indices that PHP
		// serializes as a JSON object, breaking Snapchat's strict request parser.
		return array_values(array_unique($category_names));
	}

	/**
	 * Returns an array of all the product IDs in the order
	 *
	 * @param $order
	 * @return array|void[]
	 */
	private static function get_content_ids( $order ) {
		$product_ids = array_map(function ( $item ) {
			$product = $item->get_product();
			if ($product) {
				return Product::get_dyn_r_id_for_product_by_pixel_name($product, 'snapchat');
			}
		}, Product::pmw_get_order_items($order));

		// Re-index the array
		return array_values(array_filter($product_ids));
	}

	/**
	 * This returns an array of arrays. Each array contains the following fields: id quantity item_price
	 *
	 * @param $order
	 * @return array|array[]|void[]
	 */
	private static function get_contents( $order ) {
		$product_details = array_map(function ( $item ) use ( $order ) {
			$product = $item->get_product();
			if ($product) {
				// Bundles/composites: report the assembled line total, not the 0/base container line.
				$container_line = Product::maybe_get_container_order_item_line_amount($item, false, $order);
				$item_price     = null !== $container_line ? $container_line : $item->get_total();
				return [
					'id'         => Product::get_dyn_r_id_for_product_by_pixel_name($product, 'snapchat'),
					'quantity'   => $item->get_quantity(),
					'item_price' => Helpers::format_decimal($item_price, 2),
				];
			}
		}, Product::pmw_get_order_items($order));

		// Re-index the array
		return array_values(array_filter($product_details));
	}

	/**
	 * Returns a unique array of all the brand names in the order
	 *
	 * @param $order
	 * @return array|void[]
	 */
	private static function get_brands( $order ) {
		$brands = [];

		foreach (Product::pmw_get_order_items($order) as $item) {
			$product = $item->get_product();

			if ($product) {
				$brands[] = Product::get_brand_name($product->get_id());
			}
		}

		// Re-index after array_unique so JSON encodes as a sequential array.
		return array_values(array_unique($brands));
	}

	// https://docs.snap.com/api/marketing-api/Conversions-API/UsingTheAPI
	private static function get_user_data( $order, $identifiers ) {

		$user_data = [];

		if (isset($identifiers['ip_address'])) {
			$user_data['client_ip_address'] = $identifiers['ip_address'];
		}

		if (isset($identifiers['user_agent'])) {
			$user_data['client_user_agent'] = $identifiers['user_agent'];
		}

		// The ScCid landing parameter
		if (isset($identifiers['sc_click_id']) && self::is_valid_sc_click_id($identifiers['sc_click_id'])) {
			$user_data['sc_click_id'] = $identifiers['sc_click_id'];
		}

		// The Snap pixel's first-party _scid cookie (formerly sent as uuid_c1)
		if (isset($identifiers['sc_cookie1']) && self::is_valid_sc_cookie1($identifiers['sc_cookie1'])) {
			$user_data['sc_cookie1'] = $identifiers['sc_cookie1'];
		}

		// If advanced matching is enabled, add the email address to the user_data
		if (Options::is_snapchat_advanced_matching_enabled()) {

			$order_user_data = Helpers::get_user_data($order);

			if (!empty($order_user_data['email'])) {
				$user_data['em'] = $order_user_data['email']['sha256'];
			}

			if (!empty($order_user_data['phone'])) {
				$user_data['ph'] = $order_user_data['phone']['snapchat'];
			}

			if (!empty($order_user_data['first_name'])) {
				$user_data['fn'] = $order_user_data['first_name']['snapchat'];
			}

			if (!empty($order_user_data['last_name'])) {
				$user_data['ln'] = $order_user_data['last_name']['snapchat'];
			}

			if (!empty($order_user_data['city'])) {
				$user_data['ct'] = $order_user_data['city']['snapchat'];
			}

			if (!empty($order_user_data['state'])) {
				$user_data['st'] = $order_user_data['state']['snapchat'];
			}

			if (!empty($order_user_data['postcode'])) {
				$user_data['zp'] = $order_user_data['postcode']['sha256'];
			}

			if (!empty($order_user_data['country'])) {
				$user_data['country'] = $order_user_data['country']['snapchat'];
			}

			if (!empty($order_user_data['id'])) {
				$user_data['external_id'] = $order_user_data['id']['sha256'];
			}
		}

		return $user_data;
	}

	/**
	 * Whether a value is a plausible ScCid click ID.
	 *
	 * Snap publishes no format spec for ScCid, and real values are
	 * base64url-ish with mixed case (example: CjkKCQjwmZejBhIQARJA). Up to
	 * 1.65.1 this was checked against the lowercase-hex UUID shape of the
	 * _scid cookie, which threw every genuine click ID away.
	 *
	 * @param string $sc_click_id
	 * @return bool
	 */
	public static function is_valid_sc_click_id( $sc_click_id ) {
		return (bool) preg_match('/^[A-Za-z0-9._~=-]{5,500}$/', $sc_click_id);
	}

	/**
	 * Whether a value is a plausible _scid cookie value.
	 *
	 * Example: 51c50086-bdee-47aa-8d5a-dfd1d0487305
	 *
	 * @param string $sc_cookie1
	 * @return bool
	 */
	public static function is_valid_sc_cookie1( $sc_cookie1 ) {
		return (bool) preg_match('/^[0-9a-f-]{20,60}$/', $sc_cookie1);
	}

	/**
	 * Normalizes a raw _scid / _scid_r cookie value into the bare UUID Snap
	 * expects in sc_cookie1.
	 *
	 * Newer Snap pixel builds prefix the value with a single-letter version
	 * marker (for example "a.51c50086-..."), which would not match the UUID
	 * Snap stored for that browser.
	 *
	 * @param mixed $raw
	 * @return string The bare UUID, or an empty string when nothing usable is left.
	 */
	private static function normalize_scid_cookie_value( $raw ) {

		if (!is_string($raw) || '' === $raw) {
			return '';
		}

		$value = Helpers::generic_sanitization($raw);

		if (preg_match('/^[A-Za-z]\.(.+)$/', $value, $matches)) {
			$value = $matches[1];
		}

		return self::is_valid_sc_cookie1($value) ? $value : '';
	}
}
