<?php

/**
 * Nextdoor Conversion API
 * https://developer.nextdoor.com/reference/conversion-api
 * https://developer.nextdoor.com/reference/conversions-track
 * https://developer.nextdoor.com/reference/conversion-user-matching
 *
 * @since 1.63.1
 */

namespace SweetCode\Pixel_Manager\Pixels\Nextdoor;

use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Logger;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\Product;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Class Nextdoor_CAPI
 */
class Nextdoor_CAPI extends S2S {

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		$request_args = [
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . Options::get_nextdoor_capi_token(),
			],
		];

		$http->set_request_args($request_args);

		self::$http = $http;

		self::hook_into_generic_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_nextdoor_capi_active();
	}

	/**
	 * Nextdoor purchase events are routed through the SSP Purchase Proxy when
	 * the SSP is active. Non-SSP installs continue to send directly via
	 * send_purchase_hit().
	 *
	 * @return bool
	 * @since 1.63.1
	 */
	public static function is_handled_by_ssp() {
		return true;
	}

	protected static function get_identifiers_key() {
		return 'nextdoor_user_identifiers_' . Options::get_nextdoor_pixel_id();
	}

	public static function get_purchase_hit_key() {
		return 'pmw_nextdoor_capi_purchase_hit';
	}

	/**
	 * Nextdoor Conversion API endpoint.
	 * https://developer.nextdoor.com/reference/conversions-track
	 *
	 * @return string
	 */
	private static function get_request_url() {
		return 'https://ads.nextdoor.com/v2/api/conversions/track';
	}

	/**
	 * Add the Nextdoor click ID (ndclid) to the identifiers.
	 *
	 * When a visitor clicks a Nextdoor ad, an ndclid parameter is appended to
	 * the landing page URL. Two sources, in priority order:
	 *
	 * 1. The ndclid first-party cookie the Nextdoor Universal Pixel (ndp.js)
	 *    writes on the landing page.
	 * 2. Fallback: PMW's own capture of the ndclid URL parameter
	 *    (event_listeners.js), sent to the WooCommerce session via the
	 *    transient identifiers AJAX round-trip on cart/checkout pages. Kept
	 *    because the pixel cookie is absent when the pixel never ran on the
	 *    landing page (e.g. consent granted later).
	 *
	 * @param array $identifiers
	 * @return array
	 * @since 1.63.1
	 */
	/**
	 * Click IDs this destination recovers from the universal per-order
	 * snapshot when its own identifiers carry none (historical orders,
	 * a destination activated later, a backfill).
	 *
	 * @return array<string, string>
	 * @since 1.66.0
	 */
	protected static function get_click_id_snapshot_map() {
		return [ 'ndclid' => 'ndclid' ];
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		if (isset($_cookie['ndclid']) && self::is_valid_ndclid($_cookie['ndclid'])) {
			$identifiers['ndclid'] = sanitize_text_field(wp_unslash($_cookie['ndclid']));
		}

		if (!isset($identifiers['ndclid'])) {

			$transient_identifiers = Shop::get_transient_identifiers_from_session();

			if (isset($transient_identifiers['ndclid']) && self::is_valid_ndclid($transient_identifiers['ndclid'])) {
				$identifiers['ndclid'] = $transient_identifiers['ndclid'];
			}
		}

		return $identifiers;
	}

	/**
	 * Check if a Nextdoor click ID (ndclid) is plausible.
	 *
	 * The token is opaque, so this is deliberately permissive:
	 * URL-safe characters, sane length.
	 *
	 * @param mixed $ndclid
	 * @return bool
	 * @since 1.63.1
	 */
	public static function is_valid_ndclid( $ndclid ) {

		if (!is_string($ndclid)) {
			return false;
		}

		return (bool) preg_match('/^[A-Za-z0-9._~=-]{5,500}$/', $ndclid);
	}

	/**
	 * Build the purchase event for an order.
	 *
	 * Shared by the direct send (send_purchase_hit) and the SSP Purchase Proxy,
	 * which bundles this per-destination payload and forwards it to the SSP
	 * worker's Nextdoor adapter (buildRawRequest). Returns null if the order
	 * should not be processed.
	 *
	 * The event_id mirrors the browser pixel's purchase event ID
	 * ("pmw_" + order ID), so Nextdoor deduplicates the browser pixel and the
	 * Conversion API purchase against each other via event_id + data_source_id.
	 *
	 * @param \WC_Order $order
	 * @return array|null
	 * @since 1.63.1
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		$event = [
			'event_name'            => 'purchase',
			'event_id'              => 'pmw_' . $order->get_id(),
			'event_time_epoch'      => time(),
			'action_source'         => 'website',
			'action_source_url'     => home_url(),
			'data_source_id'        => Options::get_nextdoor_pixel_id(),
			'delivery_optimization' => true,
			'customer'              => self::get_customer_data($order, $identifiers),
			'custom'                => [
				'order_id'        => (string) $order->get_id(),
				'order_value'     => (string) Shop::get_order_value_total_marketing($order, true),
				'currency'        => $order->get_currency(),
				'product_context' => self::get_product_context($order),
			],
		];

		if (Options::is_nextdoor_capi_test_event_code_set()) {
			$event['test_event'] = Options::get_nextdoor_capi_test_event_code();
		}

		return self::filter_purchase_payload('nextdoor', $event, $order);
	}

	/**
	 * Send the purchase event directly to the Nextdoor Conversion API.
	 *
	 * Used when the SSP is not active (when it is, the SSP Purchase Proxy
	 * handles the event via build_ssp_purchase_event_data() and the base class
	 * skips this direct send).
	 *
	 * @param \WC_Order $order
	 * @return void
	 */
	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached Nextdoor. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event = self::build_ssp_purchase_event_data($order);

			if (!$event) {
				return;
			}

			$response = self::$http->post(self::get_request_url(), $event);

			if (self::mark_purchase_hit_sent($order, $response)) {
				Logger::debug('Nextdoor CAPI purchase hit sent for order ' . $order->get_id());
			}
		});
	}

	/**
	 * Send an S2S event originating from the browser (page_view, view_content,
	 * add_to_cart, initiate_checkout, search). The browser adapter (adapter.js)
	 * supplies the event_id, the pixel event name, the custom data, the source
	 * URL and any advanced-matching user data; the server enriches it with the
	 * client IP, the user agent and the ndclid click ID.
	 *
	 * @param array $event_data Event data from the browser adapter.
	 * @return void
	 */
	public static function send_event_hit( $event_data ) {

		self::get_instance();

		if (!Options::is_nextdoor_capi_active()) {
			return;
		}

		if (Shop::do_not_track_user(get_current_user_id())) {
			return;
		}

		$customer = isset($event_data['customer']) && is_array($event_data['customer']) ? $event_data['customer'] : [];

		// Add the client IP address
		if (Geolocation::get_user_ip()) {
			$customer['client_ip_address'] = Geolocation::get_user_ip();
		}

		// Add the user agent
		$user_agent = Helpers::get_request_user_agent();
		if ($user_agent) {
			$customer['client_user_agent'] = $user_agent;
		}

		// Add the ndclid click ID from the cookie if the browser didn't supply one.
		// This request originates from the visitor's browser, so the cookie is available.
		if (empty($customer['click_id'])) {
			$_cookie = Helpers::get_input_vars(INPUT_COOKIE);
			if (isset($_cookie['ndclid']) && self::is_valid_ndclid($_cookie['ndclid'])) {
				$customer['click_id'] = sanitize_text_field(wp_unslash($_cookie['ndclid']));
			}
		}

		$event = [
			// The browser adapter sends the pixel event name (e.g. ADD_TO_CART);
			// the Conversion API expects the lowercase form (add_to_cart).
			'event_name'            => strtolower(isset($event_data['event_name']) ? $event_data['event_name'] : ''),
			'event_id'              => isset($event_data['event_id']) ? $event_data['event_id'] : '',
			// Always stamp with server time. The event is being sent in near
			// real time, so server time is accurate and skew-proof. This
			// mirrors the SSP worker, which overwrites the timestamp with
			// server time.
			'event_time_epoch'      => time(),
			'action_source'         => 'website',
			'action_source_url'     => isset($event_data['source_url']) ? esc_url_raw($event_data['source_url']) : home_url(),
			'data_source_id'        => Options::get_nextdoor_pixel_id(),
			'delivery_optimization' => true,
			'customer'              => $customer,
			'custom'                => isset($event_data['custom_data']) && is_array($event_data['custom_data']) ? $event_data['custom_data'] : [],
		];

		if (Options::is_nextdoor_capi_test_event_code_set()) {
			$event['test_event'] = Options::get_nextdoor_capi_test_event_code();
		}

		// event_name and event_id are required by the Nextdoor API.
		// Skip rather than send an event the API rejects.
		if (empty($event['event_name']) || empty($event['event_id'])) {
			return;
		}

		self::$http->post(self::get_request_url(), $event);
	}

	/**
	 * Get the customer object for an order.
	 * https://developer.nextdoor.com/reference/conversion-user-matching
	 *
	 * PII is sent as SHA-256 hashes of normalized (lowercase, no-space) values,
	 * and only when advanced matching is enabled. The click ID, IP address and
	 * user agent are sent as raw values, as the API expects.
	 *
	 * @param \WC_Order $order
	 * @param array     $identifiers
	 * @return array
	 */
	private static function get_customer_data( $order, $identifiers ) {

		$customer = [];

		// Add IP address
		if (isset($identifiers['ip_address'])) {
			$customer['client_ip_address'] = $identifiers['ip_address'];
		}

		// Add user agent
		if (isset($identifiers['user_agent'])) {
			$customer['client_user_agent'] = $identifiers['user_agent'];
		}

		// Add the Nextdoor click ID
		if (isset($identifiers['ndclid'])) {
			$customer['click_id'] = $identifiers['ndclid'];
		}

		// Add advanced matching data if enabled
		if (Options::is_nextdoor_advanced_matching_enabled()) {

			$user_data = Helpers::get_user_data($order);

			// Email (SHA-256 of the lowercase address)
			if (!empty($user_data['email']['sha256'])) {
				$customer['email'] = $user_data['email']['sha256'];
			}

			// Phone (SHA-256 of the E.164 formatted number)
			if (!empty($user_data['phone']['sha256']['e164'])) {
				$customer['phone_number'] = $user_data['phone']['sha256']['e164'];
			}

			// First and last name (SHA-256 of the lowercase, no-space value)
			if (!empty($user_data['first_name']['raw'])) {
				$customer['first_name'] = Helpers::hash_string(strtolower(preg_replace('/\s+/', '', $user_data['first_name']['raw'])));
			}

			if (!empty($user_data['last_name']['raw'])) {
				$customer['last_name'] = Helpers::hash_string(strtolower(preg_replace('/\s+/', '', $user_data['last_name']['raw'])));
			}

			// City (SHA-256 of the lowercase value)
			if (!empty($user_data['city']['raw'])) {
				$customer['city'] = Helpers::hash_string(strtolower(trim($user_data['city']['raw'])));
			}

			// State, postal code and country are sent as raw values
			if (!empty($user_data['state']['raw'])) {
				$customer['state'] = strtolower($user_data['state']['raw']);
			}

			if (!empty($user_data['postcode']['raw'])) {
				$customer['zip_code'] = $user_data['postcode']['raw'];
			}

			if (!empty($user_data['country']['raw'])) {
				$customer['country'] = strtolower($user_data['country']['raw']);
			}

			// External ID (SHA-256 hashed user ID)
			if (!empty($user_data['id']['sha256'])) {
				$customer['external_id'] = $user_data['id']['sha256'];
			}
		}

		return $customer;
	}

	/**
	 * Get the product context array for an order.
	 *
	 * @param \WC_Order $order
	 * @return array
	 */
	private static function get_product_context( $order ) {

		$product_context = [];

		foreach (Product::pmw_get_order_items($order) as $order_item) {

			$product_id = Product::get_variation_or_product_id($order_item->get_data(), Options::is_dynamic_remarketing_variations_output_enabled());
			$product    = wc_get_product($product_id);

			// Only add if WC retrieves a valid product
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			$quantity = (int) max(1, (int) round((float) $order_item->get_quantity()));

			$product_context[] = [
				'id'         => (string) Product::get_dyn_r_id_for_product_by_pixel_name($product, 'nextdoor'),
				'quantity'   => $quantity,
				'item_price' => round(( (float) $order_item->get_total() + (float) $order_item->get_total_tax() ) / $quantity, 2),
			];
		}

		return $product_context;
	}
}
