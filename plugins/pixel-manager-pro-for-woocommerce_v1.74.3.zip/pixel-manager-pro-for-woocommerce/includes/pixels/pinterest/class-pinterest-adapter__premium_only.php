<?php

namespace SweetCode\Pixel_Manager\Pixels\Pinterest;

use SweetCode\Pixel_Manager\Pixels\Core\Abstract_Pixel_Adapter;
use SweetCode\Pixel_Manager\Pixels\Core\Pixel_Registry;

defined('ABSPATH') || exit; // Exit if accessed directly

/**
 * Pinterest API for Conversions adapter for server-side event processing
 *
 * Handles filtering and sending events to Pinterest API for Conversions. The
 * pixel's descriptor lives in the free Pinterest_Descriptor, so the registry
 * knows the browser pixel on every tier; this adapter only exists on Pro builds.
 *
 * @package SweetCode\Pixel_Manager\Pixels\Adapters\Pinterest
 * @since 1.51.0
 */
class Pinterest_Adapter extends Abstract_Pixel_Adapter {

	/**
	 * Constructor - auto-registers this adapter
	 */
	public function __construct() {
		Pixel_Registry::register( $this );
	}

	/**
	 * Get the pixel name
	 *
	 * @return string
	 */
	public function get_pixel_name() {
		return 'pinterest';
	}

	/**
	 * Check if Pinterest APIC is available
	 *
	 * @return bool
	 */
	public function is_available() {
		return \SweetCode\Pixel_Manager\Options::is_pinterest_apic_active();
	}

	/**
	 * Send event data to Pinterest API for Conversions
	 *
	 * @param array $pixel_data Filtered event data ready to send
	 * @return void
	 */
	protected function send( $pixel_data ) {
		Pinterest_APIC::send_s2s_event( $pixel_data );
	}
}

// Auto-register the adapter
new Pinterest_Adapter();
