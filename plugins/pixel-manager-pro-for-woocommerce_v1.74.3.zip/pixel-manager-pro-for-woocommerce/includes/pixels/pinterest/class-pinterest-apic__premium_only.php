<?php

/**
 * Pinterest API for Conversions
 *
 * Sources:
 * https://developers.pinterest.com/docs/conversions/updated/
 * https://help.pinterest.com/en/business/article/the-pinterest-api-for-conversions
 * https://developers.pinterest.com/docs/api/v5/#operation/events/create
 */

namespace SweetCode\Pixel_Manager\Pixels\Pinterest;

use SweetCode\Pixel_Manager\Geolocation;
use SweetCode\Pixel_Manager\Helpers;
use SweetCode\Pixel_Manager\HTTP;
use SweetCode\Pixel_Manager\Options;
use SweetCode\Pixel_Manager\S2S;
use SweetCode\Pixel_Manager\Shop;
use SweetCode\Pixel_Manager\Product;

defined('ABSPATH') || exit; // Exit if accessed directly

class Pinterest_APIC extends S2S {

	private static $http;

	private static $instance;

	public static function get_instance() {
		if (is_null(self::$instance)) {
			$http           = new HTTP();      // Create a new HTTP object
			self::$instance = new self($http); // Pass the HTTP object to the constructor
		}
		return self::$instance;
	}

	public function __construct( HTTP $http ) {

		$request_args = [
			// Add an authorization bearer token to the header
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . Options::get_pinterest_apic_token(),
			],
		];

		$http->set_request_args($request_args);

		self::$http = $http;

		self::hook_into_generic_events();
	}

	/**
	 * Getters for constants
	 */

	public static function is_pixel_s2s_active() {
		return Options::is_pinterest_apic_active();
	}

	public static function is_handled_by_ssp() {
		return true;
	}

	/**
	 * Get the key for the identifiers
	 *
	 * @return string
	 */
	protected static function get_identifiers_key() {
		return 'pinterest_user_identifiers_' . Options::get_pinterest_ad_account_id();
	}

	/**
	 * Get the key for the purchase hit
	 *
	 * @return string
	 */
	public static function get_purchase_hit_key() {
		return 'pmw_pinterest_apic_purchase_hit';
	}

	/**
	 * Get the API version
	 *
	 * @return string
	 */
	private static function get_api_version() {
		return 'v5';
	}

	/**
	 * Get the request URL
	 *
	 * Source: https://developers.pinterest.com/docs/api/v5/#operation/events/create
	 *
	 * @param bool $debug
	 * @return string
	 */
	private static function get_request_url( $debug = false ) {

		$request_url  = 'https://';
		$request_url .= 'api.pinterest.com/';
		$request_url .= self::get_api_version() . '/';
		$request_url .= 'ad_accounts/';
		$request_url .= Options::get_pinterest_ad_account_id() . '/';
		$request_url .= 'events';

		if ($debug) {
			$request_url .= '?test=true'; // Add this query parameter to test the request
		}

		return $request_url;
	}

	/**
	 * Handle Pinterest purchase hit
	 *
	 * TODO: Use the payload helper to add more data https://developers.pinterest.com/payload-helper/
	 *
	 * @param $order
	 * @return void
	 **/
	/**
	 * Build the inner event data for a purchase event.
	 *
	 * Returns the event data object that the SSP's Pinterest adapter
	 * expects via buildRawRequest(). Returns null if the order
	 * should not be processed.
	 *
	 * @param $order
	 * @return array|null
	 * @since 1.57.0
	 */
	public static function build_ssp_purchase_event_data( $order ) {

		self::get_instance();

		if (self::can_not_process_order($order)) {
			return null;
		}

		$identifiers = self::get_identifiers_from_order($order);

		$event_data = [
			'event_name'       => 'checkout',
			'action_source'    => 'web',
			'event_time'       => time(),
			'event_id'         => 'pmw_' . $order->get_id(),
			'event_source_url' => (string) $order->get_checkout_order_received_url(),
			'opt_out'          => false,
		];

		$event_data['user_data'] = self::get_user_data_for_order($identifiers, $order);

		$event_data['custom_data'] = [
			'currency'    => (string) $order->get_currency(),
			'value'       => (string) Shop::get_order_value_total_marketing($order, true),
			'num_items'   => (int) Product::get_order_item_count($order),
			'order_id'    => (string) $order->get_id(),
			'content_ids' => self::get_product_ids($order),
			'contents'    => self::get_order_contents_with_quantity_and_item_price($order),
		];

		return self::filter_purchase_payload('pinterest', $event_data, $order);
	}

	public static function send_purchase_hit( $order ) {

		// Serialised per order so two overlapping paid triggers cannot both send it,
		// and left unmarked when the request never reached Pinterest. @since 1.69.3
		self::with_purchase_hit_lock($order, function ( $order ) {

			$event_data = self::build_ssp_purchase_event_data($order);

			if (!$event_data) {
				return;
			}

			$payload = [
				'data' => [ $event_data ],
			];

			$response = self::$http->post(self::get_request_url(), $payload);

			self::mark_purchase_hit_sent($order, $response);
		});
	}

	private static function is_one_pinterest_cookie_set( $identifiers ) {
		return (
			isset($identifiers['epik'])
			|| isset($identifiers['derived_epik'])
			|| isset($identifiers['pin_unauth'])
			|| isset($identifiers['pinterest_ct_rt'])
			|| isset($identifiers['pinterest_ct'])
			|| isset($identifiers['pinterest_ct_ua'])
			|| isset($identifiers['pinterest_sess'])
		);
	}

	private static function get_order_contents_with_quantity_and_item_price( $order ) {
		$data = [];
		foreach (Product::pmw_get_order_items($order) as $order_item) {
			$product_id = Product::get_variation_or_product_id($order_item->get_data(), Options::is_shop_variations_output_active());
			$product    = wc_get_product($product_id);

			// Only add if WC retrieves a valid product
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			// Bundles/composites: report the assembled price, not the 0/base container price.
			$container_price = Product::maybe_get_container_order_item_unit_price($order_item, false, $order);
			$item_price      = null !== $container_price ? $container_price : $product->get_price();

			$content = [
				'id'         => (string) Product::get_dyn_r_id_for_product_by_pixel_name($product, 'pinterest'),
				'item_price' => (string) Helpers::format_decimal($item_price, 2),
				'quantity'   => (int) $order_item->get_quantity(),
				'item_name'  => $product->get_name(),
			];

			// Pinterest asks for the brand and the category on the checkout
			// event and reports their absence as a coverage gap, which is what
			// its automated bidding reads to decide it has too little to work
			// with. Both live on the parent product: a variation carries
			// neither taxonomy of its own on most shops.
			$taxonomy_product_id = 'variation' === $product->get_type() ? $product->get_parent_id() : $product->get_id();

			$brand = Product::get_brand_name($taxonomy_product_id);
			if ($brand) {
				$content['item_brand'] = (string) $brand;
			}

			$categories = Product::get_product_category($taxonomy_product_id);
			if (!empty($categories)) {
				$content['item_category'] = (string) reset($categories);
			}

			$data[] = $content;
		}
		return $data;
	}

	private static function get_product_ids( $order ) {

		$data = [];

		foreach (Product::pmw_get_order_items($order) as $order_item) {

			$product_id = Product::get_variation_or_product_id($order_item->get_data(), Options::is_shop_variations_output_active());
			$product    = wc_get_product($product_id);

			// Only add if WC retrieves a valid product
			if (Product::is_not_wc_product($product)) {
				continue;
			}

			$product_id_compiled = Product::get_dyn_r_id_for_product_by_pixel_name($product, 'pinterest');

			$data[] = (string) $product_id_compiled;
		}

		return $data;
	}

	public static function send_event_hit( $event_data ) {

		// Every sibling send method does this, and without it the class relies
		// on having been instantiated during init: self::$http would still be
		// null here and the event would die on a fatal instead of being sent.
		self::get_instance();

		if (!Options::is_pinterest_apic_active()) {
			return;
		}

		if (Shop::do_not_track_user(get_current_user_id())) {
			return;
		}

		$user_ip = Geolocation::get_user_ip();

		if ($user_ip) {
			$event_data['user_data']['client_ip_address'] = $user_ip;
		}

		// Pinterest accepts an event on the strength of an IP plus a user agent
		// when no hashed identifier is present, so the user agent has to be
		// filled in alongside the IP. Events on this path are fired from the
		// visitor's browser, which makes the request's own user agent the
		// authoritative one.
		if (empty($event_data['user_data']['client_user_agent'])) {
			$user_agent = Helpers::get_request_user_agent();
			if ($user_agent) {
				$event_data['user_data']['client_user_agent'] = $user_agent;
			}
		}

		$payload = [
			'data' => [ $event_data ],
		];

		self::$http->post(self::get_request_url(), $payload);
	}

	// https://developers.pinterest.com/docs/conversions/event/#Event%20level%20requirements
	protected static function get_user_data_for_order( $identifiers, $order ) {

		$user_data_output = [];

		// Required parameter
		if (isset($identifiers['ip_address'])) {
			$user_data_output['client_ip_address'] = $identifiers['ip_address'];
		}

		// Required parameter
		if (isset($identifiers['user_agent'])) {
			$user_data_output['client_user_agent'] = $identifiers['user_agent'];
		}

		if (isset($identifiers['derived_epik'])) {
			$user_data_output['click_id'] = $identifiers['derived_epik'];
		}

		// Optional parameters
		if (isset($identifiers['epik'])) {
			$user_data_output['click_id'] = $identifiers['epik'];
		}

		if (Options::is_pinterest_advanced_matching_active()) {

			$user_data_input = Helpers::get_user_data_object($order);

			if (isset($user_data_input->email->pinterest)) {
				$user_data_output['em'] = [ $user_data_input->email->pinterest ];
			}

			if (isset($user_data_input->phone->pinterest)) {
				$user_data_output['ph'] = [ $user_data_input->phone->pinterest ];
			}

			if (isset($user_data_input->first_name->pinterest)) {
				$user_data_output['fn'] = [ $user_data_input->first_name->pinterest ];
			}

			if (isset($user_data_input->last_name->pinterest)) {
				$user_data_output['ln'] = [ $user_data_input->last_name->pinterest ];
			}

			if (isset($user_data_input->city->pinterest)) {
				$user_data_output['ct'] = [ $user_data_input->city->pinterest ];
			}

			if (isset($user_data_input->state->pinterest)) {
				$user_data_output['st'] = [ $user_data_input->state->pinterest ];
			}

			if (isset($user_data_input->zip->pinterest)) {
				$user_data_output['zp'] = [ $user_data_input->zip->pinterest ];
			}

			if (isset($user_data_input->country->pinterest)) {
				$user_data_output['country'] = [ $user_data_input->country->pinterest ];
			}

			$external_id = self::get_external_id($user_data_input);
			if ($external_id) {
				$user_data_output['external_id'] = [ $external_id ];
			}
		}

		return $user_data_output;
	}

	/**
	 * The shop's own identifier for the customer behind an event.
	 *
	 * Pinterest counts the external ID towards its coverage score and uses it
	 * to tie a shopper's events together across sessions and devices. Only a
	 * registered customer has a WordPress user ID, and most shops take the
	 * majority of their orders from guests, so those events carried no
	 * external ID at all. The hashed email address is the shop's stable
	 * identity for a guest, so it stands in.
	 *
	 * Return an empty string from pmw_pinterest_external_id to send none.
	 *
	 * @param object $user_data_input
	 * @return string
	 * @since 1.67.1
	 */
	private static function get_external_id( $user_data_input ) {

		$external_id = '';

		if (isset($user_data_input->id->sha256)) {
			$external_id = $user_data_input->id->sha256;
		} elseif (isset($user_data_input->email->pinterest)) {
			$external_id = $user_data_input->email->pinterest;
		}

		/**
		 * Filter the external ID sent to Pinterest.
		 *
		 * @param string $external_id     The hashed user ID, or the hashed email address for a guest.
		 * @param object $user_data_input The full user data object behind the event.
		 * @since 1.67.1
		 */
		return (string) apply_filters('pmw_pinterest_external_id', $external_id, $user_data_input);
	}

	/**
	 * Add identifiers specific to Pinterest APIC
	 *
	 * @param $identifiers
	 * @return mixed
	 */
	/**
	 * Click IDs this destination recovers from the universal per-order
	 * snapshot when its own identifiers carry none (historical orders,
	 * a destination activated later, a backfill).
	 *
	 * @return array<string, string>
	 * @since 1.66.0
	 */
	protected static function get_click_id_snapshot_map() {
		return [ 'epik' => 'epik' ];
	}

	protected static function add_pixel_specific_identifiers( $identifiers ) {

		$_cookie = Helpers::get_input_vars(INPUT_COOKIE);

		if (isset($_cookie['_epik']) && self::is_valid_epik($_cookie['_epik'])) {
			$identifiers['epik'] = $_cookie['_epik'];
		}

		if (isset($_cookie['_derived_epik']) && self::is_valid_derived_epik($_cookie['_derived_epik'])) {
			$identifiers['derived_epik'] = $_cookie['_derived_epik'];
		}

		// Set the _pin_unauth cookie if it exists
		if (isset($_cookie['_pin_unauth']) && self::is_valid_generic_pinterest_cookie($_cookie['_pin_unauth'])) {
			$identifiers['pin_unauth'] = $_cookie['_pin_unauth'];
		}

		// Set the _pinterest_ct_rt cookie if it exists
		if (isset($_cookie['_pinterest_ct_rt']) && self::is_valid_generic_pinterest_cookie($_cookie['_pinterest_ct_rt'])) {
			$identifiers['pinterest_ct_rt'] = $_cookie['_pinterest_ct_rt'];
		}

		// Set the _pinterest_ct cookie if it exists
		if (isset($_cookie['_pinterest_ct']) && self::is_valid_generic_pinterest_cookie($_cookie['_pinterest_ct'])) {
			$identifiers['pinterest_ct'] = $_cookie['_pinterest_ct'];
		}

		// Set the _pinterest_ct_ua cookie if it exists
		if (isset($_cookie['_pinterest_ct_ua']) && self::is_valid_generic_pinterest_cookie($_cookie['_pinterest_ct_ua'])) {
			$identifiers['pinterest_ct_ua'] = $_cookie['_pinterest_ct_ua'];
		}

		// Set the _pinterest_sess cookie if it exists
		if (isset($_cookie['_pinterest_sess']) && self::is_valid_generic_pinterest_cookie($_cookie['_pinterest_sess'])) {
			$identifiers['pinterest_sess'] = $_cookie['_pinterest_sess'];
		}

		/**
		 * Enrich the data with transient session data
		 */

		$transient_identifiers = Shop::get_transient_identifiers_from_session();

		if (!isset($_cookie['_epik']) && isset($transient_identifiers['epik'])) {
			$identifiers['epik'] = $transient_identifiers['epik'];
		}

		return $identifiers;
	}

	/**
	 * Check if the _epik cookie is valid
	 *
	 * @param $cookie
	 * @return bool
	 */
	public static function is_valid_epik( $cookie ) {
		return (bool) preg_match('/^dj0yJnU9[a-zA-Z0-9\-\_]{100}/', $cookie);
	}

	/**
	 * Check if the _derived_epik cookie is valid
	 *
	 * @param $cookie
	 * @return bool
	 */
	private static function is_valid_derived_epik( $cookie ) {
		return (bool) preg_match('/^dj0yJnU9[a-zA-Z0-9\-\_]{134}/', $cookie);
	}

	/**
	 * Check if the generic Pinterest cookie is valid
	 *
	 * @param $cookie
	 * @return bool
	 */
	private static function is_valid_generic_pinterest_cookie( $cookie ) {
		return (bool) preg_match('/^["a-zA-Z0-9=]*$/', $cookie);
	}

	/**
	 * Generate random identifiers
	 */

	/**
	 * Get random base identifiers
	 *
	 * @return string[]
	 */
	protected static function get_random_base_identifiers() {
		return [
			'epik' => self::generate_random_epik(),
		];
	}

	/**
	 * Generate a random epik string
	 *
	 * Random string with the length of 100 and contains small letters and numbers
	 *
	 * @return string
	 */
	private static function generate_random_epik() {
		return 'dj0yJnU9' . self::generate_random_partial_epik_string(100);
	}

	/**
	 * Generate a random partial epik string
	 *
	 * It can contain small letters, capital letters and numbers
	 *
	 * @return string
	 */
	private static function generate_random_partial_epik_string() {
		return (string) substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 100);
	}
}
