<?php
if(!defined('ABSPATH')) {
	exit;
}

//register settings + options
function perfmatters_settings() {

	if(get_option('perfmatters_options') == false) {	
		add_option('perfmatters_options', perfmatters_default_options());
	}

    $perfmatters_options = get_option('perfmatters_options');
    $perfmatters_tools = get_option('perfmatters_tools');

    /* options primary section
    /**********************************************************/
    add_settings_section('perfmatters_options', __('Core', 'perfmatters'), '__return_false', 'perfmatters_options');

    //disable emojis
    add_settings_field(
    	'disable_emojis', 
    	perfmatters_title(__('Disable Emojis', 'perfmatters'), 'disable_emojis', 'https://perfmatters.io/docs/disable-emojis-wordpress/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
            'id' => 'disable_emojis',
            'tooltip' => __('Removes WordPress Emojis JavaScript file (wp-emoji-release.min.js).', 'perfmatters')
        )
    );

    //disable dashicons
    add_settings_field(
        'disable_dashicons', 
        perfmatters_title(__('Disable Dashicons', 'perfmatters'), 'disable_dashicons', 'https://perfmatters.io/docs/remove-dashicons-wordpress/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'disable_dashicons',
            'tooltip' => __('Disables dashicons on the front end when not logged in.', 'perfmatters')
        )
    );

    //disable embeds
    add_settings_field(
    	'disable_embeds', 
    	perfmatters_title(__('Disable Embeds', 'perfmatters'), 'disable_embeds', 'https://perfmatters.io/docs/disable-embeds-wordpress/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'disable_embeds',
    		'tooltip' => __('Removes WordPress Embed JavaScript file (wp-embed.min.js).', 'perfmatters')   		
    	)
    );

	//disable xml-rpc
    add_settings_field(
    	'disable_xmlrpc', 
    	perfmatters_title(__('Disable XML-RPC', 'perfmatters'), 'disable_xmlrpc', 'https://perfmatters.io/docs/disable-xml-rpc-wordpress/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'disable_xmlrpc',
            'class' => 'perfmatters-input-controller',
    		'tooltip' => __('Disables WordPress XML-RPC functionality.', 'perfmatters')
    	)
    );

    //remove rsd link
    add_settings_field(
        'remove_rsd_link', 
        perfmatters_title(__('Remove RSD Link', 'perfmatters'), 'remove_rsd_link', 'https://perfmatters.io/docs/remove-rsd-link-wordpress/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'remove_rsd_link',
            'class' => 'disable_xmlrpc' . (!empty($perfmatters_options['disable_xmlrpc']) ? ' hidden' : ''),
            'tooltip' => __('Remove RSD (Real Simple Discovery) link tag.', 'perfmatters')
        )
    );

	//remove jquery migrate
    add_settings_field(
    	'remove_jquery_migrate', 
    	perfmatters_title(__('Remove jQuery Migrate', 'perfmatters'), 'remove_jquery_migrate', 'https://perfmatters.io/docs/remove-jquery-migrate-wordpress/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'remove_jquery_migrate',
    		'tooltip' => __('Removes jQuery Migrate JavaScript file (jquery-migrate.min.js).', 'perfmatters')
    	)
    );

    //hide wp version
    add_settings_field(
    	'hide_wp_version', 
    	perfmatters_title(__('Hide WP Version', 'perfmatters'), 'hide_wp_version', 'https://perfmatters.io/docs/remove-wordpress-version-number/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'hide_wp_version',
    		'tooltip' => __('Removes WordPress version meta tag.', 'perfmatters')
    	)
    );

    //remove shortlink
    add_settings_field(
    	'remove_shortlink', 
    	perfmatters_title(__('Remove Shortlink', 'perfmatters'), 'remove_shortlink', 'https://perfmatters.io/docs/remove-shortlink-wordpress/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'remove_shortlink',
    		'tooltip' => __('Remove Shortlink link tag.', 'perfmatters')
    	)
    );

    //disable rss feeds
    add_settings_field(
    	'disable_rss_feeds', 
    	perfmatters_title(__('Disable RSS Feeds', 'perfmatters'), 'disable_rss_feeds', 'https://perfmatters.io/docs/disable-rss-feeds-wordpress/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'disable_rss_feeds',
            'class' => 'perfmatters-input-controller',
    		'tooltip' => __('Disable WordPress generated RSS feeds and return a 410 response.', 'perfmatters')
    	)
    );

    //remove feed links
    add_settings_field(
    	'remove_feed_links', 
    	perfmatters_title(__('Remove RSS Feed Links', 'perfmatters'), 'remove_feed_links', 'https://perfmatters.io/docs/remove-rss-feed-links-wordpress/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'remove_feed_links',
            'class' => 'disable_rss_feeds' . (!empty($perfmatters_options['disable_rss_feeds']) ? ' hidden' : ''),
    		'tooltip' => __('Disable WordPress generated RSS feed link tags.', 'perfmatters')
    	)
    );

    //disable self pingbacks
    add_settings_field(
    	'disable_self_pingbacks', 
    	perfmatters_title(__('Disable Self Pingbacks', 'perfmatters'), 'disable_self_pingbacks', 'https://perfmatters.io/docs/disable-self-pingbacks-wordpress/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'disable_self_pingbacks',
    		'tooltip' => __('Disable Self Pingbacks (generated when linking to an article on your own blog).', 'perfmatters')
    	)
    );

    //disable rest api
    add_settings_field(
    	'disable_rest_api', 
    	perfmatters_title(__('Disable REST API', 'perfmatters'), 'disable_rest_api', 'https://perfmatters.io/docs/disable-wordpress-rest-api/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'disable_rest_api',
    		'input' => 'select',
    		'options' => array(
    			''                   => __('Default (Enabled)', 'perfmatters'),
    			'disable_non_admins' => __('Disable for Non-Admins', 'perfmatters'),
    			'disable_logged_out' => __('Disable When Logged Out', 'perfmatters')
    		),
    		'tooltip' => __('Disables REST API requests and displays an error message if the requester doesn\'t have permission.', 'perfmatters')
    	)
    );

    //remove rest api links
    add_settings_field(
    	'remove_rest_api_links', 
    	perfmatters_title(__('Remove REST API Links', 'perfmatters'), 'remove_rest_api_links', 'https://perfmatters.io/docs/remove-wordpress-rest-api-links/'), 
    	'perfmatters_print_input', 
    	'perfmatters_options', 
    	'perfmatters_options', 
    	array(
    		'id' => 'remove_rest_api_links',
    		'tooltip' => __('Removes REST API link tag from the front end and the REST API header link from page requests.', 'perfmatters')
    	)
    );

    //disable google maps
    add_settings_field(
        'disable_google_maps', 
        perfmatters_title(__('Disable Google Maps', 'perfmatters'), 'disable_google_maps', 'https://perfmatters.io/docs/disable-google-maps-api-wordpress/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'disable_google_maps',
            'class' => 'perfmatters-input-controller',
            'tooltip' => __('Removes any instances of Google Maps being loaded across your entire site.', 'perfmatters')
        )
    );

    //disable google maps exclusions
    add_settings_field(
        'disable_google_maps_exclusions', 
        perfmatters_title(__('Exclude Locations', 'perfmatters'), 'disable_google_maps_exclusions', 'https://perfmatters.io/docs/disable-google-maps-api-wordpress/#exclude'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'disable_google_maps_exclusions',
            'input' => 'text',
            'placeholder' => 'front,blog,23,19',
            'class' => 'disable_google_maps' . (empty($perfmatters_options['disable_google_maps']) ? ' hidden' : ''),
            'tooltip' => __('Prevent Google Maps from being disabled in specific locations. Format: comma separated', 'perfmatters')
        )
    );

    //disable password strength meter
    add_settings_field(
        'disable_password_strength_meter', 
        perfmatters_title(__('Disable Password Meter', 'perfmatters'), 'disable_password_strength_meter', 'https://perfmatters.io/docs/disable-password-meter-strength/'),
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'disable_password_strength_meter',
            'tooltip' => __('Removes WordPress and WooCommerce Password Strength Meter scripts from non essential pages.', 'perfmatters')
        )
    );

    //disable comments
    add_settings_field(
        'disable_comments', 
        perfmatters_title(__('Disable Comments', 'perfmatters'), 'disable_comments', 'https://perfmatters.io/docs/wordpress-disable-comments/'),
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'disable_comments',
            'tooltip' => __('Disables WordPress comments across your entire site.', 'perfmatters')
        )
    );

    if(!defined('KADENCE_VERSION')) {

        //remove comment urls
        add_settings_field(
            'remove_comment_urls', 
            perfmatters_title(__('Remove Comment URLs', 'perfmatters'), 'remove_comment_urls', 'https://perfmatters.io/docs/remove-wordpress-comment-author-link'),
            'perfmatters_print_input', 
            'perfmatters_options', 
            'perfmatters_options', 
            array(
                'id' => 'remove_comment_urls',
                'tooltip' => __('Removes the WordPress comment author link and website field from blog posts.', 'perfmatters')
            )
        );
    }

    //blank favicon
    add_settings_field(
        'blank_favicon', 
        perfmatters_title(__('Add Blank Favicon', 'perfmatters'), 'blank_favicon', 'https://perfmatters.io/docs/blank-favicon/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'blank_favicon',
            'tooltip' => __('Adds a blank favicon to your WordPress header, which will prevent a missing favicon or 404 error. If you already have a favicon on your site, you should leave this off. ', 'perfmatters')
        )
    );

    //remove global styles
    add_settings_field(
        'remove_global_styles', 
        perfmatters_title(__('Remove Global Styles', 'perfmatters'), 'remove_global_styles', 'https://perfmatters.io/docs/remove-global-inline-styles-wordpress/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'remove_global_styles',
            'tooltip' => __('Remove the inline global styles related to WordPress core blocks.', 'perfmatters')
        )
    );

    //separate block styles
    if(version_compare(get_bloginfo('version'), '6.9' , '<')) {

        //pre 6.9 toggle
        add_settings_field(
            'separate_block_styles', 
            perfmatters_title(__('Separate Block Styles', 'perfmatters'), 'separate_block_styles', 'https://perfmatters.io/docs/separate-core-block-styles-wordpress/'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'perfmatters_options', 
            array(
                'id' => 'separate_block_styles',
                'tooltip' => __('Load core block styles only when they are rendered instead of in a global stylesheet.', 'perfmatters')
            )
        );
    }
    else {

        //6.9+ dropdown
        add_settings_field(
            'separate_block_styles', 
            perfmatters_title(__('Block Style Behavior', 'perfmatters'), 'separate_block_styles', 'https://perfmatters.io/docs/block-style-behavior/'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'perfmatters_options', 
            array(
                'id' => 'separate_block_styles',
                'input' => 'select',
                'options' => array(
                    ''           => __('Separate Styles Inline', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                    'stylesheet' => __('Load Global Stylesheet', 'perfmatters')
                ),
                'tooltip' => __('Choose how WordPress core block styles are loaded.', 'perfmatters')
            )
        );
    }

    //disable heartbeat
    add_settings_field(
        'disable_heartbeat', 
        perfmatters_title(__('Disable Heartbeat', 'perfmatters'), 'disable_heartbeat', 'https://perfmatters.io/docs/disable-wordpress-heartbeat-api/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'disable_heartbeat',
            'input' => 'select',
            'options' => array(
                ''                   => __('Default', 'perfmatters'),
                'disable_everywhere' => __('Disable Everywhere', 'perfmatters'),
                'allow_posts'        => __('Only Allow When Editing Posts/Pages', 'perfmatters')
            ),
            'tooltip' => __('Disable WordPress Heartbeat everywhere or in certain areas (used for auto saving and revision tracking).', 'perfmatters')
        )
    );

    //heartbeat frequency
    add_settings_field(
        'heartbeat_frequency', 
        perfmatters_title(__('Heartbeat Frequency', 'perfmatters'), 'heartbeat_frequency', 'https://perfmatters.io/docs/change-heartbeat-frequency-wordpress/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'heartbeat_frequency',
            'input' => 'select',
            'options' => array(
                /* translators: %s: number of seconds */
                ''   => sprintf(__('%s Seconds', 'perfmatters'), '15') . ' (' . __('Default', 'perfmatters') . ')',
                /* translators: %s: number of seconds */
                '30' => sprintf(__('%s Seconds', 'perfmatters'), '30'),
                /* translators: %s: number of seconds */
                '45' => sprintf(__('%s Seconds', 'perfmatters'), '45'),
                /* translators: %s: number of seconds */
                '60' => sprintf(__('%s Seconds', 'perfmatters'), '60')
            ),
            'tooltip' => __('Controls how often the WordPress Heartbeat API is allowed to run.', 'perfmatters')
        )
    );

    //limit post revisions
    add_settings_field(
        'limit_post_revisions', 
        perfmatters_title(__('Limit Post Revisions', 'perfmatters'), 'limit_post_revisions', 'https://perfmatters.io/docs/disable-limit-post-revisions-wordpress/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'limit_post_revisions',
            'input' => 'select',
            'options' => array(
                ''      => __('Default', 'perfmatters'),
                'false' => __('Disable Post Revisions', 'perfmatters'),
                '1'     => '1',
                '2'     => '2',
                '3'     => '3',
                '4'     => '4',
                '5'     => '5',
                '10'    => '10',
                '15'    => '15',
                '20'    => '20',
                '25'    => '25',
                '30'    => '30'
            ),
            'tooltip' => __('Limits the maximum amount of revisions that are allowed for posts and pages.', 'perfmatters')
        )
    );

    //autosave interval
    add_settings_field(
        'autosave_interval', 
        perfmatters_title(__('Autosave Interval', 'perfmatters'), 'autosave_interval', 'https://perfmatters.io/docs/change-autosave-interval-wordpress/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_options', 
        array(
            'id' => 'autosave_interval',
            'input' => 'select',
            'options' => array(
                ''      => '1 ' . __('Minute', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                '86400' => __('Disable Autosave Interval', 'perfmatters'),
                '120'   => '2 ' . __('Minutes', 'perfmatters'),
                '180'   => '3 ' . __('Minutes', 'perfmatters'),
                '240'   => '4 ' . __('Minutes', 'perfmatters'),
                '300'   => '5 ' . __('Minutes', 'perfmatters'),
                '600'   => '10 ' . __('Minutes', 'perfmatters'),
                '900'   => '15 ' . __('Minutes', 'perfmatters'),
                '1200'  => '20 ' . __('Minutes', 'perfmatters'),
                '1500'  => '25 ' . __('Minutes', 'perfmatters'),
                '1800'  => '30 ' . __('Minutes', 'perfmatters')
            ),
            'tooltip' => __('Controls how often WordPress will auto save posts and pages while editing.', 'perfmatters')
        )
    );

    //login url options section
    add_settings_section('login_url', __('Login URL', 'perfmatters'), '__return_false', 'perfmatters_options');

    //change login url
    add_settings_field(
        'login_url', 
        perfmatters_title(__('Custom Login URL', 'perfmatters'), 'login_url', 'https://perfmatters.io/docs/change-wordpress-login-url/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'login_url', 
        array(
            'id' => 'login_url',
            'input' => 'text',
            'validate' => '^[a-z0-9-]+$',
            'placeholder' => 'hideme',
            'tooltip' => __('When set, this will change your WordPress login URL (slug) to the provided string and will block wp-admin and wp-login endpoints from being directly accessed.', 'perfmatters')
        )
    );

    //login url behavior
    add_settings_field(
        'login_url_behavior', 
        perfmatters_title(__('Disabled Behavior', 'perfmatters'), 'login_url_behavior', 'https://perfmatters.io/docs/change-wordpress-login-url/#disabled-behavior'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'login_url', 
        array(
            'id' => 'login_url_behavior',
            'input' => 'select',
            'options' => array(
                '' => __('Message', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                '404' => __('404 Template', 'perfmatters'),
                'home' => __('Home URL', 'perfmatters'),
                'redirect' => __('Local Redirect', 'perfmatters')
            ),
            'class' => 'perfmatters-input-controller',
            'tooltip' => __('Change what happens when an original login endpoint is visited.', 'perfmatters')
        )
    );

    //login url message
    add_settings_field(
        'login_url_message', 
        perfmatters_title(__('Message', 'perfmatters'), 'login_url_message', 'https://perfmatters.io/docs/change-wordpress-login-url/#message'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'login_url', 
        array(
            'id' => 'login_url_message',
            'input' => 'text',
            'class' => 'login_url_behavior perfmatters-select-control-' . (!empty($perfmatters_options['login_url_behavior']) ? ' hidden' : ''),
            'placeholder' => __('This has been disabled.', 'perfmatters'),
            'tooltip' => __('Change the disabled message that is displayed.', 'perfmatters')
        )
    );

    //login url redirect
    add_settings_field(
        'login_url_redirect', 
        perfmatters_title(__('Redirect Slug', 'perfmatters'), 'login_url_redirect', 'https://perfmatters.io/docs/change-wordpress-login-url/#local-redirect'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'login_url', 
        array(
            'id' => 'login_url_redirect',
            'input' => 'text',
            'class' => 'login_url_behavior perfmatters-select-control-redirect' . (empty($perfmatters_options['login_url_behavior']) || $perfmatters_options['login_url_behavior'] !== 'redirect' ? ' hidden' : ''),
            'placeholder' => __('404', 'perfmatters'),
            'tooltip' => __('Change the slug that is used for the local redirect.', 'perfmatters')
        )
    );

    if(class_exists('WooCommerce')) {

        //woocommerce options section
        add_settings_section('perfmatters_woocommerce', 'WooCommerce', '__return_false', 'perfmatters_options');

        //disable woocommerce scripts
        add_settings_field(
            'disable_woocommerce_scripts', 
            perfmatters_title(__('Disable Scripts', 'perfmatters'), 'disable_woocommerce_scripts', 'https://perfmatters.io/docs/disable-woocommerce-scripts-and-styles/'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'perfmatters_woocommerce', 
            array(
                'id' => 'disable_woocommerce_scripts',
                'tooltip' => __('Disables WooCommerce scripts and styles except on product, cart, and checkout pages.', 'perfmatters')
            )
        );

        //disable woocommerce cart fragmentation
        add_settings_field(
            'disable_woocommerce_cart_fragmentation', 
            perfmatters_title(__('Disable Cart Fragmentation', 'perfmatters'), 'disable_woocommerce_cart_fragmentation', 'https://perfmatters.io/docs/disable-woocommerce-cart-fragments-ajax/'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'perfmatters_woocommerce', 
            array(
                'id' => 'disable_woocommerce_cart_fragmentation',
                'tooltip' => __('Disables WooCommerce cart fragmentation script when there are no items in the cart.', 'perfmatters')
            )
        );

        //disable woocommerce status meta box
        add_settings_field(
            'disable_woocommerce_status', 
            perfmatters_title(__('Disable Status Meta Box', 'perfmatters'), 'disable_woocommerce_status', 'https://perfmatters.io/docs/disable-woocommerce-status-meta-box/'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'perfmatters_woocommerce', 
            array(
                'id' => 'disable_woocommerce_status',
                'tooltip' => __('Disables WooCommerce status meta box from the WP Admin Dashboard.', 'perfmatters')
            )
        );

        //disable woocommerce widgets
        add_settings_field(
            'disable_woocommerce_widgets', 
            perfmatters_title(__('Disable Widgets', 'perfmatters'), 'disable_woocommerce_widgets', 'https://perfmatters.io/docs/disable-woocommerce-widgets/'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'perfmatters_woocommerce', 
            array(
                'id' => 'disable_woocommerce_widgets',
                'tooltip' => __('Disables all WooCommerce widgets.', 'perfmatters')
            )
        );
    }

    /* assets section
    /**********************************************************/
    //add_settings_section('assets', __('Features', 'perfmatters'), '__return_false', 'perfmatters_options');

    //defer js
    add_settings_section('assets_js_defer', __('Defer', 'perfmatters'), '__return_false', 'perfmatters_options');

    //defer js
    add_settings_field(
        'defer_js', 
        perfmatters_title(__('Defer Javascript', 'perfmatters'), 'assets-defer_js', 'https://perfmatters.io/docs/defer-javascript-wordpress/#defer'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_defer', 
        array(
            'id' => 'defer_js',
            'section' => 'assets',
            'tooltip' => __('Add the defer attribute to your JavaScript files.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //defer inline
    add_settings_field(
        'defer_inline', 
        perfmatters_title(__('Include Inline Scripts', 'perfmatters'), 'assets-defer_inline', 'https://perfmatters.io/docs/defer-javascript-wordpress/#include-inline-scripts'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_defer', 
        array(
            'id' => 'defer_inline',
            'section' => 'assets',
            'tooltip' => __('Include inline scripts in deferral.', 'perfmatters'),
            'class' => 'assets-defer_js' . (empty($perfmatters_options['assets']['defer_js']) ? ' hidden' : '')
        )
    );

    //defer jquery
    add_settings_field(
        'defer_jquery', 
        perfmatters_title(__('Include jQuery', 'perfmatters'), 'assets-defer_jquery', 'https://perfmatters.io/docs/defer-javascript-wordpress/#include-jquery'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_defer', 
        array(
            'id' => 'defer_jquery',
            'section' => 'assets',
            'confirmation' => __('Many plugins and themes require jQuery. We recommend either testing jQuery deferral separately or leaving this option turned off.', 'perfmatters'),
            'tooltip' => __('Allow jQuery core to be deferred. We recommend testing this separately or leaving it off.', 'perfmatters'),
            'class' => 'assets-defer_js' . (empty($perfmatters_options['assets']['defer_js']) ? ' hidden' : '') . ' pm-advanced-option'
        )
    );

    //js exlusions
    add_settings_field(
        'js_exclusions', 
        perfmatters_title(__('Excluded from Deferral', 'perfmatters'), 'assets-js_exclusions', 'https://perfmatters.io/docs/defer-javascript-wordpress/#exclude'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_defer', 
        array(
            'id' => 'js_exclusions',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'example.js',
            'tooltip' => __('Exclude specific JavaScript files from deferral. Exclude a file by adding the source URL (example.js). Format: one per line', 'perfmatters'),
            'class' => 'assets-defer_js' . (empty($perfmatters_options['assets']['defer_js']) ? ' hidden' : '')
        )
    );

    //delay js
    add_settings_section('assets_js_delay', __('Delay', 'perfmatters'), '__return_false', 'perfmatters_options');

    //delay_js
    add_settings_field(
        'delay_js', 
        perfmatters_title(__('Delay JavaScript', 'perfmatters'), 'assets-delay_js', 'https://perfmatters.io/docs/delay-javascript/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_delay', 
        array(
            'id' => 'delay_js',
            'section' => 'assets',
            'tooltip' => __('Delay JavaScript from loading until user interaction.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //delayed js behavior
    add_settings_field(
        'delay_js_behavior', 
        perfmatters_title(__('Delay Behavior', 'perfmatters'), 'assets-delay_js_behavior', 'https://perfmatters.io/docs/delay-javascript/#behavior'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_delay', 
        array(
            'id' => 'delay_js_behavior',
            'section' => 'assets',
            'input' => 'select',
            'options' => array(
                '' => __('Only Delay Specified Scripts', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                'all' => __('Delay All Scripts', 'perfmatters')
            ),
            'tooltip' => __('Choose the method used to delay scripts.', 'perfmatters'),
            'class' => 'assets-delay_js perfmatters-input-controller' . (empty($perfmatters_options['assets']['delay_js']) ? ' hidden' : '')
        )
    );

    //delay js inclusions
    add_settings_field(
        'delay_js_inclusions', 
        perfmatters_title(__('Delayed Scripts', 'perfmatters'), 'assets-delay_js_inclusions', 'https://perfmatters.io/docs/delay-javascript/#scripts'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_delay', 
        array(
            'id' => 'delay_js_inclusions',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'example.js',
            'tooltip' => __('Delay specific JavaScript files by adding the source URL (example.js), or delay an inline script by adding a unique string from that script. Format: one per line', 'perfmatters'),
            'class' => 'assets-delay_js assets-delay_js_behavior perfmatters-select-control-' . (!empty($perfmatters_options['assets']['delay_js_behavior']) || empty($perfmatters_options['assets']['delay_js']) ? ' hidden' : '')
        )
    );

    //delay js quick exclusions
    add_settings_field(
        'delay_js_quick_exclusions', 
        perfmatters_title(__('Quick Exclusions', 'perfmatters'), false, 'https://perfmatters.io/docs/delay-javascript/#quick-exclusions'), 
        'perfmatters_print_quick_exclusions', 
        'perfmatters_options', 
        'assets_js_delay', 
        array(
            'id' => 'delay_js_quick_exclusions',
            'section' => 'assets',
            'tooltip' => __('Exclude scripts for popular plugins and themes based on our predefined lists of common exclusions.', 'perfmatters'),
            'class' => 'assets-delay_js assets-delay_js_behavior perfmatters-select-control-all' . (empty($perfmatters_options['assets']['delay_js_behavior'])  || empty($perfmatters_options['assets']['delay_js']) ? ' hidden' : '') . ' delay_js_quick_exclusions'
        )
    );

    //delay js exclusions
    add_settings_field(
        'delay_js_exclusions', 
        perfmatters_title(__('Excluded from Delay', 'perfmatters'), 'assets-delay_js_exclusions', 'https://perfmatters.io/docs/delay-javascript/#excluded'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_delay', 
        array(
            'id' => 'delay_js_exclusions',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'example.js',
            'tooltip' => __('Exclude specific JavaScript files from delay by adding the source URL (example.js), or exclude an inline script by adding a unique string from that script. Format: one per line', 'perfmatters'),
            'class' => 'assets-delay_js assets-delay_js_behavior perfmatters-select-control-all' . (empty($perfmatters_options['assets']['delay_js_behavior'])  || empty($perfmatters_options['assets']['delay_js']) ? ' hidden' : '')
        )
    );

    //delay timeout
    add_settings_field(
        'delay_timeout', 
        perfmatters_title(__('Delay Timeout', 'perfmatters'), 'assets-delay_timeout', 'https://perfmatters.io/docs/delay-javascript/#timeout'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_delay', 
        array(
            'id' => 'delay_timeout',
            'section' => 'assets',
            'tooltip' => __('Load delayed scripts after a set amount of time if no user interaction has been detected.', 'perfmatters'),
            'class' => 'assets-delay_js' . (empty($perfmatters_options['assets']['delay_js']) ? ' hidden' : '')
        )
    );

    //disable click delay
    add_settings_field(
        'disable_click_delay', 
        perfmatters_title(__('Disable Click Delay', 'perfmatters'), 'assets-disable_click_delay', 'https://perfmatters.io/docs/delay-javascript/#disable-click-delay'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_delay', 
        array(
            'id' => 'disable_click_delay',
            'section' => 'assets',
            'tooltip' => __('Prevents the first click from being delayed until JavaScript has finished loading. This can be helpful if you are excluding scripts for interactive elements manually.', 'perfmatters'),
            'class' => 'assets-delay_js' . (empty($perfmatters_options['assets']['delay_js']) ? ' hidden' : ''). ' pm-advanced-option'
        )
    );

    //fastclick
    add_settings_field(
        'fastclick', 
        perfmatters_title(__('Enable FastClick', 'perfmatters'), 'assets-fastclick', 'https://perfmatters.io/docs/delay-javascript/#fastclick'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_delay', 
        array(
            'id' => 'fastclick',
            'section' => 'assets',
            'tooltip' => __('Load the FastClick library locally to fix the double-click issue on iOS.', 'perfmatters'),
            'confirmation' => __('Using FastClick is not recommended for most modern mobile browsers and enabling it can sometimes cause problems.', 'perfmatters'),
            'class' => 'assets-delay_js' . (empty($perfmatters_options['assets']['delay_js']) ? ' hidden' : ''). ' pm-advanced-option'
        )
    );

    //minify js
    add_settings_section('assets_js_minify', __('Minify', 'perfmatters'), '__return_false', 'perfmatters_options');

    //minify js
    add_settings_field(
        'minify_js', 
        perfmatters_title(__('Minify JavaScript', 'perfmatters'), 'assets-minify_js', 'https://perfmatters.io/docs/minify-javascript-wordpress/#minify'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_minify', 
        array(
            'id' => 'minify_js',
            'section' => 'assets',
            'tooltip' => __('Remove unnecessary characters and optimize JavaScript files.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //minify js exclusions
    add_settings_field(
        'minify_js_exclusions', 
        perfmatters_title(__('Excluded from Minification', 'perfmatters'), 'assets-minify_js_exclusions', 'https://perfmatters.io/docs/minify-javascript-wordpress/#exclude'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_js_minify', 
        array(
            'id' => 'minify_js_exclusions',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'example.js',
            'tooltip' => __('Exclude specific JavaScript files from minification by adding the source URL (example.js). Format: one per line', 'perfmatters'),
            'class' => 'assets-minify_js' . (empty($perfmatters_options['assets']['minify_js']) ? ' hidden' : '')
        )
    );

    //clear minified js
    add_settings_field(
        'clear_minified_js', 
        perfmatters_title(__('Clear Minified JS', 'perfmatters'), false, 'https://perfmatters.io/docs/minify-javascript-wordpress/#clear'), 
        'perfmatters_print_input',
        'perfmatters_options', 
        'assets_js_minify', 
        array(
            'section' => 'assets',
            'id' => 'clear_minified_js',
            'input' => 'button',
            'action' => 'clear_minified_js',
            'title' => __('Clear Minified JS', 'perfmatters'),
            'class' => 'assets-minify_js' . (empty($perfmatters_options['assets']['minify_js']) ? ' hidden' : ''),
            'tooltip' => __('Remove all existing minified JavaScript files that have been generated.', 'perfmatters')
        )
    );

    //assets css section
    add_settings_section('assets_css', __('Unused', 'perfmatters'), '__return_false', 'perfmatters_options');

    //remove unused css
    add_settings_field(
        'remove_unused_css', 
        perfmatters_title(__('Remove Unused CSS', 'perfmatters'), 'assets-remove_unused_css', 'https://perfmatters.io/docs/remove-unused-css/#remove-unused-css'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css', 
        array(
            'id' => 'remove_unused_css',
            'section' => 'assets',
            'tooltip' => __('Remove unused CSS from your stylesheets and print out used CSS inline in the header.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //used css method
    add_settings_field(
        'rucss_method', 
        perfmatters_title(__('Used CSS Method', 'perfmatters'), 'assets-rucss_method', 'https://perfmatters.io/docs/remove-unused-css/#css-method'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css', 
        array(
            'id' => 'rucss_method',
            'section' => 'assets',
            'input' => 'select',
            'options' => array(
                '' => __('Inline', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                'file' => __('File', 'perfmatters')
            ),
            'tooltip' => __('Choose how the used CSS will be included.', 'perfmatters'),
            'class' => 'assets-remove_unused_css' . (empty($perfmatters_options['assets']['remove_unused_css']) ? ' hidden' : '')
        )
    );

    //unused css stylesheet behavior
    add_settings_field(
        'rucss_stylesheet_behavior', 
        perfmatters_title(__('Stylesheet Behavior', 'perfmatters'), 'assets-rucss_stylesheet_behavior', 'https://perfmatters.io/docs/remove-unused-css/#stylesheet-behavior'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css', 
        array(
            'id' => 'rucss_stylesheet_behavior',
            'section' => 'assets',
            'input' => 'select',
            'options' => array(
                '' => __('Delay', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                'async' => __('Async', 'perfmatters'),
                'remove' => __('Remove', 'perfmatters')
            ),
            'tooltip' => __('Choose how the original stylesheets (unused CSS) will be included.', 'perfmatters'),
            'class' => 'assets-remove_unused_css' . (empty($perfmatters_options['assets']['remove_unused_css']) ? ' hidden' : '')
        )
    );

    //remove unused css excluded stylesheets
    add_settings_field(
        'rucss_excluded_stylesheets', 
        perfmatters_title(__('Excluded Stylesheets', 'perfmatters'), 'assets-rucss_excluded_stylesheets', 'https://perfmatters.io/docs/remove-unused-css/#excluded-stylesheets'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css', 
        array(
            'id' => 'rucss_excluded_stylesheets',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'tooltip' => __('Exclude specific stylesheets from unused CSS removal by adding a unique portion of the source URL (example.css). Format: one per line', 'perfmatters'),
            'class' => 'assets-remove_unused_css' . (empty($perfmatters_options['assets']['remove_unused_css']) ? ' hidden' : '')
        )
    );

    //remove unused css excluded selectors
    add_settings_field(
        'rucss_excluded_selectors', 
        perfmatters_title(__('Excluded Selectors', 'perfmatters'), 'assets-rucss_excluded_selectors', 'https://perfmatters.io/docs/remove-unused-css/#excluded-selectors'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css', 
        array(
            'id' => 'rucss_excluded_selectors',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'tooltip' => __('Exclude specific CSS selectors from being removed by adding the element ID, class name, etc. (#id, .class). Format: one per line', 'perfmatters'),
            'class' => 'assets-remove_unused_css' . (empty($perfmatters_options['assets']['remove_unused_css']) ? ' hidden' : '')
        )
    );

    //inline excluded stylesheets
    add_settings_field(
        'rucss_inline_stylesheets', 
        perfmatters_title(__('Inline Excluded Stylesheets', 'perfmatters'), 'assets-rucss_inline_stylesheets', 'https://perfmatters.io/docs/remove-unused-css/#inline-excluded'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css', 
        array(
            'id' => 'rucss_inline_stylesheets',
            'section' => 'assets',
            'tooltip' => __('Inline the full contents of stylesheets that have been excluded from unused CSS removal.', 'perfmatters'),
            'class' => 'assets-remove_unused_css' . (empty($perfmatters_options['assets']['remove_unused_css']) ? ' hidden' : '') . ' pm-advanced-option'
        )
    );

    //cdn url
    add_settings_field(
        'rucss_cdn_url', 
        perfmatters_title(__('CDN URL', 'perfmatters'), 'assets-rucss_cdn_url', 'https://perfmatters.io/docs/remove-unused-css/#cdn-url'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css', 
        array(
            'id' => 'rucss_cdn_url',
            'section' => 'assets',
            'input' => 'text',
            'tooltip' => __('Provide your CDN URL if you are using a CDN rewrite outside of Perfmatters.', 'perfmatters'),
            'placeholder' => 'https://cdn.example.com',
            'class' => 'assets-remove_unused_css' . (empty($perfmatters_options['assets']['remove_unused_css']) ? ' hidden' : '') . ' pm-advanced-option'
        )
    );

    //clear used css
    add_settings_field(
        'clear_used_css', 
        perfmatters_title(__('Clear Used CSS', 'perfmatters'), false, 'https://perfmatters.io/docs/remove-unused-css/#clear-used-css'), 
        'perfmatters_print_input',
        'perfmatters_options', 
        'assets_css', 
        array(
            'section' => 'assets',
            'id' => 'clear_used_css',
            'input' => 'button',
            'action' => 'clear_used_css',
            'title' => __('Clear Used CSS', 'perfmatters'),
            'class' => 'assets-remove_unused_css' . (empty($perfmatters_options['assets']['remove_unused_css']) ? ' hidden' : ''),
            'tooltip' => __('Remove all existing used CSS files that have been generated.', 'perfmatters')
        )
    );

    //minify css
    add_settings_section('assets_css_minify', __('Minify', 'perfmatters'), '__return_false', 'perfmatters_options');

    //minify css
    add_settings_field(
        'minify_css', 
        perfmatters_title(__('Minify CSS', 'perfmatters'), 'assets-minify_css', 'https://perfmatters.io/docs/minify-css-wordpress/#minify'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css_minify', 
        array(
            'id' => 'minify_css',
            'section' => 'assets',
            'tooltip' => __('Remove unnecessary characters and optimize CSS files.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //minify css exclusions
    add_settings_field(
        'minify_css_exclusions', 
        perfmatters_title(__('Excluded from Minification', 'perfmatters'), 'assets-minify_css_exclusions', 'https://perfmatters.io/docs/minify-css-wordpress/#exclude'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_css_minify', 
        array(
            'id' => 'minify_css_exclusions',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'example.css',
            'tooltip' => __('Exclude specific CSS files from minification by adding the source URL (example.css). Format: one per line', 'perfmatters'),
            'class' => 'assets-minify_css' . (empty($perfmatters_options['assets']['minify_css']) ? ' hidden' : '')
        )
    );

    //clear minified css
    add_settings_field(
        'clear_minified_css', 
        perfmatters_title(__('Clear Minified CSS', 'perfmatters'), false, 'https://perfmatters.io/docs/minify-css-wordpress/#clear'), 
        'perfmatters_print_input',
        'perfmatters_options', 
        'assets_css_minify', 
        array(
            'section' => 'assets',
            'id' => 'clear_minified_css',
            'input' => 'button',
            'action' => 'clear_minified_css',
            'title' => __('Clear Minified CSS', 'perfmatters'),
            'class' => 'assets-minify_css' . (empty($perfmatters_options['assets']['minify_css']) ? ' hidden' : ''),
            'tooltip' => __('Remove all existing minified CSS files that have been generated.', 'perfmatters')
        )
    );

    //assets code section
    add_settings_section('assets_code', '', '__return_false', 'perfmatters_options');

    //header code
    add_settings_field(
        'header_code', 
        perfmatters_title(__('Add Header Code', 'perfmatters'), 'assets-header_code', 'https://perfmatters.io/docs/wordpress-add-code-to-header-footer/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_code', 
        array(
            'id' => 'header_code',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'codemirror',
            'tooltip' => __('Code added here will be printed in the head section on every page of your website.', 'perfmatters')
        )
    );

    //body code
    if(function_exists('wp_body_open') && version_compare(get_bloginfo('version'), '5.2' , '>=')) {

        add_settings_field(
            'body_code', 
            perfmatters_title(__('Add Body Code', 'perfmatters'), 'assets-body_code', 'https://perfmatters.io/docs/wordpress-add-code-to-header-footer/'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'assets_code', 
            array(
                'id' => 'body_code',
                'section' => 'assets',
                'input' => 'textarea',
                'textareatype' => 'codemirror',
                'tooltip' => __('Code added here will be printed below the opening body tag on every page of your website.', 'perfmatters')
            )
        );
    }

    //footer code
    add_settings_field(
        'footer_code', 
        perfmatters_title(__('Add Footer Code', 'perfmatters'), 'assets-footer_code', 'https://perfmatters.io/docs/wordpress-add-code-to-header-footer/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'assets_code', 
        array(
            'id' => 'footer_code',
            'section' => 'assets',
            'input' => 'textarea',
            'textareatype' => 'codemirror',
            'tooltip' => __('Code added here will be printed above the closing body tag on every page of your website.', 'perfmatters')
        )
    );

    /* preload section
    /**********************************************************/
    add_settings_section('preload', '', '__return_false', 'perfmatters_options');

    if(version_compare(get_bloginfo('version'), '6.8' , '<')) {

        //enable instant page
        add_settings_field(
            'instant_page', 
            perfmatters_title(__('Enable Instant Page', 'perfmatters'), 'preload-instant_page', 'https://perfmatters.io/docs/link-prefetch/'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'preload', 
            array(
                'id' => 'instant_page',
                'section' => 'preload',
                'tooltip' => __('Automatically prefetch URLs in the background after a user hovers over a link. This results in almost instantaneous load times and improves the user experience.', 'perfmatters')
            )
        );

    }

    //preload critical images
    add_settings_field(
        'critical_images', 
        perfmatters_title(__('Preload Critical Images', 'perfmatters'), 'preload-critical_images', 'https://perfmatters.io/docs/preload/#critical-images'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'preload', 
        array(
            'id' => 'critical_images',
            'section' => 'preload',
            'input' => 'select',
            'options' => array(
                '' => '0' . ' (' . __('Default', 'perfmatters') . ')',
                '1' => '1',
                '2' => '2',
                '3' => '3',
                '4' => '4',
                '5' => '5'
            ),
            'tooltip' => __('Automatically preload leading images to help improve Largest Contentful Paint (LCP).', 'perfmatters')
        )
    );

    //preload
    add_settings_field(
        'preload', 
        perfmatters_title(__('Preload', 'perfmatters'), false, 'https://perfmatters.io/docs/preload/'), 
        'perfmatters_print_input_rows', 
        'perfmatters_options', 
        'preload', 
        array(
            'id' => 'preload',
            'section' => 'preload',
            'tooltip' => __('Preload allows you to specify resources (such as fonts or CSS) needed right away during a page load. This helps fix render-blocking resource warnings. Format: https://example.com/font.woff2', 'perfmatters')
        )
    );

    //early hints
    add_settings_field(
        'early_hints', 
        perfmatters_title(__('Cloudflare Early Hints', 'perfmatters'), 'preload-early_hints', 'https://perfmatters.io/docs/early-hints'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'preload', 
        array(
            'id' => 'early_hints',
            'section' => 'preload',
            'tooltip' => __('Send early hint link headers for existing Perfmatters preloads.', 'perfmatters'),
            'class' => 'perfmatters-input-controller pm-advanced-option'
        )
    );

    //early hint types
    add_settings_field(
        'early_hint_types', 
        perfmatters_title(__('Early Hint Types', 'perfmatters'), false, 'https://perfmatters.io/docs/early-hints#types'), 
        'perfmatters_print_early_hint_types', 
        'perfmatters_options', 
        'preload', 
        array(
            'id' => 'early_hint_types',
            'section' => 'preload',
            'tooltip' => __('Choose which file types get early hint link headers.', 'perfmatters'),
            'class' => 'pm-advanced-option preload-early_hints' . (empty($perfmatters_options['preload']['early_hints']) ? ' hidden' : '')
        )
    );

    //fetch priority
    add_settings_field(
        'fetch_priority', 
        perfmatters_title(__('Fetch Priority', 'perfmatters'), false, 'https://perfmatters.io/docs/fetch-priority/'), 
        'perfmatters_print_input_rows', 
        'perfmatters_options', 
        'preload', 
        array(
            'id' => 'fetch_priority',
            'section' => 'preload',
            'tooltip' => __('Add the fetchpriority HTML attribute to a resource to proritize it higher or lower. This can help improve Largest Contentful Paint (LCP).', 'perfmatters')
        )
    );

    //disable core fetch
    add_settings_field(
        'disable_core_fetch', 
        perfmatters_title(__('Disable Core Fetch', 'perfmatters'), 'preload-disable_core_fetch', 'https://perfmatters.io/docs/fetch-priority/#disable-core'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'preload', 
        array(
            'id' => 'disable_core_fetch',
            'section' => 'preload',
            'tooltip' => __('Disable the fetch priority attribute added by WordPress core.', 'perfmatters'),
            'class' => 'pm-advanced-option'
        )
    );

    if(version_compare(get_bloginfo('version'), '6.8' , '>=')) {

        //speculative loading
        add_settings_section('preload_speculative', __('Speculative Loading', 'perfmatters'), '__return_false', 'perfmatters_options');

        //mode
        add_settings_field(
            'speculative_mode', 
            perfmatters_title(__('Mode', 'perfmatters'), 'preload-speculative_mode', 'https://perfmatters.io/docs/speculative-loading/#mode'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'preload_speculative', 
            array(
                'id' => 'speculative_mode',
                'section' => 'preload',
                'input' => 'select',
                'options' => array(
                    ''          => __('Auto', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                    'prefetch'  => __('Prefetch', 'perfmatters'),
                    'prerender' => __('Prerender', 'perfmatters'),
                    'disabled'  => __('Disabled', 'perfmatters')
                ),
                'tooltip' => __('Change the mode used for speculative loading.', 'perfmatters'),
                'class' => 'perfmatters-input-controller'
            )
        );

        //eagerness
        add_settings_field(
            'speculative_eagerness', 
            perfmatters_title(__('Eagerness', 'perfmatters'), 'preload-speculative_eagerness', 'https://perfmatters.io/docs/speculative-loading/#eagerness'), 
            'perfmatters_print_input', 
            'perfmatters_options', 
            'preload_speculative', 
            array(
                'id' => 'speculative_eagerness',
                'section' => 'preload',
                'input' => 'select',
                'options' => array(
                    ''             => __('Auto', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                    'conservative' => __('Conservative', 'perfmatters'),
                    'moderate'     => __('Moderate', 'perfmatters'),
                    'eager'        => __('Eager', 'perfmatters')
                ),
                'tooltip' => __('Change how aggressive speculative loading will behave.', 'perfmatters'),
                'class' => 'preload-speculative_mode perfmatters-select-control-disabled perfmatters-control-reverse' . (!empty($perfmatters_options['preload']['speculative_mode']) && $perfmatters_options['preload']['speculative_mode'] == 'disabled' ? ' hidden' : '')
            )
        );
    }

    //connection
    add_settings_section('preload_connection', __('Connection', 'perfmatters'), '__return_false', 'perfmatters_options');

    //preconnect
    add_settings_field(
        'preconnect', 
        perfmatters_title(__('Preconnect', 'perfmatters'), false, 'https://perfmatters.io/docs/preconnect/'), 
        'perfmatters_print_input_rows', 
        'perfmatters_options', 
        'preload_connection', 
        array(
            'id' => 'preconnect',
            'section' => 'preload',
            'tooltip' => __('Preconnect allows the browser to set up early connections before an HTTP request, eliminating roundtrip latency and saving time for users. Format: https://example.com', 'perfmatters')
        )
    );

    //dns prefetch
    add_settings_field(
        'dns_prefetch', 
        perfmatters_title(__('DNS Prefetch', 'perfmatters'), 'preload-dns_prefetch', 'https://perfmatters.io/docs/dns-prefetching/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'preload_connection', 
        array(
            'id' => 'dns_prefetch',
            'section' => 'preload',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => '//example.com',
            'tooltip' => __('Resolve domain names before a user clicks. Format: //example.com (one per line)', 'perfmatters')
        )
    );

    /* lazyload section
    /**********************************************************/
    add_settings_section('lazyload', '', '__return_false', 'perfmatters_options');

    //images
    add_settings_field(
        'lazy_loading', 
        perfmatters_title(__('Images', 'perfmatters'), 'lazyload-lazy_loading', 'https://perfmatters.io/docs/lazy-load-wordpress/#images'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'lazy_loading',
            'tooltip' => __('Enable lazy loading on images.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //exclude leading
    add_settings_field(
        'exclude_leading_images', 
        perfmatters_title(__('Exclude Leading Images', 'perfmatters'), 'lazyload-exclude_leading_images', 'https://perfmatters.io/docs/lazy-load-wordpress/#exclude-leading-images'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'exclude_leading_images',
            'input' => 'select',
            'options' => array(
                '' => '0' . ' (' . __('Default', 'perfmatters') . ')',
                '1' => '1',
                '2' => '2',
                '3' => '3',
                '4' => '4',
                '5' => '5'
            ),
            'tooltip' => __('Exclude a certain number of images starting from the top of the page.', 'perfmatters'),
            'class' => 'lazyload-lazy_loading' . (empty($perfmatters_options['lazyload']['lazy_loading']) ? ' hidden' : '')
        )
    );

    //iframes and videos
    add_settings_field(
        'lazy_loading_iframes', 
        perfmatters_title(__('iFrames and Videos', 'perfmatters'), 'lazyload-lazy_loading_iframes', 'https://perfmatters.io/docs/lazy-load-wordpress/#iframes-videos'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'lazy_loading_iframes',
            'tooltip' => __('Enable lazy loading on iframes and videos.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //youtube preview thumbnails
    add_settings_field(
        'youtube_preview_thumbnails', 
        perfmatters_title(__('YouTube Preview Thumbnails', 'perfmatters'), 'lazyload-youtube_preview_thumbnails', 'https://perfmatters.io/docs/lazy-load-wordpress/#youtube-preview-thumbnails'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'youtube_preview_thumbnails',
            'tooltip' => __('Swap out YouTube iFrames with preview thumbnails. The original iFrame is loaded when the thumbnail is clicked.', 'perfmatters'),
            'class' => 'lazyload-lazy_loading_iframes' . (empty($perfmatters_options['lazyload']['lazy_loading_iframes']) ? ' hidden' : '')
        )
    );

    //lazy load exclusions
    add_settings_field(
        'lazy_loading_exclusions', 
        perfmatters_title(__('Exclude from Lazy Loading', 'perfmatters'), 'lazyload-lazy_loading_exclusions', 'https://perfmatters.io/docs/lazy-load-wordpress/#exclude'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'lazy_loading_exclusions',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'example.png',
            'tooltip' => __('Exclude specific elements from lazy loading. Exclude an element by adding the source URL (example.png) or by adding any unique portion of its attribute string (class="example"). Format: one per line', 'perfmatters')
        )
    );

    //lazy load parent exclusions
    add_settings_field(
        'lazy_loading_parent_exclusions', 
        perfmatters_title(__('Exclude by Parent Selector', 'perfmatters'), 'lazyload-lazy_loading_parent_exclusions', 'https://perfmatters.io/docs/lazy-load-wordpress/#exclude-parent-selector'),
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'lazy_loading_parent_exclusions',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'example-div-class',
            'tooltip' => __('Exclude specific images from lazy loading by adding any unique portion of an attribute string (class="example") from a parent container. Format: one per line', 'perfmatters'),
            'class' => 'pm-advanced-option'
        )
    );

    //threshold
    add_settings_field(
        'threshold', 
        perfmatters_title(__('Threshold', 'perfmatters'), 'lazyload-threshold', 'https://perfmatters.io/docs/lazy-load-wordpress/#threshold'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'threshold',
            'input' => 'text',
            'validate' => '[0-9.pPxX%]',
            'placeholder' => '0px',
            'tooltip' => __('Extend the lazy loading threshold allowing images to load before they are visible in the viewport. (px or %)', 'perfmatters')
        )
    );

    //DOM monitoring
    add_settings_field(
        'lazy_loading_dom_monitoring', 
        perfmatters_title(__('DOM Monitoring', 'perfmatters'), 'lazyload-lazy_loading_dom_monitoring', 'https://perfmatters.io/docs/lazy-load-wordpress/#dom-monitoring'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'lazy_loading_dom_monitoring',
            'tooltip' => __('Watch for changes in the DOM and dynamically lazy load newly added elements.', 'perfmatters')
        )
    );

    //image dimensions
    add_settings_field(
        'image_dimensions', 
        perfmatters_title(__('Add Image Dimensions', 'perfmatters'), 'lazyload-image_dimensions', 'https://perfmatters.io/docs/missing-width-height-images/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'image_dimensions',
            'tooltip' => __('Add missing width and height attributes to images.', 'perfmatters')
        )
    );

    //fade in
    add_settings_field(
        'fade_in', 
        perfmatters_title(__('Fade In', 'perfmatters'), 'lazyload-fade_in', 'https://perfmatters.io/docs/lazy-load-wordpress/#fade-in'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload', 
        array(
            'section' => 'lazyload',
            'id' => 'fade_in',
            'tooltip' => __('Add fade in effect when images are loaded in.', 'perfmatters')
        )
    );

    //lazy elements
    add_settings_section('lazyload_css_background_images', __('CSS Background Images', 'perfmatters'), '__return_false', 'perfmatters_options');

    //css background images
    add_settings_field(
        'css_background_images', 
        perfmatters_title(__('Background Images', 'perfmatters'), 'lazyload-css_background_images', 'https://perfmatters.io/docs/lazy-load-wordpress/#css-background-images'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload_css_background_images', 
        array(
            'section' => 'lazyload',
            'id' => 'css_background_images',
            'tooltip' => __('Allow lazy loading of background images coming from (CSS) stylesheets.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //css background selectors
    add_settings_field(
        'css_background_selectors', 
        perfmatters_title(__('Background Selectors', 'perfmatters'), 'lazyload-css_background_selectors', 'https://perfmatters.io/docs/lazy-load-wordpress/#css-background-images'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload_css_background_images', 
        array(
            'section' => 'lazyload',
            'id' => 'css_background_selectors',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'div-background-class',
            'tooltip' => __('Lazy load a CSS background image by adding a unique selector (ID or class) found on the element that the background image has been applied to. Format: one per line', 'perfmatters'),
            'class' => 'lazyload-css_background_images' . (empty($perfmatters_options['lazyload']['css_background_images']) ? ' hidden' : '')
        )
    );

    //exclude leading
    add_settings_field(
        'css_background_exclude_leading', 
        perfmatters_title(__('Exclude Leading', 'perfmatters'), 'lazyload-css_background_exclude_leading', 'https://perfmatters.io/docs/lazy-load-wordpress/#css-background-exclude-leading'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload_css_background_images', 
        array(
            'section' => 'lazyload',
            'id' => 'css_background_exclude_leading',
            'input' => 'select',
            'options' => array(
                '' => '0' . ' (' . __('Default', 'perfmatters') . ')',
                '1' => '1',
                '2' => '2',
                '3' => '3',
                '4' => '4',
                '5' => '5'
            ),
            'tooltip' => __('Exclude a certain number of background image containers from being lazy loaded starting from the first match.', 'perfmatters'),
            'class' => 'lazyload-css_background_images' . (empty($perfmatters_options['lazyload']['css_background_images']) ? ' hidden' : '')
        )
    );

    //lazy elements
    add_settings_section('lazyload_elements', __('Lazy Elements', 'perfmatters'), '__return_false', 'perfmatters_options');

    //elements
    add_settings_field(
        'elements', 
        perfmatters_title(__('Elements', 'perfmatters'), 'lazyload-elements', 'https://perfmatters.io/docs/lazy-load-elements/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload_elements', 
        array(
            'section' => 'lazyload',
            'id' => 'elements',
            'tooltip' => __('Allow lazy loading of elements in the DOM.', 'perfmatters'),
            'class' => 'perfmatters-input-controller'
        )
    );

    //element selectors
    add_settings_field(
        'element_selectors', 
        perfmatters_title(__('Element Selectors', 'perfmatters'), 'lazyload-element_selectors', 'https://perfmatters.io/docs/lazy-load-elements/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'lazyload_elements', 
        array(
            'section' => 'lazyload',
            'id' => 'element_selectors',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => 'div-background-class',
            'tooltip' => __('Lazy load specific elements and their descendants by adding any unique portion of an attribute string (class="example") from a parent container. Format: one per line', 'perfmatters'),
            'class' => 'lazyload-elements' . (empty($perfmatters_options['lazyload']['elements']) ? ' hidden' : '')
        )
    );

    /* fonts section
    /**********************************************************/
    add_settings_section('perfmatters_fonts', '', '__return_false', 'perfmatters_options');

    //local google fonts
    add_settings_field(
        'local_google_fonts', 
        perfmatters_title(__('Local Google Fonts', 'perfmatters'), 'fonts-local_google_fonts', 'https://perfmatters.io/docs/host-google-fonts-locally/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_fonts', 
        array(
            'section' => 'fonts',
            'id' => 'local_google_fonts',
            'class' => 'perfmatters-input-controller fonts-disable_google_fonts' . (!empty($perfmatters_options['fonts']['disable_google_fonts']) ? ' hidden' : ''),
            'tooltip' => __('Host Google Font files locally on your server or CDN.', 'perfmatters')
        )
    );

    //display swap
    add_settings_field(
        'display_swap', 
        perfmatters_title(__('Display Swap', 'perfmatters'), 'fonts-display_swap', 'https://perfmatters.io/docs/font-display-swap/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_fonts', 
        array(
            'section' => 'fonts',
            'id' => 'display_swap',
            'class' => 'fonts-disable_google_fonts' . (!empty($perfmatters_options['fonts']['disable_google_fonts']) ? ' hidden' : ''),
            'tooltip' => __('Add the font-display swap property to your Google Fonts.', 'perfmatters')
        )
    );

    //method
    add_settings_field(
        'method', 
        perfmatters_title(__('Print Method', 'perfmatters'), 'fonts-method', 'https://perfmatters.io/docs/host-google-fonts-locally/#print-method'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_fonts', 
        array(
            'section' => 'fonts',
            'id' => 'method',
            'class' => 'fonts-disable_google_fonts fonts-local_google_fonts' . (!empty($perfmatters_options['fonts']['disable_google_fonts']) || empty($perfmatters_options['fonts']['local_google_fonts']) ? ' hidden' : ''),
            'input' => 'select',
            'options' => array(
                '' => __('File', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                'inline' => __('Inline', 'perfmatters')
            ),
            'tooltip' => __('Choose how the local font stylesheet will be included.', 'perfmatters')
        )
    );

    //limit subsets
    add_settings_field(
        'limit_subsets', 
        perfmatters_title(__('Limit Subsets', 'perfmatters'), 'fonts-limit_subsets', 'https://perfmatters.io/docs/limit-google-fonts-subsets/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_fonts', 
        array(
            'section' => 'fonts',
            'id' => 'limit_subsets',
            'class' => 'perfmatters-input-controller fonts-disable_google_fonts fonts-local_google_fonts' . (!empty($perfmatters_options['fonts']['disable_google_fonts']) || empty($perfmatters_options['fonts']['local_google_fonts']) ? ' hidden' : ''),
            'tooltip' => __('Limit subsets that are downloaded and included in the stylesheet.', 'perfmatters')
        )
    );

    //subsets
    add_settings_field(
        'subsets', 
        perfmatters_title(__('Allowed Subsets', 'perfmatters'), false, 'https://perfmatters.io/docs/limit-google-fonts-subsets/'), 
        'perfmatters_print_subsets', 
        'perfmatters_options', 
        'perfmatters_fonts', 
        array(
            'section' => 'fonts',
            'id' => 'subsets',
            'class' => 'fonts-disable_google_fonts fonts-local_google_fonts fonts-limit_subsets' . (!empty($perfmatters_options['fonts']['disable_google_fonts']) || empty($perfmatters_options['fonts']['local_google_fonts']) || empty($perfmatters_options['fonts']['limit_subsets']) ? ' hidden' : ''),
            'tooltip' => __('Choose which subsets to download locally.', 'perfmatters')
        )
    );

    //cdn url
    add_settings_field(
        'cdn_url', 
        perfmatters_title(__('CDN URL', 'perfmatters'), 'fonts-cdn_url', 'https://perfmatters.io/docs/host-google-fonts-locally/#cdn'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_fonts', 
        array(
            'section' => 'fonts',
            'id' => 'cdn_url',
            'input' => 'text',
            'class' => 'fonts-disable_google_fonts fonts-local_google_fonts' . (!empty($perfmatters_options['fonts']['disable_google_fonts']) || empty($perfmatters_options['fonts']['local_google_fonts']) ? ' hidden' : ''),
            'placeholder' => 'https://cdn.example.com',
            'tooltip' => __('Use your CDN URL when referencing Google Font files inside a parent stylesheet. Example: https://cdn.example.com', 'perfmatters')
        )
    );

    //clear fonts
    add_settings_field(
        'clear_fonts', 
        perfmatters_title(__('Clear Local Fonts', 'perfmatters'), false, 'https://perfmatters.io/docs/host-google-fonts-locally/#clear-local-fonts'), 
        'perfmatters_print_input',
        'perfmatters_options', 
        'perfmatters_fonts', 
        array(
            'section' => 'fonts',
            'id' => 'clear_fonts',
            'input' => 'button',
            'action' => 'clear_local_fonts',
            'title' => __('Clear Local Fonts', 'perfmatters'),
            'class' => 'fonts-disable_google_fonts fonts-local_google_fonts' . (!empty($perfmatters_options['fonts']['disable_google_fonts']) || empty($perfmatters_options['fonts']['local_google_fonts']) ? ' hidden' : ''),
            'tooltip' => __('Remove all existing local Google Font files and stylesheets.', 'perfmatters')
        )
    );

    //disable google fonts
    add_settings_field(
        'disable_google_fonts', 
        perfmatters_title(__('Disable Google Fonts', 'perfmatters'), 'fonts-disable_google_fonts', 'https://perfmatters.io/docs/disable-google-fonts/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_fonts', 
        array(
            'section' => 'fonts',
            'id' => 'disable_google_fonts',
            'class' => 'perfmatters-input-controller',
            'tooltip' => __('Removes any instances of Google Fonts being loaded across your entire site.', 'perfmatters')
        )
    );

    /* cdn section
    /**********************************************************/
    add_settings_section('perfmatters_cdn', '', '__return_false', 'perfmatters_options');

    //enable cdn rewrite
    add_settings_field(
        'enable_cdn', 
        perfmatters_title(__('Enable CDN Rewrite', 'perfmatters'), 'cdn-enable_cdn', 'https://perfmatters.io/docs/cdn-rewrite/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_cdn', 
        array(
            'section' => 'cdn',
            'id' => 'enable_cdn',
            'tooltip' => __('Enables rewriting of your site URLs with your CDN URLs which can be configured below.', 'perfmatters')
        )
    );

    //cdn url
    add_settings_field(
        'cdn_url', 
        perfmatters_title(__('CDN URL', 'perfmatters'), 'cdn-cdn_url', 'https://perfmatters.io/docs/cdn-url/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_cdn', 
        array(
            'section' => 'cdn',
            'id' => 'cdn_url',
            'input' => 'text',
            'placeholder' => 'https://cdn.example.com',
            'tooltip' => __('Enter your CDN URL without the trailing backslash. Example: https://cdn.example.com', 'perfmatters')
        )
    );

    //cdn included directories
    add_settings_field(
        'cdn_directories', 
        perfmatters_title(__('Included Directories', 'perfmatters'), 'cdn-cdn_directories', 'https://perfmatters.io/docs/cdn-included-directories/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_cdn', 
        array(
            'section' => 'cdn',
            'id' => 'cdn_directories',
            'input' => 'text',
            'placeholder' => 'wp-content,wp-includes',
            'tooltip' => __('Enter any directories you would like to be included in CDN rewriting, separated by commas (,). Default: wp-content,wp-includes', 'perfmatters')
        )
    );

    //cdn exclusions
    add_settings_field(
        'cdn_exclusions', 
        perfmatters_title(__('CDN Exclusions', 'perfmatters'), 'cdn-cdn_exclusions', 'https://perfmatters.io/docs/cdn-exclusions/'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_cdn', 
        array(
            'section' => 'cdn',
            'id' => 'cdn_exclusions',
            'input' => 'text',
            'placeholder' => '.php',
            'tooltip' => __('Enter any directories or file extensions you would like to be excluded from CDN rewriting, separated by commas (,). Default: .php', 'perfmatters')
        )
    );

    /* analytics section
    /**********************************************************/
    add_settings_section('perfmatters_analytics', '', '__return_false', 'perfmatters_options');

    //enable local ga
    add_settings_field(
        'enable_local_ga', 
        perfmatters_title(__('Enable Local Analytics', 'perfmatters'), 'analytics-enable_local_ga', 'https://perfmatters.io/docs/local-analytics/'),
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_analytics', 
        array(
            'section' => 'analytics',
            'id' => 'enable_local_ga',
            'tooltip' => __('Enable syncing of the Google Analytics script to your own server.', 'perfmatters')
        )
    );

    //google analytics id
    add_settings_field(
        'tracking_id', 
        perfmatters_title(__('Tracking ID', 'perfmatters'), 'analytics-tracking_id', 'https://perfmatters.io/docs/local-analytics/#trackingid'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_analytics', 
        array(
            'section' => 'analytics',
            'id' => 'tracking_id',
            'input' => 'text',
            'tooltip' => __('Input your Google Analytics tracking or measurement ID.', 'perfmatters')
        )
    );

    //tracking code position
    add_settings_field(
        'tracking_code_position', 
        perfmatters_title(__('Tracking Code Position', 'perfmatters'), 'analytics-tracking_code_position', 'https://perfmatters.io/docs/local-analytics/#trackingcodeposition'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_analytics', 
        array(
            'section' => 'analytics',
            'id' => 'tracking_code_position',
            'input' => 'select',
            'options' => array(
                "" => __('Header', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                "footer" => __('Footer', 'perfmatters')
                ),
            'tooltip' => __('Load your analytics script in the header (default) or footer of your site. Default: Header', 'perfmatters')
        )
    );

    //script type
    add_settings_field(
        'script_type', 
        perfmatters_title(__('Script Type', 'perfmatters'), 'analytics-script_type', 'https://perfmatters.io/docs/local-analytics/#script-type'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_analytics', 
        array(
            'section' => 'analytics',
            'id' => 'script_type',
            'input' => 'select',
            'options' => array(
                '' => 'Google Analytics 4' . ' (' . __('Default', 'perfmatters') . ')',
                'minimalv4' => 'Google Analytics 4 Minimal'
            ),
            'class' => 'perfmatters-input-controller',
            'tooltip' => __('Choose which script method you would like to use. Default Google Analytics 4 is larger and includes all features, while Minimal is smaller and only includes basic reporting features.', 'perfmatters')
        )
    );

    //track logged in admins
    add_settings_field(
        'track_admins', 
        perfmatters_title(__('Track Logged In Admins', 'perfmatters'), 'analytics-track_admins', 'https://perfmatters.io/docs/local-analytics/#track-logged-in-admins'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_analytics', 
        array(
            'section' => 'analytics',
            'id' => 'track_admins',
            'tooltip' => __('Include logged-in WordPress admins in your Google Analytics reports.', 'perfmatters')
        )
    );

    //use monsterinsights
    add_settings_field(
        'use_monster_insights', 
        perfmatters_title(__('Use MonsterInsights', 'perfmatters'), 'analytics-use_monster_insights', 'https://perfmatters.io/docs/local-analytics/#monster-insights'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_analytics', 
        array(
            'section' => 'analytics',
            'id' => 'use_monster_insights',
            'class' => 'analytics-script_type perfmatters-select-control- ' . (!empty($perfmatters_options['analytics']['script_type']) ? ' hidden' : ''),
            'tooltip' => __('Allows MonsterInsights to manage your Google Analytics while still using the locally hosted gtag.js file generated by Perfmatters.', 'perfmatters')
        )
    );

    //enable amp support
    add_settings_field(
        'enable_amp', 
        perfmatters_title(__('Enable AMP Support', 'perfmatters'), 'analytics-enable_amp', 'https://perfmatters.io/docs/local-analytics/#amp'), 
        'perfmatters_print_input', 
        'perfmatters_options', 
        'perfmatters_analytics', 
        array(
            'section' => 'analytics',
            'id' => 'enable_amp',
            'tooltip' => __('Enable support for analytics tracking on AMP sites. This is not a local script, but a native AMP script.', 'perfmatters')
        )
    );

    //page cache
    add_settings_section('cache_page', __('Page Cache', 'perfmatters'), '__return_false', 'perfmatters_options');

    if(Perfmatters\Cache::disk_available()) {

        //enable page cache
        add_settings_field(
            'page',
            perfmatters_title(__('Enable Page Cache', 'perfmatters'), 'cache-page', 'https://perfmatters.io/docs/page-cache/#enable'),
            'perfmatters_print_input',
            'perfmatters_options',
            'cache_page',
            array(
                'section' => 'cache',
                'id' => 'page',
                'class' => 'perfmatters-input-controller',
                'tooltip' => __('Cache public pages as static HTML and serve them to visitors.', 'perfmatters')
            )
        );

        //cache expires
        add_settings_field(
            'page_ttl',
            perfmatters_title(__('Cache Expires', 'perfmatters'), 'cache-page_ttl', 'https://perfmatters.io/docs/page-cache/#expires'),
            'perfmatters_print_input',
            'perfmatters_options',
            'cache_page',
            array(
                'section' => 'cache',
                'id' => 'page_ttl',
                'input' => 'select',
                'options' => Perfmatters\Cache\Config::cache_ttl_choices(),
                'class' => 'cache-page ' . (empty($perfmatters_options['cache']['page']) ? ' hidden' : ''),
                'tooltip' => __('Choose how long cached HTML is kept before it is deleted.', 'perfmatters')
            )
        );

        //separate mobile cache
        add_settings_field(
            'page_mobile',
            perfmatters_title(__('Separate Mobile', 'perfmatters'), 'cache-page_mobile', 'https://perfmatters.io/docs/page-cache/#mobile'),
            'perfmatters_print_input',
            'perfmatters_options',
            'cache_page',
            array(
                'section' => 'cache',
                'id' => 'page_mobile',
                'class' => 'cache-page ' . (empty($perfmatters_options['cache']['page']) ? ' hidden' : ''),
                'tooltip' => __('Store a separate HTML file for mobile visitors. Most responsive themes can leave this off.', 'perfmatters')
            )
        );
    }
    else {

        //placeholder row — real Enable field stays off the form while disk cannot run
        add_settings_field(
            'page_disabled',
            perfmatters_title(__('Page Cache Disabled', 'perfmatters'), 'cache-page-disabled', 'https://perfmatters.io/docs/page-cache/#enable'),
            array('Perfmatters\Cache', 'print_page_disabled_field'),
            'perfmatters_options',
            'cache_page',
            array(
                'class' => 'perfmatters-cache-page-disabled-row'
            )
        );
    }

    //cache warmer
    add_settings_section('cache_warmer', __('Warmer', 'perfmatters'), '__return_false', 'perfmatters_options');
    
    //cache warmer
    add_settings_field(
        'warmer',
        perfmatters_title(__('Cache Warmer', 'perfmatters'), 'cache-warmer', 'https://perfmatters.io/docs/warm-cache/#enable'),
        'perfmatters_print_input',
        'perfmatters_options',
        'cache_warmer',
        array(
            'section' => 'cache',
            'id' => 'warmer',
            'class' => 'perfmatters-input-controller',
            'tooltip' => __('Request public pages ahead of visitors so the next visit is served from cache. Works with Perfmatters page cache, host page cache, or a CDN (Cloudflare).', 'perfmatters')
        )
    );

    //warmer schedule
    add_settings_field(
        'warmer_schedule',
        perfmatters_title(__('Schedule', 'perfmatters'), 'cache-warmer_schedule', 'https://perfmatters.io/docs/warm-cache/#schedule'),
        'perfmatters_print_input',
        'perfmatters_options',
        'cache_warmer',
        array(
            'section' => 'cache',
            'id' => 'warmer_schedule',
            'input' => 'select',
            'options' => array(
                '' => __('None', 'perfmatters') . ' (' . __('Default', 'perfmatters') . ')',
                'hourly' => __('Hourly', 'perfmatters'),
                'twicedaily' => __('Twice Daily', 'perfmatters'),
                'daily' => __('Daily', 'perfmatters'),
                'weekly' => __('Weekly', 'perfmatters')
            ),
            'class' => 'cache-warmer ' . (empty($perfmatters_options['cache']['warmer']) ? ' hidden' : ''),
            'tooltip' => __('Choose how often the warmer runs a full crawl.', 'perfmatters')
        )
    );

    //warmer sources
    add_settings_field(
        'warmer_sources',
        perfmatters_title(__('Sources', 'perfmatters'), 'cache-warmer_sources', 'https://perfmatters.io/docs/warm-cache/#sources'),
        'perfmatters_print_warmer_sources',
        'perfmatters_options',
        'cache_warmer',
        array(
            'class' => 'cache-warmer ' . (empty($perfmatters_options['cache']['warmer']) ? ' hidden' : ''),
            'tooltip' => __('Choose which content the warmer requests.', 'perfmatters')
        )
    );

    //cloudflare
    add_settings_section('cache_cloudflare', __('Cloudflare', 'perfmatters'), '__return_false', 'perfmatters_options');

    //cloudflare edge cache (HTML + static Cache Rules)
    add_settings_field(
        'cloudflare',
        perfmatters_title(__('Cloudflare Edge Cache', 'perfmatters'), 'cache-cloudflare', 'https://perfmatters.io/docs/cloudflare-edge-cache/#enable'),
        'perfmatters_print_cloudflare',
        'perfmatters_options',
        'cache_cloudflare',
        array(
            'section' => 'cache',
            'id' => 'cloudflare',
            'class' => 'perfmatters-input-controller',
            'tooltip' => __('Cache HTML and static assets at Cloudflare edge.', 'perfmatters')
        )
    );

    //cloudflare api token
    add_settings_field(
        'cf_api_token',
        perfmatters_title(__('API Token', 'perfmatters'), 'cache-cf_api_token', 'https://perfmatters.io/docs/cloudflare-edge-cache/#api-token'),
        'perfmatters_print_cf_api_token',
        'perfmatters_options',
        'cache_cloudflare',
        array(
            'section' => 'cache',
            'id' => 'cf_api_token',
            'class' => 'cache-cloudflare ' . (empty($perfmatters_options['cache']['cloudflare']) ? ' hidden' : ''),
            'tooltip' => __('Enter a Cloudflare API token for this zone.', 'perfmatters')
        )
    );

    //cloudflare zone id
    add_settings_field(
        'cf_zone_id',
        perfmatters_title(__('Zone ID', 'perfmatters'), 'cache-cf_zone_id', 'https://perfmatters.io/docs/cloudflare-edge-cache/#zone-id'),
        'perfmatters_print_cf_zone_id',
        'perfmatters_options',
        'cache_cloudflare',
        array(
            'section' => 'cache',
            'id' => 'cf_zone_id',
            'input' => 'text',
            'placeholder' => 'auto',
            'class' => 'cache-cloudflare ' . (empty($perfmatters_options['cache']['cloudflare']) ? ' hidden' : ''),
            'tooltip' => __('Leave blank to detect this site\'s Cloudflare zone. Enter an ID when the token can access more than one zone.', 'perfmatters')
        )
    );

    //cloudflare edge html expires (CDN-Cache-Control max-age; Cache Rules stay bypass_by_default)
    add_settings_field(
        'cf_edge_ttl',
        perfmatters_title(__('Expires', 'perfmatters'), 'cache-cf_edge_ttl', 'https://perfmatters.io/docs/cloudflare-edge-cache/#expires'),
        'perfmatters_print_input',
        'perfmatters_options',
        'cache_cloudflare',
        array(
            'section' => 'cache',
            'id' => 'cf_edge_ttl',
            'input' => 'select',
            'options' => Perfmatters\Cache\Cloudflare::edge_ttl_choices(),
            'class' => 'cache-cloudflare ' . (empty($perfmatters_options['cache']['cloudflare']) ? ' hidden' : ''),
            'tooltip' => __('Choose how long Cloudflare keeps HTML at the edge.', 'perfmatters')
        )
    );

    //cache rules
    add_settings_section('cache_rules', '', '__return_false', 'perfmatters_options');

    //excluded urls
    add_settings_field(
        'excluded_urls',
        perfmatters_title(__('Excluded URLs', 'perfmatters'), 'cache-excluded_urls', 'https://perfmatters.io/docs/cache-rules/#excluded-urls'),
        'perfmatters_print_input',
        'perfmatters_options',
        'cache_rules',
        array(
            'section' => 'cache',
            'id' => 'excluded_urls',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => "/members/\n/campaign/",
            'tooltip' => __('Exclude specific paths from caching. A request is skipped when its path contains the line. Format: one per line', 'perfmatters')
        )
    );

    //bypass cookies
    add_settings_field(
        'bypass_cookies',
        perfmatters_title(__('Bypass Cookies', 'perfmatters'), 'cache-bypass_cookies', 'https://perfmatters.io/docs/cache-rules/#bypass-cookies'),
        'perfmatters_print_input',
        'perfmatters_options',
        'cache_rules',
        array(
            'section' => 'cache',
            'id' => 'bypass_cookies',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => "membership_\nwishlist_",
            'tooltip' => __('Exclude requests that send these cookies. A request is skipped when a cookie name starts with the line. Format: one per line', 'perfmatters')
        )
    );

    //purge urls
    add_settings_field(
        'purge_urls',
        perfmatters_title(__('Always Purge URLs', 'perfmatters'), 'cache-purge_urls', 'https://perfmatters.io/docs/cache-rules/#always-purge-urls'),
        'perfmatters_print_input',
        'perfmatters_options',
        'cache_rules',
        array(
            'section' => 'cache',
            'id' => 'purge_urls',
            'input' => 'textarea',
            'textareatype' => 'oneperline',
            'placeholder' => "/recent/\n/landing/",
            'tooltip' => __('Purge these pages whenever any post or page is updated. Format: one per line', 'perfmatters')
        )
    );

    //disk-only cache key variants — same omit pattern as Page Cache fields when disk is unavailable
    if(Perfmatters\Cache::disk_available()) {

        //query strings
        add_settings_field(
            'query_strings',
            perfmatters_title(__('Cache Query Strings', 'perfmatters'), 'cache-query_strings', 'https://perfmatters.io/docs/cache-rules/#cache-query-strings'),
            'perfmatters_print_input',
            'perfmatters_options',
            'cache_rules',
            array(
                'section' => 'cache',
                'id' => 'query_strings',
                'input' => 'textarea',
                'textareatype' => 'oneperline',
                'placeholder' => "orderby\nfilter",
                'tooltip' => __('Store a separate cache file for these query parameters. Parameters that are not listed skip the cache. Format: one per line', 'perfmatters')
            )
        );
    }

    register_setting('perfmatters_options', 'perfmatters_options', 'perfmatters_sanitize_options');

    //tools plugin section
    add_settings_section('plugin', __('Plugin', 'perfmatters'), '__return_false', 'perfmatters_tools');

    //script manager
    add_settings_field(
        'script_manager', 
        perfmatters_title(__('Script Manager', 'perfmatters'), 'script_manager', 'https://perfmatters.io/docs/disable-scripts-per-post-page/'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'plugin', 
        array(
            'id' => 'script_manager',
            'option' => 'perfmatters_tools',
            'tooltip' => __('Enables the Perfmatters Script Manager, which gives you the ability to disable CSS and JS files on a page by page basis.', 'perfmatters')
        )
    );

    //show advanced options
    add_settings_field(
        'show_advanced', 
        perfmatters_title(__('Show Advanced Options', 'perfmatters'), 'show_advanced', 'https://perfmatters.io/docs/advanced-options/'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'plugin', 
        array(
            'id' => 'show_advanced',
            'option' => 'perfmatters_tools',
            'tooltip' => __('Show advanced options in the Perfmatters UI.', 'perfmatters'),
            'confirmation' => __('Advanced options should only be used if you know exactly what you are doing, as they can break certain plugin functionality if used improperly.', 'perfmatters'),
        )
    );

    //disable while logged in
    add_settings_field(
        'disable_logged_in', 
        perfmatters_title(__('Disable for Logged In Users', 'perfmatters'), 'disable_logged_in', 'https://perfmatters.io/docs/disable-logged-in-users/'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'plugin', 
        array(
            'id' => 'disable_logged_in',
            'option' => 'perfmatters_tools',
            'tooltip' => __('Disable optimizations for logged in users.', 'perfmatters')
        )
    );

    //hide admin bar menu
    add_settings_field(
        'hide_admin_bar_menu', 
        perfmatters_title(__('Hide Admin Bar Menu', 'perfmatters'), 'hide_admin_bar_menu', 'https://perfmatters.io/docs/hide-admin-bar-menu/'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'plugin', 
        array(
            'id' => 'hide_admin_bar_menu',
            'option' => 'perfmatters_tools',
            'tooltip' => __('Hide the Perfmatters menu in the admin bar.', 'perfmatters')
        )
    );

    //safe mode
    add_settings_field(
        'safe_mode', 
        perfmatters_title(__('Safe Mode', 'perfmatters'), 'safe_mode', 'https://perfmatters.io/docs/test-perfmatters-off/#safe-mode'), 
        'perfmatters_print_input',
        'perfmatters_tools', 
        'plugin', 
        array(
            'id' => 'safe_mode',
            'option' => 'perfmatters_tools',
            'tooltip' => __('Disable all Perfmatters optimizations sitewide for troubleshooting. Security-related options and code snippets will remain active.', 'perfmatters')
        )
    );

    //accessibility mode
    add_settings_field(
        'accessibility_mode', 
        perfmatters_title(__('Accessibility Mode', 'perfmatters'), 'accessibility_mode', 'https://perfmatters.io/docs/accessibility-mode/'), 
        'perfmatters_print_input',
        'perfmatters_tools', 
        'plugin', 
        array(
            'id' => 'accessibility_mode',
            'input' => 'checkbox',
            'option' => 'perfmatters_tools',
            'tooltip' => __('Disable the use of visual UI elements in the plugin settings such as checkbox toggles and hovering tooltips.', 'perfmatters')
        )
    );

    //settings
    add_settings_section('settings', __('Settings', 'perfmatters'), '__return_false', 'perfmatters_tools');

    if(!is_multisite()) {

        //clean uninstall
        add_settings_field(
            'clean_uninstall', 
            perfmatters_title(__('Clean Uninstall', 'perfmatters'), 'clean_uninstall', 'https://perfmatters.io/docs/clean-uninstall/'), 
            'perfmatters_print_input', 
            'perfmatters_tools', 
            'settings', 
            array(
                'id' => 'clean_uninstall',
                'option' => 'perfmatters_tools',
                'tooltip' => __('When enabled, this will cause all Perfmatters options data to be removed from your database when the plugin is uninstalled.', 'perfmatters')
            )
        );
    }

    //restore defaults
    add_settings_field(
        'restore_defaults', 
        perfmatters_title(__('Restore Default Options', 'perfmatters'), false, 'https://perfmatters.io/docs/restore-default-options/'), 
        'perfmatters_print_input',
        'perfmatters_tools', 
        'settings', 
        array(
            'id'      => 'restore_defaults',
            'input'   => 'button',
            'action'  => 'restore_defaults',
            'title'   => __('Restore Default Options', 'perfmatters'),
            'confirmation' => __('Are you sure? This will remove all existing plugin options and restore them to their default states.', 'perfmatters'),
            'option'  => 'perfmatters_tools',
            'tooltip' => __('Restore all plugin options to their default settings.', 'perfmatters')
        )
    );

    //purge meta options
    add_settings_field(
        'purge_meta', 
        perfmatters_title(__('Purge Meta Options', 'perfmatters'), false, 'https://perfmatters.io/docs/purge-meta-options/'), 
        'perfmatters_print_purge_meta', 
        'perfmatters_tools', 
        'settings', 
        array(
            'id'           => 'purge_meta',
            'input'        => 'button',
            'option'       => 'perfmatters_tools',
            'title'        => __('Purge Meta Options', 'perfmatters'),
            'confirmation' => __('Are you sure? This will delete all existing Perfmatters meta options for all posts from the database.', 'perfmatters'),
            'tooltip'      => __('Permanently delete all existing Perfmatters meta options from your database.', 'perfmatters')
        )
    );

    //export settings
    add_settings_field(
        'export_settings', 
        perfmatters_title(__('Export Settings', 'perfmatters'), false, 'https://perfmatters.io/docs/import-export/'), 
        'perfmatters_print_input',
        'perfmatters_tools', 
        'settings', 
        array(
            'id' => 'export_settings',
            'input' => 'button',
            'action' => 'export_settings',
            'title' => __('Export Plugin Settings', 'perfmatters'),
            'option' => 'perfmatters_tools',
            'tooltip' => __('Export your Perfmatters settings for this site as a .json file. This lets you easily import the configuration into another site.', 'perfmatters')
        )
    );

    //import settings
    add_settings_field(
        'import_settings', 
        perfmatters_title(__('Import Settings', 'perfmatters'), false, 'https://perfmatters.io/docs/import-export/'), 
        'perfmatters_print_import_settings',
        'perfmatters_tools', 
        'settings', 
        array(
            'tooltip' => __('Import Perfmatters settings from an exported .json file.', 'perfmatters')
        )
    );

    //database section
    add_settings_section('database', '', '__return_false', 'perfmatters_tools');

    //optimize database
    add_settings_field(
        'scan_database', 
        perfmatters_title(__('Scan Database', 'perfmatters'), false, 'https://perfmatters.io/docs/optimize-wordpress-database/#scan'), 
        'perfmatters_print_input',
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'scan_database',
            'input' => 'button',
            'action' => 'scan_database',
            'title' => __('Scan Now', 'perfmatters'),
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Scan the database to calculate items available for optimization.', 'perfmatters')
        )
    );

    //post revisions
    add_settings_field(
        'post_revisions', 
        perfmatters_title(__('Post Revisions', 'perfmatters'), 'database-post_revisions', 'https://perfmatters.io/docs/wordpress-post-revisions/'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'post_revisions',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Include post revisions in your database optimization. This also includes revisions for pages and custom post types.', 'perfmatters')
        )
    );

    //post auto-drafts
    add_settings_field(
        'post_auto_drafts', 
        perfmatters_title(__('Post Auto-Drafts', 'perfmatters'), 'database-post_auto_drafts', 'https://perfmatters.io/docs/wordpress-auto-drafts/'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'post_auto_drafts',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Include post auto-drafts in your database optimization. This also includes auto-drafts for pages and custom post types.', 'perfmatters'),
        )
    );

    //trashed posts
    add_settings_field(
        'trashed_posts', 
        perfmatters_title(__('Trashed Posts', 'perfmatters'), 'database-trashed_posts', 'https://perfmatters.io/docs/wordpress-trash/#posts'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'trashed_posts',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Include trashed posts in your database optimization. This also includes trashed pages and custom post types.', 'perfmatters')
        )
    );

    //spam comments
    add_settings_field(
        'spam_comments', 
        perfmatters_title(__('Spam Comments', 'perfmatters'), 'database-spam_comments', 'https://perfmatters.io/docs/wordpress-spam-comments/'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'spam_comments',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Include spam comments in your database optimization.', 'perfmatters')
        )
    );

    //trashed comments
    add_settings_field(
        'trashed_comments', 
        perfmatters_title(__('Trashed Comments', 'perfmatters'), 'database-trashed_comments', 'https://perfmatters.io/docs/wordpress-trash/#comments'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'trashed_comments',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Include trashed comments in your database optimization.', 'perfmatters')
        )
    );

    //expired transients
    add_settings_field(
        'expired_transients', 
        perfmatters_title(__('Expired Transients', 'perfmatters'), 'database-expired_transients', 'https://perfmatters.io/docs/wordpress-transients/#expired'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'expired_transients',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Include expired transients in your database optimization.', 'perfmatters')
        )
    );

    //all transients
    add_settings_field(
        'all_transients', 
        perfmatters_title(__('All Transients', 'perfmatters'), 'database-all_transients', 'https://perfmatters.io/docs/wordpress-transients/#all'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'all_transients',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Include all transients in your database optimization.', 'perfmatters')
        )
    );

    //tables
    add_settings_field(
        'tables', 
        perfmatters_title(__('Tables', 'perfmatters'), 'database-tables', 'https://perfmatters.io/docs/wordpress-database-tables/'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'tables',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'tooltip' => __('Include tables in your database optimization.', 'perfmatters')
        )
    );

    if(!get_transient('perfmatters_database_optimization_process')) {

        //optimize database
        add_settings_field(
            'optimize_database', 
            perfmatters_title(__('Optimize Database', 'perfmatters'), false, 'https://perfmatters.io/docs/optimize-wordpress-database/'), 
            'perfmatters_print_input',
            'perfmatters_tools', 
            'database', 
            array(
                'id' => 'optimize_database',
                'input' => 'button',
                'action' => 'optimize_database',
                'title' => __('Optimize Now', 'perfmatters'),
                'option' => 'perfmatters_tools',
                'section' => 'database',
                'confirmation' => __('This will make permanent changes that cannot be reverted! Are you sure you want to proceed with optimization?', 'perfmatters'),
                'tooltip' => __('Run a one-time optimization of your WordPress database based on the selected options above. This process runs in the background.', 'perfmatters')
            )
        );
    }
    else {

        //cancel optimization
        add_settings_field(
            'cancel_optimization', 
            perfmatters_title(__('Cancel Optimization', 'perfmatters'), false, 'https://perfmatters.io/docs/optimize-wordpress-database/'), 
            'perfmatters_print_input',
            'perfmatters_tools', 
            'database', 
            array(
                'id' => 'cancel_optimization',
                'input' => 'button',
                'action' => 'cancel_optimization',
                'title' => __('Cancel Current Optimization', 'perfmatters'),
                'option' => 'perfmatters_tools',
                'section' => 'database',
                'tooltip' => __('Cancel the current database optimization process.', 'perfmatters')
            )
        );
    }

    //Scheduled Optimization
    add_settings_field(
        'optimize_schedule', 
        perfmatters_title(__('Scheduled Optimization', 'perfmatters'), 'database-optimize_schedule', 'https://perfmatters.io/docs/optimize-wordpress-database/#schedule'), 
        'perfmatters_print_input', 
        'perfmatters_tools', 
        'database', 
        array(
            'id' => 'optimize_schedule',
            'option' => 'perfmatters_tools',
            'section' => 'database',
            'input' => 'select',
            'options' => array(
                "" => __('Disabled', 'perfmatters'),
                "daily" => __('Daily', 'perfmatters'),
                "weekly" => __('Weekly', 'perfmatters'),
                "monthly" => __('Monthly', 'perfmatters')
                ),
            'tooltip' => __('Schedule a routine optimization of your WordPress database based on the selected options above. This process runs in the background and starts immediately after saving.', 'perfmatters')
        )
    );

    register_setting('perfmatters_tools', 'perfmatters_tools', 'perfmatters_sanitize_tools');

    //edd license option
	register_setting('perfmatters_edd_license', 'perfmatters_edd_license_key', 'perfmatters_edd_sanitize_license');
}
add_action('admin_init', 'perfmatters_settings');

//options default values
function perfmatters_default_options() {
	$defaults = array(
        'fonts' => array(
            'subsets' => array('latin')
        ),
        'cdn' => array(
            'cdn_directories' => 'wp-content,wp-includes',
            'cdn_exclusions' => '.php'
        ),
        'cache' => array(
            'warmer_sources' => array(
                'posts' => 1,
                'pages' => 1
            )
        )
	);
    perfmatters_network_defaults($defaults, 'perfmatters_options');
	return apply_filters('perfmatters_default_options', $defaults);
}

//tools default values
function perfmatters_default_tools() {
    $defaults = array();
    perfmatters_network_defaults($defaults, 'perfmatters_tools');
    return apply_filters('perfmatters_default_tools', $defaults);
}

//network defaults
function perfmatters_network_defaults(&$defaults, $option) {
    if(is_multisite() && is_plugin_active_for_network('perfmatters/perfmatters.php')) {
        $perfmatters_network = get_site_option('perfmatters_network');
        if(!empty($perfmatters_network['default'])) {
            $networkDefaultOptions = get_blog_option($perfmatters_network['default'], $option);
            if($option == 'perfmatters_options') {
                unset($networkDefaultOptions['cdn']['cdn_url']);
            }
            if(!empty($networkDefaultOptions)) {
                foreach($networkDefaultOptions as $key => $val) {
                    $defaults[$key] = $val;
                }
            }
        }
    }
}

//print settings header
function perfmatters_settings_header($text, $dashicon = '', $beta = false) {
    echo '<h2 class="perfmatters-settings-header">' . ($dashicon ? '<span class="dashicons ' . esc_attr($dashicon) . '"></span>' : '') . esc_html($text) . ($beta ? '<span class="perfmatters-beta">BETA</span>' : '') . '</h2>';
}

//print settings section
function perfmatters_settings_section($page, $section, $dashicon = '', $class = '') {

    global $wp_settings_sections;
    
    if(!empty($wp_settings_sections[$page][$section])) {

        global $wp_settings_fields;
        
        echo '<div class="perfmatters-settings-section">';
            if(!empty($wp_settings_sections[$page][$section]['title'])) {
                echo '<h2>' . ($dashicon ? '<span class="dashicons ' . esc_attr($dashicon) . '"></span>' : '') . esc_html($wp_settings_sections[$page][$section]['title']) . '</h2>';
            }
            if(!empty($wp_settings_fields[$page][$section])) {
                echo '<table class="form-table">';
                    echo '<tbody>';
                        do_settings_fields($page, $section);
                    echo '</tbody>';
                echo '</table>';
            }
        echo '</div>';
    }
}

//print form inputs
function perfmatters_print_input($args) {

    $selection_id = $args['id'];

    if(!empty($args['option'])) {
        $option = $args['option'];
        if($args['option'] == 'perfmatters_network') {
            $options = get_site_option($args['option']);
        }
        else {
            $options = get_option($args['option']);
        }
    }
    else {
        $option = 'perfmatters_options';
        $options = get_option('perfmatters_options');
    }
    if(!empty($args['option']) && $args['option'] == 'perfmatters_tools') {
        $tools = $options;
    }
    else {
        $tools = get_option('perfmatters_tools');
    }

    //set section variables
    if(!empty($args['section'])) {
        $selection_id = $args['section'] . '-' . $args['id'];
        $option = $option . '[' . $args['section'] . ']';
        $options = isset($options[$args['section']]) ? $options[$args['section']] : array();
    }


    //text
    if(!empty($args['input']) && ($args['input'] == 'text' || $args['input'] == 'color')) {
        echo "<input type='text' id='" . esc_attr($selection_id) . "' name='" . esc_attr($option . '[' . $args['id'] . ']') . "' value='" . esc_attr(!empty($options[$args['id']]) ? $options[$args['id']] : '') . "' placeholder='" . esc_attr(!empty($args['placeholder']) ? $args['placeholder'] : '') . "'" . (!empty($args['validate']) ? " perfmatters_validate='" . esc_attr($args['validate']) . "'" : "") . " />";
    }

    //select — missing/blank both match value '' so mid-list defaults (e.g. Edge Cache Expires) stay selected
    elseif(!empty($args['input']) && $args['input'] == 'select') {
        $selected = array_key_exists($args['id'], $options) ? $options[$args['id']] : '';
        echo "<select id='" . esc_attr($selection_id) . "' name='" . esc_attr($option . '[' . $args['id'] . ']') . "'>";
            foreach($args['options'] as $value => $title) {
                echo "<option value='" . esc_attr($value) . "' ";
                if((string) $selected === (string) $value) {
                    echo "selected";
                }
                echo ">" . esc_html($title) . "</option>";
            }
        echo "</select>";
    }

    //button
    elseif(!empty($args['input']) && $args['input'] == 'button') {
        perfmatters_action_button(
            $args['action'] ?? '',
            $args['title'],
            'secondary',
            $args['confirmation'] ?? ''
        );
    }

    //text area
    elseif(!empty($args['input']) && $args['input'] == 'textarea') {
        echo "<textarea id='" . esc_attr($selection_id) . "' name='" . esc_attr($option . '[' . $args['id'] . ']') . "' placeholder='" . esc_attr(!empty($args['placeholder']) ? $args['placeholder'] : '') . "'" . (!empty($args['textareatype']) && $args['textareatype'] == 'codemirror' ? " class='perfmatters-codemirror'" : "" ) . ">";
            if(!empty($options[$args['id']])) {
                if(!empty($args['textareatype']) && $args['textareatype'] == 'oneperline') {
                    foreach($options[$args['id']] as $line) {
                        echo esc_textarea($line) . "\n";
                    }
                }
                else {
                    echo esc_textarea($options[$args['id']]);
                }
            }
        echo "</textarea>";
    }

    //checkbox + toggle
    else {

        $is_toggle = empty($tools['accessibility_mode']) && (empty($args['input']) || $args['input'] != 'checkbox');
        $has_manual_tooltip = !$is_toggle && !empty($tools['accessibility_mode']) && !empty($args['tooltip']);

        if($is_toggle) {
            echo "<label for='" . esc_attr($selection_id) . "' class='perfmatters-switch'>";
        }
        elseif($has_manual_tooltip) {
            echo "<div class='perfmatters-checkbox-tooltip-offset'>";
        }
        
            echo "<input type='checkbox' id='" . esc_attr($selection_id) . "' name='" . esc_attr($option . '[' . $args['id'] . ']') . "' value='1' style='display: inline-block; margin: 0px;' ";
            checked(!empty($options[$args['id']]));
            if(!empty($args['confirmation'])) {
                echo " onChange=\"this.checked=this.checked?confirm('" . esc_js($args['confirmation']) . "'):false;\"";
            }
            echo ">";
            
        if($is_toggle) {
               echo "<div class='perfmatters-slider'></div>";
           echo "</label>";
        }
        elseif($has_manual_tooltip) {
            echo '</div>';
        }

        if(!empty($args['section']) && $args['section'] == 'database') {
            echo '<span class="perfmatters-option-data"></span>';
        }
    }

    //tooltip
	if(!empty($args['tooltip'])) {
		perfmatters_tooltip($args['tooltip']);
	}
}

//print simple exclusions
function perfmatters_print_quick_exclusions($args) {

    $options = get_option('perfmatters_options');

    //master exclusions array
    $master = Perfmatters\JS::get_quick_exclusions_master();

    //local exclusions
    $exclusions = array(
        'plugins' => array(
            'title' => __('Plugins', 'perfmatters'),
            'items' => array(),
            'dashicon' => 'admin-plugins'
        ),
        'themes' => array(
            'title' => __('Themes', 'perfmatters'),
            'items' => array(),
            'dashicon' => 'admin-appearance'
        )
    );

    //add any active plugin sets to list
    $active_plugins = (array) get_option('active_plugins', array());

    if(is_multisite()) {
        $active_plugins = array_merge($active_plugins, array_keys((array) get_site_option('active_sitewide_plugins', array())));
    }

    foreach($master['plugins'] as $key => $exclusion_set) {
        if(in_array($exclusion_set['id'], $active_plugins)) {
            $exclusions['plugins']['items'][] = $key;
        }
    }

    //add any active theme sets to list
    $theme = wp_get_theme();
    $parent = $theme->get_template();
    $active_theme = strtolower(!empty($parent) ? $parent : $theme->get('Name'));

    foreach($master['themes'] as $key => $exclusion_set) {
        if($exclusion_set['id'] == $active_theme) {
            $exclusions['themes']['items'][] = $key;
        }
    }

    //quick exclusions ui
    echo '<div class="perfmatters-input-row-wrapper">';
        echo '<div class="perfmatters-input-row-container">';

            if(empty($exclusions['plugins']['items']) && empty($exclusions['themes']['items'])) {
                echo '<style>.delay_js_quick_exclusions { display: none; }</style>';
            }

            foreach($exclusions as $type => $data) {

                if(!empty($data['items'])) {

                    $opened = !empty($options['assets']['delay_js_quick_exclusions'][$type]) ? ' perfmatters-opened' : '';

                    //quick exclusion section
                    echo '<div class="perfmatters-quick-exclusion' . esc_attr($opened) . '">';

                        //title bar
                        echo '<div class="perfmatters-quick-exclusion-title-bar" style="display: flex; justify-content: space-between;">';
                            echo '<div style="display: flex; align-items: center;">';
                                echo '<span class="dashicons dashicons-' . esc_attr($data['dashicon']) . '" style="margin-right: 5px;"></span>';
                                echo esc_html($data['title']);
                            echo '</div>';

                            echo '<span class="perfmatters-quick-exclusion-toggle dashicons dashicons-plus"></span>';
                            echo '<span class="perfmatters-quick-exclusion-toggle dashicons dashicons-minus"></span>';
                        echo '</div>';

                        //exclusions
                        echo '<div class="perfmatters-quick-exclusion-items">';
                            foreach($data['items'] as $item) {
                                echo '<div style="margin-top: 5px;">';
                                    echo '<input type="checkbox" name="perfmatters_options[assets][delay_js_quick_exclusions][' . esc_attr($type) . '][' . esc_attr($item) . ']" value="1" ' . (!empty($options['assets'][$args['id']][$type][$item]) ? 'checked ' : '') . '/>';
                                    echo esc_html($master[$type][$item]['title']);
                                echo '</div >';
                            }
                        echo '</div>';

                    echo '</div>';
                }
            }
        echo '</div>';
    echo '</div>';

    //tooltip
    if(!empty($args['tooltip'])) {
        perfmatters_tooltip($args['tooltip']);
    }
}

//input rows ui
function perfmatters_print_input_rows($args) {

    $perfmatters_options = get_option('perfmatters_options');
 
    echo '<div class="perfmatters-input-row-wrapper">';
        echo '<div class="perfmatters-input-row-container">';

            $rowCount = 0;

            if(!empty($perfmatters_options[$args['section']][$args['id']]) && is_array($perfmatters_options[$args['section']][$args['id']])) {

                foreach($perfmatters_options[$args['section']][$args['id']] as $line) {

                    call_user_func('perfmatters_print_' . $args['id'] . '_row', $rowCount, $line);

                    $rowCount++;
                }
            }
            else {

                //print empty row at the end
                call_user_func('perfmatters_print_' . $args['id'] . '_row', $rowCount);
            }

        echo '</div>';

        //add new row
        echo '<a href="#" class="perfmatters-add-input-row button button-secondary" rel="' . esc_attr($rowCount) . '">' . esc_html__('Add New', 'perfmatters') . '</a>';

    echo '</div>';

    //tooltip
    if(!empty($args['tooltip'])) {
        perfmatters_tooltip($args['tooltip']);
    }
}

//preload input row
function perfmatters_print_preload_row($rowCount = 0, $line = array()) {

    echo '<div class="perfmatters-input-row"' . (empty($line['url']) ? ' style="display: none;"' : '') . '>';

        echo '<div style="display: flex; width: 100%; align-items: center;">';
            echo '<input type="text" id="preload-' . esc_attr($rowCount) . '-url" name="perfmatters_options[preload][preload][' . esc_attr($rowCount) . '][url]" value="' . esc_attr(isset($line['url']) ? $line['url'] : '') . '" placeholder="https://example.com/font.woff2" />';

            $types = array(
                'fetch'  => 'Fetch',
                'font'   => 'Font',
                'image'  => 'Image',
                'script' => 'Script',
                'style'  => 'Style',
                'track'  => 'Track'
            );

            echo '<select id="preload-' . esc_attr($rowCount) . '-as" name="perfmatters_options[preload][preload][' . esc_attr($rowCount) . '][as]" style="margin-left: 5px;">';
                echo '<option value="">' . esc_html__('Select Type', 'perfmatters') . '</option>';
                foreach($types as $value => $label) {
                    echo '<option value="' . esc_attr($value) . '"' . (isset($line['as']) && $line['as'] == $value ? ' selected="selected"' : '') . '>' . esc_html($label) . '</option>';
                }
            echo '</select>';

            echo '<a href="#" class="perfmatters-expand-input-row" title="' . esc_attr__('Settings', 'perfmatters') . '" style="margin-left: 8px; text-decoration: none;"><span class="dashicons dashicons-admin-generic"></span></a>';
            echo '<a href="#" class="perfmatters-delete-input-row" title="' . esc_attr__('Remove', 'perfmatters') . '"><span class="dashicons dashicons-trash"></span></a>';
        echo '</div>';

        echo '<div class="perfmatters-input-row-extra">';

            echo '<select id="preload-' . esc_attr($rowCount) . '-device" name="perfmatters_options[preload][preload][' . esc_attr($rowCount) . '][device]">';
                echo '<option value="">' . esc_html__('All Devices', 'perfmatters') . '</option>';
                echo '<option value="desktop"' . (isset($line['device']) && $line['device'] == 'desktop' ? ' selected="selected"' : '') . '>' . esc_html__('Desktop', 'perfmatters') . '</option>';
                echo '<option value="mobile"' . (isset($line['device']) && $line['device'] == 'mobile' ? ' selected="selected"' : '') . '>' . esc_html__('Mobile', 'perfmatters') . '</option>';
            echo '</select>';

            echo '<label class="perfmatters-inline-label-input"><span>' . esc_html__('Location', 'perfmatters') . '</span>';
                echo '<input type="text" id="preload-' . esc_attr($rowCount) . '-locations" name="perfmatters_options[preload][preload][' . esc_attr($rowCount) . '][locations]" value="' . esc_attr(isset($line['locations']) ? $line['locations'] : '') . '" placeholder="front,blog,23,19" />';
            echo '</label>';

            echo '<label class="perfmatters-inline-label-input"><span>' . esc_html__('Priority', 'perfmatters') . '</span>';
                echo '<select id="preload-' . esc_attr($rowCount) . '-priority" name="perfmatters_options[preload][preload][' . esc_attr($rowCount) . '][priority]" />';
                    echo '<option value="">' . esc_html__('Auto', 'perfmatters') . '</option>';
                    echo '<option value="high"' . (isset($line['priority']) && $line['priority'] == 'high' ? ' selected="selected"' : '') . '>' . esc_html__('High', 'perfmatters') . '</option>';
                    echo '<option value="low"' . (isset($line['priority']) && $line['priority'] == 'low' ? ' selected="selected"' : '') . '>' . esc_html__('Low', 'perfmatters') . '</option>';

                echo '</select>';
            echo '</label>';

        echo '</div>';
    echo "</div>";
}

//print early hint types
function perfmatters_print_early_hint_types($args) {

    $options = get_option('perfmatters_options');
    
    $types = array(
        'font'   => 'Font',
        'image'  => 'Image',
        'script' => 'Script',
        'style'  => 'Style'
    );

    echo "<div style='margin: 5px auto;' id='perfmatters-early-hint-types'>";
        foreach($types as $key => $name) {
            echo "<label for='perfmatters-early-hint-types-" . esc_attr($key) . "' style='margin-right: 10px; text-wrap: nowrap;'>";
                echo "<input type='checkbox' name='perfmatters_options[preload][early_hint_types][]' id='perfmatters-early-hint-types-" . esc_attr($key) . "' " . (!empty($options['preload']['early_hint_types']) && in_array($key, $options['preload']['early_hint_types']) ? ' checked' : '') . " value='" . esc_attr($key) . "' />";
                echo esc_html($name);
            echo "</label>";
        }
    echo "</div>";

    //tooltip
    if(!empty($args['tooltip'])) {
        perfmatters_tooltip($args['tooltip']);
    }
}

//fetch priority input row
function perfmatters_print_fetch_priority_row($rowCount = 0, $line = array()) {

    echo '<div class="perfmatters-input-row"' . (empty($line['selector']) ? ' style="display: none;"' : '') . '>';

        echo '<div style="display: flex; width: 100%; align-items: center;">';
            echo '<input type="text" id="fetch-priority-' . esc_attr($rowCount) . '-url" name="perfmatters_options[preload][fetch_priority][' . esc_attr($rowCount) . '][selector]" value="' . (isset($line['selector']) ? esc_attr($line['selector']) : '') . '" placeholder="example-class" style="" />';

            $types = array(
                'high' => 'High',
                'low'  => 'Low'
            );

            echo '<select id="fetch-priority-' . esc_attr($rowCount) . '-as" name="perfmatters_options[preload][fetch_priority][' . esc_attr($rowCount) . '][priority]" style="margin-left: 5px;">';
                echo '<option value="">' . esc_html__('Select Priority', 'perfmatters') . '</option>';
                foreach($types as $value => $label) {
                    echo '<option value="' . esc_attr($value) . '"' . (isset($line['priority']) && $line['priority'] == $value ? ' selected="selected"' : '') . '>' . esc_html($label) . '</option>';
                }
            echo '</select>';

            echo '<a href="#" class="perfmatters-expand-input-row" title="' . esc_attr__('Settings', 'perfmatters') . '" style="margin-left: 8px; text-decoration: none;"><span class="dashicons dashicons-admin-generic"></span></a>';
            echo '<a href="#" class="perfmatters-delete-input-row" title="' . esc_attr__('Remove', 'perfmatters') . '"><span class="dashicons dashicons-trash"></span></a>';

        echo '</div>';

        echo '<div class="perfmatters-input-row-extra">';

            echo '<select id="fetch-priority-' . esc_attr($rowCount) . '-device" name="perfmatters_options[preload][fetch_priority][' . esc_attr($rowCount) . '][device]" style="">';
                echo '<option value="">' . esc_html__('All Devices', 'perfmatters') . '</option>';
                echo '<option value="desktop"' . (isset($line['device']) && $line['device'] == 'desktop' ? ' selected="selected"' : '') . '>' . esc_html__('Desktop', 'perfmatters') . '</option>';
                echo '<option value="mobile"' . (isset($line['device']) && $line['device'] == 'mobile' ? ' selected="selected"' : '') . '>' . esc_html__('Mobile', 'perfmatters') . '</option>';
            echo '</select>';

            echo '<label class="perfmatters-inline-label-input" style="margin-left: 5px;"><span>' . esc_html__('Location', 'perfmatters') . '</span>';
                echo '<input type="text" id="fetch-priority-' . esc_attr($rowCount) . '-locations" name="perfmatters_options[preload][fetch_priority][' . esc_attr($rowCount) . '][locations]" value="' . esc_attr(isset($line['locations']) ? $line['locations'] : '') . '" placeholder="front,blog,23,19" />';
            echo '</label>';

            echo '<label for="fetch-priority-' . esc_attr($rowCount) . '-parent">';
                echo '<input type="checkbox" id="fetch-priority-' . esc_attr($rowCount) . '-parent" name="perfmatters_options[preload][fetch_priority][' . esc_attr($rowCount) . '][parent]"' . (!empty($line['parent']) ? ' checked' : '') . ' value="1" /> Search by Parent Selector';
            echo '</label>';

        echo '</div>';
    echo '</div>';
}

//preconnect input row
function perfmatters_print_preconnect_row($rowCount = 0, $line = '') {

    //check for previous vs new format
    if(is_array($line)) {
        $url = $line['url'];
        $crossorigin = isset($line['crossorigin']) ? $line['crossorigin'] : 0;
    }
    elseif(!empty($line)) {
        $url = $line;
        $crossorigin = 1;
    }

    //print row
    echo '<div class="perfmatters-input-row"' . (empty($url) ? ' style="display: none;"' : '') . '>';
        echo '<div class="perfmatters-input-row-hero">';
            echo '<input type="text" id="preconnect-' . esc_attr($rowCount) . '-url" name="perfmatters_options[preload][preconnect][' . esc_attr($rowCount) . '][url]" value="' . esc_attr($url ?? '') . '" placeholder="https://example.com" />';
            echo '<a href="#" class="perfmatters-expand-input-row" title="' . esc_attr__('Settings', 'perfmatters') . '" style="margin-left: 8px; text-decoration: none;"><span class="dashicons dashicons-admin-generic"></span></a>';
            echo '<a href="#" class="perfmatters-delete-input-row" title="' . esc_attr__('Remove', 'perfmatters') . '"><span class="dashicons dashicons-trash"></span></a>';
        echo '</div>';
        echo '<div class="perfmatters-input-row-extra">';
            echo '<label for="preconnect-' . esc_attr($rowCount) . '-crossorigin" style="margin-left: 0px;">';
                echo "<input type='checkbox' id='preconnect-" . esc_attr($rowCount) . "-crossorigin' name='perfmatters_options[preload][preconnect][" . esc_attr($rowCount) . "][crossorigin]' " . (!empty($crossorigin) ? "checked" : "") . " value='1' /> CrossOrigin";
            echo '</label>';
        echo '</div>';
    echo '</div>';
}

//print subset options
function perfmatters_print_subsets($args) {

    $perfmatters = get_option('perfmatters_options');

    $subset_options = array(
        'arabic'              => 'Arabic',
        'bengali'             => 'Bengali',
        'chinese-hongkong'    => 'Chinese (Hong Kong)',
        'chinese-simplified'  => 'Chinese (Simplified)',
        'chinese-traditional' => 'Chinese (Traditional)',
        'cyrillic'            => 'Cyrillic',
        'cyrillic-ext'        => 'Cyrillic Extended',
        'devanagari'          => 'Devanagari',
        'greek'               => 'Greek',
        'greek-ext'           => 'Greek Extended',
        'gujarati'            => 'Gujarati',
        'gurmukhi'            => 'Gurmukhi',
        'hebrew'              => 'Hebrew',
        'japanese'            => 'Japanese',
        'kannada'             => 'Kannada',
        'khmer'               => 'Khmer',
        'korean'              => 'Korean',
        'latin'               => 'Latin (' . __('Default', 'perfmatters') . ')',
        'latin-ext'           => 'Latin Extended',
        'malayalam'           => 'Malayalam',
        'math'                => 'Math',
        'myanmar'             => 'Myanmar',
        'oriya'               => 'Oriya',
        'sinhala'             => 'Sinhala',
        'symbols'             => 'Symbols',
        'tamil'               => 'Tamil',
        'telugu'              => 'Telugu',
        'thai'                => 'Thai',
        'tibetan'             => 'Tibetan',
        'vietnamese'          => 'Vietnamese'
    );

    //checkboxes
    echo '<div id="perfmatters-subsets">';
        foreach($subset_options as $key => $name) {
            echo '<label for="perfmatters-subsets-' . esc_attr($key) . '" style="margin-right: 10px; text-wrap: nowrap;">';
                echo '<input type="checkbox" name="perfmatters_options[fonts][subsets][]" id="perfmatters-subsets-' . esc_attr($key) . '" value="' . esc_attr($key) . '"' . (!empty($perfmatters['fonts']['subsets']) && in_array($key, $perfmatters['fonts']['subsets']) ? ' checked' : '') . ' />';
                echo esc_html($name);
            echo '</label>';
        }
    echo '</div>';

    //tooltip
    if(!empty($args['tooltip'])) {
        perfmatters_tooltip($args['tooltip']);
    }
}

//which public url groups the warmer collects
function perfmatters_print_warmer_sources($args) {
	$cache = Perfmatters\Config::$options['cache'] ?? array();
	$sources = (isset($cache['warmer_sources']) && is_array($cache['warmer_sources'])) ? $cache['warmer_sources'] : array();
	$post_types = Perfmatters\Cache\Config::warmer_post_types();

	$labels = array(
		'posts' => __('Posts', 'perfmatters'),
		'pages' => __('Pages', 'perfmatters'),
		'categories' => __('Categories', 'perfmatters'),
		'tags' => __('Tags', 'perfmatters'),
		'authors' => __('Authors', 'perfmatters'),
		'archives' => __('Archives', 'perfmatters'),
		'attachments' => __('Attachments', 'perfmatters')
	);

	echo '<div class="perfmatters-cache-warmer-scan">';
		perfmatters_action_button('scan_warmer_sources', __('Scan Now', 'perfmatters'), 'secondary');
	echo '</div>';

	echo "<div id='perfmatters-cache-warmer-sources'>";

		//homepage is always warmed — locked display-only, omitted from Scan Now badges
		perfmatters_print_warmer_source_row('warmer-source-home', '', __('Homepage', 'perfmatters'), true, true);

        foreach($labels as $key => $label) {
            perfmatters_print_warmer_source_row(
                'warmer-source-' . $key,
                'perfmatters_options[cache][warmer_sources][' . $key . ']',
                $label,
                !empty($sources[$key])
            );
        }

        foreach($post_types as $name => $object) {
            $label = isset($object->labels->name) ? $object->labels->name : $name;

            perfmatters_print_warmer_source_row(
                'warmer-source-' . $name,
                'perfmatters_options[cache][warmer_sources][post_types][' . $name . ']',
                $label,
                !empty($sources['post_types'][$name])
            );
        }

	echo '</div>';

	if(!empty($args['tooltip'])) {
		perfmatters_tooltip($args['tooltip']);
	}
}

function perfmatters_print_warmer_source_row($id, $name, $label, $checked, $locked = false) {
	echo "<label for='" . esc_attr($id) . "'" . ($locked ? " class='is-locked'" : '') . '>';
		echo '<span>';
			echo "<input type='checkbox' id='" . esc_attr($id) . "' value='1' ";
			if($name !== '') {
				echo "name='" . esc_attr($name) . "' ";
			}
			checked($checked);
			if($locked) {
				echo ' disabled="disabled"';
			}
			echo ' /> ' . esc_html($label);
		echo '</span>';
		if(!$locked) {
			echo '<span class="perfmatters-option-data"></span>';
		}
	echo '</label>';
}

//Cloudflare toggle via print_input, plus connection / Sync Rules messaging when enabled
function perfmatters_print_cloudflare($args) {
	perfmatters_print_input($args);

	$options = Perfmatters\Config::$options['cache'] ?? array();

	if(empty($options['cloudflare'])) {
		return;
	}

	$status = Perfmatters\Cache\Cloudflare::status();
	$state = isset($status['state']) ? $status['state'] : 'disabled';
	$domain = !empty($status['zone_domain']) ? $status['zone_domain'] : '';
	$host_proxied = isset($status['host_proxied']) ? (int) $status['host_proxied'] : -1;

	//same class as the API Token / Zone rows so the input controller can hide this on toggle (before Save)
	echo '<div class="cache-cloudflare">';

	//status can stay "ready" after the token is removed — require credentials before claiming connected
	if($state === 'ready' && $domain !== '' && Perfmatters\Cache\Cloudflare::has_token()) {
		echo '<p class="description"><span class="dashicons dashicons-yes" style="color:#46b450;"></span> ' . esc_html(sprintf(
			/* translators: %s: Cloudflare zone domain name */
			__('Connected to %s. Cache rules are active.', 'perfmatters'),
			$domain
		)) . '</p>';

		if($host_proxied === 1) {
			echo '<p class="description"><span class="dashicons dashicons-yes" style="color:#46b450;"></span> ' . esc_html(sprintf(
				/* translators: %s: site hostname */
				__('%s is proxied (orange cloud) in Cloudflare DNS.', 'perfmatters'),
				Perfmatters\Cache\Config::site_host()
			)) . '</p>';
		}
		elseif($host_proxied === 0) {
			echo '<p class="description" style="color:#d63638;"><span class="dashicons dashicons-warning"></span> ' . esc_html(sprintf(
				/* translators: %s: site hostname */
				__('%s is DNS-only (gray cloud). Set the A/AAAA/CNAME to proxied (orange cloud) or visitors will not hit cache rules.', 'perfmatters'),
				Perfmatters\Cache\Config::site_host()
			)) . '</p>';
		}
		else {
			echo '<p class="description" style="color:#dba617;"><span class="dashicons dashicons-warning"></span> ' . esc_html(sprintf(
				/* translators: %s: site hostname */
				__('Could not verify whether %s is proxied. Add Zone → DNS → Read on the API token and click Sync Rules, and confirm an A/AAAA/CNAME for this hostname exists in the zone.', 'perfmatters'),
				Perfmatters\Cache\Config::site_host()
			)) . '</p>';
		}

		if(!empty($status['message'])) {
			echo '<p class="description">' . esc_html($status['message']) . '</p>';
		}
	}
	elseif($state === 'error' && !empty($status['message']) && Perfmatters\Cache\Cloudflare::has_token()) {
		echo '<p class="description" style="color:#d63638;"><span class="dashicons dashicons-warning"></span> ' . esc_html($status['message']) . '</p>';
	}
	elseif($state === 'disabled' || !Perfmatters\Cache\Cloudflare::has_token()) {
		echo '<p class="description">' . esc_html__('Save an API token to create cache rules for this domain.', 'perfmatters') . '</p>';
	}

	//manual re-sync / retry — only useful when credentials exist
	if(Perfmatters\Cache\Cloudflare::has_token()) {
		echo '<div class="perfmatters-cache-cf-sync" style="margin: 10px 0 0;">';
			perfmatters_action_button('sync_cloudflare_rules', __('Sync Rules', 'perfmatters'), 'secondary');
		echo '</div>';
	}

	echo '</div>';
}

//password field — never echo the stored token (lives outside perfmatters_options[cache])
//PERFMATTERS_CLOUDFLARE_API_TOKEN in wp-config locks the field (same idea as PERFMATTERS_LICENSE_KEY)
//saved DB token mirrors License Key: masked disabled input + Remove Token
function perfmatters_print_cf_api_token($args) {
	$id = !empty($args['section']) ? $args['section'] . '-' . $args['id'] : $args['id'];
	$name = 'perfmatters_options' . (!empty($args['section']) ? '[' . $args['section'] . ']' : '') . '[' . $args['id'] . ']';
	$from_constant = Perfmatters\Cache\Cloudflare::token_from_constant();
	$has_option = Perfmatters\Cache\Cloudflare::has_option_token();

	if($from_constant) {
		echo "<input type='password' id='" . esc_attr($id) . "' value='' placeholder='" . esc_attr__('••••••••••••••••', 'perfmatters') . "' disabled='disabled' autocomplete='off'>";
		echo '<p class="description">' . esc_html(sprintf(
			/* translators: %s: PHP constant name */
			__('Using %s from wp-config.php.', 'perfmatters'),
			'PERFMATTERS_CLOUDFLARE_API_TOKEN'
		)) . '</p>';

		if(!empty($args['tooltip'])) {
			perfmatters_tooltip($args['tooltip']);
		}

		return;
	}

	if($has_option) {
		echo '<div class="perfmatters-cache-cf-token-row">';
			echo "<input type='text' id='" . esc_attr($id) . "' class='perfmatters-cache-cf-token-has-value' value='" . esc_attr(Perfmatters\Cache\Cloudflare::option_token_mask()) . "' disabled='disabled' autocomplete='off' />";
			perfmatters_action_button(
				'remove_cloudflare_token',
				__('Remove Token', 'perfmatters'),
				'warning',
				__('Remove the saved Cloudflare API token and delete Perfmatters cache rules from this zone?', 'perfmatters')
			);
		echo '</div>';

		if(!empty($args['tooltip'])) {
			perfmatters_tooltip($args['tooltip']);
		}

		return;
	}

	//new-password + vendor ignore attrs — plain autocomplete=off is ignored by 1Password/LastPass on type=password
	echo "<input type='password' id='" . esc_attr($id) . "' name='" . esc_attr($name) . "' value='' autocomplete='new-password' data-1p-ignore='true' data-lpignore='true' data-protonpass-ignore='true' data-bwignore='true'>";

	if(!empty($args['tooltip'])) {
		perfmatters_tooltip($args['tooltip']);
	}
}

//text input via print_input; swap tooltip for auto-detect status when a zone was matched
function perfmatters_print_cf_zone_id($args) {
	$options = Perfmatters\Config::$options['cache'] ?? array();
	$value = isset($options['cf_zone_id']) ? $options['cf_zone_id'] : '';
	$status = Perfmatters\Cache\Cloudflare::status();

	//only show a matched zone while credentials exist — otherwise contradicts the Setup card
	if($value === '' && !empty($status['zone_id']) && Perfmatters\Cache\Cloudflare::has_token()) {
		perfmatters_print_input($args);
		echo '<p class="description">' . esc_html(sprintf(
			/* translators: 1: zone domain, 2: zone id */
			__('Using %1$s (%2$s). Leave blank to keep auto-detect.', 'perfmatters'),
			!empty($status['zone_domain']) ? $status['zone_domain'] : __('matched zone', 'perfmatters'),
			$status['zone_id']
		)) . '</p>';
		return;
	}

	perfmatters_print_input($args);
}

//print purge meta options
function perfmatters_print_purge_meta($args) {

    //input + button
    $meta_options = array(
        'perfmatters_exclude_defer_js' => 'Defer JavaScript', 
        'perfmatters_exclude_delay_js' => 'Delay JavaScript', 
        'perfmatters_exclude_minify_js' => 'Minify JavaScript',
        'perfmatters_exclude_unused_css' => 'Unused CSS',
        'perfmatters_exclude_minify_css' => 'Minify CSS', 
        'perfmatters_exclude_lazy_loading' => 'Lazy Loading'
    );

    //deprecated
    if(version_compare(get_bloginfo('version'), '6.8' , '<')) {
        $meta_options['perfmatters_exclude_instant_page'] = 'Instant Page';
    }

    echo "<div style='margin: 10px auto; line-height: 20px;' id='perfmatters-purge-meta'>";
        foreach($meta_options as $key => $name) {
            echo "<label for='perfmatters-purge-meta-" . esc_attr($key) . "' style='margin-right: 10px; text-wrap: nowrap;'>";
                echo "<input type='checkbox' name='perfmatters_tools_temp[purge_meta_options][]' id='perfmatters-purge-meta-" . esc_attr($key) . "' value='" . esc_attr($key) . "' />";
                echo esc_html($name);
            echo "</label>";
        }
    echo "</div>";
    perfmatters_action_button('purge_meta', __('Purge Meta Options', 'perfmatters'), 'secondary', $args['confirmation'] ?? '');

    //tooltip
    if(!empty($args['tooltip'])) {
        perfmatters_tooltip($args['tooltip']);
    }
}

//print import settings
function perfmatters_print_import_settings($args) {

	//input + button
    echo "<input type='file' id='perfmatters-import-settings-file' name='perfmatters_import_settings_file' /><br />";
    perfmatters_action_button('import_settings', __('Import Plugin Settings', 'perfmatters'), 'secondary');

    //tooltip
    if(!empty($args['tooltip'])) {
    	perfmatters_tooltip($args['tooltip']);
    }
}

//normalize textarea inputs that should be stored as one-per-line arrays
function perfmatters_normalize_one_per_line_options(&$values) {

    if(!is_array($values)) {
        return;
    }

    $sections_one_per_line = array(
        'lazyload' => array(
            'lazy_loading_exclusions',
            'lazy_loading_parent_exclusions',
            'css_background_selectors',
            'element_selectors'
        ),
        'assets' => array(
            'js_exclusions',
            'delay_js_inclusions',
            'delay_js_exclusions',
            'minify_js_exclusions',
            'rucss_excluded_stylesheets',
            'rucss_excluded_selectors',
            'minify_css_exclusions'
        ),
        'preload' => array(
            'dns_prefetch'
        ),
        'cache' => array(
            'excluded_urls',
            'bypass_cookies',
            'purge_urls',
            'query_strings'
        )
    );

    foreach($sections_one_per_line as $section => $options) {
        foreach($options as $id) {
            if(!empty($values[$section][$id])) {
                perfmatters_sanitize_one_per_line($values[$section][$id]);
            }
        }
    }
}

//sanitize options
function perfmatters_sanitize_options($values) {

    //textarea inputs with one per line
    perfmatters_normalize_one_per_line_options($values);

    //input rows
    $sections_input_rows = array(
        'preload' => array(
            'preload' => 'url',
            'preconnect' => 'url',
            'fetch_priority' => 'selector'
        )
    );

    foreach($sections_input_rows as $section => $options) {
        foreach($options as $id => $field) {
            if(!empty($values[$section][$id])) {
                foreach($values[$section][$id] as $key => $line) {
                    $val = trim($line[$field]);
                    if(empty($val)) {
                        unset($values[$section][$id][$key]);
                    }
                    else {
                        $values[$section][$id][$key][$field] = $val;
                    }
                }
                $values[$section][$id] = array_values($values[$section][$id]);
            }
        }
    }

    if(isset($values['cache']) && is_array($values['cache'])) {
        $values['cache'] = Perfmatters\Cache\Config::sanitize($values['cache']);
    }

    return $values;
}

//sanitize edd license
function perfmatters_edd_sanitize_license($new) {
	$old = get_option( 'perfmatters_edd_license_key' );
	if($old && $old != $new) {
		delete_option( 'perfmatters_edd_license_status' ); // new license has been entered, so must reactivate
	}
	return $new;
}

//sanitize one per line text field
function perfmatters_sanitize_one_per_line(&$value) {
    if(!is_array($value)) {
        $text = trim($value);
        $text_array = explode("\n", $text);
        $text_array = array_filter(array_map('trim', $text_array));
        $value = $text_array;
    }
}

//print tooltip
function perfmatters_tooltip($tooltip) {
    if(!empty($tooltip)) {
        $tools = get_option('perfmatters_tools');
        echo "<span class='perfmatters-tooltip-text" . (!empty($tools['accessibility_mode']) ? "-am" : "") . "'>" . esc_html($tooltip) . "<span class='perfmatters-tooltip-subtext'>" . sprintf(
            /* translators: %s: question mark icon */
            esc_html__("Click %s to view documentation.", 'perfmatters'),
            "<span class='perfmatters-tooltip-icon'>?</span>"
        ) . "</span></span>";
    }
}

//print title
function perfmatters_title($title, $id = false, $link = false) {

    if(!empty($title)) {

        $var = "<span class='perfmatters-title-wrapper'>";

            //label + title
            if(!empty($id)) {
                $var.= "<label for='" . esc_attr($id) . "'>" . esc_html($title) . "</label>";
            }
            else {
                $var.= esc_html($title);
            }

            //tooltip icon + link
            if(!empty($link)) {
                $tools = get_option('perfmatters_tools');
                $var.= "<a" . (!empty($link) ? " href='" . esc_url($link) . "'" : "") . " class='perfmatters-tooltip'" . (!empty($tools['accessibility_mode']) ? " title='" . esc_attr__("View Documentation", 'perfmatters') . "'" : "") . " target='_blank'>?</a>";
            }

        $var.= "</span>";

        return $var;
    }
}

//action button — $message_mode: inline (default) or toast (#perfmatters-action-toast)
function perfmatters_action_button($action, $label, $type = 'primary', $confirmation = '', $button_attrs = '', $message_mode = 'inline') {
	$toast = ($message_mode === 'toast');
	//warning matches License Remove (perfmatters-button-warning); others stay button-primary / button-secondary
	$button_class = ($type === 'warning')
		? 'button perfmatters-button-warning'
		: 'button button-' . sanitize_html_class($type);

    echo '<div class="perfmatters-button-container">';
        echo '<button type="button" name="submit" class="' . esc_attr($button_class) . '" data-pm-action="' . esc_attr($action) . '"' . ($toast ? ' data-pm-message="toast"' : '') . (!empty($confirmation) ? ' data-pm-confirmation="' . esc_attr($confirmation) . '"' : '') . (!empty($button_attrs) ? ' ' . $button_attrs : '') . ' style="display: flex; align-items: center;">';
            echo '<span class="perfmatters-button-text">' . esc_html($label) . '</span>';
            echo '<svg class="perfmatters-button-spinner" viewBox="0 0 100 100" role="presentation" focusable="false" style="background: rgba(0,0,0,.1); border-radius: 100%; width: 16px; height: 28px; margin: 0px 2px; overflow: visible; opacity: 1; background-color: transparent; display: none;"><circle cx="50" cy="50" r="50" vector-effect="non-scaling-stroke" style="fill: transparent; stroke-width: 1.5px; stroke: #fff;"></circle><path d="m 50 0 a 50 50 0 0 1 50 50" vector-effect="non-scaling-stroke" style="fill: transparent; stroke-width: 1.5px; stroke: #4A89DD; stroke-linecap: round; transform-origin: 50% 50%; animation: 1.4s linear 0s infinite normal both running perfmatters-spinner;"></path></svg>';
        echo '</button>';

		if(!$toast) {
			//reload confirmations use #perfmatters-action-toast only (avoid inline + toast together)
			echo '<div class="perfmatters-button-message" style="display: none; margin-left: 10px;"></div>';
		}
    echo '</div>';
}