/**
 * Product Page Gift Form JavaScript
 *
 * Handles the gift certificate receiver form on product pages.
 * Requires wp_localize_script with object 'wcScProductPageGiftForm'.
 *
 * @package woocommerce-smart-coupons
 */

(function() {
	'use strict';

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initProductGiftForm);
	} else {
		initProductGiftForm();
	}

	function initProductGiftForm() {
		const formWrapper = [...document.querySelectorAll('.wc-sc-product-page-gift-form')].find(el => el.offsetParent !== null);
		
		if (!formWrapper) return;

		// Get localized data from PHP.
		const localizedData = (typeof wcScProductPageGiftForm !== 'undefined') ? wcScProductPageGiftForm : {};

		const ajaxUrl = localizedData.ajaxUrl || '';
		const ajaxNonce = localizedData.ajaxNonce || '';
		const datepickerOptions = localizedData.datepickerOptions || {};
		const i18n = localizedData.i18n || {};

		const couponsData = JSON.parse(formWrapper.getAttribute('data-coupons') || '[]');
		const scheduleEnabled = formWrapper.getAttribute('data-schedule-enabled') === 'yes';
		const accordionsContainer = formWrapper.querySelector('#wc_sc_product_gift_form_accordions');
		const defaultAccordionState = formWrapper.getAttribute('data-accordion-state') || 'collapsed';
		const sessionData = JSON.parse(formWrapper.getAttribute('data-session-data') || '{}');
		const productId = parseInt(formWrapper.getAttribute('data-product-id'), 10) || 0;

		// Get currency formatting settings.
		const currencySymbol = formWrapper.getAttribute('data-currency-symbol') || '$';
		const currencyPosition = formWrapper.getAttribute('data-currency-position') || 'left';
		const priceDecimals = parseInt(formWrapper.getAttribute('data-price-decimals'), 10) || 2;
		const priceDecimalSep = formWrapper.getAttribute('data-price-decimal-sep') || '.';
		const priceThousandSep = formWrapper.getAttribute('data-price-thousand-sep') || ',';

		// Find quantity input element (supports various WooCommerce themes).
		let quantityInput = null;

		/**
		 * Find quantity input element.
		 * Tries multiple selectors to support different WooCommerce themes.
		 * @return {HTMLElement|null} Quantity input element or null if not found.
		 */
		const findQuantityInput = function() {
			const quantitySelectors = [
				'input.qty',
				'input[name="quantity"]',
				'form.cart input[type="number"][name*="quantity"]',
				'form.cart .quantity input',
				'.quantity input[type="number"]'
			];
			for (const selector of quantitySelectors) {
				const found = [...document.querySelectorAll(selector)].find(el => el.offsetParent !== null);

				if (found) {
					return found;
				}
			}
			return null;
		};
		quantityInput = findQuantityInput();

		// Get current quantity from input.
		let currentQty = quantityInput && quantityInput.value ? parseInt(quantityInput.value, 10) || 1 : 1;

		/**
		 * Parse field name to extract coupon ID and person index.
		 * @param {string} fieldName - Field name like "gift_receiver_email[12][0]"
		 * @return {Object|null} {couponId, personIndex} or null if invalid
		 */
		const parseFieldName = (fieldName) => {
			const match = fieldName.match(/\[(\d+)\]\[(\d+)\]/);
			return match ? {couponId: parseInt(match[1], 10), personIndex: parseInt(match[2], 10)} : null;
		};

		/**
		 * Collect form data from all fields.
		 * @return {Object} Form data object.
		 */
		const collectFormData = () => {
			const globalToggle = formWrapper.querySelector('.wc-sc-global-schedule-toggle');
			const isScheduleChecked = globalToggle ? globalToggle.checked : (sessionData.wc_sc_schedule_gift_sending === 'yes');

			const dataObj = {
				wc_sc_schedule_gift_sending: isScheduleChecked ? 'yes' : 'no',
				gift_receiver_email: {},
				gift_receiver_message: {},
				gift_sending_date_time: {},
				gift_sending_timestamp: {}
			};

			['gift_receiver_email', 'gift_receiver_message', 'gift_sending_date_time', 'gift_sending_timestamp'].forEach(fieldType => {
				formWrapper.querySelectorAll('.' + fieldType).forEach(input => {
					const parsed = parseFieldName(input.name);
					if (!parsed) return;
					if (!dataObj[fieldType][parsed.couponId]) dataObj[fieldType][parsed.couponId] = {};
					dataObj[fieldType][parsed.couponId][parsed.personIndex] = input.value ? input.value.trim() : '';
				});
			});

			return dataObj;
		};

		/**
		 * Chain session saves so WooCommerce guest session writes never overlap.
		 * Concurrent session AJAX + add-to-cart can last-writer-wins overwrite an empty cart.
		 *
		 * @type {Promise}
		 */
		let saveChain = Promise.resolve();

		/**
		 * Save form data to session via AJAX.
		 * Requests are serialized to avoid WooCommerce session race conditions.
		 *
		 * @return {Promise}
		 */
		function saveToSession() {
			const runSave = () => new Promise((resolve, reject) => {
				const dataObj = collectFormData();

				const data = new URLSearchParams();
				data.append('wc_sc_schedule_gift_sending', dataObj.wc_sc_schedule_gift_sending || 'no');

				// Collect all coupon IDs.
				const allCouponIds = new Set([...Object.keys(dataObj.gift_receiver_email), ...Object.keys(dataObj.gift_receiver_message), ...Object.keys(dataObj.gift_sending_date_time), ...Object.keys(dataObj.gift_sending_timestamp)]);

				allCouponIds.forEach(couponIdKey => {
					const couponId = parseInt(couponIdKey, 10);
					if (isNaN(couponId)) return;

					// Get all person indices for this coupon.
					const personIndices = new Set();
					['gift_receiver_email', 'gift_receiver_message', 'gift_sending_date_time', 'gift_sending_timestamp'].forEach(field => {
						if (dataObj[field][couponIdKey]) {
							Object.keys(dataObj[field][couponIdKey]).forEach(idx => personIndices.add(parseInt(idx, 10)));
						}
					});

					// Process each person index.
					personIndices.forEach(personIndex => {
						if (isNaN(personIndex)) return;

						const email = (dataObj.gift_receiver_email[couponIdKey] && dataObj.gift_receiver_email[couponIdKey][personIndex] || '').trim();
						const message = (dataObj.gift_receiver_message[couponIdKey] && dataObj.gift_receiver_message[couponIdKey][personIndex] || '').trim();
						const dateTime = (dataObj.gift_sending_date_time[couponIdKey] && dataObj.gift_sending_date_time[couponIdKey][personIndex] || '').trim();
						const timestamp = (dataObj.gift_sending_timestamp[couponIdKey] && dataObj.gift_sending_timestamp[couponIdKey][personIndex] || '').trim();

						// Only send if email is present.
						if (email) {
							data.append(`gift_receiver_email[${couponId}][${personIndex}]`, email);
							data.append(`gift_receiver_message[${couponId}][${personIndex}]`, message);
							data.append(`gift_sending_date_time[${couponId}][${personIndex}]`, dateTime);
							data.append(`gift_sending_timestamp[${couponId}][${personIndex}]`, timestamp);
						}
					});
				});

				const formData = new URLSearchParams();
				formData.append('action', 'wc_sc_save_product_page_coupon_receiver_details');
				formData.append('security', ajaxNonce);
				formData.append('product_id', productId);
				formData.append('data', data.toString());

				fetch(ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded'
					},
					body: formData.toString()
				}).then(response => {
					if (!response.ok) {
						throw new Error('HTTP error: ' + response.status);
					}
					return response.json();
				}).then(result => {
					if (result.success === 'yes') {
						// Update sessionData with saved data.
						['gift_receiver_email', 'gift_receiver_message', 'gift_sending_date_time', 'gift_sending_timestamp'].forEach(fieldType => {
							if (!sessionData[fieldType]) sessionData[fieldType] = {};
							Object.keys(dataObj[fieldType]).forEach(couponId => {
								if (!sessionData[fieldType][couponId]) sessionData[fieldType][couponId] = {};
								Object.assign(sessionData[fieldType][couponId], dataObj[fieldType][couponId]);
							});
						});

						if (dataObj.wc_sc_schedule_gift_sending) sessionData.wc_sc_schedule_gift_sending = dataObj.wc_sc_schedule_gift_sending;

						resolve(result);
					} else {
						reject(new Error((i18n.sessionSaveFailed || 'Session save failed') + ': ' + (result.message || (i18n.unknownError || 'Unknown error'))));
					}
				}).catch(reject);
			});

			// Always wait for the previous save to finish before starting another.
			saveChain = saveChain.then(runSave, runSave);
			return saveChain;
		}

		/**
		 * Escape HTML to prevent XSS attacks.
		 * @param {string} text - Text to escape.
		 * @return {string} Escaped HTML string.
		 */
		const escapeHtml = (text) => text ? document.createElement('div').appendChild(document.createTextNode(text)).parentNode.innerHTML : '';

		/**
		 * Format amount as currency.
		 * @param {number|string} amount - Amount to format.
		 * @return {string} Formatted price string.
		 */
		function formatPrice(amount) {
			if (!amount || isNaN(amount) || amount <= 0) return '';

			const formatted = parseFloat(amount).toFixed(priceDecimals);
			const parts = formatted.split('.');
			parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, priceThousandSep);
			const priceString = parts.join(priceDecimalSep);

			const positions = {
				'left': currencySymbol + priceString,
				'right': priceString + currencySymbol,
				'left_space': currencySymbol + ' ' + priceString,
				'right_space': priceString + ' ' + currencySymbol
			};

			return '<span class="woocommerce-Price-amount amount"><bdi>' + escapeHtml(positions[currencyPosition] || positions['left']) + '</bdi></span>';
		}

		/**
		 * Get current credit_called amount from input field.
		 * @return {number} Current amount or 0 if not found/invalid.
		 */
		const getCreditCalledAmount = () => {
			const el = document.querySelector('input#credit_called, input[name*="credit_called"]');
			const amount = el ? parseFloat(el.value) : 0;
			return (!isNaN(amount) && amount > 0) ? amount : 0;
		};

		let currentVariationAmount = 0;

		jQuery(document).on('found_variation', 'form.variations_form', function (e, variation) {
			currentVariationAmount = parseFloat(variation.display_price) || 0;
		});

		const getVariationAmount = () => currentVariationAmount;

		/**
		 * Get formatted coupon info text for accordion header.
		 * @param {Object} coupon - Coupon data object.
		 * @return {string} Formatted coupon string with connector.
		 */
		function getCouponInfoHtml(coupon) {
			coupon = coupon || {};
			const connector = i18n.to || 'to';
			const ofConnector = i18n.of || 'of';
			const couponLabel = coupon.formatted_text || coupon.title || (i18n.storeCredit || 'Store Credit');

			const dynamicAmount = getCreditCalledAmount() || getVariationAmount();
			const amountHtml = dynamicAmount > 0 ? formatPrice(dynamicAmount) : (coupon.formatted_amount || '');

			if (amountHtml) {
				return escapeHtml(couponLabel) + ' ' + escapeHtml(ofConnector) + ' ' + amountHtml + ' ' + escapeHtml(connector);
			}

			return escapeHtml(couponLabel) + ' ' + escapeHtml(connector);
		}

		/**
		 * Get accordion coupon line HTML.
		 * @param {number} personIndex - Person index.
		 * @return {string} HTML string.
		 */
		function getAccordionCouponLineHtml(personIndex) {
			if (!couponsData || couponsData.length === 0) {
				return getCouponInfoHtml({});
			}
			if (couponsData.length === 1) {
				return getCouponInfoHtml(couponsData[0]);
			}
			const titles = couponsData.map(c => getCouponInfoHtml(c));
			return titles.join(', ');
		}

		/**
		 * Get entered recipient email from session data for a person index.
		 * @param {number} personIndex - Person index.
		 * @param {number} couponId - Coupon ID.
		 * @param {Object} currentSessionData - Session data.
		 * @return {string} Email string or empty.
		 */
		function getRecipientEmailFromSession(personIndex, couponId, currentSessionData = {}) {
			const email = currentSessionData.gift_receiver_email?.[couponId]?.[personIndex];
			return (email && String(email).trim()) ? String(email).trim() : '';
		}

		/**
		 * Update all accordion form titles with new amount from credit_called or variation.
		 * Updates header Line 1 without rebuilding accordions or affecting user inputs.
		 * @return {void}
		 */
		function updateAccordionAmounts() {
			formWrapper.querySelectorAll('.wc-sc-gift-accordion').forEach(accordion => {
				const personIndex = parseInt(accordion.getAttribute('data-person-index'), 10) || 0;
				const couponInfoEl = accordion.querySelector('.wc-sc-accordion-coupon-info');
				if (couponInfoEl) {
					couponInfoEl.innerHTML = getAccordionCouponLineHtml(personIndex);
				}
			});
		}

		// Create gift item block for a specific coupon and person index (message + schedule only)
		function createGiftItem(coupon, personIndex, sessionData = {}, isScheduleEnabled = false) {
			const item = document.createElement('div');
			item.className = 'wc-sc-gift-item';
			item.setAttribute('data-coupon-id', coupon.id);
			item.setAttribute('data-person-index', personIndex);

			// Field names in [coupon_id][person_index] format.
			const messageFieldName = `gift_receiver_message[${coupon.id}][${personIndex}]`;
			const dateTimeFieldName = `gift_sending_date_time[${coupon.id}][${personIndex}]`;
			const timestampFieldName = `gift_sending_timestamp[${coupon.id}][${personIndex}]`;

			// Get values from session.
			const getValue = (field) => sessionData[field]?.[coupon.id]?.[personIndex] ? escapeHtml(String(sessionData[field][coupon.id][personIndex])) : '';
			const messageValue = getValue('gift_receiver_message');
			const dateTimeValue = getValue('gift_sending_date_time');
			const timestampValue = getValue('gift_sending_timestamp');

			const messageRowHTML = `<div class="message_row">
				<div class="sc_message"><textarea placeholder="${i18n.writeMessage || 'Write a message'}..." class="gift_receiver_message" name="${messageFieldName}" cols="50" rows="5">${messageValue}</textarea></div>
			</div>`;

			let dateTimeHTML = '';
			if (scheduleEnabled) {
				dateTimeHTML = `<div class="email_sending_date_time_wrapper" style="${isScheduleEnabled ? '' : 'display:none;'}">
					<input class="gift_sending_date_time" type="text" placeholder="${i18n.pickDeliveryDateTime || 'Pick a delivery date & time'}..." name="${dateTimeFieldName}" value="${dateTimeValue}" autocomplete="off" style="position: relative; z-index: 99997;"/>
					<input type="hidden" class="gift_sending_timestamp" name="${timestampFieldName}" value="${timestampValue}" />
				</div>`;
			}

			item.innerHTML = `<div class="form_table">${dateTimeHTML}${messageRowHTML}</div>`;
			return item;
		}

		/**
		 * Render Global Schedule Toggle above accordions.
		 */
		function renderGlobalScheduleToggle() {
			if (!scheduleEnabled || !accordionsContainer) return;

			let globalToggleWrapper = formWrapper.querySelector('.wc-sc-global-schedule-wrapper');
			const isScheduleChecked = sessionData.wc_sc_schedule_gift_sending === 'yes';

			if (!globalToggleWrapper) {
				globalToggleWrapper = document.createElement('div');
				globalToggleWrapper.className = 'wc-sc-global-schedule-wrapper';
				const labelText = i18n.sendLater || i18n.send || 'Send';
				globalToggleWrapper.innerHTML = `
					<span class="wc-sc-schedule-label">${escapeHtml(labelText)}</span>
					<label class="wc-sc-toggle-check">
						<input type="checkbox" class="wc-sc-toggle-check-input wc-sc-global-schedule-toggle" ${isScheduleChecked ? 'checked' : ''} />
						<span class="wc-sc-toggle-check-text"></span>
					</label>
				`;
				if (accordionsContainer.parentNode) {
					accordionsContainer.parentNode.insertBefore(globalToggleWrapper, accordionsContainer);
				}
			} else {
				const toggleInput = globalToggleWrapper.querySelector('.wc-sc-global-schedule-toggle');
				if (toggleInput) {
					toggleInput.checked = isScheduleChecked;
				}
			}
		}

		/**
		 * Create accordion for a person (contains header with email input and body with message/date).
		 * @param {number} personIndex - Person index (0-based).
		 * @param {Object} sessionData - Session data to pre-fill values.
		 * @return {HTMLElement|null} Accordion element or null if error.
		 */
		function createPersonAccordion(personIndex, sessionData = {}) {
			if (!accordionsContainer || !couponsData || couponsData.length === 0) {
				return null;
			}

			const primaryCoupon = couponsData[0];
			const primaryCouponId = primaryCoupon ? primaryCoupon.id : 0;

			// Create accordion container.
			const accordion = document.createElement('div');
			accordion.className = 'wc-sc-gift-accordion';
			accordion.setAttribute('data-person-index', personIndex);

			const isExpanded = (defaultAccordionState === 'expanded');
			if (isExpanded) {
				accordion.classList.add('expanded');
			}

			// Create header with Line 1: Coupon title, Line 2: Email input, and Chevron toggle.
			const header = document.createElement('div');
			header.className = 'wc-sc-gift-accordion-header';

			const couponInfoHtml = getAccordionCouponLineHtml(personIndex);
			const emailValue = escapeHtml(getRecipientEmailFromSession(personIndex, primaryCouponId, sessionData));
			const emailPlaceholder = i18n.enterRecipientEmail || 'Recipient e-mail (leave empty to receive yourself)';
			const emailFieldName = `gift_receiver_email[${primaryCouponId}][${personIndex}]`;

			const chevronSvg = `<svg class="wc-sc-accordion-chevron" viewBox="0 0 20 20" width="14" height="14" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>`;

			header.innerHTML = `
				<div class="wc-sc-accordion-title-wrap">
					<div class="wc-sc-accordion-coupon-info">${couponInfoHtml}</div>
					<div class="wc-sc-accordion-email-wrap">
						<input class="gift_receiver_email" type="text" placeholder="${emailPlaceholder}..." name="${emailFieldName}" value="${emailValue}" />
					</div>
				</div>
				<span class="accordion-toggle">${chevronSvg}</span>
			`;

			// Create content area.
			const content = document.createElement('div');
			content.className = 'wc-sc-gift-accordion-content';
			if (isExpanded) {
				content.classList.add('expanded');
			}

			const isScheduleChecked = sessionData.wc_sc_schedule_gift_sending === 'yes';

			// Create gift item for each coupon (body containing message textarea and scheduled date).
			couponsData.forEach(coupon => {
				const giftItem = createGiftItem(coupon, personIndex, sessionData, isScheduleChecked);
				if (giftItem) {
					content.appendChild(giftItem);
				}
			});

			// Assemble accordion.
			accordion.appendChild(header);
			accordion.appendChild(content);
			accordionsContainer.appendChild(accordion);

			return accordion;
		}

		const setAccordionState = (accordion, isOpen) => {
			const content = accordion.querySelector('.wc-sc-gift-accordion-content');
			if (content) content.classList.toggle('expanded', isOpen);
			accordion.classList.toggle('expanded', isOpen);
		};

		/**
		 * Initialize datepicker for date/time inputs.
		 * @return {void}
		 */
		function initializeDatepickers() {
			const initDatepickers = () => {
				if (typeof jQuery === 'undefined' || !jQuery.fn.datetimepicker) {
					setTimeout(initDatepickers, 100);
					return;
				}

				const setTimestampFromPicker = (dateTimeInput) => {
					let dateObj = null;
					try {
						dateObj = jQuery(dateTimeInput).datetimepicker('getDate');
					} catch (e) {
						dateObj = null;
					}

					const tsInput = dateTimeInput.closest('.form_table')?.querySelector('input.gift_sending_timestamp');
					if (!tsInput) return;

					if (dateObj instanceof Date && !isNaN(dateObj.getTime())) {
						tsInput.value = String(Math.floor(dateObj.getTime() / 1000));
					} else {
						tsInput.value = '';
					}
				};

				// Use datepicker options from localized data.
				const options = Object.assign({}, datepickerOptions);
				options.isRTL = (typeof wp !== 'undefined' && wp.i18n && wp.i18n.isRTL) ? wp.i18n.isRTL() : false;
				const existingOnClose = options.onClose;
				options.onClose = function() {
					if (typeof existingOnClose === 'function') {
						existingOnClose.apply(this, arguments);
					}
					setTimestampFromPicker(this);
				};

				formWrapper.querySelectorAll('.gift_sending_date_time:not(.hasDatepicker)').forEach(input => {
					jQuery(input).datetimepicker(options);
					input.addEventListener('change', () => setTimestampFromPicker(input));
					input.addEventListener('blur', () => setTimestampFromPicker(input));
					setTimestampFromPicker(input);
				});
			};

			setTimeout(initDatepickers, 300);
		}

		/**
		 * Render UI based on current quantity.
		 * @return {void}
		 */
		function renderUI() {
			if (!accordionsContainer || currentQty <= 0) return;

			renderGlobalScheduleToggle();

			accordionsContainer.innerHTML = '';

			// Create accordion for each person using session data.
			for (let personIndex = 0; personIndex < currentQty; personIndex++) {
				createPersonAccordion(personIndex, sessionData);
			}

			initializeDatepickers();
			updateAccordionAmounts();
		}

		function setupEventListeners() {
			// Immediate update handler for credit_called input.
			if (typeof jQuery !== 'undefined') {
				jQuery(document).on('input change keyup propertychange', 'input#credit_called, input[name*="credit_called"]', updateAccordionAmounts);

				jQuery(document).on('found_variation', 'form.variations_form', function (e, variation) {
					currentVariationAmount = parseFloat(variation.display_price) || 0;
					updateAccordionAmounts();
				});
			}

			// Quantity change handler.
			let quantityChangeTimeout;
			const handleQuantityChange = (newQty) => {
				newQty = parseInt(newQty, 10) || 0;
				if (newQty < 0 || newQty === currentQty) return;

				// Save before changing quantity.
				saveToSession().then(() => {
					const oldQty = currentQty;
					currentQty = newQty;
					if (quantityInput && quantityInput.value != newQty) quantityInput.value = newQty;

					renderUI();

					// Close all, open last if increased.
					const allAccordions = accordionsContainer.querySelectorAll('.wc-sc-gift-accordion');
					allAccordions.forEach(a => setAccordionState(a, false));
					if (newQty > oldQty) {
						const newAccordion = accordionsContainer.querySelector(`.wc-sc-gift-accordion[data-person-index="${newQty - 1}"]`);
						if (newAccordion) setAccordionState(newAccordion, true);
					}

					setTimeout(() => saveToSession().catch(() => {}), 100);
				}).catch(() => {
					// If save fails, still render with new quantity.
					currentQty = newQty;
					renderUI();
				});
			};

			// Attach quantity listeners.
			const attachQuantityListeners = () => {
				if (!quantityInput) quantityInput = findQuantityInput();
				if (!quantityInput) return;

				const quantityChangeHandler = function() {
					clearTimeout(quantityChangeTimeout);
					quantityChangeTimeout = setTimeout(() => handleQuantityChange(this.value), 300);
				};

				quantityInput.addEventListener('change', quantityChangeHandler);
				quantityInput.addEventListener('input', quantityChangeHandler);

				// Listen for +/- buttons.
				document.querySelectorAll('.quantity .plus, .quantity .minus, .bde-quantity-button, .qty-button').forEach(button => {
					button.addEventListener('click', () => {
						
						if (button.offsetParent === null) {
							return;
						}

						setTimeout(() => {
							const input = findQuantityInput();
							if (input && input.value) {
								quantityInput = input;
								handleQuantityChange(input.value);
							}
						}, 100);
					});
				});
			};

			if (quantityInput) {
				attachQuantityListeners();
			} else {
				setTimeout(attachQuantityListeners, 500);
			}

			// Global Schedule toggle handler.
			formWrapper.addEventListener('change', e => {
				if (!e.target.classList.contains('wc-sc-global-schedule-toggle')) return;

				const isEnabled = e.target.checked;
				sessionData.wc_sc_schedule_gift_sending = isEnabled ? 'yes' : 'no';

				// Show/hide date/time fields across all accordions.
				formWrapper.querySelectorAll('.email_sending_date_time_wrapper').forEach(wrapper => {
					wrapper.style.display = isEnabled ? 'block' : 'none';
				});

				saveToSession().catch(() => {});
			});

			// Accordion toggle handler (skip clicks on email input or toggle elements).
			accordionsContainer.addEventListener('click', e => {
				if (e.target.closest('.wc-sc-accordion-email-wrap') || e.target.matches('input.gift_receiver_email') || e.target.closest('.wc-sc-schedule-toggle-wrapper') || e.target.closest('.wc-sc-toggle-check')) {
					return;
				}

				const header = e.target.closest('.wc-sc-gift-accordion-header');
				if (header) {
					const accordion = header.parentElement;
					const content = accordion.querySelector('.wc-sc-gift-accordion-content');
					const isOpen = content && content.classList.contains('expanded');
					setAccordionState(accordion, !isOpen);
				}
			});

			// Save to session on field changes (debounced).
			let saveTimeout;
			const debouncedSave = () => {
				clearTimeout(saveTimeout);
				saveTimeout = setTimeout(() => saveToSession().catch(() => {}), 500);
			};

			formWrapper.addEventListener('blur', e => {
				if (e.target.matches('.gift_receiver_email, .gift_receiver_message, .gift_sending_date_time')) {
					debouncedSave();
				}
			}, true);

			formWrapper.addEventListener('input', e => {
				if (e.target.matches('.gift_receiver_email, .gift_receiver_message, .gift_sending_date_time')) {
					debouncedSave();
				}
			}, true);

			/**
			 * Clear all form fields.
			 * @return {void}
			 */
			const clearProductPageForm = () => {
				formWrapper.querySelectorAll('.gift_receiver_email, .gift_receiver_message, .gift_sending_date_time, .gift_sending_timestamp').forEach(input => input.value = '');
				const globalToggle = formWrapper.querySelector('.wc-sc-global-schedule-toggle');
				if (globalToggle) globalToggle.checked = false;
				formWrapper.querySelectorAll('.email_sending_date_time_wrapper').forEach(wrapper => wrapper.style.display = 'none');
			};

			// Save to session before add-to-cart, without racing the cart session write.
			// The first submit is stopped completely so other cart handlers (side cart
			// AJAX, theme scripts) do not add the product before that save finishes.
			// One real submit is dispatched afterwards, and those handlers run once.
			const addToCartForm = formWrapper.closest('form.cart');
			if (addToCartForm) {
				let allowNativeSubmit = false;
				let submitInFlight = false;

				/**
				 * Ensure fields required by WooCommerce survive async re-submit.
				 * requestSubmit() without a connected submitter omits name="add-to-cart".
				 * Any-amount gift cards also need credit_called[product_id].
				 *
				 * @param {HTMLElement|null} submitter Original submit button, if any.
				 * @return {void}
				 */
				const ensureCartSubmitFields = (submitter) => {
					const addToCartValue = (submitter && submitter.name === 'add-to-cart' && submitter.value)
						? submitter.value
						: String(productId || '');

					if (addToCartValue) {
						let addToCartField = addToCartForm.querySelector('input[type="hidden"][name="add-to-cart"][data-wc-sc-submitter="1"]');
						if (!addToCartField) {
							addToCartField = document.createElement('input');
							addToCartField.type = 'hidden';
							addToCartField.name = 'add-to-cart';
							addToCartField.setAttribute('data-wc-sc-submitter', '1');
							addToCartForm.appendChild(addToCartField);
						}
						addToCartField.value = addToCartValue;
					}

					const creditInput = document.querySelector('#credit_called');
					if (creditInput && creditInput.value && productId) {
						let creditField = addToCartForm.querySelector('#hidden_credit');
						if (!creditField) {
							creditField = document.createElement('input');
							creditField.type = 'hidden';
							creditField.id = 'hidden_credit';
							creditField.name = 'credit_called[' + productId + ']';
							const qty = addToCartForm.querySelector('input[name="quantity"]');
							if (qty && qty.parentNode) {
								qty.parentNode.insertBefore(creditField, qty.nextSibling);
							} else {
								addToCartForm.appendChild(creditField);
							}
						} else if (creditField.parentElement && creditField.parentElement.tagName === 'INPUT') {
							// Move out of invalid nesting inside quantity input.
							const qty = addToCartForm.querySelector('input[name="quantity"]');
							if (qty && qty.parentNode) {
								qty.parentNode.insertBefore(creditField, qty.nextSibling);
							} else {
								addToCartForm.appendChild(creditField);
							}
						}
						creditField.name = 'credit_called[' + productId + ']';
						creditField.value = creditInput.value;
					}
				};

				/**
				 * Dispatch one submit after the gift-details save.
				 * requestSubmit() lets theme and cart handlers run once.
				 * Native submit() is only a fallback and does not re-enter this listener.
				 *
				 * @param {HTMLElement|null} submitter Original submit button, if any.
				 * @return {void}
				 */
				const submitFormOnce = (submitter) => {
					ensureCartSubmitFields(submitter);

					const canRequestSubmit = typeof addToCartForm.requestSubmit === 'function' && submitter && addToCartForm.contains(submitter);
					if (!canRequestSubmit) {
						HTMLFormElement.prototype.submit.call(addToCartForm);
						return;
					}

					let didDispatchSubmit = false;
					const markDispatched = () => {
						didDispatchSubmit = true;
					};

					// Registered after the gate listener, so it runs on the same submit
					// and tells us whether constraint validation allowed the event.
					addToCartForm.addEventListener('submit', markDispatched, true);
					allowNativeSubmit = true;

					try {
						addToCartForm.requestSubmit(submitter);
					} catch (err) {
						allowNativeSubmit = false;
						addToCartForm.removeEventListener('submit', markDispatched, true);
						HTMLFormElement.prototype.submit.call(addToCartForm);
						return;
					}

					addToCartForm.removeEventListener('submit', markDispatched, true);
					if (!didDispatchSubmit) {
						allowNativeSubmit = false;
					}
				};

				addToCartForm.addEventListener('submit', (event) => {
					if (allowNativeSubmit) {
						// This is the single follow-up submit. Let every other handler run.
						allowNativeSubmit = false;
						return;
					}

					event.preventDefault();
					event.stopPropagation();
					event.stopImmediatePropagation();

					// A second click while the session save is still running must not
					// queue another add-to-cart.
					if (submitInFlight) {
						return;
					}

					submitInFlight = true;
					clearTimeout(saveTimeout);

					const submitter = event.submitter || addToCartForm.querySelector('button[name="add-to-cart"], button.single_add_to_cart_button, input[type="submit"][name="add-to-cart"]');

					// Wait for any in-flight/debounced session save to finish first.
					saveToSession()
						.catch(() => {})
						.finally(() => {
							submitInFlight = false;
							submitFormOnce(submitter);
						});
				}, true);

				// Clear form after add to cart.
				let formCleared = false;
				const handleAddedToCart = () => {
					if (formCleared) return;
					clearProductPageForm();
					formCleared = true;
				};

				document.body.addEventListener('added_to_cart', handleAddedToCart);
				if (typeof jQuery !== 'undefined') {
					jQuery(document.body).on('added_to_cart', handleAddedToCart);
				}
			}
		}

		// Initialize.
		if (!quantityInput) quantityInput = findQuantityInput();
		setupEventListeners();
		renderUI();
	}
})();
