<?php
/**
 * Compatibility file for WPML
 *
 * @author      StoreApps
 * @since       3.3.0
 * @version     1.4.0
 *
 * @package     woocommerce-smart-coupons/includes/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_WPML_Compatibility' ) ) {

	/**
	 * Class for handling compatibility with WPML
	 */
	class WC_SC_WPML_Compatibility {

		/**
		 * Order meta key used by WooCommerce Multilingual for the checkout language.
		 */
		const ORDER_LANGUAGE_META = 'wpml_language';

		/**
		 * Variable to hold instance of WC_SC_WPML_Compatibility
		 *
		 * @var $instance
		 */
		private static $instance = null;

		/**
		 * Whether a Smart Coupons email is being rendered in a switched language.
		 *
		 * @var bool
		 */
		private $email_language_switched = false;

		/**
		 * Language code for the email currently being sent.
		 *
		 * @var string
		 */
		private $email_language = '';

		/**
		 * Language to restore after the email is sent.
		 *
		 * @var string
		 */
		private $previous_language = '';

		/**
		 * WPML language cookie to restore after the email is sent.
		 *
		 * @var string|false|null
		 */
		private $previous_cookie_language = null;

		/**
		 * Whether switch_to_locale() succeeded for the current email.
		 *
		 * @var bool
		 */
		private $locale_switched = false;

		/**
		 * Languages already resolved for an email address during this request.
		 *
		 * @var array
		 */
		private $email_language_cache = array();

		/**
		 * Constructor
		 */
		public function __construct() {

			add_action( 'init', array( $this, 'woocommerce_wpml_compatibility' ), 11 );
			add_action( 'wpml_language_has_switched', array( $this, 'sc_gift_discount_on_lang_switch' ), 10, 3 );

			// WCML translates email settings from the order language. These run after that so coupon emails can use the recipient language.
			add_filter( 'woocommerce_email_get_option', array( $this, 'translate_email_setting' ), 20, 4 );
			add_filter( 'plugin_locale', array( $this, 'filter_email_plugin_locale' ), 99, 2 );
			add_filter( 'wcml_email_language', array( $this, 'filter_wcml_email_language' ), 20, 2 );
			add_filter( 'wcml_email_text_domain', array( $this, 'filter_wcml_email_text_domain' ), 20, 2 );
		}

		/**
		 * Get single instance of WC_SC_WPML_Compatibility
		 *
		 * @return WC_SC_WPML_Compatibility Singleton object of WC_SC_WPML_Compatibility
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Function to handle compatibility with WooCommerce Multilingual
		 */
		public function woocommerce_wpml_compatibility() {
			global $woocommerce_wpml;
			if ( class_exists( 'woocommerce_wpml' ) && $woocommerce_wpml instanceof woocommerce_wpml ) {
				if ( ! empty( $woocommerce_wpml->products ) && has_action( 'woocommerce_before_checkout_process', array( $woocommerce_wpml->products, 'wcml_refresh_cart_total' ) ) ) {
					remove_action( 'woocommerce_before_checkout_process', array( $woocommerce_wpml->products, 'wcml_refresh_cart_total' ) );
				}
				if ( ! empty( $woocommerce_wpml->cart ) && has_action( 'woocommerce_before_checkout_process', array( $woocommerce_wpml->cart, 'wcml_refresh_cart_total' ) ) ) {
					remove_action( 'woocommerce_before_checkout_process', array( $woocommerce_wpml->cart, 'wcml_refresh_cart_total' ) );
				}
			}
		}

		/**
		 * Prevents product discount removal when the site language is switched.
		 *
		 * In a WPML-enabled setup, switching languages can trigger cart or product
		 * re-evaluation, which may unintentionally remove applied discounts.
		 * This function ensures that existing product discounts remain intact
		 * during a language switch.
		 *
		 * @param string $lang_code         The switched language code.
		 * @param bool   $cookie_lang       Whether the language cookie was switched.
		 * @param string $original_language The original language before switching.
		 * @return void
		 */
		public function sc_gift_discount_on_lang_switch( $lang_code = '', $cookie_lang = false, $original_language = '' ) {
			static $is_running = false;

			// Only react to an actual front-end language switch, not to internal temporary locale changes.
			if ( is_admin() || wp_doing_ajax() || ! $cookie_lang || empty( $lang_code ) || $lang_code === $original_language || ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
				return;
			}

			// Prevent recursive cart recalculation loops when WCML/WooCommerce triggers nested totals updates.
			if ( $is_running || doing_action( 'woocommerce_before_calculate_totals' ) || doing_action( 'woocommerce_after_calculate_totals' ) ) {
				return;
			}

			$is_running = true;

			if ( ! class_exists( 'WC_SC_Coupon_Actions' ) ) {
				include_once WC_SC_PLUGIN_DIRPATH . 'includes/class-wc-sc-coupon-actions.php';
			}
			$wc_sc_coupon_actions = WC_SC_Coupon_Actions::get_instance();
			foreach ( WC()->cart->get_cart() as $key => $item ) {
				if ( empty( $item['wc_sc_product_source'] ) ) {
					continue;
				}

				$pid = isset( $item['product_id'] ) ? (int) $item['product_id'] : 0;
				$vid = isset( $item['variation_id'] ) ? (int) $item['variation_id'] : 0;
				$qty = isset( $item['quantity'] ) ? (int) $item['quantity'] : 1;

				WC()->cart->cart_contents[ $key ] = $wc_sc_coupon_actions->modify_cart_item_data( $item, $pid, $vid, $qty );
			}

			WC()->cart->calculate_totals();
			$is_running = false;
		}

		/**
		 * Switch WPML and the WordPress locale before a Smart Coupons email is rendered.
		 *
		 * WooCommerce Multilingual disables WooCommerce's own email locale switch and only
		 * changes language for core order emails. Coupon, expiry, and reminder emails are
		 * therefore built in the default language. This uses the order's WPML language,
		 * then the recipient email address, before the subject and body are generated.
		 *
		 * @param WC_Email $email Email being sent.
		 * @return bool True when a language was selected for this email.
		 */
		public function switch_email_language( $email ) {
			if ( $this->email_language_switched || ! $this->is_wpml_active() || ! is_object( $email ) ) {
				return false;
			}

			$context  = $this->get_email_language_context( $email );
			$language = $this->get_recipient_language( $context['email'], $context['order_id'] );

			/**
			 * Filter the language used for a Smart Coupons email.
			 *
			 * @param string   $language  Resolved language code, or an empty string.
			 * @param string   $email     Recipient email address.
			 * @param int      $order_id  Related order ID, or 0.
			 * @param WC_Email $email_obj Email being sent.
			 */
			$language = apply_filters( 'wc_sc_wpml_email_language', $language, $context['email'], $context['order_id'], $email );

			if ( ! $this->is_active_language( $language ) ) {
				return false;
			}

			global $sitepress;

			$current_language = $sitepress->get_current_language();
			if ( ! is_string( $current_language ) || '' === $current_language ) {
				return false;
			}

			$this->email_language           = $language;
			$this->previous_language        = $current_language;
			$this->previous_cookie_language = $this->get_cookie_language();
			$this->email_language_switched  = true;

			if ( $language !== $current_language ) {
				// Do not update the language cookie. WCML's own switch does that and can stick on cron and admin requests.
				$sitepress->switch_lang( $language, false );
			}

			$locale = $this->get_locale_for_language( $language );
			if ( $locale && function_exists( 'switch_to_locale' ) && function_exists( 'determine_locale' ) && determine_locale() !== $locale ) {
				$this->locale_switched = (bool) switch_to_locale( $locale );
			}

			return true;
		}

		/**
		 * Restore the language used before a Smart Coupons email was rendered.
		 *
		 * @return bool True when this class had switched the language.
		 */
		public function restore_email_language() {
			if ( ! $this->email_language_switched ) {
				return false;
			}

			global $sitepress;

			if ( $this->is_wpml_active() && is_string( $this->previous_language ) && '' !== $this->previous_language ) {
				$sitepress->switch_lang( $this->previous_language, false );
			}

			if ( $this->locale_switched && function_exists( 'restore_previous_locale' ) ) {
				restore_previous_locale();
			}

			$this->restore_cookie_language();

			$this->email_language_switched  = false;
			$this->email_language           = '';
			$this->previous_language        = '';
			$this->previous_cookie_language = null;
			$this->locale_switched          = false;

			return true;
		}

		/**
		 * Resolve the language for a notification recipient.
		 *
		 * The order language stored by WooCommerce Multilingual is used when the
		 * recipient is the customer who placed the order. A different recipient,
		 * such as a gift-card receiver, uses the language saved for that email
		 * address when one exists.
		 *
		 * @param string $email    Recipient email address.
		 * @param int    $order_id Related order ID.
		 * @return string Active language code, or an empty string.
		 */
		public function get_recipient_language( $email, $order_id = 0 ) {
			$email    = is_string( $email ) ? sanitize_email( $email ) : '';
			$order_id = absint( $order_id );

			$order_language    = $this->get_order_language( $order_id );
			$billing_email     = $this->get_order_billing_email( $order_id );
			$recipient_differs = ( is_email( $email ) && is_email( $billing_email ) && strtolower( $email ) !== strtolower( $billing_email ) );

			if ( $recipient_differs ) {
				$email_language = $this->get_language_for_email( $email );
				if ( $this->is_active_language( $email_language ) ) {
					return $email_language;
				}
			}

			if ( $this->is_active_language( $order_language ) ) {
				return $order_language;
			}

			if ( is_email( $email ) ) {
				return $this->get_language_for_email( $email );
			}

			return '';
		}

		/**
		 * Translate Smart Coupons email settings for the recipient language.
		 *
		 * WCML reads the order language from the email object. Expiry and unused
		 * reminders pass a coupon, and gift emails can target a different person
		 * than the customer who checked out, so the setting strings are translated
		 * again for the language selected for this send.
		 *
		 * @param mixed    $value     Option value.
		 * @param WC_Email $email     Email object.
		 * @param mixed    $old_value Original option value.
		 * @param string   $key       Option key.
		 * @return mixed
		 */
		public function translate_email_setting( $value, $email, $old_value, $key ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			if ( ! $this->email_language_switched || ! is_string( $value ) || '' === $value || ! $this->is_smart_coupon_email( $email ) ) {
				return $value;
			}

			$translatable_keys = array(
				'subject',
				'heading',
				'additional_content',
				'scheduled_subject',
				'scheduled_heading',
			);

			if ( ! in_array( $key, $translatable_keys, true ) ) {
				return $value;
			}

			$this->ensure_email_language();

			$context    = 'admin_texts_woocommerce_' . $email->id . '_settings';
			$name       = '[woocommerce_' . $email->id . '_settings]' . $key;
			$translated = apply_filters( 'wpml_translate_single_string', $value, $context, $name, $this->email_language );

			return ( is_string( $translated ) && '' !== $translated ) ? $translated : $value;
		}

		/**
		 * Load WooCommerce and Smart Coupons translations for the email language.
		 *
		 * WCML only replaces the locale for the WooCommerce text domain, and only
		 * after it has handled a core order email.
		 *
		 * @param string $locale Locale.
		 * @param string $domain Text domain.
		 * @return string
		 */
		public function filter_email_plugin_locale( $locale, $domain ) {
			if ( ! $this->email_language_switched || ! in_array( $domain, array( 'woocommerce', 'woocommerce-smart-coupons' ), true ) ) {
				return $locale;
			}

			$email_locale = $this->get_locale_for_language( $this->email_language );

			return $email_locale ? $email_locale : $locale;
		}

		/**
		 * Keep WCML string translation on the language selected for this email.
		 *
		 * @param string $language Current language.
		 * @param int    $order_id Order ID used by WCML.
		 * @return string
		 */
		public function filter_wcml_email_language( $language, $order_id = 0 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			if ( $this->email_language_switched && $this->is_active_language( $this->email_language ) ) {
				return $this->email_language;
			}

			return $language;
		}

		/**
		 * Ask WCML to fall back to Smart Coupons gettext while our email is sending.
		 *
		 * @param string        $domain Text domain.
		 * @param WC_Email|null $email  Email object.
		 * @return string
		 */
		public function filter_wcml_email_text_domain( $domain, $email = null ) {
			if ( $this->email_language_switched && $this->is_smart_coupon_email( $email ) ) {
				return 'woocommerce-smart-coupons';
			}

			return $domain;
		}

		/**
		 * Read the recipient and related order from a Smart Coupons email.
		 *
		 * @param WC_Email $email Email object.
		 * @return array{email: string, order_id: int}
		 */
		private function get_email_language_context( $email ) {
			$recipient = '';
			$order_id  = 0;

			if ( ! empty( $email->recipient ) && is_email( $email->recipient ) ) {
				$recipient = $email->recipient;
			} elseif ( ! empty( $email->email_args['email'] ) && is_email( $email->email_args['email'] ) ) {
				$recipient = $email->email_args['email'];
			}

			if ( ! empty( $email->email_args['order_id'] ) ) {
				$order_id = absint( $email->email_args['order_id'] );
			}

			if ( ! $order_id && isset( $email->object ) && is_a( $email->object, 'WC_Order' ) && is_callable( array( $email->object, 'get_id' ) ) ) {
				$order_id = absint( $email->object->get_id() );
			}

			if ( ! $order_id && isset( $email->object ) && is_a( $email->object, 'WC_Coupon' ) && is_callable( array( $email->object, 'get_meta' ) ) ) {
				$order_id = absint( $email->object->get_meta( 'generated_from_order_id', true ) );
			}

			return array(
				'email'    => $recipient,
				'order_id' => $order_id,
			);
		}

		/**
		 * Language stored for an email address.
		 *
		 * Checks an explicit WPML email-language filter, then the latest order
		 * billed to that address, then the account language.
		 *
		 * @param string $email Email address.
		 * @return string
		 */
		private function get_language_for_email( $email ) {
			$email = sanitize_email( $email );
			if ( ! is_email( $email ) ) {
				return '';
			}

			$cache_key = strtolower( $email );
			if ( array_key_exists( $cache_key, $this->email_language_cache ) ) {
				return $this->email_language_cache[ $cache_key ];
			}

			$language = apply_filters( 'wpml_user_email_language', null, $email );

			if ( ! $this->is_active_language( $language ) ) {
				$language = $this->get_language_from_email_orders( $email );
			}

			if ( ! $this->is_active_language( $language ) ) {
				$language = $this->get_language_from_user( $email );
			}

			$language = $this->is_active_language( $language ) ? $language : '';

			$this->email_language_cache[ $cache_key ] = $language;

			return $language;
		}

		/**
		 * Checkout language saved on an order by WooCommerce Multilingual.
		 *
		 * @param int $order_id Order ID.
		 * @return string
		 */
		private function get_order_language( $order_id ) {
			$order = $this->get_order( $order_id );
			if ( ! $order ) {
				return '';
			}

			$language = $order->get_meta( self::ORDER_LANGUAGE_META, true );

			return is_string( $language ) ? $language : '';
		}

		/**
		 * Billing email for an order.
		 *
		 * @param int $order_id Order ID.
		 * @return string
		 */
		private function get_order_billing_email( $order_id ) {
			$order = $this->get_order( $order_id );
			if ( ! $order || ! is_callable( array( $order, 'get_billing_email' ) ) ) {
				return '';
			}

			$billing_email = $order->get_billing_email();

			return is_string( $billing_email ) ? $billing_email : '';
		}

		/**
		 * Latest checkout language for orders billed to an email address.
		 *
		 * @param string $email Email address.
		 * @return string
		 */
		private function get_language_from_email_orders( $email ) {
			if ( ! function_exists( 'wc_get_orders' ) ) {
				return '';
			}

			$orders = wc_get_orders(
				array(
					'billing_email' => $email,
					'limit'         => 10,
					'orderby'       => 'date',
					'order'         => 'DESC',
					'status'        => 'any',
					'return'        => 'objects',
				)
			);

			if ( empty( $orders ) || ! is_array( $orders ) ) {
				return '';
			}

			foreach ( $orders as $order ) {
				if ( ! is_a( $order, 'WC_Order' ) ) {
					continue;
				}

				$language = $order->get_meta( self::ORDER_LANGUAGE_META, true );
				if ( $this->is_active_language( $language ) ) {
					return $language;
				}
			}

			return '';
		}

		/**
		 * WPML language saved on the user account for an email address.
		 *
		 * @param string $email Email address.
		 * @return string
		 */
		private function get_language_from_user( $email ) {
			$user = get_user_by( 'email', $email );
			if ( ! $user || empty( $user->ID ) ) {
				return '';
			}

			$language = get_user_meta( $user->ID, 'icl_admin_language', true );

			return is_string( $language ) ? $language : '';
		}

		/**
		 * Load an order when WooCommerce is available.
		 *
		 * @param int $order_id Order ID.
		 * @return WC_Order|false
		 */
		private function get_order( $order_id ) {
			$order_id = absint( $order_id );
			if ( ! $order_id || ! function_exists( 'wc_get_order' ) ) {
				return false;
			}

			$order = wc_get_order( $order_id );

			return is_a( $order, 'WC_Order' ) ? $order : false;
		}

		/**
		 * Whether WPML can switch languages.
		 *
		 * @return bool
		 */
		private function is_wpml_active() {
			global $sitepress;

			return is_object( $sitepress ) && is_callable( array( $sitepress, 'switch_lang' ) ) && is_callable( array( $sitepress, 'get_current_language' ) );
		}

		/**
		 * Whether a language code is an active WPML language.
		 *
		 * @param mixed $language Language code.
		 * @return bool
		 */
		private function is_active_language( $language ) {
			if ( ! is_string( $language ) || '' === $language || ! $this->is_wpml_active() ) {
				return false;
			}

			global $sitepress;

			if ( ! is_callable( array( $sitepress, 'get_active_languages' ) ) ) {
				return false;
			}

			$active_languages = $sitepress->get_active_languages();

			return is_array( $active_languages ) && isset( $active_languages[ $language ] );
		}

		/**
		 * WordPress locale for a WPML language code.
		 *
		 * @param string $language Language code.
		 * @return string
		 */
		private function get_locale_for_language( $language ) {
			if ( ! $this->is_active_language( $language ) ) {
				return '';
			}

			$locale = apply_filters( 'wpml_locale', null, $language );
			if ( is_string( $locale ) && '' !== $locale ) {
				return $locale;
			}

			global $sitepress;

			if ( is_callable( array( $sitepress, 'get_locale' ) ) ) {
				$locale = $sitepress->get_locale( $language );
				if ( is_string( $locale ) && '' !== $locale ) {
					return $locale;
				}
			}

			return '';
		}

		/**
		 * Switch back to the email language if another integration changed it mid-send.
		 */
		private function ensure_email_language() {
			if ( ! $this->email_language_switched || ! $this->is_wpml_active() || ! $this->is_active_language( $this->email_language ) ) {
				return;
			}

			global $sitepress;

			$current_language = $sitepress->get_current_language();
			if ( $current_language !== $this->email_language ) {
				$sitepress->switch_lang( $this->email_language, false );
			}
		}

		/**
		 * Current WPML language cookie, when the request handler is available.
		 *
		 * @return string|false|null Null when the cookie cannot be read.
		 */
		private function get_cookie_language() {
			global $wpml_request_handler;

			if ( is_object( $wpml_request_handler ) && is_callable( array( $wpml_request_handler, 'get_cookie_lang' ) ) ) {
				return $wpml_request_handler->get_cookie_lang();
			}

			return null;
		}

		/**
		 * Restore the language cookie when sending the email changed it.
		 */
		private function restore_cookie_language() {
			if ( null === $this->previous_cookie_language ) {
				return;
			}

			global $wpml_request_handler;

			if ( ! is_object( $wpml_request_handler ) || ! is_callable( array( $wpml_request_handler, 'set_language_cookie' ) ) ) {
				return;
			}

			$current_cookie = $this->get_cookie_language();
			if ( $current_cookie !== $this->previous_cookie_language && is_string( $this->previous_cookie_language ) ) {
				$wpml_request_handler->set_language_cookie( $this->previous_cookie_language );
			}
		}

		/**
		 * Whether an email belongs to Smart Coupons.
		 *
		 * @param mixed $email Email object.
		 * @return bool
		 */
		private function is_smart_coupon_email( $email ) {
			return is_object( $email ) && ! empty( $email->id ) && 0 === strpos( (string) $email->id, 'wc_sc_' );
		}
	}

}

WC_SC_WPML_Compatibility::get_instance();
