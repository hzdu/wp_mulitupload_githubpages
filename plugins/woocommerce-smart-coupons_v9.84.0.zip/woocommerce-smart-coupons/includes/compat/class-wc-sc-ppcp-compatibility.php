<?php
/**
 * Compatibility file for WooCommerce PayPal Payments
 *
 * @author      StoreApps
 * @since       9.77.0
 * @version     1.1.0
 *
 * @package     woocommerce-smart-coupons/includes/compat/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_PPCP_Compatibility' ) ) {

	/**
	 * Class for handling compatibility with WooCommerce Side Cart Premium
	 */
	class WC_SC_PPCP_Compatibility {

		/**
		 * Variable to hold instance of WC_SC_PPCP_Compatibility
		 *
		 * @var $instance
		 */
		private static $instance = null;

		/**
		 * Get single instance of WC_SC_PPCP_Compatibility
		 *
		 * @return WC_SC_PPCP_Compatibility Singleton object of WC_SC_PPCP_Compatibility
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 */
		private function __construct() {
			add_action( 'wp_loaded', array( $this, 'hooks_for_compatibility' ) );
		}

		/**
		 * Handle call to functions which is not available in this class
		 *
		 * @param string $function_name Function to call.
		 * @param array  $arguments Array of arguments passed while calling $function_name.
		 * @return mixed Result of function call.
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Add compatibility related functionality
		 */
		public function hooks_for_compatibility() {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			if ( is_plugin_active( 'woocommerce-paypal-payments/woocommerce-paypal-payments.php' ) ) {
				add_filter( 'wc_sc_query_to_find_order_id', array( $this, 'query_to_find_order_id' ), 20, 2 );
				add_filter( 'woocommerce_paypal_payments_cart_extra_discount', array( $this, 'cart_extra_discount' ), 10, 2 );
				add_filter( 'woocommerce_paypal_payments_store_api_cart_extra_discount', array( $this, 'store_api_cart_extra_discount' ), 10, 2 );
			}
		}

		/**
		 * Store-credit discount applied to tax that PayPal Payments does not see.
		 *
		 * With "Apply before tax" off, store credit that covers part of the tax is stored only in
		 * WC_Cart::get_discount_tax(); it is not in get_discount_total() and get_total_tax() is not
		 * reduced. PayPal Payments builds its amount from those getters and omits get_discount_tax(),
		 * so its amount is too high by this portion. Returned only when store credit is applied and
		 * applied after tax, so normal coupons (handled correctly by PayPal) are never affected.
		 *
		 * @param WC_Cart|null $cart The cart.
		 * @return float
		 */
		private function get_store_credit_tax_discount( $cart = null ) {
			$cart = ( $cart instanceof WC_Cart ) ? $cart : WC()->cart;
			if ( ! $cart instanceof WC_Cart ) {
				return 0.0;
			}
			if ( 'yes' === get_option( 'woocommerce_smart_coupon_apply_before_tax', 'no' ) ) {
				return 0.0;
			}
			if ( ! $this->cart_has_store_credit( $cart ) ) {
				return 0.0;
			}
			$discount_tax = is_callable( array( $cart, 'get_discount_tax' ) ) ? (float) $cart->get_discount_tax() : 0.0;
			return max( 0.0, $discount_tax );
		}

		/**
		 * Whether a store-credit (smart_coupon) coupon is applied to the cart.
		 *
		 * The transient WC_Cart::$smart_coupon_credit_used is not reliably set when PayPal reads the
		 * cart, so detect store credit from the applied coupons instead. Only when a smart_coupon is
		 * applied does Smart Coupons keep the tax discount solely in get_discount_tax(); for normal
		 * coupons WooCommerce already reduces get_total_tax(), so PayPal is correct without us.
		 *
		 * @param WC_Cart $cart The cart.
		 * @return bool
		 */
		private function cart_has_store_credit( $cart ) {
			$applied = is_callable( array( $cart, 'get_applied_coupons' ) ) ? $cart->get_applied_coupons() : array();
			if ( empty( $applied ) ) {
				return false;
			}
			foreach ( $applied as $code ) {
				$coupon = new WC_Coupon( $code );
				if ( is_callable( array( $coupon, 'get_discount_type' ) ) && 'smart_coupon' === $coupon->get_discount_type() ) {
					return true;
				}
			}
			return false;
		}

		/**
		 * Add the store-credit tax portion to PayPal Payments' classic cart discount.
		 *
		 * @param float        $extra Extra discount accumulated by other plugins.
		 * @param WC_Cart|null $cart  The cart.
		 * @return float
		 */
		public function cart_extra_discount( $extra = 0, $cart = null ) {
			return (float) $extra + $this->get_store_credit_tax_discount( $cart );
		}

		/**
		 * Add the store-credit tax portion to PayPal Payments' block (Store API) cart discount.
		 *
		 * The filter contract expects an integer in the currency's minor unit (e.g. cents).
		 *
		 * @param int $extra Extra discount in minor units accumulated by other plugins.
		 * @return int
		 */
		public function store_api_cart_extra_discount( $extra = 0 ) {
			$discount_tax = $this->get_store_credit_tax_discount( WC()->cart );
			if ( $discount_tax <= 0 ) {
				return (int) $extra;
			}
			return (int) $extra + (int) round( $discount_tax * ( 10 ** wc_get_price_decimals() ) );
		}

		/**
		 * Prepare query to find order id
		 *
		 * @param string $query The query.
		 * @param array  $args Additional arguments.
		 * @return string
		 */
		public function query_to_find_order_id( $query = '', $args = array() ) {
			try {
				global $wpdb;

				$posted_data = array();
                $post_data            = isset( $_POST['post_data'] ) && ! empty( $_POST['post_data'] ) ? wc_clean( wp_unslash( $_POST['post_data'] ) ) : ''; // phpcs:ignore
				wp_parse_str( $post_data, $posted_data );

                $post_payment_method = ( ! empty( $_POST['payment_method'] ) ) ? wc_clean( wp_unslash( $_POST['payment_method'] ) ) : ''; // phpcs:ignore

				if ( empty( $posted_data['payment_method'] ) && ! empty( $post_payment_method ) ) {
					$posted_data['payment_method'] = $post_payment_method;
				}

				$chosen_payment_method = ( ! empty( $posted_data['payment_method'] ) ) ? $posted_data['payment_method'] : '';

				if ( ! empty( $chosen_payment_method ) && 0 === strpos( $chosen_payment_method, 'ppcp-' ) ) {
					$emails = ( ! empty( $args['emails'] ) ) ? $args['emails'] : array();
					if ( $this->is_hpos() ) {
						list( $email_sql, $email_values ) = $this->prepare_email_condition_parts( $emails, 'pm.meta_value' );
                        // phpcs:disable
                        $query                            = $wpdb->prepare(
                            "SELECT id
                            FROM {$wpdb->prefix}wc_orders AS p
                            LEFT JOIN {$wpdb->prefix}wc_orders_meta AS pm
                                ON ( p.id = pm.order_id AND pm.meta_key = %s )
                            WHERE p.type = %s
                                AND {$email_sql}",
                            '_ppcp_paypal_billing_email',
                            'shop_order',
                            ...$email_values
                        );
                        // phpcs:enable
					} else {
						list( $email_sql, $email_values ) = $this->prepare_email_condition_parts( $emails, 'pm.meta_value' );
                        // phpcs:disable
                        $query                            = $wpdb->prepare(
                            "SELECT ID
                            FROM $wpdb->posts AS p
                            LEFT JOIN $wpdb->postmeta AS pm
                                ON ( p.ID = pm.post_id AND pm.meta_key = %s )
                            WHERE p.post_type = %s
                                AND {$email_sql}",
                            '_ppcp_paypal_billing_email',
                            'shop_order',
                            ...$email_values
                        );
                        // phpcs:enable
					}
				}
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}

			return $query;
		}
	}

}

WC_SC_PPCP_Compatibility::get_instance();
