<?php
namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
require 'abstract-db-table.php';
require 'abstract-stat-value-table.php';
require 'class-stat-orders-table.php';
require 'class-stat-order-products-table.php';
require 'class-stat-landing-table.php';
require 'class-stat-trafic-table.php';
require 'class-stat-utm_medium-table.php';
require 'class-stat-utm_source-table.php';
require 'class-stat-utm_term-table.php';
require 'class-stat-utm_campaing-table.php';
require 'class-stat-utm_content-table.php';
//require 'class-stat-custom-event-table.php';

class DataBaseManager {

    private $db_version = "1.0.6.5";

    /**
     * @return DataBaseTable[]
     */
    function get_tables() {
        return apply_filters("pys_db_tables",[]);
    }

    function create_table() {
        $current = get_option("pys_db_version","0.0.0");

        if(version_compare($current, "1.0.6.3", '<=')) {

            $this->drop_tables();
            $current = "0.0.0";
            update_option(WooOrderStatistic::$stat_order_imported_page, 1);
            update_option(WooOrderStatistic::$db_sync_status,OrderStatistics::$SYNC_STATUS_START);
            update_option(EddOrderStatistic::$stat_order_imported_page, 1);
            update_option(EddOrderStatistic::$db_sync_status,OrderStatistics::$SYNC_STATUS_START);
        }
        if(version_compare($current, "0.0.0", '==')) {
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            $allCreated = true;
            $tables = $this->get_tables();
            foreach ($tables as $table) {
                $status = $table->create();
                if(!$status) {
                    $allCreated = false;
                    error_log("Error create table ".$table->getName()." sql ".$table->getCreateSql());
                }
            }

            if($allCreated) {
                update_option("pys_db_version",$this->db_version);
            }
        }

        if ( version_compare($current, "1.0.6.4", '<=') && version_compare($current, "0.0.0", '>') ) {
            if ( $this->add_report_indexes() ) {
                update_option("pys_db_version", $this->db_version);
            }
        }
    }

    /**
     * Add the composite (type,date) index plus per-dimension indexes to the
     * stat-orders table, so the attribution report queries (get_attribution_*)
     * and the Reports UI use index range scans instead of full table scans.
     * Only missing indexes are added, in ONE combined ALTER (a single table
     * rebuild), which keeps the method idempotent and cheap to re-run.
     *
     * @return bool True when the indexes are present (added now or already there).
     */
    private function add_report_indexes() {
        global $wpdb;
        $table = $wpdb->prefix . "pys_stat_order";

        $indexes = array(
            'idx_type_date'           => '(`type`, `date`)',
            'idx_traffic_source'      => '(`traffic_source_id`)',
            'idx_landing'             => '(`landing_id`)',
            'idx_utm_source'          => '(`utm_source_id`)',
            'idx_utm_medium'          => '(`utm_medium_id`)',
            'idx_utm_campaign'        => '(`utm_campaing_id`)',
            'idx_utm_term'            => '(`utm_term_id`)',
            'idx_utm_content'         => '(`utm_content_id`)',
            'idx_last_traffic_source' => '(`last_traffic_source_id`)',
            'idx_last_landing'        => '(`last_landing_id`)',
            'idx_last_utm_source'     => '(`last_utm_source_id`)',
            'idx_last_utm_medium'     => '(`last_utm_medium_id`)',
            'idx_last_utm_campaign'   => '(`last_utm_campaing_id`)',
            'idx_last_utm_term'       => '(`last_utm_term_id`)',
            'idx_last_utm_content'    => '(`last_utm_content_id`)',
        );

        $clauses = array();
        foreach ( $indexes as $name => $cols ) {
            if ( ! $this->index_exists($table, $name) ) {
                $clauses[] = "ADD INDEX `{$name}` {$cols}";
            }
        }
        if ( empty($clauses) ) {
            return true; // all indexes already present
        }

        $result = $wpdb->query( "ALTER TABLE `{$table}` " . implode(", ", $clauses) );
        if ( false === $result ) {
            error_log( "[PYS] add_report_indexes failed on {$table}: " . $wpdb->last_error );
            return false;
        }

        return true;
    }

    /**
     * Whether a named index exists on a table. Portable across all MySQL/MariaDB
     * versions (information_schema) — used instead of `ADD INDEX IF NOT EXISTS`,
     * which is MariaDB-only.
     *
     * @param string $table
     * @param string $index_name
     * @return bool
     */
    private function index_exists($table, $index_name) {
        global $wpdb;

        return (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(1) FROM information_schema.statistics
             WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s",
            $table,
            $index_name
        ) );
    }

    public  function drop_tables() {
        global $wpdb;

        $tables = $this->get_tables();

        foreach ( $tables as $table ) {
            $wpdb->query( "DROP TABLE IF EXISTS {$table->getName()}" );
        }
    }



}