<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class CustomEventFactory {

	/**
	 * Per-request cache of full event lists, keyed by state.
	 *
	 * get() runs an uncached get_posts() with a meta_query and instantiates a
	 * CustomEvent per row. It is called several times per request from the event
	 * managers, including once per registered pixel in some paths, always for the
	 * same rows. Requests never see events created by another request, so a
	 * request-scoped cache is safe; writes inside this request invalidate it.
	 *
	 * @var array<string, array>
	 */
	private static $cache = array();

	/**
	 * Drop the cached event lists. Call after any write to a pys_event post.
	 */
	public static function flushCache() {
		self::$cache = array();
	}

	public static function create( $args ) {

		// create event post object
		$post_id = wp_insert_post( array(
			'post_title'     => empty( $args['title'] ) ? 'Untitled' : sanitize_text_field( $args['title'] ),
			'post_type'      => 'pys_event',
			'post_status'    => 'publish',
			'ping_status'    => 'closed',
			'comment_status' => 'closed',
		), true );

		if ( is_wp_error( $post_id ) ) {
			return false;
		}

		$event = new CustomEvent( $post_id );
		$event->update( $args );

		return $event;

	}

    public static function import( $args ) {

        // create event post object
        $post_id = wp_insert_post( array(
            'post_title'     => sanitize_text_field( $args['title'] ),
            'post_type'      => 'pys_event',
            'post_status'    => 'publish',
            'ping_status'    => 'closed',
            'comment_status' => 'closed',
        ), true );

        if ( is_wp_error( $post_id ) ) {
            return false;
        }

        $event = new CustomEvent( $post_id );
        $event->setData( $args );

        return $event;

    }

	/**
	 * @param string $state Event state. Can be 'any', 'active' or 'paused'
	 * @param null   $post_id
	 *
	 * @return array
	 */
	public static function get( $state = 'any', $post_id = null ) {

		// Single-post lookups are cheap and rare — never cached.
		if ( ! isset( $post_id ) && isset( self::$cache[ $state ] ) ) {
			return self::$cache[ $state ];
		}

		$limit = isset( $post_id ) ? 1 : -1;

		$args = array(
			'post_type'   => 'pys_event',
			'numberposts' => $limit,
			'meta_query'  => array(
				'relation' => 'AND'
			)
		);

		if( isset( $post_id ) ) {
			$args['include'] = (int) $post_id;
		}

		if ( $state !== 'any' ) {

			$args['meta_query'][] = array(
				'key'   => '_pys_event_state',
				'value' => $state
			);

		}

		$results = array();

		foreach ( get_posts( $args ) as $post ) {
			$results[ $post->ID ] = new CustomEvent( $post->ID );
		}

		//wp_reset_postdata();

		if ( ! isset( $post_id ) ) {
			self::$cache[ $state ] = $results;
		}

		return $results;

	}

	/**
	 * @param $post_id
	 *
	 * @return CustomEvent
	 */
	public static function getById( $post_id ) {

		$results = self::get( 'any', $post_id );

		if ( isset( $results[ $post_id ] ) ) {
			return $results[ $post_id ];
		} else {
			return new CustomEvent();
		}

	}

	public static function remove( $post_id ) {
		wp_delete_post( $post_id, true );
	}
	
	public static function makeClone( $post_id ) {
		
		if ( $event = self::getById( $post_id ) ) {
			
			$args = array(
				'title' => $event->getTitle() . ' (duplicate)',
			);
			
			// create new event
			$new_event = self::create( $args );
			
			if ( ! $new_event ) {
				return;
			}
            $data = get_post_meta( $event->getPostId(), '_pys_event_data' );
            $triggers = $event->getTriggers();
            $conditions = $event->getConditions();
			// copy meta from original event
            foreach ( $data as $meta_value ) {
                update_post_meta( $new_event->getPostId(), '_pys_event_data', maybe_unserialize( $meta_value ) );
            }
            if($triggers){
                update_post_meta( $new_event->getPostId(), '_pys_event_triggers', addslashes( serialize( $triggers ) ) );
            }
            if($conditions){
                update_post_meta( $new_event->getPostId(), '_pys_event_conditions', addslashes( serialize( $conditions ) ) );
            }
			
			// disable cloned event
			$new_event->disable();

		}

	}

}

/**
 * Invalidate the per-request event cache whenever a pys_event changes.
 *
 * All custom-event data lives in post meta prefixed `_pys_event_`, so watching
 * those meta writes covers CustomEvent::update()/setData() as well as direct
 * update_post_meta() calls elsewhere in the plugin.
 */
add_action( 'save_post_pys_event', array( CustomEventFactory::class, 'flushCache' ) );
add_action( 'deleted_post', array( CustomEventFactory::class, 'flushCache' ) );

foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $pys_meta_hook ) {
	add_action( $pys_meta_hook, function ( $meta_id, $object_id, $meta_key ) {
		if ( strpos( (string) $meta_key, '_pys_event_' ) === 0 ) {
			CustomEventFactory::flushCache();
		}
	}, 10, 3 );
}
unset( $pys_meta_hook );