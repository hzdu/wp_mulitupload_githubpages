<?php
/**
 * Shared base for the read-only PYS attribution-reports abilities
 * (`get_attribution_summary`, `get_attribution_drill`). Holds the common
 * store detection, OrderStatistics access, date-range resolution and the
 * store/reports guard. WooCommerce and EDD are ALWAYS separate — never combined.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class AbstractReportsAbility extends AbstractAbility {

	/** Attribution dimensions (mirror OrderStatistics::getCollNameByTag tags). */
	protected const DIMENSIONS = array(
		'traffic_source',
		'traffic_landing',
		'utm_source',
		'utm_medium',
		'utm_campaign',
		'utm_content',
		'utm_term',
	);

	/** Hard cap on rows in any single MCP response (token budget). */
	protected const MAX_ROWS = 20;

	/**
	 * WooCommerce active?
	 *
	 * @return bool
	 */
	protected static function isWooActive(): bool {
		return function_exists( 'WC' ) || class_exists( 'WooCommerce' );
	}

	/**
	 * Easy Digital Downloads active?
	 *
	 * @return bool
	 */
	protected static function isEddActive(): bool {
		return function_exists( 'EDD' ) || class_exists( 'Easy_Digital_Downloads' );
	}

	/**
	 * The OrderStatistics instance for a store, or null if unavailable.
	 *
	 * @param string $store woo | edd.
	 * @return \PixelYourSite\OrderStatistics|null
	 */
	protected static function getStatistic( string $store ) {
		if ( !function_exists( '\\PixelYourSite\\PysStatistic' ) ) {
			return null;
		}
		$s = \PixelYourSite\PysStatistic();
		if ( 'woo' === $store ) {
			return $s->wooStatistic ?? null;
		}
		if ( 'edd' === $store ) {
			return $s->eddStatistic ?? null;
		}
		return null;
	}

	/**
	 * Guard: store active + PYS reports enabled + statistic object available.
	 * Returns the OrderStatistics instance, or a WP_Error to short-circuit.
	 *
	 * @param string $store woo | edd.
	 * @return \PixelYourSite\OrderStatistics|\WP_Error
	 */
	protected static function requireStore( string $store ) {
		if ( 'woo' === $store && !self::isWooActive() ) {
			return new \WP_Error( 'pys_mcp_store_not_active', 'WooCommerce is not active on this site.', array( 'status' => 409 ) );
		}
		if ( 'edd' === $store && !self::isEddActive() ) {
			return new \WP_Error( 'pys_mcp_store_not_active', 'Easy Digital Downloads is not active on this site.', array( 'status' => 409 ) );
		}

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		$opt = 'woo' === $store ? 'woo_enabled_save_data_to_orders' : 'edd_enabled_save_data_to_orders';
		if ( null === $pys || !$pys->getOption( $opt ) ) {
			return new \WP_Error(
				'pys_mcp_reports_disabled',
				sprintf( 'PYS %s reports are not enabled — turn on "Save data to orders" in PYS → %s settings.', strtoupper( $store ), 'woo' === $store ? 'WooCommerce' : 'EDD' ),
				array( 'status' => 409 )
			);
		}

		$stat = self::getStatistic( $store );
		if ( !$stat ) {
			return new \WP_Error( 'pys_mcp_stat_unavailable', 'Reports statistic object is not available.', array( 'status' => 503 ) );
		}
		return $stat;
	}

	/**
	 * Resolve a date_range preset to [startDate, endDate] in Y-m-d (inclusive).
	 * The caller adds +1 day to endDate before passing to the query methods
	 * (matching the existing loadStatData/exportGPT pattern).
	 *
	 * @param string $range Preset name.
	 * @param string $start Custom start (Y-m-d), used when range = custom.
	 * @param string $end   Custom end (Y-m-d), used when range = custom.
	 * @return array{0: string, 1: string}
	 */
	protected static function resolveDates( string $range, string $start = '', string $end = '' ): array {
		$today = current_time( 'Y-m-d' );
		switch ( $range ) {
			case 'today':
				return array( $today, $today );
			case 'last_7_days':
				return array( date( 'Y-m-d', strtotime( '-6 days', strtotime( $today ) ) ), $today );
			case 'last_90_days':
				return array( date( 'Y-m-d', strtotime( '-89 days', strtotime( $today ) ) ), $today );
			case 'this_month':
				return array( date( 'Y-m-01', strtotime( $today ) ), $today );
			case 'last_month':
				$first = date( 'Y-m-01', strtotime( 'first day of last month', strtotime( $today ) ) );
				$last  = date( 'Y-m-t', strtotime( 'last day of last month', strtotime( $today ) ) );
				return array( $first, $last );
			case 'custom':
				if ( '' !== $start && '' !== $end ) {
					return array( sanitize_text_field( $start ), sanitize_text_field( $end ) );
				}
				// Missing custom bounds → fall through to the default.
			case 'last_30_days':
			default:
				return array( date( 'Y-m-d', strtotime( '-29 days', strtotime( $today ) ) ), $today );
		}
	}

	/** endDate + 1 day (query methods use an exclusive upper bound). */
	protected static function endPlusOne( string $endDate ): string {
		return date( 'Y-m-d', strtotime( $endDate . ' + 1 days' ) );
	}

	/**
	 * Shared date-input schema properties for the reports abilities. Besides the
	 * canonical `date_range` / `date_start` / `date_end`, it whitelists the
	 * `date_from` / `date_to` and `start_date` / `end_date` aliases that models
	 * commonly emit — without them `additionalProperties:false` rejects the whole
	 * call as invalid input ("date_from is not a valid property of Object").
	 *
	 * @return array<string, array>
	 */
	protected static function dateInputProperties(): array {
		return array(
			'date_range' => array(
				'type'        => 'string',
				'enum'        => array( 'today', 'last_7_days', 'last_30_days', 'last_90_days', 'this_month', 'last_month', 'custom' ),
				'default'     => 'last_30_days',
				'description' => 'Preset range. Omit and pass explicit start/end for a custom range.',
			),
			'date_start' => array( 'type' => 'string', 'description' => 'Custom range start, format Y-m-d. Aliases: date_from, start_date. Passing start + end implies a custom range.' ),
			'date_end'   => array( 'type' => 'string', 'description' => 'Custom range end, format Y-m-d. Aliases: date_to, end_date. Passing start + end implies a custom range.' ),
			'date_from'  => array( 'type' => 'string', 'description' => 'Alias for date_start (Y-m-d).' ),
			'date_to'    => array( 'type' => 'string', 'description' => 'Alias for date_end (Y-m-d).' ),
			'start_date' => array( 'type' => 'string', 'description' => 'Alias for date_start (Y-m-d).' ),
			'end_date'   => array( 'type' => 'string', 'description' => 'Alias for date_end (Y-m-d).' ),
		);
	}

	/**
	 * Resolve [startDate, endDate] (Y-m-d) from validated input, honouring
	 * `date_range` and the date_start/date_end aliases. When no range is given
	 * but explicit start + end are, the range is treated as `custom`.
	 *
	 * @param mixed $input Validated args.
	 * @return array{0: string, 1: string}
	 */
	protected static function resolveDatesFromInput( $input ): array {
		$input = is_array( $input ) ? $input : array();
		$start = self::firstNonEmptyArg( $input, array( 'date_start', 'date_from', 'start_date' ) );
		$end   = self::firstNonEmptyArg( $input, array( 'date_end', 'date_to', 'end_date' ) );
		$range = (string) ( $input[ 'date_range' ] ?? '' );
		if ( '' === $range ) {
			$range = ( '' !== $start && '' !== $end ) ? 'custom' : 'last_30_days';
		}

		return self::resolveDates( $range, $start, $end );
	}

	/**
	 * First non-empty trimmed string among the given input keys.
	 *
	 * @param array $input Input args.
	 * @param array $keys  Candidate keys, in priority order.
	 * @return string
	 */
	private static function firstNonEmptyArg( array $input, array $keys ): string {
		foreach ( $keys as $k ) {
			if ( isset( $input[ $k ] ) && is_string( $input[ $k ] ) && '' !== trim( $input[ $k ] ) ) {
				return trim( $input[ $k ] );
			}
		}

		return '';
	}

	/**
	 * Loud warning when the store's reports import has not FINISHED — the figures
	 * are partial and can be internally inconsistent (cost/profit exceeding
	 * revenue). Returned as an explicit response field so it cannot be missed
	 * (relying on sync_status alone is fragile). Null when sync is complete.
	 *
	 * @param \PixelYourSite\OrderStatistics $stat Statistic instance.
	 * @return string|null
	 */
	protected static function syncIncompleteWarning( $stat ): ?string {
		if ( \PixelYourSite\OrderStatistics::$SYNC_STATUS_FINISH === $stat->getSyncStatus() ) {
			return null;
		}
		return 'Reports sync for this store has NOT finished (sync_status: ' . (string) $stat->getSyncStatus()
			. ') — these figures are PARTIAL and may be internally inconsistent (cost/profit can exceed revenue). Do NOT present them as final; finish the import in PixelYourSite → Reports first.';
	}
}