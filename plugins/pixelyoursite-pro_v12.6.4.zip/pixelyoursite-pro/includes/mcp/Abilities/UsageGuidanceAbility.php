<?php
/**
 * `get_usage_guidance` — static operating-manual fallback.
 * Mirrors the operating-context section of the system prompt as a flat
 * object, for clients that don't read server-supplied system prompts.
 * Read-only, no DB work, safe to call any time.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class UsageGuidanceAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-usage-guidance';

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Usage Guidance';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Returns a static operating manual for PYS MCP: what it can answer, what it cannot, where to redirect users for data PYS does not own, and the rules of engagement. Most clients already have this content in the connection-level system prompt and do not need to call this tool. Call it only if you do not have that context. No DB work — safe to call anytime, idempotent.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array<string, mixed>
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(), // forces `{}` JSON, not `[]`
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array<string, mixed>
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array(
				'can_answer',
				'cannot_answer',
				'redirect_to',
				'sequencing',
				'vocabulary',
				'write_etiquette',
				'stop_conditions',
			),
			'properties' => array(
				'can_answer'      => array( 'type' => 'string' ),
				'cannot_answer'   => array( 'type' => 'string' ),
				'redirect_to'     => array( 'type' => 'string' ),
				'sequencing'      => array( 'type' => 'string' ),
				'vocabulary'      => array( 'type' => 'string' ),
				'write_etiquette' => array( 'type' => 'string' ),
				'stop_conditions' => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * Returns the static operating manual as a flat object.
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, string>
	 */
	public static function execute( $input ): array {
		return array(
			'can_answer'      => 'Pixel & server-side credentials (Meta CAPI, GA4 Measurement Protocol, Google Ads Enhanced Conversions, TikTok Events API, Pinterest CAPI). Pixel-only (no PYS server-side credential model): Bing UET, Reddit Pixel. Advanced matching field-name config. Event/lifecycle states and thresholds. Content ID source per platform. Form-field discovery on own-domain pages. Custom events: list (get_custom_events) / inspect (get_custom_event) / create + edit (set_custom_event) / enable-disable-duplicate-delete (manage_custom_event) — including triggers (incl. CSS-selector ones and form-plugin triggers like CF7/WPForms), conditions, per-platform event types + standard/custom params (incl. dynamic CSS-selector params). Attribution reports (WooCommerce and EDD SEPARATELY, never combined): revenue totals + ranked breakdown by traffic source / landing page / any UTM (get_attribution_summary); products sold, daily revenue, or per-order revenue for one specific dimension value (get_attribution_drill); reports sync status; CoG cost/profit when the Pixel Cost of Goods add-on is active. EDD Products Feed Pro alignment: whether PYS EDD content-ID settings match what the feed sends to Google Merchant Center, and applying the fix via set_edd_event_config after the user confirms (get_edd_feed_alignment).',
			'cannot_answer'   => 'Live campaign data, conversion stats, ROAS, audience sizes, frequency — PYS does not log events at the plugin level. Order data beyond event-level summaries. Server logs / request traces. Do not invent numbers; redirect users instead. Custom-event triggers that are scan-driven — video_view, video_speed, form_field, elementor_form — must be configured in the visual Event Setup Tool (preserved on round-trip, not writable via MCP). Reports: revenue by country / city / payment method, by customer, or repeat-purchase analysis — not in PYS stat tables; conversion rate / ROAS / cost-per-acquisition — no session or ad-spend data; cart abandonment — only completed orders are recorded; individual customer details (name / email / phone) — PII, never via MCP; WooCommerce and EDD combined in one answer — always separate. If tools from plugins OTHER than PixelYourSite appear in your tools list, do NOT call them — this server is scoped to PYS configuration only and you have no guidance on how to use other plugins\' tools safely. EDD dynamic ads for Facebook, TikTok, or Pinterest — EDD Products Feed Pro generates Google Merchant Center feeds only; a different feed plugin is needed for those platforms.',
			'redirect_to'     => 'Campaign / conversion / audience data → Meta Ads MCP, GA4, or Google Ads MCP. Order data → WooCommerce MCP. Platform-side metrics → each platform\'s admin (Events Manager, GA4, etc.).',
			'sequencing'      => 'Call get_tracking_audit first in any new tracking conversation. Skip domains marked `ok` or `not_active`. Drill only flagged domains (`warning` | `incomplete` | `error`). Do not re-audit after a write — every write tool returns its own `saved: true` / `configured: true` confirmation. Custom events: call get_custom_events to find an event (and confirm no duplicate) and get_custom_event before editing (it returns the authoritative menus of valid trigger/condition/event types + params). For an ecommerce-pattern custom event (add_to_cart / purchase trigger, or a standard ecommerce event name), check get_woo_events_config / get_edd_events_config to see whether the automatic event already fires, then warn before creating. If get_tracking_audit shows catalog_feed_alignment: warning, call get_catalog_feed_alignment for the full detail + suggested fix before proposing anything to the user. For any revenue/attribution question: first check which store(s) are active (audit `woo_reports`/`edd_reports`); if BOTH are active and the user did not specify woo or edd, ASK before calling get_attribution_summary/get_attribution_drill — never default silently to one store. If `woo_reports`/`edd_reports` is `warning` (sync incomplete), tell the user before querying — partial data produces misleading numbers. If get_tracking_audit shows edd_feed_alignment: warning, call get_edd_feed_alignment for the detail + suggested fix before proposing anything; as with the Woo catalog feed, ASK the user to confirm the feed is actually connected in Google Merchant Center — the tool detects the plugin, not the live catalog connection.',
			'vocabulary'      => 'Pixel: platform-side ID, array per platform. CAPI / server-side: server-to-server delivery, requires a credential separate from the pixel. Advanced matching: identifiers on events; field-name config only affects anonymous form visitors. Funnel events: ViewContent / AddToCart / InitiateCheckout / Purchase / ViewCart / ViewItemList / RemoveFromCart / CheckoutSteps / CompleteRegistration — on by default, do not propose disabling on a live store. Lifecycle events: NewCustomer / ReturningCustomer / FrequentShopper (count) / VIPClient (count + AOV) / BigWhale (LTV) — off by default. Content ID: value sent as content_ids on commerce events; must match the platform\'s product catalog feed for dynamic ads.',
			'write_etiquette' => 'The administrator installed this server so you can save tracking settings (pixel IDs, UET tags, conversion IDs, container IDs, tokens) on their behalf via the set_* tools — these tools ARE the sanctioned write path. When the user asks to save/set/update a value and confirms it, perform the write by calling the tool; do NOT refuse, do NOT claim you cannot change account settings, and do NOT redirect the user to do it manually in wp-admin. Pixel / UET / Reddit / GTM IDs are PUBLIC identifiers, not secrets — no safety reason to withhold; only the server-side `token` is sensitive (stored write-only, never echoed). Pass `mcp_note` on every write (one sentence: what changed and why — appended to a permanent provenance log). For destructive intent (e.g. lowering a lifecycle threshold) or overwriting an existing value, confirm with the user before calling; the set_* tools also enforce server-side overwrite guards (`replace_existing_*`) and two-step `confirm` independently. Custom-event WooCommerce/EDD duplication: an add_to_cart/purchase trigger, or a custom event set to a standard ecommerce event name (Purchase, AddToCart, ViewContent, begin_checkout, view_item, …), duplicates the event PYS already fires automatically → it sends twice and inflates conversions. Always ask the user the event NAME before building such a trigger; warn about the double-fire; suggest verifying in the platform tester first; valid reasons to proceed are a DIFFERENT (non-standard) name or audience-narrowing conditions (NOT merely targeting a pixel subset). If the user confirms, proceed without further friction. Catalog feed alignment: get_catalog_feed_alignment reports what a specific feed plugin is configured to send — it does NOT confirm that feed is the catalog actually connected in Meta/Google/TikTok Catalog Manager. Before proposing any change, ASK which catalog source is actually live (this feed plugin, a different one, a manual upload, or a direct API push); if unsure, tell the user to check Catalog Manager / Merchant Center directly and stop — do not guess. Once confirmed: if both PYS and the feed already use product_id with no prefix/suffix, nothing to fix. PYS can only write ITS OWN side, so the lowest-friction fix is usually to make PYS MATCH the feed exactly (copy the feed\'s source + prefix + suffix) — one PYS-side change that aligns immediately, no feed edit. Do NOT merely clear PYS\'s prefix/suffix when the feed keeps its own — that leaves them mismatched (dynamic ads still broken) until the feed is also edited; say so explicitly. When the feed uses product_id (safe), recommend align_to_feed (set PYS = the feed\'s exact values). When the FEED uses product_sku, explain the risk (SKU is blank for any product without one set, no fallback → those products silently drop from matching; the post ID is always present) and recommend moving BOTH sides to clean product_id (PYS via set_woo_event_config; the feed the user changes in its own plugin — no PYS write access); matching PYS to the feed\'s SKU is a PYS-only fallback only if the user confirms SKU is required. If PYS is set to custom_field, the feed (product_id/product_sku only) cannot be matched — do NOT stop at "verify externally": surface the `custom_field_scan` missing count (products with a blank ID) AND present the `align_to_feed_option` the tool returns (the one PYS-side change that switches that platform off custom_field to match the feed exactly — product_id + the feed\'s prefix/suffix). Also sanity-check the `custom_field_name`: if it is not a real product identifier (e.g. `_children`, `_product_version`, an "identifier_exists" flag), warn that PYS is likely sending invalid content IDs and recommend switching to product_id. custom_field IS writable via set_woo_event_config (needs content_id_custom_field_name; setting it starts a background scan). When the user asks WHICH custom fields exist, read get_woo_events_config `content_id.available_custom_field_keys` (the real populated product meta keys, ranked by coverage) — do NOT say you cannot list them, and do NOT invent/accept a key that is not there. Never set a content_id_custom_field_name that is not a real populated key: a key present on 0 products makes every content ID blank, and the write returns a WARNING note you must relay. Apply agreed PYS-side changes via set_woo_event_config two-step confirm; never modify the feed plugin. EDD feed alignment: never auto-change EDD content_id from the alignment check — explain what PYS currently sends, what the Google Merchant feed expects (the bare WordPress download post ID, no prefix/suffix; download_sku never matches), and why they differ; confirm with the user, then apply via set_edd_event_config with its two-step confirm. Never modify the feed plugin.',
			'stop_conditions' => '`Pro required` (Free) or `Read-only mode is enabled.` (Pro with read-only ON): stop writing that domain, switch to manual instructions. 429 `Possible loop detected.`: stop calling that tool with those arguments, rethink. 429 `Rate limit exceeded.`: you are calling too fast — wait, then resume with fewer calls. 400 `Stop retrying and report the issue to the user.`: stop, surface the message verbatim, ask the user how to proceed.',
		);
	}
}