<?php
/**
 * `get_edd_events_config` — read-only snapshot of EDD event config.
 * Returns `{ available: false }` when EDD is off, else mirrors
 * `get_woo_events_config`. EDD differences: lifecycle is FrequentShopper /
 * VIPClient / BigWhale only; subscriptions = track_subscriptions +
 * track_licenses (no POAS); content_id has no logic/variable/wpml;
 * value_settings is tax + order-id prefix only (digital — no shipping).
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\Platforms;
use PixelYourSite\MCP\EventToggleMap;

final class GetEddEventsConfigAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-edd-events-config';

	private const ADMIN_UI_PATH = 'PixelYourSite → Easy Digital Downloads';

	/** Funnel event name => core option key. */
	private const FUNNEL_KEYS = array(
		'ViewContent'      => 'edd_view_content_enabled',
		'ViewCategory'     => 'edd_view_category_enabled',
		'AddToCart'        => 'edd_add_to_cart_enabled',
		'InitiateCheckout' => 'edd_initiate_checkout_enabled',
		'Purchase'         => 'edd_purchase_enabled',
		'RemoveFromCart'   => 'edd_remove_from_cart_enabled',
	);

	/** content_id sub-keys read per-platform (EDD: source/prefix/suffix only). */
	private const CONTENT_ID_KEYS = array(
		'source' => 'edd_content_id',
		'prefix' => 'edd_content_id_prefix',
		'suffix' => 'edd_content_id_suffix',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get EDD Events Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Returns the full Easy Digital Downloads event configuration for PYS in one response. Returns `{ "available": false }` immediately if EDD is not active. Sections: `funnel_events` (compact `{ all_enabled: true }` when all default-enabled, else the per-event map), `lifecycle_events` (FrequentShopper / VIPClient / BigWhale with thresholds — EDD has NO FirstTimeBuyer/ReturningCustomer), `subscriptions` (`track_subscriptions` + `track_licenses` plus `recurring_plugin_active` / `licensing_plugin_active` flags — those toggles are editable only when their plugin is active; no POAS for EDD), `content_id` (source / prefix / suffix — EDD has no logic/variable/wpml; the Google side lives in `gatags`), `value_settings` (tax + order-id prefix — read-only), and `platform_scope` (which active platforms each writable group reaches — answer "which pixels does setting X apply to?" without a write). Call this when the audit shows `edd_events: warning | incomplete | error`, or when the user asks about EDD tracking. Do not call it if the audit shows `edd_events: ok` or `not_active`.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'available' ),
			'properties' => array(
				'available'        => array( 'type' => 'boolean' ),
				'admin_ui_path'    => array( 'type' => 'string' ),
				'platform_scope'   => array(
					'type'                 => 'object',
					'additionalProperties' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' )
					)
				),
				'funnel_events'    => array( 'type' => 'object' ),
				'lifecycle_events' => array( 'type' => 'object' ),
				'subscriptions'    => array( 'type' => 'object' ),
				'content_id'       => array( 'type' => 'object' ),
				'content_id_by_platform' => array(
					'type'                 => 'object',
					'description'          => 'Per-platform content_id values (source/prefix/suffix). Keyed by slug => { source, prefix, suffix }. GA/Google Ads omitted — Google uses the unified `gatags` entry. Write a single platform via `set_edd_event_config` `content_id_platform`.',
					'additionalProperties' => array( 'type' => 'object' ),
				),
				'value_settings'   => array( 'type' => 'object' ),
				'platform_events'  => array(
					'type'                 => 'object',
					'description'          => 'PER-PLATFORM event-firing toggles: for each active platform, which EDD events it is set to fire. An event fires for a platform only when BOTH its global toggle AND the platform toggle here are on. Only events a platform registers are listed (sets differ per platform). Keyed by slug → { event => bool }. Write via `set_edd_event_config` `platform_event_toggles`.',
					'additionalProperties' => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'boolean' ),
					),
				),
				'platform_event_labels' => array(
					'type'                 => 'object',
					'description'          => 'Admin-facing label per (platform, event): e.g. TikTok `purchase` → "PlaceAnOrder", `complete_payment` → "CompletePayment", Pinterest `checkout` → "Checkout", `page_visit` → "PageVisit". Maps UI wording to the stem to write. Keyed by slug → { event => label }.',
					'additionalProperties' => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'string' ),
					),
				),
				'event_groups'     => array(
					'type'                 => 'object',
					'description'          => 'Logical events that fan out to several member stems when toggled via `set_edd_event_config`. `purchase` → `[purchase, checkout, complete_payment]` (covers Pinterest Checkout + TikTok CompletePayment); `view_content` → `[view_content, page_visit]` (covers Pinterest PageVisit). Keyed by logical event → member stems.',
					'additionalProperties' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				),
			),
		);
	}

	/**
	 * Build the read-only EDD config snapshot.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		if ( !function_exists( '\\PixelYourSite\\isEddActive' ) || !\PixelYourSite\isEddActive() ) {
			return array( 'available' => false );
		}

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		if ( null === $pys ) {
			return array( 'available' => false );
		}

		return array(
			'available'        => true,
			'admin_ui_path'    => self::ADMIN_UI_PATH,
			'platform_scope'   => SetEddEventConfigAbility::resolveScope(),
			'funnel_events'    => self::funnelEvents( $pys ),
			'lifecycle_events' => array(
				'FrequentShopper' => array(
					'enabled'      => self::toBool( $pys->getOption( 'edd_frequent_shopper_enabled' ) ),
					'transactions' => (int) $pys->getOption( 'edd_frequent_shopper_transactions', 0 ),
				),
				'VIPClient'       => array(
					'enabled'       => self::toBool( $pys->getOption( 'edd_vip_client_enabled' ) ),
					'transactions'  => (int) $pys->getOption( 'edd_vip_client_transactions', 0 ),
					'average_value' => (float) $pys->getOption( 'edd_vip_client_average_value', 0 ),
				),
				'BigWhale'        => array(
					'enabled' => self::toBool( $pys->getOption( 'edd_big_whale_enabled' ) ),
					'ltv'     => (float) $pys->getOption( 'edd_big_whale_ltv', 0 ),
				),
			),
			'subscriptions'    => array(
				'track_subscriptions'     => self::toBool( $pys->getOption( 'edd_track_subscriptions' ) ),
				'track_licenses'          => self::toBool( $pys->getOption( 'edd_track_licenses' ) ),
				// Each editable only when its plugin is active (set tool 409s otherwise).
				'recurring_plugin_active' => function_exists(
					'\\PixelYourSite\\isEddRecurringActive'
				) ? (bool) \PixelYourSite\isEddRecurringActive() : false,
				'licensing_plugin_active' => function_exists(
					'\\PixelYourSite\\isEddSoftwareLicensingActive'
				) ? (bool) \PixelYourSite\isEddSoftwareLicensingActive() : false,
			),
			'content_id'             => self::contentId(),
			'content_id_by_platform' => self::contentIdByPlatform(),
			'value_settings'   => array(
				'value_mode'      => (string) $pys->getOption( 'edd_event_value', '' ),
				'tax_option'      => (string) $pys->getOption( 'edd_tax_option', '' ),
				'order_id_prefix' => (string) $pys->getOption( 'edd_order_id_prefix', '' ),
			),
			// Per-platform event-firing matrix (slug => { event => bool }).
			'platform_events'        => EventToggleMap::platformMatrix( 'edd' ),
			'platform_event_labels'  => EventToggleMap::labelMatrix( 'edd' ),
			'event_groups'           => EventToggleMap::multiKeyGroups( 'edd' ),
		);
	}

	/**
	 * Build the funnel-events map, collapsing to `{ all_enabled: true }`.
	 *
	 * @param mixed $pys
	 * @return array<string, mixed>
	 */
	private static function funnelEvents( $pys ): array {
		$map   = array();
		$allOn = true;
		foreach ( self::FUNNEL_KEYS as $event => $key ) {
			$on            = self::toBool( $pys->getOption( $key ) );
			$map[ $event ] = $on;
			if ( !$on ) {
				$allOn = false;
			}
		}

		return $allOn ? array( 'all_enabled' => true ) : $map;
	}

	/**
	 * Per-platform content_id (source/prefix/suffix). GA/Ads omitted — Google
	 * content_id is the unified `gatags` entry.
	 *
	 * @return array<string, array<string, string>> slug => { source, prefix, suffix }.
	 */
	private static function contentIdByPlatform(): array {
		$out = array();
		foreach ( Platforms::activeSettings() as $slug => $inst ) {
			if ( in_array( $slug, array( 'google_analytics', 'google_ads' ), true ) ) {
				continue;
			}
			if ( !method_exists( $inst, 'issetOption' ) || !$inst->issetOption( self::CONTENT_ID_KEYS[ 'source' ] ) ) {
				continue;
			}
			$row = array();
			foreach ( self::CONTENT_ID_KEYS as $label => $key ) {
				if ( $inst->issetOption( $key ) ) {
					$row[ $label ] = (string) $inst->getOption( $key, '' );
				}
			}
			if ( !empty( $row ) ) {
				$out[ $slug ] = $row;
			}
		}

		return $out;
	}

	/**
	 * content_id (source/prefix/suffix) read from a representative active
	 * module that registers it; flag divergence across registering modules.
	 *
	 * @return array<string, mixed>
	 */
	private static function contentId(): array {
		$out = array( 'source' => '', 'prefix' => '', 'suffix' => '' );

		// Only modules that register edd_content_id (GA/Ads excluded — the
		// live Google target is gatags).
		$registering = array();
		foreach ( Platforms::activeSettings() as $slug => $settings ) {
			if ( in_array( $slug, array( 'google_analytics', 'google_ads' ), true ) ) {
				continue;
			}
			if ( method_exists( $settings, 'issetOption' ) && $settings->issetOption( 'edd_content_id' ) ) {
				$registering[ $slug ] = $settings;
			}
		}

		if ( !empty( $registering ) ) {
			$first                              = reset( $registering );
			$out[ 'source' ]                    = (string) $first->getOption( self::CONTENT_ID_KEYS[ 'source' ], '' );
			$out[ 'prefix' ]                    = (string) $first->getOption( self::CONTENT_ID_KEYS[ 'prefix' ], '' );
			$out[ 'suffix' ]                    = (string) $first->getOption( self::CONTENT_ID_KEYS[ 'suffix' ], '' );
			$out[ 'diverges_across_platforms' ] = self::contentIdDiverges( $registering );
		}

		return $out;
	}

	/**
	 * Whether content_id (source/prefix/suffix) differs across registering modules.
	 *
	 * @param array $settings
	 * @return bool
	 */
	private static function contentIdDiverges( array $settings ): bool {
		$seen = array();
		foreach ( $settings as $inst ) {
			$sig = array();
			foreach ( self::CONTENT_ID_KEYS as $opt ) {
				$sig[] = (string) $inst->getOption( $opt, '' );
			}
			$seen[ implode( '|', $sig ) ] = true;
			if ( count( $seen ) > 1 ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Normalize a stored option value to a boolean.
	 *
	 * @param mixed $value
	 * @return bool
	 */
	private static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}