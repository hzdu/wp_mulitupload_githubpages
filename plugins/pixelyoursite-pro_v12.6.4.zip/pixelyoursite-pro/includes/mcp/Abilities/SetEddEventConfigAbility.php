<?php
/**
 * `set_edd_event_config` — partial write to Easy Digital Downloads config.
 * Mirror of `SetWooEventConfigAbility` sharing its scope / confirm-gate /
 * plugin-gate machinery. EDD differences:
 *  - Lifecycle = FrequentShopper / VIPClient / BigWhale only.
 *  - Subscriptions = track_subscriptions (EDD Recurring) + track_licenses
 *    (EDD Software Licensing); no POAS.
 *  - content_id = source / prefix / suffix only (no logic/variable/wpml).
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\Platforms;
use PixelYourSite\MCP\EventToggleMap;

final class SetEddEventConfigAbility extends AbstractWriteAbility {

	public const ID = 'pixelyoursite-pro/set-edd-event-config';

	private const MCP_TOOL_NAME = 'set_edd_event_config';

	/** Lifecycle toggles + subscription/license tracking — core + per-active-platform. */
	private const AGGREGATE_ARGS = array(
		'frequent_shopper',
		'vip_client',
		'big_whale',
		'track_subscriptions',
		'track_licenses',
	);

	/**
	 * Thresholds + GLOBAL funnel-event master toggles + value settings — core
	 * only (#8b). Funnel toggles are the global masters; per-platform is
	 * `platform_event_toggles`.
	 */
	private const GLOBAL_ONLY_ARGS = array(
		'frequent_shopper_transactions',
		'vip_client_transactions',
		'vip_client_average_value',
		'big_whale_ltv',
		'purchase',
		'view_content',
		'view_category',
		'add_to_cart',
		'initiate_checkout',
		'remove_from_cart',
		'value_mode',
		'tax_option',
		'order_id_prefix',
	);

	/** content_id family — per-active-platform only (no core), EXCEPT ga/ads. */
	private const PER_PLATFORM_ARGS = array(
		'content_id_source',
		'content_id_prefix',
		'content_id_suffix',
	);

	/** content-id family modules excluded (Google side = gatags). */
	private const CONTENT_ID_FAMILY_ARGS        = array(
		'content_id_source',
		'content_id_prefix',
		'content_id_suffix',
	);
	private const CONTENT_ID_EXCLUDED_PLATFORMS = array( 'google_analytics', 'google_ads' );

	private const BOOL_ARGS  = array(
		'frequent_shopper',
		'vip_client',
		'big_whale',
		'track_subscriptions',
		'track_licenses',
		// Global funnel-event master toggles (#8b).
		'purchase',
		'view_content',
		'view_category',
		'add_to_cart',
		'initiate_checkout',
		'remove_from_cart',
	);
	private const INT_ARGS   = array( 'frequent_shopper_transactions', 'vip_client_transactions' );
	private const FLOAT_ARGS = array( 'vip_client_average_value', 'big_whale_ltv' );

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Set EDD Event Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Writes a partial update to Easy Digital Downloads event configuration. Pro-only. EDD is digital-only, so the surface differs from WooCommerce. Writable: lifecycle toggles (`frequent_shopper`, `vip_client`, `big_whale` — EDD has NO FirstTimeBuyer/ReturningCustomer); lifecycle thresholds (`frequent_shopper_transactions`, `vip_client_transactions`, `vip_client_average_value`, `big_whale_ltv`); `track_subscriptions` (requires the EDD Recurring Payments plugin — 409 if inactive; check `subscriptions.recurring_plugin_active`); `track_licenses` (requires the EDD Software Licensing plugin — 409 if inactive; check `subscriptions.licensing_plugin_active`); content ID (`content_id_source` [`download_id`|`download_sku`], `content_id_prefix`, `content_id_suffix` — EDD has no content_id_logic / variable_as_simple / wpml_unified_id). GLOBAL funnel-event master toggles ARE writable (`purchase`, `view_content`, `view_category`, `add_to_cart`, `initiate_checkout`, `remove_from_cart` — master on/off across ALL platforms). Value settings are writable too: `tax_option` (`included`|`excluded`) and `order_id_prefix` (EDD is digital — no shipping/fees). The PER-PLATFORM event-firing toggles ARE writable via `platform_event_toggles` — whether a specific platform fires a specific EDD event (the per-platform layer beneath the global toggle; an event reaches a platform only when both are on). Pass `{ platform, event, enabled }` items (platform = a slug or `all`); read the current matrix from `get_edd_events_config.platform_events`; non-registering platforms come back in `unsupported_toggles`. Lifecycle + track flags aggregate to all active platforms plus the global setting; thresholds are global-only; content_id is stored PER-PLATFORM (Google side held by `gatags`/`gtm`, NOT separate GA/Google Ads). By default content_id args write to every platform; pass `content_id_platform` to scope them to ONE platform (read current per-platform values from `get_edd_events_config.content_id_by_platform`). **Two-step write:** call FIRST without `confirm` to get a `confirmation_required` preview (current→new diff + `aggregated_to`); after the user agrees, call again with `confirm: true`. A call without `confirm: true` never writes. Pass `mcp_note`.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'frequent_shopper'              => array(
					'type'        => 'boolean',
					'description' => 'Enable / disable the FrequentShopper lifecycle event.'
				),
				'vip_client'                    => array(
					'type'        => 'boolean',
					'description' => 'Enable / disable the VIPClient lifecycle event.'
				),
				'big_whale'                     => array(
					'type'        => 'boolean',
					'description' => 'Enable / disable the BigWhale lifecycle event.'
				),
				'frequent_shopper_transactions' => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => 'Completed purchases that trigger FrequentShopper.'
				),
				'vip_client_transactions'       => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => 'Completed purchases required for VIPClient.'
				),
				'vip_client_average_value'      => array(
					'type'        => 'number',
					'minimum'     => 0,
					'description' => 'Average order value threshold (store currency) for VIPClient.'
				),
				'big_whale_ltv'                 => array(
					'type'        => 'number',
					'minimum'     => 0,
					'description' => 'Total lifetime spend threshold (store currency) for BigWhale.'
				),
				'track_subscriptions'           => array(
					'type'        => 'boolean',
					'description' => 'Enable EDD subscription lifecycle tracking. REQUIRES the EDD Recurring Payments plugin — rejected with 409 if inactive. When on, SubscriptionCreated fires with predicted LTV. Check `subscriptions.recurring_plugin_active` from get_edd_events_config first.'
				),
				'track_licenses'                => array(
					'type'        => 'boolean',
					'description' => 'Enable EDD license event tracking (LicenseExpired etc.). REQUIRES the EDD Software Licensing plugin — rejected with 409 if inactive. Check `subscriptions.licensing_plugin_active` from get_edd_events_config first.'
				),
				'purchase'                      => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the EDD Purchase event (core `edd_purchase_enabled`). false disables it for ALL platforms; fires for a platform only when this master AND that platform toggle (`platform_event_toggles`) are on.'
				),
				'view_content'                  => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the EDD ViewContent event (all platforms).'
				),
				'view_category'                 => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the EDD ViewCategory event (all platforms).'
				),
				'add_to_cart'                   => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the EDD AddToCart event (all platforms).'
				),
				'initiate_checkout'             => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the EDD InitiateCheckout event (all platforms).'
				),
				'remove_from_cart'              => array(
					'type'        => 'boolean',
					'description' => 'GLOBAL master toggle for the EDD RemoveFromCart event (all platforms).'
				),
				'value_mode'                    => array(
					'type'        => 'string',
					'enum'        => array( 'price', 'custom' ),
					'description' => 'Value-calculation mode. `price` = "Use EasyDigitalDownloads price settings" (tax_option IGNORED). `custom` = "Customize Tax" (tax_option takes effect). Setting `tax_option` auto-switches this to `custom` if it was `price` (a note is returned). Set `price` to revert to EDD defaults.'
				),
				'tax_option'                    => array(
					'type'        => 'string',
					'enum'        => array( 'included', 'excluded' ),
					'description' => 'Value setting: whether tax is included in or excluded from the order value sent with events. Only applies when `value_mode` is `custom` (auto-enabled when you set this).'
				),
				'order_id_prefix'               => array(
					'type'        => 'string',
					'description' => 'Value setting: string prepended to order IDs sent with events. Empty string clears it.'
				),
				'content_id_source'             => array(
					'type'        => 'string',
					'enum'        => array( 'download_id', 'download_sku' ),
					'description' => 'Value sent as `content_ids` on EDD commerce events: `download_id` (the EDD download post ID) or `download_sku`. Must match the platform catalog feed. (EDD uses download IDs, not product IDs.)'
				),
				'content_id_prefix'             => array(
					'type'        => 'string',
					'description' => 'String prepended to content IDs. Must match the catalog feed prefix.'
				),
				'content_id_suffix'             => array(
					'type'        => 'string',
					'description' => 'String appended to content IDs. Must match the catalog feed suffix.'
				),
				'content_id_platform'           => array(
					'type'        => 'string',
					'enum'        => array( 'facebook', 'tiktok', 'pinterest', 'bing', 'reddit', 'gtm', 'gatags', 'google_analytics', 'google_ads', 'google', 'all' ),
					'description' => 'Optional. Scopes the content-id args (`content_id_source`/`content_id_prefix`/`content_id_suffix`) to ONE platform so you can set e.g. a different source for Google vs Meta. Omit (or `all`) to write all platforms (back-compat). EDD content-id is stored per-platform — read current per-platform values from `get_edd_events_config.content_id_by_platform`. Google (GA4 + Ads) share the unified `gatags` holder (pass `gatags`/`google`/`google_analytics`/`google_ads`). Does NOT affect lifecycle/threshold args in the same call.'
				),
				'platform_event_toggles'       => array(
					'type'        => 'array',
					'description' => 'PER-PLATFORM event-firing toggles — whether a specific platform fires a specific EDD event. This is the per-platform layer beneath the global event toggle: an event reaches a platform only when BOTH its global toggle and this per-platform toggle are on (read the matrix from `get_edd_events_config.platform_events`). Each item is `{ platform, event, enabled }`. `platform` is a single slug (`facebook`/`tiktok`/`google_analytics`/`google_ads`/`pinterest`/`bing`/`reddit`/`gtm`) or `all`. `event` is an EDD event stem (e.g. `purchase`, `add_to_cart`, `view_content`, `view_category`, `initiate_checkout`, `checkout`, `complete_payment`, `advance_purchase`, plus lifecycle `frequent_shopper`/`vip_client`/`big_whale`). Platforms that do not register an event are reported in `unsupported_toggles` and skipped. Subject to the SAME two-step `confirm` gate; the preview lists each platform×event `current → new`.',
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'platform', 'event', 'enabled' ),
						'additionalProperties' => false,
						'properties'           => array(
							'platform' => array(
								'type'        => 'string',
								'enum'        => EventToggleMap::TARGET_PLATFORMS,
								'description' => 'Target platform slug, or `all` for every active platform that registers this event.',
							),
							'event'    => array(
								'type'        => 'string',
								'enum'        => EventToggleMap::EDD_EVENTS,
								'description' => 'EDD event to toggle. Some logical events fan out to several per-platform keys: `purchase` covers `purchase` + Pinterest\'s `checkout` + TikTok\'s `complete_payment`; `view_content` covers `view_content` + Pinterest\'s `page_visit`. So toggling `purchase` for `all` flips every platform\'s purchase-equivalent (incl. Pinterest Checkout, TikTok CompletePayment). To target one sub-toggle only, pass its specific stem. The response `platform_event_toggles[].member`/`label` show which keys (and admin names) were affected. `get_edd_events_config.platform_event_labels` maps UI wording to a stem.',
							),
							'enabled'  => array(
								'type'        => 'boolean',
								'description' => 'true = fire this event for the platform; false = do not fire.',
							),
						),
					),
				),
				'confirm'                       => array(
					'type'        => 'boolean',
					'description' => 'Two-step write guard. Call FIRST without this flag to get a `confirmation_required` preview (current→new diff, plus per platform×event for `platform_event_toggles`, + which platforms the change reaches); show it to the user, get explicit go-ahead, THEN call again with `confirm: true` and the same args. A call without `confirm: true` never writes.',
				),
			),
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'saved'                 => array( 'type' => 'boolean' ),
				'available'             => array( 'type' => 'boolean' ),
				'confirmation_required' => array( 'type' => 'boolean' ),
				'pending_changes'       => array( 'type' => 'object', 'additionalProperties' => true ),
				'changed'               => array( 'type' => 'object', 'additionalProperties' => true ),
				'aggregated_to'         => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'unsupported'           => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				),
				'platform_event_toggles' => array(
					'type'        => 'array',
					'description' => 'Per-platform event toggles in this call (preview = would change; confirmed = written). Each entry `{ platform, event, current, new }`.',
					'items'       => array( 'type' => 'object' ),
				),
				'unsupported_toggles'   => array(
					'type'        => 'array',
					'description' => 'Per-platform event toggles that could NOT be applied. Each `{ platform, event, reason }`.',
					'items'       => array( 'type' => 'object' ),
				),
				'notes'                 => array(
					'type'        => 'array',
					'description' => 'Side-effect notices the user did NOT explicitly request — e.g. a global event master auto-enabled (two-level gate) or value mode switched to "Customize". You MUST relay every note to the user in your reply, both at the preview step and after the confirmed write — never silently omit them.',
					'items'       => array( 'type' => 'string' ),
				),
			),
		);
	}

	/**
	 * Validate, partition by scope, and write the EDD config (or preview it
	 * when `confirm` is absent).
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		if ( !is_array( $input ) ) {
			$input = array();
		}
		unset( $input[ 'mcp_note' ] );
		$confirm = !empty( $input[ 'confirm' ] );
		unset( $input[ 'confirm' ] );

		$rawToggles = array();
		if ( isset( $input[ 'platform_event_toggles' ] ) && is_array( $input[ 'platform_event_toggles' ] ) ) {
			$rawToggles = $input[ 'platform_event_toggles' ];
		}
		unset( $input[ 'platform_event_toggles' ] );

		if ( !function_exists( '\\PixelYourSite\\isEddActive' ) || !\PixelYourSite\isEddActive() ) {
			return new \WP_Error(
				'pys_mcp_edd_inactive',
				'Easy Digital Downloads is not active — cannot write EDD event config.',
				array( 'status' => 409 )
			);
		}

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		if ( null === $pys ) {
			return new \WP_Error( 'pys_mcp_pys_unavailable', 'PixelYourSite is not loaded.', array( 'status' => 500 ) );
		}

		// Plugin gates (mirror admin UI: render_switcher_input disabled
		// without the plugin).
		if ( array_key_exists( 'track_subscriptions', $input ) && !self::isEddRecurringActive() ) {
			return new \WP_Error(
				'pys_mcp_edd_recurring_inactive',
				'`track_subscriptions` requires the EDD Recurring Payments plugin, which is not active on this site. (Other args in this call were not written either — re-send them without `track_subscriptions`.)',
				array( 'status' => 409 )
			);
		}
		if ( array_key_exists( 'track_licenses', $input ) && !self::isEddSoftwareLicensingActive() ) {
			return new \WP_Error(
				'pys_mcp_edd_licensing_inactive',
				'`track_licenses` requires the EDD Software Licensing plugin, which is not active on this site. (Other args in this call were not written either — re-send them without `track_licenses`.)',
				array( 'status' => 409 )
			);
		}

		$cidPlatform = isset( $input[ 'content_id_platform' ] ) && is_string( $input[ 'content_id_platform' ] )
			? trim( $input[ 'content_id_platform' ] ) : '';
		unset( $input[ 'content_id_platform' ] );
		if ( 'all' === $cidPlatform ) {
			$cidPlatform = '';
		}
		if ( in_array( $cidPlatform, array( 'google', 'google_analytics', 'google_ads' ), true ) ) {
			$cidPlatform = 'gatags';
		}

		// Partition by write scope.
		$corePayload     = array();
		$platformPayload = array();
		$realKeyToArg    = array();
		$changed         = array();

		foreach ( $input as $arg => $rawValue ) {
			$arg     = (string) $arg;
			$realKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, $arg );
			if ( null === $realKey ) {
				continue;
			}
			$value = self::coerce( $arg, $rawValue );

			$isAggregate   = in_array( $arg, self::AGGREGATE_ARGS, true );
			$isGlobalOnly  = in_array( $arg, self::GLOBAL_ONLY_ARGS, true );
			$isPerPlatform = in_array( $arg, self::PER_PLATFORM_ARGS, true );

			if ( $isAggregate || $isGlobalOnly ) {
				$corePayload[ $realKey ] = $value;
			}
			if ( $isAggregate || $isPerPlatform ) {
				$platformPayload[ $realKey ] = $value;
				$realKeyToArg[ $realKey ]    = $arg;
			}
			$changed[ $arg ] = $value;
		}

		if ( empty( $changed ) && empty( $rawToggles ) ) {
			return new \WP_Error(
				'pys_mcp_edd_no_args',
				'No writable EDD config args provided. Pass at least one whitelisted key (e.g. `big_whale`, `content_id_source`) or `platform_event_toggles`.',
				array( 'status' => 400 )
			);
		}

		$valueModeNote = '';
		if ( !isset( $input[ 'value_mode' ] ) && array_key_exists( 'tax_option', $changed ) ) {
			$vmKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'value_mode' );
			if ( null !== $vmKey && 'custom' !== (string) $pys->getOption( $vmKey ) ) {
				$corePayload[ $vmKey ]   = 'custom';
				$changed[ 'value_mode' ] = 'custom';
				$valueModeNote           = 'Switched value mode to "Customize Tax" (was "Use EasyDigitalDownloads price settings") so the tax option takes effect.';
			}
		}

		$activeSettings = Platforms::activeSettings();

		if ( '' !== $cidPlatform && !isset( $activeSettings[ $cidPlatform ] ) ) {
			return new \WP_Error(
				'pys_mcp_edd_cid_platform_invalid',
				sprintf(
					'`content_id_platform: %s` is not an active content-id platform. Active: %s. (Google content_id is held by `gatags`.)',
					$cidPlatform,
					implode( ', ', array_keys( $activeSettings ) )
				),
				array( 'status' => 400 )
			);
		}

		if ( '' !== $cidPlatform
		     && !empty( array_intersect( array_keys( $changed ), self::PER_PLATFORM_ARGS ) ) ) {
			$baseKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'content_id_source' );
			$inst    = $activeSettings[ $cidPlatform ];
			if ( null !== $baseKey && method_exists( $inst, 'issetOption' ) && !$inst->issetOption( $baseKey ) ) {
				return new \WP_Error(
					'pys_mcp_edd_cid_platform_unsupported',
					sprintf(
						'`%s` has no EDD content_id setting — nothing to write (e.g. TikTok does not support EDD content_id). Use a platform listed in get_edd_events_config.content_id_by_platform.',
						$cidPlatform
					),
					array( 'status' => 400 )
				);
			}
		}

		// Resolve per-platform event toggles (same contract as the Woo tool).
		$toggleWrites      = array();
		$togglePending     = array();
		$toggleUnsupported = array();
		$masterEnable      = array();   // core master key => event stem (auto-enabled)
		foreach ( $rawToggles as $entry ) {
			if ( !is_array( $entry ) ) {
				continue;
			}
			$tPlatform = isset( $entry[ 'platform' ] ) && is_string( $entry[ 'platform' ] ) ? $entry[ 'platform' ] : '';
			$tEvent    = isset( $entry[ 'event' ] ) && is_string( $entry[ 'event' ] ) ? $entry[ 'event' ] : '';
			$tEnabled  = !empty( $entry[ 'enabled' ] );
			if ( '' === $tPlatform || '' === $tEvent ) {
				continue;
			}
			if ( !EventToggleMap::isKnownEvent( 'edd', $tEvent ) ) {
				$toggleUnsupported[] = array( 'platform' => $tPlatform, 'event' => $tEvent, 'reason' => 'unknown_event' );
				continue;
			}

			$members = EventToggleMap::resolveMembers( 'edd', $tEvent );
			$targets = 'all' === $tPlatform ? array_keys( $activeSettings ) : array( $tPlatform );
			$matchedAny = false;
			foreach ( $targets as $slug ) {
				$settings = $activeSettings[ $slug ] ?? null;
				if ( null === $settings || !method_exists( $settings, 'issetOption' ) ) {
					if ( 'all' !== $tPlatform ) {
						$toggleUnsupported[] = array( 'platform' => $slug, 'event' => $tEvent, 'reason' => 'platform_inactive' );
					}
					continue;
				}
				$slugMatched = false;
				foreach ( $members as $stem ) {
					if ( !EventToggleMap::platformSupports( 'edd', $slug, $stem, $settings ) ) {
						continue;
					}

					if ( EventToggleMap::isCoreScoped( 'edd', $stem, $slug ) ) {
						$slugMatched          = true;
						$matchedAny           = true;
						$ckey                 = EventToggleMap::masterKey( 'edd', $stem, $slug );
						$corePayload[ $ckey ] = $tEnabled;
						$togglePending[]      = array(
							'platform' => $slug,
							'event'    => $tEvent,
							'member'   => $stem,
							'label'    => EventToggleMap::labelFor( 'edd', $slug, $stem ),
							'current'  => method_exists( $pys, 'getOption' ) ? EventToggleMap::toBool( $pys->getOption( $ckey ) ) : false,
							'new'      => $tEnabled,
						);
						continue;
					}
					$key                           = EventToggleMap::key( 'edd', $stem );
					$slugMatched                   = true;
					$matchedAny                    = true;
					$toggleWrites[ $slug ][ $key ] = $tEnabled;
					$togglePending[]               = array(
						'platform' => $slug,
						'event'    => $tEvent,
						'member'   => $stem,
						'label'    => EventToggleMap::labelFor( 'edd', $slug, $stem ),
						'current'  => EventToggleMap::toBool( $settings->getOption( $key ) ),
						'new'      => $tEnabled,
					);

					if ( $tEnabled ) {
						$mKey = EventToggleMap::masterKey( 'edd', $stem, $slug );
						if ( !isset( $corePayload[ $mKey ] ) && method_exists( $pys, 'issetOption' )
						     && $pys->issetOption( $mKey ) && !EventToggleMap::toBool( $pys->getOption( $mKey ) ) ) {
							$corePayload[ $mKey ]  = true;
							$masterEnable[ $mKey ] = $stem;
						}
					}
				}
				if ( !$slugMatched && 'all' !== $tPlatform ) {
					$toggleUnsupported[] = array( 'platform' => $slug, 'event' => $tEvent, 'reason' => 'event_not_supported' );
				}
			}
			if ( 'all' === $tPlatform && !$matchedAny ) {
				$toggleUnsupported[] = array( 'platform' => 'all', 'event' => $tEvent, 'reason' => 'no_active_platform_registers_event' );
			}
		}

		// Per-platform accept filter (issetOption + content-id-family exclusion).
		$accepts = array();
		foreach ( $activeSettings as $slug => $settings ) {
			$accepts[ $slug ] = array();
			foreach ( $platformPayload as $realKey => $value ) {
				$arg = $realKeyToArg[ $realKey ] ?? $realKey;
				if ( !self::isValidTarget( $arg, $slug ) ) {
					continue;
				}
				if ( '' !== $cidPlatform && in_array( $arg, self::PER_PLATFORM_ARGS, true ) && $slug !== $cidPlatform ) {
					continue;
				}
				if ( method_exists( $settings, 'issetOption' ) && $settings->issetOption( $realKey ) ) {
					$accepts[ $slug ][] = $realKey;
				}
			}
		}

		$unsupported = array();
		foreach ( $activeSettings as $slug => $settings ) {
			if ( empty( $accepts[ $slug ] ) ) {
				continue;
			}
			foreach ( $platformPayload as $realKey => $value ) {
				$arg = $realKeyToArg[ $realKey ] ?? $realKey;
				if ( !self::isValidTarget( $arg, $slug ) ) {
					continue;
				}
				if ( '' !== $cidPlatform && in_array( $arg, self::PER_PLATFORM_ARGS, true ) && $slug !== $cidPlatform ) {
					continue;
				}
				if ( !in_array( $realKey, $accepts[ $slug ], true ) ) {
					$unsupported[ $arg ][] = $slug;
				}
			}
		}

		$aggregatedTo = array();
		if ( !empty( $platformPayload ) ) {
			foreach ( $accepts as $slug => $keys ) {
				if ( !empty( $keys ) ) {
					$aggregatedTo[] = $slug;
				}
			}
		}

		$masterNotes = self::masterNotes( $masterEnable );
		if ( '' !== $valueModeNote ) {
			$masterNotes[] = $valueModeNote;
		}

		// Two-step confirm gate.
		if ( !$confirm ) {
			$pending = array();
			foreach ( $changed as $arg => $newValue ) {
				$pending[ $arg ] = array(
					'current' => self::currentValue( $arg, $pys, $activeSettings, $cidPlatform ),
					'new'     => $newValue,
				);
			}
			foreach ( $masterEnable as $mKey => $stem ) {
				$pending[ 'global_' . $stem ] = array( 'current' => false, 'new' => true );
			}
			$preview = array(
				'available'             => true,
				'confirmation_required' => true,
				'pending_changes'       => (object) $pending,
				'aggregated_to'         => $aggregatedTo,
			);
			if ( !empty( $unsupported ) ) {
				$preview[ 'unsupported' ] = $unsupported;
			}
			if ( !empty( $togglePending ) ) {
				$preview[ 'platform_event_toggles' ] = $togglePending;
			}
			if ( !empty( $toggleUnsupported ) ) {
				$preview[ 'unsupported_toggles' ] = $toggleUnsupported;
			}
			if ( !empty( $masterNotes ) ) {
				$preview[ 'notes' ] = $masterNotes;
			}

			return $preview;
		}

		// Confirmed write.
		if ( !empty( $corePayload ) ) {
			$pys->updateOptions( $corePayload );
		}
		if ( !empty( $platformPayload ) ) {
			foreach ( $activeSettings as $slug => $settings ) {
				$accepted = array_intersect_key( $platformPayload, array_flip( $accepts[ $slug ] ) );
				if ( !empty( $accepted ) ) {
					$settings->updateOptions( $accepted );
				}
			}
		}

		// Per-platform event-toggle writes.
		foreach ( $toggleWrites as $slug => $kv ) {
			$settings = $activeSettings[ $slug ] ?? null;
			if ( null !== $settings && !empty( $kv ) ) {
				$settings->updateOptions( $kv );
			}
		}

		if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		foreach ( $masterEnable as $mKey => $stem ) {
			$changed[ 'global_' . $stem ] = true;
		}

		$result = array(
			'saved'         => true,
			'available'     => true,
			'changed'       => (object) $changed,
			'aggregated_to' => $aggregatedTo,
		);
		if ( !empty( $unsupported ) ) {
			$result[ 'unsupported' ] = $unsupported;
		}
		if ( !empty( $togglePending ) ) {
			$result[ 'platform_event_toggles' ] = $togglePending;
		}
		if ( !empty( $toggleUnsupported ) ) {
			$result[ 'unsupported_toggles' ] = $toggleUnsupported;
		}
		if ( !empty( $masterNotes ) ) {
			$result[ 'notes' ] = $masterNotes;
		}

		return $result;
	}

	/**
	 * Live per-group target map (lifecycle / content_id / global), for the
	 * read tool's `platform_scope`. Same routing rules as the write.
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function resolveScope(): array {
		$activeSettings = Platforms::activeSettings();
		$probe          = array(
			'lifecycle'  => ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'big_whale' ),
			'content_id' => ArgKeyMapper::resolve( self::MCP_TOOL_NAME, 'content_id_source' ),
		);
		$scope          = array();
		foreach ( $probe as $group => $key ) {
			$scope[ $group ] = array();
			if ( null === $key ) {
				continue;
			}
			$arg = 'lifecycle' === $group ? 'big_whale' : 'content_id_source';
			foreach ( $activeSettings as $slug => $settings ) {
				if ( !self::isValidTarget( $arg, $slug ) ) {
					continue;
				}
				if ( method_exists( $settings, 'issetOption' ) && $settings->issetOption( $key ) ) {
					$scope[ $group ][] = $slug;
				}
			}
		}
		$scope[ 'thresholds' ] = array( '(global setting — not per-platform)' );

		return $scope;
	}

	/**
	 * content_id family excludes GA/Google Ads (Google side = gatags). No single-platform args for EDD.
	 *
	 * @param string $arg  Public arg name.
	 * @param string $slug Platform slug.
	 * @return bool
	 */
	private static function isValidTarget( string $arg, string $slug ): bool {
		if ( in_array( $arg, self::CONTENT_ID_FAMILY_ARGS, true )
		     && in_array( $slug, self::CONTENT_ID_EXCLUDED_PLATFORMS, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Is the EDD Recurring Payments plugin active?
	 *
	 * @return bool
	 */
	private static function isEddRecurringActive(): bool {
		return function_exists( '\\PixelYourSite\\isEddRecurringActive' ) && \PixelYourSite\isEddRecurringActive();
	}

	/**
	 * Is the EDD Software Licensing plugin active?
	 *
	 * @return bool
	 */
	private static function isEddSoftwareLicensingActive(): bool {
		return function_exists( '\\PixelYourSite\\isEddSoftwareLicensingActive' )
		       && \PixelYourSite\isEddSoftwareLicensingActive();
	}

	/**
	 * Current stored value for an arg, for the preview diff. Per-platform
	 * (content_id) args read from the TARGET platform when a content_id
	 * qualifier is set, else a representative active platform.
	 *
	 * @param string                $arg            Public arg name.
	 * @param mixed                 $pys            PYS core settings instance.
	 * @param array<string, object> $activeSettings Active module instances by slug.
	 * @param string                $cidPlatform    Target content_id platform, or '' for all.
	 * @return mixed
	 */
	/**
	 * Human-readable notes for masters auto-enabled by per-platform toggles.
	 *
	 * @param array<string, string> $masterEnable masterKey => event stem.
	 * @return array<int, string>
	 */
	private static function masterNotes( array $masterEnable ): array {
		$notes = array();
		foreach ( $masterEnable as $stem ) {
			$notes[ $stem ] = sprintf(
				'Auto-enabled the global "%s" toggle (it was OFF, so the per-platform enable would not have fired) — "%s" now fires on every platform whose per-platform toggle is on.',
				EventToggleMap::labelFor( 'edd', '', $stem ),
				EventToggleMap::labelFor( 'edd', '', $stem )
			);
		}

		return array_values( $notes );
	}

	private static function currentValue( string $arg, $pys, array $activeSettings, string $cidPlatform = '' ) {
		$realKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, $arg );
		if ( null === $realKey ) {
			return null;
		}
		if ( !in_array( $arg, self::PER_PLATFORM_ARGS, true ) || empty( $activeSettings ) ) {
			return self::coerce( $arg, $pys->getOption( $realKey ) );
		}
		if ( '' !== $cidPlatform && isset( $activeSettings[ $cidPlatform ] ) ) {
			return self::coerce( $arg, $activeSettings[ $cidPlatform ]->getOption( $realKey ) );
		}
		// Fan-out (all): reflect divergence so the diff is honest.
		$distinct = array();
		foreach ( $activeSettings as $slug => $inst ) {
			if ( !self::isValidTarget( $arg, $slug ) || !method_exists( $inst, 'issetOption' )
			     || !$inst->issetOption( $realKey ) ) {
				continue;
			}
			$distinct[ (string) self::coerce( $arg, $inst->getOption( $realKey ) ) ] = true;
		}
		$values = array_keys( $distinct );
		if ( count( $values ) === 1 ) {
			return $values[ 0 ];
		}
		if ( empty( $values ) ) {
			return self::coerce( $arg, $pys->getOption( $realKey ) );
		}

		return '(varies: ' . implode( ', ', $values ) . ')';
	}

	/**
	 * Coerce a raw arg value to the type the option expects.
	 *
	 * @param string $arg Public arg name.
	 * @param mixed  $raw Raw value.
	 * @return mixed Coerced value.
	 */
	private static function coerce( string $arg, $raw ) {
		if ( in_array( $arg, self::BOOL_ARGS, true ) ) {
			return (bool) $raw;
		}
		if ( in_array( $arg, self::INT_ARGS, true ) ) {
			return (int) $raw;
		}
		if ( in_array( $arg, self::FLOAT_ARGS, true ) ) {
			return (float) $raw;
		}

		return is_string( $raw ) ? $raw : (string) $raw;
	}
}