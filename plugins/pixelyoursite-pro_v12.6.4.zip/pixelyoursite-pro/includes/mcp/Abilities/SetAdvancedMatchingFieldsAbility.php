<?php
/**
 * `set_advanced_matching_fields` — add/remove write ability.
 * Manages the eight advanced-matching lists (4 DOM input names, 4 URL
 * params) via `mode`: `append` (default) adds names without overwriting
 * existing ones; `remove` deletes the given names surgically (only the
 * names passed — never a bulk wipe). Both modes are behind the two-step
 * `confirm` gate. Pro/read-only-gated via {@see AbstractWriteAbility}.
 * The write purges page caches via `\PixelYourSite\purgeCache()` since these
 * settings feed both server-side delivery and the page-render pixel JS.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\Platforms;
use PixelYourSite\MCP\AdvancedMatchingMap;

final class SetAdvancedMatchingFieldsAbility extends AbstractWriteAbility {

	public const ID = 'pixelyoursite-pro/set-advanced-matching-fields';

	/** Public MCP tool name — matches the `ToolNameMap::MAP` entry. */
	private const MCP_TOOL_NAME = 'set_advanced_matching_fields';

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Set Advanced Matching Fields';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Adds or removes field names across the eight advanced-matching settings (4 DOM input-name lists, 4 URL-param lists). Pro-only. Controlled by `mode`: `append` (default) adds the given names and never overwrites or drops existing ones; `remove` deletes the given names from those lists. Use after `scan_page_for_form_fields` has returned and you have identified which field `name` attributes map to first name / last name / phone / email. Pass only the lists you have values for; omit the rest. In `append` mode, names already present come back as `skipped` (not an error). In `remove` mode, names that are not in the current list come back as `not_found` (not an error); removing every value just empties that list. Removal is per-name and surgical — it never touches names you did not pass; there is no bulk wipe. The same semantics apply to the URL-param lists (`url_first_name_params` etc.). SEPARATELY, this tool also writes the PER-PLATFORM matching opt-in switches via `platform_matching_toggles` — each pixel platform has its own master switch (Facebook/TikTok Advanced Matching, Pinterest Enhanced Matching, Bing Enhanced Conversions, GA4/GTM User-Provided Data, Google Ads manual Enhanced Conversions); when off, the shared field-name lists do nothing for that platform. ALL of these switches — INCLUDING TikTok "Advanced Matching" — are writable here: when the user asks to turn matching on/off for any of them, DO it via `platform_matching_toggles`; never refuse or claim it is "admin-only / only in the WordPress admin". `mode` does NOT apply to `platform_matching_toggles` (it only governs the field-name lists). Read current per-platform state from `get_advanced_matching_config.per_platform`. **Two-step write (everything here):** call FIRST without `confirm` to get a `confirmation_required` preview (`pending_changes` for the lists, `platform_matching` for the switches); after the user agrees, call again with `confirm: true` and the same args. A call without `confirm: true` never writes — this matters most in `remove` mode and when disabling a platform switch. Always pass `mcp_note` — one sentence (e.g. "Added contact form fields from /contact" or "Enabled Advanced Matching for Facebook").';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		$stringList = array(
			'type'  => 'array',
			'items' => array( 'type' => 'string', 'minLength' => 1 ),
		);

		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'mode'                   => array(
					'type'        => 'string',
					'enum'        => array( 'append', 'remove' ),
					'description' => 'Write mode. `append` (default) ADDS the given names to each list, never overwriting or dropping existing values. `remove` DELETES the given names from each list (names not present come back as `not_found`; removing all values empties the list). Removal is surgical — only the names you pass are touched. Omit for `append`.',
				),
				'first_name_field_names' => $stringList
				                            + array( 'description' => 'DOM form input `name` attributes that hold the visitor\'s first name. De-duplicated against existing values server-side.' ),
				'last_name_field_names'  => $stringList
				                            + array( 'description' => 'DOM form input `name` attributes for last name.' ),
				'phone_field_names'      => $stringList
				                            + array( 'description' => 'DOM form input `name` attributes for phone.' ),
				'email_field_names'      => $stringList
				                            + array( 'description' => 'DOM form input `name` attributes for email.' ),
				'url_first_name_params'  => $stringList
				                            + array( 'description' => 'URL query parameter names that carry first name on landing pages with prefilled forms (e.g. `fname` in `?fname=John`).' ),
				'url_last_name_params'   => $stringList
				                            + array( 'description' => 'URL query parameter names for last name.' ),
				'url_phone_params'       => $stringList
				                            + array( 'description' => 'URL query parameter names for phone.' ),
				'url_email_params'       => $stringList
				                            + array( 'description' => 'URL query parameter names for email.' ),
				'platform_matching_toggles' => array(
					'type'        => 'array',
					'description' => 'PER-PLATFORM matching opt-in switches (independent of `mode` and the field-name lists). Each item `{ platform, enabled, send_multiple_values?, use_encoding? }`. `platform` is a slug (`facebook`/`tiktok`/`pinterest`/`bing`/`google_analytics`/`google_ads`/`gtm`) or `all` (every active platform with a matching switch). `enabled` sets the platform\'s master matching toggle. `send_multiple_values` / `use_encoding` are sub-options that apply ONLY to GA4 (both) and GTM (send_multiple_values only); they are ignored on other platforms and reported in `unsupported_platform_toggles`. Inactive platforms or those without a matching switch (e.g. reddit) are reported there too. Read current state from `get_advanced_matching_config.per_platform`.',
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'platform', 'enabled' ),
						'additionalProperties' => false,
						'properties'           => array(
							'platform'             => array( 'type' => 'string' ),
							'enabled'              => array( 'type' => 'boolean' ),
							'send_multiple_values' => array( 'type' => 'boolean' ),
							'use_encoding'         => array( 'type' => 'boolean' ),
						),
					),
				),
				'confirm'                => array(
					'type'        => 'boolean',
					'description' => 'Two-step write guard. Call FIRST without this flag to get a `confirmation_required` preview (`pending_changes` shows what WOULD be added vs skipped-as-already-present per field) — nothing is written. Show it to the user, get explicit go-ahead, THEN call again with `confirm: true` and the same args to write. A call without `confirm: true` never writes.',
				),
			),
			// `required: ["mcp_note"]` is added by AbstractWriteAbility::resolvedInputSchema().
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		$stringArray  = array( 'type' => 'array', 'items' => array( 'type' => 'string' ) );
		$perArgResult = array(
			'type'       => 'object',
			'properties' => array(
				'added'          => $stringArray,
				'skipped'        => $stringArray,
				'removed'        => $stringArray,
				'not_found'      => $stringArray,
				'locked_default' => $stringArray,
			),
		);

		return array(
			'type'       => 'object',
			'properties' => array(
				'saved'                 => array( 'type' => 'boolean' ),
				'mode'                  => array(
					'type'        => 'string',
					'description' => 'Echoes the mode this call ran in (`append` or `remove`).',
				),
				'confirmation_required' => array(
					'type'        => 'boolean',
					'description' => 'True when the call was a preview (no `confirm: true`). Nothing written — show `pending_changes` and call again with `confirm: true`.',
				),
				'pending_changes'       => array(
					'type'                 => 'object',
					'additionalProperties' => $perArgResult,
					'description'          => 'Preview only. Per-list result. Append mode: `{ added, skipped }` (would-add vs already-present). Remove mode: `{ removed, not_found }` (would-delete vs absent). No write happened.',
				),
				'applied'               => array(
					'type'                 => 'object',
					'additionalProperties' => $perArgResult,
					'description'          => 'Confirmed write only. Per-list result. Append mode: `added` (values written this call), `skipped` (already present / duplicated — not an error). Remove mode: `removed` (values deleted this call), `not_found` (not in the list — not an error).',
				),
				'platform_matching'     => array(
					'type'        => 'array',
					'description' => 'Per-platform matching switches (preview = would change; confirmed = written). Each `{ platform, setting, current, new, sub_options? }` where `sub_options` is `{ name: { current, new } }`.',
					'items'       => array( 'type' => 'object' ),
				),
				'unsupported_platform_toggles' => array(
					'type'        => 'array',
					'description' => 'Per-platform toggles that could NOT be applied. Each `{ platform, reason }` (reason: `platform_inactive`, `no_matching_switch`, or `sub_option_not_supported`).',
					'items'       => array( 'type' => 'object' ),
				),
				'notes'                 => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Advisories, e.g. a removal target that is a built-in locked default (cannot be removed, still matched). Surface every note to the user.',
				),
			),
		);
	}

	/**
	 * Append field names to the advanced-matching lists (or preview when
	 * `confirm` is absent).
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		if ( !is_array( $input ) ) {
			$input = array();
		}

		unset( $input[ 'mcp_note' ] ); // consumed by Provenance, not written

		$mode = isset( $input[ 'mode' ] ) ? (string) $input[ 'mode' ] : 'append';
		unset( $input[ 'mode' ] );
		if ( 'remove' !== $mode ) {
			$mode = 'append';
		}

		// Two-step confirm gate: without `confirm:true`, preview and write nothing.
		$confirm = !empty( $input[ 'confirm' ] );
		unset( $input[ 'confirm' ] );

		$rawPlatformToggles = isset( $input[ 'platform_matching_toggles' ] ) && is_array( $input[ 'platform_matching_toggles' ] )
			? $input[ 'platform_matching_toggles' ]
			: array();
		unset( $input[ 'platform_matching_toggles' ] );

		// Whitelist + map to real PYS keys; unknown args dropped.
		$realKeyed = ArgKeyMapper::filterAndMap( self::MCP_TOOL_NAME, $input );
		if ( empty( $realKeyed ) && empty( $rawPlatformToggles ) ) {
			return new \WP_Error(
				'pys_mcp_set_am_empty',
				'Nothing to update. Pass at least one field-name list (e.g. `first_name_field_names`) or a `platform_matching_toggles` entry.',
				array( 'status' => 400 )
			);
		}

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		if ( null === $pys ) {
			return new \WP_Error(
				'pys_mcp_set_am_pys_unavailable',
				'PixelYourSite is not loaded — cannot write settings.',
				array( 'status' => 500 )
			);
		}

		// Reverse map for the response: real key → original arg name.
		$realToArg = array();
		foreach ( ArgKeyMapper::knownArgs( self::MCP_TOOL_NAME ) as $arg ) {
			$realKey = ArgKeyMapper::resolve( self::MCP_TOOL_NAME, $arg );
			if ( null !== $realKey ) {
				$realToArg[ $realKey ] = $arg;
			}
		}

		$updatePayload = array();
		$applied       = array();
		$notes         = array();

		$lockedDefaults = AdvancedMatchingConfigAbility::lockedDefaults();
		$argDimension   = array(
			'first_name_field_names' => 'first_name',
			'last_name_field_names'  => 'last_name',
			'phone_field_names'      => 'phone',
			'email_field_names'      => 'email',
		);

		foreach ( $realKeyed as $realKey => $incoming ) {
			$argName = $realToArg[ $realKey ] ?? $realKey;

			// Schema enforces `array`, but defensively re-cast.
			if ( !is_array( $incoming ) ) {
				$incoming = array();
			}

			$current = $pys->getOption( $realKey, array() );
			if ( !is_array( $current ) ) {
				$current = array();
			}
			// Strip empties (mirrors the admin UI) so they don't poison the diff.
			$current = array_values( array_filter( $current, static function( $v ): bool {
				return is_string( $v ) && '' !== trim( $v );
			} ) );

			if ( 'remove' === $mode ) {
				$dimDefaults = $lockedDefaults[ $argDimension[ $argName ] ?? '' ] ?? array();
				$targets      = array();
				$removed       = array();
				$notFound      = array();
				$lockedDefault = array();
				foreach ( $incoming as $raw ) {
					if ( !is_string( $raw ) ) {
						continue;
					}
					$value = trim( $raw );
					if ( '' === $value || in_array( $value, $targets, true ) ) {
						continue;
					}
					$targets[] = $value;
					// Built-in default → not removable; PYS always matches it.
					if ( in_array( $value, $dimDefaults, true ) ) {
						$lockedDefault[] = $value;
						continue;
					}
					// Case-sensitive: HTML `name` attributes are case-sensitive.
					if ( in_array( $value, $current, true ) ) {
						$removed[] = $value;
					} else {
						$notFound[] = $value;
					}
				}

				$applied[ $argName ] = array(
					'removed'   => $removed,
					'not_found' => $notFound,
				);
				if ( !empty( $lockedDefault ) ) {
					$applied[ $argName ][ 'locked_default' ] = $lockedDefault;
					$notes[] = sprintf(
						'%s: %s %s a built-in default that PixelYourSite always matches — it cannot be removed here and stays active (the admin shows it as a locked value). Not removed.',
						$argName,
						implode( ', ', $lockedDefault ),
						count( $lockedDefault ) > 1 ? 'are' : 'is'
					);
				}

				if ( !empty( $removed ) ) {
					$updatePayload[ $realKey ] = array_values( array_filter(
						$current,
						static function( $v ) use ( $removed ): bool {
							return !in_array( $v, $removed, true );
						}
					) );
				}
				continue;
			}

			// Append mode (default): add new names, skip ones already present.
			$added   = array();
			$skipped = array();
			foreach ( $incoming as $raw ) {
				if ( !is_string( $raw ) ) {
					continue;
				}
				$value = trim( $raw );
				if ( '' === $value ) {
					continue;
				}
				// Case-sensitive: HTML `name` attributes are case-sensitive.
				if ( in_array( $value, $current, true ) || in_array( $value, $added, true ) ) {
					if ( !in_array( $value, $skipped, true ) ) {
						$skipped[] = $value;
					}
					continue;
				}
				$added[] = $value;
			}

			$applied[ $argName ] = array(
				'added'   => $added,
				'skipped' => $skipped,
			);

			if ( !empty( $added ) ) {
				$updatePayload[ $realKey ] = array_merge( $current, $added );
			}
		}

		// --- per-platform matching toggles ---
		$activeSettings      = Platforms::activeSettings();
		$platformPending     = array();
		$platformWrites      = array(); // slug => [ realKey => value ]
		$platformUnsupported = array();
		foreach ( $rawPlatformToggles as $entry ) {
			if ( !is_array( $entry ) ) {
				continue;
			}
			$p = isset( $entry[ 'platform' ] ) && is_string( $entry[ 'platform' ] ) ? $entry[ 'platform' ] : '';
			if ( '' === $p || !array_key_exists( 'enabled', $entry ) ) {
				continue;
			}
			$enabled = (bool) $entry[ 'enabled' ];

			// Sub-options apply only to an explicit single platform, never `all`.
			$subInput = array();
			if ( 'all' !== $p ) {
				foreach ( array( 'send_multiple_values', 'use_encoding' ) as $subName ) {
					if ( array_key_exists( $subName, $entry ) ) {
						$subInput[ $subName ] = (bool) $entry[ $subName ];
					}
				}
			}

			$targets = 'all' === $p ? array_keys( $activeSettings ) : array( $p );
			foreach ( $targets as $slug ) {
				$settings = $activeSettings[ $slug ] ?? null;
				if ( null === $settings ) {
					if ( 'all' !== $p ) {
						$platformUnsupported[] = array( 'platform' => $slug, 'reason' => 'platform_inactive' );
					}
					continue;
				}
				if ( !AdvancedMatchingMap::has( $slug ) ) {
					if ( 'all' !== $p ) {
						$platformUnsupported[] = array( 'platform' => $slug, 'reason' => 'no_matching_switch' );
					}
					continue;
				}

				$pend    = array(
					'platform' => $slug,
					'setting'  => AdvancedMatchingMap::label( $slug ),
					'current'  => AdvancedMatchingMap::readMaster( $slug, $settings ),
					'new'      => $enabled,
				);
				$payload = AdvancedMatchingMap::masterPayload( $slug, $settings, $enabled );

				if ( !empty( $subInput ) ) {
					$subs    = AdvancedMatchingMap::subOptions( $slug );
					$subPend = array();
					foreach ( $subInput as $subName => $subVal ) {
						if ( isset( $subs[ $subName ] ) ) {
							$realK              = $subs[ $subName ];
							$subPend[ $subName ] = array(
								'current' => AdvancedMatchingMap::toBool( $settings->getOption( $realK ) ),
								'new'     => $subVal,
							);
							$payload[ $realK ]  = $subVal;
						} else {
							$platformUnsupported[] = array(
								'platform'   => $slug,
								'reason'     => 'sub_option_not_supported',
								'sub_option' => $subName,
							);
						}
					}
					if ( !empty( $subPend ) ) {
						$pend[ 'sub_options' ] = $subPend;
					}
				}

				$platformPending[]        = $pend;
				$platformWrites[ $slug ]  = array_merge( $platformWrites[ $slug ] ?? array(), $payload );
			}
		}

		// Preview step: show the per-list diff + per-platform diff, write nothing.
		if ( !$confirm ) {
			$preview = array(
				'mode'                  => $mode,
				'confirmation_required' => true,
				'pending_changes'       => (object) $applied,
			);
			if ( !empty( $platformPending ) ) {
				$preview[ 'platform_matching' ] = $platformPending;
			}
			if ( !empty( $platformUnsupported ) ) {
				$preview[ 'unsupported_platform_toggles' ] = $platformUnsupported;
			}
			if ( !empty( $notes ) ) {
				$preview[ 'notes' ] = $notes;
			}

			return $preview;
		}

		if ( !empty( $updatePayload ) ) {
			$pys->updateOptions( $updatePayload );
		}
		foreach ( $platformWrites as $slug => $kv ) {
			$settings = $activeSettings[ $slug ] ?? null;
			if ( null !== $settings && !empty( $kv ) ) {
				$settings->updateOptions( $kv );
			}
		}
		if ( ( !empty( $updatePayload ) || !empty( $platformWrites ) )
		     && function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		$result = array(
			'saved'   => true,
			'mode'    => $mode,
			// (object) cast: see preview note — empty must serialize as `{}`.
			'applied' => (object) $applied,
		);
		if ( !empty( $platformPending ) ) {
			$result[ 'platform_matching' ] = $platformPending;
		}
		if ( !empty( $platformUnsupported ) ) {
			$result[ 'unsupported_platform_toggles' ] = $platformUnsupported;
		}
		if ( !empty( $notes ) ) {
			$result[ 'notes' ] = $notes;
		}

		return $result;
	}
}