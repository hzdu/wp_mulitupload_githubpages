<?php
/**
 * `get_catalog_feed_alignment` — compares PYS WooCommerce content-ID settings
 * (source / prefix / suffix, per platform) against the Product Catalog Feed
 * plugin's configured feeds, and reports mismatches + a safe recommended fix.
 *
 * Read-only. Never assumes the detected feed is the catalog actually connected
 * in the advertiser's platform — the confirm-and-fix flow (see UsageGuidance)
 * requires the user to confirm the live source before any change is proposed.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class GetCatalogFeedAlignmentAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-catalog-feed-alignment';

	private const FEED_TYPE_TO_SLUG = array(
		'facebook'  => 'facebook',
		'google'    => 'gatags',
		'tiktok'    => 'tiktok',
		'pinterest' => 'pinterest',
		'bing'      => 'bing',
		'reddit'    => 'reddit',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get Catalog Feed Alignment';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Compares PYS WooCommerce content-ID settings (source/prefix/suffix, per platform) against the Product Catalog Feed plugin\'s feed(s), if that plugin is installed and configured. Returns `{ "available": false, "reason": "..." }` if WooCommerce is not active, the feed plugin is not installed/active, or it has no feeds configured. '
			. 'IMPORTANT — this tool only reports what THIS feed plugin is configured to send. It does NOT confirm that this feed is the catalog actually connected in the advertiser\'s platform (Meta Catalog Manager / Google Merchant Center / TikTok Catalog). The site could use a different feed plugin, a manual upload, or a direct API integration. Before proposing any change, ASK the user to confirm which catalog source is actually connected — never assume this feed is authoritative. '
			. 'If PYS and the feed both use `product_id` with no prefix/suffix (the default on both sides), the feed reports `recommendation: none` — the healthy baseline, nothing to change. '
			. 'PYS can only write ITS OWN side, so the lowest-friction fix is usually to make PYS match the feed EXACTLY (copy the feed\'s source + prefix + suffix) — one PYS-side change that aligns immediately, no feed edit. Do NOT just clear PYS\'s prefix/suffix when the feed keeps its own — that leaves a mismatch. Accordingly: when the feed uses `product_id` (safe), the recommendation is `align_to_feed` (`suggested_pys_change` = the feed\'s exact values). When the FEED uses `product_sku` (a reliability risk — SKU is empty for any product without one set, and the feed has no fallback, so those products silently drop out of matching), the recommendation is `prefer_default_product_id`: move BOTH sides to clean `product_id` (the WordPress post ID, always present) — `default_option` changes PYS, and the user must revert the feed in its own plugin; matching PYS to the feed\'s SKU (`alternative_option`) is a PYS-only fallback only if SKU is confirmed required. '
			. 'If PYS is set to `custom_field` on a platform, the feed (which only sends product_id/product_sku) cannot be matched by this tool — `recommendation: custom_field_not_comparable`; it also surfaces the PYS content-ID scan report (`custom_field_scan`) listing how many products are missing that field. '
			. 'Does NOT write anything — to apply a fix, call `set_woo_event_config` (pass `content_id_platform` to scope it to the feed\'s platform) with the agreed values and its standard two-step confirm. Call this when the user asks about catalog feed alignment / dynamic ads not matching, or when `get_tracking_audit` flags `catalog_feed_alignment` as anything other than `ok` / `not_active`.';
	}

	/**
	 * Input JSON-Schema (no arguments).
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array( 'type' => 'object', 'properties' => array(), 'additionalProperties' => false );
	}

	/**
	 * Output JSON-Schema (variable shape — self-documenting via description).
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array( 'type' => 'object' );
	}

	/**
	 * Compare PYS content-ID settings against every configured feed.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		// 1. WooCommerce must be active.
		if ( !function_exists( '\\PixelYourSite\\isWooCommerceActive' ) || !\PixelYourSite\isWooCommerceActive() ) {
			return array( 'available' => false, 'reason' => 'WooCommerce is not active.' );
		}

		// 2. Feed plugin's feeds.
		$feeds = self::feedsSummary();
		if ( null === $feeds ) {
			return array( 'available' => false, 'reason' => 'Product Catalog Feed plugin is not installed or active.' );
		}
		if ( empty( $feeds ) ) {
			return array( 'available' => false, 'reason' => 'Product Catalog Feed plugin is active but no feeds are configured yet.' );
		}

		// 3. PYS content_id — representative + genuine per-platform state.
		$woo        = GetWooEventsConfigAbility::execute( array() );
		$rep        = self::pysValues( is_array( $woo[ 'content_id' ] ?? null ) ? $woo[ 'content_id' ] : array() );
		$byPlatform = is_array( $woo[ 'content_id_by_platform' ] ?? null ) ? $woo[ 'content_id_by_platform' ] : array();

		// 4. Compare each feed against the content_id of its matching platform.
		$results     = array();
		$anyMismatch = false;
		foreach ( $feeds as $feed ) {
			$slug = self::FEED_TYPE_TO_SLUG[ strtolower( (string) ( $feed[ 'type' ] ?? '' ) ) ] ?? null;
			if ( null !== $slug && isset( $byPlatform[ $slug ] ) && is_array( $byPlatform[ $slug ] ) ) {
				$pys      = self::pysValues( $byPlatform[ $slug ] );
				$platform = $slug;
			} else {
				$pys      = $rep;
				$platform = 'representative';
			}
			$r = self::compareOne( (array) $feed, (array) ( $feed[ 'id_config' ] ?? array() ), $pys, $platform );
			if ( empty( $r[ 'matches' ] ) ) {
				$anyMismatch = true;
			}
			$results[] = $r;
		}

		return array(
			'available'    => true,
			'pys_settings' => $rep,
			'feeds'        => $results,
			'all_match'    => !$anyMismatch,
			'note'         => 'Reports only what THIS feed plugin is configured to send — NOT proof it is the catalog connected in Meta/Google/TikTok. Confirm the live catalog source with the user before proposing any change.',
		);
	}

	/**
	 * Feed summaries ({id, name, type, id_config}) or null if the feed plugin
	 * isn't active. Prefers the plugin's own `wpwoof_get_feeds_summary()` when it
	 * is loaded (wp-admin / cron / WP-CLI). On the MCP REST route the plugin
	 * early-returns (its guard is admin-only) and that helper is undefined, so we
	 * read its feed options directly — read-only, stable storage (`wpwoof_feedlist_*`)
	 * — and replicate only the `id_config` mapping alignment needs. No feed-plugin
	 * code is modified or loaded.
	 *
	 * @return array<int, array<string, mixed>>|null
	 */
	private static function feedsSummary(): ?array {
		if ( !self::feedPluginActive() ) {
			return null;
		}

		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT option_id, option_value FROM {$wpdb->options} WHERE option_name LIKE 'wpwoof\\_feedlist\\_%'",
			ARRAY_A
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			$cfg = @unserialize( (string) ( $row[ 'option_value' ] ?? '' ) );
			if ( !is_array( $cfg ) || empty( $cfg[ 'feed_name' ] ) ) {
				continue;
			}
			$fm        = isset( $cfg[ 'field_mapping' ] ) && is_array( $cfg[ 'field_mapping' ] ) ? $cfg[ 'field_mapping' ] : array();
			$rawSource = (string) ( $fm[ 'id' ][ 'value' ] ?? 'id' );
			$out[]     = array(
				'id'        => (int) ( $row[ 'option_id' ] ?? 0 ),
				'name'      => (string) $cfg[ 'feed_name' ],
				'type'      => (string) ( $cfg[ 'feed_type' ] ?? 'facebook' ),
				'id_config' => array(
					// Both 'sku' and the SKU meta key '_sku' mean "send the SKU".
					'source' => in_array( $rawSource, array( 'sku', '_sku' ), true ) ? 'product_sku' : 'product_id',
					'prefix' => (string) ( $fm[ 'id_prefix' ] ?? '' ),
					'suffix' => (string) ( $fm[ 'id_postfix' ] ?? '' ),
				),
			);
		}
		return $out;
	}

	/**
	 * Is the Product Catalog Feed plugin active? Read-only option check — no need
	 * for wp-admin/includes/plugin.php or the plugin itself being loaded.
	 *
	 * @return bool
	 */
	public static function feedPluginActive(): bool {
		$plugin = 'product-catalog-feed-pro/product-catalog-feed-pro.php';
		if ( in_array( $plugin, (array) get_option( 'active_plugins', array() ), true ) ) {
			return true;
		}
		$network = (array) get_site_option( 'active_sitewide_plugins', array() );
		return isset( $network[ $plugin ] );
	}

	/**
	 * Normalise a content_id row (representative or per-platform) to the three
	 * comparable fields plus the custom_field name.
	 *
	 * @param array $cid content_id sub-array.
	 * @return array{source: string, prefix: string, suffix: string, custom_field_name: string}
	 */
	private static function pysValues( array $cid ): array {
		return array(
			'source'            => (string) ( $cid[ 'source' ] ?? '' ),
			'prefix'            => (string) ( $cid[ 'prefix' ] ?? '' ),
			'suffix'            => (string) ( $cid[ 'suffix' ] ?? '' ),
			'custom_field_name' => (string) ( $cid[ 'custom_field_name' ] ?? '' ),
		);
	}

	/**
	 * Compare one feed's id_config against PYS's content_id for its platform.
	 * Reports facts only — the feed is NOT assumed authoritative (the user
	 * confirms that). Branches: custom_field_not_comparable / none /
	 * matches_but_sku_risk / prefer_default_product_id / align_to_feed.
	 *
	 * @param array  $feed     Feed summary row.
	 * @param array  $feedCfg  Feed id_config (source/prefix/suffix).
	 * @param array  $pys      PYS content_id values for the compared platform.
	 * @param string $platform PYS platform slug compared against, or 'representative'.
	 * @return array<string, mixed>
	 */
	private static function compareOne( array $feed, array $feedCfg, array $pys, string $platform ): array {
		$out = array(
			'feed_id'          => $feed[ 'id' ]   ?? null,
			'feed_name'        => $feed[ 'name' ] ?? '',
			'feed_type'        => $feed[ 'type' ] ?? '',
			'compared_against' => $platform,
		);

		$scopePlatform = ( 'representative' !== $platform ) ? $platform : null;

		if ( 'custom_field' === $pys[ 'source' ] ) {
			$out[ 'matches' ]        = false;
			$out[ 'sku_risk' ]       = false;
			$out[ 'recommendation' ] = 'custom_field_not_comparable';
			$out[ 'pys_values' ]     = array(
				'source'            => 'custom_field',
				'custom_field_name' => $pys[ 'custom_field_name' ],
			);
			$out[ 'feed_values' ]    = array(
				'source' => $feedCfg[ 'source' ] ?? '',
				'prefix' => $feedCfg[ 'prefix' ] ?? '',
				'suffix' => $feedCfg[ 'suffix' ] ?? '',
			);
			$scan = self::scanReport( $platform );
			if ( null !== $scan ) {
				$out[ 'custom_field_scan' ] = $scan;
			}

			if ( 'product_sku' === ( $feedCfg[ 'source' ] ?? '' ) ) {
				$out[ 'default_option' ] = self::withPlatform( array(
					'content_id_source' => 'product_id',
					'content_id_prefix' => '',
					'content_id_suffix' => '',
					'note'              => 'The feed uses product_sku (risky — blank for products without a SKU). Recommend switching BOTH sides to product_id — PYS via set_woo_event_config, the feed in its own plugin.',
				), $scopePlatform );
			} else {
				$out[ 'align_to_feed_option' ] = self::withPlatform( array(
					'content_id_source' => (string) ( $feedCfg[ 'source' ] ?? 'product_id' ),
					'content_id_prefix' => (string) ( $feedCfg[ 'prefix' ] ?? '' ),
					'content_id_suffix' => (string) ( $feedCfg[ 'suffix' ] ?? '' ),
					'note'              => 'Switches PYS off custom_field to match the feed EXACTLY (its source + prefix + suffix) — one PYS-side change, aligns immediately, no feed edit needed. Do NOT clear the prefix/suffix unless you also clear them on the feed side.',
				), $scopePlatform );
			}
			$out[ 'note' ] = 'PYS sends a custom_field value here; the catalog feed only sends product_id/product_sku, so this tool cannot verify the VALUES match. If you keep custom_field, confirm manually that its values equal the feed IDs (and note the missing-field scan above). To align via a single PYS-side change, use align_to_feed_option (matches the feed as-is).';
			return $out;
		}

		$sourceMatches = ( $feedCfg[ 'source' ] ?? '' ) === $pys[ 'source' ];
		$prefixMatches = ( $feedCfg[ 'prefix' ] ?? '' ) === $pys[ 'prefix' ];
		$suffixMatches = ( $feedCfg[ 'suffix' ] ?? '' ) === $pys[ 'suffix' ];
		$matches       = $sourceMatches && $prefixMatches && $suffixMatches;

		$pysUsesSku  = 'product_sku' === $pys[ 'source' ];
		$feedUsesSku = 'product_sku' === ( $feedCfg[ 'source' ] ?? '' );

		$out[ 'matches' ]  = $matches;
		$out[ 'sku_risk' ] = $pysUsesSku || $feedUsesSku;

		// Both on the safe default and matching — healthy baseline.
		if ( 'product_id' === $pys[ 'source' ] && 'product_id' === ( $feedCfg[ 'source' ] ?? '' ) && $matches ) {
			$out[ 'recommendation' ] = 'none';
			return $out;
		}

		if ( !$matches ) {
			$out[ 'feed_values' ] = array(
				'source' => $feedCfg[ 'source' ] ?? '',
				'prefix' => $feedCfg[ 'prefix' ] ?? '',
				'suffix' => $feedCfg[ 'suffix' ] ?? '',
			);

			if ( $feedUsesSku ) {

				$out[ 'recommendation' ] = 'prefer_default_product_id';
				$out[ 'default_option' ] = self::withPlatform( array(
					'content_id_source' => 'product_id',
					'content_id_prefix' => '',
					'content_id_suffix' => '',
					'note'              => 'Reverts PYS to the WordPress post ID — always present, always unique. The feed uses product_sku (blank for products without a SKU); if it is the active catalog source, revert it to product_id too — the user must do that in the feed plugin, PYS cannot. NOTE: changing only PYS leaves a mismatch until the feed is also changed.',
				), $scopePlatform );
				$alt = array_filter( array(
					'content_id_source' => $sourceMatches ? null : ( $feedCfg[ 'source' ] ?? '' ),
					'content_id_prefix' => $prefixMatches ? null : ( $feedCfg[ 'prefix' ] ?? '' ),
					'content_id_suffix' => $suffixMatches ? null : ( $feedCfg[ 'suffix' ] ?? '' ),
				), static function ( $v ) {
					return null !== $v;
				} );
				$alt[ 'note' ]              = 'Aligns PYS to match this feed exactly (product_sku + its prefix/suffix) — ONE PYS-side change, matches immediately, no feed edit. Only if SKU is confirmed required — SKU can be empty for some products, silently dropping them from catalog matching.';
				$out[ 'alternative_option' ] = self::withPlatform( $alt, $scopePlatform );
			} else {
				$out[ 'recommendation' ]       = 'align_to_feed';
				$out[ 'suggested_pys_change' ] = self::withPlatform( array_filter( array(
					'content_id_source' => $sourceMatches ? null : ( $feedCfg[ 'source' ] ?? '' ),
					'content_id_prefix' => $prefixMatches ? null : ( $feedCfg[ 'prefix' ] ?? '' ),
					'content_id_suffix' => $suffixMatches ? null : ( $feedCfg[ 'suffix' ] ?? '' ),
				), static function ( $v ) {
					return null !== $v;
				} ), $scopePlatform );
				$out[ 'suggested_pys_change' ][ 'note' ] = 'Makes PYS match the feed EXACTLY (product_id + the feed\'s prefix/suffix) — one PYS-side change, aligns immediately, no feed edit needed. Alternatively, to run clean product_id with NO prefix/suffix, clear them on BOTH sides (PYS here + the feed in its own plugin) — but until the feed\'s prefix/suffix are also cleared, only matching the feed aligns them now.';
			}
		} elseif ( $pysUsesSku || $feedUsesSku ) {
			// Matches, but both sides use SKU — flag the reliability risk anyway.
			$out[ 'recommendation' ] = 'matches_but_sku_risk';
			$out[ 'default_option' ] = self::withPlatform( array(
				'content_id_source' => 'product_id',
				'content_id_prefix' => '',
				'content_id_suffix' => '',
				'note'              => 'Both sides currently match using product_sku. This works only while every product has a SKU set. Consider switching both to product_id (always present, always unique) to remove that risk.',
			), $scopePlatform );
		}

		return $out;
	}

	/**
	 * Append `content_id_platform` to a suggested-fix option when the comparison
	 * targeted a specific platform, so the fix is scoped correctly.
	 *
	 * @param array       $option   Fix option.
	 * @param string|null $platform Platform slug or null.
	 * @return array
	 */
	private static function withPlatform( array $option, ?string $platform ): array {
		if ( null !== $platform ) {
			$option[ 'content_id_platform' ] = $platform;
		}
		return $option;
	}

	/**
	 * The PYS content-ID scan report for a platform (custom_field mode), reduced
	 * to status + counts. Null when unavailable / no report yet.
	 *
	 * @param string $slug Platform slug.
	 * @return array{status: string, total_scanned: int, missing_count: int}|null
	 */
	private static function scanReport( string $slug ): ?array {
		if ( '' === $slug || 'representative' === $slug || !class_exists( '\\PixelYourSite\\PysContentIdScanner' ) ) {
			return null;
		}
		$rep = \PixelYourSite\PysContentIdScanner::getReport( $slug );
		if ( !is_array( $rep ) || empty( $rep ) ) {
			return null;
		}
		return array(
			'status'        => (string) ( $rep[ 'status' ] ?? '' ),
			'total_scanned' => (int) ( $rep[ 'total_scanned' ] ?? 0 ),
			'missing_count' => isset( $rep[ 'missing' ] ) && is_array( $rep[ 'missing' ] ) ? count( $rep[ 'missing' ] ) : 0,
		);
	}
}