<?php
/**
 * `get_superpack_config` — read-only snapshot of the PixelYourSite Super Pack
 * add-on's GLOBAL settings: license state (status/expiry only — the key is
 * never echoed), feature toggles, and the global custom-thank-you-page config
 * for WooCommerce / EDD. Extra pixels are reported by `get_platform_pixels`;
 * per-page / per-product Super Pack rules live in post meta and are out of
 * scope here.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class GetSuperPackConfigAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-superpack-config';

	private const ADMIN_UI_PATH = 'PixelYourSite → Super Pack';

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get Super Pack Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Returns the GLOBAL configuration of the PixelYourSite Super Pack add-on. `active` is false when Super Pack is not installed/active — nothing else applies then. Sections: `license` (`key`: configured/missing — the value is NEVER returned; plus `status`, `expires`, and the master `enabled` flag), `features` (global on/off toggles: `additional_ids_enabled` [extra pixels], `dynamic_params_enabled` [`[id]`/`[title]` placeholders], `hide_by_tags_enabled` + `hide_by_url_enabled` [conditional pixel hiding], `custom_thank_you_enabled`, `remove_pixel_ui_enabled` [per-page pixel-removal meta box], `amp_enabled`), and `thank_you` (the GLOBAL custom thank-you page for `woo` and `edd`: `enabled`, `url`, `cart` = hidden/after/before order-details placement). Write these with `set_superpack_config`. Note: the EXTRA pixels Super Pack manages are reported by `get_platform_pixels` (not here); per-page pixel-removal and per-product thank-you pages are WordPress post meta, not global settings, and are not covered. Read-only.';
	}

	/**
	 * Input JSON-Schema (no args).
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'active' ),
			'properties' => array(
				'active'        => array( 'type' => 'boolean' ),
				'admin_ui_path' => array( 'type' => 'string' ),
				'license'       => array(
					'type'        => 'object',
					'description' => '`key` is `configured`/`missing` (value never echoed). `status` / `expires` are the stored license strings; `enabled` is the Super Pack master switch.',
				),
				'features'      => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'boolean' ),
					'description'          => 'Global feature toggles.',
				),
				'thank_you'     => array(
					'type'        => 'object',
					'description' => 'Global custom thank-you page config per ecommerce platform: `{ woo: {enabled, url, cart}, edd: {enabled, url, cart} }`.',
				),
			),
		);
	}

	/**
	 * Build the Super Pack snapshot.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		if ( !function_exists( '\\PixelYourSite\\isSuperPackActive' ) || !\PixelYourSite\isSuperPackActive()
		     || !function_exists( '\\PixelYourSite\\SuperPack' ) ) {
			return array( 'active' => false );
		}
		$sp = \PixelYourSite\SuperPack();
		if ( !is_object( $sp ) || !method_exists( $sp, 'getOption' ) ) {
			return array( 'active' => false );
		}

		$bool = static function ( $v ): bool {
			if ( is_bool( $v ) ) {
				return $v;
			}
			if ( is_string( $v ) ) {
				return '1' === $v || 'true' === strtolower( $v );
			}

			return is_int( $v ) && 1 === $v;
		};

		$licenseKey = (string) $sp->getOption( 'license_key' );

		return array(
			'active'        => true,
			'admin_ui_path' => self::ADMIN_UI_PATH,
			'license'       => array(
				'key'     => '' !== trim( $licenseKey ) ? 'configured' : 'missing',
				'status'  => (string) $sp->getOption( 'license_status' ),
				'expires' => (string) $sp->getOption( 'license_expires' ),
				'enabled' => $bool( $sp->getOption( 'enabled' ) ),
			),
			'features'      => array(
				'additional_ids_enabled'  => $bool( $sp->getOption( 'additional_ids_enabled' ) ),
				'dynamic_params_enabled'  => $bool( $sp->getOption( 'dynamic_params_enabled' ) ),
				'hide_by_tags_enabled'    => $bool( $sp->getOption( 'enable_hide_this_tag_by_tags' ) ),
				'hide_by_url_enabled'     => $bool( $sp->getOption( 'enable_hide_this_tag_by_url' ) ),
				'custom_thank_you_enabled' => $bool( $sp->getOption( 'custom_thank_you_page_enabled' ) ),
				'remove_pixel_ui_enabled' => $bool( $sp->getOption( 'remove_pixel_enabled' ) ),
				'amp_enabled'             => $bool( $sp->getOption( 'amp_enabled' ) ),
			),
			'thank_you'     => array(
				'woo' => array(
					'enabled' => $bool( $sp->getOption( 'woo_custom_thank_you_page_global_enabled' ) ),
					'url'     => (string) $sp->getOption( 'woo_custom_thank_you_page_global_url' ),
					'cart'    => (string) $sp->getOption( 'woo_custom_thank_you_page_global_cart' ),
				),
				'edd' => array(
					'enabled' => $bool( $sp->getOption( 'edd_custom_thank_you_page_global_enabled' ) ),
					'url'     => (string) $sp->getOption( 'edd_custom_thank_you_page_global_url' ),
					'cart'    => (string) $sp->getOption( 'edd_custom_thank_you_page_global_cart' ),
				),
			),
		);
	}
}