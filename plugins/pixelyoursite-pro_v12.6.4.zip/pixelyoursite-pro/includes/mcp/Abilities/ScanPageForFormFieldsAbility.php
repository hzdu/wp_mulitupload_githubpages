<?php
/**
 * `scan_page_for_form_fields` — SSRF-guarded form scanner ability.
 * Walks up to ten own-domain URLs and returns per-form field descriptors
 * (`name`, `id`, `type`, `label`). Backed by
 * {@see \PixelYourSite\AnyFormScanner::scanUrls()}; this class adds the
 * gating the scanner doesn't: same-origin only (host must match
 * `home_url()`), no redirect following, `http`/`https` only, 2 MB response
 * cap and a 5s per-URL timeout. Read-only.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class ScanPageForFormFieldsAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/scan-page-for-form-fields';

	private const MAX_URLS       = 3;
	private const MAX_BODY_BYTES = 2097152; // 2 MB

	/** Field `type` values that are never useful for advanced matching. */
	private const SKIP_FIELD_TYPES = array(
		'submit',
		'button',
		'hidden',
		'image',
		'reset',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Scan Page for Form Fields';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Fetches one or more own-domain page URLs, parses every `<form>` on each page, and returns each field\'s `name`, `id`, `type`, and the visible `<label>` text linked to that field. Call this only after `get_advanced_matching_config` has shown a real gap that affects anonymous form visitors. Ask the user which pages contain contact / lead / signup forms — do not attempt to discover form pages on your own. Pass only URLs the user has explicitly named, verbatim and absolute (`https://site.com/contact`), not just paths. SSRF-guarded: same-origin only, no redirect following, 5-second timeout per URL, 2 MB response cap, max 3 URLs per call (sequential fetches — keep it to the 1–3 pages that actually have forms). After scanning, identify which fields are first name / last name / phone / email using the label text — input `name` attributes alone are often opaque (`your-name`, `field-1`). Then pass the field names through `set_advanced_matching_fields` (Pro) or give the user manual setting instructions (Free).';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'required'             => array( 'urls' ),
			'additionalProperties' => false,
			'properties'           => array(
				'urls' => array(
					'type'        => 'array',
					'minItems'    => 1,
					'maxItems'    => self::MAX_URLS,
					'description' => 'Page URLs on this WordPress site to scan for forms. Same-origin only — the tool rejects external URLs. Pass URLs the user gave you verbatim. Do NOT compose URLs from a domain + path: if the user supplied only a domain or only relative paths, ASK them for the full absolute URL before calling. Never invent path segments.',
					'items'       => array(
						'type'        => 'string',
						'format'      => 'uri',
						'description' => 'Absolute http(s) URL on the connected WordPress site.',
					),
				),
			),
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		$field  = array(
			'type'       => 'object',
			'required'   => array( 'name', 'id', 'type', 'label' ),
			'properties' => array(
				'name'  => array( 'type' => 'string' ),
				'id'    => array( 'type' => 'string' ),
				'type'  => array( 'type' => 'string' ),
				'label' => array( 'type' => 'string' ),
			),
		);
		$form   = array(
			'type'       => 'object',
			'required'   => array( 'title', 'fields' ),
			'properties' => array(
				'title'  => array( 'type' => 'string' ),
				'fields' => array( 'type' => 'array', 'items' => $field ),
			),
		);
		$result = array(
			'type'       => 'object',
			'required'   => array( 'url' ),
			'properties' => array(
				'url'   => array( 'type' => 'string' ),
				'forms' => array( 'type' => 'array', 'items' => $form ),
				'error' => array( 'type' => 'string' ),
			),
		);

		return array(
			'type'       => 'object',
			'required'   => array( 'results' ),
			'properties' => array(
				'results' => array( 'type' => 'array', 'items' => $result ),
			),
		);
	}

	/**
	 * Validate the URLs, scan each same-origin page, and return form fields.
	 *
	 * @param mixed $input Validated args (`urls`).
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		$urls = is_array( $input ) && isset( $input[ 'urls' ] )
		        && is_array(
			        $input[ 'urls' ]
		        ) ? $input[ 'urls' ] : array();

		// Schema enforces 1–10; defensive checks here are belt-and-suspenders.
		if ( 0 === count( $urls ) ) {
			return new \WP_Error( 'pys_mcp_scan_empty_urls', 'At least one URL is required.', array( 'status' => 400 )
			);
		}
		if ( count( $urls ) > self::MAX_URLS ) {
			return new \WP_Error(
				'pys_mcp_scan_too_many',
				sprintf( 'Too many URLs (max %d).', self::MAX_URLS ),
				array( 'status' => 400 )
			);
		}

		$siteHost     = self::siteHost();
		$fetchOptions = array(
			'redirection'         => 0,
			'limit_response_size' => self::MAX_BODY_BYTES,
		);

		$scanner = \PixelYourSite\AnyFormScanner::instance();

		$results = array();
		foreach ( $urls as $url ) {
			$validation = self::validateUrl( $url, $siteHost );
			if ( null !== $validation ) {
				$results[] = array(
					'url'   => esc_url( (string) $url ),
					'error' => $validation,
				);
				continue;
			}
			$raw       = $scanner->scanUrl( (string) $url, $fetchOptions );
			$results[] = self::reshape( $raw );
		}

		return array( 'results' => $results );
	}

	/**
	 * Return null when the URL is acceptable, otherwise a human-readable
	 * error string suitable for the per-URL `error` field.
	 *
	 * @param mixed       $url      URL to validate.
	 * @param string|null $siteHost Lowercased site host, or null when unknown.
	 * @return string|null
	 */
	private static function validateUrl( $url, ?string $siteHost ): ?string {
		if ( !is_string( $url ) || '' === $url ) {
			return 'URL must be a non-empty string.';
		}
		$parts = wp_parse_url( $url );
		if ( !is_array( $parts ) || empty( $parts[ 'scheme' ] ) || empty( $parts[ 'host' ] ) ) {
			return 'Invalid URL — scheme and host are required.';
		}
		$scheme = strtolower( $parts[ 'scheme' ] );
		if ( 'http' !== $scheme && 'https' !== $scheme ) {
			return 'Only http and https URLs are allowed.';
		}
		if ( null === $siteHost ) {
			return 'Server cannot determine its own host — same-origin check is unavailable.';
		}
		if ( strtolower( $parts[ 'host' ] ) !== $siteHost ) {
			return sprintf(
				'Same-origin only — host "%s" does not match this site ("%s").',
				$parts[ 'host' ],
				$siteHost
			);
		}

		return null;
	}

	/**
	 * Lowercased host of `home_url()`, or null when WP can't tell.
	 *
	 * @return string|null
	 */
	private static function siteHost(): ?string {
		$home = function_exists( 'home_url' ) ? home_url() : '';
		if ( '' === $home ) {
			return null;
		}
		$host = wp_parse_url( $home, PHP_URL_HOST );

		return is_string( $host ) ? strtolower( $host ) : null;
	}

	/**
	 * Trim scanner output to the useful fields: drop non-interactive field
	 * types and internal selector detail. Per-URL `error` entries pass
	 * through unchanged.
	 *
	 * @param array $scan Raw scanner output for one URL.
	 * @return array<string, mixed>
	 */
	private static function reshape( array $scan ): array {
		if ( isset( $scan[ 'error' ] ) ) {
			return array(
				'url'   => esc_url( (string) ( $scan[ 'url' ] ?? '' ) ),
				'error' => (string) $scan[ 'error' ],
			);
		}

		$forms = array();
		foreach ( $scan[ 'forms' ] ?? array() as $form ) {
			$fields = array();
			foreach ( $form[ 'fields' ] ?? array() as $f ) {
				$type = (string) ( $f[ 'type' ] ?? '' );
				if ( in_array( $type, self::SKIP_FIELD_TYPES, true ) ) {
					continue;
				}
				// All four are raw DOM attributes / text — sanitise against injection.
				$fields[] = array(
					'name'  => self::sanitiseUserString( $f[ 'name' ] ?? '' ),
					'id'    => self::sanitiseUserString( $f[ 'id' ] ?? '' ),
					'type'  => self::sanitiseUserString( $type ),
					'label' => self::sanitiseUserString( $f[ 'label' ] ?? '' ),
				);
			}
			$forms[] = array(
				'title'  => self::sanitiseUserString( $form[ 'title' ] ?? '' ),
				'fields' => $fields,
			);
		}

		return array(
			'url'   => esc_url( (string) ( $scan[ 'url' ] ?? '' ) ),
			'forms' => $forms,
		);
	}
}
