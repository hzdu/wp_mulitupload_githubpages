<?php
/**
 * `set_superpack_config` — partial write to the PixelYourSite Super Pack
 * add-on's GLOBAL settings: feature toggles + the global custom-thank-you-page
 * config (woo / edd). Pro/read-only-gated, `mcp_note` required, two-step
 * `confirm`. Returns 409 when Super Pack is not active.
 *
 * Out of scope (by design): the license key (writing it needs the activation
 * flow), extra pixels (handled by set_platform_credential), and per-page /
 * per-product rules (WordPress post meta, not global options).
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class SetSuperPackConfigAbility extends AbstractWriteAbility {

	public const ID = 'pixelyoursite-pro/set-superpack-config';

	/** Cart-placement enum for the thank-you order details. */
	private const CART_VALUES = array( 'hidden', 'after', 'before' );

	/**
	 * Public arg => [ real Super Pack option key, type ]. type ∈ bool|text|cart.
	 * All keys live on the SuperPack Settings instance (admin: PixelYourSite →
	 * Super Pack), authoritative per options_fields.json.
	 */
	private const SETTING_KEYS = array(
		'superpack_enabled'         => array( 'enabled', 'bool' ),
		'additional_ids_enabled'    => array( 'additional_ids_enabled', 'bool' ),
		'dynamic_params_enabled'    => array( 'dynamic_params_enabled', 'bool' ),
		'hide_by_tags_enabled'      => array( 'enable_hide_this_tag_by_tags', 'bool' ),
		'hide_by_url_enabled'       => array( 'enable_hide_this_tag_by_url', 'bool' ),
		'custom_thank_you_enabled'  => array( 'custom_thank_you_page_enabled', 'bool' ),
		'remove_pixel_ui_enabled'   => array( 'remove_pixel_enabled', 'bool' ),
		'amp_enabled'               => array( 'amp_enabled', 'bool' ),
		'woo_thank_you_enabled'     => array( 'woo_custom_thank_you_page_global_enabled', 'bool' ),
		'woo_thank_you_url'         => array( 'woo_custom_thank_you_page_global_url', 'text' ),
		'woo_thank_you_cart'        => array( 'woo_custom_thank_you_page_global_cart', 'cart' ),
		'edd_thank_you_enabled'     => array( 'edd_custom_thank_you_page_global_enabled', 'bool' ),
		'edd_thank_you_url'         => array( 'edd_custom_thank_you_page_global_url', 'text' ),
		'edd_thank_you_cart'        => array( 'edd_custom_thank_you_page_global_cart', 'cart' ),
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Set Super Pack Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Writes a partial update to the PixelYourSite Super Pack GLOBAL settings. Pro-only; Super Pack add-on must be active (else 409). Authorized write: the administrator installed this server so you can change these settings on their behalf — perform the write after confirmation; do not redirect to wp-admin. Writable: feature toggles — `superpack_enabled` (Super Pack master switch — turning it off disables ALL Super Pack features), `additional_ids_enabled` (extra pixels), `dynamic_params_enabled` (`[id]`/`[title]` placeholders), `hide_by_tags_enabled` / `hide_by_url_enabled` (conditional pixel hiding), `custom_thank_you_enabled`, `remove_pixel_ui_enabled`, `amp_enabled`; and the GLOBAL custom thank-you page per platform — `woo_thank_you_enabled` + `woo_thank_you_url` (full URL) + `woo_thank_you_cart` (`hidden`/`after`/`before` order-details placement), and the `edd_` equivalents. NOT writable here: the license key (needs the activation flow — manage it in the admin), extra pixels (use `set_platform_credential` with `pixel_index >= 1`), and per-page pixel-removal / per-product thank-you pages (WordPress post meta, admin-only). Read current values from `get_superpack_config` first. Two-level gate: enabling `woo_thank_you_enabled` / `edd_thank_you_enabled` while the `custom_thank_you_enabled` master is off auto-enables that master (reported in `notes` + `pending_changes`); a thank-you page also needs a URL to redirect (a note warns if missing). Surface every `notes` entry to the user. **Two-step write:** call FIRST without `confirm` to get a `confirmation_required` preview (`pending_changes` shows per setting `current → new`); after the user agrees, call again with `confirm: true` and the same args. A call without `confirm: true` never writes. Pass `mcp_note`.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		$bool = array( 'type' => 'boolean' );
		$cart = array( 'type' => 'string', 'enum' => self::CART_VALUES );

		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'superpack_enabled'        => $bool + array( 'description' => 'Super Pack MASTER switch. false disables ALL Super Pack features site-wide.' ),
				'additional_ids_enabled'   => $bool + array( 'description' => 'Enable extra/additional pixels.' ),
				'dynamic_params_enabled'   => $bool + array( 'description' => 'Enable dynamic parameter placeholders (`[id]`, `[title]`, `[categories]`, `[tags]`).' ),
				'hide_by_tags_enabled'     => $bool + array( 'description' => 'Enable per-pixel hiding by URL query-parameter rules.' ),
				'hide_by_url_enabled'      => $bool + array( 'description' => 'Enable per-pixel hiding by URL substring rules.' ),
				'custom_thank_you_enabled' => $bool + array( 'description' => 'Master toggle for the custom thank-you page feature.' ),
				'remove_pixel_ui_enabled'  => $bool + array( 'description' => 'Enable the per-page pixel-removal meta box.' ),
				'amp_enabled'              => $bool + array( 'description' => 'Fire pixels on AMP pages.' ),
				'woo_thank_you_enabled'    => $bool + array( 'description' => 'Enable the WooCommerce global custom thank-you page.' ),
				'woo_thank_you_url'        => array( 'type' => 'string', 'description' => 'WooCommerce global thank-you page URL (full URL). Empty string clears it.' ),
				'woo_thank_you_cart'       => $cart + array( 'description' => 'WooCommerce order-details placement on the thank-you page: hidden / after / before.' ),
				'edd_thank_you_enabled'    => $bool + array( 'description' => 'Enable the EDD global custom thank-you page.' ),
				'edd_thank_you_url'        => array( 'type' => 'string', 'description' => 'EDD global thank-you page URL (full URL). Empty string clears it.' ),
				'edd_thank_you_cart'       => $cart + array( 'description' => 'EDD order-details placement on the thank-you page: hidden / after / before.' ),
				'confirm'                  => array(
					'type'        => 'boolean',
					'description' => 'Two-step write guard. Call FIRST without this flag to get a `confirmation_required` preview (`pending_changes` shows per setting current→new); show it, get explicit go-ahead, THEN resend with `confirm: true`. A call without `confirm: true` never writes.',
				),
			),
			// `required: ["mcp_note"]` added by AbstractWriteAbility::resolvedInputSchema().
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'saved'                 => array( 'type' => 'boolean' ),
				'available'             => array( 'type' => 'boolean' ),
				'confirmation_required' => array( 'type' => 'boolean' ),
				'pending_changes'       => array( 'type' => 'object', 'additionalProperties' => true ),
				'changed'               => array( 'type' => 'object', 'additionalProperties' => true ),
				'notes'                 => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Side-effect notices the user did NOT explicitly request — e.g. the "Custom Thank You Page" master toggle was auto-enabled, or a thank-you page lacks a URL. You MUST relay every note to the user, at preview AND after the confirmed write.',
				),
			),
		);
	}

	/**
	 * Validate and write (or preview) the Super Pack global config.
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		if ( !is_array( $input ) ) {
			$input = array();
		}
		unset( $input[ 'mcp_note' ] );
		$confirm = !empty( $input[ 'confirm' ] );
		unset( $input[ 'confirm' ] );

		if ( !function_exists( '\\PixelYourSite\\isSuperPackActive' ) || !\PixelYourSite\isSuperPackActive()
		     || !function_exists( '\\PixelYourSite\\SuperPack' ) ) {
			return new \WP_Error(
				'pys_mcp_superpack_inactive',
				'PixelYourSite Super Pack is not installed/active — cannot write its settings.',
				array( 'status' => 409 )
			);
		}
		$sp = \PixelYourSite\SuperPack();
		if ( !is_object( $sp ) || !method_exists( $sp, 'getOption' ) ) {
			return new \WP_Error( 'pys_mcp_superpack_unavailable', 'Super Pack is not loaded.', array( 'status' => 500 ) );
		}

		$incoming = array_intersect_key( $input, self::SETTING_KEYS );
		if ( empty( $incoming ) ) {
			return new \WP_Error(
				'pys_mcp_superpack_no_args',
				'Nothing to update. Pass at least one Super Pack setting (e.g. `amp_enabled`, `woo_thank_you_url`).',
				array( 'status' => 400 )
			);
		}

		$bool = static function ( $v ): bool {
			if ( is_bool( $v ) ) {
				return $v;
			}
			if ( is_string( $v ) ) {
				return '1' === $v || 'true' === strtolower( $v );
			}

			return is_int( $v ) && 1 === $v;
		};

		$payload = array();
		$pending = array();
		foreach ( $incoming as $arg => $value ) {
			list( $key, $type ) = self::SETTING_KEYS[ $arg ];

			if ( 'bool' === $type ) {
				$current = $bool( $sp->getOption( $key ) );
				$new     = (bool) $value;
			} elseif ( 'cart' === $type ) {
				$current = (string) $sp->getOption( $key );
				$new     = in_array( (string) $value, self::CART_VALUES, true ) ? (string) $value : $current;
			} else { // text
				$current = (string) $sp->getOption( $key );
				$new     = is_string( $value ) ? trim( $value ) : '';
			}

			$payload[ $key ]  = $new;
			$pending[ $arg ]  = array( 'current' => $current, 'new' => $new );
		}

		$notes = array();

		$enablingThankYou = ( !empty( $pending['woo_thank_you_enabled']['new'] ) )
		                    || ( !empty( $pending['edd_thank_you_enabled']['new'] ) );
		if ( $enablingThankYou && !array_key_exists( 'custom_thank_you_enabled', $incoming ) ) {
			$masterKey = 'custom_thank_you_page_enabled';
			if ( !$bool( $sp->getOption( $masterKey ) ) ) {
				$payload[ $masterKey ]                = true;
				$pending['custom_thank_you_enabled']  = array( 'current' => false, 'new' => true );
				$notes[]                              = 'Auto-enabled the Super Pack "Custom Thank You Page" master toggle — a per-platform thank-you page does nothing while the master feature is off.';
			}
		}

		foreach ( array( 'woo' => 'woo_thank_you_url', 'edd' => 'edd_thank_you_url' ) as $d => $urlArg ) {
			$enArg = $d . '_thank_you_enabled';
			if ( empty( $pending[ $enArg ]['new'] ) ) {
				continue;
			}
			$urlNew = array_key_exists( $urlArg, $pending )
				? (string) $pending[ $urlArg ]['new']
				: (string) $sp->getOption( self::SETTING_KEYS[ $urlArg ][0] );
			if ( '' === trim( $urlNew ) ) {
				$notes[] = sprintf( 'The %s thank-you page is enabled but has no URL set — it will not redirect until a URL is provided (`%s_thank_you_url`).', strtoupper( $d ), $d );
			}
		}

		// Two-step confirm gate.
		if ( !$confirm ) {
			$preview = array(
				'available'             => true,
				'confirmation_required' => true,
				'pending_changes'       => (object) $pending,
			);
			if ( !empty( $notes ) ) {
				$preview['notes'] = $notes;
			}

			return $preview;
		}

		$sp->updateOptions( $payload );

		if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		$result = array(
			'saved'     => true,
			'available' => true,
			'changed'   => (object) $pending,
		);
		if ( !empty( $notes ) ) {
			$result['notes'] = $notes;
		}

		return $result;
	}
}