<?php
/**
 * `get_edd_feed_alignment` — compares PYS EDD content-ID settings against the
 * EDD Products Feed Pro plugin's configured feeds, if installed.
 *
 * The feed plugin's Google Merchant platform always uses the WordPress download
 * post ID as the identifier (g:id = {download_id}-{price_id} for variable-price
 * downloads, g:id = {download_id} for simple ones; g:item_group_id = {download_id}
 * groups the variations). There is NO SKU option and NO prefix/suffix in the feed,
 * so PYS sending `download_sku` or any prefix/suffix produces IDs that never match.
 *
 * Read-only. Detecting the plugin is NOT the same as confirming the feed is the
 * catalog actually connected in Google Merchant Center — the confirm-and-fix flow
 * (see UsageGuidance) requires the user to confirm the live source first.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class GetEddFeedAlignmentAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-edd-feed-alignment';

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get EDD Feed Alignment';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Compares PYS Easy Digital Downloads content-ID settings (source/prefix/suffix) against the EDD Products Feed Pro plugin\'s feed(s), if that plugin is installed and configured. Returns `{ "available": false, "reason": "..." }` if EDD is not active, the feed plugin is not installed/active, or it has no feeds configured. '
			. 'The feed\'s Google Merchant platform always uses the WordPress download post ID with NO prefix or suffix — g:id = {download_id}-{price_id} for variable-price downloads, {download_id} for simple ones, and g:item_group_id = {download_id} groups the variations. So PYS must send `download_id` with no prefix/suffix to match. Sending `download_sku` (the feed has no SKU option) or any prefix/suffix produces IDs that never match. The `edd_variable_as_simple` setting is irrelevant — Google Merchant resolves variation matches via g:item_group_id either way, so this tool never checks or changes it. '
			. 'The alignment check applies to `google_merchant` feeds. `legacy`-format feeds are listed (with `feed_platform`) but not evaluated (their ID scheme differs and is out of scope). '
			. 'Covers Google Merchant Center only — EDD Products Feed Pro does not generate Facebook, TikTok, or Pinterest catalog feeds. IMPORTANT: detecting this plugin is NOT the same as confirming the feed is the catalog actually connected in Google Merchant Center. Ask the user to confirm before proposing any change. '
			. 'Does NOT write — to apply a fix, call `set_edd_event_config` with the suggested `content_id_source` / `content_id_prefix` / `content_id_suffix` values and its standard two-step confirm. Call this when the user asks about EDD catalog feed alignment / Google Merchant matching, or when `get_tracking_audit` flags `edd_feed_alignment` as anything other than `ok` / `not_active`.';
	}

	/**
	 * Input JSON-Schema (no arguments).
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array( 'type' => 'object', 'properties' => array(), 'additionalProperties' => false );
	}

	/**
	 * Output JSON-Schema (variable shape — self-documenting via description).
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array( 'type' => 'object' );
	}

	/**
	 * Compare PYS EDD content-ID settings against the configured feeds.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		// 1. EDD must be active.
		if ( !function_exists( '\\PixelYourSite\\isEddActive' ) || !\PixelYourSite\isEddActive() ) {
			return array( 'available' => false, 'reason' => 'EDD is not active.' );
		}

		// 2. Feed plugin active?
		if ( !self::feedPluginActive() ) {
			return array( 'available' => false, 'reason' => 'EDD Products Feed Pro is not installed or active.' );
		}

		// 3. Any feeds configured?
		$feeds = self::feedsSummary();
		if ( empty( $feeds ) ) {
			return array( 'available' => false, 'reason' => 'EDD Products Feed Pro is active but no feeds are configured yet.' );
		}

		// 4. Read PYS EDD content_id (representative source/prefix/suffix).
		$eddCfg    = GetEddEventsConfigAbility::execute( array() );
		$cid       = is_array( $eddCfg[ 'content_id' ] ?? null ) ? $eddCfg[ 'content_id' ] : array();
		$pysSource = (string) ( $cid[ 'source' ] ?? '' );
		$pysPrefix = (string) ( $cid[ 'prefix' ] ?? '' );
		$pysSuffix = (string) ( $cid[ 'suffix' ] ?? '' );

		// 5. The alignment check applies only to Google Merchant feeds.
		$google_merchant_feeds = array_values( array_filter( $feeds, static function ( $feed ) {
			return 'google_merchant' === $feed[ 'feed_platform' ];
		} ) );
		$has_google_merchant = !empty( $google_merchant_feeds );

		// 6. Match check: the feed always sends the bare post ID (download_id, no
		// prefix/suffix). download_sku or any prefix/suffix can never match.
		$source_ok = ( 'download_id' === $pysSource );
		$prefix_ok = ( '' === $pysPrefix );
		$suffix_ok = ( '' === $pysSuffix );
		$matches   = $source_ok && $prefix_ok && $suffix_ok;

		$content_id = array(
			'checked'       => $has_google_merchant,
			'matches'       => $has_google_merchant ? $matches : null,
			'pys_settings'  => array(
				'source' => $pysSource,
				'prefix' => $pysPrefix,
				'suffix' => $pysSuffix,
			),
			'feed_settings' => array(
				'source' => 'download_id',
				'prefix' => '',
				'suffix' => '',
				'note'   => 'g:id = {download_id}-{price_id} for variable-price downloads, {download_id} for simple. g:item_group_id = {download_id} groups variations.',
			),
		);

		if ( $has_google_merchant && !$matches ) {
			$suggested = array();
			if ( !$source_ok ) {
				$suggested[ 'content_id_source' ] = 'download_id';
			}
			if ( !$prefix_ok ) {
				$suggested[ 'content_id_prefix' ] = '';
			}
			if ( !$suffix_ok ) {
				$suggested[ 'content_id_suffix' ] = '';
			}
			$content_id[ 'suggested_pys_change' ] = $suggested;

			if ( 'download_sku' === $pysSource ) {
				$content_id[ 'mismatch_reason' ] = 'PYS is sending the EDD SKU as content_id. The feed always sends the integer WordPress post ID — these will never match. EDD SKU falls back to the post ID when empty, which may hide the mismatch on some downloads while breaking others.';
			} elseif ( !$prefix_ok || !$suffix_ok ) {
				$content_id[ 'mismatch_reason' ] = 'PYS has a prefix or suffix on the content ID. The feed sends the bare post ID with no prefix or suffix — these will not match.';
			}
		}

		// legacy-only configuration → nothing to align for Google Merchant.
		$all_ok = $has_google_merchant ? $matches : true;

		$out = array(
			'available'                  => true,
			'feed_plugin'                => 'EDD Products Feed Pro',
			'feed_destinations'          => array( 'google_merchant' ),
			'feed_count'                 => count( $feeds ),
			'google_merchant_feed_count' => count( $google_merchant_feeds ),
			'feeds'                      => $feeds,
			'content_id'                 => $content_id,
			'all_ok'                     => $all_ok,
			'platform_scope_note'        => 'EDD Products Feed Pro generates Google Merchant Center feeds only. EDD dynamic ads for Facebook, TikTok, or Pinterest require a different feed plugin.',
		);

		if ( !$has_google_merchant ) {
			$out[ 'note' ] = 'Only legacy-format feed(s) are configured (no Google Merchant feed). The Google Merchant content-ID alignment check applies to google_merchant feeds; legacy feeds are listed but not evaluated here.';
		}

		return $out;
	}

	/**
	 * Is EDD Products Feed Pro active? Its main file `require`s `inc/admin.php`
	 * unconditionally at top level (not behind an is_admin() guard), so
	 * `wpeddpcf_get_feeds()` exists on every request — including the MCP REST route
	 * — exactly when the plugin is active. A reliable, side-effect-free signal.
	 *
	 * @return bool
	 */
	public static function feedPluginActive(): bool {
		return function_exists( 'wpeddpcf_get_feeds' );
	}

	/**
	 * Feed summaries ({feed_id, feed_name, feed_platform}), read directly from the
	 * plugin's own option rows (`wpeddpcf_feedlist_*`). Read-only, stable storage;
	 * no feed-plugin code is executed or modified.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function feedsSummary(): array {
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT option_id, option_value FROM {$wpdb->options} WHERE option_name LIKE 'wpeddpcf\\_feedlist\\_%'",
			ARRAY_A
		);

		$out = array();
		foreach ( (array) $rows as $row ) {
			$cfg = @unserialize( (string) ( $row[ 'option_value' ] ?? '' ) );
			if ( !is_array( $cfg ) || empty( $cfg[ 'feed_name' ] ) ) {
				continue;
			}
			$out[] = array(
				'feed_id'       => (int) ( $row[ 'option_id' ] ?? 0 ),
				'feed_name'     => sanitize_text_field( (string) $cfg[ 'feed_name' ] ),
				'feed_platform' => sanitize_text_field( (string) ( $cfg[ 'feed_platform' ] ?? 'legacy' ) ),
			);
		}

		return $out;
	}
}