<?php
/**
 * `get_automatic_events_config` — read-only snapshot of the GLOBAL automatic
 * (page-level) events PYS fires site-wide (internal/outbound links, video,
 * form, signup, login, download, comment, scroll, time-on-page, search, 404,
 * etc.). Reports the master switch, the global per-event toggles, the
 * per-platform firing matrix, and the (read-only) thresholds/sub-toggles.
 *
 * An automatic event fires for a platform only when ALL of: the master switch
 * is on, its global toggle is on, and that platform's per-event toggle is on.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\EventToggleMap;

final class GetAutomaticEventsConfigAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-automatic-events-config';

	private const ADMIN_UI_PATH = 'PixelYourSite → General Settings → Automatic Events';

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get Automatic Events Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Returns the GLOBAL automatic (page-level) event configuration in PixelYourSite — the events PYS fires site-wide regardless of WooCommerce/EDD: internal & outbound links, video, phone/email links, form, signup, login, download, comment, AdSense, scroll depth, time on page, search, 404, rage click, video speed. Sections: `master_enabled` (the single switch that gates ALL automatic events), `global_events` (per-event on/off at the global level), `platform_events` (FULL per-platform firing matrix: for every active platform, the effective on/off of every automatic event it registers — events a platform does not register at runtime are simply absent from its row (sets differ: e.g. Pinterest/Bing/Reddit lack rage_click/video_speed/404; 404 is GA4/GTM only). When the user asks to see events by platform, render THIS as a matrix/table directly, all platforms at once, without caveats about which events are per-platform-toggleable), `platform_toggles` (the raw per-platform gate values — same pairs as `platform_events` but ignoring master/global; this is the layer `set_automatic_event_config.platform_event_toggles` writes; note the PYS admin UI only shows per-platform switches for video/signup — other pairs are MCP-only), and `settings` (scroll % threshold, time-on-page seconds, rage-click threshold, YouTube/Vimeo video sub-toggles, tracked download extensions). Write toggles AND settings via `set_automatic_event_config`. Call this when the user asks about automatic / page-level / site-wide event tracking, or which platforms fire them.';
	}

	/**
	 * Input JSON-Schema (no args).
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'available' ),
			'properties' => array(
				'available'       => array( 'type' => 'boolean' ),
				'admin_ui_path'   => array( 'type' => 'string' ),
				'master_enabled'  => array(
					'type'        => 'boolean',
					'description' => 'The single master switch (`automatic_events_enabled`). When false, NO automatic event fires for any platform regardless of the toggles below.',
				),
				'global_events'   => array(
					'type'                 => 'object',
					'description'          => 'Per-event global on/off. Keyed by event stem => bool.',
					'additionalProperties' => array( 'type' => 'boolean' ),
				),
				'platform_events' => array(
					'type'                 => 'object',
					'description'          => 'FULL effective firing matrix: platform slug => { event_stem => bool } for every active platform and every automatic event it registers. true = the event currently fires on that platform (master AND global AND the platform\'s own gate). Events a platform does not register are absent from its row — the sets legitimately differ per platform. When asked to show events by platform, present this whole matrix directly.',
					'additionalProperties' => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'boolean' ),
					),
				),
				'platform_toggles' => array(
					'type'                 => 'object',
					'description'          => 'Raw per-platform gate values (stored switch values, ignoring master/global) for every registered pair. This is the layer `set_automatic_event_config.platform_event_toggles` writes. The admin UI only renders switches for video/signup; the rest are MCP-only.',
					'additionalProperties' => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'boolean' ),
					),
				),
				'settings'        => array(
					'type'        => 'object',
					'description' => 'Thresholds / sub-toggles: `scroll_value` (% depth that triggers Scroll), `time_on_page_value` (seconds), `rage_click_threshold` (quick clicks within 2s that trigger RageClick), `video_youtube_enabled` / `video_vimeo_enabled` (Video sub-toggles), `download_extensions` (tracked file extensions, no dots). All writable via `set_automatic_event_config` (same arg names).',
				),
			),
		);
	}

	/**
	 * Build the read-only automatic-events snapshot.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		if ( null === $pys ) {
			return array( 'available' => false );
		}

		$global = array();
		foreach ( EventToggleMap::AUTOMATIC_EVENTS as $event ) {
			$global[ $event ] = EventToggleMap::toBool( $pys->getOption( EventToggleMap::key( 'automatic', $event ) ) );
		}

		$master  = EventToggleMap::toBool( $pys->getOption( 'automatic_events_enabled' ) );
		$toggles = EventToggleMap::platformMatrix( 'automatic' ); // video/signup raw toggle values

		$effective = array();
		foreach ( \PixelYourSite\MCP\Platforms::activeSettings() as $slug => $settings ) {
			if ( !in_array( $slug, EventToggleMap::TARGET_PLATFORMS, true ) ) {
				continue;
			}
			$row = array();
			foreach ( EventToggleMap::AUTOMATIC_EVENTS as $event ) {
				if ( !EventToggleMap::platformRegisters( 'automatic', $slug, $event, $settings ) ) {
					continue;
				}
				$row[ $event ] = $master && $global[ $event ]
				                 && EventToggleMap::toBool( $settings->getOption( EventToggleMap::key( 'automatic', $event ) ) );
			}
			$effective[ $slug ] = $row;
		}

		$ext = $pys->getOption( 'automatic_event_download_extensions' );

		return array(
			'available'        => true,
			'admin_ui_path'    => self::ADMIN_UI_PATH,
			'master_enabled'   => $master,
			'global_events'    => $global,
			'platform_events'  => $effective,
			'platform_toggles' => $toggles,
			'settings'        => array(
				'scroll_value'          => (float) $pys->getOption( 'automatic_event_scroll_value', 0 ),
				'time_on_page_value'    => (float) $pys->getOption( 'automatic_event_time_on_page_value', 0 ),
				'rage_click_threshold'  => (int) $pys->getOption( 'automatic_event_rage_click_threshold', 0 ),
				'video_youtube_enabled' => EventToggleMap::toBool( $pys->getOption( 'automatic_event_video_youtube_enabled' ) ),
				'video_vimeo_enabled'   => EventToggleMap::toBool( $pys->getOption( 'automatic_event_video_vimeo_enabled' ) ),
				'download_extensions'   => array_values( array_filter( is_array( $ext ) ? array_map( 'strval', $ext ) : array() ) ),
			),
		);
	}
}
