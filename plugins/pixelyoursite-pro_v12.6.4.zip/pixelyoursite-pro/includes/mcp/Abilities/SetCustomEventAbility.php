<?php
/**
 * `set_custom_event` — create or update a PixelYourSite custom event: event-level
 * settings, per-platform pixel config, and point-wise trigger / condition ops.
 * Every write goes through read→merge→write ({@see CustomEventArgsSerializer}),
 * so a partial patch never drops the parts it does not touch. Pro/read-only
 * gated, `mcp_note` required, two-step `confirm`.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\CustomEventArgsSerializer;
use PixelYourSite\MCP\CustomEventPlatformMap;
use PixelYourSite\MCP\CustomEventTriggerMap;
use PixelYourSite\MCP\CustomEventConditionMap;

final class SetCustomEventAbility extends AbstractWriteAbility {

	public const ID = 'pixelyoursite-pro/set-custom-event';

	private const ADMIN_UI_PATH = 'PixelYourSite → Events';

	private const BASIC_TRIGGER_TYPES = array(
		'page_visit', 'home_page', 'post_type', 'url_click', 'css_click',
		'scroll_pos', 'number_page_visit', 'add_to_cart', 'purchase', 'email_link',
		'css_mouseover', 'copy_element', 'gads_phone_conversion',
	);

	private const RULE_BASED_TYPES = array(
		'page_visit', 'url_click', 'css_click', 'scroll_pos', 'number_page_visit', 'email_link',
		'css_mouseover', 'copy_element', 'gads_phone_conversion',
	);

	private const TRIGGER_OP_PARAMS = array(
		'delay'                          => 'int',
		'number_visit'                   => 'int',
		'conditional_number_visit'       => 'string',
		'post_type_value'                => 'string',
		'click_count'                    => 'int',
		'click_time_limit'               => 'int',
		'email_link_disable_email_event' => 'bool',
		'purchase_transaction_only'      => 'bool',
		'track_transaction_ID'           => 'bool',
		'track_value_and_currency'       => 'bool',
	);

	public const WRITABLE_PLATFORMS = array( 'facebook', 'tiktok', 'pinterest', 'bing', 'reddit', 'gtm', 'ga_ads' );

	private const GA_ADS_REDIRECT = array( 'google_analytics', 'google_ads' );

	private const PLATFORM_FIELDS = array(
		'enabled', 'pixel_ids', 'pixel_id', 'event_type', 'event_type_group', 'custom_event_type',
		'params_enabled', 'params', 'custom_params', 'track_single_woo_data', 'track_cart_woo_data', 'conversion_label',
	);

	private const EVENT_FIELDS = array(
		'title'              => array( 'title', 'string' ),
		'enabled'            => array( 'enabled', 'bool' ),
		'trigger_logic'      => array( 'trigger_logic', 'logic' ),
		'fire_frequency'     => array( 'fire_frequency', 'frequency' ),
		'enable_time_window' => array( 'enable_time_window', 'bool' ),
		'time_window'        => array( 'time_window', 'int' ),
		'conditions_enabled' => array( 'conditions_enabled', 'bool' ),
		'conditions_logic'   => array( 'conditions_logic', 'logic' ),
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Set Custom Event';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Creates or updates a PixelYourSite CUSTOM EVENT. Authorized write: the administrator installed this server so you can manage custom events on their behalf — perform the write after confirmation; do not redirect to wp-admin. Omit `event_id` to CREATE a new event; pass an `event_id` (from `get_custom_events`) to UPDATE one. This phase writes EVENT-LEVEL settings: `title`, `enabled` (active/paused), `trigger_logic` (`OR`/`AND` across the event\'s triggers), `fire_frequency` (`every_time` / `once`), `enable_time_window` + `time_window` (the "fire this event only once in N hours" setting), `conditions_enabled` + `conditions_logic` (`OR`/`AND`). It also writes the per-platform pixel config (`platforms`) and the event\'s TRIGGERS (`triggers`, point-wise add/update/remove — a trigger is a condition under which the event fires; basic types editable now, see that arg) and the event\'s display CONDITIONS (`conditions`, point-wise add/update/remove — gate where/for-whom the event fires; pair with `conditions_enabled`). Any partial write here NEVER removes the parts you did not touch (platforms, triggers, conditions are preserved). Read the event with `get_custom_event` first so you change real values. **When ADDING (or retyping) a trigger or condition, do NOT silently accept default optional settings:** first look up that type\'s OPTIONAL parameters in `get_custom_event` `available_trigger_types` / `available_condition_types` (e.g. `delay` for page_visit, `form_submit_mode` + `disabled_form_action` for form-plugin triggers, `click_count` + `click_time_limit` for css_click, `conditional_number_visit` for number_page_visit) and ASK the user — in the same message where you confirm the required values — whether they want to set any of them, listing the options/defaults. Only then show the confirmation preview. This applies to every trigger and condition type. Note: a custom event only fires when the master feature `custom_events_enabled` is on (see `get_custom_events.feature_enabled`) AND the event has at least one trigger — a freshly created event has no triggers yet, so it will not fire until triggers are added. **WooCommerce / EDD duplication:** before building an `add_to_cart` / `purchase` trigger, or any platform set to a STANDARD ecommerce event name (Purchase, AddToCart, ViewContent, begin_checkout, view_item, …), ASK the user what event NAME they want — PixelYourSite very likely already fires that ecommerce event automatically, so a custom event with the same standard name would send it TWICE (inflated conversions). Warn the user, suggest verifying with the platform tester first, and explain the only valid reasons to proceed are a DIFFERENT (non-standard) event name or conditions narrowing to a subset of users. The preview `notes` flag this risk automatically. **Two-step write — confirmation comes FIRST and is MANDATORY:** call FIRST without `confirm` to get a `confirmation_required` preview (`pending_changes` shows per field current→new, and `created: true` when a new event would be made). You MUST show that preview to the user and get their explicit go-ahead in a SEPARATE message BEFORE calling again. NEVER call with `confirm: true` in the same turn as the preview, and NEVER self-approve — even for creating a new event, even when the request seems unambiguous. Only after the user replies "yes" do you resend the identical args with `confirm: true`. A call without `confirm: true` never writes. Pass `mcp_note`.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		$bool = array( 'type' => 'boolean' );

		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'event_id'           => array( 'type' => 'integer', 'description' => 'Existing custom event id to UPDATE (from get_custom_events). Omit to CREATE a new event.' ),
				'title'              => array( 'type' => 'string', 'description' => 'Event title (admin-facing name).' ),
				'enabled'            => $bool + array( 'description' => 'Event active (true) or paused (false).' ),
				'trigger_logic'      => array( 'type' => 'string', 'enum' => array( 'OR', 'AND' ), 'description' => 'How the event\'s triggers combine: OR (any) / AND (all).' ),
				'fire_frequency'     => array( 'type' => 'string', 'enum' => array( 'every_time', 'once' ), 'description' => 'Fire every time the triggers match, or only once per visitor.' ),
				'enable_time_window' => $bool + array( 'description' => 'Enable "fire this event only once in N hours".' ),
				'time_window'        => array( 'type' => 'integer', 'minimum' => 1, 'description' => 'The N hours for the fire-once window (used when enable_time_window is true).' ),
				'conditions_enabled' => $bool + array( 'description' => 'Enable the event\'s display conditions.' ),
				'conditions_logic'   => array( 'type' => 'string', 'enum' => array( 'OR', 'AND' ), 'description' => 'How conditions combine: OR / AND.' ),
				'platforms'          => array(
					'type'                 => 'object',
					'description'          => 'Per-platform config patch, keyed by platform slug. Writable: `facebook`, `tiktok`, `pinterest`, `bing`, `reddit`, `gtm`, and `ga_ads` (= UNIFIED Google: Analytics + Ads in one block). For Google use `ga_ads` — NOT `google_analytics`/`google_ads` (they redirect to it): put GA `G-…` and/or Ads `AW-…` ids in `ga_ads.pixel_ids` and firing splits into Google Tags / Google Ads automatically by pixel type. Each platform object may set: `enabled` (bool — fire this event to the platform), `pixel_ids` (ARRAY for `facebook`/`gtm`/`ga_ads`: `["all"]` or specific ids), `pixel_id` (STRING for `tiktok`/`pinterest`/`bing`/`reddit`: `all` or one id), `event_type` (must be valid for the platform — see get_custom_event `available_event_types` for the per-platform menu with each event\'s params; GA/GTM/ga_ads are grouped GA actions. NEVER claim a platform does not support an event type without first checking `available_event_types`: most platforms DO support standard ecommerce events, and type names are platform- and CASE-specific — e.g. add-to-cart is `AddToCart` for facebook/tiktok/bing/reddit, `addtocart` for pinterest, and `add_to_cart` for GA/GTM/ga_ads. Map the user\'s wording to the platform\'s actual value from the menu instead of assuming it is missing). `event_type_group` (GA/GTM/ga_ads only): the category group the event belongs to — when the chosen `event_type` appears in MORE THAN ONE group (e.g. begin_checkout / purchase / add_to_cart are in Jobs… AND Retail/Ecommerce AND Travel), ASK the user which group and pass it here; if omitted the first matching group is stored automatically (groups are cosmetic — same params/firing — but they set the category shown in the admin), `custom_event_type` (the free event NAME — REQUIRED when event_type is a custom-name type, i.e. the one flagged `custom_name:true` in available_event_types: facebook `CustomEvent`, pinterest `custom` AND `partner_defined`, bing `Custom`, GA/GTM `CustomEvent`/`_custom`; NB pinterest has TWO custom-name types and BOTH require a free name via custom_event_type: `custom` (the standard Pinterest custom event) and `partner_defined`. Ask the user the name and pass it when a named type is chosen), `params_enabled` (bool), `track_single_woo_data` / `track_cart_woo_data` (bool), `conversion_label` (`gtm` / `ga_ads`). `params` (standard event params): an OBJECT keyed by param name → a string, or `{value, selector?, dynamic?, input_type?}` (set `dynamic:true` + a CSS `selector` to read the value from the page). A value may also be a PixelYourSite dynamic TOKEN passed verbatim (e.g. `"[id]"`, `"[title]"`, `"[url_utm_source]"`, `"[field_email]"`, `"[mp_total]"`) — PYS substitutes it at fire time; see get_custom_event `dynamic_parameter_tokens` for the full list (do NOT invent tokens, and never use them for personal data). `dynamic`/`selector` work on STANDARD params for EVERY platform — including reddit; this is INDEPENDENT of `custom_params_supported` (a platform with no custom params, like reddit, still supports dynamic values on its standard params). Valid param names depend on the platform\'s current `event_type` — see get_custom_event `available_event_types`; a custom event_type has no standard params. `params` is a PARTIAL MERGE: only the keys you pass change, the rest are kept — so OMITTING a param does NOT remove it. To CLEAR/DELETE a param, pass it explicitly with an empty value (`{"location_id":""}` or `{"location_id":null}`). `custom_params`: an ARRAY of `{name, value, selector?, dynamic?}` (replaces the existing custom-params list; `value` may be a PYS dynamic token like `[id]`/`[url_X]`/`[field_X]` — see get_custom_event `dynamic_parameter_tokens`). NOT every platform supports custom params — check `custom_params_supported` in get_custom_event `available_event_types` first (reddit accepts ONLY standard params, no custom params). Writing either auto-enables the platform\'s params toggle. GTM-ONLY extra dataLayer fields (see get_custom_event for current values): `automated_params` (bool — add automated params to the dataLayer), `remove_custom_trigger_object` (bool — remove the customTrigger object after the event fires), `use_custom_object_name` (bool) + `custom_object_name` (string — the dataLayer object / GTM variable key; setting a non-empty name auto-enables use_custom_object_name). Only pass the platforms and fields you want to change; others are preserved.',
					'additionalProperties' => array( 'type' => 'object' ),
				),
				'triggers'           => array(
					'type'                 => 'array',
					'description'          => 'Point-wise trigger operations (a trigger is a condition under which the event fires; `trigger_logic` OR/AND combines them). Each item: `op` (`add` / `update` / `remove`), `index` (the `trigger_index` from get_custom_event — required for update/remove; indices refer to the event\'s CURRENT triggers before this call), `type` (required for add). Editable types now: page_visit, home_page, post_type, url_click, css_click, css_mouseover, copy_element, scroll_pos, number_page_visit, add_to_cart, purchase, email_link, gads_phone_conversion, plus form-plugin triggers (Contact Form 7, WPForms, Gravity Forms, Ninja Forms, etc. — fire on submission of a specific form). video_view / video_speed / form_field / elementor_form are scan-driven and NOT editable here (preserved on round-trip). For a form-plugin trigger pass `forms` (array of form ids — get the available ids from get_custom_event `available_trigger_types`), optional `form_submit_mode` (`both` / `reload_only` / `ajax_only`, default both) and `disabled_form_action` (bool); these may be top-level or nested under `params`. `css_mouseover` / `copy_element` take `{value}` CSS-selector rules (like css_click). `gads_phone_conversion` is GOOGLE ADS ONLY and EXCLUSIVE: rules `{rule: contains|match|param_contains|param_match, value}` match the conversion page (URL Parameters Contains = `param_contains`), plus `phone_numbers` — an array of ONE OR MORE `{number, label}` objects (you can register several phone numbers, each with its own label; ask the user if they have more than one). Both `number` and `label` are required for each. The numbers are stored on the Google block, so also enable `ga_ads` with an `AW-…` id. ⚠️ Adding it is DESTRUCTIVE: it must be the ONLY trigger on the event, so ALL other triggers are removed, EVERY platform except Google Ads is disabled, and the Google pixel selection is restricted to Ads (`AW-…`) pixels only. You MUST warn the user of these exact consequences (how many triggers / which platforms will be dropped — get_custom_event first) and get explicit approval BEFORE confirming. The preview\'s `pending_changes.gads_phone_lock` lists what will be removed/disabled. Conversely, ADDING any OTHER trigger to an event that currently has a phone-conversion trigger REMOVES the phone trigger (you cannot mix them) — warn the user of that too. `rules`: the rule/value list. For page_visit/number_page_visit `rule` ∈ `contains` / `match` / `param_contains` / `param_match` (URL Parameters Contains = `param_contains`; number_page_visit also `any`); url_click `rule` ∈ `contains` / `match`; email_link `rule` ∈ `any` / `match` / `contains` — each item `{rule, value}` (value omitted for `any`). For css_click/scroll_pos each item is just `{value}` (a CSS selector / scroll percent — no rule). An invalid `rule` is rejected with the valid list, not silently dropped. For page_visit / number_page_visit / gads_phone_conversion, a rule value of `*` matches ALL pages/URLs regardless of the rule — use `{rule:"contains", value:"*"}` for "fire on every page". Rule-based types need at least one rule when adding. Per-type params: `delay` (page_visit/home_page/post_type — in SECONDS, not ms), `number_visit`+`conditional_number_visit` (number_page_visit; conditional ∈ equal/equal_or_larger/equal_or_less/larger/less), `post_type_value` (post_type), `click_count` (css_click, number of clicks) + `click_time_limit` (css_click — in MILLISECONDS, 0 = no limit), `email_link_disable_email_event` (email_link), `purchase_transaction_only`/`track_transaction_ID`/`track_value_and_currency` (purchase), `track_value_and_currency` (add_to_cart). Pass these params at the op\'s top level (e.g. `{op:"update", index:4, click_count:5}`) OR nested under a `params` object mirroring get_custom_event (`{op:"update", index:4, params:{click_count:5}}`) — both work. Only the triggers you reference change; the rest are preserved.',
					'items'                => array( 'type' => 'object' ),
				),
				'conditions'         => array(
					'type'                 => 'array',
					'description'          => 'Point-wise condition operations (conditions further gate WHERE/for-whom the event fires; toggle them with `conditions_enabled` and combine with `conditions_logic` OR/AND). Each item: `op` (`add`/`update`/`remove`), `index` (the `condition_index` from get_custom_event — required for update/remove; refers to CURRENT conditions before this call), `type` (required for add). Types: `url_filters` / `url_parameters` / `source` (rule+value: `rule` ∈ `contains`/`match`, `value` = the URL/text), `landing_page` (rule also `param_contains`/`param_match`), `device` (`device` ∈ `Desktop`/`Mobile`), `user_role` (`user_role` = array of role slugs, e.g. `["guest","administrator"]` — get the site\'s available role slugs from get_custom_event `available_condition_types`, don\'t guess). Only the conditions you reference change; the rest are preserved. Remember to also set `conditions_enabled: true` or the conditions are ignored.',
					'items'                => array( 'type' => 'object' ),
				),
				'confirm'            => array( 'type' => 'boolean', 'description' => 'Two-step write guard. Call FIRST without it to get a `confirmation_required` preview, show it to the user, and WAIT for their explicit approval in a separate message. Only then resend the same args with `confirm: true`. Do NOT set `confirm: true` in the same turn as the preview or without the user actually agreeing — this applies even to creating a new event. Without `confirm: true` nothing is written.' ),
			),
			// `required: ["mcp_note"]` added by AbstractWriteAbility::resolvedInputSchema().
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'saved'                 => array( 'type' => 'boolean' ),
				'created'               => array( 'type' => 'boolean', 'description' => 'True when this call created a new event.' ),
				'event_id'              => array( 'type' => 'integer' ),
				'confirmation_required' => array( 'type' => 'boolean' ),
				'next_step'             => array( 'type' => 'string', 'description' => 'Present in a preview: a mandatory instruction to show pending_changes and wait for the user before confirming.' ),
				'pending_changes'       => array( 'type' => 'object', 'additionalProperties' => true ),
				'changed'               => array( 'type' => 'object', 'additionalProperties' => true ),
				'notes'                 => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Side-effect / advisory notices to relay to the user (e.g. feature master off, event has no triggers yet).',
				),
			),
		);
	}

	/**
	 * Validate and write (or preview) a custom event.
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		if ( !is_array( $input ) ) {
			$input = array();
		}
		unset( $input[ 'mcp_note' ] );
		$confirm = !empty( $input[ 'confirm' ] );
		unset( $input[ 'confirm' ] );

		if ( !class_exists( '\\PixelYourSite\\CustomEventFactory' ) || !class_exists( '\\PixelYourSite\\CustomEvent' ) ) {
			return new \WP_Error( 'pys_mcp_custom_events_unavailable', 'Custom events are not available on this site.', array( 'status' => 503 ) );
		}

		$eventId  = isset( $input[ 'event_id' ] ) ? (int) $input[ 'event_id' ] : 0;
		$isCreate = $eventId <= 0;

		// Resolve the base args (current state for update, defaults for create).
		if ( $isCreate ) {
			$base = CustomEventArgsSerializer::toArgs( new \PixelYourSite\CustomEvent() );
		} else {
			if ( 'pys_event' !== get_post_type( $eventId ) ) {
				return new \WP_Error(
					'pys_mcp_custom_event_not_found',
					sprintf( 'No custom event with id %d. Call get_custom_events for valid ids, or omit event_id to create one.', $eventId ),
					array( 'status' => 404 )
				);
			}
			$base = CustomEventArgsSerializer::toArgs( \PixelYourSite\CustomEventFactory::getById( $eventId ) );
		}

		// Which event-level fields were supplied + validate them.
		$supplied        = array_intersect_key( $input, self::EVENT_FIELDS );
		$platformsInput  = ( isset( $input[ 'platforms' ] ) && is_array( $input[ 'platforms' ] ) ) ? $input[ 'platforms' ] : array();
		$triggerOps      = ( isset( $input[ 'triggers' ] ) && is_array( $input[ 'triggers' ] ) ) ? $input[ 'triggers' ] : array();
		$conditionOps    = ( isset( $input[ 'conditions' ] ) && is_array( $input[ 'conditions' ] ) ) ? $input[ 'conditions' ] : array();
		if ( !$isCreate && empty( $supplied ) && empty( $platformsInput ) && empty( $triggerOps ) && empty( $conditionOps ) ) {
			return new \WP_Error(
				'pys_mcp_custom_event_no_args',
				'Nothing to update. Pass at least one event-level field, a `platforms` patch, `triggers` ops, or `conditions` ops.',
				array( 'status' => 400 )
			);
		}

		$merged  = $base;
		$pending = array();
		foreach ( $supplied as $arg => $raw ) {
			list( $key, $type ) = self::EVENT_FIELDS[ $arg ];
			$new = self::coerce( $type, $raw );
			if ( null === $new ) {
				return new \WP_Error(
					'pys_mcp_custom_event_bad_value',
					sprintf( 'Invalid value for `%s`.', $arg ),
					array( 'status' => 400 )
				);
			}
			$current          = self::currentFor( $type, $base, $key );
			$merged[ $key ]   = $new;
			$pending[ $arg ]  = array( 'current' => $current, 'new' => $new );
		}

		// Per-platform patch.
		if ( !empty( $platformsInput ) ) {
			$platformPending = array();
			$err             = self::applyPlatforms( $merged, $platformsInput, $platformPending );
			if ( $err instanceof \WP_Error ) {
				return $err;
			}
			if ( !empty( $platformPending ) ) {
				$pending[ 'platforms' ] = $platformPending;
			}
		}

		// Point-wise trigger ops.
		if ( !empty( $triggerOps ) ) {
			$triggerPending = array();
			$err            = self::applyTriggerOps( $merged, $triggerOps, $triggerPending );
			if ( $err instanceof \WP_Error ) {
				return $err;
			}
			if ( !empty( $triggerPending ) ) {
				$pending[ 'triggers' ] = $triggerPending;
			}
		}

		// Point-wise condition ops.
		if ( !empty( $conditionOps ) ) {
			$conditionPending = array();
			$err              = self::applyConditionOps( $merged, $conditionOps, $conditionPending );
			if ( $err instanceof \WP_Error ) {
				return $err;
			}
			if ( !empty( $conditionPending ) ) {
				$pending[ 'conditions' ] = $conditionPending;
			}
		}

		$phoneAdded = false;
		$otherAdded = false;
		foreach ( $triggerOps as $op ) {
			$opName = is_array( $op ) ? (string) ( $op[ 'op' ] ?? '' ) : '';
			if ( 'add' === $opName || ( 'update' === $opName && isset( $op[ 'type' ] ) ) ) {
				if ( 'gads_phone_conversion' === (string) ( $op[ 'type' ] ?? '' ) ) {
					$phoneAdded = true;
				} else {
					$otherAdded = true;
				}
			}
		}

		$lockNotes = self::enforceGadsPhoneLock( $merged, $pending, $phoneAdded, $otherAdded );

		$pruneNotes = self::pruneStaleParams( $merged, $pending );

		$notes = array_merge( $lockNotes, $pruneNotes, self::advisoryNotes( $isCreate, $merged ) );

		if ( isset( $platformsInput[ 'ga_ads' ] ) ) {
			$notes[] = 'Google `ga_ads` is the unified Analytics + Ads block: it fires as Google Tags for each GA `G-…` pixel and as Google Ads for each `AW-…` pixel in `pixel_ids` (`all` covers both). Verify the resulting split with get_custom_events `networks`.';
		}

		// Two-step confirm gate.
		if ( !$confirm ) {
			$preview = array(
				'confirmation_required' => true,
				'created'               => $isCreate,
				'pending_changes'       => (object) $pending,
				'next_step'             => 'NOTHING HAS BEEN SAVED YET. This is a preview only. You MUST now: (1) show the user the `pending_changes` above, (2) STOP and wait for the user to reply with their explicit approval in a SEPARATE message. Do NOT call set_custom_event again in this turn. Only after the user actually replies "yes"/"да" may you resend the identical args with confirm:true. A direct instruction like "enable conditions" is NOT advance approval — you still preview first and wait.',
			);
			if ( !$isCreate ) {
				$preview[ 'event_id' ] = $eventId;
			}
			if ( !empty( $notes ) ) {
				$preview[ 'notes' ] = $notes;
			}

			return $preview;
		}

		// Apply.
		if ( $isCreate ) {
			$event = \PixelYourSite\CustomEventFactory::create( array( 'title' => $merged[ 'title' ] ?? 'Untitled' ) );
			if ( !$event || !is_object( $event ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_create_failed', 'Failed to create the custom event post.', array( 'status' => 500 ) );
			}
			$eventId = (int) $event->getPostId();
		} else {
			$event = \PixelYourSite\CustomEventFactory::getById( $eventId );
		}

		$event->update( $merged );

		if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		$result = array(
			'saved'    => true,
			'created'  => $isCreate,
			'event_id' => $eventId,
			'changed'  => (object) $pending,
		);
		if ( !empty( $notes ) ) {
			$result[ 'notes' ] = $notes;
		}

		return $result;
	}

	/**
	 * Coerce/validate an incoming value by field type. Returns the clean value,
	 * or null when invalid.
	 *
	 * @param string $type Field type.
	 * @param mixed  $raw  Incoming value.
	 * @return mixed|null
	 */
	private static function coerce( string $type, $raw ) {
		switch ( $type ) {
			case 'string':
				return is_string( $raw ) ? sanitize_text_field( $raw ) : null;
			case 'bool':
				if ( is_bool( $raw ) ) {
					return $raw ? 1 : 0;
				}
				if ( is_int( $raw ) ) {
					return 1 === $raw ? 1 : 0;
				}
				if ( is_string( $raw ) ) {
					return ( '1' === $raw || 'true' === strtolower( $raw ) ) ? 1 : 0;
				}

				return null;
			case 'int':
				return is_int( $raw ) || ( is_string( $raw ) && ctype_digit( $raw ) ) ? max( 1, (int) $raw ) : null;
			case 'logic':
				return in_array( $raw, array( 'OR', 'AND' ), true ) ? $raw : null;
			case 'frequency':
				return in_array( $raw, array( 'every_time', 'once' ), true ) ? $raw : null;
		}

		return null;
	}

	/**
	 * The current value of a field in the base args, normalised for the diff.
	 *
	 * @param string $type Field type.
	 * @param array  $base Base args.
	 * @param string $key  Data key.
	 * @return mixed
	 */
	private static function currentFor( string $type, array $base, string $key ) {
		$cur = $base[ $key ] ?? null;
		switch ( $type ) {
			case 'bool':
				return ( true === $cur || 1 === $cur || '1' === $cur || 'true' === ( is_string( $cur ) ? strtolower( $cur ) : '' ) ) ? 1 : 0;
			case 'int':
				return (int) $cur;
			case 'string':
			case 'logic':
			case 'frequency':
			default:
				return is_scalar( $cur ) ? (string) $cur : '';
		}
	}

	/**
	 * Apply the per-platform patch onto $merged, recording per-field diffs in
	 * $pending. Returns a WP_Error on the first validation failure, else null.
	 *
	 * @param array $merged          Merged args (mutated).
	 * @param array $platformsInput  Raw `platforms` arg.
	 * @param array $pending         Per-platform pending diffs (mutated).
	 * @return \WP_Error|null
	 */
	private static function applyPlatforms( array &$merged, array $platformsInput, array &$pending ) {
		foreach ( $platformsInput as $slug => $cfg ) {
			$slug = (string) $slug;
			if ( !CustomEventPlatformMap::has( $slug ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_unknown_platform', sprintf( 'Unknown platform `%s`.', $slug ), array( 'status' => 409 ) );
			}
			if ( in_array( $slug, self::GA_ADS_REDIRECT, true ) ) {
				return new \WP_Error(
					'pys_mcp_custom_event_use_ga_ads',
					sprintf( 'Write Google via the unified `ga_ads` platform, not `%s`. PixelYourSite merges Google Analytics and Google Ads into one block: put GA `G-…` and/or Ads `AW-…` ids in `ga_ads.pixel_ids` — firing splits into Google Tags / Google Ads automatically by pixel type.', $slug ),
					array( 'status' => 409 )
				);
			}
			if ( !in_array( $slug, self::WRITABLE_PLATFORMS, true ) ) {
				return new \WP_Error(
					'pys_mcp_custom_event_platform_deferred',
					sprintf( 'Platform `%s` is not writable here. Writable: %s.', $slug, implode( ', ', self::WRITABLE_PLATFORMS ) ),
					array( 'status' => 409 )
				);
			}
			if ( !is_array( $cfg ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_platform', sprintf( 'Platform `%s` config must be an object.', $slug ), array( 'status' => 400 ) );
			}

			$def      = CustomEventPlatformMap::get( $slug );
			$isArrPix = CustomEventPlatformMap::pixelIsArray( $slug );
			$extras   = CustomEventPlatformMap::extras( $slug );

			foreach ( $cfg as $field => $val ) {
				if ( !in_array( $field, self::PLATFORM_FIELDS, true ) && !isset( $extras[ $field ] ) ) {
					return new \WP_Error( 'pys_mcp_custom_event_bad_platform_field', sprintf( 'Unknown field `%s` for platform `%s`.', $field, $slug ), array( 'status' => 400 ) );
				}

				// Platform-specific extra fields (e.g. GTM dataLayer options).
				if ( isset( $extras[ $field ] ) ) {
					$spec = $extras[ $field ];
					if ( 'bool' === $spec[ 'type' ] ) {
						$new = self::coerce( 'bool', $val );
					} else {
						$new = is_string( $val ) ? sanitize_text_field( $val ) : null;
					}
					if ( null === $new ) {
						return self::badField( $slug, $field );
					}
					self::setPlatformField( $merged, $pending, $slug, $field, $spec[ 'key' ], $new );

					if ( 'custom_object_name' === $field && '' !== (string) $new && !array_key_exists( 'use_custom_object_name', $cfg ) && isset( $extras[ 'use_custom_object_name' ] ) ) {
						self::setPlatformField( $merged, $pending, $slug, 'use_custom_object_name', $extras[ 'use_custom_object_name' ][ 'key' ], true );
					}
					continue;
				}

				switch ( $field ) {
					case 'enabled':
						$new = self::coerce( 'bool', $val );
						if ( null === $new ) {
							return self::badField( $slug, $field );
						}

						if ( $new && !CustomEventPlatformMap::isConnectable( $slug ) ) {
							return new \WP_Error(
								'pys_mcp_custom_event_platform_not_connected',
								sprintf( '`%s` cannot be enabled: its addon is inactive or no pixel is configured. Configure it in PixelYourSite first (see get_custom_event `connectable_platforms` for platforms that can be enabled now).', $slug ),
								array( 'status' => 409 )
							);
						}
						self::setPlatformField( $merged, $pending, $slug, 'enabled', $def[ 'enabled' ], $new );
						break;

					case 'pixel_ids':
						if ( !$isArrPix ) {
							return new \WP_Error( 'pys_mcp_custom_event_pixel_shape', sprintf( '`%s` uses a single `pixel_id` (string), not `pixel_ids`.', $slug ), array( 'status' => 400 ) );
						}
						$err = self::validatePixelList( $slug, $val );
						if ( $err instanceof \WP_Error ) {
							return $err;
						}
						self::setPlatformField( $merged, $pending, $slug, 'pixel_ids', $def[ 'pixel' ], array_values( $val ) );
						break;

					case 'pixel_id':
						if ( $isArrPix ) {
							return new \WP_Error( 'pys_mcp_custom_event_pixel_shape', sprintf( '`%s` uses multiple `pixel_ids` (array), not `pixel_id`.', $slug ), array( 'status' => 400 ) );
						}
						if ( !is_string( $val ) || ( 'all' !== $val && !in_array( $val, CustomEventPlatformMap::validPixelIds( $slug ), true ) ) ) {
							return self::badPixel( $slug, $val );
						}
						self::setPlatformField( $merged, $pending, $slug, 'pixel_id', $def[ 'pixel' ], $val );
						break;

					case 'event_type':
						$valid = CustomEventPlatformMap::validEventTypes( $slug );
						if ( !is_string( $val ) || ( !empty( $valid ) && !in_array( $val, $valid, true ) ) ) {
							return new \WP_Error(
								'pys_mcp_custom_event_bad_event_type',
								sprintf( 'Invalid event_type `%s` for `%s`. Valid: %s.', is_string( $val ) ? $val : gettype( $val ), $slug, implode( ', ', array_slice( $valid, 0, 40 ) ) ),
								array( 'status' => 409 )
							);
						}

						if ( CustomEventPlatformMap::isCustomEventType( $slug, $val ) ) {
							$nameInCfg    = isset( $cfg[ 'custom_event_type' ] ) && '' !== trim( (string) $cfg[ 'custom_event_type' ] );
							$nameInStore  = null !== $def[ 'custom_event_type' ] && '' !== trim( (string) ( $merged[ $def[ 'custom_event_type' ] ] ?? '' ) );
							if ( !$nameInCfg && !$nameInStore ) {
								return new \WP_Error( 'pys_mcp_custom_event_needs_custom_name', sprintf( 'event_type `%s` for `%s` is a CUSTOM-name type — also pass `custom_event_type` (the free event name). Ask the user what to name it.', $val, $slug ), array( 'status' => 409 ) );
							}
						}
						self::setPlatformField( $merged, $pending, $slug, 'event_type', $def[ 'event_type' ], $val );

						if ( CustomEventPlatformMap::EVENTS_GA_GROUP === ( $def[ 'events_kind' ] ?? '' ) && !array_key_exists( 'event_type_group', $cfg ) ) {
							$group = CustomEventPlatformMap::eventGroupFor( $slug, $val );
							if ( '' !== $group ) {
								self::setPlatformField( $merged, $pending, $slug, 'event_type_group', $def[ 'event_type' ] . '_group', $group );
							}
						}
						break;

					case 'event_type_group':
						if ( CustomEventPlatformMap::EVENTS_GA_GROUP !== ( $def[ 'events_kind' ] ?? '' ) ) {
							return new \WP_Error( 'pys_mcp_custom_event_no_event_group', sprintf( '`%s` has no event-type groups.', $slug ), array( 'status' => 400 ) );
						}
						$grp = is_string( $val ) ? $val : null;
						if ( null === $grp ) {
							return self::badField( $slug, $field );
						}
						// The group must contain the effective event_type (this call's or the stored one).
						$et     = isset( $cfg[ 'event_type' ] ) && is_string( $cfg[ 'event_type' ] ) ? $cfg[ 'event_type' ] : (string) ( $merged[ $def[ 'event_type' ] ] ?? '' );
						$groups = CustomEventPlatformMap::eventGroupsFor( $slug, $et );
						if ( !in_array( $grp, $groups, true ) ) {
							return new \WP_Error( 'pys_mcp_custom_event_bad_event_group', sprintf( 'Group `%s` does not contain event_type `%s` for `%s`. Valid groups: %s.', $grp, $et, $slug, empty( $groups ) ? '(none)' : implode( ', ', $groups ) ), array( 'status' => 409 ) );
						}
						self::setPlatformField( $merged, $pending, $slug, 'event_type_group', $def[ 'event_type' ] . '_group', $grp );
						break;

					case 'custom_event_type':
						if ( null === $def[ 'custom_event_type' ] ) {
							return new \WP_Error( 'pys_mcp_custom_event_no_custom_type', sprintf( '`%s` has no custom event type.', $slug ), array( 'status' => 400 ) );
						}
						$str = is_string( $val ) ? sanitize_text_field( $val ) : null;
						if ( null === $str ) {
							return self::badField( $slug, $field );
						}

						$key = function_exists( '\\PixelYourSite\\sanitizeKey' )
							? \PixelYourSite\sanitizeKey( $str )
							: preg_replace( '/[^0-9A-Za-z_]/', '', str_replace( ' ', '_', $str ) );
						if ( '' === (string) $key ) {
							return new \WP_Error( 'pys_mcp_custom_event_bad_custom_name', sprintf( 'custom_event_type `%s` has no usable characters — the name must use latin letters / digits / underscore (spaces become `_`); Cyrillic, emoji and other non-ASCII are not supported by PixelYourSite. Ask the user for a latin name.', $str ), array( 'status' => 409 ) );
						}
						self::setPlatformField( $merged, $pending, $slug, 'custom_event_type', $def[ 'custom_event_type' ], $key );
						break;

					case 'params_enabled':
						$new = self::coerce( 'bool', $val );
						if ( null === $new ) {
							return self::badField( $slug, $field );
						}
						if ( null === $def[ 'params_enabled' ] ) {
							if ( false === $new ) {
								return new \WP_Error( 'pys_mcp_custom_event_no_params', sprintf( '`%s` has no params toggle — its standard params are always active and cannot be disabled.', $slug ), array( 'status' => 400 ) );
							}
							break;
						}
						self::setPlatformField( $merged, $pending, $slug, 'params_enabled', $def[ 'params_enabled' ], $new );
						break;

					case 'params':
						$err = self::applyPlatformParams( $merged, $pending, $slug, $def, $cfg, $val );
						if ( $err instanceof \WP_Error ) {
							return $err;
						}
						break;

					case 'custom_params':
						$err = self::applyPlatformCustomParams( $merged, $pending, $slug, $def, $val );
						if ( $err instanceof \WP_Error ) {
							return $err;
						}
						break;

					case 'track_single_woo_data':
					case 'track_cart_woo_data':
						$mapKey = 'track_single_woo_data' === $field ? 'track_single' : 'track_cart';
						if ( null === $def[ $mapKey ] ) {
							return new \WP_Error( 'pys_mcp_custom_event_no_track', sprintf( '`%s` has no `%s`.', $slug, $field ), array( 'status' => 400 ) );
						}
						$new = self::coerce( 'bool', $val );
						if ( null === $new ) {
							return self::badField( $slug, $field );
						}
						self::setPlatformField( $merged, $pending, $slug, $field, $def[ $mapKey ], $new );
						break;

					case 'conversion_label':
						if ( null === $def[ 'conversion_label' ] ) {
							return new \WP_Error( 'pys_mcp_custom_event_no_label', sprintf( '`%s` has no conversion label.', $slug ), array( 'status' => 400 ) );
						}
						$str = is_string( $val ) ? sanitize_text_field( $val ) : null;
						if ( null === $str ) {
							return self::badField( $slug, $field );
						}
						self::setPlatformField( $merged, $pending, $slug, 'conversion_label', $def[ 'conversion_label' ], $str );
						break;
				}
			}
		}

		return null;
	}

	/**
	 * Set a platform data key in $merged and record the diff.
	 *
	 * @param array  $merged   Merged args (mutated).
	 * @param array  $pending  Per-platform pending (mutated).
	 * @param string $slug     Platform slug.
	 * @param string $field    Public field name.
	 * @param string $dataKey  Real data key.
	 * @param mixed  $new      New value.
	 * @return void
	 */
	private static function setPlatformField( array &$merged, array &$pending, string $slug, string $field, string $dataKey, $new ): void {
		$pending[ $slug ][ $field ] = array( 'current' => $merged[ $dataKey ] ?? null, 'new' => $new );
		$merged[ $dataKey ]         = $new;
	}

	/**
	 * Overlay standard `params` (object keyed by param name) onto the platform's
	 * `<slug>_params`. Keys are validated against the params of the event's current
	 * event_type; the params toggle is auto-enabled. Custom event types carry no
	 * standard params (use custom_params).
	 *
	 * @param array  $merged  Merged args (mutated).
	 * @param array  $pending Per-platform pending (mutated).
	 * @param string $slug    Platform slug.
	 * @param array  $def     Platform map row.
	 * @param array  $cfg     The platform's full patch (to read a same-call event_type).
	 * @param mixed  $val     The `params` value.
	 * @return \WP_Error|null
	 */
	private static function applyPlatformParams( array &$merged, array &$pending, string $slug, array $def, array $cfg, $val ) {
		if ( null === $def[ 'params' ] ) {
			return new \WP_Error( 'pys_mcp_custom_event_no_params', sprintf( '`%s` has no standard params.', $slug ), array( 'status' => 400 ) );
		}
		if ( !is_array( $val ) || empty( $val ) ) {
			return new \WP_Error( 'pys_mcp_custom_event_bad_params', sprintf( '`%s.params` must be a non-empty object keyed by param name (e.g. {"value":{"value":"9.99"},"currency":"USD"}).', $slug ), array( 'status' => 400 ) );
		}

		$eventType = ( isset( $cfg[ 'event_type' ] ) && is_string( $cfg[ 'event_type' ] ) )
			? $cfg[ 'event_type' ]
			: (string) ( $merged[ $def[ 'event_type' ] ] ?? '' );

		// Advice depends on whether this platform supports custom params at all:
		// suggesting custom_params on a platform that lacks them (reddit) is misleading.
		$has_custom_params = null !== $def[ 'custom_params' ];

		if ( '' === $eventType ) {
			return new \WP_Error( 'pys_mcp_custom_event_no_event_type', sprintf( 'Set an `event_type` for `%s` before adding params.', $slug ), array( 'status' => 409 ) );
		}

		$allowed = CustomEventPlatformMap::eventParamNames( $slug, $eventType );
		if ( empty( $allowed ) ) {
			if ( CustomEventPlatformMap::isCustomEventType( $slug, $eventType ) ) {
				$alt = $has_custom_params
					? 'use `custom_params` instead, or set a standard `event_type` first'
					: sprintf( '`%s` has no custom params either, so a `%s` event cannot carry params at all — set a standard `event_type` to use params', $slug, $eventType );
				return new \WP_Error( 'pys_mcp_custom_event_params_custom_type', sprintf( 'The current `%s` event_type (`%s`) takes no standard params — %s.', $slug, $eventType, $alt ), array( 'status' => 409 ) );
			}
			$alt = $has_custom_params
				? 'use custom_params'
				: sprintf( '`%s` has no custom params either — choose an event_type that has standard params', $slug );
			return new \WP_Error( 'pys_mcp_custom_event_event_no_params', sprintf( 'Event type `%s` for `%s` has no standard params (%s).', $eventType, $slug, $alt ), array( 'status' => 409 ) );
		}

		$current = ( isset( $merged[ $def[ 'params' ] ] ) && is_array( $merged[ $def[ 'params' ] ] ) ) ? $merged[ $def[ 'params' ] ] : array();
		$applied = array();
		foreach ( $val as $name => $pv ) {
			$name = (string) $name;
			if ( !in_array( $name, $allowed, true ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_param_name', sprintf( 'Param `%s` is not valid for `%s` event_type `%s`. Valid: %s.', $name, $slug, $eventType, implode( ', ', $allowed ) ), array( 'status' => 409 ) );
			}

			$cleared = ( null === $pv || '' === $pv || ( is_array( $pv ) && '' === (string) ( $pv[ 'value' ] ?? '' ) ) );
			if ( $cleared ) {
				unset( $current[ $name ] );
				$applied[ $name ] = null;
				continue;
			}
			$norm = self::normalizeParamValue( $pv );
			if ( null === $norm ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_param_value', sprintf( 'Invalid value for param `%s` (give a string, or an object {value, selector?, dynamic?, input_type?}).', $name ), array( 'status' => 400 ) );
			}
			$current[ $name ] = $norm;
			$applied[ $name ] = $norm;
		}

		$merged[ $def[ 'params' ] ]   = $current;
		$pending[ $slug ][ 'params' ] = $applied;
		self::autoEnableParamsFlag( $merged, $pending, $slug, $def );

		return null;
	}

	/**
	 * Replace the platform's `<slug>_custom_params` with the given list of
	 * {name, value, selector?, dynamic?} entries. The params toggle is auto-enabled.
	 *
	 * @param array  $merged  Merged args (mutated).
	 * @param array  $pending Per-platform pending (mutated).
	 * @param string $slug    Platform slug.
	 * @param array  $def     Platform map row.
	 * @param mixed  $val     The `custom_params` value.
	 * @return \WP_Error|null
	 */
	private static function applyPlatformCustomParams( array &$merged, array &$pending, string $slug, array $def, $val ) {
		if ( null === $def[ 'custom_params' ] ) {
			return new \WP_Error( 'pys_mcp_custom_event_no_custom_params', sprintf( '`%s` has no custom params.', $slug ), array( 'status' => 400 ) );
		}
		if ( !is_array( $val ) ) {
			return new \WP_Error( 'pys_mcp_custom_event_bad_custom_params', sprintf( '`%s.custom_params` must be an array of {name, value} objects.', $slug ), array( 'status' => 400 ) );
		}

		$clean = array();
		foreach ( $val as $cp ) {
			if ( !is_array( $cp ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_custom_params', 'Each custom param must be an object with `name` and `value`.', array( 'status' => 400 ) );
			}
			$name  = isset( $cp[ 'name' ] ) ? sanitize_text_field( (string) $cp[ 'name' ] ) : '';
			$value = isset( $cp[ 'value' ] ) ? sanitize_text_field( (string) $cp[ 'value' ] ) : '';
			if ( '' === $name || '' === $value ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_custom_params', 'Each custom param needs a non-empty `name` and `value`.', array( 'status' => 400 ) );
			}
			$entry = array( 'name' => $name, 'value' => $value );
			if ( isset( $cp[ 'selector' ] ) && '' !== $cp[ 'selector' ] ) {
				$entry[ 'selector' ] = sanitize_text_field( (string) $cp[ 'selector' ] );
			}
			if ( array_key_exists( 'dynamic', $cp ) ) {
				$entry[ 'dynamic' ] = (bool) $cp[ 'dynamic' ];
			}
			$clean[] = $entry;
		}

		$merged[ $def[ 'custom_params' ] ]   = $clean;
		$pending[ $slug ][ 'custom_params' ] = $clean;
		self::autoEnableParamsFlag( $merged, $pending, $slug, $def );

		return null;
	}

	/**
	 * Normalise one standard-param value: a scalar (stored as-is) or an object
	 * {value, selector?, dynamic?, input_type?}. Returns null when invalid.
	 *
	 * @param mixed $pv Incoming value.
	 * @return array<string, mixed>|string|null
	 */
	private static function normalizeParamValue( $pv ) {
		if ( is_array( $pv ) ) {
			if ( !isset( $pv[ 'value' ] ) || !is_scalar( $pv[ 'value' ] ) ) {
				return null;
			}
			$out = array( 'value' => sanitize_text_field( (string) $pv[ 'value' ] ) );
			if ( isset( $pv[ 'selector' ] ) && '' !== $pv[ 'selector' ] ) {
				$out[ 'selector' ] = sanitize_text_field( (string) $pv[ 'selector' ] );
			}
			if ( array_key_exists( 'dynamic', $pv ) ) {
				$out[ 'dynamic' ] = (bool) $pv[ 'dynamic' ];
			}
			if ( isset( $pv[ 'input_type' ] ) ) {
				$out[ 'input_type' ] = sanitize_text_field( (string) $pv[ 'input_type' ] );
			}

			return $out;
		}
		if ( is_scalar( $pv ) ) {
			return sanitize_text_field( (string) $pv );
		}

		return null;
	}

	/**
	 * Turn the platform's params toggle on (if it has one and it is off) when
	 * params / custom_params are written — mirrors the admin enabling the section.
	 *
	 * @param array  $merged  Merged args (mutated).
	 * @param array  $pending Per-platform pending (mutated).
	 * @param string $slug    Platform slug.
	 * @param array  $def     Platform map row.
	 * @return void
	 */
	private static function autoEnableParamsFlag( array &$merged, array &$pending, string $slug, array $def ): void {
		$key = $def[ 'params_enabled' ];
		if ( null !== $key && !self::truthy( $merged[ $key ] ?? false ) ) {
			self::setPlatformField( $merged, $pending, $slug, 'params_enabled', $key, true );
		}
	}

	/**
	 * Validate a pixel_ids array (each entry `all` or a configured pixel id).
	 *
	 * @param string $slug Platform slug.
	 * @param mixed  $val  Incoming value.
	 * @return \WP_Error|null
	 */
	private static function validatePixelList( string $slug, $val ) {
		if ( !is_array( $val ) || empty( $val ) ) {
			return new \WP_Error( 'pys_mcp_custom_event_bad_pixels', sprintf( '`%s` pixel_ids must be a non-empty array (e.g. ["all"]).', $slug ), array( 'status' => 400 ) );
		}
		$valid = CustomEventPlatformMap::validPixelIds( $slug );
		foreach ( $val as $pid ) {
			if ( !is_string( $pid ) || ( 'all' !== $pid && !in_array( $pid, $valid, true ) ) ) {
				return self::badPixel( $slug, $pid );
			}
		}

		return null;
	}

	/**
	 * Bad-pixel error with the valid list.
	 *
	 * @param string $slug Platform slug.
	 * @param mixed  $pid  Offending value.
	 * @return \WP_Error
	 */
	private static function badPixel( string $slug, $pid ): \WP_Error {
		$valid = CustomEventPlatformMap::validPixelIds( $slug );

		return new \WP_Error(
			'pys_mcp_custom_event_bad_pixel',
			sprintf( 'Pixel `%s` is not configured for `%s`. Use `all` or one of: %s.', is_string( $pid ) ? $pid : gettype( $pid ), $slug, empty( $valid ) ? '(none configured)' : implode( ', ', $valid ) ),
			array( 'status' => 409 )
		);
	}

	/**
	 * Generic invalid-field error.
	 *
	 * @param string $slug  Platform slug.
	 * @param string $field Field name.
	 * @return \WP_Error
	 */
	private static function badField( string $slug, string $field ): \WP_Error {
		return new \WP_Error( 'pys_mcp_custom_event_bad_value', sprintf( 'Invalid value for `%s.%s`.', $slug, $field ), array( 'status' => 400 ) );
	}

	/**
	 * Apply point-wise trigger ops onto $merged['triggers']. Op `index` values
	 * reference the pre-call list; updates in place, removes, adds append, then
	 * reindex. Returns WP_Error on first failure.
	 *
	 * @param array $merged  Merged args (mutated).
	 * @param array $ops      `triggers` arg.
	 * @param array $pending  Per-op pending summary (mutated).
	 * @return \WP_Error|null
	 */
	private static function applyTriggerOps( array &$merged, array $ops, array &$pending ) {
		$list  = ( isset( $merged[ 'triggers' ] ) && is_array( $merged[ 'triggers' ] ) ) ? array_values( $merged[ 'triggers' ] ) : array();
		$count = count( $list );

		$updates = array();
		$removes = array();
		$adds    = array();

		foreach ( $ops as $op ) {
			if ( !is_array( $op ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_trigger_op', 'Each trigger op must be an object.', array( 'status' => 400 ) );
			}
			$opName = isset( $op[ 'op' ] ) ? (string) $op[ 'op' ] : '';
			if ( !in_array( $opName, array( 'add', 'update', 'remove' ), true ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_trigger_op', 'Trigger op `op` must be add / update / remove.', array( 'status' => 400 ) );
			}

			if ( 'add' === $opName ) {
				$type = isset( $op[ 'type' ] ) ? (string) $op[ 'type' ] : '';
				if ( !CustomEventTriggerMap::has( $type ) && !CustomEventTriggerMap::isFormPlugin( $type ) ) {
					return new \WP_Error( 'pys_mcp_custom_event_bad_trigger_type', sprintf( 'Unknown trigger type `%s`.', $type ), array( 'status' => 409 ) );
				}
				if ( !CustomEventTriggerMap::isEditable( $type ) ) {
					return self::triggerTypeDeferred( $type );
				}
				$built = self::buildTriggerArgs( $type, $op, null );
				if ( $built instanceof \WP_Error ) {
					return $built;
				}
				$pn = self::applyGadsPhoneNumbers( $merged, $type, $op );
				if ( $pn instanceof \WP_Error ) {
					return $pn;
				}
				$adds[]    = $built;
				$pending[] = array( 'op' => 'add', 'type' => $type );
				continue;
			}

			// update / remove need a valid index into the current list.
			if ( !isset( $op[ 'index' ] ) || !is_int( $op[ 'index' ] ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_trigger_index', sprintf( 'Trigger op `%s` requires an integer `index`.', $opName ), array( 'status' => 400 ) );
			}
			$idx = $op[ 'index' ];
			if ( $idx < 0 || $idx >= $count ) {
				return new \WP_Error( 'pys_mcp_custom_event_trigger_index', sprintf( 'Trigger index %d out of range (event has %d trigger(s): valid 0..%d).', $idx, $count, max( 0, $count - 1 ) ), array( 'status' => 409 ) );
			}
			$type = isset( $list[ $idx ][ 'trigger_type' ] ) ? (string) $list[ $idx ][ 'trigger_type' ] : '';

			if ( 'remove' === $opName ) {
				$removes[ $idx ] = true;
				$pending[]       = array( 'op' => 'remove', 'index' => $idx, 'type' => $type );
				continue;
			}

			// update — existing trigger must be an editable type.
			if ( !CustomEventTriggerMap::isEditable( $type ) ) {
				return self::triggerTypeDeferred( $type, $idx );
			}

			$targetType = isset( $op[ 'type' ] ) ? (string) $op[ 'type' ] : $type;
			$pendingRow = array( 'op' => 'update', 'index' => $idx, 'type' => $type );

			if ( $targetType !== $type ) {
				if ( !CustomEventTriggerMap::has( $targetType ) && !CustomEventTriggerMap::isFormPlugin( $targetType ) ) {
					return new \WP_Error( 'pys_mcp_custom_event_bad_trigger_type', sprintf( 'Unknown trigger type `%s`.', $targetType ), array( 'status' => 409 ) );
				}
				if ( !CustomEventTriggerMap::isEditable( $targetType ) ) {
					return self::triggerTypeDeferred( $targetType, $idx );
				}
				if ( !array_key_exists( 'rules', $op ) && self::sameRuleShape( $type, $targetType ) ) {
					$carried = self::extractRules( $list[ $idx ], $type );
					if ( !empty( $carried ) ) {
						$op[ 'rules' ] = $carried; // re-validated by normalizeRules for the new type
					}
				}
				$built = self::buildTriggerArgs( $targetType, $op, null ); // fresh: drop the old type's keys
				$pendingRow[ 'from_type' ] = $type;
				$pendingRow[ 'type' ]      = $targetType;
				$type                       = $targetType;
			} else {
				$built = self::buildTriggerArgs( $type, $op, $list[ $idx ] ); // in-place patch
			}

			if ( $built instanceof \WP_Error ) {
				return $built;
			}
			$pn = self::applyGadsPhoneNumbers( $merged, $type, $op );
			if ( $pn instanceof \WP_Error ) {
				return $pn;
			}
			$updates[ $idx ] = $built;
			$pending[]       = $pendingRow;
		}

		foreach ( $updates as $idx => $d ) {
			$list[ $idx ] = $d;
		}
		foreach ( array_keys( $removes ) as $idx ) {
			unset( $list[ $idx ] );
		}
		foreach ( $adds as $d ) {
			$list[] = $d;
		}
		$merged[ 'triggers' ] = array_values( $list );

		return null;
	}

	/**
	 * Build/patch one trigger's admin-arg dict from a user op via the trigger map.
	 *
	 * @param string     $type     Trigger type.
	 * @param array      $op        User op.
	 * @param array|null $existing  Existing dict (update) or null (add).
	 * @return array<string, mixed>|\WP_Error
	 */
	private static function buildTriggerArgs( string $type, array $op, ?array $existing ) {
		if ( isset( $op[ 'params' ] ) && is_array( $op[ 'params' ] ) ) {
			$op = array_merge( $op[ 'params' ], $op );
			unset( $op[ 'params' ] );
		}

		if ( CustomEventTriggerMap::isFormPlugin( $type ) ) {
			return self::buildFormPluginArgs( $type, $op, $existing );
		}

		$def = CustomEventTriggerMap::get( $type );
		$out = null !== $existing ? $existing : array();
		$out[ 'trigger_type' ] = $type;

		if ( array_key_exists( 'rules', $op ) ) {
			if ( empty( $def[ 'rules_key' ] ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_trigger_no_rules', sprintf( 'Trigger type `%s` takes no rules.', $type ), array( 'status' => 400 ) );
			}
			$norm = self::normalizeRules( $op[ 'rules' ], $type );
			if ( $norm instanceof \WP_Error ) {
				return $norm;
			}
			$out[ $def[ 'rules_key' ] ] = $norm;
		}

		foreach ( self::TRIGGER_OP_PARAMS as $p => $ptype ) {
			if ( !array_key_exists( $p, $op ) ) {
				continue;
			}
			if ( !in_array( $p, $def[ 'params' ], true ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_trigger_bad_param', sprintf( 'Param `%s` is not valid for trigger type `%s`.', $p, $type ), array( 'status' => 400 ) );
			}
			$cv = self::coerceTriggerParam( $ptype, $p, $op[ $p ] );
			if ( null === $cv ) {
				return new \WP_Error( 'pys_mcp_custom_event_trigger_bad_param', sprintf( 'Invalid value for trigger param `%s`.', $p ), array( 'status' => 400 ) );
			}
			$out[ $p ] = $cv;
		}

		// Rule-based types need at least one rule when ADDED.
		if ( null === $existing && in_array( $type, self::RULE_BASED_TYPES, true ) && empty( $out[ $def[ 'rules_key' ] ] ) ) {
			return new \WP_Error( 'pys_mcp_custom_event_trigger_needs_rule', sprintf( 'Trigger type `%s` needs at least one rule to add (pass `rules`).', $type ), array( 'status' => 400 ) );
		}

		return $out;
	}

	/**
	 * Build/patch a form-plugin trigger (CF7, WPForms, …). Its args nest the
	 * form selection under the plugin slug:
	 *   { trigger_type: <slug>, <slug>: { forms: [ids], form_submit_mode, disabled_form_action } }
	 *
	 * @param string     $type     Form-plugin slug.
	 * @param array      $op        User op (params already flattened).
	 * @param array|null $existing  Existing dict (update) or null (add).
	 * @return array<string, mixed>|\WP_Error
	 */
	private static function buildFormPluginArgs( string $type, array $op, ?array $existing ) {
		$out = null !== $existing ? $existing : array();
		$out[ 'trigger_type' ] = $type;
		$block = ( isset( $existing[ $type ] ) && is_array( $existing[ $type ] ) ) ? $existing[ $type ] : array();

		$available = CustomEventTriggerMap::formPluginForms( $type ); // id => title

		if ( array_key_exists( 'forms', $op ) ) {
			$wanted = is_array( $op[ 'forms' ] ) ? $op[ 'forms' ] : array( $op[ 'forms' ] );
			$clean  = array();
			foreach ( $wanted as $f ) {
				$fid = is_scalar( $f ) ? (string) $f : '';
				if ( '' === $fid ) {
					continue;
				}
				if ( !empty( $available ) && !array_key_exists( $fid, $available ) ) {
					$valid = array();
					foreach ( $available as $id => $title ) {
						$valid[] = $id . ' (' . $title . ')';
					}

					return new \WP_Error( 'pys_mcp_custom_event_bad_form', sprintf( 'Form id `%s` is not a %s form. Valid forms: %s.', $fid, CustomEventTriggerMap::formPluginName( $type ), implode( ', ', $valid ) ), array( 'status' => 409 ) );
				}
				$clean[] = $fid;
			}
			$block[ 'forms' ] = array_values( array_unique( $clean ) );
		}

		if ( array_key_exists( 'form_submit_mode', $op ) ) {
			$mode = (string) $op[ 'form_submit_mode' ];
			if ( !in_array( $mode, CustomEventTriggerMap::FORM_SUBMIT_MODES, true ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_form_submit_mode', sprintf( '`form_submit_mode` must be one of: %s.', implode( ', ', CustomEventTriggerMap::FORM_SUBMIT_MODES ) ), array( 'status' => 409 ) );
			}
			$block[ 'form_submit_mode' ] = $mode;
		}

		if ( array_key_exists( 'disabled_form_action', $op ) ) {
			$block[ 'disabled_form_action' ] = (bool) $op[ 'disabled_form_action' ];
		}

		// On ADD: at least one form is required, and default the submit mode.
		if ( null === $existing ) {
			if ( empty( $block[ 'forms' ] ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_form_needs_form', sprintf( '`%s` trigger needs at least one form id in `forms` (see get_custom_event available_trigger_types).', $type ), array( 'status' => 400 ) );
			}
			if ( !isset( $block[ 'form_submit_mode' ] ) ) {
				$block[ 'form_submit_mode' ] = 'both';
			}
		}

		$out[ $type ] = $block;

		return $out;
	}

	/**
	 * Normalise a user `rules` array into the admin {rule,value} shape.
	 *
	 * @param mixed  $rules Incoming rules.
	 * @param string $type  Trigger type.
	 * @return array<int, array{rule:?string, value:string}>|\WP_Error
	 */
	private static function normalizeRules( $rules, string $type ) {
		if ( !is_array( $rules ) || empty( $rules ) ) {
			return new \WP_Error( 'pys_mcp_custom_event_bad_rules', sprintf( '`rules` for `%s` must be a non-empty array.', $type ), array( 'status' => 400 ) );
		}
		$allowed  = CustomEventTriggerMap::ruleValues( $type );
		$needRule = !empty( $allowed ); // rule+value type; else value-only (rule=null)
		$validMsg = $needRule ? sprintf( ' Valid `rule` values for `%s`: %s ("URL parameters contains" = `param_contains`).', $type, implode( ', ', $allowed ) ) : '';
		$out      = array();

		foreach ( $rules as $r ) {
			// Bare scalar = value-only shorthand; not allowed for rule+value types.
			if ( is_string( $r ) || is_int( $r ) ) {
				if ( $needRule ) {
					return new \WP_Error( 'pys_mcp_custom_event_bad_rules', sprintf( '`%s` rule items need `{rule, value}`.%s', $type, $validMsg ), array( 'status' => 400 ) );
				}
				$out[] = array( 'rule' => null, 'value' => sanitize_text_field( (string) $r ) );
				continue;
			}
			if ( !is_array( $r ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_rules', 'Each rule item must be a value or a {rule, value} object.', array( 'status' => 400 ) );
			}

			if ( !$needRule ) {
				// Value-only type: ignore any provided rule, keep it null.
				if ( !isset( $r[ 'value' ] ) || '' === (string) $r[ 'value' ] ) {
					return new \WP_Error( 'pys_mcp_custom_event_bad_rules', 'Each rule item needs a non-empty `value`.', array( 'status' => 400 ) );
				}
				$out[] = array( 'rule' => null, 'value' => sanitize_text_field( (string) $r[ 'value' ] ) );
				continue;
			}

			// rule+value type: rule is required AND must be one of the allowed values.
			$rule = isset( $r[ 'rule' ] ) ? sanitize_text_field( (string) $r[ 'rule' ] ) : '';
			if ( '' === $rule ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_rules', sprintf( '`%s` rule items need a `rule`.%s', $type, $validMsg ), array( 'status' => 400 ) );
			}
			if ( !in_array( $rule, $allowed, true ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_rule_value', sprintf( 'Invalid rule `%s` for `%s`.%s', $rule, $type, $validMsg ), array( 'status' => 409 ) );
			}
			if ( 'any' === $rule ) {
				$out[] = array( 'rule' => 'any', 'value' => '' );
				continue;
			}
			if ( !isset( $r[ 'value' ] ) || '' === (string) $r[ 'value' ] ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_rules', 'Each rule item needs a non-empty `value`.', array( 'status' => 400 ) );
			}
			$out[] = array( 'rule' => $rule, 'value' => sanitize_text_field( (string) $r[ 'value' ] ) );
		}

		return $out;
	}

	/**
	 * Whether two trigger types share the same rule shape, so rules can carry
	 * over on a retype (both value-only, or identical allowed-rule sets).
	 *
	 * @param string $a Type A.
	 * @param string $b Type B.
	 * @return bool
	 */
	private static function sameRuleShape( string $a, string $b ): bool {
		$ra = CustomEventTriggerMap::ruleValues( $a );
		$rb = CustomEventTriggerMap::ruleValues( $b );
		sort( $ra );
		sort( $rb );

		return $ra === $rb;
	}

	/**
	 * Pull the existing rules array (admin {rule,value} form) out of a built
	 * trigger dict, for carry-over on a retype.
	 *
	 * @param array  $dict Existing trigger arg dict.
	 * @param string $type Its trigger type.
	 * @return array<int, array>
	 */
	private static function extractRules( array $dict, string $type ): array {
		$def = CustomEventTriggerMap::get( $type );
		$key = $def[ 'rules_key' ] ?? null;
		if ( null === $key || empty( $dict[ $key ] ) || !is_array( $dict[ $key ] ) ) {
			return array();
		}

		return $dict[ $key ];
	}

	/**
	 * Coerce a trigger param value by type.
	 *
	 * @param string $ptype int|string|bool.
	 * @param string $name  Param name (for enum checks).
	 * @param mixed  $val   Incoming value.
	 * @return mixed|null
	 */
	private static function coerceTriggerParam( string $ptype, string $name, $val ) {
		switch ( $ptype ) {
			case 'int':
				return ( is_int( $val ) || ( is_string( $val ) && ctype_digit( $val ) ) ) ? max( 0, (int) $val ) : null;
			case 'bool':
				return self::coerce( 'bool', $val );
			case 'string':
				if ( !is_string( $val ) ) {
					return null;
				}
				if ( 'conditional_number_visit' === $name && !in_array( $val, array( 'equal', 'equal_or_larger', 'equal_or_less', 'larger', 'less' ), true ) ) {
					return null;
				}

				return sanitize_text_field( $val );
		}

		return null;
	}

	/**
	 * Deferred-trigger-type error.
	 *
	 * @param string   $type Trigger type.
	 * @param int|null $idx  Index (for update context).
	 * @return \WP_Error
	 */
	private static function triggerTypeDeferred( string $type, ?int $idx = null ): \WP_Error {
		$where = null === $idx ? sprintf( 'add a `%s` trigger', $type ) : sprintf( 'edit trigger #%d (type `%s`)', $idx, $type );

		return new \WP_Error(
			'pys_mcp_custom_event_trigger_deferred',
			sprintf( 'Cannot %s via MCP — `video_view`, `video_speed`, `form_field` and `elementor_form` triggers are scan-driven (you pick a specific video / form / field from a live page scan in PixelYourSite → Events) and must be configured in the admin. They are preserved on round-trip. Editable via MCP: %s, plus form-plugin triggers like CF7 / WPForms (see get_custom_event `available_trigger_types`).', $where, implode( ', ', self::BASIC_TRIGGER_TYPES ) ),
			array( 'status' => 409 )
		);
	}

	/**
	 * Google Ads phone-conversion numbers are stored event-level (in
	 * `ga_ads_phone_numbers`, consumed by updateUnifyGA when a gads_phone trigger
	 * exists), not inside the trigger. Validate + write them when a
	 * gads_phone_conversion op carries `phone_numbers`.
	 *
	 * @param array  $merged Merged args (mutated).
	 * @param string $type   Trigger type of this op.
	 * @param array  $op     The op.
	 * @return \WP_Error|null
	 */
	private static function applyGadsPhoneNumbers( array &$merged, string $type, array $op ) {
		if ( 'gads_phone_conversion' !== $type ) {
			return null;
		}

		$params = ( isset( $op[ 'params' ] ) && is_array( $op[ 'params' ] ) ) ? $op[ 'params' ] : array();
		$raw    = null;
		foreach ( array( 'phone_numbers', 'gads_phone_numbers' ) as $k ) {
			if ( array_key_exists( $k, $op ) ) {
				$raw = $op[ $k ];
				break;
			}
			if ( array_key_exists( $k, $params ) ) {
				$raw = $params[ $k ];
				break;
			}
		}
		if ( null === $raw ) {
			return null;
		}
		if ( !is_array( $raw ) ) {
			return new \WP_Error( 'pys_mcp_custom_event_bad_phone_numbers', '`phone_numbers` must be an array of { number, label } objects.', array( 'status' => 400 ) );
		}
		$out = array();
		foreach ( $raw as $pn ) {
			$number = is_array( $pn ) && isset( $pn[ 'number' ] ) ? sanitize_text_field( (string) $pn[ 'number' ] ) : '';
			$label  = is_array( $pn ) && isset( $pn[ 'label' ] ) ? sanitize_text_field( (string) $pn[ 'label' ] ) : '';
			if ( '' === $number || '' === $label ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_phone_numbers', 'Each phone number needs a non-empty `number` and `label`.', array( 'status' => 400 ) );
			}
			$out[] = array( 'number' => $number, 'label' => $label );
		}
		$merged[ 'ga_ads_phone_numbers' ]    = $out;
		$merged[ 'google_ads_phone_numbers' ] = $out; // keep the data-key mirror consistent for the serializer

		return null;
	}

	/**
	 * Apply point-wise condition ops onto $merged['conditions'] (serializer-built,
	 * ordered so index == condition_index). Same algorithm as triggers.
	 *
	 * @param array $merged   Merged args (mutated).
	 * @param array $ops       `conditions` arg.
	 * @param array $pending   Per-op pending (mutated).
	 * @return \WP_Error|null
	 */
	private static function applyConditionOps( array &$merged, array $ops, array &$pending ) {
		$list  = ( isset( $merged[ 'conditions' ] ) && is_array( $merged[ 'conditions' ] ) ) ? array_values( $merged[ 'conditions' ] ) : array();
		$count = count( $list );

		$updates = array();
		$removes = array();
		$adds    = array();

		foreach ( $ops as $op ) {
			if ( !is_array( $op ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_condition_op', 'Each condition op must be an object.', array( 'status' => 400 ) );
			}
			$opName = isset( $op[ 'op' ] ) ? (string) $op[ 'op' ] : '';
			if ( !in_array( $opName, array( 'add', 'update', 'remove' ), true ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_condition_op', 'Condition op `op` must be add / update / remove.', array( 'status' => 400 ) );
			}

			if ( 'add' === $opName ) {
				$type = isset( $op[ 'type' ] ) ? (string) $op[ 'type' ] : '';
				if ( !CustomEventConditionMap::has( $type ) ) {
					return new \WP_Error( 'pys_mcp_custom_event_bad_condition_type', sprintf( 'Unknown condition type `%s`. Valid: %s.', $type, implode( ', ', CustomEventConditionMap::types() ) ), array( 'status' => 409 ) );
				}
				$built = self::buildConditionArgs( $type, $op, null );
				if ( $built instanceof \WP_Error ) {
					return $built;
				}
				$adds[]    = $built;
				$pending[] = array( 'op' => 'add', 'type' => $type );
				continue;
			}

			if ( !isset( $op[ 'index' ] ) || !is_int( $op[ 'index' ] ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_condition_index', sprintf( 'Condition op `%s` requires an integer `index`.', $opName ), array( 'status' => 400 ) );
			}
			$idx = $op[ 'index' ];
			if ( $idx < 0 || $idx >= $count ) {
				return new \WP_Error( 'pys_mcp_custom_event_condition_index', sprintf( 'Condition index %d out of range (event has %d condition(s): valid 0..%d).', $idx, $count, max( 0, $count - 1 ) ), array( 'status' => 409 ) );
			}
			$type = isset( $list[ $idx ][ 'condition_type' ] ) ? (string) $list[ $idx ][ 'condition_type' ] : '';

			if ( 'remove' === $opName ) {
				$removes[ $idx ] = true;
				$pending[]       = array( 'op' => 'remove', 'index' => $idx, 'type' => $type );
				continue;
			}

			// update (with optional retype)
			$targetType = isset( $op[ 'type' ] ) ? (string) $op[ 'type' ] : $type;
			$pendingRow = array( 'op' => 'update', 'index' => $idx, 'type' => $type );
			if ( $targetType !== $type ) {
				if ( !CustomEventConditionMap::has( $targetType ) ) {
					return new \WP_Error( 'pys_mcp_custom_event_bad_condition_type', sprintf( 'Unknown condition type `%s`.', $targetType ), array( 'status' => 409 ) );
				}
				// Carry rule/value when both are rule_value and op omits them.
				if ( CustomEventConditionMap::SHAPE_RULE_VALUE === CustomEventConditionMap::shape( $type )
				     && CustomEventConditionMap::SHAPE_RULE_VALUE === CustomEventConditionMap::shape( $targetType ) ) {
					$inner = $list[ $idx ][ $type ] ?? array();
					if ( !array_key_exists( 'rule', $op ) && isset( $inner[ 'condition_rule' ] ) ) {
						$op[ 'rule' ] = $inner[ 'condition_rule' ];
					}
					if ( !array_key_exists( 'value', $op ) && isset( $inner[ 'condition_value' ] ) ) {
						$op[ 'value' ] = $inner[ 'condition_value' ];
					}
				}
				$built = self::buildConditionArgs( $targetType, $op, null );
				$pendingRow[ 'from_type' ] = $type;
				$pendingRow[ 'type' ]      = $targetType;
			} else {
				$built = self::buildConditionArgs( $type, $op, $list[ $idx ] );
			}
			if ( $built instanceof \WP_Error ) {
				return $built;
			}
			$updates[ $idx ] = $built;
			$pending[]       = $pendingRow;
		}

		foreach ( $updates as $idx => $d ) {
			$list[ $idx ] = $d;
		}
		foreach ( array_keys( $removes ) as $idx ) {
			unset( $list[ $idx ] );
		}
		foreach ( $adds as $d ) {
			$list[] = $d;
		}
		$merged[ 'conditions' ] = array_values( $list );

		return null;
	}

	/**
	 * Build/patch one condition's admin-arg dict.
	 *
	 * @param string     $type     Condition type.
	 * @param array      $op        User op.
	 * @param array|null $existing  Existing dict (update in-place) or null.
	 * @return array<string, mixed>|\WP_Error
	 */
	private static function buildConditionArgs( string $type, array $op, ?array $existing ) {
		$shape  = CustomEventConditionMap::shape( $type );
		$isAdd  = null === $existing;
		$out    = array( 'condition_type' => $type );

		if ( CustomEventConditionMap::SHAPE_DEVICE === $shape ) {
			$device = array_key_exists( 'device', $op ) ? (string) $op[ 'device' ] : ( $existing[ 'device' ] ?? '' );
			if ( !in_array( $device, CustomEventConditionMap::DEVICE_VALUES, true ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_device', sprintf( '`device` must be one of: %s.', implode( ', ', CustomEventConditionMap::DEVICE_VALUES ) ), array( 'status' => 409 ) );
			}
			$out[ 'device' ] = $device;

			return $out;
		}

		if ( CustomEventConditionMap::SHAPE_USER_ROLE === $shape ) {
			$roles = array_key_exists( 'user_role', $op ) ? $op[ 'user_role' ] : ( $existing[ 'user_role' ] ?? array() );
			if ( !is_array( $roles ) || empty( $roles ) ) {
				return new \WP_Error( 'pys_mcp_custom_event_bad_user_role', '`user_role` must be a non-empty array of role slugs (e.g. ["guest","administrator"]).', array( 'status' => 400 ) );
			}
			$valid = self::validRoles();
			$clean = array();
			foreach ( $roles as $role ) {
				$role = sanitize_text_field( (string) $role );
				if ( !in_array( $role, $valid, true ) ) {
					return new \WP_Error( 'pys_mcp_custom_event_bad_user_role', sprintf( 'Unknown role `%s`. Valid: %s.', $role, implode( ', ', $valid ) ), array( 'status' => 409 ) );
				}
				$clean[] = $role;
			}
			$out[ 'user_role' ] = array_values( array_unique( $clean ) );

			return $out;
		}

		// rule_value (url_filters / url_parameters / landing_page / source)
		$allowed = CustomEventConditionMap::ruleValues( $type );
		$inner   = ( null !== $existing && isset( $existing[ $type ] ) && is_array( $existing[ $type ] ) ) ? $existing[ $type ] : array();
		$rule    = array_key_exists( 'rule', $op ) ? sanitize_text_field( (string) $op[ 'rule' ] ) : ( $inner[ 'condition_rule' ] ?? '' );
		$value   = array_key_exists( 'value', $op ) ? sanitize_text_field( (string) $op[ 'value' ] ) : ( $inner[ 'condition_value' ] ?? '' );

		if ( '' === $rule || !in_array( $rule, $allowed, true ) ) {
			return new \WP_Error( 'pys_mcp_custom_event_bad_condition_rule', sprintf( 'Invalid/missing `rule` for `%s`. Valid: %s.', $type, implode( ', ', $allowed ) ), array( 'status' => 409 ) );
		}
		if ( '' === $value ) {
			return new \WP_Error( 'pys_mcp_custom_event_condition_no_value', sprintf( '`%s` condition needs a non-empty `value`.', $type ), array( 'status' => 400 ) );
		}
		$out[ $type ] = array( 'condition_rule' => $rule, 'condition_value' => $value );

		return $out;
	}

	/**
	 * Valid user-role slugs (guest + the site's roles).
	 *
	 * @return array<int, string>
	 */
	private static function validRoles(): array {
		$roles = array( 'guest' );
		if ( function_exists( '\\PixelYourSite\\getAvailableUserRoles' ) ) {
			$roles = array_merge( $roles, array_keys( (array) \PixelYourSite\getAvailableUserRoles() ) );
		} elseif ( function_exists( 'wp_roles' ) ) {
			$roles = array_merge( $roles, array_keys( wp_roles()->get_names() ) );
		}

		return array_values( array_unique( $roles ) );
	}

	/**
	 * Enforce the Google Ads Phone Conversion lock (mirrors the admin JS): the
	 * phone trigger is exclusive + Ads-only, so it becomes the sole trigger, every
	 * other platform is disabled and Google pixels are restricted to Ads (`AW-…`).
	 * Adding a non-phone trigger instead removes the phone one. Records the
	 * side-effects in $pending; idempotent when no phone trigger is present.
	 *
	 * @param array $merged     Merged args (mutated).
	 * @param array $pending    Pending-changes accumulator (mutated).
	 * @param bool  $phoneAdded This call added/retyped TO a phone trigger.
	 * @param bool  $otherAdded This call added/retyped to a NON-phone trigger.
	 * @return array<int, string> Warning notes.
	 */
	private static function enforceGadsPhoneLock( array &$merged, array &$pending, bool $phoneAdded = false, bool $otherAdded = false ): array {
		$notes    = array();
		$triggers = ( isset( $merged[ 'triggers' ] ) && is_array( $merged[ 'triggers' ] ) ) ? array_values( $merged[ 'triggers' ] ) : array();

		// Locate phone triggers + whether non-phone triggers also exist.
		$phoneIdxs = array();
		$hasOther  = false;
		foreach ( $triggers as $i => $t ) {
			if ( isset( $t[ 'trigger_type' ] ) && 'gads_phone_conversion' === $t[ 'trigger_type' ] ) {
				$phoneIdxs[] = $i;
			} else {
				$hasOther = true;
			}
		}
		if ( empty( $phoneIdxs ) ) {
			return $notes; // no phone trigger → no lock
		}

		if ( $otherAdded && !$phoneAdded && $hasOther ) {
			$kept = array();
			foreach ( $triggers as $i => $t ) {
				if ( !in_array( $i, $phoneIdxs, true ) ) {
					$kept[] = $t;
				}
			}
			$merged[ 'triggers' ]                = array_values( $kept );
			$pending[ 'gads_phone_lock' ]        = array( 'removed_phone_trigger' => true );
			$notes[]                             = 'Removed the Google Ads Phone Conversion trigger because you added a different trigger — that trigger is exclusive and cannot coexist with others. Platforms left disabled by it are unchanged; re-enable any you need.';

			return $notes;
		}

		$phoneIdx = end( $phoneIdxs );

		$lock = array();

		// 1) The phone trigger is exclusive — keep only it, drop the rest.
		$removed = array();
		foreach ( $triggers as $i => $t ) {
			if ( $i !== $phoneIdx ) {
				$removed[] = (string) ( $t[ 'trigger_type' ] ?? 'trigger' );
			}
		}
		$merged[ 'triggers' ] = array( $triggers[ $phoneIdx ] );
		if ( !empty( $removed ) ) {
			$lock[ 'removed_triggers' ] = $removed;
			$notes[]                    = sprintf( 'Google Ads Phone Conversion is an EXCLUSIVE trigger and must be the ONLY trigger on the event — %d other trigger(s) (%s) WILL BE REMOVED.', count( $removed ), implode( ', ', array_values( array_unique( $removed ) ) ) );
		}

		// 2) Works only for Google Ads — disable every other platform.
		$disabled = array();
		foreach ( array( 'facebook' => 'facebook_enabled', 'tiktok' => 'tiktok_enabled', 'pinterest' => 'pinterest_enabled', 'bing' => 'bing_enabled', 'reddit' => 'reddit_enabled', 'gtm' => 'gtm_enabled' ) as $slug => $key ) {
			if ( self::truthy( $merged[ $key ] ?? false ) ) {
				$merged[ $key ] = false;
				$disabled[]     = $slug;
			}
		}
		if ( !empty( $disabled ) ) {
			$lock[ 'disabled_platforms' ] = $disabled;
			$notes[]                      = sprintf( 'This trigger fires only for Google Ads — these platform(s) WILL BE DISABLED on the event: %s. Only Google Ads (`ga_ads`) remains.', implode( ', ', $disabled ) );
		}

		// 3) Restrict the Google pixel selection to Ads only (drop GA `G-…` ids).
		$pixels    = (array) ( $merged[ 'ga_ads_pixel_id' ] ?? array() );
		$adsOnly   = array();
		$droppedGa = array();
		foreach ( $pixels as $pid ) {
			$pid = (string) $pid;
			if ( '' === $pid ) {
				continue;
			}
			if ( 'all' === $pid || 0 === strpos( $pid, 'AW' ) ) {
				$adsOnly[] = $pid;
			} else {
				$droppedGa[] = $pid;
			}
		}
		$merged[ 'ga_ads_pixel_id' ] = array_values( array_unique( $adsOnly ) );
		if ( !empty( $droppedGa ) ) {
			$lock[ 'removed_non_ads_pixels' ] = $droppedGa;
			$notes[]                          = sprintf( 'Only Google Ads pixels apply to a phone-conversion trigger — non-Ads pixel(s) %s removed from the Google selection.', implode( ', ', $droppedGa ) );
		}

		// 4) Ads woo-data flags do not apply here (admin unchecks + disables them).
		foreach ( array( 'ga_ads_track_single_woo_data', 'ga_ads_track_cart_woo_data' ) as $k ) {
			if ( self::truthy( $merged[ $k ] ?? false ) ) {
				$merged[ $k ] = false;
			}
		}

		// 5) Delivery warnings.
		if ( !self::truthy( $merged[ 'ga_ads_enabled' ] ?? false ) ) {
			$notes[] = 'Google `ga_ads` is OFF — enable it with an `AW-…` conversion pixel or the phone-conversion trigger will not deliver.';
		} elseif ( empty( $adsOnly ) ) {
			$notes[] = 'No Google Ads (`AW-…`) pixel is selected — add one to `ga_ads.pixel_ids` or the phone-conversion trigger will not deliver.';
		}

		if ( !empty( $lock ) ) {
			$pending[ 'gads_phone_lock' ] = $lock;
		}

		return $notes;
	}

	/**
	 * Prune each ENABLED platform's standard params to only the keys valid for its
	 * current event_type. Several platforms' update() parsers copy back every key
	 * passed in args (GA/GTM/ga_ads, pinterest, bing → unbounded accumulation;
	 * facebook/tiktok keep stale values within their fixed key-list) — so on a
	 * read→merge→write that changes event_type the old type's params would pile up
	 * and show mixed in the admin. Idempotent when already clean; self-healing.
	 *
	 * @param array $merged  Merged args (mutated).
	 * @param array $pending Pending-changes accumulator (mutated).
	 * @return array<int, string> Notes for any dropped keys.
	 */
	private static function pruneStaleParams( array &$merged, array &$pending ): array {
		$notes = array();
		foreach ( CustomEventPlatformMap::slugs() as $slug ) {
			$def = CustomEventPlatformMap::get( $slug );
			if ( null === $def || null === $def[ 'params' ] ) {
				continue; // platform has no standard params (reddit / google_ads)
			}
			if ( !self::truthy( $merged[ $def[ 'enabled' ] ] ?? false ) ) {
				continue;
			}
			$pkey = $def[ 'params' ];
			if ( null === $pkey || !isset( $merged[ $pkey ] ) || !is_array( $merged[ $pkey ] ) || empty( $merged[ $pkey ] ) ) {
				continue;
			}
			$et    = (string) ( $merged[ $def[ 'event_type' ] ] ?? '' );
			$valid = CustomEventPlatformMap::eventParamNames( $slug, $et ); // [] for custom / param-less types
			$dropped = array();
			foreach ( array_keys( $merged[ $pkey ] ) as $k ) {
				if ( !in_array( (string) $k, $valid, true ) ) {
					unset( $merged[ $pkey ][ $k ] );
					$dropped[] = (string) $k;
				}
			}
			if ( !empty( $dropped ) ) {
				$pending[ $slug ][ 'params_pruned' ] = $dropped;
				$notes[] = sprintf( 'Dropped %s param(s) not used by `%s` event_type `%s`: %s (stale from a previous event type).', $slug, $slug, $et, implode( ', ', $dropped ) );
			}
		}

		return $notes;
	}

	/**
	 * Advisory notes (not requested changes) to relay to the user.
	 *
	 * @param bool  $isCreate Whether creating.
	 * @param array $merged   Merged args after patch.
	 * @return array<int, string>
	 */
	private static function advisoryNotes( bool $isCreate, array $merged ): array {
		$notes = array();

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		if ( null !== $pys && !self::truthy( $pys->getOption( 'custom_events_enabled' ) ) ) {
			$notes[] = 'The custom-events master feature (`custom_events_enabled`) is OFF — no custom event fires until it is enabled in PixelYourSite → Events.';
		}

		$triggers     = ( isset( $merged[ 'triggers' ] ) && is_array( $merged[ 'triggers' ] ) ) ? $merged[ 'triggers' ] : array();
		$triggerCount = count( $triggers );
		if ( 0 === $triggerCount ) {
			$notes[] = 'This event has no triggers, so it will not fire until at least one trigger is added (pass `triggers` with an `add` op) — even with a platform enabled.';
		}

		// gads_phone_conversion is Google-Ads-only
		$hasGadsPhone = false;
		foreach ( $triggers as $t ) {
			if ( isset( $t[ 'trigger_type' ] ) && 'gads_phone_conversion' === $t[ 'trigger_type' ] ) {
				$hasGadsPhone = true;
				break;
			}
		}
		if ( $hasGadsPhone ) {
			$gaOn   = self::truthy( $merged[ 'ga_ads_enabled' ] ?? false );
			$hasAw  = false;
			foreach ( (array) ( $merged[ 'ga_ads_pixel_id' ] ?? array() ) as $pid ) {
				if ( is_string( $pid ) && ( 'all' === $pid || 0 === strpos( $pid, 'AW' ) ) ) {
					$hasAw = true;
					break;
				}
			}
			if ( !$gaOn || !$hasAw ) {
				$notes[] = 'The Google Ads Phone Conversion trigger only works for Google Ads — enable the `ga_ads` platform with an `AW-…` conversion id (and set its phone numbers) or the trigger will not deliver.';
			}
		}

		// Conditions present but the gate is off → they are ignored at runtime.
		$conditions = ( isset( $merged[ 'conditions' ] ) && is_array( $merged[ 'conditions' ] ) ) ? $merged[ 'conditions' ] : array();
		if ( !empty( $conditions ) && !self::truthy( $merged[ 'conditions_enabled' ] ?? false ) ) {
			$notes[] = 'This event has display conditions but `conditions_enabled` is OFF — the conditions are ignored until you set `conditions_enabled: true`.';
		}

		$dup = self::ecommerceDuplicationNote( $merged );
		if ( null !== $dup ) {
			$notes[] = $dup;
		}

		// Always remind to verify a real-world fire after a write.
		$notes[] = 'After saving, verify the event actually fires with your platform\'s testing tool (Meta Pixel Helper / GA4 DebugView / Google Tag Assistant / TikTok Pixel Helper / Microsoft UET Tag Helper / Reddit Pixel Helper / Pinterest Tag Helper) before relying on it for reporting.';

		return $notes;
	}

	/**
	 * Warn when the event would DOUBLE-FIRE against PixelYourSite's automatic
	 * WooCommerce / EDD events: an `add_to_cart` / `purchase` trigger, or any
	 * enabled platform set to a STANDARD ecommerce event name (ViewContent,
	 * AddToCart, Purchase, view_item, begin_checkout, …). Advisory only.
	 *
	 * @param array $merged Merged args.
	 * @return string|null
	 */
	private static function ecommerceDuplicationNote( array $merged ): ?string {
		$triggerRisk = false;
		foreach ( ( $merged[ 'triggers' ] ?? array() ) as $t ) {
			$tt = is_array( $t ) ? ( $t[ 'trigger_type' ] ?? '' ) : '';
			if ( 'add_to_cart' === $tt || 'purchase' === $tt ) {
				$triggerRisk = true;
				break;
			}
		}

		$stdHits = array();
		foreach ( CustomEventPlatformMap::slugs() as $slug ) {
			$def = CustomEventPlatformMap::get( $slug );
			if ( null === $def || !self::truthy( $merged[ $def[ 'enabled' ] ] ?? false ) ) {
				continue;
			}
			$et = (string) ( $merged[ $def[ 'event_type' ] ] ?? '' );
			if ( '' !== $et && self::isStandardEcommerceEventType( $et ) ) {
				$stdHits[] = $slug . ':' . $et;
			}
		}

		if ( !$triggerRisk && empty( $stdHits ) ) {
			return null;
		}

		$why = $triggerRisk
			? 'it uses an `add_to_cart` / `purchase` trigger'
			: 'an enabled platform uses a standard ecommerce event name (' . implode( ', ', $stdHits ) . ')';

		return '⚠️ DUPLICATION RISK: ' . $why . '. PixelYourSite very likely ALREADY fires this ecommerce event automatically (WooCommerce / EDD), so this custom event would send it TWICE to the pixel and inflate conversions. Confirm the event NAME with the user; valid reasons to keep it are a DIFFERENT (non-standard) event name or conditions narrowing to a subset of users. Otherwise verify in the platform tester before relying on it.';
	}

	/**
	 * Whether an event_type value is a standard ecommerce funnel event that PYS
	 * fires automatically. Normalises FB-style ("AddToCart") and GA-style
	 * ("add_to_cart") names to one form before matching.
	 *
	 * @param string $eventType Event type value.
	 * @return bool
	 */
	private static function isStandardEcommerceEventType( string $eventType ): bool {
		$norm = str_replace( array( '_', '-', ' ' ), '', strtolower( $eventType ) );
		$std  = array(
			'viewcontent', 'viewitem', 'viewitemlist', 'viewcategory',
			'addtocart', 'removefromcart', 'addtowishlist', 'viewcart',
			'initiatecheckout', 'begincheckout', 'checkout', 'addpaymentinfo', 'addshippinginfo',
			'purchase', 'completepayment', 'placeanorder',
		);

		return in_array( $norm, $std, true );
	}

	/**
	 * Loose truthiness for stored option values.
	 *
	 * @param mixed $v Value.
	 * @return bool
	 */
	private static function truthy( $v ): bool {
		if ( is_bool( $v ) ) {
			return $v;
		}
		if ( is_string( $v ) ) {
			return '1' === $v || 'true' === strtolower( $v );
		}

		return is_int( $v ) && 1 === $v;
	}
}
