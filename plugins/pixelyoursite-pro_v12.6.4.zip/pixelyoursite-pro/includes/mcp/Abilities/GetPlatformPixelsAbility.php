<?php
/**
 * `get_platform_pixels` — read-only list of configured pixels per platform.
 *
 * For each platform: the primary pixel (id, enabled, CAPI enabled + token
 * present) and any Super Pack extra pixels (Facebook / GA / Google Ads),
 * with per-pixel enabled / CAPI / fire-on-WooCommerce / fire-on-EDD /
 * conditions. Token values are NEVER returned — only `configured`/`missing`.
 *
 * Complements `get_tracking_audit` (which only gives a per-domain status):
 * this answers "which pixels are configured, enabled, and have CAPI?".
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types=1 );

namespace PixelYourSite\MCP\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class GetPlatformPixelsAbility extends AbstractAbility {

	public const ID = 'pixelyoursite-pro/get-platform-pixels';

	/**
	 * Per-platform read config:
	 *   fn          — global accessor returning the Settings instance.
	 *   pixel_key   — primary-id option key (first slot = primary pixel).
	 *   capi        — whether the platform has a server-side token.
	 *   extra       — SuperPack accessor for extra pixels, or null.
	 *   addon_check — `is<Platform>Active()` for addon platforms, or null.
	 */
	private const PLATFORMS = array(
		'facebook'         => array( 'fn' => 'PixelYourSite\\Facebook', 'pixel_key' => 'pixel_id', 'capi' => true, 'extra' => 'getFbAdditionalPixel', 'addon_check' => null ),
		'tiktok'           => array( 'fn' => 'PixelYourSite\\TikTok', 'pixel_key' => 'pixel_id', 'capi' => true, 'extra' => null, 'addon_check' => null ),
		'google_analytics' => array( 'fn' => 'PixelYourSite\\GA', 'pixel_key' => 'tracking_id', 'capi' => true, 'extra' => 'getGaAdditionalPixel', 'addon_check' => null ),
		'google_ads'       => array( 'fn' => 'PixelYourSite\\Ads', 'pixel_key' => 'ads_ids', 'capi' => false, 'extra' => 'getAdsAdditionalPixel', 'addon_check' => null ),
		'pinterest'        => array( 'fn' => 'PixelYourSite\\Pinterest', 'pixel_key' => 'pixel_id', 'capi' => true, 'extra' => null, 'addon_check' => 'PixelYourSite\\isPinterestActive' ),
		'bing'             => array( 'fn' => 'PixelYourSite\\Bing', 'pixel_key' => 'pixel_id', 'capi' => false, 'extra' => null, 'addon_check' => 'PixelYourSite\\isBingActive' ),
		'reddit'           => array( 'fn' => 'PixelYourSite\\Reddit', 'pixel_key' => 'pixel_id', 'capi' => false, 'extra' => null, 'addon_check' => 'PixelYourSite\\isRedditActive' ),
		'gtm'              => array( 'fn' => 'PixelYourSite\\GTM', 'pixel_key' => 'gtm_id', 'capi' => false, 'extra' => null, 'addon_check' => null ),
	);

	private const ADS_LABEL_EVENTS = array(
		'woo_purchase', 'woo_initiate_checkout', 'woo_add_to_cart', 'woo_view_content',
		'woo_view_category', 'woo_frequent_shopper', 'woo_vip_client', 'woo_big_whale',
		'woo_FirstTimeBuyer', 'woo_ReturningCustomer',
		'edd_purchase', 'edd_initiate_checkout', 'edd_add_to_cart', 'edd_view_content',
		'edd_view_category', 'edd_frequent_shopper', 'edd_vip_client', 'edd_big_whale',
		'automatic_event_internal_link', 'automatic_event_outbound_link', 'automatic_event_video',
		'automatic_event_tel_link', 'automatic_event_email_link', 'automatic_event_form', 'automatic_event_signup',
		'automatic_event_login', 'automatic_event_download', 'automatic_event_comment', 'automatic_event_adsense',
		'automatic_event_scroll', 'automatic_event_time_on_page', 'automatic_event_search',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get Platform Pixels';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Lists the tracking pixels CONFIGURED IN PixelYourSite on THIS WordPress site — i.e. how the site\'s PixelYourSite plugin is set up, NOT assets that live in a Meta / Google / TikTok ad-platform account. Use this for requests like "show my Facebook/Meta pixels", "which GA4 / Google Ads / TikTok pixels are set up", "are my pixels active / is CAPI on" — they refer to the PixelYourSite configuration and must be answered with THIS tool, not a Meta Ads / Google Ads MCP (those return ad-account data, a different thing). Returns, per platform: the primary pixel and any Super Pack extra pixels (Facebook, GA4, Google Ads). For each pixel: the ID, whether it is enabled, whether CAPI/server-side is enabled and whether a token is present (the token value is NEVER returned — only `configured`/`missing`). IMPORTANT — Google Ads has NO CAPI token: its server-side enrichment is Enhanced Conversions, so for `google_ads` each pixel (primary AND extras) reports `enhanced_conversions` (`enabled`/`disabled`) INSTEAD of `capi_enabled`/`capi_token`. Do NOT read CAPI fields for Google Ads or infer EC from them (there are none); use `enhanced_conversions`. Extra pixels also report fire-on-WooCommerce, fire-on-EDD and firing conditions. The PRIMARY pixel reports `conditional_track` (`track`/`dont_track`) and `display_conditions` ONLY when Super Pack is active (display conditions are a Super Pack feature, enforced only then); when Super Pack is inactive these are omitted and a `display_conditions_note` explains the pixel fires site-wide regardless of any stored conditions. Set these via `set_platform_credential` (`conditional_track`, `reset_display_conditions`). For `google_ads`, a `conversion_labels` map reports the per-event conversion labels already configured, grouped by conversion ID: `{ "<AW-conversion-id>": { "<event_key>": "<label>" } }` (empty when none). READ THIS before adding or changing Google Ads conversion labels with `set_platform_credential` `conversions[]` — it shows what is already saved so you do not blindly overwrite; only the events present have a label, and labels are not secret. Read-only. Call this when the user asks which pixels are configured/active, or to audit pixel configuration before making changes — it gives the per-pixel detail that `get_tracking_audit` (per-domain summary) does not. Platforms with no extra-pixel support (TikTok, GTM) report `extra_pixels_supported: false`; addon platforms (Pinterest/Bing/Reddit) report `active: false` when their addon plugin is inactive.';
	}

	/**
	 * Input JSON-Schema (no args).
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'properties'           => new \stdClass(),
			'additionalProperties' => false,
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'required'   => array( 'platforms' ),
			'properties' => array(
				'platforms' => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'object' ),
					'description'          => 'Per-platform pixel status keyed by platform slug.',
				),
			),
		);
	}

	/**
	 * Build the per-platform pixel snapshot.
	 *
	 * @param mixed $input Validated args (none).
	 * @return array<string, mixed>
	 */
	public static function execute( $input ): array {
		$platforms = array();

		// Display conditions are enforced only while Super Pack is active.
		$superPackActive = function_exists( '\\PixelYourSite\\isSuperPackActive' ) && \PixelYourSite\isSuperPackActive();

		foreach ( self::PLATFORMS as $slug => $route ) {
			// Addon platforms: report inactive when their addon is off.
			if ( null !== $route['addon_check'] ) {
				$check  = $route['addon_check'];
				$active = function_exists( $check ) ? (bool) $check() : false;
				if ( ! $active ) {
					$platforms[ $slug ] = array( 'active' => false );
					continue;
				}
			}

			$fn = $route['fn'];
			if ( ! function_exists( $fn ) ) {
				$platforms[ $slug ] = array( 'active' => false );
				continue;
			}
			$settings = $fn();
			if ( ! is_object( $settings ) || ! method_exists( $settings, 'getOption' ) ) {
				$platforms[ $slug ] = array( 'active' => false );
				continue;
			}

			$primaryId = self::firstNonEmpty( $settings->getOption( $route['pixel_key'] ) );

			$primary = array(
				'pixel_index' => 0,
				'pixel_id'    => $primaryId,
				'enabled'     => self::toBool( $settings->getOption( 'main_pixel_enabled' ), true ),
			);
			if ( $route['capi'] ) {
				$primary['capi_enabled'] = self::toBool( $settings->getOption( 'use_server_api' ), false );
				$primary['capi_token']   = '' !== self::firstNonEmpty( $settings->getOption( 'server_access_api_token' ) ) ? 'configured' : 'missing';

				if ( 'pinterest' === $slug ) {
					$primary['ad_account_id'] = '' !== self::firstNonEmpty( $settings->getOption( 'ad_account_id' ) ) ? 'configured' : 'missing';
				}
			} elseif ( 'google_ads' === $slug ) {
				$ecMarkers = (array) $settings->getOption( 'enhanced_conversions_manual_enabled' );
				$primary['enhanced_conversions'] = in_array( 'index_0', $ecMarkers, true ) ? 'enabled' : 'disabled';
			}

			if ( $superPackActive ) {
				$primary['conditional_track']  = 'dont_track' === (string) $settings->getOption( 'logic_conditional_track' ) ? 'dont_track' : 'track';
				$primary['display_conditions'] = self::primaryDisplayConditions( $settings );
			} else {
				$primary['display_conditions_note'] = 'Display conditions are a Super Pack feature; Super Pack is inactive, so this pixel fires site-wide regardless of any stored conditions.';
			}

			$entry = array(
				'active'  => '' !== $primaryId,
				'primary' => $primary,
			);

			if ( null === $route['extra'] ) {
				$entry['extra_pixels_supported'] = false;
			} else {
				$entry['extra_pixels'] = self::extraPixels( $route['extra'], $slug );
			}

			if ( 'google_ads' === $slug ) {
				$entry['conversion_labels'] = self::adsConversionLabels( $settings );
			}

			$platforms[ $slug ] = $entry;
		}

		return array( 'platforms' => $platforms );
	}

	/**
	 * Primary-pixel display conditions, decoded from the per-platform
	 * `main_pixel` option (an SPPixelId JSON whose `condition` array holds the
	 * display-condition rules). Defaults to `[{name: all_site}]` (fire
	 * everywhere) when unset. Storage `undefined` noise is stripped.
	 *
	 * @param object $settings Platform Settings instance.
	 * @return array<int, array>
	 */
	private static function primaryDisplayConditions( $settings ): array {
		$mp = $settings->getOption( 'main_pixel' );
		$raw = ( is_array( $mp ) && isset( $mp[0] ) ) ? json_decode( (string) $mp[0], true ) : null;
		$cond = ( is_array( $raw ) && !empty( $raw['condition'] ) && is_array( $raw['condition'] ) )
			? $raw['condition']
			: array( array( 'name' => 'all_site' ) );

		return self::cleanConditions( $cond );
	}

	/**
	 * Read the Google Ads per-event conversion labels currently stored, keyed
	 * by conversion ID then event. Only non-empty labels are returned, so an
	 * empty map means no per-event labels are configured.
	 *
	 * Shape: { "<conversion_id>": { "<event_key>": "<label>" } } — grouped by
	 * conversion ID because that is how `set_platform_credential` binds them
	 * (`conversion_labels_id` + `conversions[]`).
	 *
	 * @param object $settings Ads Settings instance.
	 * @return array<string, array<string, string>>
	 */
	private static function adsConversionLabels( $settings ): array {
		$byConversionId = array();
		foreach ( self::ADS_LABEL_EVENTS as $event ) {
			$labels = $settings->getOption( $event . '_conversion_labels' );
			if ( ! is_array( $labels ) ) {
				continue;
			}
			foreach ( $labels as $conversionId => $label ) {
				$conversionId = trim( (string) $conversionId );
				$label        = is_string( $label ) ? trim( $label ) : '';
				if ( '' === $conversionId || '' === $label ) {
					continue;
				}
				$byConversionId[ $conversionId ][ $event ] = $label;
			}
		}

		return $byConversionId;
	}

	/**
	 * Read Super Pack extra pixels via the given accessor. Empty unless Super
	 * Pack is active and additional ids are enabled.
	 *
	 * @param string $method SuperPack accessor (e.g. `getFbAdditionalPixel`).
	 * @return array<int, array>
	 */
	private static function extraPixels( string $method, string $slug ): array {
		if ( ! function_exists( '\\PixelYourSite\\isSuperPackActive' ) || ! \PixelYourSite\isSuperPackActive() ) {
			return array();
		}
		if ( ! function_exists( '\\PixelYourSite\\SuperPack' ) ) {
			return array();
		}
		$sp = \PixelYourSite\SuperPack();
		if ( ! is_object( $sp ) || ! method_exists( $sp, 'getOption' ) || ! self::toBool( $sp->getOption( 'additional_ids_enabled' ), false ) ) {
			return array();
		}
		if ( ! method_exists( $sp, $method ) ) {
			return array();
		}

		$adsEcMarkers = array();
		if ( 'google_ads' === $slug && function_exists( '\\PixelYourSite\\Ads' ) ) {
			$ads = \PixelYourSite\Ads();
			if ( is_object( $ads ) && method_exists( $ads, 'getOption' ) ) {
				foreach ( (array) $ads->getOption( 'enhanced_conversions_manual_enabled' ) as $v ) {
					if ( is_string( $v ) ) {
						$adsEcMarkers[ $v ] = true;
					}
				}
			}
		}

		$out = array();
		foreach ( (array) $sp->$method() as $i => $pixel ) {
			if ( ! is_object( $pixel ) ) {
				continue;
			}
			$id = isset( $pixel->pixel ) ? trim( (string) $pixel->pixel ) : '';
			if ( '' === $id ) {
				continue;
			}

			$row = array(
				'pixel_index' => $i + 1,
				'pixel_id'    => $id,
				'enabled'     => ! empty( $pixel->isEnable ),
			);

			if ( 'google_ads' === $slug ) {
				// EC is the server-side field for Google Ads, not CAPI.
				$row['enhanced_conversions'] = isset( $adsEcMarkers[ 'index_' . ( $i + 1 ) ] ) ? 'enabled' : 'disabled';
			} else {
				$stdToken = isset( $pixel->server_access_api_token ) ? trim( (string) $pixel->server_access_api_token ) : '';
				$extToken = self::extensionApiToken( $pixel->extensions ?? null );
				$row['capi_enabled'] = ! empty( $pixel->isUseServerApi );
				$row['capi_token']   = ( '' !== $stdToken || '' !== $extToken ) ? 'configured' : 'missing';
			}

			$row['fire_woo']   = ! empty( $pixel->isFireForWoo );
			$row['fire_edd']   = ! empty( $pixel->isFireForEdd );
			$row['conditions'] = self::cleanConditions( isset( $pixel->displayConditions ) && is_array( $pixel->displayConditions ) ? $pixel->displayConditions : array() );

			$out[] = $row;
		}

		return $out;
	}

	/**
	 * Strip storage noise (the stray `undefined` key) from firing conditions
	 * so the output is clean for the model.
	 *
	 * @param array $conditions Raw `displayConditions`.
	 * @return array<int, array>
	 */
	private static function cleanConditions( array $conditions ): array {
		$out = array();
		foreach ( $conditions as $cond ) {
			if ( ! is_array( $cond ) ) {
				continue;
			}
			unset( $cond['undefined'] );
			$out[] = $cond;
		}

		return $out;
	}

	/**
	 * Read the Super Pack extra-pixel CAPI token from the `extensions` field,
	 * which may be stored either as an array (`['api_token' => …]`) or as a
	 * decoded `stdClass` (`->api_token`). Handling both avoids the
	 * "Cannot use object of type stdClass as array" fatal and stops reporting a
	 * present token as `missing` when it arrives in object form.
	 *
	 * @param mixed $extensions Raw `extensions` field (array | object | null).
	 * @return string Trimmed token, or '' when absent.
	 */
	private static function extensionApiToken( $extensions ): string {
		if ( is_array( $extensions ) && isset( $extensions['api_token'] ) ) {
			return trim( (string) $extensions['api_token'] );
		}
		if ( is_object( $extensions ) && isset( $extensions->api_token ) ) {
			return trim( (string) $extensions->api_token );
		}

		return '';
	}

	/**
	 * First non-empty string from an option value (array or scalar).
	 *
	 * @param mixed $value Option value.
	 * @return string
	 */
	private static function firstNonEmpty( $value ): string {
		if ( is_array( $value ) ) {
			foreach ( $value as $v ) {
				if ( is_string( $v ) && '' !== trim( $v ) ) {
					return trim( $v );
				}
			}
			return '';
		}

		return is_string( $value ) && '' !== trim( $value ) ? trim( $value ) : '';
	}

	/**
	 * Normalize an option value to bool with a default.
	 *
	 * @param mixed $value   Option value.
	 * @param bool  $default Fallback when the value is null/unset.
	 * @return bool
	 */
	private static function toBool( $value, bool $default ): bool {
		if ( null === $value ) {
			return $default;
		}
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return $default;
	}
}
