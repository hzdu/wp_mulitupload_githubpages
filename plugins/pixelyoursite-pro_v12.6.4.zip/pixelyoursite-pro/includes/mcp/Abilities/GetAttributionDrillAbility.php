<?php
/**
 * `get_attribution_drill` — detailed breakdown for ONE attribution dimension
 * value: products sold, daily revenue, or per-order revenue. Read-only, free.
 * ONE store (WooCommerce or EDD, never combined). Order breakdown returns
 * order_id + revenue only — NO customer PII, ever.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class GetAttributionDrillAbility extends AbstractReportsAbility {

	public const ID = 'pixelyoursite-pro/get-attribution-drill';

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get Attribution Drill';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Detailed breakdown for ONE specific attribution dimension value — products sold, daily revenue, or per-order revenue — from PYS\'s own reports data. Use after get_attribution_summary to drill into a specific campaign / source / landing page. NEVER combines WooCommerce and EDD — always specify `store`. `value` is matched EXACTLY (case-sensitive) against what PYS recorded. If the value is not in the lookup table at all → `found:false`. If it exists but had no orders in the selected range → `found:true, rows:[], count:0` (it ran at some point, just not this period). `breakdown`: products (name, qty, orders, gross_sale — or profit if CoG active), dates (per-day orders + revenue), or orders (order_id + revenue per order — NO customer name/email/phone/city, ever). Capped at 20 rows. When the store\'s reports sync is not FINISHED the response carries `data_incomplete:true` + a `warning` — relay it. Returns an error if the store or PYS reports are not active.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		$properties = array(
			'store'     => array(
				'type'        => 'string',
				'enum'        => array( 'woo', 'edd' ),
				'description' => 'Which store to query. Never combined.',
			),
			'dimension' => array(
				'type' => 'string',
				'enum' => self::DIMENSIONS,
			),
			'value'     => array(
				'type'        => 'string',
				'minLength'   => 1,
				'description' => 'The exact dimension value to drill into, e.g. "summer_sale", "google / cpc", "https://mysite.com/blog". Case-sensitive — must match exactly what PYS stored (see get_attribution_summary `breakdown[].value`).',
			),
			'breakdown' => array(
				'type'        => 'string',
				'enum'        => array( 'products', 'dates', 'orders' ),
				'default'     => 'products',
				'description' => 'products = what was sold; dates = daily revenue; orders = per-order revenue (no customer details).',
			),
			'model'     => array(
				'type'    => 'string',
				'enum'    => array( 'first_visit', 'last_visit' ),
				'default' => 'first_visit',
			),
		);

		return array(
			'type'                 => 'object',
			'required'             => array( 'store', 'dimension', 'value' ),
			'additionalProperties' => false,
			'properties'           => array_merge( $properties, self::dateInputProperties() ),
		);
	}

	/**
	 * Output JSON-Schema (variable shape — self-documenting via description).
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array( 'type' => 'object' );
	}

	/**
	 * Drill into one dimension value.
	 *
	 * @param mixed $input Validated args.
	 * @return array|\WP_Error
	 */
	public static function execute( $input ) {
		$store     = (string) ( $input[ 'store' ] ?? '' );
		$dimension = (string) ( $input[ 'dimension' ] ?? '' );
		$value     = (string) ( $input[ 'value' ] ?? '' );
		$breakdown = (string) ( $input[ 'breakdown' ] ?? 'products' );
		$model     = (string) ( $input[ 'model' ] ?? 'first_visit' );

		$stat = self::requireStore( $store );
		if ( $stat instanceof \WP_Error ) {
			return $stat;
		}

		if ( !in_array( $dimension, self::DIMENSIONS, true ) ) {
			return new \WP_Error( 'pys_mcp_invalid_dimension', 'Invalid dimension: ' . $dimension, array( 'status' => 400 ) );
		}
		if ( '' === $value ) {
			return new \WP_Error( 'pys_mcp_missing_value', 'A non-empty `value` is required.', array( 'status' => 400 ) );
		}

		list( $startDate, $endDate ) = self::resolveDatesFromInput( $input );
		$endQuery = self::endPlusOne( $endDate );

		$filterColName = $stat->getFilterColName( $dimension, $model );
		$filterTable   = $stat->getFilterTable( $dimension );
		if ( empty( $filterColName ) || !$filterTable ) {
			return new \WP_Error( 'pys_mcp_invalid_dimension', 'Invalid dimension: ' . $dimension, array( 'status' => 400 ) );
		}

		// Resolve the value string → internal lookup id (read-only).
		global $wpdb;
		$filterId = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$filterTable->getName()} WHERE item_value = %s",
			$value
		) );

		if ( !$filterId ) {
			return array(
				'found'     => false,
				'store'     => $store,
				'dimension' => $dimension,
				'value'     => self::sanitiseUserString( $value, 0 ),
				'note'      => 'No such value in this store\'s attribution data. Values are case-sensitive and must match exactly what PYS recorded (check get_attribution_summary breakdown).',
			);
		}

		$typeId = $stat->getTypeId();
		$cog    = function_exists( '\\PixelYourSite\\isPixelCogActive' ) && \PixelYourSite\isPixelCogActive();
		$rows   = array();

		switch ( $breakdown ) {
			case 'dates':
				$raw = $cog
					? $stat->orderTable->getCOGDatesForSingle( $filterColName, $filterId, $startDate, $endQuery, $typeId )
					: $stat->orderTable->getDatesForSingle( $filterColName, $filterId, $startDate, $endQuery, $typeId );
				foreach ( (array) $raw as $r ) {
					$row = array( 'date' => (string) ( $r[ 'x' ] ?? '' ), 'orders' => (int) ( $r[ 'count' ] ?? 0 ) );
					self::attachMoney( $row, $r, $cog );
					$rows[] = $row;
				}
				break;

			case 'orders':
				// order_id + revenue only. NO customer PII.
				$raw = $cog
					? $stat->orderTable->getCOGOrdersForSingle( $filterColName, $filterId, $startDate, $endQuery, $typeId )
					: $stat->orderTable->getOrdersForSingle( $filterColName, $filterId, $startDate, $endQuery, $typeId );
				foreach ( (array) $raw as $r ) {
					$row = array( 'order_id' => (int) ( $r[ 'order_id' ] ?? 0 ), 'date' => (string) ( $r[ 'x' ] ?? '' ) );
					self::attachMoney( $row, $r, $cog );
					$rows[] = $row;
				}
				break;

			case 'products':
			default:
				$productTable = $stat->productTable->getName();
				$raw          = $cog
					? $stat->orderTable->getCOGProductsForSingle( $productTable, $filterColName, $filterId, $startDate, $endQuery, $typeId )
					: $stat->orderTable->getProductsForSingle( $productTable, $filterColName, $filterId, $startDate, $endQuery, $typeId );
				foreach ( (array) $raw as $r ) {
					$name = (string) ( $r[ 'name' ] ?? '' );
					$qty  = (int) ( $r[ 'qty' ] ?? 0 );
					// Skip the null-join artefact: orders with no product rows in the
					// stat table group into one empty (no name, 0 qty) row.
					if ( '' === trim( $name ) && $qty <= 0 ) {
						continue;
					}
					$row = array(
						'name'   => self::sanitiseUserString( $name ),
						'qty'    => $qty,
						'orders' => (int) ( $r[ 'orders' ] ?? 0 ),
					);
					// getProductsForSingle: gross_sale in 'gross'; COG variant: profit in 'gross'.
					if ( $cog ) {
						$row[ 'profit' ] = (float) ( $r[ 'gross' ] ?? 0 );
					} else {
						$row[ 'gross_sale' ] = (float) ( $r[ 'gross' ] ?? 0 );
					}
					$rows[] = $row;
				}
				break;
		}

		$rows = array_slice( $rows, 0, self::MAX_ROWS );

		$result = array(
			'found'      => true,
			'store'      => $store,
			'dimension'  => $dimension,
			'value'      => self::sanitiseUserString( $value, 0 ),
			'breakdown'  => $breakdown,
			'model'      => $model,
			'period'     => array( 'start' => $startDate, 'end' => $endDate ),
			'cog_active' => $cog,
			'rows'       => $rows,
			'count'      => count( $rows ),
		);

		if ( count( $rows ) >= self::MAX_ROWS ) {
			$result[ 'note' ] = 'Results capped at ' . self::MAX_ROWS . '. Use the PYS reports UI for the full list.';
		}

		$warn = self::syncIncompleteWarning( $stat );
		if ( null !== $warn ) {
			$result[ 'data_incomplete' ] = true;
			$result[ 'warning' ]         = $warn;
		}

		return $result;
	}

	/**
	 * Attach revenue fields to a dates/orders row. Non-COG: gross_sale/net_sale/
	 * total_sale. COG: cost (from 'gross'), profit (from 'net'), total_sale.
	 *
	 * @param array $row  Target row (mutated).
	 * @param array $r    Raw DB row.
	 * @param bool  $cog  Whether CoG is active.
	 * @return void
	 */
	private static function attachMoney( array &$row, array $r, bool $cog ): void {
		$row[ 'total_sale' ] = (float) ( $r[ 'total' ] ?? 0 );
		if ( $cog ) {
			$row[ 'cost' ]   = (float) ( $r[ 'gross' ] ?? 0 );
			$row[ 'profit' ] = (float) ( $r[ 'net' ] ?? 0 );
		} else {
			$row[ 'gross_sale' ] = (float) ( $r[ 'gross' ] ?? 0 );
			$row[ 'net_sale' ]   = (float) ( $r[ 'net' ] ?? 0 );
		}
	}
}