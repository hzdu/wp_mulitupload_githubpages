<?php
/**
 * `get_attribution_summary` — revenue totals + a ranked breakdown by one
 * attribution dimension (traffic source / landing page / UTM) for ONE store
 * (WooCommerce or EDD, never combined) over a date range. Read-only, free.
 * Reads PYS's own stat tables via OrderStatistics — no WC REST / WC Admin.
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class GetAttributionSummaryAbility extends AbstractReportsAbility {

	public const ID = 'pixelyoursite-pro/get-attribution-summary';

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Get Attribution Summary';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Returns overall revenue totals and a ranked breakdown by ONE attribution dimension (traffic source, landing page, or any UTM parameter) for WooCommerce OR EDD over a date range, from PYS\'s own reports data. NEVER combines WooCommerce and EDD — always specify `store`. If BOTH stores are active and the user did not say which, ASK before calling (see get_tracking_audit `woo_reports`/`edd_reports`). Returns `totals` and a per-value `breakdown` with orders + gross_sale / net_sale / total_sale; if the Pixel Cost of Goods add-on is active it returns `cost` and `profit` instead of gross/net. `model`: first_visit (default — the session that first brought the visitor) or last_visit (the session right before purchase). Breakdown is sorted by gross_sale desc and capped at 20 rows. `attributed_values` = how many distinct values exist for the dimension in the period; `sync_status` = the reports import state; when it is not FINISHED the response also carries `data_incomplete:true` + a `warning` string — RELAY it and do NOT present the figures as final (partial data can be internally inconsistent). Returns an error if the store or PYS reports are not active. Use get_attribution_drill to see products / daily revenue / orders for one specific dimension value.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		$properties = array(
			'store'     => array(
				'type'        => 'string',
				'enum'        => array( 'woo', 'edd' ),
				'description' => 'Which store to query. woo = WooCommerce, edd = Easy Digital Downloads. Never combined — always specify one.',
			),
			'dimension' => array(
				'type'        => 'string',
				'enum'        => self::DIMENSIONS,
				'description' => 'Attribution dimension to break down by.',
			),
			'model'     => array(
				'type'        => 'string',
				'enum'        => array( 'first_visit', 'last_visit' ),
				'default'     => 'first_visit',
				'description' => 'Attribution model. first_visit = the session that first brought the visitor; last_visit = the session immediately before purchase.',
			),
		);

		return array(
			'type'                 => 'object',
			'required'             => array( 'store', 'dimension' ),
			'additionalProperties' => false,
			'properties'           => array_merge( $properties, self::dateInputProperties() ),
		);
	}

	/**
	 * Output JSON-Schema (variable shape — self-documenting via description).
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array( 'type' => 'object' );
	}

	/**
	 * Build the summary.
	 *
	 * @param mixed $input Validated args.
	 * @return array|\WP_Error
	 */
	public static function execute( $input ) {
		$store     = (string) ( $input[ 'store' ] ?? '' );
		$dimension = (string) ( $input[ 'dimension' ] ?? '' );
		$model     = (string) ( $input[ 'model' ] ?? 'first_visit' );

		$stat = self::requireStore( $store );
		if ( $stat instanceof \WP_Error ) {
			return $stat;
		}

		if ( !in_array( $dimension, self::DIMENSIONS, true ) ) {
			return new \WP_Error( 'pys_mcp_invalid_dimension', 'Invalid dimension: ' . $dimension, array( 'status' => 400 ) );
		}

		list( $startDate, $endDate ) = self::resolveDatesFromInput( $input );
		$endQuery = self::endPlusOne( $endDate );

		$filterColName = $stat->getFilterColName( $dimension, $model );
		$filterTable   = $stat->getFilterTable( $dimension );
		if ( empty( $filterColName ) || !$filterTable ) {
			return new \WP_Error( 'pys_mcp_invalid_dimension', 'Invalid dimension: ' . $dimension, array( 'status' => 400 ) );
		}

		$typeId  = $stat->getTypeId();
		$isFirst = ( 'last_visit' !== $model );
		$cog     = function_exists( '\\PixelYourSite\\isPixelCogActive' ) && \PixelYourSite\isPixelCogActive();

		// Totals + ranked breakdown (COG variants when the add-on is active).
		if ( $cog ) {
			$totals = $stat->orderTable->getCOGFilterTotal( $filterColName, $typeId, $startDate, $endQuery, $isFirst );
			$items  = $stat->orderTable->getCOGSumForFilter( $filterTable->getName(), $filterColName, $startDate, $endQuery, 0, self::MAX_ROWS, $typeId, 'gross_sale', 'desc' );
		} else {
			$totals = $stat->orderTable->getFilterTotal( $filterColName, $typeId, $startDate, $endQuery, $isFirst );
			$items  = $stat->orderTable->getSumForFilter( $filterTable->getName(), $filterColName, $startDate, $endQuery, 0, self::MAX_ROWS, $typeId, 'gross_sale', 'desc' );
		}
		$totals = is_array( $totals ) ? $totals : array();

		$breakdown = array();
		foreach ( ( $items[ 'filters' ] ?? array() ) as $row ) {
			$entry = array(
				'value'  => self::sanitiseUserString( $row[ 'name' ] ?? '', 0 ),
				'orders' => (int) ( $row[ 'count' ] ?? 0 ),
			);
			if ( $cog ) {
				// getCOGSumForFilter returns cost in 'gross' and profit in 'net'.
				$entry[ 'cost' ]       = (float) ( $row[ 'gross' ] ?? 0 );
				$entry[ 'profit' ]     = (float) ( $row[ 'net' ] ?? 0 );
				$entry[ 'total_sale' ] = (float) ( $row[ 'total' ] ?? 0 );
			} else {
				$entry[ 'gross_sale' ] = (float) ( $row[ 'gross' ] ?? 0 );
				$entry[ 'net_sale' ]   = (float) ( $row[ 'net' ] ?? 0 );
				$entry[ 'total_sale' ] = (float) ( $row[ 'total' ] ?? 0 );
			}
			$breakdown[] = $entry;
		}

		$totalsOut = array(
			'orders'     => (int) ( $totals[ 'count' ] ?? 0 ),
			'total_sale' => (float) ( $totals[ 'total_sale' ] ?? 0 ),
		);
		if ( $cog ) {
			$totalsOut[ 'cost' ]   = (float) ( $totals[ 'cost' ] ?? 0 );
			$totalsOut[ 'profit' ] = (float) ( $totals[ 'profit' ] ?? 0 );
		} else {
			$totalsOut[ 'gross_sale' ] = (float) ( $totals[ 'gross_sale' ] ?? 0 );
			$totalsOut[ 'net_sale' ]   = (float) ( $totals[ 'net_sale' ] ?? 0 );
		}

		$result = array(
			'store'             => $store,
			'dimension'         => $dimension,
			'model'             => $model,
			'period'            => array( 'start' => $startDate, 'end' => $endDate ),
			'sync_status'       => (string) $stat->getSyncStatus(),
			'attributed_values' => (int) $stat->orderTable->getFilterCount( $filterColName, $typeId, $startDate, $endQuery ),
			'cog_active'        => $cog,
			'totals'            => $totalsOut,
			'breakdown'         => $breakdown,
		);

		if ( count( $breakdown ) >= self::MAX_ROWS ) {
			$result[ 'note' ] = 'Results capped at ' . self::MAX_ROWS . '. Use the PYS reports UI for the full list.';
		}

		$warn = self::syncIncompleteWarning( $stat );
		if ( null !== $warn ) {
			$result[ 'data_incomplete' ] = true;
			$result[ 'warning' ]         = $warn;
		}

		return $result;
	}
}