<?php
/**
 * `set_automatic_event_config` — partial write to the GLOBAL automatic
 * (page-level) event configuration. Pro/read-only-gated, `mcp_note` required,
 * two-step `confirm` gate. Four write surfaces:
 *  - `master_enabled` — the single switch gating ALL automatic events (core).
 *  - `global_event_toggles[]` — per-event global on/off (core).
 *  - `platform_event_toggles[]` — per-platform firing toggles (each platform's
 *    Settings instance), with `all` fan-out and `unsupported_toggles` reporting.
 *  - Settings/thresholds (core): scroll %, time-on-page seconds, rage-click
 *    threshold, YouTube/Vimeo video sub-toggles, download extensions (the
 *    extensions list REPLACES the stored list wholesale, like the admin UI).
 *
 * @package PixelYourSite\MCP\Abilities
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP\Abilities;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PixelYourSite\MCP\Platforms;
use PixelYourSite\MCP\EventToggleMap;

final class SetAutomaticEventConfigAbility extends AbstractWriteAbility {

	public const ID = 'pixelyoursite-pro/set-automatic-event-config';

	/**
	 * Settings/threshold args → core PYS option keys. All render in
	 * `PixelYourSite → General Settings → Automatic Events`
	 * (html-main-general.php) — that view is the authoritative list.
	 */
	private const SETTING_KEYS = array(
		'scroll_value'          => 'automatic_event_scroll_value',
		'time_on_page_value'    => 'automatic_event_time_on_page_value',
		'rage_click_threshold'  => 'automatic_event_rage_click_threshold',
		'video_youtube_enabled' => 'automatic_event_video_youtube_enabled',
		'video_vimeo_enabled'   => 'automatic_event_video_vimeo_enabled',
		'download_extensions'   => 'automatic_event_download_extensions',
	);

	/**
	 * Ability ID.
	 *
	 * @return string
	 */
	public static function id(): string {
		return self::ID;
	}

	/**
	 * Display label.
	 *
	 * @return string
	 */
	public static function label(): string {
		return 'PYS MCP — Set Automatic Event Config';
	}

	/**
	 * Tool description shown to Claude.
	 *
	 * @return string
	 */
	public static function description(): string {
		return 'Writes a partial update to the GLOBAL automatic (page-level) event configuration. Pro-only. Four surfaces: `master_enabled` — the single switch that gates ALL automatic events (turning it off stops every automatic event regardless of the toggles below); `global_event_toggles` — per-event global on/off (`[{event, enabled}]`); `platform_event_toggles` — PER-PLATFORM toggles (`[{platform, event, enabled}]`, platform = a slug or `all`) for ANY event the platform registers at runtime (read the matrix from `get_automatic_events_config.platform_events` — sets differ per platform; unregistered pairs come back in `unsupported_toggles`). Note: the PYS admin UI only shows per-platform switches for video/signup — for other events this per-platform state is visible only through these MCP tools, so mention that to the user when changing them. Enabling a per-platform toggle whose GLOBAL toggle is off auto-enables the global one; the MASTER switch is never auto-enabled — a note tells you when it blocks everything. Such side-effects are returned in `notes` and you MUST tell the user about every note (e.g. "enabled the global Track-email-links toggle, otherwise the per-platform toggle would have no effect") — never apply an unrequested change silently; and settings/thresholds — `scroll_value` (% page depth that triggers Scroll, 0–100), `time_on_page_value` (seconds before TimeOnPage fires, 0–100), `rage_click_threshold` (quick clicks on the same element within 2s that trigger RageClick), `video_youtube_enabled` / `video_vimeo_enabled` (Video sub-toggles), `download_extensions` (file extensions tracked as Download, WITHOUT dots, e.g. ["pdf","zip"] — this list REPLACES the stored one wholesale, so read the current list from `get_automatic_events_config.settings` first and resend it with your additions/removals). An automatic event fires on a platform only when the master switch AND its global toggle AND that platform\'s own gate are all on. `event` is any automatic-event stem (`internal_link`, `outbound_link`, `video`, `tel_link`, `email_link`, `form`, `signup`, `login`, `download`, `comment`, `adsense`, `scroll`, `time_on_page`, `search`, `404`, `rage_click`, `video_speed`); platform×event pairs the platform does not register (e.g. Pinterest/Bing/Reddit × rage_click/video_speed/404; 404 is GA4/GTM only) are returned in `unsupported_toggles` and skipped (for `all`, silently). **Two-step write (server-enforced):** call FIRST without `confirm` to get a `confirmation_required` preview (current→new for master/global/settings, and per platform×event); show it, get explicit go-ahead, THEN call again with `confirm: true` and the same args. A call without `confirm: true` never writes. Pass `mcp_note`.';
	}

	/**
	 * Input JSON-Schema.
	 *
	 * @return array
	 */
	public static function inputSchema(): array {
		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'master_enabled'          => array(
					'type'        => 'boolean',
					'description' => 'The master automatic-events switch (`automatic_events_enabled`). false disables ALL automatic events site-wide.',
				),
				'global_event_toggles'    => array(
					'type'        => 'array',
					'description' => 'Global per-event on/off. Each item `{ event, enabled }`. This is the global layer (an event also needs its platform toggle on to fire for that platform).',
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'event', 'enabled' ),
						'additionalProperties' => false,
						'properties'           => array(
							'event'   => array( 'type' => 'string', 'enum' => EventToggleMap::AUTOMATIC_EVENTS ),
							'enabled' => array( 'type' => 'boolean' ),
						),
					),
				),
				'platform_event_toggles'  => array(
					'type'        => 'array',
					'description' => 'PER-PLATFORM automatic-event toggles. Each item `{ platform, event, enabled }` for any event the platform REGISTERS (see `get_automatic_events_config.platform_events`; sets differ — e.g. no rage_click/video_speed/404 on Pinterest/Bing/Reddit). `platform` is a slug (`facebook`/`tiktok`/`google_analytics`/`google_ads`/`pinterest`/`bing`/`reddit`/`gtm`) or `all` (every active platform registering the event). Unregistered pairs are returned in `unsupported_toggles` and skipped. Enabling a toggle whose global event toggle is off auto-enables the global one (see `notes`). For events other than video/signup the admin UI has no per-platform switch — the state is visible only via MCP.',
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'platform', 'event', 'enabled' ),
						'additionalProperties' => false,
						'properties'           => array(
							'platform' => array( 'type' => 'string', 'enum' => EventToggleMap::TARGET_PLATFORMS ),
							'event'    => array( 'type' => 'string', 'enum' => EventToggleMap::AUTOMATIC_EVENTS ),
							'enabled'  => array( 'type' => 'boolean' ),
						),
					),
				),
				'scroll_value'            => array(
					'type'        => 'number',
					'minimum'     => 0,
					'maximum'     => 100,
					'description' => 'Scroll-depth percentage (0–100) that triggers the Scroll event.',
				),
				'time_on_page_value'      => array(
					'type'        => 'number',
					'minimum'     => 0,
					'maximum'     => 100,
					'description' => 'Seconds on page (0–100, mirrors the admin cap) before the TimeOnPage event fires.',
				),
				'rage_click_threshold'    => array(
					'type'        => 'integer',
					'minimum'     => 0,
					'description' => 'Quick clicks on the same element (within 2 seconds) that trigger the RageClick event.',
				),
				'video_youtube_enabled'   => array(
					'type'        => 'boolean',
					'description' => 'Video event sub-toggle: track embedded YouTube videos.',
				),
				'video_vimeo_enabled'     => array(
					'type'        => 'boolean',
					'description' => 'Video event sub-toggle: track embedded Vimeo videos.',
				),
				'download_extensions'     => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string', 'minLength' => 1 ),
					'description' => 'File extensions tracked as Download events, WITHOUT dots (e.g. ["pdf","zip","exe"]). REPLACES the stored list wholesale — read the current list from `get_automatic_events_config.settings.download_extensions` first and resend it with your additions/removals. An empty array clears the list.',
				),
				'confirm'                 => array(
					'type'        => 'boolean',
					'description' => 'Two-step write guard. Call FIRST without this flag to get a `confirmation_required` preview (current→new for master/global/settings and per platform×event); show it, get explicit go-ahead, THEN resend with `confirm: true`. A call without `confirm: true` never writes.',
				),
			),
			// `required: ["mcp_note"]` added by AbstractWriteAbility::resolvedInputSchema().
		);
	}

	/**
	 * Output JSON-Schema.
	 *
	 * @return array
	 */
	public static function outputSchema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'saved'                  => array( 'type' => 'boolean' ),
				'available'              => array( 'type' => 'boolean' ),
				'confirmation_required'  => array( 'type' => 'boolean' ),
				'pending_changes'        => array( 'type' => 'object', 'additionalProperties' => true ),
				'changed'                => array( 'type' => 'object', 'additionalProperties' => true ),
				'platform_event_toggles' => array(
					'type'        => 'array',
					'description' => 'Per-platform toggles (preview = would change; confirmed = written). Each `{ platform, event, current, new }`.',
					'items'       => array( 'type' => 'object' ),
				),
				'unsupported_toggles'    => array(
					'type'        => 'array',
					'description' => 'Per-platform toggles that could NOT be applied. Each `{ platform, event, reason }`.',
					'items'       => array( 'type' => 'object' ),
				),
				'notes'                  => array(
					'type'        => 'array',
					'description' => 'Side-effect notices the user did NOT explicitly request — e.g. "the global email_link toggle was auto-enabled" or "the master switch is off". You MUST relay every note to the user in your reply, both at the preview step and after the confirmed write — never silently omit them.',
					'items'       => array( 'type' => 'string' ),
				),
			),
		);
	}

	/**
	 * Validate and write (or preview) the automatic-events config.
	 *
	 * @param mixed $input Validated args.
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function execute( $input ) {
		if ( !is_array( $input ) ) {
			$input = array();
		}
		unset( $input[ 'mcp_note' ] );
		$confirm = !empty( $input[ 'confirm' ] );

		$pys = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		if ( null === $pys ) {
			return new \WP_Error( 'pys_mcp_pys_unavailable', 'PixelYourSite is not loaded.', array( 'status' => 500 ) );
		}

		$hasMaster   = array_key_exists( 'master_enabled', $input ) && is_bool( $input[ 'master_enabled' ] );
		$rawGlobal   = isset( $input[ 'global_event_toggles' ] ) && is_array( $input[ 'global_event_toggles' ] ) ? $input[ 'global_event_toggles' ] : array();
		$rawPlatform = isset( $input[ 'platform_event_toggles' ] ) && is_array( $input[ 'platform_event_toggles' ] ) ? $input[ 'platform_event_toggles' ] : array();

		$rawSettings = array_intersect_key( $input, self::SETTING_KEYS );

		if ( !$hasMaster && empty( $rawGlobal ) && empty( $rawPlatform ) && empty( $rawSettings ) ) {
			return new \WP_Error(
				'pys_mcp_automatic_no_args',
				'Nothing to update. Pass at least one of `master_enabled`, `global_event_toggles`, `platform_event_toggles`, or a setting (`scroll_value`, `time_on_page_value`, `rage_click_threshold`, `video_youtube_enabled`, `video_vimeo_enabled`, `download_extensions`).',
				array( 'status' => 400 )
			);
		}

		// --- core (master + global per-event) ---
		$corePayload = array();
		$pending     = array();
		if ( $hasMaster ) {
			$new                       = (bool) $input[ 'master_enabled' ];
			$corePayload[ 'automatic_events_enabled' ] = $new;
			$pending[ 'master_enabled' ]               = array(
				'current' => EventToggleMap::toBool( $pys->getOption( 'automatic_events_enabled' ) ),
				'new'     => $new,
			);
		}
		// --- settings / thresholds (core) ---
		foreach ( $rawSettings as $arg => $value ) {
			$key = self::SETTING_KEYS[ $arg ];

			if ( 'download_extensions' === $arg ) {
				// Normalise: strings only, trimmed, leading dots stripped, deduped.
				$list = array();
				foreach ( is_array( $value ) ? $value : array() as $raw ) {
					if ( !is_string( $raw ) ) {
						continue;
					}
					$ext = strtolower( ltrim( trim( $raw ), '.' ) );
					if ( '' !== $ext && !in_array( $ext, $list, true ) ) {
						$list[] = $ext;
					}
				}
				$stored  = $pys->getOption( $key );
				$current = array_values( array_filter( is_array( $stored ) ? array_map( 'strval', $stored ) : array() ) );
				$new     = $list;
			} elseif ( 'video_youtube_enabled' === $arg || 'video_vimeo_enabled' === $arg ) {
				$current = EventToggleMap::toBool( $pys->getOption( $key ) );
				$new     = (bool) $value;
			} elseif ( 'rage_click_threshold' === $arg ) {
				$current = (int) $pys->getOption( $key, 0 );
				$new     = (int) $value;
			} else {
				$current = (float) $pys->getOption( $key, 0 );
				$new     = (float) $value;
			}

			$corePayload[ $key ] = $new;
			$pending[ $arg ]     = array(
				'current' => $current,
				'new'     => $new,
			);
		}

		foreach ( $rawGlobal as $entry ) {
			if ( !is_array( $entry ) ) {
				continue;
			}
			$event = isset( $entry[ 'event' ] ) && is_string( $entry[ 'event' ] ) ? $entry[ 'event' ] : '';
			if ( !EventToggleMap::isKnownEvent( 'automatic', $event ) ) {
				continue;
			}
			$new                                = !empty( $entry[ 'enabled' ] );
			$key                                = EventToggleMap::key( 'automatic', $event );
			$corePayload[ $key ]                = $new;
			$pending[ 'global:' . $event ]      = array(
				'current' => EventToggleMap::toBool( $pys->getOption( $key ) ),
				'new'     => $new,
			);
		}

		// --- per-platform toggles ---
		$activeSettings    = Platforms::activeSettings();
		$toggleWrites      = array();
		$togglePending     = array();
		$toggleUnsupported = array();
		foreach ( $rawPlatform as $entry ) {
			if ( !is_array( $entry ) ) {
				continue;
			}
			$tPlatform = isset( $entry[ 'platform' ] ) && is_string( $entry[ 'platform' ] ) ? $entry[ 'platform' ] : '';
			$tEvent    = isset( $entry[ 'event' ] ) && is_string( $entry[ 'event' ] ) ? $entry[ 'event' ] : '';
			$tEnabled  = !empty( $entry[ 'enabled' ] );
			if ( '' === $tPlatform || '' === $tEvent ) {
				continue;
			}
			if ( !EventToggleMap::isKnownEvent( 'automatic', $tEvent ) ) {
				$toggleUnsupported[] = array( 'platform' => $tPlatform, 'event' => $tEvent, 'reason' => 'unknown_event' );
				continue;
			}
			$key     = EventToggleMap::key( 'automatic', $tEvent );
			$targets = 'all' === $tPlatform ? array_keys( $activeSettings ) : array( $tPlatform );
			$matched = false;
			foreach ( $targets as $slug ) {
				$settings = $activeSettings[ $slug ] ?? null;
				if ( null === $settings || !method_exists( $settings, 'issetOption' )
				     || !EventToggleMap::platformSupports( 'automatic', $slug, $tEvent, $settings )
				     || !$settings->issetOption( $key ) ) {
					if ( 'all' !== $tPlatform ) {
						$toggleUnsupported[] = array(
							'platform' => $slug,
							'event'    => $tEvent,
							'reason'   => null === $settings ? 'platform_inactive' : 'event_not_supported',
						);
					}
					continue;
				}
				$matched                       = true;
				$toggleWrites[ $slug ][ $key ] = $tEnabled;
				$togglePending[]               = array(
					'platform' => $slug,
					'event'    => $tEvent,
					'current'  => EventToggleMap::toBool( $settings->getOption( $key ) ),
					'new'      => $tEnabled,
				);
			}
			if ( 'all' === $tPlatform && !$matched ) {
				$toggleUnsupported[] = array( 'platform' => 'all', 'event' => $tEvent, 'reason' => 'no_active_platform_registers_event' );
			}
		}

		$notes = array();
		foreach ( $togglePending as $togglePendingEntry ) {
			if ( empty( $togglePendingEntry[ 'new' ] ) ) {
				continue;
			}
			$gKey = EventToggleMap::key( 'automatic', $togglePendingEntry[ 'event' ] );
			if ( isset( $corePayload[ $gKey ] ) ) {
				continue;
			}
			if ( !EventToggleMap::toBool( $pys->getOption( $gKey ) ) ) {
				$corePayload[ $gKey ]                                       = true;
				$pending[ 'global:' . $togglePendingEntry[ 'event' ] ]      = array( 'current' => false, 'new' => true );
				$notes[]                                                    = sprintf(
					'Auto-enabled the global "%s" toggle — a per-platform switch has no effect while the global toggle is off.',
					$togglePendingEntry[ 'event' ]
				);
			}
		}

		$masterAfter = array_key_exists( 'automatic_events_enabled', $corePayload )
			? (bool) $corePayload[ 'automatic_events_enabled' ]
			: EventToggleMap::toBool( $pys->getOption( 'automatic_events_enabled' ) );
		if ( !$masterAfter && ( !empty( $toggleWrites ) || !empty( $corePayload ) ) ) {
			$notes[] = 'The automatic-events MASTER switch is OFF — no automatic event fires until `master_enabled: true` is set.';
		}

		// Two-step confirm gate.
		if ( !$confirm ) {
			$preview = array(
				'available'             => true,
				'confirmation_required' => true,
				'pending_changes'       => (object) $pending,
			);
			if ( !empty( $togglePending ) ) {
				$preview[ 'platform_event_toggles' ] = $togglePending;
			}
			if ( !empty( $toggleUnsupported ) ) {
				$preview[ 'unsupported_toggles' ] = $toggleUnsupported;
			}
			if ( !empty( $notes ) ) {
				$preview[ 'notes' ] = $notes;
			}

			return $preview;
		}

		// ---- Confirmed write ----
		if ( !empty( $corePayload ) ) {
			$pys->updateOptions( $corePayload );
		}
		foreach ( $toggleWrites as $slug => $kv ) {
			$settings = $activeSettings[ $slug ] ?? null;
			if ( null !== $settings && !empty( $kv ) ) {
				$settings->updateOptions( $kv );
			}
		}

		if ( function_exists( '\\PixelYourSite\\purgeCache' ) ) {
			\PixelYourSite\purgeCache();
		}

		$result = array(
			'saved'     => true,
			'available' => true,
			'changed'   => (object) $pending,
		);
		if ( !empty( $togglePending ) ) {
			$result[ 'platform_event_toggles' ] = $togglePending;
		}
		if ( !empty( $toggleUnsupported ) ) {
			$result[ 'unsupported_toggles' ] = $toggleUnsupported;
		}
		if ( !empty( $notes ) ) {
			$result[ 'notes' ] = $notes;
		}

		return $result;
	}
}
