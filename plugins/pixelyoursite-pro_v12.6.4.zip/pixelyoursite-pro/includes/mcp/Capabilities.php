<?php
/**
 * Capability checks for MCP tools (pure reads): `isPro()`, `isReadOnly()`,
 * and `isWriteAllowed()` (= isPro && !isReadOnly). Used by write-ability
 * permission callbacks, the error envelopes, and the settings UI.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class Capabilities {

	/**
	 * PYS Settings option key for the read-only toggle. Stored in
	 * `wp_pys_options` like every other PYS setting and registered in
	 * `McpServer::boot()` on `init` priority 11 (after PYS loads its schema).
	 */
	public const OPTION_READ_ONLY_ENABLED = 'mcp_read_only_enabled';

	/**
	 * Are we running as the Pro variant? True when PYS Pro is loaded and PYS
	 * Free is not active. Wrapped in one place so future tier checks extend
	 * here rather than scattering across write tools.
	 *
	 * @return bool
	 */
	public static function isPro(): bool {
		if ( !defined( 'PYS_PRO_PLUGIN_FILE' ) ) {
			return false;
		}
		if ( function_exists( 'isPysFreeActive' ) && \isPysFreeActive() ) {
			return false;
		}

		return true;
	}

	/**
	 * Has the admin enabled read-only mode? When on, read tools work and
	 * write tools return the `Read-only mode is enabled.` envelope, letting a
	 * site owner run audit-only sessions. Default false — the per-field write
	 * guards already cover the irreversible cases.
	 *
	 * @return bool
	 */
	public static function isReadOnly(): bool {
		if ( !function_exists( '\\PixelYourSite\\PYS' ) ) {
			return false;
		}

		return self::toBool( \PixelYourSite\PYS()->getOption( self::OPTION_READ_ONLY_ENABLED, false ) );
	}

	/**
	 * Toggle read-only mode via `PYS()->updateOptions()`. Returns false if
	 * PYS Pro isn't loaded (defensive — the AJAX handler is already gated).
	 *
	 * @param bool $enabled Whether read-only mode should be on.
	 * @return bool True on success, false if PYS isn't loaded.
	 */
	public static function setReadOnly( bool $enabled ): bool {
		if ( !function_exists( '\\PixelYourSite\\PYS' ) ) {
			return false;
		}
		\PixelYourSite\PYS()->updateOptions( array( self::OPTION_READ_ONLY_ENABLED => $enabled ) );

		return true;
	}

	/**
	 * Are writes allowed in the current call? Used by every write-ability's
	 * `permission_callback`; false makes the adapter return the `Pro
	 * required.` envelope.
	 *
	 * @return bool
	 */
	public static function isWriteAllowed(): bool {
		return self::isPro() && !self::isReadOnly();
	}

	/**
	 * Normalize raw option value to boolean. wp_pys_options stores checkbox
	 * values as `'1'` / `'0'` strings; some callers may pass real booleans.
	 *
	 * @param mixed $value Raw option value.
	 * @return bool
	 */
	private static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === $value;
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}
