<?php
/**
 * Declarative registry of custom-event TRIGGER types. One MAP row per type
 * (label, platform restriction, rules_key, params, json_params, special) holds
 * everything the MCP layer needs to read/validate/rebuild a trigger, mirroring
 * CustomEvent::update()'s parser — so adding or fixing a trigger is a one-row edit.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class CustomEventTriggerMap {

	private const MAP = array(
		'page_visit'            => array( 'label' => 'Page visit', 'platforms' => null, 'rules_key' => 'page_visit_triggers', 'params' => array( 'delay' ), 'json_params' => array(), 'special' => null ),
		'home_page'             => array( 'label' => 'Home page', 'platforms' => null, 'rules_key' => null, 'params' => array( 'delay' ), 'json_params' => array(), 'special' => null ),
		'add_to_cart'           => array( 'label' => 'WooCommerce add to cart', 'platforms' => null, 'rules_key' => null, 'params' => array( 'track_value_and_currency' ), 'json_params' => array(), 'special' => null ),
		'purchase'              => array( 'label' => 'WooCommerce purchase', 'platforms' => null, 'rules_key' => null, 'params' => array( 'purchase_transaction_only', 'track_transaction_ID', 'track_value_and_currency' ), 'json_params' => array(), 'special' => null ),
		'number_page_visit'     => array( 'label' => 'Number of Page Visits', 'platforms' => null, 'rules_key' => 'number_page_visit_triggers', 'params' => array( 'number_visit', 'conditional_number_visit' ), 'json_params' => array(), 'special' => null ),
		'url_click'             => array( 'label' => 'Click on HTML link', 'platforms' => null, 'rules_key' => 'url_click_triggers', 'params' => array(), 'json_params' => array(), 'special' => null ),
		'css_click'             => array( 'label' => 'Click on CSS selector', 'platforms' => null, 'rules_key' => 'css_click_triggers', 'params' => array( 'click_count', 'click_time_limit' ), 'json_params' => array(), 'special' => null ),
		'css_mouseover'         => array( 'label' => 'Mouse over CSS selector', 'platforms' => null, 'rules_key' => 'css_mouseover_triggers', 'params' => array(), 'json_params' => array(), 'special' => null ),
		'scroll_pos'            => array( 'label' => 'Page Scroll', 'platforms' => null, 'rules_key' => 'scroll_pos_triggers', 'params' => array(), 'json_params' => array(), 'special' => null ),
		'post_type'             => array( 'label' => 'Post type', 'platforms' => null, 'rules_key' => null, 'params' => array( 'delay', 'post_type_value' ), 'json_params' => array(), 'special' => null ),
		'copy_element'          => array( 'label' => 'Copy element (text copy)', 'platforms' => null, 'rules_key' => 'copy_element_triggers', 'params' => array(), 'json_params' => array(), 'special' => null ),
		'email_link'            => array( 'label' => 'Email Link', 'platforms' => null, 'rules_key' => 'email_link_triggers', 'params' => array( 'email_link_disable_email_event' ), 'json_params' => array(), 'special' => null ),
		'video_view'            => array( 'label' => 'Embedded Video View', 'platforms' => null, 'rules_key' => null, 'params' => array( 'video_view_urls', 'video_view_play_trigger', 'video_view_disable_watch_video', 'video_view_triggers' ), 'json_params' => array( 'video_view_data' ), 'special' => null ),
		'video_speed'           => array( 'label' => 'Embedded Video speed', 'platforms' => null, 'rules_key' => null, 'params' => array( 'video_speed_urls', 'video_speed_rate', 'video_speed_triggers' ), 'json_params' => array( 'video_speed_data' ), 'special' => null ),
		'form_field'            => array( 'label' => 'Filling out a form field', 'platforms' => null, 'rules_key' => null, 'params' => array(), 'json_params' => array(), 'special' => 'form_field' ),
		'gads_phone_conversion' => array( 'label' => 'Google Ads Phone Conversion', 'platforms' => array( 'google_ads' ), 'rules_key' => 'gads_phone_conversion_triggers', 'params' => array(), 'json_params' => array(), 'special' => null ),
	);

	private const RULE_VALUES = array(
		'page_visit'            => array( 'contains', 'match', 'param_contains', 'param_match' ),
		'url_click'             => array( 'contains', 'match' ),
		'number_page_visit'     => array( 'any', 'contains', 'match', 'param_contains', 'param_match' ),
		'email_link'            => array( 'any', 'match', 'contains' ),
		'gads_phone_conversion' => array( 'contains', 'match', 'param_contains', 'param_match' ),
	);

	private const PARAM_SPECS = array(
		'delay'                          => array( 'label' => 'Delay before firing', 'unit' => 'seconds' ),
		'click_count'                    => array( 'label' => 'Number of clicks required', 'unit' => 'clicks' ),
		'click_time_limit'               => array( 'label' => 'Time limit between clicks', 'unit' => 'milliseconds', 'note' => '0 = no limit' ),
		'number_visit'                   => array( 'label' => 'Number of page visits', 'unit' => 'visits' ),
		'conditional_number_visit'       => array( 'label' => 'Visit-count comparison', 'enum' => array( 'equal', 'equal_or_larger', 'equal_or_less', 'larger', 'less' ) ),
		'post_type_value'                => array( 'label' => 'Post type' ),
		'track_value_and_currency'       => array( 'label' => 'Track value & currency' ),
		'purchase_transaction_only'      => array( 'label' => 'Purchase transaction only' ),
		'track_transaction_ID'           => array( 'label' => 'Track transaction ID' ),
		'email_link_disable_email_event' => array( 'label' => 'Disable the email_link event' ),
	);

	/**
	 * Allowed `rule` values for a trigger type ([] = value-only / no rule).
	 *
	 * @param string $type Trigger type slug.
	 * @return array<int, string>
	 */
	public static function ruleValues( string $type ): array {
		return self::RULE_VALUES[ $type ] ?? array();
	}

	/**
	 * Metadata for a trigger param ({ label, unit?, note?, enum? }), or [] if the
	 * param has no special spec.
	 *
	 * @param string $name Param name.
	 * @return array<string, mixed>
	 */
	public static function paramSpec( string $name ): array {
		return self::PARAM_SPECS[ $name ] ?? array();
	}

	/**
	 * All known trigger type slugs.
	 *
	 * @return array<int, string>
	 */
	public static function types(): array {
		return array_keys( self::MAP );
	}

	/**
	 * Whether a type is known to the map.
	 *
	 * @param string $type Trigger type slug.
	 * @return bool
	 */
	public static function has( string $type ): bool {
		return isset( self::MAP[ $type ] );
	}

	/**
	 * The full definition for a type, or null if unknown.
	 *
	 * @param string $type Trigger type slug.
	 * @return array<string, mixed>|null
	 */
	public static function get( string $type ): ?array {
		return self::MAP[ $type ] ?? null;
	}

	/**
	 * Admin-facing label (falls back to the raw slug for unknown / form-plugin types).
	 *
	 * @param string $type Trigger type slug.
	 * @return string
	 */
	public static function label( string $type ): string {
		return self::MAP[ $type ][ 'label' ] ?? $type;
	}

	/**
	 * Whether a trigger type is editable via MCP. Scan-driven types (video_view /
	 * video_speed / form_field / elementor_form) are read-only; other form plugins
	 * are editable. Derived from the map, so there is no separate list to drift.
	 *
	 * @param string $type Trigger type slug.
	 * @return bool
	 */
	public static function isEditable( string $type ): bool {
		$def = self::MAP[ $type ] ?? null;
		if ( null === $def ) {
			return self::isFormPlugin( $type ) && 'elementor_form' !== $type;
		}

		return empty( $def[ 'json_params' ] ) && !in_array( $def[ 'special' ], array( 'form_field', 'form_plugin' ), true );
	}

	public const FORM_SUBMIT_MODES = array( 'both', 'reload_only', 'ajax_only' );

	private const URL_WILDCARD_TYPES = array( 'page_visit', 'number_page_visit', 'gads_phone_conversion' );

	/**
	 * Whether `*` as a rule value matches all pages for this trigger type.
	 *
	 * @param string $type Trigger type slug.
	 * @return bool
	 */
	public static function supportsUrlWildcard( string $type ): bool {
		return in_array( $type, self::URL_WILDCARD_TYPES, true );
	}

	/**
	 * Active form-plugin trigger providers, keyed by slug (CF7, WPForms, …).
	 * Sourced from the `pys_form_event_factory` filter — the SAME source the
	 * admin trigger-type dropdown uses, so what we expose matches the UI exactly.
	 *
	 * @return array<string, object> slug => provider object
	 */
	public static function formPlugins(): array {
		$out = array();
		if ( !function_exists( 'apply_filters' ) ) {
			return $out;
		}
		foreach ( (array) apply_filters( 'pys_form_event_factory', array() ) as $plugin ) {
			if ( is_object( $plugin ) && method_exists( $plugin, 'getSlug' ) ) {
				$out[ (string) $plugin->getSlug() ] = $plugin;
			}
		}

		return $out;
	}

	/**
	 * Whether a type slug is an active form-plugin trigger.
	 *
	 * @param string $type Trigger type slug.
	 * @return bool
	 */
	public static function isFormPlugin( string $type ): bool {
		return array_key_exists( $type, self::formPlugins() );
	}

	/**
	 * Display name for a form-plugin trigger (e.g. "Contact Form 7").
	 *
	 * @param string $type Trigger type slug.
	 * @return string
	 */
	public static function formPluginName( string $type ): string {
		$plugin = self::formPlugins()[ $type ] ?? null;

		return ( $plugin && method_exists( $plugin, 'getName' ) ) ? (string) $plugin->getName() : $type;
	}

	/**
	 * Available forms for a form-plugin trigger as id => title (the same list the
	 * admin form-select offers). Empty for elementor_form (scan-driven).
	 *
	 * @param string $type Trigger type slug.
	 * @return array<int|string, string>
	 */
	public static function formPluginForms( string $type ): array {
		$plugin = self::formPlugins()[ $type ] ?? null;
		if ( $plugin && method_exists( $plugin, 'getForms' ) ) {
			return (array) $plugin->getForms();
		}

		return array();
	}

	/**
	 * Pixel slugs a trigger is restricted to, or null when it applies to all.
	 *
	 * @param string $type Trigger type slug.
	 * @return array<int, string>|null
	 */
	public static function platforms( string $type ): ?array {
		return self::MAP[ $type ][ 'platforms' ] ?? null;
	}

	/**
	 * Whether a trigger type is allowed for a given pixel slug.
	 *
	 * @param string $type Trigger type slug.
	 * @param string $slug Pixel slug.
	 * @return bool
	 */
	public static function appliesTo( string $type, string $slug ): bool {
		$p = self::platforms( $type );

		return null === $p || in_array( $slug, $p, true );
	}

	/**
	 * Param names relevant to a type (params + json_params merged) — the read
	 * abilities use this to surface only meaningful params and skip class
	 * defaults that getParam() returns for every type.
	 *
	 * @param string $type Trigger type slug.
	 * @return array<int, string>
	 */
	public static function relevantParams( string $type ): array {
		$def = self::MAP[ $type ] ?? null;
		if ( null === $def ) {
			return array();
		}

		return array_merge( $def[ 'params' ], $def[ 'json_params' ] );
	}
}
