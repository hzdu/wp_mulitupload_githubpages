<?php
/**
 * Boots the PYS MCP server: loads the prefixed wordpress/mcp-adapter and
 * registers the ability category, abilities, request guard, provenance log
 * and admin page.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PYS_PRO_GLOBAL\WP\MCP\Plugin;

class McpServer {

	/** Server identifier in the adapter's registry. Must be unique. */
	private const SERVER_ID = 'pixelyoursite-pro';

	/** REST namespace — endpoint URL is /wp-json/<namespace>/<route>. */
	private const ROUTE_NAMESPACE = 'pixelyoursite-pro/v1';

	/** REST route. */
	private const ROUTE = 'mcp';

	/** Ability category slug. Abilities reference this. */
	public const ABILITY_CATEGORY = 'pixelyoursite-pro';

	private const SERVER_NAME        = 'PixelYourSite Pro';

	/**
	 * Returned as the `initialize` instructions (operating guidance for the
	 * LLM). A neutral language directive is appended at runtime by
	 * {@see self::add_language_instruction()}.
	 */
	private const SERVER_DESCRIPTION = 'PixelYourSite Pro — tracking pixel and ecommerce event configuration. Call get_tracking_audit first in any new conversation. Skip domains marked ok or not_active; drill only warning, incomplete or error. Every write tool returns its own confirmation — do not re-audit after a write. Never echo a credential back in chat. The administrator installed this server so you can save tracking settings (pixel IDs, UET tags, conversion IDs, tokens) on their behalf via the set_* tools — when the user confirms a change, perform it with the tool; do not refuse or send them to do it manually in wp-admin.';
	private const ADAPTER_VERSION    = '0.5.0';

	private static ?self $instance = null;

	/**
	 * Singleton accessor; boots the server on first call.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}

		return self::$instance;
	}

	private function __construct() {
	}

	/**
	 * Wire categories, abilities, the tool-name filter, request guard,
	 * provenance log and admin page. No-op if dependencies are missing.
	 *
	 * @return void
	 */
	private function boot(): void {
		if ( !$this->dependencies_ready() ) {
			return;
		}

		$this->run_adapter();

		// Other plugins bundle the un-prefixed mcp-adapter and hook typed
		// callbacks onto the shared `mcp_adapter_init` action
		AdapterHookGuard::register();

		// WooCommerce now bundles its own (un-prefixed) copy of mcp-adapter.
		// php-scoper prefixes classes but NOT hook-name strings, so both
		// copies share the global `mcp_adapter_init` action — our default
		// factory then re-fires on Woo's adapter init and errors with
		// `duplicate_server_id` (and both default servers fight over the same
		// `mcp/mcp-adapter-default-server` route). We don't use the adapter's
		// default server (we register our own), so drop OUR factory callback
		// before it runs (priority 1, ahead of its priority-10 hook). Woo's
		// own default server is left untouched.
		add_action( 'mcp_adapter_init', static function (): void {
			remove_action(
				'mcp_adapter_init',
				array( \PYS_PRO_GLOBAL\WP\MCP\Servers\DefaultServerFactory::class, 'create' )
			);
		}, 1 );

		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
		add_action( 'mcp_adapter_init', array( $this, 'register_server' ) );

		// Map hyphen ability IDs to the underscore MCP tool names (the WP
		// Abilities API forbids `_` in ability names, but tools use
		// `set_woo_event_config`-style names).
		add_filter( 'mcp_adapter_tool_name', array( ToolNameMap::class, 'filter' ), 10, 2 );

		// Append a neutral language directive to the initialize instructions
		// — best-effort mitigation for response-language drift.
		add_filter( 'mcp_adapter_initialize_response', array( $this, 'add_language_instruction' ), 10, 2 );

		// Register the read-only toggle as a PYS Settings option so the admin
		// page can render it. Defaults to off; existing installs keep their
		// stored value.
		add_action( 'init', static function(): void {
			if ( function_exists( '\\PixelYourSite\\PYS' ) ) {
				\PixelYourSite\PYS()->addOption( Capabilities::OPTION_READ_ONLY_ENABLED, 'checkbox', false );
			}
		}, 11 );

		// Rate-limit + loop fingerprint + repeated-failure detection.
		( new RequestGuard( self::ROUTE_NAMESPACE, self::ROUTE, self::SERVER_ID ) )->register();

		// Audit log of every write-tool call
		( new Provenance( self::SERVER_ID ) )->register();

		// Settings tab UI under PixelYourSite → MCP
		( new AdminPage( self::ROUTE_NAMESPACE, self::ROUTE ) )->register();
	}

	/**
	 * Append a neutral, non-language-naming directive to the `initialize`
	 * instructions, nudging the model to reply in the user's language.
	 * Best-effort only: response-language drift is model-level and not fully
	 * fixable server-side; the directive is deliberately neutral because
	 * naming a specific wrong language in a rule primes the model toward it.
	 * Scoped to our server; other servers' responses pass through untouched.
	 *
	 * @param mixed $result The initialize result DTO.
	 * @param mixed $server The MCP server instance.
	 * @return mixed The (possibly enriched) initialize result DTO.
	 */
	public function add_language_instruction( $result, $server ) {
		if ( ! is_object( $server ) || ! method_exists( $server, 'get_server_id' )
			|| self::SERVER_ID !== $server->get_server_id() ) {
			return $result;
		}
		if ( ! is_object( $result ) || ! method_exists( $result, 'toArray' ) ) {
			return $result;
		}
		$dtoClass = '\\PYS_PRO_GLOBAL\\WP\\McpSchema\\Common\\Protocol\\DTO\\InitializeResult';
		if ( ! class_exists( $dtoClass ) ) {
			return $result;
		}

		$data = $result->toArray();
		$base = isset( $data['instructions'] ) && is_string( $data['instructions'] ) ? trim( $data['instructions'] ) : '';
		$directive = 'Always reply in the same language the user wrote their message in.';
		$data['instructions'] = '' === $base ? $directive : $base . ' ' . $directive;

		return $dtoClass::fromArray( $data );
	}

	/**
	 * Hard requirements: the Abilities API (WP 6.9+) and the prefixed adapter
	 * classes must be available via the composer classmap.
	 *
	 * @return bool True when both dependencies are present.
	 */
	private function dependencies_ready(): bool {
		if ( !function_exists( 'wp_register_ability' ) ) {
			add_action( 'admin_notices', static function(): void {
				echo '<div class="notice notice-error pys-notice"><p><strong>PixelYourSite Pro MCP:</strong> requires WordPress 6.9+ with the Abilities API.</p></div>';
			} );

			return false;
		}

		if ( !class_exists( '\\PYS_PRO_GLOBAL\\WP\\MCP\\Plugin' ) ) {
			add_action( 'admin_notices', static function(): void {
				echo '<div class="notice notice-error pys-notice"><p><strong>PixelYourSite Pro MCP:</strong> prefixed mcp-adapter not found in <code>vendor_prefix/wordpress/</code>. Run the prefix build step.</p></div>';
			} );

			return false;
		}

		return true;
	}

	/**
	 * Boot the prefixed wordpress/mcp-adapter Plugin singleton.
	 * The adapter's own Autoloader expects a standalone vendor/ next to
	 * itself; we short-circuit it because the prefixed composer classmap
	 * already loaded everything.
	 *
	 * @return void
	 */
	private function run_adapter(): void {
		if ( !defined( 'WP_MCP_AUTOLOAD' ) ) {
			define( 'WP_MCP_AUTOLOAD', false );
		}
		if ( !defined( 'WP_MCP_DIR' ) ) {
			define( 'WP_MCP_DIR', PYS_PATH . '/vendor_prefix/wordpress/mcp-adapter' );
		}
		if ( !defined( 'WP_MCP_VERSION' ) ) {
			define( 'WP_MCP_VERSION', self::ADAPTER_VERSION );
		}

		Plugin::instance();
	}

	/**
	 * Register the `pixelyoursite-pro` ability category. Idempotent.
	 *
	 * @return void
	 */
	public function register_category(): void {
		if ( !function_exists( 'wp_register_ability_category' ) ) {
			return;
		}
		if ( function_exists( 'wp_has_ability_category' ) && wp_has_ability_category( self::ABILITY_CATEGORY ) ) {
			return;
		}
		wp_register_ability_category(
			self::ABILITY_CATEGORY,
			array(
				'label'       => 'PixelYourSite Pro',
				'description' => 'Tracking pixel and ecommerce event abilities provided by PixelYourSite Pro.',
			)
		);
	}

	/**
	 * Create the PYS MCP server in the adapter registry; abilities come from
	 * get_abilities().
	 * Transport-level auth replaces the adapter default
	 * (`is_user_logged_in()`) with our Bearer-token check
	 * (Auth::permissionCallback).
	 *
	 * @param mixed $adapter The McpAdapter instance (from `mcp_adapter_init`).
	 * @return void
	 */
	public function register_server( $adapter ): void {
		if ( !$adapter instanceof \PYS_PRO_GLOBAL\WP\MCP\Core\McpAdapter ) {
			return;
		}

		$result = $adapter->create_server(
			self::SERVER_ID,
			self::ROUTE_NAMESPACE,
			self::ROUTE,
			self::SERVER_NAME,
			self::SERVER_DESCRIPTION,
			PYS_VERSION,
			array( \PYS_PRO_GLOBAL\WP\MCP\Transport\HttpTransport::class ),
			PysMcpErrorHandler::class,
			null,
			$this->get_abilities(),
			array(),
			array(), array( Auth::class, 'permissionCallback' )
		);

		if ( is_wp_error( $result ) ) {
			error_log( '[PYS MCP] create_server failed: ' . $result->get_error_message() );
		}
	}

	/**
	 * Register all abilities owned by PYS MCP. Called on
	 * `wp_abilities_api_init`, which fires after
	 * `wp_abilities_api_categories_init` — by then the `pixelyoursite-pro`
	 * category exists, so registration succeeds.
	 *
	 * @return void
	 */
	public function register_abilities(): void {
		Abilities\PingAbility::register();

		Abilities\UsageGuidanceAbility::register();
		Abilities\CredentialSetupInstructionsAbility::register();
		Abilities\AdvancedMatchingConfigAbility::register();
		Abilities\ScanPageForFormFieldsAbility::register();
		Abilities\SetAdvancedMatchingFieldsAbility::register();
		Abilities\SetPlatformCredentialAbility::register();
		Abilities\GetPlatformPixelsAbility::register();
		Abilities\GetWooEventsConfigAbility::register();
		Abilities\SetWooEventConfigAbility::register();
		Abilities\GetEddEventsConfigAbility::register();
		Abilities\SetEddEventConfigAbility::register();
		Abilities\GetAutomaticEventsConfigAbility::register();
		Abilities\SetAutomaticEventConfigAbility::register();
		Abilities\GetSuperPackConfigAbility::register();
		Abilities\SetSuperPackConfigAbility::register();
		Abilities\GetCustomEventsAbility::register();
		Abilities\GetCustomEventAbility::register();
		Abilities\SetCustomEventAbility::register();
		Abilities\ManageCustomEventAbility::register();
		Abilities\GetCatalogFeedAlignmentAbility::register();
		Abilities\GetEddFeedAlignmentAbility::register();
		Abilities\GetAttributionSummaryAbility::register();
		Abilities\GetAttributionDrillAbility::register();
		Abilities\GetTrackingAuditAbility::register();
	}

	/**
	 * Abilities exposed by the PYS MCP server. Each entry must be an ability
	 * ID already registered via `wp_register_ability()` on the
	 * `wp_abilities_api_init` hook (see `register_abilities()`).
	 *
	 * @return array<int, string> Ability IDs.
	 */
	private function get_abilities(): array {
		$abilities = array(
			Abilities\PingAbility::ID,
			Abilities\UsageGuidanceAbility::ID,
			Abilities\CredentialSetupInstructionsAbility::ID,
			Abilities\AdvancedMatchingConfigAbility::ID,
			Abilities\ScanPageForFormFieldsAbility::ID,
			Abilities\SetAdvancedMatchingFieldsAbility::ID,
			Abilities\SetPlatformCredentialAbility::ID,
			Abilities\GetPlatformPixelsAbility::ID,
			Abilities\GetWooEventsConfigAbility::ID,
			Abilities\SetWooEventConfigAbility::ID,
			Abilities\GetEddEventsConfigAbility::ID,
			Abilities\SetEddEventConfigAbility::ID,
			Abilities\GetAutomaticEventsConfigAbility::ID,
			Abilities\SetAutomaticEventConfigAbility::ID,
			Abilities\GetSuperPackConfigAbility::ID,
			Abilities\SetSuperPackConfigAbility::ID,
			Abilities\GetCustomEventsAbility::ID,
			Abilities\GetCustomEventAbility::ID,
			Abilities\SetCustomEventAbility::ID,
			Abilities\ManageCustomEventAbility::ID,
			Abilities\GetCatalogFeedAlignmentAbility::ID,
			Abilities\GetEddFeedAlignmentAbility::ID,
			Abilities\GetAttributionSummaryAbility::ID,
			Abilities\GetAttributionDrillAbility::ID,
			Abilities\GetTrackingAuditAbility::ID,
		);

		return $abilities;
	}
}
