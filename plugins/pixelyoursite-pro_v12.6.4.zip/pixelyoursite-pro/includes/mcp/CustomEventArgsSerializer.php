<?php
/**
 * Reverse serializer: a stored CustomEvent → the admin-POST-shaped `$args` that
 * CustomEvent::update() consumes. Required because update() fully rebuilds from
 * `$args`, so the MCP write path is read → toArgs() → apply patch → update().
 * Platform + event-level data is pass-through (getAllData() keys == arg names);
 * triggers/conditions are rebuilt from their objects via the registry maps.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class CustomEventArgsSerializer {

	private const ARRAY_PIXEL_KEYS = array(
		'facebook_pixel_id',
		'ga_pixel_id',
		'ga_ads_pixel_id',
		'gtm_pixel_id',
		'google_ads_conversion_id',
	);

	/**
	 * Build the full admin-POST `$args` from a stored custom event.
	 *
	 * @param \PixelYourSite\CustomEvent $event Event model.
	 * @return array<string, mixed>
	 */
	public static function toArgs( $event ): array {
		$args = method_exists( $event, 'getAllData' ) ? (array) $event->getAllData() : array();

		// Event-level scalars not held in $data.
		$args[ 'title' ]   = (string) $event->getTitle();
		$args[ 'enabled' ] = $event->isEnabled() ? 1 : 0;

		foreach ( self::ARRAY_PIXEL_KEYS as $k ) {
			if ( isset( $args[ $k ] ) && !is_array( $args[ $k ] ) ) {
				$args[ $k ] = '' === $args[ $k ] ? array() : array( $args[ $k ] );
			}
		}

		if ( !empty( $args[ 'google_ads_phone_numbers' ] ) && is_array( $args[ 'google_ads_phone_numbers' ] ) ) {
			$args[ 'ga_ads_phone_numbers' ] = $args[ 'google_ads_phone_numbers' ];
		}

		// Triggers / conditions: rebuilt from the objects (separate metas).
		$args[ 'triggers' ]   = self::triggersToArgs( $event );
		$args[ 'conditions' ] = self::conditionsToArgs( $event );

		return $args;
	}

	/**
	 * Reconstruct `$args['triggers']` from the event's TriggerEvent objects.
	 *
	 * @param \PixelYourSite\CustomEvent $event Event model.
	 * @return array<int, array<string, mixed>>
	 */
	private static function triggersToArgs( $event ): array {
		$out      = array();
		$triggers = is_array( $event->getTriggers() ) ? $event->getTriggers() : array();
		foreach ( $triggers as $trigger ) {
			if ( !is_object( $trigger ) || !method_exists( $trigger, 'getTriggerType' ) ) {
				continue;
			}
			$out[] = self::triggerToArgs( $trigger );
		}

		return $out;
	}

	/**
	 * Reconstruct ONE trigger's admin-POST shape.
	 *
	 * @param \PixelYourSite\TriggerEvent $t Trigger object.
	 * @return array<string, mixed>
	 */
	private static function triggerToArgs( $t ): array {
		$type = (string) $t->getTriggerType();
		$out  = array( 'trigger_type' => $type );
		$def  = CustomEventTriggerMap::get( $type );

		if ( null === $def ) {
			return self::formPluginToArgs( $t, $out, $type );
		}

		// Rule/value list (page_visit_triggers, url_click_triggers, …).
		if ( !empty( $def[ 'rules_key' ] ) ) {
			$out[ $def[ 'rules_key' ] ] = method_exists( $t, 'getTriggers' ) ? (array) $t->getTriggers() : array();
		}

		// 1:1 params (scalars, bools, *_urls / *_triggers id-lists).
		foreach ( $def[ 'params' ] as $p ) {
			$v = $t->getParam( $p );
			if ( null !== $v ) {
				$out[ $p ] = $v;
			}
		}

		// Array params submitted as a JSON string (video/form data blobs).
		foreach ( $def[ 'json_params' ] as $p ) {
			$v          = $t->getParam( $p );
			$out[ $p ]  = wp_json_encode( is_array( $v ) ? $v : array() );
		}

		// form_field has a nested {form,field,type} block.
		if ( 'form_field' === ( $def[ 'special' ] ?? null ) ) {
			$out[ 'form_field_urls' ] = (array) ( $t->getParam( 'form_field_urls' ) ?: array() );
			$out[ 'form_field_data' ] = wp_json_encode( $t->getParam( 'form_field_data' ) ?: array() );
			$out[ 'form_field' ]      = array(
				'form'  => $t->getParam( 'form_field_forms' ),
				'field' => $t->getParam( 'form_field_fields' ),
				'type'  => $t->getParam( 'form_field_type' ),
			);
			$out[ 'created_via_est' ] = (bool) $t->getParam( 'created_via_est' );
		}

		return $out;
	}

	/**
	 * Best-effort reconstruction of a form-plugin trigger (elementor_form and
	 * other `pys_form_event_factory` types) so existing ones round-trip without
	 * loss. Not first-class in the write schema yet.
	 *
	 * @param \PixelYourSite\TriggerEvent $t    Trigger object.
	 * @param array                       $out  Accumulator with trigger_type set.
	 * @param string                      $type Trigger type slug.
	 * @return array<string, mixed>
	 */
	private static function formPluginToArgs( $t, array $out, string $type ): array {
		$forms = method_exists( $t, 'getForms' ) ? (array) $t->getForms() : array();
		$out[ $type ] = array(
			'forms'                => $forms,
			'disabled_form_action' => (bool) $t->getParam( 'disabled_form_action' ),
			'form_submit_mode'     => $t->getParam( 'form_submit_mode' ) ?: 'both',
		);
		if ( 'elementor_form' === $type ) {
			$out[ 'elementor_form_urls' ] = (array) ( $t->getParam( 'elementor_form_urls' ) ?: array() );
			$out[ 'elementor_form_data' ] = wp_json_encode( $t->getParam( 'elementor_form_data' ) ?: array() );
		}

		return $out;
	}

	/**
	 * Reconstruct `$args['conditions']` from the event's ConditionalEvent objects.
	 *
	 * @param \PixelYourSite\CustomEvent $event Event model.
	 * @return array<int, array<string, mixed>>
	 */
	private static function conditionsToArgs( $event ): array {
		$out        = array();
		$conditions = method_exists( $event, 'getConditions' ) && is_array( $event->getConditions() )
			? $event->getConditions() : array();
		foreach ( $conditions as $condition ) {
			if ( !is_object( $condition ) || !method_exists( $condition, 'getConditionType' ) ) {
				continue;
			}
			$type = (string) $condition->getConditionType();
			$row  = array( 'condition_type' => $type );

			switch ( CustomEventConditionMap::shape( $type ) ) {
				case CustomEventConditionMap::SHAPE_DEVICE:
					$row[ 'device' ] = $condition->getParam( 'device' );
					break;
				case CustomEventConditionMap::SHAPE_USER_ROLE:
					$row[ 'user_role' ] = $condition->getParam( 'user_role' );
					break;
				default: // rule_value — nested under the type key
					$row[ $type ] = array(
						'condition_rule'  => $condition->getParam( 'condition_rule' ),
						'condition_value' => $condition->getParam( 'condition_value' ),
					);
					break;
			}

			$out[] = $row;
		}

		return $out;
	}
}
