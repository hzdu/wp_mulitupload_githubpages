<?php
/**
 * Canonical per-platform event-firing toggle map for WooCommerce / EDD.
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class EventToggleMap {

	public const WOO_EVENTS = array(
		'view_content',
		'view_category',
		'view_cart',
		'view_item_list',
		'add_to_cart',
		'remove_from_cart',
		'initiate_checkout',
		'initiate_checkout_progress_f',
		'initiate_checkout_progress_l',
		'initiate_checkout_progress_e',
		'initiate_checkout_progress_o',
		'select_content',
		'initiate_set_checkout_option',
		'affiliate',
		'paypal',
		'advance_purchase',
		'compete_payment',
		'purchase',
		'FirstTimeBuyer',
		'ReturningCustomer',
		'frequent_shopper',
		'vip_client',
		'big_whale',
	);

	private const WOO_SUPPORT = array(
		'facebook'         => array( 'view_content', 'view_category', 'add_to_cart', 'remove_from_cart', 'advance_purchase', 'initiate_checkout', 'affiliate', 'paypal', 'purchase', 'FirstTimeBuyer', 'ReturningCustomer', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'tiktok'           => array( 'view_content', 'add_to_cart', 'initiate_checkout', 'advance_purchase', 'compete_payment', 'purchase', 'FirstTimeBuyer', 'ReturningCustomer', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'google_analytics' => array( 'view_content', 'view_cart', 'add_to_cart', 'remove_from_cart', 'advance_purchase', 'initiate_set_checkout_option', 'select_content', 'affiliate', 'paypal', 'purchase', 'FirstTimeBuyer', 'ReturningCustomer', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'google_ads'       => array( 'view_content', 'view_category', 'add_to_cart', 'initiate_checkout', 'affiliate', 'purchase', 'FirstTimeBuyer', 'ReturningCustomer', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'pinterest'        => array( 'view_content', 'view_category', 'add_to_cart', 'remove_from_cart', 'initiate_checkout', 'advance_purchase', 'affiliate', 'paypal', 'purchase', 'FirstTimeBuyer', 'ReturningCustomer', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'bing'             => array( 'view_content', 'view_category', 'add_to_cart', 'initiate_checkout', 'purchase', 'FirstTimeBuyer', 'ReturningCustomer', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'reddit'           => array( 'view_content', 'add_to_cart', 'purchase', 'FirstTimeBuyer', 'ReturningCustomer', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'gtm'              => array( 'view_content', 'view_item_list', 'add_to_cart', 'initiate_checkout', 'select_content', 'purchase', 'FirstTimeBuyer', 'ReturningCustomer', 'frequent_shopper', 'vip_client', 'big_whale' ),
	);

	private const EDD_SUPPORT = array(
		'facebook'         => array( 'view_content', 'view_category', 'add_to_cart', 'remove_from_cart', 'initiate_checkout', 'advance_purchase', 'purchase', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'tiktok'           => array( 'view_content', 'add_to_cart', 'initiate_checkout', 'advance_purchase', 'complete_payment', 'purchase', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'google_analytics' => array( 'view_content', 'view_category', 'add_to_cart', 'remove_from_cart', 'initiate_checkout', 'advance_purchase', 'purchase', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'google_ads'       => array( 'view_content', 'view_category', 'add_to_cart', 'initiate_checkout', 'purchase', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'pinterest'        => array( 'view_category', 'add_to_cart', 'remove_from_cart', 'initiate_checkout', 'advance_purchase', 'checkout', 'page_visit', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'bing'             => array( 'view_content', 'view_category', 'add_to_cart', 'initiate_checkout', 'purchase', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'reddit'           => array( 'view_content', 'add_to_cart', 'purchase', 'frequent_shopper', 'vip_client', 'big_whale' ),
		'gtm'              => array( 'view_content', 'view_category', 'add_to_cart', 'remove_from_cart', 'initiate_checkout', 'purchase', 'frequent_shopper', 'vip_client', 'big_whale' ),
	);

	public const EDD_EVENTS = array(
		'view_content',
		'view_category',
		'add_to_cart',
		'remove_from_cart',
		'initiate_checkout',
		'checkout',
		'page_visit',
		'advance_purchase',
		'complete_payment',
		'purchase',
		'frequent_shopper',
		'vip_client',
		'big_whale',
	);

	public const AUTOMATIC_EVENTS = array(
		'internal_link',
		'outbound_link',
		'video',
		'tel_link',
		'email_link',
		'form',
		'signup',
		'login',
		'download',
		'comment',
		'adsense',
		'scroll',
		'time_on_page',
		'search',
		'404',
		'rage_click',
		'video_speed',
	);

	private const GROUPS = array(
		'woo' => array(
			'purchase' => array( 'purchase', 'compete_payment' ),
		),
		'edd' => array(
			'purchase'     => array( 'purchase', 'checkout', 'complete_payment' ),
			'view_content' => array( 'view_content', 'page_visit' ),
		),
	);

	private const DEFAULT_LABELS = array(
		'view_content'                 => 'ViewContent',
		'view_category'                => 'ViewCategory',
		'view_cart'                    => 'ViewCart',
		'view_item_list'               => 'ViewItemList',
		'add_to_cart'                  => 'AddToCart',
		'remove_from_cart'             => 'RemoveFromCart',
		'initiate_checkout'            => 'InitiateCheckout',
		'initiate_checkout_progress_f' => 'CheckoutProgress (first)',
		'initiate_checkout_progress_l' => 'CheckoutProgress (last)',
		'initiate_checkout_progress_e' => 'CheckoutProgress (email)',
		'initiate_checkout_progress_o' => 'CheckoutProgress (order)',
		'select_content'               => 'SelectContent',
		'initiate_set_checkout_option' => 'SetCheckoutOption',
		'affiliate'                    => 'Affiliate',
		'paypal'                       => 'PayPal',
		'advance_purchase'             => 'AdvancePurchase',
		'compete_payment'              => 'CompletePayment',
		'complete_payment'             => 'CompletePayment',
		'checkout'                     => 'Checkout',
		'page_visit'                   => 'PageVisit',
		'purchase'                     => 'Purchase',
		'FirstTimeBuyer'               => 'FirstTimeBuyer',
		'ReturningCustomer'            => 'ReturningCustomer',
		'frequent_shopper'             => 'FrequentShopper',
		'vip_client'                   => 'VIPClient',
		'big_whale'                    => 'BigWhale',
	);

	private const LABEL_OVERRIDES = array(
		'woo.tiktok.purchase'    => 'PlaceAnOrder',
		'woo.pinterest.purchase' => 'Checkout',
		'edd.tiktok.purchase'    => 'PlaceAnOrder',
		'edd.bing.view_content'  => 'PageVisit',
	);

	private const GOOGLE_PLATFORMS = array( 'google_analytics', 'google_ads', 'gtm' );
	private const GOOGLE_LABELS    = array(
		'view_content'                 => 'view_item',
		'view_category'                => 'view_item_list',
		'view_cart'                    => 'view_cart',
		'view_item_list'               => 'view_item_list',
		'add_to_cart'                  => 'add_to_cart',
		'remove_from_cart'             => 'remove_from_cart',
		'initiate_checkout'            => 'begin_checkout',
		'initiate_set_checkout_option' => 'set_checkout_option',
		'initiate_checkout_progress_f' => 'checkout_progress (first name)',
		'initiate_checkout_progress_l' => 'checkout_progress (last name)',
		'initiate_checkout_progress_e' => 'checkout_progress (email)',
		'initiate_checkout_progress_o' => 'checkout_progress (place order)',
		'select_content'               => 'select_item',
		'purchase'                     => 'purchase',
	);

	public const TARGET_PLATFORMS = array(
		'facebook',
		'tiktok',
		'google_analytics',
		'google_ads',
		'pinterest',
		'bing',
		'reddit',
		'gtm',
		'all',
	);

	/**
	 * Canonical event stems for a domain.
	 *
	 * @param string $domain `woo` or `edd`.
	 * @return array<int, string>
	 */
	public static function events( string $domain ): array {
		if ( 'edd' === $domain ) {
			return self::EDD_EVENTS;
		}
		if ( 'automatic' === $domain ) {
			return self::AUTOMATIC_EVENTS;
		}

		return self::WOO_EVENTS;
	}

	/**
	 * Real option key for a domain + event stem. WooCommerce / EDD use
	 * `{domain}_{stem}_enabled`; global automatic events use the
	 * `automatic_event_{stem}_enabled` shape.
	 *
	 * @param string $domain `woo`, `edd` or `automatic`.
	 * @param string $event  Event stem (e.g. `purchase`, `internal_link`).
	 * @return string e.g. `woo_purchase_enabled` / `automatic_event_search_enabled`.
	 */
	public static function key( string $domain, string $event ): string {
		if ( 'automatic' === $domain ) {
			return 'automatic_event_' . $event . '_enabled';
		}

		return $domain . '_' . $event . '_enabled';
	}

	/**
	 * Is `$event` a recognised stem for `$domain`?
	 *
	 * @param string $domain `woo` or `edd`.
	 * @param string $event  Event stem.
	 * @return bool
	 */
	public static function isKnownEvent( string $domain, string $event ): bool {
		return in_array( $event, self::events( $domain ), true );
	}

	/**
	 * Member stems for a logical event. Multi-key events (Purchase, EDD
	 * ViewContent) expand to several; everything else is 1:1.
	 *
	 * @param string $domain `woo` or `edd`.
	 * @param string $event  Logical event / stem name.
	 * @return array<int, string>
	 */
	public static function resolveMembers( string $domain, string $event ): array {
		return self::GROUPS[ $domain ][ $event ] ?? array( $event );
	}

	/**
	 * Logical events that fan out to more than one member stem (for reporting).
	 *
	 * @param string $domain `woo` or `edd`.
	 * @return array<string, array<int, string>>
	 */
	public static function multiKeyGroups( string $domain ): array {
		return self::GROUPS[ $domain ] ?? array();
	}

	private const MASTER_KEY_OVERRIDES = array(
		'woo.advance_purchase.facebook'         => 'woo_advance_purchase_fb_enabled',
		'woo.advance_purchase.google_analytics' => 'woo_advance_purchase_ga_enabled',
		'edd.advance_purchase.facebook'         => 'edd_advance_purchase_fb_enabled',
		'edd.advance_purchase.google_analytics' => 'edd_advance_purchase_ga_enabled',
	);

	/**
	 * The CORE (global) master toggle key that gates an event for a platform.
	 * An event fires only when BOTH this core master AND the per-platform toggle
	 * are on, so enabling a per-platform toggle while the master is off has no
	 * effect — callers use this to auto-enable the master.
	 *
	 * @param string $domain `woo`, `edd` or `automatic`.
	 * @param string $stem   Event stem.
	 * @param string $slug   Platform slug (for the few platform-specific masters).
	 * @return string Core option key.
	 */
	public static function masterKey( string $domain, string $stem, string $slug ): string {
		return self::MASTER_KEY_OVERRIDES[ $domain . '.' . $stem . '.' . $slug ] ?? self::key( $domain, $stem );
	}

	/**
	 * Is this (domain, stem, platform) controlled by a CORE option rather than
	 * a per-module toggle? True for `advance_purchase` on Facebook/GA, whose
	 * only switch is the core `woo_advance_purchase_{fb,ga}_enabled` (no module
	 * key). For these the core key is BOTH the toggle and the master — read and
	 * write go to core (via {@see self::masterKey()}), not the module instance.
	 *
	 * @param string $domain `woo`, `edd` or `automatic`.
	 * @param string $stem   Event stem.
	 * @param string $slug   Platform slug.
	 * @return bool
	 */
	public static function isCoreScoped( string $domain, string $stem, string $slug ): bool {
		return isset( self::MASTER_KEY_OVERRIDES[ $domain . '.' . $stem . '.' . $slug ] );
	}

	/**
	 * Does `$platform` actually expose `$stem` for `$domain`? For woo/edd this
	 * is the AUTHORITATIVE admin support map (not `issetOption()`, which over-
	 * reports vestigial JSON keys — e.g. GTM woo view_cart, GA woo view_category).
	 * For automatic events the module JSON is accurate, so `issetOption()` is
	 * used (requires the Settings instance).
	 *
	 * @param string $domain   `woo`, `edd` or `automatic`.
	 * @param string $slug     Platform slug.
	 * @param string $stem     Event stem.
	 * @param object|null $settings Platform Settings instance (only used for `automatic`).
	 * @return bool
	 */
	public static function platformSupports( string $domain, string $slug, string $stem, $settings = null ): bool {
		if ( 'automatic' === $domain ) {
			return self::platformRegisters( $domain, $slug, $stem, $settings );
		}
		$map = 'edd' === $domain ? self::EDD_SUPPORT : self::WOO_SUPPORT;

		return in_array( $stem, $map[ $slug ] ?? array(), true );
	}

	/**
	 * Whether a platform REGISTERS an automatic event at runtime. The runtime
	 * gate is the module's own `automatic_event_{stem}_enabled` option (each
	 * module's event switch reads it), so a module that does not carry the
	 * key never fires the event — issetOption() is the proxy.
	 *
	 * @param string $domain   Event domain (`automatic` only; others fall back to platformSupports).
	 * @param string $slug     Platform slug.
	 * @param string $stem     Event stem.
	 * @param mixed  $settings The platform's Settings instance.
	 * @return bool
	 */
	public static function platformRegisters( string $domain, string $slug, string $stem, $settings ): bool {
		if ( 'automatic' !== $domain ) {
			return self::platformSupports( $domain, $slug, $stem, $settings );
		}

		return is_object( $settings ) && method_exists( $settings, 'issetOption' )
		       && $settings->issetOption( self::key( $domain, $stem ) );
	}

	/**
	 * Admin-facing label for a (domain, platform, stem).
	 *
	 * @param string $domain   `woo` or `edd`.
	 * @param string $platform Platform slug.
	 * @param string $stem     Event stem.
	 * @return string
	 */
	public static function labelFor( string $domain, string $platform, string $stem ): string {
		$override = self::LABEL_OVERRIDES[ $domain . '.' . $platform . '.' . $stem ] ?? null;
		if ( null !== $override ) {
			return $override;
		}
		// Google platforms use GA4 event names (begin_checkout, view_item, …).
		if ( in_array( $platform, self::GOOGLE_PLATFORMS, true ) && isset( self::GOOGLE_LABELS[ $stem ] ) ) {
			return self::GOOGLE_LABELS[ $stem ];
		}

		return self::DEFAULT_LABELS[ $stem ] ?? $stem;
	}

	/**
	 * Per-platform matrix of registered event toggles and their current state.
	 * Only active platforms that register at least one of the domain's event
	 * keys are included.
	 *
	 * @param string $domain `woo` or `edd`.
	 * @return array<string, array<string, bool>> slug => { stem => enabled }.
	 */
	public static function platformMatrix( string $domain ): array {
		$pys    = function_exists( '\\PixelYourSite\\PYS' ) ? \PixelYourSite\PYS() : null;
		$matrix = array();
		foreach ( Platforms::activeSettings() as $slug => $settings ) {
			if ( !method_exists( $settings, 'issetOption' ) ) {
				continue;
			}
			$row = array();
			foreach ( self::events( $domain ) as $event ) {
				if ( !self::platformSupports( $domain, $slug, $event, $settings ) ) {
					continue;
				}
				// Core-scoped events (advance_purchase fb/ga) read the core key.
				if ( self::isCoreScoped( $domain, $event, $slug ) && null !== $pys ) {
					$row[ $event ] = self::toBool( $pys->getOption( self::masterKey( $domain, $event, $slug ) ) );
				} else {
					$row[ $event ] = self::toBool( $settings->getOption( self::key( $domain, $event ) ) );
				}
			}
			if ( !empty( $row ) ) {
				$matrix[ $slug ] = $row;
			}
		}

		return $matrix;
	}

	/**
	 * Per-platform admin labels for the registered stems (mirror of
	 * {@see self::platformMatrix()} carrying labels instead of state) so callers
	 * can map UI wording (e.g. "PlaceAnOrder") to the right (platform, stem).
	 *
	 * @param string $domain `woo` or `edd`.
	 * @return array<string, array<string, string>> slug => { stem => label }.
	 */
	public static function labelMatrix( string $domain ): array {
		$out = array();
		foreach ( Platforms::activeSettings() as $slug => $settings ) {
			if ( !method_exists( $settings, 'issetOption' ) ) {
				continue;
			}
			$row = array();
			foreach ( self::events( $domain ) as $event ) {
				if ( self::platformSupports( $domain, $slug, $event, $settings ) ) {
					$row[ $event ] = self::labelFor( $domain, $slug, $event );
				}
			}
			if ( !empty( $row ) ) {
				$out[ $slug ] = $row;
			}
		}

		return $out;
	}

	/**
	 * Coerce a mixed option value to bool (checkbox values are `'1'` / bool).
	 *
	 * @param mixed $value Raw option value.
	 * @return bool
	 */
	public static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}
