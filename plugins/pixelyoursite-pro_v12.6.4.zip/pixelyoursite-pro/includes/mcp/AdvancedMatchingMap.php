<?php
/**
 * Per-platform advanced/enhanced-matching opt-in map. Each pixel platform
 * has its OWN matching switch, named differently and stored differently from
 * the GLOBAL field-name lists ({@see Abilities\AdvancedMatchingConfigAbility}):
 *
 * @package PixelYourSite\MCP
 */

declare( strict_types = 1 );

namespace PixelYourSite\MCP;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

final class AdvancedMatchingMap {

	private const MAP = array(
		'facebook'         => array(
			'key'   => 'advanced_matching_enabled',
			'label' => 'Advanced Matching',
		),
		'tiktok'           => array(
			'key'   => 'advanced_matching_enabled',
			'label' => 'Advanced Matching',
		),
		'pinterest'        => array(
			'key'   => 'enhanced_matching_enabled',
			'label' => 'Enhanced Matching',
		),
		'bing'             => array(
			'key'   => 'enhanced_conversions_enabled',
			'label' => 'Enhanced Conversions',
		),
		'google_analytics' => array(
			'key'   => 'send_user_provided_data',
			'label' => 'User-Provided Data',
			'sub'   => array(
				'send_multiple_values' => 'use_multiple_provided_data',
				'use_encoding'         => 'use_encoding_provided_data',
			),
		),
		'gtm'              => array(
			'key'   => 'send_user_provided_data',
			'label' => 'User-Provided Data',
			'sub'   => array(
				'send_multiple_values' => 'use_multiple_provided_data',
			),
		),
		'google_ads'       => array(
			'key'    => 'enhanced_conversions_manual_enabled',
			'label'  => 'Enhanced Conversions (manual)',
			'marker' => 'index_0', // primary-pixel marker in the per-pixel array
		),
	);

	/**
	 * Platform slugs that have a per-platform matching switch.
	 *
	 * @return array<int, string>
	 */
	public static function platforms(): array {
		return array_keys( self::MAP );
	}

	/**
	 * Whether a platform has a per-platform matching switch.
	 *
	 * @param string $slug Platform slug.
	 * @return bool
	 */
	public static function has( string $slug ): bool {
		return isset( self::MAP[ $slug ] );
	}

	/**
	 * Human-facing label for a platform's matching switch.
	 *
	 * @param string $slug Platform slug.
	 * @return string
	 */
	public static function label( string $slug ): string {
		return (string) ( self::MAP[ $slug ][ 'label' ] ?? 'Matching' );
	}

	/**
	 * Public sub-option name => real key for a platform (empty if none).
	 *
	 * @param string $slug Platform slug.
	 * @return array<string, string>
	 */
	public static function subOptions( string $slug ): array {
		return isset( self::MAP[ $slug ][ 'sub' ] ) && is_array( self::MAP[ $slug ][ 'sub' ] )
			? self::MAP[ $slug ][ 'sub' ]
			: array();
	}

	/**
	 * Read the current matching state for a platform.
	 *
	 * @param string $slug     Platform slug.
	 * @param object $settings The platform's Settings instance.
	 * @return array{enabled:bool, label:string, sub_options?:array<string,bool>}
	 */
	public static function readState( string $slug, $settings ): array {
		$out = array(
			'enabled' => self::readMaster( $slug, $settings ),
			'label'   => self::label( $slug ),
		);

		$sub = self::subOptions( $slug );
		if ( !empty( $sub ) ) {
			$subOut = array();
			foreach ( $sub as $publicName => $realKey ) {
				$subOut[ $publicName ] = self::toBool( $settings->getOption( $realKey ) );
			}
			$out[ 'sub_options' ] = $subOut;
		}

		return $out;
	}

	/**
	 * Read the master matching toggle, resolving the google_ads per-pixel
	 * marker array (primary pixel = the `index_0` marker is present).
	 *
	 * @param string $slug     Platform slug.
	 * @param object $settings The platform's Settings instance.
	 * @return bool
	 */
	public static function readMaster( string $slug, $settings ): bool {
		$spec = self::MAP[ $slug ] ?? null;
		if ( null === $spec ) {
			return false;
		}
		$raw = $settings->getOption( $spec[ 'key' ] );
		if ( isset( $spec[ 'marker' ] ) ) {
			return is_array( $raw ) && in_array( $spec[ 'marker' ], $raw, true );
		}

		return self::toBool( $raw );
	}

	/**
	 * Build the option payload that writes the master toggle for a platform.
	 * For google_ads it adds/removes the primary `index_0` marker while
	 * preserving the other pixels' markers (the array sanitiser strips empties
	 * and de-dupes these string markers harmlessly).
	 *
	 * @param string $slug     Platform slug.
	 * @param object $settings The platform's Settings instance.
	 * @param bool   $enabled  Desired master state.
	 * @return array<string, mixed> Real key => value, ready for updateOptions().
	 */
	public static function masterPayload( string $slug, $settings, bool $enabled ): array {
		$spec = self::MAP[ $slug ] ?? null;
		if ( null === $spec ) {
			return array();
		}
		if ( isset( $spec[ 'marker' ] ) ) {
			$marker = $spec[ 'marker' ];
			$raw    = $settings->getOption( $spec[ 'key' ] );
			$arr    = array_values( array_filter(
				is_array( $raw ) ? $raw : array(),
				static function( $v ): bool {
					return is_string( $v ) && '' !== $v;
				}
			) );
			$has    = in_array( $marker, $arr, true );
			if ( $enabled && !$has ) {
				$arr[] = $marker;
			} elseif ( !$enabled && $has ) {
				$arr = array_values( array_filter( $arr, static function( $v ) use ( $marker ): bool {
					return $v !== $marker;
				} ) );
			}

			return array( $spec[ 'key' ] => $arr );
		}

		return array( $spec[ 'key' ] => $enabled );
	}

	/**
	 * Real option key for a platform's master toggle.
	 *
	 * @param string $slug Platform slug.
	 * @return string|null
	 */
	public static function masterKey( string $slug ): ?string {
		return isset( self::MAP[ $slug ] ) ? (string) self::MAP[ $slug ][ 'key' ] : null;
	}

	/**
	 * Normalise a stored flag (PYS stores bools as bool/'1'/1/'true').
	 *
	 * @param mixed $value Raw option value.
	 * @return bool
	 */
	public static function toBool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) ) {
			return '1' === $value || 'true' === strtolower( $value );
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		return false;
	}
}