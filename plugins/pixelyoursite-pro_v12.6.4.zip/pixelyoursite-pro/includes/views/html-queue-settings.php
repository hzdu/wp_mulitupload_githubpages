<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

?>

<?php
$pys_cron_health = EventsQueue()->getCronHealth();

$pys_health_style = array(
    'ok'      => array( 'bg' => '#eef7ee', 'border' => '#4caf50', 'label' => __( 'Delivery is healthy', 'pys' ) ),
    'info'    => array( 'bg' => '#eef4fb', 'border' => '#5b9dd9', 'label' => __( 'Queue disabled', 'pys' ) ),
    'warning' => array( 'bg' => '#fff8e1', 'border' => '#f0ad4e', 'label' => __( 'Delivery needs attention', 'pys' ) ),
    'error'   => array( 'bg' => '#fdecea', 'border' => '#d9534f', 'label' => __( 'Events are not being delivered', 'pys' ) ),
);
$pys_style = isset( $pys_health_style[ $pys_cron_health['level'] ] )
    ? $pys_health_style[ $pys_cron_health['level'] ]
    : $pys_health_style['info'];
?>

<div class="cards-wrapper cards-wrapper-style2 gap-24 setting-wrapper">

    <!-- Delivery health: is WP-Cron actually draining the queue? -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e( 'Event Delivery Health', 'pys' ); ?></h4>
        </div>
        <div class="card-body">
            <div class="pys-notice pys-notice-<?php echo esc_attr( $pys_cron_health['level'] === 'ok' ? 'success' : $pys_cron_health['level'] ); ?>"
                 style="background:<?php echo esc_attr( $pys_style['bg'] ); ?>;border-left:4px solid <?php echo esc_attr( $pys_style['border'] ); ?>;padding:12px 16px;border-radius:4px;">
                <strong><?php echo esc_html( $pys_style['label'] ); ?></strong>
                <?php foreach ( $pys_cron_health['messages'] as $pys_message ) : ?>
                    <p class="mt-2 mb-0"><?php echo esc_html( $pys_message['text'] ); ?></p>
                <?php endforeach; ?>
            </div>

            <?php if ( $pys_cron_health['enabled'] ) : ?>
                <table class="mt-16" style="border-collapse:collapse;">
                    <tr>
                        <td class="text-gray" style="padding:2px 16px 2px 0;"><?php _e( 'Next scheduled run:', 'pys' ); ?></td>
                        <td>
                            <?php
                            if ( $pys_cron_health['next_run'] ) {
                                $pys_next = (int) $pys_cron_health['next_run'];
                                // wp_next_scheduled() returns a UTC timestamp; wp_date()
                                // renders it in the site timezone without manual offsets.
                                printf(
                                    '%s (%s)',
                                    esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $pys_next ) ),
                                    $pys_next > time()
                                        ? esc_html( sprintf( __( 'in %s', 'pys' ), human_time_diff( time(), $pys_next ) ) )
                                        : esc_html( sprintf( __( 'overdue by %s', 'pys' ), human_time_diff( $pys_next, time() ) ) )
                                );
                            } else {
                                echo '<strong>' . esc_html__( 'not scheduled', 'pys' ) . '</strong>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-gray" style="padding:2px 16px 2px 0;"><?php _e( 'Processing interval:', 'pys' ); ?></td>
                        <td><?php echo esc_html( human_time_diff( 0, (int) $pys_cron_health['interval'] ) ); ?></td>
                    </tr>
                    <tr>
                        <td class="text-gray" style="padding:2px 16px 2px 0;"><?php _e( 'Events waiting:', 'pys' ); ?></td>
                        <td>
                            <?php
                            echo (int) $pys_cron_health['pending'];
                            if ( $pys_cron_health['oldest_pending_age'] !== null ) {
                                printf( ' — %s',
                                    esc_html( sprintf( __( 'oldest waiting for %s', 'pys' ),
                                        human_time_diff( time() - (int) $pys_cron_health['oldest_pending_age'], time() ) ) ) );
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-gray" style="padding:2px 16px 2px 0;"><?php _e( 'WP-Cron constants:', 'pys' ); ?></td>
                        <td>
                            <?php
                            $pys_flags = array();
                            if ( $pys_cron_health['disable_wp_cron'] ) {
                                $pys_flags[] = 'DISABLE_WP_CRON';
                            }
                            if ( $pys_cron_health['alternate_wp_cron'] ) {
                                $pys_flags[] = 'ALTERNATE_WP_CRON';
                            }
                            if ( $pys_flags ) {
                                $pys_flags = array_map( function ( $flag ) {
                                    return '<code>' . esc_html( $flag ) . '</code>';
                                }, $pys_flags );
                                echo implode( ', ', $pys_flags );
                            } else {
                                echo esc_html__( 'none set (default WP-Cron)', 'pys' );
                            }
                            ?>
                        </td>
                    </tr>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Queue System Status -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Queue System Status', 'pys'); ?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('queue_enabled'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Enable Queue System', 'pys'); ?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Server-side events are written to a queue and delivered in batches by WP-Cron, instead of being sent while the visitor waits. Keep this on: it is what stops a slow platform API from holding up a page or a checkout request. Delivery then depends on WP-Cron, so keep an eye on Event Delivery Health above.', 'pys'); ?>
                    </p>
                </div>

                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('queue_use_for_ajax'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Also Queue Our Own AJAX and REST Events', 'pys'); ?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('Events fired during requests PixelYourSite does not control — WooCommerce AJAX such as adding an order bump on the checkout, or a normal page render — always go through the queue, whatever this setting says. Our own AJAX and REST endpoints are the exception: they hand the response back to the browser before sending, so nobody is kept waiting. Turn this on to route those through the queue as well.', 'pys'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Processing Configuration -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Processing Configuration', 'pys'); ?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div class="d-flex align-items-center number-option-block">
                    <label class="primary_heading"><?php _e('Max Events Per Batch:', 'pys'); ?></label>
                    <?php PYS()->render_number_input('queue_max_events_per_batch', '', false, 1000, 1); ?>
                </div>
                <p class="text-gray">
                    <?php _e('Maximum number of events to process in one batch (1-1000). Higher values may improve performance but use more memory.', 'pys'); ?>
                </p>

                <div>
                    <h4 class="primary_heading mb-4"><?php _e('Processing Interval:', 'pys'); ?></h4>
                    <?php PYS()->render_select_input( 'queue_processing_interval', array(
                        60 => __('1 minute', 'pys'),
                        300 => __('5 minutes', 'pys'),
                        600 => __('10 minutes', 'pys'),
                        900 => __('15 minutes', 'pys'),
                        1800 => __('30 minutes', 'pys'),
                        3600 => __('1 hour', 'pys')
                    ) ); ?>

                    <p class="text-gray mt-4">
                        <?php _e('How often to process the events queue. More frequent processing provides faster event delivery but uses more server resources.', 'pys'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Queue Limits -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Queue Limits', 'pys'); ?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div class="d-flex align-items-center number-option-block">
                    <label class="primary_heading"><?php _e('Max Queue Size:', 'pys'); ?></label>
                    <?php PYS()->render_number_input('queue_max_size', '', false, 100000, 100); ?>
                </div>
                <p class="text-gray">
                    <?php _e('Maximum number of events in queue before dropping new events (100-100000). Prevents memory issues during high traffic periods.', 'pys'); ?>
                </p>

                <div class="d-flex align-items-center number-option-block">
                    <label class="primary_heading"><?php _e('Max Retries:', 'pys'); ?></label>
                    <?php PYS()->render_number_input('queue_max_retries', '', false, 10, 0); ?>
                </div>
                <p class="text-gray">
                    <?php _e('Maximum number of retry attempts for failed events (0-10). Failed events will be retried this many times before being marked as permanently failed.', 'pys'); ?>
                </p>

            </div>
        </div>
    </div>

    <!-- Auto Cleanup Settings -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Auto Cleanup Settings', 'pys'); ?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div class="d-flex align-items-center number-option-block">
                    <label class="primary_heading"><?php _e('Pending Events Cleanup Days:', 'pys'); ?></label>
                    <?php PYS()->render_number_input('queue_pending_cleanup_days', '', false, 30, 0); ?>
                </div>
                <p class="text-gray">
                    <?php _e('Number of days after which pending (stuck) events will be automatically deleted (0-30). Set to 0 to disable automatic cleanup of pending events. Default: 1 day.', 'pys'); ?>
                </p>
                <p class="text-gray mt-2">
                    <strong><?php _e('Note:', 'pys'); ?></strong>
                    <?php _e('Automatic cleanup runs daily. Pending events older than the specified number of days will be removed to prevent queue overflow from stuck events.', 'pys'); ?>
                </p>

                <div class="d-flex align-items-center number-option-block">
                    <label class="primary_heading"><?php _e('Retention Days:', 'pys'); ?></label>
                    <?php PYS()->render_number_input('queue_retention_days', '', false, 30, 1); ?>
                </div>
                <p class="text-gray">
                    <?php _e('Number of days to keep processed/failed events in the database (1-30). Older events will be automatically cleaned up to save space.', 'pys'); ?>
                </p>

                <hr class="my-4">

                <div>
                    <div class="d-flex align-items-center">
                        <?php PYS()->render_switcher_input('queue_drop_table_on_deactivate'); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Drop Queue Table on Plugin Deactivation', 'pys'); ?></h4>
                    </div>
                    <p class="text-gray mt-4">
                        <?php _e('If enabled, the queue database table will be completely removed when the plugin is deactivated. This will permanently delete all queued events. Use with caution.', 'pys'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Queue Statistics -->
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Queue Statistics', 'pys'); ?></h4>
            <div class="queue-actions">
                <button type="button" id="refresh-stats" class="btn btn-sm btn-outline-primary">
                    <i class="fa fa-refresh"></i> <?php _e('Refresh', 'pys'); ?>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <?php 
                // Get all queue statistics in one optimized call
                $all_stats = EventsQueue()->getAllQueueStats();
                ?>
                <div class="queue-stats-grid" id="queue-stats-container">
                    <div class="stat-card stat-pending">
                        <h3 class="stat-number" id="pending-count"><?php echo $all_stats['pending'] ?? 0; ?></h3>
                        <p class="stat-label"><?php _e('Pending Events', 'pys'); ?></p>
                    </div>
                    <div class="stat-card stat-processed">
                        <h3 class="stat-number" id="processed-count"><?php echo $all_stats['processed'] ?? 0; ?></h3>
                        <p class="stat-label"><?php _e('Processed Today', 'pys'); ?></p>
                    </div>
                    <div class="stat-card stat-failed">
                        <h3 class="stat-number" id="failed-count"><?php echo $all_stats['failed'] ?? 0; ?></h3>
                        <p class="stat-label"><?php _e('Failed Events', 'pys'); ?></p>
                    </div>
                    <div class="stat-card stat-total">
                        <h3 class="stat-number" id="total-count"><?php echo $all_stats['total'] ?? 0; ?></h3>
                        <p class="stat-label"><?php _e('Total Events', 'pys'); ?></p>
                    </div>
                </div>
                
                <div class="row queue-status-info">
                    <div class="col-md-6">
                        <p class="text-gray mb-12">
                            <strong><?php _e('Last Processed:', 'pys'); ?></strong>
                            <span id="last-processed"><?php echo $all_stats['last_processed']; ?></span>
                        </p>
                        <p class="text-gray mb-2">
                            <strong><?php _e('Queue Status:', 'pys'); ?></strong>
                            <span id="queue-status" class="queue-status <?php echo $all_stats['queue_status']; ?>">
                                <?php echo $all_stats['queue_status_text']; ?>
                            </span>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <p class="text-gray mb-12">
                            <strong><?php _e('Processing Rate:', 'pys'); ?></strong>
                            <span id="processing-rate"><?php echo $all_stats['processing_rate']; ?></span> <?php _e('events/min (last 1 hour)', 'pys'); ?>
                        </p>
                        <p class="text-gray mb-2">
                            <strong><?php _e('Success Rate:', 'pys'); ?></strong>
                            <span id="success-rate"><?php echo $all_stats['success_rate']; ?>%</span>
                        </p>
                    </div>
                </div>
                
                <div class="row queue-management-actions">
                    <div class="d-flex gap-3 flex-wrap">
                        <button type="button" id="manual-process-queue" class="btn btn-primary">
                            <i class="fa fa-play"></i> <?php _e('Process Queue Now', 'pys'); ?>
                        </button>
                        <button type="button" id="clear-old-records" class="btn btn-warning">
                            <i class="fa fa-trash"></i> <?php _e('Clear Old Records', 'pys'); ?>
                        </button>
                        <button type="button" id="reset-failed-events" class="btn btn-secondary">
                            <i class="fa fa-refresh"></i> <?php _e('Reset Failed Events', 'pys'); ?>
                        </button>
                    </div>
                    <p class="text-gray mt-3">
                        <?php _e('Use these actions to manually manage your event queue. Process Queue Now will immediately start processing pending events. Clear Old Records will remove processed events older than the retention period.', 'pys'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
