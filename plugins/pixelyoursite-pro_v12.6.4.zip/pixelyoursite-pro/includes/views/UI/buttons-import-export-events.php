<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<div class="export-import-buttons mb-24">
    <input type="hidden" id="import_events_file_nonce" value="<?=wp_create_nonce("import_events_file_nonce")?>"/>
    <input type="file" id="import_events_file" name="import_events_file" accept="application/json"/>
    <label for="import_events_file" class="btn-small btn-gray btn-small-icon secondary_heading"><i class="icon-import"></i>Import Events</label>
    <a href="<?php echo esc_url( $export_url ); ?>" target="_blank" class="btn-small btn-gray btn-small-icon secondary_heading"><i class="icon-export"></i>Export Events</a>
</div>

<?php
$site_profile_url = class_exists( '\PixelYourSite\SiteProfileAdmin' )
	? admin_url( 'admin.php?page=' . SiteProfileAdmin::PAGE_SLUG )
	: '';

$import_first = $site_profile_url !== ''
	? 'import those pixels first via <a href="' . esc_url( $site_profile_url ) . '">Site Profile &rsaquo; Import</a>'
	: 'import those pixels first';

renderWarningMessage(
	'Some events can be assigned to a specific pixel ID. Before importing events scoped to specific pixels, '
	. $import_first
	. ' so the IDs exist on this site — otherwise those events won&rsquo;t fire.'
);
?>