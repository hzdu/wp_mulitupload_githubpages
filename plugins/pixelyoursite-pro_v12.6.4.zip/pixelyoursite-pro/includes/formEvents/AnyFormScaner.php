<?php

namespace PixelYourSite;

/**
 * Form scanner — fetches own-site page URLs and extracts `<form>` field
 * descriptors (name / id / type / selector / titles).
 *
 * Two integration paths:
 *
 *  - **Admin UI** (`wp_ajax_pys_scan_any_form`) — the original entry,
 *    nonce + `manage_pys` capability check, returns `wp_send_json_*`.
 *    `scan_handler()` below.
 *
 *  - **Programmatic** (`scanUrl()` / `scanUrls()`) — pure functions
 *    returning structured arrays, no JSON / no nonce checks. Phase 3.4's
 *    MCP ability (`scan_page_for_form_fields`) calls this path after its
 *    own SSRF / same-origin guards.
 *
 * The `pys_fake_cart` query param + `template_redirect` action populate the
 * cart so a checkout page renders its full billing form. They are appended
 * ONLY for checkout URLs (see `is_checkout_url()`); other pages are fetched
 * clean, since stray query args can break them (e.g. a 404 on `/contact`).
 */
class AnyFormScanner {

    private static $_instance;

    private $dom;

    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    public function __construct() {
        add_action( 'wp_ajax_pys_scan_any_form', [ $this, 'scan_handler' ] );

        add_action( 'template_redirect', function () {
            if ( isset( $_GET['pys_fake_cart'] ) && is_checkout() ) {
                if ( WC()->cart && WC()->cart->is_empty() ) {
                    $product_id = $this->pys_get_first_simple_product_id();

                    if ( $product_id ) {
                        WC()->cart->add_to_cart( $product_id, 1 );
                    }
                }
            }
            if ( isset($_GET['pys_fake_cart']) && function_exists( 'edd_is_checkout' ) &&
                edd_is_checkout() && !edd_get_cart_contents() ) {

                $download_id = $this->pys_get_first_edd_download_id();

                if ( $download_id ) {
                    edd_empty_cart(); // очистим на всякий случай
                    edd_add_to_cart( $download_id );
                }
            }
        }, 1 );
    }

    public function scan_handler() {
        if ( ! current_user_can( 'manage_pys' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $nonce = $_REQUEST['_wpnonce'] ?? null;
        if ( ! wp_verify_nonce( $nonce, 'pys_update_event' ) && ! wp_verify_nonce( $nonce, 'pys_save_settings' ) ) {
            wp_send_json_error( 'Invalid nonce', 403 );
        }

        $urls = isset( $_POST['urls'] ) ? $_POST['urls'] : [];

        if ( empty( $urls ) || ! is_array( $urls ) ) {
            wp_send_json_error( 'Invalid URLs' );
        }

        wp_send_json_success( $this->scanUrls( $urls ) );
    }

    /**
     * Programmatic scan of a single URL. No nonce / capability checks —
     * the caller is responsible for authorisation. Pure: returns an
     * array, never echoes / dies.
     *
     * `$fetchOptions` is merged into `wp_safe_remote_get()` args. Phase
     * 3.4's MCP ability passes strict SSRF opts (`redirection => 0`,
     * `limit_response_size => 2_097_152`); the admin AJAX path leaves them
     * empty and uses the default 5-s timeout + WP-default redirect handling.
     *
     * @param string $url           Absolute URL on the same origin as the WP site.
     *                              SSRF / same-origin validation is the caller's
     *                              responsibility before invoking this method.
     * @param array  $fetchOptions  Extra args forwarded to `wp_safe_remote_get()`.
     * @return array{url:string, forms?:array, error?:string}
     */
    public function scanUrl( $url, array $fetchOptions = [] ) {
        $parsed_url = wp_parse_url( $url );
        if ( empty( $parsed_url['scheme'] ) || empty( $parsed_url['host'] ) ) {
            return [
                'url'   => (string) $url,
                'error' => 'Invalid URL — scheme and host are required.',
            ];
        }

        $path = $parsed_url['path'] ?? '/';
        $clean_url = rtrim( $parsed_url['scheme'] . '://' . $parsed_url['host'] . $path, '/' );

        $fetch_url = $this->is_checkout_url( $path )
            ? add_query_arg(
                [
                    'pys_fake_cart'             => 1,
                    'ship_to_different_address' => 1,
                ],
                $clean_url
            )
            : $clean_url;

        $html = $this->fetch_url_content( $fetch_url, $fetchOptions );
        if ( ! $html ) {
            return [
                'url'   => $fetch_url,
                'error' => 'Failed to fetch content',
            ];
        }

        return [
            'url'   => $url,
            'forms' => $this->parse_forms( $html ),
        ];
    }

    /**
     * Programmatic batch scan. Each entry in `$urls` is processed by
     * {@see scanUrl()} and the results are returned in the same order.
     *
     * @param array<int, string> $urls
     * @param array              $fetchOptions Forwarded to each `scanUrl()` call.
     * @return array<int, array{url:string, forms?:array, error?:string}>
     */
    public function scanUrls( array $urls, array $fetchOptions = [] ): array {
        $results = [];
        foreach ( $urls as $url ) {
            $results[] = $this->scanUrl( (string) $url, $fetchOptions );
        }
        return $results;
    }

    /**
     * Is `$path` the WooCommerce or EDD checkout page? Compared against the
     * real checkout URL when those plugins are active, with a path-substring
     * fallback. Only checkout pages need the fake-cart query params.
     *
     * @param string $path URL path of the page being scanned.
     * @return bool
     */
    private function is_checkout_url( string $path ): bool {
        $needle = trim( strtolower( $path ), '/' );

        $candidates = [];
        if ( function_exists( 'wc_get_checkout_url' ) ) {
            $candidates[] = wp_parse_url( wc_get_checkout_url(), PHP_URL_PATH );
        }
        if ( function_exists( 'edd_get_checkout_uri' ) ) {
            $candidates[] = wp_parse_url( edd_get_checkout_uri(), PHP_URL_PATH );
        }
        foreach ( $candidates as $candidate ) {
            if ( is_string( $candidate ) && '' !== $needle && trim( strtolower( $candidate ), '/' ) === $needle ) {
                return true;
            }
        }

        // Fallback heuristic for custom setups.
        return false !== strpos( $needle, 'checkout' );
    }

    private function fetch_url_content( $url, array $opts = [] ) {
        $args = array_merge( [ 'timeout' => 5 ], $opts );
        $response = wp_safe_remote_get( $url, $args );
        if ( is_wp_error( $response ) ) {
            return false;
        }

        return wp_remote_retrieve_body( $response );
    }

    private function parse_forms( $html ) {
        libxml_use_internal_errors( true );
        $this->dom = new \DOMDocument();
        $this->dom->loadHTML( $html );
        $xpath = new \DOMXPath( $this->dom );

        $forms = $this->dom->getElementsByTagName( 'form' );

        $results = [];

        foreach ( $forms as $form ) {
            $form_info = [];

            // Найти заголовок формы: H1 > H2 > ID/class
            $form_info['title'] = $this->find_form_title( $form, $xpath );
            $form_info['attributes'] = [
                'id'    => $form->getAttribute( 'id' ),
                'class' => $form->getAttribute( 'class' ),
                'action' => $form->getAttribute( 'action' ),
                'method' => $form->getAttribute( 'method' ),
            ];
            $form_info['selector'] = $this->generate_css_selector( $form );


            $fields = [];
            $field_tags = ['input', 'textarea', 'select'];

            foreach ( $field_tags as $tag ) {
                $elements = $form->getElementsByTagName( $tag );

                foreach ( $elements as $el ) {
                    $type = '';

                    if($el->getAttribute('type') === 'hidden') {
                        continue; // Пропускаем скрытые поля
                    }

                    if ( $tag === 'input' ) {
                        // если не указан, по умолчанию — text
                        $type = $el->hasAttribute('type')
                            ? $el->getAttribute('type')
                            : 'text';
                    } elseif ( $tag === 'textarea' ) {
                        $type = 'textarea';
                    } elseif ( $tag === 'select' ) {
                        $type = 'select';
                    }

                    $field = [
                        'tag'         => $tag,
                        'name'        => $el->getAttribute( 'name' ),
                        'id'          => $el->getAttribute( 'id' ),
                        'class'       => $el->getAttribute( 'class' ),
                        'type'        => $type,
                        'label'       => $this->find_field_label( $el, $xpath ),
                    ];

                    // Уникальный селектор
                    $field['selector'] = $this->generate_css_selector( $el );

                    $fields[] = $field;
                }
            }

            $form_info['fields'] = $fields;
            $results[] = $form_info;
        }

        return $results;
    }

    /**
     * Best-effort visible label for a form field. Falls back through:
     *   1. `<label for="<id>">…</label>` matching the field's `id`.
     *   2. Wrapping `<label>` ancestor (up to depth 5).
     *   3. `aria-label` attribute.
     *   4. `placeholder` attribute.
     *
     * Returns `''` when nothing usable is found.
     */
    private function find_field_label( \DOMElement $el, \DOMXPath $xpath ): string {
        $id = $el->getAttribute( 'id' );

        // 1. <label for="id">…</label> anywhere in document.
        if ( '' !== $id ) {
            $quoted = $this->xpath_quote( $id );
            $labels = $xpath->query( '//label[@for=' . $quoted . ']' );
            if ( $labels instanceof \DOMNodeList && $labels->length > 0 ) {
                $text = trim( $labels->item( 0 )->textContent );
                if ( '' !== $text ) {
                    return $text;
                }
            }
        }

        // 2. Wrapping <label> ancestor.
        $current = $el->parentNode;
        $depth = 0;
        while ( $current instanceof \DOMElement && $depth < 5 ) {
            if ( 'label' === strtolower( $current->nodeName ) ) {
                $text = trim( $current->textContent );
                if ( '' !== $text ) {
                    return $text;
                }
                break;
            }
            if ( 'form' === strtolower( $current->nodeName ) ) {
                break;
            }
            $current = $current->parentNode;
            $depth++;
        }

        // 3. aria-label.
        if ( $el->hasAttribute( 'aria-label' ) ) {
            $text = trim( $el->getAttribute( 'aria-label' ) );
            if ( '' !== $text ) {
                return $text;
            }
        }

        // 4. placeholder.
        if ( $el->hasAttribute( 'placeholder' ) ) {
            $text = trim( $el->getAttribute( 'placeholder' ) );
            if ( '' !== $text ) {
                return $text;
            }
        }

        return '';
    }

    /**
     * Quote a string for safe inclusion in an XPath expression. Handles
     * the awkward case of values containing both single and double quotes
     * via `concat()`. Most form IDs are sane (alphanumeric / hyphen /
     * underscore), so the fast paths cover almost everything.
     */
    private function xpath_quote( string $value ): string {
        if ( false === strpos( $value, '"' ) ) {
            return '"' . $value . '"';
        }
        if ( false === strpos( $value, "'" ) ) {
            return "'" . $value . "'";
        }
        // Both quote types present — use concat() to splice the string.
        $parts = explode( '"', $value );
        $out   = [];
        foreach ( $parts as $i => $part ) {
            $out[] = '"' . $part . '"';
            if ( $i < count( $parts ) - 1 ) {
                $out[] = "'\"'";
            }
        }
        return 'concat(' . implode( ',', $out ) . ')';
    }

    private function find_form_title( \DOMElement $form ) {
        $max_depth = 2;
        $current   = $form->parentNode;

        for ( $i = 0; $i < $max_depth && $current instanceof \DOMElement; $i++ ) {
            foreach ( ['h1', 'h2'] as $tag ) {
                $headings = $current->getElementsByTagName( $tag );
                if ( $headings->length > 0 ) {
                    return trim( $headings->item(0)->textContent );
                }
            }

            $current = $current->parentNode;
        }

        // fallback: id или class формы
        $id    = $form->getAttribute( 'id' );
        $class = $form->getAttribute( 'class' );

        if ( ! empty( $id ) ) {
            return "Form #$id";
        } elseif ( ! empty( $class ) ) {
            return "Form .$class";
        }

        return 'Unnamed form';
    }

    private function generate_css_selector( \DOMElement $el ) {
        $parts = [];
        $depth = 0;
        $max_depth = 6;

        while ( $el && $el->nodeType === XML_ELEMENT_NODE && $depth < $max_depth ) {
            $selector = $el->nodeName;

            if ( $el->hasAttribute( 'id' ) ) {
                $selector .= '#' . $el->getAttribute( 'id' );
                $parts[] = $selector;
                break;
            } elseif ( $el->hasAttribute( 'class' ) ) {
                $class = preg_split( '/\s+/', $el->getAttribute( 'class' ) );
                $selector .= '.' . implode( '.', array_filter( $class ) );
            }

            $parts[] = $selector;
            $el = $el->parentNode;
            $depth++;
        }

        return implode( ' > ', array_reverse( $parts ) );
    }

    private function pys_get_first_simple_product_id() {
        $args = [
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'orderby'        => 'date',
            'order'          => 'ASC',
            'meta_query'     => [
                [
                    'key'     => '_stock_status',
                    'value'   => 'instock',
                    'compare' => '='
                ]
            ],
            'tax_query' => [
                [
                    'taxonomy' => 'product_type',
                    'field'    => 'slug',
                    'terms'    => [ 'simple' ]
                ]
            ]
        ];

        $query = new \WP_Query( $args );

        if ( $query->have_posts() ) {
            return $query->posts[0]->ID;
        }

        return false;
    }

    function pys_get_first_edd_download_id() {
        $args = [
            'post_type'      => 'download',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'orderby'        => 'date',
            'order'          => 'ASC',
        ];

        $query = new \WP_Query( $args );

        if ( $query->have_posts() ) {
            return $query->posts[0]->ID;
        }

        return false;
    }

}

/**
 * @return AnyFormScanner
 */
function AnyFormScanner() {
    return AnyFormScanner::instance();
}

AnyFormScanner();