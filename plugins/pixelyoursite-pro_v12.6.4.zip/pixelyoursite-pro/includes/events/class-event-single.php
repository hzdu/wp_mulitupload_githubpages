<?php
namespace PixelYourSite;
class SingleEvent extends PYSEvent{

    public $params = array(
    );
    public $payload = array(
        'delay' => 0
    );

	private $ecommerceParamArray = array(
		'currency',
		'value',
		'items',
		'tax',
		'shipping',
		'coupon',
		'affiliation',
		'transaction_id',
		'total_value',
        'fees',
        'new_customer',
		'ecomm_prodid',
		'ecomm_pagetype',
		'ecomm_totalvalue'
	);


    public function __construct($id,$type,$category=''){
        parent::__construct($id,$type,$category);
        $this->payload['type'] = $type;
    }


    /**
     * Insert Array params for event
     * @param array $data
     */
    function addParams($data) {
        if (is_string($data)) {
            $decoded = json_decode($data, true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
        }
        if(is_array($data)) {
	        if (isset($this->params['triggerType']['type']) && $this->params['triggerType']['type'] === 'ecommerce') {
		        foreach ( $data as $key => $value ) {
			        if ( in_array( $key, $this->ecommerceParamArray ) ) {
				        $this->params['ecommerce'][ $key ] = $data[ $key ];
			        } else {
				        $this->params[ $key ] = $data[ $key ];
			        }
		        }
	        }
			else{
				$this->params = array_merge($this->params, $data);
			}
        } else {
            error_log("addParams is not array ".print_r($data,true));
        }
    }

    /**
     * Insert additional Array data for event
     * @param array $data
     */
    function addPayload($data) {
        if (is_string($data)) {
            $decoded = json_decode($data, true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
        }
        if(is_array($data)) {
            $this->payload = array_merge($this->payload,$data);
        } else {
            error_log("addPayload no array ".print_r($data,true));
        }

    }

    /**
     * @return array
     */
    function getData() {
        $data = $this->payload;
        $data['params'] = sanitizeParams($this->params);
        $data['e_id'] = $this->getId();

        $data['delay'] = isset( $this->payload['delay'] ) ? $this->payload['delay'] : 0;
        $data['ids'] = isset( $this->payload['ids'] ) ? $this->payload['ids'] : array();
        $data['hasTimeWindow'] = isset( $this->payload['hasTimeWindow'] )  ? $this->payload['hasTimeWindow'] : false;
        $data['timeWindow'] = isset( $this->payload['timeWindow'] )  ? $this->payload['timeWindow'] : 0;
        $data['eventID'] = isset( $this->payload['eventID'] ) ? $this->payload['eventID'] : "";
        $data['woo_order'] = isset( $this->payload['woo_order'] ) ? $this->payload['woo_order'] : "";
        $data['edd_order'] = isset( $this->payload['edd_order'] ) ? $this->payload['edd_order'] : "";
        // Order key is forwarded to the browser purchase event so the REST
        // guard (RestAPIGuard) can bind the event to the specific order.
        // Best-effort: empty when the event is not tied to an order.
        $data['order_key'] = isset( $this->payload['order_key'] ) ? $this->payload['order_key'] : "";

        // Defense in Depth: this payload is consumed by wp_localize_script() in
        // EventsManager. Although wp_localize_script() JSON-encodes the array
        // (which is JS-safe), we additionally normalize scalar string control
        // fields with sanitize_text_field() so any stray HTML/JS payload that
        // slipped through addParams()/addPayload() cannot reach the JS context.
        // esc_js()/esc_attr() are intentionally NOT applied here because the
        // same structure feeds the server-side Conversions API senders, where
        // such escaping would corrupt outbound data.
        $scalar_string_fields = array( 'e_id', 'eventID', 'type', 'name');
        foreach ( $scalar_string_fields as $field ) {
            if ( isset( $data[ $field ] ) && is_string( $data[ $field ] ) ) {
                $data[ $field ] = sanitize_text_field( $data[ $field ] );
            }
        }

        return $data;
    }

    function getPayloadValue($key) {
        if(isset($this->payload[$key]))
            return $this->payload[$key];
        return null;
    }

    function getParamValue($key) {
        if(isset($this->params[$key]))
            return $this->params[$key];
        return null;
    }

    function removeParam($key) {
        if (isset($this->params[$key])) {
            unset($this->params[$key]);
        }
    }

    function removePayload($key) {
        if (isset($this->payload[$key])) {
            unset($this->payload[$key]);
        }
    }
}