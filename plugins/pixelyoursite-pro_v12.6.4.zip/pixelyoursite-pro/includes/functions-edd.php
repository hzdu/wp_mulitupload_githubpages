<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Build the EDD download content id for a pixel tag, honoring the edd_variable_as_simple option.
 *
 * Single source of truth for the EDD content-id logic in this plugin: every pixel's own helper
 * (getFacebookEddDownloadContentId / getEddDownloadContentId / ...) delegates here, passing its
 * own settings object so per-tag options (edd_content_id, prefix, suffix, edd_variable_as_simple)
 * are still honored.
 *
 * @param Settings      $settings         Pixel/settings object storing edd_content_id / prefix / suffix.
 * @param int|string    $download_id      EDD download (post) id.
 * @param int|null      $price_id         Selected price option id. 0 is a valid variation; pass null for downloads without price variations.
 * @param Settings|null $variableSettings Settings object storing edd_variable_as_simple. Defaults to $settings.
 *
 * @return string
 */
function getEddContentId( $settings, $download_id, $price_id = null, $variableSettings = null ) {

	if ( null === $variableSettings ) {
		$variableSettings = $settings;
	}

	if ( $settings->getOption( 'edd_content_id' ) == 'download_sku' ) {
		$content_id = get_post_meta( $download_id, 'edd_sku', true );
		if ( empty( $content_id ) ) {
			$content_id = $download_id; // fall back to the download id when no SKU is set
		}
	} else {
		$content_id = $download_id;
	}

	// For downloads with price variations, append the price id unless the option
	// forces the parent (simple) download id for every variation.
	if ( ! $variableSettings->getOption( 'edd_variable_as_simple' ) && null !== $price_id ) {
		$content_id = $content_id . '-' . $price_id;
	}

	$prefix = $settings->getOption( 'edd_content_id_prefix' );
	$suffix = $settings->getOption( 'edd_content_id_suffix' );

	return $prefix . $content_id . $suffix;
}

/**
 * Payment key submitted with the current request.
 *
 * EDD keys are strtolower( md5( ... ) ) (see edd_generate_order_payment_key), so
 * case is not normally an issue — but sanitize_key() is still wrong here, because
 * the `edd_generate_order_payment_key` filter lets a site change the format and
 * sanitize_key() would silently mangle it.
 *
 * urldecode() is deliberately gone: PHP has already decoded $_GET, and a second
 * pass corrupts any key that legitimately contains a percent sign.
 *
 * @return string Empty string when the request carries no key.
 */
function pysEddGetSubmittedPaymentKey() {

	if ( isset( $_GET['payment_key'] ) && is_string( $_GET['payment_key'] ) && '' !== $_GET['payment_key'] ) {
		return sanitize_text_field( wp_unslash( $_GET['payment_key'] ) );
	}

	return '';

}

/**
 * Verify EDD's own receipt link token.
 *
 * EDD builds receipt links as ?id=<order id>&order=<md5( id . payment_key . email )>
 * (edd_get_receipt_page_uri()), but its receipt shortcode resolves the key from
 * the ID without ever checking that token — it relies on edd_can_view_receipt()
 * at render time instead. We check the token, so an order ID on its own is never
 * enough to get data out of this plugin.
 *
 * @param int $order_id
 * @return bool
 */
function pysEddVerifyReceiptToken( $order_id ) {

	if ( empty( $_GET['order'] ) || ! is_string( $_GET['order'] ) || ! function_exists( 'edd_get_order' ) ) {
		return false;
	}

	$order = edd_get_order( absint( $order_id ) );

	if ( empty( $order->id ) ) {
		return false;
	}

	$submitted = sanitize_text_field( wp_unslash( $_GET['order'] ) );
	$expected  = md5( $order->id . $order->payment_key . $order->email );

	return hash_equals( $expected, $submitted );

}

/**
 * Whether the current request may see this EDD order's data.
 *
 * Accepted, in order: EDD's own receipt rule (shop manager, the logged-in
 * customer, or a live purchase session), possession of the payment key, and a
 * verified receipt token.
 *
 * Possession of the key is deliberately enough. It is the secret EDD mints per
 * order, it is the same model WooCommerce uses for order keys, and it is all an
 * offsite gateway return carries when the purchase-session cookie does not
 * survive the round trip. Sites that want to match EDD core exactly — which also
 * demands a session or a login — can opt in with:
 *
 *     add_filter( 'pys_edd_require_receipt_access', '__return_true' );
 *
 * @param int $order_id
 * @return bool
 */
function pysEddRequestCanAccessOrder( $order_id ) {

	$order_id = absint( $order_id );

	if ( ! $order_id || ! function_exists( 'edd_can_view_receipt' ) || ! function_exists( 'edd_get_payment_key' ) ) {
		return false;
	}

	$real_key = (string) edd_get_payment_key( $order_id );

	if ( '' === $real_key ) {
		return false;
	}

	// EDD's own rule. Unlike WooCommerce's `view_order`, this one is sound for
	// guests: logged out, it requires the purchase session key to match.
	if ( edd_can_view_receipt( $real_key ) ) {
		return true;
	}

	if ( apply_filters( 'pys_edd_require_receipt_access', false ) ) {
		return false;
	}

	// Possession of the payment key. The submitted value is also compared
	// lowercased because EDD keys are lowercase by construction, so lowercasing a
	// candidate can only ever match the real key, never a different one.
	$submitted = pysEddGetSubmittedPaymentKey();

	if ( '' !== $submitted
	     && ( hash_equals( $real_key, $submitted ) || hash_equals( $real_key, strtolower( $submitted ) ) ) ) {
		return true;
	}

	return pysEddVerifyReceiptToken( $order_id );

}

function getEddPaymentKey() {
	global $edd_receipt_args;

	$submitted = pysEddGetSubmittedPaymentKey();

	if ( '' !== $submitted ) {
		return $submitted;
	}

	$session = edd_get_purchase_session();

	if ( $session && isset( $session['purchase_key'] ) && '' !== $session['purchase_key'] ) {
		return $session['purchase_key'];
	}

	if ( ! empty( $edd_receipt_args['payment_key'] ) ) {
		return $edd_receipt_args['payment_key'];
	}

	// EDD's own receipt link, ?id=<order id>&order=<token>. The token is verified,
	// so this never turns a bare order ID into order data.
	if ( ! empty( $_GET['id'] ) && ! empty( $_GET['order'] ) && function_exists( 'edd_get_payment_key' ) ) {
		$order_id = absint( $_GET['id'] );
		if ( $order_id && pysEddVerifyReceiptToken( $order_id ) ) {
			$key = (string) edd_get_payment_key( $order_id );
			if ( '' !== $key ) {
				return $key;
			}
		}
	}

	return false;

}

function getEddCustomerTotals($user_id = 0, $order_id = null) {
	global $wpdb;

    if($user_id == 0)
	    $user_id = get_current_user_id();

	if ( $user_id ) {

        $orders = edd_get_users_purchases($user_id);
        if (empty($orders)) { return false; }

        $total_order_value = 0;
        $orders_count = count($orders);
        foreach ($orders as $order) {
            $payment_id = $order->ID;
            $order_total = edd_get_payment_amount($payment_id);
            $total_order_value += $order_total;
        }
        $avg_order_value = $total_order_value / $orders_count;
        return array(
            'orders_count'    => (int) $orders_count,
            'avg_order_value' => round( (float) $avg_order_value, 2),
            'ltv'             => round( (float) $total_order_value, 2),
        );
	} else {

		$payment_key = getEddPaymentKey();
		if ( ! isset( $payment_key ) ) {
			return false;
		}
		$order_ids[] = (int) edd_get_purchase_id_by_key( $payment_key );

	}
	if( empty( $order_ids ) ) {
		return false;
	}

	$order_statues = PYS()->getOption( 'edd_ltv_order_statuses' );
    if (is_array($order_statues)) {
        $order_statues = array_filter($order_statues);
    } else {
        $order_statues = array();
    }

	if ( empty( $order_statues ) ) {
		$order_statues = array_keys( edd_get_payment_statuses() );
	}

	$post_ids_placeholder = implode( ', ', array_fill( 0, count( $order_ids ), '%d' ) );

	// calculate totals
    $query = $wpdb->prepare( "
    SELECT  SUM(pm.meta_value) AS ltv,
            AVG(pm.meta_value) as avg_order_value,
            COUNT(pm.meta_value) AS orders_count 
    FROM    $wpdb->postmeta AS pm
    JOIN    $wpdb->posts AS p ON pm.post_id = p.ID
    WHERE   p.ID IN ({$post_ids_placeholder})
            AND p.post_status IN ('edd_payment_received', 'edd_payment_complete')
            AND pm.meta_key = '_edd_payment_total'
", $order_ids );

// Получите результаты запроса
    $results = $wpdb->get_results( $query );

	if ( null === $results || empty( $results ) ) {
		return false;
	} else {
		return array(
			'orders_count'    => (int) $results[0]->orders_count,
			'avg_order_value' => round( (float) $results[0]->avg_order_value, 2),
			'ltv'             => round( (float) $results[0]->ltv, 2),
		);
	}

}

function getEddCustomerTotalsByEmail($email) {
    global $wpdb;

        // get customer orders
        $order_ids = $wpdb->get_col( $wpdb->prepare( "
            SELECT post_id 
            FROM $wpdb->postmeta 
            WHERE   meta_key = '_edd_payment_user_email' 
              AND   meta_value = '%s'
            ", $email ) );


    if( empty( $order_ids ) ) {
        return false;
    }

    $order_statues = PYS()->getOption( 'edd_ltv_order_statuses' );
    $order_statues = array_filter( $order_statues );

    if ( empty( $order_statues ) ) {
        $order_statues = array_keys( edd_get_payment_statuses() );
    }

    $post_ids_placeholder = implode( ', ', array_fill( 0, count( $order_ids ), '%d' ) );
    $post_statuses_placeholder = implode( ', ', array_fill( 0, count( $order_statues ), '%s' ) );

    // calculate totals
    $query = $wpdb->prepare( "
        SELECT  SUM(meta_value) AS ltv, AVG(meta_value) as avg_order_value, COUNT(meta_value) AS orders_count 
        FROM    $wpdb->postmeta AS pm
        JOIN    $wpdb->posts AS p ON pm.post_id = p.ID
        WHERE   p.ID IN ({$post_ids_placeholder})
                AND p.post_status IN ({$post_statuses_placeholder})
                AND pm.meta_key = '_edd_payment_total'
        GROUP BY meta_key
    ", array_merge( $order_ids, $order_statues ) );

    $results = $wpdb->get_results( $query );

    if ( null === $results || empty( $results ) ) {
        return false;
    } else {
        return array(
            'orders_count'    => (int) $results[0]->orders_count,
            'avg_order_value' => round( (float) $results[0]->avg_order_value, 2),
            'ltv'             => round( (float) $results[0]->ltv, 2),
        );
    }

}

function getEddDownloadPrice( $download_id, $price_index = null ) {

	$price = edd_get_download_price( $download_id );

	if ( edd_has_variable_prices( $download_id ) ) {

		$prices = edd_get_variable_prices( $download_id );

		if ( $price_index !== null ) {

			// get selected price option
			$price = isset( $prices[ $price_index ] ) ? $prices[ $price_index ]['amount'] : 0;

		} else {

			// get default price option
			$default_option = edd_get_default_variable_price( $download_id );
			$price          = $prices[ $default_option ]['amount'];

		}

	}

	$price = (float) $price;
	$tax   = edd_get_cart_item_tax( $download_id, array(), $price );

	$include_tax = PYS()->getOption( 'edd_tax_option' ) == 'included' ? true : false;

	if ( $include_tax == false && edd_prices_include_tax() ) {
		$price -= $tax;
	} elseif ( $include_tax == true && edd_prices_include_tax() == false ) {
		$price += $tax;
	}

	return (float) $price;

}

function getEddDownloadPriceToDisplay( $download_id, $price_index = null  ) {

	if ( edd_has_variable_prices( $download_id ) ) {

		$prices = edd_get_variable_prices( $download_id );

		if ( $price_index !== null ) {

			// get selected price option
			$price = isset( $prices[ $price_index ] ) ? $prices[ $price_index ]['amount'] : 0;

		} else {

			// get default price option
			$default_option = edd_get_default_variable_price( $download_id );
			$price = $prices[ $default_option ]['amount'];

		}

	} else {

		$price = edd_get_download_price( $download_id );

	}

	return (float) $price;

}

function getEddEventValue( $option, $amount, $global, $percent ) {

	switch ( $option ) {
		case 'global':
			$value = (float) $global;
			break;

		case 'percent':
			$percents = (float) $percent;
			$percents = str_replace( '%', null, $percents );
			$percents = (float) $percents / 100;
			$value    = (float) $amount * $percents;
			break;

		default:    // "price" option
			$value = (float) $amount;
	}

	return round($value, 2);

}

function getEddDownloadLicenseData( $download_id ) {

	// license management disabled for product
	if ( false == get_post_meta( $download_id, '_edd_sl_enabled', true ) ) {
		return array();
	}

	$params = array();

	$limit      = get_post_meta( $download_id, '_edd_sl_limit', true );
	$exp_unit   = get_post_meta( $download_id, '_edd_sl_exp_unit', true );
	$exp_length = get_post_meta( $download_id, '_edd_sl_exp_length', true );
	$version    = get_post_meta( $download_id, '_edd_sl_version', true );

	$is_limited = get_post_meta( $download_id, 'edd_sl_download_lifetime', true );
	$is_limited = empty( $is_limited );

	$params['transaction_type']   = getEddDownloadPrice( $download_id ) <= 0 ? 'free' : 'paid';
	$params['license_site_limit'] = $limit;
	$params['license_time_limit'] = $is_limited ? "{$exp_length} {$exp_unit}" : 'lifetime';
	$params['license_version']    = $version;

	return $params;

}

function getEddOrderTotal( $payment_id ) {

	$include_tax = PYS()->getOption( 'edd_tax_option' ) == 'included' ? true : false;

	if ( edd_use_taxes() && $include_tax ) {
		return edd_get_payment_amount( $payment_id );
	} elseif ( edd_use_taxes() && ! $include_tax ) {
		return edd_get_payment_amount( $payment_id ) - edd_get_payment_tax( $payment_id );
	} else {
		return edd_get_payment_amount( $payment_id );
	}

}

function eddExportCustomAudiences() {
	global $wpdb;
	
	ob_clean();
	
	$csv_data = array();
	
	$order_statues = PYS()->getOption( 'edd_ltv_order_statuses', array() );
	
	if ( empty( $order_statues ) ) {
		$order_statues = array_keys( edd_get_payment_statuses() );
	}
	
	$order_statues_placeholders = implode( ', ', array_fill( 0, count( $order_statues ), '%s' ) );
	
	// collect all unique customers by email
	$query = $wpdb->prepare( "
        SELECT  postmeta.meta_value AS email, postmeta.post_id
        FROM    $wpdb->postmeta AS postmeta
        JOIN    $wpdb->posts AS posts ON postmeta.post_id = posts.ID
        WHERE   posts.post_type = 'edd_payment'
                AND posts.post_status IN ({$order_statues_placeholders})
                AND postmeta.meta_key = '_edd_payment_user_email'
    ", $order_statues );
	
	$results = $wpdb->get_results( $query );
	
	$customers = array();
	
	// format data as email => [ order_ids ]
	foreach ( $results as $row ) {
		
		$order_ids   = isset( $customers[ $row->email ] ) ? $customers[ $row->email ] : array();
		$order_ids[] = (int) $row->post_id;
		
		$customers[ $row->email ] = $order_ids;
		
	}
	
	@ini_set( 'max_execution_time', 180 );
	
	// collect data per each customer
	foreach ( $customers as $email => $order_ids ) {
		
		$order_ids_placeholders = implode( ',', array_fill( 0, count( $order_ids ), '%d' ) );
		
		// calculate customer LTV
		$query = $wpdb->prepare( "
            SELECT  SUM( meta_value )
            FROM    $wpdb->postmeta
            WHERE   post_id IN ( {$order_ids_placeholders} )
                    AND meta_key = '_edd_payment_total'
        ", $order_ids );
		
		$customer_ltv = $wpdb->get_col( $query );
		
		// query customer data from last order
		$query = $wpdb->prepare( "
            SELECT  meta_value
            FROM    $wpdb->postmeta
            WHERE   post_id = %d
                    AND meta_key = '_edd_payment_meta'
        ", end( $order_ids ) );
		
		$customer_meta        = $wpdb->get_col( $query );
		$customer_meta        = maybe_unserialize( $customer_meta[0] );
		$customer_meta['ltv'] = (float) $customer_ltv[0];
		
		$csv_data[] = $customer_meta;
		
	}
	
	// generate file name
	$site_name = site_url();
	$site_name = str_replace( array( 'http://', 'https://' ), '', $site_name );
	$site_name = strtolower( preg_replace( "/[^A-Za-z]/", '_', $site_name ) );
	$file_name = date('Ymd') . '_' . $site_name . '_edd_customers.csv';
	
	// output CSV
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=' . $file_name );
	
	$output = fopen( 'php://output', 'w' );
	
	// headings
	fputcsv( $output, array( 'email', 'phone', 'fn', 'ln', 'ct', 'st', 'country', 'zip', 'value' ) );
	
	// rows
	foreach ( $csv_data as $row ) {
		
		fputcsv( $output, array(
			$row['email'],
			'',
			isset( $row['user_info']['first_name'] ) ? $row['user_info']['first_name'] : '',
			isset( $row['user_info']['last_name'] ) ? $row['user_info']['last_name'] : '',
			isset( $row['user_info']['address']['city'] ) ? $row['user_info']['address']['city'] : '',
			isset( $row['user_info']['address']['state'] ) ? $row['user_info']['address']['state'] : '',
			isset( $row['user_info']['address']['country'] ) ? $row['user_info']['address']['country'] : '',
			isset( $row['user_info']['address']['zip'] ) ? $row['user_info']['address']['zip'] : '',
			$row['ltv']
		) );
		
	}
	
	exit;
	
}

function eddMapOrderId($orderId) {
    return PYS()->getOption("edd_order_id_prefix").$orderId;
}