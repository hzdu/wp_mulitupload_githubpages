<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Facebook REST API handler
 *
 * Extends AbstractRestAPI to handle Facebook server events via REST API
 */
class Facebook_REST_API extends AbstractRestAPI {

    /**
     * Get the REST API namespace
     *
     * @return string
     */
    protected function getRestNamespace() {
        return 'pys-facebook/v1';
    }

    /**
     * Get the server instance for Facebook
     *
     * @return FacebookServer
     */
    protected function getServerInstance() {
        return FacebookServer();
    }

    /**
     * Get the pixel instance for Facebook
     *
     * @return Facebook
     */
    protected function getPixelInstance() {
        return Facebook();
    }

    /**
     * Check if Facebook server API is enabled
     *
     * @return bool
     */
    protected function isServerApiEnabled() {
        return Facebook()->isServerApiEnabled();
    }

    /**
     * Get the localized script variable name
     *
     * @return string
     */
    protected function getScriptVariableName() {
        return 'pysFacebookRest';
    }

    /**
     * Extend abstract args with Facebook-specific `referrer_url`.
     * Kept here (not in AbstractRestAPI) to avoid affecting TikTok/Pinterest.
     */
    protected function get_event_args() {
        $args = parent::get_event_args();
        $args['referrer_url'] = [
            'required'          => false,
            'type'              => 'string',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ];
        $args['event_source_url'] = [
            'required'          => false,
            'type'              => 'string',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ];
        return $args;
    }

    /**
     * Override to capture `referrer_url` from the request payload and attach
     * it to the SingleEvent before dispatch. ServerEventHelper reads this
     * value from the payload when building CustomData for Meta CAPI.
     */
    public function handle_event( $request ) {
        $this->getPixelInstance()->getLog()->debug(
            'handleEvent send to ' . ucfirst( $this->getPlatformName() ) . ' server from REST API'  .
            ' event: ' . $request->get_param( 'event' ) .
            ' eventID: ' . $request->get_param( 'eventID' )
        );

        $event        = $request->get_param( 'event' );
        $data         = $request->get_param( 'data' ) ?: [];
        $ids          = $request->get_param( 'ids' );
        $event_id     = $request->get_param( 'eventID' );
        $woo_order    = $request->get_param( 'woo_order' );
        $edd_order    = $request->get_param( 'edd_order' );
        $event_slug   = $request->get_param( 'event_slug' );
        $referrer_url = $request->get_param( 'referrer_url' );
        $event_source_url = $request->get_param( 'event_source_url' );

        // Variant B fallback: when the browser did not send an explicit page
        // URL, use this REST request's Referer header. For a fetch/sendBeacon
        // fired from the visitor's page, Referer IS that page URL — which is
        // what Meta expects for event_source_url (never the REST endpoint).
        if ( empty( $event_source_url ) ) {
            $referer = $request->get_header( 'referer' );
            if ( ! empty( $referer ) ) {
                $event_source_url = esc_url_raw( $referer );
            }
        }

        if ( empty( $event ) || empty( $ids ) ) {
            return new \WP_Error(
                'missing_parameters',
                'Missing mandatory parameters: event and ids',
                [ 'status' => 400 ]
            );
        }

        if ( $event === 'hCR' ) {
            $event = 'CompleteRegistration';
        }

        $single_event = $this->data_to_single_event(
            $event, $data, $event_id, $ids, $woo_order, $edd_order, $event_slug
        );

        if ( ! empty( $referrer_url ) && pys_is_valid_public_url( $referrer_url ) ) {
            $single_event->addPayload( [ 'referrer_url' => $referrer_url ] );
        }

        if ( ! empty( $event_source_url ) && pys_is_valid_public_url( $event_source_url ) ) {
            $single_event->addPayload( [ 'event_source_url' => $event_source_url ] );
        }

        if ( $this->server_instance->isQueueEnabled() && PYS()->getOption( 'queue_use_for_ajax' ) ) {
            $this->server_instance->sendEventsToQueue( [ $single_event ] );
        } else {
            $this->server_instance->sendEventsNow( [ $single_event ] );
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }
}

/**
 * Accessor function for Facebook REST API
 *
 * @return Facebook_REST_API
 */
function Facebook_REST_API() {
    static $instance = null;
    if ( $instance === null ) {
        $instance = new Facebook_REST_API();
    }
    return $instance;
}
