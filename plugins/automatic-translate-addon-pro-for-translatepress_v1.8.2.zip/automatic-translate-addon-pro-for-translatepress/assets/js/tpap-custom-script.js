const tpAutoTranslator = (function (window, $) {
  //get plugin configuration object.
  const configData = window.extradata;
  const {
    ajax_url: ajaxUrl,
    nonce: nonce,
    license_key: licensekeys,
    extra_class: rtlClass,
    dashboard_url
  } = configData;
  var dict_id = new Array();
  var gettxt_id = new Array();
  var chromeAIStatus = false;
  var previousSelectedLang = null;
  onLoad();
  async function onLoad() {
    // Update localStorage with current language values
    updateLanguageStorage();
    var default_lang = $("#trp-language-select")
      .find("option:first-child")
      .val();
    var pageLang = tpap_language_code(default_lang);
    localStorage.setItem("page_lang", pageLang);

    //create strings modal
    createStringsModal("yandex");
    createStringsModal("google");

    //create strings modal
    chromeAIStatus = await checkChromeAILangStatus();
    createStringsModal('chrome-ai-translator');

    createStringsModal("openai");
    createStringsModal("gemini");
    createStringsModal("anthropic");

  }
  // Function to update Chrome AI translator button in modal when status changes
  async function updateChromeAIButton() {
    const icons = {
      error: extradata['error_preview']
    };
    const TPA_IMG = (key) => icons[key];
    
    const $chromeCard = getProviderCard('chrome-ai-translator');
    if ($chromeCard.length > 0) {
      const $actionSlot = $chromeCard.find('[data-provider-action-slot]').first();
      
      // Update button based on current chromeAIStatus
      if (chromeAIStatus === true) {
        $actionSlot.html('<button id="tpap_chrome_ai_translate_btn" class="tpap-provider-btn translate" data-translate-engen="chrome-ai-translator">Translate</button>');
        // Re-attach click handler for the new button
        $("#tpap_chrome_ai_translate_btn").off('click').on("click", function () {
          onChromeTranslateClick(this);
        });
      } else {
        const sourceLanguage = localStorage.getItem("page_lang");
        const targetLanguage = localStorage.getItem("language_code");
        const settingsUrl = getTPAPSettingsPageUrl();
        
        if (hasChromeConfigurationError()) {
          // Browser/API/secure connection error
          $actionSlot.html(`
            <button class="tpap-chromeai-disabled-message tpap-provider-btn error" onclick="window.open('${settingsUrl}', '_blank'); return false;">
              <img src="${TPA_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
              Configure
            </button>
          `);
        } else {
          // Check if it's a language pack issue (supported but not installed) or unsupported language
          const packRequired = await isLanguagePackRequired(sourceLanguage, targetLanguage);
          
          if (packRequired) {
            // Language pack required (supported but not installed) → "Configure"
            $actionSlot.html(`
              <button class="tpap-chromeai-disabled-message tpap-provider-btn error" onclick="window.open('${settingsUrl}', '_blank'); return false;">
                <img src="${TPA_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                Configure
              </button>
            `);
          } else {
            // Unsupported language - show disabled "Not Supported" button
            $actionSlot.html(`
              <button class="tpap-chromeai-disabled-message tpap-provider-btn error error-disabled" disabled>
                Not Supported
              </button>
            `);
          }
        }
      }
      syncProviderCtaFromAction($chromeCard);
      refreshProviderStartButtonState();
    }
  }

  // Helper function to update localStorage with current language values
  function updateLanguageStorage() {
    var default_lang = $("#trp-language-select")
      .find("option:first-child")
      .val();
    var getSelectedlang = $("#trp-language-select").val();
    var getTargetlangName = $("#trp-language-select").find("option:selected").text();
    var getDefaultlangName = $("#trp-language-select").find("option:first-child").text();
    
    if (getSelectedlang) {
      var pageLang = tpap_language_code(default_lang);
      var defaultLang = tpap_language_code(getSelectedlang);
      
      localStorage.setItem("page_lang", pageLang);
      localStorage.setItem("language_code", defaultLang);
      localStorage.setItem("lang", defaultLang);
      localStorage.setItem("language_name", getSelectedlang);
      localStorage.setItem("default_language", default_lang);
      localStorage.setItem("source_language_name", getDefaultlangName);
      localStorage.setItem("target_language_name", getTargetlangName);
    }
  }
  async function checkChromeAILangStatus(){
    const status = await ChromeAiTranslator.languageSupportedStatus(localStorage.getItem("page_lang"),localStorage.getItem("language_code"),localStorage.getItem("target_language_name"),localStorage.getItem("source_language_name"));
    return status;
  }

  function getTPAPSettingsPageUrl() {
    // Try to get admin URL from various sources
    if (typeof ajaxurl !== 'undefined') {
      // Extract admin URL from ajaxurl (e.g., /wp-admin/admin-ajax.php)
      const adminBase = ajaxurl.replace('/admin-ajax.php', '');
      return adminBase + '/options-general.php?page=translatepress-tpap-dashboard&tab=settings';
    }
    // Fallback: construct from current location
    const currentPath = window.location.pathname;
    const adminMatch = currentPath.match(/^(.+\/wp-admin)/);
    if (adminMatch) {
      return adminMatch[1] + '/options-general.php?page=translatepress-tpap-dashboard&tab=settings';
    }
    // Last resort: relative path
    return '/wp-admin/options-general.php?page=translatepress-tpap-dashboard&tab=settings';
  }

  // Check if Chrome has browser/API/secure connection errors (not language errors)
  function hasChromeConfigurationError() {
    // Use centralized Chrome AI Translator utility methods
    if (typeof ChromeAiTranslator === 'undefined') {
      return true; // If ChromeAiTranslator not loaded, assume error
    }
    
    // Browser check
    const bypassBrowser = configData.chrome_ai_bypass_browser_check === '1';
    const bypassSecure = configData.chrome_ai_bypass_secure_check === '1';
    const bypassApi = configData.chrome_ai_bypass_api_check === '1';

    if (!ChromeAiTranslator.checkBrowserCompatibility() && !bypassBrowser) {
      return true;
    }
    
    const apiAvailable = ChromeAiTranslator.checkApiAvailability() || bypassApi;
    const secureConnection = ChromeAiTranslator.checkSecureConnection() || window.isSecureContext || bypassSecure;
    
    // Secure connection check
    if (!apiAvailable && !secureConnection) {
      return true;
    }
    
    // API availability check
    if (!apiAvailable) {
      return true;
    }
    
    return false;
  }

  // Check if language is unsupported (not in supported languages list)
  function isLanguageUnsupported(sourceLanguage, targetLanguage) {
    if (!sourceLanguage || !targetLanguage) {
      return false; // Can't determine if unsupported without language codes
    }
    
    // Use centralized Chrome AI Translator utility methods
    if (typeof ChromeAiTranslator === 'undefined') {
      return false; // If ChromeAiTranslator not loaded, can't check
    }
    
    return !ChromeAiTranslator.isLanguageSupported(sourceLanguage) || 
           !ChromeAiTranslator.isLanguageSupported(targetLanguage);
  }

  // Check if language pack is required (language is supported but pack not installed)
  async function isLanguagePackRequired(sourceLanguage, targetLanguage) {
    // First check if language is unsupported - if so, it's not a pack issue
    if (isLanguageUnsupported(sourceLanguage, targetLanguage)) {
      return false;
    }
    
    // Use centralized Chrome AI Translator utility methods
    if (typeof ChromeAiTranslator === 'undefined') {
      return false; // Can't check pack status if ChromeAiTranslator not loaded
    }
    
    // Check if browser API is available
    if (!ChromeAiTranslator.checkApiAvailability()) {
      return false; // Can't check pack status if API not available
    }
    
    // Check language pair availability using centralized method
    try {
      const status = await ChromeAiTranslator.languagePairAvality(sourceLanguage, targetLanguage);
      
      // If status indicates pack is required or downloading, return true
      if (status === "after-download" || status === "downloadable" || status === "unavailable" || status === "downloading") {
        return true;
      }
      
      // If status is not 'readily' or 'available', pack might be required
      if (status !== 'readily' && status !== 'available' && status !== false) {
        return true;
      }
    } catch (error) {
      // If check fails, assume it's not a pack issue
      console.log('Language pack check failed:', error);
      return false;
    }
    
    return false;
  }

  async function initialize() {

    var default_lang = $("#trp-language-select")
      .find("option:first-child")
      .val();
    var getSelectedlang = $("#trp-language-select").val();

    // Embbed Auto Translate button inside Translatepress editor
    if ($("#tpap-auto-btn").length === 0) {
      addAutoTranslatepressBtn(default_lang, getSelectedlang);
    }

    //append auto translate settings model
    settingsModel();

    //on click on auto tranlsate button
    $("#tpap-auto-btn").on("click", function () {
      openSettingsModel();
    });

    //on click on yandex transllate button
    $("#tpap_yandex_transate_btn").on("click", function () {
      onYandexTranslateClick();
    });

    //on click on google translate button
    $("#tpap_gtranslate_btn").on("click", function () {
      onGoogleTranslateClick();
    });

    $("#chrome-ai-translator_settings_btn").on("click", function () {
      onChromeTranslateClick(this);
    });

    $(document).on("click", "#tpap_openai_transate_btn", function () {
      onAiProviderTranslateClick('openai', 'openai');
    });
    $(document).on("click", "#tpap_gemini_transate_btn", function () {
      onAiProviderTranslateClick('gemini', 'google');
    });
    $(document).on("click", "#tpap_anthropic_transate_btn", function () {
      onAiProviderTranslateClick('anthropic', 'anthropic');
    });

    // Provider selection modal interactions (custom modal, no jQuery UI dialog)
    $(document).off('click.tpapProviderModal').on('click.tpapProviderModal', '.tpap-provider-card', function(e){
      // Ignore clicks on interactive elements inside the card (e.g. docs links, hidden action buttons)
      if ($(e.target).closest('a,button').length) return;
      selectProviderCard($(this));
    });
    $(document).off('keydown.tpapProviderModal').on('keydown.tpapProviderModal', '.tpap-provider-card', function(e){
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        selectProviderCard($(this));
      }
    });
    $(document).off('click.tpapProviderModalStart').on('click.tpapProviderModalStart', '#tpap-provider-start', function(){
      startSelectedProvider();
    });
    $(document).off('click.tpapProviderModalClose').on('click.tpapProviderModalClose', '#tpap-provider-close', function(){
      closeProviderModal();
    });
    $(document).off('click.tpapProviderModalOverlay').on('click.tpapProviderModalOverlay', '#tpap-provider-overlay', function(e){
      if (e.target === this) closeProviderModal();
    });
    $(document).off('keydown.tpapProviderModalEsc').on('keydown.tpapProviderModalEsc', function(e){
      if (e.key === 'Escape' && isProviderModalOpen()) closeProviderModal();
    });

    //on google translation - use event delegation for dynamically created select
    $(document).on('change', '#google_translate_element select.goog-te-combo', function () {
      translation_process();
    });
    // Disabled "Not Supported" buttons won't trigger this handler
    $(document).on('click', '.tpap-chromeai-disabled-message:not(:disabled)', function(e) {
      // If button has onclick attribute (like "Configure" button), let it handle the click
      if ($(this).attr('onclick')) {
        return; // Let onclick handler execute
      }
      // Otherwise, prevent default
      e.preventDefault();
    });
    
    $(document).on('click','.save_it',onSaveClick)
    $(document).on('click','.retry_missing_it',onRetryMissingClick)
  }

  function addAutoTranslatepressBtn(default_lang, getSelectedlang) {
    $("#trp-language-switch").before(
      '<div><label class="tpap-steps">Step 1 - Select Language</label></div>'
    );
    $("#trp-next-previous").after(
      '<div><label class="tpap-steps">Step 2 - Click Auto Translate Button</label></div><button id="tpap-auto-btn">Auto Translate</button><div class="tpap-user-message">Translate all plain strings of current page </div>'
    );
    $("#tpap-auto-btn").attr("disabled", true);
    $("#tpap-auto-btn").removeClass("enabled");
    $(".tpap-user-message").html('*To enable the button, change the default language in Step 1.');
  }

  //Enable/disable the automatic translate button
  setInterval(enableAutotranslateButton, 200);
  async function enableAutotranslateButton() {
    var default_lang = $("#trp-language-select")
      .find("option:first-child")
      .val();
    var getSelectedlang = $("#trp-language-select").val();

    // Check if language has changed
    if (previousSelectedLang !== null && previousSelectedLang !== getSelectedlang) {
      // Update localStorage with new language values
      updateLanguageStorage();
      // Re-check Chrome AI translator status with new language
      chromeAIStatus = await checkChromeAILangStatus();
      // Update Chrome AI translator button in modal if modal exists
      updateChromeAIButton();
    }
    
    // Initialize previousSelectedLang on first run
    if (previousSelectedLang === null) {
      previousSelectedLang = getSelectedlang;
      // Update localStorage on first run
      updateLanguageStorage();
    } else {
      previousSelectedLang = getSelectedlang;
    }
    // Check if the loader is hidden
    var isLoaderHidden = $("#trp-preview-loader").css("display") === "none";
    var isAjaxLoaderHidden = $('#trp-string-saved-ajax-loader').css("display") == "none";
    var newButtonState = default_lang !== getSelectedlang && isLoaderHidden && isAjaxLoaderHidden;

    // Enable or disable the button based on the condition
    if (newButtonState) {
      $("#tpap-auto-btn").addClass("enabled");
      $("#tpap-auto-btn").attr("disabled", false);
      $("#tpap-auto-btn").removeAttr('title');
      $(".tpap-user-message").html('Translate all plain strings of current page.');
    } else {
      $("#tpap-auto-btn").removeClass("enabled");
      $("#tpap-auto-btn").attr("disabled", true);
      $(".tpap-user-message").html('*To enable the button, change the default language in Step 1.');
    }
  }

  function settingsModel() {
    const icons = {
        yandex: extradata['yt_preview'],
        google: extradata['gt_preview'],
        chrome: extradata['ct_preview'],
        openai: extradata['openai_preview'],
        gemini: extradata['gemini_preview'],
        anthropic: extradata['anthropic_preview'],
        docs: extradata['document_preview'],
        info: extradata['information_preview'],
        error: extradata['error_preview']
    };

    const licenseKey = extradata["license_key"];
    const isPro = licenseKey !== "No";

    const licenseLink = dashboard_url + '&tab=license';
    const url = 'https://docs.coolplugins.net/docs/automatic-translate-addon-for-translatepress-pro/';

    const TPAP_IMG = (key) => icons[key];
    const DOC_ICON_IMG = `<img src="${TPAP_IMG('docs')}" width="10" alt="Docs">`;

    // Get provider states from saved settings (extradata) - default to enabled if not set
    const isYandexEnabled = typeof extradata !== 'undefined' && extradata.provider_yandex_enabled ? extradata.provider_yandex_enabled === '1' : true;
    const isChromeEnabled = typeof extradata !== 'undefined' && extradata.provider_chrome_enabled ? extradata.provider_chrome_enabled === '1' : true;
    const isGoogleEnabled = typeof extradata !== 'undefined' && extradata.provider_google_enabled ? extradata.provider_google_enabled === '1' : true;
    const isOpenaiEnabled = typeof extradata !== 'undefined' && extradata.provider_openai_enabled ? extradata.provider_openai_enabled === '1' : true;
    const isGeminiEnabled = typeof extradata !== 'undefined' && extradata.provider_gemini_enabled ? extradata.provider_gemini_enabled === '1' : true;
    const isAnthropicEnabled = typeof extradata !== 'undefined' && extradata.provider_anthropic_enabled ? extradata.provider_anthropic_enabled === '1' : true;
    const hasOpenaiKey = typeof extradata !== 'undefined' && extradata.provider_openai_has_key ? extradata.provider_openai_has_key === '1' : false;
    const hasGeminiKey = typeof extradata !== 'undefined' && extradata.provider_gemini_has_key ? extradata.provider_gemini_has_key === '1' : false;
    const hasAnthropicKey = typeof extradata !== 'undefined' && extradata.provider_anthropic_has_key ? extradata.provider_anthropic_has_key === '1' : false;
    const settingsUrl = getTPAPSettingsPageUrl();
    const apiKeyLink = settingsUrl + '#tpap-bulk-translation-section';
    const allRows = [
        {
            key: 'yandex',
            name: 'Yandex Translate',
            icon: 'yandex',
            info: 'https://translate.yandex.com/',
            doc: `${url}how-to-translate-your-website-content-automatically-via-yandex/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=popup_yandex`,
            cta: '',
            btn: `<button id="tpap_yandex_transate_btn" class="tpap-provider-btn translate" data-translate-engen="yandex">Translate</button>`,
            enabled: isYandexEnabled
        },
        {
            key: 'google',
            name: 'Google Translate',
            icon: 'google',
            info: 'https://translate.google.com/',
            doc: `${url}how-to-translate-your-website-content-automatically-via-google/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=popup_google_pro`,
            cta: '',
            btn: isPro
                ? `<button id="tpap_gtranslate_btn" class="tpap-provider-btn translate" data-translate-engen="google">Translate</button>`
                : `
                    <a href="${licenseLink}">
                        <button class="tpap-provider-btn error">
                            <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                            Add License Key
                        </button>
                    </a>
                `,
            enabled: isGoogleEnabled
        },
        {
            key: 'chrome-ai-translator',
            name: 'Chrome Built-in AI',
            icon: 'chrome',
            info: 'https://developer.chrome.com/docs/ai/translator-api',
            doc: `${url}how-to-translate-your-website-content-automatically-via-chrome-ai/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=popup_chrome_pro`,
            cta: '',
            btn: chromeAIStatus === true
                  ? `<button id="chrome-ai-translator_settings_btn" class="tpap-provider-btn translate" data-translate-engen="chrome-ai-translator">Translate</button>`
                  : (hasChromeConfigurationError()
                    ? `<button class="tpap-chromeai-disabled-message tpap-provider-btn error" onclick="window.open('${getTPAPSettingsPageUrl()}', '_blank'); return false;">
                        <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                        Configure
                    </button>`
                    : (isLanguageUnsupported(localStorage.getItem("page_lang"), localStorage.getItem("language_code"))?
                        `<button class="tpap-chromeai-disabled-message tpap-provider-btn error error-disabled" disabled>
                        Not Supported
                    </button>`
                    : `<button class="tpap-chromeai-disabled-message tpap-provider-btn error" id="tpap-chrome-btn-placeholder">
                        <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                        Loading...
                    </button>`
                    )
                  ),
            enabled: isChromeEnabled
        },
        {
            key: 'openai',
            name: 'OpenAI',
            icon: 'openai',
            info: 'https://openai.com/',
            doc: `${url}generate-open-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=popup_openai`,
            cta: '',
            btn: isOpenaiEnabled
                  ? (!isPro
                      ? `
                        <a href="${licenseLink}">
                            <button class="tpap-provider-btn error">
                                <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                                Add License Key
                            </button>
                        </a>
                      `
                      : (!hasOpenaiKey
                          ? `
                            <a href="${apiKeyLink}" target="_blank" rel="noopener noreferrer">
                                <button class="tpap-provider-btn error">
                                    <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                                    Add API Key
                                </button>
                            </a>
                          `
                          : `<button id="tpap_openai_transate_btn" class="tpap-provider-btn translate" data-translate-engen="openai">Translate</button>`))
                  : `<button class="tpap-openai-disabled-message tpap-provider-btn error" disabled>
                      Not Supported
                    </button>`,
            enabled: isOpenaiEnabled
        },
        {
            key: 'gemini',
            name: 'Google Gemini',
            icon: 'gemini',
            info: 'https://gemini.google.com/',
            doc: `${url}generate-google-gemini-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=popup_gemini`,
            cta: '',
            btn: isGeminiEnabled
                  ? (!isPro
                      ? `
                        <a href="${licenseLink}">
                            <button class="tpap-provider-btn error">
                                <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                                Add License Key
                            </button>
                        </a>
                      `
                      : (!hasGeminiKey
                          ? `
                            <a href="${apiKeyLink}" target="_blank" rel="noopener noreferrer">
                                <button class="tpap-provider-btn error">
                                    <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                                    Add API Key
                                </button>
                            </a>
                          `
                          : `<button id="tpap_gemini_transate_btn" class="tpap-provider-btn translate" data-translate-engen="gemini">Translate</button>`))
                  : `<button class="tpap-gemini-disabled-message tpap-provider-btn error" disabled>
                      Not Supported
                    </button>`,
            enabled: isGeminiEnabled
        },
        {
            key: 'anthropic',
            name: 'Anthropic Claude',
            icon: 'anthropic',
            info: 'https://anthropic.com/',
            doc: `${url}generate-anthropic-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=popup_anthropic`,
            cta: '',
            btn: isAnthropicEnabled
                  ? (!isPro
                      ? `
                        <a href="${licenseLink}">
                            <button class="tpap-provider-btn error">
                                <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                                Add License Key
                            </button>
                        </a>
                      `
                      : (!hasAnthropicKey
                          ? `
                            <a href="${apiKeyLink}" target="_blank" rel="noopener noreferrer">
                                <button class="tpap-provider-btn error">
                                    <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                                    Add API Key
                                </button>
                            </a>
                          `
                          : `<button id="tpap_anthropic_transate_btn" class="tpap-provider-btn translate" data-translate-engen="anthropic">Translate</button>`))
                  : `<button class="tpap-anthropic-disabled-message tpap-provider-btn error" disabled>
                      Not Supported
                    </button>`,
            enabled: isAnthropicEnabled
        }
    ];
    const rows = allRows.filter(row => row.enabled);

    const cardsHTML = rows.map(row => `
      <div class="tpap-provider-card" data-provider-key="${row.key}" tabindex="0" role="button" aria-pressed="false">
        <div class="tpap-provider-card-top">
          <div class="tpap-provider-card-logo">
            <a href="${row.info}" target="_blank" class="tpap-provider-card-info" aria-label="${row.name} info">
              <img src="${TPAP_IMG(row.icon)}" class="tpap-provider-card-icon" alt="${row.name}">
            </a>
            <span class="tpap-provider-card-title">${row.name}</span>
          </div>
          <div class="tpap-provider-card-check" aria-hidden="true"></div>
        </div>
        
        <div class="tpap-provider-card-footer">
          <a href="${row.doc}" target="_blank" class="tpap-provider-card-docs">${DOC_ICON_IMG} Docs</a>
          <span class="tpap-provider-card-cta" data-provider-cta-slot>${row.cta || ''}</span>
        </div>
        <span class="tpap-provider-card-action" data-provider-action-slot>${row.btn}</span>
      </div>
    `).join('');

    const modelHTML = `
      <div class="tpap-provider-overlay ${rtlClass || ''}" id="tpap-provider-overlay" style="display:none;">
        <div class="tpap-provider-modal" id="tpap-dialog" role="dialog" aria-modal="true" aria-labelledby="tpap-provider-title">
          <button type="button" class="tpap-provider-close" id="tpap-provider-close" aria-label="Close"></button>
          <div class="tpap-provider-header">
            <div class="tpap-provider-step">STEP 3 OF 4</div>
            <div class="tpap-provider-title-row">
              <h2 class="tpap-provider-title" id="tpap-provider-title">Select Translation Engine</h2>
            </div>
            <p class="tpap-provider-subtitle">Choose the translation provider you want to use for this translation batch.</p>
          </div>
          <div class="tpap-provider-grid">
            ${cardsHTML}
          </div>
          <div class="tpap-provider-footer">
            <button type="button" class="tpap-provider-footer-btn tpap-provider-start" id="tpap-provider-start" disabled>Start Translation</button>
          </div>
        </div>
      </div>
    `;

    if(cardsHTML.length > 0){
        // Replace any existing markup (defensive)
        $("#tpap-provider-overlay").remove();
        $("#tpap-dialog").remove();
        $("body").append(modelHTML);

        // Initialize CTA buttons + disabled states (license / not supported, etc.)
        $("#tpap-dialog .tpap-provider-card").each(function(){
          syncProviderCtaFromAction($(this));
        });
        refreshProviderStartButtonState();
    }else{
        $("#tpap-provider-overlay").remove();
        $("#tpap-dialog").remove();
        $("body").append(`
          <div class="tpap-provider-overlay ${rtlClass || ''}" id="tpap-provider-overlay" style="display:none;">
            <div class="tpap-provider-modal" id="tpap-dialog" role="dialog" aria-modal="true" aria-labelledby="tpap-provider-title">
              <button type="button" class="tpap-provider-close" id="tpap-provider-close" aria-label="Close"></button>
              <div class="tpap-provider-header">
                <div class="tpap-provider-step">STEP 3 OF 4</div>
                <div class="tpap-provider-title-row">
                  <h2 class="tpap-provider-title" id="tpap-provider-title">Select Translation Engine</h2>
                </div>
                <p class="tpap-provider-subtitle">No translation providers found. Please enable at least one provider.</p>
              </div>
              <div class="tpap-provider-footer tpap-provider-footer--single">
                <a href="${dashboard_url}" target="_blank" class="tpap-provider-footer-link">Go to Dashboard</a>
              </div>
            </div>
          </div>
        `);
    }

    // After modal is created, check language pack status and update Chrome button if needed
    if (chromeAIStatus !== true && !hasChromeConfigurationError() && !isLanguageUnsupported(localStorage.getItem("page_lang"), localStorage.getItem("language_code"))) {
      (async function() {
          const sourceLanguage = localStorage.getItem("page_lang");
          const targetLanguage = localStorage.getItem("language_code");
          const packRequired = await isLanguagePackRequired(sourceLanguage, targetLanguage);
          const settingsUrl = getTPAPSettingsPageUrl();
          const $chromeCard = getProviderCard('chrome-ai-translator');
          if ($chromeCard.length > 0) {
              const $actionSlot = $chromeCard.find('[data-provider-action-slot]').first();
              const icons = {
                  error: extradata['error_preview']
              };
              const TPAP_IMG = (key) => icons[key];
              
              if (packRequired) {
                  // Language pack required → "Configure"
                  $actionSlot.html(`
                      <button class="tpap-chromeai-disabled-message tpap-provider-btn error" onclick="window.open('${settingsUrl}', '_blank'); return false;">
                          <img src="${TPAP_IMG('error')}" alt="error" style="height:16px; vertical-align:middle; margin-right:5px;">
                          Configure
                      </button>
                  `);
              } else {
                  // Unsupported language - show disabled "Not Supported" button
                  $actionSlot.html(`
                      <button class="tpap-chromeai-disabled-message tpap-provider-btn error error-disabled" disabled>
                          Not Supported
                      </button>
                  `);
              }
              syncProviderCtaFromAction($chromeCard);
              refreshProviderStartButtonState();
          }
      })();
  }
}

  function openSettingsModel() {
    //Get Dictionary Ids
    $('#trp-string-categories optgroup option[data-group="String List"]').each(
      function (x) {
        var database_id = $(this).attr("data-database-id");
        dict_id[x] = database_id;
      }
    );

    //Get Gettext Ids
    $('#trp-string-categories optgroup option[data-group="Gettext Strings"]').each(function (x) {
        var database_id = $(this).attr("data-database-id");
        gettxt_id[x] = database_id;
    });
      var getSelectedlang = $("#trp-language-select").val();
      var getTargetlangName = $("#trp-language-select").find("option:selected").text();
      var getDefaultlangName = $("#trp-language-select").find("option:first-child").text()
      var default_lang = $("#trp-language-select")
        .find("option:first-child")
        .val();
      var defaultLang = tpap_language_code(getSelectedlang);
      localStorage.setItem("language_code", defaultLang);
      localStorage.setItem("lang", defaultLang);
      localStorage.setItem("yt-widget", JSON.stringify({ active: false, lang: defaultLang }));
      localStorage.setItem("language_name", getSelectedlang);
      localStorage.setItem("default_language", default_lang);
      localStorage.setItem("source_language_name", getDefaultlangName);
      localStorage.setItem("target_language_name", getTargetlangName);
      localStorage.setItem("dictionary_id", dict_id);
      localStorage.setItem("gettxt_id", gettxt_id);

    createPopup();
  }

  // create auto translate popup
  function createPopup() {
    openProviderModal();
  }

  function onYandexTranslateClick() {
    $('.tpap-preloader-wrap').show();
    $('.modal-body').hide();
    var tr_type = $('#tpap_yandex_transate_btn').attr("data-translate-engen");
    $(".save_it").prop("disabled", true);
    $(".tpap-stats").css("display", "none");
    var default_code = localStorage.getItem("language_code");
    if($(".string_container").find(".yandex-translation-info").length === 0) {
      $(".string_container").prepend("<div class='yandex-translation-info'>Translating Strings into " + localStorage.getItem("target_language_name") + " Using Yandex Translator.</div>");
    }
    var arr = ['iw','ki', 'en', 'pl', 'af', 'jv', 'no', 'am', 'ar', 'az', 'ba', 'be', 'bg', 'bn', 'bs', 'ca', 'ceb', 'cs', 'cy', 'da', 'de', 'el', 'en', 'eo', 'es', 'et', 'eu', 'fa', 'fi', 'fr', 'ga', 'gd', 'gl', 'gu', 'he', 'hi', 'hr', 'ht', 'hu', 'hy', 'id', 'is', 'it', 'ja', 'jv', 'ka', 'kk', 'km', 'kn', 'ko', 'ky', 'la', 'lb', 'lo', 'lt', 'lv', 'mg', 'mhr', 'mi', 'mk', 'ml', 'mn', 'mr', 'mrj', 'ms', 'mt', 'my', 'ne', 'nl', 'no', 'pa', 'pap', 'pl', 'pt', 'ro', 'ru', 'si', 'sk', 'sl', 'sq', 'sr', 'su', 'sv', 'sw', 'ta', 'te', 'tg', 'th', 'tl', 'tr', 'tt', 'udm', 'uk', 'ur', 'uz', 'vi', 'xh', 'yi', 'zh'];
    if (arr.includes(default_code)) {
      $(".modal-body .translator-widget, .notice-info, .is-dismissible").show();
      addStringsInModal(tr_type);
    } else {
      $('.tpap-preloader-wrap').hide();
      $('.modal-body').show();
      $(".notice-container")
        .addClass("notice inline notice-warning tpap-modern-alert not-supported")
        .html("<div class='tpap-modern-alert-body'>Yandex Automatic Translator Does not support this language.</div>");
      $(
        ".string_container, .choose-lang, .save_it, .notice-info, .is-dismissible"
      ).hide();
      $(".modal-body .translator-widget").hide();
    }
    closeProviderModal();
    $(".yandex-widget-container").css("display", "flex").hide().fadeIn("slow", function() {
        $(document).trigger('tpap_yandex_modal_open');
    });
  }

  function onGoogleTranslateClick(){
    $('.tpap-preloader-wrap').show();
    $('.modal-body').hide();
    var tr_type = $('#tpap_gtranslate_btn').attr("data-translate-engen");
    $(".save_it").prop("disabled", true);
    $(".tpap-stats").css("display", "none");
    var default_code = localStorage.getItem("language_code");
    var arr = ['ck', 'sz', 'oc','ki','dz' ,'fu', 'bo', 'as', 'af', 'en', 'pl', 'af', 'jv', 'no', 'am', 'ar', 'az', 'ba', 'be', 'bg', 'bn', 'bs', 'ca', 'ceb', 'cs', 'cy', 'da', 'de', 'el', 'en', 'eo', 'es', 'et', 'eu', 'fa', 'fi', 'fr', 'ga', 'gd', 'gl', 'gu', 'he', 'hi', 'hr', 'ht', 'hu', 'hy', 'id', 'is', 'it', 'ja', 'jv', 'ka', 'kk', 'km', 'kn', 'ko', 'ky', 'la', 'lb', 'lo', 'lt', 'lv', 'mg', 'mhr', 'mi', 'mk', 'ml', 'mn', 'mr', 'mrj', 'ms', 'mt', 'my', 'ne', 'nl', 'no', 'pa', 'pap', 'pl', 'pt', 'ro', 'ru', 'si', 'sk', 'sl', 'sq', 'sr', 'su', 'sv', 'sw', 'ta', 'te', 'tg', 'th', 'tl', 'tr', 'tt', 'udm', 'uk', 'ur', 'uz', 'vi', 'xh', 'yi', 'zh'];
    if (arr.includes(default_code)) {
      $(".modal-body .translator-widget, .notice-info, .is-dismissible").show();
      addStringsInModal(tr_type, default_code);
    } else {
      $('.tpap-preloader-wrap').hide();
      $('.modal-body').show();
      $(".notice-container")
        .addClass("notice inline notice-warning tpap-modern-alert not-supported")
        .html("<div class='tpap-modern-alert-body'>Google Automatic Translator Does not support this language.</div>");
      $(
        ".string_container, .choose-lang, .save_it, .notice-info, .is-dismissible"
      ).hide();
      $(".modal-body .translator-widget").hide();
    }
    closeProviderModal();
    $(".google-widget-container").css("display", "flex").hide().fadeIn("slow");
  }

  function onChromeTranslateClick(triggerEl){
    $('.tpap-preloader-wrap').show();
    $('.modal-body').hide();
    // Chrome can be triggered by different buttons (provider selection row vs modal button).
    // Always derive provider type from the clicked element, with a safe fallback.
    var $trigger = triggerEl ? $(triggerEl) : $();
    var tr_type = $trigger.attr("data-translate-engen") || $('#chrome-ai-translator_settings_btn').attr("data-translate-engen") || "chrome-ai-translator";
    $(".save_it").prop("disabled", true);
    $(".tpap-stats").css("display", "none");
    var default_code = localStorage.getItem("language_code");
    var arr = ['en', 'pl', 'af', 'jv', 'no', 'am', 'ar', 'az', 'ba', 'be', 'bg', 'bn', 'bs', 'ca', 'ceb', 'cs', 'cy', 'da', 'de', 'el', 'en', 'eo', 'es', 'et', 'eu', 'fa', 'fi', 'fr', 'ga', 'gd', 'gl', 'gu', 'he', 'hi', 'hr', 'ht', 'hu', 'hy', 'id', 'is', 'it', 'ja', 'jv', 'ka', 'kk', 'km', 'kn', 'ko', 'ky', 'la', 'lb', 'lo', 'lt', 'lv', 'mg', 'mhr', 'mi', 'mk', 'ml', 'mn', 'mr', 'mrj', 'ms', 'mt', 'my', 'ne', 'nl', 'no', 'pa', 'pap', 'pl', 'pt', 'ro', 'ru', 'si', 'sk', 'sl', 'sq', 'sr', 'su', 'sv', 'sw', 'ta', 'te', 'tg', 'th', 'tl', 'tr', 'tt', 'udm', 'uk', 'ur', 'uz', 'vi', 'xh', 'yi', 'zh'];
    if (arr.includes(default_code)) {
      $(".modal-body .translator-widget, .notice-info, .is-dismissible").show();
      addStringsInModal(tr_type, default_code);
    } else {
      $('.tpap-preloader-wrap').hide();
      $('.modal-body').show();
      $(".notice-container")
        .addClass("notice inline notice-warning tpap-modern-alert not-supported")
        .html("<div class='tpap-modern-alert-body'>Chrome Translator Does not support this language.</div>");
      $(
        ".string_container, .choose-lang, .save_it, .notice-info, .is-dismissible"
      ).hide();
      $(".modal-body .translator-widget").hide();
    }
    closeProviderModal();
    $(".chrome-ai-translator-container").css("display", "flex").hide().fadeIn("slow");
  }

  function onAiProviderTranslateClick(widgetType, aiProviderId) {
    $('.tpap-preloader-wrap').show();
    $('.modal-body').hide();
    $(".save_it").prop("disabled", true);
    $(".retry_missing_it").prop("disabled", true).hide();
    $(".tpap-stats").css("display", "none");

    addStringsInModal(widgetType);

    closeProviderModal();
    var containerClass = widgetType + '-widget-container';
    $("." + containerClass).css("display", "flex").hide().fadeIn("slow");
  }

  async function translateStringsWithAiProvider(widgetType, aiProviderId, options) {
    options = options || {};
    var onlyMissing = options.onlyMissing !== false;
    var containerClass = widgetType + '-widget-container';
    var $container = $("." + containerClass);
    // Reuse the same progress UI as other providers (my_translate_progress box).
    var $progressBox = $container.find('.my_translate_progress');
    var $progressBar = $progressBox.find('.progress-bar');
    var $progressText = $progressBox.find('#progressText');
    var $stringContainer = $container.find(".string_container");
    var $table = $container.find("table.tpap-stringTemplate");
    var $rows = $table.find("tbody tr");
    var $noticeContainer = $container.find(".notice-container").first();
    var $saveBtn = $container.find(".save_it");
    var $retryBtn = $container.find(".retry_missing_it");
    var totalRows = $rows.length;

    if (totalRows === 0) return;
    $container.attr("data-ai-provider-id", aiProviderId);
    $container.attr("data-ai-widget-type", widgetType);
    $retryBtn.prop("disabled", true).hide();

    $progressBox.show().fadeIn("slow");
    $progressBar.css('width', '0%');
    $progressBar.removeClass('tpap-progress-waiting');
    if ($progressText.length) {
      $progressText.text('0%');
    }
    // Match other providers: start at top, then auto-scroll as progress advances.
    if ($stringContainer.length) {
      $stringContainer.stop(true);
      $stringContainer.scrollTop(0);
    }

    var stringsToTranslate = [];
    $rows.each(function () {
      var id = $(this).find("td.source").data("db-id");
      var original = $(this).find("td.source").text().trim();
      var targetText = $(this).find("td.target").text().trim();
      if (id && original && (!onlyMissing || !targetText)) {
        stringsToTranslate.push({ id: String(id).trim(), original: original });
      }
    });

    if (stringsToTranslate.length === 0) {
      if ($noticeContainer.length) {
        $noticeContainer
          .addClass("notice inline notice-warning tpap-modern-alert tpap-modern-alert--warning")
          .html("<div class='tpap-modern-alert-body'>No strings to translate.</div>");
      }
      return;
    }

    var sourceLang = localStorage.getItem("default_language") || '';
    var targetLang = localStorage.getItem("language_name") || '';
    // Smaller chunks reduce server timeouts on long pages.
    var chunkSize = 20;
    var queue = [];
    for (var i = 0; i < stringsToTranslate.length; i += chunkSize) {
      queue.push(stringsToTranslate.slice(i, i + chunkSize));
    }

    async function requestChunk(chunk) {
      return await $.ajax({
        type: "POST",
        url: ajaxUrl,
        dataType: "json",
        // Some hosts/proxies kill long admin-ajax requests; keep this high but rely on chunking.
        timeout: 600000,
        data: {
          action: 'tpap_ai_translate_single',
          provider: aiProviderId,
          source_lang: sourceLang,
          target_lang: targetLang,
          strings: JSON.stringify(chunk),
          _ajax_nonce: nonce
        }
      });
    }

    async function processChunkWithSplit(chunk) {
      try {
        return await requestChunk(chunk);
      } catch (err) {
        // If we timed out and chunk can be split, split and retry smaller requests.
        if (err && err.statusText === 'timeout' && chunk && chunk.length > 1) {
          var mid = Math.ceil(chunk.length / 2);
          var left = chunk.slice(0, mid);
          var right = chunk.slice(mid);
          var leftRes = await processChunkWithSplit(left);
          var rightRes = await processChunkWithSplit(right);
          return { __split: true, results: [leftRes, rightRes] };
        }
        throw err;
      }
    }

    var allTranslations = {};
    var translatedCount = 0;
    var errorOccurred = false;
    function hasNonEmptyTranslation(value) {
      return typeof value === "string" && value.trim().length > 0;
    }

    function getAiErrorHint(message) {
      var m = String(message || '').toLowerCase();
      if (m.indexOf('rate limit') !== -1) {
        return 'Wait a few minutes, then try again. If this keeps happening, confirm your API quota or billing in the provider dashboard.';
      }
      if (m.indexOf('timeout') !== -1 || m.indexOf('timed out') !== -1) {
        return 'The server took too long to respond. Try again shortly, or translate a page with fewer strings.';
      }
      if (m.indexOf('api key') !== -1 || m.indexOf('unauthorized') !== -1 || m.indexOf('401') !== -1) {
        return 'Check that your API key is saved correctly in the plugin settings.';
      }
      return 'You can close this dialog and try again when ready.';
    }

    function showAiModalNotice(message) {
      if (!$noticeContainer || !$noticeContainer.length) return;
      var hint = getAiErrorHint(message);
      var $icon = $('<div class="tpap-modern-alert-icon" aria-hidden="true">!</div>');
      var $body = $("<div class='tpap-modern-alert-body'></div>").append(
        $("<strong class='tpap-ai-error-primary'></strong>").text(message)
      );
      if (hint) {
        $body.append($("<p class='tpap-ai-error-hint'></p>").text(hint));
      }
      var $closeBtn = $(
        '<button type="button" class="tpap-modern-alert-close notice-dismiss" aria-label="Dismiss"></button>'
      );
      $noticeContainer
        .removeClass()
        .addClass(
          "notice inline notice-error tpap-modern-alert tpap-modern-alert--error is-dismissible ai-translation-error"
        )
        .empty()
        .append($icon, $body, $closeBtn);
      // Full failure: hide table + provider heading; show error only (partial success keeps UI).
      if (translatedCount === 0) {
        $container.find(".string_container").hide();
        $container.find(".translator-widget").hide();
        if ($progressBox && $progressBox.length) {
          $progressBox.stop(true, true).hide();
        }
      }
      var el = $noticeContainer.get(0);
      if (el && el.scrollIntoView) {
        try {
          el.scrollIntoView({ behavior: "smooth", block: "nearest" });
        } catch (scrollErr) {
          el.scrollIntoView(true);
        }
      }
    }

    localStorage.setItem("translationStartTime", new Date().getTime());

    var totalInitialChunks = queue.length;
    var processedInitialChunks = 0;

    while (queue.length) {
      if (errorOccurred) break;

      try {
        // Slow providers can take time to respond; show an indeterminate "waiting" state.
        $progressBar.addClass('tpap-progress-waiting');
        if ($progressText.length) {
          $progressText.text('Translating...');
        }
        var chunk = queue.shift();
        var result = await processChunkWithSplit(chunk);

        $progressBar.removeClass('tpap-progress-waiting');
        // If we split, flatten results; otherwise handle single response.
        var resultsToApply = (result && result.__split) ? result.results : [result];
        for (var r = 0; r < resultsToApply.length; r++) {
          var res = resultsToApply[r];
          if (res && res.success && res.data && res.data.translations) {
            var translations = res.data.translations;
            for (var key in translations) {
              if (translations.hasOwnProperty(key)) {
                var translatedText = translations[key];
                if (hasNonEmptyTranslation(translatedText)) {
                  allTranslations[key] = translatedText;
                  translatedCount++;
                }
              }
            }
          } else {
            var errMsg = (res && res.data && res.data.message) ? res.data.message : 'Unknown error';
            console.warn('AI translation failed (server response)', errMsg, res);
            showAiModalNotice(errMsg);
            errorOccurred = true;
            break;
          }
        }
      } catch (ajaxErr) {
        $progressBar.removeClass('tpap-progress-waiting');
        var msg = 'Translation request failed.';
        if (ajaxErr.statusText === 'timeout') {
          msg = 'Request timed out. Retrying with smaller batches...';
        }
        var originalAjax =
          ajaxErr && (ajaxErr.responseJSON != null ? ajaxErr.responseJSON : ajaxErr.responseText);
        console.warn('AI translation request error', msg, {
          status: ajaxErr && ajaxErr.status,
          statusText: ajaxErr && ajaxErr.statusText,
          original: originalAjax != null && originalAjax !== '' ? originalAjax : ajaxErr
        });
        showAiModalNotice(msg);
        errorOccurred = true;
      }

      processedInitialChunks++;
      var pct = totalInitialChunks
        ? Math.min(100, Math.round((processedInitialChunks / totalInitialChunks) * 100))
        : 100;
      $progressBar.css('width', pct + '%');
      if ($progressText.length) {
        $progressText.text(pct + '%');
      }
      // Auto-scroll the strings container to match progress (smooth, non-blocking).
      if ($stringContainer.length) {
        var el = $stringContainer.get(0);
        if (el && el.scrollHeight && el.clientHeight) {
          var maxScroll = Math.max(0, el.scrollHeight - el.clientHeight);
          var targetScroll = Math.round((pct / 100) * maxScroll);
          $stringContainer.stop(true).animate({ scrollTop: targetScroll }, 220, "linear");
        }
      }
    }

    $rows.each(function () {
      var id = String($(this).find("td.source").data("db-id")).trim();
      if (hasNonEmptyTranslation(allTranslations[id])) {
        $(this).find("td.target").text(allTranslations[id]);
      }
    });

    var unresolvedRows = [];
    $rows.each(function () {
      var $row = $(this);
      var rowId = String($row.find("td.source").data("db-id") || "").trim();
      if (!rowId) return;
      var target = $row.find("td.target").text().trim();
      if (!target) {
        unresolvedRows.push(rowId);
      }
    });

    calculateAndSaveTranslationTime();

    if (!errorOccurred && translatedCount > 0) {
      $saveBtn.prop("disabled", false);
      $container.find(".tpap-stats").fadeIn("slow");
    } else if (errorOccurred && translatedCount > 0) {
      $saveBtn.prop("disabled", false);
      $container.find(".tpap-stats").fadeIn("slow");
    }
    if (unresolvedRows.length > 0) {
      $retryBtn
        .text("Retry Empty (" + unresolvedRows.length + ")")
        .prop("disabled", false)
        .show();
      if (!errorOccurred && $noticeContainer.length) {
        $noticeContainer
          .removeClass()
          .addClass("notice inline notice-warning tpap-modern-alert tpap-modern-alert--warning is-dismissible ai-translation-partial")
          .html(
            "<div class='tpap-modern-alert-body'><strong>" +
              unresolvedRows.length +
              "</strong> strings came back empty. You can merge translated rows now, or retry the empty ones.</div><button type='button' class='tpap-modern-alert-close notice-dismiss' aria-label='Dismiss'></button>"
          );
      }
    } else {
      $retryBtn.hide();
    }

    // Match other providers: hide the progress box once translation is complete (skip if already hidden on full error).
    if ($progressBox && $progressBox.length && $progressBox.is(":visible")) {
      setTimeout(function () {
        if ($progressBox.is(":visible")) {
          $progressBox.fadeOut("slow");
        }
      }, 1500);
    }

    // Ensure we end at the bottom like other providers (skip when table hidden after error).
    if ($stringContainer.length && $stringContainer.is(":visible")) {
      $stringContainer.stop(true);
      $stringContainer.scrollTop($stringContainer.get(0).scrollHeight || 0);
    }
  }

  function getAiProviderIdFromWidgetType(widgetType) {
    var map = { openai: 'openai', gemini: 'google', anthropic: 'anthropic' };
    return map[widgetType] || widgetType;
  }

  function isProviderModalOpen(){
    return $("#tpap-provider-overlay").is(":visible");
  }

  function openProviderModal(){
    const $overlay = $("#tpap-provider-overlay");
    if(!$overlay.length) return;

    $("body").addClass("tpap-provider-modal-open");
    $overlay.css("display", "flex").hide().fadeIn(120);

    // Auto-select first card (prefer one with an enabled action)
    const $selected = $overlay.find(".tpap-provider-card.is-selected").first();
    if ($selected.length === 0) {
      const $firstSelectableTranslate = $overlay.find(".tpap-provider-card").filter(function(){
        const $card = $(this);
        if(!isProviderCardSelectable($card)) return false;
        const $action = $card.find('[data-provider-action-slot]').first();
        return getEnabledProviderTranslateButtons($action).length > 0;
      }).first();
      const $fallbackSelectable = $overlay.find(".tpap-provider-card").filter(function(){
        return isProviderCardSelectable($(this));
      }).first();
      selectProviderCard($firstSelectableTranslate.length ? $firstSelectableTranslate : $fallbackSelectable);
    } else {
      refreshProviderStartButtonState();
    }
  }

  function closeProviderModal(){
    const $overlay = $("#tpap-provider-overlay");
    if(!$overlay.length) return;
    $overlay.fadeOut(120);
    $("body").removeClass("tpap-provider-modal-open");
  }

  function getProviderCard(providerKey){
    return $("#tpap-dialog").find(`.tpap-provider-card[data-provider-key="${providerKey}"]`);
  }

  function isProviderCardSelectable($card){
    if(!$card || !$card.length) return false;
    const attr = $card.attr('data-provider-selectable');
    if (attr === undefined || attr === null || attr === '') return true;
    return attr === '1' || attr === 'true';
  }

  function getEnabledProviderTranslateButtons($action){
    if(!$action || !$action.length) return $();
    return $action
      .find('.tpap-provider-btn.translate[data-translate-engen]')
      .filter(':not(:disabled)');
  }

  function setProviderCardSelectable($card, selectable){
    if(!$card || !$card.length) return;
    $card.attr('data-provider-selectable', selectable ? '1' : '0');
    $card.toggleClass('is-disabled', !selectable);
    $card.attr('aria-disabled', selectable ? 'false' : 'true');
    $card.attr('tabindex', selectable ? '0' : '-1');

    if(!selectable){
      $card.removeClass('is-selected').attr('aria-pressed','false');
    }
  }

  function selectProviderCard($card){
    if(!$card || !$card.length) return;
    if(!isProviderCardSelectable($card)) return;
    const $root = $("#tpap-dialog");
    $root.find(".tpap-provider-card").removeClass("is-selected").attr("aria-pressed", "false");
    $card.addClass("is-selected").attr("aria-pressed", "true");
    refreshProviderStartButtonState();
  }

  function getProviderStartTarget($card){
    if(!$card || !$card.length) return null;
    const $action = $card.find('[data-provider-action-slot]').first();
    if(!$action.length) return null;

    // Prefer a visible/enabled translate button (dynamic via data-translate-engen)
    const $translateBtn = getEnabledProviderTranslateButtons($action).first();
    if($translateBtn.length) return { type: 'click', $el: $translateBtn };

    // If it's a configure button (with onclick), allow clicking it as the start action
    const $configureBtn = $action.find('.tpap-chromeai-disabled-message:not(:disabled)').first();
    if($configureBtn.length) return { type: 'click', $el: $configureBtn };

    // If it contains a license link (Google without license), treat it as a start action by opening it
    const $link = $action.find('a[href]').first();
    if($link.length) return { type: 'href', href: $link.attr('href') };

    return null;
  }

  function syncProviderCtaFromAction($card){
    if(!$card || !$card.length) return;
    const $cta = $card.find('[data-provider-cta-slot]').first();
    const $action = $card.find('[data-provider-action-slot]').first();
    if(!$cta.length || !$action.length) return;

    // If translate is available, no CTA pill is needed
    const $translate = getEnabledProviderTranslateButtons($action).first();
    if($translate.length){
      $cta.html('');
      setProviderCardSelectable($card, true);
      return;
    }

    // Configure CTA (Chrome)
    const $configure = $action.find('.tpap-chromeai-disabled-message:not(:disabled)').first();
    if($configure.length){
      $cta.html('<button type="button" class="tpap-provider-cta-btn tpap-provider-cta-btn--danger">Configure</button>');
      // Clicking the button should run the same action
      $cta.find('button').off('click').on('click', function(e){
        e.preventDefault();
        $configure.trigger('click');
      });
      // Configure should be light/disabled (not selectable), but still actionable via the button
      setProviderCardSelectable($card, false);
      return;
    }

    // Not supported (disabled)
    const $notSupported = $action.find('.tpap-chromeai-disabled-message:disabled').first();
    if($notSupported.length){
      $cta.html('<button type="button" class="tpap-provider-cta-btn tpap-provider-cta-btn--muted" disabled>Not Supported</button>');
      setProviderCardSelectable($card, false);
      return;
    }

    // Link CTA (e.g. "Add License Key" / "Add API Key")
    const $link = $action.find('a[href]').first();
    if($link.length){
      const href = $link.attr('href') || '';
      const linkBtnText = ($link.find('button').first().text() || '').trim();
      const label = linkBtnText || (href.indexOf('#tpap-bulk-translation-section') !== -1 ? 'Add API Key' : 'Open');
      const variantClass = (label.toLowerCase().indexOf('api') !== -1) ? 'tpap-provider-cta-btn--danger' : 'tpap-provider-cta-btn--warning';

      $cta.html(`<button type="button" class="tpap-provider-cta-btn ${variantClass}">${label}</button>`);
      $cta.find('button').off('click').on('click', function(e){
        e.preventDefault();
        if (href) window.open(href, '_blank');
      });
      setProviderCardSelectable($card, false);
      return;
    }

    // Loading placeholder
    const $loading = $action.find('#tpap-chrome-btn-placeholder').first();
    if($loading.length){
      $cta.html('<button type="button" class="tpap-provider-cta-btn tpap-provider-cta-btn--muted" disabled>Loading…</button>');
      setProviderCardSelectable($card, true);
      return;
    }
  }

  function refreshProviderStartButtonState(){
    const $start = $("#tpap-provider-start");
    if(!$start.length) return;
    const $selected = $("#tpap-dialog").find(".tpap-provider-card.is-selected").first();
    if ($selected.length && !isProviderCardSelectable($selected)) {
      $start.prop("disabled", true);
      return;
    }
    const target = getProviderStartTarget($selected);
    $start.prop("disabled", !target);
  }

  function startSelectedProvider(){
    const $selected = $("#tpap-dialog").find(".tpap-provider-card.is-selected").first();
    const target = getProviderStartTarget($selected);
    if(!target) return;
    if(target.type === 'click') {
      target.$el.trigger('click');
      return;
    }
    if(target.type === 'href' && target.href) {
      window.open(target.href, '_blank');
    }
  }

  function calculateAndSaveTranslationTime() {
    const endTime = new Date().getTime();
    const startTime = parseInt(localStorage.getItem("translationStartTime")); 
    const totalTime = (endTime - startTime) / 1000;
    localStorage.setItem("total_translation_time", totalTime);
  }

  function translation_process() {
    var container = $(".google-widget-container");
    container.find(".string_container").scrollTop(0);
    var scrollHeight = container.find(".string_container").get(0).scrollHeight;
    var scrollSpeed = 800;
    if (scrollHeight > scrollSpeed) {
      scrollSpeed = scrollHeight;
    }
    if (scrollHeight !== undefined && scrollHeight > 100) {
      // Store start time as timestamp instead of Date object
      localStorage.setItem("translationStartTime", new Date().getTime());
      container.find(".progress-wrapper").show();
      container.find(".my_translate_progress").fadeIn("slow");
      const progressBar = container.find(".progress-wrapper .progress-bar");
      setTimeout(() => {
        container.find(".string_container").animate(
          {
            scrollTop: scrollHeight + 2000,
          },
          scrollSpeed * 2,
          "linear"
        );
      }, 1000);
      container.find(".string_container").on("scroll", function (e) {
        var scrollTop = e.target.scrollTop;
        var scrollHeight = e.target.scrollHeight;
        var clientHeight = e.target.clientHeight;
        var scrollPercentage = (scrollTop / (scrollHeight - clientHeight)) * 100;
        progressBar.css('width', scrollPercentage + '%');
        progressBar.find('#progressText').text((Math.round(scrollPercentage * 10) / 10).toFixed(1) + '%');
        if (
          $(this).scrollTop() + $(this).innerHeight() + 50 >=
          $(this)[0].scrollHeight
        ) {
          setTimeout(() => {
            calculateAndSaveTranslationTime();
            container.find(".save_it").prop("disabled", false);
            container.find(".tpap-stats").fadeIn("slow");
            container.find(".my_translate_progress").fadeOut("slow");
            container.find(".string_container").stop();
            $("body").css("top", "0");
          }, 1500);
          
        }
      });
      if (
        container.find(".string_container").innerHeight() + 10 >=
        scrollHeight
      ) {
        setTimeout(() => {
          calculateAndSaveTranslationTime();
          container.find(".save_it").prop("disabled", false);
          container.find(".tpap-stats").fadeIn("slow");
          container.find(".my_translate_progress").fadeOut("slow");
          container.find(".string_container").stop();
          $("body").css("top", "0");
        }, 1500);
      }
    } else {
      setTimeout(() => {}, 2000);
    }
  }

  function addStringsInModal(tr_type, default_code) {
    var language_code = localStorage.getItem("language_name");
    var lang_code = localStorage.getItem("language_code");
    var default_lang = localStorage.getItem("default_language");
    var current_page_db_id = localStorage.getItem("dictionary_id");
    var gettxt_id = localStorage.getItem("gettxt_id");
    var request_data = {
      action: "tpap_get_strings",
      data: language_code,
      dictionary_id: current_page_db_id,
      gettxt_id: gettxt_id,
      default_lang: default_lang,
      _ajax_nonce: nonce,
    };
    $.ajax({
      type: "POST",
      url: ajaxUrl,
      dataType: "json",
      data: request_data,
      success: function (response) {
        var plainStrArr = response;
        var strings = new Array();
        var group = new Array();
        var idss = new Array();
        var i = 0;
        plainStrArr.forEach(function (entry) {
          strings[i] = entry.strings;
          group[i] = entry.data_group;
          idss[i] = entry.database_ids;
          i++;
        });
        if (plainStrArr.length > 0) {
          $(".tpap-preloader-wrap").hide();
          $("#tpap-notice-check").show();
          $(".modal-body").show();
          if (tr_type == "google") {
            if (licensekeys == "No") {
              $("#tpap-notice-check").remove();
              $(".choose-lang").before(
                '<div class="notice inline notice-info is-dismissible" id="tpap-notice-check" style="">AI Translation For TranslatePress (Pro) - License key is missing! Please add your License key in the settings panel to activate all premium features.</div>'
              );
              return;
            } else {
              $("html").addClass("notranslate");
              googleTranslateElementInit(default_code);
              printStringsInPopup(strings, tr_type, group, idss);
            }
          } else {
            $("html").attr("translate", "no");
            printStringsInPopup(strings, tr_type, group, idss);
          }
          if (tr_type == "yandex") {
            $(document).trigger('tpap:yandex-start');
            setTimeout(function() {
              $("#ytWidget .yt-button_type_left").trigger("click");
            }, 1000);
          }
          if(tr_type == "google"){
            // Wait for Google Translate widget to be fully initialized
            var attempts = 0;
            var maxAttempts = 20; // Try for up to 10 seconds (20 * 500ms)
            var checkInterval = setInterval(function() {
              attempts++;
              var $select = $("#google_translate_element").find("select.goog-te-combo");
              
              // Check if select exists and has options loaded
              if ($select.length && $select.find("option").length > 0) {
                clearInterval(checkInterval);
                
                // Check if the target language option exists
                var $targetOption = $select.find("option[value='" + lang_code + "']");
                if ($targetOption.length) {
                  // Set the value and trigger change event
                  $select.val(lang_code);
                  
                  // Trigger both change and input events to ensure Google Translate processes it
                  $select.trigger("change");
                  $select.trigger("input");
                  
                  // Also try triggering on the select element directly
                  if ($select[0]) {
                    var event = new Event('change', { bubbles: true });
                    $select[0].dispatchEvent(event);
                  }
                  
                  // Call translation_process after a short delay to ensure translation starts
                  setTimeout(function() {
                    translation_process();
                  }, 500);
                }
              } else if (attempts >= maxAttempts) {
                clearInterval(checkInterval);
                console.warn("Google Translate widget did not initialize in time");
              }
            }, 500);
          }
          if(tr_type == "chrome-ai-translator"){
            tpapChromeAiInit();
            setTimeout(function() {
              $(".chrome_ai_translator_btn").trigger("click");
            }, 1000);
          }
          if(tr_type == "openai" || tr_type == "gemini" || tr_type == "anthropic"){
            var aiPid = getAiProviderIdFromWidgetType(tr_type);
            translateStringsWithAiProvider(tr_type, aiPid);
          }
        } else {
          $('.tpap-preloader-wrap').hide();
          $('.modal-body .translator-widget, .notice-info, .is-dismissible').hide();
          $(".modal-body").show();

          if ($(".tpap_custom_model .notice-container").length > 0) {
            $(".notice-container")
              .addClass("notice inline notice-warning tpap-modern-alert tpap-modern-alert--warning no-strings-available")
              .html("<div class='tpap-modern-alert-body'>There is no plain string available for translations.</div>");
          } else {
            $(".modal-content").append("<div class='notice-container'></div>");
            $(".notice-container")
              .addClass("notice inline notice-warning tpap-modern-alert tpap-modern-alert--warning no-strings-available")
              .html("<div class='tpap-modern-alert-body'>There is no plain string available for translations.</div>");
          }
          $(".string_container").hide();
          $(".choose-lang").hide();
          $(".save_it, .retry_missing_it").hide();
        }
      },
    });
  }

  function printStringsInPopup(jsonObj, type, group, idss) {
    if (type == "google" && licensekeys == "No") {
      return;
    }
    $(".notice-container.notice.inline.notice-warning").remove();
    $(".string_container").show();
    $(".choose-lang").show();
    $(".save_it").show();
    $(".retry_missing_it").hide();
    var html = "";
    var totalTChars = 0;
    var index = 1;
    if (jsonObj) {
      for (const key in jsonObj) {
        if (jsonObj.hasOwnProperty(key)) {
          const groups = group[key];
          const element = jsonObj[key];
          if (element.source != "") {
            if (type == "google" || type == "yandex" || type == "chrome-ai-translator") {
              html += `<tr id="${key}"><td>${index}</td><td  class="notranslate source" data-group= "${group[key]}" data-db-id =" ${idss[key]}">${element}</td>`;
            } else {
              if (key > 2500) {
                break;
              }
              html += `<tr id="${key}"><td>${index}</td><td  class="notranslate source" data-group= "${group[key]}" data-db-id =" ${idss[key]}">${element}</td>`;
            }
            if (type == "google" || type == "yandex" || type == "chrome-ai-translator") {
              html += `<td translate ="yes" class = "target translate">${element}</td></tr>`;
            } else {
              html += `<td class ="target translate"></td></tr>`;
            }
            index++;
            totalTChars += element.length;
          }
        }
      }
  $(".tpap-stats").each(function () {
        $(this).find(".totalChars").html(totalTChars);
      });
    }
    $(`#${type}_tpap_string_tbl_body`).html(html);
  }

  // Dismiss notices (delegated because modals are injected dynamically)
  $(document).on("click", ".tpap_custom_model .notice-dismiss, .tpap_custom_model .tpap-modern-alert-close", function () {
    $(this).closest(".notice, .tpap-modern-alert").fadeOut("slow");
  });
  
  function isYandexModal($modal) {
    return $modal && $modal.length && ($modal.is("#tpa_yandex_model") || $modal.hasClass("yandex-widget-container"));
  }

  // Close modal (delegated)
  $(document).on("click", ".tpap_custom_model .modal-content .close, .tpap_custom_model .tpap-modern-close", () => {
    const $modal = $('.tpap_custom_model');
    if (isYandexModal($modal)) {
        destroyYandexTranslator();
    }
    $modal.fadeOut("slow");
    location.reload(true);
    tpa_google_Reset();
  });
  
  window.tpa_google_Reset = () => $('#\\:1\\.container').contents().find('#\\:1\\.restore').click();

  function getStringsModalId(widgetType){
    const safe = String(widgetType || 'default').toLowerCase().replace(/[^a-z0-9]+/g, '_');
    return `tpap_strings_model_${safe}`;
  }

  function destroyYandexTranslator() {
    if (typeof window.tpapDestroyYandexTranslation === 'function') {
        window.tpapDestroyYandexTranslation();
    } else {
        $(document).trigger('tpap:yandex-cancel');
    }
    $('.yt-button__icon.yt-button__icon_type_right').trigger('click');
    $('.yandex-widget-container').find('.string_container').scrollTop(0);

    const progressContainer = $('.yandex-widget-container').find('.my_translate_progress');
    progressContainer.hide();
    progressContainer.find('.progress-wrapper').hide();
    progressContainer.find('#myProgressBar').css('width', '0');
    progressContainer.find('#progressText').text('0%');
  }

  function createStringsModal(widgetType) {
    //Set wrapper, header, and body classes based on widgetType
    let { wrapperCls, headerCls, bodyCls, footerCls } = getWidgetClasses(widgetType);
    const modalId = getStringsModalId(widgetType);
    let modelHTML = `
    <div id="${modalId}" class="modal tpap_custom_model ${wrapperCls} ${rtlClass}">
      <div class="modal-content">
        <input type="hidden" id="project_id" >
        ${modelHeaderHTML(widgetType, headerCls)}   
        ${modelBodyHTML(widgetType, bodyCls)}   
        ${modelFooterHTML(widgetType, footerCls)}
      </div>
    </div>`;
    // Defensive: remove existing modal for this widgetType before re-injecting
    $(`#${modalId}`).remove();
    $("body").prepend(modelHTML);
  }

  // Get widget classes based on widgetType
  function getWidgetClasses(widgetType) {
    let wrapperCls = "";
    let headerCls = "";
    let bodyCls = "";
    let footerCls = "";
    let wrapperId; 
    switch (widgetType) {
        case "yandex":
            wrapperCls = "yandex-widget-container";
            headerCls = "yandex-widget-header";
            bodyCls = "yandex-widget-body";
            footerCls = "yandex-widget-footer";
            break;

        case "google":
            wrapperCls = "google-widget-container";
            headerCls = "google-widget-header";
            bodyCls = "google-widget-body";
            footerCls = "google-widget-footer";
            break;

        case "chrome-ai-translator":
            wrapperCls = "chrome-ai-translator-container chrome-ai-translator-modal";
            headerCls = "chrome-ai-translator-header";
            bodyCls = "chrome-ai-translator-body";
            footerCls = "chrome-ai-translator-footer";
            break;
        case "openai":
            wrapperCls = "openai-widget-container";
            headerCls = "openai-widget-header";
            bodyCls = "openai-widget-body";
            footerCls = "openai-widget-footer";
            break;
        case "gemini":
            wrapperCls = "gemini-widget-container";
            headerCls = "gemini-widget-header";
            bodyCls = "gemini-widget-body";
            footerCls = "gemini-widget-footer";
            break;
        case "anthropic":
            wrapperCls = "anthropic-widget-container";
            headerCls = "anthropic-widget-header";
            bodyCls = "anthropic-widget-body";
            footerCls = "anthropic-widget-footer";
            break;
        default:
            wrapperCls = "yandex-widget-container";
            headerCls = "yandex-widget-header";
            bodyCls = "yandex-widget-body";
            footerCls = "yandex-widget-footer";
            break;
    }
    return {
        wrapperCls,
        headerCls,
        bodyCls,
        footerCls
      };
  }

  function modelHeaderHTML(widgetType, headerCls) {
    const HTML = `
    <div class="tpap-modern-header modal-header ${headerCls}">
      <div class="tpap-modern-header-top">
        <div class="tpap-modern-step">STEP 4 OF 4</div>
        <button type="button" class="tpap-modern-close" aria-label="Close"></button>
      </div>
      <h2 class="notranslate tpap-modern-title">Start Automatic Translation Process</h2>
    </div>

    <div class="tpap-modern-alert tpap-modern-alert--warning notice inline notice-info is-dismissible" id="tpap-notice-check">
      <div class="tpap-modern-alert-body">
       ⚠️ Machine translations are not 100% correct. Please verify strings before using on production website.
      </div>
      <button type="button" class="tpap-modern-alert-close notice-dismiss" aria-label="Dismiss"></button>
    </div>

      <div class="tpap-preloader-wrap">
          <div class="ph-item">
              <div class="ph-col-12">
                  <div class="ph-row">
                      <div class="ph-col-6 big"></div>
                      <div class="ph-col-4 big"></div>
                      <div class="ph-col-2 big"></div>
                      <div class="ph-col-4"></div>
                      <div class="ph-col-8"></div>
                      <div class="ph-col-6"></div>
                      <div class="ph-col-6"></div>
                      <div class="ph-col-12"></div>
                      <div class="ph-col-4"></div>
                      <div class="ph-col-8"></div>
                      <div class="ph-col-6"></div>
                      <div class="ph-col-6"></div>
                      <div class="ph-col-12"></div>
                      <div class="ph-col-4"></div>
                      <div class="ph-col-8"></div>
                      <div class="ph-col-6"></div>
                      <div class="ph-col-6"></div>
                      <div class="ph-col-12"></div>
                      <div class="ph-col-6 big"></div>
                      <div class="ph-col-4 big"></div>
                      <div class="ph-col-2 big"></div>
                  </div>
              </div>
          </div>
      </div>`;
    return HTML;
  }

  function modelBodyHTML(widgetType, bodyCls) {
    const HTML = `
    <div class="modal-body ${bodyCls}">
      <div class="my_translate_progress">
      <div class="my_translate_progress_content">
            Automatic translation is in progress....<br/>
            It will take a few minutes, enjoy ☕ coffee in this time!<br/><br/>
              <div class="progress-wrapper">
                <div class="progress-container">
                  <div class="progress-bar" id="myProgressBar">
                    <span id="progressText">0%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ${translatorWidget(widgetType)}
      <div class="string_container">
          <table class="scrolldown tpap-stringTemplate" data-widget="${widgetType}">
              <thead>
                  <th class="notranslate">S.No</th>
                  <th class="notranslate">Source Text</th>
                  <th class="notranslate">Translation</th>
              </thead>
              <tbody id="${widgetType}_tpap_string_tbl_body">
              </tbody>
          </table>
      </div>
      <div class="notice-container"></div>
    </div>
  `;
    return HTML;
  }

  function modelFooterHTML(widgetType, footerCls) {
    const HTML = `
    <div class="modal-footer ${footerCls}">
      <div class="tpap-modern-footer">
        <div class="tpap-modern-alert tpap-modern-alert--info tpap-stats" style="display:none">
          <div class="tpap-modern-alert-icon" aria-hidden="true">i</div>
          <div class="tpap-modern-alert-body">
            <strong>Wahooo!</strong> You have saved your valuable time via auto translating
            <strong class="totalChars"></strong> characters using
            <a href="https://wordpress.org/plugins/automatic-translate-addon-for-translatepress/#reviews" target="_new">
              AI Translation For TranslatePress
            </a>.
          </div>
        </div>
        <div class="save_btn_cont">
            <button type="button" class="notranslate retry_missing_it button tpap-modern-retry" style="display:none" disabled="true">
                Retry Empty
            </button>
            <button class="notranslate save_it button button-primary tpap-modern-primary" disabled="true">
                Merge Translation
            </button>
        </div>
      </div>
    </div>
  `;
    return HTML;
  }

  function translatorWidget(widgetType) {
    if (widgetType === "yandex") {
      return ` <div id="ytWidget" style="display:none"></div>`;
    } else if (widgetType === "google") {
      const widgetPlaceholder =
        '<div id="google_translate_element"></div>';
      return `
            <div class="translator-widget">
            <h3 class="choose-lang">Choose language <span class="dashicons-before dashicons-translation"></span></h3>
                ${widgetPlaceholder}
            </div>`;
    } else if (widgetType === 'chrome-ai-translator'){
      return `
      <div class="translator-widget ${widgetType}">
        <h3 class="choose-lang">Translate Using Chrome AI Translator <span class="dashicons-before dashicons-translation"></span></h3>
        <div id="chrome_ai_translator_element"></div>
      </div>`
    } else if (widgetType === 'openai' || widgetType === 'gemini' || widgetType === 'anthropic') {
      const displayNames = { openai: 'OpenAI', gemini: 'Google Gemini', anthropic: 'Anthropic Claude' };
      const displayName = displayNames[widgetType] || widgetType;
      // Share the same progress container UI as other providers (my_translate_progress).
      // Here we only render a heading matching the selected AI provider.
      return `
      <div class="translator-widget ${widgetType}-translator">
        <h3 class="choose-lang">Translate Using ${displayName} <span class="dashicons-before dashicons-translation"></span></h3>
      </div>`;
    } else {
      return "";
    }
  }

  /**
   *
   * This function is used to get language code
   */
  function tpap_language_code(getSelectedlang) {
    var response = getSelectedlang.substring(0, 3);
    var default_code = "";
    var sbstr = getSelectedlang.substring(0, 3);
    if (sbstr == "nb_") {
      default_code = "no";
    } else if (sbstr == "azb") {
      default_code = "azb";
    } else if (sbstr == "ceb") {
      default_code = "ceb";
    } else if (sbstr == "arg") {
      default_code = "arg";
    } else {
      default_code = getSelectedlang.substring(0, 2);
    }
    return default_code;
  }

  function onSaveClick(){
    var translatedObj = [];
    var updatedataObj = [];
    let totalCharacterCount = 0;
    let totalWordCount = 0;
    let totalTranslationTime = localStorage.getItem("total_translation_time");
    const $activeModal = $(".tpap_custom_model:visible").first();
    const $table = $activeModal.find("table.tpap-stringTemplate").first();
    $table.find("tbody tr").each(function (index) {
        
        var provider = $table.data("widget");
        // Get the source text from the current tr
        var sourceText = $(this).find("td.source").text().trim();

        post_id = extradata["post_id"];
        var index = $(this).find("td.source").text();
        var source = $(this).find("td.source").text();
        var target = $(this).find("td.target").text().trim();
        var type = $(this).find("td.source").data("group");
        var db_id = $(this).find("td.source").data("db-id");
        var language_code = localStorage.getItem("language_name");
        var default_lang = localStorage.getItem("default_language");
        var date = new Date().toISOString();
        if (!target) {
          return;
        }
        // Count only rows that are actually being saved.
        var sourceWordCount = sourceText ? sourceText.trim().split(/\s+/).filter(word => /[^\p{L}\p{N}]/.test(word)).length : 0;
        var sourceCharacterCount = sourceText.length;
        totalCharacterCount += sourceCharacterCount;
        totalWordCount += sourceWordCount;
        translatedObj.push({
            "original": source,
            "translated": target,
            "data_group": type,
            "language_code": language_code,
            "id": db_id,
            "status": "2",
            "default_lang": default_lang
        });
        updatedataObj = {
            'language_code': language_code,
            'default_lang': default_lang,
            'provider' : provider,
            'timeTaken' : totalTranslationTime,
            'totalWordCount' : totalWordCount,
            'totalCharacterCount' : totalCharacterCount,
            'date' : date,
            'post_id' : post_id
          };
    });
    if (translatedObj.length === 0) {
      alert("No translated strings available to merge.");
      return;
    }
    
    var data = {
        'action': 'tpap_save_translations',
        'data': JSON.stringify(translatedObj),
        '_ajax_nonce': nonce,
    };
    // Close merge translation function
    jQuery.post(ajaxUrl, data, function (response) {
        var updateData = {
          'action': 'tpap_update_translate_data',
          'data': JSON.stringify(updatedataObj),
          '_ajax_nonce': nonce,
        };

        jQuery.post(ajaxUrl, updateData, function (updateResponse) {
          if (updateResponse.success) {
              console.log("Translation metadata saved successfully.");
          } else {
              
          }
        });
        $(".tpap_custom_model").fadeOut("slow");
        location.reload();
        tpa_google_Reset();
    });
  }

  function onRetryMissingClick() {
    const $activeModal = $(".tpap_custom_model:visible").first();
    if (!$activeModal.length) {
      return;
    }
    var $table = $activeModal.find("table.tpap-stringTemplate").first();
    var widgetType = $table.data("widget");
    var aiProviderId = String($activeModal.attr("data-ai-provider-id") || getAiProviderIdFromWidgetType(widgetType) || "").trim();
    if (!widgetType || !aiProviderId) {
      return;
    }
    $activeModal.find(".retry_missing_it").prop("disabled", true).text("Retrying...");
    translateStringsWithAiProvider(widgetType, aiProviderId, { onlyMissing: true });
  }

  function googleTranslateElementInit(default_codes) {
    if (licensekeys == "No") {
      $("#tpap-notice-check").remove();
      $(".choose-lang").before(
        '<div class="notice inline notice-info is-dismissible" id="tpap-notice-check" style="">AI Translation For TranslatePress (Pro) - License key is missing! Please add your License key in the settings panel to activate all premium features.</div>'
      );
      return;
    }
    var defaultlang = "";
    var default_code = default_codes;
    var page_lang = localStorage.getItem("page_lang");
    switch (default_code) {
      case 'sz':
        defaultlang='szl';
        break;
      case 'ki':
        defaultlang='ky';
        break;
      case "ck":
        defaultlang = "ckb";
        break;
      case "fu":
        defaultlang =  'fur';
      break;
      case "bel":
        defaultlang = "be";
        break;
      case "he":
        defaultlang = "iw";
        break;
      case "snd":
        defaultlang = "sd";
        break;
      case "jv":
        defaultlang = "jw";
        break;
      case "nb":
        defaultlang = "no";
        break;
      case "nn":
        defaultlang = "no";
        break;
      case "zh":
        defaultlang = "zh-CN,zh-TW";
        break;
      default:
        defaultlang = default_code;
        break;
        return defaultlang;
    }

    new google.translate.TranslateElement(
      {
        pageLanguage: page_lang,
        includedLanguages: defaultlang,
        defaultLanguage: defaultlang,
        multilanguagePage: true,
      },
      "google_translate_element"
    );
  }

  // oninit
  $(document).ready(function () {
    initialize();
  });
})(window, jQuery);
