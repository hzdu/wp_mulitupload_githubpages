(function (window, $) {
  'use strict';

  /**
   * Normalize a language code using the shared Google language helper.
   */
  function tpapNormalizeLanguageCode(code) {
    if (window.tpapBulkGoogleLanguage && typeof window.tpapBulkGoogleLanguage.tpapNormalizeLanguageCode === 'function') {
      return window.tpapBulkGoogleLanguage.tpapNormalizeLanguageCode(code);
    }
    if (window.tpapBulkGoogleLanguage && typeof window.tpapBulkGoogleLanguage.normalize === 'function') {
      return window.tpapBulkGoogleLanguage.normalize(code);
    }
    return String(code || '');
  }

  /**
   * Convert a TranslatePress language code into a Google widget target code.
   */
  function tpapFilterLanguageForWidget(code) {
    if (window.tpapBulkGoogleLanguage && typeof window.tpapBulkGoogleLanguage.tpapFilterLanguageForWidget === 'function') {
      return window.tpapBulkGoogleLanguage.tpapFilterLanguageForWidget(code);
    }
    if (window.tpapBulkGoogleLanguage && typeof window.tpapBulkGoogleLanguage.filterLanguageForWidget === 'function') {
      return window.tpapBulkGoogleLanguage.filterLanguageForWidget(code);
    }
    return tpapNormalizeLanguageCode(code);
  }

  /**
   * Ensure the hidden Google widget host exists in DOM.
   */
  function tpapEnsureWidgetHost() {
    var hostId = 'tpap-google-widget-bulk-host';
    var $host = $('#' + hostId);

    if (!$host.length) {
      $host = $('<div></div>')
        .attr({ id: hostId, 'aria-hidden': 'true' })
        .css({
          position: 'fixed',
          left: '0px',
          top: '0',
          width: '320px',
          height: '70px',
          opacity: '0',
          pointerEvents: 'none',
          overflow: 'hidden',
          zIndex: '100000'
        });

      $host.append($('<div></div>').attr('id', hostId + '-btn'));
      $('body').append($host);
    }

    return { $host: $host, btnId: hostId + '-btn' };
  }

  function tpapSetGoogTransCookie(from, to) {
    var value = '/' + String(from) + '/' + String(to);
    document.cookie = 'googtrans=' + value + ';path=/;SameSite=Lax';
  }

  function tpapGetWidgetLanguageSelector() {
    var hostId = 'tpap-google-widget-bulk-host';
    return document.querySelector('#' + hostId + '-btn .goog-te-combo') || 
           document.querySelector('#' + hostId + ' .goog-te-combo') || 
           document.querySelector('select.goog-te-combo');
  }

  var tpapWait = function(ms) { return new Promise(function(res) { setTimeout(res, ms); }); };

  /**
   * DOM Isolation: Protects the rest of the page from being translated.
   */
  function applyGlobalNotranslateExcept($container) {
    var body = document.body;
    if (!body) return [];
    var containerEl = $container && $container.get ? $container.get(0) : null;
    var hostEl = document.getElementById('tpap-google-widget-bulk-host');
    var changed = [];
    var children = Array.from(body.children);

    for (var i = 0; i < children.length; i++) {
      var el = children[i];
      if (!el || el.nodeType !== 1 || ['SCRIPT', 'STYLE', 'LINK'].includes(el.tagName)) continue;
      if (containerEl && (el === containerEl || el.contains(containerEl))) continue;
      if (hostEl && (el === hostEl || el.contains(hostEl))) continue;
      if (el.classList && el.classList.contains('skiptranslate')) continue;

      changed.push({
        el: el,
        hadTranslateAttr: el.hasAttribute('translate'),
        prevTranslateAttr: el.getAttribute('translate'),
        hadNotranslateClass: el.classList.contains('notranslate')
      });
      el.setAttribute('translate', 'no');
      el.classList.add('notranslate');
    }
    return changed;
  }

  function restoreGlobalNotranslate(changed) {
    if (!Array.isArray(changed)) return;
    changed.forEach(function(item) {
      if (item.hadTranslateAttr) {
        item.el.setAttribute('translate', item.prevTranslateAttr);
      } else {
        item.el.removeAttribute('translate');
      }
      if (!item.hadNotranslateClass) {
        item.el.classList.remove('notranslate');
      }
    });
  }

  /**
   * Row checking logic.
   */
  function getPendingCount(rows) {
    var pending = 0;
    rows.forEach(function (r) {
      var $cell = r.$row.find('.tpap-translated');
      var originalText = String(r.original || '').trim();
      if (!originalText) return;

      var currentText = $cell.text() || '';
      var hasMutation = $cell.find('font').length > 0;
      var isTranslated = (currentText !== originalText) || hasMutation;

      if (!isTranslated) pending++;
    });
    return pending;
  }

  /**
   * Async Scrolling to trigger Google's lazy-load translation.
   */
  async function scrollContainer($container, rows) {
    var el = $container.get(0);
    if (!el) return;

    var maxTop = el.scrollHeight - el.clientHeight;
    if (maxTop <= 0) {
      await tpapWait(2000);
      return;
    }

    var checkpoints = [0, 0.25, 0.5, 0.75, 1];
    for (var i = 0; i < checkpoints.length; i++) {
      if (getPendingCount(rows) === 0) break;
      el.scrollTo({ top: maxTop * checkpoints[i], behavior: 'smooth' });
      await tpapWait(800);
    }
  }

  async function ensureWidgetReady(sourceLang) {
    var host = tpapEnsureWidgetHost();
    var sl = tpapNormalizeLanguageCode(sourceLang);

    var libAttempts = 0;
    while (libAttempts < 60) {
      if (typeof window.google !== 'undefined' && window.google.translate && typeof window.google.translate.TranslateElement === 'function') break;
      await tpapWait(250);
      libAttempts++;
    }

    if (typeof window.google === 'undefined' || !window.google.translate || typeof window.google.translate.TranslateElement !== 'function') {
      throw new Error('Google Translate library is not loaded.');
    }

    // Create widget if missing or selector not available yet.
    var needsCreate = !window.__tpapBulkGoogleTranslateElementCreated || !tpapGetWidgetLanguageSelector();
    if (needsCreate) {
      var btnEl = document.getElementById(host.btnId);
      if (btnEl) btnEl.innerHTML = '';
      window.__tpapBulkGoogleTranslateElementCreated = false;
      new window.google.translate.TranslateElement({ pageLanguage: sl, autoDisplay: false }, host.btnId);
      window.__tpapBulkGoogleTranslateElementCreated = true;
    }

    // Wait for selector AND it to be populated with options.
    var attempts = 0;
    while (attempts < 80) {
      var sel = tpapGetWidgetLanguageSelector();
      if (sel && sel.options && sel.options.length > 1) return;
      await tpapWait(250);
      attempts++;
    }
  }

  function tpapOptionExistsForLangCode(languageSelector, langCode) {
    if (!languageSelector || !langCode) return false;
    var want = String(langCode || '');
    var opts = languageSelector.querySelectorAll('option');
    for (var i = 0; i < opts.length; i++) {
      if (String(opts[i].value) === want) return true;
    }
    var wantLower = want.toLowerCase();
    for (var j = 0; j < opts.length; j++) {
      if (String(opts[j].value).toLowerCase() === wantLower) return true;
    }
    return false;
  }

  function tpapApplyComboValue(languageSelector, langCode) {
    var want = String(langCode || '');
    var matched = want;
    var opts = languageSelector.querySelectorAll('option');
    var k;
    for (k = 0; k < opts.length; k++) {
      if (String(opts[k].value) === want) {
        matched = opts[k].value;
        break;
      }
    }
    if (k >= opts.length) {
      var wl = want.toLowerCase();
      for (var m = 0; m < opts.length; m++) {
        if (String(opts[m].value).toLowerCase() === wl) {
          matched = opts[m].value;
          break;
        }
      }
    }
    languageSelector.value = matched;
    languageSelector.dispatchEvent(new Event('change'));
    languageSelector.dispatchEvent(new Event('input', { bubbles: true }));
  }

  async function translateRowsForLanguage($container, rows, sourceLang, targetLang) {
    var sl = tpapNormalizeLanguageCode(sourceLang);
    var langCode = tpapFilterLanguageForWidget(targetLang);
    
    // Reset Row State
    rows.forEach(function(r) {
      r.$row.find('.tpap-source').attr('translate', 'no').addClass('notranslate');
      r.$row.find('.tpap-translated').attr('translate', 'yes').text(r.original || '');
    });

    var selector = tpapGetWidgetLanguageSelector();
    if (!selector) throw new Error('Google selector not found.');

    tpapSetGoogTransCookie(sl, langCode);
    if (!tpapOptionExistsForLangCode(selector, langCode)) {
      throw new Error('Google widget does not support language: ' + String(targetLang || ''));
    }
    tpapApplyComboValue(selector, langCode);

    // Wait and Scroll cycle (max 60s)
    var deadline = Date.now() + 60000;
    while (Date.now() < deadline && getPendingCount(rows) > 0) {
      await scrollContainer($container, rows);
      await tpapWait(1000);
    }

    // Collect results: never send empty keys; prefer .tpap-translated, handle <font> mutations.
    var dict = {}, gettext = {}, pending = getPendingCount(rows);
    rows.forEach(function(r) {
      var $t = r.$row.find('.tpap-translated');
      var text = ($t.text() || '').trim();
      if (!text && $t.find('font').length) {
        text = ($t[0] && $t[0].innerText) ? String($t[0].innerText).trim() : text;
      }
      var orig = String(r.original || '').trim();
      var hasMutation = $t.find('font').length > 0;
      if (!text) {
        return;
      }
      if (text === orig && !hasMutation) {
        return;
      }
      var target = r.bucket === 'dict' ? dict : gettext;
      target[r.id] = text;
    });

    if (pending > 0) throw new Error(pending + ' strings failed to translate.');
    return { dict: dict, gettext: gettext };
  }

  /**
   * Main Public Wrapper
   */
  async function runProcess($container, rows, sourceLang, targetLangs) {
    var isolationState = applyGlobalNotranslateExcept($container);
    $('.tpap-bulk-translate-model-container, .tpap-bulk-translate-model').addClass('notranslate').attr('translate', 'no');

    try {
      await ensureWidgetReady(sourceLang);
      var langs = Array.isArray(targetLangs) ? targetLangs : [targetLangs];
      var results = {}, errors = {};

      for (var i = 0; i < langs.length; i++) {
        var lang = langs[i];
        try {
          results[lang] = await translateRowsForLanguage($container, rows, sourceLang, lang);
        } catch (e) {
          errors[lang] = e.message;
        }
      }
      return { results: results, errors: errors };
    } finally {
      restoreGlobalNotranslate(isolationState);
    }
  }

  window.tpapBulkGoogleProvider = {
    translateTable: function(c, r, s, t) { return runProcess(c, r, s, t); },
    translateTableForLanguages: function(c, r, s, t) { return runProcess(c, r, s, t); }
  };

})(window, window.jQuery);