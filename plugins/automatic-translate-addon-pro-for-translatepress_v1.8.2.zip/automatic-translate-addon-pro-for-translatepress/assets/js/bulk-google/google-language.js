(function (window) {
  'use strict';

  // The canonical list provided by Google
  const languages = [
    "ab","ace","ach","aa","af","sq","alz","am","ar","hy","as","av","awa","ay","az","ban","bal","bm","bci","ba",
    "eu","btx","bts","bbc","be","bem","bn","bew","bho","bik","bs","br","bg","bua","yue","ca","ceb","ch","ce",
    "ny","zh-CN","zh-TW","chk","cv","co","crh","crh-Latn","hr","cs","da","fa-AF","dv","din","doi","dov","nl",
    "dyu","dz","en","eo","et","ee","fo","fj","tl","fi","fon","fr","fr-CA","fy","fur","ff","gaa","gl","ka",
    "de","el","gn","gu","ht","cnh","ha","haw","iw","hil","hi","hmn","hu","hrx","iba","is","ig","ilo","id",
    "iu-Latn","iu","ga","it","jam","ja","jw","kac","kl","kn","kr","pam","kk","kha","km","cgg","kg","rw","ktu",
    "trp","kv","gom","ko","kri","ku","ckb","ky","lo","ltg","la","lv","lij","li","ln","lt","lmo","lg","luo",
    "lb","mk","mad","mai","mak","mg","ms","ms-Arab","ml","mt","mam","gv","mi","mr","mh","mwr","mfe","chm",
    "mni-Mtei","min","lus","mn","my","nhe","ndc-ZW","nr","new","ne","bm-Nkoo","no","nus","oc","or","om","os",
    "pag","pap","ps","fa","pl","pt","pt-PT","pa","pa-Arab","qu","kek","rom","ro","rn","ru","se","sm","sg","sa",
    "sat-Latn","sat","gd","nso","sr","st","crs","shn","sn","scn","szl","sd","si","sk","sl","so","es","su",
    "sus","sw","ss","sv","ty","tg","ber-Latn","ber","ta","tt","te","tet","th","bo","ti","tiv","tpi","to","lua",
    "ts","tn","tcy","tum","tr","tk","tyv","ak","udm","uk","ur","ug","uz","ve","vec","vi","war","cy","wo","xh",
    "sah","yi","yo","yua","zap","zu"
  ];

  // Quick lookup maps
  const normalizedToCanonical = {};
  const languageSet = new Set();

  languages.forEach(lang => {
    const lower = lang.toLowerCase();
    normalizedToCanonical[lower] = lang;
    languageSet.add(lower);
  });

  // Static map of non-standard codes to Google-friendly codes
  const SPECIAL_MAP = {
    sz: 'szl',
    ki: 'ky',
    ck: 'ckb',
    fu: 'fur',
    bel: 'be',
    he: 'iw',
    snd: 'sd',
    jv: 'jw',
    nb: 'no',
    nn: 'no',
    zh: 'zh-CN'
  };

  /**
   * Normalize code to Google Canonical form
   */
  function tpapNormalizeLanguageCode(code) {
    if (!code) return '';

    // Standardize format: en_US -> en-us
    let normalized = String(code).trim().replace(/_/g, '-').toLowerCase();
    if (!normalized) return '';

    // 1. Exact match in canonical list
    if (normalizedToCanonical[normalized]) {
      return normalizedToCanonical[normalized];
    }

    // 2. Extract base (e.g., 'en-US' -> 'en')
    let basePart = normalized.split('-')[0];

    // 3. Check special overrides
    if (SPECIAL_MAP[basePart]) {
      basePart = SPECIAL_MAP[basePart];
    }

    // 4. Return canonical if base match found, else return the base attempt
    return normalizedToCanonical[basePart] || basePart;
  }

  /**
   * Check if supported
   */
  function tpapIsLanguageSupported(code) {
    const n = tpapNormalizeLanguageCode(code).toLowerCase();
    return languageSet.has(n);
  }

  /**
   * Filter for Widget Select Value
   */
  function tpapFilterLanguageForWidget(code) {
    if (code == null || code === '') return '';
    
    const raw = String(code).trim();
    // Specific legacy override for TranslatePress 'zh'
    if (raw === 'zh') return 'zh-CN';
    
    return tpapNormalizeLanguageCode(raw);
  }

  // Export
  window.tpapBulkGoogleLanguage = {
    tpapNormalizeLanguageCode: tpapNormalizeLanguageCode,
    tpapIsLanguageSupported: tpapIsLanguageSupported,
    tpapFilterLanguageForWidget: tpapFilterLanguageForWidget,
    languages: languages,
    // Aliases
    normalize: tpapNormalizeLanguageCode,
    supports: tpapIsLanguageSupported,
    filterLanguageForWidget: tpapFilterLanguageForWidget
  };

})(window);