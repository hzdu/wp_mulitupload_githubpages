/**
 * Bulk translation UI: language selection modal, progress modal, and AJAX batch orchestration.
 *
 * @namespace tpBulkTranslator
 * @param {Window} window
 * @param {jQuery} $
 * @returns {{ init: function }}
 */
window.tpBulkTranslator = (function (window, $) {
	'use strict';

	const config = window.tpap_bulk_data || {};
	if (!config || !config.ajax_url) {
		console.error('Bulk translator config missing');
		return { init: function () {} };
	}
	const SAVE_CHUNK_SIZE = 50;
	const MODAL_ANIMATION_MS = 300;
	const BULK_AJAX_TIMEOUT_MS = 120000;
	const BULK_AJAX_TIMEOUT_SDK_MS = (config.bulk_ajax_timeout_sdk_ms != null)
		? parseInt(config.bulk_ajax_timeout_sdk_ms, 10) : 300000;

	const STATUS = Object.freeze({
		PENDING: 'pending',
		IN_PROGRESS: 'in_progress',
		COMPLETED: 'completed',
		ALREADY_TRANSLATED: 'already_translated',
		ERROR: 'error',
		NOT_SUPPORTED: 'not_supported'
	});

	/**
	 * Centralized POST to bulk AJAX endpoint.
	 * @param {Object} data - Request payload (action, etc.). nonce is added automatically.
	 * @param {number} [timeout] - Optional timeout in ms.
	 * @returns {jQuery.jqXHR}
	 */
	function apiPost(data, timeout) {
		return $.ajax({
			url: config.ajax_url,
			type: 'POST',
			timeout: timeout != null ? timeout : BULK_AJAX_TIMEOUT_MS,
			data: Object.assign({}, data, { _ajax_nonce: config.nonce })
		});
	}

	/**
	 * Structured error for runTranslationTask responses (enables better debugging/analytics).
	 * @param {string} message
	 * @param {string} [code]
	 * @returns {{ success: false, data: { message: string, error?: { code: string } } }}
	 */
	function createErrorResponse(message, code) {
		const payload = { message: message || 'Unknown error' };
		if (code) {
			payload.error = { code: code || 'UNKNOWN', message: payload.message };
		}
		return { success: false, data: payload };
	}

	/** @returns {number} Timeout in ms for save requests (longer for SDK providers). */
	function getSaveTimeoutMs(provider) {
		const isSdk = provider && provider !== '' && provider !== 'chrome_ai';
		return isSdk ? BULK_AJAX_TIMEOUT_SDK_MS : BULK_AJAX_TIMEOUT_MS;
	}

	/** @param {*} e - Exception or jQuery error. @returns {string} User-friendly message. */
	function getRequestErrorMessage(e) {
		if (!e) return 'Request failed';
		const isTimeout = e.status === 0 && (
			e.statusText === 'timeout' || String(e.statusText || '').toLowerCase().indexOf('timeout') !== -1
		);
		return isTimeout ? e.message || 'Request timed out' : e.message || 'Request failed';
	}

	/** Split array into chunks of given size. */
	function chunkArrayBySize(arr, size) {
		const chunks = [];
		for (let i = 0; i < arr.length; i += size) {
			chunks.push(arr.slice(i, i + size));
		}
		return chunks;
	}

	/** Yield to the browser so UI can repaint before the next batch. */
	function yieldToUi() {
		return new Promise(function (resolve) {
			if (window.requestAnimationFrame) {
				window.requestAnimationFrame(function () {
					resolve();
				});
				return;
			}
			setTimeout(resolve, 0);
		});
	}

	/** Load pending strings for a page. Returns jqXHR for abort support. */
	function apiPost(data, timeout) {
		return $.ajax({
			url: config.ajax_url,
			type: 'POST',
			timeout: timeout ?? BULK_AJAX_TIMEOUT_MS,
			data: { ...data, _ajax_nonce: config.nonce }
		}).catch(function (xhr) {
			return createErrorResponse(
				getRequestErrorMessage(xhr),
				xhr.status === 0 ? 'TIMEOUT' : 'AJAX_ERROR'
			);
		});
	}

	/** Load pending strings for a page. Returns jqXHR for abort support. */
	function apiLoadStringsForPage(pid, lang) {
		return apiPost({
			action: 'tpap_bulk_load_strings',
			page_ids: [pid],
			language: lang
		});
	}

	/**
	 * Save pre-translated strings via AJAX.
	 *
	 * @param {string} lang Target language code.
	 * @param {string} provider Provider identifier.
	 * @param {Object} dictTranslations Dictionary table translations map.
	 * @param {Object} gettextTranslations Gettext table translations map.
	 * @param {number} pageId Page ID.
	 * @param {Object} pageData Page metadata from load endpoint.
	 * @param {number} charCount Character count used for reporting.
	 * @param {number|null} timeTakenSec Translation duration in seconds.
	 * @param {boolean} includeMeta Whether to include page/report metadata.
	 * @returns {jQuery.jqXHR}
	 */
	function apiSavePreTranslatedStrings(lang, provider, dictTranslations, gettextTranslations, pageId, pageData, charCount, timeTakenSec, includeMeta) {
		const payload = {
			action: 'tpap_bulk_save_translations',
			language: lang,
			provider: provider || 'chrome_ai',
			dict_translations: dictTranslations || {},
			gettext_translations: gettextTranslations || {}
		};
		if (includeMeta !== false) {
			payload.page_id = pageId;
			payload.page_title = (pageData && pageData.title) || '';
			payload.review_url = (pageData && pageData.review_url) || '';
			payload.character_count = charCount || 0;
			payload.time_taken_sec = timeTakenSec != null ? timeTakenSec : null;
		}
		return apiPost(payload, getSaveTimeoutMs(provider || 'chrome_ai'));
	}

	/**
	 * Split an object map into multiple object chunks.
	 *
	 * @param {Object} obj Source key-value map.
	 * @param {number} size Max chunk size.
	 * @returns {Array<Object>} Chunked map list.
	 */
	function mapToChunks(obj, size) {
		const source = obj || {};
		const keys = Object.keys(source);
		const chunks = [];
		for (let i = 0; i < keys.length; i += size) {
			const part = {};
			for (let j = i; j < i + size && j < keys.length; j++) {
				const key = keys[j];
				part[key] = source[key];
			}
			chunks.push(part);
		}
		return chunks;
	}

	/**
	 * Keep only source entries present in allowed ID map.
	 *
	 * @param {Object} sourceMap Full source key-value map.
	 * @param {Object} allowedIdMap Allowed IDs map (`id -> true`).
	 * @returns {Object} Filtered key-value map.
	 */
	function pickByIdMap(sourceMap, allowedIdMap) {
		const out = {};
		const src = sourceMap || {};
		for (const id in src) {
			if (!Object.prototype.hasOwnProperty.call(src, id)) {
				continue;
			}
			if (allowedIdMap && allowedIdMap[id]) {
				out[id] = src[id];
			}
		}
		return out;
	}

	/**
	 * Extract IDs that are still pending translation from load endpoint payload.
	 *
	 * @param {Object} loadRes Load response.
	 * @param {number|string} pageId Page identifier.
	 * @returns {Object} Pending IDs map (`id -> true`).
	 */
	function extractPendingIdMapFromLoad(loadRes, pageId) {
		const out = {};
		if (!loadRes || !loadRes.success) return out;
		const pages = loadRes.data && loadRes.data.pages ? loadRes.data.pages : {};
		const page = pages && pages[String(pageId)] ? pages[String(pageId)] : pages[pageId];
		if (!page) return out;
		const dict = Array.isArray(page.dict_strings) ? page.dict_strings : [];
		const gettext = Array.isArray(page.gettext_strings) ? page.gettext_strings : [];
		for (let i = 0; i < dict.length; i++) {
			const row = dict[i];
			const id = row && row.id != null ? String(row.id) : '';
			if (id) out[id] = true;
		}
		for (let j = 0; j < gettext.length; j++) {
			const row = gettext[j];
			const id = row && row.id != null ? String(row.id) : '';
			if (id) out[id] = true;
		}
		return out;
	}

	/**
	 * Save pre-translated payload in chunks and retry once against pending IDs when needed.
	 *
	 * @param {string} lang Target language code.
	 * @param {string} provider Provider identifier.
	 * @param {Object} dictTranslations Dictionary translations.
	 * @param {Object} gettextTranslations Gettext translations.
	 * @param {number} pageId Page ID.
	 * @param {Object} pageData Page metadata.
	 * @param {number} charCount Character count for reporting.
	 * @param {number|null} timeTakenSec Elapsed translation time in seconds.
	 * @returns {Promise<Object>} Save result payload.
	 */
	async function savePreTranslatedStringsInChunks(lang, provider, dictTranslations, gettextTranslations, pageId, pageData, charCount, timeTakenSec) {
		dictTranslations = filterValidTranslatedMap(dictTranslations);
		gettextTranslations = filterValidTranslatedMap(gettextTranslations);
		async function saveMapsInChunks(dictMap, gettextMap, attemptLabel) {
			const dictChunks = mapToChunks(dictMap, SAVE_CHUNK_SIZE);
			const gettextChunks = mapToChunks(gettextMap, SAVE_CHUNK_SIZE);
			const totalChunks = dictChunks.length + gettextChunks.length;

			if (totalChunks === 0) {
				return { success: true, data: { message: 'No translations to save' } };
			}

			let chunkIdx = 0;
			let lastRes = { success: true };

			for (let i = 0; i < dictChunks.length; i++) {
				chunkIdx++;
				const isFinal = chunkIdx === totalChunks;
				lastRes = await apiSavePreTranslatedStrings(
					lang,
					provider,
					dictChunks[i],
					{},
					pageId,
					pageData,
					charCount,
					isFinal ? timeTakenSec : null,
					isFinal
				);
				if (!lastRes || !lastRes.success) return lastRes;
			}

			for (let j = 0; j < gettextChunks.length; j++) {
				chunkIdx++;
				const isFinal = chunkIdx === totalChunks;
				lastRes = await apiSavePreTranslatedStrings(
					lang,
					provider,
					{},
					gettextChunks[j],
					pageId,
					pageData,
					charCount,
					isFinal ? timeTakenSec : null,
					isFinal
				);
				if (!lastRes || !lastRes.success) return lastRes;
			}

			lastRes._attempt = attemptLabel;
			return lastRes;
		}

		// First pass: normal chunked save.
		let saveRes = await saveMapsInChunks(dictTranslations, gettextTranslations, 'initial');
		if (!saveRes || !saveRes.success) return saveRes;

		// Verification pass: reload pending strings and retry only IDs that are still missing.
		// This helps large pages where some keys may be dropped by server/input limits.
		try {
			const verifyRes = await apiLoadStringsForPage(pageId, lang);
			const pendingMap = extractPendingIdMapFromLoad(verifyRes, pageId);
			const retryDict = pickByIdMap(dictTranslations, pendingMap);
			const retryGettext = pickByIdMap(gettextTranslations, pendingMap);
			const retryCount = Object.keys(retryDict).length + Object.keys(retryGettext).length;
			if (retryCount > 0) {
				saveRes = await saveMapsInChunks(retryDict, retryGettext, 'retry_missing_ids');
			}
		} catch (e) {
			// Non-fatal: keep success from initial save when verification endpoint is unavailable.
		}

		return saveRes;
	}

	/**
	 * Save one SDK chunk where untranslated source strings are sent for server-side AI translation.
	 *
	 * @param {string} lang Target language code.
	 * @param {string} provider Provider identifier.
	 * @param {number} pageId Page ID.
	 * @param {Object} pageData Page metadata.
	 * @param {Array<Object>} dictStrings Dictionary source rows.
	 * @param {Array<Object>} gettextStrings Gettext source rows.
	 * @param {boolean} isFinalChunk Whether this is the final chunk for a page/lang pair.
	 * @param {number} charCount Character count for reporting.
	 * @param {number|null} timeTakenSec Elapsed translation time in seconds.
	 * @returns {jQuery.jqXHR}
	 */
	function apiSaveSdkChunk(lang, provider, pageId, pageData, dictStrings, gettextStrings, isFinalChunk, charCount, timeTakenSec) {
		return apiPost({
			action: 'tpap_bulk_save_translations',
			language: lang,
			provider: provider,
			dict_strings: dictStrings || [],
			gettext_strings: gettextStrings || [],
			page_id: pageId,
			page_title: (pageData && pageData.title) || '',
			review_url: (pageData && pageData.review_url) || '',
			character_count: charCount || 0,
			is_final_chunk: isFinalChunk,
			time_taken_sec: (isFinalChunk && timeTakenSec != null) ? timeTakenSec : null
		}, getSaveTimeoutMs(provider));
	}

	function filterValidTranslatedMap(map) {
		const source = map || {};
		const out = {};
		for (const id in source) {
			if (!Object.prototype.hasOwnProperty.call(source, id)) {
				continue;
			}
			const value = source[id];
			if (value == null) {
				continue;
			}
			const text = String(value);
			if (text.trim() === '') {
				continue;
			}
			out[id] = text;
		}
		return out;
	}

	async function saveTranslationsForProvider(args) {
		const lang = args && args.lang ? args.lang : '';
		const provider = args && args.provider ? args.provider : '';
		const dict = (args && args.dict) || (provider === 'chrome_ai' || provider === 'google_widget' ? {} : []);
		const gettext = (args && args.gettext) || (provider === 'chrome_ai' || provider === 'google_widget' ? {} : []);
		const pageId = args && args.pageId ? args.pageId : 0;
		const pageData = args && args.pageData ? args.pageData : {};
		const charCount = args && args.charCount ? args.charCount : 0;
		const timeTakenSec = args && args.timeTaken != null ? args.timeTaken : null;

		if (provider === 'chrome_ai' || provider === 'google_widget') {
			const sanitizedDict = filterValidTranslatedMap(dict);
			const sanitizedGettext = filterValidTranslatedMap(gettext);
			if (Object.keys(sanitizedDict).length === 0 && Object.keys(sanitizedGettext).length === 0) {
				return createErrorResponse('No translated strings were produced for this page.', 'NO_TRANSLATIONS');
			}
			return savePreTranslatedStringsInChunks(
				lang,
				provider,
				sanitizedDict,
				sanitizedGettext,
				pageId,
				pageData,
				charCount,
				timeTakenSec
			);
		}

		const dictStrings = Array.isArray(dict) ? dict : Object.values(dict || {});
		const gettextStrings = Array.isArray(gettext) ? gettext : Object.values(gettext || {});
		const dictChunks = chunkArrayBySize(dictStrings, SAVE_CHUNK_SIZE);
		const gettextChunks = chunkArrayBySize(gettextStrings, SAVE_CHUNK_SIZE);
		const totalChunks = dictChunks.length + gettextChunks.length;
		let chunkIdx = 0;
		let lastRes = { success: true };

		for (let d = 0; d < dictChunks.length; d++) {
			chunkIdx++;
			const isFinal = chunkIdx === totalChunks;
			lastRes = await apiSaveSdkChunk(
				lang,
				provider,
				pageId,
				pageData,
				dictChunks[d],
				[],
				isFinal,
				charCount,
				isFinal ? timeTakenSec : null
			);
			if (!lastRes || !lastRes.success) {
				return lastRes || createErrorResponse('Failed to save translations.', 'SAVE_ERROR');
			}
		}

		for (let g = 0; g < gettextChunks.length; g++) {
			chunkIdx++;
			const isFinal = chunkIdx === totalChunks;
			lastRes = await apiSaveSdkChunk(
				lang,
				provider,
				pageId,
				pageData,
				[],
				gettextChunks[g],
				isFinal,
				charCount,
				isFinal ? timeTakenSec : null
			);
			if (!lastRes || !lastRes.success) {
				return lastRes || createErrorResponse('Failed to save translations.', 'SAVE_ERROR');
			}
		}

		return lastRes;
	}

	$(document).on('click', '.tpap-bulk-translation-notice', function () {
		var $notice = $(this);
		$.ajax({
			url: config.ajax_url,
			type: 'POST',
			data: { action: 'tpap_bulk_translation_notice_dismissed', nonce: $notice.data('nonce') },
			success: function (response) {
				if (response.success && $notice.length) {
					$notice.slideUp();
				}
			},
		});
	});
	
	/**
	 * Escape string for safe use in HTML text content.
	 *
	 * @param {string|null|undefined} str
	 * @returns {string}
	 */
	function escapeHtmlString(str) {
		if (str == null || str === '') {
			return '';
		}
		const div = document.createElement('div');
		div.textContent = str;
		return div.innerHTML;
	}

	const SEL = {
		bulkBtn: '.tpap-bulk-translate-btn',
		modal: '.tpap-bulk-translate-model-container',
		postCheckbox: '.wp-list-table input[name="post[]"]:checked',
		postCheckboxPublished: '.wp-list-table tr.status-publish input[name="post[]"]:checked',
		langSelectAll: '#tpap-lang-select-all',
		langList: '.tpap-bulk-translate-languages-list'
	};

	/** Language display name from TranslatePress-added languages (passed from PHP). */
	function getLanguageName(code) {
		const names = config.language_names || {};
		if (names[code]) {
			return names[code];
		}
		return code ? String(code).replace(/_/g, ' ') : code;
	}

	/**
	 * Normalize a TranslatePress language code (e.g. en_US, fr_FR, pt-BR)
	 * into a short code more suitable for Chrome AI (e.g. en, fr, pt).
	 *
	 * @param {string} code
	 * @returns {string}
	 */
	function normalizeLangForChromeAi(code) {
		if (!code) {
			return '';
		}
		const str = String(code).toLowerCase();
		const parts = str.split(/[-_]/);
		return parts[0] || str;
	}

	/**
	 * Check if a TranslatePress language code is supported by Chrome AI.
	 * Falls back to \"true\" when ChromeAiTranslator is not available so
	 * that the rest of the UI does not break in non-Chrome environments.
	 *
	 * @param {string} code
	 * @returns {boolean}
	 */
	function isChromeAiLanguageSupported(code) {
		if (!code || typeof window === 'undefined' || !window.ChromeAiTranslator) {
			return true;
		}
		if (typeof ChromeAiTranslator.isLanguageSupported !== 'function') {
			return true;
		}
		const normalized = normalizeLangForChromeAi(code);
		return ChromeAiTranslator.isLanguageSupported(normalized);
	}

	function normalizeLangForGoogleWidget(code) {
		if (window.tpapBulkGoogleLanguage && typeof window.tpapBulkGoogleLanguage.normalize === 'function') {
			return window.tpapBulkGoogleLanguage.normalize(code);
		}
		if (!code) return '';
		return String(code).toLowerCase().split(/[-_]/)[0] || '';
	}

	function isGoogleWidgetLanguageSupported(code) {
		if (window.tpapBulkGoogleLanguage && typeof window.tpapBulkGoogleLanguage.supports === 'function') {
			return window.tpapBulkGoogleLanguage.supports(code);
		}
		return normalizeLangForGoogleWidget(code) !== '';
	}

	async function translateTextsWithGoogleWidget(texts, sourceLang, targetLang) {
		const sl = normalizeLangForGoogleWidget(sourceLang);
		const tl = normalizeLangForGoogleWidget(targetLang);
		const list = Array.isArray(texts) ? texts : [];
		if (!sl || !tl) {
			throw new Error('Google widget does not support this language pair.');
		}
		if (!list.length) {
			return [];
		}

		const out = new Array(list.length);
		const CHUNK_SIZE = 35;
		for (let i = 0; i < list.length; i += CHUNK_SIZE) {
			const chunk = list.slice(i, i + CHUNK_SIZE);
			const params = new URLSearchParams();
			params.set('client', 'gtx');
			params.set('sl', sl);
			params.set('tl', tl);
			params.set('dt', 't');
			chunk.forEach(function (q) {
				params.append('q', String(q || ''));
			});

			const res = await fetch('https://translate.googleapis.com/translate_a/single?' + params.toString(), {
				method: 'GET',
				credentials: 'omit'
			});
			if (!res.ok) {
				throw new Error('Google widget translation request failed.');
			}
			const data = await res.json();
			const translatedChunk = (Array.isArray(data) && Array.isArray(data[0])) ? data[0] : [];
			for (let c = 0; c < chunk.length; c++) {
				const seg = translatedChunk[c];
				out[i + c] = (Array.isArray(seg) && seg[0] != null) ? String(seg[0]) : String(chunk[c] || '');
			}
		}

		return out;
	}

	function tpapInit() {
		$(SEL.bulkBtn).on('click', function () {
			openLanguageSelectModal();
		});
	}

	function closeModal($container) {
		if (!$container || !$container.length) {
			return;
		}
		$container.removeClass('tpap-active');
		setTimeout(function () {
			$container.remove();
		}, MODAL_ANIMATION_MS);
	}

	function showErrorModal(message, linkUrl, linkText) {
		$(SEL.modal).remove();
		const html = `<div class="tpap-bulk-translate-model-container">
			<div class="tpap-bulk-translate-model tpap-error-modal">
				<div class="tpap-bulk-translate-model-header">
					<button class="tpap-bulk-translate-model-close" title="Close">&times;</button>
				</div>
				<div class="tpap-bulk-translate-model-body">
					<p class="tpap-model-error-desc">${escapeHtmlString(message)}</p>
					<p><a href="${escapeHtmlString(linkUrl)}" class="button tpap-dashboard-btn primary" target="_blank" rel="noopener noreferrer">${escapeHtmlString(linkText)}</a></p>
				</div>
			</div>
		</div>`;
		$('body').append(html);
		$(SEL.modal).addClass('tpap-active');
		$(SEL.modal).find('.tpap-bulk-translate-model-close').on('click', function () {
			closeModal($(SEL.modal));
		});
	}

	/**
	 * Show a notice modal (title + message only, no link). Same style as error modal.
	 *
	 * @param {string} message
	 */
	function showNoticeModal(message) {
		$(SEL.modal).remove();
		const html = `<div class="tpap-bulk-translate-model-container">
			<div class="tpap-bulk-translate-model tpap-error-modal">
				<div class="tpap-bulk-translate-model-header">
					<button class="tpap-bulk-translate-model-close" title="Close">&times;</button>
				</div>
				<div class="tpap-bulk-translate-model-body">
					<p class="tpap-model-error-desc">${escapeHtmlString(message)}</p>
				</div>
			</div>
		</div>`;
		$('body').append(html);
		$(SEL.modal).addClass('tpap-active');
		$(SEL.modal).find('.tpap-bulk-translate-model-close').on('click', function () {
			closeModal($(SEL.modal));
		});
		$(SEL.modal).on('click', function (e) {
			if (e.target === this) closeModal($(SEL.modal));
		});
	}

	function updateSelectAllState($container, refs) {
		const $list = refs && refs.$list ? refs.$list : $container.find(SEL.langList);
		const $visible = $list.find('.tpap-bulk-translate-lang-item:visible');
		const $checked = $visible.find('input[type="checkbox"]:checked');
		const total = $visible.length;
		const checked = $checked.length;
		const $selectAll = refs && refs.$selectAll ? refs.$selectAll : $container.find(SEL.langSelectAll);
		if (total === 0) {
			$selectAll.prop('checked', false).prop('indeterminate', false);
		} else {
			$selectAll.prop('indeterminate', checked > 0 && checked < total);
			$selectAll.prop('checked', checked === total);
		}

		if ($container.hasClass('tpap-lang-step-modal')) {
			const anySelected = (refs && refs.$checkboxes ? refs.$checkboxes : $list.find('input[type="checkbox"]')).filter(':checked').length > 0;
			const $nextBtn = refs && refs.$nextBtn ? refs.$nextBtn : $container.find('.tpap-bulk-translate-model-submit');
			$nextBtn.prop('disabled', !anySelected);
			$nextBtn.toggleClass('tpap-disabled', !anySelected);
		}
	}

	function getCheckedPageIds() {
		return $(SEL.postCheckboxPublished).map(function () {
			return $(this).val();
		}).get();
	}

	/**
	 * Build map of pageId -> title from list table DOM (from row containing each checked checkbox).
	 *
	 * @returns {Object.<string, string>}
	 */
	function getPageTitlesFromTable() {
		const map = {};
		$(SEL.postCheckboxPublished).each(function () {
			const pid = $(this).val();
			const key = String(pid);
			const $row = $(this).closest('tr');
			let title = '';
			if ($row.length) {
				const $titleCell = $row.find('td.column-title a.row-title, td.column-title a, .column-title a').first();
				if ($titleCell.length) {
					title = $titleCell.text().trim();
				} else {
					const $secondTd = $row.find('td').eq(1);
					if ($secondTd.length) {
						title = $secondTd.find('a').first().text().trim() || $secondTd.text().trim();
					}
				}
			}
			map[key] = title || '';
		});
		return map;
	}

	function openLanguageSelectModal(preselectedLangs, selectedProviderId) {
		$(SEL.modal).remove();

		// Validation: if there are blocking issues, show a dedicated popup and
		// do NOT open the language selection modal. Only published posts count.
		const hasPages = $(SEL.postCheckboxPublished).length > 0;
		const hasLicense = config.license_key && config.license_key !== 'No';
		const baseUrl = config.dashboard_url || '';
		const urlSep = baseUrl.indexOf('?') !== -1 ? '&' : '?';
		const licenseUrl = baseUrl + urlSep + 'tab=license';
		const postType = config.post_type;

		if (!hasPages) {
			showNoticeModal(`Please select at least one Published ${postType} to translate.`);
			return;
		}
		if (!hasLicense) {
			showErrorModal('Please activate your license key to enable bulk translation features.', licenseUrl, 'Activate License');
			return;
		}

		const languages = config.languages || [];
		const defaultLang = config.default_language || '';
		const availableLangs = languages.filter(function (code) { return code !== defaultLang; });
		const langCount = availableLangs.length;

		const flagUrls = config.language_flags || {};
		const providerId = typeof selectedProviderId === 'string' ? selectedProviderId.toLowerCase() : '';
		let langOptionsHtml = availableLangs.map(function (code) {
			const name = getLanguageName(code);
			const flagUrl = flagUrls[code] || '';
			const safeCode = escapeHtmlString(code);
			const safeName = escapeHtmlString(name);
			const flagHtml = flagUrl ? '<img src="' + escapeHtmlString(flagUrl) + '" alt="" class="tpap-lang-flag-img" aria-hidden="true">' : '<span class="tpap-lang-flag"></span>';
			const chromeSupported = providerId === 'chrome_ai' ? isChromeAiLanguageSupported(code) : true;
			const googleWidgetSupported = providerId === 'google_widget' ? isGoogleWidgetLanguageSupported(code) : true;
			const chromeSupportAttr = chromeSupported ? '1' : '0';
			const googleWidgetSupportAttr = googleWidgetSupported ? '1' : '0';
			const chromeBadgeHtml = (!chromeSupported && providerId === 'chrome_ai')
				? '<span class="tpap-lang-support-badge tpap-lang-support-badge-unsupported">Not supported in Chrome AI</span>'
				: '';
			const googleWidgetBadgeHtml = (!googleWidgetSupported && providerId === 'google_widget')
				? '<span class="tpap-lang-support-badge tpap-lang-support-badge-unsupported">Not supported in Google Widget</span>'
				: '';
			return '<div class="tpap-bulk-translate-lang-item" data-lang-code="' + safeCode + '" data-lang-name="' + safeName.toLowerCase() + '" data-chrome-ai-supported="' + chromeSupportAttr + '" data-google-widget-supported="' + googleWidgetSupportAttr + '">' +
				'<input type="checkbox" id="tpap-lang-' + safeCode + '" name="tpap-languages[]" value="' + safeCode + '">' +
				'<span class="tpap-check-visual" aria-hidden="true"></span>' +
				'<span class="tpap-lang-flag-wrap" aria-hidden="true">' + flagHtml + '</span>' +
				'<label for="tpap-lang-' + safeCode + '">' + safeName + '</label>' +
				chromeBadgeHtml +
				googleWidgetBadgeHtml +
				'</div>';
		}).join('');

		if (!langOptionsHtml) {
			langOptionsHtml = '<div class="tpap-bulk-translate-empty">No additional languages identified in TranslatePress settings.</div>';
		}

		const stepLabel = 'STEP 1 OF 3';
		const html = '<div class="tpap-bulk-translate-model-container tpap-lang-step-modal">' +
			'<div class="tpap-bulk-translate-model">' +
			'<div class="tpap-bulk-translate-model-header">' +
			'<div class="tpap-modal-header-inner">' +
			'<span class="tpap-step-label">' + escapeHtmlString(stepLabel) + '</span>' +
			'<h2>Select Languages</h2>' +
			'<p class="tpap-model-desc">Pick the languages you want to translate your content into.</p>' +
			'</div>' +
			'<button class="tpap-bulk-translate-model-close" title="Close">&times;</button></div>' +
			'<div class="tpap-bulk-translate-model-body">' +
			'<div class="tpap-lang-toolbar">' +
			'<label class="tpap-lang-select-all-wrap"><input type="checkbox" id="tpap-lang-select-all" class="tpap-lang-select-all"><span class="tpap-check-visual" aria-hidden="true"></span><span>Select All</span></label>' +
			'<span class="tpap-lang-count">' + langCount + ' ' + (langCount === 1 ? 'Language' : 'Languages') + ' Available</span>' +
			'</div><hr class="tpap-lang-toolbar-divider">' +
			'<div class="tpap-bulk-translate-languages-list">' + langOptionsHtml + '</div></div>' +
			'<div class="tpap-bulk-translate-model-footer">' +
			'<button class="tpap-bulk-translate-model-cancel button tpap-dashboard-btn tpap-btn-cancel">Cancel</button>' +
			'<button type="button" class="button tpap-dashboard-btn tpap-bulk-translate-model-submit primary tpap-disabled" disabled>Next <span class="tpap-next-arrow">&#8594;</span></button>' +
			'</div></div>';

		$('body').append(html);
		$(SEL.modal).addClass('tpap-active');

		const $container = $(SEL.modal);
		const $list = $container.find(SEL.langList);
		const $items = $list.find('.tpap-bulk-translate-lang-item');
		const $selectAll = $container.find(SEL.langSelectAll);
		const $checkboxes = $list.find('input[type="checkbox"]');
		const $modalCloseButtons = $container.find('.tpap-bulk-translate-model-close, .tpap-bulk-translate-model-cancel');
		const $nextBtn = $container.find('.tpap-bulk-translate-model-submit');
		const modalSelectors = {
			$list: $list,
			$selectAll: $selectAll,
			$checkboxes: $checkboxes,
			$nextBtn: $nextBtn
		};

		// Restore previously selected languages when coming back from the provider step.
		const preselected = Array.isArray(preselectedLangs) ? preselectedLangs.map(String) : [];
		if (preselected.length) {
			$items.each(function () {
				const $cb = $(this).find('input[type="checkbox"]');
				const val = String($cb.val());
				if (preselected.indexOf(val) !== -1) {
					$cb.prop('checked', true);
				}
			});
		}

		$modalCloseButtons.on('click', function () {
			closeModal($container);
		});

		$selectAll.on('change', function () {
			const checked = $(this).prop('checked');
			$list.find('.tpap-bulk-translate-lang-item:visible input[type="checkbox"]').prop('checked', checked);
			updateSelectAllState($container, modalSelectors);
		});

		$list.on('change', 'input[type="checkbox"]', function () {
			updateSelectAllState($container, modalSelectors);
		});

		$list.on('click', '.tpap-bulk-translate-lang-item', function (e) {
			// Clicking the label already toggles the input natively (via `for=""`),
			// so don't double-toggle it here.
			if (e.target.tagName === 'INPUT' || e.target.tagName === 'LABEL') return;
			const $cb = $(this).find('input[type="checkbox"]');
			$cb.prop('checked', !$cb.prop('checked'));
			updateSelectAllState($container, modalSelectors);
		});

		updateSelectAllState($container, modalSelectors);

		$nextBtn.on('click', function () {
			const $btn = $(this);
			if ($btn.hasClass('tpap-disabled') || $btn.prop('disabled')) return;
			const selectedLangs = $checkboxes.filter(':checked').map(function () {
				return $(this).val();
			}).get();
			if (selectedLangs.length === 0) {
				showNoticeModal('Please select at least one language to translate.');
				return;
			}
			// Instantly transition to provider step without an extra delay gap.
			closeModal($container);
			openProviderSelectModal(selectedLangs, getCheckedPageIds());
		});
	}

	function joinUrl(baseUrl, path) {
		const base = (baseUrl || '').trim();
		if (!base) return path;
		if (base.charAt(base.length - 1) === '/' && path.charAt(0) === '/') {
			return base + path.slice(1);
		}
		if (base.charAt(base.length - 1) !== '/' && path.charAt(0) !== '/') {
			return base + '/' + path;
		}
		return base + path;
	}

	function getProviderIconHtml(providerId, providerName) {
		const id = String(providerId || '').toLowerCase();
		const imagesUrl = config.images_url || '';
		// Exact provider id → asset filename (no substring matching).
		const iconFileById = {
			google_widget: 'google.png',
			google: 'google-gemini.png',
			openai: 'openAI.png',
			anthropic: 'anthropic.png',
			chrome_ai: 'chrome.png',
		};
		const fileName = iconFileById[id] || '';

		if (fileName && imagesUrl) {
			const src = joinUrl(imagesUrl, fileName);
			const alt = escapeHtmlString(providerName || providerId || '');
			return '<img class="tpap-provider-icon-img" src="' + escapeHtmlString(src) + '" alt="' + alt + '" loading="lazy" decoding="async">';
		}
	}

	function getProviderDisplayName(providerId) {
		const id = String(providerId || '').toLowerCase();
		if (!id) return '';
		if (id === 'chrome_ai') return 'Chrome AI';
		if (id === 'google_widget') return 'Google Widget';
		const providers = Array.isArray(config.available_providers) ? config.available_providers : [];
		for (let i = 0; i < providers.length; i++) {
			const p = providers[i];
			if (!p) continue;
			if (String(p.id || '').toLowerCase() === id) {
				return p.name ? String(p.name) : id;
			}
		}
		return id;
	}

	function openProviderSelectModal(selectedLangs, pageIds) {
		$(SEL.modal).remove();

		// Start with server-side AI providers (OpenAI, Gemini, Anthropic, etc.).
		const providers = (config.available_providers || []).slice();

		// Optionally add Chrome AI as a browser-based provider when the script is loaded.
		let chromeAiEnvReady = false;
		let chromeAiEnvDetected = false;
		if (typeof window !== 'undefined' && window.ChromeAiTranslator) {
			chromeAiEnvDetected = true;
			try {
				const isChrome = typeof ChromeAiTranslator.checkBrowserCompatibility === 'function'
					? ChromeAiTranslator.checkBrowserCompatibility()
					: false;
				const hasApi = typeof ChromeAiTranslator.checkApiAvailability === 'function'
					? ChromeAiTranslator.checkApiAvailability()
					: false;
				const isSecure = typeof ChromeAiTranslator.checkSecureConnection === 'function'
					? ChromeAiTranslator.checkSecureConnection()
					: false;
				chromeAiEnvReady = !!(isChrome && hasApi && isSecure);
			} catch (e) {
				chromeAiEnvReady = false;
			}
		}

		const providerEnabled = config.provider_enabled || {};
		const chromeAiEnabled = providerEnabled.chrome_ai == null ? true : String(providerEnabled.chrome_ai) === '1';
		if (chromeAiEnabled && chromeAiEnvDetected) {
			providers.push({
				id: 'chrome_ai',
				name: 'Chrome AI',
				has_key: true, // no API key required; env readiness handled separately
				env_ready: chromeAiEnvReady
			});
		}

		const googleWidgetEnabled = providerEnabled.google_widget == null ? true : String(providerEnabled.google_widget) === '1';
		if (googleWidgetEnabled) {
			providers.push({
				id: 'google_widget',
				name: 'Google Widget',
				has_key: true, // no API key required; env readiness handled separately
				env_ready: true
			});
		}

		const dashboardUrl = config.dashboard_url || '';
		const settingsUrl = dashboardUrl + (dashboardUrl.indexOf('?') !== -1 ? '&' : '?') + 'tab=settings';
		const imagesUrl = config.images_url || '';
		const providerDocUrls = config.provider_doc_urls || {};
		const docIconUrl = joinUrl(imagesUrl, 'document.svg');
		const hasProviderError = providers.length === 0;

		const anyProviderNeedsKey = !hasProviderError && providers.some(function (p) {
			// Chrome AI never needs an API key; its issues are environment-only.
			if ((p.id || '').toLowerCase() === 'chrome_ai') {
				return false;
			}
			return !p.has_key;
		});
		const settingsNoticeHtml = anyProviderNeedsKey
			? '<p class="tpap-provider-settings-notice">Need an API key? <a href="' + escapeHtmlString(settingsUrl) + '#tpap-bulk-translation-section" target="_blank" rel="noopener noreferrer" class="tpap-provider-add-key">Add or manage keys in Settings</a>.</p>'
			: '';

		let cardsHtml = '';
		if (hasProviderError) {
			const enabledMap = config.provider_enabled || {};
			const anyEnabled = Object.keys(enabledMap).length
				? Object.keys(enabledMap).some(function (k) { return String(enabledMap[k]) === '1'; })
				: true; // backwards-compatible: if not provided, assume enabled
			const reasonHtml = anyEnabled
				? 'No providers were found. This usually means API keys are not configured yet (or the AI client is unavailable).'
				: 'All providers are currently disabled.';
			const dashboardUrl2 = dashboardUrl || (config.dashboard_url || '');
			const dashboardLink = dashboardUrl2
				? '<a href="' + escapeHtmlString(dashboardUrl2) + '" target="_blank" rel="noopener noreferrer">Dashboard</a>'
				: 'Dashboard';

			cardsHtml = '<div class="tpap-bulk-translate-empty tpap-provider-empty">' +
				'<strong>No AI providers available</strong><br />' +
				escapeHtmlString(reasonHtml) + '<br />' +
				'<span class="tpap-provider-empty-actions">' +
				'Go to ' + dashboardLink + ' to enable a provider, or open <a href="' + escapeHtmlString(settingsUrl) + '#tpap-bulk-translation-section" target="_blank" rel="noopener noreferrer">Settings</a> to add/manage API keys.' +
				'</span>' +
				'</div>';
		} else {
			cardsHtml = providers.map(function (p) {
				const hasKey = !!p.has_key;
				const idRaw = p.id || '';
				const id = escapeHtmlString(idRaw);
				const name = escapeHtmlString(p.name);
				const icon = getProviderIconHtml(p.id, p.name);
				const lowerId = idRaw.toLowerCase();
				const isChromeAi = lowerId === 'chrome_ai';
				const envReady = (typeof p.env_ready === 'boolean') ? p.env_ready : true;
				const docUrl = providerDocUrls[lowerId];
				const docsLinkHtml = docUrl
					? '<a href="' + escapeHtmlString(docUrl) + '" target="_blank" rel="noopener noreferrer" class="tpap-provider-card-docs">' +
						'<img src="' + escapeHtmlString(docIconUrl) + '" alt="" class="tpap-provider-card-docs-icon" aria-hidden="true"><span>Docs</span></a>'
					: '';

				let actionHtml = '';
				if (isChromeAi && !envReady) {
					actionHtml = '<a href="' + escapeHtmlString(settingsUrl) + '#tpap-chrome-local-ai-notice" target="_blank" rel="noopener noreferrer" class="tpap-provider-card-add-key">Configure</a>';
				} else if (!hasKey) {
					actionHtml = '<a href="' + escapeHtmlString(settingsUrl) + '#tpap-bulk-translation-section" target="_blank" rel="noopener noreferrer" class="tpap-provider-card-add-key">Add API Key</a>';
				}

				return '<div class="tpap-provider-card" data-provider-id="' + id + '" data-has-key="' + (hasKey ? '1' : '0') + '" data-env-ready="' + (envReady ? '1' : '0') + '" role="button" tabindex="0">' +
					'<span class="tpap-provider-card-icon" aria-hidden="true">' + icon + '<span class="tpap-provider-card-name">' + name + '</span></span>' +
					'<span class="tpap-provider-card-check" aria-hidden="true"></span>' +
					'<span class="tpap-provider-card-footer">' +
					docsLinkHtml +
					'<span class="tpap-provider-card-action" data-provider-action-slot>' + actionHtml + '</span>' +
					'</span>' +
					'</div>';
			}).join('');
		}

		const stepLabel = 'STEP 2 OF 3';
		const html = '<div class="tpap-bulk-translate-model-container tpap-provider-step-modal">' +
			'<div class="tpap-bulk-translate-model tpap-provider-model">' +
			'<div class="tpap-bulk-translate-model-header">' +
			'<div class="tpap-modal-header-inner">' +
			'<span class="tpap-step-label">' + escapeHtmlString(stepLabel) + '</span>' +
			'<h2>Select Translation Provider</h2>' +
			'<p class="tpap-model-desc">Select the AI provider you’d like to use for this translation batch.</p>' +
			'</div>' +
			'<button class="tpap-bulk-translate-model-close" title="Close">&times;</button></div>' +
			'<div class="tpap-bulk-translate-model-body">' +
			settingsNoticeHtml +
			'<div class="tpap-provider-cards">' + cardsHtml + '</div>' +
			'</div>' +
			'<div class="tpap-bulk-translate-model-footer">' +
			'<button class="tpap-bulk-translate-model-back button tpap-dashboard-btn tpap-btn-cancel">Back</button>' +
			'<button type="button" class="button tpap-dashboard-btn tpap-bulk-translate-model-start primary" disabled>Start Translation <span class="tpap-next-arrow">&#8594;</span></button>' +
			'</div></div></div>';

		$('body').append(html);
		$(SEL.modal).addClass('tpap-active');

		const $container = $(SEL.modal);
		const $cards = $container.find('.tpap-provider-card');
		const $startBtn = $container.find('.tpap-bulk-translate-model-start');

		function setSelected($card) {
			$cards.removeClass('tpap-provider-card-selected');
			if ($card) {
				const hasKeyData = $card.data('has-key');
				const envReadyData = $card.data('env-ready');
				if (hasKeyData === 1 && envReadyData !== 0) {
					$card.addClass('tpap-provider-card-selected');
				}
			}
			const selected = $container.find('.tpap-provider-card-selected');
			$startBtn.prop('disabled', selected.length === 0);
		}

		$cards.on('click', function (e) {
			// Let Docs and Add/Configure buttons work without toggling card selection.
			if ($(e.target).closest('.tpap-provider-card-docs, .tpap-provider-card-add-key').length) {
				return;
			}
			const $card = $(this);
			const hasKeyData = $card.data('has-key');
			const envReadyData = $card.data('env-ready');
			if (hasKeyData === 1 && envReadyData !== 0) {
				// Toggle selection: clicking the already-selected provider deselects it.
				if ($card.hasClass('tpap-provider-card-selected')) {
					setSelected(null);
				} else {
					setSelected($card);
				}
			}
		});
		$cards.on('keydown', function (e) {
			if (e.key === 'Enter' || e.key === ' ') {
				e.preventDefault();
				$(this).trigger('click');
			}
		});

		$container.find('.tpap-bulk-translate-model-close').on('click', function () {
			closeModal($container);
		});
		$container.find('.tpap-bulk-translate-model-back').on('click', function () {
			// Instantly transition back to language selection and keep selected languages.
			const $sel = $container.find('.tpap-provider-card-selected');
			const selectedProviderId = $sel.length ? $sel.attr('data-provider-id') : '';
			closeModal($container);
			openLanguageSelectModal(selectedLangs, selectedProviderId);
		});
		$container.find('.tpap-bulk-translate-model-start').on('click', function () {
			if ($startBtn.prop('disabled')) return;
			$startBtn.prop('disabled', true);
			const $sel = $container.find('.tpap-provider-card-selected');
			const provider = $sel.length ? $sel.attr('data-provider-id') : '';
			closeModal($container);
			setTimeout(function () {
				startBulkCrawl(selectedLangs, pageIds, null, { provider: provider });
			}, MODAL_ANIMATION_MS);
		});
	}

	function collectFailedByLang(data, failedByLang, lang) {
		if (!data.failed_details || data.failed_details.length === 0) {
			return;
		}
		failedByLang[lang] = failedByLang[lang] || [];
		const details = data.failed_details;
		for (let i = 0; i < details.length; i++) {
			const pid = details[i].page_id;
			if (failedByLang[lang].indexOf(pid) === -1) {
				failedByLang[lang].push(pid);
			}
		}
	}

	/**
	 * Remove from failedByLang pages that succeeded (so retry button hides when all pass on retry).
	 *
	 * @param {Object} data
	 * @param {Object} failedByLang
	 * @param {string} lang
	 */
	function removeSucceededFromFailed(data, failedByLang, lang) {
		if (!data.pages_data || !failedByLang[lang] || failedByLang[lang].length === 0) {
			return;
		}
		const failedIds = [];
		if (data.failed_details) {
			data.failed_details.forEach(function (fd) {
				failedIds.push(String(fd.page_id));
			});
		}
		const toRemove = [];
		Object.keys(data.pages_data).forEach(function (pid) {
			if (failedIds.indexOf(String(pid)) === -1) {
				toRemove.push(pid);
			}
		});
		if (toRemove.length === 0) {
			return;
		}
		failedByLang[lang] = failedByLang[lang].filter(function (id) {
			return toRemove.indexOf(String(id)) === -1;
		});
	}

	/**
	 * Get status UI config for a task (class and HTML for status/actions cells).
	 * Centralizes status logic for both full table build and single-row updates.
	 *
	 * @param {Object} task - Task object with status, pageUrl, errorMessage, isChromeAi, etc.
	 * @returns {{ statusClass: string, statusHtml: string, actionsHtml: string }}
	 */
	function getStatusConfig(task) {
		const dashboardUrl = (config.dashboard_url || '').trim();
		const settingsUrl = dashboardUrl
			? dashboardUrl + (dashboardUrl.indexOf('?') !== -1 ? '&' : '?') + 'tab=settings'
			: '';

		switch (task.status) {
			case STATUS.IN_PROGRESS:
				return {
					statusClass: 'tpap-status-progress',
					statusHtml: '<span class="tpap-status-in-progress-wrap"><span class="tpap-task-spinner-ring"></span><span class="tpap-status-circle tpap-status-progress"><span class="tpap-status-pct"></span></span></span>',
					actionsHtml: ''
				};
			case STATUS.NOT_SUPPORTED:
				return {
					statusClass: 'tpap-status-not-supported',
					statusHtml: '<span class="tpap-status-badge tpap-status-not-supported">Not supported</span>',
					actionsHtml: ''
				};
			case STATUS.COMPLETED:
				return {
					statusClass: 'tpap-status-completed',
					statusHtml: '<span class="tpap-status-circle tpap-status-completed"><span class="tpap-status-pct">100%</span></span>',
					actionsHtml: (task.pageUrl)
						? '<a href="' + escapeHtmlString(task.pageUrl) + '" target="_blank" rel="noopener noreferrer" class="tpap-btn-review button button-small">Review</a>'
						: '<span class="tpap-badge-done">Complete</span>'
				};
			case STATUS.ALREADY_TRANSLATED:
				return {
					statusClass: 'tpap-status-already-translated',
					statusHtml: '<span class="tpap-status-badge tpap-status-already-translated">Already Translated</span>',
					actionsHtml: (task.pageUrl)
						? '<a href="' + escapeHtmlString(task.pageUrl) + '" target="_blank" rel="noopener noreferrer" class="tpap-btn-review button button-small">Review</a>'
						: '<span class="tpap-status-badge tpap-status-already-translated">Already translated</span>'
				};
			case STATUS.ERROR: {
				// Don't show Configure for load/data errors (no point opening Chrome AI settings).
				const loadErrorCodes = ['NO_PAGE_DATA', 'LOAD_FAILED', 'LOAD_ERROR'];
				const isLoadStringsError = task.errorCode && loadErrorCodes.indexOf(task.errorCode) !== -1;
				const showConfigure = task.isChromeAi && settingsUrl && !isLoadStringsError;
				return {
					statusClass: 'tpap-status-error',
					statusHtml: '<span class="tpap-status-error-msg">' + escapeHtmlString(task.errorMessage || 'Error') + '</span>',
					actionsHtml: showConfigure
						? '<a href="' + escapeHtmlString(settingsUrl) + '#tpap-chrome-local-ai-notice" target="_blank" rel="noopener noreferrer" class="tpap-provider-card-add-key">Configure</a>'
						: ''
				};
			}
			default:
				return {
					statusClass: 'tpap-status-pending',
					statusHtml: '<span class="tpap-status-badge tpap-status-pending">Pending</span>',
					actionsHtml: ''
				};
		}
	}

	/**
	 * Build grouped table rows HTML for each task in the progress modal.
	 * Rows are grouped by page so the page title is shown once in a header
	 * row, with all of that page's languages listed underneath.
	 *
	 * @param {Array} tasks
	 * @returns {string}
	 */
	function buildTaskRowsHtml(tasks) {
		let html = '';
		let currentPageId = null;

		// Use tasks array order directly so the table matches the actual
		// processing order (page-by-page, language-by-language).
		tasks.forEach(function (t) {
			const config = getStatusConfig(t);

			const langDisplayName = (t.langName != null && t.langName !== '') ? t.langName : t.lang;
			const langFlagHtml = (t.langFlag != null && t.langFlag !== '') ? '<img src="' + escapeHtmlString(t.langFlag) + '" alt="" class="tpap-lang-flag" />' : '';

			// Insert a page title header row the first time we encounter each page.
			if (t.pageId !== currentPageId) {
				currentPageId = t.pageId;
				const pageTitle = t.pageTitle || '(no title)';
				html += '<tr class="tpap-page-group-header" data-page-id="' + escapeHtmlString(String(t.pageId)) + '">' +
					'<td colspan="3" class="tpap-col-page-group">' +
					escapeHtmlString(pageTitle) +
					'</td>' +
					'</tr>';
			}

			html += '<tr class="tpap-task-row ' + config.statusClass + '" data-page-id="' + escapeHtmlString(t.pageId) + '" data-lang="' + escapeHtmlString(t.lang) + '">' +
				'<td class="tpap-col-lang">' + langFlagHtml + '<span class="tpap-lang-name">' + escapeHtmlString(langDisplayName) + '</span></td>' +
				'<td class="tpap-col-status">' + config.statusHtml + '</td>' +
				'<td class="tpap-col-actions">' + config.actionsHtml + '</td>' +
				'</tr>';
		});

		return html;
	}

	/**
	 * Update a single task row in the progress table (avoids full table re-render).
	 *
	 * @param {jQuery} $tbody - Table body element.
	 * @param {Array} tasks - Tasks array (to find task by pageId/lang).
	 * @param {string} pageId
	 * @param {string} lang
	 */
	function updateTaskRow($tbody, tasks, pageId, lang, taskIndex) {
		const pidStr = String(pageId);
		const task = taskIndex ? taskIndex[createTaskKey(pidStr, lang)] : tasks.find(function (x) {
			return String(x.pageId) === pidStr && x.lang === lang;
		});
		if (!task) return;

		const $row = $tbody.find('tr.tpap-task-row').filter(function () {
			return $(this).attr('data-page-id') === pidStr && $(this).attr('data-lang') === lang;
		});
		if (!$row.length) return;

		const statusConfig = getStatusConfig(task);
		$row.removeClass('tpap-status-pending tpap-status-progress tpap-status-completed tpap-status-already-translated tpap-status-error tpap-status-not-supported')
			.addClass('tpap-task-row ' + statusConfig.statusClass);
		$row.find('.tpap-col-status').html(statusConfig.statusHtml);
		$row.find('.tpap-col-actions').html(statusConfig.actionsHtml);
	}

	/**
	 * Run Chrome AI translation for all pending strings on a single page.
	 * @param {string|number} pageId
	 * @param {string} lang
	 * @param {Object} pageData
	 * @returns {Promise<{dict: Object, gettext: Object}>}
	 */
	function runChromeAiTranslationForPage(pageId, lang, pageData) {
		if (typeof window === 'undefined' || !window.ChromeAiTranslator) {
			throw new Error('Chrome AI is not available in this browser.');
		}
		const dictStrings = Array.isArray(pageData.dict_strings) ? pageData.dict_strings : [];
		const gettextStrings = Array.isArray(pageData.gettext_strings) ? pageData.gettext_strings : [];
		if (dictStrings.length === 0 && gettextStrings.length === 0) return Promise.resolve({ dict: {}, gettext: {} });

		const safeLang = String(lang || '');
		const tableKey = String(pageId) + '-' + safeLang.replace(/[^a-z0-9_-]/gi, '');
		const $container = createBulkStringsTable('tpap-chrome-ai-bulk', tableKey, dictStrings, gettextStrings);
		const containerId = String($container.attr('id') || '');
		const cleanup = function () { if (containerId) { jQuery('#' + containerId).remove(); } };
		return new Promise(async function (resolve, reject) {
			function collectResults() {
				try {
					const dictOut = {}; const gettextOut = {};
					$container.find('.tpap-google-table-row[data-string-id]').each(function () {
						const $row = jQuery(this);
						const bucket = String($row.attr('data-bucket') || '');
						const id = String($row.attr('data-string-id') || '');
						if (!id || !bucket) return;
						const $trans = $row.find('.tpap-translated');
						const $src = $row.find('.tpap-source');
						let text = ($trans.text() || '').trim();
						if (!text && $trans.find('font').length && $trans[0]) {
							text = String($trans[0].innerText || '').trim();
						}
						if (!text) {
							text = ($src.text() || '').trim();
						}
						const orig = String($src.attr('data-original') || $src.text() || '').trim();
						if (!text || text === orig) {
							return;
						}
						if (bucket === 'dict') dictOut[id] = text;
						else if (bucket === 'gettext') gettextOut[id] = text;
					});
					resolve({ dict: dictOut, gettext: gettextOut });
				} catch (e) { reject(e); }
			}
			const opts = {
				mainWrapperSelector: '#' + containerId,
				btnSelector: '#' + containerId,
				btnClass: 'chrome_ai_translator_btn', btnText: 'Translate',
				stringSelector: '#' + containerId + ' .tpap-google-table-cell.tpap-source',
				progressBarSelector: '',
				sourceLanguage: normalizeLangForChromeAi(config.default_language || ''),
				targetLanguage: normalizeLangForChromeAi(lang),
				onStartTranslationProcess: function () { }, onBeforeTranslate: function () { }, onAfterTranslate: function () { },
				onComplete: collectResults,
				onLanguageError: function (msg) { reject(new Error(msg || 'Chrome AI language pair is not available.')); },
				targetLanguageLabel: getLanguageName(lang)
			};
			let translatorObj;
			try { translatorObj = await ChromeAiTranslator.Object(opts); } catch (err) { reject(err); return; }
			if (!translatorObj || typeof translatorObj.init !== 'function') {
				reject(new Error('Chrome AI could not be initialized for this language.')); return;
			}
			try {
				translatorObj.init();
				if (typeof translatorObj.startTranslation === 'function') translatorObj.startTranslation();
				else jQuery('#' + containerId).find('button.chrome_ai_translator_btn').trigger('click');
			} catch (e) { reject(e); }
		}).finally(cleanup);
	}

	function createBulkStringsTable(idPrefix, pageId, dictRows, gettextRows) {
		const prefix = idPrefix ? String(idPrefix) : 'tpap-bulk-strings';
		const containerId = prefix + '-' + String(pageId).replace(/[^a-z0-9_-]/gi, '');

		const visibleBaseCss = {
			background: '#fff',
			border: '1px solid #ccd0d4',
			boxShadow: '0 2px 8px rgba(0,0,0,.08)',
			overflow: 'auto',
			pointerEvents: 'auto',
			opacity: '1'
		};

		const $container = $('<div></div>')
			.attr('id', containerId)
			.addClass('tpap-google-widget-bulk-container tpap-google-table-container translate')
			.attr('aria-hidden', 'true')
			.css(
				{
						position: 'fixed',
						left: 'max(8px, calc((100vw - 1200px) / 2))',
						top: '40px',
						width: 'min(96vw, 1200px)',
						height: '85vh',
						opacity: '0',
						pointerEvents: 'none',
						overflow: 'auto',
						zIndex: '0'
					}
			);

		const stringsId = containerId + '-strings';
		const $stringsContainer = $('<div></div>')
			.attr('id', stringsId)
			.addClass('tpap-google-translate-strings-container');

		const appendRows = function (bucket, rows) {
			(rows || []).forEach(function (row) {
				const id = Number(row && row.id);
				if (!id) return;
				const original = String((row && row.original) || '');
				const $row = $('<div class="tpap-google-table-row"></div>')
					.attr('data-bucket', bucket)
					.attr('data-string-id', String(id));
				$row.append(
					$('<div class="tpap-google-table-cell tpap-id"></div>').text(String(id)),
					$('<div class="tpap-google-table-cell tpap-source"></div>').text(original).attr('data-original', original),
					$('<div class="tpap-google-table-cell tpap-translated"></div>')
				);
				$stringsContainer.append($row);
			});
		};

		appendRows('dict', dictRows);
		appendRows('gettext', gettextRows);

		const $headerRow = $('<div class="tpap-google-table-row tpap-google-table-row--header"></div>')
			.append(
				$('<div class="tpap-google-table-cell">ID</div>'),
				$('<div class="tpap-google-table-cell">Source</div>'),
				$('<div class="tpap-google-table-cell">Translation</div>')
			);

		const $grid = $('<div class="tpap-google-widget-bulk-grid"></div>');
		$grid.append($headerRow);
		$grid.append($stringsContainer);
		$container.append($grid);
		$('body').append($container);

		return $container;
	}

	async function runGoogleTranslateElementForTableLanguages($container, rows, sourceLang, targetLangs) {
		if (!window.tpapBulkGoogleProvider || typeof window.tpapBulkGoogleProvider.translateTableForLanguages !== 'function') {
			throw new Error('Google widget provider module is missing.');
		}
		return window.tpapBulkGoogleProvider.translateTableForLanguages($container, rows, sourceLang, targetLangs);
	}

	async function runGoogleWidgetTranslationsForPageLangs(pageId, pageData, sourceLang, targetLangs) {
		const dictRows = Array.isArray(pageData.dict_strings) ? pageData.dict_strings : [];
		const gettextRows = Array.isArray(pageData.gettext_strings) ? pageData.gettext_strings : [];
		const $stringTable = createBulkStringsTable('tpap-google-widget-bulk', pageId, dictRows, gettextRows);

		try {
			const rows = [];
			$stringTable.find('.tpap-google-table-row[data-string-id]').each(function () {
				const $row = $(this);
				rows.push({
					bucket: String($row.attr('data-bucket') || ''),
					id: Number($row.attr('data-string-id') || 0),
					original: $row.find('.tpap-source').text() || '',
					$row: $row
				});
			});
			if (!rows.length) {
				return { results: {}, errors: {} };
			}

			let providerBundle;
			try {
				providerBundle = await runGoogleTranslateElementForTableLanguages($stringTable, rows, sourceLang, targetLangs);
			} catch (e) {
				const msg = e && e.message ? String(e.message) : 'Google widget translation failed';
				const errors = {};
				(targetLangs || []).forEach(function (lang) {
					errors[lang] = msg;
				});
				providerBundle = { results: {}, errors: errors };
			}

			const results = providerBundle && providerBundle.results ? providerBundle.results : {};
			const errors = providerBundle && providerBundle.errors ? providerBundle.errors : {};

			// Fallback to Google public endpoint when widget does not translate for a language.
			for (let i = 0; i < targetLangs.length; i++) {
				const lang = targetLangs[i];
				if (results[lang]) continue;
				const originals = rows.map(function (r) { return r.original; });
				try {
					const translations = await translateTextsWithGoogleWidget(originals, sourceLang, lang);
					const dict = {};
					const gettext = {};
					for (let j = 0; j < rows.length; j++) {
						const translated = translations[j] != null ? String(translations[j]) : '';
						if (rows[j].bucket === 'dict') dict[rows[j].id] = translated;
						else gettext[rows[j].id] = translated;
					}
					results[lang] = { dict: dict, gettext: gettext };
				} catch (fallbackErr) {
					errors[lang] = fallbackErr && fallbackErr.message ? String(fallbackErr.message) : (errors[lang] || 'Google fallback translation failed');
				}
			}

			return { results: results, errors: errors };
		} finally {
			$stringTable.remove();
		}
	}

	/**
	 * Build task queue entries for all selected page/language combinations.
	 *
	 * @param {Array<string>} selectedLangs Selected target languages.
	 * @param {Array<number>} pageIds Selected page IDs.
	 * @param {Object} failedByLang Previous run failed pages map.
	 * @param {boolean} isRetry Whether this queue is for retry mode.
	 * @param {Object} pageTitlesMap Page title lookup map.
	 * @param {boolean} isChromeAi Whether Chrome AI mode is active.
	 * @param {boolean} isGoogleWidget Whether Google widget mode is active.
	 * @returns {Array<Object>} Normalized task list.
	 */
	function createTaskList(selectedLangs, pageIds, failedByLang, isRetry, pageTitlesMap, isChromeAi, isGoogleWidget) {
		const languageFlags = config.language_flags || {};
		const tasks = [];
		if (isRetry) {
			const allFailedPageIds = [];
			selectedLangs.forEach(function (lang) {
				(failedByLang[lang] || []).forEach(function (pid) {
					if (allFailedPageIds.indexOf(pid) === -1) allFailedPageIds.push(pid);
				});
			});
			allFailedPageIds.forEach(function (pid) {
				const pageIdStr = String(pid);
				const pageTitle = (pageTitlesMap[pageIdStr] != null && pageTitlesMap[pageIdStr] !== '') ? pageTitlesMap[pageIdStr] : '';
				selectedLangs.forEach(function (lang) {
					if ((failedByLang[lang] || []).indexOf(pid) === -1) return;
					tasks.push({
						pageId: pageIdStr, pageTitle: pageTitle, lang: lang,
						langName: getLanguageName(lang), langFlag: languageFlags[lang] || '',
						isChromeAi: isChromeAi, chromeSupported: isChromeAi ? isChromeAiLanguageSupported(lang) : true,
						googleWidgetSupported: isGoogleWidget ? isGoogleWidgetLanguageSupported(lang) : true,
						status: STATUS.PENDING, percent: 0, errorMessage: ''
					});
				});
			});
		} else {
			pageIds.forEach(function (pid) {
				const pageIdStr = String(pid);
				const pageTitle = (pageTitlesMap[pageIdStr] != null && pageTitlesMap[pageIdStr] !== '') ? pageTitlesMap[pageIdStr] : '';
				selectedLangs.forEach(function (lang) {
					tasks.push({
						pageId: pageIdStr, pageTitle: pageTitle, lang: lang,
						langName: getLanguageName(lang), langFlag: languageFlags[lang] || '',
						isChromeAi: isChromeAi, chromeSupported: isChromeAi ? isChromeAiLanguageSupported(lang) : true,
						googleWidgetSupported: isGoogleWidget ? isGoogleWidgetLanguageSupported(lang) : true,
						status: STATUS.PENDING, percent: 0, errorMessage: ''
					});
				});
			});
		}
		return tasks;
	}

	function createTaskKey(pageId, lang) {
		return String(pageId) + '_' + String(lang);
	}

	function createTaskIndex(tasks) {
		const taskIndex = {};
		const list = Array.isArray(tasks) ? tasks : [];
		for (let i = 0; i < list.length; i++) {
			const task = list[i];
			taskIndex[createTaskKey(task.pageId, task.lang)] = task;
		}
		return taskIndex;
	}

	/**
	 * Create shared runtime context for one bulk translation run.
	 *
	 * @param {Array<string>} selectedLangs Selected language codes.
	 * @param {Array<number>} pageIds Selected page IDs.
	 * @param {number} sessionStartTime Timestamp when the run started.
	 * @param {Object} options Provider and retry options.
	 * @returns {Object} Mutable bulk processing context.
	 */
	function createBulkContext(selectedLangs, pageIds, sessionStartTime, options) {
		options = options || {};
		let failedByLang = options.failedByLang || null;
		const provider = options.provider || '';
		const isRetry = failedByLang && Object.keys(failedByLang).length > 0;
		const isChromeAi = provider === 'chrome_ai';
		const isGoogleWidget = provider === 'google_widget';
		if (isRetry) {
			selectedLangs = Object.keys(failedByLang);
			pageIds = [];
			selectedLangs.forEach(function (lang) {
				(failedByLang[lang] || []).forEach(function (pid) {
					if (pageIds.indexOf(pid) === -1) pageIds.push(pid);
				});
			});
		} else {
			if (!Array.isArray(selectedLangs) || selectedLangs.length === 0) { 
				console.log('startBulkCrawl: no languages selected'); 
				return null; 
			}
			if (!Array.isArray(pageIds) || pageIds.length === 0) { 
				console.log('startBulkCrawl: no page IDs'); 
				return null; 
			}
		}
		sessionStartTime = sessionStartTime != null ? sessionStartTime : Date.now();
		failedByLang = isRetry ? (options.failedByLang || {}) : {};
		const pageTitlesMap = getPageTitlesFromTable();
		const tasks = createTaskList(selectedLangs, pageIds, failedByLang, isRetry, pageTitlesMap, isChromeAi, isGoogleWidget);
		const taskIndex = createTaskIndex(tasks);
		return {
			provider: provider, isChromeAi: isChromeAi, isGoogleWidget: isGoogleWidget, isRetry: isRetry, tasks: tasks,
			taskIndex: taskIndex,
			selectedLangs: Array.isArray(selectedLangs) ? selectedLangs.slice() : [],
			pageIds: Array.isArray(pageIds) ? pageIds.slice() : [],
			failedByLang: failedByLang, sessionStartTime: sessionStartTime,
			stopProcess: false, currentRequest: null, completed: 0, elapsedInterval: null
		};
	}

	function buildProgressModalHtml(tasks) {
		const label = 'STEP 3 OF 3';
		return '<div class="tpap-bulk-translate-model-container tpap-progress-modal tpap-active">' +
			'<div class="tpap-bulk-translate-model tpap-progress-model-wide">' +
			'<div class="tpap-bulk-translate-model-header">' +
			'<div class="tpap-modal-header-inner">' +
			'<span class="tpap-step-label">' + escapeHtmlString(label) + '</span><h2>Bulk Translation</h2>' +
			'<p class="tpap-model-desc">Translating your selected content. You can stop the process at any time.</p>' +
			'</div><button class="tpap-bulk-progress-close tpap-bulk-translate-model-close" title="Close">&times;</button></div>' +
			'<div class="tpap-bulk-translate-model-body">' +
			'<div class="tpap-progress-header">' +
			'<div class="tpap-bulk-progress-bar-container"><div class="tpap-bulk-progress-bar" style="width: 0%"></div></div>' +
			'<p class="tpap-progress-percent-wrap"><span class="tpap-progress-percent">0%</span></p></div>' +
			'<div class="tpap-bulk-progress-table-wrap">' +
			'<table class="tpap-bulk-progress-table">' +
			'<thead><tr><th>Language</th><th>Status</th><th>Actions</th></tr></thead>' +
			'<tbody class="tpap-bulk-progress-tbody">' + buildTaskRowsHtml(tasks) + '</tbody></table></div></div>' +
			'<div class="tpap-bulk-translate-model-footer">' +
			'<button class="tpap-bulk-cancel-process button tpap-dashboard-btn tpap-bulk-translate-model-cancel tpap-btn-cancel">Stop Process</button>' +
			'<button class="tpap-bulk-retry-failed-btn button tpap-dashboard-btn tpap-is-hidden">Retry failed pages</button>' +
			'<button class="tpap-bulk-finish-btn button tpap-dashboard-btn primary tpap-is-hidden">Finish</button>' +
			'</div></div></div>';
	}

	function updateTaskInContext(context, pageId, lang, update) {
		const pidStr = String(pageId);
		const task = context.taskIndex ? context.taskIndex[createTaskKey(pidStr, lang)] : null;
		if (!task) return;
		if (update.pageTitle !== undefined) task.pageTitle = (update.pageTitle === '' && task.pageTitle) ? task.pageTitle : update.pageTitle;
		if (update.status !== undefined) task.status = update.status;
		if (update.percent !== undefined) task.percent = update.percent;
		if (update.errorMessage !== undefined) task.errorMessage = update.errorMessage;
		if (update.errorCode !== undefined) task.errorCode = update.errorCode;
		if (update.pageUrl !== undefined) task.pageUrl = update.pageUrl;
	}

	function queueTaskRowUpdate(context, pageId, lang) {
		if (!context) return;
		if (!context.rowUpdateQueue) context.rowUpdateQueue = {};
		context.rowUpdateQueue[createTaskKey(pageId, lang)] = { pageId: String(pageId), lang: String(lang) };
	}

	function flushTaskRowUpdates(ui, context) {
		if (!context || !context.rowUpdateQueue) return;
		const queue = context.rowUpdateQueue;
		context.rowUpdateQueue = {};
		for (const k in queue) {
			if (!Object.prototype.hasOwnProperty.call(queue, k)) continue;
			const item = queue[k];
			updateTaskRow(ui.$tbody, context.tasks, item.pageId, item.lang, context.taskIndex);
		}
	}

	function renderTaskRow(ui, context, pageId, lang) {
		queueTaskRowUpdate(context, pageId, lang);
		flushTaskRowUpdates(ui, context);
	}

	function updateOverallProgress(context, ui) {
		const total = context.tasks.length;
		const pct = total ? Math.min(100, Math.round((context.completed / total) * 1000) / 10) : 0;
		ui.$progressBar.css('width', pct + '%');
		ui.$percentEl.text(pct + '%');
	}

	function markBatchFailedInContext(ids, langCode, errorMessage, errorCode, context, ui) {
		context.failedByLang[langCode] = context.failedByLang[langCode] || [];
		ids.forEach(function (pid) {
			if (context.failedByLang[langCode].indexOf(pid) === -1) context.failedByLang[langCode].push(pid);
			updateTaskInContext(context, pid, langCode, { status: STATUS.ERROR, errorMessage: errorMessage, errorCode: errorCode });
		queueTaskRowUpdate(context, pid, langCode);
		});
		flushTaskRowUpdates(ui, context);
	}

	function applyPagesDataToContext(pagesData, lang, context) {
		if (!pagesData) return;
		for (const pid in pagesData) {
			if (!Object.prototype.hasOwnProperty.call(pagesData, pid)) {
				continue;
			}
			const pdata = pagesData[pid];
			const title = (pdata && pdata.title != null) ? String(pdata.title) : '';
			const reviewUrl = (pdata && pdata.review_url) ? String(pdata.review_url) : '';
			updateTaskInContext(context, pid, lang, pdata && pdata.already_translated
				? { pageTitle: title, status: STATUS.ALREADY_TRANSLATED, percent: 100, pageUrl: reviewUrl }
				: { pageTitle: title, status: STATUS.COMPLETED, percent: 100, pageUrl: reviewUrl });
			queueTaskRowUpdate(context, pid, lang);
		}
	}

	function applyFailedDetailsToContext(failedDetails, lang, context) {
		if (!failedDetails) return;
		failedDetails.forEach(function (fd) {
			updateTaskInContext(context, fd.page_id, lang, { pageTitle: fd.title, status: STATUS.ERROR, errorMessage: fd.reason || 'Failed' });
			queueTaskRowUpdate(context, fd.page_id, lang);
		});
	}

	/**
	 * Render and initialize the progress modal UI.
	 *
	 * @param {Object} context Bulk processing context.
	 * @returns {Object} UI handlers and references.
	 */
	function createProgressModal(context) {
		$(SEL.modal).remove();
		const $modal = $(buildProgressModalHtml(context.tasks)).appendTo('body');
		const ui = {
			$modal: $modal,
			$progressHeader: $modal.find('.tpap-progress-header'),
			$progressDesc: $modal.find('.tpap-bulk-translate-model-header .tpap-model-desc'),
			$tbody: $modal.find('.tpap-bulk-progress-tbody'),
			$progressBar: $modal.find('.tpap-bulk-progress-bar'),
			$percentEl: $modal.find('.tpap-progress-percent'),
			$cancelBtn: $modal.find('.tpap-bulk-cancel-process'),
			$finishBtn: $modal.find('.tpap-bulk-finish-btn'),
			$retryBtn: $modal.find('.tpap-bulk-retry-failed-btn')
		};
		$modal.find('.tpap-bulk-progress-close').on('click', function () {
			context.stopProcess = true;
			if (context.currentRequest && typeof context.currentRequest.abort === 'function') context.currentRequest.abort();
			if (context.elapsedInterval != null) { clearInterval(context.elapsedInterval); context.elapsedInterval = null; }
			$(SEL.modal).remove();
			location.reload();
		});
		ui.$cancelBtn.on('click', function () {
			context.stopProcess = true;
			if (context.currentRequest && typeof context.currentRequest.abort === 'function') context.currentRequest.abort();
			if (context.elapsedInterval != null) { clearInterval(context.elapsedInterval); context.elapsedInterval = null; }
			$(SEL.modal).remove();
			location.reload();
		});
		return ui;
	}

	function handleTaskResult(task, result, context, ui) {
		if (!result) return;
		if (result.success) {
			if (context.isRetry) {
				collectFailedByLang(result.data, context.failedByLang, task.lang);
				applyPagesDataToContext(result.data.pages_data, task.lang, context);
				applyFailedDetailsToContext(result.data.failed_details || [], task.lang, context);
				removeSucceededFromFailed(result.data, context.failedByLang, task.lang);
			} else {
				applyPagesDataToContext(result.data.pages_data, task.lang, context);
			}
			const pagesData = result.data.pages_data || {};
			Object.keys(pagesData).forEach(function (pid) { renderTaskRow(ui, context, pid, task.lang); });
			(result.data.failed_details || []).forEach(function (fd) { renderTaskRow(ui, context, fd.page_id, task.lang); });
		} else {
			const errData = result.data && result.data.error;
			const errorCode = errData && errData.code ? errData.code : undefined;
			markBatchFailedInContext([task.pageId], task.lang, (result.data && result.data.message) || 'Unknown error', errorCode, context, ui);
		}
	}

	/**
	 * Process tasks one-by-one (non-Google-widget providers).
	 *
	 * @param {Object} context Bulk processing context.
	 * @param {Object} ui Progress modal UI references.
	 * @returns {Promise<void>}
	 */
	async function processTasksSequentially(context, ui) {
		if (context && context.isGoogleWidget) {
			await processGoogleWidgetTasksByPage(context, ui);
			return;
		}
		for (let i = 0; i < context.tasks.length; i++) {
			if (context.stopProcess) break;
			const task = context.tasks[i];
			const pid = task.pageId;
			const lang = task.lang;
			if (context.isChromeAi && task.chromeSupported === false) {
				updateTaskInContext(context, pid, lang, { status: STATUS.NOT_SUPPORTED, percent: 0 });
				renderTaskRow(ui, context, pid, lang);
				context.completed++;
				updateOverallProgress(context, ui);
				await yieldToUi();
				continue;
			}
			if (context.isGoogleWidget && task.googleWidgetSupported === false) {
				updateTaskInContext(context, pid, lang, { status: STATUS.NOT_SUPPORTED, percent: 0 });
				renderTaskRow(ui, context, pid, lang);
				context.completed++;
				updateOverallProgress(context, ui);
				await yieldToUi();
				continue;
			}
			updateTaskInContext(context, pid, lang, { status: STATUS.IN_PROGRESS, percent: 0 });
			renderTaskRow(ui, context, pid, lang);
			if (ui.$progressDesc && ui.$progressDesc.length) {
				const pageLabel = task && task.pageTitle ? String(task.pageTitle) : String(pid);
				const providerName = getProviderDisplayName(context.provider);
				ui.$progressDesc.text('Translating ' + pageLabel + ' into ' + getLanguageName(lang) + (providerName ? ' via ' + providerName : ''));
			}
			ui.$progressHeader.addClass('tpap-progress-loading');
			await yieldToUi();
			let crawlResponse;
			try {
				crawlResponse = await runTranslationTask(task, context);
			} catch (e) {
				markBatchFailedInContext([pid], lang, getRequestErrorMessage(e), 'LOAD_ERROR', context, ui);
			} finally {
				ui.$progressHeader.removeClass('tpap-progress-loading');
			}
			handleTaskResult(task, crawlResponse, context, ui);
			context.completed++;
			updateOverallProgress(context, ui);
			await yieldToUi();
		}
	}

	/**
	 * Process Google widget tasks grouped by page, then by selected languages.
	 *
	 * @param {Object} context Bulk processing context.
	 * @param {Object} ui Progress modal UI references.
	 * @returns {Promise<void>}
	 */
	async function processGoogleWidgetTasksByPage(context, ui) {
		const sourceLang = config.default_language || '';
		const selectedLangs = Array.isArray(context.selectedLangs) ? context.selectedLangs.slice() : [];
		const pageIds = Array.isArray(context.pageIds) ? context.pageIds.slice() : [];

		for (let p = 0; p < pageIds.length; p++) {
			if (context.stopProcess) break;
			const pid = String(pageIds[p]);

			const langsForPage = selectedLangs.filter(function (lang) {
				const task = context.taskIndex ? context.taskIndex[createTaskKey(pid, lang)] : null;
				if (!task) return false;
				if (task.googleWidgetSupported === false) return false;
				if (context.isRetry) {
					const failed = context.failedByLang && context.failedByLang[lang] ? context.failedByLang[lang] : [];
					return failed.indexOf(pid) !== -1;
				}
				return true;
			});

			// Unsupported languages for this page are immediately marked.
			selectedLangs.forEach(function (lang) {
				const task = context.taskIndex ? context.taskIndex[createTaskKey(pid, lang)] : null;
				if (!task) return;
				if (task.googleWidgetSupported === false) {
					updateTaskInContext(context, pid, lang, { status: STATUS.NOT_SUPPORTED, percent: 0 });
					renderTaskRow(ui, context, pid, lang);
					context.completed++;
					updateOverallProgress(context, ui);
				}
			});

			if (!langsForPage.length) {
				await yieldToUi();
				continue;
			}

			// TranslatePress uses one dictionary table per target language (trp_dictionary_{source}_{target}).
			// Row IDs are not shared across those tables — loading strings for only the first language
			// produced correct translations in JS but wrong DB rows for all other languages.
			for (let li = 0; li < langsForPage.length; li++) {
				if (context.stopProcess) break;
				const lang = langsForPage[li];
				const pageStartTime = Date.now();
				ui.$progressHeader.addClass('tpap-progress-loading');
				await yieldToUi();

				let loadRes;
				let pageData;
				try {
					context.currentRequest = apiLoadStringsForPage(pid, lang);
					loadRes = await context.currentRequest;
					const pagesPayload = loadRes.data && loadRes.data.pages ? loadRes.data.pages : {};
					pageData = pagesPayload && pagesPayload[pid] ? pagesPayload[pid] : null;
				} catch (e) {
					markBatchFailedInContext([pid], lang, getRequestErrorMessage(e), 'LOAD_ERROR', context, ui);
					context.completed++;
					updateOverallProgress(context, ui);
					ui.$progressHeader.removeClass('tpap-progress-loading');
					context.currentRequest = null;
					await yieldToUi();
					continue;
				} finally {
					context.currentRequest = null;
					ui.$progressHeader.removeClass('tpap-progress-loading');
				}

				if (!loadRes || !loadRes.success || !pageData) {
					const msg = (loadRes && loadRes.data && loadRes.data.message) ? loadRes.data.message : 'Failed to load strings for this page.';
					markBatchFailedInContext([pid], lang, msg, 'LOAD_FAILED', context, ui);
					context.completed++;
					updateOverallProgress(context, ui);
					await yieldToUi();
					continue;
				}

				const hasDict = Array.isArray(pageData.dict_strings) && pageData.dict_strings.length > 0;
				const hasGettext = Array.isArray(pageData.gettext_strings) && pageData.gettext_strings.length > 0;
				if (!hasDict && !hasGettext) {
					updateTaskInContext(context, pid, lang, {
						pageTitle: pageData.title || '',
						status: STATUS.ALREADY_TRANSLATED,
						percent: 100,
						pageUrl: pageData.review_url || ''
					});
					renderTaskRow(ui, context, pid, lang);
					const ok = {
						success: true,
						data: { pages_data: { [pid]: { title: pageData.title || '', already_translated: true, review_url: pageData.review_url || '' } }, failed_details: [] }
					};
					handleTaskResult({ pageId: pid, lang: lang }, ok, context, ui);
					context.completed++;
					updateOverallProgress(context, ui);
					await yieldToUi();
					continue;
				}

				updateTaskInContext(context, pid, lang, { status: STATUS.IN_PROGRESS, percent: 0 });
				renderTaskRow(ui, context, pid, lang);
				if (ui.$progressDesc && ui.$progressDesc.length) {
					const taskKey = createTaskKey(pid, lang);
					const rowTask = context.taskIndex ? context.taskIndex[taskKey] : null;
					const pageLabel = rowTask && rowTask.pageTitle ? String(rowTask.pageTitle) : String(pid);
					const providerName = getProviderDisplayName(context.provider);
					ui.$progressDesc.text('Translating ' + pageLabel + ' into ' + getLanguageName(lang) + (providerName ? ' via ' + providerName : ''));
				}
				await yieldToUi();

				const dictStrings = Array.isArray(pageData.dict_strings) ? pageData.dict_strings : [];
				const gettextStrings = Array.isArray(pageData.gettext_strings) ? pageData.gettext_strings : [];
				const charCount = dictStrings.reduce(function (s, r) { return s + (r && r.original ? String(r.original).length : 0); }, 0) +
					gettextStrings.reduce(function (s, r) { return s + (r && r.original ? String(r.original).length : 0); }, 0);

				let providerBundle;
				try {
					providerBundle = await runGoogleWidgetTranslationsForPageLangs(pid, pageData, sourceLang, [lang]);
				} catch (e) {
					markBatchFailedInContext([pid], lang, getRequestErrorMessage(e), 'GOOGLE_WIDGET_ERROR', context, ui);
					context.completed++;
					updateOverallProgress(context, ui);
					await yieldToUi();
					continue;
				}

				const translated = providerBundle && providerBundle.results ? providerBundle.results[lang] : null;
				if (!translated) {
					const msg = providerBundle && providerBundle.errors && providerBundle.errors[lang]
						? providerBundle.errors[lang]
						: 'Google widget translation failed';
					markBatchFailedInContext([pid], lang, msg, 'GOOGLE_WIDGET_ERROR', context, ui);
					context.completed++;
					updateOverallProgress(context, ui);
					await yieldToUi();
					continue;
				}

				let saveRes;
				try {
					const elapsedSec = Math.max(1, Math.round((Date.now() - pageStartTime) / 1000));
					saveRes = await apiSavePreTranslatedStrings(
						lang,
						'google_widget',
						translated.dict || {},
						translated.gettext || {},
						pid,
						pageData,
						charCount,
						elapsedSec
					);
				} catch (e) {
					markBatchFailedInContext([pid], lang, getRequestErrorMessage(e), 'SAVE_ERROR', context, ui);
					context.completed++;
					updateOverallProgress(context, ui);
					await yieldToUi();
					continue;
				}

				if (!saveRes || !saveRes.success) {
					markBatchFailedInContext([pid], lang, (saveRes && saveRes.data && saveRes.data.message) ? saveRes.data.message : 'Failed to save Google widget translations.', 'SAVE_FAILED', context, ui);
					context.completed++;
					updateOverallProgress(context, ui);
					await yieldToUi();
					continue;
				}

				const ok = {
					success: true,
					data: {
						pages_data: { [pid]: { title: pageData.title || '', review_url: pageData.review_url || '' } },
						failed_details: []
					}
				};
				handleTaskResult({ pageId: pid, lang: lang }, ok, context, ui);
				context.completed++;
				updateOverallProgress(context, ui);
				await yieldToUi();
			}
		}
	}

	/**
	 * Finalize counters, actions, and status visibility after processing ends.
	 *
	 * @param {Object} context Bulk processing context.
	 * @param {Object} ui Progress modal UI references.
	 * @returns {void}
	 */
	function finalizeProgressUI(context, ui) {
		if (context.elapsedInterval != null) { clearInterval(context.elapsedInterval); context.elapsedInterval = null; }
		if (!ui.$modal.length || !$.contains(document.body, ui.$modal[0])) return;
		ui.$progressBar.css('width', '100%');
		ui.$percentEl.text('100%');
		ui.$cancelBtn.addClass('tpap-is-hidden');
		ui.$finishBtn.removeClass('tpap-is-hidden').off('click').on('click', function () { location.reload(); });
		const totalFailed = Object.keys(context.failedByLang).reduce(function (sum, l) {
			return sum + (context.failedByLang[l] || []).length;
		}, 0);
		if (totalFailed > 0) {
			ui.$retryBtn.removeClass('tpap-is-hidden').off('click').on('click', function () {
				ui.$retryBtn.prop('disabled', true);
				ui.$modal.remove();
				startBulkCrawl(null, null, null, { failedByLang: context.failedByLang, provider: context.provider });
			});
		} else {
			ui.$retryBtn.addClass('tpap-is-hidden');
		}
	}

	/**
	 * Execute one task for one page/language pair.
	 *
	 * @param {Object} task Task descriptor.
	 * @param {Object} context Bulk processing context.
	 * @returns {Promise<Object>} Task result payload.
	 */
	async function runTranslationTask(task, context) {
		const pid = task.pageId;
		const lang = task.lang;
		const provider = context.provider;
		const isChromeAiProvider = context.isChromeAi;
		const isGoogleWidgetProvider = context.isGoogleWidget;
		const pageStartTime = Date.now();

		if (context.stopProcess) return createErrorResponse('Stopped', 'STOPPED');

		let loadRes;
		try {
			context.currentRequest = apiLoadStringsForPage(pid, lang);
			loadRes = await context.currentRequest;
		} catch (e) {
			return createErrorResponse(getRequestErrorMessage(e), e && e.status === 0 ? 'TIMEOUT' : 'LOAD_ERROR');
		} finally {
			context.currentRequest = null;
		}

		if (!loadRes.success) return createErrorResponse((loadRes.data && loadRes.data.message) || 'Unknown error', 'LOAD_FAILED');

		const pagesPayload = loadRes.data && loadRes.data.pages ? loadRes.data.pages : {};
		const pageData = pagesPayload && pagesPayload[pid] ? pagesPayload[pid] : null;
		if (!pageData) return createErrorResponse('Failed to load strings for this page.', 'NO_PAGE_DATA');

		const hasDict = Array.isArray(pageData.dict_strings) && pageData.dict_strings.length > 0;
		const hasGettext = Array.isArray(pageData.gettext_strings) && pageData.gettext_strings.length > 0;
		if (!hasDict && !hasGettext) {
			return {
				success: true,
				data: {
					pages_data: { [pid]: { title: pageData.title || task.pageTitle, already_translated: true, review_url: pageData.review_url || '' } },
					failed_details: []
				}
			};
		}

		const dictStrings = Array.isArray(pageData.dict_strings) ? pageData.dict_strings : [];
		const gettextStrings = Array.isArray(pageData.gettext_strings) ? pageData.gettext_strings : [];
		const charCount = dictStrings.reduce(function (s, r) { return s + (r && r.original ? String(r.original).length : 0); }, 0) +
			gettextStrings.reduce(function (s, r) { return s + (r && r.original ? String(r.original).length : 0); }, 0);

		if (isChromeAiProvider) {
			let translationResult;
			try {
				translationResult = await runChromeAiTranslationForPage(pid, lang, pageData);
			} catch (e) {
				return createErrorResponse((e && e.message) || 'Chrome AI translation failed', 'CHROME_AI_ERROR');
			}
			let saveRes;
			try {
				const elapsedSec = Math.max(1, Math.round((Date.now() - pageStartTime) / 1000));
				saveRes = await saveTranslationsForProvider({
					lang: lang,
					provider: 'chrome_ai',
					dict: translationResult.dict,
					gettext: translationResult.gettext,
					pageId: pid,
					pageData: pageData,
					charCount: charCount,
					timeTaken: elapsedSec
				});
			} catch (e) {
				return createErrorResponse(getRequestErrorMessage(e), 'SAVE_ERROR');
			}
			if (!saveRes.success) return createErrorResponse((saveRes.data && saveRes.data.message) || 'Failed to save translations.', 'SAVE_FAILED');
			return {
				success: true,
				data: {
					pages_data: { [pid]: { title: pageData.title || task.pageTitle, review_url: pageData.review_url || '' } },
					failed_details: []
				}
			};
		}
		if (isGoogleWidgetProvider) {
			let googleBundle;
			try {
				googleBundle = await runGoogleWidgetTranslationsForPageLangs(
					pid,
					pageData,
					config.default_language || '',
					[lang]
				);
			} catch (e) {
				return createErrorResponse((e && e.message) || 'Google widget translation failed', 'GOOGLE_WIDGET_ERROR');
			}

			const translated = googleBundle && googleBundle.results ? googleBundle.results[lang] : null;
			if (!translated) {
				const errMsg = (googleBundle && googleBundle.errors && googleBundle.errors[lang]) ? String(googleBundle.errors[lang]) : 'Google widget translation failed';
				return createErrorResponse(errMsg, 'GOOGLE_WIDGET_ERROR');
			}

			let googleSaveRes;
			try {
				const elapsedSec = Math.max(1, Math.round((Date.now() - pageStartTime) / 1000));
				googleSaveRes = await saveTranslationsForProvider({
					lang: lang,
					provider: 'google_widget',
					dict: translated.dict || {},
					gettext: translated.gettext || {},
					pageId: pid,
					pageData: pageData,
					charCount: charCount,
					timeTaken: elapsedSec
				});
			} catch (e) {
				return createErrorResponse(getRequestErrorMessage(e), 'SAVE_ERROR');
			}
			if (!googleSaveRes.success) return createErrorResponse((googleSaveRes.data && googleSaveRes.data.message) || 'Failed to save Google widget translations.', 'SAVE_FAILED');
			return {
				success: true,
				data: {
					pages_data: { [pid]: { title: pageData.title || task.pageTitle, review_url: pageData.review_url || '' } },
					failed_details: []
				}
			};
		}
		try {
			const elapsedSec = Math.max(1, Math.round((Date.now() - pageStartTime) / 1000));
			const saveRes = await saveTranslationsForProvider({
				lang: lang,
				provider: provider,
				dict: dictStrings,
				gettext: gettextStrings,
				pageId: pid,
				pageData: pageData,
				charCount: charCount,
				timeTaken: elapsedSec
			});
			if (!saveRes || !saveRes.success) {
				const message = (saveRes && saveRes.data && saveRes.data.message) ? saveRes.data.message : 'Failed';
				return createErrorResponse(message, 'SAVE_ERROR');
			}
		} catch (e) {
			return createErrorResponse(getRequestErrorMessage(e), 'SAVE_ERROR');
		}
		return {
			success: true,
			data: {
				pages_data: { [pid]: { title: pageData.title || task.pageTitle, review_url: pageData.review_url || '' } },
				failed_details: []
			}
		};
	}

	/**
	 * Main entry for bulk translation execution after provider/language selection.
	 *
	 * @param {Array<string>} selectedLangs Selected target languages.
	 * @param {Array<number>} pageIds Selected page IDs.
	 * @param {number} sessionStartTime Timestamp when run started.
	 * @param {Object} options Runtime options.
	 * @returns {Promise<void>}
	 */
	async function startBulkCrawl(selectedLangs, pageIds, sessionStartTime, options) {
		const context = createBulkContext(selectedLangs, pageIds, sessionStartTime, options);
		if (!context || !context.tasks.length) return;
		const ui = createProgressModal(context);
		await processTasksSequentially(context, ui);
		finalizeProgressUI(context, ui);
	}

	return {
		tpapInit: tpapInit,
		init: tpapInit
	};
})(window, jQuery);

jQuery(function ($) {
	var bulk = window.tpBulkTranslator;
	if (bulk && typeof bulk.init === 'function') {
		bulk.init();
	}
});
