/* global tpap_ald_data */
(function () {
  'use strict';

  const cfg = (typeof window !== 'undefined' && window.tpap_ald_data) ? window.tpap_ald_data : null;
  if (!cfg) return;

  const COOKIE_NAME = cfg.cookie_name || 'trp_language';
  const COOKIE_PATH = cfg.cookie_path || '/';
  const COOKIE_AGE_DAYS = Number(cfg.cookie_age_days || 30);

  const publishLanguages = Array.isArray(cfg.publish_languages) ? cfg.publish_languages : [];
  const languageUrls = cfg.language_urls || {};
  const languageNames = cfg.language_names || {};

  const addDays = (date, days) => {
    const d = new Date(date.getTime());
    d.setDate(d.getDate() + days);
    return d;
  };

  const setCookie = (name, value, days, path) => {
    const expires = addDays(new Date(), days).toUTCString();
    document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}; expires=${expires}; path=${path}; SameSite=Lax`;
  };

  const getCookie = (name) => {
    const nameEq = `${encodeURIComponent(name)}=`;
    const parts = document.cookie.split(';');
    for (let i = 0; i < parts.length; i++) {
      let c = parts[i];
      while (c.charAt(0) === ' ') c = c.substring(1);
      if (c.indexOf(nameEq) === 0) return decodeURIComponent(c.substring(nameEq.length));
    }
    return '';
  };

  const inArray = (needle, haystack) => haystack.indexOf(needle) !== -1;

  const escapeHtml = (str) => {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  };

  const normalizeLang = (lang) => {
    if (!lang || typeof lang !== 'string') return '';
    return lang.replace(/-/g, '_');
  };

  const getCurrentDomLanguage = () => {
    // TranslatePress often injects a `#tp-language` element.
    const tpLangEl = document.getElementById('tp-language');
    let domLang = '';
    if (tpLangEl) {
      domLang = tpLangEl.getAttribute('data-tp-language') || tpLangEl.getAttribute('lang') || '';
    }
    if (!domLang) {
      domLang = document.documentElement.getAttribute('lang') || '';
    }
    domLang = normalizeLang(domLang);

    if (!inArray(domLang, publishLanguages)) {
      domLang = cfg.default_language || '';
    }
    return domLang;
  };

  const buildFloatingUI = (suggestedLang, currentLang) => {
    const container = document.createElement('div');
    container.id = 'tpap-ald-float';
    container.className = cfg.is_rtl ? 'tpap-ald-rtl' : '';

    const header = document.createElement('div');
    header.className = 'tpap-ald-header';

    const title = document.createElement('div');
    title.className = 'tpap-ald-title';
    title.textContent = 'Language detected';

    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'tpap-ald-close';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.innerHTML = '&times;';

    header.appendChild(title);
    header.appendChild(closeBtn);

    const body = document.createElement('div');
    body.className = 'tpap-ald-body';

    const suggestedName = languageNames[suggestedLang] || suggestedLang;
    const msg = document.createElement('div');
    msg.className = 'tpap-ald-msg';
    msg.innerHTML = 'We noticed you might prefer <span class="tpap-ald-lang-name">' + escapeHtml(suggestedName) + '.</span> Would you like to switch to your local language?';

    const select = document.createElement('select');
    select.className = 'tpap-ald-select';
    select.setAttribute('aria-label', 'Select language');

    publishLanguages.forEach((code) => {
      const opt = document.createElement('option');
      opt.value = code;
      opt.textContent = languageNames[code] || code;
      if (code === suggestedLang) opt.selected = true;
      select.appendChild(opt);
    });

    const actions = document.createElement('div');
    actions.className = 'tpap-ald-actions';

    const switchBtn = document.createElement('button');
    switchBtn.type = 'button';
    switchBtn.className = 'tpap-ald-switch';
    switchBtn.innerHTML = 'Switch';

    const dismissBtn = document.createElement('button');
    dismissBtn.type = 'button';
    dismissBtn.className = 'tpap-ald-dismiss';
    dismissBtn.innerHTML = 'Dismiss';

    actions.appendChild(switchBtn);
    actions.appendChild(dismissBtn);

    body.appendChild(msg);
    body.appendChild(select);
    body.appendChild(actions);

    container.appendChild(header);
    container.appendChild(body);

    const hide = () => {
      container.classList.add('tpap-ald-hidden');
      window.setTimeout(() => {
        if (container.parentNode) container.parentNode.removeChild(container);
      }, 250);
    };

    const onDismiss = (e) => {
      e.preventDefault();
      setCookie(COOKIE_NAME, currentLang, COOKIE_AGE_DAYS, COOKIE_PATH);
      hide();
    };

    closeBtn.addEventListener('click', onDismiss);
    dismissBtn.addEventListener('click', onDismiss);

    switchBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const selected = select.value;
      if (!selected || !languageUrls[selected]) return;
      setCookie(COOKIE_NAME, selected, COOKIE_AGE_DAYS, COOKIE_PATH);
      window.location.href = languageUrls[selected];
    });

    return container;
  };

  const showSuggestionIfNeeded = async () => {
    if (!publishLanguages.length) return;

    // If cookie is already set, don't show UI (user already has preference).
    const existing = getCookie(COOKIE_NAME);
    if (existing && inArray(existing, publishLanguages)) return;

    const currentLang = getCurrentDomLanguage();
    if (!currentLang) return;

    // Ask server for detected language (browser/IP). Cached pages can still call admin-ajax.php.
    const form = new URLSearchParams();
    form.set('action', 'tpap_ald_get_needed_language');
    form.set('nonce', cfg.nonce || '');

    let needed = null;
    try {
      const res = await fetch(cfg.ajax_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: form.toString(),
        credentials: 'same-origin',
      });
      const json = await res.json();
      if (json && json.success && json.data) {
        needed = json.data.needed_language || null;
      }
    } catch (_) {
      return;
    }

    if (!needed || !inArray(needed, publishLanguages)) return;
    if (needed === currentLang) return;

    const ui = buildFloatingUI(needed, currentLang);
    document.body.appendChild(ui);
    window.setTimeout(() => ui.classList.add('tpap-ald-active'), 10);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', showSuggestionIfNeeded);
  } else {
    showSuggestionIfNeeded();
  }
})();

