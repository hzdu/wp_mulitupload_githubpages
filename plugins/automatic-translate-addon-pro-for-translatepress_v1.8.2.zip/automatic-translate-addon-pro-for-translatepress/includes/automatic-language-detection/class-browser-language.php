<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Browser language detection (Accept-Language) for TranslatePress published languages.
 *
 * Ported from TranslatePress Automatic Language Detection add-on.
 */
class TPAP_ALD_Browser_Language {

	/**
	 * Return language code preferred by browser from the published languages.
	 * Returns null if none matches.
	 *
	 * @param array $published_languages TranslatePress settings['publish-languages'].
	 * @param array $iso_codes           ISO codes of the published languages.
	 * @return string|null
	 */
	public function get_browser_language( $published_languages, $iso_codes ) {
		if ( empty( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ) {
			return null;
		}

		$iso_codes_array = array( 'no_matches' => null ) + (array) $iso_codes;

		// Preferred ISO code among all available.
		$matched_iso_code = $this->preferred_language( array_values( $iso_codes_array ) );

		// Preferred full TP language code among those matching that ISO code.
		$matched_language_code = $this->preferred_language_code( (array) $published_languages, (array) $iso_codes, $matched_iso_code );

		return $matched_language_code;
	}

	/**
	 * @param array       $language_code_array Published language codes.
	 * @param array       $iso_codes           Map: language_code => iso_code.
	 * @param string|null $matched_iso_code    ISO code matched by browser.
	 * @return array Map: language_code => lowercase-dashed-code.
	 */
	public function matching_language_codes( $language_code_array, $iso_codes, $matched_iso_code ) {
		$return = array( 'no_matches' => null );
		foreach ( (array) $language_code_array as $language_code ) {
			if ( isset( $iso_codes[ $language_code ] ) && $iso_codes[ $language_code ] === $matched_iso_code ) {
				$return[ $language_code ] = $this->convert_lowercase_dashed( $language_code );
			}
		}
		return $return;
	}

	/**
	 * Return TP language code corresponding to matched ISO code.
	 *
	 * @param array       $published_languages
	 * @param array       $iso_codes
	 * @param string|null $matched_iso_code
	 * @return string|null
	 */
	public function preferred_language_code( $published_languages, $iso_codes, $matched_iso_code ) {
		$language_array = $this->matching_language_codes( $published_languages, $iso_codes, $matched_iso_code );

		if ( count( $language_array ) < 2 ) {
			// Always contains one null value at 'no_matches'.
			return null;
		}

		if ( count( $language_array ) === 2 ) {
			$language_array = array_slice( $language_array, 1, 1 );
			return key( $language_array );
		}

		$preferred_language   = $this->preferred_language( array_values( $language_array ) );
		$matched_language_code = array_search( $preferred_language, $language_array, true );

		if ( ( $matched_language_code === 'no_matches' ) && ( $matched_iso_code !== null ) ) {
			$language_array = array_slice( $language_array, 1, 1 );
			return key( $language_array );
		}

		if ( $matched_language_code === 'no_matches' ) {
			$matched_language_code = null;
		}

		return $matched_language_code;
	}

	/**
	 * Determine which language out of an available set the browser prefers most.
	 *
	 * @param array  $available_languages Array with language-tag-strings (must be lowercase) that are available.
	 * @param string $http_accept_language HTTP_ACCEPT_LANGUAGE string; "auto" reads from header.
	 * @return string
	 */
	public function preferred_language( $available_languages, $http_accept_language = 'auto' ) {
		if ( $http_accept_language === 'auto' ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Accept-Language header; escaped via htmlspecialchars.
			$http_accept_language = isset( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ? htmlspecialchars( (string) $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) : '';
		}

		preg_match_all(
			"/([[:alpha:]]{1,8})(-([[:alpha:]|-]{1,8}))?(\s*;\s*q\s*=\s*(1\.0{0,3}|0\.\d{0,3}))?\s*(,|$)/i",
			$http_accept_language,
			$hits,
			PREG_SET_ORDER
		);

		$bestlang = $available_languages[0];
		$bestqval = 0;

		foreach ( $hits as $arr ) {
			$langprefix = strtolower( $arr[1] );
			if ( ! empty( $arr[3] ) ) {
				$langrange = strtolower( $arr[3] );
				$language  = $langprefix . '-' . $langrange;
			} else {
				$language = $langprefix;
			}

			$qvalue = 1.0;
			if ( ! empty( $arr[5] ) ) {
				$qvalue = (float) $arr[5];
			}

			if ( in_array( $language, $available_languages, true ) && ( $qvalue > $bestqval ) ) {
				$bestlang = $language;
				$bestqval = $qvalue;
			} elseif ( in_array( $langprefix, $available_languages, true ) && ( ( $qvalue * 0.9 ) > $bestqval ) ) {
				$bestlang = $langprefix;
				$bestqval = $qvalue * 0.9;
			}
		}

		return $bestlang;
	}

	/**
	 * Return language code in lowercase dashed format.
	 *
	 * @param string $code
	 * @return string
	 */
	public function convert_lowercase_dashed( $code ) {
		$code = str_replace( '_', '-', (string) $code );
		return strtolower( $code );
	}
}

