<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use TP_MaxMind\Db\Reader as TPAP_MaxMind_Reader;

/**
 * IP-based language detection via Cloudflare header and/or GeoLite2 country DB.
 *
 * Ported from TranslatePress Automatic Language Detection add-on.
 */
class TPAP_ALD_IP_Language {

	/**
	 * @param array $published_languages TranslatePress settings['publish-languages'].
	 * @param array $iso_codes           ISO codes of the published languages.
	 * @return string|null
	 */
	public function get_ip_language( $published_languages, $iso_codes ) {
		$ip_country = $this->get_country_iso_code();

		if ( empty( $ip_country ) ) {
			return null;
		}

		foreach ( (array) $published_languages as $language_code ) {
			$language_code_country = $this->get_country_for_language_code( $language_code );
			if ( ! empty( $language_code_country ) && strtolower( $language_code_country ) === strtolower( $ip_country ) ) {
				return $language_code;
			}
		}

		return null;
	}

	/**
	 * Return country ISO code encoded in given TP language code.
	 *
	 * @param string $language_code
	 * @return string
	 */
	public function get_country_for_language_code( $language_code ) {
		$country_code = '';

		if ( ( $pos = strpos( (string) $language_code, '_' ) ) !== false ) {
			$country_code = substr( (string) $language_code, $pos + 1 );
			$country_code = strpos( $country_code, '_' ) ? substr( $country_code, 0, strpos( $country_code, '_' ) ) : $country_code;
		}

		if ( $country_code === '' ) {
			$country_codes_array = $this->get_language_country_assoc_array();
			if ( isset( $country_codes_array[ $language_code ] ) ) {
				$country_code = $country_codes_array[ $language_code ];
			}
		}

		return $country_code;
	}

	/**
	 * Map of WP language codes that do not contain country codes.
	 *
	 * @return array<string,string>
	 */
	public function get_language_country_assoc_array() {
		return array(
			'ary' => 'MA',
			'az'  => 'AZ',
			'azb' => 'AZ',
			'bel' => 'BY',
			'ca'  => 'ES',
			'cy'  => 'GB',
			'el'  => 'GR',
			'et'  => 'EE',
			'eu'  => 'ES',
			'fi'  => 'FI',
			'gd'  => 'GB',
			'hr'  => 'HR',
			'hy'  => 'AM',
			'ja'  => 'JP',
			'kk'  => 'KZ',
			'lo'  => 'LA',
			'lv'  => 'LV',
			'mn'  => 'MN',
			'sq'  => 'AL',
			'th'  => 'TH',
			'uk'  => 'UA',
			'vi'  => 'VN',
		);
	}

	/**
	 * Return current IP.
	 *
	 * @return string
	 */
	public function get_current_ip() {
		if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- IP from server, validated via filter_var below.
			$ip = (string) $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- IP from server, validated via filter_var below.
			$ip = (string) $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- IP from server, validated via filter_var below.
			$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		}

		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$ip = '127.0.0.1';
		}

		return $ip;
	}

	/**
	 * Return iso code of country determined from IP.
	 *
	 * Uses Cloudflare country header when present; otherwise attempts GeoLite2 lookup.
	 *
	 * @return string|null
	 */
	public function get_country_iso_code() {
		// Cloudflare short-circuit.
		if ( isset( $_SERVER['HTTP_CF_IPCOUNTRY'] ) && ! empty( $_SERVER['HTTP_CF_IPCOUNTRY'] ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.strip_tags_strip_tags, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cloudflare country code, non-HTML output.
			return strtolower( strip_tags( (string) $_SERVER['HTTP_CF_IPCOUNTRY'] ) );
		}

		$db_path = $this->get_geolite_db_path();
		if ( empty( $db_path ) || ! is_readable( $db_path ) ) {
			return null;
		}

		$this->require_maxmind_reader_lib();

		try {
			$reader = new TPAP_MaxMind_Reader( $db_path );
			$ip     = $this->get_current_ip();
			$record = $reader->get( $ip );
		} catch ( \Throwable $e ) {
			return null;
		}

		if ( ! empty( $record ) && ! empty( $record['country'] ) && ! empty( $record['country']['iso_code'] ) ) {
			return (string) $record['country']['iso_code'];
		}

		return null;
	}

	/**
	 * Prefer our own bundled DB path; fallback to the extracted TranslatePress ALD DB if present.
	 *
	 * @return string|null
	 */
	private function get_geolite_db_path() {
		$primary = trailingslashit( TPAP_PATH ) . 'includes/automatic-language-detection/lib/GeoLite2-Country/GeoLite2-Country.mmdb';
		if ( is_readable( $primary ) ) {
			return $primary;
		}

		$fallback = trailingslashit( TPAP_PATH ) . 'translatepress/translatepress/automatic-language-detection/assets/lib/GeoLite2-Country/GeoLite2-Country.mmdb';
		if ( is_readable( $fallback ) ) {
			return $fallback;
		}

		return null;
	}

	/**
	 * Load the minimal MaxMind reader implementation shipped with this plugin.
	 *
	 * @return void
	 */
	private function require_maxmind_reader_lib() {
		if ( class_exists( 'TP_MaxMind\Db\Reader' ) ) {
			return;
		}

		$base = trailingslashit( TPAP_PATH ) . 'includes/automatic-language-detection/lib/TP_MaxMind/Db/';
		require_once $base . 'Reader.php';
		require_once $base . 'Reader/Decoder.php';
		require_once $base . 'Reader/InvalidDatabaseException.php';
		require_once $base . 'Reader/Metadata.php';
		require_once $base . 'Reader/Util.php';
	}
}

