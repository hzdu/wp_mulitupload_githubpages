<?php

namespace TP_MaxMind\Db\Reader;

/**
 * Ported from TranslatePress Automatic Language Detection add-on.
 */
class Util {
	public static function read( $stream, $offset, $numberOfBytes ) {
		if ( $numberOfBytes === 0 ) {
			return '';
		}
		if ( fseek( $stream, $offset ) === 0 ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- MaxMind binary stream read; WP_Filesystem not applicable.
			$value = fread( $stream, $numberOfBytes );
			if ( ftell( $stream ) - $offset === $numberOfBytes ) {
				return $value;
			}
		}
		throw new InvalidDatabaseException( 'The MaxMind DB file contains bad data' );
	}
}

