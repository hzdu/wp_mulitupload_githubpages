<?php

namespace TP_MaxMind\Db\Reader;

/**
 * This class should be thrown when unexpected data is found in the database.
 *
 * Ported from TranslatePress Automatic Language Detection add-on.
 */
class InvalidDatabaseException extends \Exception {
}

