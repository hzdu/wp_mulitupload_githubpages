<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine the needed language based on browser and/or IP.
 *
 * Ported from TranslatePress Automatic Language Detection add-on.
 */
class TPAP_ALD_Determine_Language {

	public function __construct() {
		require_once __DIR__ . '/class-browser-language.php';
		require_once __DIR__ . '/class-ip-language.php';
	}

	/**
	 * Return preferred language code based on parameters.
	 *
	 * @param array  $published_languages TranslatePress settings['publish-languages'].
	 * @param array  $iso_codes           ISO codes of the published languages.
	 * @param string $detection_method    One of: browser-ip, ip-browser, browser, ip.
	 * @return string|null
	 */
	public function get_needed_language( $published_languages, $iso_codes, $detection_method ) {
		$needed_language = null;

		$trp_browser_language  = new TPAP_ALD_Browser_Language();
		$browser_language_code = $trp_browser_language->get_browser_language( $published_languages, $iso_codes );

		$trp_ip_language  = new TPAP_ALD_IP_Language();
		$ip_language_code = $trp_ip_language->get_ip_language( $published_languages, $iso_codes );

		switch ( $detection_method ) {
			case 'browser-ip':
				if ( $browser_language_code ) {
					$needed_language = $browser_language_code;
				} elseif ( $ip_language_code ) {
					$needed_language = $ip_language_code;
				}
				break;
			case 'ip-browser':
				if ( $ip_language_code ) {
					$needed_language = $ip_language_code;
				} elseif ( $browser_language_code ) {
					$needed_language = $browser_language_code;
				}
				break;
			case 'browser':
				if ( $browser_language_code ) {
					$needed_language = $browser_language_code;
				}
				break;
			case 'ip':
				if ( $ip_language_code ) {
					$needed_language = $ip_language_code;
				}
				break;
		}

		return $needed_language;
	}
}

