<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Get Data From Database
 * Hooked to wp_ajax_get_strings.
 */
function tpap_getstrings() {
	// Check user capabilities first - restrict to administrators only
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( esc_html__( 'Insufficient permissions to access translation strings. Administrator access required.', 'automatic-translate-addon-pro-for-translatepress' ) );
		wp_die( '0', 403 );
	}
	
	// Ready for the magic to protect our code
	check_ajax_referer( 'auto-translate-press-pro-nonces' );
	$reg_exUrl = '/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/';
	$pattern   = '/\[[^]]+\]/i';
	global $wpdb;
	$result           = array();
	$data             = array();
	$default_code     = isset( $_POST['data'] ) ? sanitize_text_field( wp_unslash( $_POST['data'] ) ) : '';
	$default_language = isset( $_POST['default_lang'] ) ? sanitize_text_field( wp_unslash( $_POST['default_lang'] ) ) : '';
	$current_page_id  = isset( $_POST['dictionary_id'] ) ? sanitize_text_field( wp_unslash( $_POST['dictionary_id'] ) ) : '';
	$gettxt_id        = isset( $_POST['gettxt_id'] ) ? sanitize_text_field( wp_unslash( $_POST['gettxt_id'] ) ) : '';
	
	// Validate language codes - only allow alphanumeric characters and underscores/dashes
	if ( ! preg_match( '/^[a-zA-Z0-9_-]+$/', $default_code ) || ! preg_match( '/^[a-zA-Z0-9_-]+$/', $default_language ) ) {
		wp_send_json_error( esc_html__( 'Invalid language code format.', 'automatic-translate-addon-pro-for-translatepress' ) );
		wp_die();
	}
	
	// Language code validation removed per user request
	
	// Validate and sanitize IDs arrays with limits to prevent enumeration attacks
	$strings_ID = array_filter( array_map( 'absint', explode( ',', $current_page_id ) ) );
	$get_txt_ids = array_filter( array_map( 'absint', explode( ',', $gettxt_id ) ) );
	
	// Ensure we have valid IDs to work with
	if ( empty( $strings_ID ) && empty( $get_txt_ids ) ) {
		wp_send_json_error( esc_html__( 'No valid IDs provided.', 'automatic-translate-addon-pro-for-translatepress' ) );
		wp_die();
	}
	
	$def_lang         = strtolower( $default_language );
	$default_code_lower = strtolower( $default_code );
	
	// Construct table names with validated input
	$table2           = $wpdb->get_blog_prefix() . 'trp_gettext_' . $default_code_lower;
	$table1           = $wpdb->get_blog_prefix() . 'trp_dictionary_' . $def_lang . '_' . $default_code_lower;
	
	// Additional table name validation for SQL injection prevention
	if ( ! tpap_validate_table_name( $table1 ) || ! tpap_validate_table_name( $table2 ) ) {
		wp_send_json_error( esc_html__( 'Invalid table name format detected.', 'automatic-translate-addon-pro-for-translatepress' ) );
		wp_die();
	}
	
	// Validate table names exist before proceeding - using esc_sql for additional protection
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checking TranslatePress custom tables, caching not appropriate for dynamic table checks
	$table1_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", esc_sql( $table1 ) ) );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checking TranslatePress custom tables, caching not appropriate for dynamic table checks
	$table2_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", esc_sql( $table2 ) ) );
	
	$results_gettxt = array();
	$results = array();
	
	// Process table1 query only if table exists and we have valid IDs
	if ( $table1_exists && ! empty( $strings_ID ) ) {
		// IDOR protection: Add additional constraints to prevent unauthorized access
		$current_blog_id = get_current_blog_id();
		$placeholders = implode( ',', array_fill( 0, count( $strings_ID ), '%d' ) );
		
		// Additional security: Re-validate and escape table name before query construction
		if ( ! tpap_validate_table_name( $table1 ) ) {
			wp_send_json_error( esc_html__( 'Invalid table name detected during query construction.', 'automatic-translate-addon-pro-for-translatepress' ) );
			wp_die();
		}
		
		// Use escaped table name in query construction
		$safe_table1 = esc_sql( $table1 );
		$query = "SELECT id,original_id,original FROM `{$safe_table1}` WHERE id IN ({$placeholders}) AND status!='2'";
		
		// Apply additional filters for authorization if available
		$query = apply_filters( 'tpap_filter_translation_query', $query, $table1, 'dictionary' );
		
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name validated via tpap_validate_table_name() and escaped with esc_sql(), query prepared with placeholders, querying TranslatePress custom tables
		$results_gettxt = $wpdb->get_results( $wpdb->prepare( $query, ...$strings_ID ) );
		
		// Additional validation: Ensure returned results are authorized for current user
		$results_gettxt = tpap_filter_authorized_translation_strings( $results_gettxt, 'dictionary' );
	}
	
	// Process table2 query only if table exists and we have valid IDs  
	if ( $table2_exists && ! empty( $get_txt_ids ) ) {
		$current_blog_id = get_current_blog_id();
		$placeholders = implode( ',', array_fill( 0, count( $get_txt_ids ), '%d' ) );
		
		// Additional security: Re-validate and escape table name before query construction
		if ( ! tpap_validate_table_name( $table2 ) ) {
			wp_send_json_error( esc_html__( 'Invalid table name detected during query construction.', 'automatic-translate-addon-pro-for-translatepress' ) );
			wp_die();
		}
		
		// Use escaped table name in query construction
		$safe_table2 = esc_sql( $table2 );
		$query = "SELECT id,original FROM `{$safe_table2}` WHERE id IN ({$placeholders}) AND status!='2'";
		
		// Apply additional filters for authorization if available
		$query = apply_filters( 'tpap_filter_translation_query', $query, $table2, 'gettext' );
		
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name validated via tpap_validate_table_name() and escaped with esc_sql(), query prepared with placeholders, querying TranslatePress custom tables
		$results = $wpdb->get_results( $wpdb->prepare( $query, ...$get_txt_ids ) );
		
		// Additional validation: Ensure returned results are authorized for current user
		$results = tpap_filter_authorized_translation_strings( $results, 'gettext' );
	}
	$final_res        = array_merge( $results_gettxt, $results );
	if ( is_array( $final_res ) && count( $final_res ) > 0 ) {
		foreach ( $final_res as $row ) {
			$original_id = isset( $row->original_id ) ? absint( $row->original_id ) : '';
			$original    = isset( $row->original ) ? $row->original : '';
			$string      = htmlspecialchars_decode( $original );
			if ( $string != wp_strip_all_tags( $string ) ) {
				continue;
			} elseif ( preg_match( $reg_exUrl, $string ) ) {
				continue;
			} elseif ( preg_match( $pattern, $string ) ) {
				continue;
			}

			if ( $original_id == '' ) {
				$group = 'Gettext';
			} else {
				$group = 'String';
			}
			$data['strings']      = $string;
			$data['database_ids'] = isset( $row->id ) ? absint( $row->id ) : '';
			$data['data_group']   = $group;
			$result[]             = $data;
		}
	}
	wp_send_json( $result );
}

/**
 * Recursively sanitize array data
 */
function tpap_sanitize_array_recursive( $array ) {
	if ( ! is_array( $array ) ) {
		return sanitize_text_field( $array );
	}
	
	$sanitized = array();
	foreach ( $array as $key => $value ) {
		$clean_key = sanitize_key( $key );
		if ( is_array( $value ) ) {
			$sanitized[ $clean_key ] = tpap_sanitize_array_recursive( $value );
		} else {
			$sanitized[ $clean_key ] = sanitize_text_field( $value );
		}
	}
	
	return $sanitized;
}

/**
 *  save translation from ajax post
 * Hooked to wp_ajax_save_translations.
 */
function tpap_save_translations() {
	// Check user capabilities first - restrict to administrators only
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( esc_html__( 'Insufficient permissions to save translations. Administrator access required.', 'automatic-translate-addon-pro-for-translatepress' ) );
		wp_die( '0', 403 );
	}
	
	 // Ready for the magic to protect our code
	check_ajax_referer( 'auto-translate-press-pro-nonces' );
	global $wpdb;
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Data will be sanitized after json_decode via tpap_sanitize_array_recursive()
	$raw_data = isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : '';
	$decoded_data = json_decode( $raw_data, true );
	$strings = tpap_sanitize_array_recursive( $decoded_data );
	if ( is_array( $strings ) && count( $strings ) > 0 ) {
		$table1_query = array();
		$table2_query = array();
		$table1       = null;
		$table2       = null;
		$validated_language_codes = array();
		
		foreach ( $strings as $languages => $string ) {
			$types            = isset( $string['data_group'] ) ? sanitize_text_field( $string['data_group'] ) : '';
			$default_code     = isset( $string['language_code'] ) ? sanitize_text_field( $string['language_code'] ) : '';
			$default_language = isset( $string['default_lang'] ) ? sanitize_text_field( $string['default_lang'] ) : '';
			
			// Validate language codes - only allow alphanumeric characters and underscores/dashes
			if ( ! preg_match( '/^[a-zA-Z0-9_-]+$/', $default_code ) || ! preg_match( '/^[a-zA-Z0-9_-]+$/', $default_language ) ) {
				wp_send_json_error( esc_html__( 'Invalid language code format.', 'automatic-translate-addon-pro-for-translatepress' ) );
				wp_die();
			}
			
			$def_lang = strtolower( $default_language );
			$default_code_lower = strtolower( $default_code );
			$lang_pair = $def_lang . '_' . $default_code_lower;
			
			// Only construct tables once per language pair
			if ( ! isset( $validated_language_codes[ $lang_pair ] ) ) {
				$table2 = $wpdb->get_blog_prefix() . 'trp_gettext_' . $default_code_lower;
				$table1 = $wpdb->get_blog_prefix() . 'trp_dictionary_' . $def_lang . '_' . $default_code_lower;
				
				// Additional table name validation for SQL injection prevention
				if ( ! tpap_validate_table_name( $table1 ) || ! tpap_validate_table_name( $table2 ) ) {
					wp_send_json_error( esc_html__( 'Invalid table name format detected.', 'automatic-translate-addon-pro-for-translatepress' ) );
					wp_die();
				}
				
				// Validate table names exist before proceeding - using esc_sql for additional protection
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checking TranslatePress custom tables, caching not appropriate for dynamic table checks
				$table1_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", esc_sql( $table1 ) ) );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checking TranslatePress custom tables, caching not appropriate for dynamic table checks
				$table2_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", esc_sql( $table2 ) ) );
				
				if ( ! $table1_exists || ! $table2_exists ) {
					wp_send_json_error( esc_html__( 'Required translation tables do not exist.', 'automatic-translate-addon-pro-for-translatepress' ) );
					wp_die();
				}
				
				$validated_language_codes[ $lang_pair ] = array(
					'table1' => $table1,
					'table2' => $table2
				);
			} else {
				$table1 = $validated_language_codes[ $lang_pair ]['table1'];
				$table2 = $validated_language_codes[ $lang_pair ]['table2'];
			}
			
			if ( $types == 'String' ) {
				$table1_query[] = $string;
			} else {
				$table2_query[] = $string;
			}
		}
		
		if ( $table1 != null && $table2 != null ) {
			if ( ! empty( $table1_query ) ) {
				tpap_insert_rows( $table1, true, 'id', $table1_query );
			}
			if ( ! empty( $table2_query ) ) {
				tpap_insert_rows( $table2, true, 'id', $table2_query );
			}
		}
		wp_die();
	}
}

/**
 *  A method for inserting multiple rows into the specified table
 *  Updated to include the ability to Update existing rows by primary key
 */
function tpap_insert_rows( $wp_table_name, $update = false, $primary_key = 'id', $row_arrays = array() ) {
	global $wpdb;
	
	// Enhanced table name validation for SQL injection prevention
	if ( ! tpap_validate_table_name( $wp_table_name ) ) {
		return false;
	}
	
	// Verify table exists before attempting insert - using esc_sql for additional protection
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Checking TranslatePress custom tables, caching not appropriate for dynamic table checks
	$table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", esc_sql( $wp_table_name ) ) );
	if ( ! $table_exists ) {
		return false;
	}
	
	// Validate primary key name
	$primary_key = preg_replace( '/[^a-zA-Z0-9_]/', '', $primary_key );
	if ( empty( $primary_key ) ) {
		$primary_key = 'id';
	}
	
	// Setup arrays for Actual Values, and Placeholders
	$values        = array();
	$place_holders = array();
	$query         = '';
	$query_columns = '';
	
	// Use escaped table name for query construction
	$safe_table_name = esc_sql( $wp_table_name );
	$query        .= "INSERT INTO `{$safe_table_name}` (";
	foreach ( $row_arrays as $count => $row_array ) {
		foreach ( $row_array as $key => $value ) {
			if ( in_array( $key, array( 'data_group', 'original', 'language_code', 'database_id', 'default_lang' ) ) ) {
				continue;
			}
			
			// Validate column name - only allow alphanumeric characters and underscores
			$key = preg_replace( '/[^a-zA-Z0-9_]/', '', $key );
			if ( empty( $key ) ) {
				continue;
			}
			
			if ( $count == 0 ) {
				if ( $query_columns ) {
					$query_columns .= ', `' . $key . '`';
				} else {
					$query_columns .= '`' . $key . '`';
				}
			}
			$values[] = $value;
			$symbol   = '%s';
			if ( is_numeric( $value ) ) {
				$symbol = '%d';
			}
			if ( isset( $place_holders[ $count ] ) ) {
				$place_holders[ $count ] .= ", '$symbol'";
			} else {
				$place_holders[ $count ] = "( '$symbol'";
			}
		}
		// mind closing the GAP
		$place_holders[ $count ] .= ')';
	}
	$query .= " $query_columns ) VALUES ";
	$query .= implode( ', ', $place_holders );
	if ( $update ) {
		$update = " ON DUPLICATE KEY UPDATE `$primary_key`=VALUES( `$primary_key` ),";
		$cnt    = 0;
		foreach ( $row_arrays[0] as $key => $value ) {
			if ( in_array( $key, array( 'data_group', 'original', 'language_code', 'database_id', 'default_lang' ) ) ) {
				continue;
			}
			
			// Validate column name - only allow alphanumeric characters and underscores
			$key = preg_replace( '/[^a-zA-Z0-9_]/', '', $key );
			if ( empty( $key ) ) {
				continue;
			}
			
			if ( $cnt == 0 ) {
				$update .= "`$key`=VALUES(`$key`)";
				$cnt     = 1;
			} else {
				$update .= ", `$key`=VALUES(`$key`)";
			}
		}
		$query .= $update;
	}
	// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name and column names validated and sanitized, values prepared via $wpdb->prepare()
	$sql = $wpdb->prepare( $query, $values );
	// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- SQL is prepared via $wpdb->prepare() above, querying TranslatePress custom tables, column names validated and sanitized via preg_replace
	if ( $wpdb->query( $sql ) ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Validate table name format to prevent SQL injection
 * 
 * @param string $table_name The table name to validate
 * @return bool True if valid, false otherwise
 */
function tpap_validate_table_name( $table_name ) {
	global $wpdb;
	
	// Get WordPress table prefix for validation
	$blog_prefix = $wpdb->get_blog_prefix();
	
	// Table name must start with WordPress prefix
	if ( strpos( $table_name, $blog_prefix ) !== 0 ) {
		return false;
	}
	
	// Remove the prefix for pattern validation
	$suffix = substr( $table_name, strlen( $blog_prefix ) );
	
	// Validate suffix follows TranslatePress patterns
	$valid_patterns = array(
		'/^trp_gettext_[a-z0-9_-]+$/',           // trp_gettext_en, trp_gettext_es_es
		'/^trp_dictionary_[a-z0-9_-]+_[a-z0-9_-]+$/' // trp_dictionary_en_es, trp_dictionary_fr_de
	);
	
	foreach ( $valid_patterns as $pattern ) {
		if ( preg_match( $pattern, $suffix ) ) {
			return true;
		}
	}
	
	return false;
}



/**
 * Filter authorized translation strings to prevent unauthorized access
 * 
 * @param array $results Database results
 * @param string $type Type of translation (dictionary or gettext)
 * @return array Filtered results
 */
function tpap_filter_authorized_translation_strings( $results, $type = 'dictionary' ) {
	// Apply additional authorization filters if needed
	$filtered_results = apply_filters( 'tpap_filter_translation_results', $results, $type );
	
	// Additional validation can be added here based on user permissions, site settings, etc.
	
	return is_array( $filtered_results ) ? $filtered_results : array();
}

/**
 * AJAX handler: translate strings via AI provider (translate only, no save).
 * Used by single-page translation for OpenAI, Gemini, Anthropic.
 * Hooked to wp_ajax_tpap_ai_translate_single.
 */
function tpap_ai_translate_single() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Insufficient permissions.', 'automatic-translate-addon-pro-for-translatepress' ) ) );
	}

	check_ajax_referer( 'auto-translate-press-pro-nonces' );

	if ( function_exists( 'set_time_limit' ) ) {
		set_time_limit( 300 ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- extend execution time for AI translation.
	}

	$provider_id  = isset( $_POST['provider'] ) ? sanitize_text_field( wp_unslash( $_POST['provider'] ) ) : '';
	$source_lang  = isset( $_POST['source_lang'] ) ? sanitize_text_field( wp_unslash( $_POST['source_lang'] ) ) : '';
	$target_lang  = isset( $_POST['target_lang'] ) ? sanitize_text_field( wp_unslash( $_POST['target_lang'] ) ) : '';
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON decoded and sanitized below.
	$raw_strings  = isset( $_POST['strings'] ) ? wp_unslash( $_POST['strings'] ) : '';

	if ( empty( $provider_id ) || empty( $source_lang ) || empty( $target_lang ) || empty( $raw_strings ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Missing required parameters.', 'automatic-translate-addon-pro-for-translatepress' ) ) );
	}

	$allowed_providers = array( 'openai', 'google', 'anthropic' );
	if ( ! in_array( $provider_id, $allowed_providers, true ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Invalid provider.', 'automatic-translate-addon-pro-for-translatepress' ) ) );
	}

	$strings = json_decode( $raw_strings, true );
	if ( ! is_array( $strings ) || empty( $strings ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'No strings to translate.', 'automatic-translate-addon-pro-for-translatepress' ) ) );
	}

	$items = array();
	foreach ( $strings as $item ) {
		if ( ! is_array( $item ) || ! isset( $item['id'], $item['original'] ) ) {
			continue;
		}
		$id = absint( $item['id'] );
		if ( $id > 0 ) {
			// Match bulk behaviour: keep original text (HTML allowed), sanitize only IDs separately.
			$items[ $id ] = (string) $item['original'];
		}
	}

	if ( empty( $items ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'No valid strings found.', 'automatic-translate-addon-pro-for-translatepress' ) ) );
	}

	$chunk_size       = (int) apply_filters( 'tpap_ai_single_chunk_size', 50 );
	$chunks           = array_chunk( $items, $chunk_size, true );
	$all_translations = array();
	$errors           = array();
	$rate_limit_hit   = false;

	$selected_models = get_option( 'tpap_ai_models', array() );
	$model_id        = '';
	if ( is_array( $selected_models ) ) {
		$pkey = sanitize_key( $provider_id );
		if ( isset( $selected_models[ $pkey ] ) && is_string( $selected_models[ $pkey ] ) && '' !== $selected_models[ $pkey ] ) {
			$model_id = $selected_models[ $pkey ];
		}
	}

	foreach ( $chunks as $chunk ) {
		if ( $rate_limit_hit ) {
			break;
		}

		$strings_json = wp_json_encode( $chunk, JSON_UNESCAPED_UNICODE );
		$prompt_text  = sprintf(
			'Instruction 1: Translate visible text content semantically from %1$s to %2$s. Provide a proper meaning-based translation.
			Instruction 2: Do not translate or modify any content inside square brackets []. These are shortcodes or dynamic placeholders and must remain exactly as they are.
			Instruction 3: Preserve all HTML tags and their attributes such as class, id, data-*, etc. Do not alter any part of the HTML structure.
			Instruction 4: Return the translation in the format of a JSON object with the keys being the provided IDs, and the values being the translated strings.
			Instruction 5: Do not escape double quotes with backslashes. Output must be valid JSON without extra slashes.
			Instruction 6: Ensure the JSON is well-formed and complete.
			Instruction 7: Decode any &lt; and &gt; HTML entities back to < and > symbols in the output & preserve and maintain whitespace.
			Instruction 8: Return the output as a valid JSON object only. Do not wrap the output in a string or markdown code block (no ```json). Output must start with { and end with }.
			Strings are :- %3$s',
			$source_lang,
			$target_lang,
			$strings_json
		);

		try {
			$is_anthropic = str_contains( strtolower( $provider_id ), 'anthropic' );
			if ( function_exists( 'wp_ai_client_prompt' ) ) {
				$ai_prompt = $is_anthropic
					? wp_ai_client_prompt( $prompt_text )
					: wp_ai_client_prompt( $prompt_text )->as_json_response();
			} else {
				$ai_prompt = $is_anthropic
					? \WordPress\AI_Client\AI_Client::prompt( $prompt_text )
					: \WordPress\AI_Client\AI_Client::prompt_with_wp_error( $prompt_text )->as_json_response();
			}

			$ai_prompt->using_provider( $provider_id );

			if ( ! empty( $model_id ) && class_exists( '\WordPress\AiClient\AiClient' ) ) {
				$registry       = \WordPress\AiClient\AiClient::defaultRegistry();
				$model_instance = $registry->getProviderModel( $provider_id, $model_id );
				$ai_prompt->using_model( $model_instance );
			}

			$response = $ai_prompt->generate_text();

			if ( is_wp_error( $response ) ) {
				$error_msg = $response->get_error_message();
				if ( tpap_ai_single_is_rate_limit_error( $error_msg ) ) {
					$rate_limit_hit = true;
					$error_msg      = __( 'Rate limit exceeded. Please try again later.', 'automatic-translate-addon-pro-for-translatepress' );
				} elseif ( strpos( $error_msg, 'timed out' ) !== false || strpos( $error_msg, 'cURL error 28' ) !== false ) {
					$error_msg = __( 'Request timed out', 'automatic-translate-addon-pro-for-translatepress' );
				}
				if ( $error_msg && ! in_array( $error_msg, $errors, true ) ) {
					$errors[] = $error_msg;
				}
				break;
			}

			$clean_text = $response;
			if ( is_string( $clean_text ) ) {
				// Strip markdown code fences like ```json ... ``` if returned by the model.
				$clean_text = preg_replace( '/^```json\\s*/i', '', $clean_text );
				$clean_text = preg_replace( '/^```\\s*/', '', $clean_text );
				$clean_text = preg_replace( '/```\\s*$/', '', $clean_text );
				$clean_text = trim( $clean_text );

				// Normalize excessive escaping (some providers return double backslashes).
				$clean_text = preg_replace( '/\\\\{2,}([\'"n])/', '\\\$1', $clean_text );
			}

			$translations = json_decode( $clean_text, true );
			if ( is_array( $translations ) ) {
				$all_translations += $translations;
			}
		} catch ( \Exception $e ) {
			$error_msg = $e->getMessage();
			if ( $e->getPrevious() && method_exists( $e->getPrevious(), 'getMessage' ) ) {
				$prev = $e->getPrevious()->getMessage();
				if ( '' !== $prev ) {
					$error_msg = $prev;
				}
			}
			if ( tpap_ai_single_is_rate_limit_error( $error_msg ) ) {
				$rate_limit_hit = true;
				$error_msg      = __( 'Rate limit exceeded. Please try again later.', 'automatic-translate-addon-pro-for-translatepress' );
			} elseif ( strpos( $error_msg, 'timed out' ) !== false || strpos( $error_msg, 'cURL error 28' ) !== false ) {
				$error_msg = __( 'Request timed out', 'automatic-translate-addon-pro-for-translatepress' );
			}
			if ( $error_msg && ! in_array( $error_msg, $errors, true ) ) {
				$errors[] = $error_msg;
			}
			break;
		}
	}

	if ( $rate_limit_hit && empty( $all_translations ) ) {
		wp_send_json_error( array( 'message' => __( 'Rate limit exceeded. Please try again later.', 'automatic-translate-addon-pro-for-translatepress' ) ) );
	}

	if ( ! empty( $errors ) && empty( $all_translations ) ) {
		wp_send_json_error( array( 'message' => implode( '; ', $errors ) ) );
	}

	wp_send_json_success( array(
		'translations' => $all_translations,
		'errors'       => $errors,
	) );
}

/**
 * Check if an API error for single-page AI endpoint indicates rate limit.
 *
 * Mirrors bulk logic in TPAP_Bulk_Translation::tpap_is_rate_limit_error().
 *
 * @param string $message Error message.
 * @return bool
 */
function tpap_ai_single_is_rate_limit_error( $message ) {
	if ( ! is_string( $message ) || '' === $message ) {
		return false;
	}
	$msg_lower = strtolower( $message );
	return strpos( $msg_lower, '429' ) !== false
		|| strpos( $msg_lower, 'rate limit' ) !== false
		|| strpos( $msg_lower, 'too many requests' ) !== false;
}

function tpap_get_providers_key($providers=array(), $removed_mask_filter=false) {
	$api_key = array();

	if(empty($providers) || ! class_exists( '\WordPress\AiClient\AiClient'  )) {
		$providers = array();
	}

	$allowed_providers = array('openai', 'google', 'anthropic');

	$providers = array_intersect($providers, $allowed_providers);

	if(function_exists('_wp_register_default_connector_settings')){
		foreach ($providers as $provider) {
			$ai_client_option_name='connectors_ai_'.$provider.'_api_key';

			if(true === $removed_mask_filter){
				remove_filter( "option_{$ai_client_option_name}", '_wp_connectors_mask_api_key' );
			}
			$client_api_key=get_option($ai_client_option_name, '');

			if(true === $removed_mask_filter){
				add_filter( "option_{$ai_client_option_name}", '_wp_connectors_mask_api_key' );
			}

			if(!empty($client_api_key) && is_string($client_api_key)) {
				$api_key[$provider] = $client_api_key;
			}
		}
	}else{
		$wp_ai_providers_options=get_option('wp_ai_client_provider_credentials', array());

		foreach ($wp_ai_providers_options as $provider => $value) {
			if(!empty($value) && is_string($value)) {
				$api_key[$provider] = $value;
			}
		}
	}

	return $api_key;
}
