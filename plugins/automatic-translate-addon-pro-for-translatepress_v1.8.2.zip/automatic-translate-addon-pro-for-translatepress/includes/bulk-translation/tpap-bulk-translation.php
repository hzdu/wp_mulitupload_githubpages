<?php
/**
 * Bulk translation module: AJAX handler, batch processing, and UI integration.
 *
 * @package Automatic_Translate_Addon_For_TranslatePress_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'TPAP_Bulk_Translation' ) ) {

	/**
	 * Class TPAP_Bulk_Translation
	 *
	 * Handles bulk translation of posts/pages via AJAX batches.
	 */
	class TPAP_Bulk_Translation {
		const SAVE_CHUNK_SIZE      = 50;

		public static $init;

		/**
		 * Instance
		 *
		 * @return self
		 */
		public static function instance() {
			if ( ! isset( self::$init ) ) {
				self::$init = new self();
			}
			return self::$init;
		}

		public function __construct() {
			add_action( 'manage_posts_extra_tablenav', array( $this, 'tpap_render_bulk_translate_button' ), 20, 1 );
			add_action( 'admin_enqueue_scripts', array( $this, 'tpap_bulk_translate_enqueue_scripts' ) );
			add_action( 'wp_ajax_tpap_bulk_load_strings', array( $this, 'tpap_bulk_load_strings' ) );
			add_action( 'wp_ajax_tpap_bulk_save_translations', array( $this, 'tpap_bulk_save_translations' ) );
			add_filter( 'wp_ai_client_default_request_timeout', array( $this, 'tpap_ai_request_timeout' ), 10, 0 );
		}
		
		/**
		 * Provide default timeout for AI client requests.
		 *
		 * @return int Timeout in seconds.
		 */
		public function tpap_ai_request_timeout() {
			return (int) apply_filters( 'tpap_ai_request_timeout', 30 );
		}


		/**
		 * AJAX handler: load pending strings for the given pages and language.
		 *
		 * @return void
		 */
		public function tpap_bulk_load_strings() {
			// Custom nonce validation so we can return JSON instead of a hard 403.
			$nonce = isset( $_REQUEST['_ajax_nonce'] )
				? sanitize_text_field( wp_unslash( $_REQUEST['_ajax_nonce'] ) )
				: ( isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '' );

			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'auto-translate-press-pro-nonces' ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Security check failed. Please reload the page and try again.', 'automatic-translate-addon-pro-for-translatepress' ),
					)
				);
			}

			if ( function_exists( 'set_time_limit' ) ) {
				set_time_limit( 300 ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- extend execution time for long bulk translation requests.
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Insufficient permissions', 'automatic-translate-addon-pro-for-translatepress' ),
					)
				);
			}

			$page_ids = isset( $_POST['page_ids'] ) ? array_map( 'absint', (array) $_POST['page_ids'] ) : array();
			$language = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '';

			if ( empty( $page_ids ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'No pages selected', 'automatic-translate-addon-pro-for-translatepress' ),
					)
				);
			}

			if ( empty( $language ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'No target language provided', 'automatic-translate-addon-pro-for-translatepress' ),
					)
				);
			}

			if ( ! class_exists( 'TRP_Translate_Press' ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'TranslatePress is not available', 'automatic-translate-addon-pro-for-translatepress' ),
					)
				);
			}

			// Ensure TranslatePress renders the page in the requested preview language.
			$_REQUEST['trp-edit-translation'] = 'preview';
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- TranslatePress global, required for preview context.
			global $TRP_LANGUAGE;
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- TranslatePress global, required for preview context.
			$TRP_LANGUAGE = $language;

			$source_lang = $this->tpap_get_default_language();
			$tables      = $this->tpap_get_tables( $source_lang, $language );

			$trp                = TRP_Translate_Press::get_trp_instance();
			$translation_render = $trp->get_component( 'translation_render' );
			$url_converter      = $trp->get_component( 'url_converter' );

			$response_payload = array(
				'pages'          => array(),
				'failed_details' => array(),
			);

			foreach ( $page_ids as $page_id ) {
				$title = get_the_title( $page_id );
				$url   = get_permalink( $page_id );

				if ( ! $url ) {
					$response_payload['failed_details'][] = $this->tpap_failed_detail(
						$page_id,
						$title,
						__( 'No permalink (trashed or invalid post)', 'automatic-translate-addon-pro-for-translatepress' )
					);
					continue;
				}

				$lang_url = $url_converter->get_url_for_language( $language, $url );
				$lang_url = add_query_arg( 'nocache', time(), $lang_url );
				$response = wp_remote_get( $lang_url, $this->tpap_get_crawl_request_args() );

				if ( is_wp_error( $response ) ) {
					$response_payload['failed_details'][] = $this->tpap_failed_detail(
						$page_id,
						$title,
						$this->tpap_get_request_error_message( $response )
					);
					continue;
				}

				$response_code = (int) wp_remote_retrieve_response_code( $response );
				if ( 200 !== $response_code ) {
					$reason = 404 === $response_code
						? __( 'Page not found (404)', 'automatic-translate-addon-pro-for-translatepress' )
						: sprintf(
							/* translators: %s: HTTP response code (e.g. 500, 503). */
							__( 'HTTP %s', 'automatic-translate-addon-pro-for-translatepress' ),
							$response_code
						);

					$response_payload['failed_details'][] = $this->tpap_failed_detail( $page_id, $title, $reason );
					continue;
				}

				$html = wp_remote_retrieve_body( $response );
				if ( empty( $html ) ) {
					$response_payload['failed_details'][] = $this->tpap_failed_detail(
						$page_id,
						$title,
						__( 'Empty response body', 'automatic-translate-addon-pro-for-translatepress' )
					);
					continue;
				}

				$translated_html = $translation_render->translate_page( $html );
				$ids             = $this->tpap_extract_trp_ids_from_html( $translated_html );
				$dict_strings    = $this->tpap_fetch_pending_strings( $ids['dict_ids'], $tables['dict'] );
				$gettext_strings = $this->tpap_fetch_pending_strings( $ids['gettext_ids'], $tables['gettext'] );

				$review_url = $url_converter->get_url_for_language( $language, $url );
				if ( strpos( $review_url, '#TRPLINKPROCESSED' ) !== false ) {
					$review_url = substr( $review_url, 0, strpos( $review_url, '#TRPLINKPROCESSED' ) );
				}

				$response_payload['pages'][ $page_id ] = array(
					'title'           => (string) $title,
					'dict_ids'        => $ids['dict_ids'],
					'gettext_ids'     => $ids['gettext_ids'],
					'dict_strings'    => $dict_strings,
					'gettext_strings' => $gettext_strings,
					'review_url'      => $review_url,
				);
			}

			wp_send_json_success( $response_payload );
		}

		/**
		 * AJAX handler: save translations. Unified for all providers.
		 *
		 * @return void
		 */
		public function tpap_bulk_save_translations() {
			// Custom nonce validation so we can return JSON instead of a hard 403.
			$nonce = isset( $_REQUEST['_ajax_nonce'] )
				? sanitize_text_field( wp_unslash( $_REQUEST['_ajax_nonce'] ) )
				: ( isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '' );

			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'auto-translate-press-pro-nonces' ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Security check failed. Please reload the page and try again.', 'automatic-translate-addon-pro-for-translatepress' ),
					)
				);
			}

			// Normalize provider once. Treat "chrome_ai" as pre-translated mode (not SDK).
			$provider_raw = isset( $_POST['provider'] )
				? sanitize_text_field( wp_unslash( $_POST['provider'] ) )
				: '';

			$is_sdk_mode = ( '' !== $provider_raw && 'chrome_ai' !== $provider_raw );
			$save_timeout = $is_sdk_mode
				? (int) apply_filters( 'tpap_bulk_save_timeout_sdk', 300 )
				: (int) apply_filters( 'tpap_bulk_save_timeout', 120 );
			if ( function_exists( 'set_time_limit' ) && $save_timeout > 0 ) {
				set_time_limit( $save_timeout ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- extend execution time for long bulk translation save operations.
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Insufficient permissions', 'automatic-translate-addon-pro-for-translatepress' ),
					)
				);
			}

			$language = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '';
			if ( empty( $language ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'No target language provided', 'automatic-translate-addon-pro-for-translatepress' ),
					)
				);
			}

			$source_lang = $this->tpap_get_default_language();
			$tables      = $this->tpap_get_tables( $source_lang, $language );

			// Common optional metadata (used when available, e.g. bulk translation dashboard logging).
			$page_id   = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
			$page_title = isset( $_POST['page_title'] ) ? sanitize_text_field( wp_unslash( $_POST['page_title'] ) ) : '';
			$char_count = isset( $_POST['character_count'] ) ? absint( $_POST['character_count'] ) : 0;
			$review_url = isset( $_POST['review_url'] ) ? esc_url_raw( wp_unslash( $_POST['review_url'] ) ) : '';

			// Mode A: pre-translated (Chrome AI or other pre-filled translations)
			$raw_dict    = isset( $_POST['dict_translations'] ) && is_array( $_POST['dict_translations'] ) ? wp_unslash( $_POST['dict_translations'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per-entry below.
			$raw_gettext = isset( $_POST['gettext_translations'] ) && is_array( $_POST['gettext_translations'] ) ? wp_unslash( $_POST['gettext_translations'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per-entry below.

			if ( ! empty( $raw_dict ) || ! empty( $raw_gettext ) ) {
				$dict_translations    = array();
				$gettext_translations = array();
				foreach ( $raw_dict as $id => $text ) {
					$id = absint( $id );
					if ( ! $id ) {
						continue;
					}
					$clean = wp_kses_post( (string) wp_unslash( $text ) );
					if ( '' !== $clean ) {
						$dict_translations[ $id ] = $clean;
					}
				}
				foreach ( $raw_gettext as $id => $text ) {
					$id = absint( $id );
					if ( ! $id ) {
						continue;
					}
					$clean = wp_kses_post( (string) wp_unslash( $text ) );
					if ( '' !== $clean ) {
						$gettext_translations[ $id ] = $clean;
					}
				}
				if ( empty( $dict_translations ) && empty( $gettext_translations ) ) {
					wp_send_json_error( array( 'message' => __( 'No translations received', 'automatic-translate-addon-pro-for-translatepress' ) ) );
				}
				$saved_dict = 0;
				$saved_gettext = 0;
				if ( ! empty( $dict_translations ) && ! empty( $tables['dict'] ) ) {
					$this->tpap_save_translations_batch( $dict_translations, $tables['dict'] );
					$saved_dict = count( $dict_translations );
				}
				if ( ! empty( $gettext_translations ) && ! empty( $tables['gettext'] ) ) {
					$this->tpap_save_translations_batch( $gettext_translations, $tables['gettext'] );
					$saved_gettext = count( $gettext_translations );
				}

				// When called from bulk Chrome AI translation, log stats into CPT dashboard data.
				if ( $page_id > 0 && ( $saved_dict > 0 || $saved_gettext > 0 ) && class_exists( 'Tpap_Dashboard' ) ) {
					// Default provider to chrome_ai when not explicitly provided.
					$provider_id = ( '' !== $provider_raw ) ? $provider_raw : 'chrome_ai';
					$title       = $page_title ? $page_title : get_the_title( $page_id );
					$time_taken  = isset( $_POST['time_taken_sec'] ) ? absint( $_POST['time_taken_sec'] ) : 0;
					if ( $time_taken <= 0 ) {
						$time_taken = 1;
					}
					$translation_data = array(
						'post_id'          => $page_id,
						'service_provider' => $provider_id,
						'source_language'  => $source_lang,
						'target_language'  => $language,
						'time_taken'       => $time_taken,
						'string_count'     => $saved_dict + $saved_gettext,
						'character_count'  => $char_count,
						'date_time'        => current_time( 'Y-m-d H:i:s' ),
						'version_type'     => 'pro',
					);
					// Keep post title if available for better reporting.
					if ( ! empty( $title ) ) {
						$translation_data['post_title'] = $title;
					}
					if ( ! empty( $review_url ) ) {
						$translation_data['review_url'] = $review_url;
					}
					Tpap_Dashboard::store_options( 'tpa', 'post_id', 'update', $translation_data );
				}

				wp_send_json_success( array( 'saved_dict' => $saved_dict, 'saved_gettext' => $saved_gettext ) );
			}

			// Mode B: API translate + save (chunked, max SAVE_CHUNK_SIZE per request)
			$provider_id = $provider_raw;
			$dict_strings    = isset( $_POST['dict_strings'] ) && is_array( $_POST['dict_strings'] ) ? array_slice( wp_unslash( $_POST['dict_strings'] ), 0, self::SAVE_CHUNK_SIZE ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- original strings are sanitized before saving.
			$gettext_strings  = isset( $_POST['gettext_strings'] ) && is_array( $_POST['gettext_strings'] ) ? array_slice( wp_unslash( $_POST['gettext_strings'] ), 0, self::SAVE_CHUNK_SIZE ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- original strings are sanitized before saving.

			if ( empty( $provider_id ) || ( empty( $dict_strings ) && empty( $gettext_strings ) ) ) {
				wp_send_json_error( array( 'message' => __( 'No provider or strings to translate', 'automatic-translate-addon-pro-for-translatepress' ) ) );
			}

			$ai_errors      = array();
			$rate_limit_hit = false;
			$saved_dict     = 0;
			$saved_gettext  = 0;

			$dict_strings_sanitized = array();
			foreach ( $dict_strings as $item ) {
				if ( ! is_array( $item ) || ! isset( $item['id'], $item['original'] ) ) {
					continue;
				}
				$id = absint( $item['id'] );
				if ( ! $id ) {
					continue;
				}
				$dict_strings_sanitized[] = array( 'id' => $id, 'original' => (string) $item['original'] );
			}
			$gettext_strings_sanitized = array();
			foreach ( $gettext_strings as $item ) {
				if ( ! is_array( $item ) || ! isset( $item['id'], $item['original'] ) ) {
					continue;
				}
				$id = absint( $item['id'] );
				if ( ! $id ) {
					continue;
				}
				$gettext_strings_sanitized[] = array( 'id' => $id, 'original' => (string) $item['original'] );
			}

			if ( ! empty( $dict_strings_sanitized ) ) {
				$translations = $this->tpap_perform_ai_translation( $dict_strings_sanitized, $source_lang, $language, $ai_errors, $provider_id, $rate_limit_hit );
				if ( ! empty( $translations ) && ! empty( $tables['dict'] ) ) {
					$this->tpap_save_translations_batch( $translations, $tables['dict'] );
					$saved_dict = count( $translations );
				}
			}
			if ( ! empty( $gettext_strings_sanitized ) && ! $rate_limit_hit ) {
				$translations = $this->tpap_perform_ai_translation( $gettext_strings_sanitized, $source_lang, $language, $ai_errors, $provider_id, $rate_limit_hit );
				if ( ! empty( $translations ) && ! empty( $tables['gettext'] ) ) {
					$this->tpap_save_translations_batch( $translations, $tables['gettext'] );
					$saved_gettext = count( $translations );
				}
			}

			if ( $rate_limit_hit ) {
				wp_send_json_error( array( 'message' => self::RATE_LIMIT_MESSAGE() ) );
			}

			$page_id   = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
			$is_final  = ! empty( $_POST['is_final_chunk'] );
			$response  = array( 'saved_dict' => $saved_dict, 'saved_gettext' => $saved_gettext );

			if ( $is_final && $page_id > 0 && ( $saved_dict > 0 || $saved_gettext > 0 ) && class_exists( 'Tpap_Dashboard' ) ) {
				$title      = isset( $_POST['page_title'] ) ? sanitize_text_field( wp_unslash( $_POST['page_title'] ) ) : get_the_title( $page_id );
				$char_count = isset( $_POST['character_count'] ) ? absint( $_POST['character_count'] ) : 0;
				$time_taken = isset( $_POST['time_taken_sec'] ) ? absint( $_POST['time_taken_sec'] ) : 0;
				if ( $time_taken <= 0 ) {
					$time_taken = 1;
				}
				$translation_data = array(
					'post_id'          => $page_id,
					'service_provider' => $provider_id,
					'source_language'  => $source_lang,
					'target_language'  => $language,
					'time_taken'       => $time_taken,
					'string_count'     => $saved_dict + $saved_gettext,
					'character_count'  => $char_count,
					'date_time'        => current_time( 'Y-m-d H:i:s' ),
					'version_type'     => 'pro',
				);
				Tpap_Dashboard::store_options( 'tpa', 'post_id', 'update', $translation_data );
			}

			if ( $is_final && $page_id > 0 ) {
				$response['pages_data'] = array(
					$page_id => array(
						'title'              => isset( $_POST['page_title'] ) ? sanitize_text_field( wp_unslash( $_POST['page_title'] ) ) : get_the_title( $page_id ),
						'review_url'         => isset( $_POST['review_url'] ) ? esc_url_raw( wp_unslash( $_POST['review_url'] ) ) : '',
						'already_translated' => ( $saved_dict === 0 && $saved_gettext === 0 ),
					),
				);
			}

			wp_send_json_success( $response );
		}

		/**
		 * Parse HTML and extract TRP dictionary and gettext IDs.
		 *
		 * @param string $html HTML with data-trp-translate-id and data-trp-gettext-id.
		 * @return array{ dict_ids: int[], gettext_ids: int[] }
		 */
		private function tpap_extract_trp_ids_from_html( $html ) {
			$dict_ids   = array();
			$gt_ids     = array();
			$doc        = new DOMDocument();
			libxml_use_internal_errors( true );
			$doc->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
			libxml_clear_errors();
			$xpath = new DOMXPath( $doc );

			foreach ( $xpath->query( '//*[@data-trp-translate-id]' ) as $node ) {
				$id = $node->getAttribute( 'data-trp-translate-id' );
				if ( $id ) {
					$dict_ids[] = absint( $id );
				}
			}
			foreach ( $xpath->query( '//*[@data-trp-gettext-id]' ) as $node ) {
				$id = $node->getAttribute( 'data-trp-gettext-id' );
				if ( $id ) {
					$gt_ids[] = absint( $id );
				}
			}

			return array(
				'dict_ids'    => array_values( array_unique( $dict_ids ) ),
				'gettext_ids' => array_values( array_unique( $gt_ids ) ),
			);
		}

		/**
		 * Request args for crawling a page URL.
		 *
		 * @return array
		 */
		private function tpap_get_crawl_request_args() {
			$timeout = (int) apply_filters( 'tpap_bulk_translate_crawl_timeout', 60 );
			$timeout = max( 15, min( 120, $timeout ) );
			$args = array(
				'timeout'     => $timeout,
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter for local SSL verify.
				'sslverify'   => apply_filters( 'https_local_ssl_verify', false ),
				'httpversion' => '1.1',
			);

			return $args;
		}

		/**
		 * Get a user-friendly error message from WP_Error.
		 *
		 * @param \WP_Error $response WP_Error from wp_remote_get.
		 * @return string
		 */
		private function tpap_get_request_error_message( $response ) {
			$msg = $response->get_error_message();
			if ( strpos( $msg, 'timed out' ) !== false || strpos( $msg, 'cURL error 28' ) !== false ) {
				return __( 'Request timed out', 'automatic-translate-addon-pro-for-translatepress' );
			}
			if ( strpos( $msg, 'cURL error' ) !== false || strlen( $msg ) > 80 ) {
				return __( 'Connection error', 'automatic-translate-addon-pro-for-translatepress' );
			}
			return $msg;
		}

		/**
		 * Build a failed-detail entry for the response.
		 *
		 * @param int    $page_id Post ID.
		 * @param string $title   Post title.
		 * @param string $reason  Failure reason.
		 * @return array
		 */
		private function tpap_failed_detail( $page_id, $title, $reason ) {
			return array(
				'page_id' => $page_id,
				'title'   => $title ? $title : '(no title)',
				'reason'  => $reason,
			);
		}

		/**
		 * Get TranslatePress default language code.
		 *
		 * @return string
		 */
		private function tpap_get_default_language() {
			$trp_settings = get_option( 'trp_settings' );
			return isset( $trp_settings['default-language'] ) ? $trp_settings['default-language'] : 'en_US';
		}

		/**
		 * Build TranslatePress dictionary/gettext table names for a language pair.
		 *
		 * @param string $source_lang Source language code.
		 * @param string $target_lang Target language code.
		 * @return array{dict: string, gettext: string}
		 */
		private function tpap_get_tables( $source_lang, $target_lang ) {
			global $wpdb;
			$source_lang = strtolower( $source_lang );
			$target_lang = strtolower( $target_lang );
			
			return array(
				'dict' => $wpdb->get_blog_prefix() . 'trp_dictionary_' . $source_lang . '_' . $target_lang,
				'gettext' => $wpdb->get_blog_prefix() . 'trp_gettext_' . $target_lang
			);
		}

		/**
		 * Fetch untranslated source strings from a TranslatePress table by IDs.
		 *
		 * @param int[]  $ids   String IDs.
		 * @param string $table Database table name.
		 * @return array<int, array<string, mixed>>
		 */
		private function tpap_fetch_pending_strings( $ids, $table ) {
			global $wpdb;
			if ( empty( $ids ) || empty( $table ) ) {
				return array();
			}

			// Verify table exists
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- TranslatePress custom tables; no core API.
			if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) {
				return array();
			}

			$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			// Fetch only strings that are not yet translated: not locked (status != 2) and no translation text yet.
			// This ensures we never send already-translated content for translation again.
			$query = "SELECT id, original FROM `$table` WHERE id IN ($placeholders) AND (status != 2 OR status IS NULL) AND (translated IS NULL OR translated = '')";
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Table from tpap_get_tables(); IDs passed to prepare(); TranslatePress custom tables.
			return $wpdb->get_results( $wpdb->prepare( $query, ...$ids ), ARRAY_A );
		}

		/**
		 * Check if an API error message indicates rate limit (429 / too many requests).
		 *
		 * @param string $message Error message from API or SDK.
		 * @return bool
		 */
		private function tpap_is_rate_limit_error( $message ) {
			if ( ! is_string( $message ) || $message === '' ) {
				return false;
			}
			$msg_lower = strtolower( $message );
			return strpos( $msg_lower, '429' ) !== false
				|| strpos( $msg_lower, 'rate limit' ) !== false
				|| strpos( $msg_lower, 'too many requests' ) !== false;
		}

		/**
		 * Get normalized API rate-limit message for UI responses.
		 *
		 * @return string
		 */
		private static function RATE_LIMIT_MESSAGE() {
			return __( 'Rate limit exceeded. Please try again later.', 'automatic-translate-addon-pro-for-translatepress' );
		}

		/**
		 * Translate source strings through the selected AI provider in chunks.
		 *
		 * @param array       $strings        String rows with `id` and `original`.
		 * @param string      $source_lang    Source language code.
		 * @param string      $target_lang    Target language code.
		 * @param array       $errors         Collected provider/API errors.
		 * @param string      $provider_id    Provider identifier.
		 * @param bool|null   $rate_limit_hit Whether a rate-limit error occurred.
		 * @return array<string, string>
		 */
		private function tpap_perform_ai_translation( $strings, $source_lang, $target_lang, &$errors, $provider_id = '', &$rate_limit_hit = null ) {
			if ( empty( $strings ) ) {
				return array();
			}

			$rate_limit_hit = false;
			$items_to_translate = array();
			foreach ( $strings as $item ) {
				$items_to_translate[ $item['id'] ] = $item['original'];
			}

			$chunks = array_chunk( $items_to_translate, 50, true );
			$all_translations = array();

			foreach ( $chunks as $chunk ) {
				try {
					$strings_for_prompt = wp_json_encode( $chunk, JSON_UNESCAPED_UNICODE );
					$prompt_text        = sprintf(
						'Instruction 1: Translate visible text content semantically from %1$s to %2$s. Provide a proper meaning-based translation.
						Instruction 2: Do not translate or modify any content inside square brackets []. These are shortcodes or dynamic placeholders and must remain exactly as they are.
						Instruction 3: Preserve all HTML tags and their attributes such as class, id, data-*, etc. Do not alter any part of the HTML structure.
						Instruction 4: Return the translation in the format of a JSON object with the keys being the provided IDs, and the values being the translated strings.
						Instruction 5: Do not escape double quotes with backslashes. Output must be valid JSON without extra slashes.
						Instruction 6: Ensure the JSON is well-formed and complete.
						Instruction 7: Decode any &lt; and &gt; HTML entities back to < and > symbols in the output & preserve and maintain whitespace.
						Instruction 8: Return the output as a valid JSON object only. Do not wrap the output in a string or markdown code block (no ```json). Output must start with { and end with }.
						Strings are :- %3$s',
						$source_lang,
						$target_lang,
						$strings_for_prompt
					);

					$is_anthropic = ! empty( $provider_id ) && str_contains( strtolower( $provider_id ), 'anthropic' );
					if ( function_exists( 'wp_ai_client_prompt' ) ) {
						if ( $is_anthropic ) {
							$ai_prompt = wp_ai_client_prompt( $prompt_text );
						} else {
							$ai_prompt = wp_ai_client_prompt( $prompt_text )->as_json_response();
						}
					} else {
						if ( $is_anthropic ) {
							$ai_prompt = \WordPress\AI_Client\AI_Client::prompt( $prompt_text );
						} else {
							$ai_prompt = \WordPress\AI_Client\AI_Client::prompt_with_wp_error( $prompt_text )->as_json_response();
						}
					}

					if ( ! empty( $provider_id ) ) {
						$ai_prompt->using_provider( $provider_id );
					}
					$model_id = $this->tpap_get_best_model_for_provider( $provider_id );
					if ( ! empty( $model_id ) ) {
						$registry = \WordPress\AiClient\AiClient::defaultRegistry();
						$model_instance = $registry->getProviderModel( $provider_id, $model_id );
						$ai_prompt->using_model( $model_instance );
					}

					$response = $ai_prompt->generate_text();
					if ( is_wp_error( $response ) ) {
						$error_msg = $response->get_error_message();
						if ( $this->tpap_is_rate_limit_error( $error_msg ) ) {
							$rate_limit_hit = true;
							$error_msg = self::RATE_LIMIT_MESSAGE();
						} elseif ( strpos( $error_msg, 'timed out' ) !== false || strpos( $error_msg, 'cURL error 28' ) !== false ) {
							$error_msg = __( 'Request timed out', 'automatic-translate-addon-pro-for-translatepress' );
						}
						if ( $error_msg && ! in_array( $error_msg, $errors ) ) {
							$errors[] = $error_msg;
						}
						break;
					}
					
					$clean_text = $response;
					if ( is_string( $clean_text ) ) {
						// Strip markdown code fences like ```json ... ``` if returned by the model.
						$clean_text = preg_replace( '/^```json\\s*/i', '', $clean_text );
						$clean_text = preg_replace( '/^```\\s*/', '', $clean_text );
						$clean_text = preg_replace( '/```\\s*$/', '', $clean_text );
						$clean_text = trim( $clean_text );

						// Normalize excessive escaping (some providers return double backslashes).
						$clean_text = preg_replace( '/\\\\{2,}([\'"n])/', '\\\$1', $clean_text );
					}

					$translations = json_decode( $clean_text, true );
					if ( is_array( $translations ) ) {
						$all_translations += $translations;
					}
				} catch ( \Exception $e ) {
					$error_msg = $e->getMessage();
					if ( $e->getPrevious() && method_exists( $e->getPrevious(), 'getMessage' ) ) {
						$prev = $e->getPrevious()->getMessage();
						if ( $prev !== '' ) {
							$error_msg = $prev;
						}
					}
					if ( $this->tpap_is_rate_limit_error( $error_msg ) ) {
						$rate_limit_hit = true;
						$error_msg = self::RATE_LIMIT_MESSAGE();
					} elseif ( strpos( $error_msg, 'timed out' ) !== false || strpos( $error_msg, 'cURL error 28' ) !== false ) {
						$error_msg = __( 'Request timed out', 'automatic-translate-addon-pro-for-translatepress' );
					}
					if ( $error_msg && ! in_array( $error_msg, $errors ) ) {
						$errors[] = $error_msg;
					}
					break;
				}
			}

			return $all_translations;
		}
		

		/**
		 * Persist translated strings into TranslatePress custom tables in chunks.
		 *
		 * @param array<int|string, string> $translations Translated values keyed by row ID.
		 * @param string                    $table        Database table name.
		 * @return void
		 */
		private function tpap_save_translations_batch( $translations, $table ) {
			global $wpdb;
			if ( empty( $translations ) || empty( $table ) ) {
				return;
			}

			// Construct bulk update query
			// We use INSERT ... ON DUPLICATE KEY UPDATE
			
			$values = array();
			$placeholders = array();
			
			foreach ( $translations as $id => $translated_text ) {
				if ( empty( $translated_text ) ) continue;
				
				$values[] = $id;
				$values[] = $translated_text;
				$values[] = 2; // Status 2 for human/locked translation
				$placeholders[] = "(%d, %s, %d)";
			}

			if ( empty( $values ) ) {
				return;
			}

			$query = "INSERT INTO `$table` (id, translated, status) VALUES " . implode( ', ', $placeholders );
			$query .= " ON DUPLICATE KEY UPDATE translated = VALUES(translated), status = VALUES(status)";
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Table from tpap_get_tables(); all values passed to prepare(); TranslatePress custom tables.
			$wpdb->query( $wpdb->prepare( $query, $values ) );
		}

		/**
		 * Resolve preferred model ID for a provider using plugin settings.
		 *
		 * @param string $provider_id Provider slug.
		 * @return string
		 */
		private function tpap_get_best_model_for_provider( $provider_id ) {
			// Priority 0: User-selected model from settings (tpap_ai_models option).
			$selected_models = get_option( 'tpap_ai_models', array() );
			if ( is_array( $selected_models ) ) {
				$provider_key = sanitize_key( (string) $provider_id );
				if ( isset( $selected_models[ $provider_key ] ) && is_string( $selected_models[ $provider_key ] ) && $selected_models[ $provider_key ] !== '' ) {
					return $selected_models[ $provider_key ];
				}
			}
		}

		/**
		 * Enqueue bulk translate scripts and styles; localize data for JS.
		 *
		 * @return void
		 */
		public function tpap_bulk_translate_enqueue_scripts() {
			wp_enqueue_style( 'dashicons' );
			wp_enqueue_style( 'tpap-bulk-translate', TPAP_URL . 'assets/css/tpap-bulk-translate.css', array(), TPAP_VERSION );

			// Google Translate widget dependencies used by bulk Google Widget provider.
			wp_register_script(
				'tpap-google-translate-element-bulk',
				'https://translate.google.com/translate_a/element.js',
				array(),
				TPAP_VERSION,
				true
			);
			wp_register_script(
				'tpap-bulk-google-language',
				TPAP_URL . 'assets/js/bulk-google/google-language.js',
				array( 'jquery', 'tpap-google-translate-element-bulk' ),
				TPAP_VERSION,
				true
			);
			wp_register_script(
				'tpap-bulk-google-provider',
				TPAP_URL . 'assets/js/bulk-google/google-provider.js',
				array( 'jquery', 'tpap-google-translate-element-bulk', 'tpap-bulk-google-language' ),
				TPAP_VERSION,
				true
			);

			wp_enqueue_script(
				'tpap-bulk-translate',
				TPAP_URL . 'assets/js/tpap-bulk-translate.js',
				array( 'jquery', 'tpap-google-translate-element-bulk', 'tpap-bulk-google-language', 'tpap-bulk-google-provider' ),
				TPAP_VERSION,
				true
			);
			if ( ! wp_script_is( 'tpap-chrome-ai-translation', 'registered' ) ) {
				wp_register_script( 'tpap-chrome-ai-translation', TPAP_URL . 'assets/js/chrome-ai-translation.js', array( 'jquery' ), TPAP_VERSION, true );
			}
			wp_enqueue_script( 'tpap-chrome-ai-translation' );

			$trp_settings     = get_option( 'trp_settings', array() );
			$languages        = isset( $trp_settings['translation-languages'] ) ? $trp_settings['translation-languages'] : array();
			$default_language = isset( $trp_settings['default-language'] ) ? $trp_settings['default-language'] : '';

			// Language names and flag URLs from TranslatePress (TRP_Languages + trp_custom_language_switcher).
			$language_names = $this->tpap_get_language_data_from_translatepress( $languages, 'names' );
			$language_flags = $this->tpap_get_language_data_from_translatepress( $languages, 'flags' );

			$license_option   = get_option( 'TranslatepressAutomaticTranslateAddonPro_lic_Key', '' );
			$license_key      = ! empty( $license_option ) ? $license_option : 'No';
			$ai_credentials   = get_option( 'wp_ai_client_provider_credentials', array() );
			$has_ai_key       = count( array_filter( $ai_credentials ) ) > 0;

			// Detect current post type for nicer notice messaging in JS.
			$post_type_name = '';
			if ( function_exists( 'get_current_screen' ) ) {
				$screen = get_current_screen();
				if ( $screen && ! empty( $screen->post_type ) ) {
					$post_type_obj = get_post_type_object( $screen->post_type );
					if ( $post_type_obj && ! empty( $post_type_obj->labels->singular_name ) ) {
						$post_type_name = $post_type_obj->labels->singular_name;
					} else {
						$post_type_name = $screen->post_type;
					}
				}
			}

			$available_providers = array();
			$provider_enabled_map = array(
				// Provider IDs used by wp-ai-client registry.
				'openai'    => ( get_option( 'tpa_provider_openai_enabled', '1' ) === '1' ),
				'anthropic' => ( get_option( 'tpa_provider_anthropic_enabled', '1' ) === '1' ),
				'google'    => ( get_option( 'tpa_provider_gemini_enabled', '1' ) === '1' ),
				'chrome_ai' => ( get_option( 'tpa_provider_chrome_enabled', '1' ) === '1' ),
				'google_widget' => ( get_option( 'tpa_provider_google_enabled', '1' ) === '1' ),
			);
			try {
				if ( class_exists( 'WordPress\AiClient\AiClient' ) ) {
					$registry     = \WordPress\AiClient\AiClient::defaultRegistry();
					$provider_ids = $registry->getRegisteredProviderIds();
					$requirements = new \WordPress\AiClient\Providers\Models\DTO\ModelRequirements(
						array( \WordPress\AiClient\Providers\Models\Enums\CapabilityEnum::textGeneration() ),
						array()
					);
					foreach ( $provider_ids as $provider_id ) {
						// Respect provider toggles: if disabled, do not offer it in provider cards.
						if ( isset( $provider_enabled_map[ $provider_id ] ) && ! $provider_enabled_map[ $provider_id ] ) {
							continue;
						}
						$models_metadata = $registry->findProviderModelsMetadataForSupport( $provider_id, $requirements );
						$class_name      = $registry->getProviderClassName( $provider_id );
						$provider_key    = is_array( $ai_credentials ) && isset( $ai_credentials[ $provider_id ] );
						$has_key         = $provider_key && ! empty( trim( (string) $ai_credentials[ $provider_id ] ) );
						$available_providers[] = array(
							'id'      => $provider_id,
							'name'    => $class_name::metadata()->getName(),
							'has_key' => $has_key,
						);

						if ( $available_providers[ count( $available_providers ) - 1 ]['id'] === 'google' ) {
							$available_providers[ count( $available_providers ) - 1 ]['name'] = 'Gemini';
						}
					}
				}
			} catch ( \Exception $e ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Intentional logging for provider fetch failures.
				error_log( 'Error fetching AI providers: ' . $e->getMessage() );
			}

			$provider_doc_urls = array(
				'openai'    => 'https://docs.coolplugins.net/doc/generate-open-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=bulk_translate_openai',
				'google'    => 'https://docs.coolplugins.net/doc/generate-google-gemini-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=bulk_translate_gemini',
				'anthropic' => 'https://docs.coolplugins.net/doc/generate-anthropic-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=bulk_translate_anthropic',
				'chrome_ai' => 'https://docs.coolplugins.net/doc/chrome-ai-translation-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=bulk_translate_chrome_ai',
				'google_widget' => 'https://docs.coolplugins.net/doc/google-translate-for-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=bulk_translate_google_widget',
			);

			$bulk_ajax_timeout_sdk_ms = (int) apply_filters( 'tpap_bulk_ajax_timeout_sdk', 300000 );

			wp_localize_script( 'tpap-bulk-translate', 'tpap_bulk_data', array(
				'post_type'                => $post_type_name,
				'languages'               => $languages,
				'language_names'          => $language_names,
				'language_flags'          => $language_flags,
				'default_language'        => $default_language,
				'images_url'              => TPAP_URL . 'assets/images/',
				'provider_doc_urls'       => $provider_doc_urls,
				'dashboard_url'           => admin_url( 'options-general.php?page=translatepress-tpap-dashboard' ),
				'license_key'             => $license_key,
				'ajax_url'                => admin_url( 'admin-ajax.php' ),
				'nonce'                   => wp_create_nonce( 'auto-translate-press-pro-nonces' ),
				'has_ai_key'              => $has_ai_key,
				'available_providers'     => $available_providers,
				'provider_enabled'        => array(
					'openai'    => $provider_enabled_map['openai'] ? '1' : '0',
					'anthropic' => $provider_enabled_map['anthropic'] ? '1' : '0',
					'google'    => $provider_enabled_map['google'] ? '1' : '0',
					'chrome_ai' => $provider_enabled_map['chrome_ai'] ? '1' : '0',
					'google_widget' => $provider_enabled_map['google_widget'] ? '1' : '0',
				),
				'admin_url'               => admin_url( '' ),
				'bulk_ajax_timeout_sdk_ms' => $bulk_ajax_timeout_sdk_ms,
			) );
		}

		/**
		 * Build UI language payload from TranslatePress language records.
		 *
		 * @param array  $language_codes Language codes list.
		 * @param string $type           Language list type (all/active).
		 * @return array<int, array<string, string>>
		 */
		private function tpap_get_language_data_from_translatepress( $language_codes, $type ) {
			$language_codes = (array) $language_codes;
			$out            = array();
			foreach ( $language_codes as $code ) {
				$out[ $code ] = '';
			}

			if ( ! class_exists( 'TRP_Translate_Press' ) ) {
				return $out;
			}

			$trp = TRP_Translate_Press::get_trp_instance();

			if ( 'names' === $type ) {
				$trp_languages = $trp->get_component( 'languages' );
				if ( $trp_languages && method_exists( $trp_languages, 'get_language_names' ) ) {
					$names = $trp_languages->get_language_names( $language_codes );
					$out   = array_merge( $out, $names );
				}
				return $out;
			}

			// Flags: use trp_custom_language_switcher when available (TP’s flag_link); else build from TP path and only if file exists.
			if ( function_exists( 'trp_custom_language_switcher' ) ) {
				$switcher = trp_custom_language_switcher();
				if ( is_array( $switcher ) ) {
					foreach ( $language_codes as $code ) {
						if ( isset( $switcher[ $code ]['flag_link'] ) && $switcher[ $code ]['flag_link'] !== '' ) {
							$out[ $code ] = esc_url( $switcher[ $code ]['flag_link'] );
						}
					}
				}
			}

			if ( defined( 'TRP_PLUGIN_URL' ) && defined( 'TRP_PLUGIN_DIR' ) ) {
				$svg_flags_dir = TRP_PLUGIN_DIR . 'assets/flags/4x3/';
				foreach ( $language_codes as $code ) {
					$locale_file = str_replace( '-', '_', trim( $code ) ) . '.svg';
					if ( file_exists( $svg_flags_dir . $locale_file ) ) {
						$out[ $code ] = esc_url( trailingslashit( TRP_PLUGIN_URL ) . 'assets/flags/4x3/' . rawurlencode( $locale_file ) );
						continue;
					}
				}
			}
			return $out;
		}

		/**
		 * Output the Bulk Translate button in the posts list table.
		 *
		 * Hooked into `manage_posts_extra_tablenav`.
		 *
		 * @param string $which 'top' or 'bottom' tablenav.
		 * @return void
		 */
		public function tpap_render_bulk_translate_button( $which ) {
			// Only show in the top toolbar.
			if ( 'top' !== $which ) {
				return;
			}

			// Don't show on Trash views.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only: used only to decide button visibility, value sanitized.
			$current_status = isset( $_GET['post_status'] ) ? sanitize_key( wp_unslash( $_GET['post_status'] ) ) : '';
			if ( 'trash' === $current_status ) {
				return;
			}

			echo '<button type="button" class="button tpap-bulk-translate-btn">' . esc_html__( 'AI Translate', 'automatic-translate-addon-pro-for-translatepress' ) . '</button>';
		}
	}
}
