<?php
namespace TranslatePressAutoTranslateAddon\Register;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once TPAP_PATH . '/admin/Registration/AutomaticTranslateAddonForTranslatePressBase.php';
if(!class_exists("TranslatepressAutomaticTranslateAddonPro")) {	
	class TranslatepressAutomaticTranslateAddonPro {
		public $responseObj;
		public $licenseMessage;
		public $showMessage = false;
		public $slug        = 'translatepress-tpap-dashboard';
		private const OPTION_LICENSE_KEY = 'TranslatepressAutomaticTranslateAddonPro_lic_Key';
		private const OPTION_LICENSE_EMAIL = 'TranslatepressAutomaticTranslateAddonPro_lic_email';
		public static $form_status = false;

		private const TPAP_ALD_OPTION_NAME = 'tpap_ald_settings';
		private const WP_AI_CLIENT_OPTION_NAME = 'wp_ai_client_provider_credentials';

		function __construct() {
			$this->tpap_register_hooks();
			$this->tpap_initialize_license();
			// Add error notice hook
			add_action('tpap_display_admin_notices', array($this, 'tpap_display_license_error_messages'));
		}

		private function tpap_register_hooks() {
			add_action( 'admin_enqueue_scripts', [ $this, 'tpap_set_admin_style' ] );
			add_action( 'admin_menu', array( $this, 'tpap_add_sub_menu' ), 101 );
			add_action( 'admin_init', array( $this, 'tpap_register_ald_settings' ) );
			add_action( 'admin_init', array( $this, 'tpap_save_settings' ), 9 );
			add_action( 'rest_api_init', array( $this, 'tpap_register_rest_routes' ) );
			add_action('admin_post_tpap_activate_license', [$this, 'tpap_handle_license_activation']);
			add_action('admin_post_tpap_deactivate_license', [$this, 'tpap_handle_license_deactivation']);
			add_action('wp_ajax_tpap_refresh_license_ajax', [$this, 'tpap_handle_refresh_license_ajax']);
		}

		/**
		 * Register REST routes for saving credentials (AutoML-style).
		 */
		public function tpap_register_rest_routes() {
			if ( ! function_exists( 'register_rest_route' ) ) {
				return;
			}

			register_rest_route(
				'tpap-bulk-translate',
				'/wizard-save-credentials',
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'tpap_rest_save_credentials' ),
					'permission_callback' => static function () {
						return current_user_can( 'manage_options' );
					},
				)
			);
		}

		/**
		 * Whether this site uses core "connectors" storage (WP 7.0+).
		 *
		 * @return bool
		 */
		private function tpap_use_connectors_storage() {
			return function_exists( '_wp_register_default_connector_settings' ) || function_exists( 'wp_ai_client_prompt' );
		}

		/**
		 * Get stored API keys (normalized to array{provider=>key}).
		 *
		 * @return array<string,string>
		 */
		private function tpap_get_stored_ai_keys() {
			if ( $this->tpap_use_connectors_storage() ) {
				$keys = array();
				foreach ( array( 'openai', 'google', 'anthropic' ) as $provider ) {
					$key = get_option( 'connectors_ai_' . $provider . '_api_key', '' );
					if ( is_string( $key ) && trim( $key ) !== '' ) {
						$keys[ $provider ] = trim( $key );
					}
				}
				return $keys;
			}

			$keys = get_option( self::WP_AI_CLIENT_OPTION_NAME, array() );
			if ( ! is_array( $keys ) ) {
				return array();
			}

			$normalized = array();
			foreach ( array( 'openai', 'google', 'anthropic' ) as $provider ) {
				if ( isset( $keys[ $provider ] ) && is_string( $keys[ $provider ] ) && trim( $keys[ $provider ] ) !== '' ) {
					$normalized[ $provider ] = trim( $keys[ $provider ] );
				}
			}
			return $normalized;
		}

		/**
		 * Persist API keys to the appropriate storage for this WP version.
		 *
		 * @param array<string,string> $keys Provider => API key.
		 * @return void
		 */
		private function tpap_save_ai_keys( array $keys ) {
			// Always keep the legacy option in sync (the plugin reads from it in multiple places).
			update_option( self::WP_AI_CLIENT_OPTION_NAME, $keys );

			if ( ! $this->tpap_use_connectors_storage() ) {
				return;
			}

			foreach ( array( 'openai', 'google', 'anthropic' ) as $provider ) {
				if ( isset( $keys[ $provider ] ) && is_string( $keys[ $provider ] ) && trim( $keys[ $provider ] ) !== '' ) {
					update_option( 'connectors_ai_' . $provider . '_api_key', $keys[ $provider ] );
				} else {
					delete_option( 'connectors_ai_' . $provider . '_api_key' );
				}
			}
		}

		/**
		 * Update the `tpap_ai_models` option (only for providers whose param was provided).
		 *
		 * @param array<string,mixed> $incoming_models Provider => model_id|null.
		 * @return array<string,mixed> Previous models (for rollback).
		 */
		private function tpap_update_models_option( array $incoming_models ) {
			$previous_models = get_option( 'tpap_ai_models', array() );
			$previous_models = is_array( $previous_models ) ? $previous_models : array();

			$models = $previous_models;
			foreach ( $incoming_models as $provider => $model_id ) {
				if ( $model_id === null ) {
					continue;
				}
				$val = is_string( $model_id ) ? trim( $model_id ) : '';
				if ( $val !== '' ) {
					$models[ $provider ] = sanitize_text_field( $val );
				} else {
					unset( $models[ $provider ] );
				}
			}

			if ( ! empty( $models ) ) {
				update_option( 'tpap_ai_models', $models );
			} else {
				delete_option( 'tpap_ai_models' );
			}

			return $previous_models;
		}

		/**
		 * Roll back the models option to a previous value.
		 *
		 * @param array<string,mixed> $previous_models Previous models.
		 * @return void
		 */
		private function tpap_restore_models_option( array $previous_models ) {
			if ( ! empty( $previous_models ) ) {
				update_option( 'tpap_ai_models', $previous_models );
			} else {
				delete_option( 'tpap_ai_models' );
			}
		}

		/**
		 * Save settings (API keys + models) via REST with validation, compatible with WP 6.9 + WP 7.0.
		 * Mirrors wpml-translation-check's wizard_save_credentials() behavior.
		 *
		 * @param \WP_REST_Request $request Request.
		 * @return \WP_REST_Response|\WP_Error
		 */
		public function tpap_rest_save_credentials( $request ) {
			// 1) Persist models first (and rollback on validation error).
			$previous_models = $this->tpap_update_models_option(
				array(
					'openai'    => $request->get_param( 'openai_model' ),
					'google'    => $request->get_param( 'google_model' ),
					'anthropic' => $request->get_param( 'anthropic_model' ),
				)
			);

			// 2) Validate + apply key changes (changed-only).
			$previous_keys = $this->tpap_get_stored_ai_keys();
			$updated_keys  = $previous_keys;
			$errors        = array();

			$incoming_keys = array(
				'openai'    => $request->get_param( 'openai_key' ),
				'google'    => $request->get_param( 'google_key' ),
				'anthropic' => $request->get_param( 'anthropic_key' ),
			);

			foreach ( $incoming_keys as $provider => $incoming_key ) {
				if ( $incoming_key === null ) {
					continue;
				}

				$new_key = trim( sanitize_text_field( (string) $incoming_key ) );
				$old_key = isset( $previous_keys[ $provider ] ) && is_string( $previous_keys[ $provider ] ) ? $previous_keys[ $provider ] : '';

				// Clear/delete (no-op if already empty).
				if ( $new_key === '' ) {
					if ( $old_key === '' ) {
						continue;
					}
					unset( $updated_keys[ $provider ] );
					continue;
				}

				// Skip validation/save when unchanged.
				if ( $new_key === $old_key ) {
					continue;
				}

				$validation = $this->tpap_validate_provider_api_key( $provider, $new_key );
				if ( is_array( $validation ) && ! empty( $validation['message'] ) ) {
					$errors[ $provider ] = $validation['message'];
					continue;
				}

				$updated_keys[ $provider ] = $new_key;
			}

			if ( ! empty( $errors ) ) {
				$this->tpap_restore_models_option( $previous_models );
				return new \WP_Error(
					'tpap_invalid_api_key',
					__( 'One of the API keys is invalid.', 'automatic-translate-addon-pro-for-translatepress' ),
					array(
						'status' => 400,
						'errors' => $errors,
					)
				);
			}

			// 3) Save updated keys.
			$this->tpap_save_ai_keys( $updated_keys );

			return new \WP_REST_Response( array( 'success' => true ), 200 );
		}

		/**
		 * Register Automatic Language Detection (ALD) settings.
		 *in WP options table as `tpap_ald_settings`.
		 * Stored 
		 */
		public function tpap_register_ald_settings() {
			register_setting(
				'tpap-settings',
				self::TPAP_ALD_OPTION_NAME,
				array(
					'type'              => 'array',
					'sanitize_callback' => array( $this, 'tpap_sanitize_ald_settings' ),
					'default'           => $this->tpap_get_default_ald_settings(),
				)
			);

			// Register AI credentials so options.php can save them directly from the settings form.
			register_setting(
				'tpap-settings',
				'wp_ai_client_provider_credentials',
				array(
					'type'              => 'array',
					'sanitize_callback' => static function ( $value ) {
						if ( ! is_array( $value ) ) {
							return array();
						}
						$allowed   = array( 'openai', 'google', 'anthropic' );
						$sanitized = array();
						foreach ( $value as $provider_id => $api_key ) {
							if ( ! is_string( $provider_id ) || ! in_array( sanitize_key( $provider_id ), $allowed, true ) ) {
								continue;
							}
							if ( ! is_string( $api_key ) ) {
								continue;
							}
							$sanitized[ sanitize_key( $provider_id ) ] = sanitize_text_field( $api_key );
						}
						return $sanitized;
					},
					'default'           => array(),
				)
			);
		}

		/**
		 * Default ALD settings.
		 *
		 * @return array{enabled:string,detection_method:string}
		 */
		private function tpap_get_default_ald_settings() {
			return array(
				'enabled'          => 'no',
				'detection_method' => 'browser-ip',
			);
		}

		/**
		 * Sanitize ALD settings on save.
		 *
		 * @param mixed $value Incoming option value.
		 * @return array Sanitized option value.
		 */
		public function tpap_sanitize_ald_settings( $value ) {
			$defaults = $this->tpap_get_default_ald_settings();
			$value    = is_array( $value ) ? $value : array();

			$enabled = isset( $value['enabled'] ) ? sanitize_text_field( (string) $value['enabled'] ) : $defaults['enabled'];
			$enabled = in_array( $enabled, array( 'yes', 'no' ), true ) ? $enabled : $defaults['enabled'];

			$method = isset( $value['detection_method'] ) ? sanitize_key( (string) $value['detection_method'] ) : $defaults['detection_method'];
			$allowed_methods = array( 'browser-ip', 'ip-browser', 'browser', 'ip' );
			if ( ! in_array( $method, $allowed_methods, true ) ) {
				$method = $defaults['detection_method'];
			}

			return array(
				'enabled'          => $enabled,
				'detection_method' => $method,
			);
		}

	/**
	 * Get TranslatePress language settings
	 *
	 * @return array Language settings including all configured languages
	 */
	private function get_trp_language_settings() {
		$defaults = array(
			'source_language' => 'en',
			'target_language' => 'hi',
			'source_language_label' => 'English',
			'target_language_label' => 'Hindi',
			'all_languages' => array(),
		);
		
		// Get TRP settings
		$trp_settings = get_option( 'trp_settings', array() );
		
		if ( empty( $trp_settings ) ) {
			return $defaults;
		}
		
		// Get default language (source)
		$default_lang = isset( $trp_settings['default-language'] ) ? $trp_settings['default-language'] : 'en_US';
		
		// Get published languages
		$published_languages = isset( $trp_settings['publish-languages'] ) ? $trp_settings['publish-languages'] : array();
		$translation_languages = isset( $trp_settings['translation-languages'] ) ? $trp_settings['translation-languages'] : array();
		$published_languages = count( array_diff( $published_languages, array( $default_lang ) ) ) > 0 ? $published_languages : $translation_languages;
		// Get language names - pass language codes to get_language_names()
		$language_names = array();
		$all_language_codes = array_unique( array_merge( array( $default_lang ), $published_languages ) );
		
		if ( class_exists( 'TRP_Translate_Press' ) && ! empty( $all_language_codes ) ) {
			$trp = \TRP_Translate_Press::get_trp_instance();
			if ( $trp && method_exists( $trp, 'get_component' ) ) {
				$trp_languages = $trp->get_component( 'languages' );
				if ( $trp_languages && method_exists( $trp_languages, 'get_language_names' ) ) {
					// Pass language codes array to get_language_names()
					$language_names = $trp_languages->get_language_names( $all_language_codes );
				}
			}
		}
		
		// Extract base language code (e.g., 'en' from 'en_US')
		$source_language = strtolower( substr( $default_lang, 0, 2 ) );
		$source_language_label = isset( $language_names[ $default_lang ] ) ? $language_names[ $default_lang ] : 'English';
		
		// Build array of all languages with their codes and labels
		$all_languages = array();
		
		// Add source language
		$all_languages[] = array(
			'code' => $source_language,
			'full_code' => $default_lang,
			'label' => $source_language_label,
			'is_default' => true,
		);
		
		// Add all published languages (excluding default if it's already in published languages)
		if ( ! empty( $published_languages ) && is_array( $published_languages ) ) {
			foreach ( $published_languages as $lang_code ) {
				if ( $lang_code !== $default_lang ) {
					$lang_base = strtolower( substr( $lang_code, 0, 2 ) );
					$lang_label = isset( $language_names[ $lang_code ] ) ? $language_names[ $lang_code ] : ucfirst( $lang_base );
					$all_languages[] = array(
						'code' => $lang_base,
						'full_code' => $lang_code,
						'label' => $lang_label,
						'is_default' => false,
					);
				}
			}
		}
		
		// Get first target language for backward compatibility
		$target_language = 'hi';
		$target_language_label = 'Hindi';
		if ( ! empty( $published_languages ) && is_array( $published_languages ) ) {
			foreach ( $published_languages as $lang_code ) {
				if ( $lang_code !== $default_lang ) {
					$target_language = strtolower( substr( $lang_code, 0, 2 ) );
					$target_language_label = isset( $language_names[ $lang_code ] ) ? $language_names[ $lang_code ] : 'Hindi';
					break;
				}
			}
		}
		
		return array(
			'source_language' => $source_language,
			'target_language' => $target_language,
			'source_language_label' => $source_language_label,
			'target_language_label' => $target_language_label,
			'all_languages' => $all_languages,
			'chrome_ai_bypass_api_check' => get_option('tpap_chrome_ai_bypass_api_check', '0'),
			'chrome_ai_bypass_secure_check' => get_option('tpap_chrome_ai_bypass_secure_check', '0'),
			'chrome_ai_bypass_browser_check' => get_option('tpap_chrome_ai_bypass_browser_check', '0'),
		);
	}

	private function tpap_initialize_license() {
		$licenseKey = get_option(self::OPTION_LICENSE_KEY, "");
		$liceEmail = get_option(self::OPTION_LICENSE_EMAIL, get_bloginfo('admin_email'));
		
		\AutomaticTranslateAddonForTranslatePressBase::add_on_delete(function(){
		   delete_option(self::OPTION_LICENSE_KEY);
		   delete_option(self::OPTION_LICENSE_EMAIL);
		});

		if (\AutomaticTranslateAddonForTranslatePressBase::CheckWPPlugin($licenseKey, $liceEmail, $this->licenseMessage, $this->responseObj, TPAP_FILE)) {
			self::$form_status = true;
		} else {
			self::$form_status = false;
			if(!empty($licenseKey) && !empty($this->licenseMessage)) {
				$this->showMessage = true;
			}
		}
	}
		function tpap_set_admin_style() {
		
		wp_enqueue_script(
			'tpap-plugin-setting',
			esc_url(TPAP_URL . 'admin/tpa-dashboard/js/tpap-plugin-setting.js'),
			array('jquery', 'tpap-chrome-ai-translation'),
			TPAP_VERSION,
			true
		);
		wp_localize_script( 'tpap-plugin-setting', 'tpapDashboard', array(
			'ajax_url'  => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'tpap_provider_states_nonce' ),
			'rest_url'  => rest_url( 'tpap-bulk-translate/wizard-save-credentials' ),
			'rest_nonce'=> wp_create_nonce( 'wp_rest' ),
		) );

		$trp_languages = $this->get_trp_language_settings();
		wp_localize_script( 'tpap-plugin-setting', 'tpapTrpLanguages', $trp_languages );
		wp_enqueue_script( 'tpap-chrome-ai-translation', TPAP_URL . 'assets/js/chrome-ai-translation.js', array(), TPAP_VERSION, true );
		wp_enqueue_script( 'tpap-chrome-ai-notice', TPAP_URL . 'admin/tpa-dashboard/js/tpap-chrome-ai-notice.js', array( 'jquery', 'tpap-chrome-ai-translation' ), TPAP_VERSION, true );
		wp_localize_script( 'tpap-chrome-ai-notice', 'tpapTrpLanguages', $trp_languages );
		
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading GET parameter for display logic only, already sanitized
		if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'translatepress-tpap-dashboard') {
			wp_enqueue_style( 'tpap-editor-styles', TPAP_URL . 'admin/tpa-dashboard/css/admin-styles.css', null, TPAP_VERSION, 'all' );
			wp_enqueue_script( 'tpap-data-share-setting', TPAP_URL . 'admin/tpa-dashboard/js/tpap-data-share-setting.js', array('jquery'), TPAP_VERSION, true );
		}
	}

		/**
		 * Validate a provider API key by doing a small metadata call via WP AI Client.
		 *
		 * @param string $provider_id Provider ID (e.g. 'openai', 'google', 'anthropic').
		 * @param string $api_key     API key to test.
		 * @return true|array         true on success, or ['message' => 'error text'] on failure.
		 */
		private function tpap_validate_provider_api_key( $provider_id, $api_key ) {
			$provider_id = is_string( $provider_id ) ? trim( $provider_id ) : '';
			$api_key     = is_string( $api_key ) ? trim( $api_key ) : '';

			if ( $provider_id === '' || $api_key === '' ) {
				return array(
					'message' => __( 'Provider and API key are required.', 'automatic-translate-addon-pro-for-translatepress' ),
				);
			}

			if ( ! class_exists( '\WordPress\AiClient\AiClient' ) ) {
				return array(
					'message' => __( 'AI client is not available.', 'automatic-translate-addon-pro-for-translatepress' ),
				);
			}

			$registry = \WordPress\AiClient\AiClient::defaultRegistry();
			if ( ! $registry->hasProvider( $provider_id ) ) {
				return array(
					'message' => __( 'Invalid AI provider.', 'automatic-translate-addon-pro-for-translatepress' ),
				);
			}

			// Slightly longer cooldown for Google/Gemini due to stricter rate limits.
			$is_gemini = ( 'google' === strtolower( $provider_id ) ) || str_contains( strtolower( $provider_id ), 'gemini' );
			$cooldown  = $is_gemini ? 60 : 5;
			$lock_key  = 'tpap_ai_test_lock_' . md5( $provider_id . '|' . $api_key );

			if ( get_transient( $lock_key ) ) {
				return array(
					'message' => $is_gemini
						? __( 'Gemini rate limit reached. Please wait a minute and try again.', 'automatic-translate-addon-pro-for-translatepress' )
						: __( 'Please wait a few seconds before testing again.', 'automatic-translate-addon-pro-for-translatepress' ),
				);
			}

			// Inject the test API key into the registry.
			$auth_class = '\WordPress\AiClient\Providers\Http\DTO\ApiKeyRequestAuthentication';
			if ( ! class_exists( $auth_class ) ) {
				return array(
					'message' => __( 'AI authentication class is not available.', 'automatic-translate-addon-pro-for-translatepress' ),
				);
			}

			$registry->setProviderRequestAuthentication(
				$provider_id,
				new $auth_class( $api_key )
			);

			set_transient( $lock_key, 1, $cooldown );

			try {
				$provider_classname    = $registry->getProviderClassName( $provider_id );
				$provider_availability = $provider_classname::availability();

				if ( ! $provider_availability->isConfigured() ) {
					return array(
						'message' => __( 'API key is not configured for this provider.', 'automatic-translate-addon-pro-for-translatepress' ),
					);
				}

				$model_metadata_directory = $provider_classname::modelMetadataDirectory();
				// If the key is invalid, this will typically throw.
				$model_metadata_directory->listModelMetadata();
			} catch ( \Exception $e ) {
				$msg = $e->getMessage();
				if ( str_contains( strtolower( $msg ), '429' ) ) {
					return array(
						'message' => $is_gemini
							? __( 'Gemini free tier rate limit exceeded. Please wait and try again.', 'automatic-translate-addon-pro-for-translatepress' )
							: __( 'Rate limit exceeded. Please try again later.', 'automatic-translate-addon-pro-for-translatepress' ),
					);
				}

				return array(
					'message' => __( 'Invalid API key. Please check your credentials.', 'automatic-translate-addon-pro-for-translatepress' ),
				);
			}

			return true;
		}
		/**
		 * Save ALL TPAP settings in one place (options.php submit).
		 *
		 * This runs on every settings save for the `tpap-settings` group (not only when ALD changes).
		 *
		 * @return void
		 */
		public function tpap_save_settings() {
			if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
				return;
			}

			if ( empty( $_POST ) ) {
				return;
			}

			// Only handle options.php submissions for our settings group.
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below.
			$option_page = isset( $_POST['option_page'] ) ? sanitize_key( wp_unslash( $_POST['option_page'] ) ) : '';
			if ( 'tpap-settings' !== $option_page ) {
				return;
			}

			// Verify the Settings API nonce printed by settings_fields( 'tpap-settings' ).
			check_admin_referer( 'tpap-settings-options' );

			// 1) Save ALD settings.
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$ald_raw = isset( $_POST[ self::TPAP_ALD_OPTION_NAME ] ) ? wp_unslash( $_POST[ self::TPAP_ALD_OPTION_NAME ] ) : array();
			$ald_new = $this->tpap_sanitize_ald_settings( $ald_raw );
			update_option( self::TPAP_ALD_OPTION_NAME, $ald_new );

			// 2) Save usage data sharing (opt-in) + cron scheduling.
			// This uses its own nonce because the checkbox is not part of the Settings API fields.
			try {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below for this specific action.
				$optin_nonce = isset( $_POST['tpap_optin_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['tpap_optin_nonce'] ) ) : '';
				if ( $optin_nonce && wp_verify_nonce( $optin_nonce, 'tpap_save_optin_settings' ) ) {
					// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
					$feedback_opt_in = isset( $_POST['tpap-dashboard-feedback-checkbox'] ) ? 'yes' : 'no';
					$feedback_opt_in = in_array( $feedback_opt_in, array( 'yes', 'no' ), true ) ? $feedback_opt_in : 'no';
					update_option( 'tpa_feedback_opt_in', $feedback_opt_in );

					$cron_hook = sanitize_key( 'tpap_extra_data_update' );
					if ( 'no' === $feedback_opt_in && wp_next_scheduled( $cron_hook ) ) {
						wp_clear_scheduled_hook( $cron_hook );
					} elseif ( 'yes' === $feedback_opt_in && ! wp_next_scheduled( $cron_hook ) ) {
						$interval  = 'every_30_days';
						$schedules = wp_get_schedules();
						if ( isset( $schedules[ $interval ] ) ) {
							wp_schedule_event( time(), $interval, $cron_hook );
							if ( class_exists( 'Tpap_cronjob' ) && method_exists( 'Tpap_cronjob', 'tpap_send_data' ) ) {
								\Tpap_cronjob::tpap_send_data();
							}
						}
					}
				}
			} catch ( \Throwable $e ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Intentional debug logging when WP_DEBUG_LOG enabled.
					error_log( 'TPAP Opt-in Settings Error: ' . sanitize_text_field( $e->getMessage() ) );
				}
			}

			// 3) Save AI models (used by bulk translate).
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Settings nonce verified above.
			if ( isset( $_POST['tpap_ai_models'] ) && is_array( $_POST['tpap_ai_models'] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Settings nonce verified above.
				$raw_models = wp_unslash( $_POST['tpap_ai_models'] );
				$models     = array();
				foreach ( $raw_models as $provider_id => $model_id ) {
					if ( ! is_string( $provider_id ) ) {
						continue;
					}
					$provider_key = sanitize_key( (string) $provider_id );
					$models[ $provider_key ] = is_string( $model_id ) ? sanitize_text_field( $model_id ) : '';
				}
				$existing = get_option( 'tpap_ai_models', array() );
				$existing = is_array( $existing ) ? $existing : array();
				update_option( 'tpap_ai_models', array_merge( $existing, $models ) );
			}

			// 4) Save AI credentials when posted via legacy field name (kept for backward compatibility).
			// Note: the settings UI saves credentials via REST, so this is primarily a safety net.
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Settings nonce verified above.
			if ( isset( $_POST['tpap_ai_credentials'] ) && is_array( $_POST['tpap_ai_credentials'] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Settings nonce verified above.
				$raw_creds = wp_unslash( $_POST['tpap_ai_credentials'] );

				$existing_creds = get_option( self::WP_AI_CLIENT_OPTION_NAME, array() );
				$existing_creds = is_array( $existing_creds ) ? $existing_creds : array();
				$new_creds      = $existing_creds;

				foreach ( $raw_creds as $provider_id => $api_key ) {
					if ( ! is_string( $provider_id ) ) {
						continue;
					}
					$provider_key = sanitize_key( (string) $provider_id );
					$clean_key    = is_string( $api_key ) ? trim( sanitize_text_field( $api_key ) ) : '';

					if ( $clean_key === '' ) {
						unset( $new_creds[ $provider_key ] );
						continue;
					}

					$old_key = isset( $existing_creds[ $provider_key ] ) && is_string( $existing_creds[ $provider_key ] )
						? trim( (string) $existing_creds[ $provider_key ] )
						: '';

					if ( $old_key !== '' && $old_key === $clean_key ) {
						continue;
					}

					$result = $this->tpap_validate_provider_api_key( $provider_key, $clean_key );
					if ( $result === true ) {
						$new_creds[ $provider_key ] = $clean_key;
					}
				}

				$this->tpap_save_ai_keys( $new_creds );
			}
		}

		/*
		|-------------------------------------------------------
		|    Automatic Translate Addon For TranslatePress  admin page
		|-------------------------------------------------------
		*/
		function tpap_add_sub_menu() {
			add_options_page(
				__( 'AI Translation [TranslatePress]', 'automatic-translate-addon-pro-for-translatepress' ),
				__( 'AI Translation [TranslatePress]', 'automatic-translate-addon-pro-for-translatepress' ),
				'manage_options',
				$this->slug,
				array(
					$this,
					'tpap_dashboard_page',
				)
			);
		}

		/**
		 * Render the dashboard page with dynamic text domain support
		 * 
		 */
			function tpap_dashboard_page() {
				$file_prefix = 'admin/tpa-dashboard/views/';
				
				$valid_tabs = $this->tpap_get_valid_tabs();
				$buttons = $this->tpap_get_action_buttons();

				// Get current tab with fallback
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Tab read for display only; value sanitized.
				$tab 			= isset($_GET['tab']) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
				$current_tab 	= array_key_exists($tab, $valid_tabs) ? $tab : 'dashboard';
				
				// Start HTML output
				?>
				<div class="tpap-dashboard-wrapper">
					<div class="tpap-dashboard-header">
						<div class="tpap-dashboard-header-left">
							<img src="<?php echo esc_url(TPAP_URL . 'admin/tpa-dashboard/images/translatepress-addon.svg'); ?>" 
								alt="<?php esc_attr_e('TranslatePress Addon', 'automatic-translate-addon-pro-for-translatepress'); ?>">
							<div class="tpap-dashboard-tab-title">
								<span>↳</span> <?php echo esc_html($valid_tabs[$current_tab]); ?>
							</div>
						</div>
						<div class="tpap-dashboard-header-right">
							<span><?php esc_html_e('Auto translate pages and posts.', 'automatic-translate-addon-pro-for-translatepress'); ?></span>
							<?php foreach ($buttons as $button): ?>
								<a href="<?php echo esc_url($button['url']); ?>" 
								class="tpap-dashboard-btn" 
								target="_blank"
								aria-label="<?php echo isset($button['alt']) ? esc_attr($button['alt']) : ''; ?>">
									<?php if (isset($button['img'])): ?>
										<img src="<?php echo esc_url(TPAP_URL . 'admin/tpa-dashboard/images/' . $button['img']); ?>" 
											alt="<?php echo esc_attr($button['alt']); ?>">
									<?php endif; ?>
									<?php if (isset($button['text'])): ?>
										<span><?php echo esc_html($button['text']); ?></span>
									<?php endif; ?>
								</a>
							<?php endforeach; ?>
						</div>
					</div>
					
					<nav class="nav-tab-wrapper" aria-label="<?php esc_attr_e('Dashboard navigation', 'automatic-translate-addon-pro-for-translatepress'); ?>">
						<?php foreach ($valid_tabs as $tab_key => $tab_title): ?>
							<a href="?page=translatepress-tpap-dashboard&tab=<?php echo esc_attr($tab_key); ?>" 
							class="nav-tab <?php echo esc_attr($tab === $tab_key ? 'nav-tab-active' : ''); ?>">
								<?php echo esc_html($tab_title); ?>
							</a>
						<?php endforeach; ?>
					</nav>
				<?php
				?>
				<div class="tab-content">
					<?php
					require_once TPAP_PATH . $file_prefix . $tab . '.php';
					if($tab === 'license'){
						$licenseKey = get_option(self::OPTION_LICENSE_KEY,"");
						$liceEmail = get_option( self::OPTION_LICENSE_EMAIL,"");
						\AutomaticTranslateAddonForTranslatePressBase::add_on_delete(function(){
						   delete_option(self::OPTION_LICENSE_KEY);
						});
						if(\AutomaticTranslateAddonForTranslatePressBase::CheckWPPlugin($licenseKey,$liceEmail,$this->licenseMessage,$this->responseObj,__FILE__)){
							tpap_render_license_page_pro($this->responseObj);
						}else{
							tpap_render_license_page();
						}
					}
					require_once TPAP_PATH . $file_prefix . 'sidebar.php';
					?>
				</div>
				<?php require_once TPAP_PATH . $file_prefix . 'footer.php'; ?>
			</div>
		<?php
		}

		private function tpap_get_valid_tabs() {
			return [
				'dashboard'       => __('Dashboard', 'automatic-translate-addon-pro-for-translatepress'),
				'settings'        => __('Settings', 'automatic-translate-addon-pro-for-translatepress'),
				'license'         => __('License', 'automatic-translate-addon-pro-for-translatepress'),
				'ai-translations' => __('Documentation', 'automatic-translate-addon-pro-for-translatepress'),
			];
		}

		private function tpap_get_action_buttons() {
			return [
				[
					'url'  => 'https://coolplugins.net/products/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=view_plugin&utm_content=dashboard_header',
					'alt'  => __('Explore Cool Plugins', 'automatic-translate-addon-pro-for-translatepress'),
					'img'  => 'upgrade-now.svg',
					'text' => __('Explore Cool Plugins', 'automatic-translate-addon-pro-for-translatepress')
				],
				[
					'url' => 'https://docs.coolplugins.net/docs/automatic-translate-addon-for-translatepress-pro/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_header',
					'img' => 'document.svg',
					'alt' => __('document', 'automatic-translate-addon-pro-for-translatepress')
				],
				[
					'url' => 'https://coolplugins.net/support/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=support&utm_content=dashboard_header',
					'img' => 'contact.svg',
					'alt' => __('contact', 'automatic-translate-addon-pro-for-translatepress')
				]
			];
		}

		function tpap_handle_license_activation() {
			$this->tpap_check_user_capabilities();
			check_admin_referer('tpap-license');
			
			// Validate license key
			$license_key = !empty($_POST['license_code']) ? sanitize_text_field(wp_unslash($_POST['license_code'])) : '';
			if (empty($license_key)) {
				$this->tpap_redirect_with_error('missing_key');
				return;
			}
			
			// Validate email
			$license_email = !empty($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
			if (empty($license_email)) {
				$this->tpap_redirect_with_error('missing_email');
				return;
			}

			// Validate email format
			if (!is_email($license_email)) {
				$this->tpap_redirect_with_error('invalid_email');
				return;
			}
			
			if (!$this->tpap_is_valid_license_key($license_key)) {
				$this->tpap_redirect_with_error('invalid_format');
				return;
			}

			$error = '';
			$responseObj = null;
			
			if ($this->tpap_activate_license($license_key, $license_email, $error, $responseObj)) {
				update_option(self::OPTION_LICENSE_KEY, $license_key);
				update_option(self::OPTION_LICENSE_EMAIL, $license_email);
				delete_site_transient('update_plugins');
				$this->tpap_redirect_with_success();
			}
			
			// Map error message to error code
			$error_code = $this->tpap_map_error_to_code($error);
			$this->tpap_redirect_with_error($error_code);
		}

		private function tpap_check_user_capabilities() {
			if (!current_user_can('manage_options')) {
				wp_die( esc_html( __( 'You do not have sufficient permissions to access this page.', 'automatic-translate-addon-pro-for-translatepress' ) ) );
			}
		}

		private function tpap_activate_license($licenseKey, $licenseEmail, &$error, &$responseObj) {
			if (\AutomaticTranslateAddonForTranslatePressBase::CheckWPPlugin($licenseKey, $licenseEmail, $error, $responseObj, __FILE__)) {
				update_option(self::OPTION_LICENSE_KEY, $licenseKey);
				update_option(self::OPTION_LICENSE_EMAIL, $licenseEmail);
				delete_site_transient('update_plugins');
				return true;
			}
			return false;
		}

		private function tpap_redirect_with_success() {
			wp_safe_redirect(admin_url('admin.php?page=translatepress-tpap-dashboard&tab=license&activated=true'));
			exit;
		}

		private function tpap_redirect_with_error($error) {
			wp_safe_redirect(admin_url('admin.php?page=translatepress-tpap-dashboard&tab=license&error=' . urlencode($error)));
			exit;
		}

		function tpap_handle_license_deactivation() {
			try {
				// Check user capabilities
				if (!current_user_can('manage_options')) {
					wp_die( esc_html( __( 'You do not have sufficient permissions to access this page.', 'automatic-translate-addon-pro-for-translatepress' ) ) );
				}
				
				// Verify nonce
				check_admin_referer('tpap-license');
				
				// Get current license info
				$licenseKey = get_option(self::OPTION_LICENSE_KEY, '');
				
				// Match the base class name and file constant with the license.php file
				$message = '';
				if (\AutomaticTranslateAddonForTranslatePressBase::RemoveLicenseKey(__FILE__, $message)) {
					// Success - clean up using same option names as license.php
					delete_option('TranslatepressAutomaticTranslateAddonPro_lic_Key');
					delete_option('TranslatepressAutomaticTranslateAddonPro_lic_email');
					delete_site_transient('update_plugins');
					
					wp_safe_redirect(admin_url('admin.php?page=translatepress-tpap-dashboard&tab=license&deactivated=true'));
					exit;
				}
				
				wp_safe_redirect(admin_url('admin.php?page=translatepress-tpap-dashboard&tab=license&error=' . urlencode($message)));
				exit;
				
			} catch (\Exception $e) {
				wp_safe_redirect(admin_url('admin.php?page=translatepress-tpap-dashboard&tab=license&error=unexpected_error'));
				exit;
			}
		}

		
			/**
			 * Handle AJAX license refresh request
			 */
			function tpap_handle_refresh_license_ajax() {
				// Check nonce for security
				if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'tpap_refresh_license_nonce' ) ) {
					wp_send_json_error(array('message' => 'Security check failed.'));
					return;
				}

				$this->tpap_check_user_capabilities();
				
				// Get existing license key and email
				$license_key    = get_option(self::OPTION_LICENSE_KEY, '');
				$license_email  = get_option(self::OPTION_LICENSE_EMAIL, '');

				if (empty($license_key) || empty($license_email)) {
					wp_send_json_error(array('message' => 'No license information found to refresh.'));
					return;
				}

				$error = '';
				$responseObj = null;

				// Use the same activation logic to refresh the license
				if ($this->tpap_activate_license($license_key, $license_email, $error, $responseObj)) {
					
					// Get updated license information
					$license_info = array(
						'is_valid' => $responseObj->is_valid ? $responseObj->is_valid:false,
						'license_title' => $responseObj->license_title ? $responseObj->license_title : '',
						'expire_date' => $responseObj->expire_date ? $responseObj->expire_date : '',
						'market' => $responseObj->market ? $responseObj->market : '',
						'support_end' => $responseObj->support_end ? $responseObj->support_end : '',
					);
					
					
					wp_send_json_success(array(
						'message' => 'License Status Updated successfully!',
						'license_info' => $license_info,
						'version_available_message' => \TranslatePress_Addon_Pro::tpapGetVersionAvailableMessage()
					));
				} else {
					// Map error message to error code
					$error_code = $this->tpap_map_error_to_code($error);
					$error_message = $this->tpap_get_error_message($error_code);
					wp_send_json_error(array('message' => $error_message));
				}
		}

		private function tpap_is_valid_license_key($licenseKey) {
			// Define the pattern for the license key structure
			$pattern = '/^[0-9A-F][0-9A-F]{7}-[0-9A-F]{8}-[0-9A-F]{8}-[0-9A-F]{8}$/i';
			
			// Check if the license key matches the pattern
			return preg_match($pattern, $licenseKey) ? true : false;
		}

		// Add new method to display error messages
		public function tpap_display_license_error_messages() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET used for display only; values sanitized below.
			if ( isset( $_GET['page'] ) && sanitize_key( wp_unslash( $_GET['page'] ) ) === 'translatepress-tpap-dashboard' && isset( $_GET['tab'] ) && sanitize_key( wp_unslash( $_GET['tab'] ) ) === 'license' ) {
				// Display error message if exists
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET for display only; value sanitized.
				if ( isset( $_GET['error'] ) ) {
					// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET for display only; value sanitized.
					$error_message = $this->tpap_get_error_message( sanitize_text_field( wp_unslash( $_GET['error'] ) ) );
					?>
					<div class="notice notice-error is-dismissible">
						<p><?php echo esc_html($error_message); ?></p>
					</div>
					<?php
				}

				// Display success message
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET for display only; value sanitized.
				if ( isset( $_GET['activated'] ) && sanitize_text_field( wp_unslash( $_GET['activated'] ) ) === 'true' ) {
					?>
					<div class="notice notice-success is-dismissible">
						<p><?php esc_html_e( 'License activated successfully!', 'automatic-translate-addon-pro-for-translatepress' ); ?></p>
					</div>
					<?php
				}

				// Display deactivation message
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET for display only; value sanitized.
				if ( isset( $_GET['deactivated'] ) && sanitize_text_field( wp_unslash( $_GET['deactivated'] ) ) === 'true' ) {
					?>
					<div class="notice notice-info is-dismissible">
						<p><?php esc_html_e( 'License deactivated successfully!', 'automatic-translate-addon-pro-for-translatepress' ); ?></p>
					</div>
					<?php
				}

				// Display license message if exists
				if ($this->showMessage && !empty($this->licenseMessage)) {
					?>
					<div class="notice notice-error is-dismissible">
						<p><?php echo esc_html($this->licenseMessage); ?></p>
					</div>
					<?php
				}
			}
		}

		// Add new method to get error messages
		private function tpap_get_error_message($error_code) {
			$messages = array(
				'missing_key' => __('License key is required.', 'automatic-translate-addon-pro-for-translatepress'),
				'missing_email' => __('Email address is required.', 'automatic-translate-addon-pro-for-translatepress'),
				'invalid_email' => __('Please enter a valid email address.', 'automatic-translate-addon-pro-for-translatepress'),
				'invalid_format' => __('Invalid license key format. Please check your license key.', 'automatic-translate-addon-pro-for-translatepress'),
				'invalid_key' => __('Invalid license key. Please check your license key and try again.', 'automatic-translate-addon-pro-for-translatepress'),
				'expired' => __('Your license key has expired. Please renew your license.', 'automatic-translate-addon-pro-for-translatepress'),
				'disabled' => __('Your license key has been disabled.', 'automatic-translate-addon-pro-for-translatepress'),
				'no_activations' => __('License quota has been over, you can not add more domain with this license key.', 'automatic-translate-addon-pro-for-translatepress'),
				'refunded' => __('Your purchase key has been refunded.', 'automatic-translate-addon-pro-for-translatepress'),
				'wrong_license_status' => __('Your license key is inactive, has been refunded, or has exceeded the allowed domain limit.', 'automatic-translate-addon-pro-for-translatepress'),
				'domain_exceeded' => __('Your license key has exceeded the allowed domain limit.', 'automatic-translate-addon-pro-for-translatepress'),
				'default' => __('An error occurred while validating your license. Please try again.', 'automatic-translate-addon-pro-for-translatepress')
			);

			return isset($messages[$error_code]) ? $messages[$error_code] : $messages['default'];
		}

		// Add new method to map error messages to codes
		private function tpap_map_error_to_code($error) {
			$error = strtolower($error);
			if (strpos($error, 'invalid') !== false) {
				return 'invalid_key';
			} elseif (strpos($error, 'disabled') !== false || strpos($error, 'temporary inactivated') !== false || strpos($error, 'inactive_license') !== false) {
				return 'disabled';
			} elseif (strpos($error, 'license quota has been over') !== false || strpos($error, 'installed on another domain') !== false) {
				return 'no_activations';
			} elseif (strpos($error, 'refunded') !== false || strpos($error, 'refunded_license') !== false) {
				return 'refunded';
			} elseif (strpos($error, 'expired') !== false) {
				return 'expired';
			} elseif (strpos($error, 'wrong_license_status') !== false) {
				return 'wrong_license_status';
			} elseif (strpos($error, 'domain_exceeded') !== false) {
				return 'domain_exceeded';
			}
			return 'default';
		}
	}
}

new TranslatepressAutomaticTranslateAddonPro();
