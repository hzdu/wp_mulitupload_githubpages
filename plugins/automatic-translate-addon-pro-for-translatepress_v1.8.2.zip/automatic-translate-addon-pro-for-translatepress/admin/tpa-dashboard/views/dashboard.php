<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
    <div class="tpap-dashboard-left-section">
        
        <!-- Welcome Section -->
        <div class="tpap-dashboard-welcome">
            <div class="tpap-dashboard-welcome-text">
                <h2><?php echo esc_html__('Welcome To TranslatePress Addon', 'automatic-translate-addon-pro-for-translatepress'); ?></h2>
                <p><?php echo esc_html__('Translate WordPress Full Webpage instantly with TranslatePress Addon. One-click, thousands of strings - no extra cost!', 'automatic-translate-addon-pro-for-translatepress'); ?></p>
                <div class="tpap-dashboard-btns-row">
                    <a href="<?php echo esc_url(admin_url('options-general.php?page=translate-press')); ?>" target="_blank" class="tpap-dashboard-btn primary"><?php echo esc_html__('Website Languages', 'automatic-translate-addon-pro-for-translatepress'); ?></a>
                    <a href="<?php echo esc_url(site_url('/?trp-edit-translation=true')); ?>" target="_blank" class="tpap-dashboard-btn"><?php echo esc_html__('Translate Site', 'automatic-translate-addon-pro-for-translatepress'); ?></a>
                </div>
                <a class="tpap-dashboard-docs" href="<?php echo esc_url('https://docs.coolplugins.net/docs/automatic-translate-addon-for-translatepress-pro/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard'); ?>" target="_blank" rel="noopener noreferrer"><img src="<?php echo esc_url(TPAP_URL . 'admin/tpa-dashboard/images/document.svg'); ?>" alt="document"> <?php echo esc_html__('Read Plugin Docs', 'automatic-translate-addon-pro-for-translatepress'); ?></a>
            </div>
            <div class="tpap-dashboard-welcome-video">
                <a href="<?php echo esc_url('https://docs.coolplugins.net/doc/ai-translation-translatepress-video-tutorials/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_video'); ?>" target="_blank" class="tpap-dashboard-video-link" rel="noopener noreferrer">
                    <img decoding="async" src="<?php echo esc_url(TPAP_URL . 'admin/tpa-dashboard/images/video.svg'); ?>" class="play-icon" alt="play-icon">
                    <picture>
                        <source srcset="<?php echo esc_url(TPAP_URL . 'admin/tpa-dashboard/images/translatepress-addon-video.png'); ?>" type="image/avif">
                        <img src="<?php echo esc_url(TPAP_URL . 'admin/tpa-dashboard/images/translatepress-addon-video.jpg'); ?>" class="translatepress-addon-video" alt="translatepress addon preview">
                    </picture>
                </a>
            </div>
        </div>

        <!-- Translation Providers -->  
        <div class="tpap-dashboard-translation-providers">
            <h3><?php esc_html_e('Translation Providers', 'automatic-translate-addon-pro-for-translatepress'); ?></h3>
            <div class="tpap-dashboard-providers-grid">
                
                <?php
                $tpap_yandex_enabled = get_option('tpa_provider_yandex_enabled', '1');
                $tpap_chrome_enabled = get_option('tpa_provider_chrome_enabled', '1');
                $tpap_google_enabled = get_option('tpa_provider_google_enabled', '1');
                $tpap_anthropic_enabled = get_option('tpa_provider_anthropic_enabled', '1');
                $tpap_gemini_enabled = get_option('tpa_provider_gemini_enabled', '1');
                $tpap_openai_enabled = get_option('tpa_provider_openai_enabled', '1');
                $tpap_providers = [
                    [
                        "Chrome Built-in AI", 
                        "powered-by-chrome-api.png", 
                        [
                            esc_html__("Fast AI Translations in Browser", 'automatic-translate-addon-pro-for-translatepress'), 
                            esc_html__("Unlimited Free Translations", 'automatic-translate-addon-pro-for-translatepress'),
                            esc_html__("Bulk Translation", 'automatic-translate-addon-pro-for-translatepress')
                        ], 
                        'https://docs.coolplugins.net/docs/automatic-translate-addon-for-translatepress-pro/how-to-translate-your-website-content-automatically-via-chrome-ai/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_chrome',
                        $tpap_chrome_enabled
                    ],
                    [
                        "Google Translate", 
                        "powered-by-google.png", 
                        [
                            esc_html__("Unlimited Free Translations", 'automatic-translate-addon-pro-for-translatepress'), 
                            esc_html__("Fast & No API Key Required", 'automatic-translate-addon-pro-for-translatepress'),
                            esc_html__("Bulk Translation", 'automatic-translate-addon-pro-for-translatepress')
                        ], 
                        'https://docs.coolplugins.net/docs/automatic-translate-addon-for-translatepress-pro/how-to-translate-your-website-content-automatically-via-google/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_google',
                        $tpap_google_enabled
                    ],
                    [
                        "Yandex Translate", 
                        "powered-by-yandex.png", 
                        [
                            esc_html__("Unlimited Free Translations", 'automatic-translate-addon-pro-for-translatepress'), 
                            esc_html__("No API & No Extra Cost", 'automatic-translate-addon-pro-for-translatepress')
                        ], 
                        'https://docs.coolplugins.net/docs/automatic-translate-addon-for-translatepress-pro/how-to-translate-your-website-content-automatically-via-yandex/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_yandex',
                        $tpap_yandex_enabled
                    ],
                    [
                        "Anthropic Claude",
                        "powered-by-anthropic.png",
                        [
                            esc_html__("Unlimited Free Translations", 'automatic-translate-addon-pro-for-translatepress'), 
                            esc_html__("Use Translation Modals", 'automatic-translate-addon-pro-for-translatepress'),
                            esc_html__("Bulk Translation", 'automatic-translate-addon-pro-for-translatepress')
                        ], 
                        'https://docs.coolplugins.net/doc/generate-anthropic-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_anthropic',
                        $tpap_anthropic_enabled
                    ],
                    [
                        "Gemini",
                        "powered-by-google-gemini.png",
                        [
                            esc_html__("Unlimited Free Translations", 'automatic-translate-addon-pro-for-translatepress'), 
                            esc_html__("Use Translation Modals", 'automatic-translate-addon-pro-for-translatepress'),
                            esc_html__("Bulk Translation", 'automatic-translate-addon-pro-for-translatepress')
                        ], 
                        'https://docs.coolplugins.net/doc/generate-google-gemini-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_gemini',
                        $tpap_gemini_enabled
                    ],
                    [
                        "OpenAI",
                        "powered-by-openai.png",
                        [
                            esc_html__("Unlimited Free Translations", 'automatic-translate-addon-pro-for-translatepress'), 
                            esc_html__("Use Translation Modals", 'automatic-translate-addon-pro-for-translatepress'),
                            esc_html__("Bulk Translation", 'automatic-translate-addon-pro-for-translatepress')
                        ], 
                        'https://docs.coolplugins.net/doc/generate-open-ai-api-key-translatepress/?utm_source=tpa_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_openai',
                        $tpap_openai_enabled
                    ],
                ];

                foreach ($tpap_providers as $tpap_index => $tpap_provider) {
                    $tpap_provider_slug = strtolower(str_replace(' ', '-', $tpap_provider[0]));
                    $tpap_is_enabled = isset($tpap_provider[4]) ? $tpap_provider[4] : '1';
                    $tpap_is_checked = ($tpap_is_enabled === '1') ? 'checked' : '';
                    ?>
                    <div class="tpap-dashboard-provider-card">
                        <div class="tpap-dashboard-provider-header">
                            <a href="<?php echo esc_url($tpap_provider[3]); ?>" target="_blank" rel="noopener noreferrer">
                                <img src="<?php echo esc_url(TPAP_URL . 'assets/images/' . sanitize_file_name($tpap_provider[1])); ?>" 
                                     alt="<?php echo esc_attr(substr($tpap_provider[0], 0, 100)); ?>">
                            </a>
                            <?php
                                // Show switch only for providers that have an enabled state entry.
                                if ( isset( $tpap_provider[4] ) ) {
                            ?>
                            <div class="tpap-provider-switch-container">
                                <label class="tpap-provider-switch">
                                    <input type="checkbox" 
                                           class="tpap-provider-toggle" 
                                           data-provider="<?php echo esc_attr($tpap_provider_slug); ?>"
                                           <?php echo esc_attr( $tpap_is_checked ); ?>>
                                    <span class="tpap-switch-slider"></span>
                                </label>
                            </div>
                            <?php
                                }
                            ?>
                        </div>
                        <h4><?php echo esc_html(substr($tpap_provider[0], 0, 100)); ?></h4>
                        <ul>
                            <?php foreach ($tpap_provider[2] as $tpap_feature) { ?>
                                <li>✅ <?php echo esc_html($tpap_feature); ?></li>
                            <?php } ?>
                        </ul>
                        <div class="tpap-dashboard-provider-buttons">
                            <a href="<?php echo esc_url($tpap_provider[3]); ?>" class="tpap-dashboard-btn" target="_blank" rel="noopener noreferrer">
                                <?php echo esc_html__('Docs', 'automatic-translate-addon-pro-for-translatepress'); ?>
                            </a>
                            <?php if($tpap_provider[0] == "Chrome Built-in AI") { ?>
                                <a href="<?php echo esc_url(admin_url('options-general.php?page=translatepress-tpap-dashboard&tab=settings')); ?>" class="tpap-dashboard-btn primary tpap-chrome-configure-btn" style="<?php echo ($tpap_chrome_enabled == '1') ? '' : 'display:none;'; ?>">Configure</a>
                            <?php } ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>

