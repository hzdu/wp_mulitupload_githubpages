<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Automatic Language Detection settings (TPAP)
$tpap_ald_option_name = 'tpap_ald_settings';
$tpap_ald_defaults = array(
    'enabled' => 'no',
    'detection_method' => 'browser-ip',
);
$tpap_ald_settings = get_option( $tpap_ald_option_name, $tpap_ald_defaults );
$tpap_ald_settings = is_array( $tpap_ald_settings ) ? array_merge( $tpap_ald_defaults, $tpap_ald_settings ) : $tpap_ald_defaults;
$tpap_ald_enabled = isset( $tpap_ald_settings['enabled'] ) ? sanitize_text_field( (string) $tpap_ald_settings['enabled'] ) : 'no';
$tpap_ald_method = isset( $tpap_ald_settings['detection_method'] ) ? sanitize_key( (string) $tpap_ald_settings['detection_method'] ) : 'browser-ip';

// Initialize variables
$tpap_settings_updated = false;
$tpap_settings_error = false;
$tpap_error_message = '';

// Show success notice after redirect from options.php.
// phpcs:disable WordPress.Security.NonceVerification.Recommended
if ( current_user_can( 'manage_options' ) && isset( $_GET['settings-updated'] ) && 'true' === sanitize_text_field( wp_unslash( $_GET['settings-updated'] ) ) ) {
	$tpap_settings_updated = true;
}

// Check if TranslatePress has at least one translation language (for Chrome AI test section).
$tpap_trp_settings          = get_option( 'trp_settings', array() );
$tpap_default_lang          = isset( $tpap_trp_settings['default-language'] ) ? $tpap_trp_settings['default-language'] : '';
$tpap_publish_languages     = isset( $tpap_trp_settings['publish-languages'] ) && is_array( $tpap_trp_settings['publish-languages'] ) ? $tpap_trp_settings['publish-languages'] : array();
$tpap_translation_languages = isset( $tpap_trp_settings['translation-languages'] ) && is_array( $tpap_trp_settings['translation-languages'] ) ? $tpap_trp_settings['translation-languages'] : array();
$tpap_publish_languages     = count( array_diff( $tpap_publish_languages, array( $tpap_default_lang ) ) ) > 0 ? $tpap_publish_languages : $tpap_translation_languages;
$tpap_has_translation_langs = ! empty( $tpap_publish_languages ) && count( array_diff( $tpap_publish_languages, array( $tpap_default_lang ) ) ) > 0;
?>
<div class="tpap-dashboard-settings">
    <div class="tpap-dashboard-settings-container">
        
        <?php if ($tpap_settings_error): ?>
            <div class="notice notice-error is-dismissible">
                <p><?php echo esc_html($tpap_error_message); ?></p>
            </div>
        <?php endif; ?>

        <?php if(get_option('tpa_provider_chrome_enabled') == '1') : ?>
            <h2 class="tpap-section-title tpap-section-title-with-icon">
                <span class="tpap-section-icon tpap-icon-sparkle" aria-hidden="true">
                        <img
                            src="<?php echo esc_url( TPAP_URL . 'assets/images/single-page-chrome-translation.svg' ); ?>"
                            alt=""
                            width="20"
                            height="20"
                            loading="lazy"
                            decoding="async"
                        />
                    </span>
                <?php esc_html_e('Chrome AI Configuration', 'automatic-translate-addon-pro-for-translatepress'); ?>
            </h2>
            <p class="tpap-section-description">
                <?php esc_html_e('Use Chrome’s built-in AI to translate strings. Configure and test it here.', 'automatic-translate-addon-pro-for-translatepress'); ?>
            </p>
            <div class="tpap-dashboard-chrome-ai-settings">
                <!-- Chrome Local AI Notice -->
                <div id="tpap-chrome-local-ai-notice" class="tpap-chrome-local-ai-notice">
                    <?php if ( ! $tpap_has_translation_langs ) : ?>
                        <span class="tpap-chrome-no-languages-content"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" id="error"><g><rect fill="none"/></g><g><path d="M12 7c.55 0 1 .45 1 1v4c0 .55-.45 1-1 1s-1-.45-1-1V8c0-.55.45-1 1-1zm-.01-5C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm1-3h-2v-2h2v2z"></path></g></svg><?php
                            printf(
                                wp_kses_post(
									// translators: %s is a link to the TranslatePress settings page.
                                    __( 'Add at least %s to use the Chrome AI translation test', 'automatic-translate-addon-pro-for-translatepress' )
                                ),
                                '<a href="' . esc_url( admin_url( 'options-general.php?page=translate-press' ) ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'one language in TranslatePress', 'automatic-translate-addon-pro-for-translatepress' ) . '</a>'
                            );
                        ?></span>
                    <?php else : ?>
                    <div class="tpap-chrome-local-ai-notice-content">
                        <h3 id="tpap-chrome-notice-heading" class="tpap-chrome-notice-heading"></h3>
                        <div id="tpap-chrome-notice-message" class="tpap-chrome-notice-message"></div>
                    </div>
                    
                    <!-- Test Translation Section -->
                    <div id="tpap-chrome-test-translation" class="tpap-chrome-test-translation">
                        <h3 class="tpap-chrome-test-translation-heading"><?php esc_html_e('Chrome AI Translation Test', 'automatic-translate-addon-pro-for-translatepress'); ?></h3>
                        <p class="tpap-chrome-test-translation-description"><?php esc_html_e('Check whether Chrome AI Translation is properly configured by translating a sample text.', 'automatic-translate-addon-pro-for-translatepress'); ?></p>
                        
                        <div class="tpap-chrome-test-translation-language-pair">
                            <label class="tpap-chrome-test-translation-label"><?php esc_html_e('Language Pair:', 'automatic-translate-addon-pro-for-translatepress'); ?></label>
                            <select id="tpap-test-translation-source" class="tpap-chrome-test-translation-source"></select>
                            <span class="tpap-chrome-test-translation-arrow">→</span>
                            <select id="tpap-test-translation-target" class="tpap-chrome-test-translation-target"></select>
                        </div>
                        
                        <button id="tpap-test-translation-btn" class="tpap-dashboard-btn primary tpap-chrome-test-translation-btn">
                            <?php esc_html_e('Test Translation', 'automatic-translate-addon-pro-for-translatepress'); ?>
                        </button>
                        
                        <div id="tpap-test-translation-result" class="tpap-chrome-test-translation-result"></div>
                        <div id="tpap-test-translation-error" class="tpap-chrome-test-translation-error"></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <form action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>" method="post" class="tpap-dashboard-settings-form tpap-settings-form">
            <?php 
                // Nonce for TPAP feedback opt‑in.
                wp_nonce_field( 'tpap_save_optin_settings', 'tpap_optin_nonce' );

                // Settings API fields for TPAP options (ALD etc).
                settings_fields( 'tpap-settings' );

                // NOTE: Keep this value available for conditional UI below if needed.
                $tpap_display_opt_in = sanitize_text_field( get_option( 'cpfm_opt_in_choice_cool_translations', '' ) );
            ?>

            <?php if ( get_option( 'tpa_provider_gemini_enabled' ) == '1' || get_option( 'tpa_provider_openai_enabled' ) == '1' || get_option( 'tpa_provider_anthropic_enabled' ) == '1' ) : ?>
                <div class="tpap-bulk-translation-section tpap-ai-credentials-section">
                    <h2 class="tpap-section-title tpap-section-title-with-icon">
                        <span class="tpap-section-icon tpap-icon-key" aria-hidden="true">
                            <img
                                src="<?php echo esc_url( TPAP_URL . 'assets/images/API-key-icon.svg' ); ?>"
                                alt=""
                                width="24"
                                height="24"
                                loading="lazy"
                                decoding="async"
                            />
                        </span>
                        <?php esc_html_e( 'AI API Keys & Models', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                    </h2>
                    <p class="tpap-ai-credentials-description">
                        <?php esc_html_e( 'Add your API credentials to connect AI services to your site for bulk translation.', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                    </p>
                    <div id="tpap-ai-settings-validation-notice" class="notice notice-error" style="margin: 1rem 0; display: none;" role="alert">
                        <p></p>
                    </div>
                    <?php
                    // Existing credentials and model choices.
                    $tpap_ai_credentials = get_option( 'wp_ai_client_provider_credentials', array() );
                    $tpap_ai_credentials = is_array( $tpap_ai_credentials ) ? $tpap_ai_credentials : array();
                    // On WP 7.0+, keys may be stored in connectors options. Prefer those for display.
                    if ( function_exists( 'wp_ai_client_prompt' ) || function_exists( '_wp_register_default_connector_settings' ) ) {
                        foreach ( array( 'openai', 'google', 'anthropic' ) as $tpap_provider ) {
                            $tpap_connector_key = get_option( 'connectors_ai_' . $tpap_provider . '_api_key', '' );
                            if ( is_string( $tpap_connector_key ) && $tpap_connector_key !== '' ) {
                                $tpap_ai_credentials[ $tpap_provider ] = $tpap_connector_key;
                            }
                        }
                    }

                    $tpap_ai_models = get_option( 'tpap_ai_models', array() );
                    $tpap_ai_models = is_array( $tpap_ai_models ) ? $tpap_ai_models : array();

                    // Normalize keys, current model selection, and discovered models per provider.
                    $tpap_providers = array(
                        'anthropic' => array(
                            'label'            => __( 'Anthropic (Claude)', 'automatic-translate-addon-pro-for-translatepress' ),
                            'description'      => __( ' to see how to configure Anthropic and manage API keys.', 'automatic-translate-addon-pro-for-translatepress' ),
                            'default_model'    => 'claude-3-haiku-20240307',
                            'model_label'      => __( 'Claude model', 'automatic-translate-addon-pro-for-translatepress' ),
                            'models'           => array(),
                            'current_model'    => '',
                            'api_key'          => '',
                            'api_key_label'    => 'anthropic',
                            'enabled'          => get_option( 'tpa_provider_anthropic_enabled' ) == '1' ? true : false,
                            'provider_url'     => 'https://console.anthropic.com',
                            'console_url'      => 'https://console.anthropic.com',
                            'console_label'    => 'console.anthropic.com',
                        ),
                        'google'    => array(
                            'label'            => __( 'Google Gemini', 'automatic-translate-addon-pro-for-translatepress' ),
                            'description'      => __( ' to see how to configure Gemini and manage API keys.', 'automatic-translate-addon-pro-for-translatepress' ),
                            'default_model'    => 'gemini-2.5-flash',
                            'model_label'      => __( 'Gemini model', 'automatic-translate-addon-pro-for-translatepress' ),
                            'models'           => array(),
                            'current_model'    => '',
                            'api_key'          => '',
                            'api_key_label'    => 'google',
                            'enabled'          => get_option( 'tpa_provider_gemini_enabled' ) == '1' ? true : false,
                            'provider_url'     => 'https://aistudio.google.com/app/api-keys',
                            'console_url'      => 'https://aistudio.google.com/app/api-keys',
                            'console_label'    => 'aistudio.google.com',
                        ),
                        'openai'    => array(
                            'label'            => __( 'OpenAI', 'automatic-translate-addon-pro-for-translatepress' ),
                            'description'      => __( ' to see how to configure OpenAI and manage API keys.', 'automatic-translate-addon-pro-for-translatepress' ),
                            'default_model'    => 'gpt-4o-mini',
                            'model_label'      => __( 'OpenAI model', 'automatic-translate-addon-pro-for-translatepress' ),
                            'models'           => array(),
                            'current_model'    => '',
                            'api_key'          => '',
                            'api_key_label'    => 'openai',
                            'enabled'          => get_option( 'tpa_provider_openai_enabled' ) == '1' ? true : false,
                            'provider_url'     => 'https://platform.openai.com/api-keys',
                            'console_url'      => 'https://platform.openai.com/api-keys',
                            'console_label'    => 'platform.openai.com',
                        ),
                    );

                    foreach ( $tpap_providers as $tpap_provider_id => &$tpap_provider_config ) {
                        $tpap_key_from_option = isset( $tpap_ai_credentials[ $tpap_provider_id ] ) && is_string( $tpap_ai_credentials[ $tpap_provider_id ] )
                            ? $tpap_ai_credentials[ $tpap_provider_id ]
                            : '';

                        $tpap_provider_config['api_key'] = $tpap_key_from_option;

                        $tpap_model_from_option = isset( $tpap_ai_models[ $tpap_provider_id ] ) && is_string( $tpap_ai_models[ $tpap_provider_id ] ) && $tpap_ai_models[ $tpap_provider_id ] !== ''
                            ? $tpap_ai_models[ $tpap_provider_id ]
                            : $tpap_provider_config['default_model'];

                        $tpap_provider_config['current_model'] = $tpap_model_from_option;
                    }
                    unset( $tpap_provider_config );

                    // Discover available models per provider using WP AI Client, when available.
                    if (
                        class_exists( '\WordPress\AiClient\AiClient' ) &&
                        class_exists( '\WordPress\AiClient\Providers\Models\DTO\ModelRequirements' ) &&
                        class_exists( '\WordPress\AiClient\Providers\Models\Enums\CapabilityEnum' )
                    ) {
                        try {
                            $tpap_registry     = \WordPress\AiClient\AiClient::defaultRegistry();
                            $tpap_requirements = new \WordPress\AiClient\Providers\Models\DTO\ModelRequirements(
                                array( \WordPress\AiClient\Providers\Models\Enums\CapabilityEnum::textGeneration() ),
                                array()
                            );

                            // Helper closure to load models for a provider and filter out obviously non-translation models.
                            $tpap_load_models = static function ( $tpap_provider_id ) use ( $tpap_registry, $tpap_requirements ) {
                                try {
                                    $models_metadata = $tpap_registry->findProviderModelsMetadataForSupport( $tpap_provider_id, $tpap_requirements );
                                    $ids             = array();
                                    if ( is_array( $models_metadata ) ) {
                                        foreach ( $models_metadata as $model ) {
                                            if ( is_object( $model ) && method_exists( $model, 'getId' ) ) {
                                                $ids[] = $model->getId();
                                            }
                                        }
                                    }
                                    if ( empty( $ids ) ) {
                                        return array();
                                    }
                                    $excluded_patterns = array(
                                        'audio',
                                        'transcribe',
                                        'search',
                                        'vision',
                                        'embedding',
                                        'image',
                                        'code',
                                        'whisper',
                                        'tts',
                                    );
                                    $filtered = array();
                                    foreach ( $ids as $id ) {
                                        $lower = strtolower( $id );
                                        $skip  = false;
                                        foreach ( $excluded_patterns as $pattern ) {
                                            if ( strpos( $lower, $pattern ) !== false ) {
                                                $skip = true;
                                                break;
                                            }
                                        }
                                        if ( ! $skip ) {
                                            $filtered[] = $id;
                                        }
                                    }
                                    return $filtered;
                                } catch ( \Throwable $e ) {
                                    return array();
                                }
                            };

                            // Discover models for each provider that has a key.
                            foreach ( $tpap_providers as $tpap_provider_id => &$tpap_provider_config ) {
                                $tpap_api_key = isset( $tpap_provider_config['api_key'] ) ? (string) $tpap_provider_config['api_key'] : '';
                                if ( $tpap_api_key === '' ) {
                                    continue;
                                }
                                $tpap_models = $tpap_load_models( $tpap_provider_id );
                                $tpap_provider_config['models'] = is_array( $tpap_models ) ? $tpap_models : array();
                            }
                            unset( $tpap_provider_config );
                        } catch ( \Throwable $e ) {
                            foreach ( $tpap_providers as &$tpap_provider_config ) {
                                $tpap_provider_config['models'] = array();
                            }
                            unset( $tpap_provider_config );
                        }
                    }

                    // Fallback defaults when discovery fails but a key exists.
                    foreach ( $tpap_providers as $tpap_provider_id => &$tpap_provider_config ) {
                        $tpap_has_key = isset( $tpap_provider_config['api_key'] ) && is_string( $tpap_provider_config['api_key'] ) && $tpap_provider_config['api_key'] !== '';
                        if ( $tpap_has_key && empty( $tpap_provider_config['models'] ) ) {
                            $tpap_provider_config['models'] = array( $tpap_provider_config['default_model'] );
                        }
                    }
                    unset( $tpap_provider_config );

					if ( ! function_exists( 'tpap_mask_api_key' ) ) {
						/**
						 * Mask an API key for safe display in settings UI.
						 *
						 * @param string $api_key Raw API key.
						 * @return string Masked key.
						 */
						function tpap_mask_api_key( $api_key ) {
							if ( empty( $api_key ) ) {
								return $api_key;
							}
							if ( strpos( $api_key, '*' ) !== false || strpos( $api_key, '•' ) !== false ) {
								return $api_key;
							}
							if ( strlen( $api_key ) < 12 ) {
								return $api_key;
							}
							$start         = substr( $api_key, 0, 6 );
							$end           = substr( $api_key, -6 );
							$middle_length = strlen( $api_key ) - 12;
							$masked_middle = str_repeat( '*', min( max( $middle_length, 0 ), 24 ) );
							return $start . $masked_middle . $end;
						}
					}
                    ?>

                    <div class="tpap-ai-provider-list">
                        <?php foreach ( $tpap_providers as $tpap_provider_id => $tpap_provider_config ) : ?>
                            <?php if ( $tpap_provider_config['enabled'] ) : ?>
                            <div class="tpap-ai-provider-card">
                                <h3 class="tpap-ai-provider-title">
                                    <?php echo esc_html( $tpap_provider_config['label'] ); ?>
                                </h3>
								<?php
								$tpap_has_existing_key = isset( $tpap_provider_config['api_key'] ) && is_string( $tpap_provider_config['api_key'] ) && $tpap_provider_config['api_key'] !== '';
								$tpap_masked_key       = $tpap_has_existing_key ? tpap_mask_api_key( $tpap_provider_config['api_key'] ) : '';
								?>
                                <input
                                    type="text"
                                    id="tpap-<?php echo esc_attr( $tpap_provider_id ); ?>-api-key"
                                    name="wp_ai_client_provider_credentials[<?php echo esc_attr( $tpap_provider_id ); ?>]"
                                    value="<?php echo $tpap_has_existing_key ? esc_attr( $tpap_masked_key ) : ''; ?>"
									placeholder="<?php echo $tpap_has_existing_key ? '' : esc_attr__( 'Paste API key…', 'automatic-translate-addon-pro-for-translatepress' ); ?>"
                                    autocomplete="new-password"
                                    class="regular-text tpap-api-key-input"
                                    data-provider="<?php echo esc_attr( $tpap_provider_id ); ?>"
									data-has-key="<?php echo $tpap_has_existing_key ? '1' : '0'; ?>"
									data-original-masked="<?php echo $tpap_has_existing_key ? esc_attr( $tpap_masked_key ) : ''; ?>"
                                />
                                <div
                                    id="tpap-ai-settings-message-<?php echo esc_attr( $tpap_provider_id ); ?>"
                                    class="tpap-ai-settings-message"
                                    style="margin-top: 4px; margin-bottom: 12px; display: none; color: #b32d2e; font-size: 13px;"
                                    role="alert"
                                ></div>

                                <?php if ( ! empty( $tpap_provider_config['models'] ) ) : ?>
                                    <?php
                                    $tpap_display_models = array_combine(
                                        $tpap_provider_config['models'],
                                        $tpap_provider_config['models']
                                    );
                                    ?>
                                    <div class="tpap-ai-provider-model">
                                        <label
                                            for="tpap-<?php echo esc_attr( $tpap_provider_id ); ?>-model"
                                            class="tpap-ai-model-inline-label"
                                        >
                                            <?php echo esc_html( $tpap_provider_config['model_label'] ); ?>
                                        </label>
                                        <select
                                            id="tpap-<?php echo esc_attr( $tpap_provider_id ); ?>-model"
                                            name="tpap_ai_models[<?php echo esc_attr( $tpap_provider_id ); ?>]"
                                            class="tpap-ai-model-select"
                                        >
                                            <?php foreach ( $tpap_display_models as $tpap_model_id => $tpap_model_label ) : ?>
                                                <option
                                                    value="<?php echo esc_attr( $tpap_model_id ); ?>"
                                                    <?php selected( $tpap_provider_config['current_model'], $tpap_model_id ); ?>
                                                >
                                                    <?php echo esc_html( $tpap_model_label ); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php endif; ?>
                                <p class="tpap-ai-provider-description description">
                                    <?php
                                    $tpap_console_url   = isset( $tpap_provider_config['console_url'] ) ? $tpap_provider_config['console_url'] : $tpap_provider_config['provider_url'];
                                    echo wp_kses(
                                        '<a class="tpap-ai-console-link" href="' . esc_url( $tpap_console_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Click here', 'automatic-translate-addon-pro-for-translatepress' ) . '</a>',
                                        array(
                                            'a' => array(
                                                'class' => array(),
                                                'href' => array(),
                                                'target' => array(),
                                                'rel' => array(),
                                            ),
                                        )
                                    );
                                    echo esc_html( $tpap_provider_config['description'] ) . ' ';
                                    ?>
                                </p>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>

                        <?php if ( get_option( 'tpap_ai_credentials_migrated_to_wp70' ) ) : ?>
						<div class="tpap-ai-connectors-note">
							<p>
								<em>
									<?php esc_html_e(
										'Note: API keys configured here are linked with the',
										'automatic-translate-addon-pro-for-translatepress'
									); ?>
									<a href="<?php echo esc_url( admin_url( 'options-connectors.php' ) ); ?>" target="_blank" rel="noopener noreferrer">
										<strong>
											<?php esc_html_e( 'Settings → Connectors', 'automatic-translate-addon-pro-for-translatepress' ); ?>
										</strong>
									</a>
									<?php esc_html_e(
										' in WordPress.',
										'automatic-translate-addon-pro-for-translatepress'
									); ?>
								</em>
							</p>
						</div>
					<?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            <div class="tpap-bulk-translation-section tpap-ald-section">
                <h2 class="tpap-section-title tpap-section-title-with-icon">
                    <span class="tpap-section-icon tpap-icon-sparkle" aria-hidden="true">
                        <img
                            src="<?php echo esc_url( TPAP_URL . 'assets/images/language-detection.svg' ); ?>"
                            alt=""
                            width="24"
                            height="24"
                            loading="lazy"
                            decoding="async"
                        />
                    </span>
                    <?php esc_html_e( 'Automatic Language Detection', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                </h2>
                <p class="tpap-ald-description description">
                    <?php esc_html_e( 'Display a small floating suggestion to help visitors switch to their preferred language.', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                </p>

                <div class="tpap-ald-options">
                    <div class="tpap-ald-toggle-row">
                        <input type="hidden" name="<?php echo esc_attr( $tpap_ald_option_name ); ?>[enabled]" value="no" />
                        <label for="tpap-ald-enabled" class="tpap-ald-toggle-label">
                            <input
                                type="checkbox"
                                id="tpap-ald-enabled"
                                name="<?php echo esc_attr( $tpap_ald_option_name ); ?>[enabled]"
                                value="yes"
                                <?php checked( $tpap_ald_enabled, 'yes' ); ?>
                            />
                            <span class="tpap-ald-toggle-text"><?php esc_html_e( 'Enable language suggestion', 'automatic-translate-addon-pro-for-translatepress' ); ?></span>
                        </label>
                    </div>

                    <div id="tpap-ald-method-wrap" class="tpap-ald-method-wrap">
                        <label for="tpap-ald-detection-method" class="tpap-ald-method-label"><?php esc_html_e( 'Detection method', 'automatic-translate-addon-pro-for-translatepress' ); ?></label>
                        <select
                            id="tpap-ald-detection-method"
                            name="<?php echo esc_attr( $tpap_ald_option_name ); ?>[detection_method]"
                            class="tpap-ald-select"
                        >
                            <option value="browser-ip" <?php selected( $tpap_ald_method, 'browser-ip' ); ?>>
                                <?php esc_html_e( 'Browser first, then IP (recommended)', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                            </option>
                            <option value="ip-browser" <?php selected( $tpap_ald_method, 'ip-browser' ); ?>>
                                <?php esc_html_e( 'IP first, then browser', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                            </option>
                            <option value="browser" <?php selected( $tpap_ald_method, 'browser' ); ?>>
                                <?php esc_html_e( 'Browser language only', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                            </option>
                            <option value="ip" <?php selected( $tpap_ald_method, 'ip' ); ?>>
                                <?php esc_html_e( 'IP address only', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                            </option>
                        </select>
                        <p class="tpap-ald-tip description">
                            <?php esc_html_e( 'Tip: With Cloudflare, IP detection uses the visitor country header automatically.', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                        </p>
                    </div>
                </div>
            </div>

            <?php if ( $tpap_display_opt_in ) : ?>
            <div class="tpap-dashboard-feedback-container">
                <h3 class="tpap-section-title">
                    <?php esc_html_e( 'Usage Data Sharing', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                </h3>
                <div class="feedback-row">
                    <input
                        type="checkbox"
                        id="tpap-dashboard-feedback-checkbox"
                        name="tpap-dashboard-feedback-checkbox"
						<?php
						checked(get_option('tpa_feedback_opt_in'), 'yes');
						?>
                    >
                    <p><?php esc_html_e( 'Help us make this plugin more compatible with your site by sharing non-sensitive site data.', 'automatic-translate-addon-pro-for-translatepress' ); ?></p>
                    <a href="#" class="tpap-see-terms"><?php esc_html_e( '[See terms]', 'automatic-translate-addon-pro-for-translatepress' ); ?></a>
                </div>
                <div id="termsBox" class="tpap-terms-box">
                    <p>
						<?php esc_html_e( "Opt in to receive email updates about security improvements, new features, helpful tutorials, and occasional special offers. We'll collect:", 'automatic-translate-addon-pro-for-translatepress' ); ?>
                        <a href="https://my.coolplugins.net/terms/usage-tracking/" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Click here', 'automatic-translate-addon-pro-for-translatepress' ); ?></a>
                    </p>
                    <ul class="tpap-terms-box-list">
                        <li><?php esc_html_e( 'Your website home URL and WordPress admin email.', 'automatic-translate-addon-pro-for-translatepress' ); ?></li>
                        <li><?php esc_html_e( 'To check plugin compatibility, we will collect the following: list of active plugins and themes, server type, MySQL version, WordPress version, memory limit, site language and database prefix.', 'automatic-translate-addon-pro-for-translatepress' ); ?></li>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
            <div class="tpap-dashboard-save-settings">
                <button type="submit" class="tpap-dashboard-btn primary save-settings-btn">
                    <?php esc_html_e( 'Save Changes', 'automatic-translate-addon-pro-for-translatepress' ); ?>
                </button>
            </div>
        </form>
    </div>
</div>