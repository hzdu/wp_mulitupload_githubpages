<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- Right Sidebar -->
<div class="tpap-dashboard-sidebar">
    <div class="tpap-dashboard-status">
        <h3><?php esc_html_e('Auto Translation status', 'automatic-translate-addon-pro-for-translatepress'); ?></h3>
        <div class="tpap-dashboard-sts-top">
            <?php
            // Security: Sanitize data from database
            $tpap_all_data = get_option('cpt_dashboard_data', array());

            if (!is_array($tpap_all_data) || !isset($tpap_all_data['tpa'])) {

                $tpap_all_data['tpa'] = []; // Ensure $tpap_all_data['tpa'] is an array

            }

            $totals = array_reduce($tpap_all_data['tpa'] ?? [], function($carry, $translation) {
                // Ensure $translation['string_count'] is numeric
                // Ensure all values are properly handled
                $carry['string_count'] += intval($translation['string_count'] ?? 0);
                $carry['character_count'] += intval($translation['character_count'] ?? 0);
                $carry['time_taken'] += intval($translation['time_taken'] ?? 0);
                
                // Count total translations instead of unique post IDs
                if (!empty($translation['post_id'])) {
                    $carry['translation_count']++;
                }
                return $carry;
            }, ['string_count' => 0, 'character_count' => 0, 'time_taken' => 0, 'translation_count' => 0]);
            // Update the time taken string using the new function
            $tpap_time_taken_str = tpap_format_time_taken($totals['time_taken']);
            ?>
            <span><?php echo esc_html(tpap_format_number($totals['string_count'], 'automatic-translate-addon-pro-for-translatepress')); ?></span>
            <span><?php esc_html_e('Total Strings Translated!', 'automatic-translate-addon-pro-for-translatepress'); ?></span>
        </div>
        <ul class="tpap-dashboard-sts-btm">
            <li><span><?php esc_html_e('Total Characters', 'automatic-translate-addon-pro-for-translatepress'); ?></span> <span><?php echo esc_html(tpap_format_number($totals['character_count'], 'automatic-translate-addon-pro-for-translatepress')); ?></span></li>
            <li><span><?php esc_html_e('Total Pages / Posts', 'automatic-translate-addon-pro-for-translatepress'); ?></span> <span><?php echo esc_html($totals['translation_count']); ?></span></li>
            <li><span><?php esc_html_e('Time Taken', 'automatic-translate-addon-pro-for-translatepress'); ?></span> <span><?php echo esc_html($tpap_time_taken_str); ?></span></li>
        </ul>
    </div>
    <div class="tpap-dashboard-translate-full">
        <h3><?php esc_html_e('Automatically Translate Plugins & Themes', 'automatic-translate-addon-pro-for-translatepress'); ?></h3>
        <div class="tpap-dashboard-addon first">
            <div class="tpap-dashboard-addon-l">
                <strong><?php echo esc_html(tpap_get_plugin_display_name('automatic-translator-addon-for-loco-translate', 'automatic-translate-addon-pro-for-translatepress')); ?></strong>
                <span class="addon-desc"><?php esc_html_e('LocoAI to translate plugins and themes.', 'automatic-translate-addon-pro-for-translatepress'); ?></span>
                <?php
                    if ( ! function_exists( 'is_plugin_active' ) ) {
                        require_once ABSPATH . 'wp-admin/includes/plugin.php';
                    }
                    $tpap_tw_plugin_file = 'automatic-translator-addon-for-loco-translate/automatic-translator-addon-for-loco-translate.php';
                    $tpap_tw_pro_plugin_file = 'loco-automatic-translate-addon-pro/loco-automatic-translate-addon-pro.php';
                    $tpap_tw_installed   = tpap_is_plugin_installed( 'automatic-translator-addon-for-loco-translate' );
                    $tpap_tw_active      = false;
                    if ( function_exists( 'is_plugin_active' ) ) {
                        $tpap_tw_active = is_plugin_active( $tpap_tw_plugin_file ) || is_plugin_active( $tpap_tw_pro_plugin_file );
                    }
                ?>

                <?php if ( $tpap_tw_installed && $tpap_tw_active ): ?>
                    <span class="installed"><?php esc_html_e('Activated', 'automatic-translate-addon-pro-for-translatepress'); ?></span>
                <?php else: ?>
                    <button
                        type="button"
                        class="tpap-dashboard-btn tpap-install-plugin"
                        data-slug="automatic-translator-addon-for-loco-translate"
                        data-nonce="<?php echo esc_attr( wp_create_nonce( 'tpap_install_nonce' ) ); ?>"
                    >
                        <?php echo esc_html( $tpap_tw_installed ? __( 'Activate', 'automatic-translate-addon-pro-for-translatepress' ) : __( 'Install', 'automatic-translate-addon-pro-for-translatepress' ) ); ?>
                    </button>
                    <div class="tpap-install-message" aria-live="polite" style="margin-top:8px;"></div>
                <?php endif; ?>
            </div>
            <div class="tpap-dashboard-addon-r">
                <img src="<?php echo esc_url(TPAP_URL . 'admin/tpa-dashboard/images/atlt-logo.png'); ?>" alt="<?php esc_attr_e('TranslatePress Addon', 'automatic-translate-addon-pro-for-translatepress'); ?>">
            </div>
        </div>
    </div>
    <div class="tpap-dashboard-rate-us">
        <h3><?php esc_html_e('Rate Us ⭐⭐⭐⭐⭐', 'automatic-translate-addon-pro-for-translatepress'); ?></h3>
        <p><?php esc_html_e('We\'d love your feedback! Hope this addon made auto-translations easier for you.', 'automatic-translate-addon-pro-for-translatepress'); ?></p>
        <a href="<?php echo esc_url('https://wordpress.org/support/plugin/automatic-translate-addon-for-translatepress/reviews/#new-post'); ?>" class="review-link" target="_blank"><?php esc_html_e('Submit a Review →', 'automatic-translate-addon-pro-for-translatepress'); ?></a>
    </div>
</div>

<?php

function tpap_format_time_taken($time_taken) {
    // Security: Sanitize and validate inputs
    $time_taken = absint($time_taken); // Ensure positive integer
    
    if ($time_taken === 0) return esc_html__('0', 'automatic-translate-addon-pro-for-translatepress');
    if ($time_taken < 60) {
        return sprintf(
            /* translators: %d: time taken in seconds */ 
            esc_html__('%d sec', 'automatic-translate-addon-pro-for-translatepress'), $time_taken
        );
    }
    if ($time_taken < 3600) {
        $min = floor($time_taken / 60);
        $sec = $time_taken % 60;
        return sprintf(
            /* translators: %1$d: minutes, %2$d: seconds */ 
            esc_html__('%1$d min %2$d sec', 'automatic-translate-addon-pro-for-translatepress'), $min, $sec
        );
    }
    $hours = floor($time_taken / 3600);
    $min = floor(($time_taken % 3600) / 60);
    return sprintf(
        /* translators: %1$d: hours, %2$d: minutes */ 
        esc_html__('%1$d hours %2$d min', 'automatic-translate-addon-pro-for-translatepress'), $hours, $min
    );
}

function tpap_is_plugin_installed($plugin_slug) {
    // Security: Sanitize and validate plugin slug
    $plugin_slug = sanitize_key($plugin_slug);
    $plugins = get_plugins();
    
    // Check if the plugin is installed
    if ($plugin_slug === 'automatic-translator-addon-for-loco-translate') {
        return isset($plugins['automatic-translator-addon-for-loco-translate/automatic-translator-addon-for-loco-translate.php']) || isset($plugins['loco-automatic-translate-addon-pro/loco-automatic-translate-addon-pro.php']);
    }

    return false; // Return false if no match found
}

function tpap_get_plugin_display_name($plugin_slug) {
    if ( ! function_exists( 'is_plugin_active' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $plugins = get_plugins();

    // Define free and pro plugin paths
    $plugin_paths = [
        'automatic-translator-addon-for-loco-translate' => [
            'free' => 'automatic-translator-addon-for-loco-translate/automatic-translator-addon-for-loco-translate.php',
            'pro'  => 'loco-automatic-translate-addon-pro/loco-automatic-translate-addon-pro.php',
            'free_name' => esc_html__('LocoAI – Auto Translate for Loco Translate', 'automatic-translate-addon-pro-for-translatepress'),
            'pro_name'  => esc_html__('LocoAI – Auto Translate for Loco Translate (Pro)', 'automatic-translate-addon-pro-for-translatepress'),
        ]
    ];

    // Check if the provided plugin slug exists
    if (!isset($plugin_paths[$plugin_slug])) {
        return $plugin_slug;
    }

    $path_info = $plugin_paths[$plugin_slug];

    // 1. Check if Pro is active
    if (isset($path_info['pro']) && is_plugin_active($path_info['pro'])) {
        return $path_info['pro_name'];
    }

    // 2. Check if Free is active
    if (isset($path_info['free']) && is_plugin_active($path_info['free'])) {
        return $path_info['free_name'];
    }

    // 3. Fallback to installed check if neither is active
    $pro_installed = isset($path_info['pro']) && isset($plugins[$path_info['pro']]);
    
    if ($pro_installed) {
        return $path_info['pro_name'];
    }

    return $path_info['free_name'] ?? $plugin_slug;
}

function tpap_format_number($number) {
    // Security: Sanitize and validate inputs
    $number = absint($number); // Ensure positive integer
    
    if ($number >= 1000000000) {
        return round($number / 1000000000, 1) . esc_html__('B', 'automatic-translate-addon-pro-for-translatepress');
    } elseif ($number >= 1000000) {
        return round($number / 1000000, 1) . esc_html__('M', 'automatic-translate-addon-pro-for-translatepress');
    } elseif ($number >= 1000) {
        return round($number / 1000, 1) . esc_html__('K', 'automatic-translate-addon-pro-for-translatepress');
    }
    return $number;
}

