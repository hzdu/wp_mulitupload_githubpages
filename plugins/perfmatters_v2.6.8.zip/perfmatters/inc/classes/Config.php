<?php
namespace Perfmatters;

if(!defined('ABSPATH')) {
	exit;
}

use WP_Admin_Bar;

class Config
{
	public static $options;
	public static $tools;
	public static $code_disabled = false;

	//initialize config
	public static function init()
	{
		//load plugin options
		self::$options = get_option('perfmatters_options');
		self::$tools = get_option('perfmatters_tools');

		//ensure one-per-line options are arrays
		if(is_array(self::$options)) {
			perfmatters_normalize_one_per_line_options(self::$options);
		}

		//actions
		add_action('admin_bar_menu', array('Perfmatters\Config', 'admin_bar_menu'), 500);
		add_action('wp', array('Perfmatters\Config', 'queue'));

		//check for code disable constant
        if(defined('PERFMATTERS_DISABLE_CODE') && PERFMATTERS_DISABLE_CODE) {
        	self::$code_disabled = true;
		}
	}

	//setup admin bar menu
	public static function admin_bar_menu(WP_Admin_Bar $wp_admin_bar) 
	{

		if(!current_user_can('manage_options') || !perfmatters_network_access() || !empty(self::$tools['hide_admin_bar_menu'])) {
			return;
		}

		//add top level menu item
		$wp_admin_bar->add_menu(array(
			'id'    => 'perfmatters',
			'title' => 'Perfmatters',
			'href'  => admin_url('options-general.php?page=perfmatters')
		));
	}

	//safe mode admin notice
	public static function safe_mode_notice() {

		if(is_network_admin() || empty(self::$tools['safe_mode'])) {
			return;
		}

		$tools_url = admin_url('options-general.php?page=perfmatters#tools');

		echo '<div class="notice notice-warning">';
			echo '<p>';
				echo '<strong>' . esc_html__('Perfmatters Warning', 'perfmatters') . ':</strong> ';
				echo esc_html__('Safe Mode is enabled. Performance optimizations are currently disabled.', 'perfmatters') . ' ';
				echo '<a href="' . esc_url($tools_url) . '">' . esc_html__('Manage Safe Mode', 'perfmatters') . '</a>';
			echo '</p>';
		echo '</div>';
	}

	//run the queue
	public static function queue() {

		//inital checks
        if(is_admin() || Utilities::is_dynamic_request() || Utilities::is_page_builder() || isset($_GET['perfmatters']) || Utilities::is_perfmatters_off()) {
            return;
        }

        //logged in check
        if(!empty(self::$tools['disable_logged_in']) && is_user_logged_in()) {
            return;
        }

        //user agent check
        if(!empty($_SERVER['HTTP_USER_AGENT'])) {
            $excluded_agents = array(
                'usercentrics'
            );
            foreach($excluded_agents as $agent) {
                if(stripos($_SERVER['HTTP_USER_AGENT'], $agent) !== false) {
                    return;
                }
            }
        }

		do_action('perfmatters_queue');
	}
}