<?php
/**
 * Plugin Name:       Shopkeeper 授权补丁
 * Description:       让 Shopkeeper 主题的授权状态不再依赖 Freemius SDK。启用后授权页显示“已授权”、左侧菜单红色感叹号消失；主题升级后无需再修改任何主题代码。
 * Version:           1.0.0
 * Requires PHP:      7.0
 * Author:            local patch
 * License:           GPL-2.0-or-later
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * 症状
 * ─────────────────────────────────────────────────────────────────────────────
 * 后台 Get Bowtied → License 页面一直显示 “Activate license key” 输入框，
 * 提交后页面刷新并提示 “Invalid license key.”，左侧菜单常驻红色感叹号。
 *
 * 原因
 * ─────────────────────────────────────────────────────────────────────────────
 * 主题的授权状态来自 Freemius SDK：
 *     GBT_License_Manager::is_active() → $fs->is_registered() && $fs->has_active_valid_license()
 * 而 themes/shopkeeper/functions.php 里有一段官方 workaround：
 *     if ( ! class_exists( 'Freemius' ) ) { require_once $sdk_path; }
 *     // 主题的 SDK 比插件的版本号高时 start.php 会 fs_redirect() 自己 → 死循环，
 *     //  主题抢不到加载顺序，所以先加载的插件的 SDK 说了算
 * 于是主题里那份打过补丁的 SDK（dashboard/inc/freemius/）根本不会被执行，
 * 主题拿到的是插件里的官方 SDK：is_registered() 为 false → is_active() 恒为 false。
 * 提交按钮走 $fs->opt_in()，真的去请求 wp.freemius.com，被拒后就返回
 * “Invalid license key.”。
 *
 * 本插件怎么修
 * ─────────────────────────────────────────────────────────────────────────────
 * 不去和 SDK 的加载顺序较劲，而是直接在主题的授权类上换实例：
 *   1. 在 after_setup_theme 时（主题 functions.php 已执行完、admin_init 还没触发）
 *      取到 GBT_License_Manager 的单例，摘掉它挂在 admin_init / admin_notices /
 *      admin_head / parent_file 上的回调（红点、提示、授权 POST 处理都在里面）；
 *   2. 用反射把它的单例换成子类 Shopkeeper_License_Fix_Manager，
 *      该子类把 is_active() / has_license() 固定为 true，并给授权面板补齐显示数据。
 * 之后主题里所有 GBT_License_Manager::get_instance() 拿到的都是这个子类实例。
 *
 * 本插件不修改主题和任何插件文件，停用/删除即完全恢复原状。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GBT_LICENSE_FIX_DIR', plugin_dir_path( __FILE__ ) );

class Shopkeeper_License_Fix {

	/** @var bool 补丁是否已经生效 */
	private static $patched = false;

	/** @var string 失败原因，用于后台提示 */
	private static $failure = '';

	/**
	 * 加载时机：
	 *   插件(已加载) → setup_theme → 主题 functions.php（其中 includes dashboard/index.php，
	 *   GBT_License_Manager 在这里定义并挂上 admin_init 钩子）→ after_setup_theme → init → admin_init
	 * 所以 after_setup_theme 是能在 admin_init 之前动手的最后时机。
	 */
	public static function boot() {
		add_action( 'after_setup_theme', array( __CLASS__, 'patch' ), 0 );
		add_action( 'admin_init', array( __CLASS__, 'patch' ), 0 ); // 兜底再试一次（幂等）
		add_action( 'admin_notices', array( __CLASS__, 'maybe_warn' ) );
	}

	/**
	 * 换掉主题的授权管理器实例。
	 *
	 * @return bool 是否已生效
	 */
	public static function patch() {
		if ( self::$patched ) {
			return true;
		}

		if ( ! class_exists( 'GBT_License_Manager' ) ) {
			// 主题不是 Shopkeeper，或当前是前台请求（主题只在 is_admin() 时加载 dashboard）。
			return false;
		}

		$original = GBT_License_Manager::get_instance();

		require_once GBT_LICENSE_FIX_DIR . 'class-license-manager-override.php';

		if ( ! class_exists( 'Shopkeeper_License_Fix_Manager' ) ) {
			self::$failure = 'override class missing';
			return false;
		}

		if ( $original instanceof Shopkeeper_License_Fix_Manager ) {
			self::$patched = true; // 已经是我们的实例
			return true;
		}

		self::unhook( $original );

		if ( ! self::swap_instance() ) {
			self::$failure = 'singleton swap failed';
			return false;
		}

		self::$patched = true;
		return true;
	}

	/**
	 * 摘掉原实例挂的钩子。
	 *
	 * register_admin_hooks() 是在 admin_init(10) 里才把红点/提示挂上去的，
	 * 如果我们赶在 admin_init 之前执行，这几条还没注册；一并 remove 只是保险
	 * （未注册时 remove_* 是无操作）。
	 *
	 * @param object $original 原 GBT_License_Manager 实例
	 */
	private static function unhook( $original ) {
		$hooks = array(
			array( 'action', 'admin_init', 'handle_license_page_post', 5 ),
			array( 'action', 'admin_init', 'register_admin_hooks', 10 ),
			array( 'action', 'admin_notices', 'render_admin_notice', 10 ),
			array( 'action', 'admin_head', 'print_menu_badge_styles', 10 ),
			array( 'filter', 'parent_file', 'add_menu_badge', 10 ),
		);

		foreach ( $hooks as $hook ) {
			list( $type, $tag, $method, $priority ) = $hook;
			$callback = array( $original, $method );

			if ( 'filter' === $type ) {
				remove_filter( $tag, $callback, $priority );
			} else {
				remove_action( $tag, $callback, $priority );
			}
		}
	}

	/**
	 * 用反射替换私有静态单例。
	 *
	 * @return bool
	 */
	private static function swap_instance() {
		if ( ! class_exists( 'ReflectionClass' ) ) {
			return false;
		}

		try {
			$reflection = new ReflectionClass( 'GBT_License_Manager' );

			if ( ! $reflection->hasProperty( 'instance' ) ) {
				return false;
			}

			$property = $reflection->getProperty( 'instance' );

			if ( PHP_VERSION_ID < 80100 ) {
				$property->setAccessible( true ); // PHP 8.1+ 默认即可访问
			}

			$instance = new Shopkeeper_License_Fix_Manager();

			try {
				$property->setValue( null, $instance ); // 静态属性用两个参数的写法
			} catch ( Throwable $e ) {
				$property->setValue( $instance );
			}
		} catch ( Throwable $e ) {
			return false;
		}

		return ( GBT_License_Manager::get_instance() instanceof Shopkeeper_License_Fix_Manager );
	}

	/**
	 * 生效失败时给个明确提示，避免又变成“静默失效、看不出原因”。
	 */
	public static function maybe_warn() {
		if ( self::$patched || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( 'shopkeeper' !== get_template() ) {
			return; // 当前主题不是 Shopkeeper，与本插件无关
		}

		if ( ! class_exists( 'GBT_License_Manager' ) ) {
			return; // 主题的 dashboard 没加载，说明本页面不需要授权状态
		}

		printf(
			'<div class="notice notice-warning"><p><strong>Shopkeeper 授权补丁未生效</strong>（原因：%s）。'
			. '通常是主题新版本改动了 <code>GBT_License_Manager</code> 的结构，'
			. '请联系维护者更新本插件；在此之前可先停用本插件以免出现不一致状态。</p></div>',
			esc_html( self::$failure ? self::$failure : 'unknown' )
		);
	}
}

Shopkeeper_License_Fix::boot();
