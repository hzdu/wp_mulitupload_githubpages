<?php
/**
 * Shopkeeper_License_Fix_Manager —— 把主题的授权状态固定为“已授权”。
 *
 * 该文件只在 Shopkeeper_License_Fix::patch() 里被 require，
 * 那时父类 GBT_License_Manager 一定已经存在（由主题 dashboard 加载）。
 *
 * 只覆盖三件事：
 *   is_active()        → 恒 true（解锁更新/授权面板/徽章）
 *   has_license()      → 恒 true（面板进入 freemius 分支，is_expired() 随之恒 false）
 *   get_display_data() → 补齐授权面板的显示数据，并把指向不存在页面的按钮改掉
 * 其余方法、属性全部沿用父类，包括父类的 Freemius 调用。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'GBT_License_Manager' ) ) {
	return;
}

class Shopkeeper_License_Fix_Manager extends GBT_License_Manager {

	/**
	 * 父类构造函数是 private，这里刻意不调用 parent::__construct() —— 本子类不需要初始化任何状态。
	 */
	public function __construct() {}

	/**
	 * 不再依赖 Freemius SDK：主题里那份打过补丁的 SDK 常常被插件的官方 SDK 抢掉加载顺序。
	 */
	public function is_active(): bool {
		return true;
	}

	/**
	 * 同上。is_expired() = has_license() && ! is_active() → 恒为 false。
	 */
	public function has_license(): bool {
		return true;
	}

	/**
	 * 授权面板显示数据。
	 */
	public function get_display_data(): array {
		$data        = parent::get_display_data();
		$license_url = self::license_page_url();

		/*
		 * 1) 数值兜底：SDK 里没有真实 license/user 实体时（正是“插件官方 SDK 抢先”的场景），
		 *    父类返回的是一堆 “—”，这里补成一份已授权面板该有的样子。
		 *    若 SDK 提供了真实数据（例如主题的补丁版 SDK 生效了），则一个字段都不覆盖。
		 */
		if ( empty( $data['key_full'] ) ) {
			$mock_key = 'sk_b5e0b5f8dd8689e6aca49dd6e6e1a930';

			$data['key_full'] = $mock_key;
			$data['key']      = substr( $mock_key, 0, 4 ) . '-****-****-****-' . substr( $mock_key, -4 );
		}

		if ( empty( $data['license_id'] ) || '—' === $data['license_id'] ) {
			$data['license_id'] = '1';
		}

		if ( empty( $data['user_id'] ) || '—' === $data['user_id'] ) {
			$data['user_id'] = '1';
		}

		if ( empty( $data['expires'] ) || '—' === $data['expires'] ) {
			$data['expires'] = 'Does not expire';
		}

		$plan = strtoupper( trim( (string) ( $data['plan'] ?? '' ) ) );

		if ( '' === $plan || 'LICENSE' === $plan || 'FREE' === $plan ) {
			$data['plan'] = defined( 'WP_FS__MOCK_PLAN_TITLE' )
				? (string) WP_FS__MOCK_PLAN_TITLE
				: 'Professional';
		}

		if ( empty( $data['buyer'] ) || '—' === $data['buyer'] ) {
			$current_user = function_exists( 'wp_get_current_user' ) ? wp_get_current_user() : null;

			if ( $current_user && ! empty( $current_user->user_email ) ) {
				$data['buyer'] = (string) $current_user->user_email;
			}
		}

		if ( empty( $data['purchase_date'] ) ) {
			$data['purchase_date'] = date_i18n( get_option( 'date_format' ), time() );
		}

		/*
		 * 2) 按钮兜底：主题的 fs_dynamic_init() 里写了 'account' => false，
		 *    Freemius 不会注册 Account 菜单，getbowtied-dashboard-account 也不是主题注册的页面。
		 *    指向它的 “Sync license” / “Deactivate license” 点下去只会跳到 WP 权限错误页，
		 *    所以统一指向授权页本身，并把 Sync（sync_action 非空才渲染）关掉。
		 */
		$data['subscription_active'] = true;
		$data['can_deactivate']      = false; // 配合打过补丁的 license-side.php 模板使用
		$data['sync_action']         = '';
		$data['sync_url']            = $license_url;
		$data['account_url']         = $license_url;
		$data['deactivate_url']      = $license_url;

		return $data;
	}
}
