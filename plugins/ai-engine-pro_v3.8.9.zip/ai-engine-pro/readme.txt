=== AI Engine (Pro) – MCP Server & AI Chatbot for WordPress, with Claude, ChatGPT & Gemini ===
Contributors: TigrouMeow
Tags: ai, chatbot, mcp, claude, chatgpt
Donate link: https://www.patreon.com/meowapps
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 3.8.9
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The AI chatbot, AI agent and MCP server for WordPress. Connect OpenAI, Claude, Gemini and more to chat, write, search and automate your site.

== Description ==

**Free MCP server: Claude and ChatGPT connect with no account, no cap and no API key.**

**AI Engine connects WordPress with AI models.** One install, stable connectors for every major AI provider: OpenAI, Anthropic, Google, Mistral, and more. Build intelligent chatbots, generate content, create AI forms, and automate tasks. All from your WordPress dashboard.

https://www.youtube.com/watch?v=CBsXit0W4Ro

Take the tour at [vibewithwp.ai](https://vibewithwp.ai/): what AI Engine does, how the MCP server works, and how it compares to the alternatives. Please make sure you read the [disclaimer](https://meowapps.com/ai-engine/disclaimer/). For more information, check the official website of [AI Engine](https://meowapps.com/ai-engine/).

== Quick Intro ==

Hello! ☀️ I built AI Engine to bring OpenAI, Anthropic, and other AI models into WordPress. Create chatbots that understand your content, generate posts in your voice, translate instantly, create images, or build custom AI tools.

For developers: [internal APIs](https://ai.thehiddendocs.com/php-functions/), [REST endpoints](https://ai.thehiddendocs.com/public-rest-api/), [function calling](https://ai.thehiddendocs.com/function-calling/), and [MCP support](https://ai.thehiddendocs.com/mcp/). Build AI features, automate workflows, or create SaaS applications on WordPress.

There is also a Workspace: a full-screen AI chat inside wp-admin, with every model you configured, and free apps for [iPhone](https://apps.apple.com/app/workspace-for-wordpress/id6794717714) and [Android](https://play.google.com/store/apps/details?id=com.meowapps.workspace) so you can keep working on your site from your phone. Details on [workspace.press](https://workspace.press/).

Feeling overwhelmed? 🤪 Start simple: Create a chatbot. Then connect [Claude Code](https://ai.thehiddendocs.com/mcp/mcp-server-claude-code/), [Claude](https://ai.thehiddendocs.com/mcp/mcp-server-claude/), [ChatGPT](https://ai.thehiddendocs.com/mcp/mcp-server-chatgpt/), or [OpenClaw](https://meowapps.com/openclaw-wordpress-mcp/) through MCP, giving AI direct access to your site. Desktop clients can connect via OAuth: users just paste the MCP URL, sign in to WordPress, and approve. No shared token to manage. Add [SEO Engine](https://wordpress.org/plugins/seo-engine/) and watch it manage SEO in ways you never imagined. You can even connect AI Engine to multiple WordPress sites and manage them all through conversation.

https://www.youtube.com/watch?v=qg75Y3PDBpc

You'll be having a blast before you've explored everything. You'll probably spot bits of AI Engine in plenty of other AI plugins, code and UI alike. Flattering, really... or fishy? 🤣 But only AI Engine keeps pushing forward with real care for its community, a drive toward perfection, and the patience to get the details right.

== Core Modules ==

🤖 **Chatbots**
Create chatbots for your visitors, with five built-in themes (including the new Glass), realtime audio, file uploads, discussions, and conversation memory. Every theme can be restyled, and every text the chatbot says can be translated.

🖥️ **Workspace** (with free [iPhone](https://apps.apple.com/app/workspace-for-wordpress/id6794717714) and [Android](https://play.google.com/store/apps/details?id=com.meowapps.workspace) apps)
A full-screen AI chat inside your WordPress admin: every model you configured, conversation history and folders, a prompt library, image generation, web search, and hands-on access to your site through the MCP tools. It also runs on your phone and tablet, through [Workspace for WordPress](https://workspace.press/).

🎨 **Content & Media**
Write posts in the Content Studio, create and edit images in the Image Studio, compare models side by side in the Playground, and use Copilot in the WordPress editor to correct, enhance, translate, or rewrite text.

📝 **AI Forms (Pro)**
Build custom AI-powered forms that handle text, images, audio, or file uploads. Create advanced apps with conditional logic.

🧠 **Knowledge & Embeddings (Pro)**
Create embeddings and build knowledge bases from PDFs. Connect with Pinecone, Chroma, Qdrant, or OpenAI Vector Store for semantic search.

🔧 **Function Calling**
Connect AI to WordPress functions, WooCommerce, appointments, or custom APIs. Let AI interact with your site's data and services in real-time.

🛡️ **Security & Moderation**
IP banning, word filtering, and content moderation to keep your AI interactions safe.

💡 **Advisor**
AI-powered recommendations and insights to help you set up and optimize your WordPress site.

🔌 **Developer Tools**
Internal APIs, REST endpoints, MCP support, and extensive hooks. Build AI-driven features, automate workflows, or create SaaS applications.

== 🖥️ Workspace (and its mobile apps) ==

A full-screen AI chat that lives in your WordPress admin, and now in your pocket too.

Every model you configured is one tap away, in the same conversation: start a thread on Claude, continue it on ChatGPT or Gemini, generate an image, search the web, then let it work on the site itself through the MCP tools, with an approval dialog before anything is changed.

**Workspace for WordPress** brings all of it to your phone and tablet, on the [App Store](https://apps.apple.com/app/workspace-for-wordpress/id6794717714) and [Google Play](https://play.google.com/store/apps/details?id=com.meowapps.workspace). You scan a QR code once to pair it with your site, no password typed on a phone keyboard, and the pairing is a revocable Application Password you can cut off at any time. Your conversations, folders and themes stay on your own site, and your API keys never leave it.

The app is free, the plugin is free, and there is no markup on anything: you pay your AI providers directly, at their price. Workspace is off by default: enable it under AI Engine → Settings → Modules, and the Workspace entry appears in your admin menu. More about it on [workspace.press](https://workspace.press/).

**Features:**

* History, folders, pins, full-text search and a prompt library
* Attach files and save generated images to the Media Library
* Requires iOS 17 or newer, or Android 8 or newer

== 🤖 Chatbots ==

Transform visitor interactions with intelligent, customizable chatbots.

**Features:**

* Five built-in themes: Timeless, Messages, ChatGPT, Foundation, and Glass, a frosted glass theme with a dark and a light mode
* A Themes editor for colors, fonts, and custom CSS
* Popup, inline, or fullscreen, with an optional macOS-style window
* Realtime audio conversations
* File and image uploads, several at once, or simply pasted
* Discussions list and conversation memory
* Every text translatable, and message actions reachable with the keyboard
* Cross-site embedding
* GDPR compliance tools

== 🎨 Content & Media ==

Create, refine, and visualize content with AI assistance.

**Studios:**

* Content Studio: from a brief to a full draft, with templates you can reuse
* Image Studio: generate images, keep every version, and edit them with a brush
* Playground: try a prompt on several models side by side

**Copilot (Magic Wand):**

* Correct grammar and spelling
* Enhance text for readability and quality
* Make text longer or shorter
* Translate text and full posts
* Generate content from scratch
* Multi-block support in the WordPress editor

**Image Tools:**

* Create images from text prompts
* Edit existing images with AI
* Vision AI for image analysis
* Automatic alt text generation

== 📝 AI Forms (Pro) ==

Build powerful AI-driven forms and applications.

**Capabilities:**

* Text, image, audio, and file inputs
* Conditional logic and validation
* Custom AI-powered apps
* Multi-step workflows
* Result templates

== 🧠 Knowledge & Embeddings (Pro) ==

Create intelligent knowledge bases and semantic search.

**Vector Databases:**

* Chroma, Qdrant, Pinecone
* OpenAI Vector Store
* Automatic synchronization
* Dimension validation

**Smart Features:**

* PDF import with auto-chunking
* AI-powered search (Simple, Context-Aware, Smart)
* Content classification
* Personalized recommendations

== 🔧 Developer Tools ==

Extend WordPress with AI capabilities.

**APIs:**

* Internal API for plugin integration
* REST API for external applications
* MCP (Model Context Protocol) support
* Function calling framework

**Integration:**

* Works with SEO Engine, Social Engine, Code Engine
* Media File Renamer support
* Custom shortcodes and hooks
* Extensive WordPress filters

**Resources:**

* [Code Examples & Customization](https://ai.thehiddendocs.com/examples/)

== MCP (Model Context Protocol) ==

AI Engine turns your WordPress site into an intelligent MCP server. AI agents like ChatGPT, Claude, Claude Code, and OpenClaw can connect directly, browse content, edit posts, manage media, and handle complex tasks through natural conversation.

**More than 130 tools, over 200 with the Meow Apps family.** Posts, pages, media, comments, users, taxonomies, block patterns, editor notes, image generation and vision come free. Pro adds plugins, themes, database, WooCommerce, Polylang and WPML. SEO Engine, Code Engine and Social Engine plug in their own, and any WordPress Ability can join. You choose which sets are on, so each AI only carries what it needs.

**Direct and private.** AI apps connect straight to your site. There is no relay service in between, your credentials never leave WordPress, and the MCP server is free, with no monthly fee and no usage cap.

**See and undo every change.** The MCP tab lists what each assistant changed on your site, with a link to WordPress's before/after view and a one-click way back to the version before the edit.

Rather have it set up for you? [Connect with Meow Apps](https://connect.meowapps.com/?ref=wporg) adds your site to ChatGPT or Claude in a few clicks, through our gateway, which passes requests along without storing them.

**What AI Agents Can Do:**

* Create and edit posts
* Moderate comments
* Install and manage plugins
* Customize themes
* Check SEO and analytics
* Manage media files
* Run SQL queries
* Create images for your posts, in the shape you need
* Manage WooCommerce products, orders, inventory, and customers
* Handle Polylang and WPML translations

Setup guides for [ChatGPT](https://ai.thehiddendocs.com/mcp/mcp-server-chatgpt/), [Claude](https://ai.thehiddendocs.com/mcp/mcp-server-claude/) and [Claude Code](https://ai.thehiddendocs.com/mcp/mcp-server-claude-code/) are in the [MCP documentation](https://ai.thehiddendocs.com/mcp/).

AI Engine can also connect to external MCP servers, extending your chatbots with tools and services beyond WordPress.

**A note on safety and "full access":**

AI Engine's MCP tools are curated and permission-aware on purpose. They do not run arbitrary code, so your site stays safe even while an AI agent works on it.

Each person connects with their own WordPress account, so every action shows up under their name. Administrators get full access. Editors can connect too once you turn on Editor Access, limited to the content they can already edit in WordPress: settings, users, plugins, themes and deleting stay with administrators.

Arbitrary PHP execution, as some tools offer, will never be part of AI Engine: it turns your site into remote code execution. For a development site only, the companion [AI Engine YOLO](https://github.com/jordymeow/ai-engine-yolo) adds it, switches itself off on production, and lives on GitHub only.

== Pro Features ==

* **AI Forms**: Create dynamic forms that generate answers, images, or files using AI.
* **Embeddings & Vector Databases**: Build knowledge bases from your content and PDFs for semantic search.
* **Content-Aware**: Let AI use your post and page content as context for smarter responses.
* **Function Calling**: Connect AI to WordPress functions, WooCommerce, or any custom API.
* **Cross-Site Chatbots**: Embed your chatbots on external websites.
* **Editor Assistant**: An AI sidebar in the post editor that can read, rewrite, insert, and rearrange your content blocks through chained function calls.
* **Realtime Audio**: Voice-based conversations on OpenAI's GA Realtime API, with the latest voice reasoning capabilities.
* **Statistics & Usage Control**: Track usage, set limits per role, and monitor costs.
* **Extra MCP Tools**: Adds plugin, theme, database, Polylang, WPML, and WooCommerce management to the MCP server.
* **Models API**: Let coding agents and OpenAI-compatible apps use your site's AI models with one key, with usage tracked in Insights.
* **Priority Support**: Get faster help from the Meow Apps team.

== Why AI Engine? ==

**Native to WordPress**
Built specifically for WordPress with seamless integration. No clunky interfaces, just native WordPress experience.

**Flexible & Powerful**
Built-in connectors for OpenAI, Anthropic, Google, xAI (Grok), Mistral, Perplexity, OpenRouter, Replicate, Azure (OpenAI), plus a Custom (OpenAI-compatible) connector for Ollama, LM Studio, vLLM, llama.cpp, LocalAI, or any self-hosted server. Use the models that work best for you.

**Developer Friendly**
Clean APIs, extensive hooks, and MCP support. Build custom AI features or entire SaaS applications on WordPress.

**Real MCP, for Real WordPress**
Generic MCP adapters wrap the REST API. AI Engine's tools are crafted for AI agents, with rich context, smart defaults and practical actions, on any WordPress host. The REST API can be exposed as tools too, if you want it.

**Privacy First**
IP hashing, GDPR tools, secure file handling, and session-based tracking. You control your data. The free version sends nothing to us; the Pro version's update check also says whether MCP was used in the last 30 days (a simple yes or no, nothing about what it did) and how many phones are paired with Workspace (a number only).

**Constantly Evolving**
Weekly updates based on real user feedback. We listen, we improve.

== My Dream for AI ==

I am excited about AI, but I believe we need to use it with intention and clarity. Social media showed us how powerful tools can reshape our lives in ways we never expected, sometimes for the better, sometimes not. I want to avoid repeating those mistakes. AI should help us remove the meaningless, tedious work or enhance the work we enjoy. Modern tools should give us more time for what truly matters: spending beautiful moments with the people we love! 💕

== Installation ==

1. Upload `ai-engine` to `/wp-content/plugins/`
2. Activate through the 'Plugins' menu
3. Get an API key from OpenAI (or your preferred AI provider)
4. Add your API key in Settings (Meow Apps > AI Engine)
5. Start creating! 🚀

== Disclaimer ==

AI Engine is a plugin that helps you to connect your websites to AI services. You need your own API keys and must follow the rules set by the AI service you choose. For OpenAI, check their [Terms of Service](https://openai.com/terms/) and [Privacy Policy](https://openai.com/privacy/). It is also important to check your usage on the [OpenAI website](https://platform.openai.com/usage) for accurate information. Please do so with other services as well.

The developer of AI Engine and related parties are not responsible for any issues or losses caused by using the plugin or AI-generated content. You should talk to a legal expert and follow the laws and regulations of your country. AI Engine does only store data on your own server, and it is your responsibility to keep it safe. AI Engine's full disclaimer is [here](https://meowapps.com/ai-engine/disclaimer/).

== External services ==

AI Engine connects to the AI services you configure (OpenAI, Anthropic, Google and others) with your own API keys, only to run the features you use. See the Disclaimer above for their terms.

When you connect an AI assistant in the MCP tab, the connection card can offer an optional "Keep me posted on Meow Apps news" box. Only if you tick it and click Subscribe, your email address is sent to meowapps.com (Meow Apps' newsletter, double opt-in, one-click unsubscribe). Nothing is sent otherwise. See the [Meow Apps privacy policy](https://meowapps.com/privacy-policy/).

== Compatibility ==

Please be aware that there may be conflicts with certain caching or performance plugins, such as SiteGround Optimizer and Ninja Firewall. To prevent any issues, ensure that AI Engine is excluded from these plugins.

== Screenshots ==

1. A chatbot on your site, here as a popup in the corner of a page. Give it a name, an avatar and a personality.
2. The same chatbot inline, with a dark theme. Themes are built in, and you can style your own.
3. Realtime: a voice conversation with the AI, with avatars and the live events feed.
4. Building a chatbot in the settings: pick the environment, the model, the context and the functions, and try it right there in the live preview.
5. The Content Generator: a whole post from a topic, sections first, then the content and the excerpt, all editable before it is published.
6. The Workspace: a full-screen AI chat inside wp-admin that can read and manage your site, with every model you configured.
7. Workspace on your phone: your site's AI on iPhone or Android. Every model, your keys, your site, with conversations kept on your own WordPress and image generation included.

== Frequently Asked Questions ==

= Why am I getting "Error 429: You exceeded your current quota"? =

This error comes from OpenAI's API, not AI Engine. Set up billing limits in your [OpenAI account](https://platform.openai.com/account/billing). Caching plugins can sometimes store error responses, so [clear your caches](https://ai.thehiddendocs.com/common-issues/exceeded-current-quota/) too.

= Who is AI Engine for, and how do I manage usage limits? =

AI Engine can be used by site owners, administrators, and visitors via chat widgets. To set query limits and prevent unlimited model runs, follow the [Managing Limits guide](https://ai.thehiddendocs.com/limits/).

= Does the chatbot support my language? =

AI models support many languages, but quality varies. There's no definitive list since models are constantly updated. Test your language in the AI Playground.

= How does MCP work, and what can I do with it? =

MCP (Model Context Protocol) exposes WordPress tools to AI agents. [Learn how to enable the MCP endpoint](https://ai.thehiddendocs.com/mcp/), choose which tools to expose, and secure them. You can manage posts, comments, users, media, and more. Administrators get full access, and you can also let Editors connect with their own account for content only.

= Is the MCP server free? Do I need an API key or my own server? =

Yes. The MCP server is part of this free plugin, with no account and no daily cap. There is no extra server to host: Claude and ChatGPT connect to your WordPress site with OAuth and use the plan you already have, so no API key is needed. [The facts, side by side with another MCP plugin](https://meowapps.com/ai-engine-vs-wpvibe/).

= Does AI Engine work with WordPress AI (the AI plugin, Connectors and providers)? =

Yes, but you don't need it. AI Engine already does everything WordPress AI offers, and more: it connects to every major provider, and adds chatbots, AI Forms, embeddings, a dedicated MCP server with more than 130 tools, and usage insights. That's why we don't recommend installing the WordPress AI plugin alongside it. If you already use it, that's fine: we make sure both play nicely together. On the Connectors page, choose to let AI Engine manage your providers: the API keys you already saved there are reused, both screens stay in sync, and the AI features of WordPress run through AI Engine, so their usage shows up in its Insights.

= Do I need the MCP Adapter plugin? =

No. AI Engine has its own MCP server, with more than 130 tools (over 200 with SEO Engine, Code Engine and Social Engine), OAuth for Claude and ChatGPT, and per-user access, so there is nothing else to install. The MCP Adapter is the official WordPress bridge that turns the abilities other plugins register into MCP tools. Think of it as a power socket, and AI Engine as the appliance. If you already run it, both live side by side on different endpoints, and the Abilities option in the MCP tab lets AI Engine's own server expose those abilities too.

= Can I restrict the chatbot to answer only from my site content? =

You can't completely block the model's built-in knowledge, but you can [use smart prompts and embeddings](https://ai.thehiddendocs.com/restrict-chatbot-topics/) to steer conversations toward your content.

= The chatbot doesn't appear or looks odd on my site =

Check the [Common Issues guide](https://ai.thehiddendocs.com/common-issues/) for solutions to REST API problems, caching conflicts, nonce errors, and layout glitches.

= Where can I learn the basics and troubleshoot problems? =

Start with the [Basics guide](https://ai.thehiddendocs.com/basics/) for installation and key concepts. For specific issues, check [Common Issues](https://ai.thehiddendocs.com/common-issues/).

= How do I report security issues? =

Report security vulnerabilities through the [Patchstack Vulnerability Disclosure Program](https://patchstack.com/database/vdp/9e5fbbbc-964a-4204-8bc0-198f21284efd).

== Changelog ==

= 3.8.9 (2026/10/30) =
* Add: GPT-6.1 Terra model.
* Add: Restore link in Recent Changes, which opens the version from before an AI edit.
* Update: Connect card now offers a choice between a direct connection (recommended) and the Meow Apps relay, with labels under each choice explaining what it brings, and the address to copy now sits in the Copy step.
* Update: Connect card opens on the direct connection for Claude and ChatGPT, with the directory and the ChatGPT app one click away.
* Update: Image Studio's edit link now only accepts a media ID.
* Fix: Chatbot now explains why a file could not be sent to OpenAI, instead of showing OpenAI's "Expected an ID that begins with file" error.
* Fix: OpenRouter model list now waits up to 30 seconds to load, for slow hosts.

= 3.8.8 (2026/10/27) =
* Fix: Security: Shop Managers can no longer edit administrator accounts through MCP, and the plugin and theme file tools now follow DISALLOW_FILE_EDIT.
* Fix: Security: Forms and the Public API can no longer read protected uploads, the Google voice chatbot no longer exposes its API key, voice chats cannot replace someone else's conversation, and only admins can read the logs.
* Fix: Security: Guests can no longer reset their usage limits with a fake IP header, while proxies and Cloudflare are still recognized.
* Fix: Security: Chatbot replies now drop embedded frames and forms, and guest uploads are capped at 20 per hour.
* Add: MCP tab showing the week's activity, recent changes with links to each WordPress diff, connections, access and tools.
* Add: Settings backups with a restore in Maintenance, and settings now save only what changed.
* Add: Chatbots panel in Workspace to chat with the site's own chatbots, using their instructions, model and Knowledge.
* Add: Gemini 4 models such as gemini-4-argon now get vision, PDF, web search, Google Maps and thinking, as features follow the version number.
* Add: Keepalives for streams that stay silent from the start, so nginx no longer cuts them at 120 seconds.
* Add: The header shows the installed version and, when a newer one is out, how to update or renew.
* Update: The MCP connect card guides you through Claude's directory first, confirms when your assistant reaches the site, points ChatGPT users to the official AI Engine app with Developer mode as the direct option, says the connector stores no password and none of your content, and offers an optional, unticked Meow Apps news signup.
* Update: MCP stays off on updated sites that never stored the setting, only new installs get it on by default.
* Update: The MCP Connection Test warns when the host strips the Authorization header and gives the .htaccess line, and AI Engine reads that header from Apache when WordPress cannot see it.
* Update: The MCP post list accepts several post types or statuses at once, returns everything when asked for all posts, understands an author given by name, and the post count and post list tools return clearer data.
* Update: In the Knowledge tab, creating an environment moved into the environment dropdown and Create New became Add Manually.
* Update: New Meow Apps dashboard, from the latest shared common code.
* Update: The admin now works on tablets, with the header, columns and Chatbots toolbar no longer breaking.
* Update: The header lights the button of the screen you are on.
* Update: Various labels and links, including the Dashboard footer now pointing to the Getting started guide and the Discussions setting pointing to the Discussions tab.
* Fix: Chatbots keep web search, MCP servers and their reasoning settings after calling a function, which also stops Claude's "Invalid signature in thinking block" error.
* Fix: Chatbots keep their Knowledge context after calling a function on every provider, including Google, OpenRouter and other compatible providers.
* Fix: Syncing a large OpenAI Vector Store no longer times out, each step stops after about 25 seconds and the next one continues from there.
* Fix: The chatbot preview in the Chatbots tab shows the conversations held before 3.8.7 again instead of starting empty.
* Fix: Content Studio no longer shows each section heading twice when the model repeats it.
* Fix: MCP tools now accept text request ids as the JSON-RPC spec allows.
* Fix: Re-setting a featured image through MCP no longer fails, terms can be removed, and featured image errors say why.
* Fix: Admin scripts refresh when only the UI library changes instead of staying cached.

= 3.8.7 (2026/10/23) =
* Fix: Security: Voice chatbots now only run functions attached to their own chatbot.
* Fix: Security: Editors on MCP can no longer publish other content types or file references through a decoy fields object, and Public API tools and MCP servers stay restricted to administrators.
* Fix: Security: Cross-Site requests are now matched on their real REST route, so other REST calls can no longer skip the nonce check by mimicking its URL.
* Fix: Security: Contributors can no longer take over a live chatbot through WordPress' embed preview, and outside post content a shortcode can no longer replace a live chatbot's prompt, model or API key.
* Fix: Security: The Gemini file upload now verifies TLS.
* Fix: Security: The MCP sign-in page can no longer be framed by another site, shows where the app sends you, and warns when an app calls itself Claude or ChatGPT without being it.
* Add: Explore AI Engine, a ten-goal tour from the dashboard that follows you as a slim bar onto each screen, with Knowledge guidance in the chatbot settings.
* Add: Workspace mobile app on the dashboard, with QR code, store links and a status line once a phone is paired.
* Add: Sakana AI (Fugu and Namazu) as a native provider, hidden until switched on with MWAI_SAKANA.
* Add: Read-only access for Claude and ChatGPT MCP connections, with a switch per connection in Connected Apps.
* Add: Clean Up button in Knowledge for rows of deleted environments and orphans.
* Add: The mwai_openai_body filter, to set any OpenAI parameter AI Engine leaves to the defaults, like high quality for the chatbot's image tool.
* Update: Redesigned the dashboard with a Your AI card for models and providers, a This week chart compared with last week, shuffleable idea tiles and per-company AI visibility bars.
* Update: Glass now takes its colors from the lights you pick for the visitor's bubbles, the launcher and the accent, and the theme editor preview opens with a sample conversation that is never saved or sent to the AI.
* Update: New popup chatbots now open in the macOS frame and header, while existing chatbots keep the frame they already have.
* Update: The MCP screen now shows how many tools each set brings and how many AI Engine has in all.
* Update: MCP deletes without force now always go to the trash (products, events, media and comments too) or refuse clearly, and deletes that would be permanent ask the AI to check with the user first.
* Update: The Settings screen, dashboard cards and feature showcase are now translatable, and Knowledge, Privacy First and Content Studio wording is clearer.
* Update: Every Pro link in the admin now points to the AI Engine page and is tagged, Pro-locked buttons open it instead of doing nothing, and Pro chatbot modes show their Pro pill for free users.
* Update: The License tab was redesigned, with an Activate your license link for Pro buyers who have not entered a key yet.
* Update: The Pro update check now reports whether MCP was used in the last 30 days and how many phones are paired.
* Update: The chatbot preview in the admin now keeps its own history, and the dashboard uses the same spacing as the other tabs.
* Fix: Insights logs work again on sites whose logs table predates 2.5.6, since tables now get their missing columns on update.
* Fix: Chatbots and forms no longer stay blank when one of their settings contains entity text like &quot;.
* Fix: Posts containing an escaped "<" (like "<48 dB") no longer lose everything after it in Knowledge and Content-Aware.
* Fix: AI Forms in chatbot mode now use the chatbot's own Max Tokens, model and temperature instead of hidden form values that cut replies at 4096 tokens.
* Fix: Messages, uploads, stopping a reply and loading a conversation now follow the right chatbot's discussion when a chat id belongs to another chatbot.
* Fix: Claude no longer rejects the answer after a function call when Knowledge is on (Invalid signature in thinking block).
* Fix: When a thinking model spends its whole Max Tokens reasoning, the reply now says so instead of showing the raw reasoning as the answer.
* Fix: Knowledge no longer retries rows of deleted environments, and large OpenAI Vector Stores sync page by page instead of timing out.
* Fix: MCP connections no longer drop when a client revokes the token it just replaced after a refresh, and sign-in responses say which site answered.
* Fix: Links in the GDPR consent text are now clickable instead of shown as raw text.
* Fix: The site-wide popup chatbot no longer leaves a screen of blank space at the bottom of the page on themes that give the body a height.
* Fix: The user's IP is shown again under their name in Discussions and Insights for logged-in users, and in the discussion details.
* Fix: Chatbot names with & no longer show &amp;.
* Fix: Admin screens no longer load blank, and the header now shows the Free and Pro tiles.
* Fix: Links on other plugins' screens are no longer tagged as AI Engine traffic.
* Fix: OVHcloud and Sakana AI now follow one rule: hidden until switched on with MWAI_OVH or MWAI_SAKANA, and always shown where an environment of that type exists.
* 🎵 Discuss with others about Ai Engine on [the Discord](https://discord.gg/bHDGh38).
* 🌴 Keep us motivated with [a little review here](https://wordpress.org/support/plugin/ai-engine/reviews/). Thank you!
* 🥰 If you want to help us, check our [Patreon](https://www.patreon.com/meowapps). Thank you!
* 🚀 [Click here](https://trello.com/b/8U9SdiMy/ai-engine-feature-requests) to vote for the features you want the most.

= 3.8.6 (2026/10/17) =
* Fix: Security: Editors can no longer change the title or excerpt of posts they are not allowed to edit (coupons, menus, templates) through the AI helpers, and the other helpers taking a post ID now check permissions too (reported by Anatoly Gorbounov, x1will, via WPScan).
* Fix: Hotfix: Chatbot replies no longer crash on servers with an older cURL, such as Xserver, because of a constant added in 3.8.5.
* Add: The MCP screen's Claude step now opens Claude with this site's connector already filled in, so there is nothing to copy and paste.
* Fix: Messages like "0" or an image alone no longer fail the reply when Knowledge is on.
* Fix: Chatbot saves silently refused by the database now show an error.
* Fix: A Max Height set without a unit is now treated as pixels.
* Fix: AI Forms set to a specific environment with the Default model now work instead of failing with "Model not found".
* Fix: Settings changed while a chatbot reply is running are no longer undone when that reply saves its usage stats, which could revert a refreshed model list.

= 3.8.5 (2026/10/14) =
* Fix: Security: MCP no longer returns API keys or tokens when reading WordPress options.
* Fix: Security: Pro MCP tools now refuse accounts that cannot manage the site instead of running as the first user, and they pause when the license lapses.
* Fix: Security: Uploaded files can no longer carry metadata AI Engine uses internally, and the expired files cleanup only deletes the expired file itself.
* Add: GPT Realtime 2.1 and GPT Realtime 2.1 Mini for voice chatbots.
* Add: Claude Haiku 5.5.
* Add: Notice on new sites to turn on the MCP module in one click.
* Add: Warning in Settings and the chatbot editor when Knowledge has no embeddings model to search with.
* Add: Optional comment_parent on the MCP wp_create_comment tool, to reply inside a comment thread.
* Update: Playground presets are now a system prompt with parameters: picking one no longer fills the message box or resets the models being compared, the message box sits on top while the conversation is empty, and reply stats read plainly.
* Update: The Knowledge Export button is now always visible under the table, instead of only in Expert Mode.
* Update: AI Forms in chatbot mode now use the chatbot's functions and MCP servers.
* Update: Gemini 3.6 and newer no longer receive the temperature setting, and Gemini 3 and newer no longer receive a thinking budget.
* Update: The Perplexity connection check now uses the models endpoint, and shows Perplexity's own error when the key is wrong.
* Update: Streamed replies stay connected through long silent phases such as Code Interpreter or slow tool calls, and stop calling the AI provider when the visitor leaves.
* Fix: ChatGPT connections no longer fail with a missing resultType error when MCP requests use the 2026-07-28 format.
* Fix: ChatGPT and Claude can now sign in to MCP on servers that block paths containing /.well-known/ under /wp-json/, like many nginx setups.
* Fix: Connecting ChatGPT or Claude no longer fails with an expired code right after approval on sites with a persistent object cache.
* Fix: Claude Sonnet 5.5 cache reads now cost $0.10, as Anthropic charges.
* Fix: AI Engine no longer loads the block editor scripts on Classic Editor screens, which broke plugins like HTML Editor Syntax Highlighter.

= 3.8.4 (2026/10/08) =
* Fix: Security: A chatbot shortcode in a post can now only change the prompt, model or API key when its author can edit others' posts.
* Fix: Security: The search endpoint used by the Search settings screen is now limited to administrators.
* Add: Claude Opus 5.5 and Claude Sonnet 5.5.
* Add: GPT-6 Sol, GPT-6 Luna and GPT-6.1 Sol.
* Add: MCP tools to create, update, resolve and delete editor Notes, attached to the right block.
* Add: Gemini image sizes 512px, 1K, 2K and 4K, from the mwai_image MCP tool or the imageSize query param; models limited to 1K keep their default.
* Add: The mwai_image MCP tool now accepts an environment, a model, a quality and a file name per call, names files after the title, and records the model used.
* Add: An mwai_generated meta on every image AI Engine saves to the Media Library, set before wp_generate_attachment_metadata runs.
* Add: REST routes to enable MCP and check its status.
* Add: The mwai_anthropic_body filter, to tune the Anthropic request such as the web search limits before it is sent.
* Update: Knowledge now keeps at least 16,384 characters of each post instead of the old 4,096 default kept on older sites, and long posts are not re-synced after the update.
* Update: Pro modules switched off while a license was missing now turn back on by themselves once the license is valid again.
* Update: Site search with Knowledge or AI keywords skips bot and spam searches, and the same search is only paid for once a day.
* Update: The MCP Plugins and Themes options now say they can read and edit files, and the tool sets remind you to refresh the tools in ChatGPT or Claude after a change.
* Update: Workspace conversations continue on the model of their last reply, a new chat starts on your default model, and a default the site cannot run falls back to the first model.
* Update: Pinecone and Qdrant now keep each chunk's text and post ID, so Pull All rebuilds a working Knowledge base after a site move.
* Update: Current Claude models can now be picked as the default model for JSON queries.
* Update: Marked Claude Sonnet 4.5, GPT-5.4 Nano and GPT-5.1 as deprecated.
* Update: The review notice now shows two days after the first successful MCP tool call.
* Fix: Qdrant and Chroma server URLs pasted from the browser, like :6333/dashboard#, now work instead of sending every request to the dashboard page.
* Fix: Streamed replies are no longer cut after 5 minutes while still arriving, only when the connection goes silent.
* Fix: The JSON helpers used by Meow Apps Health and add-ons now work on Claude and Gemini sites with default settings.
* Fix: Uploading to an OpenAI Vector Store now says exactly what is wrong with the environment, such as a missing store ID, no OpenAI environment or no API key.
* Fix: Pro sites whose server cannot reach the update server no longer hit a fatal error on PHP 8 when WordPress checks for updates.

= 3.8.3 (2026/10/01) =
* Add: Abilities to MCP, so tools registered by plugins through the WordPress Abilities API work over MCP and in Workspace, appear in MCP Logs, and are labelled Ability or Native in the renamed MCP Tools & Abilities list.
* Add: Cached tokens are now counted and priced at the cached rate for OpenAI, Anthropic, DeepSeek, OpenRouter and Claude Fable 5, and Insights shows cached tokens per query.
* Add: OpenAI requests carry a prompt cache key per chatbot, so repeated prompts and tools are billed at the cached rate.
* Add: A reply cut by Max Tokens now ends with a short notice instead of stopping mid-sentence, in chatbots and forms.
* Add: A chatbot limited to one file shows the attached file name and a remove button before sending, like the multi-file mode.
* Add: Prices for Gemini text models, so their queries are costed and dollar limits apply to them.
* Add: The mwai_openrouter_body filter, to add any OpenRouter parameter to a request, such as provider routing.
* Update: The MCP settings were reorganized, with the Connect card filling its block, Connections and MCP Settings under it, tool sets and WordPress abilities under the tools list, and the bearer token masked in the Claude Code commands.
* Update: The Files Manager lists files uploaded by every user and guest instead of only your own, and expired files are cleaned up every hour instead of once a day.
* Update: New chatbots start with their texts in the site language instead of always in English, existing chatbots are untouched.
* Update: OpenRouter requests are attributed to AI Engine instead of each site, and the existing filters still let a site credit itself.
* Update: Workspace chats are grouped under Today and Yesterday in the user timezone instead of UTC.
* Fix: The Editor Assistant no longer fails with Feedback session expired after applying edits, saved queries no longer store API keys, and it now sees paragraphs edited after the page loaded.
* Fix: Claude, Gemini and other non-OpenAI chatbots on an OpenAI Vector Store now receive the matching knowledge instead of an empty context.
* Fix: Non-streamed errors from OpenRouter, Mistral, OVH and custom providers are shown as a message instead of raw JSON.
* Fix: Gemini replies cut by Max Tokens end with the notice instead of an empty-reply error, and Gemini errors wrapped in a list are readable.
* Fix: Picking an environment without a model now asks for one instead of sending another provider's default model and failing with a 404.
* Fix: An AI Form repeated on a page answers in its own copy, and a streamed form error no longer floods the PHP log.
* Fix: GPT-6 Astra can generate images, its model entry was missing the image generation tool.
* Fix: Uploads that fail now say why, with the size limit when the file is too large, instead of an unknown error or a wrong invalid file type message.
* Fix: An empty completion request is refused before reaching the provider, and Suggest Synonyms without a selection returns a clear error instead of a fatal.
* Fix: MCP tool failures, like a missing post, reach the AI as a readable tool error instead of a protocol error.
* Fix: ChatGPT MCP connections no longer drop when several of its sessions share one connection, and revoking an app disconnects all of its sessions at once.
* Fix: When AI Engine manages the WordPress Connectors, an empty key no longer wipes a saved one, and keys already saved in WordPress are reused.
* Fix: Syncing a single post that gets skipped (ignored, language filter, or filtered out) now says why instead of doing nothing.
* Fix: Copying a masked MCP command by hand copies the real token, and Knowledge asks to pick an environment instead of showing the first-run screen.
* Fix: On touch screens the Stop button works with a single tap, while a quick double tap on Send still cannot cancel the message.
* Fix: A failed license check shows the real reason straight away, and a successful retry no longer keeps saying the Pro version is disabled.
* Fix: Two PHP warnings on every logs request when Insights is off.

= 3.8.2 (2026/09/25) =
* Add: Connect an AI assistant card in the MCP settings, which checks the host, guides you through Claude, ChatGPT or Claude Code step by step, and confirms the connection works.
* Add: The license section now names the actual problem (server unreachable, not activated on this site, expired) instead of an unknown error, and lets you copy the diagnosis for support.
* Update: The MCP settings and the readme now state that connections are direct, with no relay, no fee or cap, and credentials staying on the site.
* Fix: A site that cannot reach the license server no longer hangs the admin for minutes: connection diagnostics run once instead of once per URL, and the license check times out after 20 seconds instead of 45.
* Fix: MCP connections no longer break when a client, such as ChatGPT, reuses a refresh token that was already replaced.
* Fix: Chatbots with streaming disabled no longer slide the window up when a reply starts, which hid the Glass header and could make the page jump.
* Fix: Add-ons now keep their own visitor params as sent; only denied keys are matched by their canonical name and only messages is folded into one key.

For older releases, see [changelog.txt](https://plugins.svn.wordpress.org/ai-engine/trunk/changelog.txt).

