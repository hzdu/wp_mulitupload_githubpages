<?php
/**
 * Smart Coupons Order Coupon Meta Lookup
 *
 * @author      StoreApps
 * @since       9.74.0
 * @version     1.0.1
 *
 * @package     woocommerce-smart-coupons/includes/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Order_Coupon_Meta_Lookup' ) ) {

	/**
	 * Class WC_SC_Order_Coupon_Meta_Lookup
	 *
	 * Handles capturing and storing coupon configuration snapshots at order creation.
	 */
	class WC_SC_Order_Coupon_Meta_Lookup {

		/**
		 * Database version.
		 */
		const TABLE_VERSION = '1.0.0';

		/**
		 * The single instance of the class.
		 *
		 * @var WC_SC_Order_Coupon_Meta_Lookup
		 */
		protected static $instance = null;

		/**
		 * Flag to check if table exists check is already performed in current request.
		 *
		 * @var bool
		 */
		private $table_exists_checked = false;

		/**
		 * Get class instance.
		 *
		 * @return WC_SC_Order_Coupon_Meta_Lookup
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->ensure_table_exists();
			$this->init_hooks();
		}

		/**
		 * Handle call to functions which is not available in this class
		 *
		 * @param string $function_name The function name.
		 * @param array  $arguments Array of arguments passed while calling $function_name.
		 * @return mixed result of function call.
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Initialize hooks.
		 */
		private function init_hooks() {
			/**
			 * We use order status hooks (processing/completed) to ensure that the order items
			 * are fully committed to the database and synced. This avoids race conditions
			 * found in early checkout hooks where line items might not be available yet.
			 */
			add_action( 'woocommerce_order_status_processing', array( $this, 'capture_order_coupons' ), 10, 1 );
			add_action( 'woocommerce_order_status_completed', array( $this, 'capture_order_coupons' ), 10, 1 );
		}

		/**
		 * Ensure the lookup table exists.
		 */
		public function ensure_table_exists() {
			if ( true === $this->table_exists_checked ) {
				return;
			}

			global $wpdb;
			$table_name = $wpdb->prefix . 'wc_sc_order_coupon_meta_lookup';

			$saved_version = get_option( 'wc_sc_order_coupon_lookup_table_version' );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$query = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

			if ( $wpdb->get_var( $query ) !== $table_name || self::TABLE_VERSION !== $saved_version ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
				$this->create_table();
				update_option( 'wc_sc_order_coupon_lookup_table_version', self::TABLE_VERSION );
			}

			$this->table_exists_checked = true;
		}

		/**
		 * Create the order coupon meta lookup table.
		 */
		public function create_table() {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $this->get_schema() );
		}

		/**
		 * Get the schema for the order coupon meta lookup table.
		 *
		 * @return string The SQL schema.
		 */
		public function get_schema() {
			global $wpdb;

			$table_name = $wpdb->prefix . 'wc_sc_order_coupon_meta_lookup';

			$charset_collate = $wpdb->get_charset_collate();

			return "CREATE TABLE {$table_name} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				order_id BIGINT UNSIGNED NOT NULL,
				coupon_id BIGINT UNSIGNED NOT NULL,
				coupon_code VARCHAR(255) NOT NULL,
				discount_amount DECIMAL(28,8) NULL,
				discount_tax DECIMAL(28,8) NULL,
				discount_type VARCHAR(50) NULL,
				coupon_amount DECIMAL(28,8) NULL,
				individual_use TINYINT(1) NULL,
				usage_limit INT NULL,
				usage_limit_per_user INT NULL,
				limit_usage_to_x_items INT NULL,
				usage_count INT NULL,
				free_shipping TINYINT(1) NULL,
				minimum_amount DECIMAL(28,8) NULL,
				maximum_amount DECIMAL(28,8) NULL,
				date_expires DATETIME NULL,
				apply_before_tax TINYINT(1) NULL,
				exclude_sale_items TINYINT(1) NULL,
				product_ids LONGTEXT NULL,
				exclude_product_ids LONGTEXT NULL,
				product_categories LONGTEXT NULL,
				exclude_product_categories LONGTEXT NULL,
				customer_emails LONGTEXT NULL,
				wc_sc_auto_apply_coupon TINYINT(1) NULL,
				sc_is_visible_storewide TINYINT(1) NULL,
				sc_restrict_to_new_user TINYINT(1) NULL,
				sc_disable_email_restriction TINYINT(1) NULL,
				wc_sc_max_discount DECIMAL(28,8) NULL,
				sc_restrict_to_shipping_methods LONGTEXT NULL,
				sc_restrict_to_payment_methods LONGTEXT NULL,
				wc_sc_allowed_user_roles LONGTEXT NULL,
				sc_coupon_validity INT NULL,
				validity_suffix VARCHAR(20) NULL,
				auto_generate_coupon TINYINT(1) NULL,
				coupon_title_prefix VARCHAR(255) NULL,
				coupon_title_suffix VARCHAR(255) NULL,
				wc_sc_add_product_details LONGTEXT NULL,
				wc_sc_cheapest_costliest_settings VARCHAR(255) NULL,
				is_pick_price_of_product TINYINT(1) NULL,
				wc_sc_payment_method_ids LONGTEXT NULL,
				wc_sc_shipping_method_ids LONGTEXT NULL,
				wc_sc_user_role_ids LONGTEXT NULL,
				wc_sc_exclude_user_role_ids LONGTEXT NULL,
				wc_sc_product_attribute_ids LONGTEXT NULL,
				wc_sc_exclude_product_attribute_ids LONGTEXT NULL,
				wc_sc_taxonomy_restrictions LONGTEXT NULL,
				wc_sc_product_quantity_restrictions LONGTEXT NULL,
				wc_sc_order_count_restriction LONGTEXT NULL,
				sa_cbl_locations_lookup_in VARCHAR(50) NULL,
				sa_cbl_billing_locations LONGTEXT NULL,
				sa_cbl_shipping_locations LONGTEXT NULL,
				wc_sc_excluded_customer_email LONGTEXT NULL,
				wc_sc_no_of_selectable_product TINYINT(1) NULL,
				wc_sc_expiry_time INT NULL,
				wc_sc_original_amount DECIMAL(28,8) NULL,
				wc_coupon_message LONGTEXT NULL,
				wc_email_message TINYINT(1) NULL,
				wc_sc_combined_coupons_allowed LONGTEXT NULL,
				wc_sc_combined_coupons_blocked LONGTEXT NULL,
				generated_from_order_id BIGINT UNSIGNED NULL,
				wc_sc_coupon_receiver_details LONGTEXT NULL,
				wc_sc_scheduled_actions_ids LONGTEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY order_coupon (order_id, coupon_id),
				INDEX order_id (order_id),
				INDEX coupon_id (coupon_id)
			) $charset_collate;";
		}

		/**
		 * Capture and store coupon data for an order.
		 *
		 * @param int $order_id The ID of the order.
		 */
		public function capture_order_coupons( $order_id ) {
			try {
				$this->ensure_table_exists();

				$order = wc_get_order( $order_id );

				if ( ! is_a( $order, 'WC_Order' ) ) {
					return;
				}

				// Prevent duplicate processing.
				if ( 'yes' === $this->get_post_meta( $order_id, '_wc_sc_coupon_meta_lookup_processed', true, false, $order ) ) {
					return;
				}

				$coupon_items = $order->get_items( 'coupon' );

				// Only capture if coupons exist in the order.
				// Do NOT mark as processed if empty, as coupons might be added later via manual admin edits before reaching stable statuses.
				if ( empty( $coupon_items ) ) {
					return;
				}

				$all_success = true;

				foreach ( $coupon_items as $coupon_item ) {
					if ( ! is_a( $coupon_item, 'WC_Order_Item_Coupon' ) ) {
						continue;
					}
					$coupon_code = $coupon_item->get_code();
					if ( empty( $coupon_code ) ) {
						continue;
					}

					$coupon = new WC_Coupon( $coupon_code );

					$coupon_id = ( $this->is_callable( $coupon, 'get_id' ) ) ? $coupon->get_id() : 0;

					if ( empty( $coupon_id ) ) {
						continue;
					}

					$data = $this->prepare_coupon_data( $order, $coupon_item, $coupon );
					if ( false === $this->insert_coupon_row( $data ) ) {
						$all_success = false;
					}
				}

				/**
				 * Mark as processed ONLY after successful insertion of all coupon items.
				 * This ensures the snapshot is captured once and remains immutable for the order.
				 */
				if ( true === $all_success ) {
					if ( $this->is_callable( $order, 'update_meta_data' ) ) {
						$order->update_meta_data( '_wc_sc_coupon_meta_lookup_processed', 'yes' );
						$order->save();
					} else {
						update_post_meta( $order_id, '_wc_sc_coupon_meta_lookup_processed', 'yes' );
					}
				}
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}
		}

		/**
		 * Prepare data for a single coupon row.
		 *
		 * @param WC_Order             $order       The order object.
		 * @param WC_Order_Item_Coupon $coupon_item The order item coupon object.
		 * @param WC_Coupon            $coupon      The coupon object.
		 * @return array The prepared data for insertion.
		 */
		private function prepare_coupon_data( $order, $coupon_item, $coupon ) {

			$coupon_id = ( $this->is_callable( $coupon, 'get_id' ) ) ? $coupon->get_id() : 0;

			$product_ids      = ( $this->is_callable( $coupon, 'get_product_ids' ) ) ? $coupon->get_product_ids() : get_post_meta( $coupon_id, 'product_ids', true );
			$excluded_ids     = ( $this->is_callable( $coupon, 'get_excluded_product_ids' ) ) ? $coupon->get_excluded_product_ids() : get_post_meta( $coupon_id, 'exclude_product_ids', true );
			$product_cats     = ( $this->is_callable( $coupon, 'get_product_categories' ) ) ? $coupon->get_product_categories() : get_post_meta( $coupon_id, 'product_categories', true );
			$excluded_cats    = ( $this->is_callable( $coupon, 'get_excluded_product_categories' ) ) ? $coupon->get_excluded_product_categories() : get_post_meta( $coupon_id, 'exclude_product_categories', true );
			$customer_emails  = ( $this->is_callable( $coupon, 'get_email_restrictions' ) ) ? $coupon->get_email_restrictions() : get_post_meta( $coupon_id, 'customer_email', true );
			$shipping_methods = $this->get_post_meta( $coupon_id, 'sc_restrict_to_shipping_methods', true );
			$payment_methods  = $this->get_post_meta( $coupon_id, 'sc_restrict_to_payment_methods', true );
			$user_roles       = $this->get_post_meta( $coupon_id, 'wc_sc_allowed_user_roles', true );
			$add_products     = $this->get_post_meta( $coupon_id, 'wc_sc_add_product_details', true );

			$pm_ids                  = $this->get_post_meta( $coupon_id, 'wc_sc_payment_method_ids', true );
			$sm_ids                  = $this->get_post_meta( $coupon_id, 'wc_sc_shipping_method_ids', true );
			$allowed_user_roles      = $this->get_post_meta( $coupon_id, 'wc_sc_user_role_ids', true );
			$excluded_user_roles     = $this->get_post_meta( $coupon_id, 'wc_sc_exclude_user_role_ids', true );
			$product_attribute_ids   = $this->get_post_meta( $coupon_id, 'wc_sc_product_attribute_ids', true );
			$exclude_attribute_ids   = $this->get_post_meta( $coupon_id, 'wc_sc_exclude_product_attribute_ids', true );
			$taxonomy_restrictions   = $this->get_post_meta( $coupon_id, 'wc_sc_taxonomy_restrictions', true );
			$qty_restrictions        = $this->get_post_meta( $coupon_id, 'wc_sc_product_quantity_restrictions', true );
			$order_count_restrict    = $this->get_post_meta( $coupon_id, 'wc_sc_order_count_restriction', true );
			$lookup_in               = $this->get_post_meta( $coupon_id, 'sa_cbl_locations_lookup_in', true );
			$billing_locations       = $this->get_post_meta( $coupon_id, 'sa_cbl_billing_locations', true );
			$shipping_locations      = $this->get_post_meta( $coupon_id, 'sa_cbl_shipping_locations', true );
			$excluded_customer_email = $this->get_post_meta( $coupon_id, 'wc_sc_excluded_customer_email', true );
			$no_selectable_product   = $this->get_post_meta( $coupon_id, 'wc_sc_no_of_selectable_product', true );
			$expiry_time             = $this->get_post_meta( $coupon_id, 'wc_sc_expiry_time', true );
			$original_amount         = $this->get_post_meta( $coupon_id, 'wc_sc_original_amount', true );
			$coupon_message          = $this->get_post_meta( $coupon_id, 'wc_coupon_message', true );
			$email_message           = $this->get_post_meta( $coupon_id, 'wc_email_message', true );
			$combined_allowed        = $this->get_post_meta( $coupon_id, 'wc_sc_combined_coupons_allowed', true );
			$combined_blocked        = $this->get_post_meta( $coupon_id, 'wc_sc_combined_coupons_blocked', true );
			$generated_from_order    = $this->get_post_meta( $coupon_id, 'generated_from_order_id', true );
			$coupon_receiver_details = $this->get_post_meta( $coupon_id, 'wc_sc_coupon_receiver_details', true );
			$scheduled_actions_ids   = $this->get_post_meta( $coupon_id, 'wc_sc_scheduled_actions_ids', true );

			$expiry_date               = ( $this->is_callable( $coupon, 'get_date_expires' ) ) ? $coupon->get_date_expires() : get_post_meta( $coupon_id, 'date_expires', true );
			$individual_use            = ( $this->is_callable( $coupon, 'get_individual_use' ) ) ? $coupon->get_individual_use() : get_post_meta( $coupon_id, 'individual_use', true );
			$free_shipping             = ( $this->is_callable( $coupon, 'get_free_shipping' ) ) ? $coupon->get_free_shipping() : get_post_meta( $coupon_id, 'free_shipping', true );
			$apply_before_tax          = $this->get_post_meta( $coupon_id, 'apply_before_tax', true );
			$exclude_sale_items        = ( $this->is_callable( $coupon, 'get_exclude_sale_items' ) ) ? $coupon->get_exclude_sale_items() : get_post_meta( $coupon_id, 'exclude_sale_items', true );
			$auto_apply_coupon         = $this->get_post_meta( $coupon_id, 'wc_sc_auto_apply_coupon', true );
			$is_visible_storewide      = $this->get_post_meta( $coupon_id, 'sc_is_visible_storewide', true );
			$restrict_to_new_user      = $this->get_post_meta( $coupon_id, 'sc_restrict_to_new_user', true );
			$disable_email_restriction = $this->get_post_meta( $coupon_id, 'sc_disable_email_restriction', true );
			$auto_generate_coupon      = $this->get_post_meta( $coupon_id, 'auto_generate_coupon', true );
			$pick_price_of_product     = $this->get_post_meta( $coupon_id, 'is_pick_price_of_product', true );

			if ( empty( $shipping_methods ) ) {
				$shipping_methods = $sm_ids;
			}
			if ( empty( $payment_methods ) ) {
				$payment_methods = $pm_ids;
			}
			if ( empty( $user_roles ) ) {
				$user_roles = $allowed_user_roles;
			}

			$discount_amount = ( $this->is_callable( $coupon_item, 'get_discount' ) ) ? $coupon_item->get_discount() : 0;
			$discount_tax    = ( $this->is_callable( $coupon_item, 'get_discount_tax' ) ) ? $coupon_item->get_discount_tax() : 0;

			$date_expires = null;
			if ( ! empty( $expiry_date ) ) {
				if ( is_a( $expiry_date, 'WC_DateTime' ) ) {
					$date_expires = $expiry_date->date( 'Y-m-d H:i:s' );
				} elseif ( is_numeric( $expiry_date ) ) {
					$date_expires = gmdate( 'Y-m-d H:i:s', absint( $expiry_date ) );
				} else {
					$date_expires = $expiry_date;
				}
			}

			return array(
				'order_id'                            => ( $this->is_callable( $order, 'get_id' ) ) ? $order->get_id() : 0,
				'coupon_id'                           => $coupon_id,
				'coupon_code'                         => ( $this->is_callable( $coupon, 'get_code' ) ) ? $coupon->get_code() : '',
				'discount_amount'                     => $discount_amount,
				'discount_tax'                        => $discount_tax,
				'discount_type'                       => ( $this->is_callable( $coupon, 'get_discount_type' ) ) ? $coupon->get_discount_type() : '',
				'coupon_amount'                       => ( $this->is_callable( $coupon, 'get_amount' ) ) ? $coupon->get_amount() : get_post_meta( $coupon_id, 'coupon_amount', true ),
				'individual_use'                      => ( true === $individual_use || 'yes' === $individual_use ) ? 1 : 0,
				'usage_limit'                         => ( $this->is_callable( $coupon, 'get_usage_limit' ) ) ? $coupon->get_usage_limit() : get_post_meta( $coupon_id, 'usage_limit', true ),
				'usage_limit_per_user'                => ( $this->is_callable( $coupon, 'get_usage_limit_per_user' ) ) ? $coupon->get_usage_limit_per_user() : get_post_meta( $coupon_id, 'usage_limit_per_user', true ),
				'limit_usage_to_x_items'              => ( $this->is_callable( $coupon, 'get_limit_usage_to_x_items' ) ) ? $coupon->get_limit_usage_to_x_items() : get_post_meta( $coupon_id, 'limit_usage_to_x_items', true ),
				'usage_count'                         => ( $this->is_callable( $coupon, 'get_usage_count' ) ) ? $coupon->get_usage_count() : get_post_meta( $coupon_id, 'usage_count', true ),
				'free_shipping'                       => ( true === $free_shipping || 'yes' === $free_shipping ) ? 1 : 0,
				'minimum_amount'                      => ( $this->is_callable( $coupon, 'get_minimum_amount' ) ) ? $coupon->get_minimum_amount() : get_post_meta( $coupon_id, 'minimum_amount', true ),
				'maximum_amount'                      => ( $this->is_callable( $coupon, 'get_maximum_amount' ) ) ? $coupon->get_maximum_amount() : get_post_meta( $coupon_id, 'maximum_amount', true ),
				'date_expires'                        => $date_expires,
				'apply_before_tax'                    => 'yes' === $apply_before_tax ? 1 : 0,
				'exclude_sale_items'                  => ( true === $exclude_sale_items || 'yes' === $exclude_sale_items ) ? 1 : 0,
				'product_ids'                         => ! empty( $product_ids ) ? ( is_array( $product_ids ) ? wp_json_encode( $product_ids ) : $product_ids ) : null,
				'exclude_product_ids'                 => ! empty( $excluded_ids ) ? ( is_array( $excluded_ids ) ? wp_json_encode( $excluded_ids ) : $excluded_ids ) : null,
				'product_categories'                  => ! empty( $product_cats ) ? ( is_array( $product_cats ) ? wp_json_encode( $product_cats ) : $product_cats ) : null,
				'exclude_product_categories'          => ! empty( $excluded_cats ) ? ( is_array( $excluded_cats ) ? wp_json_encode( $excluded_cats ) : $excluded_cats ) : null,
				'customer_emails'                     => ! empty( $customer_emails ) ? ( is_array( $customer_emails ) ? wp_json_encode( $customer_emails ) : $customer_emails ) : null,
				'wc_sc_auto_apply_coupon'             => 'yes' === $auto_apply_coupon ? 1 : 0,
				'sc_is_visible_storewide'             => 'yes' === $is_visible_storewide ? 1 : 0,
				'sc_restrict_to_new_user'             => 'yes' === $restrict_to_new_user ? 1 : 0,
				'sc_disable_email_restriction'        => 'yes' === $disable_email_restriction ? 1 : 0,
				'wc_sc_max_discount'                  => $this->get_post_meta( $coupon_id, 'wc_sc_max_discount', true ),
				'sc_restrict_to_shipping_methods'     => ! empty( $shipping_methods ) ? ( is_array( $shipping_methods ) ? wp_json_encode( $shipping_methods ) : $shipping_methods ) : null,
				'sc_restrict_to_payment_methods'      => ! empty( $payment_methods ) ? ( is_array( $payment_methods ) ? wp_json_encode( $payment_methods ) : $payment_methods ) : null,
				'wc_sc_allowed_user_roles'            => ! empty( $user_roles ) ? ( is_array( $user_roles ) ? wp_json_encode( $user_roles ) : $user_roles ) : null,
				'sc_coupon_validity'                  => $this->get_post_meta( $coupon_id, 'sc_coupon_validity', true ),
				'validity_suffix'                     => $this->get_post_meta( $coupon_id, 'validity_suffix', true ),
				'auto_generate_coupon'                => 'yes' === $auto_generate_coupon ? 1 : 0,
				'coupon_title_prefix'                 => $this->get_post_meta( $coupon_id, 'coupon_title_prefix', true ),
				'coupon_title_suffix'                 => $this->get_post_meta( $coupon_id, 'coupon_title_suffix', true ),
				'wc_sc_add_product_details'           => ! empty( $add_products ) ? ( is_array( $add_products ) ? wp_json_encode( $add_products ) : $add_products ) : null,
				'wc_sc_cheapest_costliest_settings'   => $this->get_post_meta( $coupon_id, 'wc_sc_cheapest_costliest_settings', true ),
				'is_pick_price_of_product'            => 'yes' === $pick_price_of_product ? 1 : 0,
				'wc_sc_payment_method_ids'            => ! empty( $pm_ids ) ? ( is_array( $pm_ids ) ? wp_json_encode( $pm_ids ) : $pm_ids ) : null,
				'wc_sc_shipping_method_ids'           => ! empty( $sm_ids ) ? ( is_array( $sm_ids ) ? wp_json_encode( $sm_ids ) : $sm_ids ) : null,
				'wc_sc_user_role_ids'                 => ! empty( $allowed_user_roles ) ? ( is_array( $allowed_user_roles ) ? wp_json_encode( $allowed_user_roles ) : $allowed_user_roles ) : null,
				'wc_sc_exclude_user_role_ids'         => ! empty( $excluded_user_roles ) ? ( is_array( $excluded_user_roles ) ? wp_json_encode( $excluded_user_roles ) : $excluded_user_roles ) : null,
				'wc_sc_product_attribute_ids'         => ! empty( $product_attribute_ids ) ? ( is_array( $product_attribute_ids ) ? wp_json_encode( $product_attribute_ids ) : $product_attribute_ids ) : null,
				'wc_sc_exclude_product_attribute_ids' => ! empty( $exclude_attribute_ids ) ? ( is_array( $exclude_attribute_ids ) ? wp_json_encode( $exclude_attribute_ids ) : $exclude_attribute_ids ) : null,
				'wc_sc_taxonomy_restrictions'         => ! empty( $taxonomy_restrictions ) ? ( is_array( $taxonomy_restrictions ) ? wp_json_encode( $taxonomy_restrictions ) : $taxonomy_restrictions ) : null,
				'wc_sc_product_quantity_restrictions' => ! empty( $qty_restrictions ) ? ( is_array( $qty_restrictions ) ? wp_json_encode( $qty_restrictions ) : $qty_restrictions ) : null,
				'wc_sc_order_count_restriction'       => ! empty( $order_count_restrict ) ? ( is_array( $order_count_restrict ) ? wp_json_encode( $order_count_restrict ) : $order_count_restrict ) : null,
				'sa_cbl_locations_lookup_in'          => ! empty( $lookup_in ) ? ( is_array( $lookup_in ) && isset( $lookup_in['address'] ) ? $lookup_in['address'] : ( is_string( $lookup_in ) ? $lookup_in : null ) ) : null,
				'sa_cbl_billing_locations'            => ! empty( $billing_locations ) ? ( is_array( $billing_locations ) ? wp_json_encode( $billing_locations ) : $billing_locations ) : null,
				'sa_cbl_shipping_locations'           => ! empty( $shipping_locations ) ? ( is_array( $shipping_locations ) ? wp_json_encode( $shipping_locations ) : $shipping_locations ) : null,
				'wc_sc_excluded_customer_email'       => ! empty( $excluded_customer_email ) ? ( is_array( $excluded_customer_email ) ? wp_json_encode( $excluded_customer_email ) : $excluded_customer_email ) : null,
				'wc_sc_no_of_selectable_product'      => '' !== $no_selectable_product ? (int) $no_selectable_product : null,
				'wc_sc_expiry_time'                   => '' !== $expiry_time ? (int) $expiry_time : null,
				'wc_sc_original_amount'               => '' !== $original_amount ? $original_amount : null,
				'wc_coupon_message'                   => ! empty( $coupon_message ) ? $coupon_message : null,
				'wc_email_message'                    => 'yes' === $email_message ? 1 : 0,
				'wc_sc_combined_coupons_allowed'      => ! empty( $combined_allowed ) ? ( is_array( $combined_allowed ) ? wp_json_encode( $combined_allowed ) : $combined_allowed ) : null,
				'wc_sc_combined_coupons_blocked'      => ! empty( $combined_blocked ) ? ( is_array( $combined_blocked ) ? wp_json_encode( $combined_blocked ) : $combined_blocked ) : null,
				'generated_from_order_id'             => ! empty( $generated_from_order ) ? (int) $generated_from_order : null,
				'wc_sc_coupon_receiver_details'       => ! empty( $coupon_receiver_details ) ? ( is_array( $coupon_receiver_details ) ? wp_json_encode( $coupon_receiver_details ) : $coupon_receiver_details ) : null,
				'wc_sc_scheduled_actions_ids'         => ! empty( $scheduled_actions_ids ) ? ( is_array( $scheduled_actions_ids ) ? wp_json_encode( $scheduled_actions_ids ) : $scheduled_actions_ids ) : null,
				'created_at'                          => current_time( 'mysql', 1 ),
				'updated_at'                          => current_time( 'mysql', 1 ),
			);
		}

		/**
		 * Insert a row into the lookup table.
		 *
		 * @param array $data The data to insert.
		 * @return bool True on success, false on failure.
		 */
		private function insert_coupon_row( $data ) {
			global $wpdb;

			$table_name = $wpdb->prefix . 'wc_sc_order_coupon_meta_lookup';

			$formats = array();
			foreach ( array_keys( $data ) as $column ) {
				if ( in_array( $column, array( 'order_id', 'coupon_id', 'individual_use', 'usage_limit', 'usage_limit_per_user', 'limit_usage_to_x_items', 'usage_count', 'free_shipping', 'apply_before_tax', 'exclude_sale_items', 'wc_sc_auto_apply_coupon', 'sc_is_visible_storewide', 'sc_restrict_to_new_user', 'sc_disable_email_restriction', 'auto_generate_coupon', 'is_pick_price_of_product', 'wc_sc_no_of_selectable_product', 'wc_sc_expiry_time', 'wc_email_message', 'generated_from_order_id' ), true ) ) {
					$formats[] = '%d';
				} elseif ( in_array( $column, array( 'discount_amount', 'discount_tax', 'coupon_amount', 'minimum_amount', 'maximum_amount', 'wc_sc_max_discount', 'sc_coupon_validity', 'wc_sc_original_amount' ), true ) ) {
					$formats[] = '%f';
				} else {
					$formats[] = '%s';
				}
			}

			$columns      = implode( ',', array_keys( $data ) );
			$placeholders = implode( ',', $formats );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.DirectDatabaseQuery.NoCaching
			$query = $wpdb->prepare(
				"INSERT INTO {$table_name} ({$columns}) VALUES ({$placeholders}) ON DUPLICATE KEY UPDATE updated_at = VALUES(updated_at)",
				array_values( $data )
			);

			if ( false === $wpdb->query( $query ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
				$this->sc_block_catch_error(
					new \Exception(
						_x(
							'Failed to insert coupon lookup data.',
							'error message',
							'woocommerce-smart-coupons'
						)
					)
				);
				return false;
			}
			return true;
			// phpcs:enable
		}
	}
}

WC_SC_Order_Coupon_Meta_Lookup::get_instance();
