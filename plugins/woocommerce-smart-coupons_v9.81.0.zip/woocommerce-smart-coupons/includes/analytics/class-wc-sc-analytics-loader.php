<?php
/**
 * Smart Coupons analytics loader
 *
 * Loads analytics-related modules such as insights.
 *
 * @author      StoreApps
 * @since       9.73.0
 * @version     1.1.0
 * @package     WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Analytics_Loader' ) ) {

	/**
	 * Analytics loader for Smart Coupons.
	 *
	 * @since 9.72.0
	 */
	class WC_SC_Analytics_Loader {

		/**
		 * Instance of WC_SC_Analytics_Loader.
		 *
		 * @var WC_SC_Analytics_Loader
		 */
		private static $instance = null;

		/**
		 * Get single instance of WC_SC_Analytics_Loader.
		 *
		 * @return WC_SC_Analytics_Loader
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		private function __construct() {
			// Register admin-only hooks.
			if ( is_admin() ) {
				$this->register_admin_hooks();
			}
		}

		/**
		 * Handle dynamic calls by forwarding to main Smart Coupons instance.
		 *
		 * @param string $function_name Function name.
		 * @param array  $arguments     Arguments passed to function.
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Register admin-only hooks for UI and AJAX.
		 *
		 * @return void
		 */
		protected function register_admin_hooks() {
			add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_widgets' ) );
			add_action( 'wp_ajax_wc_sc_get_insights_metrics', array( $this, 'ajax_get_insights_metrics' ) );
		}

		/**
		 * Generate metrics insights and store in transient.
		 *
		 * @return array
		 */
		public function generate_and_cache_results() {
			try {
				$this->load_insights_dependencies();

				$insights = WC_SC_Insights::get_instance();
				$metrics  = $insights->get_aggregated_insights_data();

				$generated_at = time();

				$results = array(
					'metrics'  => $metrics,
					'metadata' => array(
						'generated_at'        => $generated_at,
						'generated_at_human'  => date_i18n( 'j M', $generated_at ),
						'order_count'         => isset( $metrics['order_count'] ) ? $metrics['order_count'] : 0,
						'dataset_type'        => 'recent_100_paid',
						'calculation_version' => WC_SC_Insights::CALCULATION_VERSION,
					),
				);

				set_transient( 'wc_sc_insights_results', $results, DAY_IN_SECONDS * 1 );

				return $results;
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return array();
			}
		}

		/**
		 * Load revenue insights dependencies if not already loaded.
		 *
		 * @return void
		 */
		private function load_insights_dependencies() {
			if ( ! class_exists( 'WC_SC_Insights_Order_Helper' ) ) {
				require_once WC_SC_PLUGIN_DIRPATH . 'includes/analytics/insights/class-wc-sc-insights-order-helper.php';
			}

			if ( ! class_exists( 'WC_SC_Insights' ) ) {
				require_once WC_SC_PLUGIN_DIRPATH . 'includes/analytics/insights/class-wc-sc-insights.php';
			}

			if ( ! class_exists( 'WC_SC_Revenue_Insights' ) ) {
				require_once WC_SC_PLUGIN_DIRPATH . 'includes/analytics/insights/revenue/class-wc-sc-revenue-insights.php';
			}

			if ( ! class_exists( 'WC_SC_Time_And_Effort' ) ) {
				require_once WC_SC_PLUGIN_DIRPATH . 'includes/analytics/class-wc-sc-time-and-effort.php';
			}

			if ( class_exists( 'WC_SC_Time_And_Effort' ) ) {
				WC_SC_Time_And_Effort::get_instance();
			}
		}

		/**
		 * Register analytics dashboard widgets.
		 *
		 * @return void
		 */
		public function register_dashboard_widgets() {
			try {
				if ( ! current_user_can( 'manage_woocommerce' ) ) {
					return;
				}

				$this->load_insights_dependencies();

				WC_SC_Insights::get_instance()->register_dashboard_widget();
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}
		}

		/**
		 * AJAX handler to return revenue insights metrics.
		 *
		 * @return void
		 */
		public function ajax_get_insights_metrics() {
			try {
				if ( ! current_user_can( 'manage_woocommerce' ) ) {
					wp_send_json_error(
						array(
							'message' => _x( 'Permission denied.', 'ajax error', 'woocommerce-smart-coupons' ),
						)
					);
				}

				check_ajax_referer( 'wc_sc_get_insights_metrics', 'nonce' );

				$this->load_insights_dependencies();

				$results = get_transient( 'wc_sc_insights_results' );

				if ( false !== $results ) {
					$version = isset( $results['metadata']['calculation_version'] ) ? $results['metadata']['calculation_version'] : '1.0.0';
					if ( version_compare( $version, WC_SC_Insights::CALCULATION_VERSION, '<' ) ) {
						delete_transient( 'wc_sc_insights_results' );
						$results = false;
					}
				}

				if ( false === $results ) {
					$results = $this->generate_and_cache_results();
				}

				if ( ! empty( $results ) ) {
					wp_send_json_success(
						array(
							'metrics'  => $results['metrics'],
							'metadata' => $results['metadata'],
						)
					);
				}

				wp_send_json_error(
					array(
						'message' => _x( 'Could not load insights.', 'ajax error', 'woocommerce-smart-coupons' ),
					)
				);
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );

				wp_send_json_error(
					array(
						'message' => _x( 'An error occurred while loading insights.', 'ajax error', 'woocommerce-smart-coupons' ),
					)
				);
			}
		}
	}
}

WC_SC_Analytics_Loader::get_instance();
