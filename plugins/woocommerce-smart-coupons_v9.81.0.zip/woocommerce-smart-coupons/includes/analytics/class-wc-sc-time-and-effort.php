<?php
/**
 * Analyzing & recording time & effort saved by Smart Coupons
 *
 * @author      StoreApps
 * @since       9.73.0
 * @version     1.2.0
 * @package     woocommerce-smart-coupons/includes/analytics
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Time_And_Effort' ) ) {

	/**
	 * Class for analyzing & recording time & effort saved by Smart Coupons
	 */
	class WC_SC_Time_And_Effort {

		/**
		 * Singleton instance
		 *
		 * @var WC_SC_Time_And_Effort|null
		 */
		private static $instance = null;

		/**
		 * Get singleton instance
		 */
		public static function get_instance() {

			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 */
		private function __construct() {

			add_action( 'init', array( $this, 'schedule_daily_event' ) );

			add_action( 'wc_sc_aggregate_daily_time', array( $this, 'process_daily_totals' ) );
			add_filter( 'wc_sc_insights_config', array( $this, 'add_insights_config' ) );
			add_filter( 'wc_sc_insights_metrics', array( $this, 'add_metrics_data' ) );
		}

		/**
		 * Add time and effort metrics data.
		 *
		 * @param array $metrics Existing metrics.
		 * @return array
		 */
		public function add_metrics_data( $metrics ) {
			$metrics['time_savings']           = $this->get_time_saved_seconds();
			$metrics['automated_coupons_sent'] = $this->get_automation_count_value();
			return $metrics;
		}

		/**
		 * Get the automation count value.
		 *
		 * @return int
		 */
		private function get_automation_count_value() {
			$activity = get_option( 'wc_sc_track_activity', array() );
			return ( ! empty( $activity['count']['coupon_generated'] ) ) ? (int) $activity['count']['coupon_generated'] : 0;
		}

		/**
		 * Handle dynamic calls by forwarding to main Smart Coupons instance.
		 *
		 * @param string $function_name Function name.
		 * @param array  $arguments     Arguments passed to function.
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Add time and effort data in dashboard widget section
		 *
		 * @param array $config The configuration.
		 * @return array
		 */
		public function add_insights_config( $config = array() ) {
			$config['sections']['automation'] = array(
				'label'    => _x( 'Automation Insights', 'dashboard widget', 'woocommerce-smart-coupons' ),
				'priority' => 2,
				'metrics'  => array(
					'time_savings'           => array(
						'label'   => _x( 'Time Savings', 'dashboard widget', 'woocommerce-smart-coupons' ),
						'icon'    => 'dashicons-clock',
						'tooltip' => _x( 'Estimated manual effort reduced through Smart Coupons automation.', 'dashboard widget tooltip', 'woocommerce-smart-coupons' ),
						'order'   => 50,
					),
					'automated_coupons_sent' => array(
						'label'   => _x( 'Automated Coupons Sent', 'dashboard widget', 'woocommerce-smart-coupons' ),
						'icon'    => 'dashicons-email-alt',
						'tooltip' => _x( 'Coupons automatically generated and sent via Smart Coupons workflows.', 'dashboard widget tooltip', 'woocommerce-smart-coupons' ),
						'order'   => 60,
					),
				),
			);
			return $config;
		}

		/**
		 * Schedule daily Action Scheduler task
		 */
		public function schedule_daily_event() {

			if ( ! function_exists( 'as_schedule_recurring_action' ) ) {
				return;
			}

			if ( ! as_next_scheduled_action( 'wc_sc_aggregate_daily_time' ) ) {
				$first_run = strtotime( 'tomorrow 00:05:00 UTC' );

				as_schedule_recurring_action(
					$first_run,
					DAY_IN_SECONDS,
					'wc_sc_aggregate_daily_time'
				);
			}
		}

		/**
		 * Aggregate request times per day
		 */
		public function process_daily_totals() {

			$data = get_option( 'wc_sc_track_activity' );

			if ( empty( $data['time'] ) || ! is_array( $data['time'] ) ) {
				return;
			}

			$times = $data['time'];

			// Midnight UTC today.
			$now            = time();
			$today_boundary = $now - ( $now % DAY_IN_SECONDS );

			$daily_totals = array();

			foreach ( $times as $request_time => $entry ) {
				$timestamp = (int) $request_time;

				// Ignore today's entries.
				if ( $timestamp >= $today_boundary ) {
					continue;
				}

				if ( empty( $entry['total'] ) ) {
					unset( $times[ $request_time ] );
					continue;
				}

				// Calculate day key (UTC midnight).
				$day_key = $timestamp - ( $timestamp % DAY_IN_SECONDS );

				if ( ! isset( $daily_totals[ $day_key ] ) ) {
					$daily_totals[ $day_key ] = 0;
				}

				$daily_totals[ $day_key ] += (float) $entry['total'];

				unset( $times[ $request_time ] );
			}

			if ( ! empty( $daily_totals ) ) {
				if ( empty( $data['days'] ) ) {
					$data['days'] = array();
				}

				foreach ( $daily_totals as $day => $total ) {
					if ( isset( $data['days'][ $day ] ) ) {
						$data['days'][ $day ] += $total;
					} else {
						$data['days'][ $day ] = $total;
					}
				}
			}

			$data['time'] = $times;

			update_option( 'wc_sc_track_activity', $data, false );
		}

		/**
		 * Log request start time
		 */
		public function log_request_start_time() {
			$activity = get_option( 'wc_sc_track_activity', null );
			if ( empty( $activity ) ) {
				$activity = array();
			}
			if ( empty( $activity['days'] ) || ! is_array( $activity['days'] ) ) {
				$activity['days'] = array();
			}
			if ( empty( $activity['time'] ) || ! is_array( $activity['time'] ) ) {
				$activity['time'] = array();
			}
			$request_id = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) sanitize_text_field( wp_unslash( $_SERVER['REQUEST_TIME_FLOAT'] ) ) : 0;
			if ( empty( $request_id ) ) {
				return;
			}
			$request_id_str = strval( $request_id );
			if ( empty( $activity['time'][ $request_id_str ] ) || ! is_array( $activity['time'][ $request_id_str ] ) ) {
				$activity['time'][ $request_id_str ] = array();
			}
			if ( ! empty( $activity['time'][ $request_id_str ]['start'] ) ) {
				$current_time                                 = microtime( true );
				$activity['time'][ $request_id_str ]['total'] = $current_time - $activity['time'][ $request_id_str ]['start'];
				$activity['time'][ $request_id_str ]['start'] = $current_time;
			} else {
				$activity['time'][ $request_id_str ]['start'] = microtime( true );
			}
			update_option( 'wc_sc_track_activity', $activity, 'no' );
		}

		/**
		 * Log request top time
		 */
		public function log_request_stop_time() {
			$activity = get_option( 'wc_sc_track_activity', null );
			if ( empty( $activity ) ) {
				$activity = array();
			}
			if ( empty( $activity['days'] ) || ! is_array( $activity['days'] ) ) {
				$activity['days'] = array();
			}
			if ( empty( $activity['time'] ) || ! is_array( $activity['time'] ) ) {
				$activity['time'] = array();
			}
			$request_id = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) sanitize_text_field( wp_unslash( $_SERVER['REQUEST_TIME_FLOAT'] ) ) : 0;
			if ( empty( $request_id ) ) {
				return;
			}
			$request_id_str = strval( $request_id );
			if ( empty( $activity['time'][ $request_id_str ] ) || ! is_array( $activity['time'][ $request_id_str ] ) ) {
				$activity['time'][ $request_id_str ] = array();
			}
			if ( ! empty( $activity['time'][ $request_id_str ]['start'] ) ) {
				$current_time = microtime( true );
				if ( empty( $activity['time'][ $request_id_str ]['total'] ) ) {
					$activity['time'][ $request_id_str ]['total'] = $current_time - $activity['time'][ $request_id_str ]['start'];
				} else {
					$activity['time'][ $request_id_str ]['total'] += $current_time - $activity['time'][ $request_id_str ]['start'];
				}
				$activity['time'][ $request_id_str ]['start'] = $current_time;
			} else {
				$current_time = microtime( true );
				if ( empty( $activity['time'][ $request_id_str ]['total'] ) ) {
					$activity['time'][ $request_id_str ]['total'] = $current_time - floatval( $request_id );
				} else {
					$activity['time'][ $request_id_str ]['total'] += $current_time - floatval( $request_id );
				}
				$activity['time'][ $request_id_str ]['start'] = $current_time;
			}
			update_option( 'wc_sc_track_activity', $activity, 'no' );
		}

		/**
		 * Track coupon count
		 */
		public function track_coupon_count() {
			$posted_data = get_option( 'woo_sc_generate_coupon_posted_data' );
			if ( ! empty( $posted_data['total_coupons_to_generate'] ) ) {
				$activity = get_option( 'wc_sc_track_activity', null );
				if ( empty( $activity ) ) {
					$activity = array();
				}
				if ( empty( $activity['count'] ) || ! is_array( $activity['count'] ) ) {
					$activity['count'] = array();
				}
				if ( ! empty( $activity['count']['coupon_generated'] ) ) {
					$activity['count']['coupon_generated'] += $posted_data['total_coupons_to_generate'];
				} else {
					$activity['count']['coupon_generated'] = $posted_data['total_coupons_to_generate'];
				}
				$is_email_coupon = get_option( 'woo_sc_is_email_imported_coupons' );
				if ( 'yes' === $is_email_coupon ) {
					if ( ! empty( $activity['count']['coupon_emailed'] ) ) {
						$activity['count']['coupon_emailed'] += $posted_data['total_coupons_to_generate'];
					} else {
						$activity['count']['coupon_emailed'] = $posted_data['total_coupons_to_generate'];
					}
				}
				update_option( 'wc_sc_track_activity', $activity, 'no' );
			}
		}

		/**
		 * Increment count of coupon generated
		 *
		 * @param integer $count Increment by this count.
		 */
		public function increment_coupon_generated( $count = 1 ) {
			$activity = get_option( 'wc_sc_track_activity', null );
			if ( empty( $activity ) ) {
				$activity = array();
			}
			if ( empty( $activity['count'] ) || ! is_array( $activity['count'] ) ) {
				$activity['count'] = array();
			}
			if ( ! empty( $activity['count']['coupon_generated'] ) ) {
				$activity['count']['coupon_generated'] += $count;
			} else {
				$activity['count']['coupon_generated'] = $count;
			}
			update_option( 'wc_sc_track_activity', $activity, 'no' );
		}

		/**
		 * Increment count of coupon emailed
		 *
		 * @param integer $count Increment by this count.
		 */
		public function increment_coupon_emailed( $count = 1 ) {
			$activity = get_option( 'wc_sc_track_activity', null );
			if ( empty( $activity ) ) {
				$activity = array();
			}
			if ( empty( $activity['count'] ) || ! is_array( $activity['count'] ) ) {
				$activity['count'] = array();
			}
			if ( ! empty( $activity['count']['coupon_emailed'] ) ) {
				$activity['count']['coupon_emailed'] += $count;
			} else {
				$activity['count']['coupon_emailed'] = $count;
			}
			update_option( 'wc_sc_track_activity', $activity, 'no' );
		}

		/**
		 * Calculate time saved in seconds
		 */
		public function get_time_saved_seconds() {
			$original_time_taken_multiplier = array(
				'coupon_generated' => 8,
				'coupon_emailed'   => 10,
			);
			$activity                       = get_option( 'wc_sc_track_activity', array() );
			if ( ! empty( $activity ) || ! is_scalar( $activity ) ) {
				$time_taken            = 0;
				$time_taken_by_wc      = 0;
				$coupon_generated_time = 0;
				$coupon_emailed_time   = 0;
				if ( ! empty( $activity['days'] ) && is_array( $activity['days'] ) ) {
					$time_taken += array_sum( $activity['days'] );
				}
				if ( ! empty( $activity['time'] ) && is_array( $activity['time'] ) ) {
					$time_taken += array_sum( array_column( $activity['time'], 'total' ) );
				}
				if ( ! empty( $activity['count'] ) && ! is_scalar( $activity['count'] ) ) {
					foreach ( $activity['count'] as $action => $count ) {
						if ( 'coupon_generated' === $action ) {
							$coupon_generated_time = $original_time_taken_multiplier['coupon_generated'] * $activity['count']['coupon_generated'];
						}
						if ( 'coupon_emailed' === $action ) {
							$coupon_emailed_time = $original_time_taken_multiplier['coupon_emailed'] * $activity['count']['coupon_emailed'];
						}
					}
					$time_taken_by_wc = $coupon_generated_time + $coupon_emailed_time;
				}
				return round( $time_taken_by_wc - $time_taken, 5 );
			}
			return 0;
		}

		/**
		 * Format time to human readable format
		 *
		 * @param integer $seconds Number of seconds.
		 * @return string
		 */
		public function format_time( $seconds ) {
			return human_time_diff( time() - $seconds, time() );
		}

		/**
		 * Get automation count
		 *
		 * @return integer
		 */
		public function get_automation_count() {
			$activity = get_option( 'wc_sc_track_activity', array() );
			if ( ! empty( $activity['count'] ) ) {
				return $activity['count'];
			}
			return array();
		}
	}

}

WC_SC_Time_And_Effort::get_instance();
