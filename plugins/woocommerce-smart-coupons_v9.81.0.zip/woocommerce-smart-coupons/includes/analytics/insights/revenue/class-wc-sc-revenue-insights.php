<?php
/**
 * Smart Coupons revenue insights
 *
 * Aggregates Smart Coupons revenue metrics over a set of orders.
 *
 * @author      StoreApps
 * @since       9.73.0
 * @version     1.1.0
 * @package     WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Revenue_Insights' ) ) {

	/**
	 * Class WC_SC_Revenue_Insights
	 */
	class WC_SC_Revenue_Insights {

		/**
		 * Instance of WC_SC_Revenue_Insights.
		 *
		 * @var WC_SC_Revenue_Insights
		 */
		private static $instance = null;

		/**
		 * Order helper instance.
		 *
		 * @var WC_SC_Insights_Order_Helper
		 */
		protected $order_helper;

		/**
		 * Get single instance of WC_SC_Revenue_Insights.
		 *
		 * @return WC_SC_Revenue_Insights
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->order_helper = new WC_SC_Insights_Order_Helper();
			add_filter( 'wc_sc_insights_config', array( $this, 'add_insights_config' ) );
			add_filter( 'wc_sc_insights_process_order', array( $this, 'process_order' ), 10, 2 );
		}

		/**
		 * Handle call to functions which is not available in this class.
		 *
		 * @param string $function_name Function name.
		 * @param array  $arguments     Arguments passed while calling $function_name.
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Add insights config for revenue insights.
		 *
		 * @param array $config Existing config.
		 * @return array
		 */
		public function add_insights_config( $config ) {
			$config['sections']['revenue'] = array(
				'label'    => _x( 'Revenue Insights', 'dashboard widget', 'woocommerce-smart-coupons' ),
				'priority' => 1,
				'metrics'  => array(
					'revenue_influenced'    => array(
						'label'   => _x( 'Revenue Influenced', 'dashboard widget', 'woocommerce-smart-coupons' ),
						'icon'    => 'dashicons-chart-line',
						'tooltip' => _x( 'Revenue generated from orders where Smart Coupons were applied.', 'dashboard widget tooltip', 'woocommerce-smart-coupons' ),
						'order'   => 10,
					),
					'orders_influenced'     => array(
						'label'   => _x( 'Orders Influenced', 'dashboard widget', 'woocommerce-smart-coupons' ),
						'icon'    => 'dashicons-products',
						'tooltip' => _x( 'Orders where Smart Coupons contributed to the purchase.', 'dashboard widget tooltip', 'woocommerce-smart-coupons' ),
						'order'   => 20,
					),
					'store_credit_redeemed' => array(
						'label'   => _x( 'Store Credit Redeemed', 'dashboard widget', 'woocommerce-smart-coupons' ),
						'icon'    => 'dashicons-tickets-alt',
						'tooltip' => _x( 'Total store credit redeemed by customers.', 'dashboard widget tooltip', 'woocommerce-smart-coupons' ),
						'order'   => 30,
					),
					'coupon_driven_sales'   => array(
						'label'   => _x( 'Coupon-Driven Sales', 'dashboard widget', 'woocommerce-smart-coupons' ),
						'icon'    => 'dashicons-tag',
						'tooltip' => _x( 'Revenue generated from products added through Smart Coupon actions.', 'dashboard widget tooltip', 'woocommerce-smart-coupons' ),
						'order'   => 40,
					),
				),
			);

			return $config;
		}

		/**
		 * Process a single order for insights.
		 *
		 * @param array    $metrics Current metrics.
		 * @param WC_Order $order   Order object.
		 * @return array
		 */
		public function process_order( $metrics, $order ) {
			try {
				if ( ! $order instanceof WC_Order ) {
					return $metrics;
				}

				// 1. Store Credit Redeemed.
				$metrics['store_credit_redeemed'] = ( isset( $metrics['store_credit_redeemed'] ) ? (float) $metrics['store_credit_redeemed'] : 0.0 ) + $this->order_helper->get_store_credit_used( $order );

				// 2. Coupon-Driven Sales.
				$metrics['coupon_driven_sales'] = ( isset( $metrics['coupon_driven_sales'] ) ? (float) $metrics['coupon_driven_sales'] : 0.0 ) + $this->order_helper->get_action_products_value( $order );

				// 3. Influenced Check.
				if ( $this->order_helper->is_smart_coupons_order( $order ) ) {
					$metrics['orders_influenced']  = ( isset( $metrics['orders_influenced'] ) ? (int) $metrics['orders_influenced'] : 0 ) + 1;
					$metrics['revenue_influenced'] = ( isset( $metrics['revenue_influenced'] ) ? (float) $metrics['revenue_influenced'] : 0.0 ) + (float) $order->get_total();
				}

				return $metrics;
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return $metrics;
			}
		}

		/**
		 * Get empty metrics array.
		 *
		 * @return array
		 */
		public function get_empty_metrics() {
			return array(
				'revenue_influenced'    => wc_price( 0.0 ),
				'orders_influenced'     => number_format_i18n( 0 ),
				'store_credit_redeemed' => wc_price( 0.0 ),
				'coupon_driven_sales'   => wc_price( 0.0 ),
			);
		}
	}
}
WC_SC_Revenue_Insights::get_instance();
