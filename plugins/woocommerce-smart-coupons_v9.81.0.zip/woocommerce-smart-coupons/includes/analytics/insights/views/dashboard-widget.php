<?php
/**
 * Smart Coupons insights dashboard widget view.
 *
 * @package WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wc_sc_nonce       = isset( $metrics['nonce'] ) ? wp_unslash( $metrics['nonce'] ) : '';
$wc_sc_ajax_action = isset( $metrics['ajax_action'] ) ? sanitize_text_field( wp_unslash( $metrics['ajax_action'] ) ) : 'wc_sc_get_insights_metrics';
$wc_sc_config      = isset( $metrics['config'] ) ? $metrics['config'] : array();

?>
<style>
	#wc_sc_insights .inside { padding: 0; margin: 0; }
	.wc-sc-widget-container,
	.wc-sc-widget-container *,
	.wc-sc-widget-container *::before,
	.wc-sc-widget-container *::after {
		box-sizing: border-box;
	}
	.wc-sc-widget-container { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; background: #fff; overflow: hidden; width: 100%; }
	
	/* Results Context Line */
	.wc-sc-results-context { 
		padding: 12px 20px; 
		color: #646970; 
		font-size: 0.75rem; 
		display: flex; 
		align-items: center; 
		gap: 10px; 
		background: #fff; 
		border-bottom: 0;
		font-weight: 400;
	}
	.wc-sc-results-context .wc-sc-date { color: #8c8f94; }
	.wc-sc-results-context .dashicons-info { 
		font-size: 14px; 
		width: 14px; 
		height: 14px; 
		color: #dcdcde; 
		cursor: help; 
		pointer-events: auto;
	}

	/* Balanced 2x3 Grid using CSS Grid */
	.wc-sc-stats-container {
		display: grid;
		grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
		border-top: 1px solid #dcdcde;
		background: #dcdcde;
		gap: 1px;
		width: 100%;
		align-items: stretch;
	}
	
	.wc-sc-kpi-card {
		padding: 24px 16px;
		display: flex;
		align-items: center;
		gap: 12px;
		background: #fff;
		min-height: 96px;
		min-width: 0;
	}
	.wc-sc-kpi-card:hover { background: #fcfcfc; }

	/* Icon Wrapper Styling */
	.wc-sc-kpi-icon-wrapper {
		width: 44px;
		height: 44px;
		border-radius: 50%;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
	}
	.wc-sc-kpi-icon-wrapper .dashicons { font-size: 24px; width: 24px; height: 24px; }

	/* Content Styling */
	.wc-sc-kpi-content {
		display: flex;
		flex-direction: column;
		min-width: 0;
		text-align: left;
		justify-content: center;
		flex: 1;
	}
	.wc-sc-kpi-value { 
		font-size: 1.25rem; 
		font-weight: 600; 
		color: #1d2327; 
		line-height: 1.1; 
		margin-bottom: 4px; 
		white-space: nowrap;
	}
	.wc-sc-kpi-label-wrapper { display: flex; align-items: center; gap: 4px; line-height: 1.2; width: 100%; }
	.wc-sc-kpi-label {
		font-size: 0.75rem;
		color: #646970;
		font-weight: 500;
		line-height: 1.2;
		flex: 1;
		white-space: normal;
		overflow: hidden;
		text-overflow: ellipsis;
	}
	.wc-sc-kpi-tooltip-trigger { 
		font-size: 12px; 
		width: 12px; 
		height: 12px; 
		color: #dcdcde; 
		cursor: help; 
		display: inline-flex; 
		align-items: center; 
		vertical-align: middle; 
		flex-shrink: 0; 
		pointer-events: auto;
		margin-left: 4px;
	}

	/* Skeleton / Loading States */
	.wc-sc-kpi-value.is-loading { 
		width: 80px; 
		height: 24px; 
		background: #f0f0f1; 
		border-radius: 4px; 
		color: transparent; 
		display: inline-block;
		animation: wc-sc-skeleton-pulse 1.5s infinite ease-in-out;
	}
	@keyframes wc-sc-skeleton-pulse {
		0% { opacity: 1; }
		50% { opacity: 0.5; }
		100% { opacity: 1; }
	}

	.wc-sc-error-message { padding: 12px 20px; background: #fcf0f1; border-bottom: 1px solid #dcdcde; color: #d63638; font-size: 13px; display: none; }

	/* Footer Links */
	.wc-sc-dashboard-footer { display: flex; border-top: 1px solid #dcdcde; background: #fff; }
	.wc-sc-dashboard-footer a {
		flex: 1;
		padding: 16px;
		text-align: center;
		color: #2271b1;
		text-decoration: none;
		font-weight: 500;
		font-size: 13px;
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 8px;
		border-right: 1px solid #dcdcde;
	}
	.wc-sc-dashboard-footer a:last-child { border-right: 0; }
	.wc-sc-dashboard-footer a:hover { background: #f6f7f7; color: #135e96; }
	.wc-sc-dashboard-footer a .dashicons { font-size: 18px; width: 18px; height: 18px; color: #2271b1; }

	/* KPI Specific Color Schemes */
	.wc-sc-kpi-card[data-metric-key="revenue_influenced"] .wc-sc-kpi-icon-wrapper { background: #f0f9f0; color: #2e7d32; }
	.wc-sc-kpi-card[data-metric-key="orders_influenced"] .wc-sc-kpi-icon-wrapper { background: #eef4ff; color: #1565c0; }
	.wc-sc-kpi-card[data-metric-key="store_credit_redeemed"] .wc-sc-kpi-icon-wrapper { background: #f0f9f0; color: #2e7d32; }
	.wc-sc-kpi-card[data-metric-key="coupon_driven_sales"] .wc-sc-kpi-icon-wrapper { background: #f0f9f0; color: #2e7d32; }
	.wc-sc-kpi-card[data-metric-key="time_savings"] .wc-sc-kpi-icon-wrapper { background: #f5ecfb; color: #7b1fa2; }
	.wc-sc-kpi-card[data-metric-key="automated_coupons_sent"] .wc-sc-kpi-icon-wrapper { background: #f5ecfb; color: #7b1fa2; }

	@media (max-width: 782px) {
		.wc-sc-stats-container {
			grid-template-columns: 1fr;
		}
		.wc-sc-dashboard-footer { flex-direction: column; }
		.wc-sc-dashboard-footer a { border-right: 0; border-bottom: 1px solid #dcdcde; }
		.wc-sc-dashboard-footer a:last-child { border-bottom: 0; }
	}
</style>

<div class="wc-sc-widget-container" id="wc-sc-results-widget"></div>

<?php
wp_register_script( 'wc-smart-coupons-results-inline', '', array(), $this->get_smart_coupons_version(), true );
wp_enqueue_script( 'wc-smart-coupons-results-inline' );

wp_localize_script(
	'wc-smart-coupons-results-inline',
	'wcScResultsData',
	array(
		'ajax_url' => admin_url( 'admin-ajax.php' ),
		'nonce'    => $wc_sc_nonce,
		'action'   => $wc_sc_ajax_action,
		'config'   => $wc_sc_config,
		'strings'  => array(
			'recent_100'      => _x( 'Recent 100 orders', 'dashboard widget', 'woocommerce-smart-coupons' ),
			/* translators: %s: date */
			'as_of'           => _x( '(as of %s)', 'dashboard widget', 'woocommerce-smart-coupons' ),
			'results_tooltip' => _x( 'This widget shows your most recent 100 paid orders to keep your dashboard fast.', 'dashboard widget tooltip', 'woocommerce-smart-coupons' ),
			'dashboard'       => _x( 'Dashboard', 'dashboard widget footer link', 'woocommerce-smart-coupons' ),
			'settings'        => _x( 'Settings', 'dashboard widget footer link', 'woocommerce-smart-coupons' ),
			'network_error'   => _x( 'Could not load results. Please try refreshing.', 'dashboard widget error', 'woocommerce-smart-coupons' ),
			'currency_symbol' => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401, get_bloginfo( 'charset' ) ),
			'currency_pos'    => get_option( 'woocommerce_currency_pos' ),
		),
	)
);

$wc_sc_inline_js = <<<'JS'
( function() {
	const container = document.getElementById( 'wc-sc-results-widget' );
	const data      = window?.wcScResultsData;
	if ( ! container || ! data ) return;

	let isFetching = false;

	/**
	 * Renders the UI shell.
	 */
	const renderSkeleton = ( config, strings ) => {
		if ( container.getAttribute( 'data-initialized' ) ) return;
		
		let html = `<div class="wc-sc-error-message" id="wc-sc-error-msg"></div>`;

		html += `
			<div class="wc-sc-results-context">
				<span class="wc-sc-context-label">${strings.recent_100}</span>
				<span class="wc-sc-date" id="wc-sc-results-date"></span>
				<span class="dashicons dashicons-info" title="${strings.results_tooltip}"></span>
			</div>
		`;

		html += `<div class="wc-sc-stats-container">`;

		if ( config && config.sections ) {
			const sortedSectionIds = Object.keys( config.sections ).sort( ( a, b ) => {
				return ( config.sections[a].priority || 10 ) - ( config.sections[b].priority || 10 );
			} );

			sortedSectionIds.forEach( sectionId => {
				const metrics = config.sections[ sectionId ].metrics || {};
				const sortedKeys = Object.keys( metrics ).sort( ( a, b ) => {
					return ( metrics[a].order || 100 ) - ( metrics[b].order || 100 );
				} );

				sortedKeys.forEach( key => {
					const metric = metrics[key];
					html += `
						<div class="wc-sc-kpi-card wc-sc-single-stats" data-metric-key="${key}">
							<div class="wc-sc-kpi-icon-wrapper">
								<span class="dashicons ${metric.icon || 'dashicons-chart-area'}"></span>
							</div>
							<div class="wc-sc-kpi-content">
								<div class="wc-sc-kpi-value wc-sc-value is-loading" data-metric="${key}">---</div>
								<div class="wc-sc-kpi-label-wrapper">
									<span class="wc-sc-kpi-label wc-sc-label" title="${metric.label || ''}">${metric.label || ''}</span>
									${metric.tooltip ? `<span class="dashicons dashicons-info wc-sc-kpi-tooltip-trigger" title="${metric.tooltip}"></span>` : ''}
								</div>
							</div>
						</div>
					`;
				} );
			} );
		}

		html += `</div>`;

		html += `
			<div class="wc-sc-dashboard-footer">
				<a href="${admin_url( 'admin.php?page=wc-smart-coupons' )}" target="_blank" rel="noopener noreferrer">
					${strings.dashboard}<span class="dashicons dashicons-external"></span>
				</a>
				<a href="${admin_url( 'admin.php?page=wc-settings&tab=wc-smart-coupons' )}" target="_blank" rel="noopener noreferrer">
					${strings.settings}<span class="dashicons dashicons-external"></span>
				</a>
			</div>
		`;

		container.innerHTML = html;
		container.setAttribute( 'data-initialized', '1' );
	};

	const admin_url = ( path ) => {
		const base = data.ajax_url.replace( 'admin-ajax.php', '' );
		return base + path;
	};

	const formatCurrency = ( value ) => {
		const symbol = data.strings.currency_symbol || '$';
		const pos = data.strings.currency_pos || 'left';
		const formatted = new Intl.NumberFormat( undefined, {
			minimumFractionDigits: 2,
			maximumFractionDigits: 2
		} ).format( value );
		
		switch ( pos ) {
			case 'left':
				return `${symbol}${formatted}`;
			case 'right':
				return `${formatted}${symbol}`;
			case 'left_space':
				return `${symbol} ${formatted}`;
			case 'right_space':
				return `${formatted} ${symbol}`;
			default:
				return `${symbol}${formatted}`;
		}
	};

	const formatValue = ( key, value ) => {
		if ( [ 'revenue_influenced', 'store_credit_redeemed', 'coupon_driven_sales' ].includes( key ) ) {
			return formatCurrency( value );
		}
		if ( key === 'time_savings' ) {
			const minutes = Math.round( value / 60 );
			return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'}`;
		}
		return value;
	};

	const updateUI = ( result ) => {
		const errEl = document.getElementById( 'wc-sc-error-msg' );
		if ( errEl ) errEl.style.display = 'none';

		if ( result.metrics ) {
			Object.keys( result.metrics ).forEach( key => {
				const el = container.querySelector( `[data-metric="${key}"]` );
				if ( el ) {
					el.textContent = formatValue( key, result.metrics[key] );
					el.classList.remove( 'is-loading' );
				}
			} );
		}

		if ( result.metadata && result.metadata.generated_at_human ) {
			const dateEl = document.getElementById( 'wc-sc-results-date' );
			if ( dateEl ) {
				dateEl.textContent = data.strings.as_of.replace( '%s', result.metadata.generated_at_human );
			}
		}
	};

	const fetchResults = async () => {
		if ( isFetching ) return;
		isFetching = true;

		try {
			const formData = new FormData();
			formData.append( 'action', data.action );
			formData.append( 'nonce', data.nonce );

			const response = await fetch( data.ajax_url, { method: 'POST', body: formData } );
			if ( ! response.ok ) throw new Error();

			const result = await response.json();
			if ( result.success ) {
				updateUI( result.data );
			}
		} catch ( e ) {
			const errEl = document.getElementById( 'wc-sc-error-msg' );
			if ( errEl ) {
				errEl.textContent = data.strings.network_error;
				errEl.style.display = 'block';
			}
		} finally {
			isFetching = false;
		}
	};

	const init = () => {
		renderSkeleton( data.config, data.strings );

		if ( 'IntersectionObserver' in window ) {
			const observer = new IntersectionObserver( ( entries ) => {
				if ( entries[0].isIntersecting ) {
					fetchResults();
					observer.unobserve( container );
				}
			}, { rootMargin: '50px' } );
			observer.observe( container );
		} else {
			fetchResults();
		}
	};

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
JS;

wp_add_inline_script( 'wc-smart-coupons-results-inline', $wc_sc_inline_js );
?>
