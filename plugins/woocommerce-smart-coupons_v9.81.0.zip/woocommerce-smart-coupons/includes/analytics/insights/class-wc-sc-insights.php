<?php
/**
 * Smart Coupons insights
 *
 * Controller for Smart Coupons insights dashboard widget.
 *
 * @author      StoreApps
 * @since       9.73.0
 * @version     1.1.0
 * @package     WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Insights' ) ) {

	/**
	 * Class WC_SC_Insights
	 */
	class WC_SC_Insights {

		/**
		 * Calculation version for insights metrics.
		 * Increment this when the logic changes to force a cache refresh.
		 *
		 * @var string
		 */
		const CALCULATION_VERSION = '1.0.0';

		/**
		 * Instance of WC_SC_Insights.
		 *
		 * @var WC_SC_Insights
		 */
		private static $instance = null;

		/**
		 * Get single instance of WC_SC_Insights.
		 *
		 * @return WC_SC_Insights
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Handle dynamic calls by forwarding to main Smart Coupons instance.
		 *
		 * @param string $function_name Function name.
		 * @param array  $arguments     Arguments passed to function.
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return null;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Register insights dashboard widget.
		 *
		 * @return void
		 */
		public function register_dashboard_widget() {
			try {
				wp_add_dashboard_widget(
					'wc_sc_insights',
					_x( 'Smart Coupons – Results', 'dashboard widget title', 'woocommerce-smart-coupons' ),
					array( $this, 'render_dashboard_widget' )
				);
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}
		}

		/**
		 * Get aggregated insights data using a single-pass loop.
		 *
		 * @return array
		 */
		public function get_aggregated_insights_data() {
			try {
				$helper    = new WC_SC_Insights_Order_Helper();
				$order_ids = $helper->get_recent_order_ids( 100 );
				$metrics   = $this->get_empty_metrics();

				if ( ! empty( $order_ids ) ) {
					foreach ( $order_ids as $order_id ) {
						$order = wc_get_order( $order_id );

						if ( ! $order instanceof WC_Order ) {
							continue;
						}

						/**
						 * Filters the metrics during the single-pass order loop.
						 *
						 * @since 9.73.0
						 * @param array    $metrics The metrics accumulator.
						 * @param WC_Order $order   The current order object.
						 */
						$metrics = apply_filters( 'wc_sc_insights_process_order', $metrics, $order );
					}
				}

				/**
				 * Filters the final aggregated metrics before returning.
				 *
				 * @since 9.73.0
				 * @param array $metrics The aggregated metrics.
				 */
				return apply_filters( 'wc_sc_insights_metrics', $metrics );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return $this->get_empty_metrics();
			}
		}

		/**
		 * Render insights dashboard widget.
		 *
		 * @return void
		 */
		public function render_dashboard_widget() {
			try {
				$view = WC_SC_PLUGIN_DIRPATH . 'includes/analytics/insights/views/dashboard-widget.php';

				if ( file_exists( $view ) ) {
					$metrics = array(
						'nonce'       => wp_create_nonce( 'wc_sc_get_insights_metrics' ),
						'ajax_action' => 'wc_sc_get_insights_metrics',
						'config'      => $this->get_config(),
					);

					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					include $view;
				}
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}
		}

		/**
		 * Get the metrics configuration for the Insights widget.
		 *
		 * This defines the sections, labels, and individual metrics to be displayed.
		 * Developers can use the 'wc_sc_insights_config' filter to extend this.
		 *
		 * @return array
		 */
		public function get_config() {
			/**
			 * Filters the configuration for Smart Coupons insights.
			 *
			 * @since 9.73.0
			 *
			 * @param array $config The initial configuration array.
			 *
			 * @example
			 * add_filter( 'wc_sc_insights_config', function( $config ) {
			 *     $config['sections']['my_section'] = array(
			 *         'label'    => 'My Section',
			 *         'priority' => 20,
			 *         'metrics'  => array(
			 *             'my_metric' => array(
			 *                 'label' => 'My Metric',
			 *             ),
			 *         ),
			 *     );
			 *     return $config;
			 * } );
			 */
			return apply_filters( 'wc_sc_insights_config', array( 'sections' => array() ) );
		}

		/**
		 * Get a flat array of all registered metric keys.
		 *
		 * @return array
		 */
		public function get_registered_metric_keys() {
			try {
				$config = $this->get_config();
				$keys   = array();

				if ( ! empty( $config['sections'] ) ) {
					foreach ( $config['sections'] as $section ) {
						if ( ! empty( $section['metrics'] ) ) {
							$keys = array_merge( $keys, array_keys( $section['metrics'] ) );
						}
					}
				}

				return array_unique( $keys );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return array();
			}
		}

		/**
		 * Generate an empty metrics array based on currently registered keys.
		 *
		 * @return array
		 */
		public function get_empty_metrics() {
			try {
				$keys    = $this->get_registered_metric_keys();
				$metrics = array();

				foreach ( $keys as $key ) {
					$metrics[ $key ] = 0;
				}

				return $metrics;
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return array();
			}
		}
	}
}

WC_SC_Insights::get_instance();
