<?php
/**
 * Smart Coupons BOGO Preset Coupon
 *
 * @author      StoreApps
 * @version     1.4.0
 *
 * @package     woocommerce-smart-coupons/includes/
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WC_SC_Preset_BOGO_Coupon' ) ) {

	/**
	 * Handles registration and rendering of the BOGO coupon preset UI.
	 *
	 * This class keeps BOGO-specific logic and delegates markup rendering to
	 * template files so the preset framework can be extended safely.
	 */
	class WC_SC_Preset_BOGO_Coupon {

		/**
		 * Holds class instance.
		 *
		 * @var WC_SC_Preset_BOGO_Coupon|null
		 */
		private static $instance = null;

		/**
		 * Constructor.
		 *
		 * @return void
		 */
		private function __construct() {

			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ), 21 );
			add_action( 'admin_head', array( $this, 'add_coupon_button' ) );
			add_action( 'rest_api_init', array( $this, 'register_sell_gift_card_routes' ) );
		}

		/**
		 * Gets class instance.
		 *
		 * @return WC_SC_Preset_BOGO_Coupon
		 */
		public static function get_instance() {

			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Handles proxy calls for unavailable methods.
		 *
		 * @param string $function_name The function name.
		 * @param array  $arguments     Arguments passed while calling $function_name.
		 *
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Enqueues scripts and styles on coupon admin screen.
		 *
		 * @return void
		 */
		public function enqueue_assets() {

			$screen = get_current_screen();

			if ( empty( $screen->id ) || ! in_array( $screen->id, array( 'shop_coupon', 'edit-shop_coupon', 'marketing_page_wc-smart-coupons' ), true ) ) {
				return;
			}

			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
			$this->enqueue_product_search_dependencies( $suffix );
			wp_enqueue_style( 'dashicons' );
			wp_enqueue_media();
			wp_enqueue_script( 'sc-preset-popup', plugins_url( 'assets/js/sc-preset-popup' . $suffix . '.js', WC_SC_PLUGIN_FILE ), array( 'jquery', 'wc-enhanced-select' ), $this->get_version() . '.' . time(), true );

			$sell_gift_card_labels = $this->get_sell_gift_card_labels();

			$localized_data = array_merge(
				array(
					'rest_nonce' => wp_create_nonce( 'wp_rest' ),
					'rest_url'   => esc_url_raw( rest_url() ),
				),
				$sell_gift_card_labels,
				array(
					'i18n' => array(
					'generate_in_progress'            => esc_html__( 'Generating...', 'woocommerce-smart-coupons' ),
					'generate_button'                 => esc_html__( 'Generate coupon', 'woocommerce-smart-coupons' ),
					'coupon_generated_button'         => esc_html__( 'Coupon generated', 'woocommerce-smart-coupons' ),
					'generating_coupon'               => esc_html__( 'Generating coupon...', 'woocommerce-smart-coupons' ),
					'coupon_created'                  => esc_html__( 'Coupon created:', 'woocommerce-smart-coupons' ),
					'coupon_failed'                   => esc_html__( 'Coupon creation failed.', 'woocommerce-smart-coupons' ),
					'valid_coupon_amount'             => esc_html__( 'Please enter a valid coupon amount.', 'woocommerce-smart-coupons' ),
					'select_buy_product'              => esc_html__( 'Please select at least one product customers must buy.', 'woocommerce-smart-coupons' ),
					'select_get_product'              => esc_html__( 'Please select at least one gift product.', 'woocommerce-smart-coupons' ),
					'valid_percent_discount'          => esc_html__( 'Please enter a discount amount between 0 and 100.', 'woocommerce-smart-coupons' ),
					'previous'                        => esc_html__( 'Previous', 'woocommerce-smart-coupons' ),
					'buy_product_qty_restrictions'    => esc_html__( 'Purchase quantity rules', 'woocommerce-smart-coupons' ),
					'buy_product_multi_help'          => esc_html__( 'If you select multiple products, customers only need to buy any one of them to qualify for this offer.', 'woocommerce-smart-coupons' ),
					'qty_restrictions_tooltip'        => esc_html__( 'OR: The offer will apply if any one of the selected products meets the quantity condition.', 'woocommerce-smart-coupons' ),
					'product'                         => esc_html__( 'Product', 'woocommerce-smart-coupons' ),
					'min'                             => esc_html__( 'Min. quantity', 'woocommerce-smart-coupons' ),
					'max'                             => esc_html__( 'Max. quantity', 'woocommerce-smart-coupons' ),
					'or'                              => esc_html__( 'OR', 'woocommerce-smart-coupons' ),
					'product_number'                  => esc_html__( 'Product #%s', 'woocommerce-smart-coupons' ),
					'minimum_qty'                     => esc_html__( 'Minimum qty', 'woocommerce-smart-coupons' ),
					'maximum_qty'                     => esc_html__( 'Maximum qty', 'woocommerce-smart-coupons' ),
					'sgc_create_button'               => esc_html__( 'Proceed to set up', 'woocommerce-smart-coupons' ),
					'sgc_creating'                    => esc_html__( 'Creating the product and coupon...', 'woocommerce-smart-coupons' ),
					'sgc_create_another'              => esc_html__( 'Create another %s', 'woocommerce-smart-coupons' ),
					'sgc_almost_done_title'           => __( "You're almost done!", 'woocommerce-smart-coupons' ),
					'sgc_success_description'         => esc_html__( 'You can review the product and coupon settings using the buttons: Edit product & Edit coupon.', 'woocommerce-smart-coupons' ),
					'sgc_publish_notice'              => __( "Now, you can preview the product. Once you're happy with everything, publish the product to make it live.", 'woocommerce-smart-coupons' ),
					'sgc_close'                       => esc_html__( 'Close', 'woocommerce-smart-coupons' ),
					'sgc_created'                     => esc_html__( 'Gift card created successfully.', 'woocommerce-smart-coupons' ),
					'sgc_created_title'               => esc_html__( '%s created', 'woocommerce-smart-coupons' ),
					'sgc_failed'                      => esc_html__( 'Gift card preset creation failed.', 'woocommerce-smart-coupons' ),
					'sgc_product_type'                => esc_html__( 'Please choose a %s product type.', 'woocommerce-smart-coupons' ),
					'sgc_amount'                      => esc_html__( 'Please enter a valid %s amount.', 'woocommerce-smart-coupons' ),
					'sgc_amounts'                     => esc_html__( 'Please enter at least one valid variation value and price.', 'woocommerce-smart-coupons' ),
					'sgc_publish_product'             => esc_html__( 'Publish product', 'woocommerce-smart-coupons' ),
					'sgc_publishing'                  => esc_html__( 'Publishing...', 'woocommerce-smart-coupons' ),
					'sgc_publish_failed'              => esc_html__( 'Product publish failed.', 'woocommerce-smart-coupons' ),
					'sgc_published'                   => esc_html__( 'Published', 'woocommerce-smart-coupons' ),
					'sgc_edit_product'                => esc_html__( 'Edit product', 'woocommerce-smart-coupons' ),
					'sgc_edit_coupon'                 => esc_html__( 'Edit coupon', 'woocommerce-smart-coupons' ),
					'sgc_preview_product'             => esc_html__( 'Preview product', 'woocommerce-smart-coupons' ),
					'sgc_view_product'                => esc_html__( 'View product', 'woocommerce-smart-coupons' ),
					'sgc_subtitle'                    => esc_html__( 'Fill in the details below to set up a product that customers can use to buy %s.', 'woocommerce-smart-coupons' ),
					'sgc_subtitle_done'               => esc_html__( 'Review all the changes before publishing the product', 'woocommerce-smart-coupons' ),
					'sgc_pricing_type_fixed'          => esc_html__( 'A fixed amount %s', 'woocommerce-smart-coupons' ),
					'sgc_pricing_type_custom'         => esc_html__( 'Let customer enter any custom amount', 'woocommerce-smart-coupons' ),
					'sgc_pricing_type_variable'       => esc_html__( 'Variable fixed amount', 'woocommerce-smart-coupons' ),
					'sgc_choose_image'                => esc_html__( 'Choose %s product image', 'woocommerce-smart-coupons' ),
					'sgc_use_this_image'              => esc_html__( 'Use this image', 'woocommerce-smart-coupons' ),
					'sgc_image_selected'              => esc_html__( 'Image selected', 'woocommerce-smart-coupons' ),
					'sgc_default_label'               => esc_html__( 'Gift card', 'woocommerce-smart-coupons' ),
					'sgc_default_plural_label'        => esc_html__( 'Gift cards', 'woocommerce-smart-coupons' ),
					'sgc_default_attribute_name'      => esc_html__( 'Amount', 'woocommerce-smart-coupons' ),
					'sgc_review_product'              => esc_html__( 'Product', 'woocommerce-smart-coupons' ),
					'sgc_review_product_name'         => esc_html__( 'Product name', 'woocommerce-smart-coupons' ),
					'sgc_review_product_type'         => esc_html__( 'Product type', 'woocommerce-smart-coupons' ),
					'sgc_review_variable_product'     => esc_html__( 'Variable product', 'woocommerce-smart-coupons' ),
					'sgc_review_simple_product'       => esc_html__( 'Simple product', 'woocommerce-smart-coupons' ),
					'sgc_review_type_amounts'         => esc_html__( 'Type / amounts', 'woocommerce-smart-coupons' ),
					'sgc_review_type'                 => esc_html__( 'Type', 'woocommerce-smart-coupons' ),
					'sgc_review_total_variations'     => esc_html__( 'Total variations', 'woocommerce-smart-coupons' ),
					'sgc_review_coupons'              => esc_html__( 'Coupons', 'woocommerce-smart-coupons' ),
					'sgc_review_coupon_label'         => esc_html__( 'Coupon', 'woocommerce-smart-coupons' ),
					'sgc_review_coupon_type'          => esc_html__( 'Coupon type', 'woocommerce-smart-coupons' ),
					'sgc_review_coupon_amount'        => esc_html__( 'Coupon amount', 'woocommerce-smart-coupons' ),
					'sgc_review_assignment'           => esc_html__( 'Assignment', 'woocommerce-smart-coupons' ),
					'sgc_review_linked_automatically' => esc_html__( 'Linked automatically', 'woocommerce-smart-coupons' ),
					'sgc_success_variations'          => esc_html__( 'Variations', 'woocommerce-smart-coupons' ),
					'sgc_success_amount'              => esc_html__( 'Amount', 'woocommerce-smart-coupons' ),
					'sgc_success_generated_auto'      => esc_html__( 'Generated automatically', 'woocommerce-smart-coupons' ),
					'coupon_api_unavailable'          => esc_html__( 'Coupon API data is not available.', 'woocommerce-smart-coupons' ),
					'woocommerce_api_error'           => esc_html__( 'WooCommerce API error.', 'woocommerce-smart-coupons' ),
				),
				)
			);

			wp_localize_script(
				'sc-preset-popup',
				'scPresetData',
				$localized_data
			);

			wp_localize_script(
				'sc-preset-popup',
				'scBogoData',
				$localized_data
			);

			wp_enqueue_style( 'sc-preset-popup-style', plugins_url( 'assets/css/sc-preset-popup' . $suffix . '.css', WC_SC_PLUGIN_FILE ), array(), $this->get_version() . '.' . time() );
		}

		/**
		 * Enqueues required dependencies for product search fields.
		 *
		 * @param string $suffix Asset suffix.
		 *
		 * @return void
		 */
		public function enqueue_product_search_dependencies( $suffix = '' ) {

			if ( ! function_exists( 'WC' ) || ! is_object( WC() ) ) {
				return;
			}

			$is_wc_gte_32   = is_callable( array( $this, 'is_wc_gte_32' ) ) && true === $this->is_wc_gte_32();
			$select2_handle = $is_wc_gte_32 ? 'selectWoo' : 'wc-sc-select2';

			if ( ! wp_script_is( $select2_handle, 'registered' ) ) {
				if ( $is_wc_gte_32 ) {
					wp_register_script( 'selectWoo', WC()->plugin_url() . '/assets/js/selectWoo/selectWoo.full' . $suffix . '.js', array( 'jquery' ), WC()->version, false );
				} else {
					wp_register_script( 'wc-sc-select2', WC()->plugin_url() . '/assets/js/select2/select2.full' . $suffix . '.js', array( 'jquery' ), WC()->version, false );
				}
			}

			if ( ! wp_script_is( 'woocommerce_admin', 'registered' ) ) {
				wp_register_script( 'woocommerce_admin', WC()->plugin_url() . '/assets/js/admin/woocommerce_admin' . $suffix . '.js', array( 'jquery', 'jquery-blockui', 'jquery-ui-sortable', 'jquery-ui-widget', 'jquery-ui-core', 'jquery-tiptip', $select2_handle ), WC()->version, false );
			}

			if ( ! wp_script_is( 'wc-enhanced-select', 'registered' ) ) {
				wp_register_script( 'wc-enhanced-select', WC()->plugin_url() . '/assets/js/admin/wc-enhanced-select' . $suffix . '.js', array( 'jquery', $select2_handle ), WC()->version, false );
			}

			if ( ! wp_style_is( 'wc-sc-select2', 'registered' ) ) {
				$assets_path = str_replace( array( 'http:', 'https:' ), '', WC()->plugin_url() ) . '/assets/';
				wp_register_style( 'wc-sc-select2', $assets_path . 'css/select2.css', array(), WC()->version );
			}

			if ( ! wp_script_is( $select2_handle, 'enqueued' ) ) {
				wp_enqueue_script( $select2_handle );
			}

			if ( ! wp_script_is( 'wc-enhanced-select', 'enqueued' ) ) {
				wp_enqueue_script( 'wc-enhanced-select' );
			}

			if ( ! wp_style_is( 'wc-sc-select2', 'enqueued' ) ) {
				wp_enqueue_style( 'wc-sc-select2' );
			}
		}

		/**
		 * Renders BOGO trigger button, shared modal shell and BOGO template.
		 *
		 * @return void
		 */
		public function add_coupon_button() {

			$screen = get_current_screen();

			if ( ! in_array( $screen->id, array( 'edit-shop_coupon', 'marketing_page_wc-smart-coupons' ), true ) ) {
				return;
			}

			$presets = $this->get_available_presets();

			if ( empty( $presets ) || ! is_array( $presets ) ) {
				return;
			}

			?>

			<script type="text/javascript">
				document.addEventListener('DOMContentLoaded', function () {
					setTimeout(function () {
						var dropdownLabel = '<?php echo esc_js( esc_html__( 'Quick start', 'woocommerce-smart-coupons' ) ); ?>';
						var presets = <?php echo wp_json_encode( $presets ); ?>;
						var tourBtn = document.querySelector('.wrap a.button[href*="page=sc-tour"]');
						var addNewBtn = document.querySelector('.wrap .page-title-action');

						if (tourBtn) {
							var dropdownAfterTour = createPresetDropdown(dropdownLabel, presets);
							tourBtn.parentNode.insertBefore(dropdownAfterTour, tourBtn.nextSibling);
							return;
						}

						if (addNewBtn) {
							var dropdown = createPresetDropdown(dropdownLabel, presets);
							addNewBtn.parentNode.insertBefore(dropdown, addNewBtn.nextSibling);
							return;
						}

						var legacyTourBtn = document.querySelector('h2 a.button[href*="page=sc-tour"]');
						var legacyBtn = document.querySelector('h2 .add-new-h2');

						if (legacyTourBtn) {
							var dropdownLegacyAfterTour = createPresetDropdown(dropdownLabel, presets);
							legacyTourBtn.parentNode.insertBefore(dropdownLegacyAfterTour, legacyTourBtn.nextSibling);
							return;
						}

						if (legacyBtn) {
							var dropdownLegacy = createPresetDropdown(dropdownLabel, presets);
							legacyBtn.parentNode.insertBefore(dropdownLegacy, legacyBtn.nextSibling);
						}
					}, 0);

					function createPresetDropdown(label, presetsData) {
						var wrapper = document.createElement('div');
						wrapper.title = 'Presets let you quickly create common coupon offers without configuring every setting manually';
						wrapper.className = 'sc-preset-dropdown';

						var toggle = document.createElement('button');
						toggle.type = 'button';
						toggle.id = 'sc-preset-toggle';
						toggle.className = 'page-title-action sc-preset-toggle';
						toggle.setAttribute('aria-haspopup', 'true');
						toggle.setAttribute('aria-expanded', 'false');
						toggle.appendChild(document.createTextNode(label));

						var toggleIcon = document.createElement('span');
						toggleIcon.className = 'dashicons dashicons-arrow-down-alt2 sc-preset-toggle-icon';
						toggleIcon.setAttribute('aria-hidden', 'true');
						toggle.appendChild(toggleIcon);

						var menu = document.createElement('div');
						menu.className = 'sc-preset-menu';
						menu.setAttribute('role', 'menu');

						function resetDropdownLayout() {
							toggle.style.width = '';
							menu.style.width = '';
							menu.style.minWidth = '';
							menu.style.left = '';
							menu.style.right = '';
						}

						function syncDropdownLayout() {
							menu.style.width = 'max-content';
							menu.style.minWidth = toggle.offsetWidth + 'px';
							menu.style.left = '0';
							menu.style.right = '';

							var targetWidth = menu.offsetWidth;
							toggle.style.width = targetWidth + 'px';
							menu.style.width = targetWidth + 'px';

							var rect = wrapper.getBoundingClientRect();
							if (rect.left + targetWidth > window.innerWidth - 16) {
								menu.style.left = 'auto';
								menu.style.right = '0';
							}
						}

						function setMenuOpen(isOpen) {
							wrapper.classList.toggle('is-open', isOpen);
							menu.classList.toggle('is-open', isOpen);
							menu.style.display = isOpen ? 'block' : 'none';
							toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
							toggleIcon.className = isOpen ? 'dashicons dashicons-arrow-up-alt2 sc-preset-toggle-icon' : 'dashicons dashicons-arrow-down-alt2 sc-preset-toggle-icon';

							if (isOpen) {
								syncDropdownLayout();
							} else {
								resetDropdownLayout();
							}
						}

						if (!window.scPresetDropdownResizeBound) {
							window.scPresetDropdownResizeBound = true;
							window.addEventListener('resize', function () {
								var openMenu = document.querySelector('.sc-preset-menu.is-open');
								if (!openMenu) {
									return;
								}
								var openWrapper = openMenu.closest('.sc-preset-dropdown');
								if (!openWrapper) {
									return;
								}
								var openToggle = openWrapper.querySelector('#sc-preset-toggle');
								if (!openToggle) {
									return;
								}
								openMenu.style.width = 'max-content';
								openMenu.style.minWidth = openToggle.offsetWidth + 'px';
								var targetWidth = openMenu.offsetWidth;
								openToggle.style.width = targetWidth + 'px';
								openMenu.style.width = targetWidth + 'px';
							});
						}

						Object.keys(presetsData).forEach(function (presetKey) {
							if (!presetsData[presetKey] || !presetsData[presetKey].label) {
								return;
							}

							var item = document.createElement('button');
							item.type = 'button';
							item.className = 'sc-preset-item';
							item.textContent = String(presetsData[presetKey].label);
							item.setAttribute('data-sc-open-preset', '1');
							item.setAttribute('data-sc-preset', String(presetKey));

							item.addEventListener('click', function (event) {
								event.preventDefault();
								event.stopPropagation();

								setMenuOpen(false);

								if ('function' === typeof window.scOpenPresetModal) {
									window.scOpenPresetModal(String(presetKey));
									return;
								}

								var fallbackTrigger = document.createElement('button');
								fallbackTrigger.type = 'button';
								fallbackTrigger.style.display = 'none';
								fallbackTrigger.setAttribute('data-sc-open-preset', '1');
								fallbackTrigger.setAttribute('data-sc-preset', String(presetKey));
								document.body.appendChild(fallbackTrigger);
								fallbackTrigger.click();
								fallbackTrigger.remove();
							});

							menu.appendChild(item);
						});

						toggle.addEventListener('click', function () {
							setMenuOpen(!menu.classList.contains('is-open'));
						});

						document.addEventListener('click', function (event) {
							if (!wrapper.contains(event.target)) {
								setMenuOpen(false);
							}
						});

						wrapper.appendChild(toggle);
						wrapper.appendChild(menu);

						return wrapper;
					}
				});
			</script>

			<div id="scBogoModal" class="sc-modal" data-sc-modal="coupon-preset">
				<div class="sc-modal-content">

					<span class="sc-close">&times;</span>
					<div class="sc-modal-scroll">
						<div id="scPresetModalBody"></div>
					</div>

					<div class="sc-modal-footer">
						<div id="scBogoResult" class="sc-bogo-result" data-sc-result="coupon-preset"></div>

						<div class="sc-wizard-actions">
							<button type="button" class="button" id="scStepPrev"><?php esc_html_e( 'Previous', 'woocommerce-smart-coupons' ); ?></button>
							<button type="button" class="button button-primary" id="scStepNext"><?php esc_html_e( 'Next', 'woocommerce-smart-coupons' ); ?></button>
							<button type="button" class="button button-primary" id="scGenerateBogo"><?php esc_html_e( 'Generate coupon', 'woocommerce-smart-coupons' ); ?></button>
						</div>
					</div>

				</div>
			</div>

			<div id="scPresetTemplates" style="display:none;">
				<?php foreach ( $presets as $preset_key => $preset_data ) { ?>
					<?php
					$template_name = isset( $preset_data['template'] ) ? $preset_data['template'] : '';
					$template_args = isset( $preset_data['args'] ) && is_array( $preset_data['args'] ) ? $preset_data['args'] : array();
					?>
					<div data-sc-preset-template="<?php echo esc_attr( $preset_key ); ?>">
						<?php $this->get_template( $template_name, $template_args ); ?>
					</div>
				<?php } ?>
			</div>


			<?php
		}

		/**
		 * Gets available preset definitions.
		 *
		 * @return array<string,array<string,mixed>>
		 */
		public function get_available_presets() {

			$sell_gift_card_labels = $this->get_sell_gift_card_labels();

			$presets = array(
				'sell_gift_card' => array(
					'label'    => $sell_gift_card_labels['sell_gift_card_title'],
					'template' => 'admin/presets/sell-gift-card.php',
					'args'     => array_merge(
						array(
							'is_wc_gte_30' => $this->is_wc_gte_30(),
						),
						$sell_gift_card_labels
					),
				),
				'bogo' => array(
					'label'    => esc_html__( 'Create a BOGO Coupon', 'woocommerce-smart-coupons' ),
					'template' => $this->get_template_name(),
					'args'     => $this->get_template_args(),
				),
			);

			$presets = apply_filters( 'wc_sc_coupon_presets', $presets, $this );

			if ( empty( $presets ) || ! is_array( $presets ) ) {
				return array();
			}

			foreach ( $presets as $preset_key => $preset_data ) {
				if ( ! is_string( $preset_key ) || empty( $preset_key ) || ! is_array( $preset_data ) ) {
					unset( $presets[ $preset_key ] );
					continue;
				}

				if ( empty( $preset_data['label'] ) || empty( $preset_data['template'] ) ) {
					unset( $presets[ $preset_key ] );
					continue;
				}

				$presets[ $preset_key ]['label'] = $this->to_dropdown_sentence_case(
					wp_strip_all_tags( (string) $preset_data['label'] )
				);
			}

			return $presets;
		}

		/**
		 * Formats dropdown labels with only the first word capitalized.
		 *
		 * @param string $text Label text.
		 * @return string
		 */
		private function to_dropdown_sentence_case( $text ) {
			$text = trim( (string) $text );

			if ( '' === $text ) {
				return '';
			}

			return ucfirst( strtolower( $text ) );
		}

		/**
		 * Gets Sell Gift Card preset labels used across PHP, JS, and templates.
		 *
		 * @return array{store_credit_singular_label:string,store_credit_plural_label:string,sell_gift_card_title:string}
		 */
		private function get_sell_gift_card_labels() {
			static $labels = null;

			if ( null !== $labels ) {
				return $labels;
			}

			$store_credit_singular_label = $this->get_sell_gift_card_store_credit_label();
			$store_credit_plural_label   = $this->get_sell_gift_card_store_credit_plural_label();

			$labels = array(
				'store_credit_singular_label' => $store_credit_singular_label,
				'store_credit_plural_label'   => $store_credit_plural_label,
				'sell_gift_card_title'        => $this->to_popup_title_case(
					sprintf(
						/* translators: %s: Store Credit/Gift Card label. */
						__( 'Sell %s', 'woocommerce-smart-coupons' ),
						$store_credit_singular_label
					)
				),
			);

			return $labels;
		}

		/**
		 * Gets the configured singular Store Credit/Gift Card label for the preset UI.
		 *
		 * @return string
		 */
		private function get_sell_gift_card_store_credit_label() {

			global $store_credit_label;

			$label = '';
			if ( ! empty( $store_credit_label['singular'] ) ) {
				$label = $store_credit_label['singular'];
			}

			if ( empty( $label ) ) {
				$label = get_option( 'sc_store_credit_singular_text' );
			}

			return ! empty( $label ) ? ucwords( sanitize_text_field( $label ) ) : __( 'Gift Card', 'woocommerce-smart-coupons' );
		}

		/**
		 * Gets the configured plural Store Credit/Gift Card label for the preset UI.
		 *
		 * @return string
		 */
		private function get_sell_gift_card_store_credit_plural_label() {

			global $store_credit_label;

			$label = '';
			if ( ! empty( $store_credit_label['plural'] ) ) {
				$label = $store_credit_label['plural'];
			}

			if ( empty( $label ) ) {
				$label = get_option( 'sc_store_credit_plural_text' );
			}

			return ! empty( $label ) ? ucwords( sanitize_text_field( $label ) ) : __( 'Gift Cards', 'woocommerce-smart-coupons' );
		}

		/**
		 * Formats popup main titles in title case.
		 *
		 * @param string $text Title text.
		 * @return string
		 */
		private function to_popup_title_case( $text ) {
			return ucwords( strtolower( (string) $text ) );
		}

		/**
		 * Gets preset key.
		 *
		 * @return string
		 */
		public function get_preset_key() {
			return 'bogo';
		}

		/**
		 * Gets BOGO template name.
		 *
		 * @return string
		 */
		public function get_template_name() {
			return 'admin/presets/bogo.php';
		}

		/**
		 * Gets BOGO template args.
		 *
		 * @return array<string,mixed>
		 */
		public function get_template_args() {

			$is_allow_auto_apply = $this->sc_get_option( 'wc_sc_allow_auto_apply', 'yes' );

			return array(
				'coupon_discount_types' => $this->get_coupon_discount_types(),
				'is_wc_gte_30'          => $this->is_wc_gte_30(),
				'is_allow_auto_apply'   => ( 'yes' === $is_allow_auto_apply ),
			);
		}

		/**
		 * Gets available coupon discount types.
		 *
		 * @return array<string,string>
		 */
		public function get_coupon_discount_types() {

			$coupon_discount_types = function_exists( 'wc_get_coupon_types' ) ? wc_get_coupon_types() : array();

			if ( empty( $coupon_discount_types ) || ! is_array( $coupon_discount_types ) ) {
				$coupon_discount_types = array(
					'percent'       => __( 'Percentage discount', 'woocommerce' ),
					'fixed_cart'    => __( 'Fixed cart discount', 'woocommerce' ),
					'fixed_product' => __( 'Fixed product discount', 'woocommerce' ),
				);
			}

			return $coupon_discount_types;
		}

		/**
		 * Loads preset template file.
		 *
		 * @param string $template_name Template path relative to plugin templates directory.
		 * @param array  $args          Template data.
		 *
		 * @return void
		 */
		public function get_template( $template_name = '', $args = array() ) {

			if ( empty( $template_name ) || ! is_string( $template_name ) ) {
				return;
			}

			global $wp_filesystem;

			if ( ! function_exists( 'WP_Filesystem' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}
			WP_Filesystem();

			$template_path = trailingslashit( WC_SC_PLUGIN_DIRPATH . 'templates' ) . ltrim( $template_name, '/' );

			$real_full_path = realpath( $template_path );
			if ( $real_full_path && strpos( wp_normalize_path( $real_full_path ), wp_normalize_path( realpath( WP_PLUGIN_DIR ) ) ) === 0 && is_readable( $real_full_path ) ) {
				if ( $wp_filesystem->exists( $real_full_path ) && $wp_filesystem->is_readable( $real_full_path ) ) {
					if ( ! empty( $args ) && is_array( $args ) ) {
						extract( $args, EXTR_SKIP ); // phpcs:ignore
					}

					include $real_full_path; // nosemgrep: audit.php.lang.security.file.inclusion-arg .
				}
			}
		}

		/**
		 * Registers Sell Gift Card preset REST routes.
		 *
		 * @return void
		 */
		public function register_sell_gift_card_routes() {

			// Preset orchestration endpoint: creates gift card product, variations, coupons and links them in one flow.
			register_rest_route(
				'wc/v3/sc',
				'/sell-gift-card-preset',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_sell_gift_card_preset' ),
					'permission_callback' => array( $this, 'sell_gift_card_permissions_check' ),
				)
			);

			register_rest_route(
				'wc/v3/sc',
				'/sell-gift-card-product/(?P<id>[\d]+)/publish',
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'publish_sell_gift_card_product' ),
					'permission_callback' => array( $this, 'sell_gift_card_permissions_check' ),
					'args'                => array(
						'id' => array(
							'description' => __( 'Gift card product ID.', 'woocommerce-smart-coupons' ),
							'type'        => 'integer',
						),
					),
				)
			);

		}

		/**
		 * Checks Sell Gift Card preset permissions.
		 *
		 * @return bool
		 */
		public function sell_gift_card_permissions_check() {
			return current_user_can( 'manage_woocommerce' ) || current_user_can( 'edit_products' ) || current_user_can( 'edit_shop_coupons' );
		}

		/**
		 * Creates product and linked Store Credit coupons for Sell Gift Card.
		 *
		 * @param WP_REST_Request $request Request object.
		 * @return WP_Error|WP_REST_Response
		 */
		public function create_sell_gift_card_preset( $request ) {

			try {
				$params       = $request->get_json_params();
				$params       = is_array( $params ) ? $params : array();
				$product_type = ! empty( $params['product_type'] ) ? sanitize_key( $params['product_type'] ) : 'simple';

				if ( ! in_array( $product_type, array( 'simple', 'variable' ), true ) ) {
					return new WP_Error( 'wc_sc_sgc_invalid_product_type', __( 'Please choose a valid gift card product type.', 'woocommerce-smart-coupons' ), array( 'status' => 400 ) );
				}

				$product = $this->create_sell_gift_card_product( $params, $product_type );

				if ( ! $product instanceof WC_Product ) {
					return new WP_Error( 'wc_sc_sgc_product_failed', __( 'Gift card product creation failed.', 'woocommerce-smart-coupons' ), array( 'status' => 500 ) );
				}

				$coupons = $this->assign_sell_gift_card_coupons( $product, $params );
				$product->save();

				$response = $this->get_sell_gift_card_product_response( $product );
				$response['coupons'] = $coupons;
				$response['message'] = __( 'Gift card created successfully.', 'woocommerce-smart-coupons' );

				return rest_ensure_response( $response );
			} catch ( \Throwable $e ) {
				global $woocommerce_smart_coupon;

				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}

				return new WP_Error( 'wc_sc_sgc_create_failed', $e->getMessage() ? $e->getMessage() : __( 'Gift card preset creation failed.', 'woocommerce-smart-coupons' ), array( 'status' => 500 ) );
			}
		}

		/**
		 * Publishes a draft Sell Gift Card product from the Done step.
		 *
		 * @param WP_REST_Request $request Request object.
		 * @return WP_Error|WP_REST_Response
		 */
		public function publish_sell_gift_card_product( $request ) {

			$product_id = absint( $request['id'] );
			$product    = wc_get_product( $product_id );

			if ( ! $product instanceof WC_Product ) {
				return new WP_Error( 'wc_sc_sgc_product_not_found', __( 'Gift card product not found.', 'woocommerce-smart-coupons' ), array( 'status' => 404 ) );
			}

			$product->set_status( 'publish' );
			$product->save();

			return rest_ensure_response( $this->get_sell_gift_card_product_response( $product ) );
		}

		/**
		 * Creates a simple or variable gift card product.
		 *
		 * @param array  $params Product data.
		 * @param string $product_type Product type.
		 * @return WC_Product
		 */
		private function create_sell_gift_card_product( $params, $product_type ) {

			$product_name   = ! empty( $params['product_name'] ) ? sanitize_text_field( $params['product_name'] ) : $this->get_sell_gift_card_store_credit_label();
			$image_id       = ! empty( $params['image_id'] ) ? absint( $params['image_id'] ) : 0;
			$attribute_name = ! empty( $params['attribute_name'] ) ? sanitize_text_field( $params['attribute_name'] ) : __( 'Amount', 'woocommerce-smart-coupons' );

			if ( 'variable' === $product_type ) {
				$variations = $this->parse_sell_gift_card_variations( isset( $params['variations'] ) ? $params['variations'] : array() );

				if ( empty( $variations ) ) {
					throw new Exception( __( 'Please enter at least one valid variation value and price.', 'woocommerce-smart-coupons' ) );
				}

				$attribute_data = $this->prepare_sell_gift_card_attribute( $attribute_name, $variations );

				$product = new WC_Product_Variable();
				$product->set_name( $product_name );
				$product->set_status( 'draft' );
				$product->set_catalog_visibility( 'visible' );
				$product->set_short_description( '' );
				$product->set_image_id( $image_id );
				$product->set_virtual( true );
				$product->set_attributes( array( $attribute_data['attribute_key'] => $attribute_data['attribute'] ) );
				$product_id = $product->save();

				$this->create_sell_gift_card_variations( $product_id, $attribute_data['variations'], $attribute_data['attribute_key'], $image_id );

				return wc_get_product( $product_id );
			}

			$pricing_type = ! empty( $params['pricing_type'] ) ? sanitize_key( $params['pricing_type'] ) : 'custom';
			$amount       = ( 'fixed' === $pricing_type && isset( $params['amount'] ) && '' !== (string) $params['amount'] ) ? wc_format_decimal( $params['amount'] ) : '0';
			if ( '' === $amount || (float) $amount < 0 ) {
				throw new Exception( __( 'Please enter a valid gift card amount.', 'woocommerce-smart-coupons' ) );
			}

			$product = new WC_Product_Simple();
			$product->set_name( $product_name );
			$product->set_status( 'draft' );
			$product->set_catalog_visibility( 'visible' );
			$product->set_short_description( '' );
			$product->set_regular_price( $amount );
			$product->set_price( $amount );
			$product->set_virtual( true );
			$product->set_image_id( $image_id );
			$product->save();

			return $product;
		}

		/**
		 * Prepares product attribute data for gift card variations.
		 *
		 * @param string $attribute_name Attribute name.
		 * @param array  $variations Variation data.
		 * @return array
		 */
		private function prepare_sell_gift_card_attribute( $attribute_name, $variations ) {

			$attribute_label = ! empty( $attribute_name ) ? $attribute_name : __( 'Amount', 'woocommerce-smart-coupons' );
			$attribute_slug  = sanitize_title( $attribute_label );
			$taxonomy        = function_exists( 'wc_attribute_taxonomy_name' ) ? wc_attribute_taxonomy_name( $attribute_slug ) : '';
			$attribute_id    = function_exists( 'wc_attribute_taxonomy_id_by_name' ) ? wc_attribute_taxonomy_id_by_name( $attribute_slug ) : 0;
			$attribute       = new WC_Product_Attribute();

			if ( empty( $attribute_id ) && function_exists( 'wc_create_attribute' ) ) {
				$attribute_id = wc_create_attribute(
					array(
						'name'         => $attribute_label,
						'slug'         => $attribute_slug,
						'type'         => 'select',
						'order_by'     => 'menu_order',
						'has_archives' => false,
					)
				);

				if ( is_wp_error( $attribute_id ) ) {
					throw new Exception( $attribute_id->get_error_message() );
				}

				delete_transient( 'wc_attribute_taxonomies' );
			}

			if ( empty( $attribute_id ) || empty( $taxonomy ) ) {
				throw new Exception( __( 'Gift card product attribute creation failed.', 'woocommerce-smart-coupons' ) );
			}

			if ( ! taxonomy_exists( $taxonomy ) ) {
				register_taxonomy(
					$taxonomy,
					array( 'product' ),
					array(
						'hierarchical' => false,
						'show_ui'      => false,
						'query_var'    => true,
						'rewrite'      => false,
					)
				);
			}

			$term_ids = array();

			foreach ( $variations as $index => $variation ) {
				$term = term_exists( $variation['label'], $taxonomy );

				if ( empty( $term ) ) {
					$term = wp_insert_term( $variation['label'], $taxonomy );
				}

				if ( is_wp_error( $term ) || empty( $term['term_id'] ) ) {
					continue;
				}

				$term_id   = absint( $term['term_id'] );
				$term_obj  = get_term( $term_id, $taxonomy );
				$term_slug = ( $term_obj instanceof WP_Term ) ? $term_obj->slug : sanitize_title( $variation['label'] );

				$term_ids[]                                = $term_id;
				$variations[ $index ]['attribute_value'] = $term_slug;
			}

			if ( empty( $term_ids ) ) {
				throw new Exception( __( 'Gift card product attribute terms could not be created.', 'woocommerce-smart-coupons' ) );
			}

			$attribute->set_id( absint( $attribute_id ) );
			$attribute->set_name( $taxonomy );
			$attribute->set_options( array_values( array_unique( $term_ids ) ) );
			$attribute->set_position( 0 );
			$attribute->set_visible( true );
			$attribute->set_variation( true );

			return array(
				'attribute'     => $attribute,
				'attribute_key' => $taxonomy,
				'variations'    => $variations,
			);
		}

		/**
		 * Creates variable product variations.
		 *
		 * @param int    $product_id Parent product ID.
		 * @param array  $variations Variation data.
		 * @param string $attribute_key Attribute key.
		 * @param int    $image_id Image ID.
		 * @return void
		 */
		private function create_sell_gift_card_variations( $product_id, $variations, $attribute_key, $image_id = 0 ) {

			foreach ( $variations as $variation_data ) {
				$label           = $variation_data['label'];
				$attribute_value = ! empty( $variation_data['attribute_value'] ) ? $variation_data['attribute_value'] : $label;
				$price           = $variation_data['price'];
				$variation       = new WC_Product_Variation();

				$variation->set_parent_id( $product_id );
				$variation->set_status( 'publish' );
				$variation->set_virtual( true );
				$variation->set_regular_price( wc_format_decimal( $price ) );
				$variation->set_price( wc_format_decimal( $price ) );
				$variation->set_sku( $this->get_unique_sell_gift_card_variation_sku( $product_id, $label ) );
				$variation->set_image_id( $image_id );
				$variation->set_attributes( array( $attribute_key => $attribute_value ) );
				$variation->save();
			}

			if ( class_exists( 'WC_Product_Variable' ) ) {
				WC_Product_Variable::sync( $product_id );
			}
		}

		/**
		 * Creates and assigns Store Credit coupons to product or variations.
		 *
		 * @param WC_Product $product Product object.
		 * @param array      $params Preset params.
		 * @return array
		 */
		private function assign_sell_gift_card_coupons( $product, $params = array() ) {

			$assigned = array();
			$coupon   = $this->create_sell_gift_card_coupon( $product->get_name(), 0 );
			$code     = $coupon->get_code();

			$product->update_meta_data( '_coupon_title', array( $code ) );

			$assigned[] = array(
				'id'         => $coupon->get_id(),
				'code'       => $code,
				'amount'     => 0,
				'assignment' => 'product',
				'edit_url'   => get_edit_post_link( $coupon->get_id(), 'raw' ),
			);

			return $assigned;
		}

		/**
		 * Creates a Store Credit coupon configured to pick value from product price.
		 *
		 * @param string $product_name Product name.
		 * @param mixed  $amount Coupon amount.
		 * @return WC_Coupon
		 */
		private function create_sell_gift_card_coupon( $product_name, $amount ) {

			global $woocommerce_smart_coupon;

			$code = '';
			if ( is_object( $woocommerce_smart_coupon ) && is_callable( array( $woocommerce_smart_coupon, 'generate_unique_code' ) ) ) {
				$code = $woocommerce_smart_coupon->generate_unique_code();
			}

			if ( empty( $code ) ) {
				$code = wc_format_coupon_code( 'gift-card-' . wp_generate_password( 8, false, false ) );
			}

			$coupon = new WC_Coupon();
			$coupon->set_code( $code );
			$coupon->set_discount_type( 'smart_coupon' );
			$coupon->set_amount( wc_format_decimal( $amount ) );
			$coupon->set_description( sprintf( __( 'This Product %s is for selling gift card, so make sure this coupon is not deleted.', 'woocommerce-smart-coupons' ), $product_name ) );
			$coupon->update_meta_data( 'auto_generate_coupon', 'yes' );
			$coupon->update_meta_data( 'is_pick_price_of_product', 'yes' );
			$coupon->update_meta_data( 'apply_before_tax', 'no' );
			$coupon->update_meta_data( 'sc_is_visible_storewide', 'no' );
			$coupon->update_meta_data( 'sc_disable_email_restriction', 'no' );
			$coupon->save();

			return $coupon;
		}

		/**
		 * Parses variable gift card variation values and prices.
		 *
		 * @param mixed $variations Variations.
		 * @return array
		 */
		private function parse_sell_gift_card_variations( $variations ) {

			$values = array();
			foreach ( (array) $variations as $variation ) {
				if ( ! is_array( $variation ) ) {
					continue;
				}

				$label = ! empty( $variation['label'] ) ? sanitize_text_field( $variation['label'] ) : '';
				$price = isset( $variation['price'] ) ? wc_format_decimal( $variation['price'] ) : '';

				if ( '' === $label || '' === $price || (float) $price < 0 || isset( $values[ $label ] ) ) {
					continue;
				}

				$values[ $label ] = array(
					'label' => $label,
					'price' => $price,
				);
			}

			return array_values( $values );
		}

		/**
		 * Gets a unique variation SKU.
		 *
		 * @param int   $product_id Product ID.
		 * @param mixed $label Variation label.
		 * @return string
		 */
		private function get_unique_sell_gift_card_variation_sku( $product_id, $label ) {

			$base   = 'GC-' . absint( $product_id ) . '-' . strtoupper( preg_replace( '/[^0-9A-Za-z_-]/', '', (string) $label ) );
			$sku    = $base;
			$suffix = 1;

			while ( wc_get_product_id_by_sku( $sku ) ) {
				$sku = $base . '-' . $suffix;
				$suffix++;
			}

			return $sku;
		}

		/**
		 * Gets Sell Gift Card product response data.
		 *
		 * @param WC_Product $product Product object.
		 * @return array
		 */
		private function get_sell_gift_card_product_response( $product ) {

			$image_id   = $product->get_image_id();
			$image_url  = $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' );
			$variations = array();

			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $variation_id ) {
					$variation = wc_get_product( $variation_id );
					if ( ! $variation instanceof WC_Product_Variation ) {
						continue;
					}

					$attributes = $variation->get_attributes();
					$amount     = ! empty( $attributes ) ? current( $attributes ) : $variation->get_regular_price();

					$variations[] = array(
						'id'     => $variation_id,
						'amount' => $amount,
						'sku'    => $variation->get_sku(),
						'price'  => $variation->get_regular_price(),
					);
				}
			}

			$preview_url = get_preview_post_link( $product->get_id() );
			if ( ! $preview_url ) {
				$preview_url = get_permalink( $product->get_id() );
			}

			return array(
				'id'             => $product->get_id(),
				'name'           => $product->get_name(),
				'type'           => $product->is_type( 'variable' ) ? 'variable' : 'simple',
				'type_label'     => $product->is_type( 'variable' ) ? __( 'Variable product', 'woocommerce-smart-coupons' ) : __( 'Simple product', 'woocommerce-smart-coupons' ),
				'price'          => $product->get_price(),
				'price_html'     => $product->get_price_html(),
				'status'         => $product->get_status(),
				'image_id'       => $image_id,
				'image_url'      => $image_url,
				'edit_url'       => get_edit_post_link( $product->get_id(), 'raw' ),
				'preview_url'    => $preview_url,
				'view_url'       => get_permalink( $product->get_id() ),
				'variations'     => $variations,
				'variation_count'=> count( $variations ),
			);
		}
	}
}

// Initialize class.
WC_SC_Preset_BOGO_Coupon::get_instance();
