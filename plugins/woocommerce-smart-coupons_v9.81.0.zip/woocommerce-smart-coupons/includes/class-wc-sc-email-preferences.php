<?php
/**
 * Smart Coupons Email Preferences Service
 *
 * @author      StoreApps
 * @since       9.81.0
 * @version     1.0.0
 * @package     WooCommerce Smart Coupons
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WC_SC_Email_Preferences' ) ) {

	/**
	 * Email Preferences Service Class
	 */
	class WC_SC_Email_Preferences {

		/**
		 * Algorithm to use for HMAC signing
		 *
		 * @var string
		 */
		const HMAC_ALGORITHM = 'sha256';

		/**
		 * Variable to hold instance of this class.
		 *
		 * @var $instance
		 */
		private static $instance = null;

		/**
		 * Mapping of old email type to new preference keys
		 *
		 * @var array
		 */
		private $preference_key_map = array(
			'expiry_reminders'        => 'reminder_coupon_expiry',
			'unused_coupon_reminders' => 'reminder_unused_coupon',
		);

		/**
		 * Get the single instance of this class
		 *
		 * @return WC_SC_Email_Preferences
		 */
		public static function get_instance() {
			// Check if the instance already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Handle call to functions which is not available in this class
		 *
		 * @param string $function_name The function name.
		 * @param array  $arguments Array of arguments passed while calling $function_name.
		 * @return mixed result of function call
		 */
		public function __call( $function_name = '', $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Constructor
		 */
		private function __construct() {
			add_action( 'init', array( $this, 'add_query_vars' ), 10 );
			add_action( 'template_redirect', array( $this, 'handle_request' ), 10 );
		}

		/**
		 * Add query vars
		 */
		public function add_query_vars() {
			global $wp;
			$wp->add_query_var( 'sc_email_preference_action' );
		}

		/**
		 * Normalize email address
		 *
		 * @param string $email Email address to normalize.
		 * @return string Normalized email address.
		 */
		public function normalize_email( $email ) {
			return sanitize_email( strtolower( trim( $email ) ) );
		}

		/**
		 * Get preference key (supports old keys for BC)
		 *
		 * @param string $key Key to normalize.
		 * @return string Normalized preference key.
		 */
		private function get_preference_key( $key ) {
			if ( isset( $this->preference_key_map[ $key ] ) ) {
				return $this->preference_key_map[ $key ];
			}
			return $key;
		}

		/**
		 * Get email preference for a given email
		 *
		 * @param string $email Email address to get preference for.
		 * @param string $preference Preference key (e.g., 'expiry_reminders', 'reminder_coupon_expiry').
		 * @return bool|null Preference value (true/false if set, null if not found).
		 */
		public function get_preference( $email, $preference ) {
			try {
				global $wpdb;

				$email          = $this->normalize_email( $email );
				$preference_key = $this->get_preference_key( $preference );
				if ( ! is_email( $email ) ) {
					return null;
				}

				$table_name = $wpdb->prefix . 'wc_sc_email_preferences';
				// phpcs:disable
				$row = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT status FROM $table_name WHERE email = %s AND preference_key = %s LIMIT 1",
						$email,
						$preference_key
					),
					ARRAY_A
				);
				// phpcs:enable

				if ( null !== $row && isset( $row['status'] ) ) {
					return ( 'subscribed' === $row['status'] );
				}

				// If no record found, default to true (subscribed by default).
				return true;
			} catch ( \Throwable $e ) {
				global $woocommerce_smart_coupon;
				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}
				return null;
			}
		}

		/**
		 * Set email preference for a given email
		 *
		 * @param string $email Email address to set preference for.
		 * @param string $preference Preference key.
		 * @param bool   $value Preference value (true for subscribed, false for unsubscribed).
		 * @return bool True on success, false on failure.
		 */
		public function set_preference( $email, $preference, $value ) {
			try {
				global $wpdb;

				$email          = $this->normalize_email( $email );
				$preference_key = $this->get_preference_key( $preference );
				if ( ! is_email( $email ) ) {
					return false;
				}

				$status = ( true === $value ) ? 'subscribed' : 'unsubscribed';

				$table_name = $wpdb->prefix . 'wc_sc_email_preferences';
				// phpcs:disable
				$result = $wpdb->query(
					$wpdb->prepare(
						"INSERT INTO $table_name 
						 (email, preference_key, status, created_at, updated_at) 
						 VALUES (%s, %s, %s, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) 
						 ON DUPLICATE KEY UPDATE 
						 status = %s, updated_at = CURRENT_TIMESTAMP",
						$email,
						$preference_key,
						$status,
						$status
					)
				);
				// phpcs:enable

				return false !== $result;
			} catch ( \Throwable $e ) {
				global $woocommerce_smart_coupon;
				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}
				return false;
			}
		}

		/**
		 * Check if an email is unsubscribed from a specific email type
		 *
		 * @param string $email Email address to check.
		 * @param string $email_type Email type (e.g., 'expiry_reminders', 'unused_coupon_reminders').
		 * @return bool True if unsubscribed, false otherwise.
		 */
		public function is_unsubscribed( $email, $email_type = null ) {
			if ( null === $email_type ) {
				// If no type specified, check if unsubscribed from either.
				$expiry_unsubscribed = ! $this->get_preference( $email, 'expiry_reminders' );
				$unused_unsubscribed = ! $this->get_preference( $email, 'unused_coupon_reminders' );
				return $expiry_unsubscribed || $unused_unsubscribed;
			}

			return ! $this->get_preference( $email, $email_type );
		}

		/**
		 * Bulk fetch unsubscribed emails for a specific email type
		 *
		 * @param string $email_type Email type (e.g., 'expiry_reminders', 'unused_coupon_reminders').
		 * @return array Array of unsubscribed email addresses.
		 */
		public function bulk_fetch_unsubscribed( $email_type ) {
			try {
				global $wpdb;

				$preference_key = $this->get_preference_key( $email_type );
				$table_name     = $wpdb->prefix . 'wc_sc_email_preferences';
				// phpcs:disable
				$results = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT email FROM $table_name WHERE preference_key = %s AND status = 'unsubscribed'",
						$preference_key
					)
				);
				// phpcs:enable

				return is_array( $results ) ? $results : array();
			} catch ( \Throwable $e ) {
				global $woocommerce_smart_coupon;
				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}
				return array();
			}
		}

		/**
		 * Bulk fetch preferences for a list of emails
		 *
		 * @param array $emails List of email addresses to fetch preferences for.
		 * @return array Associative array of email => preferences (email_type => bool).
		 */
		public function bulk_fetch_preferences_for_emails( $emails ) {
			try {
				global $wpdb;

				$normalized_emails = array_map( array( $this, 'normalize_email' ), $emails );
				$valid_emails      = array_filter( $normalized_emails, 'is_email' );

				if ( empty( $valid_emails ) ) {
					return array();
				}

				$table_name   = $wpdb->prefix . 'wc_sc_email_preferences';
				$placeholders = implode( ',', array_fill( 0, count( $valid_emails ), '%s' ) );

				// phpcs:disable
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT email, preference_key, status FROM $table_name WHERE email IN ($placeholders)",
						$valid_emails
					),
					ARRAY_A
				);
				// phpcs:enable

				$preferences = array();
				if ( is_array( $results ) ) {
					foreach ( $results as $row ) {
						if ( ! isset( $preferences[ $row['email'] ] ) ) {
							$preferences[ $row['email'] ] = array();
						}

						// Map back to old keys for BC.
						foreach ( $this->preference_key_map as $old_key => $new_key ) {
							if ( $row['preference_key'] === $new_key ) {
								$preferences[ $row['email'] ][ $old_key ] = ( 'subscribed' === $row['status'] );
							}
						}
					}
				}

				return $preferences;
			} catch ( \Throwable $e ) {
				global $woocommerce_smart_coupon;
				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}
				return array();
			}
		}

		/**
		 * Get all email preferences for a given email address
		 *
		 * @param string $email Email address to get preferences for.
		 * @return array Array of preferences (e.g., ['expiry_reminders' => true, ...]).
		 */
		public function get_all_preferences( $email ) {
			try {
				global $wpdb;

				$email = $this->normalize_email( $email );
				if ( ! is_email( $email ) ) {
					return array();
				}

				$table_name = $wpdb->prefix . 'wc_sc_email_preferences';
				// phpcs:disable
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT preference_key, status FROM $table_name WHERE email = %s",
						$email
					),
					ARRAY_A
				);
				// phpcs:enable

				$preferences = array();
				if ( is_array( $results ) ) {
					foreach ( $results as $row ) {
						// Map back to old keys for BC.
						foreach ( $this->preference_key_map as $old_key => $new_key ) {
							if ( $row['preference_key'] === $new_key ) {
								$preferences[ $old_key ] = ( 'subscribed' === $row['status'] );
							}
						}
					}
				}

				return $preferences;
			} catch ( \Throwable $e ) {
				global $woocommerce_smart_coupon;
				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}
				return array();
			}
		}

		/**
		 * Delete all email preferences for a given email address
		 *
		 * @param string $email Email address to delete preferences for.
		 * @return bool True on success, false on failure.
		 */
		public function delete_preferences( $email ) {
			try {
				global $wpdb;

				$email = $this->normalize_email( $email );
				if ( ! is_email( $email ) ) {
					return false;
				}

				$table_name = $wpdb->prefix . 'wc_sc_email_preferences';
				// phpcs:disable
				$result = $wpdb->delete(
					$table_name,
					array( 'email' => $email ),
					array( '%s' )
				);
				// phpcs:enable

				return false !== $result;
			} catch ( \Throwable $e ) {
				global $woocommerce_smart_coupon;
				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}
				return false;
			}
		}

		/**
		 * Handle the email preference request
		 */
		public function handle_request() {
			try {
				global $wp_query;

				// Check if it's our request
				if ( ! isset( $wp_query->query_vars['sc_email_preference_action'] ) ) {
					return;
				}

				// Check if the database is updated to the required version.
				if ( ! in_array( $this->get_db_status_for( '9.81.0' ), array( 'done', 'completed' ), true ) ) {
					$this->show_error();
					return;
				}

				// Get and validate payload
				$payload    = $this->get_validated_payload();

				if ( ! $payload ) {
					$this->show_error();
					return;
				}

				$email    = isset( $payload['email'] ) ? sanitize_email( $payload['email'] ) : '';
				$action   = $wp_query->query_vars['sc_email_preference_action'];
				$email_type = isset( $payload['email_type'] ) ? sanitize_key( $payload['email_type'] ) : 'all';

				// Basic validation
				if ( ! is_email( $email ) ) {
					$this->show_error();
					return;
				}

				switch ( $action ) {
					case 'unsubscribe':
						$this->handle_unsubscribe( $email, $email_type );
						break;
					case 'resubscribe':
						$this->handle_resubscribe( $email, $email_type );
						break;
					case 'confirm':
						$this->show_confirmation( $email, $email_type );
						break;
					default:
						$this->show_error();
				}
			} catch ( \Throwable $e ) {
				global $woocommerce_smart_coupon;
				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}
				$this->show_error();
			}
		}

		/**
		 * Handle unsubscribe action
		 *
		 * @param string $email User email
		 * @param string $email_type Email type to unsubscribe
		 */
		private function handle_unsubscribe( $email, $email_type ) {
			if ( $email_type === 'all' ) {
				$this->set_preference( $email, 'expiry_reminders', false );
				$this->set_preference( $email, 'unused_coupon_reminders', false );
			} else {
				$this->set_preference( $email, $email_type, false );
			}

			$this->show_success( 'unsubscribed', $email, $email_type );
		}

		/**
		 * Handle resubscribe action
		 *
		 * @param string $email User email
		 * @param string $email_type Email type to resubscribe
		 */
		private function handle_resubscribe( $email, $email_type ) {
			if ( $email_type === 'all' ) {
				$this->set_preference( $email, 'expiry_reminders', true );
				$this->set_preference( $email, 'unused_coupon_reminders', true );
			} else {
				$this->set_preference( $email, $email_type, true );
			}

			$this->show_success( 'resubscribed', $email, $email_type );
		}

		/**
		 * Get reminder type label
		 *
		 * @param string $email_type Email type
		 * @return string Label
		 */
		private function get_reminder_type_label( $email_type ) {
			$labels = array(
				'expiry_reminders'         => __( 'expiring coupons', 'woocommerce-smart-coupons' ),
				'unused_coupon_reminders'  => __( 'unused coupons', 'woocommerce-smart-coupons' ),
				'all'                      => __( 'expiring and unused coupons', 'woocommerce-smart-coupons' ),
			);

			return isset( $labels[ $email_type ] ) ? $labels[ $email_type ] : $labels['all'];
		}

		/**
		 * Show confirmation page (unsubscribe only)
		 *
		 * @param string $email User email.
		 * @param string $email_type Reminder type to confirm action for.
		 */
		private function show_confirmation( $email, $email_type ) {
			get_header();

			$is_unsubscribed = $this->is_unsubscribed( $email, 'all' === $email_type ? null : $email_type );

			// If already unsubscribed, show a message instead of confirmation
			if ( $is_unsubscribed ) {
				$reminder_type = $this->get_reminder_type_label( $email_type );
				$resubscribe_payload = $this->create_signed_url(
					home_url( '/?sc_email_preference_action=resubscribe' ),
					array(
						'email'      => $email,
						'email_type' => $email_type,
					)
				);
				?>
				<div class="woocommerce sc-email-preferences-page">
					<h1 class="page-title"><?php esc_html_e( 'You\'re already unsubscribed', 'woocommerce-smart-coupons' ); ?></h1>
					<div class="entry-content">
						<p><?php printf( esc_html__( 'You are currently unsubscribed from reminder emails about %s.', 'woocommerce-smart-coupons' ), esc_html( $reminder_type ) ); ?></p>
						<p><a href="<?php echo esc_url( $resubscribe_payload ); ?>" class="button button-primary"><?php esc_html_e( 'Resubscribe', 'woocommerce-smart-coupons' ); ?></a></p>
					</div>
				</div>
				<?php
				get_footer();
				exit;
			}

			// Otherwise, show the confirmation page
			$unsubscribe_payload = $this->create_signed_url(
				home_url( '/?sc_email_preference_action=unsubscribe' ),
				array(
					'email'      => $email,
					'email_type' => $email_type,
				)
			);

			$reminder_type = $this->get_reminder_type_label( $email_type );
			?>
			<div class="woocommerce sc-email-preferences-page">
				<h1 class="page-title"><?php esc_html_e( 'Confirm unsubscribe', 'woocommerce-smart-coupons' ); ?></h1>
				<div class="entry-content">
					<p><?php printf( esc_html__( 'Are you sure you want to unsubscribe from reminder emails about %s?', 'woocommerce-smart-coupons' ), esc_html( $reminder_type ) ); ?></p>
					<p><?php esc_html_e( 'You will stop receiving these reminder emails until you subscribe again.', 'woocommerce-smart-coupons' ); ?></p>
					<p><a href="<?php echo esc_url( $unsubscribe_payload ); ?>" class="button button-primary"><?php esc_html_e( 'Confirm unsubscribe', 'woocommerce-smart-coupons' ); ?></a></p>
				</div>
			</div>
			<?php

			get_footer();
			exit;
		}

		/**
		 * Show success page
		 *
		 * @param string $action The action that was successful.
		 * @param string $email User email.
		 * @param string $email_type Email type for the action.
		 */
		private function show_success( $action, $email, $email_type ) {
			get_header();

			$reverse_action = ( 'unsubscribed' === $action ) ? 'resubscribe' : 'unsubscribe';
			$reverse_payload = $this->create_signed_url(
				home_url( '/?sc_email_preference_action=' . $reverse_action ),
				array(
					'email'      => $email,
					'email_type' => $email_type,
				)
			);

			$email_type_label = $this->get_reminder_type_label( $email_type );

			$messages = array(
				'unsubscribed' => sprintf(
					/* translators: %s: reminder type */
					__( 'You have successfully unsubscribed from reminder emails about %s.', 'woocommerce-smart-coupons' ),
					$email_type_label
				),
				'resubscribed' => sprintf(
					/* translators: %s: reminder type */
					__( 'You will now receive reminder emails about %s.', 'woocommerce-smart-coupons' ),
					$email_type_label
				),
			);

			$reverse_action_label = ( 'unsubscribed' === $action )
				? __( 'Resubscribe', 'woocommerce-smart-coupons' )
				: __( 'Unsubscribe', 'woocommerce-smart-coupons' );

			$page_title = ( 'unsubscribed' === $action )
				? __( 'You\'ve been unsubscribed', 'woocommerce-smart-coupons' )
				: __( 'You\'re subscribed again', 'woocommerce-smart-coupons' );

			?>
			<div class="woocommerce sc-email-preferences-page">
				<h1 class="page-title"><?php echo esc_html( $page_title ); ?></h1>

				<div class="entry-content">
					<p><?php echo esc_html( $messages[ $action ] ); ?></p>

					<p>
						<a href="<?php echo esc_url( $reverse_payload ); ?>" class="button button-secondary">
							<?php echo esc_html( $reverse_action_label ); ?>
						</a>
					</p>

					<p>
						<a href="<?php echo esc_url( home_url() ); ?>" class="button">
							<?php esc_html_e( 'Back to store', 'woocommerce-smart-coupons' ); ?>
						</a>
					</p>
				</div>
			</div>
			<?php

			get_footer();
			exit;
		}

		/**
		 * Show error page
		 */
		private function show_error() {
			get_header();

			?>
			<div class="woocommerce sc-email-preferences-page">
				<h1 class="page-title"><?php esc_html_e( 'Unable to process your request', 'woocommerce-smart-coupons' ); ?></h1>

				<div class="entry-content">
					<p>
						<?php esc_html_e( 'The unsubscribe link you used is invalid or is no longer available.', 'woocommerce-smart-coupons' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Please use the unsubscribe link from the latest email you received and try again.', 'woocommerce-smart-coupons' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'If you continue to experience this issue, please contact the store owner for assistance.', 'woocommerce-smart-coupons' ); ?>
					</p>
					<p>
						<a href="<?php echo esc_url( home_url() ); ?>" class="button">
							<?php esc_html_e( 'Back to store', 'woocommerce-smart-coupons' ); ?>
						</a>
					</p>
				</div>
			</div>
			<?php

			get_footer();
			exit;
		}

		/**
		 * Get the secret key for HMAC signing
		 *
		 * @return string
		 */
		public function get_secret_key() {
			// Use WordPress's AUTH_KEY as the secret, or fall back to a salt
			return defined( 'AUTH_KEY' ) ? AUTH_KEY : wp_salt();
		}

		/**
		 * Encode payload array to URL-safe base64 string
		 *
		 * @param array $payload
		 * @return string
		 */
		public function encode_payload( $payload ) {
			return rtrim( strtr( base64_encode( json_encode( $payload ) ), '+/', '-_' ), '=' );
		}

		/**
		 * Decode URL-safe base64 string back to payload array
		 *
		 * @param string $encoded_payload
		 * @return array|null
		 */
		public function decode_payload( $encoded_payload ) {
			$decoded = base64_decode( strtr( $encoded_payload, '-_', '+/' ) );
			if ( false === $decoded ) {
				return null;
			}

			$payload = json_decode( $decoded, true );
			if ( json_last_error() !== JSON_ERROR_NONE ) {
				return null;
			}

			return $payload;
		}

		/**
		 * Generate HMAC signature for payload
		 *
		 * @param array $payload
		 * @return string
		 */
		public function generate_signature( $payload ) {
			$encoded_payload = $this->encode_payload( $payload );
			return hash_hmac( self::HMAC_ALGORITHM, $encoded_payload, $this->get_secret_key() );
		}

		/**
		 * Validate HMAC signature for payload and signature
		 *
		 * @param array $payload
		 * @param string $signature
		 * @return bool
		 */
		public function validate_signature( $payload, $signature ) {
			$expected_signature = $this->generate_signature( $payload );
			return hash_equals( $expected_signature, $signature );
		}

		/**
		 * Create full signed URL from base URL and payload
		 *
		 * @param string $base_url
		 * @param array $payload
		 * @return string
		 */
		public function create_signed_url( $base_url, $payload ) {
			$encoded_payload = $this->encode_payload( $payload );
			$signature = $this->generate_signature( $payload );

			return add_query_arg(
				array(
					'sc_payload' => $encoded_payload,
					'sc_signature' => $signature,
				),
				$base_url
			);
		}

		/**
		 * Extract and validate payload from signed URL (or current request)
		 *
		 * @param string|null $url Optional URL to parse, if not provided uses current request
		 * @return array|null Valid payload or null on failure
		 */
		public function get_validated_payload( $url = null ) {
			if ( is_null( $url ) ) {
				// Use current request's query args
				if ( ! isset( $_GET['sc_payload'], $_GET['sc_signature'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					return null;
				}

				$encoded_payload = wc_clean( wp_unslash( $_GET['sc_payload'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$signature = wc_clean( wp_unslash( $_GET['sc_signature'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			} else {
				// Parse query args from provided URL
				$query = parse_url( $url, PHP_URL_QUERY );
				if ( ! $query ) {
					return null;
				}

				parse_str( $query, $query_args );
				if ( ! isset( $query_args['sc_payload'], $query_args['sc_signature'] ) ) {
					return null;
				}

				$encoded_payload = wc_clean( wp_unslash( $query_args['sc_payload'] ) );
				$signature = wc_clean( wp_unslash( $query_args['sc_signature'] ) );
			}

			$payload = $this->decode_payload( $encoded_payload );
			if ( is_null( $payload ) ) {
				return null;
			}

			if ( ! $this->validate_signature( $payload, $signature ) ) {
				return null;
			}

			return $payload;
		}
	} // End class

} // End class exists check

if ( ! class_exists( 'WC_SC_Email_Preferences_Handler' ) ) {
	/**
	 * Backward-compatible class alias for WC_SC_Email_Preferences
	 *
	 * @deprecated 9.81.0 Use WC_SC_Email_Preferences instead
	 */
	class WC_SC_Email_Preferences_Handler extends WC_SC_Email_Preferences {
	}
}

WC_SC_Email_Preferences::get_instance();
