<?php
/**
 * Compatibility file for CheckoutWC.
 *
 * @author      StoreApps
 * @since       8.11.0
 * @version     1.1.0
 *
 * @package     woocommerce-smart-coupons/includes/compat/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_CFW_Compatibility' ) ) {

	/**
	 * Class for handling compatibility with CheckoutWC.
	 */
	class WC_SC_CFW_Compatibility {

		/**
		 * Singleton instance.
		 *
		 * @var WC_SC_CFW_Compatibility|null
		 */
		private static $instance = null;

		/**
		 * Get instance.
		 *
		 * @return WC_SC_CFW_Compatibility
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		private function __construct() {
			add_action( 'init', array( $this, 'register_hooks' ) );
		}

		/**
		 * Register hooks for compatibility.
		 */
		public function register_hooks() {
			if ( defined( 'CFW_VERSION' ) ) {
				add_filter( 'wc_sc_checkout_coupon_success_js', array( $this, 'filter_checkout_coupon_success_js' ), 10, 2 );
				add_filter( 'wc_sc_should_use_block_coupon_js', '__return_false' );

				add_action( 'woocommerce_ajax_added_to_cart', array( $this, 'apply_coupon_from_session_for_ajax' ) );
				add_action( 'cfw_cart_updated', array( $this, 'apply_coupon_from_session_for_ajax' ) );

				add_action(
					'cfw_checkout_main_container_start',
					array( WC_SC_Display_Coupons::get_instance(), 'show_available_coupons_before_checkout_form' )
				);
			}
		}

		/**
		 * JS override for coupon application in CheckoutWC.
		 *
		 * @param string $js   Existing JS code.
		 * @param array  $args Additional context.
		 * @return string Modified JS.
		 */
		public function filter_checkout_coupon_success_js( $js, $args ) {
			// Return default if CFW is not active.
			if ( empty( $args['cfw_active'] ) ) {
				return $js;
			}

			$custom_js = <<<'JS'
success: function( response ) {
	if ( response ) {
		jQuery( '.woocommerce-error, .woocommerce-message' ).remove();
		response = response.replace(/woocommerce-message/g, 'message');
		var notice_html = jQuery('<div>', {
			class: 'cfw-alert cfw-alert-success',
			html: response
		});

		if (jQuery('.woocommerce-notices-wrapper').length) {
			jQuery('.woocommerce-notices-wrapper').html(notice_html);
		}

		jQuery( document.body ).trigger( 'update_checkout', { update_shipping_method: false } );
	}
},
complete: function() {
	jQuery( '.sc-coupons-list' ).removeClass( 'processing' ).unblock();
},
JS;

			return $custom_js;
		}

		/**
		 * Apply URL-held coupons during AJAX cart updates used by CheckoutWC.
		 *
		 * The core Smart Coupons session flow intentionally skips AJAX requests,
		 * but CheckoutWC side cart relies on AJAX cart mutations from the shop page.
		 */
		public function apply_coupon_from_session_for_ajax() {
			if ( ! defined( 'CFW_VERSION' ) || ! class_exists( 'WC_SC_URL_Coupon' ) ) {
				return;
			}

			$cart = ( is_object( WC() ) && isset( WC()->cart ) ) ? WC()->cart : null;
			if ( ! $cart instanceof WC_Cart || $cart->is_empty() ) {
				return;
			}

			$wc_sc_url_coupon_instance = WC_SC_URL_Coupon::get_instance();
			$user_id                   = get_current_user_id();

			if ( 0 === $user_id ) {
				$unique_id               = ! empty( $_COOKIE['sc_applied_coupon_profile_id'] ) ? wc_clean( wp_unslash( $_COOKIE['sc_applied_coupon_profile_id'] ) ) : ''; // phpcs:ignore
				$applied_coupon_from_url = ! empty( $unique_id ) ? $wc_sc_url_coupon_instance->get_applied_coupons_by_guest_user( $unique_id ) : array();
			} else {
				$applied_coupon_from_url = get_user_meta( $user_id, 'sc_applied_coupon_from_url', true );
			}

			if ( empty( $applied_coupon_from_url ) || ! is_array( $applied_coupon_from_url ) ) {
				return;
			}

			foreach ( $applied_coupon_from_url as $index => $coupon_code ) {
				$coupon = new WC_Coupon( $coupon_code );

				if ( $wc_sc_url_coupon_instance->is_valid( $coupon ) && ! WC()->cart->has_discount( $coupon_code ) ) {
					WC()->cart->add_discount( trim( $coupon_code ) );
					unset( $applied_coupon_from_url[ $index ] );
				}
			}

			if ( 0 === $user_id ) {
				$wc_sc_url_coupon_instance->set_applied_coupon_for_guest_user( $unique_id, $applied_coupon_from_url );
			} else {
				update_user_meta( $user_id, 'sc_applied_coupon_from_url', $applied_coupon_from_url );
			}
		}
	}
}

WC_SC_CFW_Compatibility::get_instance();
