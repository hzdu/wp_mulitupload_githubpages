<?php
/**
 * Compatibility file for WooCommerce PayPal Payments
 *
 * @author      StoreApps
 * @since       9.77.0
 * @version     1.0.0
 *
 * @package     woocommerce-smart-coupons/includes/compat/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_PPCP_Compatibility' ) ) {

	/**
	 * Class for handling compatibility with WooCommerce Side Cart Premium
	 */
	class WC_SC_PPCP_Compatibility {

		/**
		 * Variable to hold instance of WC_SC_PPCP_Compatibility
		 *
		 * @var $instance
		 */
		private static $instance = null;

		/**
		 * Get single instance of WC_SC_PPCP_Compatibility
		 *
		 * @return WC_SC_PPCP_Compatibility Singleton object of WC_SC_PPCP_Compatibility
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 */
		private function __construct() {
			add_action( 'wp_loaded', array( $this, 'hooks_for_compatibility' ) );
		}

		/**
		 * Handle call to functions which is not available in this class
		 *
		 * @param string $function_name Function to call.
		 * @param array  $arguments Array of arguments passed while calling $function_name.
		 * @return mixed Result of function call.
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Add compatibility related functionality
		 */
		public function hooks_for_compatibility() {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			if ( is_plugin_active( 'woocommerce-paypal-payments/woocommerce-paypal-payments.php' ) ) {
				add_filter( 'wc_sc_query_to_find_order_id', array( $this, 'query_to_find_order_id' ), 20, 2 );
			}
		}

		/**
		 * Prepare query to find order id
		 *
		 * @param string $query The query.
		 * @param array  $args Additional arguments.
		 * @return string
		 */
		public function query_to_find_order_id( $query = '', $args = array() ) {
			try {
				global $wpdb;

				$posted_data = array();
                $post_data            = isset( $_POST['post_data'] ) && ! empty( $_POST['post_data'] ) ? wc_clean( wp_unslash( $_POST['post_data'] ) ) : ''; // phpcs:ignore
				wp_parse_str( $post_data, $posted_data );

                $post_payment_method = ( ! empty( $_POST['payment_method'] ) ) ? wc_clean( wp_unslash( $_POST['payment_method'] ) ) : ''; // phpcs:ignore

				if ( empty( $posted_data['payment_method'] ) && ! empty( $post_payment_method ) ) {
					$posted_data['payment_method'] = $post_payment_method;
				}

				$chosen_payment_method = ( ! empty( $posted_data['payment_method'] ) ) ? $posted_data['payment_method'] : '';

				if ( ! empty( $chosen_payment_method ) && 0 === strpos( $chosen_payment_method, 'ppcp-' ) ) {
					$emails = ( ! empty( $args['emails'] ) ) ? $args['emails'] : array();
					if ( $this->is_hpos() ) {
						list( $email_sql, $email_values ) = $this->prepare_email_condition_parts( $emails, 'pm.meta_value' );
                        // phpcs:disable
                        $query                            = $wpdb->prepare(
                            "SELECT id
                            FROM {$wpdb->prefix}wc_orders AS p
                            LEFT JOIN {$wpdb->prefix}wc_orders_meta AS pm
                                ON ( p.id = pm.order_id AND pm.meta_key = %s )
                            WHERE p.type = %s
                                AND {$email_sql}",
                            '_ppcp_paypal_billing_email',
                            'shop_order',
                            ...$email_values
                        );
                        // phpcs:enable
					} else {
						list( $email_sql, $email_values ) = $this->prepare_email_condition_parts( $emails, 'pm.meta_value' );
                        // phpcs:disable
                        $query                            = $wpdb->prepare(
                            "SELECT ID
                            FROM $wpdb->posts AS p
                            LEFT JOIN $wpdb->postmeta AS pm
                                ON ( p.ID = pm.post_id AND pm.meta_key = %s )
                            WHERE p.post_type = %s
                                AND {$email_sql}",
                            '_ppcp_paypal_billing_email',
                            'shop_order',
                            ...$email_values
                        );
                        // phpcs:enable
					}
				}
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}

			return $query;
		}
	}

}

WC_SC_PPCP_Compatibility::get_instance();
