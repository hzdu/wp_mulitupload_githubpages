<?php
/**
 * Class to create and manage wc_sc_email_preferences table
 *
 * @package     woocommerce-smart-coupons/includes/
 * @since       9.81.0
 * @version     1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WC_SC_Background_Process', false ) ) {
	if ( file_exists( WC_SC_PLUGIN_DIRPATH . 'includes/abstracts/class-wc-sc-background-process.php' ) ) {
		include_once WC_SC_PLUGIN_DIRPATH . 'includes/abstracts/class-wc-sc-background-process.php';
	}
}

if ( ! class_exists( 'WC_SC_Email_Preferences_Table' ) && class_exists( 'WC_SC_Background_Process' ) ) {

	/**
	 * WC_SC_Email_Preferences_Table class.
	 */
	class WC_SC_Email_Preferences_Table extends WC_SC_Background_Process {

		/**
		 * Variable to hold instance of this class.
		 *
		 * @var $instance
		 */
		private static $instance = null;

		/**
		 * Get the single instance of this class
		 *
		 * @return WC_SC_Email_Preferences_Table
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 */
		private function __construct() {

			// Set the batch limit.
			$this->batch_limit = 1;

			// Set the action name.
			$this->action = 'wc_sc_email_preferences_table';

			// Initialize the parent class to execute background process.
			parent::__construct();

			add_action( $this->action . '_process_completed', array( $this, 'finalize' ) );
		}

		/**
		 * Execute the task for each batch.
		 *
		 * @param string $current_item The current status of the table creation.
		 *
		 * @throws Exception If any problem during the process.
		 */
		public function task( $current_item = '' ) {

			global $wpdb;

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			switch ( $current_item ) {
				case 'create':
					$collate = '';

					if ( $wpdb->has_cap( 'collation' ) ) {
						if ( ! empty( $wpdb->charset ) ) {
							$collate .= "DEFAULT CHARACTER SET $wpdb->charset";
						}
						if ( ! empty( $wpdb->collate ) ) {
							$collate .= " COLLATE $wpdb->collate";
						}
					}

					$create_table_query = "
						 CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wc_sc_email_preferences (
							 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
							 email VARCHAR(320) NOT NULL,
							 preference_key VARCHAR(255) NOT NULL,
							 status ENUM('subscribed', 'unsubscribed') NOT NULL,
							 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
							 PRIMARY KEY (id),
							 UNIQUE KEY email_preference (email, preference_key),
							 KEY email (email),
							 KEY preference_key (preference_key)
						 ) $collate";

					@ini_set( 'max_execution_time', '300' ); // phpcs:ignore

					$table_exists = false;
					if ( function_exists( 'maybe_create_table' ) && is_callable( 'maybe_create_table' ) ) {
						$table_exists = maybe_create_table( $wpdb->prefix . 'wc_sc_email_preferences', $create_table_query );
					} elseif ( function_exists( 'dbDelta' ) && is_callable( 'dbDelta' ) ) {
						dbDelta( $create_table_query ); // phpcs:ignore
					}

					$this->remove_status_from_remaining_items( 'create' );
					break;
			}

			// Check process health before continuing.
			if ( ! $this->health_status() ) {
				throw new Exception(
					sprintf(
						/* translators: 1: The task class name */
						_x( 'Batch stopped due to health status in task: %s', 'Logger for stopped batch process due to health status', 'woocommerce-smart-coupons' ),
						__CLASS__
					)
				);
			}
		}

		/**
		 * Get the remaining items for doing the action.
		 *
		 * @return string The function that needs to be processed.
		 */
		public function get_remaining_items() {
			try {
				global $woocommerce_smart_coupon;

				$rows = get_option( 'wc_sc_table_email_preferences_creation_status' );
				if ( is_array( $rows ) && in_array( 'create', $rows, true ) ) {
					return 'create';
				}
			} catch ( \Throwable $e ) {
				if ( is_object( $woocommerce_smart_coupon ) && method_exists( $woocommerce_smart_coupon, 'sc_block_catch_error' ) ) {
					$woocommerce_smart_coupon->sc_block_catch_error( $e );
				}
			}

			return '';
		}

		/**
		 * Remove status from remaining items
		 *
		 * @param mixed $statuses Status to remove.
		 */
		public function remove_status_from_remaining_items( $statuses = null ) {
			try {
				if ( empty( $statuses ) ) {
					return;
				}
				$rows = get_option( 'wc_sc_table_email_preferences_creation_status' );
				if ( is_array( $statuses ) ) {
					$rows = array_diff( $rows, $statuses );
				} else {
					$rows = array_diff( $rows, array( $statuses ) );
				}
				update_option( 'wc_sc_table_email_preferences_creation_status', $rows, true );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}
		}

		/**
		 * Update option once migration complete.
		 */
		public function finalize() {
			delete_option( 'wc_sc_table_email_preferences_creation_status' );
		}
	}
}

WC_SC_Email_Preferences_Table::get_instance();
