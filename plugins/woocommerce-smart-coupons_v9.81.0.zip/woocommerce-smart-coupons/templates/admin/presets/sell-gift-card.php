<?php
/**
 * Sell Gift Card preset wizard template.
 *
 * @package woocommerce-smart-coupons/templates/admin/presets
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$store_credit_singular_label = ! empty( $store_credit_singular_label ) ? $store_credit_singular_label : __( 'Gift Card', 'woocommerce-smart-coupons' );
$store_credit_plural_label   = ! empty( $store_credit_plural_label ) ? $store_credit_plural_label : __( 'Gift Cards', 'woocommerce-smart-coupons' );
$sell_gift_card_title        = ! empty( $sell_gift_card_title ) ? $sell_gift_card_title : ucwords( strtolower( sprintf( /* translators: %s: Store Credit/Gift Card label. */ __( 'Sell %s', 'woocommerce-smart-coupons' ), $store_credit_singular_label ) ) );
?>
<div class="sc-preset-template sc-sgc" data-sc-preset="sell_gift_card">
	<div class="sc-wizard-header">
		<h2><?php echo esc_html( $sell_gift_card_title ); ?></h2>
		<p>
			<?php
			printf(
				/* translators: %s: Store Credit/Gift Card plural label. */
				esc_html__( 'Fill in the details below to set up a product that customers can use to buy %s.', 'woocommerce-smart-coupons' ),
				esc_html( strtolower( $store_credit_plural_label ) )
			);
			?>
		</p>
	</div>

	<div class="sc-stepper" id="scWizardStepper">
		<div class="sc-stepper-item is-active" data-step="1">
			<div class="sc-stepper-dot">1</div>
			<span><?php esc_html_e( 'Setup', 'woocommerce-smart-coupons' ); ?></span>
		</div>
		<div class="sc-stepper-line"></div>
		<div class="sc-stepper-item" data-step="2">
			<div class="sc-stepper-dot">2</div>
			<span><?php esc_html_e( 'Done', 'woocommerce-smart-coupons' ); ?></span>
		</div>
	</div>

	<div class="sc-wizard-body">
		<div class="sc-step-panel is-active" data-step="1">
			<div class="sc-sgc-form-layout">
				<div>
					<div class="sc-field-grid sc-grid-2">
						<div class="sc-field sc-full-width sc-custom-modal-select-field">
							<label for="sc_sgc_pricing_type" id="sc_sgc_pricing_type_label">
								<?php
								printf(
									/* translators: %s: Store Credit/Gift Card label. */
									esc_html__( 'How would you like to sell %s?', 'woocommerce-smart-coupons' ),
									esc_html( strtolower( $store_credit_singular_label ) )
								);
								?>
							</label>
							<select id="sc_sgc_pricing_type" class="sc-custom-modal-select">
								<option value="custom"><?php esc_html_e( 'Let customer enter any custom amount', 'woocommerce-smart-coupons' ); ?></option>
								<option value="fixed"><?php echo esc_html( sprintf( /* translators: %s: Store Credit/Gift Card label. */ __( 'A fixed amount %s', 'woocommerce-smart-coupons' ), strtolower( $store_credit_singular_label ) ) ); ?></option>
								<option value="variable"><?php esc_html_e( 'Variable fixed amount', 'woocommerce-smart-coupons' ); ?></option>
							</select>
						</div>

						<div class="sc-field sc-full-width">
							<label for="sc_sgc_product_name"><?php esc_html_e( 'Product name', 'woocommerce-smart-coupons' ); ?></label>
							<input type="text" id="sc_sgc_product_name" value="<?php echo esc_attr( $store_credit_singular_label ); ?>">
						</div>

						<div class="sc-field sc-full-width" data-sgc-fixed-field style="display:none;">
							<label for="sc_sgc_fixed_amount"><?php esc_html_e( 'Fixed amount', 'woocommerce-smart-coupons' ); ?></label>
							<input type="number" id="sc_sgc_fixed_amount" min="0" step="0.01" value="50">
						</div>

						<div class="sc-field sc-full-width" data-sgc-variable-field style="display:none;">
							<label for="sc_sgc_attribute_name"><?php esc_html_e( 'Attribute name', 'woocommerce-smart-coupons' ); ?></label>
							<input type="text" id="sc_sgc_attribute_name" value="<?php esc_attr_e( 'Amount', 'woocommerce-smart-coupons' ); ?>">
						</div>

						<div class="sc-field sc-full-width" data-sgc-variable-field style="display:none;">
							<label for="sc_sgc_variable_amounts"><?php esc_html_e( 'Variable fixed amounts', 'woocommerce-smart-coupons' ); ?></label>
							<input type="text" id="sc_sgc_variable_amounts" value="20 | 50 | 100">
							<p class="description"><?php esc_html_e( 'Separate amounts with pipes. Example: 20 | 50 | 100', 'woocommerce-smart-coupons' ); ?></p>
						</div>

						<div class="sc-field sc-full-width">
							<label><?php esc_html_e( 'Product featured image', 'woocommerce-smart-coupons' ); ?></label>
							<button type="button" class="button sc-sgc-image-button" data-sgc-image-button>
								<?php esc_html_e( 'Upload image', 'woocommerce-smart-coupons' ); ?>
							</button>
							<input type="hidden" id="sc_sgc_image_id" data-sgc-image-id value="">
							<p class="description"><?php esc_html_e( 'Recommended size: 600 by 600 pixels', 'woocommerce-smart-coupons' ); ?></p>
						</div>
					</div>
				</div>
				<div class="sc-sgc-preview-card" data-sgc-preview="gift-card"></div>
			</div>
		</div>

		<div class="sc-step-panel" data-step="2">
			<div class="sc-sgc-success" data-sgc-success>
				<p><?php esc_html_e( 'You can review the product and coupon settings using the buttons: Edit product & Edit coupon.', 'woocommerce-smart-coupons' ); ?></p>
				<div class="sc-sgc-success-summary" data-sgc-success-summary></div>
				<div class="sc-sgc-notice">
					<?php esc_html_e( "Now, you can preview the product. Once you're happy with everything, publish the product to make it live.", 'woocommerce-smart-coupons' ); ?>
				</div>
				<div class="sc-sgc-success-actions" data-sgc-success-actions></div>
			</div>
		</div>
	</div>
</div>
