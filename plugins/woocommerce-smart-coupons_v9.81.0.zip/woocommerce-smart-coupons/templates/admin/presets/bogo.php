<?php
/**
 * BOGO preset wizard template.
 *
 * @package woocommerce-smart-coupons/templates/admin/presets
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$coupon_discount_types = ( ! empty( $coupon_discount_types ) && is_array( $coupon_discount_types ) ) ? $coupon_discount_types : array();
$is_wc_gte_30          = ( isset( $is_wc_gte_30 ) && is_bool( $is_wc_gte_30 ) ) ? $is_wc_gte_30 : false;
$is_allow_auto_apply   = ( isset( $is_allow_auto_apply ) ) ? $is_allow_auto_apply : true;

if ( empty( $coupon_discount_types ) ) {
	$coupon_discount_types = array(
		'percent'       => __( 'Percentage discount', 'woocommerce' ),
		'fixed_cart'    => __( 'Fixed cart discount', 'woocommerce' ),
		'fixed_product' => __( 'Fixed product discount', 'woocommerce' ),
	);
}
?>
<div class="sc-preset-template" data-sc-preset="bogo">
	<div class="sc-wizard-header">
		<h2><?php esc_html_e( 'Create a BOGO Coupon', 'woocommerce-smart-coupons' ); ?></h2>
		<p><?php esc_html_e( 'Complete this process to setup a coupon for "Buy X Get X" OR "Buy X Get Y" offer.', 'woocommerce-smart-coupons' ); ?></p>
	</div>

	<div class="sc-stepper" id="scWizardStepper">
		<div class="sc-stepper-item is-active" data-step="1">
			<div class="sc-stepper-dot">1</div>
			<span><?php esc_html_e( 'Set products to buy', 'woocommerce-smart-coupons' ); ?></span>
		</div>
		<div class="sc-stepper-line"></div>
		<div class="sc-stepper-item" data-step="2">
			<div class="sc-stepper-dot">2</div>
			<span><?php esc_html_e( 'Set discounted products', 'woocommerce-smart-coupons' ); ?></span>
		</div>
		<div class="sc-stepper-line"></div>
		<div class="sc-stepper-item" data-step="3">
			<div class="sc-stepper-dot">3</div>
			<span><?php esc_html_e( 'Coupon settings', 'woocommerce-smart-coupons' ); ?></span>
		</div>
	</div>

	<div class="sc-wizard-body">
		<div class="sc-step-panel" data-step="3">
			<div class="sc-field-grid">
				<div class="sc-field sc-full-width">
					<label for="sc_bogo_code"><?php esc_html_e( 'Coupon code', 'woocommerce-smart-coupons' ); ?></label>
					<input type="text" id="sc_bogo_code" placeholder="<?php echo esc_attr__( 'Leave blank to generate automatically', 'woocommerce-smart-coupons' ); ?>">
				</div>
				<?php if ( true === $is_allow_auto_apply ) { ?>
					<div class="sc-field sc-full-width sc-auto-apply-row" id="sc_auto_apply_row">
						<p class="sc-auto-apply-title"><?php esc_html_e( 'Auto apply', 'woocommerce-smart-coupons' ); ?></p>
						<label class="sc-auto-apply-option" for="wc_sc_auto_apply_coupon">
							<input type="checkbox" id="wc_sc_auto_apply_coupon" value="yes">
							<span><?php esc_html_e( 'Apply this coupon automatically when its conditions are met.', 'woocommerce-smart-coupons' ); ?></span>
						</label>
					</div>
				<?php } ?>
			</div>
		</div>

		<div class="sc-step-panel is-active" data-step="1">
			<div class="sc-field-grid sc-grid-2 sc-buy-step-grid">
				<div class="sc-field sc-full-width sc-buy-product-field">
					<label for="sc_buy_product_id"><?php esc_html_e( 'Products customers must buy', 'woocommerce-smart-coupons' ); ?></label>
					<?php if ( true === $is_wc_gte_30 ) { ?>
						<select class="sc-preset-product-search select2_search_products_coupons" style="width: 100%;" multiple="multiple" id="sc_buy_product_id" name="sc_buy_product_id[]" data-placeholder="<?php echo esc_attr__( 'Search for a product&hellip;', 'woocommerce-smart-coupons' ); ?>" data-action="wc_sc_json_search_products_and_variations" data-security="<?php echo esc_attr( wp_create_nonce( 'search-products' ) ); ?>">
						</select>
					<?php } else { ?>
						<input type="hidden" class="sc-preset-product-search select2_search_products_coupons" style="width: 100%;" id="sc_buy_product_id" name="sc_buy_product_id[]" data-placeholder="<?php echo esc_attr__( 'Search for a product&hellip;', 'woocommerce-smart-coupons' ); ?>" data-action="wc_sc_json_search_products_and_variations" data-multiple="true" data-security="<?php echo esc_attr( wp_create_nonce( 'search-products' ) ); ?>"/>
					<?php } ?>
				</div>
				<p class="sc-field-help sc-buy-product-help sc-full-width" id="sc_buy_product_help">
					<span class="sc-field-help__icon" aria-hidden="true">
						<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
							<circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1.25"/>
							<path d="M8 7.1V11" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
							<circle cx="8" cy="5.1" r="0.75" fill="currentColor"/>
						</svg>
					</span>
					<span><?php esc_html_e( 'If you select multiple products, customers only need to buy any one of them to qualify for this offer.', 'woocommerce-smart-coupons' ); ?></span>
				</p>
				<div class="sc-field sc-full-width sc-buy-qty-restrictions-wrap" id="sc_product_qty_restrictions_field" style="display:none;">
					<label class="sc-product-qty-restrictions__label">
						<span><?php esc_html_e( 'Purchase quantity rules', 'woocommerce-smart-coupons' ); ?></span>
					</label>
					<div class="sc-product-qty-restrictions__panel">
						<div class="sc-product-qty-restrictions__head">
							<span><?php esc_html_e( 'Product', 'woocommerce-smart-coupons' ); ?></span>
							<span><?php esc_html_e( 'Min. quantity', 'woocommerce-smart-coupons' ); ?></span>
							<span><?php esc_html_e( 'Max. quantity', 'woocommerce-smart-coupons' ); ?></span>
						</div>
						<div id="sc_product_qty_restrictions_rows" class="sc-product-qty-restrictions__rows"></div>
					</div>
				</div>
			</div>
		</div>

		<div class="sc-step-panel" data-step="2">
			<div class="sc-field-grid sc-grid-2">
				<div class="sc-field">
					<label for="sc_product_id"><?php esc_html_e( 'Gift products', 'woocommerce-smart-coupons' ); ?></label>
					<?php if ( true === $is_wc_gte_30 ) { ?>
						<select class="sc-preset-product-search select2_search_products_coupons" style="width: 100%;" multiple="multiple" id="sc_product_id" name="sc_product_id[]" data-placeholder="<?php echo esc_attr__( 'Search for a product&hellip;', 'woocommerce-smart-coupons' ); ?>" data-action="wc_sc_json_search_products_and_variations" data-security="<?php echo esc_attr( wp_create_nonce( 'search-products' ) ); ?>">
						</select>
					<?php } else { ?>
						<input type="hidden" class="sc-preset-product-search select2_search_products_coupons" style="width: 100%;" id="sc_product_id" name="sc_product_id[]" data-placeholder="<?php echo esc_attr__( 'Search for a product&hellip;', 'woocommerce-smart-coupons' ); ?>" data-action="wc_sc_json_search_products_and_variations" data-multiple="true" data-security="<?php echo esc_attr( wp_create_nonce( 'search-products' ) ); ?>"/>
					<?php } ?>
				</div>
				<div class="sc-field">
					<label for="sc_quantity"><?php esc_html_e( 'Quantity per gift', 'woocommerce-smart-coupons' ); ?></label>
					<input type="number" id="sc_quantity" value="1" min="1" step="1">
				</div>
				<div class="sc-field">
					<label for="sc_discount_amount"><?php esc_html_e( 'Discount amount', 'woocommerce-smart-coupons' ); ?></label>
					<input type="number" id="sc_discount_amount" min="0" step="0.01">
				</div>
				<div class="sc-field sc-custom-modal-select-field">
					<label for="sc_discount_type" id="sc_discount_type_label"><?php esc_html_e( 'Discount type', 'woocommerce-smart-coupons' ); ?></label>
					<select id="sc_discount_type" class="sc-custom-modal-select">
						<option value="percent"><?php esc_html_e( 'Percentage (%)', 'woocommerce-smart-coupons' ); ?></option>
						<option value="flat"><?php esc_html_e( 'Fixed amount ($)', 'woocommerce-smart-coupons' ); ?></option>
					</select>
				</div>
				<div class="sc-field sc-full-width sc-checkbox-field">
					<p class="sc-checkbox-title"><?php esc_html_e( 'Gift product selection', 'woocommerce-smart-coupons' ); ?></p>
					<label class="sc-checkbox-option" for="wc_sc_no_of_selectable_product">
						<input type="checkbox" id="wc_sc_no_of_selectable_product" value="yes">
						<span><?php esc_html_e( 'Let customers choose one gift when multiple gift products are available.', 'woocommerce-smart-coupons' ); ?></span>
					</label>
				</div>
			</div>
		</div>
	</div>
</div>
