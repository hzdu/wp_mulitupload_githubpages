<?php

namespace FlyingPress\Integrations\Hosting;

class FlyingHost
{
  private static $api_url = 'https://api.flyinghost.com/purge';
  private static $host;
  public static function init()
  {
    if (!defined('FLYINGHOST_SITE_TOKEN')) {
      return;
    }

    self::$host = parse_url(home_url(), PHP_URL_HOST);

    add_action('flying_press_purge_urls:before', [__CLASS__, 'purge_urls'], 10, 1);
    add_action('flying_press_purge_pages:before', [__CLASS__, 'purge_pages']);
    add_action('flying_press_purge_everything:before', [__CLASS__, 'purge_everything']);
  }

  public static function purge_everything()
  {
    wp_remote_post(self::$api_url . '/everything', [
      'blocking' => false,
      'headers' => [
        'content-type' => 'application/json',
        'x-flyinghost-token' => FLYINGHOST_SITE_TOKEN,
      ],
      'body' => wp_json_encode(['host' => self::$host]),
    ]);
  }

  public static function purge_pages()
  {
    wp_remote_post(self::$api_url . '/pages', [
      'blocking' => false,
      'headers' => [
        'content-type' => 'application/json',
        'x-flyinghost-token' => FLYINGHOST_SITE_TOKEN,
      ],
      'body' => wp_json_encode(['host' => self::$host]),
    ]);
  }

  public static function purge_urls($urls)
  {
    wp_remote_post(self::$api_url . '/urls', [
      'blocking' => false,
      'headers' => [
        'content-type' => 'application/json',
        'x-flyinghost-token' => FLYINGHOST_SITE_TOKEN,
      ],
      'body' => wp_json_encode([
        'urls' => array_values((array) $urls),
        'host' => self::$host,
      ]),
    ]);
  }
}
