<?php

namespace FlyingPress;

class ObjectCache
{
  const DROPIN_FILE = WP_CONTENT_DIR . '/object-cache.php';
  const METRICS_TTL = 3600;

  public static function init()
  {
    register_activation_hook(FLYING_PRESS_FILE_NAME, [__CLASS__, 'handle_drop_in']);
    add_action('deactivate_' . FLYING_PRESS_FILE_NAME, [__CLASS__, 'remove_drop_in']);
    add_action('flying_press_update_config:after', [__CLASS__, 'handle_drop_in'], 10, 2);
    add_action('flying_press_upgraded', [__CLASS__, 'flush_redis_db']);
    add_action('shutdown', [__CLASS__, 'record_cached_stats']);
  }

  public static function handle_drop_in($config = null, $prev = null)
  {
    $is_enabled = is_array($config)
      ? !empty($config['object_cache'])
      : Config::$config['object_cache'];

    if (!$is_enabled) {
      self::remove_drop_in();
      return;
    }

    $source_drop_in = file_get_contents(FLYING_PRESS_PLUGIN_DIR . 'assets/object-cache.php');

    $plugin_file_path = FLYING_PRESS_PLUGIN_DIR . 'src/ObjectCache.php';
    $source_drop_in = str_replace(
      'FLYING_PRESS_OBJECT_CACHE_FILE_PATH',
      $plugin_file_path,
      $source_drop_in
    );

    $was_enabled = is_array($prev) && !empty($prev['object_cache']);

    if (is_file(self::DROPIN_FILE) && file_get_contents(self::DROPIN_FILE) === $source_drop_in) {
      if (!$was_enabled) {
        self::flush_redis_db(true);
      }

      return;
    }

    if (file_put_contents(self::DROPIN_FILE, $source_drop_in) && !$was_enabled) {
      self::flush_redis_db(true);
    }
  }

  public static function remove_drop_in()
  {
    if (self::validate_dropin() !== true) {
      return;
    }

    unlink(self::DROPIN_FILE);
  }

  public static function record_cached_stats()
  {
    global $wp_object_cache;
    if (
      !Config::$config['object_cache'] ||
      !$wp_object_cache instanceof \FP_Object_Cache ||
      !$wp_object_cache->redis_connected
    ) {
      return;
    }

    $hits = $wp_object_cache->cache_hits;
    $misses = $wp_object_cache->cache_misses;

    if ($hits + $misses === 0) {
      return;
    }

    try {
      $minute = (int) (time() / 60) * 60;
      $metric_key = self::metric_key($wp_object_cache, $minute);

      $pipe = $wp_object_cache->redis->pipeline();
      $pipe->hIncrBy($metric_key, 'hits', $hits);
      $pipe->hIncrBy($metric_key, 'misses', $misses);
      $pipe->expire($metric_key, self::METRICS_TTL);
      $pipe->exec();
    } catch (\Throwable $e) {
      error_log('[FlyingPress stats]: ' . $e->getMessage());
    }
  }

  public static function connect_redis()
  {
    if (!class_exists('Redis')) {
      return false;
    }

    $params = [
      'host' => defined('WP_REDIS_HOST') ? \WP_REDIS_HOST : '127.0.0.1',
      'port' => defined('WP_REDIS_PORT') ? (int) \WP_REDIS_PORT : 6379,
      'timeout' => defined('WP_REDIS_TIMEOUT') ? (float) \WP_REDIS_TIMEOUT : 1.0,
      'username' => defined('WP_REDIS_USERNAME') ? \WP_REDIS_USERNAME : '',
      'password' => defined('WP_REDIS_PASSWORD') ? \WP_REDIS_PASSWORD : '',
      'database' => defined('WP_REDIS_DATABASE') ? (int) \WP_REDIS_DATABASE : 0,
      'scheme' => defined('WP_REDIS_SCHEME') ? \WP_REDIS_SCHEME : 'tcp',
      'path' => defined('WP_REDIS_PATH') ? \WP_REDIS_PATH : '',
    ];

    try {
      $redis = new \Redis();

      $persistent_id = "{$params['host']}:{$params['port']}:{$params['database']}";

      $params['scheme'] === 'unix'
        ? $redis->pconnect($params['path'], 0, $params['timeout'], $persistent_id)
        : $redis->pconnect($params['host'], $params['port'], $params['timeout'], $persistent_id);

      if (!empty($params['password'])) {
        $redis->auth(
          !empty($params['username'])
            ? [$params['username'], $params['password']]
            : $params['password']
        );
      }

      if ($params['database'] !== 0) {
        $redis->select($params['database']);
      }

      $redis->setOption(
        \Redis::OPT_SERIALIZER,
        extension_loaded('igbinary') && defined('Redis::SERIALIZER_IGBINARY')
          ? \Redis::SERIALIZER_IGBINARY
          : \Redis::SERIALIZER_PHP
      );

      return $redis;
    } catch (\Throwable $e) {
      error_log('[FlyingPress Redis connect]: ' . $e->getMessage());
      return false;
    }
  }

  public static function check_redis()
  {
    global $wp_object_cache;

    return $wp_object_cache instanceof \FP_Object_Cache && $wp_object_cache->redis_connected
      ? $wp_object_cache->redis
      : self::connect_redis();
  }

  public static function flush_redis_db(bool $include_active_prefix = false)
  {
    $redis = self::check_redis();
    if (!$redis) {
      return;
    }

    $main_prefix = defined('WP_REDIS_PREFIX')
      ? rtrim((string) \WP_REDIS_PREFIX, '_') . '_'
      : 'flying-press_';

    $key_prefixes = [$main_prefix];
    $active_prefix =
      !defined('WP_REDIS_PREFIX') && defined('WP_CACHE_KEY_SALT')
        ? 'fp_' . substr(md5((string) \WP_CACHE_KEY_SALT), 0, 12) . '_'
        : null;

    if ($include_active_prefix && !defined('WP_REDIS_PREFIX')) {
      global $wp_object_cache;

      if ($wp_object_cache instanceof \FP_Object_Cache && !empty($wp_object_cache->key_prefix)) {
        $key_prefixes[] = $wp_object_cache->key_prefix;
      } elseif ($active_prefix) {
        $key_prefixes[] = $active_prefix;
      }
    }

    try {
      foreach (array_unique($key_prefixes) as $key_prefix) {
        self::flush_by_keys($redis, $key_prefix);
      }

      if (!$include_active_prefix && $active_prefix && $active_prefix !== $main_prefix) {
        self::flush_by_keys($redis, "{$active_prefix}php:v");
        self::flush_by_keys($redis, "{$active_prefix}igbinary:v");
        self::flush_by_keys($redis, "{$active_prefix}fpoc:version:");
      }
    } catch (\Throwable $e) {
      error_log('[FlyingPress Redis flush]: ' . $e->getMessage());
    }
  }

  public static function flush_by_keys($redis, $key_prefix)
  {
    $iterator = null;
    $pattern = $key_prefix . '*';

    do {
      $keys = $redis->scan($iterator, $pattern, 500);
      if (!empty($keys)) {
        $to_delete = array_filter($keys, fn($k) => strpos($k, ':flying_press:metric:') === false);
        if (!empty($to_delete)) {
          $redis->unlink(...$to_delete);
        }
      }
    } while ($iterator > 0);
  }

  private static function metric_key(\FP_Object_Cache $cache, int $minute): string
  {
    return "{$cache->key_prefix}{$cache->blog_prefix}:flying_press:metric:v2:{$minute}";
  }

  public static function get_stats()
  {
    if (!Config::$config['object_cache']) {
      return false;
    }

    $validate_dropin = self::validate_dropin();
    if ($validate_dropin !== true) {
      return [
        'error' => $validate_dropin,
      ];
    }

    global $wp_object_cache;

    if (!$wp_object_cache instanceof \FP_Object_Cache) {
      return false;
    }

    if (!empty($wp_object_cache->error)) {
      return ['error' => $wp_object_cache->error];
    }

    $metrics = [];
    $now = (int) (time() / 60) * 60;

    try {
      $keys = array_map(
        fn($i) => self::metric_key($wp_object_cache, $now - $i * 60),
        range(59, 0, -1)
      );

      $pipe = $wp_object_cache->redis->pipeline();
      foreach ($keys as $key) {
        $pipe->hMGet($key, ['hits', 'misses']);
      }

      $cached_metrics = $pipe->exec() ?: [];

      foreach ($cached_metrics as $index => $metric) {
        if (empty($metric) || !is_array($metric)) {
          continue;
        }

        $hits = (int) ($metric['hits'] ?? 0);
        $misses = (int) ($metric['misses'] ?? 0);
        $total = $hits + $misses;

        if ($total > 0) {
          $metrics[] = [
            'timestamp' => $now - (59 - $index) * 60,
            'ratio' => round(($hits * 100) / $total, 2),
          ];
        }
      }
    } catch (\Throwable $e) {
      error_log('[FlyingPress Stats]: ' . $e->getMessage());
    }

    try {
      $memory_info = $wp_object_cache->redis->info('memory');
      $memory_info = $memory_info['Memory'] ?? $memory_info;
      $memory_used =
        (int) ($memory_info['used_memory_dataset'] ?? ($memory_info['used_memory'] ?? 0));
      $memory_total =
        (int) ($memory_info['maxmemory'] ?? 0) ?: (int) ($memory_info['total_system_memory'] ?? 0);
    } catch (\Throwable $e) {
      $memory_used = $memory_total = 0;
    }

    return [
      'metrics' => $metrics,
      'memory_used' => max(0, $memory_used),
      'memory_total' => $memory_total,
    ];
  }

  private static function validate_dropin()
  {
    if (!is_writable(WP_CONTENT_DIR)) {
      return __('File is not writable. Check wp-content directory permission.', 'flying-press');
    }

    if (!is_file(self::DROPIN_FILE)) {
      return __('Drop-in is missing. Please re-enable Object Caching.', 'flying-press');
    }

    $content = file_get_contents(self::DROPIN_FILE);
    if (!$content || strpos($content, 'class FP_Object_Cache') === false) {
      return __('Invalid Drop-in. Please re-enable Object Caching.', 'flying-press');
    }

    return true;
  }
}
