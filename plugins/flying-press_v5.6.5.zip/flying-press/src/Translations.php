<?php

namespace FlyingPress;

class Translations
{
  private const URL = 'https://translations.flyingpress.com/v' . FLYING_PRESS_VERSION . '.zip';

  public static function init()
  {
    register_activation_hook(FLYING_PRESS_FILE_NAME, [__CLASS__, 'install']);
    add_action('flying_press_upgraded', [__CLASS__, 'install']);
  }

  public static function install()
  {
    $target_dir = WP_LANG_DIR . '/plugins';

    require_once ABSPATH . 'wp-admin/includes/file.php';

    if (!wp_mkdir_p($target_dir) || !WP_Filesystem()) {
      return;
    }

    $zip = download_url(self::URL, 10);

    if (is_wp_error($zip)) {
      return;
    }

    self::delete_files();

    $unzipped = unzip_file($zip, $target_dir);
    wp_delete_file($zip);

    if (is_wp_error($unzipped)) {
      return;
    }
  }

  public static function delete_files()
  {
    $target_dir = WP_LANG_DIR . '/plugins';

    if (!is_dir($target_dir)) {
      return;
    }

    foreach (glob($target_dir . '/flying-press-*') as $file) {
      wp_delete_file($file);
    }
  }
}
