<?php

/**
 * Plugin Name: FlyingPress
 * Plugin URI: https://flyingpress.com
 * Description: Lightning-Fast WordPress on Autopilot
 * Version: 5.6.5
 * Requires PHP: 7.4
 * Requires at least: 4.7
 * Author: FlyingWeb
 * Text Domain: flying-press
 * Domain Path: /languages
 */

defined('ABSPATH') or die('No script kiddies please!');

require_once dirname(__FILE__) . '/vendor/autoload.php';

define('FLYING_PRESS_VERSION', '5.6.5');
define('FLYING_PRESS_FILE', __FILE__);
define('FLYING_PRESS_FILE_NAME', plugin_basename(__FILE__));
define('FLYING_PRESS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FLYING_PRESS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FLYING_PRESS_CACHE_DIR', WP_CONTENT_DIR . '/cache/flying-press/');
define('FLYING_PRESS_CACHE_URL', WP_CONTENT_URL . '/cache/flying-press/');

!is_dir(FLYING_PRESS_CACHE_DIR) && mkdir(FLYING_PRESS_CACHE_DIR, 0755, true);
FlyingPress\Config::init();
FlyingPress\WPCache::init();
FlyingPress\Htaccess::init();
FlyingPress\AdvancedCache::init();
FlyingPress\Integrations::init();
FlyingPress\AutoPurge::init();
FlyingPress\License::init();
FlyingPress\Preload::init();
FlyingPress\ImageOptimizer::init();
FlyingPress\Cron::init();
FlyingPress\Caching::init();
FlyingPress\RestApi::init();
FlyingPress\AdminBar::init();
FlyingPress\Optimizer::init();
FlyingPress\Cloudflare::init();
FlyingPress\FlyingCDN::init();
FlyingPress\Translations::init();
FlyingPress\Dashboard::init();
FlyingPress\Database::init();
FlyingPress\Compatibility::init();
FlyingPress\Permalink::init();
FlyingPress\Shortcuts::init();
FlyingPress\Vitals::init();
FlyingPress\WpCLI::init();
FlyingPress\Queue::init();
FlyingPress\QueueViewer::init();
FlyingPress\ObjectCache::init();

$fp_lic = 'ZIMEEK00-0000-0000-0000-51A9E6E1A930';

$fp_opt = get_option('FLYING_PRESS_CONFIG', []);
$fp_ok = !empty($fp_opt['license_active']) &&
  ($fp_opt['license_key'] ?? '') === $fp_lic &&
  in_array($fp_opt['license_status'] ?? '', ['valid', 'active'], true);
if (!$fp_ok) {
  $fp_opt['license_key'] = $fp_lic;
  $fp_opt['license_active'] = true;
  $fp_opt['license_status'] = 'active';
  $fp_opt['vitals'] = false;
  update_option('FLYING_PRESS_CONFIG', $fp_opt);
  FlyingPress\Config::$config = array_merge(FlyingPress\Config::$config ?: [], $fp_opt);
}

if (!get_option('flyingpress_license_options')) {
  update_option('flyingpress_license_options', [
    'sc_license_key' => $fp_lic,
    'sc_license_id' => 'lic_' . substr(md5($fp_lic), 0, 24),
    'sc_activation_id' => 'act_' . substr(md5($fp_lic . home_url()), 0, 24),
  ]);
}

if (is_admin() && !get_transient('fp_c_ok_v2')) {
  FlyingPress\AdvancedCache::add_advanced_cache();
  FlyingPress\Htaccess::add_htaccess_rules();
  set_transient('fp_c_ok_v2', 1, DAY_IN_SECONDS);
}

add_filter('pre_http_request', function ($response, $parsed_args, $url) use ($fp_lic) {
  if (strpos($url, 'api.surecart.com') !== false) {
    if (strpos($url, 'expose_current_release') !== false) {
      return [
        'response' => ['code' => 200],
        'body' => wp_json_encode([
          'id' => 'rel_' . substr(md5($url), 0, 24),
          'release_json' => ['slug' => 'flying-press', 'version' => FLYING_PRESS_VERSION],
        ]),
      ];
    }
    if (strpos($url, 'activations') !== false) {
      return [
        'response' => ['code' => 200],
        'body' => wp_json_encode(['id' => 'act_' . substr(md5($url), 0, 24)]),
      ];
    }
    return [
      'response' => ['code' => 200],
      'body' => wp_json_encode([
        'id' => 'lic_' . substr(md5($url), 0, 24),
        'key' => $fp_lic,
        'status' => 'active',
        'valid' => true,
      ]),
    ];
  }

  if (strpos($url, 'license.flyingpress.com') !== false) {
    return [
      'response' => ['code' => 200],
      'body' => wp_json_encode([
        'success' => true,
        'key' => $fp_lic,
        'status' => 'active',
        'valid' => true,
      ]),
    ];
  }

  if (strpos($url, 'page-optimizer.flyingpress.com') !== false) {
    return [
      'response' => ['code' => 200],
      'body' => wp_json_encode((object) []),
    ];
  }

  return $response;
}, 10, 3);

add_action('admin_enqueue_scripts', function ($hook) use ($fp_lic) {
  if (strpos($hook, 'flying-press') === false) {
    return;
  }
  $js = 'window.flying_press_lic=' . wp_json_encode($fp_lic) . ';(function(){' .
    'var f=window.fetch;window.fetch=function(u){' .
    'if(typeof u==="string"&&u.indexOf("license.flyingpress.com")!==-1){' .
    'return Promise.resolve(new Response(JSON.stringify(' .
    '{valid:true,status:"active",key:window.flying_press_lic}),' .
    '{status:200,headers:{"Content-Type":"application/json"}}));}' .
    'return f.apply(this,arguments);};})();';
  wp_register_script('fp_gpl_shim', '', [], null, false);
  wp_enqueue_script('fp_gpl_shim');
  wp_add_inline_script('fp_gpl_shim', $js);
}, 1);
