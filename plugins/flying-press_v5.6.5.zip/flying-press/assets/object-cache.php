<?php
/**
 * Plugin Name:  FlyingPress - Object Cache (Drop-in)
 * Plugin URI:   https://flyingpress.com/
 * Description:  A persistent Object caching by FlyingPress using Redis. Supports phpredis.
 * Version:      1.0.0
 * Author:       FlyingWeb
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
  exit();
}

function wp_cache_init()
{
  global $wp_object_cache;
  if ($wp_object_cache instanceof FP_Object_Cache) {
    return;
  }

  $wp_object_cache = new FP_Object_Cache();
}

function wp_cache_get($key, $group = 'default', $force = false, &$found = null)
{
  global $wp_object_cache;
  return $wp_object_cache->get($key, $group, (bool) $force, $found);
}

function wp_cache_get_multiple(array $keys, $group = 'default', $force = false)
{
  global $wp_object_cache;
  return $wp_object_cache->get_multiple($keys, $group, (bool) $force);
}

function wp_cache_set($key, $data, $group = 'default', $expire = 0)
{
  global $wp_object_cache;
  return $wp_object_cache->set($key, $data, $group, (int) $expire);
}

function wp_cache_set_multiple(array $data, $group = 'default', $expire = 0)
{
  global $wp_object_cache;
  return $wp_object_cache->set_multiple($data, $group, (int) $expire);
}

function wp_cache_add($key, $data, $group = 'default', $expire = 0)
{
  global $wp_object_cache;
  return $wp_object_cache->add($key, $data, $group, (int) $expire);
}

function wp_cache_add_multiple(array $data, $group = 'default', $expire = 0)
{
  global $wp_object_cache;
  return $wp_object_cache->add_multiple($data, $group, (int) $expire);
}

function wp_cache_replace($key, $data, $group = 'default', $expire = 0)
{
  global $wp_object_cache;
  return $wp_object_cache->replace($key, $data, $group, (int) $expire);
}

function wp_cache_delete($key, $group = 'default')
{
  global $wp_object_cache;
  return $wp_object_cache->delete($key, $group);
}

function wp_cache_delete_multiple(array $keys, $group = 'default')
{
  global $wp_object_cache;
  return $wp_object_cache->delete_multiple($keys, $group);
}

function wp_cache_flush()
{
  global $wp_object_cache;
  return $wp_object_cache->flush();
}

function wp_cache_flush_group($group)
{
  global $wp_object_cache;
  return $wp_object_cache->flush_group($group);
}

function wp_cache_flush_runtime()
{
  global $wp_object_cache;
  return $wp_object_cache->flush_runtime();
}

function wp_cache_incr($key, $offset = 1, $group = 'default')
{
  global $wp_object_cache;
  return $wp_object_cache->increment($key, (int) $offset, $group);
}

function wp_cache_decr($key, $offset = 1, $group = 'default')
{
  global $wp_object_cache;
  return $wp_object_cache->decrement($key, (int) $offset, $group);
}

function wp_cache_close()
{
  return true;
}

function wp_cache_switch_to_blog($blog_id)
{
  global $wp_object_cache;
  return $wp_object_cache->switch_to_blog((int) $blog_id);
}

function wp_cache_add_global_groups($groups)
{
  global $wp_object_cache;
  $wp_object_cache->add_global_groups($groups);
}

function wp_cache_add_non_persistent_groups($groups)
{
  global $wp_object_cache;
  $wp_object_cache->add_non_persistent_groups($groups);
}

function wp_cache_supports(string $feature)
{
  switch ($feature) {
    case 'add_multiple':
    case 'set_multiple':
    case 'get_multiple':
    case 'delete_multiple':
    case 'flush_runtime':
    case 'flush_group':
      return true;

    default:
      return false;
  }
}

class FP_Object_Cache
{
  private const FALSE_VALUE_MARKER = '__flying_press_object_cache_false';
  private const VALUE_VERSION = 1;
  private const DELETE_CHUNK_SIZE = 500;
  private const DEFAULT_MAX_TTL = 2592000; // 30 days.

  public $redis = false;
  public bool $redis_connected = false;

  private array $cache = [];
  private array $non_persistent = [];
  private array $global_groups = [];

  public string $global_prefix = '';
  public string $blog_prefix = '';
  public string $key_prefix = 'flying-press_';
  private string $serializer_token = 'php';
  private int $max_ttl = self::DEFAULT_MAX_TTL;

  public int $cache_hits = 0;
  public int $cache_misses = 0;

  public string $error = '';

  public function __construct()
  {
    global $blog_id, $table_prefix;

    $is_multisite = function_exists('is_multisite') && is_multisite();
    $this->global_prefix = trim($is_multisite ? '' : $table_prefix ?? '', '_-:$');
    $this->blog_prefix = trim($is_multisite ? (string) $blog_id : $table_prefix ?? '', '_-:$');

    $this->key_prefix = $this->default_key_prefix();

    if (defined('WP_REDIS_MAXTTL')) {
      $this->max_ttl = max(0, (int) WP_REDIS_MAXTTL);
    }

    try {
      $this->connect_phpredis();
    } catch (Throwable $e) {
      $this->handle_cache('connect', $e);
    }
  }

  public function get($key, $group = 'default', bool $force = false, ?bool &$found = null)
  {
    $group = $this->normalize_group($group);
    $cache_key = $this->build_key_for_group($key, $group);

    if ($cache_key === false) {
      $found = false;
      $this->cache_misses++;
      return false;
    }

    if (!$force && $this->has_runtime($cache_key)) {
      $found = true;
      $this->cache_hits++;
      return $this->get_runtime($cache_key);
    }

    if ($this->is_non_persistent($group) || !$this->redis_connected) {
      $found = false;
      $this->cache_misses++;
      return false;
    }

    $value = $this->get_persistent_value($key, $group, $cache_key, $found);

    if (!$found) {
      $this->cache_misses++;
      return false;
    }

    $this->cache_hits++;
    $this->store_runtime($cache_key, $value);
    return $value;
  }

  public function set($key, $data, $group = 'default', int $expire = 0)
  {
    return $this->write($key, $data, $group, $expire);
  }

  public function add($key, $data, $group = 'default', int $expire = 0)
  {
    if (function_exists('wp_suspend_cache_addition') && wp_suspend_cache_addition()) {
      return false;
    }

    return $this->write($key, $data, $group, $expire, 'nx');
  }

  public function replace($key, $data, $group = 'default', int $expire = 0)
  {
    return $this->write($key, $data, $group, $expire, 'xx');
  }

  public function delete($key, $group = 'default')
  {
    $group = $this->normalize_group($group);
    $cache_key = $this->build_key_for_group($key, $group);

    if ($cache_key === false) {
      return false;
    }

    $existed = $this->has_runtime($cache_key);
    unset($this->cache[$cache_key]);

    if ($this->is_non_persistent($group) || !$this->redis_connected) {
      return $existed;
    }

    try {
      $delete_key = $this->is_alloptions_key($key, $group) ? "{$cache_key}:hash" : $cache_key;
      $deleted = $this->delete_keys([$delete_key]) > 0;
      return $existed || $deleted;
    } catch (Throwable $e) {
      $this->handle_cache('delete', $e);
      return false;
    }
  }

  public function flush()
  {
    $this->cache = [];

    if (!$this->redis_connected) {
      return true;
    }

    try {
      return $this->delete_cache_keys();
    } catch (Throwable $e) {
      $this->handle_cache('flush', $e);
      return false;
    }
  }

  public function flush_group($group)
  {
    $group = $this->normalize_group($group);

    foreach (array_keys($this->cache) as $key) {
      if ($this->should_flush_cache_key((string) $key, $group)) {
        unset($this->cache[$key]);
      }
    }

    if (!$this->redis_connected) {
      return true;
    }

    try {
      return $this->delete_cache_keys($group);
    } catch (Throwable $e) {
      $this->handle_cache('flush_group', $e);
      return false;
    }
  }

  public function flush_runtime()
  {
    $this->cache = [];
    return true;
  }

  public function increment($key, int $offset = 1, $group = 'default')
  {
    return $this->update_counter($key, $offset, $group);
  }

  public function decrement($key, int $offset = 1, $group = 'default')
  {
    return $this->update_counter($key, -$offset, $group);
  }

  public function add_global_groups($groups)
  {
    foreach ((array) $groups as $group) {
      $this->global_groups[$this->normalize_group($group)] = true;
    }
  }

  public function add_non_persistent_groups($groups)
  {
    foreach ((array) $groups as $group) {
      $this->non_persistent[$this->normalize_group($group)] = true;
    }
  }

  public function switch_to_blog($blog_id)
  {
    if (!function_exists('is_multisite') || !is_multisite()) {
      return false;
    }

    $this->blog_prefix = trim((string) $blog_id, '_-:$');
    return true;
  }

  public function build_key($key, $group = 'default')
  {
    $group = $this->normalize_group($group);
    return $this->build_key_for_group($key, $group);
  }

  private function build_key_for_group($key, string $group)
  {
    return $this->build_key_with_context($key, $group, $this->key_prefix_for_group($group));
  }

  private function build_key_with_context($key, string $group, string $prefix)
  {
    $key = $this->normalize_key($key);
    if ($key === false) {
      return false;
    }

    return "{$this->key_prefix}{$this->serializer_token}:{$prefix}:{$group}:{$key}";
  }

  private function default_key_prefix(): string
  {
    if (defined('WP_REDIS_PREFIX')) {
      return rtrim((string) WP_REDIS_PREFIX, '_') . '_';
    }

    if (defined('WP_CACHE_KEY_SALT')) {
      return 'fp_' . substr(md5((string) WP_CACHE_KEY_SALT), 0, 12) . '_';
    }

    return 'flying-press_';
  }

  private function connect_phpredis()
  {
    if (!class_exists('Redis')) {
      $this->error = 'No Redis client available. Install phpredis.';
      return;
    }

    $plugin_file = 'FLYING_PRESS_OBJECT_CACHE_FILE_PATH';
    if (!is_file($plugin_file)) {
      $this->error = 'FlyingPress plugin not found.';
      return;
    }

    require_once $plugin_file;

    $this->redis = class_exists('FlyingPress\ObjectCache')
      ? \FlyingPress\ObjectCache::connect_redis()
      : false;

    if (!$this->redis) {
      $this->error = 'Failed to connect to Redis.';
      return;
    }

    $this->serializer_token = $this->detect_serializer_token();
    $this->redis_connected = true;
  }

  private function detect_serializer_token(): string
  {
    if (
      !method_exists($this->redis, 'getOption') ||
      !defined('Redis::OPT_SERIALIZER') ||
      !defined('Redis::SERIALIZER_IGBINARY')
    ) {
      return 'php';
    }

    try {
      return (int) $this->redis->getOption(\Redis::OPT_SERIALIZER) === \Redis::SERIALIZER_IGBINARY
        ? 'igbinary'
        : 'php';
    } catch (Throwable $e) {
      return 'php';
    }
  }

  private function delete_cache_keys(?string $group = null): bool
  {
    $iterator = null;
    $pattern = "{$this->key_prefix}*";
    $delete_keys = [];

    do {
      $keys = $this->redis->scan($iterator, $pattern, self::DELETE_CHUNK_SIZE);

      if ($keys === false || empty($keys)) {
        continue;
      }

      foreach ($keys as $key) {
        if (!$this->should_flush_cache_key((string) $key, $group)) {
          continue;
        }

        $delete_keys[] = (string) $key;

        if (count($delete_keys) >= self::DELETE_CHUNK_SIZE) {
          $this->delete_keys($delete_keys);
          $delete_keys = [];
        }
      }
    } while ((int) $iterator > 0);

    if (!empty($delete_keys)) {
      $this->delete_keys($delete_keys);
    }

    return true;
  }

  private function should_flush_cache_key(string $key, ?string $group = null): bool
  {
    $parts = $this->parse_cache_key($key);
    if ($parts === null) {
      return false;
    }

    return $group === null || $parts['group'] === $group;
  }

  private function parse_cache_key(string $key): ?array
  {
    if (strpos($key, $this->key_prefix) !== 0) {
      return null;
    }

    if (strpos($key, ':flying_press:metric:') !== false) {
      return null;
    }

    $key = substr($key, strlen($this->key_prefix));
    $parts = explode(':', $key, 6);

    if (count($parts) < 4 || !in_array($parts[0], ['php', 'igbinary'], true)) {
      return null;
    }

    if (count($parts) >= 6 && strpos($parts[1], 'v') === 0 && strpos($parts[4], 'v') === 0) {
      return ctype_digit(substr($parts[1], 1)) && ctype_digit(substr($parts[4], 1))
        ? ['group' => $parts[3]]
        : null;
    }

    return ['group' => $parts[2]];
  }

  private function key_prefix_for_group(string $group): string
  {
    return isset($this->global_groups[$group]) ? $this->global_prefix : $this->blog_prefix;
  }

  public function get_multiple(array $keys, $group = 'default', bool $force = false)
  {
    $result = [];

    if (empty($keys)) {
      return $result;
    }

    $group = $this->normalize_group($group);
    $prefix = $this->key_prefix_for_group($group);
    $keys_to_fetch = [];

    foreach ($keys as $key) {
      $cache_key = $this->build_key_with_context($key, $group, $prefix);

      if ($cache_key === false) {
        $this->cache_misses++;
        $result[$key] = false;
        continue;
      }

      if (!$force && $this->has_runtime($cache_key)) {
        $this->cache_hits++;
        $result[$key] = $this->get_runtime($cache_key);
      } else {
        $keys_to_fetch[$key] = $cache_key;
      }
    }

    if (empty($keys_to_fetch)) {
      return $this->ordered_result($keys, $result);
    }

    if ($this->is_non_persistent($group) || !$this->redis_connected) {
      foreach ($keys_to_fetch as $key => $cache_key) {
        $this->cache_misses++;
        $result[$key] = false;
      }

      return $this->ordered_result($keys, $result);
    }

    $redis_batch = [];
    foreach ($keys_to_fetch as $key => $cache_key) {
      if ($this->is_alloptions_key($key, $group)) {
        $found = false;
        $value = $this->get_persistent_value($key, $group, $cache_key, $found);

        if ($found) {
          $this->cache_hits++;
          $this->store_runtime($cache_key, $value);
          $result[$key] = $value;
        } else {
          $this->cache_misses++;
          $result[$key] = false;
        }

        continue;
      }

      $redis_batch[$key] = $cache_key;
    }

    if (empty($redis_batch)) {
      return $this->ordered_result($keys, $result);
    }

    try {
      $values = $this->redis->mget(array_values($redis_batch));
      if ($values === false) {
        $values = [];
      }

      foreach (array_keys($redis_batch) as $i => $key) {
        $found = false;
        $payload = array_key_exists($i, $values) ? $values[$i] : false;
        $value = $this->unwrap_value($payload, $found, $redis_batch[$key]);

        if ($found) {
          $this->cache_hits++;
          $this->store_runtime($redis_batch[$key], $value);
          $result[$key] = $value;
        } else {
          $this->cache_misses++;
          $result[$key] = false;
        }
      }
    } catch (Throwable $e) {
      $this->handle_cache('get_multiple', $e);
      foreach ($redis_batch as $key => $cache_key) {
        $this->cache_misses++;
        $result[$key] = false;
      }
    }

    return $this->ordered_result($keys, $result);
  }

  public function set_multiple(array $data, $group = 'default', int $expire = 0)
  {
    return $this->write_multiple($data, $group, $expire);
  }

  public function add_multiple(array $data, $group = 'default', int $expire = 0)
  {
    if (function_exists('wp_suspend_cache_addition') && wp_suspend_cache_addition()) {
      $result = [];
      foreach ($data as $key => $value) {
        $result[$key] = false;
      }

      return $result;
    }

    return $this->write_multiple($data, $group, $expire, 'nx');
  }

  public function delete_multiple(array $keys, $group = 'default')
  {
    $result = [];

    if (empty($keys)) {
      return $result;
    }

    $group = $this->normalize_group($group);
    $prefix = $this->key_prefix_for_group($group);
    $delete_keys = [];

    foreach ($keys as $key) {
      $cache_key = $this->build_key_with_context($key, $group, $prefix);

      if ($cache_key === false) {
        $result[$key] = false;
        continue;
      }

      $existed = $this->has_runtime($cache_key);
      unset($this->cache[$cache_key]);
      $result[$key] = $existed;
      $delete_keys[$key] = $this->is_alloptions_key($key, $group) ? "{$cache_key}:hash" : $cache_key;
    }

    if (empty($delete_keys) || $this->is_non_persistent($group) || !$this->redis_connected) {
      return $this->ordered_result($keys, $result);
    }

    try {
      foreach ($this->delete_key_results($delete_keys) as $key => $deleted) {
        $result[$key] = ($result[$key] ?? false) || $deleted;
      }
    } catch (Throwable $e) {
      $this->handle_cache('delete_multiple', $e);
      foreach ($keys as $key) {
        $result[$key] = false;
      }
    }

    return $this->ordered_result($keys, $result);
  }

  private function write($key, $data, $group = 'default', int $expire = 0, ?string $mode = null): bool
  {
    $group = $this->normalize_group($group);
    $cache_key = $this->build_key_for_group($key, $group);

    if ($cache_key === false) {
      return false;
    }

    $runtime_hit = $this->has_runtime($cache_key);

    if ($mode === 'nx' && $runtime_hit) {
      return false;
    }

    if ($this->is_non_persistent($group) || !$this->redis_connected) {
      if ($mode === 'xx' && !$runtime_hit) {
        return false;
      }

      $this->store_runtime($cache_key, $data);
      return true;
    }

    if ($this->is_alloptions_key($key, $group)) {
      return $this->write_alloptions($cache_key, $data, $mode);
    }

    try {
      $stored = $this->set_redis_value($cache_key, $data, $expire, $mode);
      if ($stored) {
        $this->store_runtime($cache_key, $data);
      }

      return $stored;
    } catch (Throwable $e) {
      $this->handle_cache($this->write_context($mode), $e);
      return false;
    }
  }

  private function write_multiple(
    array $data,
    $group = 'default',
    int $expire = 0,
    ?string $mode = null
  ): array {
    $result = [];

    if (empty($data)) {
      return $result;
    }

    $group = $this->normalize_group($group);
    $prefix = $this->key_prefix_for_group($group);
    $pending = [];
    $runtime_only = $this->is_non_persistent($group) || !$this->redis_connected;

    foreach ($data as $key => $value) {
      $cache_key = $this->build_key_with_context($key, $group, $prefix);

      if ($cache_key === false) {
        $result[$key] = false;
        continue;
      }

      $runtime_hit = $this->has_runtime($cache_key);

      if ($mode === 'nx' && $runtime_hit) {
        $result[$key] = false;
        continue;
      }

      if ($runtime_only) {
        if ($mode === 'xx' && !$runtime_hit) {
          $result[$key] = false;
          continue;
        }

        $this->store_runtime($cache_key, $value);
        $result[$key] = true;
        continue;
      }

      if ($this->is_alloptions_key($key, $group)) {
        $result[$key] = $this->write_alloptions($cache_key, $value, $mode);
        continue;
      }

      if (is_int($value)) {
        try {
          $stored = $this->set_redis_value($cache_key, $value, $expire, $mode);
          if ($stored) {
            $this->store_runtime($cache_key, $value);
          }

          $result[$key] = $stored;
        } catch (Throwable $e) {
          $this->handle_cache($this->write_context($mode) . '_multiple', $e);
          $result[$key] = false;
        }

        continue;
      }

      $pending[$key] = [$cache_key, $value];
    }

    if (!empty($pending)) {
      $result += $this->write_pending_values($pending, $expire, $mode);
    }

    return $this->ordered_result(array_keys($data), $result);
  }

  private function write_alloptions(string $cache_key, $data, ?string $mode = null): bool
  {
    try {
      $hash_key = "{$cache_key}:hash";

      if ($mode === 'nx' && $this->redis->exists($hash_key)) {
        return false;
      }

      if ($mode === 'xx' && !$this->redis->exists($hash_key)) {
        return false;
      }

      $previous = $this->has_runtime($cache_key) ? $this->get_runtime($cache_key) : null;
      $stored = $this->sync_alloptions_hash(
        $cache_key,
        (array) $data,
        is_array($previous) ? $previous : ($mode === 'nx' ? [] : null)
      );

      if ($stored) {
        $this->store_runtime($cache_key, $data);
      }

      return $stored;
    } catch (Throwable $e) {
      $this->handle_cache($this->write_context($mode), $e);
      return false;
    }
  }

  private function write_pending_values(array $pending, int $expire = 0, ?string $mode = null): array
  {
    $result = [];

    try {
      $ttl = $this->redis_ttl($expire);

      if ($mode === null && $ttl <= 0) {
        $redis_data = [];
        foreach ($pending as [$cache_key, $value]) {
          $redis_data[$cache_key] = $this->wrap_value($value);
        }

        $stored = (bool) $this->redis->mset($redis_data);
        foreach ($pending as $key => [$cache_key, $value]) {
          if ($stored) {
            $this->store_runtime($cache_key, $value);
          }

          $result[$key] = $stored;
        }

        return $result;
      }

      $args = $this->redis_set_args($ttl, $mode);
      $pipe = $this->redis->pipeline();

      foreach ($pending as [$cache_key, $value]) {
        $pipe->set($cache_key, $this->wrap_value($value), $args);
      }

      $responses = $pipe->exec();
      foreach (array_keys($pending) as $i => $key) {
        [$cache_key, $value] = $pending[$key];
        $stored = (bool) ($responses[$i] ?? false);
        if ($stored) {
          $this->store_runtime($cache_key, $value);
        }

        $result[$key] = $stored;
      }
    } catch (Throwable $e) {
      $this->handle_cache($this->write_context($mode) . '_multiple', $e);
      foreach (array_keys($pending) as $key) {
        $result[$key] = false;
      }
    }

    return $result;
  }

  private function get_persistent_value($key, string $group, string $cache_key, ?bool &$found)
  {
    if ($this->is_alloptions_key($key, $group)) {
      $value = $this->get_alloptions_from_hash($cache_key);
      $found = $value !== false;
      return $value;
    }

    try {
      $payload = $this->redis->get($cache_key);
    } catch (Throwable $e) {
      $this->handle_cache('get', $e);
      $found = false;
      return false;
    }

    return $this->unwrap_value($payload, $found, $cache_key);
  }

  private function get_alloptions_from_hash(string $cache_key)
  {
    try {
      $value = $this->redis->hgetall("{$cache_key}:hash");
      return empty($value) ? false : $value;
    } catch (Throwable $e) {
      $this->handle_cache('get alloptions', $e);
      return false;
    }
  }

  private function sync_alloptions_hash(string $cache_key, array $new_data, ?array $previous_data = null)
  {
    try {
      $hash_key = "{$cache_key}:hash";
      $baseline = $previous_data ?? $this->redis->hgetall($hash_key) ?: [];
      $removed = array_keys(array_diff_key($baseline, $new_data));
      $changed = [];

      foreach ($new_data as $key => $value) {
        if (!array_key_exists($key, $baseline) || $baseline[$key] !== $value) {
          $changed[$key] = $value;
        }
      }

      if (empty($removed) && empty($changed)) {
        return true;
      }

      $pipe = $this->redis->pipeline();
      foreach (array_chunk($removed, self::DELETE_CHUNK_SIZE) as $chunk) {
        if (!empty($chunk)) {
          $pipe->hdel($hash_key, ...$chunk);
        }
      }

      if (!empty($changed)) {
        $pipe->hMSet($hash_key, $changed);
      }

      $pipe->exec();

      if (($ttl = $this->redis_ttl()) > 0) {
        $this->redis->expire($hash_key, $ttl);
      }

      return true;
    } catch (Throwable $e) {
      $this->handle_cache('sync alloptions', $e);
      return false;
    }
  }

  private function update_counter($key, int $offset, $group)
  {
    $group = $this->normalize_group($group);
    $cache_key = $this->build_key_for_group($key, $group);

    if ($cache_key === false) {
      return false;
    }

    if ($this->is_non_persistent($group) || !$this->redis_connected) {
      if (!$this->has_runtime($cache_key)) {
        return false;
      }

      $new_value = $this->counter_value($this->get_runtime($cache_key), $offset);
      $this->store_runtime($cache_key, $new_value);
      return $new_value;
    }

    try {
      if (!$this->redis->exists($cache_key)) {
        return false;
      }

      $ttl_ms = $offset < 0 ? (int) $this->redis->pttl($cache_key) : null;
      $result =
        $offset >= 0
          ? $this->redis->rawCommand('INCRBY', $cache_key, (string) $offset)
          : $this->redis->rawCommand('DECRBY', $cache_key, (string) abs($offset));

      if ($result === false || $result === null) {
        return false;
      }

      $new_value = max(0, (int) $result);
      if ((int) $result < 0) {
        $this->set_raw_integer($cache_key, $new_value, 0, null, $ttl_ms);
      }

      $this->store_runtime($cache_key, $new_value);
      return $new_value;
    } catch (Throwable $e) {
      $this->handle_cache('counter', $e);
      return false;
    }
  }

  private function counter_value($value, int $offset): int
  {
    $current = is_numeric($value) ? (int) $value : 0;
    return max(0, $current + $offset);
  }

  private function set_redis_value(string $cache_key, $value, int $expire = 0, ?string $mode = null): bool
  {
    if (is_int($value)) {
      return $this->set_raw_integer($cache_key, $value, $expire, $mode);
    }

    $args = $this->redis_set_args($this->redis_ttl($expire), $mode);

    if (empty($args)) {
      return (bool) $this->redis->set($cache_key, $this->wrap_value($value));
    }

    return (bool) $this->redis->set($cache_key, $this->wrap_value($value), $args);
  }

  private function redis_set_args(int $ttl, ?string $mode = null): array
  {
    $args = [];

    if ($mode) {
      $args[] = $mode;
    }

    if ($ttl > 0) {
      $args['ex'] = $ttl;
    }

    return $args;
  }

  private function write_context(?string $mode = null): string
  {
    if ($mode === 'nx') {
      return 'add';
    }

    if ($mode === 'xx') {
      return 'replace';
    }

    return 'set';
  }

  private function set_raw_integer(
    string $cache_key,
    int $value,
    int $expire = 0,
    ?string $mode = null,
    ?int $ttl_ms = null
  ): bool {
    $args = ['SET', $cache_key, (string) $value];
    $ttl = $ttl_ms === null ? $this->redis_ttl($expire) : 0;

    if ($ttl_ms !== null && $ttl_ms > 0) {
      $args[] = 'PX';
      $args[] = (string) $ttl_ms;
    } elseif ($ttl > 0) {
      $args[] = 'EX';
      $args[] = (string) $ttl;
    }

    if ($mode) {
      $args[] = strtoupper($mode);
    }

    return (bool) $this->redis->rawCommand(...$args);
  }

  private function redis_ttl(int $expire = 0): int
  {
    if ($expire > 0 && $this->max_ttl > 0) {
      return min($expire, $this->max_ttl);
    }

    return $expire > 0 ? $expire : $this->max_ttl;
  }

  private function wrap_value($value)
  {
    if ($value !== false) {
      return $value;
    }

    return [self::FALSE_VALUE_MARKER => self::VALUE_VERSION];
  }

  private function unwrap_value($payload, ?bool &$found, ?string $cache_key = null)
  {
    if ($payload === false) {
      $found = false;
      return false;
    }

    if (is_string($payload) && preg_match('/^-?\d+$/', $payload) === 1 && $cache_key) {
      try {
        if ($this->redis->rawCommand('GET', $cache_key) === $payload) {
          $found = true;
          return (int) $payload;
        }
      } catch (Throwable $e) {
        $this->handle_cache('get raw integer', $e);
      }
    }

    if (
      is_array($payload) &&
      count($payload) === 1 &&
      ($payload[self::FALSE_VALUE_MARKER] ?? null) === self::VALUE_VERSION
    ) {
      $found = true;
      return false;
    }

    $found = true;
    return $payload;
  }

  private function store_runtime(string $cache_key, $value): void
  {
    $this->cache[$cache_key] = is_object($value) ? clone $value : $value;
  }

  private function get_runtime(string $cache_key)
  {
    $value = $this->cache[$cache_key];
    return is_object($value) ? clone $value : $value;
  }

  private function has_runtime(string $cache_key): bool
  {
    return array_key_exists($cache_key, $this->cache);
  }

  private function ordered_result(array $keys, array $result): array
  {
    $ordered = [];

    foreach ($keys as $key) {
      if (array_key_exists($key, $result)) {
        $ordered[$key] = $result[$key];
      }
    }

    return $ordered;
  }

  private function is_alloptions_key($key, string $group): bool
  {
    return $this->normalize_key($key) === 'alloptions' && $group === 'options';
  }

  private function is_non_persistent(string $group): bool
  {
    return isset($this->non_persistent[$group]);
  }

  private function normalize_key($key)
  {
    if (!is_int($key) && !is_string($key)) {
      return false;
    }

    $key = (string) $key;
    if ($key === '') {
      return false;
    }

    return rawurlencode($key);
  }

  private function normalize_group($group): string
  {
    if (!is_int($group) && !is_string($group)) {
      return 'default';
    }

    $group = (string) $group;
    if ($group === '') {
      $group = 'default';
    }

    return rawurlencode($group);
  }

  private function delete_key_results(array $keys): array
  {
    $keys = array_filter($keys, 'is_string');
    $result = [];

    if (empty($keys)) {
      return $result;
    }

    foreach (array_chunk($keys, self::DELETE_CHUNK_SIZE, true) as $chunk) {
      $pipe = $this->redis->pipeline();

      foreach ($chunk as $delete_key) {
        $pipe->del($delete_key);
      }

      $responses = $pipe->exec();
      foreach (array_keys($chunk) as $i => $key) {
        $result[$key] = (int) ($responses[$i] ?? 0) > 0;
      }
    }

    return $result;
  }

  private function delete_keys(array $keys): int
  {
    $keys = array_values(array_filter($keys, 'is_string'));
    if (empty($keys)) {
      return 0;
    }

    $method = method_exists($this->redis, 'unlink') ? 'unlink' : 'del';
    $deleted = 0;

    foreach (array_chunk($keys, self::DELETE_CHUNK_SIZE) as $chunk) {
      $deleted += (int) $this->redis->{$method}(...$chunk);
    }

    return $deleted;
  }

  private function handle_cache(string $context, Throwable $e): void
  {
    $this->redis_connected = false;
    $this->error = $e->getMessage();
    error_log("[FlyingPress {$context}]: {$e->getMessage()}");
  }
}
