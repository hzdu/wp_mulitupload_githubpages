<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * @link https://wordpress.org/plugins/ginger/
 */
function isGingerPluginActivated() {
    
    if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }
    
    return is_plugin_active( 'ginger/ginger-eu-cookie-law.php' );
    
}

/**
 * @link https://wordpress.org/plugins/cookiebot/
 * @link https://www.cookiebot.com/en/developer/
 */
function isCookiebotPluginActivated() {
    
    if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }
    
    return is_plugin_active( 'cookiebot/cookiebot.php' );
    
}

/**
 * @link https://wordpress.org/plugins/cookie-notice/
 */
function isCookieNoticePluginActivated() {
    
    if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }
    
    return is_plugin_active( 'cookie-notice/cookie-notice.php' );
    
}

/**
 * GDPR Cookie Consent
 *
 * @link https://wordpress.org/plugins/cookie-law-info/
 */
function isCookieLawInfoPluginActivated() {
    
    if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }
    
    return is_plugin_active( 'cookie-law-info/cookie-law-info.php' )
           || is_plugin_active( 'webtoffee-cookie-consent/webtoffee-cookie-consent.php' );
    
}

/**
 * ConsentMagic
 */
function isConsentMagicPluginActivated() {

    if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }

    return (is_plugin_active( 'consent-magic-pro/consent-magic-pro.php' ) || is_plugin_active( 'consent-magic/consent-magic.php' )) ;

}
function isConsentMagicPluginInstalled() {

    if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }
    $installed_plugins = get_plugins();
    $plugin_slug = 'consent-magic/consent-magic.php';
    $plugin_slug_pro = "consent-magic-pro/consent-magic-pro.php";

    return
        array_key_exists( $plugin_slug, $installed_plugins ) ||
        in_array( $plugin_slug, $installed_plugins, true ) ||
        array_key_exists( $plugin_slug_pro, $installed_plugins ) ||
        in_array( $plugin_slug_pro, $installed_plugins, true );

}

function isConsentMagicPluginLicenceActivated() {
    $id = get_option('cs_product_id');
    if($id && get_option('wc_am_client_'.$id.'_activated') == 'Activated' || is_plugin_active( 'consent-magic/consent-magic.php')) {
        return true;
    }
    return false;
}

/**
 * GDPR Real Cookie Banner
 *
 * @link https://wordpress.org/plugins/real-cookie-banner/
 */
function isRealCookieBannerPluginActivated() {

    if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }

    return is_plugin_active( 'real-cookie-banner-pro/index.php' )
        || is_plugin_active( 'real-cookie-banner/index.php' ) ;

}

function adminGdprAjaxNotEnabledNotice() {
    $user_id = get_current_user_id();
    $url = buildAdminUrl( 'pixelyoursite', 'gdpr', false, array(
        '_wpnonce' => wp_create_nonce( 'pys_enable_gdpr_ajax' ),
        'pys' => array(
            'enable_gdpr_ajax' => true,
        ),
    ) );
    $meta_key = 'pys_core_gdpr_ajax_notice_dismissed_at';
    $dismissed_at = get_user_meta( $user_id, $meta_key );
    if(!$dismissed_at){
        ?>

        <div class="notice notice-error is-dismissible pys_core_gdpr_ajax_notice pys-notice">
            <p>You use the <strong>GDPR Cookie Consent</strong> and <strong>PixelYourSite PRO</strong> plugins. You
                must turn on "Enable AJAX filter values update" option to avoid problems with cache plugins.
                <a href="<?php echo esc_url( $url ); ?>" class="notice-link"><strong>CLICK HERE TO
                        ENABLE</strong></a>.</p>
        </div>
        <script type="application/javascript">
            jQuery(document).on('click', '.pys_core_gdpr_ajax_notice .notice-dismiss', function () {

                jQuery.ajax({
                    url: ajaxurl,
                    data: {
                        action: 'pys_notice_dismiss',
                        nonce: '<?php echo esc_attr( wp_create_nonce( 'pys_notice_dismiss' ) ); ?>',
                        user_id: '<?php echo esc_attr( $user_id ); ?>',
                        addon_slug: 'core',
                        meta_key: 'gdpr_ajax_notice'
                    }
                })

            })
        </script>
        <?php
    }
}

function adminGdprAjaxEnabledNotice() {
    ?>

    <div class="notice notice-success">
        <p>All good :)</p>
    </div>

    <?php
}

/**
 * The four Google Consent Mode signals as PYS resolves them for the current
 * request — the same values the browser gets in options.gdpr.
 *
 * A signal is 'enabled' when Consent Mode is on (the option, a consent plugin
 * speaking through cm_google_consent_mode, or a pys_{signal}_mode filter);
 * otherwise its value says nothing about the visitor.
 *
 * @return array signal => array( 'enabled' => bool, 'value' => 'granted'|'denied', 'filter' => bool )
 */
function pys_resolve_google_consent_state() {
    $signals = array( 'analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization' );

    $has_mode_filter = false;
    foreach ( $signals as $signal ) {
        $has_mode_filter = $has_mode_filter || has_filter( "pys_{$signal}_mode" );
    }
    $enabled = ( has_filter( 'cm_google_consent_mode' ) || $has_mode_filter ) ? true : PYS()->getOption( 'google_consent_mode' );

    $defaults = array();
    foreach ( $signals as $signal ) {
        $defaults[ $signal ] = array(
            'enabled' => $enabled,
            'value'   => 'granted',
        );
    }
    $state = apply_filters( 'cm_google_consent_mode', $defaults );
    $state = is_array( $state ) ? array_merge( $defaults, $state ) : $defaults;

    foreach ( $signals as $signal ) {
        $filter                     = has_filter( "pys_{$signal}_mode" );
        $state[ $signal ]['filter'] = $filter;
        if ( $filter ) {
            $state[ $signal ]['value'] = apply_filters( "pys_{$signal}_mode", true ) ? 'granted' : 'denied';
        }
    }

    return $state;
}

/**
 * Snapshot the buyer's Consent Mode choice on the order at checkout.
 *
 * Server events of the order (status-change fallback, webhooks, cron, admin)
 * run without the buyer's cookies, so this is the only record of the choice
 * they can use. Stored only for signals Consent Mode actually governs.
 *
 * Consent Magic writes the same _cm_* keys on woocommerce_new_order / EDD
 * payment insert when its order consent log is on; a value already there is
 * the consent plugin's own record and is kept.
 *
 * @param string $type     'woo' or 'edd'
 * @param mixed  $order    WC_Order for 'woo', null for 'edd'
 * @param int    $order_id
 * @return void
 */
function pys_save_consent_in_order( $type, $order, $order_id ) {
    $values = array();
    foreach ( pys_resolve_google_consent_state() as $signal => $data ) {
        if ( empty( $data['enabled'] ) || ! in_array( $data['value'] ?? '', array( 'granted', 'denied' ), true ) ) {
            continue;
        }
        $key      = '_cm_' . $signal;
        $existing = $type === 'woo' ? $order->get_meta( $key, true ) : edd_get_payment_meta( $order_id, $key, true );
        if ( empty( $existing ) ) {
            $values[ $key ] = $data['value'];
        }
    }
    if ( empty( $values ) ) {
        return;
    }

    if ( $type === 'woo' ) {
        foreach ( $values as $key => $value ) {
            $order->update_meta_data( $key, $value );
        }
        $order->save();
        return;
    }

    foreach ( $values as $key => $value ) {
        edd_update_payment_meta( $order_id, $key, $value );
    }
}

/**
 * woocommerce_checkout_update_order_meta / woocommerce_store_api_checkout_update_order_meta
 *
 * @param int|\WC_Order $order_param
 * @return void
 */
function pys_save_consent_in_woo_order( $order_param ) {
    $order = $order_param instanceof \WC_Order ? $order_param : wc_get_order( $order_param );
    if ( ! $order || $order->get_created_via() === 'admin' ) {
        return; // an admin's cookies are not the buyer's choice
    }

    pys_save_consent_in_order( 'woo', $order, $order->get_id() );
}

/**
 * edd_insert_payment
 *
 * @param int $payment_id
 * @return void
 */
function pys_save_consent_in_edd_order( $payment_id ) {
    // A payment added in wp-admin carries the admin's cookies; checkout
    // itself may run through admin-ajax.php.
    if ( empty( $payment_id ) || ( is_admin() && ! wp_doing_ajax() ) ) {
        return;
    }

    pys_save_consent_in_order( 'edd', null, (int) $payment_id );
}

/**
 * Resolve Google Consent Mode params for purchase/subscription/license events.
 *
 * Events bound to an order use only the choice saved on the order at
 * checkout (pys_save_consent_in_order()). When none was saved, no consent
 * params are sent: such events often run in a request that is not the buyer's
 * (webhook, cron, wp-admin), and assuming 'granted' there would report a
 * consent the buyer may never have given.
 *
 * Other events, per parameter:
 *   1. $_REQUEST (cm_analytics_storage, cm_ad_storage, cm_ad_user_data, cm_ad_personalization)
 *   2. 'granted' fallback when the google_consent_mode option is enabled
 *
 * The SingleEvent payload is used to derive the order id:
 *   - woo_order -> WooCommerce order meta
 *   - edd_order -> EDD payment meta
 *
 * @param SingleEvent|null $event
 * @return array
 */
function getConsentModeParams( $event = null ) {
    $params = array();
    $google_consent_mode = PYS()->getOption( 'google_consent_mode' );

    $keys = array(
        'analytics_storage'  => 'cm_analytics_storage',
        'ad_storage'         => 'cm_ad_storage',
        'ad_user_data'       => 'cm_ad_user_data',
        'ad_personalization' => 'cm_ad_personalization',
    );

    $meta_values = array();

    if ( $event instanceof SingleEvent ) {
        $woo_order_id = $event->getPayloadValue( 'woo_order' );
        $edd_order_id = $event->getPayloadValue( 'edd_order' );

        if ( ! empty( $woo_order_id ) && function_exists( 'wc_get_order' ) ) {
            $order = wc_get_order( $woo_order_id );
            if ( $order ) {
                foreach ( $keys as $param_key => $request_key ) {
                    $val = $order->get_meta( '_' . $request_key );
                    if ( ! empty( $val ) ) {
                        $meta_values[ $param_key ] = $val;
                    }
                }
            }
        } elseif ( ! empty( $edd_order_id ) && function_exists( 'edd_get_payment_meta' ) ) {
            foreach ( $keys as $param_key => $request_key ) {
                $val = edd_get_payment_meta( $edd_order_id, '_' . $request_key, true );
                if ( ! empty( $val ) ) {
                    $meta_values[ $param_key ] = $val;
                }
            }
        }
    }

    $order_bound = $event instanceof SingleEvent
        && ( ! empty( $event->getPayloadValue( 'woo_order' ) ) || ! empty( $event->getPayloadValue( 'edd_order' ) ) );

    foreach ( $keys as $param_key => $request_key ) {
        if ( ! empty( $meta_values[ $param_key ] ) ) {
            $params[ $param_key ] = $meta_values[ $param_key ];
        } elseif ( $order_bound ) {
            continue; // nothing recorded at checkout: send no consent params
        } elseif ( isset( $_REQUEST[ $request_key ] ) ) {
            $params[ $param_key ] = sanitize_text_field( $_REQUEST[ $request_key ] );
        } elseif ( $google_consent_mode ) {
            $params[ $param_key ] = 'granted';
        }
    }

    return $params;
}