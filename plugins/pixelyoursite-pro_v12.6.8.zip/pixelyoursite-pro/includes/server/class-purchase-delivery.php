<?php
/**
 * Per-platform delivery state of a server Purchase (Advanced Deduplication).
 *
 * @package PixelYourSite
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Tracks which pixels of a platform have accepted an order's server Purchase.
 *
 * _pys_purchase_event_fired only says the thank-you page built the browser
 * payload; nothing guarantees the browser sent it. In Advanced Deduplication the
 * server copies are therefore gated by what each platform actually accepted:
 *
 *   _pys_server_event_sent_{platform}    accepted pixels:
 *                                        array( 'event_id' => ..., 'pixels' => [...] ).
 *                                        A plain eventID string (written before
 *                                        12.6.8) means every pixel accepted it.
 *   _pys_server_event_pending_{platform} pixels a request is sending right now:
 *                                        array( 'event_id' => ..., 'pixels' => [ id => time ] ).
 *
 * A request claims the pixels it is about to send, so the browser AJAX copy and
 * the order-status fallback cannot both send the same Purchase — Meta does not
 * deduplicate two server events. A claim left by a request that died expires
 * after CLAIM_TTL seconds; a failed send drops its claim at once, so the pixel
 * stays retryable.
 */
class PurchaseDelivery {

    const CLAIM_TTL = 120;

    /**
     * Is this an order-bound purchase event in Advanced Deduplication mode?
     *
     * @param SingleEvent $event
     * @return array|null array( type, order_id, event_id ) or null
     */
    public static function getContext( $event ) {
        $event_name = $event->getId();

        if ( $event_name === 'woo_purchase' ) {
            $type     = 'woo';
            $order_id = isset( $event->payload['woo_order'] ) ? (int) $event->payload['woo_order'] : 0;
        } elseif ( $event_name === 'edd_purchase' || $event_name === 'edd_complete_payment' ) {
            $type     = 'edd';
            $order_id = isset( $event->payload['edd_order'] ) ? (int) $event->payload['edd_order'] : 0;
        } else {
            return null;
        }

        $event_id = isset( $event->payload['eventID'] ) ? (string) $event->payload['eventID'] : '';

        if ( ! $order_id || $event_id === '' || ! self::isAdvancedMode( $type ) ) {
            return null;
        }
        if ( $type === 'woo' && ! function_exists( 'wc_get_order' ) ) {
            return null;
        }
        if ( $type === 'edd' && ! function_exists( 'edd_get_payment_meta' ) ) {
            return null;
        }

        return array( $type, $order_id, $event_id );
    }

    /**
     * @param string $type 'woo' or 'edd'
     * @return bool
     */
    public static function isAdvancedMode( $type ) {
        return PYS()->getOption( "{$type}_purchase_on_transaction_mode", 'advanced' ) !== 'single';
    }

    /**
     * Reserve the pixels that still need this Purchase.
     *
     * @param string $type
     * @param int    $order_id
     * @param string $platform
     * @param string $event_id
     * @param array  $pixel_ids Pixels the caller wants to send to
     * @return array Pixels the caller may send to now; the rest were accepted
     *               already or are being sent by another request.
     */
    public static function claim( $type, $order_id, $platform, $event_id, $pixel_ids ) {
        $pixel_ids = array_values( array_unique( array_map( 'strval', (array) $pixel_ids ) ) );
        if ( empty( $pixel_ids ) ) {
            return array();
        }

        return self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platform, $event_id, $pixel_ids ) {
            $sent    = self::getSentPixels( $type, $order, $order_id, $platform, $event_id );
            if ( $sent === true ) {
                return array();
            }
            $pending = self::getPending( $type, $order, $order_id, $platform, $event_id );
            $now     = time();

            $claimed = array();
            foreach ( $pixel_ids as $pixel_id ) {
                if ( in_array( $pixel_id, $sent, true ) ) {
                    continue;
                }
                if ( isset( $pending[ $pixel_id ] ) && $now - (int) $pending[ $pixel_id ] < self::CLAIM_TTL ) {
                    continue;
                }
                $pending[ $pixel_id ] = $now;
                $claimed[]            = $pixel_id;
            }

            if ( ! empty( $claimed ) ) {
                self::writeMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}", array(
                    'event_id' => $event_id,
                    'pixels'   => $pending,
                ) );
            }

            return $claimed;
        } );
    }

    /**
     * Record the outcome of a send: accepted pixels become "sent", the claim of
     * every other claimed pixel is dropped so a later attempt may retry it.
     *
     * @param string $type
     * @param int    $order_id
     * @param string $platform
     * @param string $event_id
     * @param array  $claimed  Pixels returned by claim()
     * @param array  $accepted Pixels the platform accepted
     */
    public static function settle( $type, $order_id, $platform, $event_id, $claimed, $accepted ) {
        $claimed  = array_map( 'strval', (array) $claimed );
        $accepted = array_values( array_intersect( array_map( 'strval', (array) $accepted ), $claimed ) );

        self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platform, $event_id, $claimed, $accepted ) {
            if ( ! empty( $accepted ) ) {
                $sent = self::getSentPixels( $type, $order, $order_id, $platform, $event_id );
                if ( $sent !== true ) {
                    self::writeMeta( $type, $order, $order_id, "_pys_server_event_sent_{$platform}", array(
                        'event_id' => $event_id,
                        'pixels'   => array_values( array_unique( array_merge( $sent, $accepted ) ) ),
                    ) );
                }
            }

            $pending = self::getPending( $type, $order, $order_id, $platform, $event_id );
            foreach ( $claimed as $pixel_id ) {
                unset( $pending[ $pixel_id ] );
            }
            self::writeMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}", empty( $pending ) ? null : array(
                'event_id' => $event_id,
                'pixels'   => $pending,
            ) );

            return null;
        } );
    }

    /**
     * Mark pixels as handed off to a sender that retries on its own (the
     * events queue): from here the queue owns the delivery.
     */
    public static function markHandedOff( $type, $order_id, $platform, $event_id, $pixel_ids ) {
        $claimed = self::claim( $type, $order_id, $platform, $event_id, $pixel_ids );
        if ( ! empty( $claimed ) ) {
            self::settle( $type, $order_id, $platform, $event_id, $claimed, $claimed );
        }

        return $claimed;
    }

    /**
     * Pixels that accepted this event_id.
     *
     * @return array|true true when the legacy marker says every pixel did
     */
    private static function getSentPixels( $type, $order, $order_id, $platform, $event_id ) {
        $value = self::readMeta( $type, $order, $order_id, "_pys_server_event_sent_{$platform}" );

        if ( is_string( $value ) ) {
            return $value !== '' && $value === $event_id ? true : array();
        }
        if ( is_array( $value ) && isset( $value['event_id'], $value['pixels'] ) && (string) $value['event_id'] === $event_id ) {
            return array_map( 'strval', (array) $value['pixels'] );
        }

        return array();
    }

    private static function getPending( $type, $order, $order_id, $platform, $event_id ) {
        $value = self::readMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}" );

        if ( is_array( $value ) && isset( $value['event_id'], $value['pixels'] ) && (string) $value['event_id'] === $event_id ) {
            return (array) $value['pixels'];
        }

        return array();
    }

    /**
     * Run a read-modify-write of the order's delivery meta under a per-order
     * lock, on freshly read meta. Its own lock context, so it nests inside the
     * purchase lock of the order-status fallback.
     */
    private static function withLock( $type, $order_id, callable $callback ) {
        $lock_state = pysAcquireNamedLock( 'purchase_claim_' . $type, $order_id, 5 );

        try {
            $order = null;
            if ( $type === 'woo' ) {
                if ( ! function_exists( 'wc_get_order' ) ) {
                    return array();
                }
                $order = wc_get_order( $order_id );
                if ( ! $order ) {
                    return array();
                }
                $order->read_meta_data( true );
            } else {
                if ( ! function_exists( 'edd_update_payment_meta' ) ) {
                    return array();
                }
                // EDD 3 order meta lives in the edd_order meta type.
                wp_cache_delete( $order_id, 'edd_order_meta' );
            }

            return $callback( $order );
        } finally {
            if ( 'acquired' === $lock_state ) {
                pysReleaseNamedLock( 'purchase_claim_' . $type, $order_id );
            }
        }
    }

    private static function readMeta( $type, $order, $order_id, $key ) {
        if ( $type === 'woo' ) {
            return $order->get_meta( $key, true );
        }

        return edd_get_payment_meta( $order_id, $key, true );
    }

    private static function writeMeta( $type, $order, $order_id, $key, $value ) {
        if ( $type === 'woo' ) {
            if ( $value === null ) {
                $order->delete_meta_data( $key );
            } else {
                $order->update_meta_data( $key, $value );
            }
            $order->save();
            return;
        }

        // EDD has no payment-level delete helper; an empty value reads as "none".
        edd_update_payment_meta( $order_id, $key, $value === null ? '' : $value );
    }
}
