<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Consent {

	private static $_instance;
	private string $consentKey    = "pys_consent";
	private bool   $consentLoaded = false;
	private bool   $consentPlugin = false;
	private array  $cookieConsent = array();

	private array $consentData = array(
		'facebook'   => true,
		'ga'         => true,
		'google_ads' => true,
		'tiktok'     => true,
		'bing'       => true,
		'pinterest'  => true,
		'gtm'        => true,
		'reddit'     => true,
		'openai'     => true,
		'awin'       => true,
	);

	public static function instance(): Consent {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct() {
		$this->checkConsentPlugin();
	}

	/**
	 * Consent is resolved on first use, never at construction time.
	 *
	 * @return void
	 */
	private function loadConsent() {

		if ( $this->consentLoaded ) {
			return;
		}

		$has_cookie = false;

		if ( $this->consentPlugin ) {

			if ( isset( $_COOKIE[ $this->consentKey ] ) && !empty( $_COOKIE[ $this->consentKey ] ) ) {

				$consent = json_decode( base64_decode( sanitize_text_field( $_COOKIE[ $this->consentKey ] ) ), true );

				if ( !empty( $consent ) ) {
					$this->consentData   = $consent;
					$this->cookieConsent = $consent;
					$has_cookie        = true;
				} else {
					$this->disableAllPixels();
				}

			} else {
				$this->disableAllPixels();
			}
		}

		$this->consentLoaded = (bool) did_action( 'plugins_loaded' );

		if ( apply_filters( 'pys_disable_by_gdpr', false ) ) {
			$this->disableAllPixels();

			return;
		}

		$this->applyGdprFilter( array( 'facebook' ), 'pys_disable_facebook_by_gdpr', $has_cookie );
		$this->applyGdprFilter( array( 'ga', 'gtm' ), 'pys_disable_analytics_by_gdpr', $has_cookie );
		$this->applyGdprFilter( array( 'google_ads' ), 'pys_disable_google_ads_by_gdpr', $has_cookie );
		$this->applyGdprFilter( array( 'pinterest' ), 'pys_disable_pinterest_by_gdpr', $has_cookie );
		$this->applyGdprFilter( array( 'bing' ), 'pys_disable_bing_by_gdpr', $has_cookie );
		$this->applyGdprFilter( array( 'tiktok' ), 'pys_disable_tiktok_by_gdpr', $has_cookie );
		$this->applyGdprFilter( array( 'reddit' ), 'pys_disable_reddit_by_gdpr', $has_cookie );
		$this->applyGdprFilter( array( 'openai' ), 'pys_disable_openai_by_gdpr', $has_cookie );
		$this->applyGdprFilter( array( 'awin' ), 'pys_disable_awin_by_gdpr', $has_cookie );

		if ( $this->consentPlugin && !has_filter( 'pys_disable_awin_by_gdpr' ) ) {

			if ( $this->consentMagicIntegrated() ) {
				// ConsentMagic without Awin support: Awin follows the Facebook
				// category. No Facebook filter means CM does not gate Facebook.
				$this->consentData[ 'awin' ] = has_filter( 'pys_disable_facebook_by_gdpr' )
					? !apply_filters( 'pys_disable_facebook_by_gdpr', false )
					: true;

			} elseif ( !$has_cookie && $this->pixelFiltersHooked() ) {
				// A consent plugin that answers for the other pixels but not
				// for Awin is not a yes for Awin.
				$this->consentData[ 'awin' ] = false;
			}
		}
	}

	private function consentMagicIntegrated(): bool {
		return isConsentMagicPluginActivated() && PYS()->getOption( 'consent_magic_integration_enabled' );
	}

	/**
	 * Whether a consent plugin answers through the per-pixel filters.
	 *
	 * @return bool
	 */
	private function pixelFiltersHooked(): bool {

		$filters = array(
			'pys_disable_facebook_by_gdpr',
			'pys_disable_analytics_by_gdpr',
			'pys_disable_google_ads_by_gdpr',
			'pys_disable_pinterest_by_gdpr',
			'pys_disable_bing_by_gdpr',
			'pys_disable_tiktok_by_gdpr',
			'pys_disable_reddit_by_gdpr',
			'pys_disable_openai_by_gdpr',
		);

		foreach ( $filters as $filter ) {
			if ( has_filter( $filter ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * A consent plugin speaks through one of two channels, and only one of them
	 * is present on any given site.
	 *
	 * @param string[] $slugs      Pixels the filter governs.
	 * @param string   $filter     Filter name.
	 * @param bool     $has_cookie Whether the visitor's choice was in the cookie.
	 * @return void
	 */
	private function applyGdprFilter( array $slugs, string $filter, bool $has_cookie ): void {

		if ( has_filter( $filter ) ) {
			$disabled = (bool) apply_filters( $filter, false );

			foreach ( $slugs as $slug ) {
				$this->consentData[ $slug ] = !$disabled;
			}

			return;
		}

		if ( $has_cookie ) {
			return; // the cookie already carries the answer
		}

		foreach ( $slugs as $slug ) {
			$this->consentData[ $slug ] = true;
		}
	}

	/**
	 * Whether a site without a consent plugin answers through the filters,
	 * the same ones the browser reads.
	 *
	 * @return bool
	 */
	private function gdprFiltersHooked(): bool {
		return has_filter( 'pys_disable_by_gdpr' )
			|| has_filter( 'pys_disable_awin_by_gdpr' )
			|| $this->pixelFiltersHooked();
	}

	private function checkConsentPlugin(): void {
		$this->consentPlugin = isCookiebotPluginActivated() || isCookieNoticePluginActivated() || isRealCookieBannerPluginActivated() || isConsentMagicPluginActivated() || isCookieLawInfoPluginActivated();
	}

	private function disableAllPixels(): void {
		foreach ( $this->consentData as &$pixel ) {
			$pixel = false;
		}

		unset( $pixel );
	}

	/**
	 * A refusal does not always mean silence.
	 *
	 * @param string $pixel Pixel slug.
	 * @return bool
	 */
	public function firesInRestrictedMode( $pixel ): bool {

		switch ( $pixel ) {

			case 'facebook':
				$restricted = (bool) apply_filters( 'pys_meta_ldu_mode', false );
				break;

			case 'reddit':
				$restricted = (bool) apply_filters( 'pys_reddit_ldu_mode', false );
				break;

			case 'openai':
				$restricted = (bool) apply_filters( 'pys_openai_consent_mode', false );
				break;

			case 'awin':
				// Awin reports without consent only in its own consent mode.
				$restricted = function_exists( __NAMESPACE__ . '\Awin' ) && Awin()->loadsBeforeConsent();
				break;

			case 'ga':
			case 'gtm':
			case 'google_ads':
				$restricted = has_filter( 'cm_google_consent_mode' )
					|| has_filter( 'pys_analytics_storage_mode' )
					|| has_filter( 'pys_ad_storage_mode' )
					|| has_filter( 'pys_ad_user_data_mode' )
					|| has_filter( 'pys_ad_personalization_mode' );
				break;

			case 'bing':
				$restricted = has_filter( 'cm_bing_consent_mode' )
					|| has_filter( 'pys_bing_ad_storage_mode' );
				break;

			default:
				$restricted = false;
		}

		return (bool) apply_filters( 'pys_pixel_restricted_mode', (bool) $restricted, $pixel );
	}

	/**
	 * May this pixel report anything at all right now?
	 *
	 * @param string $pixel Pixel slug.
	 * @return bool
	 */
	public function mayFire( $pixel ): bool {
		return $this->checkConsent( $pixel ) || $this->firesInRestrictedMode( $pixel );
	}

	/**
	 * Consent that a real answer stands behind.
	 *
	 * checkConsent() falls back to "allowed" when a consent plugin is installed
	 * but has said nothing yet (first visit, nothing chosen). Storing an ID in a
	 * cookie needs more than that: the plugin answered through its filter, or
	 * the visitor's recorded choice says yes.
	 *
	 * @param string $pixel Pixel slug.
	 * @return bool
	 */
	public function hasExplicitConsent( $pixel ): bool {

		if ( !$this->checkConsent( $pixel ) ) {
			return false;
		}

		if ( !$this->consentPlugin || has_filter( 'pys_check_consent_by_gdpr' ) ) {
			$explicit = true;
		} elseif ( has_filter( "pys_disable_{$pixel}_by_gdpr" ) ) {
			$explicit = true;
		} elseif ( 'awin' === $pixel && $this->consentMagicIntegrated() ) {
			// Answered from the ConsentMagic configuration (the Facebook category).
			$explicit = true;
		} else {
			$explicit = isset( $this->cookieConsent[ $pixel ] ) && true === $this->cookieConsent[ $pixel ];
		}

		return (bool) apply_filters( 'pys_explicit_consent', $explicit, $pixel );
	}

	public function checkConsent( $pixel ): bool {

		if ( $this->consentPlugin || $this->gdprFiltersHooked() ) {
			$this->loadConsent();
		}

		$consented = $this->consentData[ $pixel ] ?? false;

        return (bool) apply_filters( 'pys_check_consent_by_gdpr', $consented, $pixel );
	}
}

/**
 * @return Consent
 */
function Consent(): Consent {
	return Consent::instance();
}

Consent();