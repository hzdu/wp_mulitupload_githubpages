<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Order parameters asked for by a custom event's WooCommerce purchase trigger.
 *
 * The purchase trigger carries two switches, "Track value and currency" and
 * "Track transaction ID". Every sender that builds a custom event reads them here
 * so the Google Ads conversion, the GA4 event, the GTM data layer and the Meta
 * event all carry the same value, currency and transaction_id for the same order.
 *
 * @param CustomEvent   $customEvent The event being built.
 * @param callable|null $get_order   Returns the order on this page, or false. Defaults to
 *                                   EventsWoo()->getOrder(); tests pass a stub.
 *
 * @return array Subset of value / currency / transaction_id, or [] when the event has no
 *               purchase trigger, both switches are off, or there is no order.
 */
function getCustomEventPurchaseTriggerParams( $customEvent, $get_order = null ) {

	$purchase_trigger = null;
	foreach ( $customEvent->getTriggers() as $trigger ) {
		if ( $trigger->getTriggerType() === 'purchase' ) {
			$purchase_trigger = $trigger;
			break;
		}
	}
	if ( ! $purchase_trigger ) {
		return array();
	}

	$track_value = (bool) $purchase_trigger->getTrackValueAndCurrency();
	$track_id    = (bool) $purchase_trigger->getTrackTransactionID();
	if ( ! $track_value && ! $track_id ) {
		return array();
	}

	$order = $get_order ? call_user_func( $get_order ) : EventsWoo()->getOrder();
	if ( ! $order ) {
		return array();
	}

	$params = array();
	if ( $track_value ) {
		$params['value']    = $order->get_total();
		$params['currency'] = $order->get_currency();
	}
	if ( $track_id ) {
		$params['transaction_id'] = wooMapOrderId( $order->get_id() );
	}

	return $params;
}
