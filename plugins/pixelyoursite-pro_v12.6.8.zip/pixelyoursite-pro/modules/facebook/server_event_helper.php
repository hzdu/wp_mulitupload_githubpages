<?php
namespace PixelYourSite;

use PixelYourSite;
use PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\Event;
use PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\UserData;
use PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\CustomData;
use PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\Content;
defined('ABSPATH') or die('Direct access not allowed');




class ServerEventHelper {

	private static $fbp;
	private static $fbc;
    /**
     * @param SingleEvent $event
     * @return Event | null
     */
    public static function mapEventToServerEvent($event) {

        $eventData = $event->getData();

        $eventData = EventsManager::filterEventParams($eventData,$event->getCategory(),[
            'event_id'=>$event->getId(),
            'pixel'=>Facebook()->getSlug()
        ]);

        $eventName = $eventData['name'];
        $eventParams = $eventData['params'];
        $wooOrder = isset($event->payload['woo_order']) ? $event->payload['woo_order'] : null;
        $eddOrder = isset($event->payload['edd_order']) ? $event->payload['edd_order'] : null;

        // Loaded once: the order supplies the customer's IP, user agent and
        // stored _fbp/_fbc below. Guarded because $wooOrder can arrive from the
        // client payload on a site that has no WooCommerce at all.
        $order = null;
        if ( $wooOrder && PixelYourSite\isWooCommerceActive() ) {
            $order = \wc_get_order( $wooOrder ) ?: null;
        }
        // An EDD order is not loaded here, but its event is order-bound all the
        // same: a gateway webhook carries no browser to mint a browser id for.
        $order_bound = $order || !empty( $eddOrder );

        // The request this runs in is not always the customer's: an admin
        // changing an order's status, a gateway webhook, cron. IP and user
        // agent therefore come from the order when it has them, and the
        // request's own cookies are read only when the request is a visitor's.
        // See includes/functions-event-signals.php.
        $signals = pys_event_client_signals( $order, self::getIpAddress(), self::getHttpUserAgent(), pys_is_admin_page_request() );

        $user_data = ServerEventHelper::getUserData($wooOrder,$eddOrder)
            ->setClientUserAgent( $signals['user_agent'] );

        // Set only when we have a routable address. An empty client_ip_address
        // is not a neutral value: it occupies the field Meta weighs most with
        // something that cannot match.
        if ( '' !== $signals['ip'] ) {
            $user_data->setClientIpAddress( $signals['ip'] );
        }

		$fbp_withheld      = false;
		$fbp_withheld_note = '';

		if ( ! $signals['request_cookies'] ) {
			// A wp-admin request: its cookies are the administrator's, and a
			// cookie minted here would land in the administrator's browser.
		} elseif ( ParamBuilderAdapter::is_enabled() ) {
			// Meta's param builder already minted and persisted these on 'init',
			// in the correct format: a millisecond creation time, a derived
			// subdomain_index, an fbclid recovered from the referrer when the
			// URL had none, and the appendix that lets Meta recognise the
			// integration. Nothing to do here but read the result.
			ParamBuilderAdapter::for_request()->flush_cookies();
		} elseif ( Consent()->checkConsent( 'facebook' ) ) {
			// Meta's format is `version.subdomainIndex.creationTime.payload`,
			// creationTime in MILLISECONDS; $fb_prefix supplies both.
			//
			// Writing needs headers unsent, cookies not switched off by the
			// site AND the domain settled: a host-only write while pending
			// stakes a claim the next request contradicts.
			// Whether a value may be PRODUCED is answered per cookie below.
			$can_write = pys_may_write_cookies();

			$fb_prefix = 'fb.' . pys_cookie_subdomain_index_for_request() . '.'
				. (int) round( microtime( true ) * 1000 ) . '.';

			// `_fbp` needs both answers to agree: its payload is random, so a
			// value sent but not stored is a browser id that exists nowhere.
			// Withholding is noted here and logged further down, once the
			// order's stored value has had its turn: a webhook or cron request
			// has no cookies but usually does have the order, and an `_fbp`
			// that reaches Meta from there was not withheld from anyone.
			//
			// Never minted for an order-bound event or on cron: there is no
			// browser, and the static would hand one invented id to every
			// order of a batch. That skip is not a withheld loss either.
			//
			// A payload `_fbp` counts only when Meta's library would keep it
			// (pys_fbp_is_valid()); an invalid cookie or payload is as good as
			// none, and the new value overwrites the cookie once.
			if ( !$order_bound && !wp_doing_cron() && !self::getFbp() && !( isset( $eventParams[ '_fbp' ] ) && pys_fbp_is_valid( $eventParams[ '_fbp' ] ) ) ) {
				if ( $can_write ) {
					self::setFbp( pys_fb_append_appendix( $fb_prefix . mt_rand( 0, 2147483647 ), true ) );
					setcookie( "_fbp", self::getFbp(), time() + pys_fb_cookie_lifetime(), '/', pys_cookie_domain() );
					// Readable within this request: the order snapshot taken
					// later must not store the stale value.
					$_COOKIE['_fbp'] = self::getFbp();
				} else {
					$fbp_withheld      = true;
					$fbp_withheld_note = headers_sent() ? 'the response headers were already sent' : '';
				}
			}

			// `_fbc` is produced even when it cannot be stored: its payload is
			// the request's `fbclid`, not an invented id, so there is no phantom
			// identity. The domain is pending on the landing request of every
			// paid click, and withholding there loses the click on a bounce.
			// The cost: Meta may see two `_fbc` strings for one click, ours and
			// our JS's, differing in creation time.
			//
			// The referrer is consulted only when the URL carries no fbclid:
			// server events POST to /wp-json/..., whose Referer is the landing
			// page.
			$fbclid = self::getUrlParameter( 'fbclid' );

			if ( ! $fbclid ) {
				$fbclid = pys_fbclid_from_referrer();
			}

			// A new click replaces a stored one; the same click id does not,
			// because re-minting would move creation_time. The URL is read on
			// every event now, not only when `_fbc` is missing — that is how a
			// second ad click is noticed at all.
			if ( pys_fbc_needs_refresh( self::getFbc(), (string) $fbclid ) ) {
				self::setFbc( pys_fb_append_appendix( $fb_prefix . $fbclid, true ) );
				if ( $can_write ) {
					setcookie( "_fbc", self::$fbc, time() + pys_fb_cookie_lifetime(), '/', pys_cookie_domain() );
					// Readable within this request: the order snapshot taken
					// later must not store the stale click.
					$_COOKIE['_fbc'] = self::$fbc;
				} else {
					// The value above still reaches Meta; what is lost is the
					// cookie, and with it every reader of document.cookie on
					// this page load (a form's hidden field, for one).
					pys_cookie_domain_log_deferral( '_fbc', headers_sent() ? 'the response headers were already sent' : '' );
				}
			}
		}

        $fbp = '';
        $fbc = '';

        if ( $order ) {
            $fbCookie = $order->get_meta('pys_fb_cookie', true);
            if ($fbCookie) {
                if (!empty($fbCookie['fbp']) && pys_fbp_is_valid($fbCookie['fbp'])) {
                    $fbp = $fbCookie['fbp'];
                }
                if (!empty($fbCookie['fbc'])) {
                    $fbc = $fbCookie['fbc'];
                }
            }
        }

// Checking that the values are not empty and setting alternative values if they are missing.
// Order-sourced values keep top priority: they were captured when the order was
// placed and describe that visitor, which a value read now may no longer do.
// The request's values stand in only when the request is that visitor's: in
// wp-admin they are the administrator's, and an order placed without a browser
// is better sent without a browser id than with the wrong one.
        if ( $signals['request_cookies'] ) {
            // Not for an order-bound event or on cron, for the reason `_fbp` is
            // not minted there: the adapter is a per-request singleton, so a
            // queue batch would share one invented id between unrelated orders.
            if ( empty( $fbp ) && ParamBuilderAdapter::is_enabled() && ! $order_bound && ! wp_doing_cron() ) {
                $fbp = ParamBuilderAdapter::for_request()->get_fbp() ?? '';
                // The adapter withholds `_fbp` while the cookie domain is pending
                // and says nothing about it: whether that is a loss depends on the
                // fallbacks below, so the note is taken here and logged at the end.
                if ( '' === $fbp && pys_cookie_domain_pending() ) {
                    $fbp_withheld = true;
                }
            }
            if ( empty( $fbc ) && ParamBuilderAdapter::is_enabled() ) {
                $fbc = ParamBuilderAdapter::for_request()->get_fbc() ?? '';
            }
            if(empty($fbp)) {
                $fbp = self::getFbp() ?? ( isset( $eventParams['_fbp'] ) && pys_fbp_is_valid( $eventParams['_fbp'] ) ? $eventParams['_fbp'] : '' );
            }
            if (empty($fbc)) {
                $fbc = self::getFbc() ?? $eventParams['_fbc'] ?? '';
            }
        }

        // Only now is "withheld" a loss: nothing above could supply an `_fbp`
        // either, so this event reaches Meta without one. Logged because a
        // site whose front end never reports the domain would otherwise lose
        // server-side `_fbp` silently and permanently.
        if ( ! empty( $fbp_withheld ) && empty( $fbp ) ) {
            pys_cookie_domain_log_deferral( '_fbp', $fbp_withheld_note );
        }

        // Whatever supplied the value — the order snapshot, a cookie, the payload
        // — it is tagged as unchanged rather than new. A value we minted above
        // already carries its own token and is returned untouched.
        if(!empty($fbp)) { $user_data->setFbp( pys_fb_append_appendix( $fbp, false ) ); }
        if(!empty($fbc)) { $user_data->setFbc( pys_fb_append_appendix( $fbc, false ) ); }


        $customData = self::paramsToCustomData($eventParams, $event);
        $uri = self::getRequestUri(PYS()->getOption('enable_remove_source_url_params'));

        // set custom uri use in ajax request
        if(isset($_POST['url'])) {
            if(PYS()->getOption('enable_remove_source_url_params')) {
                $list = explode("?",esc_url_raw($_POST[ 'url' ]));
                if(is_array($list) && count($list) > 0) {
                    $uri = $list[0];
                } else {
                    $uri = esc_url_raw($_POST[ 'url' ]);
                }
            } else {
                $uri = esc_url_raw($_POST[ 'url' ]);
            }
        }

        // Highest priority: the real page URL captured by the browser and
        // passed through the REST/AJAX payload (or derived from the REST
        // request Referer header). Meta requires event_source_url to be the
        // page where the event happened, not the REST endpoint.
        if ( method_exists( $event, 'getPayloadValue' ) ) {
            $payload_source_url = $event->getPayloadValue( 'event_source_url' );
            if ( ! empty( $payload_source_url ) ) {
                if ( PYS()->getOption( 'enable_remove_source_url_params' ) ) {
                    $payload_source_url = explode( '?', esc_url_raw( $payload_source_url ) )[0];
                } else {
                    $payload_source_url = esc_url_raw( $payload_source_url );
                }
                $uri = $payload_source_url;
            }
        }

        // A top-level server event parameter, not a custom_data property.
        $referrer_url = pys_resolve_event_referrer_url( $event );
        self::requireServerSideClasses();

        $serverEvent = (new PysServerEvent())
            ->setReferrerUrl($referrer_url)
            ->setEventName($eventName)
            ->setEventTime(time())
            ->setEventSourceUrl($uri)
            ->setActionSource("website")
            ->setCustomData($customData)
            ->setUserData($user_data);

        if(isset($event->payload['eventID'])) {
            $serverEvent->setEventId($event->payload['eventID']);
        }

		if ( Facebook()->getLDUMode() ) {
			$serverEvent
				->setDataProcessingOptions( [ 'LDU' ] )
				->setDataProcessingOptionsCountry( 0 )
				->setDataProcessingOptionsState( 0 );
		}

        return $serverEvent;
    }


    // pys_client_ip_for_capi(), not PYS()->get_user_ip(): the latter may return a
    // private or reserved address on purpose, because blocked_ips and transient
    // keys need any stable identifier. Meta cannot match on one, so here an empty
    // result is the honest answer and the caller omits the parameter.
    private static function getIpAddress() {
        return pys_client_ip_for_capi();
    }

    private static function isValidIpAddress($ip_address) {
        return filter_var($ip_address,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_IPV4
            | FILTER_FLAG_IPV6
            | FILTER_FLAG_NO_PRIV_RANGE
            | FILTER_FLAG_NO_RES_RANGE);
    }

    private static function getHttpUserAgent() {
        $user_agent = null;

        if (!empty($_SERVER['HTTP_USER_AGENT'])) {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
        }

        return $user_agent;
    }

    private static function getRequestUri($removeQuery = false) {
        $request_uri = null;

        if (!empty($_SERVER['REQUEST_URI'])) {
            $start = pys_get_request_protocol();
            $host = $_SERVER['HTTP_HOST'] ?? parse_url(get_site_url(), PHP_URL_HOST);
            $request_uri = $start . $host . $_SERVER['REQUEST_URI'];
        }
        if($removeQuery && isset($_SERVER['QUERY_STRING'])) {
            $request_uri = str_replace("?".$_SERVER['QUERY_STRING'],"",$request_uri);
        }


        return $request_uri;
    }
	/**
	 * A named query parameter's value, or false when it has none.
	 *
	 * `?fbclid` with no `=` must not become a click id: boolean true used to
	 * stringify into one and pin the visitor to it, since the caller only mints
	 * while `! self::getFbc()`. A valueless match does not end the scan either,
	 * so `?fbclid&fbclid=REAL` still finds the real one. Its JS twin in
	 * dist/scripts/public.js must agree; tools/tests/url-parameter.* assert both.
	 *
	 * @param string $sParam Parameter name.
	 * @return string|false Decoded value, or false if absent or valueless.
	 */
	static function getUrlParameter($sParam) {
		// Absent on WP-CLI and some cron paths.
		$sPageURL = isset( $_SERVER['QUERY_STRING'] ) ? (string) $_SERVER['QUERY_STRING'] : '';
		$sURLVariables = explode('&', $sPageURL);

		foreach ($sURLVariables as $sURLVariable) {
			$sParameterName = explode('=', $sURLVariable);

			if ($sParameterName[0] === $sParam) {
				if ( ! isset( $sParameterName[1] ) ) {
					continue;
				}
				return urldecode($sParameterName[1]);
			}
		}

		return false;
	}

	public static function setFbp($fbp) {
		self::$fbp = $fbp;
	}

	public static function setFbc($fbc) {
		self::$fbc = $fbc;
	}
	/**
	 * The `_fbp` this request knows about.
	 *
	 * Read through pys_fb_cookie(), which hands `_fbp` over exactly as $_COOKIE
	 * holds it (PHP keeps the first of two copies) — no oldest-duplicate pick,
	 * no repair of a seconds timestamp, as in Meta's own library. What decides
	 * is pys_fbp_is_valid(), on the RAW value: an invalid cookie counts as
	 * absent, so the caller mints and overwrites it.
	 *
	 * Single choke point on purpose, so "must a value be produced" and "what
	 * goes into the event" cannot disagree. The static set by setFbp() still
	 * wins only when the request carries no usable cookie.
	 */
    static function getFbp() {
        $fbp = null;
        $resolved = pys_fb_cookie( '_fbp' );

        if ( '' !== $resolved && pys_fbp_is_valid( $resolved ) ) {
            $fbp = sanitize_text_field($resolved);
        }
		elseif (!empty(self::$fbp)){
			$fbp = self::$fbp;
		}

        return $fbp;
    }

	/**
	 * The `_fbc` this request knows about. See getFbp().
	 * Unlike `_fbp`, a value minted in this request wins over the cookie: it is
	 * only minted when the request carries a newer click than the stored one.
	 */
    static function getFbc() {
        $fbc = null;
        $resolved = pys_fb_cookie( '_fbc' );

        if (!empty(self::$fbc)){
	        $fbc = self::$fbc;
        }
        elseif ('' !== $resolved) {
            $fbc = sanitize_text_field($resolved);
        }

        return $fbc;
    }

	private static function getUserData( $wooOrder = null, $eddOrder = null ) {
		$userData = new UserData();

		/**
		 * Add purchase WooCommerce Advanced Matching params
		 */
		if ( PixelYourSite\isWooCommerceActive() && isEventEnabled( 'woo_purchase_enabled' ) && ( $wooOrder || ( PixelYourSite\PYS()->woo_is_order_received_page() && wooIsRequestContainOrderId() ) ) ) {
			if ( wooIsRequestContainOrderId() ) {
				$order_id = wooGetOrderIdFromRequest();
			} else {
				$order_id = $wooOrder;
			}

			$order = \wc_get_order( $order_id );

			if ( $order ) {
				if ( PixelYourSite\isWooCommerceVersionGte( '3.0.0' ) ) {

					$user_firstname = $order->get_billing_first_name();
					$user_lastname = $order->get_billing_last_name();
					$user_phone = $order->get_billing_phone();
					$user_email = $order->get_billing_email();

					if ( $order->get_billing_postcode() ) {
						$userData->setZipCode( $order->get_billing_postcode() );
					}
					if ( $order->get_billing_country() ) {
						$userData->setCountryCode( strtolower( $order->get_billing_country() ) );
					}

					if ( $order->get_billing_city() ) {
						$userData->setCity( $order->get_billing_city() );
					}

					if ( $order->get_billing_state() ) {
						$userData->setState( $order->get_billing_state() );
					}
					$external_ids = PixelYourSite\pys_get_order_external_ids( $order->get_meta( 'external_id' ), $order->get_user_id() );
					if ( !empty( $external_ids ) ) {
						$userData->setExternalIds( $external_ids );
					}
				} else {
					$user_firstname = $order->billing_first_name;
					$user_lastname = $order->billing_last_name;
					$user_phone = $order->billing_phone;
					$user_email = $order->billing_email;

					if ( $order->billing_postcode ) {
						$userData->setZipCode( $order->billing_postcode );
					}
					$userData->setCountryCode( strtolower( $order->billing_country ) );
					$userData->setCity( $order->billing_city );
					$userData->setState( $order->billing_state );
					$external_ids = PixelYourSite\pys_get_order_external_ids( get_post_meta( $order_id, 'external_id', true ), $order->get_user_id() );
					if ( !empty( $external_ids ) ) {
						$userData->setExternalIds( $external_ids );
					}
				}

				$user_persistence_data = get_persistence_user_data( $user_email, $user_firstname, $user_lastname, $user_phone );
				if ( !empty( $user_persistence_data[ 'fn' ] ) ) $userData->setFirstName( $user_persistence_data[ 'fn' ] );
				if ( !empty( $user_persistence_data[ 'ln' ] ) ) $userData->setLastName( $user_persistence_data[ 'ln' ] );
				if ( !empty( $user_persistence_data[ 'em' ] ) ) $userData->setEmail( $user_persistence_data[ 'em' ] );
				if ( !empty( $user_persistence_data[ 'tel' ] ) ) $userData->setPhone( $user_persistence_data[ 'tel' ] );

				$user_id = $order->get_user_id();
				if ( $user_id && apply_filters( 'pys_send_meta_id', true ) ) {
					$login_id = get_user_meta( $user_id, '_socplug_social_id_Facebook', true );
					if ( !empty( $login_id ) ) {
						$userData->setFbLoginId( $login_id );
					}
				}

			} else {
				return ServerEventHelper::getRegularUserData();
			}

		} else {

			if ( PixelYourSite\isEddActive() && isEventEnabled( 'edd_purchase_enabled' ) && ( $eddOrder || edd_is_success_page() ) ) {

				if ( $eddOrder ) $payment_id = $eddOrder; else {
					$payment_key = getEddPaymentKey();
					$payment_id = (int) edd_get_purchase_id_by_key( $payment_key );
				}
				
				// Check if payment_id is valid before proceeding
				if ( $payment_id > 0 ) {
					$user_info = edd_get_payment_meta_user_info( $payment_id );
					$email = edd_get_payment_user_email( $payment_id );

					$user_firstname = $user_lastname = $user_email = '';

					if ( isset($user_info[ 'first_name' ]) && $user_info[ 'first_name' ] ) {
						$user_firstname = $user_info[ 'first_name' ];
					}
					if ( isset($user_info[ 'last_name' ]) && $user_info[ 'last_name' ] ) {
						$user_lastname = $user_info[ 'last_name' ];
					}
					if ( $email ) {
						$user_email = $email;
					}

					$user_persistence_data = get_persistence_user_data( $user_email, $user_firstname, $user_lastname, '' );
					if ( !empty( $user_persistence_data[ 'fn' ] ) ) $userData->setFirstName( $user_persistence_data[ 'fn' ] );
					if ( !empty( $user_persistence_data[ 'ln' ] ) ) $userData->setLastName( $user_persistence_data[ 'ln' ] );
					if ( !empty( $user_persistence_data[ 'em' ] ) ) $userData->setEmail( $user_persistence_data[ 'em' ] );
					if ( !empty( $user_persistence_data[ 'tel' ] ) ) $userData->setPhone( $user_persistence_data[ 'tel' ] );

					// Browser id saved on the payment, plus the account that owns it
					$external_ids = PixelYourSite\pys_get_order_external_ids(
						edd_get_payment_meta( $payment_id, 'external_id', true ),
						isset( $user_info[ 'id' ] ) ? $user_info[ 'id' ] : 0
					);
					if ( !empty( $external_ids ) ) {
						$userData->setExternalIds( $external_ids );
					}

					// Check if user_info is valid and contains 'id' key
					if ( isset($user_info[ 'id' ]) && $user_info[ 'id' ] && apply_filters( 'pys_send_meta_id', true ) ) {
						$login_id = get_user_meta( $user_info[ 'id' ], '_socplug_social_id_Facebook', true );
						if ( !empty( $login_id ) ) {
							$userData->setFbLoginId( $login_id );
						}
					}
				} else {
					// If payment_id is invalid, fall back to regular user data
					return ServerEventHelper::getRegularUserData();
				}

			} else {
				return ServerEventHelper::getRegularUserData();
			}
		}

		return apply_filters( "pys_fb_server_user_data", $userData );
	}

	private static function getRegularUserData() {

		$user = wp_get_current_user();
		$userData = new UserData();
		if ( $user->ID ) {

			$user_firstname = $user->get( 'user_firstname' );
			$user_lastname = $user->get( 'user_lastname' );
			$user_phone = $user->get( 'billing_phone' );

			/**
			 * Add common WooCommerce Advanced Matching params
			 */
			if ( PixelYourSite\isWooCommerceActive() ) {
				// if first name is not set in regular wp user meta
				if ( empty( $user_firstname ) ) {
					$user_firstname = $user->get( 'billing_first_name' );
				}

				// if last name is not set in regular wp user meta
				if ( empty( $user_lastname ) ) {
					$user_lastname = $user->get( 'billing_last_name' );
				}

				if ( $user_phone ) $user_phone = $user->get( 'billing_phone' );
				if ( $user->get( 'billing_city' ) ) $userData->setCity( $user->get( 'billing_city' ) );
				if ( $user->get( 'billing_state' ) ) $userData->setState( $user->get( 'billing_state' ) );
				if ( $user->get( 'shipping_country' ) ) $userData->setCountryCode( strtolower( $user->get( 'shipping_country' ) ) );
				if ( $user->get( 'billing_postcode' ) ) {
					$userData->setZipCode( $user->get( 'billing_postcode' ) );
				}
			}
			$user_persistence_data = get_persistence_user_data( $user->get( 'user_email' ), $user_firstname, $user_lastname, $user_phone );

			$login_id = get_user_meta( $user->ID, '_socplug_social_id_Facebook', true );
			if ( !empty( $login_id ) && apply_filters( 'pys_send_meta_id', true ) ) {
				$userData->setFbLoginId( $login_id );
			}
		} else {
			$user_persistence_data = get_persistence_user_data( '', '', '', '' );
		}

		if ( !empty( $user_persistence_data[ 'fn' ] ) ) $userData->setFirstName( $user_persistence_data[ 'fn' ] );
		if ( !empty( $user_persistence_data[ 'ln' ] ) ) $userData->setLastName( $user_persistence_data[ 'ln' ] );
		if ( !empty( $user_persistence_data[ 'em' ] ) ) $userData->setEmail( $user_persistence_data[ 'em' ] );
		if ( !empty( $user_persistence_data[ 'tel' ] ) ) $userData->setPhone( $user_persistence_data[ 'tel' ] );

		$external_ids = PixelYourSite\pys_get_external_ids();
		if ( !empty( $external_ids ) ) {
			$userData->setExternalIds( $external_ids );
		}

		return apply_filters( "pys_fb_server_user_data", $userData );
	}

    static function paramsToCustomData($data, $singleEvent) {
        $wooOrder = isset($singleEvent->payload['woo_order']) ? $singleEvent->payload['woo_order'] : null;
        $eddOrder = isset($singleEvent->payload['edd_order']) ? $singleEvent->payload['edd_order'] : null;

        if(isset($data['contents']) && is_array($data['contents'])) {
            $contents = array();
            if(isset($data['contents']) && is_array($data['contents'])) {
                foreach ($data['contents'] as $c) {
                    if(isset($c['id']) && isset($c['quantity'])) {
                        $contents[] = new Content([
                            'product_id' => $c['id'],
                            'quantity' => $c['quantity']
                        ]);
                    }
                }
            }
            $data['contents'] = $contents;
        } else {
            $data['contents'] = array();
        }
        $customData = new CustomData($data);
        $customProperties = array();

        $isParentOrder = false;

        $getEnrichDataEvents = ['woo_start_trial',
            'woo_subscription_created',
            'woo_subscription_renewal',
            'woo_subscription_expired',
            'woo_subscription_canceled',
            'edd_start_trial',
            'edd_subscription_created',
            'edd_subscription_renewal',
            'edd_subscription_expired',
            'edd_subscription_canceled',
            'edd_license_created',
            'edd_license_upgrade',
            'edd_license_renewal',
            'edd_license_expired'];


        if(in_array($singleEvent->getId(), $getEnrichDataEvents) || (isset($data['advanced_purchase_tracking']) && !empty($data['advanced_purchase_tracking']))) {

            if(isset($data['advanced_purchase_tracking'])){
                $customProperties['advanced_purchase_tracking'] = $data['advanced_purchase_tracking'];
            }


            $enrichData = array();

            if ($wooOrder && PixelYourSite\isWooCommerceActive()) {
                $order = wc_get_order( $wooOrder );
                if(isWooUseHPStorage()) {
                    // WooCommerce >= 3.0
                    if($order) {
                        $enrichData = $order->get_meta( 'pys_enrich_data', true );
                    }
                } else {
                    // WooCommerce < 3.0
                    if(get_post_meta($wooOrder, "pys_enrich_data", true))
                    {
                        $enrichData = get_post_meta($wooOrder, "pys_enrich_data",true);
                    }
                }
            }
            if ($eddOrder && PixelYourSite\isEddActive()) {
                $payment      = new \EDD_Payment( $eddOrder );
                if(isset($payment) && $payment->get_meta()) {
                    $meta = $payment->get_meta();
                    if(isset($meta['pys_enrich_data'])) {
                        $enrichData = $meta['pys_enrich_data'];
                    }
                }
            }

            if (!empty($enrichData)) {
                $is_last_visit = PYS()->getOption('visit_data_model') === 'last_visit';

                if(PYS()->getOption( 'track_traffic_source' )) {
                    // Traffic source
                    if ($is_last_visit && isset($enrichData['last_pys_source'])) {
                        $customProperties['traffic_source'] = $enrichData['last_pys_source'];
                    } elseif (!$is_last_visit && isset($enrichData['pys_source'])) {
                        $customProperties['traffic_source'] = $enrichData['pys_source'];
                    }
                }
                if(PYS()->getOption( 'track_utms' )) {
                    // UTM parameters
                    if ($is_last_visit && isset($enrichData['last_pys_utm'])) {
                        $customProperties = array_merge($customProperties, parseUtmString($enrichData['last_pys_utm']));
                    } elseif (!$is_last_visit && isset($enrichData['pys_utm'])) {
                        $customProperties = array_merge($customProperties, parseUtmString($enrichData['pys_utm']));
                    }
                }
                if(PYS()->getOption( 'track_landing_page' )) {
                    // Landing page
                    if ($is_last_visit && isset($enrichData['last_pys_landing'])) {
                        $customProperties['landing_page'] = $enrichData['last_pys_landing'];
                    } elseif (!$is_last_visit && isset($enrichData['pys_landing'])) {
                        $customProperties['landing_page'] = $enrichData['pys_landing'];
                    }
                }

                // Browser time (same for both)
                if (isset($enrichData['pys_browser_time']) && !$isParentOrder) {
                    $customProperties = array_merge($customProperties, getUserTime($enrichData['pys_browser_time']));
                }
            }
        }
        else {
            if(PYS()->getOption( 'track_traffic_source' ))
                $customProperties['traffic_source'] = getTrafficSource(PYS()->getOption('visit_data_model') === "last_visit");

            if(PYS()->getOption( 'track_utms' )) {
                $customProperties = array_merge($customProperties,getUtms(false, PYS()->getOption('visit_data_model') === "last_visit"));
            }
        }

        if(isset($data['category_name'])) {
            $customData->setContentCategory($data['category_name']);
        }

        $custom_values = ['event_action','download_type','download_name','download_url','target_url','text','trigger','traffic_source','plugin','user_role','event_url','event_time', 'event_hour','event_day','event_month','page_title',"post_type",'post_id','categories','tags','video_type',
            'video_id','video_title','event_trigger','link_type','tag_text',"URL",
            'form_id','form_class','form_submit_label','transactions_count','average_order',
            'shipping_cost','tax','total','shipping','coupon_used','post_category','landing_page',
        'number_of_transactions', 'subscription_value', 'subscription_name', 'license_name',
            'subscription_id', 'license_id'];


        $adding_custom_field = array();
        $eventsCustom = EventsCustom()->getEvents();
        foreach ($eventsCustom as $event)
        {
            $fbCustomEvents = $event->getFacebookCustomParams();

            foreach ($fbCustomEvents as $paramKey => $params)
            {
                if(!in_array($params['name'], $custom_values) && !in_array($params['name'], $customData->attributeMap()))
                {
                    $adding_custom_field[] = $params['name'];
                }
            }
        }


        $result_custom_values = array_merge($custom_values, $adding_custom_field);

        foreach ($result_custom_values as $val) {
            if(isset($data[$val])){
                $customProperties[$val] = $data[$val];
            }
        }
        //get filter value
        $custom_filter_data_event = apply_filters('pys_event_data',array(),$singleEvent->getCategory(),[
            'event_id'=>$singleEvent->getId(),
            'pixel'=>Facebook()->getSlug()
        ]);

        if(isset($custom_filter_data_event['params']) && !empty($custom_filter_data_event['params'])) {
            foreach ($custom_filter_data_event['params'] as $key => $value) {
                $customProperties[$key] = $value;
            }
        }

        $customData->setCustomProperties($customProperties);
        return $customData;
    }

    /**
     * Explicitly require Facebook ServerSide SDK class files.
     *
     * PHP's unserialize() may produce __PHP_Incomplete_Class objects when the
     * Composer autoloader hasn't resolved these classes yet (background HTTP
     * requests, cron context, OPCache timing issues, plugin conflicts, etc.).
     * Calling this method before any unserialize() that involves these classes
     * eliminates the race condition.
     */
    public static function requireServerSideClasses() {
        $base  = PYS_PATH . '/vendor_prefix/facebook/php-business-sdk/src/FacebookAds/Object/ServerSide/';
        $files = [ 'Event.php', 'UserData.php', 'CustomData.php', 'Content.php' ];
        foreach ( $files as $file ) {
            $path = $base . $file;
            if ( file_exists( $path ) ) {
                require_once $path;
            }
        }
        // After Event.php: it extends it, and queued events unserialize into it.
        require_once __DIR__ . '/PysServerEvent.php';
    }

}