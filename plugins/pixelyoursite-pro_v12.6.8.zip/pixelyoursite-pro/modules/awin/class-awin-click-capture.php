<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Keeps the Awin click on the server.
 *
 * The MasterTag stores the click in a cookie written by JavaScript, which
 * browsers cut short. Awin asks for a first-party cookie set by the server
 * (HttpOnly, Secure), written on landing and kept with the order.
 */
class AwinClickCapture {

	const COOKIE_CLICK     = 'awc';
	const COOKIE_INCENTIVE = 'awc_sn';
	const COOKIE_SOURCE    = 'awin_source';

	const CLICK_DAYS  = 365;
	const SOURCE_DAYS = 30;

	const ORDER_META = '_pys_awin_click';

	const CLICK_PATTERN  = '/^\d{1,6}_\d{10}_[0-9a-f]{1,64}$/i';
	const SOURCE_PATTERN = '/^[a-z0-9_-]{1,50}$/';

	/** @var string[] Cookies written by the current captureFrom() run. */
	private $written = array();

	public function __construct() {
		// Front-end pages only, before any output.
		add_action( 'template_redirect', array( $this, 'capture' ), 1 );

		// Consent given on the landing page itself, after it was served.
		add_action( 'wp_ajax_pys_awin_click', array( $this, 'ajaxCapture' ) );
		add_action( 'wp_ajax_nopriv_pys_awin_click', array( $this, 'ajaxCapture' ) );

		add_action( 'woocommerce_checkout_order_created', array( $this, 'storeOnWooOrder' ) );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'storeOnWooOrder' ) );
		add_action( 'edd_built_order', array( $this, 'storeOnEddOrder' ) );
	}

	public static function isValidClick( $value ) {
		return is_string( $value ) && preg_match( self::CLICK_PATTERN, $value ) === 1;
	}

	/**
	 * Records the click from the landing URL, or keeps the MasterTag's own
	 * cookie on the server once the visitor has consented.
	 */
	public function capture() {

		if ( Awin()->isExcludedPage() ) {
			return;
		}

		$this->captureFrom( wp_unslash( $_GET ) );
	}

	/**
	 * The landing page's awc / source / sn, posted by the browser once the
	 * visitor has consented there. The cookies go out as response headers,
	 * which is what Awin asks for; values are validated exactly as on landing.
	 */
	public function ajaxCapture() {

		$query = array();

		foreach ( array( 'awc', 'source', 'sn' ) as $key ) {
			if ( isset( $_POST[ $key ] ) && is_scalar( $_POST[ $key ] ) ) {
				$query[ $key ] = (string) wp_unslash( $_POST[ $key ] );
			}
		}

		wp_send_json_success( array( 'stored' => $this->captureFrom( $query ) ) );
	}

	/**
	 * @param array $query awc, source and sn as found in the landing URL.
	 * @return string[] Names of the cookies written.
	 */
	public function captureFrom( array $query ) {

		$awin    = Awin();
		$written = array();

		if ( !$awin->configured() || headers_sent() ) {
			return $written;
		}

		$this->written = array();

		$mid       = $awin->getAdvertiserId();
		$consent   = Consent()->hasExplicitConsent( 'awin' );
		$incentive = isset( $query[ 'sn' ] ) && '1' === (string) $query[ 'sn' ];
		$click     = isset( $query[ 'awc' ] ) ? $this->clickFromQuery( $query[ 'awc' ] ) : '';

		if ( $click !== '' ) {
			// A cashback click is strictly necessary; any other needs consent.
			if ( $incentive ) {
				$this->setCookie( self::COOKIE_INCENTIVE, $click, self::CLICK_DAYS );
			} elseif ( $consent ) {
				$this->setCookie( self::COOKIE_CLICK, $click, self::CLICK_DAYS );
			}
		}

		// The MasterTag wrote its cookie after consent on an earlier page.
		if ( $consent ) {
			$this->mirror( '_aw_m_' . $mid, self::COOKIE_CLICK );
		}
		$this->mirror( '_aw_sn_' . $mid, self::COOKIE_INCENTIVE );

		$source = '';

		if ( $click !== '' ) {
			// An Awin click is the last click: Awin requires channel "aw".
			$source = 'aw';
		} elseif ( isset( $query[ 'source' ] ) && is_scalar( $query[ 'source' ] ) ) {
			$candidate = strtolower( trim( (string) $query[ 'source' ] ) );
			$source    = preg_match( self::SOURCE_PATTERN, $candidate ) ? $candidate : '';
		}

		if ( $source !== '' && ( $consent || $incentive ) && $awin->getOption( 'source_param_enabled' ) ) {
			$this->setCookie( self::COOKIE_SOURCE, $source, self::SOURCE_DAYS );
		}

		return $this->written;
	}

	/**
	 * The click as it stands on this request.
	 *
	 * @param bool $consent
	 * @return array{awc: string, awc_sn: string, source: string}
	 */
	public function current( $consent ) {

		$mid = Awin()->getAdvertiserId();

		$click = $this->cookie( self::COOKIE_CLICK );
		if ( $click === '' ) {
			$click = $this->cookie( '_aw_m_' . $mid );
		}

		$incentive = $this->cookie( self::COOKIE_INCENTIVE );
		if ( $incentive === '' ) {
			$incentive = $this->cookie( '_aw_sn_' . $mid );
		}

		$source = isset( $_COOKIE[ self::COOKIE_SOURCE ] ) ? strtolower( (string) wp_unslash( $_COOKIE[ self::COOKIE_SOURCE ] ) ) : '';

		return array(
			'awc'    => $consent ? $click : '',
			'awc_sn' => $incentive,
			'source' => preg_match( self::SOURCE_PATTERN, $source ) ? $source : '',
		);
	}

	/**
	 * @param int|\WC_Order $order
	 */
	public function storeOnWooOrder( $order ) {

		$order = $order instanceof \WC_Order ? $order : wc_get_order( $order );

		if ( !$order instanceof \WC_Order || !Awin()->configured() ) {
			return;
		}

		$click = $this->forOrder();

		if ( null !== $click ) {
			$order->update_meta_data( self::ORDER_META, $click );
			AwinWooOrder::saveMeta( $order );
		}
	}

	/**
	 * @param int $order_id
	 */
	public function storeOnEddOrder( $order_id ) {

		if ( !Awin()->configured() || !function_exists( 'edd_update_order_meta' ) ) {
			return;
		}

		$click = $this->forOrder();

		if ( null !== $click ) {
			edd_update_order_meta( (int) $order_id, self::ORDER_META, $click );
		}
	}

	/**
	 * What to keep with an order placed now, or null when there is no click.
	 *
	 * @return array|null
	 */
	private function forOrder() {

		$click = $this->current( Consent()->hasExplicitConsent( 'awin' ) );

		if ( $click[ 'awc' ] === '' && $click[ 'awc_sn' ] === '' && $click[ 'source' ] === '' ) {
			return null;
		}

		return $click + array(
			'advertiserId' => Awin()->getAdvertiserId(),
			'capturedAt'   => time(),
		);
	}

	/**
	 * The newest valid click in the awc parameter. Awin may send several.
	 *
	 * @param mixed $raw
	 * @return string
	 */
	private function clickFromQuery( $raw ) {

		$best = '';
		$time = 0;

		foreach ( preg_split( '/[,\s]+/', is_scalar( $raw ) ? (string) $raw : '' ) as $candidate ) {
			if ( self::isValidClick( $candidate ) ) {
				$parts = explode( '_', $candidate );

				if ( (int) $parts[ 1 ] >= $time ) {
					$time = (int) $parts[ 1 ];
					$best = $candidate;
				}
			}
		}

		return $best;
	}

	/**
	 * Copy a MasterTag cookie into its server-side twin.
	 */
	private function mirror( $from, $to ) {

		$value = $this->cookie( $from );

		if ( $value !== '' && $value !== $this->cookie( $to ) ) {
			$this->setCookie( $to, $value, self::CLICK_DAYS );
		}
	}

	/**
	 * A valid click from a cookie, or ''.
	 */
	private function cookie( $name ) {
		$value = isset( $_COOKIE[ $name ] ) ? (string) wp_unslash( $_COOKIE[ $name ] ) : '';

		return self::isValidClick( $value ) ? $value : '';
	}

	private function setCookie( $name, $value, $days ) {

		$options = array(
			'expires'  => time() + $days * DAY_IN_SECONDS,
			'path'     => '/',
			'domain'   => function_exists( __NAMESPACE__ . '\pys_cookie_domain' ) ? pys_cookie_domain() : '',
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		);

		$options = (array) apply_filters( 'pys_awin_cookie_options', $options, $name );

		setcookie( $name, $value, $options );

		$this->written[] = $name;

		// The rest of this request sees it too.
		$_COOKIE[ $name ] = $value;
	}
}
