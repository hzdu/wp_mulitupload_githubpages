<?php
/**
 * Copyright © 2019-2026 Rhubarb Tech Inc. All Rights Reserved.
 *
 * The Object Cache Pro Software and its related materials are property and confidential
 * information of Rhubarb Tech Inc. Any reproduction, use, distribution, or exploitation
 * of the Object Cache Pro Software and its related materials, in whole or in part,
 * is strictly forbidden unless prior permission is obtained from Rhubarb Tech Inc.
 *
 * In addition, any reproduction, use, distribution, or exploitation of the Object Cache Pro
 * Software and its related materials, in whole or in part, is subject to the End-User License
 * Agreement accessible in the included `LICENSE` file, or at: https://objectcache.pro/eula
 */

declare(strict_types=1);

namespace RedisCachePro\Plugin;

use WP_Error;
use Throwable;

use Relay\Relay;

use RedisCachePro\Plugin;
use RedisCachePro\License;
use RedisCachePro\Diagnostics\Diagnostics;
use RedisCachePro\ObjectCaches\ObjectCache;

use function RedisCachePro\log;

/**
 * @mixin \RedisCachePro\Plugin
 */
trait Licensing
{
    /**
     * Boot licensing component.
     *
     * @return void
     */
    public function bootLicensing()
    {
        add_action('admin_notices', [$this, 'displayLicenseNotices'], -1);
        add_action('network_admin_notices', [$this, 'displayLicenseNotices'], -1);

        if (is_admin() || (defined('WP_CLI') && WP_CLI)) {
            $this->storeRelayLicense();
        }
    }

    /**
     * Return the license configured token.
     *
     * @return string|void
     */
    public function token()
    {
        if (defined('WP_REDIS_CONFIG') && isset(\WP_REDIS_CONFIG['token'])) {
            return \WP_REDIS_CONFIG['token'];
        }

        return 'offline-token-0eaaea766b40-placeholder';
    }

    /**
     * Display admin notices when license is unpaid/canceled,
     * and when no license token is set.
     *
     * @return void
     */
    public function displayLicenseNotices()
    {
        return;
    }

    /**
     * Returns the license object.
     *
     * Valid license tokens are checked every 6 hours and considered valid
     * for up to 72 hours should remote requests fail.
     *
     * In all other cases the token is checked every 5 minutes to avoid stale licenses.
     *
     * @param  bool  $readOnly
     * @return \RedisCachePro\License|null
     */
    public function license($readOnly = false)
    {
        static $license = null;

        if ($license) {
            return $license;
        }

        $loaded = License::load();

        if ($readOnly) {
            return $loaded;
        }

        $license = $loaded;

        // if no license is stored or the token has changed, always attempt to fetch it
        if (! $license instanceof License || $license->token() !== $this->token()) {
            $response = $this->fetchLicense();

            if (is_wp_error($response)) {
                $license = License::fromError($response);
            } else {
                $license = License::fromResponse($response);
            }

            return $license;
        }

        // deauthorize valid licenses that could not be re-verified within 72h
        if ($license->isValid() && $license->hoursSinceVerification(72)) {
            // only deauthorize if the machine wasn't asleep for 72 hours
            if (! $license->hoursSinceLastCheck(72)) {
                $license->deauthorize();

                return $license;
            }
        }

        // verify valid licenses every 6 (or 24 for hosts) hours and
        // attempt to verify invalid licenses every 20 minutes
        if ($license->needsReverification()) {
            $response = $this->fetchLicense();

            if (is_wp_error($response)) {
                $license = $license->checkFailed($response);
            } else {
                $license = License::fromResponse($response);
            }
        }

        return $license;
    }

    /**
     * Fetch the license for configured token.
     *
     * @return \RedisCachePro\Support\PluginApiLicenseResponse|\WP_Error
     */
    protected function fetchLicense()
    {
        $response = $this->request('license');

        if (is_wp_error($response)) {
            return new WP_Error($response->get_error_code(), sprintf(
                'Could not verify license: %s',
                $response->get_error_message()
            ), array_merge(
                ['token' => $this->token()],
                $response->get_error_data() ?? []
            ));
        }

        /** @var \RedisCachePro\Support\PluginApiLicenseResponse $response */
        return $response;
    }

    /**
     * Attempt to store Relay's license so it can be displayed.
     *
     * @return void
     */
    public function storeRelayLicense()
    {
        if (! extension_loaded('relay')) {
            return;
        }

        $runtime = Relay::license();
        $stored = get_site_option('objectcache_relay_license');

        $storeRuntimeLicense = function () use ($runtime) {
            update_site_option('objectcache_relay_license', [
                'state' => $runtime['state'],
                'reason' => $runtime['reason'],
                'raw' => array_diff_key($runtime, ['last-response' => null]),
                'last' => $runtime['last-response'],
                'updated_at' => time(),
            ]);
        };

        if (! is_array($stored)) {
            $storeRuntimeLicense();

            return;
        }

        if ($runtime['state'] === 'licensed') {
            // update invalid licenses instantly
            if ($stored['state'] !== 'licensed') {
                $storeRuntimeLicense();
            }

            // update valid licenses every hour
            if ($stored['state'] === 'licensed' && $stored['updated_at'] < (time() - 3600)) {
                $storeRuntimeLicense();
            }

            return;
        }

        if ($stored['state'] === 'licensed') {
            // invalidate stored licenses
            if (in_array($runtime['state'], ['unlicensed', 'suspended'])) {
                $storeRuntimeLicense();
            }

            // force update stored license every day
            if ($stored['updated_at'] < (time() - 86400)) {
                $storeRuntimeLicense();
            }

            return;
        }

        // avoid `unknown` license state
        if ($stored['state'] === 'unknown' && $runtime['state'] !== 'unknown') {
            $storeRuntimeLicense();

            return;
        }

        // update stored license every hour
        if ($stored['updated_at'] < (time() - 3600)) {
            $storeRuntimeLicense();
        }
    }

    /**
     * Perform API request.
     *
     * @param  string  $action
     * @return \RedisCachePro\Support\PluginApiResponse|\WP_Error
     */
    protected function request($action)
    {
        return (object) [
            'success' => true,
            'state' => 'valid',
            'token' => $this->token(),
            'plan' => 'B5',
            'stability' => 'stable',
            'organization' => null,
            'license' => null,
            'version' => null,
            'package' => null,
            'wp' => null,
            'php' => null,
        ];
    }

    /**
     * Performs a `plugin/info` request and returns the result.
     *
     * @return \RedisCachePro\Support\PluginApiInfoResponse|\WP_Error
     */
    public function pluginInfoRequest()
    {
        $response = $this->request('plugin/info');

        if (is_wp_error($response)) {
            return $response;
        }

        /** @var \RedisCachePro\Support\PluginApiInfoResponse $response */
        return $response;
    }

    /**
     * Performs a `plugin/update` request and returns the result.
     *
     * @return \RedisCachePro\Support\PluginApiUpdateResponse|\WP_Error
     */
    public function pluginUpdateRequest()
    {
        $response = $this->request('plugin/update');

        if (is_wp_error($response)) {
            $update = (object) (get_site_transient('objectcache_update') ?: []);

            set_site_transient('objectcache_update', (object) [
                'version' => $update->version ?? null,
                'last_check' => time(),
                'payload' => $update->payload ?? null,
            ], DAY_IN_SECONDS);

            return $response;
        }

        /** @var \RedisCachePro\Support\PluginApiUpdateResponse $response */
        $payload = ($encoded = json_encode($response)) ? base64_encode($encoded) : null;

        set_site_transient('objectcache_update', (object) [
            'version' => $response->version,
            'last_check' => time(),
            'payload' => $payload,
        ], DAY_IN_SECONDS);

        if ($response->license) {
            $current = $this->license(true);
            $tokenChanged = $current && $current->token() !== $this->token();

            if (! $current || $tokenChanged || ! $current->isValid()) {
                License::fromResponse($response->license);
            }
        }

        return $response;
    }

    /**
     * The telemetry sent along with requests.
     *
     * @return array<string, mixed>
     */
    public function telemetry()
    {
        return [];
    }

    /**
     * Normalizes the metrics snapshot.
     *
     * @return array<string, int|float|null>
     */
    protected function normalizedMetricsSnapshot()
    {
        return array_filter(
            get_site_option('objectcache_snapshot') ?: [],
            function ($value, $key) {
                return strpos((string) $key, '_') === false
                    && (is_null($value) || is_numeric($value));
            },
            ARRAY_FILTER_USE_BOTH
        );
    }

    /**
     * Some hosting partners want the plugin removed when their customer moves away.
     *
     * @param  \RedisCachePro\License|null  $license
     * @return void
     */
    protected function killSwitch(?License $license)
    {
        return;
    }

    /**
     * Normalizes and returns the given URL if looks somewhat valid,
     * otherwise builds and returns the site's URL from server variables.
     *
     * @param  string  $url
     * @return string|void
     */
    public static function normalizeUrl($url)
    {
        $scheme = is_ssl() ? 'https' : 'http';
        $forwardedHosts = explode(',', $_SERVER['HTTP_X_FORWARDED_HOST'] ?? '');
        $forwardedHost = trim(end($forwardedHosts)) ?: '';
        $httpHost = trim($_SERVER['HTTP_HOST'] ?? '');
        $serverName = trim($_SERVER['SERVER_NAME'] ?? '');

        foreach ([
            $url,
            get_option('home'),
            get_option('siteurl'),
            get_site_option('home'),
            get_site_option('siteurl'),
            $forwardedHost,
            $httpHost,
            $serverName,
        ] as $thing) {
            $thing = urldecode(urldecode((string) $thing));
            $thing = rtrim(trim($thing), '/\\');

            if (self::isLooselyValidUrl($thing)) {
                return $thing;
            }

            if (preg_match('~^:?//~', $thing)) {
                $urlWithScheme = preg_replace('~^:?//(.+)~', 'http://$1', $url);

                if (self::isLooselyValidUrl($urlWithScheme)) {
                    return $urlWithScheme;
                }
            }

            if (! preg_match('~^https?://~', $thing)) {
                $urlWithPrefix = "{$scheme}://{$thing}";

                if (self::isLooselyValidUrl($urlWithPrefix)) {
                    return $urlWithPrefix;
                }
            }
        }

        log('warning', sprintf(
            'Unable to normalize URL (url=%s; scheme=%s; host=%s; server=%s; forwarded=%s)',
            $url,
            $scheme,
            $httpHost,
            $serverName,
            $forwardedHost
        ));
    }

    /**
     * Whether the given string looks somewhat like a URL.
     *
     * @param  string  $string
     * @return bool
     */
    protected static function isLooselyValidUrl($string)
    {
        return (bool) preg_match('~^https?://[^\s/$.?#].[^\s]*$~i', $string);
    }
}
