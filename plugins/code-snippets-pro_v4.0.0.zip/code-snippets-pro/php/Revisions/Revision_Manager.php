<?php
/**
 * Manages snippet revision lifecycle: CPT registration, creation, retrieval, cleanup.
 *
 * @package Code_Snippets
 */

namespace Code_Snippets\Revisions;

use Code_Snippets\Model\Snippet;
use WP_Post;
use WP_Query;
use function Code_Snippets\code_snippets;
use function Code_Snippets\get_snippet;
use function Code_Snippets\save_snippet;
use function Code_Snippets\Settings\get_setting;
use function Code_Snippets\Utils\get_self_option;
use function Code_Snippets\Utils\validate_network_param;
use function Code_Snippets\Utils\update_self_option;

/**
 * Handles snippet revision storage using a hidden CPT.
 */
class Revision_Manager {

	/**
	 * The custom post type slug for revisions.
	 */
	const POST_TYPE = 'snippet_revision';

	/**
	 * Meta key for the snippet ID this revision belongs to.
	 */
	const META_SNIPPET_ID = '_snippet_id';

	/**
	 * Meta key for the network flag.
	 */
	const META_NETWORK = '_snippet_network';

	/**
	 * Meta key for the sequential revision number.
	 */
	const META_REVISION_NUMBER = '_revision_number';

	/**
	 * Option key for per-snippet versioning toggle.
	 */
	const OPTION_DISABLED = 'code_snippets_revisions_disabled';

	/**
	 * Per-request revision choice override, set by the REST controller.
	 *
	 * @var string|null 'delete', 'keep', or null (use settings).
	 */
	private ?string $request_revision_choice = null;

	/**
	 * Initialize hooks.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_post_type' ] );
		add_action( 'code_snippets/create_snippet', [ $this, 'on_snippet_created' ], 10, 2 );
		add_action( 'code_snippets/update_snippet', [ $this, 'on_snippet_saved' ], 10, 2 );
		add_action( 'code_snippets/delete_snippet', [ $this, 'on_snippet_deleted' ], 10, 2 );
	}

	/**
	 * Register the hidden snippet_revision CPT.
	 *
	 * @return void
	 */
	public function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			[
				'public'       => false,
				'show_ui'      => false,
				'show_in_rest' => false,
				'supports'     => [ 'author' ],
				'labels'       => [ 'name' => __( 'Snippet Revisions', 'code-snippets' ) ],
			]
		);
	}

	/**
	 * Set a per-request revision choice override.
	 *
	 * @param string|null $choice 'delete', 'keep', or null to clear.
	 */
	public function set_request_revision_choice( ?string $choice ): void {
		$this->request_revision_choice = $choice;
	}

	/**
	 * Check whether revisions are globally enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return self::get_max_revisions() > 0;
	}

	/**
	 * Get the maximum number of revisions to keep per snippet.
	 *
	 * @return int
	 */
	public static function get_max_revisions(): int {
		$max = get_setting( 'general', 'max_revisions' );
		return null === $max ? 10 : (int) $max;
	}

	/**
	 * Check whether versioning is disabled for a specific snippet.
	 *
	 * @param int       $snippet_id Snippet ID.
	 * @param bool|null $network    Whether the snippet is network-wide.
	 *
	 * @return bool
	 */
	public static function is_snippet_versioning_disabled( int $snippet_id, ?bool $network = null ): bool {
		$network = validate_network_param( $network );
		$disabled = get_self_option( $network, self::OPTION_DISABLED, [] );

		return isset( $disabled[ $snippet_id ] ) && $disabled[ $snippet_id ];
	}

	/**
	 * Set whether versioning is disabled for a specific snippet.
	 *
	 * @param int       $snippet_id Snippet ID.
	 * @param bool      $disabled   Whether versioning should be disabled.
	 * @param bool|null $network    Whether the snippet is network-wide.
	 *
	 * @return void
	 */
	public static function set_snippet_versioning_disabled( int $snippet_id, bool $disabled, ?bool $network = null ): void {
		$network = validate_network_param( $network );
		$option = get_self_option( $network, self::OPTION_DISABLED, [] );

		if ( $disabled ) {
			$option[ $snippet_id ] = true;
		} else {
			unset( $option[ $snippet_id ] );
		}

		update_self_option( $network, self::OPTION_DISABLED, $option );
	}

	/**
	 * Build a JSON snapshot of a snippet's current state.
	 *
	 * @param Snippet $snippet The snippet to snapshot.
	 *
	 * @return array<string, mixed>
	 */
	public static function build_snapshot( Snippet $snippet ): array {
		return [
			'name'         => $snippet->name,
			'desc'         => $snippet->desc,
			'code'         => $snippet->code,
			'tags'         => $snippet->tags,
			'scope'        => $snippet->scope,
			'priority'     => $snippet->priority,
			'condition_id' => $snippet->condition_id,
			'active'       => $snippet->active,
		];
	}

	/**
	 * Compare two snapshots, ignoring activation state.
	 *
	 * Switching a snippet on or off changes nothing a revision could usefully
	 * preserve, and activation is never restored, so a toggle should not push a
	 * revision into the history.
	 *
	 * @param array<string, mixed> $first  Snapshot to compare.
	 * @param array<string, mixed> $second Snapshot to compare against.
	 *
	 * @return bool Whether the two hold the same versioned content.
	 */
	private static function is_same_content( array $first, array $second ): bool {
		unset( $first['active'], $second['active'] );
		return $first === $second;
	}

	/**
	 * Hook: After a snippet is created, record its initial state.
	 *
	 * The code a snippet starts life with is only ever stored here, so that the
	 * first edit has something to go back to.
	 *
	 * @param Snippet $snippet The new snippet.
	 * @param string  $table   The table name (unused but part of hook signature).
	 *
	 * @return void
	 */
	public function on_snippet_created( Snippet $snippet, string $table ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by the hook signature.
		$this->record_revision( $snippet );
	}

	/**
	 * Hook: After a snippet is saved, record the state it was saved in.
	 *
	 * @param Snippet $snippet The saved snippet.
	 * @param string  $table   The table name (unused but part of hook signature).
	 *
	 * @return void
	 */
	public function on_snippet_saved( Snippet $snippet, string $table ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by the hook signature.
		$this->record_revision( $snippet );
	}

	/**
	 * Store the snippet's current state as a revision.
	 *
	 * As in WordPress core, each save records the state it produced: the newest
	 * revision mirrors the live snippet, and every version the snippet has held
	 * — including the one a restore puts back — stays in the history.
	 *
	 * @param Snippet $snippet The snippet as it now stands.
	 *
	 * @return void
	 */
	private function record_revision( Snippet $snippet ): void {
		if ( ! $snippet->id || ! self::is_enabled() ) {
			return;
		}

		if ( self::is_snippet_versioning_disabled( $snippet->id, $snippet->network ) ) {
			return;
		}

		$max = self::get_max_revisions();
		if ( $max <= 0 ) {
			return;
		}

		$snapshot = self::build_snapshot( $snippet );

		// Skip if identical to most recent revision.
		$latest = $this->get_latest_revision( $snippet->id, $snippet->network );
		if ( $latest ) {
			$latest_snapshot = json_decode( $latest->post_content, true );
			if ( is_array( $latest_snapshot ) && self::is_same_content( $latest_snapshot, $snapshot ) ) {
				return;
			}
		}

		$this->create_revision( $snippet->id, $snippet->network, $snapshot );
		$this->enforce_fifo_limit( $snippet->id, $snippet->network, $max );
	}

	/**
	 * Create a new revision post for a snippet.
	 *
	 * @param int                  $snippet_id Snippet ID.
	 * @param bool|null            $network    Whether the snippet is network-wide.
	 * @param array<string, mixed> $snapshot   The snapshot data.
	 *
	 * @return int|false The revision post ID, or false on failure.
	 */
	public function create_revision( int $snippet_id, ?bool $network, array $snapshot ) {
		$network = validate_network_param( $network );
		$next_number = $this->get_next_revision_number( $snippet_id, $network );

		// wp_insert_post() runs wp_unslash() on its arguments, which would strip the
		// backslashes from JSON escapes (turning "\n" into a literal "n" before it
		// reaches the database). Pre-slash the encoded JSON so the unslash cancels out.
		$post_id = wp_insert_post(
			[
				'post_type'    => self::POST_TYPE,
				'post_status'  => 'publish',
				'post_content' => wp_slash( wp_json_encode( $snapshot ) ),
				'post_author'  => get_current_user_id(),
				'meta_input'   => [
					self::META_SNIPPET_ID     => $snippet_id,
					self::META_NETWORK        => $network ? 1 : 0,
					self::META_REVISION_NUMBER => $next_number,
				],
			],
			true
		);

		return is_wp_error( $post_id ) ? false : $post_id;
	}

	/**
	 * Retrieve the latest revision post for a snippet.
	 *
	 * @param int       $snippet_id Snippet ID.
	 * @param bool|null $network    Whether the snippet is network-wide.
	 *
	 * @return WP_Post|null
	 */
	public function get_latest_revision( int $snippet_id, ?bool $network = null ): ?WP_Post {
		$revisions = $this->get_revisions( $snippet_id, $network, 1 );
		return $revisions[0] ?? null;
	}

	/**
	 * Retrieve revisions for a snippet.
	 *
	 * @param int       $snippet_id Snippet ID.
	 * @param bool|null $network    Whether the snippet is network-wide.
	 * @param int       $limit      Max number of revisions to return. -1 for all.
	 *
	 * @return WP_Post[]
	 */
	public function get_revisions( int $snippet_id, ?bool $network = null, int $limit = -1 ): array {
		$network = validate_network_param( $network );

		$query = new WP_Query(
			[
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => $limit,
				'orderby'        => 'ID',
				'order'          => 'DESC',
				'no_found_rows'  => true,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Revisions are scoped by snippet ID and network, which are only stored in post meta.
				'meta_query'     => [
					'relation' => 'AND',
					[
						'key'     => self::META_SNIPPET_ID,
						'value'   => $snippet_id,
						'compare' => '=',
						'type'    => 'NUMERIC',
					],
					[
						'key'     => self::META_NETWORK,
						'value'   => $network ? 1 : 0,
						'compare' => '=',
						'type'    => 'NUMERIC',
					],
				],
			]
		);

		return $query->posts;
	}

	/**
	 * Whether a revision belongs to a given snippet, in a given scope.
	 *
	 * Both halves matter. Snippet IDs are only unique within their own table, so
	 * a site snippet and a network snippet can share an ID — matching on the ID
	 * alone would let a site-scoped request reach a network snippet's revision,
	 * and restore it over the site snippet that happens to share that ID.
	 *
	 * @param int       $revision_id The revision post ID.
	 * @param int       $snippet_id  Snippet the revision must belong to.
	 * @param bool|null $network     Scope the revision must belong to.
	 *
	 * @return bool
	 */
	private function revision_belongs_to( int $revision_id, int $snippet_id, ?bool $network ): bool {
		$revision_snippet_id = (int) get_post_meta( $revision_id, self::META_SNIPPET_ID, true );
		$revision_network = (bool) (int) get_post_meta( $revision_id, self::META_NETWORK, true );
		$expected_network = (bool) validate_network_param( $network );

		return $revision_snippet_id === $snippet_id && $revision_network === $expected_network;
	}

	/**
	 * Retrieve a single revision belonging to a specific snippet and scope.
	 *
	 * @param int       $revision_id The revision post ID.
	 * @param int       $snippet_id  Snippet the revision must belong to.
	 * @param bool|null $network     Whether the snippet is network-wide.
	 *
	 * @return WP_Post|null Null when the revision is missing, is not a revision,
	 *                      or belongs to a different snippet or scope.
	 */
	public function get_revision( int $revision_id, int $snippet_id, ?bool $network = null ): ?WP_Post {
		$post = get_post( $revision_id );

		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return null;
		}

		if ( ! $this->revision_belongs_to( $revision_id, $snippet_id, $network ) ) {
			return null;
		}

		return $post;
	}

	/**
	 * Get the count of revisions for a snippet.
	 *
	 * @param int       $snippet_id Snippet ID.
	 * @param bool|null $network    Whether the snippet is network-wide.
	 *
	 * @return int
	 */
	public function get_revision_count( int $snippet_id, ?bool $network = null ): int {
		$network = validate_network_param( $network );

		$query = new WP_Query(
			[
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Revisions are scoped by snippet ID and network, which are only stored in post meta.
				'meta_query'     => [
					'relation' => 'AND',
					[
						'key'     => self::META_SNIPPET_ID,
						'value'   => $snippet_id,
						'compare' => '=',
						'type'    => 'NUMERIC',
					],
					[
						'key'     => self::META_NETWORK,
						'value'   => $network ? 1 : 0,
						'compare' => '=',
						'type'    => 'NUMERIC',
					],
				],
			]
		);

		return $query->found_posts;
	}

	/**
	 * Get the next sequential revision number for a snippet.
	 *
	 * @param int       $snippet_id Snippet ID.
	 * @param bool|null $network    Whether the snippet is network-wide.
	 *
	 * @return int
	 */
	private function get_next_revision_number( int $snippet_id, ?bool $network ): int {
		$latest = $this->get_latest_revision( $snippet_id, $network );

		if ( ! $latest ) {
			return 1;
		}

		$current = (int) get_post_meta( $latest->ID, self::META_REVISION_NUMBER, true );
		return $current + 1;
	}

	/**
	 * Enforce the FIFO revision limit: delete oldest revisions when over the max.
	 *
	 * @param int       $snippet_id Snippet ID.
	 * @param bool|null $network    Whether the snippet is network-wide.
	 * @param int       $max        Maximum number of revisions to keep.
	 *
	 * @return void
	 */
	private function enforce_fifo_limit( int $snippet_id, ?bool $network, int $max ): void {
		$network = validate_network_param( $network );

		$query = new WP_Query(
			[
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'fields'         => 'ids',
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Revisions are scoped by snippet ID and network, which are only stored in post meta.
				'meta_query'     => [
					'relation' => 'AND',
					[
						'key'     => self::META_SNIPPET_ID,
						'value'   => $snippet_id,
						'compare' => '=',
						'type'    => 'NUMERIC',
					],
					[
						'key'     => self::META_NETWORK,
						'value'   => $network ? 1 : 0,
						'compare' => '=',
						'type'    => 'NUMERIC',
					],
				],
			]
		);

		$ids = $query->posts;
		$total = count( $ids );

		if ( $total <= $max ) {
			return;
		}

		$to_delete = array_slice( $ids, 0, $total - $max );
		foreach ( $to_delete as $post_id ) {
			wp_delete_post( $post_id, true );
		}
	}

	/**
	 * Restore a snippet from a revision.
	 *
	 * Creates a backup revision of the current state, then applies the selected revision.
	 *
	 * @param int       $snippet_id  The snippet ID.
	 * @param int       $revision_id The revision post ID to restore.
	 * @param bool|null $network     Whether the snippet is network-wide.
	 *
	 * @return Snippet|null The restored snippet, or null on failure.
	 */
	public function restore_revision( int $snippet_id, int $revision_id, ?bool $network = null ): ?Snippet {
		$network = validate_network_param( $network );

		// Scope-checked: null here also covers a revision from another snippet
		// or from the other side of the site/network divide.
		$revision = $this->get_revision( $revision_id, $snippet_id, $network );

		if ( ! $revision ) {
			return null;
		}

		$snippet = get_snippet( $snippet_id, $network );

		if ( ! $snippet || ! $snippet->id ) {
			return null;
		}

		$snapshot = json_decode( $revision->post_content, true );

		if ( ! is_array( $snapshot ) ) {
			return null;
		}

		// Apply revision data to the snippet.
		foreach ( $snapshot as $field => $value ) {
			// Activation is deliberately not restored. Restoring a snapshot taken
			// while the snippet was active would otherwise switch it on — running
			// the restored code immediately — and a snapshot taken while inactive
			// would switch a live snippet off. Neither is shown in the restore
			// preview, so both would happen silently. Whether a snippet runs stays
			// under the activation toggle alone.
			if ( 'active' === $field ) {
				continue;
			}

			$snippet->set_field( $field, $value );
		}

		return save_snippet( $snippet );
	}

	/**
	 * Hook: After a snippet is permanently deleted, optionally purge revisions.
	 *
	 * @param Snippet   $snippet The deleted snippet.
	 * @param bool|null $network Whether the snippet is network-wide.
	 *
	 * @return void
	 */
	public function on_snippet_deleted( Snippet $snippet, ?bool $network ): void {
		// Per-request override takes priority (set by REST controller).
		$choice = $this->request_revision_choice;
		$this->request_revision_choice = null;

		if ( null === $choice ) {
			// Fall back to the persistent user preference.
			$choice = get_setting( 'general', 'delete_revision_default' );
		}

		if ( 'keep' === $choice ) {
			return;
		}

		if ( 'delete' === $choice ) {
			$this->purge_revisions( $snippet->id, $network );
			return;
		}

		// Fall back to preserve_on_delete global setting.
		$preserve = get_setting( 'general', 'preserve_on_delete' );
		if ( $preserve ) {
			return;
		}

		$this->purge_revisions( $snippet->id, $network );
	}

	/**
	 * Delete a single revision by its post ID.
	 *
	 * @param int       $revision_id The revision post ID.
	 * @param int       $snippet_id  The snippet ID this revision must belong to.
	 * @param bool|null $network     Whether the snippet is network-wide.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function delete_revision( int $revision_id, int $snippet_id, ?bool $network ): bool {
		if ( ! $this->get_revision( $revision_id, $snippet_id, $network ) ) {
			return false;
		}

		return (bool) wp_delete_post( $revision_id, true );
	}

	/**
	 * Permanently delete all revisions for a snippet.
	 *
	 * @param int       $snippet_id Snippet ID.
	 * @param bool|null $network    Whether the snippet is network-wide.
	 *
	 * @return int Number of revisions deleted.
	 */
	public function purge_revisions( int $snippet_id, ?bool $network = null ): int {
		$revisions = $this->get_revisions( $snippet_id, $network );
		$count = 0;

		foreach ( $revisions as $revision ) {
			if ( wp_delete_post( $revision->ID, true ) ) {
				++$count;
			}
		}

		return $count;
	}
}
