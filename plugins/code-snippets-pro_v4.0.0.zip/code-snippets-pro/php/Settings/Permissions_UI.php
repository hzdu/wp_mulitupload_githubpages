<?php

namespace Code_Snippets\Settings;

use function get_editable_roles;

/**
 * Renders the role-based permissions settings UI.
 *
 * @package Code_Snippets\Settings
 */
class Permissions_UI {

	/**
	 * Capability levels.
	 *
	 * @var array<string, string>
	 */
	private static array $capability_levels = [
		'none' => 'No access',
		'view' => 'View only',
		'edit' => 'Create & Edit',
		'full' => 'Full access (Create, Edit, Delete)',
	];

	/**
	 * Sanitize the posted role-capabilities settings.
	 *
	 * @param mixed $input Raw posted value: role_id => [ 'level' => string ].
	 *
	 * @return array<string, array<string, string>>
	 */
	public static function sanitize_role_capabilities( $input ): array {
		$result = [];

		if ( ! is_array( $input ) ) {
			return $result;
		}

		foreach ( $input as $role_id => $config ) {
			$level = is_array( $config ) && isset( $config['level'] ) ? sanitize_key( $config['level'] ) : 'none';

			if ( ! isset( self::$capability_levels[ $level ] ) ) {
				$level = 'none';
			}

			$result[ sanitize_key( $role_id ) ] = [ 'level' => $level ];
		}

		return $result;
	}

	/**
	 * Render the role permissions settings field.
	 *
	 * @return void
	 */
	public static function render_role_permissions(): void {
		$settings = get_settings_values();
		$current_settings = $settings['permissions']['role_capabilities'] ?? [];
		$editable_roles = get_editable_roles();

		if ( empty( $editable_roles ) ) {
			echo '<p>' . esc_html__( 'No editable roles found.', 'code-snippets' ) . '</p>';
			return;
		}

		?>
		<div class="code-snippets-permissions-table">
			<table>
				<thead>
					<tr>
						<th><?php esc_html_e( 'Role', 'code-snippets' ); ?></th>
						<th><?php esc_html_e( 'Capability Level', 'code-snippets' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $editable_roles as $role_id => $role_data ) : ?>
						<?php
						$level = $current_settings[ $role_id ]['level'] ?? 'none';
						?>
						<tr>
							<td class="role-name">
								<strong><?php echo esc_html( $role_data['name'] ); ?></strong>
							</td>
							<td class="capability-level">
								<select
									name="code_snippets_settings[permissions][role_capabilities][<?php echo esc_attr( $role_id ); ?>][level]"
									aria-label="<?php /* translators: %s: role name */ echo esc_attr( sprintf( __( 'Capability level for %s', 'code-snippets' ), $role_data['name'] ) ); ?>"
								>
									<?php foreach ( self::$capability_levels as $level_key => $level_label ) : ?>
										<option value="<?php echo esc_attr( $level_key ); ?>"
											<?php selected( $level, $level_key ); ?>>
											<?php echo esc_html( $level_label ); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="code-snippets-permissions-warning">
				<strong><?php esc_html_e( 'Note:', 'code-snippets' ); ?></strong>
				<?php esc_html_e( 'Snippets can run PHP and JavaScript. Granting a role Create or Edit access lets its users execute code on your site — only grant this to roles you trust.', 'code-snippets' ); ?>
			</p>
		</div>
		<style>
			/* Break this data table out of the two-column form-table layout so it
			   spans the full width, left-aligned like the other settings tabs.
			   Scope to the form-table's own cells only — not the nested data
			   table inside the td. */
			.permissions-settings .form-table > tbody > tr > th {
				display: none;
			}

			.permissions-settings .form-table > tbody > tr > td {
				padding-inline-start: 0;
			}

			.code-snippets-permissions-table table {
				width: auto;
				border-collapse: collapse;
				margin-top: 0;
			}

			.code-snippets-permissions-table th,
			.code-snippets-permissions-table td {
				padding: 0.75rem;
				text-align: left;
				border-bottom: 1px solid #ddd;
			}

			.code-snippets-permissions-table th {
				background-color: #f5f5f5;
				font-weight: 600;
			}

			.code-snippets-permissions-table .role-name {
				min-width: 120px;
			}

			.code-snippets-permissions-table .capability-level select {
				min-width: 220px;
			}

			.code-snippets-permissions-warning {
				max-inline-size: 640px;
				margin-block-start: 1rem;
				color: #50575e;
			}
		</style>
		<?php
	}
}
