<?php

namespace Code_Snippets;

use Code_Snippets\Admin\Bootstrap_Admin;
use Code_Snippets\Admin\Feedback_Error_Capture;
use Code_Snippets\Admin\Feedback_Panel;
use Code_Snippets\Admin\Menus\Manage\Manage_Menu;
use Code_Snippets\Client\Cloud_Error_Reporter;
use Code_Snippets\Client\Cloud_Sync_Notifier;
use Code_Snippets\Client\Feedback_Client;
use Code_Snippets\Controller\Cloud_Library_Controller;
use Code_Snippets\Controller\Cloud_Search_Controller;
use Code_Snippets\Controller\Cloud_Auth_Controller;
use Code_Snippets\Core\DB;
use Code_Snippets\Core\Licensing;
use Code_Snippets\Core\Upgrader;
use Code_Snippets\Integration\Active_Snippets_Tracker;
use Code_Snippets\Integration\Admin_Bar;
use Code_Snippets\Integration\Snippet_Performance_Tracker;
use Code_Snippets\Integration\Block_Editor;
use Code_Snippets\Integration\Classic_Editor\MCE_Plugin;
use Code_Snippets\Integration\Command;
use Code_Snippets\Integration\Elementor\Elementor;
use Code_Snippets\Integration\Evaluate_Assets;
use Code_Snippets\Integration\Evaluate_Content;
use Code_Snippets\Integration\Evaluate_Functions;
use Code_Snippets\Integration\Promotions\Promotion_Manager;
use Code_Snippets\Integration\Shortcodes;
use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\Model\Feedback_Connection;
use Code_Snippets\Integration\Snippet_Security_Scanner;
use Code_Snippets\REST_API\Cloud\Cloud_AI_Agent_REST_Controller;
use Code_Snippets\REST_API\Cloud\Cloud_AI_REST_Controller;
use Code_Snippets\REST_API\Cloud\Cloud_Auth_REST_Controller;
use Code_Snippets\REST_API\Cloud\Cloud_Bundles_REST_Controller;
use Code_Snippets\REST_API\Cloud\Cloud_Catalogue_REST_Controller;
use Code_Snippets\REST_API\Cloud\Cloud_License_REST_Controller;
use Code_Snippets\REST_API\Cloud\Cloud_Plugin_REST_Controller;
use Code_Snippets\REST_API\Cloud\Cloud_Public_Bundles_REST_Controller;
use Code_Snippets\REST_API\Cloud\Cloud_Snippets_REST_Controller;
use Code_Snippets\REST_API\Feedback\Feedback_REST_Controller;
use Code_Snippets\REST_API\Import\File_Import_REST_Controller;
use Code_Snippets\REST_API\Import\Plugins_Import_REST_Controller;
use Code_Snippets\REST_API\Preferences\Demos_Seen_REST_Controller;
use Code_Snippets\REST_API\Preferences\Stats_View_Rest_Controller;
use Code_Snippets\REST_API\Preferences\Snippet_View_REST_Controller;
use Code_Snippets\REST_API\Snippets\Conditions_REST_Controller;
use Code_Snippets\REST_API\Snippets\Recently_Active_REST_Controller;
use Code_Snippets\REST_API\Snippets\Revisions_REST_Controller;
use Code_Snippets\REST_API\Snippets\Snippets_REST_Controller;
use Code_Snippets\Revisions\Revision_Manager;
use function Code_Snippets\Settings\are_settings_unified;

/**
 * The main plugin class
 *
 * @package Code_Snippets
 */
class Plugin {

	/**
	 * Current plugin version number
	 *
	 * @deprecated Use the PLUGIN_VERSION constant instead.
	 *
	 * @var string
	 */
	public string $version = PLUGIN_VERSION;

	/**
	 * Filesystem path to the main plugin file
	 *
	 * @deprecated Use the PLUGIN_FILE constant instead.
	 *
	 * @var string
	 */
	public string $file = PLUGIN_FILE;

	/**
	 * Database class
	 *
	 * @var DB
	 */
	public DB $db;

	/**
	 * Class for evaluating style and script snippets.
	 *
	 * @var Evaluate_Assets
	 */
	public Evaluate_Assets $evaluate_assets;

	/**
	 * Class for managing shortcodes.
	 *
	 * @var Shortcodes
	 */
	public Shortcodes $shortcodes;

	/**
	 * Administration area class
	 *
	 * @var Bootstrap_Admin
	 */
	public Bootstrap_Admin $admin;

	/**
	 * Handles licensing and plugin updates.
	 *
	 * @var Licensing
	 */
	public Licensing $licensing;

	/**
	 * Records which snippets ran on the current request.
	 *
	 * @var Active_Snippets_Tracker
	 */
	public Active_Snippets_Tracker $active_snippets_tracker;

	/**
	 * Handles snippet handler registration.
	 *
	 * @var Flat_Files\Handler_Registry
	 */
	public Flat_Files\Handler_Registry $snippet_handler_registry;

	/**
	 * Instance of connection to Code Snippets Cloud.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	public Authenticated_Cloud_Connection $cloud_connection;

	/**
	 * Class for creating a connetion to Code Snippets Cloud.
	 *
	 * @var Cloud_Auth_Controller
	 */
	public Cloud_Auth_Controller $cloud_auth;

	/**
	 * Manages snippet revision history.
	 *
	 * @var Revision_Manager
	 */
	public Revision_Manager $revision_manager;

	/**
	 * Class constructor
	 */
	public function __construct() {
		wp_cache_add_global_groups( CACHE_GROUP );
		add_action( 'allowed_redirect_hosts', [ $this, 'allow_code_snippets_redirect' ] );
	}

	/**
	 * Load the plugin utilities.
	 */
	private function load_utilities() {
		require_once __DIR__ . '/Utils/editor.php';
		require_once __DIR__ . '/Utils/options.php';
		require_once __DIR__ . '/Settings/settings.php';
		require_once __DIR__ . '/conditions.php';
		require_once __DIR__ . '/snippet-ops.php';
	}

	/**
	 * Initialize the plugin and load all necessary classes.
	 */
	public function load_plugin() {
		$this->load_utilities();

		Settings\Permissions::register();

		$this->db = new DB();
		$this->licensing = new Licensing();
		$this->active_snippets_tracker = new Active_Snippets_Tracker();

		$this->cloud_connection = new Authenticated_Cloud_Connection();
		$this->cloud_auth = new Cloud_Auth_Controller( $this->cloud_connection, $this->get_menu_url( 'settings' ) );
		( new Cloud_Sync_Notifier( $this->cloud_connection ) )->init();
		( new Cloud_Error_Reporter( $this->cloud_connection ) )->init();

		new Evaluate_Content( $this->db );
		new Evaluate_Functions( $this->db );

		$this->evaluate_assets = new Evaluate_Assets( $this->db );
		$this->shortcodes = new Shortcodes();

		if ( is_admin() ) {
			$this->admin = new Bootstrap_Admin( $this->cloud_auth );
			new Promotion_Manager();
			new Feedback_Error_Capture( new Feedback_Panel() );
		}

		if ( class_exists( 'WP_CLI_Command' ) ) {
			Command::register();
		}

		new Elementor();
		new MCE_Plugin();
		new Block_Editor();
		new Condition_Lifecycle_Handler();

		// Reset persisted timing stats when a snippet's code changes —
		// historic timings become meaningless once the body is different.
		add_action(
			'code_snippets/update_snippet',
			static function ( $updated ): void {
				if ( is_object( $updated ) && ! empty( $updated->id ) ) {
					Snippet_Performance_Tracker::reset( (int) $updated->id );
				}
			},
			10,
			1
		);

		new Shortcodes();
		new MCE_Plugin();
		$this->revision_manager = new Revision_Manager();
		new Revisions_REST_Controller( $this->revision_manager );

		new Upgrader( PLUGIN_VERSION, $this->db );
		new Admin_Bar();

		// Re-scan a snippet's body on save when the setting is on.
		// Runs only on save (advisory, no per-page-render overhead).
		// Findings stored as a single WP option, keyed by snippet ID,
		// with each finding's `dismissed` flag preserved across re-scans
		// when the user has already triaged it.
		add_action(
			'code_snippets/update_snippet',
			static function ( $updated ): void {
				if ( ! is_object( $updated ) || empty( $updated->id ) || 'php' !== $updated->type ) {
					return;
				}
				if ( ! (bool) Settings\get_setting( 'general', 'enable_security_scan' ) ) {
					return;
				}

				Snippet_Security_Scanner::update_for_snippet( (int) $updated->id, (string) ( $updated->code ?? '' ) );
			},
			20,
			1
		);

		new Admin\Insights_Actions();

		$this->init_snippet_files();

		add_action( 'rest_api_init', [ $this, 'init_rest_api' ], 1 );
	}

	/**
	 * Retrieve singleton instance of cloud library controller.
	 *
	 * This controller is initialised only when necessary as it loads a large amount of data when constructed.
	 *
	 * @return Cloud_Library_Controller
	 */
	public function get_cloud_library(): Cloud_Library_Controller {
		static $controller = null;

		if ( ! isset( $controller ) ) {
			$controller = new Cloud_Library_Controller( $this->cloud_connection );
		}

		return $controller;
	}

	/**
	 * Load REST API controller classes when serving REST API requests.
	 *
	 * @return void
	 */
	public function init_rest_api() {
		$cloud_library = $this->get_cloud_library();
		$cloud_search = new Cloud_Search_Controller( $this->cloud_connection, $cloud_library );

		new Snippets_REST_Controller( $cloud_library );
		new Recently_Active_REST_Controller();
		new Conditions_REST_Controller();

		new Snippet_View_REST_Controller();
		new Stats_View_Rest_Controller();
		new Demos_Seen_REST_Controller();

		new Plugins_Import_REST_Controller();
		new File_Import_REST_Controller();

		new Cloud_AI_REST_Controller( $this->cloud_connection );
		new Cloud_AI_Agent_REST_Controller( $this->cloud_connection );
		new Cloud_Auth_REST_Controller( $this->cloud_auth );
		new Cloud_Snippets_REST_Controller( $cloud_search, $cloud_library );
		new Cloud_Bundles_REST_Controller( $this->cloud_connection );
		new Cloud_Public_Bundles_REST_Controller( $this->cloud_connection );
		new Cloud_Catalogue_REST_Controller( $this->cloud_connection );
		new Cloud_Plugin_REST_Controller( $this->cloud_connection );
		new Cloud_License_REST_Controller( $this->cloud_connection );

		new Feedback_REST_Controller( new Feedback_Client( new Feedback_Connection() ) );
	}

	/**
	 * Initializes the snippet files component.
	 *
	 * @return void
	 */
	private function init_snippet_files() {
		$this->snippet_handler_registry = new Flat_Files\Handler_Registry(
			[
				'php'  => new Flat_Files\Handlers\Functions_Snippet_Handler(),
				'html' => new Flat_Files\Handlers\Content_Snippet_Handler(),
				'css'  => new Flat_Files\Handlers\Styles_Snippet_Handler(),
				'js'   => new Flat_Files\Handlers\Scripts_Snippet_Handler(),
				'cond' => new Flat_Files\Handlers\Conditions_Snippet_Handler(),
			]
		);

		$fs = new Flat_Files\WP_Filesystem_Adapter();
		$config_repo = new Flat_Files\Flat_File_Config_Repository( $fs );

		$snippet_files = new Flat_Files\Snippet_Files( $this->snippet_handler_registry, $fs, $config_repo );
		$snippet_files->register_hooks();
	}

	/**
	 * Determine whether the menu is full or compact.
	 *
	 * @return bool
	 */
	public function is_compact_menu(): bool {
		return ! is_network_admin() && apply_filters( 'code_snippets_compact_menu', false );
	}

	/**
	 * Fetch the admin menu slug for a menu.
	 *
	 * @param string $menu Name of menu to retrieve the slug for.
	 *
	 * @return string The menu's slug.
	 */
	public function get_menu_slug( string $menu = '' ): string {
		$add = [ 'single', 'add', 'add-new', 'add-snippet', 'new-snippet', 'add-new-snippet' ];
		$edit = [ 'edit', 'edit-snippet' ];
		$import = [ 'import', 'import-snippets', 'import-code-snippets' ];
		$settings = [ 'settings', 'snippets-settings' ];
		$cloud = [ 'cloud', 'cloud-snippets' ];
		$stats = [ 'stats', 'code-snippets-stats' ];
		$welcome = [ 'welcome', 'getting-started', 'code-snippets' ];

		if ( in_array( $menu, $edit, true ) ) {
			return 'edit-snippet';
		} elseif ( in_array( $menu, $add, true ) ) {
			return 'add-snippet';
		} elseif ( in_array( $menu, $import, true ) ) {
			return 'import-code-snippets';
		} elseif ( in_array( $menu, $settings, true ) ) {
			return 'snippets-settings';
		} elseif ( in_array( $menu, $cloud, true ) ) {
			return 'snippets&subpage=cloud-community';
		} elseif ( in_array( $menu, $stats, true ) ) {
			return 'code-snippets-stats';
		} elseif ( in_array( $menu, $welcome, true ) ) {
			return 'code-snippets-welcome';
		} else {
			return 'snippets';
		}
	}

	/**
	 * Fetch the URL to a snippets admin menu.
	 *
	 * @param string $menu    Name of menu to retrieve the URL to.
	 * @param string $context URL scheme to use.
	 *
	 * @return string The menu's URL.
	 */
	public function get_menu_url( string $menu = '', string $context = 'self' ): string {
		$slug = $this->get_menu_slug( $menu );

		if ( $this->is_compact_menu() && 'network' !== $context ) {
			$base_slug = $this->get_menu_slug();
			$url = 'tools.php?page=' . $base_slug;

			if ( $slug !== $base_slug ) {
				$url .= '&sub=' . $slug;
			}
		} else {
			$url = 'admin.php?page=' . $slug;
		}

		if ( 'snippets-settings' === $slug && are_settings_unified() ) {
			return network_admin_url( $url );
		}

		switch ( $context ) {
			case 'network':
				return network_admin_url( $url );

			case 'admin':
				return admin_url( $url );

			default:
				return self_admin_url( $url );
		}
	}

	/**
	 * Allow redirecting to the Code Snippets site.
	 *
	 * @param string[] $hosts Allowed hosts.
	 *
	 * @return array Modified allowed hosts.
	 */
	public function allow_code_snippets_redirect( array $hosts ): array {
		$hosts[] = 'codesnippets.pro';
		$hosts[] = 'snipco.de';
		return $hosts;
	}

	/**
	 * Determine whether the current user can perform actions on snippets.
	 *
	 * @return bool Whether the current user has the required capability.
	 *
	 * @since 2.8.6
	 */
	public function current_user_can(): bool {
		return current_user_can( $this->get_cap() );
	}

	/**
	 * Retrieve the name of the capability required to manage sub-site snippets.
	 *
	 * @return string
	 */
	public function get_cap_name(): string {
		return apply_filters( 'code_snippets_cap', Settings\Permissions::ACCESS_CAP );
	}

	/**
	 * Retrieve the name of the capability required to manage network snippets.
	 *
	 * @return string
	 */
	public function get_network_cap_name(): string {
		return apply_filters( 'code_snippets_network_cap', 'manage_network_options' );
	}

	/**
	 * Determine if a subsite user menu is enabled via *Network Settings > Enable administration menus*.
	 *
	 * @return bool
	 */
	public function is_subsite_menu_enabled(): bool {
		if ( ! is_multisite() ) {
			return true;
		}

		$menu_perms = get_site_option( 'menu_items', array() );
		return ! empty( $menu_perms['snippets'] );
	}

	/**
	 * Determine if the current user should have the network snippets capability.
	 *
	 * @return bool
	 */
	public function user_can_manage_network_snippets(): bool {
		return is_super_admin() || current_user_can( $this->get_network_cap_name() );
	}

	/**
	 * Get the required capability to perform a certain action on snippets.
	 * Does not check if the user has this capability or not.
	 *
	 * If multisite, adjusts the capability based on whether the user is viewing
	 * the network dashboard or a subsite and whether the menu is enabled for subsites.
	 *
	 * @return string The capability required to manage snippets.
	 *
	 * @since 2.0
	 */
	public function get_cap(): string {
		return is_multisite() && ( is_network_admin() || ! $this->is_subsite_menu_enabled() )
			? $this->get_network_cap_name()
			: $this->get_cap_name();
	}

	/**
	 * Localize a plugin script to provide the CODE_SNIPPETS object.
	 *
	 * @param string $handle Script handle.
	 *
	 * @return void
	 */
	public function localize_script( string $handle ) {
		wp_localize_script(
			$handle,
			'CODE_SNIPPETS',
			[
				'debug'              => defined( 'WP_DEBUG' ) && WP_DEBUG,
				'isLicensed'         => $this->licensing->is_licensed(),
				'isCloudConnected'   => $this->cloud_connection->is_authenticated(),
				'hideUpsell'         => Settings\get_setting( 'general', 'hide_upgrade_menu' ),
				'snippetView'        => Snippet_View_REST_Controller::get_snippet_view(),
				'statsChartViews'    => Stats_View_Rest_Controller::get_stats_chart_views(),
				'demosSeen'          => Demos_Seen_REST_Controller::get_demos_seen(),
				'restAPI'            => [
					'base'           => esc_url_raw( rest_url() ),
					'snippets'       => esc_url_raw( rest_url( Snippets_REST_Controller::get_base_route() ) ),
					'recentlyActive' => esc_url_raw( rest_url( Recently_Active_REST_Controller::get_base_route() ) ),
					'conditions'     => esc_url_raw( rest_url( Conditions_REST_Controller::get_base_route() ) ),
					'snippetView'    => esc_url_raw( rest_url( Snippet_View_REST_Controller::get_base_route() ) ),
					'statsView'      => esc_url_raw( rest_url( Stats_View_Rest_Controller::get_base_route() ) ),
					'demosSeen'      => esc_url_raw( rest_url( Demos_Seen_REST_Controller::get_base_route() ) ),
					'importPlugins'  => esc_url_raw( rest_url( Plugins_Import_REST_Controller::get_base_route() ) ),
					'importFiles'    => esc_url_raw( rest_url( File_Import_REST_Controller::get_base_route() ) ),
					'nonce'          => wp_create_nonce( 'wp_rest' ),
					'cloud'          => [
						'token'            => $this->cloud_connection->get_local_token(),
						'snippets'         => esc_url_raw( rest_url( Cloud_Snippets_REST_Controller::get_base_route() ) ),
						'bundles'          => esc_url_raw( rest_url( Cloud_Bundles_REST_Controller::get_base_route() ) ),
						'communityBundles' => esc_url_raw( rest_url( Cloud_Public_Bundles_REST_Controller::get_base_route() ) ),
						'auth'             => esc_url_raw( rest_url( Cloud_Auth_REST_Controller::get_base_route() ) ),
						'ai'               => esc_url_raw( rest_url( Cloud_AI_REST_Controller::get_base_route() ) ),
						'aiAgent'          => esc_url_raw( rest_url( Cloud_AI_Agent_REST_Controller::get_base_route() ) ),
					],
					'revisions'      => esc_url_raw( rest_url( Revisions_REST_Controller::get_base_route() ) ),
				],
				'urls'               => [
					'plugin'       => esc_url_raw( plugins_url( '', PLUGIN_FILE ) ),
					'manage'       => esc_url_raw( $this->get_menu_url() ),
					'edit'         => esc_url_raw( $this->get_menu_url( 'edit' ) ),
					'addNew'       => esc_url_raw( $this->get_menu_url( 'add' ) ),
					'stats'        => esc_url_raw( $this->get_menu_url( 'stats' ) ),
					'welcome'      => esc_url_raw( $this->get_menu_url( 'welcome' ) ),
					'import'       => esc_url_raw( $this->get_menu_url( 'import' ) ),
					'cloud'        => esc_url_raw( $this->cloud_connection->get_base_url() ),
					'connectCloud' => esc_url_raw( $this->cloud_auth->get_connect_cloud_url() ),
					'resetCloud'   => esc_url_raw( $this->cloud_auth->get_reset_cloud_url() ),
					'demoReset'    => esc_url_raw( Manage_Menu::get_demo_reset_url() ),
					'settings'     => ! are_settings_unified() || is_super_admin()
						? esc_url_raw( $this->get_menu_url( 'settings' ) )
						: null,
				],
			]
		);
	}
}
