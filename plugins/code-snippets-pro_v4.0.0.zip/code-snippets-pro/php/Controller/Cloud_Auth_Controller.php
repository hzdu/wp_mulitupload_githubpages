<?php

namespace Code_Snippets\Controller;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use WP_Error;
use WP_REST_Request;
use function Code_Snippets\code_snippets;

/**
 * Class for handling the connection between this site and Code Snippets Cloud.
 */
class Cloud_Auth_Controller {

	/**
	 * Action name for the nonce required to create a cloud connection.
	 */
	private const CLOUD_ACTION_NONCE = 'connect_code_snippets_cloud';

	/**
	 * Cloud connection instance.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * URL to admin page where cloud connection can be initiated.
	 *
	 * @var string
	 */
	private string $admin_page_url;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection     Connection to Code Snippets Cloud.
	 * @param string                         $admin_page_url URL to admin page where cloud connection can be initiated.
	 *
	 * @return void
	 */
	public function __construct( Authenticated_Cloud_Connection $connection, string $admin_page_url ) {
		$this->connection = $connection;
		$this->admin_page_url = $admin_page_url;

		add_action( 'plugins_loaded', [ $this, 'init_oauth_sync' ] );
		add_filter( 'allowed_redirect_hosts', [ $this, 'allow_cloud_redirects' ] );
	}

	/**
	 * Determine whether the cloud connection has been set-up.
	 *
	 * @return bool
	 */
	public function is_authenticated(): bool {
		return $this->connection->is_authenticated();
	}

	/**
	 * Verify a REST API request is authorised to access controller functions.
	 *
	 * @param WP_REST_Request $request The REST API request.
	 *
	 * @return bool
	 */
	public function verify_rest_request( WP_REST_Request $request ): bool {
		return $this->connection->verify_rest_request( $request );
	}

	/**
	 * Normalise a generated password by removing special characters
	 *
	 * @param string $password Original generated password.
	 *
	 * @return string Sanitised password.
	 */
	private static function sanitise_generated_password( string $password ): string {
		return str_replace( '=', '', strtr( $password, '+/', '-_' ) );
	}

	/**
	 * Initialise data for OAuth Cloud Connect.
	 *
	 * @return void
	 *
	 * @uses wp_generate_password() – must be loaded after pluggable functions.
	 */
	public function init_oauth_sync() {
		// Bail early if the cloud key is already verified or if code verifier is already set.
		if ( $this->connection->is_cloud_key_verified() || $this->connection->get_code_verifier() ) {
			return;
		}

		$code_verifier = self::sanitise_generated_password( wp_generate_password( 128, false ) );

		$code_challenge = self::sanitise_generated_password(
			base64_encode( hash( 'sha256', $code_verifier, true ) ) // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		);

		$state = (string) wp_generate_password( 15, false ) ?? '';
		$local_token = (string) wp_generate_password( 30, false ) ?? '';

		$this->connection->set_local_token(
			[
				'code_verifier'  => $code_verifier,
				'code_challenge' => $code_challenge,
				'state'          => $state,
				'local_token'    => $local_token,
			]
		);
	}

	/**
	 * Generate a URL for initiating a new cloud connection.
	 *
	 * @return string
	 */
	public function get_connect_cloud_url(): string {
		return add_query_arg(
			[
				'connect-authorise-cloud' => true,
				'_wpnonce'                => wp_create_nonce( self::CLOUD_ACTION_NONCE ),
			],
			$this->admin_page_url
		);
	}

	/**
	 * Generate a URL for resetting the current cloud connection.
	 *
	 * @return string
	 */
	public function get_reset_cloud_url(): string {
		return add_query_arg(
			[
				'reset-cloud' => true,
				'_wpnonce'    => wp_create_nonce( self::CLOUD_ACTION_NONCE ),
			],
			$this->admin_page_url
		);
	}

	/**
	 * Filter the list of allowed redirect hosts to include the Cloud site.
	 *
	 * @param string[] $allowed_hosts List of allowed redirect hosts.
	 *
	 * @return string[] Modified list of allowed redirect hosts.
	 */
	public function allow_cloud_redirects( array $allowed_hosts ): array {
		$api_url = wp_parse_url( $this->connection->get_base_url() );
		$allowed_hosts[] = $api_url['host'];
		return $allowed_hosts;
	}

	/**
	 * Initialise the process for connecting to Cloud.
	 *
	 * Use verify_connection_nonce() or similar validation before calling this function.
	 *
	 * @return void
	 */
	public function init_cloud_connection() {
		$callback_url = add_query_arg( [ 'confirm-authorise-cloud' => true ], code_snippets()->get_menu_url( 'settings' ) );

		$url = add_query_arg(
			[
				'response_type'  => 'code',
				'client_id'      => $this->connection->get_client_id(),
				'code_challenge' => $this->connection->get_code_challenge(),
				'state'          => $this->connection->get_current_state(),
				'callback_url'   => esc_url_raw( $callback_url ),
			],
			sprintf( '%s/oauth/login', $this->connection->get_base_url() )
		);

		wp_safe_redirect( esc_url_raw( $url ) );
		exit;
	}

	/**
	 * Clear connection to cloud.
	 *
	 * @return void
	 */
	public function reset_connection() {
		$this->connection->reset();
	}

	/**
	 * Verify that a request to connect to or disconnect from cloud is genuine.
	 *
	 * @param string|null $nonce_value Value of nonce to verify, or null if nonce has already been verified.
	 *
	 * @return bool
	 */
	public function verify_action_nonce( string $nonce_value ): bool {
		return wp_verify_nonce( $nonce_value, self::CLOUD_ACTION_NONCE );
	}

	/**
	 * Exchange the auth code for a bearer token.
	 *
	 * @param string $state     Received state.
	 * @param string $auth_code Authorisation code.
	 *
	 * @return WP_Error|null Error on failure, null on success.
	 */
	public function decode_auth_code( string $state, string $auth_code ): ?WP_Error {
		if ( $this->connection->get_current_state() !== $state ) {
			return new WP_Error(
				'snippets_cloud_invalid_state',
				__( 'Did not receive a valid state from Code Snippets Cloud. Please try again.', 'code-snippets' )
			);
		}

		$response = wp_remote_post(
			sprintf( '%s/auth/token', $this->connection->get_api_url() ),
			[
				'method'  => 'POST',
				'headers' => [
					'Accept'                      => 'application/json',
					'Local-Token'                 => $this->connection->get_local_token(),
					'Access-Control-Allow-Origin' => '*',
				],
				'body'    => [
					'code'          => $auth_code,
					'client_id'     => $this->connection->get_client_id(),
					'grant_type'    => 'authorization_code',
					'code_verifier' => $this->connection->get_code_verifier(),
				],
			]
		);

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		// Check the response codes and return accordingly.
		if ( 401 === wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error(
				'snippets_cloud_invalid_token',
				esc_html__( 'That token is invalid – please check and try again.', 'code-snippets' )
			);
		}

		if ( empty( $data['token'] ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error(
				'snippets_cloud_connection_error',
				esc_html__( 'There was an error connecting to the cloud platform. Please try again later.', 'code-snippets' )
			);
		}

		// Save the token in code snippets cloud settings.
		$this->connection->set_verified_cloud_token( $data['token'] );
		return null;
	}
}
