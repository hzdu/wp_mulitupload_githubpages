<?php

namespace Code_Snippets\Controller;

use Code_Snippets\Client\Cloud_Private_Client;
use Code_Snippets\Client\Cloud_Public_Client;
use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\Model\Cloud_Link;
use Code_Snippets\Model\Cloud_Snippet;
use Code_Snippets\Model\Cloud_Snippets;
use Code_Snippets\Model\Snippet;
use WP_REST_Request;
use function Code_Snippets\get_snippets;
use function Code_Snippets\save_snippet;
use function Code_Snippets\update_snippet_fields;

/**
 * Controller for interfacing with private data on Code Snippets Cloud.
 */
class Cloud_Library_Controller {

	/**
	 * Days to cache data retrieved from API.
	 */
	private const DAYS_TO_STORE_CS = 1;

	/**
	 * Key used to access the local-to-cloud map transient data.
	 */
	private const CLOUD_MAP_TRANSIENT_KEY = 'code_snippets_cloud_links';

	/**
	 * Key used to access the codevault snippets transient data.
	 */
	private const CODEVAULT_SNIPPETS_TRANSIENT_KEY = 'cs_codevault_snippets';

	/**
	 * Client for fetching public cloud data.
	 *
	 * @var Cloud_Public_Client
	 */
	private Cloud_Public_Client $public_client;

	/**
	 * Client for fetching private cloud data.
	 *
	 * @var Cloud_Private_Client
	 */
	private Cloud_Private_Client $private_client;

	/**
	 * Cached list of cloud links.
	 *
	 * @var array<int, Cloud_Link>|null
	 */
	private ?array $cloud_links = null;

	/**
	 * Cached codevault data, as returned from the cloud API.
	 *
	 * @var Cloud_Snippets|null
	 */
	private ?Cloud_Snippets $codevault_data = null;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		$this->public_client = new Cloud_Public_Client( $connection );
		$this->private_client = new Cloud_Private_Client( $connection );
	}

	/**
	 * Verify a REST API request has permission to perform this classes' actions.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function verify_rest_request( WP_REST_Request $request ): bool {
		return $this->public_client->verify_rest_request( $request );
	}

	/**
	 * Initialise the stored codevault data, either from cache or from the cloud API.
	 *
	 * @return void
	 */
	private function init_codevault_data() {
		$transient_data = get_transient( self::CODEVAULT_SNIPPETS_TRANSIENT_KEY );

		if ( $transient_data instanceof Cloud_Snippets ) {
			$this->codevault_data = $transient_data;
		} else {
			$remote_data = $this->private_client->get_codevault_snippets();
			$this->codevault_data = $remote_data ?? new Cloud_Snippets();

			if ( $remote_data ) {
				// Only persist the codevault data if the remote API returned actual data.
				$this->update_codevault_data_cache();
			}
		}
	}

	/**
	 * Initialise stored cloud link data.
	 *
	 * @return void
	 */
	private function init_cloud_links() {
		$transient_data = get_transient( self::CLOUD_MAP_TRANSIENT_KEY );

		if ( is_array( $transient_data ) ) {
			$this->cloud_links = $transient_data;
			return;
		}

		$this->cloud_links = [];

		foreach ( get_snippets() as $local_snippet ) {
			$this->create_cloud_link( $local_snippet );
		}

		$this->update_cloud_links_cache();
	}

	/**
	 * Retrieve already-loaded CodeVault data without contacting the cloud.
	 *
	 * Callers that know which slice of the vault they want use this to decide
	 * whether a fetch is needed at all, so that deciding does not itself trigger
	 * an unsized fetch they would immediately have to repeat.
	 *
	 * @return Cloud_Snippets|null Loaded data, or null when nothing is cached.
	 */
	private function get_cached_codevault_data(): ?Cloud_Snippets {
		if ( $this->codevault_data ) {
			return $this->codevault_data;
		}

		$transient_data = get_transient( self::CODEVAULT_SNIPPETS_TRANSIENT_KEY );

		return $transient_data instanceof Cloud_Snippets ? $transient_data : null;
	}

	/**
	 * Retrieve the current CodeVault data, initialising it only when required.
	 *
	 * @return Cloud_Snippets
	 */
	private function get_codevault_data(): Cloud_Snippets {
		if ( ! $this->codevault_data ) {
			$this->init_codevault_data();
		}

		return $this->codevault_data;
	}

	/**
	 * Retrieve the current cloud link map, initialising it only when required.
	 *
	 * @return array<int, Cloud_Link>
	 */
	private function get_cloud_links(): array {
		if ( is_null( $this->cloud_links ) ) {
			$this->init_cloud_links();
		}

		return $this->cloud_links;
	}

	/**
	 * Create a new cloud link object from a linked local snippet and add it to the local store.
	 *
	 * @param Snippet $local_snippet Local snippet to create a cloud link for.
	 */
	private function create_cloud_link( Snippet $local_snippet ): ?Cloud_Link {
		if ( ! $local_snippet->cloud_id || $local_snippet->trashed ) {
			return null;
		}

		$link = new Cloud_Link();

		$link->local_id = $local_snippet->id;
		$link->cloud_id = $local_snippet->cloud_id;
		$link->is_owner = $local_snippet->is_cloud_owner;
		$link->update_available = $local_snippet->revision < ( $this->get_cloud_snippet_revision( $local_snippet ) ?? -1 );

		$this->cloud_links[ $local_snippet->cloud_id ] = $link;
		return $link;
	}

	/**
	 * Retrieve the cloud link for a local snippet.
	 *
	 * @param Snippet $local_snippet Syncronised local snippet.
	 *
	 * @return Cloud_Link|null The cloud link, if it exists.
	 */
	public function get_cloud_link( Snippet $local_snippet ): ?Cloud_Link {
		$cloud_links = $this->get_cloud_links();
		return $cloud_links[ $local_snippet->cloud_id ] ?? null;
	}

	/**
	 * Directly retrieve a cloud snippet by its identifier.
	 *
	 * @param int $cloud_id Cloud snippet identifier.
	 *
	 * @return Cloud_Snippet|null
	 */
	public function get_cloud_snippet( int $cloud_id ): ?Cloud_Snippet {
		$snippet = $this->private_client->get_cloud_snippet( $cloud_id );
		return $snippet ? $this->enrich_cloud_snippet( $snippet ) : null;
	}

	/**
	 * Get the revision number of a linked cloud snippet.
	 *
	 * This function should only be used when generating cloud link map.
	 *
	 * @param Snippet $local_snippet Local snippet linked to cloud snippet.
	 *
	 * @return int|null
	 */
	private function get_cloud_snippet_revision( Snippet $local_snippet ): ?int {
		$codevault_data = $this->get_codevault_data();

		return $codevault_data->cloud_id_rev[ $local_snippet->cloud_id ]
		       ?? $this->public_client->get_cloud_snippet_revision( $local_snippet->cloud_id );
	}

	/**
	 * Refresh the cached synced data.
	 *
	 * @return void
	 */
	public static function clear_caches() {
		delete_transient( self::CLOUD_MAP_TRANSIENT_KEY );
		delete_transient( self::CODEVAULT_SNIPPETS_TRANSIENT_KEY );
	}

	/**
	 * Delete cached data and refresh locally stored data.
	 *
	 * @return void
	 */
	public function refresh_cached_data() {
		self::clear_caches();
		$this->codevault_data = null;
		$this->cloud_links = null;
		$this->init_codevault_data();
		$this->init_cloud_links();
	}

	/**
	 * Store the local $codevault_data value in the transient data.
	 *
	 * @return void
	 */
	private function update_codevault_data_cache() {
		if ( ! $this->codevault_data ) {
			return;
		}

		set_transient(
			self::CODEVAULT_SNIPPETS_TRANSIENT_KEY,
			$this->codevault_data,
			DAY_IN_SECONDS * self::DAYS_TO_STORE_CS
		);
	}

	/**
	 * Store the local $cached_cloud_links value in the transient data.
	 *
	 * @return void
	 */
	private function update_cloud_links_cache() {
		if ( is_null( $this->cloud_links ) ) {
			return;
		}

		set_transient(
			self::CLOUD_MAP_TRANSIENT_KEY,
			$this->cloud_links,
			DAY_IN_SECONDS * self::DAYS_TO_STORE_CS
		);
	}

	/**
	 * Update the list of synced snippets on cloud to match that stored locally.
	 *
	 * @return void
	 */
	private function update_synced_list() {
		$synced_cloud_ids = array_map(
			fn( Cloud_Link $link ) => $link->cloud_id,
			$this->get_cloud_links()
		);

		$this->private_client->update_synced_list( array_filter( $synced_cloud_ids ) );
	}


	/**
	 * Enrich a cloud snippet with local linking information
	 *
	 * @param Cloud_Snippet $cloud_snippet Snippet to enrich.
	 *
	 * @return Cloud_Snippet Cloud snippet object with updated data.
	 */
	public function enrich_cloud_snippet( Cloud_Snippet $cloud_snippet ): Cloud_Snippet {
		$cloud_links = $this->get_cloud_links();
		$link = $cloud_links[ $cloud_snippet->id ] ?? null;

		$cloud_snippet->local_id = $link ? $link->local_id : 0;
		$cloud_snippet->update_available = $link && $link->update_available;

		return $cloud_snippet;
	}

	/**
	 * Enrich all snippets within a collection of cloud snippets.
	 *
	 * @param Cloud_Snippets $cloud_snippets Cloud Snippets collection.
	 *
	 * @return Cloud_Snippets Enriched data.
	 */
	public function enrich_cloud_snippets( Cloud_Snippets $cloud_snippets ): Cloud_Snippets {
		$cloud_snippets->snippets = array_map(
			fn( Cloud_Snippet $cloud_snippet ) => $this->enrich_cloud_snippet( $cloud_snippet ),
			$cloud_snippets->snippets
		);

		return $cloud_snippets;
	}

	/**
	 * Add a new link item to the local-to-cloud map.
	 *
	 * @param Snippet $local_snippet The local snippet.
	 *
	 * @return bool Whether linking was successful.
	 */
	public function link_snippet_to_cloud( Snippet $local_snippet ): bool {
		$this->get_cloud_links();
		$link = $this->create_cloud_link( $local_snippet );

		if ( $link ) {
			$this->update_cloud_links_cache();
			return true;
		}

		return false;
	}

	/**
	 * Delete a snippet from local-to-cloud map.
	 *
	 * @param Snippet $snippet Local snippet.
	 *
	 * @return bool Whether a link was removed.
	 */
	public function unlink_local_snippet( Snippet $snippet ): bool {
		$this->get_cloud_links();

		if ( $snippet->cloud_id && isset( $this->cloud_links[ $snippet->cloud_id ] ) ) {
			unset( $this->cloud_links[ $snippet->cloud_id ] );
			$this->update_cloud_links_cache();
			return true;
		}

		return false;
	}

	/**
	 * Retrieves a list of cloud snippets from the authenticated user's codevault..
	 *
	 * Cached data is only reusable when it covers the same slice of the vault, so
	 * a change of page size invalidates it just as a change of page does.
	 *
	 * @param int      $page     Page of data to retrieve.
	 * @param int|null $per_page Items per page, or null to accept the cloud's default.
	 *
	 * @return Cloud_Snippets|null Retrieved cloud snippets, including local linking information.
	 */
	public function get_codevault_snippets( int $page, ?int $per_page = null ): Cloud_Snippets {
		$requested_per_page = Cloud_Private_Client::normalise_per_page( $per_page );
		$codevault_data = $this->get_cached_codevault_data();
		$is_stale = ! $codevault_data ||
			$codevault_data->page !== $page ||
			( ! is_null( $requested_per_page ) && $codevault_data->per_page !== $requested_per_page );

		if ( $is_stale ) {
			$remote_data = $this->private_client->get_codevault_snippets( $page, $requested_per_page );

			if ( ! $remote_data ) {
				return new Cloud_Snippets();
			}

			$this->codevault_data = $remote_data;
			$this->update_codevault_data_cache();
		}

		return $this->enrich_cloud_snippets( $this->get_codevault_data() );
	}

	/**
	 * Upload a local snippet to the cloud platform.
	 *
	 * @param Snippet $local_snippet Local snippet to upload.
	 *
	 * @return Snippet|null Snippet with cloud information, or null if upload failed.
	 */
	public function create_cloud_snippet( Snippet $local_snippet ): ?Snippet {
		if ( $local_snippet->cloud_id ) {
			return null;
		}

		$uploaded = $this->private_client->store_snippet( $local_snippet );

		if ( $uploaded ) {
			$saved = save_snippet( $uploaded );
			$link = $this->link_snippet_to_cloud( $saved );
			return $link ? $saved : null;
		}

		return null;
	}

	/**
	 * Update the already-existing remote data for a series of snippets.
	 *
	 * @param Snippet $local_snippet Local snippet to update.
	 *
	 * @return void
	 */
	public function push_changes_to_cloud( Snippet $local_snippet ) {
		if ( $local_snippet->cloud_id && $this->private_client->update_snippet( $local_snippet ) ) {
			self::clear_caches();
		}
	}

	/**
	 * Unsync local snippets from the cloud
	 *
	 * @param Snippet $local_snippet Local snippet to ynsunc.
	 */
	public function unlink_from_cloud( Snippet $local_snippet ) {
		$local_snippet->cloud_id = 0;
		$this->unlink_local_snippet( save_snippet( $local_snippet ) );
		self::clear_caches();
	}

	/**
	 * Retrieve snippets stored in a bundle using the bundle's identifier.
	 *
	 * @param int $bundle_id Bundle identifier.
	 *
	 * @return Cloud_Snippets|null
	 */
	public function get_snippets_by_bundle_id( int $bundle_id ): ?Cloud_Snippets {
		$snippets = $this->private_client->get_snippets_from_bundle( $bundle_id );
		return $snippets ? $this->enrich_cloud_snippets( $snippets ) : null;
	}

	/**
	 * Retrieve snippets stored in a bundle using the bundle's shared name.
	 *
	 * @param string $bundle_share_name Bundle share name.
	 *
	 * @return Cloud_Snippets|null
	 */
	public function get_snippets_by_bundle_share_code( string $bundle_share_name ): ?Cloud_Snippets {
		$snippets = $this->private_client->get_snippets_from_shared_bundle( $bundle_share_name );
		return $snippets ? $this->enrich_cloud_snippets( $snippets ) : null;
	}
}
