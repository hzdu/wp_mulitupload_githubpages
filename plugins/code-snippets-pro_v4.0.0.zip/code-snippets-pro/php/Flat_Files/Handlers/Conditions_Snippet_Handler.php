<?php

namespace Code_Snippets\Flat_Files\Handlers;

use Code_Snippets\Flat_Files\Interfaces\Snippet_Type_Handler;

/**
 * Snippet type handler for conditions.
 */
class Conditions_Snippet_Handler implements Snippet_Type_Handler {

	/**
	 * Set 'php' as the file extension for conditions.
	 *
	 * @return string
	 */
	public function get_file_extension(): string {
		return 'php';
	}

	/**
	 * Store content snippets in a 'cond' directory.
	 *
	 * @return string
	 */
	public function get_dir_name(): string {
		return 'cond';
	}

	/**
	 * Wrap content snippets by adding a header that disallows direct access.
	 *
	 * @param string $code Content snippet code.
	 *
	 * @return string Content snippet code with header prepended.
	 */
	public function wrap_code( string $code ): string {
		$header = "<?php\n\nif ( ! defined( 'ABSPATH' ) ) { return; }\n\n";

		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_var_export
		return $header . var_export( json_decode( $code, true ), true );
	}
}
