<?php

namespace Code_Snippets\Flat_Files\Handlers;

use Code_Snippets\Flat_Files\Interfaces\Snippet_Type_Handler;
use Code_Snippets\Vendor\MatthiasMullie\Minify;
use function Code_Snippets\Settings\get_setting;

/**
 * Snippet type handler for style snippets.
 */
class Styles_Snippet_Handler implements Snippet_Type_Handler {

	/**
	 * Set 'css' as the file extension for style snippets.
	 *
	 * @return string
	 */
	public function get_file_extension(): string {
		return 'css';
	}

	/**
	 * Store script snippets in a 'css' directory.
	 *
	 * @return string
	 */
	public function get_dir_name(): string {
		return 'css';
	}

	/**
	 * Prepare CSS snippet code for output.
	 *
	 * @param string $code Snippet CSS code.
	 *
	 * @return string Browser-ready CSS code.
	 */
	public function wrap_code( string $code ): string {
		$setting = get_setting( 'general', 'minify_output' );

		if ( is_array( $setting ) && in_array( 'css', $setting, true ) ) {
			$minifier = new Minify\CSS( $code );
			$code = $minifier->minify();
		}

		return $code;
	}
}
