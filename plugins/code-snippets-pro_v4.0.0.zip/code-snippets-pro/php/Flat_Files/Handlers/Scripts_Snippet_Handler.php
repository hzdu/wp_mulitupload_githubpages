<?php

namespace Code_Snippets\Flat_Files\Handlers;

use Code_Snippets\Flat_Files\Interfaces\Snippet_Type_Handler;
use Code_Snippets\Vendor\MatthiasMullie\Minify;
use function Code_Snippets\Settings\get_setting;

/**
 * Snippet type handler for script snippets.
 */
class Scripts_Snippet_Handler implements Snippet_Type_Handler {

	/**
	 * Set 'js' as the file extension for script snippets.
	 *
	 * @return string
	 */
	public function get_file_extension(): string {
		return 'js';
	}

	/**
	 * Store script snippets in a 'js' directory.
	 *
	 * @return string
	 */
	public function get_dir_name(): string {
		return 'js';
	}

	/**
	 * Prepare JavaScript snippet code for output.
	 *
	 * @param string $code Snippet JavaScript code.
	 *
	 * @return string Browser-ready JavaScript code.
	 */
	public function wrap_code( string $code ): string {
		$setting = get_setting( 'general', 'minify_output' );

		if ( is_array( $setting ) && in_array( 'js', $setting, true ) ) {
			$minifier = new Minify\JS( $code );
			$code = $minifier->minify();
		}

		return $code;
	}
}
