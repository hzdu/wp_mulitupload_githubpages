<?php

namespace Code_Snippets\Admin;

use Code_Snippets\Integration\Snippet_Performance_Tracker;
use Code_Snippets\Integration\Snippet_Security_Scanner;
use function Code_Snippets\code_snippets;

/**
 * Admin-post handlers for the row-level Insights pills:
 * rescan-all security, reset perf data (all or one snippet),
 * dismiss a single security finding.
 *
 * Each handler verifies its own nonce, requires manage_options,
 * and redirects back to the All Snippets table with a flash flag.
 */
class Insights_Actions {

	/**
	 * Wire the admin-post handlers.
	 */
	public function __construct() {
		add_action( 'admin_post_code_snippets_insights_rescan', [ $this, 'rescan_all' ] );
		add_action( 'admin_post_code_snippets_insights_reset_perf', [ $this, 'reset_perf' ] );
		add_action( 'admin_post_code_snippets_insights_dismiss', [ $this, 'dismiss_finding' ] );
	}

	/**
	 * Re-run the security scanner across every PHP snippet.
	 *
	 * @return void
	 */
	public function rescan_all(): void {
		check_admin_referer( 'code_snippets_insights_rescan' );
		$this->require_cap();
		$count = Snippet_Security_Scanner::rescan_all();
		$this->redirect_back(
			[
				'insights_msg'   => 'rescanned',
				'insights_count' => $count,
			]
		);
	}

	/**
	 * Reset performance stats for one snippet, or for all snippets when no id is given.
	 *
	 * @return void
	 */
	public function reset_perf(): void {
		check_admin_referer( 'code_snippets_insights_reset_perf' );
		$this->require_cap();

		$snippet_id = isset( $_POST['snippet_id'] ) ? (int) $_POST['snippet_id'] : 0;
		if ( $snippet_id > 0 ) {
			Snippet_Performance_Tracker::reset( $snippet_id );
		} else {
			Snippet_Performance_Tracker::reset_all();
		}

		$this->redirect_back( [ 'insights_msg' => 'perf_reset' ] );
	}

	/**
	 * Mark a single security finding as dismissed.
	 *
	 * @return void
	 */
	public function dismiss_finding(): void {
		check_admin_referer( 'code_snippets_insights_dismiss' );
		$this->require_cap();

		$snippet_id = isset( $_POST['snippet_id'] ) ? (int) $_POST['snippet_id'] : 0;
		$rule       = isset( $_POST['rule'] ) ? sanitize_key( wp_unslash( $_POST['rule'] ) ) : '';
		$line       = isset( $_POST['line'] ) ? (int) $_POST['line'] : 0;

		if ( $snippet_id > 0 && '' !== $rule ) {
			Snippet_Security_Scanner::dismiss( $snippet_id, $rule, $line );
		}

		$this->redirect_back( [ 'insights_msg' => 'dismissed' ] );
	}

	/**
	 * Render a "Rescan all snippets now" action on the Settings page,
	 * directly under the "Scan Snippets for Security Issues" checkbox.
	 *
	 * Also surfaces the last-scan timestamp + how many snippets have findings,
	 * so the user has context before clicking.
	 *
	 * @return void
	 */
	public static function render_rescan_field(): void {
		$findings = Snippet_Security_Scanner::get_all_findings();
		$with_findings = 0;
		foreach ( $findings as $rows ) {
			if ( is_array( $rows ) && count( $rows ) > 0 ) {
				++$with_findings;
			}
		}

		$summary = $with_findings > 0
			/* translators: %d: number of snippets with security findings. */
			? sprintf( _n( '%d snippet has open findings.', '%d snippets have open findings.', $with_findings, 'code-snippets' ), $with_findings )
			: __( 'No findings on record.', 'code-snippets' );

		// Render as a nonce'd link rather than a nested <form>: this field is
		// rendered inside the settings <form action="options.php">, and nested
		// forms get coalesced by the browser into the outer one.
		$action_url = wp_nonce_url(
			add_query_arg( 'action', 'code_snippets_insights_rescan', admin_url( 'admin-post.php' ) ),
			'code_snippets_insights_rescan'
		);

		echo '<span style="display:inline-flex;align-items:center;gap:12px;flex-wrap:wrap;">';
		printf(
			'<a href="%s" class="button">%s</a>',
			esc_url( $action_url ),
			esc_html__( 'Rescan all snippets now', 'code-snippets' )
		);
		printf( '<span class="description">%s</span>', esc_html( $summary ) );
		echo '</span>';
		printf(
			'<p class="description" style="margin-top:6px;">%s</p>',
			esc_html__( 'Snippets are scanned automatically on save. Use this to backfill after enabling scanning, or after a plugin update that may have added new rules.', 'code-snippets' )
		);
	}

	/**
	 * Bail with a 403 if the current user can't manage snippets.
	 *
	 * @return void
	 */
	private function require_cap(): void {
		if ( ! current_user_can( code_snippets()->get_cap() ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'code-snippets' ), '', 403 );
		}
	}

	/**
	 * Redirect back to wherever the request came from, falling back to
	 * the All Snippets menu. Lets rescan-from-Settings land on Settings,
	 * and dismiss-from-table land back on the table.
	 *
	 * @param array<string, string|int> $extra Query args to append.
	 */
	private function redirect_back( array $extra = [] ): void {
		$referer = wp_get_referer();
		$base    = $referer ? $referer : code_snippets()->get_menu_url();
		wp_safe_redirect( add_query_arg( $extra, $base ) );
		exit;
	}
}
