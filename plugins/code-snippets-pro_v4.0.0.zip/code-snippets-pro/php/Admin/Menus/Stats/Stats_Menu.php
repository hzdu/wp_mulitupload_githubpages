<?php

namespace Code_Snippets\Admin\Menus\Stats;

use Code_Snippets\Admin\Contextual_Help;
use Code_Snippets\Admin\Menus\Admin_Menu;
use function Code_Snippets\code_snippets;
use const Code_Snippets\PLUGIN_FILE;
use const Code_Snippets\PLUGIN_VERSION;

/**
 * Provides the Stats admin menu.
 */
class Stats_Menu extends Admin_Menu {

	/**
	 * Handle for the Stats script and stylesheet.
	 */
	private const ASSET_HANDLE = 'code-snippets-stats';

	/**
	 * Class constructor.
	 */
	public function __construct() {
		parent::__construct(
			'stats',
			_x( 'Stats', 'menu label', 'code-snippets' ),
			__( 'Snippet Stats', 'code-snippets' )
		);
	}

	/**
	 * Render the Stats interface.
	 *
	 * @return void
	 */
	public function render() {
		echo '<div id="code-snippets-stats-container" class="wrap"></div>';
	}

	/**
	 * Load the contextual help tabs.
	 *
	 * @return void
	 */
	public function load() {
		parent::load();

		$contextual_help = new Contextual_Help( 'stats' );
		$contextual_help->load();
	}

	/**
	 * Enqueue Stats assets and localized runtime data.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		wp_enqueue_style(
			self::ASSET_HANDLE,
			plugins_url( 'dist/stats.css', PLUGIN_FILE ),
			self::$style_deps,
			PLUGIN_VERSION
		);

		wp_enqueue_script(
			self::ASSET_HANDLE,
			plugins_url( 'dist/stats.js', PLUGIN_FILE ),
			self::$script_deps,
			PLUGIN_VERSION,
			true
		);

		wp_set_script_translations( self::ASSET_HANDLE, 'code-snippets' );
		code_snippets()->localize_script( self::ASSET_HANDLE );
		wp_localize_script( self::ASSET_HANDLE, 'CODE_SNIPPETS_STATS', ( new Stats_Summary() )->get() );
	}
}
