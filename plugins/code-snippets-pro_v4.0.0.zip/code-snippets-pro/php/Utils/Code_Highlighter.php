<?php

namespace Code_Snippets\Utils;

use const Code_Snippets\PLUGIN_FILE;
use const Code_Snippets\PLUGIN_VERSION;

/**
 * This class handles the integration of the PrismJS syntax highlighter.
 *
 * @package Code_Snippets
 */
class Code_Highlighter {

	/**
	 * Handle to use for the PrismJS library.
	 */
	public const PRISM_HANDLE = 'code-snippets-prism';

	/**
	 * Enqueue the styles and scripts for the Prism syntax highlighter.
	 *
	 * @return void
	 */
	public static function register_prism_assets() {
		wp_register_script(
			self::PRISM_HANDLE,
			plugins_url( 'dist/prism.js', PLUGIN_FILE ),
			[],
			PLUGIN_VERSION,
			[ 'in_footer' => true ]
		);

		wp_register_style(
			self::PRISM_HANDLE,
			plugins_url( 'dist/prism.css', PLUGIN_FILE ),
			[],
			PLUGIN_VERSION
		);

		foreach ( self::get_prism_themes() as $theme => $label ) {
			wp_register_style(
				self::get_prism_theme_style_handle( $theme ),
				plugins_url( "dist/prism-themes/prism-$theme.css", PLUGIN_FILE ),
				array(),
				PLUGIN_VERSION
			);
		}
	}

	/**
	 * Enqueue all available Prism themes.
	 *
	 * @return void
	 */
	public static function enqueue_all_prism_themes() {
		self::register_prism_assets();

		foreach ( self::get_prism_themes() as $theme => $label ) {
			wp_enqueue_style( self::get_prism_theme_style_handle( $theme ) );
		}

		wp_enqueue_style( self::PRISM_HANDLE );
		wp_enqueue_script( self::PRISM_HANDLE );
	}

	/**
	 * Retrieve the style handle for a PrismJS theme.
	 *
	 * @param string $theme Theme name.
	 *
	 * @return string
	 */
	public static function get_prism_theme_style_handle( string $theme ): string {
		return "code-snippets-prism-theme-$theme";
	}

	/**
	 * Retrieve a list of PrismJS themes.
	 *
	 * @return array
	 */
	public static function get_prism_themes(): ?array {
		static $themes = null;

		if ( ! is_null( $themes ) ) {
			return $themes;
		}

		$themes = array();
		$themes_dir = plugin_dir_path( PLUGIN_FILE ) . 'dist/prism-themes/';
		$theme_files = glob( $themes_dir . '*.css' );

		foreach ( $theme_files as $theme ) {
			$theme = str_replace( $themes_dir, '', $theme );
			$theme = str_replace( '.css', '', $theme );
			$theme = str_replace( 'prism-', '', $theme );

			$label = str_replace( '.', '-', $theme );
			$label = array_map(
				function ( $word ) {
					return strlen( $word ) < 3 ?
						'of' === $word ? $word : strtoupper( $word ) :
						ucfirst( $word );
				},
				explode( '-', $label )
			);

			$themes[ $theme ] = implode( ' ', $label );
		}

		return $themes;
	}
}
