<?php

namespace Code_Snippets\Client;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\Model\Snippet;

/**
 * Reports fatal/parse errors on cloud-linked snippets up to Code Snippets
 * Cloud so the self-heal pipeline can propose an AI fix.
 *
 * The plugin already captures execution errors into `code_error` /
 * `code_error_trace` on the Snippet model after each save attempt; we
 * hook the same `code_snippets/update_snippet` action and, when those
 * fields are populated AND the snippet is cloud-linked, fire-and-forget
 * a POST to cloud-app's /cloud/site-snippet-error endpoint.
 *
 * @package Code_Snippets
 */
final class Cloud_Error_Reporter {

	/**
	 * Cloud connection instance — gives us the site's local_token to authenticate
	 * the outbound webhook the same way cloud→site deploys do.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Cloud connection instance.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		$this->connection = $connection;
	}

	/**
	 * Register WP hooks. Priority 100 so we run after Cloud_Sync_Notifier.
	 */
	public function init(): void {
		add_action( 'code_snippets/update_snippet', [ $this, 'on_snippet_updated' ], 100, 4 );
	}

	/**
	 * Post the error to cloud when the snippet has a code_error and is cloud-linked.
	 *
	 * @param Snippet  $updated  The snippet that was just saved.
	 * @param string   $table    DB table (ignored).
	 * @param ?Snippet $existing The previous state (ignored).
	 * @param ?Snippet $input    The incoming state (ignored).
	 *
	 * @return void
	 */
	public function on_snippet_updated( $updated, $table, $existing = null, $input = null ): void {
		unset( $table, $existing, $input );

		if ( ! ( $updated instanceof Snippet ) || empty( $updated->cloud_id ) ) {
			return;
		}

		$code_error = $updated->code_error;
		if ( empty( $code_error ) || ! is_array( $code_error ) ) {
			return;
		}

		$message = isset( $code_error[0] ) ? (string) $code_error[0] : 'Unknown error';
		$line    = isset( $code_error[1] ) ? (int) $code_error[1] : null;
		$trace   = (string) ( $updated->code_error_trace ?? '' );

		$payload = [
			'cloud_id'      => (string) $updated->cloud_id,
			'local_id'      => (int) $updated->id,
			'code'          => (string) $updated->code,
			'error_message' => $message,
			'error_line'    => $line,
			'error_trace'   => function_exists( 'mb_substr' ) ? mb_substr( $trace, 0, 4000 ) : substr( $trace, 0, 4000 ),
		];

		$url = $this->connection->get_api_url() . '/cloud/site-snippet-error';

		wp_remote_post(
			$url,
			[
				'timeout'   => 4,
				'blocking'  => false,
				'headers'   => [
					'Content-Type'   => 'application/json',
					'Accept'         => 'application/json',
					'Access-Control' => $this->connection->get_local_token(),
				],
				'body'      => wp_json_encode( $payload ),
				'sslverify' => apply_filters( 'code_snippets/cloud_error_sslverify', true ),
			]
		);
	}
}
