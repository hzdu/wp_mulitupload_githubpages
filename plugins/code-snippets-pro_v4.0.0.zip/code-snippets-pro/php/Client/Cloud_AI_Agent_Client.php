<?php

namespace Code_Snippets\Client;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use WP_Error;
use function Code_Snippets\code_snippets;
use function Code_Snippets\Utils\unpack_response_body;

/**
 * Client for the Cloud plan-first AI generation API (`/api/v1/ai-generations`).
 *
 * @package Code_Snippets
 */
class Cloud_AI_Agent_Client {

	/**
	 * Base path for the generation endpoints, relative to the cloud API URL.
	 */
	public const API_PATH = 'ai-generations';

	/**
	 * Path for the quota endpoint, reused from the assistant feature.
	 */
	public const QUOTA_PATH = 'assistant/quota';

	/**
	 * Request timeout, in seconds. Planning and building happen on the cloud
	 * queue, so these calls only enqueue work or read state and return quickly.
	 */
	private const REQUEST_TIMEOUT = 15;

	/**
	 * Cloud connection instance.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		$this->connection = $connection;
	}

	/**
	 * Create a new generation conversation from an initial prompt.
	 *
	 * @param string               $prompt  Initial user prompt.
	 * @param array<string, mixed> $context Optional L1/L2/L3 context payload.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( string $prompt, array $context = [] ) {
		if ( '' === trim( $prompt ) ) {
			return $this->invalid_input( __( 'Cannot start a generation with an empty prompt.', 'code-snippets' ) );
		}

		$body = [ 'prompt' => $prompt ];
		if ( $context ) {
			$body['context'] = $context;
		}

		return $this->request( 'POST', self::API_PATH, $body );
	}

	/**
	 * List the current user's generation conversations, newest first.
	 *
	 * @param int $page Page number to fetch.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function list_generations( int $page = 1 ) {
		return $this->request( 'GET', add_query_arg( 'page', max( 1, $page ), self::API_PATH ) );
	}

	/**
	 * Fetch the current state of a single generation.
	 *
	 * @param int $id Generation ID.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function get( int $id ) {
		return $this->request( 'GET', sprintf( '%s/%d', self::API_PATH, $id ) );
	}

	/**
	 * Refine an existing plan with a follow-up message.
	 *
	 * @param int                  $id      Generation ID.
	 * @param string               $message Refinement message.
	 * @param array<string, mixed> $context Optional context payload.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function refine( int $id, string $message, array $context = [] ) {
		if ( '' === trim( $message ) ) {
			return $this->invalid_input( __( 'Cannot refine a plan with an empty message.', 'code-snippets' ) );
		}

		$body = [ 'message' => $message ];
		if ( $context ) {
			$body['context'] = $context;
		}

		return $this->request( 'POST', sprintf( '%s/%d/refine', self::API_PATH, $id ), $body );
	}

	/**
	 * Accept the current plan and start building the snippet(s).
	 *
	 * @param int $id Generation ID.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function proceed( int $id ) {
		return $this->request( 'POST', sprintf( '%s/%d/proceed', self::API_PATH, $id ) );
	}

	/**
	 * Retry the failed stage of a generation.
	 *
	 * @param int $id Generation ID.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function retry( int $id ) {
		return $this->request( 'POST', sprintf( '%s/%d/retry', self::API_PATH, $id ) );
	}

	/**
	 * Cancel a generation that is still planning or building.
	 *
	 * @param int $id Generation ID.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function cancel( int $id ) {
		return $this->request( 'POST', sprintf( '%s/%d/cancel', self::API_PATH, $id ) );
	}

	/**
	 * Answer a generation's outstanding request for wider context.
	 *
	 * Sending an empty context declines the request, which resumes planning with
	 * what the cloud already holds.
	 *
	 * @param int                  $id      Generation ID.
	 * @param array<string, mixed> $context Context payload, or empty to decline.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function provide_context( int $id, array $context ) {
		return $this->request(
			'POST',
			sprintf( '%s/%d/context', self::API_PATH, $id ),
			$context ? [ 'context' => $context ] : [ 'decline' => true ]
		);
	}

	/**
	 * Request edits to existing snippets in a completed generation.
	 *
	 * @param int                  $id          Generation ID.
	 * @param array<int>           $snippet_ids Cloud IDs of the snippets to edit.
	 * @param string               $message     Edit instruction.
	 * @param array<string, mixed> $context     Optional L1/L2/L3 context payload.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function edit( int $id, array $snippet_ids, string $message, array $context = [] ) {
		if ( empty( $snippet_ids ) ) {
			return $this->invalid_input( __( 'Select at least one snippet to edit.', 'code-snippets' ) );
		}

		if ( '' === trim( $message ) ) {
			return $this->invalid_input( __( 'Cannot edit snippets with an empty message.', 'code-snippets' ) );
		}

		$body = [
			'snippet_ids' => array_map( 'intval', $snippet_ids ),
			'message'     => $message,
		];
		if ( $context ) {
			$body['context'] = $context;
		}

		return $this->request( 'POST', sprintf( '%s/%d/edit', self::API_PATH, $id ), $body );
	}

	/**
	 * Delete a generation conversation.
	 *
	 * @param int $id Generation ID.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function delete( int $id ) {
		return $this->request( 'DELETE', sprintf( '%s/%d', self::API_PATH, $id ) );
	}

	/**
	 * Fetch the current AI usage quota. Resilient: a failure yields an empty
	 * result rather than an error, since quota is a non-critical sidebar widget.
	 *
	 * @return array<string, mixed>
	 */
	public function quota(): array {

		$response = $this->request( 'GET', self::QUOTA_PATH );
		return is_wp_error( $response ) ? [] : $response;
	}

	/**
	 * Send an authenticated request to the cloud API.
	 *
	 * @param string                    $method   HTTP method.
	 * @param string                    $endpoint Endpoint path relative to the API URL.
	 * @param array<string, mixed>|null $body     Optional request body.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	private function request( string $method, string $endpoint, ?array $body = null ) {
		if ( ! $this->connection->is_cloud_key_verified() ) {
			return new WP_Error(
				'cloud_ai_agent_key_error',
				__( 'Cannot access the Cloud AI API without a verified cloud key.', 'code-snippets' ),
				[ 'status' => 403 ]
			);
		}

		// The cloud confines a request to one site by its `Local-Token` header and
		// treats an empty value as absent — which widens the scope to every site
		// the account owns. Verification only covers the cloud key, so refuse
		// rather than send a blank token.
		if ( '' === $this->connection->get_local_token() ) {
			return new WP_Error(
				'cloud_ai_agent_site_token_error',
				__( 'Cannot access the Cloud AI API without a site token.', 'code-snippets' ),
				[ 'status' => 403 ]
			);
		}

		$freemius_license = code_snippets()->licensing->get_license_key();
		if ( ! $freemius_license ) {
			return new WP_Error(
				'cloud_ai_agent_license_error',
				__( 'Could not retrieve license details for the API request.', 'code-snippets' ),
				[ 'status' => 403 ]
			);
		}

		$url = sprintf( '%s/%s', $this->connection->get_api_url(), ltrim( $endpoint, '/\\' ) );

		$args = [
			'method'  => $method,
			'headers' => $this->connection->get_request_headers(),
			'timeout' => self::REQUEST_TIMEOUT,
		];

		// Bodyless methods must carry the license key outside the body: Laravel
		// does not parse a form body on GET/DELETE requests.
		//
		// `add_query_arg()` does not encode the values it is given, and a license
		// key can contain reserved characters — an `&` truncates the key at the
		// server, which reads as an invalid license. GET therefore sends it as a
		// header, which the cloud accepts and which also keeps the secret out of
		// the cloud's access logs. The cloud only falls back to that header on
		// GET, so DELETE has to keep it in the query string, encoded explicitly.
		//
		// The header is spelled with a dash: the cloud reads it via Symfony's
		// HeaderBag, which normalises `_` to `-`, and web servers routinely drop
		// headers containing underscores.
		if ( 'GET' === $method ) {
			$args['headers']['fs-key'] = $freemius_license;
		} elseif ( 'DELETE' === $method ) {
			$url = add_query_arg( [ 'fs_key' => rawurlencode( $freemius_license ) ], $url );
		} else {
			$args['body'] = array_merge( [ 'fs_key' => $freemius_license ], $body ?? [] );
		}

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'cloud_ai_agent_request_error',
				__( 'Failed to send request to the Cloud AI API.', 'code-snippets' ),
				$response->get_error_message()
			);
		}

		$status = wp_remote_retrieve_response_code( $response );

		if ( $status >= 400 ) {
			return $this->error_from_response( $response, $status );
		}

		if ( 204 === $status ) {
			return [ 'success' => true ];
		}

		$body = unpack_response_body( $response );

		if ( ! is_array( $body ) ) {
			return new WP_Error(
				'cloud_ai_agent_response_error',
				__( 'Did not receive a valid response from the Cloud AI API.', 'code-snippets' )
			);
		}

		// The generation API returns a single row unwrapped but paginates lists
		// inside a `data`/`meta` envelope, so the envelope is preserved for the
		// caller. The unwrapping branch only covers endpoints that wrap a lone
		// resource without pagination, such as quota.
		return isset( $body['data'] ) && ! isset( $body['meta'] ) && is_array( $body['data'] )
			? $body['data']
			: $body;
	}

	/**
	 * Build a WP_Error from an unsuccessful cloud response.
	 *
	 * @param array<string, mixed> $response Raw HTTP response.
	 * @param int                  $status   HTTP status code.
	 *
	 * @return WP_Error
	 */
	private function error_from_response( array $response, int $status ): WP_Error {
		$body = unpack_response_body( $response );
		$message = is_array( $body ) && ! empty( $body['message'] )
			? $body['message']
			: __( 'The Cloud AI API returned an error.', 'code-snippets' );

		$code = 429 === $status ? 'cloud_ai_agent_rate_limited' : 'cloud_ai_agent_error';
		return new WP_Error( $code, $message, [ 'status' => $status ] );
	}

	/**
	 * Build a 400 validation error.
	 *
	 * @param string $message Error message.
	 *
	 * @return WP_Error
	 */
	private function invalid_input( string $message ): WP_Error {
		return new WP_Error( 'cloud_ai_agent_invalid_input', $message, [ 'status' => 400 ] );
	}
}
