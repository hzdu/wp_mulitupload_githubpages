<?php

namespace Code_Snippets\Client;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\Model\Snippet;

/**
 * Notifies Code Snippets Cloud whenever a cloud-linked snippet is saved
 * locally on this site. Fire-and-forget POST so a flaky cloud doesn't
 * block the WP save UI.
 *
 * Wired by hooking the existing `code_snippets/update_snippet` action.
 *
 * @package Code_Snippets
 */
final class Cloud_Sync_Notifier {

	/**
	 * Cloud connection instance — gives us the site's local_token to authenticate
	 * the outbound webhook the same way cloud→site deploys do.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Cloud connection instance.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		$this->connection = $connection;
	}

	/**
	 * Register WP hooks.
	 */
	public function init(): void {
		add_action( 'code_snippets/update_snippet', [ $this, 'on_snippet_updated' ], 99, 4 );
	}

	/**
	 * Fire-and-forget POST to cloud-app when a cloud-linked snippet is saved.
	 *
	 * @param Snippet  $updated  The snippet that was just saved.
	 * @param string   $table    DB table (ignored).
	 * @param ?Snippet $existing The previous state, when available.
	 * @param ?Snippet $input    The incoming state, when available.
	 *
	 * @return void
	 */
	public function on_snippet_updated( $updated, $table, $existing = null, $input = null ): void {
		unset( $table, $existing, $input );

		if ( ! ( $updated instanceof Snippet ) || empty( $updated->cloud_id ) ) {
			return;
		}

		// Don't echo cloud's own pushes back at it.
		if ( $this->is_currently_handling_cloud_push() ) {
			return;
		}

		$display_name = wp_get_current_user()->display_name;
		$edited_by = '' !== $display_name ? $display_name : 'site admin';

		$payload = [
			'cloud_id'    => (string) $updated->cloud_id,
			'local_id'    => (int) $updated->id,
			'code'        => (string) $updated->code,
			'name'        => (string) $updated->name,
			'description' => (string) $updated->desc,
			'scope'       => (string) $updated->scope,
			'revision'    => (int) $updated->revision,
			'modified'    => (string) $updated->modified,
			'edited_by'   => $edited_by,
		];

		$url = $this->connection->get_api_url() . '/cloud/site-snippet-changed';

		wp_remote_post(
			$url,
			[
				'timeout'   => 4,
				'blocking'  => false,
				'headers'   => [
					'Content-Type'   => 'application/json',
					'Accept'         => 'application/json',
					'Access-Control' => $this->connection->get_local_token(),
				],
				'body'      => wp_json_encode( $payload ),
				'sslverify' => apply_filters( 'code_snippets/cloud_sync_sslverify', true ),
			]
		);
	}

	/**
	 * Detect whether the current request is itself an incoming cloud → site
	 * deploy. If so, the local save was caused by cloud and we'd just be
	 * echoing the change back. Detect by checking for the Access-Control
	 * request header on the in-flight REST request.
	 *
	 * @return bool
	 */
	private function is_currently_handling_cloud_push(): bool {
		if ( ! defined( 'REST_REQUEST' ) || ! REST_REQUEST ) {
			return false;
		}

		$local_token = $this->connection->get_local_token();
		if ( '' === $local_token ) {
			return false;
		}

		// The token is an opaque secret compared in constant time and never
		// stored or echoed, so it is deliberately not run through a sanitiser
		// (which could alter it and cause a false mismatch).
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$incoming = isset( $_SERVER['HTTP_ACCESS_CONTROL'] ) ? (string) wp_unslash( $_SERVER['HTTP_ACCESS_CONTROL'] ) : '';

		return '' !== $incoming && hash_equals( $local_token, $incoming );
	}
}
