<?php

namespace Code_Snippets\Client;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\Model\Cloud_Snippet;
use Code_Snippets\Model\Cloud_Snippets;
use Code_Snippets\Model\Snippet;
use function Code_Snippets\Utils\unpack_response_body;

/**
 * Client for fetching private data from Code Snippets Cloud.
 *
 * @package Code_Snippets
 */
class Cloud_Private_Client {

	/**
	 * Request timeout, in seconds, for the codevault endpoint. As with the public search endpoint, this is higher
	 * than WordPress's 5s default.
	 */
	private const CODEVAULT_REQUEST_TIMEOUT = 15;

	/**
	 * Largest page size the codevault endpoint will serve. Asking for more is
	 * capped server-side, so the request is clamped here to keep the page size
	 * the caller is told about the one it actually gets.
	 */
	public const MAX_PER_PAGE = 200;

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		$this->connection = $connection;
	}

	/**
	 * Retrieve a single cloud snippet from the API, with access to private snippets.
	 *
	 * @param int $cloud_id Remote cloud snippet ID.
	 *
	 * @return Cloud_Snippet Retrieved snippet.
	 */
	public function get_cloud_snippet( int $cloud_id ): ?Cloud_Snippet {
		$response = wp_remote_get(
			sprintf( '%s/private/getsnippet/%s', $this->connection->get_api_url(), $cloud_id ),
			[ 'headers' => $this->connection->get_request_headers() ]
		);

		$body = unpack_response_body( $response );

		return is_array( $body ) && ! empty( $body['success'] ) && is_array( $body['snippet'] ?? null )
			? new Cloud_Snippet( $body['snippet'] )
			: null;
	}

	/**
	 * Clamp a requested page size to the range the codevault endpoint serves.
	 *
	 * Callers compare the normalised value against cached data, so it has to be
	 * derived the same way on both sides of that comparison.
	 *
	 * @param int|null $per_page Requested page size, or null for the cloud default.
	 *
	 * @return int|null Clamped page size, or null when no size was requested.
	 */
	public static function normalise_per_page( ?int $per_page ): ?int {
		return is_null( $per_page )
			? null
			: min( self::MAX_PER_PAGE, max( 1, $per_page ) );
	}

	/**
	 * Fetch snippets from the authenticated user's private codevault.
	 *
	 * Paginating in the request lets the cloud page in SQL rather than loading
	 * the whole vault into memory, which is the difference on large vaults.
	 *
	 * @param int      $page     Page number to fetch.
	 * @param int|null $per_page Items per page, or null to accept the cloud's default.
	 *
	 * @return Cloud_Snippets|null
	 */
	public function get_codevault_snippets( int $page = 1, ?int $per_page = null ): ?Cloud_Snippets {
		$query_args = [ 'page' => max( 0, $page - 1 ) ];
		$requested_per_page = self::normalise_per_page( $per_page );

		if ( ! is_null( $requested_per_page ) ) {
			$query_args['per_page'] = $requested_per_page;
		}

		$response = wp_remote_get(
			add_query_arg(
				$query_args,
				sprintf( '%s/private/allsnippets', $this->connection->get_api_url() )
			),
			[
				'headers' => $this->connection->get_request_headers(),
				'timeout' => self::CODEVAULT_REQUEST_TIMEOUT,
			],
		);

		$body = unpack_response_body( $response );
		return $body ? Cloud_Snippets::unpack_api_response( $body, $page, $requested_per_page ) : null;
	}

	/**
	 * Upload a local snippet to the cloud.
	 *
	 * @param Snippet $snippet Snippet to upload.
	 *
	 * @return Snippet Local snippet with cloud information populated.
	 */
	public function store_snippet( Snippet $snippet ): ?Snippet {
		$response = wp_remote_post(
			sprintf( '%s/private/storesnippet', $this->connection->get_api_url() ),
			[
				'method'  => 'POST',
				'headers' => $this->connection->get_request_headers(),
				'body'    => [
					'name'     => $snippet->name,
					'desc'     => wp_strip_all_tags( $snippet->desc ),
					'code'     => $snippet->code,
					'scope'    => $snippet->scope,
					'revision' => $snippet->revision,
				],
			]
		);

		$body = unpack_response_body( $response );

		$cloud_id = $body['cloud_id'] ?? '';
		$revision = intval( $body['revision'] ) ?? 0;

		if ( ! $cloud_id || ! $revision ) {
			return null;
		}

		$snippet->cloud_id = $cloud_id;
		$snippet->revision = $revision;
		return $snippet;
	}

	/**
	 * Update the already-existing remote data for a series of snippets.
	 *
	 * @param Snippet $snippet Local snippet to syncronise with cloud.
	 *
	 * @return bool Whether the operation was successful.
	 */
	public function update_snippet( Snippet $snippet ): bool {
		if ( ! $snippet->cloud_id ) {
			return false;
		}

		// Send post request to cs store api with snippet data.
		$response = wp_remote_post(
			sprintf( '%s/private/updatesnippet/%d', $this->connection->get_api_url(), $snippet->cloud_id ),
			[
				'method'  => 'POST',
				'headers' => $this->connection->get_request_headers(),
				'body'    => [
					'name'     => $snippet->name,
					'desc'     => wp_strip_all_tags( $snippet->desc ),
					'code'     => $snippet->code,
					'revision' => $snippet->revision,
					'local_id' => $snippet->id,
				],
			]
		);

		$updated = unpack_response_body( $response );
		return ! empty( $updated['data']['success'] );
	}

	/**
	 * Update the list of snippets synced to the cloud.
	 *
	 * @param int[] $cloud_id_array List of identifiers of synced cloud snippets.
	 *
	 * @return void
	 */
	public function update_synced_list( array $cloud_id_array ) {
		wp_remote_post(
			sprintf( '%s/private/setsyncedsnippetlist', $this->connection->get_api_url() ),
			[
				'method'  => 'POST',
				'headers' => $this->connection->get_request_headers(),
				'body'    => [
					'cloud_id_array' => wp_json_encode( $cloud_id_array ),
				],
			]
		);
	}

	/**
	 * Get list of all bundles from the cloud API.
	 *
	 * @return array{id: string, name: string} List of retrieved bundles.
	 */
	public function get_bundles(): array {
		$response = wp_remote_get(
			sprintf( '%s/private/bundles', $this->connection->get_api_url() ),
			[ 'headers' => $this->connection->get_request_headers() ]
		);

		$body = unpack_response_body( $response );

		return isset( $body['bundles'][0] ) && is_array( $body['bundles'][0] ) ?
			$body['bundles'][0] :
			[];
	}

	/**
	 * Get List of Snippets from a Bundle from the cloud API.
	 *
	 * @param int $bundle_id Bundle ID.
	 *
	 * @return Cloud_Snippets
	 */
	public function get_snippets_from_bundle( int $bundle_id ): ?Cloud_Snippets {
		$response = wp_remote_post(
			sprintf( '%s/private/getbundle/%s', $this->connection->get_api_url(), $bundle_id ),
			[
				'method'  => 'POST',
				'headers' => $this->connection->get_request_headers(),
			]
		);

		return Cloud_Snippets::unpack_api_response( unpack_response_body( $response ), 1 );
	}

	/**
	 * Get List of Snippets from a Shared Bundle from the cloud API.
	 *
	 * @param string $bundle_share_name Bundle share name.
	 *
	 * @return Cloud_Snippets
	 */
	public function get_snippets_from_shared_bundle( string $bundle_share_name ): ?Cloud_Snippets {
		$response = wp_remote_post(
			sprintf( '%s/private/getsharedbundle?share_name=%s', $this->connection->get_api_url(), $bundle_share_name ),
			[
				'method'  => 'POST',
				'headers' => $this->connection->get_request_headers(),
			]
		);

		return Cloud_Snippets::unpack_api_response( unpack_response_body( $response ), 1 );
	}
}
