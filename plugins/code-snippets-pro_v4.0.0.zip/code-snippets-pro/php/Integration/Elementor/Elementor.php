<?php

namespace Code_Snippets\Integration\Elementor;

use Elementor\Controls_Manager;
use Elementor\Elements_Manager;
use Elementor\Widgets_Manager;

/**
 * Handles integration with the Elementor website builder plugin.
 *
 * @package Code_Snippets
 */
class Elementor {

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_widget_category' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		add_action( 'elementor/controls/register', [ $this, 'register_controls' ] );
	}

	/**
	 * Add a new widget category for Elementor.
	 *
	 * @param Elements_Manager $elements_manager Elementor elements manager.
	 */
	public function add_widget_category( Elements_Manager $elements_manager ) {
		$elements_manager->add_category(
			'code-snippets',
			[
				'title' => esc_html__( 'Code Snippets', 'code-snippets' ),
			]
		);
	}

	/**
	 * Register new Elementor widgets.
	 *
	 * @param Widgets_Manager $widgets_manager Elementor widgets manager.
	 *
	 * @return void
	 */
	public function register_widgets( Widgets_Manager $widgets_manager ) {
		$widgets_manager->register( new Content_Widget() );
		$widgets_manager->register( new Source_Widget() );
	}

	/**
	 * Register new Elementor controls.
	 *
	 * @param Controls_Manager $controls_manager Elementor controls manager.
	 *
	 * @return void
	 */
	public function register_controls( Controls_Manager $controls_manager ) {
		$controls_manager->register( new Control_Select() );
	}
}
