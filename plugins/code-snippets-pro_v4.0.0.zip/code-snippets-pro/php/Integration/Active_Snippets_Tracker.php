<?php

namespace Code_Snippets\Integration;

/**
 * Per-request register of snippets that actually executed (or emitted output)
 * during the current page load. Read at admin-bar render time to populate the
 * "Ran on this page" menu group.
 *
 * Wires itself to the snippet execution/emission hooks on construction, so no
 * caller records into it directly:
 * - PHP snippets via `code_snippets/after_execute_snippet[_from_flat_file]`
 * - content / asset snippets via `code_snippets/snippet_ran_on_page`
 *
 * Entries are deliberately minimal (id + kind); fresh metadata is read from the
 * database at render time so the listing stays in sync with edits.
 *
 * @package Code_Snippets
 */
final class Active_Snippets_Tracker {

	/**
	 * Snippets recorded this request, keyed by ID so repeats are ignored.
	 *
	 * @var array<int, array{id: int, kind: string}>
	 */
	private array $records = [];

	/**
	 * Register the execution/emission hooks this tracker listens to.
	 */
	public function __construct() {
		add_action( 'code_snippets/after_execute_snippet', [ $this, 'record_executed_snippet' ], 10, 2 );
		add_action( 'code_snippets/after_execute_snippet_from_flat_file', [ $this, 'record_executed_snippet' ], 10, 2 );
		add_action( 'code_snippets/snippet_ran_on_page', [ $this, 'record_output_snippet' ], 10, 2 );
	}

	/**
	 * Record a PHP snippet from the execute hooks. Both the database and
	 * flat-file variants pass the snippet ID as their second argument.
	 *
	 * @param mixed $context Snippet code or file path (unused).
	 * @param mixed $id      Snippet ID.
	 *
	 * @return void
	 */
	public function record_executed_snippet( $context, $id ): void {
		if ( is_int( $id ) ) {
			$this->record( $id, 'php' );
		}
	}

	/**
	 * Record a content/asset snippet from the `code_snippets/snippet_ran_on_page`
	 * hook. Lenient about its arguments since it is a public extension point.
	 *
	 * @param mixed $id   Snippet ID.
	 * @param mixed $kind Execution kind.
	 *
	 * @return void
	 */
	public function record_output_snippet( $id, $kind = 'php' ): void {
		if ( is_int( $id ) ) {
			$this->record( $id, is_string( $kind ) ? $kind : 'php' );
		}
	}

	/**
	 * Record that a snippet ran (or emitted output) on the current request.
	 * Safe to call repeatedly — only the first call per ID is kept.
	 *
	 * @param int    $snippet_id Snippet ID.
	 * @param string $kind       Execution kind: 'php', 'content', 'css', 'js'.
	 *
	 * @return void
	 */
	public function record( int $snippet_id, string $kind = 'php' ): void {
		if ( $snippet_id > 0 && ! isset( $this->records[ $snippet_id ] ) ) {
			$this->records[ $snippet_id ] = [
				'id'   => $snippet_id,
				'kind' => $kind,
			];
		}
	}

	/**
	 * Return all snippets recorded this request.
	 *
	 * @return array<int, array{id: int, kind: string}>
	 */
	public function all(): array {
		return $this->records;
	}

	/**
	 * Return the number of snippets recorded this request.
	 *
	 * @return int
	 */
	public function count(): int {
		return count( $this->records );
	}

	/**
	 * Clear the in-memory record. Primarily for tests.
	 *
	 * @return void
	 */
	public function reset(): void {
		$this->records = [];
	}
}
