<?php

namespace Code_Snippets\Integration;

use WP_Post;
use Code_Snippets\Flat_Files\Snippet_Files;
use Code_Snippets\Model\Snippet;
use Code_Snippets\Utils\Code_Highlighter;
use function Code_Snippets\Conditions\evaluate_condition;
use function Code_Snippets\code_snippets;
use function Code_Snippets\get_snippet;
use function Code_Snippets\Settings\get_setting;
use function Code_Snippets\Utils\validate_network_param;

/**
 * This class manages the shortcodes included with the plugin,
 *
 * @package Code_Snippets
 */
class Shortcodes {

	/**
	 * Name of the shortcode tag for rendering the code source
	 */
	public const SOURCE_SHORTCODE = 'code_snippet_source';

	/**
	 * Name of the shortcode tag for rendering content snippets
	 */
	public const CONTENT_SHORTCODE = 'code_snippet';

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_action( 'the_posts', [ $this, 'enqueue_highlighting' ] );

		add_shortcode( self::CONTENT_SHORTCODE, [ $this, 'render_content_shortcode' ] );
		add_shortcode( self::SOURCE_SHORTCODE, [ $this, 'render_source_shortcode' ] );

		add_filter( 'code_snippets/render_content_shortcode', 'trim' );
	}

	/**
	 * Enqueue the syntax highlighting assets if they are required for the current posts
	 *
	 * @param array<WP_Post|int>|null|false $posts List of currently visible posts.
	 *
	 * @return array<WP_Post|int>|null|false Unchanged list of posts.
	 */
	public function enqueue_highlighting( $posts ) {
		if ( empty( $posts ) || get_setting( 'general', 'disable_prism' ) ) {
			return $posts;
		}

		// Loop through the posts, checking for an existing shortcode, short-circuiting if possible.
		$found_shortcode_content = null;

		foreach ( $posts as $post ) {
			if ( false !== stripos( $post->post_content, '[' . self::SOURCE_SHORTCODE ) ||
			     false !== strpos( $post->post_content, '<!-- wp:code-snippets/source ' ) ) {
				$found_shortcode_content = $post->post_content;
				break;
			}
		}

		// Load assets on the appropriate hook if a matching shortcode was found.
		if ( null !== $found_shortcode_content ) {
			Code_Highlighter::register_prism_assets();

			add_action(
				'wp_enqueue_scripts',
				function () use ( $found_shortcode_content ) {
					foreach ( Code_Highlighter::get_prism_themes() as $theme => $label ) {
						if ( strpos( $found_shortcode_content, "is-style-prism-$theme" ) ) {
							wp_enqueue_style( Code_Highlighter::get_prism_theme_style_handle( $theme ) );
						}
					}

					wp_enqueue_style( Code_Highlighter::PRISM_HANDLE );
					wp_enqueue_script( Code_Highlighter::PRISM_HANDLE );
				},
				100
			);
		}

		return $posts;
	}

	/**
	 * Print a message to the user if the snippet ID attribute is invalid.
	 *
	 * @param int $id Snippet ID.
	 *
	 * @return string Warning message.
	 */
	protected function invalid_id_warning( int $id ): string {
		// translators: %d: snippet ID.
		$text = esc_html__( 'Could not load snippet with an invalid ID: %d.', 'code-snippets' );
		return current_user_can( 'edit_posts' ) ? sprintf( $text, $id ) : '';
	}

	/**
	 * Allow boolean attributes to be provided without a value, similar to how React works.
	 *
	 * @param array<string|number, mixed> $atts          Unfiltered shortcode attributes.
	 * @param array<string>               $boolean_flags List of attribute names with boolean values.
	 *
	 * @return array<string|number, mixed> Shortcode attributes with flags converted to attributes.
	 */
	protected function convert_boolean_attribute_flags( array $atts, array $boolean_flags ): array {
		foreach ( $atts as $key => $value ) {
			if ( in_array( $value, $boolean_flags, true ) && ! isset( $atts[ $value ] ) ) {
				$atts[ $value ] = true;
				unset( $atts[ $key ] );
			}
		}

		return $atts;
	}

	/**
	 * Build the file path for a snippet's flat file.
	 *
	 * @param string  $table_name Table name for the snippet.
	 * @param Snippet $snippet    Snippet object.
	 *
	 * @return string Full file path for the snippet.
	 */
	private function build_snippet_flat_file_path( string $table_name, Snippet $snippet ): string {
		$handler = code_snippets()->snippet_handler_registry->get_handler( $snippet->get_type() );

		return Snippet_Files::get_base_dir( $table_name, $handler->get_dir_name() ) . '/' . $snippet->id . '.' . $handler->get_file_extension();
	}

	/**
	 * Evaluate the code from a content shortcode.
	 *
	 * @param Snippet              $snippet Snippet.
	 * @param array<string, mixed> $atts    Shortcode attributes.
	 *
	 * @return string Evaluated shortcode content.
	 */
	protected function evaluate_shortcode_content( Snippet $snippet, array $atts ): string {
		if ( empty( $atts['php'] ) ) {
			return $snippet->code;
		}

		if ( ! Snippet_Files::is_active() ) {
			return $this->evaluate_shortcode_from_db( $snippet, $atts );
		}

		$network = validate_network_param( $snippet->network );
		$table_name = Snippet_Files::get_hashed_table_name( code_snippets()->db->get_table_name( $network ) );
		$filepath = $this->build_snippet_flat_file_path( $table_name, $snippet );

		return file_exists( $filepath )
			? $this->evaluate_shortcode_from_flat_file( $filepath, $atts )
			: $this->evaluate_shortcode_from_db( $snippet, $atts );
	}

	/**
	 * Evaluate a snippet by evaluating its code as a string.
	 *
	 * @param Snippet $snippet Snippet to execute.
	 * @param array   $atts    Shortcode attributes.
	 *
	 * @return string Snippet output.
	 *
	 * phpcs:disable Squiz.PHP.Eval.Discouraged
	 */
	private function evaluate_shortcode_from_db( Snippet $snippet, array $atts ): string {
		/**
		 * Avoiding extract is typically recommended, however in this situation we want to make it easy for snippet
		 * authors to use custom attributes.
		 *
		 * phpcs:disable WordPress.PHP.DontExtract.extract_extract
		 */
		extract( $atts, EXTR_SKIP );

		ob_start();
		eval( "?>\n\n" . $snippet->code );

		return ob_get_clean();
	}

	/**
	 * Check if being rendered within the block editor.
	 *
	 * @return bool True if in the block editor, false otherwise.
	 */
	private function is_block_editor(): bool {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		return $screen && method_exists( $screen, 'is_block_editor' ) && $screen->is_block_editor();
	}

	/**
	 * Evaluate a snippet by loading its code from the filesystem.
	 *
	 * @param string $filepath Path to file to evaluate.
	 * @param array  $atts     Shortcode attributes.
	 *
	 * @return string Snippet output.
	 */
	private function evaluate_shortcode_from_flat_file( string $filepath, array $atts ): string {
		ob_start();

		( function ( $atts ) use ( $filepath ) {
			/**
			 * Avoiding extract is typically recommended, however in this situation we want to make it easy for snippet
			 * authors to use custom attributes.
			 *
			 * phpcs:ignore WordPress.PHP.DontExtract.extract_extract
			 */
			extract( $atts, EXTR_SKIP );
			require_once $filepath;
		} )( $atts );

		return ob_get_clean();
	}

	/**
	 * Retrieve a content snippet from the filesystem or the database.
	 *
	 * @param int  $id      Snippet identifier.
	 * @param bool $network Whether the snippet is network-wide.
	 *
	 * @return Snippet|null
	 */
	private function get_snippet( int $id, bool $network ): ?Snippet {
		if ( ! Snippet_Files::is_active() ) {
			return get_snippet( $id, $network );
		}

		$validated_network = validate_network_param( $network );
		$table_name = Snippet_Files::get_hashed_table_name( code_snippets()->db->get_table_name( $validated_network ) );
		$handler = code_snippets()->snippet_handler_registry->get_handler( 'html' );
		$config_filepath = Snippet_Files::get_base_dir( $table_name, $handler->get_dir_name() ) . '/index.php';

		if ( file_exists( $config_filepath ) ) {
			$config = require_once $config_filepath;
			$snippet_data = $config[ $id ] ?? null;

			if ( $snippet_data ) {
				$snippet = new Snippet( $snippet_data );
				return apply_filters( 'code_snippets/get_snippet', $snippet, $id, $network );
			}
		}

		return get_snippet( $id, $network );
	}

	/**
	 * Render the value of a content shortcode
	 *
	 * @param array<string, mixed> $atts Shortcode attributes.
	 *
	 * @return string Shortcode content.
	 */
	public function render_content_shortcode( array $atts ): string {
		$atts = $this->convert_boolean_attribute_flags( $atts, [ 'network', 'php', 'format', 'shortcodes', 'debug' ] );
		$original_atts = $atts;

		$atts = shortcode_atts(
			[
				'id'         => 0,
				'snippet_id' => 0,
				'network'    => false,
				'php'        => false,
				'format'     => false,
				'shortcodes' => false,
				'debug'      => $this->is_block_editor(),
			],
			$atts,
			self::CONTENT_SHORTCODE
		);

		$id = 0 !== intval( $atts['snippet_id'] ) ? intval( $atts['snippet_id'] ) : intval( $atts['id'] );
		if ( ! $id ) {
			return $this->invalid_id_warning( $id );
		}

		$snippet = $this->get_snippet( $id, (bool) $atts['network'] );

		// Render the source code if this is not a shortcode snippet.
		if ( 'content' !== $snippet->scope ) {
			return $snippet->id ? $this->render_snippet_source( $snippet ) : $this->invalid_id_warning( $snippet->id );
		}

		// If the snippet is inactive, either display a message or render nothing.
		if ( ! $snippet->active ) {
			if ( $atts['debug'] ) {
				/* translators: 1: snippet name, 2: snippet edit link */
				$text = __( '%1$s is currently inactive. You can <a href="%2$s">edit this snippet</a> to activate it and make it visible. This message will not appear in the published post.', 'code-snippets' );
				$snippet_name = '<strong>' . $snippet->name . '</strong>';
				$edit_url = add_query_arg( 'id', $snippet->id, code_snippets()->get_menu_url( 'edit' ) );

				$message = wp_kses(
					sprintf( $text, $snippet_name, $edit_url ),
					[
						'strong' => [],
						'a'      => [
							'href' => [],
						],
					]
				);

				return "<p>$message</p><p>" . esc_html__( 'This message will not appear in the published post.', 'code-snippets' ) . '</p>';
			} else {
				return '';
			}
		}

		if ( $snippet->condition_id && ! $this->is_block_editor() ) {
			$condition = $this->get_content_snippet( $snippet->condition_id, $snippet->network );

			if ( $condition && ! evaluate_condition( $condition->code ) ) {
				return '';
			}
		}

		$content = $this->evaluate_shortcode_content( $snippet, $original_atts );

		if ( $atts['format'] ) {
			$functions = [ 'wptexturize', 'convert_smilies', 'convert_chars', 'wpautop', 'capital_P_dangit' ];
			foreach ( $functions as $function ) {
				$content = call_user_func( $function, $content );
			}
		}

		if ( $atts['shortcodes'] ) {
			// Temporarily remove this shortcode from the list to prevent recursion while executing do_shortcode.
			remove_shortcode( self::CONTENT_SHORTCODE );
			$content = do_shortcode( $atts['format'] ? shortcode_unautop( $content ) : $content );
			add_shortcode( self::CONTENT_SHORTCODE, [ $this, 'render_content_shortcode' ] );
		}

		return apply_filters( 'code_snippets/content_shortcode', $content, $snippet, $atts, $original_atts );
	}

	/**
	 * Converts a value and key into an HTML attribute pair.
	 *
	 * @param string $value Attribute value.
	 * @param string $key   Attribute name.
	 *
	 * @return void
	 */
	private static function create_attribute_pair( string &$value, string $key ) {
		$value = sprintf( '%s="%s"', sanitize_key( $key ), esc_attr( $value ) );
	}

	/**
	 * Render the source code of a given snippet
	 *
	 * @param Snippet              $snippet Snippet object.
	 * @param array<string, mixed> $atts    Shortcode attributes.
	 *
	 * @return string Shortcode content.
	 */
	private function render_snippet_source( Snippet $snippet, array $atts = [] ): string {
		$atts = array_merge(
			array(
				'line_numbers'    => false,
				'highlight_lines' => '',
			),
			$atts
		);

		$language = 'css' === $snippet->type ? 'css' : ( 'js' === $snippet->type ? 'js' : 'php' );

		$pre_attributes = array(
			'id'    => "code-snippet-source-$snippet->id",
			'class' => 'code-snippet-source',
		);

		$code_attributes = array(
			'class' => "language-$language",
		);

		if ( $atts['line_numbers'] ) {
			$code_attributes['class'] .= ' line-numbers';
			$pre_attributes['class'] .= ' linkable-line-numbers';
		}

		if ( $atts['highlight_lines'] ) {
			$pre_attributes['data-line'] = $atts['highlight_lines'];
		}

		$pre_attributes = apply_filters( 'code_snippets/prism_pre_attributes', $pre_attributes, $snippet, $atts );
		$code_attributes = apply_filters( 'code_snippets/prism_code_attributes', $code_attributes, $snippet, $atts );

		array_walk( $code_attributes, array( $this, 'create_attribute_pair' ) );
		array_walk( $pre_attributes, array( $this, 'create_attribute_pair' ) );

		$code = 'php' === $snippet->type ? "<?php\n\n$snippet->code" : $snippet->code;

		$output = sprintf(
			'<pre %s><code %s>%s</code></pre>',
			implode( ' ', $pre_attributes ),
			implode( ' ', $code_attributes ),
			esc_html( $code )
		);

		return apply_filters( 'code_snippets/render_source_shortcode', $output, $snippet, $atts );
	}

	/**
	 * Render the value of a source shortcode
	 *
	 * @param array<string, mixed> $atts Shortcode attributes.
	 *
	 * @return string Shortcode content.
	 */
	public function render_source_shortcode( array $atts ): string {
		$atts = $this->convert_boolean_attribute_flags( $atts, [ 'network', 'line_numbers' ] );

		$atts = shortcode_atts(
			array(
				'id'              => 0,
				'snippet_id'      => 0,
				'network'         => false,
				'line_numbers'    => false,
				'highlight_lines' => '',
			),
			$atts,
			self::SOURCE_SHORTCODE
		);

		$id = 0 !== intval( $atts['snippet_id'] ) ? intval( $atts['snippet_id'] ) : intval( $atts['id'] );
		if ( ! $id ) {
			return $this->invalid_id_warning( $id );
		}

		$snippet = $this->get_snippet( $id, (bool) $atts['network'] );
		return $this->render_snippet_source( $snippet, $atts );
	}
}
