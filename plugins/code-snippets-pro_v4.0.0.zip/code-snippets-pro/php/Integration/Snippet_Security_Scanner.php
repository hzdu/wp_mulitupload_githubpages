<?php

namespace Code_Snippets\Integration;

/**
 * Static-analysis pass over a PHP snippet's body, flagging patterns
 * commonly associated with security vulnerabilities or malicious code.
 *
 * The scanner is intentionally regex-based for v1: cheap, dependency-free,
 * and easy to extend. An AST-based replacement (php-parser) is a v2 ask
 * for higher accuracy.
 *
 * Findings are advisory — they do not block saves. The user is responsible
 * for reviewing each one and either fixing or dismissing it.
 *
 * Output shape per finding:
 *
 *   [
 *     'rule'     => 'eval_use',
 *     'severity' => 'high'|'medium'|'low',
 *     'line'     => 12,
 *     'excerpt'  => 'eval($user_input);',
 *     'title'    => 'Use of eval()',
 *     'message'  => 'eval() runs arbitrary PHP. Especially risky inside ...',
 *   ]
 *
 * @package Code_Snippets
 */
final class Snippet_Security_Scanner {

	public const SEVERITY_HIGH = 'high';
	public const SEVERITY_MEDIUM = 'medium';
	public const SEVERITY_LOW = 'low';

	private const OPTION_NAME = 'code_snippets_security_findings';

	/**
	 * Each rule is [regex, severity, key, title, message].
	 * Regexes are case-insensitive and run line-by-line.
	 *
	 * @return array<int, array{0: string, 1: string, 2: string, 3: string, 4: string}>
	 */
	private static function rules(): array {
		return [
			// --- HIGH: nested code-eval ---
			[
				'/\beval\s*\(/i',
				self::SEVERITY_HIGH,
				'eval_use',
				'Use of eval()',
				'Calls eval() inside a snippet (which is itself eval\'d). Any user-supplied data reaching this eval is an arbitrary code execution risk.',
			],
			[
				'/\bassert\s*\(\s*[\'"]/i',
				self::SEVERITY_HIGH,
				'assert_string',
				'Use of assert() with a string argument',
				'assert() with a string argument behaves like eval(). Use a boolean expression instead.',
			],
			[
				'/\bcreate_function\s*\(/i',
				self::SEVERITY_HIGH,
				'create_function',
				'Use of create_function()',
				'create_function() is deprecated and behaves like eval(). Replace with an anonymous function (closure).',
			],
			[
				'/\bpreg_replace\s*\(\s*[\'"][^\'"]*\/[a-z]*e[a-z]*[\'"]/i',
				self::SEVERITY_HIGH,
				'preg_replace_e',
				'preg_replace with /e modifier',
				'The /e modifier evaluates the replacement as PHP code. Removed in PHP 7. Use preg_replace_callback instead.',
			],
			// --- HIGH: command execution ---
			[
				'/\b(shell_exec|system|exec|passthru|proc_open|popen)\s*\(/i',
				self::SEVERITY_HIGH,
				'shell_exec',
				'Direct command execution',
				'Calls the shell. Any user-controlled value reaching this call is a remote-code-execution vector.',
			],
			// --- MEDIUM: obfuscation ---
			[
				'/\bbase64_decode\s*\(/i',
				self::SEVERITY_MEDIUM,
				'base64_decode',
				'Use of base64_decode()',
				'Often used to hide payloads in malicious snippets. Legitimate uses exist (e.g. decoding binary blobs); review and dismiss if intentional.',
			],
			// --- MEDIUM: symbol-table poisoning ---
			[
				'/\bextract\s*\(\s*\$(_GET|_POST|_REQUEST|_COOKIE|_SERVER)/i',
				self::SEVERITY_MEDIUM,
				'extract_super',
				'extract() on a superglobal',
				'Lets attackers overwrite any local variable by sending crafted request params.',
			],
			// --- MEDIUM: dynamic includes ---
			[
				'/\b(include|require|include_once|require_once)\s*\(?\s*\$/i',
				self::SEVERITY_MEDIUM,
				'dynamic_include',
				'include/require with a variable path',
				'Including a file based on a variable can become a Local File Inclusion bug if the variable is user-influenced.',
			],
			// --- MEDIUM: credentials ---
			[
				'/AKIA[0-9A-Z]{16}/',
				self::SEVERITY_MEDIUM,
				'aws_access_key',
				'Hard-coded AWS access key',
				'Looks like an AWS access key. Credentials in code get committed, leaked, or shared by accident — store in wp-config or env.',
			],
			[
				'/\b(password|passwd|secret|api[_-]?key|token)\s*=\s*[\'"][^\'"\s]{8,}[\'"]/i',
				self::SEVERITY_MEDIUM,
				'hardcoded_credential',
				'Looks like a hard-coded credential',
				'A variable named like a credential is being assigned a literal value. Move secrets to wp-config or environment variables.',
			],
			// --- LOW: input handling ---
			[
				'/\$_(?:GET|POST|REQUEST|COOKIE)\s*\[/',
				self::SEVERITY_LOW,
				'raw_superglobal',
				'Direct superglobal access',
				'Reading $_GET/$_POST etc. without sanitization. Always run user input through sanitize_text_field(), absint(), etc.',
			],
			// --- LOW: error hiding ---
			[
				'/@\s*[a-zA-Z_]/',
				self::SEVERITY_LOW,
				'error_suppression',
				'@ error-suppression operator',
				'Hides errors from logs. Prefer explicit try/catch or function_exists() checks.',
			],
			[
				'/\berror_reporting\s*\(\s*0\s*\)/i',
				self::SEVERITY_LOW,
				'error_reporting_off',
				'error_reporting(0)',
				'Silencing all errors makes problems harder to diagnose. Use targeted error handling instead.',
			],
		];
	}

	/**
	 * Scan a snippet's PHP code body and return any findings.
	 *
	 * @param string $code PHP code (no opening tag).
	 *
	 * @return array<int, array{rule: string, severity: string, line: int, excerpt: string, title: string, message: string}>
	 */
	public static function scan( string $code ): array {
		if ( '' === trim( $code ) ) {
			return [];
		}

		$findings = [];
		$lines = preg_split( '/\R/', $code );
		if ( ! is_array( $lines ) ) {
			return [];
		}

		foreach ( $lines as $i => $line ) {
			$line_no = $i + 1;
			$trimmed = trim( $line );

			// Skip pure-comment lines so we don't flag rule code in
			// the user's snippet's own comments. Crude but cheap.
			if ( '' === $trimmed ) {
				continue;
			}
			if ( str_starts_with( $trimmed, '//' ) || str_starts_with( $trimmed, '#' ) ) {
				continue;
			}

			foreach ( self::rules() as $rule ) {
				[ $regex, $severity, $key, $title, $message ] = $rule;
				if ( preg_match( $regex, $line ) ) {
					$findings[] = [
						'rule'     => $key,
						'severity' => $severity,
						'line'     => $line_no,
						'excerpt'  => mb_substr( $trimmed, 0, 160 ),
						'title'    => $title,
						'message'  => $message,
					];
				}
			}
		}

		return $findings;
	}

	/**
	 * Sort key for ordering findings by severity then line number.
	 *
	 * @param string $severity Severity constant.
	 *
	 * @return int Higher = more severe.
	 */
	public static function severity_rank( string $severity ): int {
		switch ( $severity ) {
			case self::SEVERITY_HIGH:
				return 3;
			case self::SEVERITY_MEDIUM:
				return 2;
			case self::SEVERITY_LOW:
				return 1;
			default:
				return 0;
		}
	}

	/**
	 * All findings, keyed by snippet ID.
	 *
	 * @return array<int, array<int, array<string, mixed>>>
	 */
	public static function get_all_findings(): array {
		$all = get_option( self::OPTION_NAME, [] );
		return is_array( $all ) ? $all : [];
	}

	/**
	 * Findings for a single snippet (open + dismissed both included).
	 *
	 * @param int $snippet_id Snippet ID.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_findings( int $snippet_id ): array {
		$all = self::get_all_findings();
		return isset( $all[ $snippet_id ] ) && is_array( $all[ $snippet_id ] ) ? $all[ $snippet_id ] : [];
	}

	/**
	 * Re-scan a single snippet's code, preserving dismissed flags
	 * for any findings that survive the re-scan (matched by rule:line).
	 *
	 * @param int    $snippet_id Snippet ID.
	 * @param string $code       Snippet code.
	 *
	 * @return void
	 */
	public static function update_for_snippet( int $snippet_id, string $code ): void {
		$fresh = self::scan( $code );
		$all   = self::get_all_findings();

		$prior_dismissed = [];
		if ( isset( $all[ $snippet_id ] ) && is_array( $all[ $snippet_id ] ) ) {
			foreach ( $all[ $snippet_id ] as $row ) {
				if ( ! empty( $row['dismissed'] ) ) {
					$prior_dismissed[ $row['rule'] . ':' . (int) $row['line'] ] = true;
				}
			}
		}

		if ( empty( $fresh ) ) {
			unset( $all[ $snippet_id ] );
		} else {
			$all[ $snippet_id ] = array_map(
				static function ( $row ) use ( $prior_dismissed ): array {
					$key              = $row['rule'] . ':' . (int) $row['line'];
					$row['dismissed'] = isset( $prior_dismissed[ $key ] );
					return $row;
				},
				$fresh
			);
		}

		update_option( self::OPTION_NAME, $all, false );
	}

	/**
	 * Walk every PHP snippet and rescan it.
	 *
	 * @return int Number of snippets scanned.
	 */
	public static function rescan_all(): int {
		if ( ! function_exists( __NAMESPACE__ . '\\..\\get_snippets' ) && ! function_exists( 'Code_Snippets\\get_snippets' ) ) {
			return 0;
		}
		$snippets = \Code_Snippets\get_snippets();
		$count    = 0;
		foreach ( $snippets as $snippet ) {
			if ( 'php' !== $snippet->type ) {
				continue;
			}
			self::update_for_snippet( (int) $snippet->id, (string) $snippet->code );
			++$count;
		}
		return $count;
	}

	/**
	 * Mark a single finding as dismissed.
	 *
	 * @param int    $snippet_id Snippet ID.
	 * @param string $rule       Rule key.
	 * @param int    $line       Line number.
	 *
	 * @return bool True if a finding was updated.
	 */
	public static function dismiss( int $snippet_id, string $rule, int $line ): bool {
		$all = self::get_all_findings();
		if ( ! isset( $all[ $snippet_id ] ) || ! is_array( $all[ $snippet_id ] ) ) {
			return false;
		}
		$changed = false;
		foreach ( $all[ $snippet_id ] as $idx => $row ) {
			if ( $row['rule'] === $rule && (int) $row['line'] === $line ) {
				$all[ $snippet_id ][ $idx ]['dismissed'] = true;
				$changed                                 = true;
			}
		}
		if ( $changed ) {
			update_option( self::OPTION_NAME, $all, false );
		}
		return $changed;
	}
}
