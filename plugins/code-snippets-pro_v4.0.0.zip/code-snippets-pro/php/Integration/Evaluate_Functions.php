<?php

namespace Code_Snippets\Integration;

use Code_Snippets\Core\DB;
use Code_Snippets\Flat_Files\Snippet_Files;
use Code_Snippets\REST_API\Snippets\Snippets_REST_Controller;
use function Code_Snippets\clean_active_snippets_cache;
use function Code_Snippets\clean_snippets_cache;
use function Code_Snippets\Conditions\evaluate_condition;
use function Code_Snippets\code_snippets;
use function Code_Snippets\execute_snippet;
use function Code_Snippets\execute_snippet_from_flat_file;

/**
 * Class for evaluating functions snippets.
 *
 * @package Code_Snippets
 */
class Evaluate_Functions {

	/**
	 * Database class.
	 *
	 * @var DB
	 */
	private DB $db;

	/**
	 * Snippets with an attached condition that should be evaluated later.
	 *
	 * @var array[]
	 */
	private array $snippets_with_condition = [];

	/**
	 * List of conditions that should be evaluated later.
	 *
	 * @var array[]
	 */
	private array $conditions = [];

	/**
	 * Class constructor.
	 *
	 * @param DB $db Database class instance.
	 */
	public function __construct( DB $db ) {
		$this->db = $db;
		add_action( 'plugins_loaded', [ $this, 'evaluate_early' ], 1 );
		add_action( 'wp', [ $this, 'evaluate_conditional_snippets' ], 1 );
		add_action( 'admin_init', [ $this, 'evaluate_conditional_snippets' ], 1 );
		add_filter( 'code_snippets/execute_snippets', [ $this, 'disable_snippet_execution' ], 5 );

		// Only the query var is inspected here. This constructor runs while
		// plugins are still being included, which is before WordPress loads
		// pluggable.php, so a capability check at this point would call an
		// undefined wp_get_current_user() and take the whole request down.
		// The capability is checked in the callback instead, which never runs
		// before URLs are being generated.
		if ( $this->is_safe_mode_query_var_set() ) {
			add_filter( 'home_url', [ $this, 'add_safe_mode_query_var' ] );
			add_filter( 'admin_url', [ $this, 'add_safe_mode_query_var' ] );
		}
	}

	/**
	 * Check whether the safe mode query var is present on this request.
	 *
	 * Safe to call at any point, as it reads nothing but the request.
	 *
	 * @return bool
	 */
	public function is_safe_mode_query_var_set(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return ! empty( $_REQUEST['snippets-safe-mode'] );
	}

	/**
	 * Check if safe mode has been requested via query var.
	 *
	 * Performs a capability check, so must not be called before pluggable
	 * functions are available.
	 *
	 * @return bool
	 */
	public function is_safe_mode_requested(): bool {
		return $this->is_safe_mode_query_var_set() && code_snippets()->current_user_can();
	}

	/**
	 * Inject the safe mode query var into URLs
	 *
	 * @param mixed $url Original URL, from an unknown earlier callback.
	 *
	 * @return string Modified URL.
	 */
	public function add_safe_mode_query_var( $url ): string {
		$url = is_string( $url ) ? $url : '';

		return $this->is_safe_mode_requested() ?
			add_query_arg( 'snippets-safe-mode', true, $url ) :
			$url;
	}

	/**
	 * Retrieve details about the currently edited snippet, if any.
	 *
	 * @return ?array{id: int, table: string}
	 */
	private function get_currently_editing_snippet(): ?array {
		if ( wp_is_json_request() && ! empty( $_SERVER['REQUEST_URI'] ) ) {
			$url = wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) );

			if ( isset( $url['path'] ) && false !== strpos( $url['path'], Snippets_REST_Controller::get_prefixed_base_route() ) ) {
				$path_parts = explode( '/', $url['path'] );
				$edit_id = intval( end( $path_parts ) );

				if ( ! empty( $url['query'] ) ) {
					wp_parse_str( $url['query'], $path_params );
					$edit_table = isset( $path_params['network'] ) && rest_sanitize_boolean( $path_params['network'] )
						? $this->db->ms_table
						: $this->db->table;
				}

				return [
					'id'    => $edit_id,
					'table' => $edit_table ?? $this->db->table,
				];
			}
		}

		return null;
	}

	/**
	 * Check if the plugin is running in safe mode.
	 *
	 * @return bool
	 *
	 * @noinspection PhpUndefinedConstantInspection
	 */
	public static function is_safe_mode_active(): bool {
		return ( defined( 'CODE_SNIPPETS_SAFE_MODE' ) && CODE_SNIPPETS_SAFE_MODE ) ||
		       ! apply_filters( 'code_snippets/execute_snippets', true );
	}

	/**
	 * Disable snippet execution if the necessary query var is set.
	 *
	 * @param mixed $execute_snippets Current filter value, from an unknown
	 *                                earlier callback.
	 *
	 * @return bool New filter value.
	 */
	public function disable_snippet_execution( $execute_snippets ): bool {
		return $execute_snippets && ! $this->is_safe_mode_requested();
	}

	/**
	 * Quickly deactivate a snippet with minimal overhead.
	 *
	 * @param int    $snippet_id ID of the snippet to deactivate.
	 * @param string $table_name Name of the table where the snippet is stored.
	 *
	 * @return void
	 */
	private function quick_deactivate_snippet( int $snippet_id, string $table_name ) {
		global $wpdb;

		$active_shared_ids = get_option( 'active_shared_network_snippets', [] );
		$active_shared_ids = is_array( $active_shared_ids )
			? array_map( 'intval', $active_shared_ids )
			: [];

		if ( $table_name === $this->db->ms_table && in_array( $snippet_id, $active_shared_ids, true ) ) {
			unset( $active_shared_ids[ array_search( $snippet_id, $active_shared_ids, true ) ] );
			$active_shared_ids = array_values( $active_shared_ids );
			update_option( 'active_shared_network_snippets', $active_shared_ids );
			clean_active_snippets_cache( $table_name );
		} else {
			$wpdb->update(
				$table_name,
				[ 'active' => '0' ],
				[ 'id' => $snippet_id ],
				[ '%d' ],
				[ '%d' ]
			);
			clean_snippets_cache( $table_name );

			$network = $table_name === $this->db->ms_table;
			do_action( 'code_snippets/deactivate_snippet', $snippet_id, $network );
		}
	}

	/**
	 * Evaluate a snippet.
	 *
	 * @param array       $snippet      Snippet data.
	 * @param string|null $file_path    Path to the snippet file, or null if executing from the database.
	 * @param array|null  $edit_snippet Data of snippet currently being edited, if applicable.
	 *
	 * @return void
	 */
	private function evaluate_snippet( array $snippet, ?string $file_path, ?array $edit_snippet ) {
		$snippet_id = $snippet['id'];
		$code = $snippet['code'];
		$table_name = $snippet['table'];

		// If the snippet is a single-use snippet, deactivate it before execution to ensure that the process always happens.
		if ( 'single-use' === $snippet['scope'] ) {
			$this->quick_deactivate_snippet( $snippet_id, $table_name );
		}

		if ( ! is_null( $edit_snippet ) && $edit_snippet['id'] === $snippet_id && $edit_snippet['table'] === $table_name ) {
			return;
		}

		if ( apply_filters( 'code_snippets/allow_execute_snippet', true, $snippet_id, $table_name ) ) {
			if ( is_null( $file_path ) ) {
				execute_snippet( $code, $snippet_id );
			} else {
				execute_snippet_from_flat_file( $code, $file_path, $snippet_id );
			}
		}
	}

	/**
	 * Evaluate applicable active snippets as early as possible.
	 *
	 * @return bool True if snippets were evaluated, false if safe mode is active.
	 */
	public function evaluate_early(): bool {
		if ( self::is_safe_mode_active() ) {
			return false;
		}

		if ( Snippet_Files::is_active() ) {
			return $this->evaluate_file_snippets();
		}

		return $this->evaluate_db_snippets();
	}
	/**
	 * Evaluate active snippets stored in the database.
	 *
	 * @return bool True on completion.
	 */
	public function evaluate_db_snippets(): bool {
		$scopes = [ 'global', 'single-use', is_admin() ? 'admin' : 'front-end', 'condition' ];
		$active_snippets = $this->db->fetch_active_snippets( $scopes );
		$edit_snippet = $this->get_currently_editing_snippet();

		foreach ( $active_snippets as $snippet ) {
			if ( 'condition' === $snippet['scope'] ) {
				$this->conditions[] = $snippet;
			} elseif ( 0 !== $snippet['condition_id'] ) {
				$this->snippets_with_condition[] = $snippet;
			} else {
				$this->evaluate_snippet( $snippet, null, $edit_snippet );
			}
		}

		return true;
	}

	/**
	 * Evaluate active snippets stored in flat files.
	 *
	 * @return bool True on completion.
	 */
	private function evaluate_file_snippets(): bool {
		$type = 'php';
		$scopes = [ 'global', 'single-use', is_admin() ? 'admin' : 'front-end' ];
		$snippets = Snippet_Files::get_active_snippets_from_flat_files( $scopes, $type );
		$conditions = Snippet_Files::get_active_snippets_from_flat_files( [ 'condition' ], 'cond' );
		$active_snippets = array_merge( $snippets, $conditions );
		$edit_snippet = $this->get_currently_editing_snippet();

		foreach ( $active_snippets as $snippet ) {
			if ( 'condition' === $snippet['scope'] ) {
				$this->conditions[] = $snippet;
			} elseif ( 0 !== $snippet['condition_id'] ) {
				$this->snippets_with_condition[] = $snippet;
			} else {
				$table_name = Snippet_Files::get_hashed_table_name( $snippet['table'] );
				$base_path = Snippet_Files::get_base_dir( $table_name, $type );
				$file = $base_path . '/' . $snippet['id'] . '.' . $type;

				$this->evaluate_snippet( $snippet, $file, $edit_snippet );
			}
		}

		return true;
	}

	/**
	 * Evaluate conditional snippets on the 'wp' action.
	 *
	 * @return void
	 */
	public function evaluate_conditional_snippets() {
		if ( self::is_safe_mode_active() ) {
			return;
		}

		$condition_results = [];

		foreach ( $this->conditions as $condition ) {
			$condition_results[ $condition['id'] ] = evaluate_condition( $condition['code'] );
		}

		foreach ( $this->snippets_with_condition as $snippet ) {
			$condition_id = $snippet['condition_id'];

			if ( isset( $condition_results[ $condition_id ] ) ) {
				if ( $condition_results[ $condition_id ] ) {
					$this->evaluate_snippet( $snippet, null, null );
				}
			}
		}
	}
}
