<?php

namespace Code_Snippets\Integration;

/**
 * Capture execution timing for PHP snippets, both for the current request
 * (live, in-memory) and aggregated across requests (persisted to a single
 * WP option).
 *
 * Live view: read while the same request is still running, e.g. by the
 * admin bar to show "this snippet took 0.42 ms on this page". Aggregate
 * view: stable history shown on the Performance admin page and the snippets
 * list column.
 *
 * Storage: a single option `code_snippets_perf_stats` keyed by snippet id.
 * Per snippet we keep:
 *   - last_ms      Most-recent measured duration
 *   - max_ms       Highest seen
 *   - ema_ms       Exponential moving average (alpha=0.2 — favours recency)
 *   - samples      Total exec count since stats last reset
 *   - updated      Unix timestamp of last write
 *
 * Stats are reset when a snippet's code changes (revision bump) so old
 * timings don't muddy comparisons after edits.
 *
 * @package Code_Snippets
 */
final class Snippet_Performance_Tracker {

	private const OPTION_NAME = 'code_snippets_perf_stats';
	private const EMA_ALPHA = 0.2;

	/**
	 * Snippet ID => microtime(true) of when execution started.
	 *
	 * @var array<int, float>
	 */
	private static array $starts = [];

	/**
	 * Snippet ID => elapsed milliseconds for the current request.
	 *
	 * @var array<int, float>
	 */
	private static array $live = [];

	/**
	 * Tracks whether the per-request shutdown flush hook has been registered.
	 *
	 * @var bool
	 */
	private static bool $flush_registered = false;

	/**
	 * Begin timing a snippet execution.
	 *
	 * @param int $snippet_id Snippet ID.
	 *
	 * @return void
	 */
	public static function start( int $snippet_id ): void {
		if ( $snippet_id <= 0 || ! self::is_enabled() ) {
			return;
		}
		self::$starts[ $snippet_id ] = microtime( true );
	}

	/**
	 * Whether the tracker is currently enabled. Controlled by the
	 * "Track Snippet Performance" setting under General. Defaults to off
	 * since it adds a tiny per-snippet overhead and one option write per
	 * page render.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		if ( ! function_exists( '\\Code_Snippets\\Settings\\get_setting' ) ) {
			return false;
		}
		return (bool) \Code_Snippets\Settings\get_setting( 'general', 'enable_performance_tracker' );
	}

	/**
	 * Finish timing a snippet execution. Records the elapsed milliseconds
	 * into the live in-memory map (last wins) and updates the persisted
	 * aggregate row for this snippet.
	 *
	 * @param int $snippet_id Snippet ID.
	 *
	 * @return void
	 */
	public static function stop( int $snippet_id ): void {
		if ( $snippet_id <= 0 || ! isset( self::$starts[ $snippet_id ] ) ) {
			return;
		}

		$elapsed_ms = ( microtime( true ) - self::$starts[ $snippet_id ] ) * 1000;
		unset( self::$starts[ $snippet_id ] );

		self::$live[ $snippet_id ] = $elapsed_ms;

		// Defer the option write until shutdown so we coalesce all
		// snippet timings for this request into a single update_option()
		// call instead of one per snippet exec.
		if ( ! self::$flush_registered && function_exists( 'add_action' ) ) {
			self::$flush_registered = true;
			add_action( 'shutdown', [ self::class, 'flush' ], 99 );
		}
	}

	/**
	 * Persist all live samples captured during this request to the
	 * option store, merging into existing per-snippet stats.
	 *
	 * @return void
	 */
	public static function flush(): void {
		if ( empty( self::$live ) ) {
			return;
		}

		$all = self::all_stats();

		foreach ( self::$live as $snippet_id => $elapsed_ms ) {
			$existing = $all[ $snippet_id ] ?? null;

			$max_ms = $existing ? max( (float) $existing['max_ms'], $elapsed_ms ) : $elapsed_ms;
			$ema_ms = $existing
				? ( self::EMA_ALPHA * $elapsed_ms ) + ( ( 1 - self::EMA_ALPHA ) * (float) $existing['ema_ms'] )
				: $elapsed_ms;
			$samples = $existing ? (int) $existing['samples'] + 1 : 1;

			$all[ $snippet_id ] = [
				'last_ms' => round( $elapsed_ms, 3 ),
				'max_ms'  => round( $max_ms, 3 ),
				'ema_ms'  => round( $ema_ms, 3 ),
				'samples' => $samples,
				'updated' => time(),
			];
		}

		update_option( self::OPTION_NAME, $all, false );
	}

	/**
	 * Return live (current-request) duration for a snippet, in milliseconds,
	 * or null if it hasn't been recorded this request.
	 *
	 * @param int $snippet_id Snippet ID.
	 *
	 * @return float|null
	 */
	public static function live_ms( int $snippet_id ): ?float {
		return self::$live[ $snippet_id ] ?? null;
	}

	/**
	 * Return every live timing recorded for the current request.
	 *
	 * @return array<int, float> Snippet id => live ms recorded this request.
	 */
	public static function all_live(): array {
		return self::$live;
	}

	/**
	 * Return the aggregated stats row for a single snippet, or null if no
	 * data has been recorded yet.
	 *
	 * @param int $snippet_id Snippet ID.
	 *
	 * @return array{last_ms: float, max_ms: float, ema_ms: float, samples: int, updated: int}|null
	 */
	public static function stats( int $snippet_id ): ?array {
		$all = self::all_stats();
		return $all[ $snippet_id ] ?? null;
	}

	/**
	 * Return the entire persisted stats map.
	 *
	 * @return array<int, array{last_ms: float, max_ms: float, ema_ms: float, samples: int, updated: int}>
	 */
	public static function all_stats(): array {
		$raw = get_option( self::OPTION_NAME, [] );
		return is_array( $raw ) ? $raw : [];
	}

	/**
	 * Clear all persisted stats for a snippet — invoked when the snippet's
	 * code changes so historic timings don't carry forward stale comparisons.
	 *
	 * @param int $snippet_id Snippet ID.
	 *
	 * @return void
	 */
	public static function reset( int $snippet_id ): void {
		$all = self::all_stats();
		if ( ! isset( $all[ $snippet_id ] ) ) {
			return;
		}
		unset( $all[ $snippet_id ] );
		update_option( self::OPTION_NAME, $all, false );
	}

	/**
	 * Reset every snippet's stats. Exposed for tests + the Performance
	 * admin page's "Reset all" button.
	 *
	 * @return void
	 */
	public static function reset_all(): void {
		delete_option( self::OPTION_NAME );
		self::$live = [];
		self::$starts = [];
	}
}
