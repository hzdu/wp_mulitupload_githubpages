<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\REST_API\REST_Collection_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;
use const Code_Snippets\PLUGIN_VERSION;

/**
 * Exposes the site's plugin-known taxonomies / capabilities / locales /
 * installed plugins + themes to Code Snippets Cloud so the cloud-side
 * Conditions editor can offer real values instead of placeholder text.
 *
 * Authed via a token-first check: the cloud calls this endpoint with no
 * WP session, so a valid Access-Control token alone is sufficient.
 *
 * @package Code_Snippets
 */
final class Cloud_Catalogue_REST_Controller extends REST_Collection_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base of this controller's route.
	 */
	public const BASE_ROUTE = 'cloud/catalogue';

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Authenticated connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		parent::__construct();
		$this->connection = $connection;
	}

	/**
	 * Check if the current request has permission to access the catalogue endpoint.
	 *
	 * Cloud has no WP session: accept a valid site token, OR a logged-in admin for local calls.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return $this->connection->verify_rest_request( $request ) || code_snippets()->current_user_can();
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			$this->rest_base,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);
	}

	/**
	 * Return the catalogue. Each section is independently capped/guarded so
	 * a degraded WP install (missing translation API, no themes installed)
	 * still returns something.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_items( $request ): WP_REST_Response {
		$roles = [];
		foreach ( wp_roles()->get_names() as $role => $display_name ) {
			$roles[] = [
				'role' => $role,
				'name' => $display_name,
			];
		}

		$caps = [];
		foreach ( wp_roles()->roles as $role_info ) {
			$caps = array_merge( $caps, array_keys( $role_info['capabilities'] ) );
		}
		$caps = array_values( array_unique( $caps ) );

		$locales = [];
		$translations_file = ABSPATH . 'wp-admin/includes/translation-install.php';
		if ( file_exists( $translations_file ) ) {
			require_once $translations_file;
			if ( function_exists( 'wp_get_available_translations' ) ) {
				foreach ( wp_get_available_translations() as $locale => $translation ) {
					$locales[] = [
						'locale' => $locale,
						'name'   => $translation['native_name'] ?? $locale,
					];
				}
			}
		}

		// Plugins + themes need `get_plugins` / `wp_get_themes` from wp-admin.
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins = get_plugins();

		$plugins = [];
		foreach ( $all_plugins as $file => $plugin_data ) {
			// Root-level single-file plugins (e.g. hello.php) have no directory;
			// dirname() yields '.', so fall back to the file name as the slug.
			$plugin_dir = dirname( $file );
			$plugins[] = [
				'slug'   => ( '' === $plugin_dir || '.' === $plugin_dir ) ? $file : $plugin_dir,
				'name'   => $plugin_data['Name'] ?? $file,
				'active' => is_plugin_active( $file ),
			];
		}

		$themes = [];
		foreach ( wp_get_themes() as $slug => $theme ) {
			$themes[] = [
				'slug'   => $slug,
				'name'   => $theme->get( 'Name' ),
				'active' => get_option( 'stylesheet' ) === $slug,
			];
		}

		$post_types = [];
		foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $post_type ) {
			$post_types[] = [
				'slug' => $post_type->name,
				'name' => $post_type->labels->name ?? $post_type->name,
			];
		}

		$taxonomies = [];
		foreach ( get_taxonomies( [ 'public' => true ], 'objects' ) as $taxonomy ) {
			$taxonomies[] = [
				'slug' => $taxonomy->name,
				'name' => $taxonomy->labels->name ?? $taxonomy->name,
			];
		}

		return rest_ensure_response(
			[
				'roles'         => $roles,
				'capabilities'  => $caps,
				'locales'       => $locales,
				'plugins'       => $plugins,
				'themes'        => $themes,
				'post_types'    => $post_types,
				'taxonomies'    => $taxonomies,
				'active_theme'  => get_option( 'stylesheet' ),
				'wp_version'    => get_bloginfo( 'version' ),
				'php_version'   => PHP_VERSION,
				'multisite'     => is_multisite(),
				'code_snippets' => $this->get_code_snippets_status( $all_plugins ),
			]
		);
	}

	/**
	 * Build the Code Snippets install/version block so the cloud can detect Pro
	 * and free presence, active state, and version.
	 *
	 * This response is generated by Code Snippets Pro itself, so Pro is by
	 * definition installed and running — it is reported directly from Pro's own
	 * version constant rather than looked up by folder path. (A dev/build
	 * checkout can live in a folder such as `src/`, so any hardcoded Pro path
	 * would wrongly report it as not installed.) Only the free plugin, which is
	 * a separate install, is detected from WordPress plugin data.
	 *
	 * @param array<string, array<string, string>> $all_plugins Result of get_plugins(), keyed by plugin file.
	 *
	 * @return array<string, bool|string|null>
	 */
	private function get_code_snippets_status( array $all_plugins ): array {
		$free_file = 'code-snippets/code-snippets.php';
		$free_installed = isset( $all_plugins[ $free_file ] );

		return [
			'pro_installed'  => true,
			'pro_active'     => true,
			'pro_version'    => PLUGIN_VERSION,
			'free_installed' => $free_installed,
			'free_version'   => $free_installed ? ( $all_plugins[ $free_file ]['Version'] ?? null ) : null,
		];
	}
}
