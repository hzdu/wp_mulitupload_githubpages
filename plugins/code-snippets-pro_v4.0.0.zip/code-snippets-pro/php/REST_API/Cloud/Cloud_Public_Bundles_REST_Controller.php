<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\Client\Cloud_Public_Client;
use Code_Snippets\Model\Basic_Cloud_Connection;
use Code_Snippets\REST_API\REST_Collection_Controller;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;

/**
 * Allows fetching public community bundles through the WordPress REST API.
 *
 * @package Code_Snippets
 */
final class Cloud_Public_Bundles_REST_Controller extends REST_Collection_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base route for these API endpoints.
	 */
	public const BASE_ROUTE = 'cloud/community-bundles';

	/**
	 * Public connection to Code Snippets Cloud.
	 *
	 * @var Basic_Cloud_Connection
	 */
	private Basic_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Basic_Cloud_Connection $connection Public connection to Code Snippets Cloud.
	 */
	public function __construct( Basic_Cloud_Connection $connection ) {
		parent::__construct();
		$this->connection = $connection;
	}

	/**
	 * Verify that a request is authorised to access community bundle data.
	 *
	 * The underlying cloud endpoint is public, so only a local capability check is needed.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return code_snippets()->current_user_can();
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		$collection_args = $this->get_collection_params();

		$pagination_args = [
			'page'     => $collection_args['page'],
			'per_page' => $collection_args['per_page'],
		];

		\register_rest_route(
			$this->namespace,
			$this->rest_base,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => $pagination_args,
				],
			]
		);

		\register_rest_route(
			$this->namespace,
			$this->rest_base . '/share_code/(?P<share_code>[\w-]+)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_bundle_snippets' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => $pagination_args + [
						'share_code' => [
							'type'     => 'string',
							'required' => true,
						],
					],
				],
			]
		);
	}

	/**
	 * Retrieve a list of public community bundles.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		$page = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = max( 1, (int) $request->get_param( 'per_page' ) );

		$client = new Cloud_Public_Client( $this->connection );

		$bundles = $client->get_featured_bundles( $page, $per_page );

		return \is_wp_error( $bundles ) ? $bundles : \rest_ensure_response( $bundles );
	}

	/**
	 * Retrieve snippets from a publicly shared bundle by its share code.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_bundle_snippets( WP_REST_Request $request ) {
		$share_code = (string) $request->get_param( 'share_code' );
		$page = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = max( 1, (int) $request->get_param( 'per_page' ) );

		$client = new Cloud_Public_Client( $this->connection );

		$snippets = $client->get_snippets_from_shared_bundle( $share_code, $page, $per_page );

		if ( is_wp_error( $snippets ) ) {
			return $snippets;
		}

		return is_null( $snippets )
			? new WP_Error(
				'code_snippets_rest_bundle_not_found',
				\__( 'The requested bundle could not be found.', 'code-snippets' ),
				[ 'status' => 404 ]
			)
			: $snippets->to_rest_response();
	}
}
