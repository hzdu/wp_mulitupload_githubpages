<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\Client\Cloud_AI_Agent_Client;
use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\REST_API\REST_Controller;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;

/**
 * Exposes the plan-first Cloud AI generation flow to the WordPress REST API.
 *
 * These routes are thin proxies to {@see Cloud_AI_Agent_Client}; the cloud owns
 * the conversation state, planning, and building.
 *
 * @package Code_Snippets
 */
final class Cloud_AI_Agent_REST_Controller extends REST_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base route for these API endpoints.
	 */
	public const BASE_ROUTE = 'cloud/ai-agent';

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Authenticated connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		parent::__construct();
		$this->connection = $connection;
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		$base = self::BASE_ROUTE;

		register_rest_route(
			$this->namespace,
			$base . '/generations',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'list_generations' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => [
						'page' => [
							'description' => esc_html__( 'Page of conversations to retrieve.', 'code-snippets' ),
							'type'        => 'integer',
							'default'     => 1,
							'minimum'     => 1,
						],
					],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_generation' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => [
						'prompt' => [
							'description'       => esc_html__( 'Prompt describing what to build.', 'code-snippets' ),
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_textarea_field',
						],
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/generations/(?P<id>\d+)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_generation' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => $this->id_arg(),
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'delete_generation' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => $this->id_arg(),
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/generations/(?P<id>\d+)/refine',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'refine_generation' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => $this->id_arg(
						[
							'message' => [
								'description'       => esc_html__( 'Refinement message describing what to change.', 'code-snippets' ),
								'required'          => true,
								'type'              => 'string',
								'sanitize_callback' => 'sanitize_textarea_field',
							],
						]
					),
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/generations/(?P<id>\d+)/proceed',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'proceed_generation' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => $this->id_arg(),
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/generations/(?P<id>\d+)/retry',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'retry_generation' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => $this->id_arg(),
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/generations/(?P<id>\d+)/cancel',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'cancel_generation' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => $this->id_arg(),
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/generations/(?P<id>\d+)/context',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'provide_context' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => $this->id_arg(),
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/generations/(?P<id>\d+)/edit',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'edit_generation' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => $this->id_arg(
						[
							'snippet_ids' => [
								'description' => esc_html__( 'Cloud IDs of the snippets to edit.', 'code-snippets' ),
								'required'    => true,
								'type'        => 'array',
								'items'       => [ 'type' => 'integer' ],
							],
							'message'     => [
								'description'       => esc_html__( 'Description of the changes to make.', 'code-snippets' ),
								'required'          => true,
								'type'              => 'string',
								'sanitize_callback' => 'sanitize_textarea_field',
							],
						]
					),
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/quota',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_quota' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);
	}

	/**
	 * Build the shared `id` route argument, optionally merged with more args.
	 *
	 * @param array<string, mixed> $extra Additional argument definitions.
	 *
	 * @return array<string, mixed>
	 */
	private function id_arg( array $extra = [] ): array {
		return array_merge(
			[
				'id' => [
					'description' => esc_html__( 'Generation ID.', 'code-snippets' ),
					'type'        => 'integer',
					'required'    => true,
				],
			],
			$extra
		);
	}

	/**
	 * Check that the current user may access these endpoints.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return code_snippets()->current_user_can() && $this->connection->verify_rest_request( $request );
	}

	/**
	 * Create a cloud AI agent client for the current connection.
	 *
	 * @return Cloud_AI_Agent_Client
	 */
	private function client(): Cloud_AI_Agent_Client {
		return new Cloud_AI_Agent_Client( $this->connection );
	}

	/**
	 * Wrap a client result in a REST response, passing through any error.
	 *
	 * @param array<string, mixed>|WP_Error $result Client result.
	 * @param int                           $status Success status code.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	private function respond( $result, int $status = 200 ) {
		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, $status );
	}

	/**
	 * List the current user's generations.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_generations( WP_REST_Request $request ) {
		return $this->respond( $this->client()->list_generations( (int) $request->get_param( 'page' ) ) );
	}

	/**
	 * Create a new generation.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_generation( WP_REST_Request $request ) {
		return $this->respond(
			$this->client()->create(
				(string) $request->get_param( 'prompt' ),
				(array) $request->get_param( 'context' )
			),
			201
		);
	}

	/**
	 * Fetch a single generation's current state.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_generation( WP_REST_Request $request ) {
		return $this->respond( $this->client()->get( (int) $request->get_param( 'id' ) ) );
	}

	/**
	 * Refine a generation's plan.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function refine_generation( WP_REST_Request $request ) {
		return $this->respond(
			$this->client()->refine(
				(int) $request->get_param( 'id' ),
				(string) $request->get_param( 'message' ),
				(array) $request->get_param( 'context' )
			)
		);
	}

	/**
	 * Cancel a running generation.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function cancel_generation( WP_REST_Request $request ) {
		return $this->respond( $this->client()->cancel( (int) $request->get_param( 'id' ) ) );
	}

	/**
	 * Answer a generation's outstanding request for wider context.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function provide_context( WP_REST_Request $request ) {
		return $this->respond(
			$this->client()->provide_context(
				(int) $request->get_param( 'id' ),
				(array) $request->get_param( 'context' )
			)
		);
	}

	/**
	 * Accept a plan and start building.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function proceed_generation( WP_REST_Request $request ) {
		return $this->respond( $this->client()->proceed( (int) $request->get_param( 'id' ) ) );
	}

	/**
	 * Retry a failed generation.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function retry_generation( WP_REST_Request $request ) {
		return $this->respond( $this->client()->retry( (int) $request->get_param( 'id' ) ) );
	}

	/**
	 * Request edits to existing snippets in a generation.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function edit_generation( WP_REST_Request $request ) {
		$snippet_ids = array_map( 'intval', (array) $request->get_param( 'snippet_ids' ) );

		return $this->respond(
			$this->client()->edit(
				(int) $request->get_param( 'id' ),
				$snippet_ids,
				(string) $request->get_param( 'message' ),
				(array) $request->get_param( 'context' )
			)
		);
	}

	/**
	 * Delete a generation.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_generation( WP_REST_Request $request ) {
		return $this->respond( $this->client()->delete( (int) $request->get_param( 'id' ) ), 200 );
	}

	/**
	 * Fetch the current AI usage quota.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_quota( WP_REST_Request $request ) {
		return $this->respond( $this->client()->quota() );
	}
}
