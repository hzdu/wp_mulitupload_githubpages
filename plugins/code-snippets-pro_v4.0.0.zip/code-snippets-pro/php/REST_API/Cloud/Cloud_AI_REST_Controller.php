<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\REST_API\REST_Controller;
use Code_Snippets\Client\Cloud_GPT_Client;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;

/**
 * Allows communication with the Cloud AI API from the WordPress REST API.
 *
 * @package Code_Snippets
 */
final class Cloud_AI_REST_Controller extends REST_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base route for these API endpoints.
	 */
	public const BASE_ROUTE = 'cloud/ai';

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Authenticated connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		parent::__construct();
		$this->connection = $connection;
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			self::BASE_ROUTE . '/prompt',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'cloud_ai_prompt' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => [
						'prompt' => [
							'description' => esc_html__( 'Prompt to use when generating snippet.', 'code-snippets' ),
							'required'    => true,
							'type'        => 'string',
						],
						'type'   => [
							'description' => esc_html__( 'Language type to use when generating code.', 'code-snippets' ),
							'required'    => true,
							'type'        => 'string',
							'enum'        => Cloud_GPT_Client::VALID_PROMPT_TYPES,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			self::BASE_ROUTE . '/site-context',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_site_context' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			self::BASE_ROUTE . '/explain',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'cloud_ai_explain' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => [
						'code'  => [
							'description' => esc_html__( 'Snippet code to use for generating an explanation.', 'code-snippets' ),
							'required'    => true,
							'type'        => 'string',
						],
						'field' => [
							'description' => esc_html__( 'Snippet field to target when generating explanation.', 'code-snippets' ),
							'required'    => true,
							'type'        => 'string',
							'enum'        => Cloud_GPT_Client::VALID_EXPLAIN_FIELDS,
						],
					],
				],
			]
		);
	}

	/**
	 * Check if the current user has permission to access the Cloud AI API endpoints.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return code_snippets()->current_user_can() && $this->connection->verify_rest_request( $request );
	}

	/**
	 * Describe the site environment, for the AI Agent's L3 context level.
	 *
	 * Deliberately limited to the things that change what a snippet may safely
	 * do — platform versions, the active theme and active plugins. No site URL,
	 * user data or option values are included, since this is handed to a model.
	 *
	 * @return WP_REST_Response
	 */
	public function get_site_context(): WP_REST_Response {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$theme = wp_get_theme();
		$all_plugins = get_plugins();
		$plugins = [];

		foreach ( (array) get_option( 'active_plugins', [] ) as $plugin_file ) {
			if ( isset( $all_plugins[ $plugin_file ] ) ) {
				$plugins[] = [
					'name'    => $all_plugins[ $plugin_file ]['Name'],
					'version' => $all_plugins[ $plugin_file ]['Version'],
				];
			}
		}

		// Wrapped in `data` to match the envelope the sibling endpoints in this
		// controller use, and which the agent's fetch unpacks.
		return rest_ensure_response(
			[
				'data' => [
					'wp'        => get_bloginfo( 'version' ),
					'php'       => PHP_VERSION,
					'locale'    => get_locale(),
					'multisite' => is_multisite(),
					'theme'     => [
						'name'     => $theme->get( 'Name' ),
						'version'  => $theme->get( 'Version' ),
						'template' => $theme->get_template(),
					],
					'plugins'   => $plugins,
				],
			]
		);
	}

	/**
	 * Get the response from Cloud AI API /prompt endpoint
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function cloud_ai_prompt( WP_REST_Request $request ) {
		$prompt = $request->get_param( 'prompt' );
		$type = $request->get_param( 'type' );

		$cloud_ai_api = new Cloud_GPT_Client( $this->connection );
		$result = $cloud_ai_api->prompt( $prompt, $type );

		return is_wp_error( $result ) ?
			$result :
			rest_ensure_response(
				[
					'status'  => 'success',
					'message' => $result,
				]
			);
	}

	/**
	 * Get the response from Cloud AI API /explain endpoint.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function cloud_ai_explain( WP_REST_Request $request ) {
		$code = $request->get_param( 'code' );
		$field = $request->get_param( 'field' );

		$cloud_ai_api = new Cloud_GPT_Client( $this->connection );
		$result = $cloud_ai_api->explain( $code, $field );

		return is_wp_error( $result ) ?
			$result :
			rest_ensure_response(
				[
					'status'  => 'success',
					'message' => $result,
				]
			);
	}
}
