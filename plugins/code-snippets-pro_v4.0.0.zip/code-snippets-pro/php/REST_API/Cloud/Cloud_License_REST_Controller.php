<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\REST_API\REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;
use const Code_Snippets\PLUGIN_VERSION;

/**
 * Reports Code Snippets Pro install state and Freemius license identifiers to
 * Code Snippets Cloud so the cloud can drive the Pro update flow.
 *
 * The cloud verifies the license against the Freemius API itself, so this
 * endpoint exposes only identifiers and status flags — never the license key,
 * secret key, or any activation token. It is strictly read-only.
 *
 * Authed via the same per-site `Access-Control` token used by the other
 * cloud→site routes; the cloud has no WP session, so a valid token alone is
 * sufficient.
 *
 * @package Code_Snippets
 */
final class Cloud_License_REST_Controller extends REST_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base of this controller's route.
	 */
	public const BASE_ROUTE = 'cloud/license';

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Authenticated connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		parent::__construct();
		$this->connection = $connection;
	}

	/**
	 * Check if the current request may read the license status.
	 *
	 * Cloud has no WP session: accept a valid site token, OR a logged-in admin for local calls.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return $this->connection->verify_rest_request( $request ) || code_snippets()->current_user_can();
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			self::BASE_ROUTE,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);
	}

	/**
	 * Return the Pro install state plus identifiers-only license status.
	 *
	 * The `license` object is always present (with nulls when unavailable) so the
	 * cloud can distinguish "no data" from an old plugin build that omits the key.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_items( $request ): WP_REST_Response {
		// This endpoint is served by Code Snippets Pro itself, so Pro is by
		// definition installed and running — report it directly from Pro's own
		// version constant rather than looking it up by folder path (a dev/build
		// checkout may live in a folder such as `src/`).
		return rest_ensure_response(
			[
				'pro_installed' => true,
				'pro_active'    => true,
				'pro_version'   => PLUGIN_VERSION,
				'license'       => code_snippets()->licensing->get_cloud_identifiers(),
			]
		);
	}
}
