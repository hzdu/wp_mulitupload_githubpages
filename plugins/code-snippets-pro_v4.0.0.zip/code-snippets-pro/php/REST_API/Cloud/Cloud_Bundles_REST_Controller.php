<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\Client\Cloud_Private_Client;
use Code_Snippets\Controller\Cloud_Library_Controller;
use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\REST_API\REST_Collection_Controller;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;

/**
 * Allows fetching cloud bundles through the WordPress REST API.
 *
 * @package Code_Snippets
 */
final class Cloud_Bundles_REST_Controller extends REST_Collection_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base route for these API endpoints.
	 */
	public const BASE_ROUTE = 'cloud/bundles';

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		parent::__construct();
		$this->connection = $connection;
	}

	/**
	 * Verify that a request is authorised to access Code Snippets Cloud data.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return code_snippets()->current_user_can() && $this->connection->verify_rest_request( $request );
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			$this->rest_base,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
				],
			]
		);
	}

	/**
	 * Retrieve a list of cloud bundles.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		$client = new Cloud_Private_Client( $this->connection );
		return rest_ensure_response( $client->get_bundles() );
	}
}
