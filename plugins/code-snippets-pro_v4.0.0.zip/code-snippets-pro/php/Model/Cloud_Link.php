<?php

namespace Code_Snippets\Model;

/**
 * A connection between a local snippet and remote cloud snippet.
 *
 * @package Code_Snippets
 */
class Cloud_Link {

	/**
	 * ID of local snippet as stored in WordPress database.
	 *
	 * @var int
	 */
	public int $local_id;

	/**
	 * ID of remote snippet on cloud platform.
	 *
	 * @var int
	 */
	public int $cloud_id;

	/**
	 * Ownership status of remote snippet on cloud platform.
	 *
	 * @var bool
	 */
	public bool $is_owner;

	/**
	 * If synchronised, whether there is an update available on the cloud platform.
	 *
	 * @var bool
	 */
	public bool $update_available;
}
