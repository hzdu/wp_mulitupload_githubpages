<?php

namespace Code_Snippets\Model;

/**
 * Represents an authenticated connection to Code Snippets Cloud.
 */
class Authenticated_Cloud_Connection extends Basic_Cloud_Connection {

	/**
	 * Name of option used to store cloud settings.
	 */
	private const CLOUD_SETTINGS_OPTION = 'code_snippets_cloud_settings';

	/**
	 * Name of key used to cache cloud settings.
	 *
	 * @var string
	 */
	private const CLOUD_SETTINGS_CACHE_KEY = 'code_snippets_cloud_settings';

	/**
	 * Cached cloud settings values.
	 *
	 * @var array{
	 *     cloud_token: string,
	 *     local_token: string,
	 *     token_verified: bool,
	 *     code_verifier: string,
	 *     code_challenge: string,
	 *     state: string
	 * }|null
	 */
	private ?array $settings = [
		'cloud_token'    => '',
		'local_token'    => '',
		'token_verified' => false,
		'code_verifier'  => '',
		'code_challenge' => '',
		'state'          => '',
	];

	/**
	 * Class constructor.
	 */
	public function __construct() {
		parent::__construct();

		$cached_settings = wp_cache_get( self::CLOUD_SETTINGS_CACHE_KEY );

		if ( is_array( $cached_settings ) ) {
			$this->settings = array_replace( $this->settings, $cached_settings );
		} else {
			$stored_settings = get_option( self::CLOUD_SETTINGS_OPTION );

			if ( is_array( $stored_settings ) ) {
				$this->settings = array_replace( $this->settings, $stored_settings );
			} else {
				update_option( self::CLOUD_SETTINGS_CACHE_KEY, $this->settings );
			}

			wp_cache_set( self::CLOUD_SETTINGS_CACHE_KEY, $this->settings );
		}
	}

	/**
	 * Retrieve the current cloud connection state.
	 *
	 * @return string
	 */
	public function get_current_state(): string {
		return $this->settings['state'];
	}

	/**
	 * Generate the client ID from the current local token and site URL.
	 *
	 * @return string Client ID.
	 */
	public function get_client_id(): string {
		$site_host = wp_parse_url( get_site_url(), PHP_URL_HOST );
		return sprintf( '%s-%s', $site_host, $this->get_local_token() );
	}

	/**
	 * Retrieve code verifier value.
	 *
	 * @return mixed|string
	 */
	public function get_code_verifier() {
		return $this->settings['code_verifier'];
	}

	/**
	 * Retrieve the cloud local token.
	 *
	 * @return string
	 */
	public function get_local_token(): string {
		return $this->settings['local_token'] ?? '';
	}

	/**
	 * Retrieve the code challenge used for authorization.
	 *
	 * @return string
	 */
	public function get_code_challenge(): string {
		return $this->settings['code_challenge'];
	}

	/**
	 * Retrieve the cloud API key.
	 *
	 * @return string
	 */
	public function get_cloud_key(): string {
		return $this->settings['cloud_token'];
	}

	/**
	 * Check that the cloud key is valid and verified.
	 *
	 * @return bool
	 */
	public function is_cloud_key_verified(): bool {
		return boolval( $this->settings['token_verified'] );
	}

	/**
	 * Check if the API key is set and verified.
	 *
	 * @return bool
	 */
	public function is_authenticated(): bool {
		return $this->get_cloud_key() && $this->is_cloud_key_verified();
	}

	/**
	 * Set the cloud token and mark it as verified.
	 *
	 * @param string $token Cloud token.
	 *
	 * @return void
	 */
	public function set_verified_cloud_token( string $token ) {
		$this->update_cloud_settings(
			[
				'cloud_token'    => $token,
				'token_verified' => true,
			]
		);
	}

	/**
	 * Update the stored local token.
	 *
	 * @param array{code_verifier: string, code_challenge: string, state: string, local_token: string} $details Token details.
	 *
	 * @return void
	 */
	public function set_local_token( array $details ) {
		$this->update_cloud_settings(
			[
				'code_verifier'  => $details['code_verifier'],
				'code_challenge' => $details['code_challenge'],
				'state'          => $details['state'],
				'local_token'    => $details['local_token'],
			]
		);
	}

	/**
	 * Create a list of headers required for an authenticated request.
	 *
	 * @return array<string, string> Header name and value pairs.
	 */
	public function get_request_headers(): array {
		return [
			'Authorization' => sprintf( 'Bearer %s', $this->get_cloud_key() ),
			'Local-Token'   => $this->get_local_token(),
		];
	}


	/**
	 * Update multiple cloud settings
	 *
	 * @param array<string, mixed> $settings to update in cloud settings with key value pairs 'setting' => 'value'.
	 *
	 * @return void
	 */
	private function update_cloud_settings( array $settings ) {
		foreach ( $settings as $setting => $value ) {
			$this->settings[ $setting ] = $value;
		}

		update_option( self::CLOUD_SETTINGS_OPTION, $this->settings );
		wp_cache_set( self::CLOUD_SETTINGS_CACHE_KEY, $this->settings );
	}

	/**
	 * Reset the cloud connection by clearing all relevant settings and cached values.
	 *
	 * @return void
	 */
	public function reset() {
		$this->update_cloud_settings(
			[
				'cloud_token'    => '',
				'token_verified' => false,
				'local_token'    => '',
				'code_challenge' => '',
				'code_verifier'  => '',
			]
		);
	}
}
