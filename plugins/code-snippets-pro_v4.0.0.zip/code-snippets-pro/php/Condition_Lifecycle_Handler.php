<?php
/**
 * Handles condition lifecycle events (trash, delete, restore).
 *
 * @package Code_Snippets
 */

namespace Code_Snippets;

use Code_Snippets\Model\Snippet;

/**
 * Manages condition snippet lifecycle operations including trash, delete, and restore.
 */
class Condition_Lifecycle_Handler {

	/**
	 * Register action hooks.
	 */
	public function __construct() {
		add_action( 'code_snippets/delete_snippet', [ $this, 'handle_delete' ], 10, 2 );
		add_action( 'code_snippets/trash_snippet', [ $this, 'handle_trash' ], 10, 2 );
		add_action( 'code_snippets/restore_snippet', [ $this, 'handle_restore' ], 10, 2 );
	}

	/**
	 * Handle snippet deletion.
	 *
	 * @param Snippet $snippet Snippet object.
	 * @param bool    $network Whether this is a network-wide snippet.
	 *
	 * @return void
	 */
	public function handle_delete( Snippet $snippet, bool $network ): void {
		if ( ! $snippet->is_condition() ) {
			return;
		}

		$table = code_snippets()->db->get_table_name( $network );

		$this->detach_snippets_from_condition( $snippet, $network );
		$this->remove_condition_from_trash_data( $snippet, $table );
	}

	/**
	 * Handle snippet trashing.
	 *
	 * @param Snippet $snippet Snippet object.
	 * @param bool    $network Whether this is a network-wide snippet.
	 *
	 * @return void
	 */
	public function handle_trash( Snippet $snippet, bool $network ): void {
		if ( ! $snippet->is_condition() ) {
			return;
		}

		$table = code_snippets()->db->get_table_name( $network );

		$attached_snippet_ids = $this->get_attached_snippet_ids( $snippet, $network );
		$this->detach_snippets_from_condition( $snippet, $network );
		$this->store_trashed_condition( $snippet, $attached_snippet_ids, $table );
	}

	/**
	 * Handle snippet restoration.
	 *
	 * @param int  $id      Snippet ID.
	 * @param bool $network Whether this is a network-wide snippet.
	 *
	 * @return void
	 */
	public function handle_restore( int $id, bool $network ): void {
		$snippet = get_snippet( $id, $network );
		if ( ! $snippet->is_condition() ) {
			return;
		}

		$table = code_snippets()->db->get_table_name( $network );

		$trashed_data = $this->get_trashed_condition_data( $snippet, $table );
		$this->remove_condition_from_trash_data( $snippet, $table );

		if ( $trashed_data && isset( $trashed_data['attached_snippet_ids'] ) ) {
			$this->restore_snippet_attachments( $snippet, $trashed_data['attached_snippet_ids'], $table );
		}
	}

	/**
	 * Detach all snippets from a condition.
	 *
	 * @param Snippet $snippet Snippet object.
	 * @param bool    $network Whether the snippet belongs to the network table.
	 *
	 * @return void
	 */
	private function detach_snippets_from_condition( Snippet $snippet, bool $network ): void {
		code_snippets()->db->detach_condition_consumers( $snippet->id, $network );
	}

	/**
	 * Get all snippet IDs attached to a condition.
	 *
	 * @param Snippet $snippet Snippet object.
	 * @param bool    $network Whether the snippet belongs to the network table.
	 *
	 * @return array Array of snippet IDs.
	 */
	private function get_attached_snippet_ids( Snippet $snippet, bool $network ): array {
		return code_snippets()->db->fetch_condition_consumer_ids( $snippet->id, $network );
	}

	/**
	 * Store a trashed condition's data for potential restoration.
	 *
	 * @param Snippet $snippet              Snippet object.
	 * @param array   $attached_snippet_ids Array of snippet IDs that were attached to this condition.
	 * @param string  $table                Database table name.
	 *
	 * @return void
	 */
	private function store_trashed_condition( Snippet $snippet, array $attached_snippet_ids, string $table ): void {
		$trashed_condition = [
			'snippet_id'           => $snippet->id,
			'condition_id'         => $snippet->condition_id,
			'attached_snippet_ids' => $attached_snippet_ids,
		];

		$option_name = 'trashed_snippets_conditions_' . sanitize_key( $table );
		$existing = get_option( $option_name );

		if ( ! is_array( $existing ) ) {
			$existing = [];
		}

		$existing[] = $trashed_condition;

		update_option( $option_name, $existing );
	}

	/**
	 * Get trashed condition data for a specific snippet.
	 *
	 * @param Snippet $snippet Snippet object.
	 * @param string  $table   Database table name.
	 *
	 * @return array|null Trashed condition data or null if not found.
	 */
	private function get_trashed_condition_data( Snippet $snippet, string $table ): ?array {
		$option_name = 'trashed_snippets_conditions_' . sanitize_key( $table );
		$existing = get_option( $option_name );

		if ( ! is_array( $existing ) ) {
			return null;
		}

		foreach ( $existing as $condition ) {
			if ( $condition['snippet_id'] === $snippet->id ) {
				return $condition;
			}
		}

		return null;
	}

	/**
	 * Restore snippet attachments to a condition.
	 *
	 * @param Snippet $snippet              Snippet object.
	 * @param array   $attached_snippet_ids Array of snippet IDs to reattach.
	 * @param string  $table                Database table name.
	 *
	 * @return void
	 */
	private function restore_snippet_attachments( Snippet $snippet, array $attached_snippet_ids, string $table ): void {
		if ( empty( $attached_snippet_ids ) ) {
			return;
		}

		global $wpdb;

		$table = esc_sql( $table );
		$placeholders = implode( ',', array_fill( 0, count( $attached_snippet_ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE $table SET condition_id = %d WHERE id IN ($placeholders)",
				array_merge( [ $snippet->id ], $attached_snippet_ids )
			)
		);
	}

	/**
	 * Remove a condition from the stored trash data.
	 *
	 * @param Snippet $snippet Snippet object.
	 * @param string  $table   Database table name.
	 *
	 * @return void
	 */
	private function remove_condition_from_trash_data( Snippet $snippet, string $table ): void {
		$option_name = 'trashed_snippets_conditions_' . sanitize_key( $table );
		$existing = get_option( $option_name );

		if ( is_array( $existing ) ) {
			$existing = array_filter(
				$existing,
				function ( $condition ) use ( $snippet ) {
					return $condition['snippet_id'] !== $snippet->id;
				}
			);

			if ( empty( $existing ) ) {
				delete_option( $option_name );
			} else {
				update_option( $option_name, $existing );
			}
		}
	}
}
