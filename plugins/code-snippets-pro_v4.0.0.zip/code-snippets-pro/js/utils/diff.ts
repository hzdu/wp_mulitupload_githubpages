import DiffMatchPatch from 'diff-match-patch'

export type DiffRowType = 'unchanged' | 'modified' | 'added' | 'removed'

export interface DiffRow {
	type: DiffRowType
	leftLineNum?: number
	leftContent?: string
	rightLineNum?: number
	rightContent?: string
}

/**
 * Split a run of text into lines, dropping the empty string that trails a final newline.
 */
const toLines = (text: string): string[] => {
	const lines = text.split('\n')
	return '' === lines[lines.length - 1] ? lines.slice(0, -1) : lines
}

/**
 * Pair removed lines with added ones so a changed line shows old and new side by
 * side, leaving any surplus on either side as a pure removal or addition.
 */
const pairRun = (removed: string[], added: string[], oldLine: number, newLine: number): DiffRow[] => {
	const paired = Math.min(removed.length, added.length)

	return [
		...removed.slice(0, paired).map((content, index): DiffRow => ({
			type: 'modified',
			leftLineNum: oldLine + index,
			leftContent: content,
			rightLineNum: newLine + index,
			rightContent: added[index]
		})),
		...removed.slice(paired).map((content, index): DiffRow => ({
			type: 'removed',
			leftLineNum: oldLine + paired + index,
			leftContent: content
		})),
		...added.slice(paired).map((content, index): DiffRow => ({
			type: 'added',
			rightLineNum: newLine + paired + index,
			rightContent: content
		}))
	]
}

/**
 * Compare two blocks of code line by line, ready to render as two columns.
 *
 * Lines are diffed as whole units rather than by character, so an inserted line
 * shifts the lines after it instead of reporting them all as rewritten.
 */
export const computeLineDiff = (oldText: string, newText: string): DiffRow[] => {
	const differ = new DiffMatchPatch()
	const { chars1, chars2, lineArray } = differ.diff_linesToChars_(oldText, newText)
	const diffs = differ.diff_main(chars1, chars2, false)
	differ.diff_charsToLines_(diffs, lineArray)

	const rows: DiffRow[] = []
	let removed: string[] = []
	let added: string[] = []
	let oldLine = 1
	let newLine = 1

	const flush = () => {
		if (removed.length || added.length) {
			rows.push(...pairRun(removed, added, oldLine, newLine))
			oldLine += removed.length
			newLine += added.length
			removed = []
			added = []
		}
	}

	for (const [operation, text] of diffs) {
		switch (operation) {
			case DiffMatchPatch.DIFF_DELETE:
				removed.push(...toLines(text))
				break

			case DiffMatchPatch.DIFF_INSERT:
				added.push(...toLines(text))
				break

			case DiffMatchPatch.DIFF_EQUAL:
				flush()
				for (const content of toLines(text)) {
					rows.push({
						type: 'unchanged',
						leftLineNum: oldLine,
						leftContent: content,
						rightLineNum: newLine,
						rightContent: content
					})
					oldLine += 1
					newLine += 1
				}
				break
		}
	}

	flush()

	return rows
}
