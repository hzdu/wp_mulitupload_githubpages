import { useCallback, useEffect, useState } from 'react'
import { useSnippetForm } from '../components/EditMenu/SnippetForm/WithSnippetFormContext'
import { useRevisionsAPI } from './useRevisionsAPI'
import type { Revision } from '../types/Revision'

export interface SnippetRevisions {
	revisions: Revision[]
	isLoading: boolean
	versioningDisabled: boolean
	setVersioningDisabled: (disabled: boolean) => void
	deleteRevision: (revision: Revision) => Promise<Revision[]>
}

/**
 * Load the stored revisions for the snippet being edited, and the versioning
 * setting that governs whether new ones are recorded.
 */
export const useSnippetRevisions = (): SnippetRevisions => {
	const { snippet } = useSnippetForm()
	const revisionsAPI = useRevisionsAPI()

	const [revisions, setRevisions] = useState<Revision[]>([])
	const [isLoading, setIsLoading] = useState(false)
	const [versioningDisabled, setVersioningDisabled] = useState(false)

	const loadRevisions = useCallback(() => {
		if (!snippet.id) {return}

		setIsLoading(true)
		Promise.all([
			revisionsAPI.fetchAll(snippet.id, snippet.network),
			revisionsAPI.getSettings(snippet.id, snippet.network),
		])
			.then(([revs, settings]) => {
				setRevisions(revs)
				setVersioningDisabled(settings.disabled)
			})
			.catch(() => setRevisions([]))
			.finally(() => setIsLoading(false))
	}, [snippet.id, snippet.network, revisionsAPI])

	// Reloads on mount and whenever a save moves the modification date on.
	useEffect(loadRevisions, [snippet.modified, loadRevisions])

	const deleteRevision = useCallback((revision: Revision) => {
		if (!snippet.id) {return Promise.resolve(revisions)}

		return revisionsAPI.deleteRevision(snippet.id, revision.id, snippet.network)
			.then(() => {
				const remaining = revisions.filter(({ id }) => id !== revision.id)
				setRevisions(remaining)
				return remaining
			})
			.catch(() => revisions)
	}, [snippet.id, snippet.network, revisionsAPI, revisions])

	return { revisions, isLoading, versioningDisabled, setVersioningDisabled, deleteRevision }
}
