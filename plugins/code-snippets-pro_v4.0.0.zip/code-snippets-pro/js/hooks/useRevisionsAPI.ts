import { useMemo } from 'react'
import { REST_BASES } from '../utils/restAPI'
import { buildUrl } from '../utils/urls'
import { useRestAPI } from './useRestAPI'
import type { Revision, RevisionSettings } from '../types/Revision'

export interface DeletePreference {
	delete_revision_default: '' | 'delete' | 'keep'
}

export interface RevisionsAPI {
	fetchAll: (snippetId: number, network?: boolean | null) => Promise<Revision[]>
	fetch: (snippetId: number, revisionId: number, network?: boolean | null) => Promise<Revision>
	restore: (snippetId: number, revisionId: number, network?: boolean | null) => Promise<{ success: boolean }>
	deleteRevision: (snippetId: number, revisionId: number, network?: boolean | null) => Promise<undefined>
	getSettings: (snippetId: number, network?: boolean | null) => Promise<RevisionSettings>
	updateSettings: (snippetId: number, disabled: boolean, network?: boolean | null) => Promise<RevisionSettings>
	getDeletePreference: () => Promise<DeletePreference>
	setDeletePreference: (value: '' | 'delete' | 'keep') => Promise<DeletePreference>
}

const buildRevisionsUrl = (snippetId: number, network?: boolean | null, ...parts: string[]) =>
	buildUrl([REST_BASES.snippets, snippetId, 'revisions', ...parts].join('/'), { network })

export const useRevisionsAPI = (): RevisionsAPI => {
	const { api } = useRestAPI()

	return useMemo<RevisionsAPI>(() => ({
		fetchAll: (snippetId, network) =>
			api.get<Revision[]>(buildRevisionsUrl(snippetId, network)),

		fetch: (snippetId, revisionId, network) =>
			api.get<Revision>(buildRevisionsUrl(snippetId, network, String(revisionId))),

		restore: (snippetId, revisionId, network) =>
			api.post<{ success: boolean }>(buildRevisionsUrl(snippetId, network, String(revisionId), 'restore')),

		deleteRevision: (snippetId, revisionId, network) =>
			api.del<undefined>(buildRevisionsUrl(snippetId, network, String(revisionId))),

		getSettings: (snippetId, network) =>
			api.get<RevisionSettings>(buildRevisionsUrl(snippetId, network, 'settings')),

		updateSettings: (snippetId, disabled, network) =>
			api.post<RevisionSettings, { disabled: boolean }>(buildRevisionsUrl(snippetId, network, 'settings'), { disabled }),

		getDeletePreference: () =>
			api.get<DeletePreference>([REST_BASES.snippets, 'revisions', 'preferences'].join('/')),

		setDeletePreference: value =>
			api.post<DeletePreference, DeletePreference>(
				[REST_BASES.snippets, 'revisions', 'preferences'].join('/'),
				{ delete_revision_default: value }
			),
	}), [api])
}
