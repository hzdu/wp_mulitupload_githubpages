import { __, sprintf } from '@wordpress/i18n'
import { BlueprintBase } from './BlueprintBase'
import { TaxonomyForm } from './forms/TaxonomyForm'
import { formatPhpCommentText, formatPhpString, formatPhpValue, formatTranslateX, joinAsPhpArray } from './utils/format'
import type { TaxonomyFormData } from './forms/TaxonomyForm'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'

export class TaxonomyBlueprint extends BlueprintBase<TaxonomyFormData> {
	static override getMetadata(): BlueprintMetadata {
		return {
			slug: 'taxonomy',
			order: 30,
			title: __('Add a Custom Taxonomy', 'code-snippets'),
			description: __('Add custom categories or tags to organize your content, like “Project Type” or “Book Author”.', 'code-snippets'),
			categories: ['content'],
			docsUrl: 'https://codesnippets.pro/doc/blueprint-add-a-custom-taxonomy/',
			intro: __('Use this Blueprint to create a custom taxonomy, like categories or tags, to better organize your content.', 'code-snippets')
		}
	}

	constructor(formData?: TaxonomyFormData) {
		super('general', TaxonomyForm, formData)
	}

	protected override construct(formData: TaxonomyFormData): BlueprintBase<TaxonomyFormData> {
		return new TaxonomyBlueprint(formData)
	}

	override getDefaultSnippetName(): string {
		const { general: { taxonomyKey } } = this.formData
		return taxonomyKey
			// translators: %s: taxonomy key.
			? sprintf(__('%s Custom Taxonomy', 'code-snippets'), taxonomyKey)
			: super.getDefaultSnippetName()
	}

	override generateCode(): string {
		const { general: { taxonomyKey, objectType, textDomain } } = this.formData

		const postTypes = objectType
			.split(',')
			.filter(type => type.trim())
			.map(type => formatPhpString(type.trim()))
			.join(', ')

		const arrays = [
			this.buildLabelsArray(),
			this.buildRewriteArray(),
			this.buildCapabilitiesArray(),
			this.buildMainArgs()
		].filter(code => code)

		return `<php
/**
 * Register Custom Taxonomy: ${formatPhpCommentText(taxonomyKey)}
 *
 * @see https://developer.wordpress.org/reference/functions/register_taxonomy/
 *
 * Text Domain: ${formatPhpCommentText(textDomain)}
 */

add_action( 'init', function () {
	${arrays.join('\n\n')}

	register_taxonomy( ${formatPhpString(taxonomyKey)}, [ ${postTypes} ], $args );
}, 0 );`
	}

	private buildLabelsArray(): string {
		const { general: { textDomain, nameSingular, namePlural }, labels } = this.formData

		return `
	$labels = [
		'name'                       => ${formatTranslateX(namePlural, 'Taxonomy General Name', textDomain)},
		'singular_name'              => ${formatTranslateX(nameSingular, 'Taxonomy Singular Name', textDomain)},
		'menu_name'                  => ${formatPhpString(labels.menuName, textDomain)},
		'all_items'                  => ${formatPhpString(labels.allItems, textDomain)},
		'parent_item'                => ${formatPhpString(labels.parentItem, textDomain)},
		'parent_item_colon'          => ${formatPhpString(labels.parentItemColon, textDomain)},

		'new_item_name'              => ${formatPhpString(labels.newItemName, textDomain)},
		'add_new_item'               => ${formatPhpString(labels.addNewItem, textDomain)},
		'edit_item'                  => ${formatPhpString(labels.editItem, textDomain)},
		'update_item'                => ${formatPhpString(labels.updateItem, textDomain)},
		'view_item'                  => ${formatPhpString(labels.viewItem, textDomain)},
		
		'separate_items_with_commas' => ${formatPhpString(labels.separateItemsWithCommas, textDomain)},
		'add_or_remove_items'        => ${formatPhpString(labels.addOrRemoveItems, textDomain)},
		'choose_from_most_used'      => ${formatPhpString(labels.chooseFromMostUsed, textDomain)},
		'popular_items'              => ${formatPhpString(labels.popularItems, textDomain)},
		'search_items'               => ${formatPhpString(labels.searchItems, textDomain)},
		'not_found'                  => ${formatPhpString(labels.notFound, textDomain)},
		'no_terms'                   => ${formatPhpString(labels.noTerms, textDomain)},
		'items_list'                 => ${formatPhpString(labels.itemsList, textDomain)},
		'items_list_navigation'      => ${formatPhpString(labels.itemsListNavigation, textDomain)},
		'back_to_items'              => ${formatPhpString(labels.backToItems, textDomain)},
		'filter_by_item'             => ${formatPhpString(labels.filterByItem, textDomain)},
		'item_link'                  => ${formatPhpString(labels.itemLink, textDomain)},
		'item_link_description'      => ${formatPhpString(labels.itemLinkDescription, textDomain)},
	];`
	}

	private buildRewriteArray(): string {
		const { permalinks: { rewrite, rewriteSlug, rewriteWithFront, rewriteHierarchical } } = this.formData

		return 'custom' !== rewrite ? '' : `
	$rewrite = [
		'slug'         => ${formatPhpValue(rewriteSlug)},
		'with_front'   => ${formatPhpValue(rewriteWithFront)},
		'hierarchical' => ${formatPhpValue(rewriteHierarchical)},
	];`
	}

	private buildCapabilitiesArray(): string {
		const { capabilities } = this.formData

		if ('custom' !== capabilities.capabilitiesMode) {
			return ''
		}

		const allCaps = {
			manage_terms: capabilities.capabilitiesManageTerms,
			edit_terms: capabilities.capabilitiesEditTerms,
			delete_terms: capabilities.capabilitiesDeleteTerms,
			assign_terms: capabilities.capabilitiesAssignTerms
		}

		const providedCaps = Object.fromEntries(
			Object.entries(allCaps)
				.filter(([_, cap]) => cap.trim())
				.map(([key, cap]) => [key, formatPhpString(cap.trim())]))

		return `\t$capabilities = [\n${joinAsPhpArray(providedCaps)}\n\t];`
	}

	private buildMainArgs(): string {
		const { general, visibility, query, permalinks, capabilities, restApi, advanced } = this.formData

		const args = {
			labels: '$labels',
			hierarchical: formatPhpValue(general.hierarchical),
			public: formatPhpValue(visibility.public),
			show_ui: formatPhpValue(visibility.showUI),
			show_admin_column: formatPhpValue(visibility.showAdminColumn),
			show_in_nav_menus: formatPhpValue(visibility.showInNavMenus),
			show_tagcloud: formatPhpValue(visibility.showTagCloud),

			...'custom' === query.queryVar && query.queryVarSlug && { query_var: formatPhpValue(query.queryVarSlug) },
			...'custom' === permalinks.rewrite && { rewrite: '$rewrite' },
			...'custom' === capabilities.capabilitiesMode && { capabilities: '$capabilities' },
			...advanced.updateCountCallback && { update_count_callback: formatPhpValue(advanced.updateCountCallback) },

			...restApi.showInRest && { show_in_rest: formatPhpValue(restApi.showInRest) },
			...restApi.restBase && { rest_base: formatPhpValue(restApi.restBase) },
			...restApi.restNamespace && { rest_namespace: formatPhpValue(restApi.restNamespace) },
			...restApi.restControllerClass && { rest_controller_class: formatPhpValue(restApi.restControllerClass) }
		}

		return `\t$args = [\n${joinAsPhpArray(args)}\n\t];`
	}
}
