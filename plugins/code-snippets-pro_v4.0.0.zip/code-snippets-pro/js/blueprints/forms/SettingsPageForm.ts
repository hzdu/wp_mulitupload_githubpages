import { __ } from '@wordpress/i18n'
import { isValidPhpIdentifier, isValidTextDomain, isValidWordPressKey } from '../utils/validate'
import type { BlueprintForm, BlueprintFormRepeaters } from '../BlueprintBase'

export interface SettingsField {
	fieldType: '' | 'text' | 'number' | 'email' | 'url' | 'date' | 'time' |
		'color' | 'textarea' | 'checkbox' | 'checkboxes' | 'radio' | 'select'
	id: string
	label: string
	description: string
	defaultValue: string
	placeholder?: string
	options: string
}

const SETTING_FIELD_TYPES_WITH_OPTIONS = new Set<SettingsField['fieldType']>(['select', 'radio', 'checkboxes'])

export interface SettingsPageFormData {
	general: {
		className: string
		textDomain: string
		contentBeforeFields: string
	}
	menu: {
		menuType: 'add_menu_page' | 'add_submenu_page'
		submenu: string
		pageTitle: string
		menuTitle: string
		capability: string
		menuSlug: string
		menuIcon: string
		menuPosition: string
	}
	settings: {
		settingsGroup: string
		settingsBase: string
	}
	fields: object
}

export interface SettingsPageRepeaterData {
	fields: SettingsField
}

export const SettingsPageForm: BlueprintForm<SettingsPageFormData> = {
	general: {
		title: __('General', 'code-snippets'),
		fields: {
			className: {
				type: 'text',
				label: __('Class Name', 'code-snippets'),
				value: 'Custom_Settings_Page',
				required: true,
				placeholder: 'Custom_Settings_Page',
				description: __('PHP class name. Use a capital letter for each word, separated by underscores.', 'code-snippets'),
				validate(className) {
					if (!className) {
						return __('Class name is required', 'code-snippets')
					} else if (!isValidPhpIdentifier(className)) {
						return __('Class name must be a valid PHP identifier', 'code-snippets')
					} else {
						return
					}
				}
			},
			textDomain: {
				type: 'text',
				label: __('Text Domain', 'code-snippets'),
				value: 'code-snippets-blueprints',
				placeholder: 'text_domain',
				description: __('Translation file text domain. Optional.', 'code-snippets'),
				validate: textDomain =>
					textDomain && !isValidTextDomain(textDomain)
						? __('Text domain must contain only letters, numbers, underscores, or hyphens', 'code-snippets')
						: undefined
			},
			contentBeforeFields: {
				type: 'textarea',
				label: __('Content before fields', 'code-snippets'),
				value: '',
				placeholder: '<p>Optional intro or explanation. HTML allowed.</p>',
				description: __('Optional. HTML or text output above the settings fields, after the form starts.', 'code-snippets')
			}
		}
	},
	menu: {
		title: __('Menu', 'code-snippets'),
		fields: {
			menuType: {
				type: 'select',
				label: __('Menu Type', 'code-snippets'),
				value: 'add_submenu_page',
				required: true,
				options: [
					{ value: 'add_menu_page', label: __('Top-level Menu', 'code-snippets') },
					{ value: 'add_submenu_page', label: __('Submenu', 'code-snippets') }
				],
				description: __('Add as top-level menu or submenu.', 'code-snippets')
			},
			submenu: {
				type: 'text',
				label: __('Parent Menu Slug', 'code-snippets'),
				value: 'options-general.php',
				required: true,
				placeholder: 'options-general.php',
				description: __('Parent menu slug (required for submenu). Common: options-general.php (Settings), tools.php (Tools), themes.php (Appearance)', 'code-snippets'),
				showIf: formData => 'add_menu_page' === formData.menu.menuType,
				validate: submenu =>
					submenu ? undefined : __('Parent menu slug is required for submenu', 'code-snippets')
			},
			pageTitle: {
				type: 'text',
				label: __('Page Title', 'code-snippets'),
				value: __('Settings', 'code-snippets'),
				required: true,
				placeholder: __('Settings', 'code-snippets'),
				description: __('Title shown at the top of the page.', 'code-snippets')
			},
			menuTitle: {
				type: 'text',
				label: __('Menu Title', 'code-snippets'),
				value: __('Settings', 'code-snippets'),
				required: true,
				placeholder: __('Settings', 'code-snippets'),
				description: __('Title shown in the admin menu.', 'code-snippets')
			},
			capability: {
				type: 'text',
				label: __('Capability', 'code-snippets'),
				value: 'manage_options',
				required: true,
				placeholder: 'manage_options',
				description: __('User capability required to access this page (e.g., manage_options).', 'code-snippets')
			},
			menuSlug: {
				type: 'text',
				label: __('Menu Slug', 'code-snippets'),
				value: 'custom-settings',
				required: true,
				placeholder: 'custom-settings',
				description: __('Unique identifier for the menu page. The callback function will be auto-generated from this.', 'code-snippets'),
				validate(slug) {
					if (!slug) {
						return __('Menu slug is required', 'code-snippets')
					} else if (!isValidWordPressKey(slug)) {
						return __('Menu slug must be a valid WordPress key', 'code-snippets')
					} else {
						return
					}
				}
			},
			menuIcon: {
				type: 'text',
				label: __('Menu Icon', 'code-snippets'),
				value: 'dashicons-admin-settings',
				placeholder: 'dashicons-admin-settings',
				description: __('Dashicon class name (only for top-level menu).', 'code-snippets')
			},
			menuPosition: {
				type: 'text',
				label: __('Menu Position', 'code-snippets'),
				value: '100',
				placeholder: '100',
				description: __('Menu position number (only for top-level menu). Lower numbers appear first.', 'code-snippets'),
				showIf: formData => 'add_menu_page' === formData.menu.menuType,
				validate(menuPosition) {
					const n = parseInt(menuPosition.trim(), 10)

					if (!isNaN(n) && (!Number.isInteger(n) || 0 > n)) {
						return __('Menu position must be a non-negative integer', 'code-snippets')
					} else {
						return
					}
				}
			}
		}
	},
	settings: {
		title: __('Settings', 'code-snippets'),
		fields: {
			settingsGroup: {
				type: 'text',
				label: __('Settings Group', 'code-snippets'),
				value: 'custom_settings_group',
				required: true,
				placeholder: 'custom_settings_group',
				description: __('Settings group identifier.', 'code-snippets'),
				validate(settingsGroup) {
					if (!settingsGroup) {
						return __('Settings group is required', 'code-snippets')
					} else if (!isValidWordPressKey(settingsGroup)) {
						return __('Settings group must be a valid WordPress key', 'code-snippets')
					} else {
						return
					}
				}
			},
			settingsBase: {
				type: 'text',
				label: __('Settings Name', 'code-snippets'),
				value: 'custom_settings',
				required: true,
				placeholder: 'custom_settings',
				description: __('Option name used to store settings in the database.', 'code-snippets'),
				validate(settingsBase) {
					if (!settingsBase.trim()) {
						return __('Settings name is required', 'code-snippets')
					} else if (!isValidWordPressKey(settingsBase.trim())) {
						return __('Settings name must be a valid WordPress key', 'code-snippets')
					} else {
						return
					}
				}
			}
		}
	},
	fields: {
		title: __('Fields', 'code-snippets'),
		description: __('Add settings fields using the repeater below. Each row defines one field (type, id, label, etc.).', 'code-snippets'),
		fields: {}
	}
}

export const SettingsPageFormRepeaters: BlueprintFormRepeaters<SettingsPageFormData, SettingsPageRepeaterData> = {
	fields: {
		section: 'fields',
		label: __('Settings fields', 'code-snippets'),
		addLabel: __('Add field', 'code-snippets'),
		emptyMessage: __('Add at least one field. Select a type and set ID and label for each.', 'code-snippets'),
		fields: {
			fieldType: {
				type: 'select',
				label: __('Type', 'code-snippets'),
				value: 'text',
				options: [
					{ value: '', label: __('None', 'code-snippets') },
					{ value: 'text', label: __('Text', 'code-snippets') },
					{ value: 'number', label: __('Number', 'code-snippets') },
					{ value: 'email', label: __('Email', 'code-snippets') },
					{ value: 'url', label: __('URL', 'code-snippets') },
					{ value: 'date', label: __('Date', 'code-snippets') },
					{ value: 'time', label: __('Time', 'code-snippets') },
					{ value: 'color', label: __('Color', 'code-snippets') },
					{ value: 'textarea', label: __('Textarea', 'code-snippets') },
					{ value: 'checkbox', label: __('Checkbox', 'code-snippets') },
					{ value: 'checkboxes', label: __('Checkboxes', 'code-snippets') },
					{ value: 'radio', label: __('Radio', 'code-snippets') },
					{ value: 'select', label: __('Select', 'code-snippets') }
				],
				description: __('Select the field type.', 'code-snippets')
			},
			id: {
				type: 'text',
				required: true,
				label: __('ID', 'code-snippets'),
				value: '',
				placeholder: 'field_name',
				description: __('Field identifier (lowercase, no spaces).', 'code-snippets'),
				validate: id =>
					isValidWordPressKey(id)
						? undefined
						: __('Field ID must be a valid WordPress key', 'code-snippets')
			},
			label: {
				type: 'text',
				required: true,
				label: __('Label', 'code-snippets'),
				value: '',
				placeholder: __('Field label', 'code-snippets'),
				description: __('Display label for the field.', 'code-snippets')
			},
			description: {
				type: 'text',
				label: __('Description', 'code-snippets'),
				value: '',
				placeholder: __('Field description text', 'code-snippets'),
				description: __('Help text shown below the field.', 'code-snippets')
			},
			defaultValue: {
				type: 'text',
				label: __('Default', 'code-snippets'),
				value: '',
				placeholder: 'default_value',
				description: __('Default value for the field.', 'code-snippets')
			},
			options: {
				type: 'textarea',
				label: __('Options', 'code-snippets'),
				value: '',
				required: true,
				placeholder: 'value1|Label 1\nvalue2|Label 2',
				description: __('Options for select/radio/checkboxes (format: value|Label, one per line).', 'code-snippets'),
				showIf: row => SETTING_FIELD_TYPES_WITH_OPTIONS.has(row.fieldType)
			}
		}
	}
}
