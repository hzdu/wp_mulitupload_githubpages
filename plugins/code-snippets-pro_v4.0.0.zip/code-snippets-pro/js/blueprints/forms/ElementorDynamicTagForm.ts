import { __ } from '@wordpress/i18n'
import { isValidShortcodeTag, isValidTextDomain } from '../utils/validate'
import type { BlueprintForm } from '../BlueprintBase'

export type TagGroupOption = 'post' | 'site' | 'author' | 'archive' | 'actions'

export type ValueSourceOption = 'post_meta' | 'user_meta' | 'option' | 'current_date' | 'custom_php'

export type EscapeModeOption = 'esc_html' | 'wp_kses_post'

export interface ElementorDynamicTagFormData {
	general: {
		tagName: string
		tagTitle: string
		tagGroup: TagGroupOption
		textDomain: string
	}
	valueSource: {
		valueSource: ValueSourceOption
		metaKey: string
		optionName: string
		dateFormat: string
		customPhp: string
	}
	controls: {
		enableFallback: boolean
		fallbackControlLabel: string
		fallbackControlDefault: string
	}
	output: {
		escapeMode: EscapeModeOption
	}
}

const tagGroupOptions: { value: TagGroupOption; label: string }[] = [
	{ value: 'post', label: __('Post', 'code-snippets') },
	{ value: 'site', label: __('Site', 'code-snippets') },
	{ value: 'author', label: __('Author', 'code-snippets') },
	{ value: 'archive', label: __('Archive', 'code-snippets') },
	{ value: 'actions', label: __('Actions', 'code-snippets') }
]

const valueSourceOptions: { value: ValueSourceOption; label: string }[] = [
	{ value: 'post_meta', label: __('Post meta', 'code-snippets') },
	{ value: 'user_meta', label: __('User meta', 'code-snippets') },
	{ value: 'option', label: __('Site option', 'code-snippets') },
	{ value: 'current_date', label: __('Current date', 'code-snippets') },
	{ value: 'custom_php', label: __('Custom PHP', 'code-snippets') }
]

const escapeModeOptions: { value: EscapeModeOption; label: string }[] = [
	{ value: 'esc_html', label: __('Plain text (esc_html)', 'code-snippets') },
	{ value: 'wp_kses_post', label: __('Basic HTML (wp_kses_post)', 'code-snippets') }
]

const usesMetaKey = (valueSource: ValueSourceOption): boolean =>
	'post_meta' === valueSource || 'user_meta' === valueSource

export const ElementorDynamicTagForm: BlueprintForm<ElementorDynamicTagFormData> = {
	general: {
		title: __('General', 'code-snippets'),
		description: __('Set the tag identity and where it appears in Elementor\u2019s dynamic tag picker.', 'code-snippets'),
		fields: {
			tagName: {
				type: 'text',
				label: __('Tag Name', 'code-snippets'),
				value: 'my-custom-tag',
				required: true,
				placeholder: 'my-custom-tag',
				description: __('Unique kebab-case ID returned by get_name(). Lowercase, start with a letter.', 'code-snippets'),
				validate(tagName) {
					if (!tagName.trim()) {
						return __('Tag name is required.', 'code-snippets')
					}
					if (!isValidShortcodeTag(tagName.trim())) {
						return __('Tag name must be lowercase, start with a letter, and contain only letters, numbers, underscores, or hyphens.', 'code-snippets')
					}
					return undefined
				}
			},
			tagTitle: {
				type: 'text',
				label: __('Tag Title', 'code-snippets'),
				value: 'My Custom Tag',
				required: true,
				placeholder: __('My Custom Tag', 'code-snippets'),
				description: __('Display label shown in the Elementor dynamic tag picker.', 'code-snippets')
			},
			tagGroup: {
				type: 'select',
				label: __('Tag Group', 'code-snippets'),
				value: 'post',
				required: true,
				options: tagGroupOptions,
				description: __('Built-in Elementor group where this tag appears in the picker.', 'code-snippets')
			},
			textDomain: {
				type: 'text',
				label: __('Text Domain', 'code-snippets'),
				value: 'code-snippets-blueprints',
				placeholder: 'code-snippets-blueprints',
				description: __('Optional. Used for translatable strings in the generated tag.', 'code-snippets'),
				validate: textDomain =>
					textDomain.trim() && !isValidTextDomain(textDomain.trim())
						? __('Text domain must contain only letters, numbers, underscores, or hyphens.', 'code-snippets')
						: undefined
			}
		}
	},
	valueSource: {
		title: __('Value Source', 'code-snippets'),
		description: __('Choose where the tag gets its output value from.', 'code-snippets'),
		fields: {
			valueSource: {
				type: 'select',
				label: __('Source', 'code-snippets'),
				value: 'post_meta',
				required: true,
				options: valueSourceOptions
			},
			metaKey: {
				type: 'text',
				label: __('Meta Key', 'code-snippets'),
				value: 'my_meta_key',
				placeholder: 'my_meta_key',
				description: __('Post or user meta key to read.', 'code-snippets'),
				showIf: formData => usesMetaKey(formData.valueSource.valueSource),
				validate: (metaKey, formData) =>
					usesMetaKey(formData.valueSource.valueSource) && !metaKey.trim()
						? __('Meta key is required.', 'code-snippets')
						: undefined
			},
			optionName: {
				type: 'text',
				label: __('Option Name', 'code-snippets'),
				value: '',
				placeholder: 'my_option_name',
				description: __('Name of the option in wp_options.', 'code-snippets'),
				showIf: formData => 'option' === formData.valueSource.valueSource,
				validate: (optionName, formData) =>
					'option' === formData.valueSource.valueSource && !optionName.trim()
						? __('Option name is required.', 'code-snippets')
						: undefined
			},
			dateFormat: {
				type: 'text',
				label: __('Date Format', 'code-snippets'),
				value: 'Y-m-d',
				placeholder: 'Y-m-d',
				description: __('PHP date format passed to wp_date().', 'code-snippets'),
				showIf: formData => 'current_date' === formData.valueSource.valueSource,
				validate: (dateFormat, formData) =>
					'current_date' === formData.valueSource.valueSource && !dateFormat.trim()
						? __('Date format is required.', 'code-snippets')
						: undefined
			},
			customPhp: {
				type: 'textarea',
				label: __('Custom PHP', 'code-snippets'),
				value: '',
				placeholder: "return get_post_meta( get_the_ID(), 'price', true );",
				description: __('Must return the value as a string. Runs inside a closure without access to $this.', 'code-snippets'),
				showIf: formData => 'custom_php' === formData.valueSource.valueSource,
				validate: (customPhp, formData) =>
					'custom_php' === formData.valueSource.valueSource && !customPhp.trim()
						? __('Custom PHP is required.', 'code-snippets')
						: undefined
			}
		}
	},
	controls: {
		title: __('Editor Controls', 'code-snippets'),
		description: __('Optional settings exposed in the Elementor editor when this tag is selected.', 'code-snippets'),
		fields: {
			enableFallback: {
				type: 'boolean-select',
				label: __('Enable Fallback Control', 'code-snippets'),
				value: false,
				required: true,
				description: __('When enabled, adds a Fallback text field in the Elementor editor used when the value is empty.', 'code-snippets')
			},
			fallbackControlLabel: {
				type: 'text',
				label: __('Fallback Label', 'code-snippets'),
				value: 'Fallback',
				placeholder: __('Fallback', 'code-snippets'),
				showIf: formData => formData.controls.enableFallback,
				validate: (fallbackControlLabel, formData) =>
					formData.controls.enableFallback && !fallbackControlLabel.trim()
						? __('Fallback label is required.', 'code-snippets')
						: undefined
			},
			fallbackControlDefault: {
				type: 'text',
				label: __('Fallback Default', 'code-snippets'),
				value: '',
				placeholder: '',
				description: __('Default value pre-filled in the Elementor editor.', 'code-snippets'),
				showIf: formData => formData.controls.enableFallback
			}
		}
	},
	output: {
		title: __('Output', 'code-snippets'),
		description: __('How the computed value is escaped before output.', 'code-snippets'),
		fields: {
			escapeMode: {
				type: 'select',
				label: __('Escape Mode', 'code-snippets'),
				value: 'esc_html',
				required: true,
				options: escapeModeOptions,
				description: __('Use wp_kses_post when the value contains basic HTML from a trusted source.', 'code-snippets')
			}
		}
	}
}
