import { __ } from '@wordpress/i18n'
import { isValidPhpIdentifier, isValidShortcodeTag, isValidTextDomain } from '../utils/validate'
import type { BlueprintForm, BlueprintFormRepeaters } from '../BlueprintBase'

export interface ShortcodeAttribute {
	name: string
	default: string
	type: 'string' | 'number' | 'boolean'
}

export interface ShortcodeFormData {
	general: {
		functionName: string
		shortcodeTag: string
		shortcodeDescription: string
		textDomain: string
		isEnclosing: boolean
		supportsNestedShortcodes: boolean
	}
	attributes: object
	output: {
		useOutputBuffering: boolean
		shortcodeCode: string
	}
}

export interface ShortcodeFormRepeaterData {
	shortcodeAttributes: ShortcodeAttribute
}

export const ShortcodeForm: BlueprintForm<ShortcodeFormData> = {
	general: {
		title: __('General', 'code-snippets'),
		fields: {
			functionName: {
				type: 'text',
				label: __('Function Name', 'code-snippets'),
				value: 'my_custom_shortcode',
				required: true,
				placeholder: __('my_custom_shortcode', 'code-snippets'),
				description: __('The callback function name for your shortcode.', 'code-snippets'),
				validate(functionName) {
					if (!functionName) {
						return __('Function name is required', 'code-snippets')
					} else if (!isValidPhpIdentifier(functionName)) {
						return __('Function name must be a valid PHP function name', 'code-snippets')
					} else {
						return
					}
				}
			},
			shortcodeTag: {
				type: 'text',
				label: __('Shortcode Tag', 'code-snippets'),
				value: 'my_shortcode',
				required: true,
				placeholder: __('my_shortcode', 'code-snippets'),
				description: __('The shortcode tag used in content (e.g., [my_shortcode]). Lowercase, no spaces.', 'code-snippets'),
				validate(tag) {
					if (!tag) {
						return __('Shortcode tag is required', 'code-snippets')
					}

					if (!isValidShortcodeTag(tag)) {
						return __('Shortcode tag must be lowercase, start with a letter, and contain only letters, numbers, underscores, or hyphens', 'code-snippets')
					}
					const reserved = ['embed', 'wp_caption', 'caption', 'gallery', 'playlist', 'audio', 'video']

					if (reserved.includes(tag)) {
						return __('This shortcode tag is reserved by WordPress', 'code-snippets')
					}

					return
				}
			},
			shortcodeDescription: {
				type: 'text',
				label: __('Description', 'code-snippets'),
				value: '',
				placeholder: __('A brief description of what this shortcode does', 'code-snippets'),
				description: __('Optional description for documentation purposes.', 'code-snippets')
			},
			textDomain: {
				type: 'text',
				label: __('Text Domain', 'code-snippets'),
				value: 'code-snippets-blueprints',
				placeholder: __('code-snippets-blueprints', 'code-snippets'),
				description: __('Translation text domain. Optional.', 'code-snippets'),
				validate: textDomain =>
					textDomain && !isValidTextDomain(textDomain)
						? __('Text domain must contain only letters, numbers, underscores, or hyphens', 'code-snippets')
						: undefined
			},
			isEnclosing: {
				type: 'select',
				label: __('Enclosing Shortcode', 'code-snippets'),
				value: false,
				required: true,
				options: [
					{ value: true, label: __('Yes (has content between tags)', 'code-snippets') },
					{ value: false, label: __('No (self-closing)', 'code-snippets') }
				],
				description: __('Enclosing shortcodes wrap content: [shortcode]content[/shortcode]', 'code-snippets')
			},
			supportsNestedShortcodes: {
				type: 'boolean-select',
				label: __('Support Nested Shortcodes', 'code-snippets'),
				value: false,
				required: true,
				description: __('Process shortcodes within the content using do_shortcode().', 'code-snippets')
			}
		}
	},
	attributes: {
		title: __('Attributes', 'code-snippets'),
		description: __('Add shortcode attributes (name and default value). Use $atts in your output code to read them.', 'code-snippets'),
		fields: {}
	},
	output: {
		title: __('Output', 'code-snippets'),
		fields: {
			useOutputBuffering: {
				type: 'select',
				label: __('Use Output Buffering', 'code-snippets'),
				value: false,
				required: true,
				options: [
					{ value: true, label: __('Yes (capture echo/print output)', 'code-snippets') },
					{ value: false, label: __('No (use return statement)', 'code-snippets') }
				],
				description: __('Enable output buffering to capture echoed content instead of returning.', 'code-snippets')
			},
			shortcodeCode: {
				type: 'textarea',
				label: __('Shortcode Code', 'code-snippets'),
				value:
`// Your shortcode output code here
// $atts['title'] comes from the shortcode attribute (e.g. [my_shortcode title="Custom"])
return '<div class="my-shortcode">' . esc_html( $atts['title'] ) . '</div>';`,
				required: true,
				placeholder: __('// Your shortcode code here\nreturn \'<div>Output</div>\';', 'code-snippets'),
				description: __('The PHP code that generates the shortcode output. Use $atts for attributes and $content for enclosed content.', 'code-snippets')
			}
		}
	}
}

export const ShortcodeFormRepeaters: BlueprintFormRepeaters<ShortcodeFormData, ShortcodeFormRepeaterData> = {
	shortcodeAttributes: {
		section: 'attributes',
		label: __('Shortcode attributes', 'code-snippets'),
		addLabel: __('Add attribute', 'code-snippets'),
		allowEmpty: true,
		emptyMessage: __('No attributes. Add rows for name and default value, or leave empty.', 'code-snippets'),
		fields: {
			name: {
				type: 'text',
				label: __('Attribute name', 'code-snippets'),
				value: '',
				placeholder: 'title',
				description: __('Lowercase, no spaces (e.g. title, count, show_date).', 'code-snippets'),
				validate: attributeName =>
					attributeName && !isValidPhpIdentifier(attributeName)
						? __('Attribute name must be a valid PHP variable name (letters, numbers, underscores).', 'code-snippets')
						: undefined
			},
			default: {
				type: 'text',
				label: __('Default value', 'code-snippets'),
				value: '',
				placeholder: __('Hello World', 'code-snippets'),
				description: __('Used when the attribute is not provided. Use true/false for boolean, a number for numeric.', 'code-snippets')
			},
			type: {
				type: 'select',
				label: __('Attribute type', 'code-snippets'),
				value: 'string',
				options: [
					{ value: 'string', label: __('Text', 'code-snippets') },
					{ value: 'number', label: __('Number', 'code-snippets') },
					{ value: 'boolean', label: __('Boolean', 'code-snippets') }
				]
			}
		}
	}
}
