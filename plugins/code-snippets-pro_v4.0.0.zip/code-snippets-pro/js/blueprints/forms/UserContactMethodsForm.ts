import { __ } from '@wordpress/i18n'
import { isValidTextDomain, isValidWordPressKey } from '../utils/validate'
import type { BlueprintForm, BlueprintFormRepeaters } from '../BlueprintBase'

const LABEL_MAX_LENGTH = 255

export interface ProfileField {
	fieldKey: string
	label: string
}

export interface UserContactMethodsFormData {
	general: {
		textDomain: string
	}
	profileFields: object
}

export interface UserContactMethodsRepeaterData {
	profileFields: ProfileField
}

export const UserContactMethodsForm: BlueprintForm<UserContactMethodsFormData> = {
	general: {
		title: __('General', 'code-snippets'),
		fields: {
			textDomain: {
				type: 'text',
				label: __('Text Domain', 'code-snippets'),
				value: 'code-snippets-blueprints',
				placeholder: 'text_domain',
				description: __('Translation file text domain. Optional.', 'code-snippets'),
				validate: textDomain =>
					textDomain && !isValidTextDomain(textDomain)
						? __('Text domain must contain only letters, numbers, underscores, or hyphens', 'code-snippets')
						: undefined
			}
		}
	},
	profileFields: {
		title: __('Profile Fields', 'code-snippets'),
		description: __('Add profile fields using the repeater below. Each row has a field key and a display label.', 'code-snippets'),
		fields: {}
	}
}

export const UserContactMethodsRepeaters: BlueprintFormRepeaters<UserContactMethodsFormData, UserContactMethodsRepeaterData> = {
	profileFields: {
		section: 'profileFields',
		label: __('Profile fields', 'code-snippets'),
		addLabel: __('Add field', 'code-snippets'),
		emptyMessage: __('Add at least one profile field (field key and label).', 'code-snippets'),
		fields: {
			fieldKey: {
				type: 'text',
				label: __('Field key', 'code-snippets'),
				value: '',
				required: true,
				placeholder: 'linkedin',
				description: __('Lowercase, no spaces (e.g. linkedin, github, phone).', 'code-snippets'),
				validate: fieldKey =>
					fieldKey && !isValidWordPressKey(fieldKey)
						? __('Field key must be lowercase, max 32 characters, and contain only letters, numbers, underscores, or hyphens', 'code-snippets')
						: undefined
			},
			label: {
				type: 'text',
				label: __('Label', 'code-snippets'),
				value: '',
				required: true,
				placeholder: __('LinkedIn', 'code-snippets'),
				description: __('Display label for this field.', 'code-snippets'),
				validate: label =>
					label && label.length > LABEL_MAX_LENGTH
						? __('Label must be 255 characters or less', 'code-snippets')
						: undefined
			}
		}
	}
}
