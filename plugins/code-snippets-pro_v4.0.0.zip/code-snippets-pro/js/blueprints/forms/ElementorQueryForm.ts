import { __ } from '@wordpress/i18n'
import { isValidPhpIdentifier } from '../utils/validate'
import type { BlueprintForm, BlueprintFormRepeaters } from '../BlueprintBase'

export type OrderByOption =
	| 'date'
	| 'title'
	| 'menu_order'
	| 'rand'
	| 'comment_count'
	| 'meta_value'
	| 'meta_value_num'
	| 'custom'

export type OrderDirection = 'ASC' | 'DESC'

export type MetaCompareOperator =
	| '='
	| '!='
	| '>'
	| '>='
	| '<'
	| '<='
	| 'LIKE'
	| 'NOT LIKE'
	| 'IN'
	| 'NOT IN'
	| 'EXISTS'
	| 'NOT EXISTS'

export type MetaValueType = 'CHAR' | 'NUMERIC' | 'DATE' | 'DATETIME' | 'TIME' | 'BINARY'

export type TaxQueryField = 'term_id' | 'slug' | 'name'

export type TaxQueryOperator = 'IN' | 'NOT IN' | 'AND' | 'EXISTS' | 'NOT EXISTS'

export interface MetaQueryRow {
	key: string
	value: string
	compare: MetaCompareOperator
	type: MetaValueType
}

export interface TaxQueryRow {
	taxonomy: string
	field: TaxQueryField
	terms: string
	operator: TaxQueryOperator
}

export interface ElementorQueryFormData {
	general: {
		queryId: string
		description: string
	}
	postTypes: {
		enablePostTypeFilter: boolean
		postTypes: string
	}
	postStatus: {
		enablePostStatusFilter: boolean
		postStatuses: string
	}
	pagination: {
		enablePostsPerPage: boolean
		postsPerPage: string
	}
	ordering: {
		enableOrder: boolean
		orderby: OrderByOption
		customOrderby: string
		order: OrderDirection
		metaKey: string
	}
	metaQuery: object
	taxQuery: object
	custom: {
		customCode: string
	}
}

export interface ElementorQueryRepeaterData {
	metaQueryRows: MetaQueryRow
	taxQueryRows: TaxQueryRow
}

const isIntegerOrAllPosts = (value: string): boolean =>
	/^-1$|^[1-9]\d*$/.test(value.trim())

const hasNonEmptyCsvTokens = (value: string): boolean =>
	0 < value.split(',').map(token => token.trim()).filter(Boolean).length

const orderByOptions: { value: OrderByOption; label: string }[] = [
	{ value: 'date', label: __('Date', 'code-snippets') },
	{ value: 'title', label: __('Title', 'code-snippets') },
	{ value: 'menu_order', label: __('Menu Order', 'code-snippets') },
	{ value: 'rand', label: __('Random', 'code-snippets') },
	{ value: 'comment_count', label: __('Comment Count', 'code-snippets') },
	{ value: 'meta_value', label: __('Meta Value (text)', 'code-snippets') },
	{ value: 'meta_value_num', label: __('Meta Value (numeric)', 'code-snippets') },
	{ value: 'custom', label: __('Custom…', 'code-snippets') }
]

const orderDirectionOptions: { value: OrderDirection; label: string }[] = [
	{ value: 'ASC', label: __('Ascending', 'code-snippets') },
	{ value: 'DESC', label: __('Descending', 'code-snippets') }
]

const metaCompareOptions: { value: MetaCompareOperator; label: string }[] = [
	{ value: '=', label: '=' },
	{ value: '!=', label: '!=' },
	{ value: '>', label: '>' },
	{ value: '>=', label: '>=' },
	{ value: '<', label: '<' },
	{ value: '<=', label: '<=' },
	{ value: 'LIKE', label: 'LIKE' },
	{ value: 'NOT LIKE', label: 'NOT LIKE' },
	{ value: 'IN', label: 'IN' },
	{ value: 'NOT IN', label: 'NOT IN' },
	{ value: 'EXISTS', label: 'EXISTS' },
	{ value: 'NOT EXISTS', label: 'NOT EXISTS' }
]

const metaTypeOptions: { value: MetaValueType; label: string }[] = [
	{ value: 'CHAR', label: 'CHAR' },
	{ value: 'NUMERIC', label: 'NUMERIC' },
	{ value: 'DATE', label: 'DATE' },
	{ value: 'DATETIME', label: 'DATETIME' },
	{ value: 'TIME', label: 'TIME' },
	{ value: 'BINARY', label: 'BINARY' }
]

const taxFieldOptions: { value: TaxQueryField; label: string }[] = [
	{ value: 'term_id', label: __('Term ID', 'code-snippets') },
	{ value: 'slug', label: __('Slug', 'code-snippets') },
	{ value: 'name', label: __('Name', 'code-snippets') }
]

const taxOperatorOptions: { value: TaxQueryOperator; label: string }[] = [
	{ value: 'IN', label: 'IN' },
	{ value: 'NOT IN', label: 'NOT IN' },
	{ value: 'AND', label: 'AND' },
	{ value: 'EXISTS', label: 'EXISTS' },
	{ value: 'NOT EXISTS', label: 'NOT EXISTS' }
]

export const ElementorQueryForm: BlueprintForm<ElementorQueryFormData> = {
	general: {
		title: __('General', 'code-snippets'),
		description: __('Set the Query ID assigned to the Elementor widget under Advanced › Query controls.', 'code-snippets'),
		fields: {
			queryId: {
				type: 'text',
				label: __('Query ID', 'code-snippets'),
				value: 'my_custom_filter',
				required: true,
				placeholder: 'my_custom_filter',
				description: __('Must match the Query ID set on the Elementor widget. Start with a letter or underscore; letters, numbers and underscores only.', 'code-snippets'),
				validate(queryId) {
					if (!queryId.trim()) {
						return __('Query ID is required.', 'code-snippets')
					}
					if (!isValidPhpIdentifier(queryId.trim())) {
						return __('Query ID must start with a letter or underscore and contain only letters, numbers, and underscores.', 'code-snippets')
					}
					return undefined
				}
			},
			description: {
				type: 'text',
				label: __('Description', 'code-snippets'),
				value: '',
				placeholder: __('Optional short note about this query modification.', 'code-snippets'),
				description: __('Optional. Included as a comment in the generated snippet.', 'code-snippets')
			}
		}
	},
	postTypes: {
		title: __('Post Types', 'code-snippets'),
		fields: {
			enablePostTypeFilter: {
				type: 'boolean-select',
				label: __('Filter by Post Type', 'code-snippets'),
				value: true,
				required: true,
				description: __('Override which post types the widget queries.', 'code-snippets')
			},
			postTypes: {
				type: 'text',
				label: __('Post Types', 'code-snippets'),
				value: 'post',
				placeholder: 'post,page',
				description: __('Comma-separated list of post type slugs (e.g. post,page,product).', 'code-snippets'),
				showIf: formData => formData.postTypes.enablePostTypeFilter,
				validate: (postTypes, formData) =>
					formData.postTypes.enablePostTypeFilter && !hasNonEmptyCsvTokens(postTypes)
						? __('Add at least one post type.', 'code-snippets')
						: undefined
			}
		}
	},
	postStatus: {
		title: __('Post Status', 'code-snippets'),
		fields: {
			enablePostStatusFilter: {
				type: 'boolean-select',
				label: __('Filter by Post Status', 'code-snippets'),
				value: false,
				required: true,
				description: __('Override which post statuses the widget queries.', 'code-snippets')
			},
			postStatuses: {
				type: 'text',
				label: __('Post Statuses', 'code-snippets'),
				value: 'publish',
				placeholder: 'publish,private',
				description: __('Comma-separated list of post statuses (e.g. publish,private,draft).', 'code-snippets'),
				showIf: formData => formData.postStatus.enablePostStatusFilter,
				validate: (postStatuses, formData) =>
					formData.postStatus.enablePostStatusFilter && !hasNonEmptyCsvTokens(postStatuses)
						? __('Add at least one post status.', 'code-snippets')
						: undefined
			}
		}
	},
	pagination: {
		title: __('Pagination', 'code-snippets'),
		fields: {
			enablePostsPerPage: {
				type: 'boolean-select',
				label: __('Override Posts Per Page', 'code-snippets'),
				value: true,
				required: true,
				description: __('Override the number of posts returned by the widget.', 'code-snippets')
			},
			postsPerPage: {
				type: 'text',
				label: __('Posts Per Page', 'code-snippets'),
				value: '5',
				placeholder: '10',
				description: __('A positive integer, or -1 to return every matching post.', 'code-snippets'),
				showIf: formData => formData.pagination.enablePostsPerPage,
				validate(postsPerPage, formData) {
					if (!formData.pagination.enablePostsPerPage) {
						return undefined
					}
					if (!postsPerPage.trim()) {
						return __('Posts per page is required.', 'code-snippets')
					}
					if (!isIntegerOrAllPosts(postsPerPage)) {
						return __('Posts per page must be -1 or a positive integer.', 'code-snippets')
					}
					return undefined
				}
			}
		}
	},
	ordering: {
		title: __('Ordering', 'code-snippets'),
		fields: {
			enableOrder: {
				type: 'boolean-select',
				label: __('Override Ordering', 'code-snippets'),
				value: false,
				required: true,
				description: __('Override the order and orderby parameters used by the widget.', 'code-snippets')
			},
			orderby: {
				type: 'select',
				label: __('Order By', 'code-snippets'),
				value: 'date',
				required: true,
				options: orderByOptions,
				showIf: formData => formData.ordering.enableOrder,
				description: __('Property used to sort results.', 'code-snippets')
			},
			customOrderby: {
				type: 'text',
				label: __('Custom Order By', 'code-snippets'),
				value: '',
				placeholder: 'modified',
				description: __('A custom orderby value passed directly to WP_Query (e.g. modified, post__in, name).', 'code-snippets'),
				showIf: formData =>
					formData.ordering.enableOrder && 'custom' === formData.ordering.orderby,
				validate: (customOrderby, formData) =>
					formData.ordering.enableOrder && 'custom' === formData.ordering.orderby && !customOrderby.trim()
						? __('Custom order by value is required.', 'code-snippets')
						: undefined
			},
			order: {
				type: 'select',
				label: __('Order Direction', 'code-snippets'),
				value: 'DESC',
				required: true,
				options: orderDirectionOptions,
				showIf: formData => formData.ordering.enableOrder,
				description: __('Sort direction.', 'code-snippets')
			},
			metaKey: {
				type: 'text',
				label: __('Meta Key', 'code-snippets'),
				value: '',
				placeholder: 'price',
				description: __('The post meta key whose value drives the ordering.', 'code-snippets'),
				showIf: formData =>
					formData.ordering.enableOrder && formData.ordering.orderby.startsWith('meta_value'),
				validate: (metaKey, formData) =>
					formData.ordering.enableOrder &&
					formData.ordering.orderby.startsWith('meta_value') &&
					!metaKey.trim()
						? __('Meta key is required when ordering by a meta value.', 'code-snippets')
						: undefined
			}
		}
	},
	metaQuery: {
		title: __('Meta Query', 'code-snippets'),
		description: __('Add meta_query rows to filter by post meta. Each row is appended to any existing meta_query.', 'code-snippets'),
		fields: {}
	},
	taxQuery: {
		title: __('Taxonomy Query', 'code-snippets'),
		description: __('Add tax_query rows to filter by taxonomy. Each row is appended to any existing tax_query.', 'code-snippets'),
		fields: {}
	},
	custom: {
		title: __('Custom Code', 'code-snippets'),
		description: __('Optional raw PHP appended to the callback body. The query variable is $query (a WP_Query).', 'code-snippets'),
		fields: {
			customCode: {
				type: 'textarea',
				label: __('Additional PHP', 'code-snippets'),
				value: '',
				placeholder: "$query->set( 'no_found_rows', true );",
				description: __('Inserted verbatim at the end of the callback. Call any $query->set( … ) you need.', 'code-snippets')
			}
		}
	}
}

export const ElementorQueryFormRepeaters: BlueprintFormRepeaters<ElementorQueryFormData, ElementorQueryRepeaterData> = {
	metaQueryRows: {
		section: 'metaQuery',
		label: __('Meta query rows', 'code-snippets'),
		addLabel: __('Add meta query row', 'code-snippets'),
		allowEmpty: true,
		emptyMessage: __('No meta query rows. Add a row to filter by post meta.', 'code-snippets'),
		fields: {
			key: {
				type: 'text',
				label: __('Meta Key', 'code-snippets'),
				value: '',
				required: true,
				placeholder: 'featured'
			},
			value: {
				type: 'text',
				label: __('Value', 'code-snippets'),
				value: '',
				placeholder: '1',
				description: __('For IN / NOT IN, separate values with commas.', 'code-snippets'),
				hideIf: row => 'EXISTS' === row.compare || 'NOT EXISTS' === row.compare
			},
			compare: {
				type: 'select',
				label: __('Compare', 'code-snippets'),
				value: '=',
				required: true,
				options: metaCompareOptions
			},
			type: {
				type: 'select',
				label: __('Type', 'code-snippets'),
				value: 'CHAR',
				required: true,
				options: metaTypeOptions
			}
		}
	},
	taxQueryRows: {
		section: 'taxQuery',
		label: __('Taxonomy query rows', 'code-snippets'),
		addLabel: __('Add tax query row', 'code-snippets'),
		allowEmpty: true,
		emptyMessage: __('No taxonomy query rows. Add a row to filter by taxonomy.', 'code-snippets'),
		fields: {
			taxonomy: {
				type: 'text',
				label: __('Taxonomy', 'code-snippets'),
				value: '',
				required: true,
				placeholder: 'category',
				description: __('Taxonomy slug (e.g. category, post_tag, product_cat).', 'code-snippets')
			},
			field: {
				type: 'select',
				label: __('Field', 'code-snippets'),
				value: 'slug',
				required: true,
				options: taxFieldOptions
			},
			terms: {
				type: 'text',
				label: __('Terms', 'code-snippets'),
				value: '',
				required: true,
				placeholder: 'news,featured',
				description: __('Comma-separated list of term identifiers (matching the field above).', 'code-snippets')
			},
			operator: {
				type: 'select',
				label: __('Operator', 'code-snippets'),
				value: 'IN',
				required: true,
				options: taxOperatorOptions
			}
		}
	}
}
