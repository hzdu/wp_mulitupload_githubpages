import { __ } from '@wordpress/i18n'
import { v4 as uuid } from 'uuid'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'
import type { EmbeddedFormField, FormField } from '../types/blueprints/FormField'

export type BlueprintFormRepeaters<FormData, RepeaterData> = {
	[R in keyof RepeaterData]: {
		section: keyof FormData
		label: string
		addLabel?: string
		allowEmpty?: true
		emptyMessage?: string
		fields: {
			[F in keyof RepeaterData[R]]: FormField<RepeaterData[R][F]> & EmbeddedFormField<RepeaterData[R][F], RepeaterData[R]>
		}
	}
}

export type BlueprintForm<FormData> = {
	[S in keyof FormData]: {
		title: string
		description?: string
		fields: {
			[F in keyof FormData[S]]: FormField<FormData[S][F]> & EmbeddedFormField<FormData[S][F], FormData>
		}
	}
}

export interface BlueprintFormField<FormData, S extends keyof FormData, F extends keyof FormData[S]> {
	section: S
	name: F
	props: FormField<FormData[S][F]>
	error: string | undefined
}

export interface BlueprintRepeaterField<RepeaterFields, R extends keyof RepeaterFields, FormData> {
	section: keyof FormData
	name: R
	error: string | undefined
	label: string
	addLabel?: string
	allowEmpty?: boolean
	emptyMessage?: string
}

export type BlueprintRepeaterData<RepeaterFields> = {
	[R in keyof RepeaterFields]?: Partial<Record<string, RepeaterFields[R]>>
}

export interface BlueprintRepeaterRow<T> {
	rowId: string
	fields: {
		props: FormField<T[keyof T]>
		name: keyof T
		error: string | undefined
	}[]
}

const literalObjectKeys = <T extends object>(object: T): readonly (keyof T)[] =>
	<(keyof T)[]> Object.keys(object)

const isFieldVisible = <T, V>(field: EmbeddedFormField<T, V>, values: V): boolean =>
	!field.hideIf?.(values) && (!field.showIf || field.showIf(values))

export abstract class BlueprintBase<FormData, RepeaterFields = never> {
	protected readonly formData: FormData
	protected fieldErrors: { [S in keyof FormData]?: { [F in keyof FormData[S]]?: string } } = {}
	protected repeaterErrors: { [R in keyof RepeaterFields]?: string } = {}
	protected repeaterFieldErrors: {
		[R in keyof RepeaterFields]?: Partial<Record<string, { [F in keyof RepeaterFields[R]]?: string }>>
	} = {}

	protected constructor(
		public readonly defaultSectionKey: keyof FormData,
		protected readonly form: BlueprintForm<FormData>,
		formData?: FormData,
		protected readonly repeaterFields?: BlueprintFormRepeaters<FormData, RepeaterFields>,
		protected readonly repeaterData: BlueprintRepeaterData<RepeaterFields> = {}
	) {
		this.formData = formData ?? <FormData> Object.fromEntries(
			literalObjectKeys(this.form).map(sectionKey => {
				return [sectionKey, Object.fromEntries(
					literalObjectKeys(this.form[sectionKey].fields).map(fieldKey =>
						[fieldKey, this.form[sectionKey].fields[fieldKey].value]))]
			})
		)
	}

	static getMetadata(): BlueprintMetadata {
		throw new Error('getMetadata() must be implemented in the Blueprint subclass')
	}

	getMetadata(): BlueprintMetadata {
		return (<typeof BlueprintBase> this.constructor).getMetadata()
	}

	getDefaultSnippetName(): string {
		return __('Generated', 'code-snippets')
	}

	getDefaultSnippetDescription() {
		return `Auto-generated ${this.getMetadata().slug} code`
	}

	abstract generateCode(): string

	validate(): void {
		this.fieldErrors = {}

		for (const sectionKey in this.formData) {
			const section = this.form[sectionKey]

			literalObjectKeys(section.fields)
				.filter(fieldKey => isFieldVisible(section.fields[fieldKey], this.formData))
				.forEach(fieldKey => {
					const field = section.fields[fieldKey]
					const value = this.formData[sectionKey][fieldKey]
					const errorMessage = BlueprintBase.validateField(field, value, this.formData)
					if (errorMessage) {
						this.fieldErrors[sectionKey] = { ...this.fieldErrors[sectionKey], [fieldKey]: errorMessage }
					}
				})
		}

		if (this.repeaterFields) {
			this.repeaterFieldErrors = {}

			for (const repeaterKey of literalObjectKeys(this.repeaterFields)) {
				this.validateRepeaterField(repeaterKey)
			}
		}
	}

	private validateRepeaterField(repeaterKey: keyof RepeaterFields) {
		const repeater = this.repeaterFields?.[repeaterKey]
		if (!repeater) {
			return
		}

		const rows = this.getRepeaterRows(repeaterKey)
		if (0 === rows.length) {
			if (!repeater.allowEmpty) {
				this.repeaterErrors[repeaterKey] = repeater.emptyMessage ?? __('Please add at least one item.', 'code-snippets')
			}
			return
		}

		for (const row of rows) {
			for (const field of row.fields) {
				const errorMessage = BlueprintBase.validateField(field.props, field.props.value, row)

				if (errorMessage) {
					this.repeaterFieldErrors[repeaterKey] = {
						...this.repeaterFieldErrors[repeaterKey],
						[row.rowId]: {
							...this.repeaterFieldErrors[repeaterKey]?.[row.rowId],
							[field.name]: errorMessage
						}
					}
				}
			}
		}
	}

	private static validateField<T, V>(field: FormField<T> & EmbeddedFormField<T, V>, value: T, values: V) {
		return field.required && (value === undefined || '' === value || Array.isArray(value) && 0 === value.length)
			? __('This field is required.', 'code-snippets')
			: field.validate?.(value, values)
	}

	hasValidationErrors(): boolean {
		return literalObjectKeys(this.form).some(sectionKey =>
			this.fieldErrors[sectionKey] && Object.values(this.fieldErrors[sectionKey]).some(Boolean)) ||
			!!this.repeaterFields && literalObjectKeys(this.repeaterFields).some(repeaterKey =>
				!!this.repeaterErrors[repeaterKey] ||
				this.repeaterFieldErrors[repeaterKey] && Object.values(this.repeaterFieldErrors[repeaterKey]).some(errors =>
					errors && Object.values(errors).some(Boolean)))
	}

	getFormSection<S extends keyof FormData>(section: S): BlueprintForm<FormData>[S] {
		return this.form[section]
	}

	getFormSectionKeys(): readonly (keyof FormData)[] {
		return literalObjectKeys(this.form)
	}

	getSectionFields<S extends keyof FormData>(section: S): BlueprintFormField<FormData, S, keyof FormData[S]>[] {
		return literalObjectKeys(this.form[section].fields)
			.filter(fieldKey => isFieldVisible(this.form[section].fields[fieldKey], this.formData))
			.map(fieldKey => this.getSectionField(section, fieldKey))
	}

	getSectionField<S extends keyof FormData, F extends keyof FormData[S]>(
		sectionKey: S,
		fieldKey: F
	): BlueprintFormField<FormData, S, F> {
		const field = this.form[sectionKey].fields[fieldKey]
		field.value = this.formData[sectionKey][fieldKey]

		return {
			section: sectionKey,
			name: fieldKey,
			props: field,
			error: this.fieldErrors[sectionKey]?.[fieldKey]
		}
	}

	getFieldValue<S extends keyof FormData, F extends keyof FormData[S]>(
		sectionKey: S,
		fieldKey: F
	): FormData[S][F] {
		return this.formData[sectionKey][fieldKey]
	}

	getRepeaterEntries<R extends keyof RepeaterFields>(repeater: R): RepeaterFields[R][] {
		return this.repeaterData[repeater]
			? Object.values(this.repeaterData[repeater]).filter(entry => entry !== undefined)
			: []
	}

	protected abstract construct(
		formData?: FormData,
		repeaterData?: BlueprintRepeaterData<RepeaterFields>
	): BlueprintBase<FormData, RepeaterFields>

	public clone(): BlueprintBase<FormData, RepeaterFields> {
		return this.construct(this.formData, this.repeaterData)
	}

	modifyFieldValue<S extends keyof FormData, F extends keyof FormData[S]>(
		section: S,
		field: F,
		value: FormData[S][F]
	): BlueprintBase<FormData, RepeaterFields> {
		const formData: FormData = { ...this.formData, [section]: { ...this.formData[section], [field]: value } }

		return this.construct(
			this.form[section].fields[field].onUpdate?.(value, formData) ?? formData,
			this.repeaterData
		)
	}

	getSectionRepeaters(section: keyof FormData): BlueprintRepeaterField<RepeaterFields, keyof RepeaterFields, FormData>[] {
		return this.repeaterFields
			? literalObjectKeys(this.repeaterFields)
				.filter(repeaterKey => this.repeaterFields?.[repeaterKey].section === section)
				.map(repeaterKey => this.getRepeaterField(repeaterKey))
				.filter(repeater => repeater !== undefined)
			: []
	}

	getRepeaterField(name: keyof RepeaterFields) {
		return this.repeaterFields?.[name]
			? { ...this.repeaterFields[name], name, error: this.repeaterErrors[name] }
			: undefined
	}

	getRepeaterRows<R extends keyof RepeaterFields>(repeater: R): BlueprintRepeaterRow<RepeaterFields[R]>[] {
		const data = this.repeaterData[repeater]
		const fields = this.repeaterFields?.[repeater].fields

		return fields && data
			? Object.keys(data).map<BlueprintRepeaterRow<RepeaterFields[R]>>(rowId => ({
				rowId,
				fields: literalObjectKeys(fields)
					.map(name => {
						const props = { ...fields[name] }

						if (data[rowId]?.[name]) {
							props.value = data[rowId][name]
						}

						const error = this.repeaterFieldErrors[repeater]?.[rowId]?.[name]
						return { name, props, error }
					})
					.filter(field => !data[rowId] || isFieldVisible(field.props, data[rowId]))
			}))
			: []
	}

	addRepeaterRow(repeaterKey: keyof RepeaterFields): BlueprintBase<FormData, RepeaterFields> {
		const repeaterField = this.repeaterFields?.[repeaterKey]
		if (!repeaterField) {
			return this
		}

		const blankRow = Object.fromEntries(
			literalObjectKeys(repeaterField.fields)
				.map(fieldKey => [fieldKey, repeaterField.fields[fieldKey].value]))

		const repeaterData = {
			...this.repeaterData,
			[repeaterKey]: { ...this.repeaterData[repeaterKey], [uuid()]: blankRow }
		}

		return this.construct(this.formData, repeaterData)
	}

	removeRepeaterRow(repeaterKey: keyof RepeaterFields, rowId: string): BlueprintBase<FormData, RepeaterFields> {
		if (!this.repeaterData[repeaterKey]?.[rowId]) {
			return this
		}

		const { [rowId]: _, ...dataCopy } = this.repeaterData[repeaterKey]
		const repeaterData = { ...this.repeaterData, [repeaterKey]: dataCopy }
		return this.construct(this.formData, repeaterData)
	}

	setRepeaterField<R extends keyof RepeaterFields, F extends keyof RepeaterFields[R]>(
		repeater: R,
		rowId: string,
		field: F,
		value: RepeaterFields[R][F]
	): BlueprintBase<FormData, RepeaterFields> {
		const repeaterData = {
			...this.repeaterData,
			[repeater]: {
				...this.repeaterData[repeater],
				[rowId]: {
					...this.repeaterData[repeater]?.[rowId],
					[field]: value
				}
			}
		}

		return this.construct(this.formData, repeaterData)
	}
}
