import { ElementorDynamicTagBlueprint } from './ElementorDynamicTagBlueprint'
import { ElementorQueryBlueprint } from './ElementorQueryBlueprint'
import { PostTypeBlueprint } from './PostTypeBlueprint'
import { SettingsPageBlueprint } from './SettingsPageBlueprint'
import { ShortcodeBlueprint } from './ShortcodeBlueprint'
import { TaxonomyBlueprint } from './TaxonomyBlueprint'
import { UserContactMethodsBlueprint } from './UserContactMethodsBlueprint'
import type { BlueprintBase } from './BlueprintBase'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'

export const registry = [
	ElementorDynamicTagBlueprint,
	ElementorQueryBlueprint,
	PostTypeBlueprint,
	SettingsPageBlueprint,
	ShortcodeBlueprint,
	TaxonomyBlueprint,
	UserContactMethodsBlueprint
]

export interface BlueprintListItem {
	metadata: BlueprintMetadata
	construct: () => BlueprintBase<unknown>
}

export const listBlueprints = (): BlueprintListItem[] =>
	registry
		.map((definition, index) =>
			({
				index,
				definition,
				construct: () => <BlueprintBase<unknown>> <unknown> new definition(),
				metadata: definition.getMetadata()
			}))
		.sort((a, b) => {
			const diff = a.metadata.order - b.metadata.order
			return 0 === diff ? a.index - b.index : diff
		})
		.map(({ construct, metadata }) => ({ construct, metadata }))
