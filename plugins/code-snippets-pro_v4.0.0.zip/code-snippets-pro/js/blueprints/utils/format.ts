const htmlSpecialCharsMap: Record<string, string> = {
	'&': '&amp;',
	'<': '&lt;',
	'>': '&gt;',
	'"': '&quot;',
	"'": '&#039;'
}

export const sanitizePhpIdentifier = (identifier: string): string =>
	identifier.replace(/^[^A-Za-z_]|[^\w\x80-\xff]*/, '')

export const escapeHtmlAttr = (text: string): string =>
	text.replace(/[&<>"']/g, match => htmlSpecialCharsMap[match])

export const formatPhpCommentText = (text: string): string =>
	text
		.replace(/\*\//g, '* /')
		.replace(/\n/g, '\n * ')

export const formatPhpValue = (value: string | boolean | number | undefined | null): string => {
	if (value === undefined || null === value) {
		return 'null'
	}

	if ('boolean' === typeof value || 'number' === typeof value) {
		return String(value)
	}

	return formatPhpString(value)
}

export const joinAsPhpArray = (escapedData: Record<string, string | undefined>, indent = '\t\t') => {
	const maxKeyLength = Object.entries(escapedData)
		.reduce((max, [key, value]) =>
			value === undefined ? max : Math.max(max, key.length), 0)

	return Object.entries(escapedData)
		.map(([key, value]) =>
			value === undefined ? undefined
				: `${indent}${formatPhpString(key).padEnd(maxKeyLength - key.length)} => ${value},`)
		.filter(entry => entry !== undefined)
		.join('\n')
}

export const formatPhpString = (text: string, textDomain?: string): string =>
	textDomain
		? `__( ${formatPhpString(text)}, ${formatPhpString(textDomain)} )`
		: `'${text
			.replace(/\\/g, '\\\\')
			.replace(/'/g, "\\'")}'`

export const formatTranslateX = (text: string, contextStr: string, textDomain: string) =>
	textDomain
		? `_x( ${formatPhpString(text)}, ${formatPhpString(contextStr)}, ${formatPhpString(textDomain)} )`
		: formatPhpString(text)
