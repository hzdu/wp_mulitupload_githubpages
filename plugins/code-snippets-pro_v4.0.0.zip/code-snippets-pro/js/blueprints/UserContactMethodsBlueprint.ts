import { __ } from '@wordpress/i18n'
import { v4 as uuid } from 'uuid'
import { BlueprintBase } from './BlueprintBase'
import { UserContactMethodsForm, UserContactMethodsRepeaters } from './forms/UserContactMethodsForm'
import { formatPhpCommentText, formatPhpString } from './utils/format'
import type { BlueprintRepeaterData } from './BlueprintBase'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'
import type { ProfileField, UserContactMethodsFormData, UserContactMethodsRepeaterData } from './forms/UserContactMethodsForm'

const DEFAULT_PROFILE_FIELD: ProfileField = {
	fieldKey: 'linkedin',
	label: 'LinkedIn'
}

export class UserContactMethodsBlueprint extends BlueprintBase<UserContactMethodsFormData, UserContactMethodsRepeaterData> {
	static override getMetadata(): BlueprintMetadata {
		return {
			order: 35,
			recommendedScope: 'admin',
			slug: 'user-profile-fields',
			title: __('Add Extra User Profile Fields', 'code-snippets'),
			description: __('Add custom fields to user profiles (e.g. LinkedIn, GitHub, phone, or any custom field).', 'code-snippets'),
			categories: ['admin'],
			docsUrl: 'https://codesnippets.pro/doc/blueprint-add-extra-user-profile-fields/',
			intro: __('With this Blueprint, you can add custom fields to WordPress user profiles.', 'code-snippets') +
				__(' These fields are shown on the Edit User screen in the admin and can store any extra information you need.', 'code-snippets')
		}
	}

	constructor(formData?: UserContactMethodsFormData, repeaterData?: BlueprintRepeaterData<UserContactMethodsRepeaterData>) {
		super(
			'general',
			UserContactMethodsForm,
			formData,
			UserContactMethodsRepeaters,
			repeaterData ?? UserContactMethodsBlueprint.buildDefaultRepeaterData()
		)
	}

	private static buildDefaultRepeaterData(): BlueprintRepeaterData<UserContactMethodsRepeaterData> {
		return {
			profileFields: { [uuid()]: DEFAULT_PROFILE_FIELD }
		}
	}

	protected override construct(
		formData?: UserContactMethodsFormData,
		repeaterData?: BlueprintRepeaterData<UserContactMethodsRepeaterData>
	): BlueprintBase<UserContactMethodsFormData, UserContactMethodsRepeaterData> {
		return new UserContactMethodsBlueprint(formData, repeaterData)
	}

	override getDefaultSnippetName(): string {
		return __('User profile fields', 'code-snippets')
	}

	override generateCode(): string {
		const { general: { textDomain } } = this.formData
		const profileFields = this.getRepeaterEntries('profileFields')

		return `<?php
/**
 * Register User Profile Fields
 *
 * @see https://developer.wordpress.org/reference/hooks/user_contactmethods/
 *
 * Text Domain: ${formatPhpCommentText(textDomain)}
 */

add_filter( 'user_contactmethods', function ( $methods ) {

	${profileFields.map(({ fieldKey, label }) =>
		`\t$methods[${formatPhpString(fieldKey)}] = ${formatPhpString(label, textDomain)};`
	).join('\n')}

	return $methods;
} );
		`
	}
}
