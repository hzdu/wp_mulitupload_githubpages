import { __, sprintf } from '@wordpress/i18n'
import { BlueprintBase } from './BlueprintBase'
import { ElementorDynamicTagForm } from './forms/ElementorDynamicTagForm'
import { formatPhpCommentText, formatPhpString, joinAsPhpArray, sanitizePhpIdentifier } from './utils/format'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'
import type { ElementorDynamicTagFormData, EscapeModeOption } from './forms/ElementorDynamicTagForm'

const UNIQUE_ID_RADIX = 36
const INDENT = '\t\t'
const ARRAY_INDENT = '\t\t\t'
const ELEMENTOR_TAG_BASE_CLASS = '\\Elementor\\Core\\DynamicTags\\Tag'

export class ElementorDynamicTagBlueprint extends BlueprintBase<ElementorDynamicTagFormData> {
	private uniqueSuffix = Date.now().toString(UNIQUE_ID_RADIX)

	static override getMetadata(): BlueprintMetadata {
		return {
			slug: 'elementor-dynamic-tag',
			order: 55,
			title: __('Create an Elementor Dynamic Tag', 'code-snippets'),
			description: __('Register a custom dynamic tag that Elementor widgets can pull text from.', 'code-snippets'),
			categories: ['design'],
			docsUrl: 'https://codesnippets.pro/doc/blueprint-dynamic-tag/',
			intro: __('Works with Elementor Free and Pro. Generates a text dynamic tag pulling its value from post meta, user meta, an option, the current date, or your own PHP. The tag will only appear inside Elementor widgets that expose dynamic-tag-enabled fields (more widgets do so under Pro).', 'code-snippets'),
			recommendedScope: 'global'
		}
	}

	constructor(formData?: ElementorDynamicTagFormData) {
		super('general', ElementorDynamicTagForm, formData)
	}

	protected override construct(formData?: ElementorDynamicTagFormData): BlueprintBase<ElementorDynamicTagFormData> {
		return new ElementorDynamicTagBlueprint(formData)
	}

	override getDefaultSnippetName(): string {
		const { general: { tagTitle, tagName } } = this.formData
		const label = tagTitle.trim() || tagName.trim()
		return label
			// translators: %s: Elementor dynamic tag display title.
			? sprintf(__('Elementor Tag: %s', 'code-snippets'), label)
			: super.getDefaultSnippetName()
	}

	override getDefaultSnippetDescription(): string {
		return __('Auto-generated Elementor dynamic tag', 'code-snippets')
	}

	override generateCode(): string {
		const { general: { tagTitle, textDomain } } = this.formData
		const className = this.buildClassName()
		const textDomainComment = textDomain.trim()
			? `\n *\n * Text Domain: ${formatPhpCommentText(textDomain.trim())}`
			: ''

		return `<?php
/**
 * Elementor Dynamic Tag: ${formatPhpCommentText(tagTitle.trim())}${textDomainComment}
 *
 * @see https://developers.elementor.com/docs/dynamic-tags/
 */

if ( class_exists( '${ELEMENTOR_TAG_BASE_CLASS}' ) && ! class_exists( '${className}' ) ) {

	class ${className} extends \\Elementor\\Core\\DynamicTags\\Tag {

${this.buildGetNameMethod()}

${this.buildGetTitleMethod()}

${this.buildGetGroupMethod()}

${this.buildGetCategoriesMethod()}${this.buildRegisterControlsMethod()}${this.buildRenderMethod()}
	}

	add_action( 'elementor/dynamic_tags/register', function ( $dynamic_tags_manager ) {
		$dynamic_tags_manager->register( new ${className}() );
	} );
}
`
	}

	private buildClassName(): string {
		return sanitizePhpIdentifier(`CS_Elementor_Tag_${this.uniqueSuffix}`)
	}

	private buildGetNameMethod(): string {
		const { general: { tagName } } = this.formData
		return `${INDENT}public function get_name(): string {
${INDENT}${INDENT}return ${formatPhpString(tagName.trim())};
${INDENT}}`
	}

	private buildGetTitleMethod(): string {
		const { general: { tagTitle, textDomain } } = this.formData
		const title = ElementorDynamicTagBlueprint.formatTranslatableString(tagTitle.trim(), textDomain.trim())
		return `${INDENT}public function get_title(): string {
${INDENT}${INDENT}return ${title};
${INDENT}}`
	}

	private buildGetGroupMethod(): string {
		const { general: { tagGroup } } = this.formData
		return `${INDENT}public function get_group(): array {
${INDENT}${INDENT}return [ ${formatPhpString(tagGroup)} ];
${INDENT}}`
	}

	private buildGetCategoriesMethod(): string {
		return `${INDENT}public function get_categories(): array {
${INDENT}${INDENT}return [ \\Elementor\\Modules\\DynamicTags\\Module::TEXT_CATEGORY ];
${INDENT}}

`
	}

	private buildRegisterControlsMethod(): string {
		const { controls: { enableFallback, fallbackControlLabel, fallbackControlDefault }, general: { textDomain } } = this.formData
		if (!enableFallback) {
			return ''
		}

		const label = ElementorDynamicTagBlueprint.formatTranslatableString(
			fallbackControlLabel.trim(),
			textDomain.trim()
		)
		const controlConfig = joinAsPhpArray({
			label,
			type: '\\Elementor\\Controls_Manager::TEXT',
			default: formatPhpString(fallbackControlDefault)
		}, ARRAY_INDENT)

		return `${INDENT}protected function register_controls(): void {
${INDENT}${INDENT}$this->add_control(
${INDENT}${INDENT}${INDENT}'fallback',
${INDENT}${INDENT}${INDENT}[
${controlConfig}
${INDENT}${INDENT}${INDENT}]
${INDENT}${INDENT});
${INDENT}}

`
	}

	private buildRenderMethod(): string {
		return `${INDENT}public function render(): void {
${this.buildRenderBody()}
${INDENT}}`
	}

	private buildRenderBody(): string {
		const { controls: { enableFallback }, output: { escapeMode } } = this.formData
		const lines = [
			`${INDENT}${INDENT}${this.buildValueExpression()};`
		]

		if (enableFallback) {
			lines.push(
				'',
				`${INDENT}${INDENT}if ( empty( $value ) ) {`,
				`${INDENT}${INDENT}${INDENT}$value = $this->get_settings( 'fallback' );`,
				`${INDENT}${INDENT}}`
			)
		}

		lines.push(
			'',
			`${INDENT}${INDENT}${ElementorDynamicTagBlueprint.buildEchoStatement(escapeMode)}`
		)

		return lines.join('\n')
	}

	private buildValueExpression(): string {
		const { valueSource: { valueSource, metaKey, optionName, dateFormat, customPhp } } = this.formData

		switch (valueSource) {
			case 'post_meta':
				return `$value = get_post_meta( get_the_ID(), ${formatPhpString(metaKey.trim())}, true )`
			case 'user_meta':
				return `$value = get_user_meta( get_current_user_id(), ${formatPhpString(metaKey.trim())}, true )`
			case 'option':
				return `$value = get_option( ${formatPhpString(optionName.trim())} )`
			case 'current_date':
				return `$value = wp_date( ${formatPhpString(dateFormat.trim())} )`
			case 'custom_php':
				return ElementorDynamicTagBlueprint.buildCustomPhpExpression(customPhp)
			default:
				return '$value = \'\''
		}
	}

	private static buildCustomPhpExpression(customPhp: string): string {
		const indentedBody = customPhp
			.split('\n')
			.map(line => `${INDENT}${INDENT}${INDENT}${line}`)
			.join('\n')

		return `$value = ( function () {
${indentedBody}
${INDENT}${INDENT}} )()`
	}

	private static buildEchoStatement(escapeMode: EscapeModeOption): string {
		return 'wp_kses_post' === escapeMode
			? 'echo wp_kses_post( $value );'
			: 'echo esc_html( $value );'
	}

	private static formatTranslatableString(text: string, textDomain: string): string {
		return textDomain
			? `esc_html__( ${formatPhpString(text)}, ${formatPhpString(textDomain)} )`
			: `esc_html( ${formatPhpString(text)} )`
	}
}
