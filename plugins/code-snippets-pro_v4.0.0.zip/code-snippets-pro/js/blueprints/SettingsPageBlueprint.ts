import { __ } from '@wordpress/i18n'
import { BlueprintBase } from './BlueprintBase'
import { SettingsPageForm, SettingsPageFormRepeaters } from './forms/SettingsPageForm'
import { escapeHtmlAttr, formatPhpCommentText, formatPhpString, sanitizePhpIdentifier } from './utils/format'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'
import type { BlueprintRepeaterData } from './BlueprintBase'
import type { SettingsField, SettingsPageFormData, SettingsPageRepeaterData } from './forms/SettingsPageForm'

const UNIQUE_ID_RADIX = 36
const SELECT_OPTION_PARTS = 2

export class SettingsPageBlueprint extends BlueprintBase<SettingsPageFormData, SettingsPageRepeaterData> {
	private uniqueSuffix = Date.now().toString(UNIQUE_ID_RADIX)

	static override getMetadata(): BlueprintMetadata {
		return {
			order: 36,
			slug: 'settings-page',
			recommendedScope: 'admin',
			title: __('Create a Settings Page', 'code-snippets'),
			description: __('Create a custom admin settings page with fields to store and manage options.', 'code-snippets'),
			categories: ['admin'],
			docsUrl: 'https://codesnippets.pro/doc/blueprint-create-a-settings-page/',
			intro: __('With this Blueprint, you can add a custom settings page to the WordPress admin.', 'code-snippets')
		}
	}

	constructor(formData?: SettingsPageFormData, repeaterData?: BlueprintRepeaterData<SettingsPageRepeaterData>) {
		super('general', SettingsPageForm, formData, SettingsPageFormRepeaters, repeaterData)
	}

	protected override construct(
		formData?: SettingsPageFormData,
		repeaterData?: BlueprintRepeaterData<SettingsPageRepeaterData>
	): BlueprintBase<SettingsPageFormData, SettingsPageRepeaterData> {
		return new SettingsPageBlueprint(formData, repeaterData)
	}

	override getDefaultSnippetName(): string {
		return __('Custom settings page', 'code-snippets')
	}

	protected get optionGroup(): string {
		const { settings: { settingsGroup } } = this.formData
		return `${settingsGroup}_${this.uniqueSuffix}`
	}

	protected get optionName(): string {
		return this.optionGroup
	}

	protected get settingPage(): string {
		const { settings: { settingsBase } } = this.formData
		return `${settingsBase}_${this.uniqueSuffix}`
	}

	protected get sectionId(): string {
		const { settings: { settingsBase } } = this.formData
		return `${settingsBase}_${this.uniqueSuffix}_section`
	}

	override generateCode(): string {
		const { general: { textDomain, className: classNamePrefix } } = this.formData

		const classIdentifier = sanitizePhpIdentifier(`${classNamePrefix}_${this.uniqueSuffix}`)

		return `<?php
/**
 * Settings Page: ${formatPhpCommentText(classNamePrefix)}
 *
 * @see https://developer.wordpress.org/plugins/settings/settings-api/
 *
 * Text Domain: ${formatPhpCommentText(textDomain)}
 * Unique ID: ${formatPhpCommentText(this.uniqueSuffix)}
 */

class ${classIdentifier} {

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
		add_action( 'admin_init', [ $this, 'init_settings' ] );
	}

	${this.buildAddMenuFunction()}

	public function init_settings() {
		register_setting(
			${formatPhpString(this.optionGroup)},
			${formatPhpString(this.optionName)}
		);

		add_settings_section(
			${formatPhpString(this.sectionId)},
			'',
			false,
			${formatPhpString(this.settingPage)}
		);

		${this.buildRegisterSettingsFields()}
	};

	${this.buildCallbackFunction()}

	${this.buildFieldRenderers()}
}

new ${classIdentifier}();
`
	}

	private buildAddMenuFunction(): string {
		const {
			general: { textDomain },
			menu: { menuType, submenu, pageTitle, menuTitle, capability, menuSlug, menuIcon, menuPosition }
		} = this.formData

		const args = [
			'add_submenu_page' === menuType && formatPhpString(submenu),
			formatPhpString(pageTitle, textDomain),
			formatPhpString(menuTitle, textDomain),
			formatPhpString(capability),
			formatPhpString(`${menuSlug}_${this.uniqueSuffix}`),
			'[ $this, \'render_menu_page\' ]',
			'add_submenu_page' === menuType && formatPhpString(menuIcon),
			'add_submenu_page' === menuType && SettingsPageBlueprint.sanitizeMenuPosition(menuPosition)
		].filter(arg => false !== arg)

		return `public function add_admin_menu() {
		${sanitizePhpIdentifier(menuType)}(
			${args.join('\n\t\t\t')}
		);
	}`
	}

	private buildRegisterSettingsFields(): string {
		const { general: { textDomain } } = this.formData
		const fields = this.getRepeaterEntries('fields')

		return fields.map(field => `
		add_settings_field(
			${formatPhpString(field.id)},
			${formatPhpString(field.label, textDomain)},
			[ $this, '${sanitizePhpIdentifier(`render_${field.id}_field`)}' ],
			${formatPhpString(this.settingPage)},
			${formatPhpString(this.sectionId)}
		);`)
			.join('\n\n')
	}

	private buildCallbackFunction(): string {
		const { general } = this.formData

		const beforeFields = general.contentBeforeFields.trim() ? `
		$content_before = ${formatPhpString(general.contentBeforeFields)};
		echo wp_kses_post( $content_before );

` : ''

		return `
	public function render_menu_page() {
		echo '<div class="wrap">';
		echo '<h1>', esc_html( get_admin_page_title() ), '</h1>';

		echo '<form action="options.php" method="post">';

		settings_fields( ${formatPhpString(this.optionGroup)} );
		${beforeFields}
		do_settings_sections( ${formatPhpString(this.settingPage)} );
		submit_button();

		echo '</form>';
		echo '</div>';
	}
`
	}

	private buildFieldRenderers(): string {
		const { general: { textDomain } } = this.formData

		return this.getRepeaterEntries('fields').map(field => {
			const defaultValue = 'checkboxes' === field.fieldType ? '[]' : formatPhpString(field.defaultValue)

			const description = field.description
				? `\necho '<p class="description">', ${formatPhpString(field.description, textDomain)}, '</p>';`
				: ''

			return `

	public function ${sanitizePhpIdentifier(`render_${field.id}_field`)}() {
		// Retrieve data from the database.
		$options = get_option( ${formatPhpString(this.optionName)}, [] );
		// Fetch field value.
		$value = isset( $options[${formatPhpString(field.id)}] ) ? $options[${formatPhpString(field.id)}] : ${defaultValue};

		// Field output.
		?>
		${this.buildFieldOutput(field)}
		<?php${description}
	}
`
		}).join('\n\n\n')
	}

	private buildFieldName(fieldId: string): string {
		return `${this.optionName}[${fieldId}]`
	}

	private buildTextField({ id, fieldType, placeholder }: SettingsField): string {
		const { general: { textDomain } } = this.formData

		const placeholderAttr = textDomain
			? `<?php esc_attr_e( ${formatPhpString(placeholder ?? '')}, ${formatPhpString(textDomain)} ); ?>`
			: formatPhpString(placeholder ?? '')

		return `
		<input type="${escapeHtmlAttr(fieldType)}" name="${escapeHtmlAttr(this.buildFieldName(id))}"
			class="regular-text ${escapeHtmlAttr(`${id}_field`)}"
			placeholder="${placeholderAttr}"
			value="<?php echo esc_attr( $value ); ?>">`
	}

	private buildTextareaField({ id, placeholder }: SettingsField): string {
		const { general: { textDomain } } = this.formData

		const placeholderAttr = textDomain
			? `<?php esc_attr_e( ${formatPhpString(placeholder ?? '')}, ${formatPhpString(textDomain)} ); ?>`
			: formatPhpString(placeholder ?? '')

		return `
		<textarea name="${escapeHtmlAttr(this.buildFieldName(id))}"
			class="regular-text ${escapeHtmlAttr(`${id}_field`)}"
			placeholder="${placeholderAttr}"><?php echo wp_kses_post( $value ); ?></textarea>`
	}

	private buildCheckboxField({ id, placeholder }: SettingsField): string {
		const { general: { textDomain } } = this.formData

		const placeholderHtml = textDomain
			? `<?php esc_html_e( ${formatPhpString(placeholder ?? '')}, ${formatPhpString(textDomain)} ); ?>`
			: formatPhpString(placeholder ?? '')

		return `
		<input type="checkbox" name="${escapeHtmlAttr(this.buildFieldName(id))}" class="${escapeHtmlAttr(`${id}_field`)}"
				value="checked"<?php checked( $value, 'checked' ); ?>> ${placeholderHtml}`
	}

	private parseFieldOptions({ options }: Pick<SettingsField, 'options'>): [string, string][] {
		return options.split('\n')
			.filter(line => line.trim())
			.map(option => option.split('|', SELECT_OPTION_PARTS).map(part => part.trim()))
			.map<[string, string]>(parts => [parts[0], parts[1] ?? parts[0]])
	}

	private buildSelectField(field: SettingsField): string {
		const { general: { textDomain } } = this.formData

		return `
		<select name="${escapeHtmlAttr(this.buildFieldName(field.id))}" class="${escapeHtmlAttr(`${field.id}_field`)}">
			${this.parseFieldOptions(field).map(([value, label]) =>
				`<option value="<?php echo esc_attr( ${formatPhpString(value)} ); ?>"
			<?php selected( $value, ${formatPhpString(value)} ); ?>>
			<?php ${textDomain
				? `esc_html_e( ${formatPhpString(label)}, ${formatPhpString(textDomain)} )`
				: `echo esc_html( ${formatPhpString(label)} )`}; ?>
			</option>`).join('\n\n')}
		</select>`
	}

	private buildRadioFields({ id, options, fieldType }: SettingsField): string {
		const { general: { textDomain } } = this.formData
		const isMulti = 'checkboxes' === fieldType

		return !options
			? ''
			: this.parseFieldOptions({ options }).map(([value, label]) => `
		<input type="${isMulti ? 'checkbox' : 'radio'}"
		  name="${escapeHtmlAttr(this.buildFieldName(id))}]${isMulti ? '[]' : ''}"
			class="${escapeHtmlAttr(`${id}_field`)}"
			value="<?php echo esc_attr( ${formatPhpString(value)} ); ?>"
			<?php checked( ${isMulti
				? `in_array( ${formatPhpString(value)}, $value, true )`
				: `$value, ${formatPhpString(value)}`} ); ?>>
			${textDomain
				? `esc_html_e( ${formatPhpString(label)}, ${formatPhpString(textDomain)} );`
				: `echo esc_html( ${formatPhpString(label)} );`}
			<br>`
			).join('\n\n')
	}

	private buildFieldOutput(field: SettingsField): string {
		switch (field.fieldType) {
			case 'text':
			case 'number':
			case 'email':
			case 'url':
			case 'date':
			case 'time':
			case 'color':
				return this.buildTextField(field)

			case 'textarea':
				return this.buildTextareaField(field)

			case 'checkbox':
				return this.buildCheckboxField(field)

			case 'checkboxes':
			case 'radio':
				return this.buildRadioFields(field)

			case 'select':
				return this.buildSelectField(field)

			default:
				console.error('[Code Snippets Blueprint] Unsupported field type:', field.fieldType)
				return ''
		}
	}

	/** Sanitize menu position to a safe integer string for PHP (avoids code injection). */
	private static sanitizeMenuPosition(raw: string): string {
		const n = parseInt(raw.trim(), 10)
		return Number.isInteger(n) && 0 <= n ? String(n) : '100'
	}
}
