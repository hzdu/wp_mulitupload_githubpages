import { __, sprintf } from '@wordpress/i18n'
import { BlueprintBase } from './BlueprintBase'
import { ElementorQueryForm, ElementorQueryFormRepeaters } from './forms/ElementorQueryForm'
import { formatPhpCommentText, formatPhpString, joinAsPhpArray } from './utils/format'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'
import type { BlueprintRepeaterData } from './BlueprintBase'
import type {
	ElementorQueryFormData,
	ElementorQueryRepeaterData,
	MetaQueryRow,
	TaxQueryRow
} from './forms/ElementorQueryForm'

const INDENT = '\t\t'
const ROW_INDENT = '\t\t\t'

export class ElementorQueryBlueprint extends BlueprintBase<ElementorQueryFormData, ElementorQueryRepeaterData> {
	static override getMetadata(): BlueprintMetadata {
		return {
			slug: 'elementor-custom-query',
			order: 50,
			title: __('Customize an Elementor Query', 'code-snippets'),
			description: __('Modify the query of an Elementor Posts or Portfolio widget using its Query ID.', 'code-snippets'),
			categories: ['query'],
			docsUrl: 'https://codesnippets.pro/doc/blueprint-elementor-custom-query/',
			intro: __('Requires Elementor Pro. Set a unique Query ID in the widget\u2019s Advanced \u203a Query controls, then use the same ID below.', 'code-snippets'),
			recommendedScope: 'global'
		}
	}

	constructor(
		formData?: ElementorQueryFormData,
		repeaterData?: BlueprintRepeaterData<ElementorQueryRepeaterData>
	) {
		super('general', ElementorQueryForm, formData, ElementorQueryFormRepeaters, repeaterData)
	}

	protected override construct(
		formData?: ElementorQueryFormData,
		repeaterData?: BlueprintRepeaterData<ElementorQueryRepeaterData>
	): BlueprintBase<ElementorQueryFormData, ElementorQueryRepeaterData> {
		return new ElementorQueryBlueprint(formData, repeaterData)
	}

	override getDefaultSnippetName(): string {
		const { general: { queryId } } = this.formData
		return queryId.trim()
			// translators: %s: Elementor Query ID.
			? sprintf(__('Elementor Query: %s', 'code-snippets'), queryId.trim())
			: super.getDefaultSnippetName()
	}

	override getDefaultSnippetDescription(): string {
		return __('Auto-generated Elementor query filter', 'code-snippets')
	}

	override generateCode(): string {
		const { general: { queryId, description } } = this.formData
		const trimmedQueryId = queryId.trim()
		const trimmedDescription = description.trim()

		const docDescription = trimmedDescription
			? `\n *\n * ${formatPhpCommentText(trimmedDescription)}`
			: ''

		const blocks = [
			this.buildPostTypeBlock(),
			this.buildPostStatusBlock(),
			this.buildPostsPerPageBlock(),
			this.buildOrderingBlock(),
			this.buildMetaQueryBlock(),
			this.buildTaxQueryBlock(),
			this.buildCustomCodeBlock()
		].filter(Boolean).join('\n\n')

		const body = blocks || `${INDENT}// Add $query->set( ... ) calls here.`

		return `<?php
/**
 * Customize Elementor query: ${formatPhpCommentText(trimmedQueryId)}${docDescription}
 *
 * @see https://developers.elementor.com/docs/hooks/custom-query-filter/
 */

if ( defined( 'ELEMENTOR_PRO_VERSION' ) ) {
	add_action( 'elementor/query/${trimmedQueryId}', function ( $query ) {

${body}

	} );
}
`
	}

	private buildPostTypeBlock(): string {
		const { postTypes: { enablePostTypeFilter, postTypes } } = this.formData
		if (!enablePostTypeFilter) {
			return ''
		}
		const items = ElementorQueryBlueprint.csvToPhpItems(postTypes)
		return `${INDENT}// Filter by post type.\n${INDENT}$query->set( 'post_type', [ ${items} ] );`
	}

	private buildPostStatusBlock(): string {
		const { postStatus: { enablePostStatusFilter, postStatuses } } = this.formData
		if (!enablePostStatusFilter) {
			return ''
		}
		const items = ElementorQueryBlueprint.csvToPhpItems(postStatuses)
		return `${INDENT}// Filter by post status.\n${INDENT}$query->set( 'post_status', [ ${items} ] );`
	}

	private buildPostsPerPageBlock(): string {
		const { pagination: { enablePostsPerPage, postsPerPage } } = this.formData
		if (!enablePostsPerPage) {
			return ''
		}
		return `${INDENT}// Override posts per page.\n${INDENT}$query->set( 'posts_per_page', ${postsPerPage.trim()} );`
	}

	private buildOrderingBlock(): string {
		const { ordering: { enableOrder, orderby, customOrderby, order, metaKey } } = this.formData
		if (!enableOrder) {
			return ''
		}
		const effectiveOrderby = 'custom' === orderby ? customOrderby.trim() : orderby
		const lines = [
			`${INDENT}// Override ordering.`,
			`${INDENT}$query->set( 'orderby', ${formatPhpString(effectiveOrderby)} );`,
			`${INDENT}$query->set( 'order', ${formatPhpString(order)} );`
		]
		if (orderby.startsWith('meta_value') && metaKey.trim()) {
			lines.push(`${INDENT}$query->set( 'meta_key', ${formatPhpString(metaKey.trim())} );`)
		}
		return lines.join('\n')
	}

	private buildMetaQueryBlock(): string {
		const rows = this.getRepeaterEntries('metaQueryRows')
		if (0 === rows.length) {
			return ''
		}
		const lines: string[] = [
			`${INDENT}// Merge meta query.`,
			`${INDENT}$meta_query = $query->get( 'meta_query' ) ?: [];`
		]
		for (const row of rows) {
			const fields = ElementorQueryBlueprint.formatMetaQueryRow(row)
			lines.push(`${INDENT}$meta_query[] = [\n${joinAsPhpArray(fields, ROW_INDENT)}\n${INDENT}];`)
		}
		lines.push(`${INDENT}$query->set( 'meta_query', $meta_query );`)
		return lines.join('\n')
	}

	private static formatMetaQueryRow(row: MetaQueryRow): Record<string, string | undefined> {
		const omitsValue = 'EXISTS' === row.compare || 'NOT EXISTS' === row.compare
		return {
			key: formatPhpString(row.key.trim()),
			value: omitsValue ? undefined : ElementorQueryBlueprint.formatMetaQueryValue(row),
			compare: formatPhpString(row.compare),
			type: formatPhpString(row.type)
		}
	}

	private static formatMetaQueryValue(row: MetaQueryRow): string {
		if ('IN' === row.compare || 'NOT IN' === row.compare) {
			return `[ ${ElementorQueryBlueprint.csvToPhpItems(row.value)} ]`
		}
		return formatPhpString(row.value)
	}

	private buildTaxQueryBlock(): string {
		const rows = this.getRepeaterEntries('taxQueryRows')
		if (0 === rows.length) {
			return ''
		}
		const lines: string[] = [
			`${INDENT}// Merge taxonomy query.`,
			`${INDENT}$tax_query = $query->get( 'tax_query' ) ?: [];`
		]
		for (const row of rows) {
			const fields = ElementorQueryBlueprint.formatTaxQueryRow(row)
			lines.push(`${INDENT}$tax_query[] = [\n${joinAsPhpArray(fields, ROW_INDENT)}\n${INDENT}];`)
		}
		lines.push(`${INDENT}$query->set( 'tax_query', $tax_query );`)
		return lines.join('\n')
	}

	private static formatTaxQueryRow(row: TaxQueryRow): Record<string, string> {
		return {
			taxonomy: formatPhpString(row.taxonomy.trim()),
			field: formatPhpString(row.field),
			terms: `[ ${ElementorQueryBlueprint.csvToPhpItems(row.terms)} ]`,
			operator: formatPhpString(row.operator)
		}
	}

	private buildCustomCodeBlock(): string {
		const { custom: { customCode } } = this.formData
		if (!customCode.trim()) {
			return ''
		}
		const indented = customCode.split('\n').map(line => `${INDENT}${line}`).join('\n')
		return `${INDENT}// Custom code.\n${indented}`
	}

	private static csvToPhpItems(value: string): string {
		return value.split(',')
			.map(item => item.trim())
			.filter(Boolean)
			.map(item => formatPhpString(item))
			.join(', ')
	}
}
