import { __ } from '@wordpress/i18n'
import { v4 as uuid } from 'uuid'
import { BlueprintBase } from './BlueprintBase'
import { ShortcodeForm, ShortcodeFormRepeaters } from './forms/ShortcodeForm'
import { formatPhpCommentText, formatPhpString } from './utils/format'
import type { BlueprintRepeaterData } from './BlueprintBase'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'
import type { ShortcodeAttribute, ShortcodeFormData, ShortcodeFormRepeaterData } from './forms/ShortcodeForm'

const INDENT = '\t'

const DEFAULT_ATTRIBUTE: ShortcodeAttribute = {
	name: 'title',
	default: 'Hello World',
	type: 'string'
}

export class ShortcodeBlueprint extends BlueprintBase<ShortcodeFormData, ShortcodeFormRepeaterData> {
	static override getMetadata(): BlueprintMetadata {
		return {
			slug: 'shortcode',
			order: 40,
			title: __('Create a Shortcode', 'code-snippets'),
			description: __('Create a custom shortcode to display dynamic content using a simple tag.', 'code-snippets'),
			categories: ['content'],
			docsUrl: 'https://codesnippets.pro/doc/blueprint-create-a-shortcode/',
			intro: __('Create a custom shortcode to add dynamic content anywhere on your site using a simple tag like [my_shortcode].', 'code-snippets')
		}
	}

	constructor(formData?: ShortcodeFormData, repeaterData?: BlueprintRepeaterData<ShortcodeFormRepeaterData>) {
		super(
			'general',
			ShortcodeForm,
			formData,
			ShortcodeFormRepeaters,
			repeaterData ?? ShortcodeBlueprint.buildDefaultRepeaterData()
		)
	}

	private static buildDefaultRepeaterData(): BlueprintRepeaterData<ShortcodeFormRepeaterData> {
		return {
			shortcodeAttributes: { [uuid()]: DEFAULT_ATTRIBUTE }
		}
	}

	protected override construct(
		formData?: ShortcodeFormData,
		repeaterData?: BlueprintRepeaterData<ShortcodeFormRepeaterData>
	): BlueprintBase<ShortcodeFormData, ShortcodeFormRepeaterData> {
		return new ShortcodeBlueprint(formData, repeaterData)
	}

	override generateCode(): string {
		const { general: { shortcodeTag, isEnclosing, textDomain, shortcodeDescription } } = this.formData
		const functionParams = isEnclosing ? '$atts, $content = null' : '$atts'

		return `
<?php
/**
 * Shortcode: [${formatPhpCommentText(shortcodeTag)}]
 * ${shortcodeDescription ? `\n *\n * ${formatPhpCommentText(shortcodeDescription)}` : ''}
 *
 * @see https://developer.wordpress.org/reference/functions/add_shortcode/
 * 
 * Text Domain: ${formatPhpCommentText(textDomain)}
 */
 
add_shortcode( ${formatPhpString(shortcodeTag)}, function ( ${functionParams} ) {

	${this.buildFunctionBody()}

} );
`
	}

	private static inferAttributeType(value: string): 'string' | 'number' | 'boolean' {
		switch (true) {
			case 'true' === value.toLowerCase() || 'false' === value.toLowerCase():
				return 'boolean'

			case '' !== value && !isNaN(Number(value)):
				return 'number'

			default:
				return 'string'
		}
	}

	private buildFunctionBody(): string {
		const {
			general: { isEnclosing, supportsNestedShortcodes },
			output: { useOutputBuffering, shortcodeCode }
		} = this.formData

		const attributes = this.getRepeaterEntries('shortcodeAttributes')

		// Build defaults array
		let code = ShortcodeBlueprint.buildDefaultsArray(attributes
			.filter(({ name }) => name.trim())
			.map(({ name, default: defaultValue }) => ({
				name: name.trim(),
				default: defaultValue.trim(),
				type: ShortcodeBlueprint.inferAttributeType(defaultValue.trim())
			})))

		// Parse attributes
		code += `${INDENT}$atts = shortcode_atts( $defaults, $atts );\n\n`

		// Extract attributes to variables for convenience
		if (0 < attributes.length) {
			code += `${INDENT}// Extract attributes to variables\n`
			code += `${INDENT}extract( $atts );\n\n`
		}

		// Handle content for enclosing shortcodes
		if (isEnclosing) {
			code += `${INDENT}// Sanitize content\n`
			code += `${INDENT}$content = wp_kses_post( $content );\n\n`

			if (supportsNestedShortcodes) {
				code += `${INDENT}// Process nested shortcodes\n`
				code += `${INDENT}$content = do_shortcode( $content );\n\n`
			}
		}

		// Output buffering or direct return
		if (useOutputBuffering) {
			code += `${INDENT}// Start output buffering\n`
			code += `${INDENT}ob_start();\n\n`
			code += `${INDENT}${ShortcodeBlueprint.indentCode(shortcodeCode)}\n\n`
			code += `${INDENT}// Return buffered content\n`
			code += `${INDENT}return ob_get_clean();\n`
		} else {
			code += `${INDENT}${ShortcodeBlueprint.indentCode(shortcodeCode)}\n`
		}

		return code
	}

	private static buildDefaultsArray(attributes: ShortcodeAttribute[]): string {
		let code = `${INDENT}// Default attribute values\n`
		code += `${INDENT}$defaults = array(\n`

		if (0 === attributes.length) {
			code += `${INDENT}${INDENT}// Add your default attributes here\n`
		} else {
			attributes.forEach((attr, index) => {
				const isLast = index === attributes.length - 1
				const comma = isLast ? '' : ','
				const value = ShortcodeBlueprint.formatAttributeValue(attr)
				code += `${INDENT}${INDENT}${formatPhpString(attr.name)} => ${value}${comma}\n`
			})
		}

		code += `${INDENT});\n\n`

		return code
	}

	private static formatAttributeValue(attr: ShortcodeAttribute): string {
		switch (attr.type) {
			case 'boolean':
				return 'true' === attr.default.toLowerCase() ? 'true' : 'false'
			case 'number': {
				const number = parseFloat(attr.default)
				return Number.isFinite(number) ? String(number) : '0'
			}
			default:
				return formatPhpString(attr.default)
		}
	}

	private static indentCode(code: string): string {
		return code
			.split('\n')
			.map((line, index) => 0 === index ? line : `${INDENT}${line}`)
			.join('\n')
	}
}
