import { __, sprintf } from '@wordpress/i18n'
import { BlueprintBase } from './BlueprintBase'
import { PostTypeForm } from './forms/PostTypeForm'
import { formatPhpCommentText, formatPhpString, formatPhpValue, formatTranslateX, joinAsPhpArray } from './utils/format'
import type { PostTypeFormData } from './forms/PostTypeForm'
import type { BlueprintMetadata } from '../types/blueprints/BlueprintMetadata'

export class PostTypeBlueprint extends BlueprintBase<PostTypeFormData> {
	static override getMetadata(): BlueprintMetadata {
		return {
			order: 10,
			slug: 'post-type',
			title: __('Add a Custom Content Type', 'code-snippets'),
			description: __('Add a new content type for your site — perfect for organizing content like projects, books, or anything else you need.', 'code-snippets'),
			categories: ['content'],
			docsUrl: 'https://codesnippets.pro/doc/blueprint-custom-content-type/'
		}
	}

	constructor(formData?: PostTypeFormData) {
		super('general', PostTypeForm, formData)
	}

	protected override construct(formData: PostTypeFormData): BlueprintBase<PostTypeFormData> {
		return new PostTypeBlueprint(formData)
	}

	override getDefaultSnippetName(): string {
		const { general: { postTypeKey } } = this.formData

		return postTypeKey
			// translators: %s: post type key.
			? sprintf(__('%s Custom Content', 'code-snippets'), postTypeKey)
			: super.getDefaultSnippetName()
	}

	override getDefaultSnippetDescription(): string {
		return __('Auto-generated custom content code', 'code-snippets')
	}

	override generateCode(): string {
		const { general: { postTypeKey, textDomain } } = this.formData

		const arrays = [
			this.buildLabelsArray(),
			this.buildRewriteArrayData(),
			this.buildCapabilitiesArrayData(),
			this.buildMainArgs()
		].filter(Boolean).join('\n\n')

		return `<?php
/**
 * Register Custom Post Type: ${formatPhpCommentText(postTypeKey)}
 * 
 * @see https://developer.wordpress.org/reference/functions/register_post_type/ 
 *
 * Text Domain: ${formatPhpCommentText(textDomain)}
 */

add_action( 'init', function () {
	${arrays}
	
	register_post_type( ${formatPhpString(postTypeKey)}, $args );
}, 0 );
`
	}

	private buildLabelsArray(): string {
		const { general: { textDomain, namePlural, nameSingular }, labels } = this.formData

		return `
	$labels = [
		'name'                     => ${formatTranslateX(namePlural, 'Post Type General Name', textDomain)},
		'singular_name'            => ${formatTranslateX(nameSingular, 'Post Type Singular Name', textDomain)},
		'menu_name'                => ${formatPhpString(labels.menuName, textDomain)},
		'name_admin_bar'           => ${formatPhpString(labels.adminBarName, textDomain)},
		'archives'                 => ${formatPhpString(labels.archives, textDomain)},
		'attributes'               => ${formatPhpString(labels.attributes, textDomain)},
		'parent_item_colon'        => ${formatPhpString(labels.parentItem, textDomain)},
		'all_items'                => ${formatPhpString(labels.allItems, textDomain)},
		'add_new_item'             => ${formatPhpString(labels.addNewItem, textDomain)},
		'add_new'                  => ${formatPhpString(labels.addNew, textDomain)},
		'new_item'                 => ${formatPhpString(labels.newItem, textDomain)},
		'edit_item'                => ${formatPhpString(labels.editItem, textDomain)},
		'update_item'              => ${formatPhpString(labels.updateItem, textDomain)},
		'view_item'                => ${formatPhpString(labels.viewItem, textDomain)},
		'view_items'               => ${formatPhpString(labels.viewItems, textDomain)},
		'search_items'             => ${formatPhpString(labels.searchItems, textDomain)},
		'not_found'                => ${formatPhpString(labels.notFound, textDomain)},
		'not_found_in_trash'       => ${formatPhpString(labels.notFoundInTrash, textDomain)},

		'featured_image'           => ${formatPhpString(labels.featuredImage, textDomain)},
		'set_featured_image'       => ${formatPhpString(labels.setFeaturedImage, textDomain)},
		'remove_featured_image'    => ${formatPhpString(labels.removeFeaturedImage, textDomain)},
		'use_featured_image'       => ${formatPhpString(labels.useFeaturedImage, textDomain)},
		'insert_into_item'         => ${formatPhpString(labels.insertIntoItem, textDomain)},
		'uploaded_to_this_item'    => ${formatPhpString(labels.uploadedToThisItem, textDomain)},
		'items_list'               => ${formatPhpString(labels.itemsList, textDomain)},
		'items_list_navigation'    => ${formatPhpString(labels.itemsListNavigation, textDomain)},
		'filter_items_list'        => ${formatPhpString(labels.filterItemsList, textDomain)},

		'item_published'           => ${formatPhpString(labels.itemPublished, textDomain)},
		'item_published_privately' => ${formatPhpString(labels.itemPublishedPrivately, textDomain)},
		'item_reverted_to_draft'   => ${formatPhpString(labels.itemRevertedToDraft, textDomain)},
		'item_scheduled'           => ${formatPhpString(labels.itemScheduled, textDomain)},
		'item_updated'             => ${formatPhpString(labels.itemUpdated, textDomain)},
		'item_link'                => ${formatPhpString(labels.itemLink, textDomain)},
		'item_link_description'    => ${formatPhpString(labels.itemLinkDescription, textDomain)},
		'filter_by_date'           => ${formatPhpString(labels.filterByDate, textDomain)},
	];
`
	}

	private buildRewriteArrayData(): string {
		const { permalinks } = this.formData

		if ('custom' !== permalinks.permalinkRewrite) {
			return ''
		}

		const rewrite = {
			slug: formatPhpValue(permalinks.urlSlug),
			with_front: formatPhpValue(permalinks.useUrlSlug),
			pages: formatPhpValue(permalinks.pagination),
			feeds: formatPhpValue(permalinks.feeds)
		}

		return `\t$rewrite = [\n${joinAsPhpArray(rewrite)}\n\t];`
	}

	private buildCapabilitiesArrayData(): string {
		const { capabilities } = this.formData

		if ('custom' !== capabilities.capabilitiesMode) {
			return ''
		}

		const allCaps = {
			read_post: capabilities.readCapability,
			read_private_posts: capabilities.readPrivateCapability,
			publish_posts: capabilities.publishCapability,
			delete_post: capabilities.deleteCapability,
			delete_posts: capabilities.deletePostsCapability,
			edit_post: capabilities.editCapability,
			edit_posts: capabilities.editPostsCapability,
			edit_others_posts: capabilities.editOthersCapability
		}

		const providedCaps = Object.fromEntries(
			Object.entries(allCaps).map(([key, cap]) =>
				[key, cap.trim() ? formatPhpString(cap.trim()) : undefined]))

		return `\t$capabilities = [\n${joinAsPhpArray(providedCaps)}\n\t];`
	}

	private buildSupportsArrayData(): string[] {
		const { supports } = this.formData

		const supportsEnabled = {
			'title': supports.supportsTitle,
			'editor': supports.supportsEditor,
			'except': supports.supportsExcerpt,
			'author': supports.supportsAuthor,
			'thumbnail': supports.supportsThumbnail,
			'comments': supports.supportsComments,
			'trackbacks': supports.supportsTrackbacks,
			'revisions': supports.supportsRevisions,
			'custom-fields': supports.supportsCustomFields,
			'page-attributes': supports.supportsPageAttributes,
			'post-formats': supports.supportsFormats
		}

		return Object.entries(supportsEnabled)
			.filter(([_, enabled]) => enabled)
			.map(([feature]) => formatPhpString(feature))
	}

	private buildMainArgs(): string {
		const {
			general: { textDomain, ...general },
			options: { enableArchives, ...options },
			query: { queryVariable, customQueryVar, publiclyQueryable },
			visibility: { showInSidebar, menuPosition, adminSidebarIcon, ...visibility },
			permalinks: { permalinkRewrite },
			capabilities: { baseCapabilityType, capabilitiesMode },
			restApi: { showInRest, restBase, restControllerClass }
		} = this.formData

		const linkTaxonomiesArray = general.linkTaxonomies.split(',')
			.filter(tax => tax.trim())
			.map(tax => formatPhpString(tax.trim()))

		const args = {
			label: formatPhpString(general.nameSingular, textDomain),
			...general.description && { description: formatPhpString(general.description, textDomain) },
			labels: '$labels',
			supports: `[ ${this.buildSupportsArrayData().join(', ')} ]`,
			...0 < linkTaxonomiesArray.length && { taxonomies: `[ ${linkTaxonomiesArray.join(', ')} ]` },
			hierarchical: formatPhpValue(general.hierarchical),

			public: formatPhpValue(visibility.public),
			show_ui: formatPhpValue(visibility.showUI),
			show_in_menu: formatPhpValue(showInSidebar),
			...menuPosition && { menu_position: formatPhpValue(menuPosition.split(' - ')[0]) },
			...showInSidebar && adminSidebarIcon && { menu_icon: formatPhpValue(adminSidebarIcon) },
			show_in_admin_var: formatPhpValue(visibility.showInAdminBar),
			show_in_nav_menus: formatPhpValue(visibility.showInNavMenus),

			can_export: formatPhpValue(options.enableExport),
			...enableArchives && { has_archive: formatPhpValue(options.customArchiveSlug.trim() || true) },
			exclude_from_search: formatPhpValue(options.excludeFromSearch),
			publicly_queryable: formatPhpValue(publiclyQueryable),
			...'custom' === queryVariable && { query_var: formatPhpValue(customQueryVar || Boolean(queryVariable)) },
			...'custom' === permalinkRewrite && { rewrite: '$rewrite' },
			...!permalinkRewrite && { rewrite: 'false' },
			...'custom' === capabilitiesMode && { capabilities: '$capabilities' },
			...'base' === capabilitiesMode && { capability_type: formatPhpValue(baseCapabilityType.toLowerCase()) },

			...showInRest && {
				show_in_rest: 'true',
				...restBase && { rest_base: formatPhpValue(restBase) },
				...restControllerClass && { rest_controller_class: formatPhpValue(restControllerClass) }
			}
		}

		return `\t$args = [\n${joinAsPhpArray(args)}\n\t];`
	}
}
