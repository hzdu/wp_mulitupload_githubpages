export type FormField<T> =
	| TextLikeFormField
	| CheckboxFormField
	| BooleanSelectFormField
	| SelectFormField<T>

export interface FormFieldBase<T> {
	label: string
	value: T
	required?: boolean
	placeholder?: string
	description?: string
}

export interface TextLikeFormField extends FormFieldBase<string> {
	type: 'text' | 'textarea'
}

export interface CheckboxFormField extends FormFieldBase<boolean> {
	type: 'checkbox'
}

export interface BooleanSelectFormField extends FormFieldBase<boolean> {
	type: 'boolean-select'
}

export interface SelectFormField<T> extends FormFieldBase<T> {
	type: 'select' | 'radio'
	options: { value: T; label: string }[]
}

export interface EmbeddedFormField<V, Values> {
	showIf?: (values: Values) => boolean
	hideIf?: (values: Values) => boolean
	validate?: (value: V, values: Values) => string | undefined
	onUpdate?: (value: V, values: Values) => Values | undefined
}
