export interface BlueprintMetadata {
	/** Unique slug, should be lowercase and contain only letters, numbers, hyphens, and underscores. */
	slug: string

	/** Order for displaying the blueprint in the gallery. Blueprints are sorted by this value ascending, then by registration order. */
	order: number

	/** Title shown in the gallery and at the top of the blueprint generator page. */
	title: string

	/** Short description shown in the gallery and below the title on the blueprint generator page. */
	description: string

	/** Categories to help users find the blueprint in the gallery and understand its use cases. */
	categories: BlueprintCategory[]

	/** Optional URL to documentation or tutorial related to the blueprint. Should be a full URL (e.g. https://example.com/docs). */
	docsUrl?: string

	/** Optional extended text shown at the top of the blueprint generator page, below the title and description. */
	intro?: string

	/**
	 * Recommended scope when the user saves the generated code as a new snippet.
	 * Ensures the snippet runs in the right context (e.g. admin for settings pages).
	 * Default is 'global' if not overridden.
	 */
	recommendedScope?: 'global' | 'admin' | 'front-end'
}

export const BLUEPRINT_CATEGORIES = <const> ['admin', 'content', 'core', 'design', 'general', 'query']
export type BlueprintCategory = typeof BLUEPRINT_CATEGORIES[number]
