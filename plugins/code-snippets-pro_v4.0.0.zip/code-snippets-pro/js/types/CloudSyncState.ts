import type { Snippet } from './Snippet'
import type { CloudSnippetSchema } from './schema/CloudSnippetSchema'

export enum CloudSyncState {
	Unsynced,
	Synced,
	UpdateAvailable,
	Errored
}

export const getCloudSnippetSyncState = (snippet: CloudSnippetSchema): CloudSyncState => {
	switch (true) {
		case 'number' !== typeof snippet.local_id || 'boolean' !== typeof snippet.update_available:
			return CloudSyncState.Errored

		case snippet.update_available:
			return CloudSyncState.UpdateAvailable

		case !!snippet.local_id:
			return CloudSyncState.Synced

		default:
			return CloudSyncState.Unsynced
	}
}

export const getSnippetCloudSyncState = (snippet: Snippet): CloudSyncState => {
	switch (true) {
		case snippet.cloud.updateAvailable:
			return CloudSyncState.UpdateAvailable

		case !!snippet.cloud.id:
			return CloudSyncState.Synced

		default:
			return CloudSyncState.Unsynced
	}
}
