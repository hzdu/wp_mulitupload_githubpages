export interface SnippetSnapshot {
	readonly name: string
	readonly desc: string
	readonly code: string
	readonly tags: string[]
	readonly scope: string
	readonly priority: number
	readonly condition_id: number
	readonly active: boolean
}

export interface Revision {
	readonly id: number
	readonly snippet_id: number
	readonly revision_number: number
	readonly date: string
	readonly author: string
	readonly author_id: number
	readonly snapshot: SnippetSnapshot
}

export interface RevisionSettings {
	readonly disabled: boolean
	readonly revision_count?: number
}
