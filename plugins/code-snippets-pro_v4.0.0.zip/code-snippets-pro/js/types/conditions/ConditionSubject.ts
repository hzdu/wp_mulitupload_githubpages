import type { PostStatusSchema } from '../schema/wp/PostStatusSchema'
import type { PageSchema } from '../schema/wp/PageSchema'
import type { PostSchema } from '../schema/wp/PostSchema'
import type { PostTypeSchema } from '../schema/wp/PostTypeSchema'
import type { CategorySchema, PostTagSchema } from '../schema/wp/TermSchema'
import type { UserSchema } from '../schema/wp/UserSchema'
import type { UserRole } from '../schema/wp/UserRole'
import type { Snippet } from '../Snippet'

export interface SiteConditionSubjects {
	siteArea: 'global' | 'frontend' | 'admin'
	currentQuery: 'home' | 'frontpage' | 'search' | 'archive' | '404' | 'single' | 'page' | 'postTypeArchive'
	visitorLanguage: string
	currentTheme: string
	activePlugin: string
	debugEnabled: boolean
}

export interface SnippetConditionSubjects {
	condition: Snippet['id']
}

export interface PostConditionSubjects {
	post: PostSchema['id']
	page: PageSchema['id']
	postType: PostTypeSchema['slug']
	category: CategorySchema['id']
	tag: PostTagSchema['id']
	author: PostSchema['author']
	postStatus: PostStatusSchema['slug']
	postPublished: string
	postModified: string
}

export interface UserConditionSubjects {
	authenticated: boolean
	user: UserSchema['id']
	userRole: UserRole['role']
	userCap: string
	userLocale: string
	userRegistered: string
}

export interface DateConditionSubjects {
	currentDate: string
	timeOfDay: string
	dayOfWeek: 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat' | 'Sun'
}

export type ConditionSubjects =
	SiteConditionSubjects &
	PostConditionSubjects &
	UserConditionSubjects &
	DateConditionSubjects

export type ConditionSubject = keyof ConditionSubjects
