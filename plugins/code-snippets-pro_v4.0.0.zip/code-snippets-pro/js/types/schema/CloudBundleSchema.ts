export interface CloudBundleSchema {
	id: number
	name?: string
	description?: string | null
	is_public?: boolean
	share_name?: string | null
	share_code: string
	snippets_count: number
}

export interface CloudBundlesSchema {
	bundles: CloudBundleSchema[]
	meta: {
		total: number
		total_pages: number
		page: number
		per_page: number
	}
}
