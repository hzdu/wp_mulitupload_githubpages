import React from 'react'
import { __, _n, sprintf } from '@wordpress/i18n'
import { Modal } from '@wordpress/components'
import type { Snippet } from '../../../types/Snippet'

interface PerfStat {
	ema_ms: number
	last_ms: number
	max_ms: number
	samples: number
	updated?: number
}

interface SecurityFinding {
	rule: string
	severity: 'high' | 'medium' | 'low'
	line: number
	excerpt: string
	title: string
	message: string
	dismissed?: boolean
}

export interface InsightsModalProps {
	snippet: Snippet
	onClose: VoidFunction
}

// Show one decimal for sub-10ms values where the difference matters,
// round otherwise. Tinting kicks in at WARN/DANGER thresholds.
const MS_DECIMAL_CUTOFF = 10
const MS_THRESHOLD_WARN = 50
const MS_THRESHOLD_DANGER = 200

const formatMs = (n: number): string =>
	`${n < MS_DECIMAL_CUTOFF ? n.toFixed(1) : Math.round(n)}ms`

type InsightsPayload = NonNullable<NonNullable<Window['CODE_SNIPPETS_MANAGE']>['insights']>

interface PerfSectionProps {
	insights: InsightsPayload
	snippetId: number
	perf: PerfStat | undefined
}

const PerfSection: React.FC<PerfSectionProps> = ({ insights, snippetId, perf }) => {
	const hasSamples = perf && 0 < perf.samples
	return (
		<section className="cs-insights-section">
			<h3>
				{__('Performance', 'code-snippets')}
				{insights.perfEnabled && hasSamples && (
					<span className="cs-insights-section-meta">
						{sprintf(_n('%d sample', '%d samples', perf.samples, 'code-snippets'), perf.samples)}
					</span>
				)}
			</h3>
			{insights.perfEnabled
				? hasSamples
					? <PerfMetrics perf={perf} />
					: <p className="cs-insights-empty">{__('No execution recorded yet for this snippet.', 'code-snippets')}</p>
				: <p className="cs-insights-empty">{__('Performance tracking is off. Enable it in Settings to collect data.', 'code-snippets')}</p>}
			{insights.perfEnabled && hasSamples && (
				<form action={insights.actionUrl} method="post" className="cs-insights-reset-form">
					<input type="hidden" name="action" value="code_snippets_insights_reset_perf" />
					<input type="hidden" name="_wpnonce" value={insights.resetPerfNonce} />
					<input type="hidden" name="snippet_id" value={snippetId} />
					<button type="submit" className="cs-insights-reset-link">
						{__('Reset stats for this snippet', 'code-snippets')}
					</button>
				</form>
			)}
		</section>
	)
}

interface SecuritySectionProps {
	insights: InsightsPayload
	snippetId: number
	findings: SecurityFinding[]
}

const SecuritySection: React.FC<SecuritySectionProps> = ({ insights, snippetId, findings }) => {
	const open = findings.filter(f => !f.dismissed)
	const dismissed = findings.filter(f => f.dismissed)
	return (
		<section className="cs-insights-section">
			<h3>
				{__('Security', 'code-snippets')}
				{insights.securityEnabled && 0 < findings.length && (
					<span className="cs-insights-section-meta">
						{0 < open.length
							? sprintf(_n('%d open', '%d open', open.length, 'code-snippets'), open.length)
							: __('all dismissed', 'code-snippets')}
						{0 < dismissed.length && ` · ${sprintf(_n('%d dismissed', '%d dismissed', dismissed.length, 'code-snippets'), dismissed.length)}`}
					</span>
				)}
			</h3>
			{insights.securityEnabled
				? 0 === findings.length
					? <p className="cs-insights-empty">{__('No issues found in the last scan.', 'code-snippets')}</p>
					: <FindingsList
						findings={[...open, ...dismissed]}
						snippetId={snippetId}
						actionUrl={insights.actionUrl}
						dismissNonce={insights.dismissNonce}
					/>
				: <p className="cs-insights-empty">{__('Security scanning is off. Enable it in Settings to scan on save.', 'code-snippets')}</p>}
		</section>
	)
}

export const InsightsModal: React.FC<InsightsModalProps> = ({ snippet, onClose }) => {
	const insights = window.CODE_SNIPPETS_MANAGE?.insights
	if (!insights) {return null}

	const id = String(snippet.id)
	const perf = insights.perfData[id]
	const findings: SecurityFinding[] = insights.security[id] ?? []

	return (
		<Modal
			title={sprintf(__('Insights — %s', 'code-snippets'), snippet.name || __('(untitled)', 'code-snippets'))}
			onRequestClose={onClose}
			className="cs-insights-modal"
			closeButtonLabel={__('Close', 'code-snippets')}
			isDismissible={true}
		>
			<PerfSection insights={insights} snippetId={snippet.id} perf={perf} />
			<SecuritySection insights={insights} snippetId={snippet.id} findings={findings} />
		</Modal>
	)
}

interface PerfMetricsProps {
	perf: PerfStat
}

const PerfMetrics: React.FC<PerfMetricsProps> = ({ perf }) => {
	const avgClass = perf.ema_ms > MS_THRESHOLD_DANGER
		? 'is-danger'
		: perf.ema_ms > MS_THRESHOLD_WARN ? 'is-warn' : ''
	return (
		<dl className="cs-insights-perf">
			<div className={`cs-insights-metric ${avgClass}`}>
				<dt>{__('Average', 'code-snippets')}</dt>
				<dd>{formatMs(perf.ema_ms)}</dd>
			</div>
			<div className="cs-insights-metric">
				<dt>{__('Last', 'code-snippets')}</dt>
				<dd>{formatMs(perf.last_ms)}</dd>
			</div>
			<div className="cs-insights-metric">
				<dt>{__('Max', 'code-snippets')}</dt>
				<dd>{formatMs(perf.max_ms)}</dd>
			</div>
			<div className="cs-insights-metric">
				<dt>{__('Samples', 'code-snippets')}</dt>
				<dd>{perf.samples}</dd>
			</div>
		</dl>
	)
}

interface FindingsListProps {
	findings: SecurityFinding[]
	snippetId: number
	actionUrl: string
	dismissNonce: string
}

const FindingsList: React.FC<FindingsListProps> = ({ findings, snippetId, actionUrl, dismissNonce }) =>
	<ul className="cs-insights-findings">
		{findings.map((f, i) => (
			<li key={`${f.rule}:${f.line}:${i}`} className={f.dismissed ? 'is-dismissed' : ''}>
				<div className="cs-insights-finding-head">
					<span className={`cs-insights-pill cs-insights-pill--${f.severity}`}>
						{f.severity.toUpperCase()}
					</span>
					<span className="cs-insights-finding-title">{f.title}</span>
					<span className="cs-insights-finding-line">
						{sprintf(__('Line %d', 'code-snippets'), f.line)}
					</span>
					{!f.dismissed && (
						<form action={actionUrl} method="post" className="cs-insights-dismiss-form">
							<input type="hidden" name="action" value="code_snippets_insights_dismiss" />
							<input type="hidden" name="_wpnonce" value={dismissNonce} />
							<input type="hidden" name="snippet_id" value={snippetId} />
							<input type="hidden" name="rule" value={f.rule} />
							<input type="hidden" name="line" value={f.line} />
							<button type="submit" className="button-link cs-insights-dismiss">
								{__('Dismiss', 'code-snippets')}
							</button>
						</form>
					)}
				</div>
				<code className="cs-insights-excerpt">{f.excerpt}</code>
				<p className="cs-insights-message">{f.message}</p>
			</li>
		))}
	</ul>
