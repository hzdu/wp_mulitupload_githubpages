import { __ } from '@wordpress/i18n'
import classnames from 'classnames'
import React, { useMemo } from 'react'
import { BLUEPRINT_CATEGORIES } from '../../../../types/blueprints/BlueprintMetadata'
import { useHorizontalScrollOverflow } from '../../../../hooks/useHorizontalScrollOverflow'
import { CATEGORY_LABELS } from './BlueprintGalleryBody'
import type { BlueprintCategory } from '../../../../types/blueprints/BlueprintMetadata'
import type { BlueprintListItem } from '../../../../blueprints'
import type { FilterCategory } from './BlueprintGalleryBody'

interface CategoryTabProps {
	category: FilterCategory
	activeCategory?: FilterCategory
	setActiveCategory: (category: FilterCategory) => void
	count?: number
}

const CategoryTab: React.FC<CategoryTabProps> = ({
	category,
	activeCategory,
	setActiveCategory,
	count
}) =>
	<li>
		<button
			type="button"
			className={classnames('snippet-type-link', `${category}-category-link`, {
				'active-type': category === activeCategory
			})}
			aria-current={category === activeCategory ? 'page' : undefined}
			onClick={() => setActiveCategory(category)}
		>
			<span>
				{'all' === category ? __('All Blueprints', 'code-snippets') : CATEGORY_LABELS[category]}
			</span>
			{undefined !== count && <span className="subnav-count">{count}</span>}
		</button>
	</li>

export interface BlueprintCategoryNavProps {
	blueprints: BlueprintListItem[]
	activeCategory?: FilterCategory
	setActiveCategory: (category: FilterCategory) => void
}

export const BlueprintCategoryNav: React.FC<BlueprintCategoryNavProps> = ({
	blueprints,
	activeCategory,
	setActiveCategory
}) => {
	const [availableCategories, categoryCounts] =
		useMemo<[FilterCategory[], Map<BlueprintCategory, number>]>(() => {
			const counts = new Map<BlueprintCategory, number>()

			blueprints.forEach(({ metadata }) =>
				metadata.categories.forEach(category => counts.set(category, (counts.get(category) ?? 0) + 1)))

			return [['all', ...BLUEPRINT_CATEGORIES.filter(category => counts.has(category))], counts]
		}, [blueprints])

	const { atStart, atEnd, scrollRef } = useHorizontalScrollOverflow()

	return (
		<div
			className={classnames('snippet-type-nav-wrapper blueprint-category-nav-wrapper', {
				'has-scroll-start': !atStart,
				'has-scroll-end': !atEnd
			})}
		>
			<nav
				ref={scrollRef}
				className="snippet-type-nav blueprint-category-nav"
				aria-label={__('Blueprint categories', 'code-snippets')}
			>
				<ul>
					{availableCategories.map(category =>
						<CategoryTab
							key={category}
							category={category}
							count={'all' === category ? blueprints.length : categoryCounts.get(category)}
							activeCategory={activeCategory}
							setActiveCategory={setActiveCategory}
						/>)}
				</ul>
			</nav>
		</div>
	)
}
