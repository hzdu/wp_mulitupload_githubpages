import { __, _n, sprintf } from '@wordpress/i18n'
import React from 'react'
import { Button } from '../../../common/Button'
import { SnippetViewToggle } from '../../../common/SnippetViewToggle'
import type { SnippetView } from '../../../../types/SnippetView'

export interface BlueprintSearchIndicatorProps {
	searchQuery: string
	setSearchQuery: (query: string) => void
}

export const BlueprintSearchIndicator: React.FC<BlueprintSearchIndicatorProps> = ({
	searchQuery,
	setSearchQuery
}) =>
	searchQuery.trim()
		? <p className="snippets-search-subtitle">
			{__('Search results', 'code-snippets')}

			{/* translators: %s: search query. */}
			{sprintf(__(' for “%s”', 'code-snippets'), searchQuery.trim())}

			{' '}
			<Button small className="clear-filters" onClick={() => setSearchQuery('')}>
				{__('Clear Filters', 'code-snippets')}
			</Button>
		</p>
		: null

export interface BlueprintsToolbarProps {
	searchQuery: string
	setSearchQuery: (query: string) => void
	totalItems: number
	snippetView: SnippetView
	setSnippetView: (view: SnippetView) => void
}

export const BlueprintsToolbar: React.FC<BlueprintsToolbarProps> = ({
	searchQuery,
	setSearchQuery,
	totalItems,
	snippetView,
	setSnippetView
}) =>
	<div className="tablenav top blueprints-toolbar">
		<div className="snippets-search-area">
			<search className="search-box" aria-label={__('Search Blueprints', 'code-snippets')}>
				<input
					id="blueprint-search-input"
					type="search"
					value={searchQuery}
					aria-label={__('Search Blueprints:', 'code-snippets')}
					onChange={event => setSearchQuery(event.target.value)}
					placeholder={__('Search Blueprints', 'code-snippets')}
				/>
			</search>
		</div>

		<div className="tablenav-pages-nav">
			<span className="displaying-num" role="status" aria-live="polite">
				{sprintf(
					// translators: %s: number of blueprints matching current filters.
					_n('%s item', '%s items', totalItems, 'code-snippets'),
					totalItems
				)}
			</span>
		</div>

		<SnippetViewToggle snippetView={snippetView} setSnippetView={setSnippetView} />

		<br className="clear" />
	</div>
