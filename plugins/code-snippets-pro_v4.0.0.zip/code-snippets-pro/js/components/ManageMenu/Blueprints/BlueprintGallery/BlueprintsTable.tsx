import { __ } from '@wordpress/i18n'
import React from 'react'
import { Button } from '../../../common/Button'
import { CATEGORY_LABELS } from './BlueprintGalleryBody'
import type { BlueprintBase, BlueprintListItem } from '../../../../blueprints'
import type { BlueprintMetadata } from '../../../../types/blueprints/BlueprintMetadata'

interface BlueprintRowProps {
	metadata: BlueprintMetadata
	onSelect: VoidFunction
}

const BlueprintRow: React.FC<BlueprintRowProps> = ({ metadata, onSelect }) =>
	<tr>
		<td className="column-name column-primary">
			<strong>
				<button type="button" className="blueprint-name-button" onClick={onSelect}>
					{metadata.title}
				</button>
			</strong>
		</td>

		<td className="column-type">
			{metadata.categories.map(category =>
				<span key={category} className="blueprint-card__badge">
					{CATEGORY_LABELS[category]}
				</span>)}
		</td>

		<td className="column-desc">
			<div className="blueprint-table-description">{metadata.description}</div>
		</td>

		<td className="column-view">
			<Button primary onClick={onSelect}>
				{__('View Blueprint', 'code-snippets')}
			</Button>
		</td>
	</tr>

export interface BlueprintsTableProps {
	blueprints: BlueprintListItem[]
	setBlueprint: (blueprint: BlueprintBase<object>) => void
}

export const BlueprintsTable: React.FC<BlueprintsTableProps> = ({ blueprints, setBlueprint }) =>
	<table className="wp-list-table widefat fixed striped blueprints-table">
		<thead>
			<tr>
				<th scope="col" className="column-name column-primary">{__('Name', 'code-snippets')}</th>
				<th scope="col" className="column-type">{__('Type', 'code-snippets')}</th>
				<th scope="col" className="column-desc">{__('Description', 'code-snippets')}</th>
				<th scope="col" className="column-view">
					<span className="screen-reader-text">{__('Actions', 'code-snippets')}</span>
				</th>
			</tr>
		</thead>
		<tbody>
			{0 < blueprints.length
				? blueprints.map(({ construct, metadata }) =>
					<BlueprintRow
						key={metadata.slug}
						metadata={metadata}
						onSelect={() => setBlueprint(construct() as unknown as BlueprintBase<object>)}
					/>)
				: <tr className="no-items">
					<td colSpan={4}>{__('No blueprints found matching the current filters.', 'code-snippets')}</td>
				</tr>}
		</tbody>
	</table>
