import { __ } from '@wordpress/i18n'
import { createInterpolateElement } from '@wordpress/element'
import React, { useMemo, useState } from 'react'
import { useSnippetView } from '../../../../hooks/useSnippetView'
import { BlueprintCardGrid, blueprintMatchesSearch } from './BlueprintGalleryBody'
import { BlueprintSearchIndicator, BlueprintsToolbar } from './BlueprintGalleryHeader'
import { BlueprintsTable } from './BlueprintsTable'
import type { BlueprintBase, BlueprintListItem } from '../../../../blueprints'
import type { FilterCategory } from './BlueprintGalleryBody'

const BlueprintsDescription = () =>
	<p className="snippets-page-description">
		{createInterpolateElement(
			__('Use code Blueprints to create advanced Code Snippets. <a>Learn more.</a>', 'code-snippets'),
			{
				a: (
					// eslint-disable-next-line jsx-a11y/anchor-has-content, jsx-a11y/control-has-associated-label
					<a
						href="https://codesnippets.pro/doc/blueprints-overview/"
						target="_blank"
						rel="noopener noreferrer"
					/>
				)
			}
		)}
	</p>

export interface BlueprintGalleryProps {
	blueprints: BlueprintListItem[]
	activeCategory: FilterCategory
	setActiveCategory: (category: FilterCategory) => void
	setBlueprint: (blueprint: BlueprintBase<object>) => void
}

export const BlueprintGallery = ({
	blueprints,
	activeCategory,
	setActiveCategory,
	setBlueprint
}: BlueprintGalleryProps) => {
	const [searchQuery, setSearchQuery] = useState('')
	const { snippetView, setSnippetView } = useSnippetView()

	const filteredBlueprints = useMemo(
		() => blueprints
			.filter(({ metadata }) =>
				'all' === activeCategory || metadata.categories.includes(activeCategory))
			.filter(({ metadata }) => blueprintMatchesSearch(metadata, searchQuery)),
		[blueprints, activeCategory, searchQuery]
	)

	return (
		<>
			<BlueprintsDescription />

			<hr className="wp-header-end" />

			<div className="snippets-list-view blueprints-list-view">
				<BlueprintsToolbar
					searchQuery={searchQuery}
					setSearchQuery={setSearchQuery}
					totalItems={filteredBlueprints.length}
					snippetView={snippetView}
					setSnippetView={setSnippetView}
				/>

				<BlueprintSearchIndicator searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

				{'card' === snippetView
					? <BlueprintCardGrid
						blueprints={filteredBlueprints}
						setActiveCategory={setActiveCategory}
						setBlueprint={setBlueprint}
					/>
					: <BlueprintsTable blueprints={filteredBlueprints} setBlueprint={setBlueprint} />}
			</div>
		</>
	)
}
