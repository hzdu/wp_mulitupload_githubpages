import { __ } from '@wordpress/i18n'
import React from 'react'
import { SnippetCard } from '../../../common/snippets/SnippetCard'
import type { BlueprintCategory, BlueprintMetadata } from '../../../../types/blueprints/BlueprintMetadata'
import type { BlueprintBase, BlueprintListItem } from '../../../../blueprints'

export type FilterCategory = 'all' | BlueprintCategory

export const CATEGORY_LABELS: Record<FilterCategory, string> = {
	all: __('All', 'code-snippets'),
	admin: __('Admin', 'code-snippets'),
	content: __('Content', 'code-snippets'),
	core: __('Core', 'code-snippets'),
	design: __('Design', 'code-snippets'),
	general: __('General', 'code-snippets'),
	query: __('Query', 'code-snippets')
}

export const blueprintMatchesSearch = (metadata: BlueprintMetadata, query: string): boolean =>
	'' === query.trim() ||
	[
		metadata.title,
		metadata.description,
		metadata.slug,
		metadata.categories.map(category => CATEGORY_LABELS[category]).join(' ')
	]
		.join(' ')
		.toLowerCase()
		.includes(query.trim().toLowerCase())

interface BlueprintCardProps {
	metadata: BlueprintMetadata
	onCategorySelect: (category: BlueprintCategory) => void
	onSelect: VoidFunction
}

const BlueprintCard = ({ metadata, onCategorySelect, onSelect }: BlueprintCardProps) => {
	const handleSelect = (event: React.SyntheticEvent) => {
		event.preventDefault()
		onSelect()
	}

	return (
		<SnippetCard
			className="blueprint-card"
			footer={
				<button
					type="button"
					className="button button-primary"
					onClick={handleSelect}
				>
					{__('View Blueprint', 'code-snippets')}
				</button>
			}
			footerStatus={
				0 < metadata.categories.length
					? metadata.categories.map(category =>
						<button
							key={category}
							type="button"
							className="blueprint-card-category"
							onClick={() => onCategorySelect(category)}
						>
							{CATEGORY_LABELS[category]}
						</button>)
					: null
			}
		>
			<div className="card-inner">
				<div className="blueprint-card-header">
					<h2 className="blueprint-card-heading">
						<button
							type="button"
							className="blueprint-card-title"
							onClick={handleSelect}
						>
							{metadata.title}
						</button>
					</h2>

					<span className="blueprint-card-pro-badge">{__('Pro', 'code-snippets')}</span>
				</div>

				<p className="blueprint-card-description">{metadata.description}</p>
			</div>
		</SnippetCard>
	)
}

export interface BlueprintCardGridProps {
	blueprints: BlueprintListItem[]
	setActiveCategory: (category: BlueprintCategory) => void
	setBlueprint: (blueprint: BlueprintBase<object>) => void
}

export const BlueprintCardGrid: React.FC<BlueprintCardGridProps> = ({
	blueprints,
	setActiveCategory,
	setBlueprint
}) =>
	<div className="blueprint-gallery">
		<ul className="code-snippets-cards blueprint-card-grid">
			{blueprints.map(({ construct, metadata }) =>
				<BlueprintCard
					key={metadata.slug}
					metadata={metadata}
					onCategorySelect={setActiveCategory}
					onSelect={() => setBlueprint(construct() as unknown as BlueprintBase<object>)}
				/>)}
		</ul>
	</div>
