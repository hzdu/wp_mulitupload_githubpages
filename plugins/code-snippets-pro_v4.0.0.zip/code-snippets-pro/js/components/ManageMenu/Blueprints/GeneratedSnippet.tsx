import { __, sprintf } from '@wordpress/i18n'
import React, { useState } from 'react'
import { useSnippetsAPI } from '../../../hooks/useSnippetsAPI'
import { createSnippetObject } from '../../../utils/snippets/snippets'
import { buildUrl } from '../../../utils/urls'
import type { BlueprintBase } from '../../../blueprints'
import type { BlueprintSaveMessage } from './Blueprints'
import type { FormEventHandler, PropsWithChildren } from 'react'
import type { Snippet } from '../../../types/Snippet'

const REDIRECT_DELAY_MS = 1500

interface CreateSnippetFormProps extends PropsWithChildren {
	createPayload: () => Snippet
	setIsSaving: (isSaving: boolean) => void
	setIsRedirecting: (isRedirecting: boolean) => void
	setSaveMessage: (message?: { type: 'success' | 'error'; message: string }) => void
}

const CreateSnippetForm: React.FC<CreateSnippetFormProps> = ({
	children,
	setIsSaving,
	setSaveMessage,
	setIsRedirecting,
	createPayload
}) => {
	const snippetsAPI = useSnippetsAPI()

	const handleSave: FormEventHandler<HTMLFormElement> = event => {
		event.preventDefault()

		setIsSaving(true)
		setSaveMessage(undefined)
		setIsRedirecting(false)

		snippetsAPI.create(createPayload())
			.then(response => {
				if (response.id) {
					setIsRedirecting(true)
					setSaveMessage({
						type: 'success',
						message: __('Snippet created successfully! Redirecting to edit page…', 'code-snippets')
					})
					setTimeout(() => {
						window.location.href = buildUrl(window.CODE_SNIPPETS?.urls.edit, { id: response.id })
					}, REDIRECT_DELAY_MS)
				} else {
					setIsSaving(false)
				}
			})
			.catch(() => {
				setIsSaving(false)
				setSaveMessage({
					type: 'error',
					message: __('Failed to create snippet. Please try again.', 'code-snippets')
				})
			})
	}

	return <form className="generated-snippet" onSubmit={handleSave}>{children}</form>
}

interface SnippetMetaFormFieldsProps {
	snippetName: string
	setSnippetName: (name: string) => void
	snippetDescription: string
	setSnippetDescription: (description: string) => void
}

const SnippetMetaFormFields: React.FC<SnippetMetaFormFieldsProps> = ({
	snippetName,
	setSnippetName,
	snippetDescription,
	setSnippetDescription
}) =>
	<div className="snippet-meta">
		<div className="form-field">
			<label htmlFor="snippet-name" id="snippet-name-label">
				{__('Snippet Name', 'code-snippets')}
			</label>
			<input
				type="text"
				id="snippet-name"
				value={snippetName}
				aria-labelledby="snippet-name-label"
				onChange={event => setSnippetName(event.target.value)}
			/>
		</div>

		<div className="form-field">
			<label htmlFor="snippet-description" id="snippet-description-label">
				{__('Description', 'code-snippets')}
			</label>
			<input
				type="text"
				id="snippet-description"
				value={snippetDescription}
				aria-labelledby="snippet-description-label"
				onChange={event => setSnippetDescription(event.target.value)}
			/>
		</div>
	</div>

interface GeneratedCodePreviewProps {
	code: string
}

const GeneratedCodePreview: React.FC<GeneratedCodePreviewProps> = ({ code }) =>
	<div className="code-preview">
		<div className="form-field">
			<label htmlFor="generated-code" id="generated-code-label">
				{__('Generated PHP Code', 'code-snippets')}
			</label>
			<textarea
				id="generated-code"
				value={code}
				readOnly
				rows={20}
				style={{ fontFamily: 'monospace' }}
				className="widefat"
				aria-labelledby="generated-code-label"
			/>
		</div>
	</div>

interface SaveButtonProps {
	isSaving: boolean
}

const SaveButton: React.FC<SaveButtonProps> = ({ isSaving }) =>
	<button type="submit" className="generated-snippet__save" disabled={isSaving}>
		{isSaving ? __('Saving…', 'code-snippets') : __('Save as New Snippet', 'code-snippets')}
	</button>

export interface GeneratedSnippetProps<FormData> {
	blueprint: BlueprintBase<FormData>
	generatedCode: string
	setSaveMessage: (message?: BlueprintSaveMessage) => void
}

export const GeneratedSnippet = <FormData, >({
	blueprint,
	generatedCode,
	setSaveMessage
}: GeneratedSnippetProps<FormData>) => {
	const [isSaving, setIsSaving] = useState(false)
	const [_isRedirecting, setIsRedirecting] = useState(false)

	const { slug: blueprintSlug, recommendedScope } = blueprint.getMetadata()

	const [snippetName, setSnippetName] = useState(() =>
		// translators: %s: default snippet name (e.g. "Custom settings page" or "my_post_type Custom Content")
		sprintf(__('%s - Blueprint Code', 'code-snippets'), blueprint.getDefaultSnippetName()))

	const [snippetDescription, setSnippetDescription] = useState(() => blueprint.getDefaultSnippetDescription())

	const createPayload = () => createSnippetObject({
		name: snippetName,
		code: generatedCode,
		desc: snippetDescription,
		tags: ['generated', 'blueprint', blueprintSlug],
		scope: recommendedScope ?? 'global'
	})

	return (
		<CreateSnippetForm {...{ setIsSaving, setIsRedirecting, setSaveMessage, createPayload }}>
			<div className="generated-snippet__header">
				<h2>{__('Code Preview', 'code-snippets')}</h2>
				<div className="generated-snippet__actions-top">
					<SaveButton isSaving={isSaving} />
				</div>
			</div>

			<SnippetMetaFormFields {...{ snippetName, setSnippetName, snippetDescription, setSnippetDescription }} />
			<GeneratedCodePreview code={generatedCode} />

			<div className="snippet-actions">
				<p className="description" style={{ marginBottom: 8 }}>
					{'admin' === recommendedScope && __('When saved, this snippet will be set to run: Only in admin.', 'code-snippets')}
					{'front-end' === recommendedScope && __('When saved, this snippet will be set to run: Only on front-end.', 'code-snippets')}
					{'global' === recommendedScope && __('When saved, this snippet will be set to run: Run everywhere.', 'code-snippets')}
				</p>
				<SaveButton isSaving={isSaving} />
			</div>
		</CreateSnippetForm>
	)
}
