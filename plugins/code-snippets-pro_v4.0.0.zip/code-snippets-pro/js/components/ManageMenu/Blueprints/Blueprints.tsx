import { __, sprintf } from '@wordpress/i18n'
import React, { useMemo, useState } from 'react'
import { WithRestAPIContext } from '../../../hooks/useRestAPI'
import { WithSnippetsAPIContext } from '../../../hooks/useSnippetsAPI'
import { listBlueprints } from '../../../blueprints'
import { fetchQueryParam, updateQueryParams } from '../../../utils/urls'
import { ScreenMetaSlot } from '../../common/ScreenMetaSlot'
import { BlueprintDetails } from './BlueprintDetails/BlueprintDetails'
import { BlueprintCategoryNav } from './BlueprintGallery/BlueprintCategoryNav'
import { CATEGORY_LABELS } from './BlueprintGallery/BlueprintGalleryBody'
import { BlueprintGallery } from './BlueprintGallery/BlueprintGallery'
import { GeneratedSnippet } from './GeneratedSnippet'
import type { BlueprintBase } from '../../../blueprints'
import type { Dispatch, ReactNode, SetStateAction } from 'react'
import type { FilterCategory } from './BlueprintGallery/BlueprintGalleryBody'

const BLUEPRINT_URL_PARAM = 'blueprint'

const getBlueprintFromUrl = () => {
	const param = fetchQueryParam(BLUEPRINT_URL_PARAM)

	if (param) {
		for (const blueprint of listBlueprints()) {
			if (blueprint.metadata.slug === param) {
				return blueprint.construct()
			}
		}
	}

	updateQueryParams({ [BLUEPRINT_URL_PARAM]: undefined })
	return undefined
}

interface BlueprintData<FormData> {
	blueprint?: BlueprintBase<FormData>
	setBlueprint: Dispatch<SetStateAction<BlueprintBase<FormData> | undefined>>
}

const useBlueprintData = <FormData, >(): BlueprintData<FormData> => {
	const [blueprint, setBlueprint] = useState<BlueprintBase<FormData> | undefined>(() =>
		getBlueprintFromUrl() as BlueprintBase<FormData> | undefined)

	return { blueprint, setBlueprint }
}

export interface BlueprintSaveMessage {
	type: 'success' | 'error'
	message: ReactNode
}

interface SaveMessageProps {
	message: BlueprintSaveMessage
}

const SaveMessage: React.FC<SaveMessageProps> = ({ message }) =>
	<div className={`notice notice-${message.type} is-dismissible`}>
		<p>{message.message}</p>
	</div>

interface BlueprintPageHeaderProps {
	blueprints: ReturnType<typeof listBlueprints>
	activeCategory: FilterCategory
	navigationActiveCategory?: FilterCategory
	title?: string
	onBack?: VoidFunction
	setActiveCategory: (category: FilterCategory) => void
}

const BlueprintPageHeader: React.FC<BlueprintPageHeaderProps> = ({
	blueprints,
	activeCategory,
	navigationActiveCategory,
	title,
	onBack,
	setActiveCategory
}) =>
	<>
		<BlueprintCategoryNav
			blueprints={blueprints}
			activeCategory={navigationActiveCategory}
			setActiveCategory={setActiveCategory}
		/>

		<ScreenMetaSlot />

		<div className="snippets-page-header">
			<h1>{sprintf(
				// translators: %s: selected Blueprint title or currently selected Blueprint category label.
				__('Blueprints: %s', 'code-snippets'),
				title ?? ('all' === activeCategory
					? __('All Blueprints', 'code-snippets')
					: CATEGORY_LABELS[activeCategory])
			)}</h1>

			{onBack && (
				<button type="button" className="button button-secondary" onClick={onBack}>
					{__('Back to blueprints', 'code-snippets')}
				</button>)}
		</div>
	</>

// eslint-disable-next-line max-lines-per-function
const BlueprintsInner = () => {
	const { blueprint, setBlueprint } = useBlueprintData<object>()
	const [activeCategory, setActiveCategory] = useState<FilterCategory>('all')
	const [saveMessage, setSaveMessage] = useState<BlueprintSaveMessage>()
	const [generatedCode, setGeneratedCode] = useState<string>()
	const blueprints = useMemo(() => listBlueprints(), [])

	const handleGenerate = () => {
		setBlueprint(previous => {
			if (!previous) {
				return previous
			}

			const newBlueprint = previous.clone()
			newBlueprint.validate()

			if (newBlueprint.hasValidationErrors()) {
				setGeneratedCode(undefined)
			} else {
				setGeneratedCode(newBlueprint.generateCode())
			}

			return newBlueprint
		})
	}

	const handleResetSelection = () => {
		setBlueprint(undefined)
		setGeneratedCode(undefined)
		updateQueryParams({ [BLUEPRINT_URL_PARAM]: undefined })
	}

	const handleCategoryChange = (category: FilterCategory) => {
		setActiveCategory(category)
		handleResetSelection()
	}

	return (
		<div className="blueprints-page">
			{saveMessage && <SaveMessage message={saveMessage} />}

			<BlueprintPageHeader
				blueprints={blueprints}
				activeCategory={activeCategory}
				navigationActiveCategory={blueprint ? undefined : activeCategory}
				title={blueprint?.getMetadata().title}
				onBack={blueprint ? handleResetSelection : undefined}
				setActiveCategory={handleCategoryChange}
			/>

			{blueprint
				? <BlueprintDetails
					blueprint={blueprint}
					setBlueprint={setBlueprint}
					onGenerate={handleGenerate}
				/>
				: <BlueprintGallery
					blueprints={blueprints}
					activeCategory={activeCategory}
					setActiveCategory={handleCategoryChange}
					setBlueprint={newBlueprint => {
						setBlueprint(newBlueprint)
						updateQueryParams({ [BLUEPRINT_URL_PARAM]: newBlueprint.getMetadata().slug })
					}}
				/>}

			{blueprint && generatedCode && (
				<GeneratedSnippet
					blueprint={blueprint}
					setSaveMessage={setSaveMessage}
					generatedCode={generatedCode}
				/>)}
		</div>
	)
}

export const Blueprints = () =>
	<WithRestAPIContext>
		<WithSnippetsAPIContext>
			<BlueprintsInner />
		</WithSnippetsAPIContext>
	</WithRestAPIContext>
