import React, { useState } from 'react'
import classnames from 'classnames'
import { __ } from '@wordpress/i18n'
import { fetchQueryParam, updateQueryParams } from '../../../../utils/urls'
import { BlueprintFormFields } from './BlueprintFormFields'
import type { Dispatch, SetStateAction } from 'react'
import type { BlueprintMetadata } from '../../../../types/blueprints/BlueprintMetadata'
import type { BlueprintBase } from '../../../../blueprints'

const FORM_SECTION_URL_PARAM = 'section'

const getFormSectionFromUrl = <FormData, >(blueprint: BlueprintBase<FormData>): keyof FormData | undefined => {
	const param = fetchQueryParam(FORM_SECTION_URL_PARAM)

	if (param) {
		const sectionKeys = blueprint.getFormSectionKeys().map(String)
		if (sectionKeys.includes(param)) {
			return param as keyof FormData
		}
	}

	updateQueryParams({ [FORM_SECTION_URL_PARAM]: undefined })
	return undefined
}

interface BlueprintDetailHeaderProps {
	metadata: BlueprintMetadata
}

const BlueprintDetailHeader: React.FC<BlueprintDetailHeaderProps> = ({ metadata: { description, intro, docsUrl } }) =>
	<header className="blueprint-detail__header">
		<div className="blueprint-detail__header-content">
			<p>{description}</p>

			{intro && <p className="blueprint-detail__intro">{intro}</p>}

			{docsUrl && (
				<a
					href={docsUrl}
					target="_blank"
					rel="noopener noreferrer"
					className="button button-secondary docs-link"
				>
					{__('Read Documentation', 'code-snippets')}
				</a>)}
		</div>
	</header>

interface BlueprintFormSidebarProps<FormData> {
	blueprint: BlueprintBase<FormData>
	activeSectionId: keyof FormData
	setActiveSectionId: (sectionId: keyof FormData) => void
}

const BlueprintFormSidebar = <FormData, >({
	blueprint,
	activeSectionId,
	setActiveSectionId
}: BlueprintFormSidebarProps<FormData>) =>
	<nav
		className="blueprint-form-sidebar"
		aria-label={__('Blueprint sections', 'code-snippets')}
	>
		<ul>
			{blueprint.getFormSectionKeys().map(sectionId => {
				const isActive = sectionId === activeSectionId
				const section = blueprint.getFormSection(sectionId)

				return <li key={String(sectionId)}>
					<button
						type="button"
						className={classnames('blueprint-form-sidebar__item', { 'is-active': isActive })}
						onClick={event => {
							event.preventDefault()
							setActiveSectionId(sectionId)
						}}
						aria-current={isActive ? 'step' : undefined}
					>
						<span>{section.title}</span>
					</button>
				</li>
			})}
		</ul>

		<div className="blueprint-form-sidebar__generate-wrap">
			<button type="submit" className="blueprint-form-sidebar__generate">
				{__('Generate Code', 'code-snippets')}
			</button>
		</div>
	</nav>

interface BlueprintDetailsContentProps<FormData> {
	blueprint: BlueprintBase<FormData>
	setBlueprint: Dispatch<SetStateAction<BlueprintBase<FormData> | undefined>>
}

const BlueprintDetailsContent = <FormData, >({ blueprint, setBlueprint }: BlueprintDetailsContentProps<FormData>) => {
	const [sectionKey, setSectionKey] = useState(() =>
		getFormSectionFromUrl(blueprint) ?? blueprint.defaultSectionKey)

	const section = blueprint.getFormSection(sectionKey)

	return (
		<>
			<BlueprintFormSidebar
				blueprint={blueprint}
				activeSectionId={sectionKey}
				setActiveSectionId={setSectionKey}
			/>

			<div className="blueprint-form-content">
				<>
					<h2>{section.title}</h2>
					{section.description && <p className="blueprint-form-section-description">{section.description}</p>}

					<BlueprintFormFields
						blueprint={blueprint}
						sectionKey={sectionKey}
						setBlueprint={setBlueprint}
					/>
				</>
			</div>
		</>
	)
}

export interface BlueprintDetailsProps<FormData> {
	blueprint: BlueprintBase<FormData>
	setBlueprint: Dispatch<SetStateAction<BlueprintBase<FormData> | undefined>>
	onGenerate: VoidFunction
}

export const BlueprintDetails = <FormData, >({
	blueprint,
	setBlueprint,
	onGenerate
}: BlueprintDetailsProps<FormData>) =>
	<div className="blueprint-detail">
		<BlueprintDetailHeader metadata={blueprint.getMetadata()} />

		{blueprint.hasValidationErrors() && (
			<div className="notice notice-error blueprint-validation-notice" role="alert">
				<p>{__('Please fix the errors below before generating code.', 'code-snippets')}</p>
			</div>)}

		<form className="blueprint-form-layout" onSubmit={event => {
			event.preventDefault()
			onGenerate()
		}}>
			<BlueprintDetailsContent blueprint={blueprint} setBlueprint={setBlueprint} />
		</form>
	</div>
