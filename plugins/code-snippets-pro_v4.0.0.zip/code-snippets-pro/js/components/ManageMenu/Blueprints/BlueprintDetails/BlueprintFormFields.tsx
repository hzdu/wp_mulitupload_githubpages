import classnames from 'classnames'
import React from 'react'
import { BlueprintInputField } from './BlueprintInputField'
import { BlueprintFieldRepeater } from './BlueprintFieldRepeater'
import type { Dispatch, ReactNode, SetStateAction } from 'react'
import type { BlueprintBase } from '../../../../blueprints'

interface FormFieldWrapperProps {
	className?: classnames.Argument
	children: ReactNode
	errorMessage: string | undefined
	name: string
	label: string
	required?: boolean
}

const FormFieldWrapper: React.FC<FormFieldWrapperProps> = ({
	name,
	label,
	required,
	className,
	children,
	errorMessage
}) =>
	<div className={classnames('blueprint-form-field', { 'has-error': errorMessage }, className)}>
		<label htmlFor={name}>
			{label} {required && <span className="required">*</span>}
		</label>
		{children}
		{errorMessage && <p className="blueprint-form-field__error" role="alert">{errorMessage}</p>}
	</div>

export interface BlueprintFormFieldsProps<FormData, RepeaterFields> {
	blueprint: BlueprintBase<FormData, RepeaterFields>
	sectionKey: keyof FormData
	setBlueprint: Dispatch<SetStateAction<BlueprintBase<FormData, RepeaterFields> | undefined>>
}

export const BlueprintFormFields = <FormData, RepeaterFields>({
	blueprint,
	sectionKey,
	setBlueprint
}: BlueprintFormFieldsProps<FormData, RepeaterFields>) =>
	<div className="blueprint-form-fields">
		{blueprint.getSectionFields(sectionKey).map(field =>
			<FormFieldWrapper
				key={field.name.toString()}
				name={field.name.toString()}
				label={field.props.label}
				required={field.props.required}
				errorMessage={field.error}
			>
				<BlueprintInputField
					name={field.name.toString()}
					field={field.props}
					onChange={newValue => {
						setBlueprint(previous =>
							previous?.modifyFieldValue(sectionKey, field.name, newValue as FormData[typeof sectionKey][typeof field.name]))
					}}
				/>
				{field.props.description && <p className="description">{field.props.description}</p>}
			</FormFieldWrapper>)}

		{blueprint.getSectionRepeaters(sectionKey).map(repeater =>
			<FormFieldWrapper
				key={repeater.name.toString()}
				name={repeater.name.toString()}
				label={repeater.label}
				required={!repeater.allowEmpty}
				className="blueprint-form-repeater"
				errorMessage={repeater.error}
			>
				<BlueprintFieldRepeater blueprint={blueprint} setBlueprint={setBlueprint} repeaterKey={repeater.name} />
			</FormFieldWrapper>)}
	</div>
