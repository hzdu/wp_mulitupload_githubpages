import React from 'react'
import classnames from 'classnames'
import { __ } from '@wordpress/i18n'
import { BlueprintInputField } from './BlueprintInputField'
import type { BlueprintBase, BlueprintRepeaterRow } from '../../../../blueprints'
import type { Dispatch, SetStateAction } from 'react'

interface RepeaterRowFieldsProps<FormData, RepeaterFields, R extends keyof RepeaterFields> {
	repeater: R
	row: BlueprintRepeaterRow<RepeaterFields[R]>
	setBlueprint: Dispatch<SetStateAction<BlueprintBase<FormData, RepeaterFields> | undefined>>
}

const RepeaterRowFields = <FormData, RepeaterFields, R extends keyof RepeaterFields>({
	row,
	repeater,
	setBlueprint
}: RepeaterRowFieldsProps<FormData, RepeaterFields, R>) =>
	row.fields.map(field =>
		<div
			key={field.name.toString()}
			className={classnames('blueprint-form-field blueprint-form-repeater__cell', { 'has-error': field.error })}
		>
			{'checkbox' === field.props.type && (
				<BlueprintInputField
					name={field.name.toString()}
					field={field.props}
					onChange={newValue => setBlueprint(blueprint =>
						blueprint?.setRepeaterField(repeater, row.rowId, field.name, newValue as RepeaterFields[R][typeof field.name]))}
				/>)}

			<label htmlFor={field.name.toString()}>
				{field.props.label}
				{field.props.required && <span className="required">*</span>}
			</label>

			{'checkbox' !== field.props.type && (
				<BlueprintInputField
					name={field.name.toString()}
					field={field.props}
					onChange={newValue => setBlueprint(blueprint =>
						blueprint?.setRepeaterField(repeater, row.rowId, field.name, newValue as RepeaterFields[R][typeof field.name]))}
				/>
			)}

			{field.props.description && <p className="description">{field.props.description}</p>}
			{field.error && <p className="blueprint-form-field__error" role="alert">{field.error}</p>}
		</div>
	)

interface AddRowButtonProps {
	label?: string
	onClick: VoidFunction
}

export const AddRowButton = ({ label, onClick }: AddRowButtonProps) =>
	<button
		type="button"
		className="button button-secondary blueprint-form-repeater__add"
		onClick={onClick}
	>
		{label ?? __('Add', 'code-snippets')}
	</button>

export interface BlueprintRepeaterFieldProps<FormData, RepeaterFields> {
	blueprint: BlueprintBase<FormData, RepeaterFields>
	repeaterKey: keyof RepeaterFields
	setBlueprint: Dispatch<SetStateAction<BlueprintBase<FormData, RepeaterFields> | undefined>>
}

export const BlueprintFieldRepeater = <FormData, RepeaterFields>({
	blueprint,
	repeaterKey,
	setBlueprint
}: BlueprintRepeaterFieldProps<FormData, RepeaterFields>) => {
	const repeater = blueprint.getRepeaterField(repeaterKey)
	const rows = blueprint.getRepeaterRows(repeaterKey)

	if (!repeater) {
		return null
	}

	const handleAdd = () => {
		setBlueprint(previous =>
			previous?.addRepeaterRow(repeaterKey))
	}

	const handleRemove = (rowId: string) => {
		setBlueprint(previous =>
			previous?.removeRepeaterRow(repeaterKey, rowId))
	}

	return (
		<>
			{0 === rows.length && (
				<p className="blueprint-form-field__repeater-empty">
					{repeater.emptyMessage ?? __('Add at least one item.', 'code-snippets')}
				</p>)}

			<div className="blueprint-form-repeater">
				{rows.map(row =>
					<div key={row.rowId} className="blueprint-form-repeater__row">
						<RepeaterRowFields row={row} repeater={repeaterKey} setBlueprint={setBlueprint} />

						<div className="blueprint-form-repeater__actions">
							<button
								type="button"
								className="button button-secondary button-small"
								onClick={() => handleRemove(row.rowId)}
							>
								{__('Remove', 'code-snippets')}
							</button>
						</div>
					</div>)}

				<AddRowButton label={repeater.addLabel} onClick={handleAdd} />
			</div>
		</>
	)
}
