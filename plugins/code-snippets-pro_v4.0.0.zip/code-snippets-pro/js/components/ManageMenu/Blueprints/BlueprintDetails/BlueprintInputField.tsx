import React, { useState } from 'react'
import { __ } from '@wordpress/i18n'
import type { CheckboxFormField, FormField, SelectFormField, TextLikeFormField } from '../../../../types/blueprints/FormField'
import type { Dispatch, SetStateAction } from 'react'

const yesNoOptions = [
	{ value: true, label: __('Yes', 'code-snippets') },
	{ value: false, label: __('No', 'code-snippets') }
]

const asString = (value: unknown) => {
	if ('string' === typeof value) {
		return value
	}

	if ('number' === typeof value || 'boolean' === typeof value) {
		return String(value)
	}

	return ''
}

const useFormFieldValue = <T, F extends FormField<T>>(field: F): [
	F['value'],
	Dispatch<SetStateAction<F['value']>>
] => {
	const [fieldValue, setFieldValue] = useState(field.value)

	return [fieldValue, setFieldValue]
}

interface InputFieldProps<F extends FormField<unknown>> {
	name: string
	field: F
	onChange: (newValue: F['value']) => void
	label: string
}

const TextInputField: React.FC<InputFieldProps<TextLikeFormField>> = ({ name, field, label, onChange }) => {
	const [fieldValue, setFieldValue] = useFormFieldValue(field)

	return (
		<input
			type="text"
			aria-label={label}
			id={name}
			value={fieldValue}
			onChange={event => setFieldValue(event.target.value)}
			onBlur={() => onChange(fieldValue)}
			placeholder={field.placeholder}
		/>
	)
}

const TextAreaInputField: React.FC<InputFieldProps<TextLikeFormField>> = ({ name, field, label, onChange }) => {
	const [fieldValue, setFieldValue] = useFormFieldValue(field)

	return (
		<textarea
			id={name}
			aria-label={label}
			value={fieldValue}
			onChange={event => setFieldValue(event.target.value)}
			onBlur={() => onChange(fieldValue)}
			placeholder={field.placeholder}
			rows={5}
			className="widefat"
		/>
	)
}

const SelectInputField = <T, >({ name, field, label, onChange }: InputFieldProps<SelectFormField<T>>) =>
	<select
		id={name}
		aria-label={label}
		value={asString(field.value)}
		onChange={event => {
			for (const option of field.options) {
				if (asString(option.value) === event.target.value) {
					onChange(option.value)
					break
				}
			}
		}}
	>
		<option value="">{__('-- Select --', 'code-snippets')}</option>
		{field.options.map(option =>
			<option key={option.label} value={asString(option.value)}>{option.label}</option>)}
	</select>

const CheckboxInputField: React.FC<InputFieldProps<CheckboxFormField>> = ({ name, field, label, onChange }) =>
	<input
		type="checkbox"
		id={name}
		aria-label={label}
		checked={field.value}
		onChange={event => onChange(event.target.checked)}
	/>

export interface BlueprintInputFieldProps<T, F extends FormField<T>> {
	name: string
	field: F
	onChange: (newValue: T) => void
	label: string
}

export const BlueprintInputField = <T, F extends FormField<T>>({
	name,
	field,
	label,
	onChange
}: BlueprintInputFieldProps<F['value'], F>) => {
	switch (field.type) {
		case 'text':
			return <TextInputField field={field} name={name} label={label} onChange={onChange} />

		case 'textarea':
			return <TextAreaInputField field={field} name={name} label={label} onChange={onChange} />

		case 'select':
			return <SelectInputField field={field} name={name} label={label} onChange={onChange} />

		case 'checkbox':
			return <CheckboxInputField field={field} name={name} label={label} onChange={onChange} />

		case 'boolean-select':
			return (
				<SelectInputField
					name={name}
					label={label}
					field={{ ...field, type: 'select', options: yesNoOptions }}
					onChange={onChange}
				/>
			)

		default: {
			console.error(`Unsupported field type: ${field.type}`)
			return null
		}
	}
}
