import { __ } from '@wordpress/i18n'
import React, { useMemo, useState } from 'react'
import { useFetchData } from '../../../hooks/useFetchData'
import { useSnippetView } from '../../../hooks/useSnippetView'
import { WithRestAPIContext } from '../../../hooks/useRestAPI'
import { REST_BASES } from '../../../utils/restAPI'
import { buildUrl } from '../../../utils/urls'
import { CloudConnectPrompt } from '../../common/cloud/CloudConnectPrompt'
import { LibraryIcon } from '../../common/icons/LibraryIcon'
import { LoadingStatusNotices } from '../../common/LoadingStatusNotices'
import { ScreenMetaSlot } from '../../common/ScreenMetaSlot'
import { WithCloudSnippetDownloadsContext } from '../../common/cloud/WithCloudSnippetDownloadsContext'
import { SnippetViewToggle } from '../../common/SnippetViewToggle'
import { SubnavTabs, getTabFromQuery } from '../../common/SubnavTabs'
import { CloudLibraryBundles } from './CloudLibraryBundles'
import { CloudLibraryCards } from './CloudLibraryCards'
import { CloudLibraryTable } from './CloudLibraryTable'
import type { CloudSnippetSchema } from '../../../types/schema/CloudSnippetSchema'
import type { ReactNode} from 'react'
import type { LoadingStatus } from '../../../hooks/useFetchData'
import type { SubnavTab } from '../../common/SubnavTabs'
import type { SnippetView } from '../../../types/SnippetView'
import type { CloudBundleSchema } from '../../../types/schema/CloudBundleSchema'
import type { CloudSnippetsSchema } from '../../../types/schema/CloudSnippetsSchema'

export const TAB_QUERY_PARAM = 'tab'

const TABS: SubnavTab<'snippets' | 'bundles'>[] = [
	{
		name: 'snippets',
		label: __('My Code Snippets', 'code-snippets')
	},
	{
		name: 'bundles',
		label: __('My Bundles', 'code-snippets')
	}
]

interface CloudLibrarySearchAreaProps {
	searchQuery: string
	setSearchQuery: (query: string) => void
}

const CloudLibrarySearchArea: React.FC<CloudLibrarySearchAreaProps> = ({
	searchQuery,
	setSearchQuery
}) =>
	<div className="snippets-search-area">
		<search className="search-box" aria-label={__('Search Snippets', 'code-snippets')}>
			<input
				type="search"
				id="cloud-library-search"
				value={searchQuery}
				aria-label={__('Filter snippets on this page:', 'code-snippets')}
				onChange={event => setSearchQuery(event.target.value)}
				placeholder={__('Filter snippets on this page', 'code-snippets')}
			/>
		</search>
	</div>

const filterCloudSnippets = (snippets: CloudSnippetSchema[], searchTerms: string): CloudSnippetSchema[] =>
	searchTerms
		? snippets.filter(snippet =>
			[snippet.name, snippet.description, snippet.tags.join(' ')]
				.join(' ')
				.toLowerCase()
				.includes(searchTerms))
		: snippets

interface CloudLibrarySnippetsViewProps {
	view: SnippetView
	snippets: CloudSnippetsSchema
	isLoading: boolean
	currentPage: number
	setCurrentPage: (page: number) => void
	onDownloaded: () => Promise<void>
	extraTableNav?: (which: 'top' | 'bottom') => ReactNode
	endTableNav?: (which: 'top' | 'bottom') => ReactNode
}

const CloudLibrarySnippetsView: React.FC<CloudLibrarySnippetsViewProps> = ({
	view,
	snippets,
	isLoading,
	currentPage,
	onDownloaded,
	setCurrentPage,
	extraTableNav,
	endTableNav
}) =>
	'card' === view
		? <CloudLibraryCards
			snippets={snippets}
			onDownloaded={onDownloaded}
			currentPage={currentPage}
			setCurrentPage={setCurrentPage}
			totalPages={snippets.total_pages}
			disabled={isLoading}
			extraTableNav={extraTableNav}
			endTableNav={endTableNav}
		/>
		: <CloudLibraryTable
			snippets={snippets}
			onDownloaded={onDownloaded}
			currentPage={currentPage}
			setCurrentPage={setCurrentPage}
			extraTableNav={extraTableNav}
			endTableNav={endTableNav}
			totalPages={snippets.total_pages}
			totalItems={snippets.total_snippets}
		/>

interface CloudLibrarySnippetsProps {
	codevault: CloudSnippetsSchema | undefined
	codevaultPage: number
	setCodevaultPage: (page: number) => void
	snippetView: SnippetView
	setSnippetView: (snippetView: SnippetView) => void
	loadingStatus: LoadingStatus
	refreshCodevault: () => Promise<void>
}

const CloudLibrarySnippets: React.FC<CloudLibrarySnippetsProps> = ({
	codevault,
	codevaultPage,
	setCodevaultPage,
	refreshCodevault,
	loadingStatus,
	snippetView,
	setSnippetView
}) => {
	const [query, setQuery] = useState('')

	const filteredSnippets = useMemo(
		() => codevault?.snippets && filterCloudSnippets(codevault.snippets, query.trim().toLowerCase()),
		[codevault?.snippets, query]
	)

	return codevault && filteredSnippets
		? <CloudLibrarySnippetsView
			view={snippetView}
			snippets={{ ...codevault, snippets: filteredSnippets }}
			onDownloaded={refreshCodevault}
			isLoading={loadingStatus.isLoading}
			currentPage={codevaultPage}
			setCurrentPage={page => {
				setQuery('')
				setCodevaultPage(page)
			}}
			extraTableNav={which =>
				'top' === which
					? <CloudLibrarySearchArea searchQuery={query} setSearchQuery={setQuery} />
					: null}
			endTableNav={which =>
				'top' === which
					? <SnippetViewToggle snippetView={snippetView} setSnippetView={setSnippetView} />
					: null}
		/>
		: <LoadingStatusNotices
			{...loadingStatus}
			noticeLabel={__('Cloud library load status', 'code-snippets')}
			loadingNotice={__('Loading snippets from cloud library…', 'code-snippets')}
		/>
}

const ConnectedCloudLibrary = () => {
	const { snippetView, setSnippetView } = useSnippetView()
	const [currentTab, setCurrentTab] = useState(() => getTabFromQuery(TABS, TAB_QUERY_PARAM))

	const [codevaultPage, setCodevaultPage] = useState(1)

	const { data: bundles, ...bundlesLoadingStatus } = useFetchData<CloudBundleSchema[]>(REST_BASES.cloud.bundles)

	const { data: codevault, refreshData: refreshCodevault, ...codevaultStatus } =
		useFetchData<CloudSnippetsSchema>(buildUrl(`${REST_BASES.cloud.snippets}/codevault`, { page: codevaultPage }))

	return (
		<>
			<SubnavTabs
				className="cloud-library-nav"
				ariaLabel={__('Cloud Library tabs', 'code-snippets')}
				tabs={TABS}
				currentTab={currentTab}
				setCurrentTab={setCurrentTab}
				queryParamName={TAB_QUERY_PARAM}
				getTabCount={tab => {
					switch (tab.name) {
						case 'snippets':
							return codevault?.total_snippets

						case 'bundles':
							return bundles?.length
					}
				}}
			/>

			<ScreenMetaSlot />

			<div className="snippets-page-header">
				<h1>{currentTab.label}</h1>
			</div>

			<hr className="wp-header-end" />

			{(() => {
				switch (currentTab.name) {
					case 'snippets':
						return (
							<CloudLibrarySnippets
								{...{ codevault, snippetView, setSnippetView, codevaultPage, setCodevaultPage, refreshCodevault }}
								loadingStatus={codevaultStatus}
							/>
						)

					case 'bundles':
						return <CloudLibraryBundles bundles={bundles} loadingStatus={bundlesLoadingStatus} />
				}
			})()}
		</>
	)
}

export const CloudLibrary = () =>
	window.CODE_SNIPPETS?.isCloudConnected
		? <WithRestAPIContext>
			<WithCloudSnippetDownloadsContext>
				<ConnectedCloudLibrary />
			</WithCloudSnippetDownloadsContext>
		</WithRestAPIContext>
		: <CloudConnectPrompt
			title={__('Cloud Library', 'code-snippets')}
			Icon={LibraryIcon}
			description={
				__('Your snippets and bundles saved to Code Snippets Cloud, ready to download to any connected site.', 'code-snippets')
			}
			message={__('Connect to Code Snippets Cloud to use the Cloud Library.', 'code-snippets')}
		/>
