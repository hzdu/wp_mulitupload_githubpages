import React from 'react'
import { __, sprintf } from '@wordpress/i18n'
import { truncateWords } from '../../../utils/text'
import { Button } from '../../common/Button'
import type { ReactNode } from 'react'
import type { CloudBundleSchema } from '../../../types/schema/CloudBundleSchema'

const MAX_WORDS = 30

interface CloudBundleProps {
	bundle: CloudBundleSchema
	onViewSnippets: VoidFunction
}

const CloudBundle: React.FC<CloudBundleProps> = ({ bundle, onViewSnippets }) =>
	<li className="code-snippets-card cloud-bundle">
		<div className="card-inner">
			<h3>{bundle.name}</h3>

			<div className="bundle-meta">
				<span className={`badge small-badge ${bundle.is_public ? 'public' : 'private'}-badge`}>
					{bundle.is_public ? __('Public', 'code-snippets') : __('Private', 'code-snippets')}
				</span>

				<span className="badge small-badge neutral-badge">{
					// translators: %d is the number of snippets in the bundle.
					sprintf(__('%d snippets', 'code-snippets'), bundle.snippets_count)
				}</span>
			</div>

			{bundle.description && 
				<p className="bundle-description">{truncateWords(bundle.description, MAX_WORDS)}</p>}
		</div>

		<footer>
			<Button primary large onClick={onViewSnippets}>{__('View Snippets', 'code-snippets')}</Button>
		</footer>
	</li>

export interface BundlesGridProps {
	bundles: CloudBundleSchema[]
	intro?: ReactNode
	onViewSnippets: (bundle: CloudBundleSchema) => void
}

export const BundlesGrid: React.FC<BundlesGridProps> = ({ bundles, intro, onViewSnippets }) =>
	<>
		{intro ?? <p>
			{__('These are your saved Bundles.', 'code-snippets')} <a
				target="_blank"
				href={`${window.CODE_SNIPPETS?.urls.cloud}/bundles`} rel="noopener noreferrer"
			>
				{__('Manage your bundles in your Cloud account.', 'code-snippets')}
			</a>
		</p>}

		<ul className="code-snippets-cards">
			{bundles.map(bundle =>
				<CloudBundle
					key={bundle.id}
					bundle={bundle}
					onViewSnippets={() => onViewSnippets(bundle)}
				/>)}
		</ul>
	</>
