import classnames from 'classnames'
import React, { useState } from 'react'
import { __ } from '@wordpress/i18n'
import { useRestAPI } from '../../../hooks/useRestAPI'
import { TableNavigation } from '../../common/ListTable/TableNavigation'
import { CloudSnippetCard } from '../../common/cloud/CloudSnippetCard'
import { downloadCloudSnippets } from './downloadCloudSnippets'
import type { CloudSnippetSchema } from '../../../types/schema/CloudSnippetSchema'
import type { ListTableAction } from '../../common/ListTable'
import type { CloudSnippetsSchema } from '../../../types/schema/CloudSnippetsSchema'
import type { Dispatch, ReactNode, SetStateAction } from 'react'

type BulkAction = 'download'

const BULK_ACTIONS: ListTableAction<BulkAction>[] = [
	{ key: 'download', label: __('Download', 'code-snippets') }
]

interface CardGridProps {
	snippets: CloudSnippetSchema[]
	selected: Set<CloudSnippetSchema['id']>
	setSelected: Dispatch<SetStateAction<Set<CloudSnippetSchema['id']>>>
	onDownloaded?: VoidFunction
}

const CardGrid: React.FC<CardGridProps> = ({ snippets, selected, setSelected, onDownloaded }) =>
	0 < snippets.length
		? <ul
			className={classnames('cloud-search-results', 'code-snippets-cards', {
				'has-selection': snippets.some(snippet => selected.has(snippet.id))
			})}
		>
			{snippets.map(snippet =>
				<CloudSnippetCard
					key={snippet.id}
					snippet={snippet}
					isSelected={selected.has(snippet.id)}
					onSnippetDownloaded={onDownloaded}
					onSelectedChange={isSelected => {
						setSelected(previous => {
							const updated = new Set(previous)

							if (isSelected) {
								updated.add(snippet.id)
							} else {
								updated.delete(snippet.id)
							}

							return updated
						})
					}}
				/>)}
		</ul>
		: <p>{__('No snippets in your cloud library yet.', 'code-snippets')}</p>

const getVisibleSelection = (
	selected: Set<CloudSnippetSchema['id']>,
	visible: CloudSnippetSchema[]
): Set<CloudSnippetSchema['id']> =>
	new Set([...selected].filter(id => visible.some(snippet => snippet.id === id)))

export interface CloudLibraryCardsProps {
	snippets: CloudSnippetsSchema
	onDownloaded: () => Promise<void>
	currentPage: number
	totalPages: number | undefined
	setCurrentPage: (page: number) => void
	disabled?: boolean
	extraTableNav?: (which: 'top' | 'bottom') => ReactNode
	endTableNav?: (which: 'top' | 'bottom') => ReactNode
}

export const CloudLibraryCards: React.FC<CloudLibraryCardsProps> = ({
	snippets,
	onDownloaded,
	currentPage,
	totalPages,
	setCurrentPage,
	disabled,
	extraTableNav,
	endTableNav
}) => {
	const { api } = useRestAPI()
	const [selected, setSelected] = useState(() => new Set<CloudSnippetSchema['id']>())
	const visibleSnippetIds = snippets.snippets.map(snippet => snippet.id)

	const handleAction = (action: BulkAction, selectedIds: Set<CloudSnippetSchema['id']>) =>
		downloadCloudSnippets(api, action, selectedIds, onDownloaded)

	return (
		<div className="cloud-library-snippets snippets-list-view">
			<TableNavigation
				totalItems={snippets.total_snippets}
				totalPages={totalPages}
				currentPage={currentPage}
				setCurrentPage={setCurrentPage}
				disabled={disabled}
				selected={getVisibleSelection(selected, snippets.snippets)}
				setSelected={setSelected}
				selectAllKeys={visibleSnippetIds}
				actions={BULK_ACTIONS}
				doAction={handleAction}
				extraTableNav={extraTableNav}
				endTableNav={endTableNav}
			>
				<CardGrid
					snippets={snippets.snippets}
					selected={selected}
					setSelected={setSelected}
					onDownloaded={() => void onDownloaded()}
				/>
			</TableNavigation>
		</div>
	)
}
