import React, { useEffect, useState } from 'react'
import { __ } from '@wordpress/i18n'
import { useFetchData } from '../../../hooks/useFetchData'
import { REST_BASES } from '../../../utils/restAPI'
import { buildAdminUrl, fetchQueryParam, updateQueryParams } from '../../../utils/urls'
import { LoadingStatusNotices } from '../../common/LoadingStatusNotices'
import { BundlesGrid } from './BundlesGrid'
import { TAB_QUERY_PARAM } from './CloudLibrary'
import { CloudLibraryTable } from './CloudLibraryTable'
import type { LoadingStatus} from '../../../hooks/useFetchData'
import type { CloudBundleSchema } from '../../../types/schema/CloudBundleSchema'
import type { CloudSnippetsSchema } from '../../../types/schema/CloudSnippetsSchema'

const BUNDLE_ID_QUERY_PARAM = 'bundle'

interface BundleSnippetsProps {
	bundle: CloudBundleSchema
}

const BundleSnippets: React.FC<BundleSnippetsProps> = ({ bundle }) => {
	const { data: bundleSnippets, refreshData, ...loadingStatus } =
		useFetchData<CloudSnippetsSchema>(`${REST_BASES.cloud.snippets}/bundle/id/${bundle.id}`)

	return (
		<div className="cloud-bundle-snippets-results">
			<h3>
				{__('All snippets in bundle: ', 'code-snippets')}
				<a href={`${window.CODE_SNIPPETS?.urls.cloud}/bundles/${bundle.id}`} target="_blank" rel="noopener noreferrer">
					{bundle.name}
				</a>
			</h3>

			{bundleSnippets
				? <CloudLibraryTable
					snippets={bundleSnippets}
					onDownloaded={refreshData}
				/>
				: <LoadingStatusNotices
					{...loadingStatus}
					errorPrefix={__('Could not fetch snippets from bundle.', 'code-snippets')}
					loadingNotice={__('Loading bundled snippets…', 'code-snippets')}
				/>}
		</div>
	)
}

export interface CloudLibraryBundlesProps {
	bundles: CloudBundleSchema[] | undefined
	loadingStatus: LoadingStatus
}

export const CloudLibraryBundles: React.FC<CloudLibraryBundlesProps> = ({ bundles, loadingStatus }) => {
	const [currentBundle, setCurrentBundle] = useState<CloudBundleSchema>()

	const queryArgBundleId = Number(fetchQueryParam(BUNDLE_ID_QUERY_PARAM) ?? 0)

	useEffect(() => {
		if (bundles && queryArgBundleId && queryArgBundleId !== currentBundle?.id) {
			setCurrentBundle(bundles.find(bundle => bundle.id === queryArgBundleId) ?? currentBundle)
		}
	}, [queryArgBundleId, bundles, currentBundle])

	return currentBundle
		? <>
			<a
				href={buildAdminUrl({}, [TAB_QUERY_PARAM])}
				className="button button-secondary code-snippets-return-link"
				onClick={event => {
					event.preventDefault()
					setCurrentBundle(undefined)
				}}
			>
				{__('Back to bundles', 'code-snippets')}
			</a>

			<BundleSnippets bundle={currentBundle} />
		</>
		: <div className="cloud-bundles">
			{bundles
				? <BundlesGrid
					bundles={bundles}
					onViewSnippets={bundle => {
						updateQueryParams({ [BUNDLE_ID_QUERY_PARAM]: bundle.id.toString() })
						setCurrentBundle(bundle)
					}}
				/>
				: <LoadingStatusNotices
					{...loadingStatus}
					errorPrefix={__('Failed to load bundles.', 'code-snippets')}
					loadingNotice={__('Loading bundles from cloud…', 'code-snippets')}
				/>}
		</div>
}
