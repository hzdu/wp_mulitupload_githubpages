import { REST_BASES } from '../../../utils/restAPI'
import type { RestAPI } from '../../../hooks/useRestAPI'
import type { DownloadSnippetResponse } from '../../common/cloud/CloudSnippetDownloadButton'
import type { CloudSnippetSchema } from '../../../types/schema/CloudSnippetSchema'

/**
 * Download the selected cloud library snippets to the site, then refresh the
 * current view. Shared by the card and table views of the cloud library.
 */
export const downloadCloudSnippets = async (
	api: RestAPI,
	action: string,
	selectedIds: Set<CloudSnippetSchema['id']>,
	onDownload: () => Promise<void>
): Promise<void> => {
	if ('download' !== action) {
		throw new Error(`Unknown action: ${action}`)
	}

	await Promise.allSettled(Array.from(selectedIds.values()).map(selectedId =>
		api.post<DownloadSnippetResponse>(`${REST_BASES.cloud.snippets}/${selectedId}/download`)))

	await onDownload()
}
