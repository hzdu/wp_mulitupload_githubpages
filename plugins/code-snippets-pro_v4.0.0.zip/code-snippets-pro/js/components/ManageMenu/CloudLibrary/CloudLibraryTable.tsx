import React, { useMemo, useState } from 'react'
import { __ } from '@wordpress/i18n'
import { useRestAPI } from '../../../hooks/useRestAPI'
import { ListTable, PartialDataListTable, sortTableItems } from '../../common/ListTable'
import { cloudLibraryColumns } from './CloudLibraryColumns'
import { downloadCloudSnippets } from './downloadCloudSnippets'
import type { CloudSnippetSchema } from '../../../types/schema/CloudSnippetSchema'
import type { ListTableAction, ListTableColumn, ListTableProps, ListTableSortDirection } from '../../common/ListTable'
import type { CloudSnippetsSchema } from '../../../types/schema/CloudSnippetsSchema'
import type { ReactNode } from 'react'

type BulkAction = 'download'

const BULK_ACTIONS: ListTableAction<BulkAction>[] = [
	{ key: 'download', label: __('Download', 'code-snippets') }
]

export interface CloudLibraryTableProps {
	snippets: CloudSnippetsSchema
	onDownloaded: () => Promise<void>
	currentPage?: number
	totalPages?: number
	totalItems?: number
	setCurrentPage?: (page: number) => void
	extraTableNav?: (which: 'top' | 'bottom') => ReactNode
	endTableNav?: (which: 'top' | 'bottom') => ReactNode
}

export const CloudLibraryTable: React.FC<CloudLibraryTableProps> = ({
	snippets,
	totalItems,
	onDownloaded,
	currentPage,
	totalPages,
	setCurrentPage,
	extraTableNav,
	endTableNav
}) => {
	const { api } = useRestAPI()

	const handleAction = (action: BulkAction, selected: Set<CloudSnippetSchema['id']>) =>
		downloadCloudSnippets(api, action, selected, onDownloaded)

	const [sortColumn, setSortColumn] = useState<ListTableColumn<CloudSnippetSchema>>()
	const [sortDirection, setSortDirection] = useState<ListTableSortDirection>('asc')

	const sortedItems: CloudSnippetSchema[] = useMemo(
		() => sortTableItems(snippets.snippets, sortColumn, sortDirection),
		[snippets.snippets, sortColumn, sortDirection])

	const listTableProps: ListTableProps<CloudSnippetSchema, number, BulkAction> = {
		fixed: true,
		striped: true,
		items: snippets.snippets,
		columns: cloudLibraryColumns(() => void onDownloaded()),
		actions: BULK_ACTIONS,
		doAction: handleAction,
		getKey: snippet => snippet.id,
		extraTableNav,
		endTableNav
	}

	return (
		<div className="cloud-library-snippets snippets-list-view">
			{currentPage && setCurrentPage && totalPages && totalItems
				? <PartialDataListTable
					visibleItems={sortedItems}
					{...listTableProps}
					{...{
						currentPage,
						setCurrentPage,
						totalItems,
						totalPages,
						sortColumn,
						sortDirection,
						setSortColumn,
						setSortDirection
					}}
				/>
				: <ListTable {...listTableProps} />}
		</div>
	)
}
