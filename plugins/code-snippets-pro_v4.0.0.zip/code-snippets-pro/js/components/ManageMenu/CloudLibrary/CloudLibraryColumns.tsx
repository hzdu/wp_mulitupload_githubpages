import React, { Fragment, useState } from 'react'
import { __ } from '@wordpress/i18n'
import { humanTimeDiff } from '@wordpress/date'
import { CloudSyncState, getCloudSnippetSyncState } from '../../../types/CloudSyncState'
import { getSnippetDisplayName, getSnippetEditUrl, getSnippetType } from '../../../utils/snippets/snippets'
import { stripTags, truncateChars } from '../../../utils/text'
import { Badge } from '../../common/Badge'
import { Button } from '../../common/Button'
import { CloudSnippetDownloadButton } from '../../common/cloud/CloudSnippetDownloadButton'
import { CloudStatusBadge } from '../../common/cloud/CloudStatusBadge'
import { CloudAvailableIcon } from '../../common/icons/cloud/CloudAvailableIcon'
import { CloudErrorIcon } from '../../common/icons/cloud/CloudErrorIcon'
import { CloudSyncedIcon } from '../../common/icons/cloud/CloudSyncedIcon'
import { CloudUpdateIcon } from '../../common/icons/cloud/CloudUpdateIcon'
import { CloudSnippetPreviewModal } from '../../common/snippets/SnippetPreviewModal'
import { Tooltip } from '../../common/Tooltip'
import type { ListTableColumn } from '../../common/ListTable'
import type { ReactNode } from 'react'
import type { CloudSnippetSchema } from '../../../types/schema/CloudSnippetSchema'

interface ColumnProps {
	snippet: CloudSnippetSchema
}

const CloudSyncStateIcons: Record<CloudSyncState, ReactNode> = {
	[CloudSyncState.Unsynced]: <CloudAvailableIcon />,
	[CloudSyncState.Synced]: <CloudSyncedIcon />,
	[CloudSyncState.UpdateAvailable]: <CloudUpdateIcon />,
	[CloudSyncState.Errored]: <CloudErrorIcon />
}

const CloudSyncStateLabels: Record<CloudSyncState, string> = {
	[CloudSyncState.Unsynced]: __('Available in Cloud', 'code-snippets'),
	[CloudSyncState.Synced]: __('Synced to Cloud', 'code-snippets'),
	[CloudSyncState.UpdateAvailable]: __('Update available', 'code-snippets'),
	[CloudSyncState.Errored]: __('Sync error', 'code-snippets')
}

const StateColumn: React.FC<ColumnProps> = ({ snippet }) => {
	const state = getCloudSnippetSyncState(snippet)
	const label = CloudSyncStateLabels[state]

	const icon =
		<span className="cloud-sync-indicator" role="img" aria-label={label}>
			{CloudSyncStateIcons[state]}
		</span>

	return (
		<Tooltip inline label={label} icon={icon}>
			{label}
		</Tooltip>
	)
}

const NameColumn: React.FC<ColumnProps> = ({ snippet }) =>
	<strong>{snippet.local_id
		? <a href={getSnippetEditUrl({ id: snippet.local_id })}>
			{snippet.name}
		</a>
		: snippet.name}
	</strong>

const TagsColumn: React.FC<ColumnProps> = ({ snippet }) =>
	snippet.tags.map((tag, index) =>
		<Fragment key={tag}>{tag}{index < snippet.tags.length - 1 ? ', ' : ''}</Fragment>)

const DateColumn: React.FC<ColumnProps> = ({ snippet }) =>
	snippet.updated
		? <span className="modified-column-content" title={snippet.updated}>
			<time dateTime={snippet.updated}>
				{humanTimeDiff(snippet.updated, undefined)}
			</time>
		</span>
		: <>&#8212;</>

interface ActionsColumnProps {
	snippet: CloudSnippetSchema
	onDownloaded: VoidFunction
}

const ActionsColumn: React.FC<ActionsColumnProps> = ({ snippet, onDownloaded }) => {
	const [isPreviewOpen, setIsPreviewOpen] = useState(false)

	return (
		<div className="cloud-snippet-action-buttons">
			<Button secondary onClick={() => setIsPreviewOpen(true)}>
				{__('Preview', 'code-snippets')}
			</Button>

			<CloudSnippetDownloadButton snippet={snippet} onDownloaded={onDownloaded} />

			{isPreviewOpen && (
				<CloudSnippetPreviewModal snippet={snippet} setIsOpen={setIsPreviewOpen} onDownloaded={onDownloaded} />)}
		</div>
	)
}

const BASE_COLUMNS: ListTableColumn<CloudSnippetSchema>[] = [
	{
		id: 'state',
		title: <CloudAvailableIcon aria-labelledby={__('Sync Status', 'code-snippets')} />,
		sortedValue: snippet => getCloudSnippetSyncState(snippet),
		render: snippet => <StateColumn snippet={snippet} />
	},
	{
		id: 'name',
		title: __('Snippet Name', 'code-snippets'),
		isPrimary: true,
		sortedValue: snippet => getSnippetDisplayName(snippet).toLowerCase(),
		render: snippet => <NameColumn snippet={snippet} />
	},
	{
		id: 'type',
		title: __('Type', 'code-snippets'),
		sortedValue: snippet => getSnippetType(snippet),
		render: snippet => <Badge name={getSnippetType(snippet)} />
	},
	{
		id: 'status',
		title: __('Status', 'code-snippets'),
		sortedValue: snippet => snippet.status,
		render: snippet => <CloudStatusBadge status={snippet.status} />
	},
	{
		id: 'desc',
		title: __('Description', 'code-snippets'),
		render: snippet =>
			<div className="snippet-description-content">
				{truncateChars(stripTags(snippet.description))}
			</div>
	},
	{
		id: 'tags',
		title: __('Tags', 'code-snippets'),
		sortedValue: snippet =>
			snippet.tags.toSorted((a, b) => a.localeCompare(b)).join(', '),
		render: snippet => <TagsColumn snippet={snippet} />
	},
	{
		id: 'date',
		title: __('Updated', 'code-snippets'),
		sortedValue: snippet => snippet.updated ? new Date(snippet.updated).toISOString() : '',
		render: snippet => <DateColumn snippet={snippet} />
	}
]

export const cloudLibraryColumns = (
	onDownloaded: VoidFunction
): ListTableColumn<CloudSnippetSchema>[] => [
	...BASE_COLUMNS,
	{
		id: 'actions',
		title: <span className="screen-reader-text">{__('Actions', 'code-snippets')}</span>,
		render: snippet => <ActionsColumn snippet={snippet} onDownloaded={onDownloaded} />
	}
]
