import React from 'react'
import { __, _n, sprintf } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { Badge } from '../../common/Badge'
import { Button } from '../../common/Button'
import { useAiAgentContext } from './AiAgentContext'
import { languageToSnippetType } from './types'
import type { AiPlan } from './types'

interface PlanCardProps {
	plan: AiPlan
	onRefine: () => void
}

export const PlanCard: React.FC<PlanCardProps> = ({ plan, onRefine }) => {
	const { accept, isSubmitting } = useAiAgentContext()

	const isBundle = 'bundle' === plan.type
	const badge = isBundle
		? sprintf(
			/* translators: %d: number of snippets in the bundle. */
			_n('Bundle · %d snippet', 'Bundle · %d snippets', plan.parts.length, 'code-snippets'),
			plan.parts.length
		)
		: __('Single snippet', 'code-snippets')

	return (
		<div className="ai-agent-plan">
			<div className="ai-agent-plan__header">
				<h3 className="ai-agent-plan__title">{plan.title}</h3>
				<span className={`ai-agent-plan__badge ${isBundle ? 'is-bundle' : 'is-snippet'}`}>{badge}</span>
			</div>

			<p className="ai-agent-plan__overview">{plan.summary}</p>

			<h3 className="ai-agent-plan__parts-heading">
				{__('What will be created', 'code-snippets')}
			</h3>

			<ul className="ai-agent-plan__parts">
				{plan.parts.map((part, index) =>
					<li key={`${part.language}-${index}`} className="ai-agent-plan__part">
						<Badge name={languageToSnippetType(part.language)} small />
						<span className="ai-agent-plan__part-name">{part.name}</span>
						<p className="ai-agent-plan__part-desc">{part.description}</p>
					</li>)}
			</ul>

			<div className="ai-agent-plan__actions">
				<Button
					primary
					type="button"
					disabled={isSubmitting}
					aria-label={__('Accept & create', 'code-snippets')}
					aria-busy={isSubmitting}
					onClick={() => void accept()}
				>
					{isSubmitting ? <Spinner aria-hidden="true" /> : __('Accept & create', 'code-snippets')}
				</Button>

				<Button secondary type="button" disabled={isSubmitting} onClick={onRefine}>
					{__('Refine plan', 'code-snippets')}
				</Button>
			</div>
		</div>
	)
}
