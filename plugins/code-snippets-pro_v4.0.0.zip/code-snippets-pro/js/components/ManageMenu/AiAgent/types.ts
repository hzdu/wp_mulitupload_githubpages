import type { SnippetScope, SnippetType } from '../../../types/Snippet'

export type AiLanguage = 'php' | 'javascript' | 'css' | 'html'

/**
 * Map an AI plan language to the snippet type used for badge colours and Prism
 * highlighting (the all-snippets page uses `js`, not `javascript`).
 */
export const languageToSnippetType = (language: AiLanguage): SnippetType =>
	'javascript' === language ? 'js' : language

const LANGUAGES: readonly AiLanguage[] = ['php', 'javascript', 'css', 'html']

export const isAiLanguage = (value: unknown): value is AiLanguage =>
	LANGUAGES.includes(<AiLanguage>value)

/**
 * The default snippet scope for each language, so downloaded snippets are saved
 * as the correct type (CSS/JS/HTML) rather than defaulting to a PHP scope.
 */
export const scopeForLanguage = (language: AiLanguage): SnippetScope => {
	switch (language) {
		case 'css':
			return 'site-css'
		case 'javascript':
			return 'site-footer-js'
		case 'html':
			return 'content'
		default:
			return 'global'
	}
}

export type AiGenerationStatus = 'planning' | 'plan_ready' | 'generating' | 'completed' | 'failed' | 'editing'

export interface AiPlanPart {
	language: AiLanguage
	name: string
	description: string
}

export interface AiPlan {
	type: 'snippet' | 'bundle'
	title: string
	summary: string
	parts: AiPlanPart[]
}

export interface AiHistoryEntry {
	role: 'user' | 'assistant'
	content: string
}

export interface AiResultSnippet {
	cloud_id: number
	name: string
	/** Optional: the cloud has been seen to omit this on created snippets. */
	language?: AiLanguage | null
	code?: string
}

export interface AiResultBundle {
	cloud_id: number
	name: string
	snippets: AiResultSnippet[]
}

export interface AiResult {
	type: 'snippet' | 'bundle'
	snippet?: AiResultSnippet
	bundle?: AiResultBundle
}

/**
 * The language of a created snippet. Result snippets have been seen to come
 * back from the cloud with no language, so fall back to the plan part of the
 * same name. Callers must handle `undefined` — rendering it anyway produces a
 * blank badge and saves the snippet under the wrong type.
 */
export const resolveSnippetLanguage = (
	snippet: AiResultSnippet,
	plan?: AiPlan | null
): AiLanguage | undefined => {
	if (isAiLanguage(snippet.language)) {
		return snippet.language
	}

	const part = plan?.parts.find(candidate => candidate.name === snippet.name)

	return part && isAiLanguage(part.language) ? part.language : undefined
}

/**
 * Why a generation ended in `failed`. The cloud sets this on every failure and
 * leaves it null on every other status, so it is authoritative where present.
 * Only `error` can be resolved by retrying; `question` and `context` are the
 * agent asking for something, and `cancelled` is the user's own Stop. An
 * unrecognised or absent value is treated as `error`.
 */
export type AiFailureReason = 'question' | 'refused' | 'cancelled' | 'context' | 'error'

/**
 * The agent asking to widen the context before it plans. Nothing wider leaves
 * the site until the user answers this.
 */
export interface AiContextRequest {
	level: AiContextLevel
	reason: string
}

export interface AiGeneration {
	id: number
	status: AiGenerationStatus
	prompt: string
	plan: AiPlan | null
	history: AiHistoryEntry[]
	result: AiResult | null
	error: string | null
	failure_reason?: AiFailureReason | null
	context_request?: AiContextRequest | null
	created_at: string
	updated_at: string
}

export interface AiGenerationListItem {
	id: number
	status: AiGenerationStatus
	title: string
	created_at: string
	updated_at: string
}

export interface AiGenerationList {
	data: AiGenerationListItem[]
	meta?: {
		current_page: number
		last_page: number
		total: number
	}
}

/**
 * Maximum number of history messages (user + assistant) allowed in a single
 * conversation before the prompt box is disabled. Mirrors the cloud limit.
 */
export const MESSAGE_LIMIT_PER_CONVERSATION = 200

export const BUSY_STATUSES: readonly AiGenerationStatus[] = ['planning', 'generating', 'editing']

export const isBusyStatus = (status: AiGenerationStatus): boolean =>
	BUSY_STATUSES.includes(status)

/**
 * Context level sent with a generation. Ported from the assistant drawer's
 * L1/L2/L3 pills, remapped for generation:
 *  - L1: prompt only
 *  - L2: + the user's existing snippet library (names/types/scopes)
 *  - L3: + site environment (WP/PHP, theme, active plugins)
 */
export type AiContextLevel = 'L1' | 'L2' | 'L3'

export interface AiLibrarySnippet {
	id: number
	name: string
	type: string
	scope: string
}

export interface AiAgentContext {
	level: AiContextLevel
	library?: AiLibrarySnippet[]
	siteContext?: unknown
}
