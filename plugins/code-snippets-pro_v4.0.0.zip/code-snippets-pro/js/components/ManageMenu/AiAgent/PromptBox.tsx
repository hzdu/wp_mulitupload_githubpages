import React, { useRef } from 'react'
import { __ } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { Button } from '../../common/Button'

interface PromptBoxProps {
	value: string
	onChange: (value: string) => void
	onSubmit: () => void
	submitLabel: string
	placeholder?: string
	disabled?: boolean
	busy?: boolean
	submitDisabled?: boolean
	/**
	 * When set, the submit button becomes a Stop control for the duration of the
	 * request: one button, two states, so the composer keeps a single action.
	 */
	onStop?: () => void
	id?: string
	inputRef?: React.RefObject<HTMLTextAreaElement>
}

export const PromptBox: React.FC<PromptBoxProps> = ({
	value,
	onChange,
	onSubmit,
	submitLabel,
	placeholder,
	disabled = false,
	busy = false,
	submitDisabled = false,
	onStop,
	id = 'ai-agent-prompt',
	inputRef
}) => {
	const internalRef = useRef<HTMLTextAreaElement>(null)
	const textareaRef = inputRef ?? internalRef

	const canSubmit = !disabled && !busy && !submitDisabled && '' !== value.trim()
	const showStop = Boolean(onStop) && busy

	const insertNewline = () => {
		const element = textareaRef.current

		if (!element) {
			onChange(`${value}\n`)
			return
		}

		const start = element.selectionStart
		const end = element.selectionEnd
		onChange(`${value.slice(0, start)}\n${value.slice(end)}`)

		requestAnimationFrame(() => {
			element.selectionStart = start + 1
			element.selectionEnd = start + 1
		})
	}

	const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
		if ('Enter' !== event.key) {
			return
		}

		// Shift+Enter inserts a newline natively; Ctrl/⌘+Enter we insert manually.
		if (event.shiftKey) {
			return
		}

		if (event.ctrlKey || event.metaKey) {
			event.preventDefault()
			insertNewline()
			return
		}

		event.preventDefault()

		if (canSubmit) {
			onSubmit()
		}
	}

	return (
		<div className="ai-agent-prompt">
			<textarea
				ref={textareaRef}
				id={id}
				name={id}
				className="ai-agent-prompt__input"
				value={value}
				onChange={event => onChange(event.target.value)}
				onKeyDown={handleKeyDown}
				placeholder={placeholder ?? __('Describe what you want to build…', 'code-snippets')}
				disabled={disabled}
				rows={4}
				aria-label={__('Prompt', 'code-snippets')}
				aria-describedby={`${id}-hint`}
			/>

			<div className="ai-agent-prompt__footer">
				<span id={`${id}-hint`} className="ai-agent-prompt__hint">
					{__('Enter to send · Shift/Ctrl/⌘+Enter for a new line', 'code-snippets')}
				</span>

				{showStop
					? <Button
						secondary
						type="button"
						aria-label={__('Stop', 'code-snippets')}
						onClick={onStop}
					>
						{__('Stop', 'code-snippets')}
					</Button>
					: <Button
						primary
						type="button"
						disabled={!canSubmit}
						aria-label={submitLabel}
						aria-busy={busy}
						onClick={onSubmit}
					>
						{busy ? <Spinner aria-hidden="true" /> : submitLabel}
					</Button>}
			</div>
		</div>
	)
}
