/* eslint-disable max-lines-per-function */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { isAbortError, unpackErrorResponse } from '../../../utils/errors'
import { useRestAPI } from '../../../hooks/useRestAPI'
import { REST_BASES } from '../../../utils/restAPI'
import { getSnippetDisplayName, getSnippetType } from '../../../utils/snippets/snippets'
import { useAiAgentClient } from './aiAgentClient'
import { MESSAGE_LIMIT_PER_CONVERSATION, isBusyStatus } from './types'
import type { AiAgentContext, AiContextLevel, AiGeneration, AiGenerationListItem, AiGenerationStatus, AiLibrarySnippet } from './types'

const POLL_INTERVAL_MS = 1500

const siteContextEndpoint = (): string =>
	REST_BASES.snippets.replace(/\/snippets$/, '/cloud/ai/site-context')

/**
 * Maximum polls (~2 minutes at the poll interval) before a busy generation is
 * treated as timed out, surfacing a retry rather than spinning forever.
 */
const MAX_POLLS = 80

/**
 * Number of consecutive poll failures tolerated before surfacing an error.
 * A single transient failure should not flash an error mid-generation.
 */
const MAX_POLL_FAILURES = 3

export interface AiAgentState {
	generation: AiGeneration | undefined
	conversations: readonly AiGenerationListItem[]
	conversationsLoaded: boolean
	status: AiGenerationStatus | undefined
	isBusy: boolean
	isSubmitting: boolean
	isLoadingConversation: boolean
	pollTimedOut: boolean
	isStopped: boolean
	actionError: string | undefined
	pendingPrompt: string | undefined
	messageCount: number
	limitReached: boolean
	submitPrompt: (prompt: string) => Promise<void>
	refine: (message: string) => Promise<void>
	accept: () => Promise<void>
	retry: () => Promise<void>
	editSnippets: (snippetIds: number[], message: string) => Promise<void>
	shareContext: () => Promise<void>
	declineContext: () => Promise<void>
	stop: () => void
	resume: () => void
	newConversation: () => void
	openConversation: (id: number) => Promise<void>
	deleteConversation: (id: number) => Promise<void>
	refreshConversations: () => Promise<void>
}

export const useAiAgent = (): AiAgentState => {
	const client = useAiAgentClient()
	const { api } = useRestAPI()

	const [generation, setGeneration] = useState<AiGeneration>()
	const [conversations, setConversations] = useState<AiGenerationListItem[]>([])
	const [conversationsLoaded, setConversationsLoaded] = useState(false)
	const [isSubmitting, setIsSubmitting] = useState(false)
	const [isLoadingConversation, setIsLoadingConversation] = useState(false)
	const [pollTimedOut, setPollTimedOut] = useState(false)
	const [isStopped, setIsStopped] = useState(false)
	const [actionError, setActionError] = useState<string>()
	const [pendingPrompt, setPendingPrompt] = useState<string>()

	const pollCount = useRef(0)
	const pollFailures = useRef(0)
	const abortController = useRef<AbortController>()

	// Context breadth is the cloud's decision: conversations start at L1 and only
	// widen when the agent asks and the user agrees, so there is no picker.
	const [contextLevel, setContextLevel] = useState<AiContextLevel>('L1')
	const siteContext = useRef<unknown>(null)

	const library = useMemo<AiLibrarySnippet[]>(() => {
		const list = window.CODE_SNIPPETS_MANAGE?.snippetsList ?? []
		return list
			.filter(snippet => !snippet.trashed)
			.map(snippet => ({
				id: snippet.id,
				name: getSnippetDisplayName(snippet),
				type: getSnippetType(snippet),
				scope: snippet.scope
			}))
	}, [])

	// Fetched only once the user has agreed to share it, and cached for the rest
	// of the page: nothing about the site environment leaves before then.
	const buildContextFor = useCallback(async (level: AiContextLevel): Promise<AiAgentContext> => {
		if ('L1' === level) {
			return { level }
		}

		if ('L2' === level) {
			return { level, library }
		}

		// Through the shared REST instance, not a bare axios call: the nonce is
		// applied by an interceptor registered on that instance, and without it
		// WordPress rejects the request as unauthenticated. That failure used to
		// be swallowed here, so the agent sent siteContext: null and the cloud
		// saw an L2 payload answering an L3 request.
		siteContext.current ??= await api.get<{ data?: unknown }>(siteContextEndpoint())
			.then(response => response.data ?? null)
			.catch((error: unknown) => {
				// Still non-fatal — the user gets a plan from their library
				// rather than nothing — but no longer silent.
				console.error('Could not collect site context for the AI Agent', error)
				return null
			})

		return { level, library, siteContext: siteContext.current }
	}, [api, library])

	const status = generation?.status
	const isBusy = status ? isBusyStatus(status) : false
	const messageCount = generation?.history.length ?? 0
	const limitReached = messageCount >= MESSAGE_LIMIT_PER_CONVERSATION

	const refreshConversations = useCallback(async (): Promise<void> => {
		try {
			const list = await client.list()
			setConversations(list.data)
		} catch (error) {
			console.error('Failed to load AI conversations', error)
		} finally {
			setConversationsLoaded(true)
		}
	}, [client])

	useEffect(() => {
		void refreshConversations()
	}, [refreshConversations])

	const beginGeneration = useCallback((fresh: AiGeneration) => {
		pollCount.current = 0
		pollFailures.current = 0
		setPollTimedOut(false)
		setActionError(undefined)
		setGeneration(fresh)
	}, [])

	const runAction = useCallback(async (
		action: (signal: AbortSignal) => Promise<AiGeneration>,
		optimisticMessage?: string
	): Promise<void> => {
		abortController.current?.abort()
		const controller = new AbortController()
		abortController.current = controller

		setIsSubmitting(true)
		setIsStopped(false)
		setActionError(undefined)
		setPendingPrompt(optimisticMessage)

		try {
			beginGeneration(await action(controller.signal))
		} catch (error) {
			// A stopped request already left the UI idle; only real failures show.
			if (!isAbortError(error)) {
				setActionError(unpackErrorResponse(error))
			}
		} finally {
			if (abortController.current === controller) {
				abortController.current = undefined
			}

			setIsSubmitting(false)
			setPendingPrompt(undefined)
		}
	}, [beginGeneration])

	/**
	 * Stop the current generation. Once the cloud has a row to act on this is a
	 * real cancel — work not yet done is discarded and `retry` resumes it. Before
	 * then there is nothing to cancel, so aborting the in-flight request and
	 * halting polling is the whole of it, and `resume` picks the thread back up.
	 */
	const stop = useCallback((): void => {
		abortController.current?.abort()
		abortController.current = undefined
		setPendingPrompt(undefined)
		setIsSubmitting(false)

		if (!generation || !isBusyStatus(generation.status)) {
			setIsStopped(true)
			return
		}

		client.cancel(generation.id)
			.then(setGeneration)
			.catch(() => setIsStopped(true))
	}, [client, generation])

	const resume = useCallback((): void => {
		pollCount.current = 0
		pollFailures.current = 0
		setPollTimedOut(false)
		setIsStopped(false)
	}, [])

	const submitPrompt = useCallback(async (prompt: string): Promise<void> => {
		const context = await buildContextFor(contextLevel)
		await runAction(signal => client.create(prompt, context, signal), prompt)
		void refreshConversations()
	}, [client, contextLevel, refreshConversations, runAction, buildContextFor])

	const refine = useCallback(async (message: string): Promise<void> => {
		if (generation) {
			const context = await buildContextFor(contextLevel)
			await runAction(signal => client.refine(generation.id, message, context, signal), message)
		}
	}, [client, contextLevel, generation, runAction, buildContextFor])

	const accept = useCallback(async (): Promise<void> => {
		if (generation) {
			// Show the building state immediately while the request is in flight.
			setGeneration({ ...generation, status: 'generating' })
			await runAction(signal => client.accept(generation.id, signal))
		}
	}, [client, generation, runAction])

	const retry = useCallback(async (): Promise<void> => {
		if (generation) {
			await runAction(signal => client.retry(generation.id, signal))
		}
	}, [client, generation, runAction])

	const editSnippets = useCallback(async (snippetIds: number[], message: string): Promise<void> => {
		if (generation && snippetIds.length) {
			// Show the updating state immediately while the request is in flight.
			setGeneration({ ...generation, status: 'editing' })
			const context = await buildContextFor(contextLevel)
			await runAction(signal => client.editSnippets(generation.id, snippetIds, message, context, signal))
		}
	}, [client, contextLevel, generation, runAction, buildContextFor])

	/**
	 * Answer the agent's outstanding request to widen the context. Agreeing sends
	 * the payload at the level it asked for and keeps the conversation there;
	 * declining resumes planning with what the cloud already holds.
	 */
	const answerContextRequest = useCallback(async (agree: boolean): Promise<void> => {
		const request = generation?.context_request

		if (!generation || !request) {
			return
		}

		const context = agree ? await buildContextFor(request.level) : undefined

		if (agree) {
			setContextLevel(request.level)
		}

		await runAction(signal => client.provideContext(generation.id, context, signal))
	}, [client, generation, runAction, buildContextFor])

	const shareContext = useCallback((): Promise<void> => answerContextRequest(true), [answerContextRequest])

	const declineContext = useCallback((): Promise<void> => answerContextRequest(false), [answerContextRequest])

	const newConversation = useCallback((): void => {
		abortController.current?.abort()
		abortController.current = undefined
		pollCount.current = 0
		setPollTimedOut(false)
		setIsStopped(false)
		setActionError(undefined)
		setGeneration(undefined)
		setContextLevel('L1')
	}, [])

	const openConversation = useCallback(async (id: number): Promise<void> => {
		setIsLoadingConversation(true)

		// Consent does not carry across conversations: this one starts at L1 again
		// and the cloud re-asks if it needs more. The context already agreed for
		// the row is stored cloud-side, so nothing it was given is lost.
		setContextLevel('L1')

		try {
			await runAction(() => client.get(id))
		} finally {
			setIsLoadingConversation(false)
		}
	}, [client, runAction])

	const deleteConversation = useCallback(async (id: number): Promise<void> => {
		try {
			await client.remove(id)
			setGeneration(current => current?.id === id ? undefined : current)
			void refreshConversations()
		} catch (error) {
			setActionError(unpackErrorResponse(error))
		}
	}, [client, refreshConversations])

	useEffect(() => {
		if (!generation || !isBusy || pollTimedOut || isSubmitting || isStopped) {
			return
		}

		const { id } = generation

		const interval = setInterval(() => {
			if (pollCount.current >= MAX_POLLS) {
				setPollTimedOut(true)
				return
			}

			pollCount.current += 1

			client.get(id)
				.then(fresh => {
					// A successful poll clears any transient error from earlier polls.
					pollFailures.current = 0
					setActionError(undefined)
					setPollTimedOut(false)
					setGeneration(fresh)

					if (!isBusyStatus(fresh.status)) {
						void refreshConversations()
					}
				})
				.catch((error: unknown) => {
					pollFailures.current += 1

					// Only surface an error once the stream has genuinely stopped.
					if (pollFailures.current >= MAX_POLL_FAILURES) {
						setActionError(unpackErrorResponse(error))
						setPollTimedOut(true)
					}
				})
		}, POLL_INTERVAL_MS)

		return () => clearInterval(interval)
	}, [generation, isBusy, pollTimedOut, isSubmitting, isStopped, client, refreshConversations])

	return {
		generation,
		conversations,
		conversationsLoaded,
		status,
		isBusy,
		isSubmitting,
		isLoadingConversation,
		pollTimedOut,
		isStopped,
		actionError,
		pendingPrompt,
		messageCount,
		limitReached,
		submitPrompt,
		refine,
		accept,
		retry,
		editSnippets,
		shareContext,
		declineContext,
		stop,
		resume,
		newConversation,
		openConversation,
		deleteConversation,
		refreshConversations
	}
}
