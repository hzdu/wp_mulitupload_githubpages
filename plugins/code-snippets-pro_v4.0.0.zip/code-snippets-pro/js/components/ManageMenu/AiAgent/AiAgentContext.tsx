import React, { useState } from 'react'
import { createContextHook } from '../../../utils/bootstrap'
import { useAiAgent } from './useAiAgent'
import type { AiAgentState } from './useAiAgent'
import type { PropsWithChildren } from 'react'

export interface AiAgentContextValue extends AiAgentState {
	/**
	 * Whether the result card's snippet-edit mode is open. The main composer and
	 * the edit composer are separate inputs in the same view, so this is shared
	 * to keep exactly one of them live at a time.
	 */
	isEditingSnippets: boolean
	setEditingSnippets: (editing: boolean) => void
}

const [Context, useAiAgentContext] = createContextHook<AiAgentContextValue>('useAiAgentContext')

export const WithAiAgentContext: React.FC<PropsWithChildren> = ({ children }) => {
	const state = useAiAgent()
	const [isEditingSnippets, setEditingSnippets] = useState(false)
	const value: AiAgentContextValue = { ...state, isEditingSnippets, setEditingSnippets }

	return <Context.Provider value={value}>{children}</Context.Provider>
}

export { useAiAgentContext }
