import { useCallback, useEffect, useState } from 'react'
import { isAxiosError } from 'axios'
import { useRestAPI } from '../../../hooks/useRestAPI'
import { useSnippetsAPI } from '../../../hooks/useSnippetsAPI'
import { unpackErrorResponse } from '../../../utils/errors'
import { REST_BASES } from '../../../utils/restAPI'
import { getSnippetType } from '../../../utils/snippets/snippets'
import { languageToSnippetType, resolveSnippetLanguage, scopeForLanguage } from './types'
import type { AiLanguage, AiPlan, AiResult, AiResultSnippet } from './types'
import type { DownloadSnippetResponse } from '../../common/cloud/CloudSnippetDownloadButton'

export type DownloadStatus = 'downloading' | 'checking' | 'done' | 'error' | 'deleted'

const HTTP_NOT_FOUND = 404

const isNotFound = (error: unknown): boolean =>
	isAxiosError(error) && HTTP_NOT_FOUND === error.response?.status

export interface DownloadItem {
	cloudId: number
	name: string
	language: AiLanguage | undefined
	localId?: number
	status: DownloadStatus
	error?: string
}

export interface AiAgentDownload {
	items: readonly DownloadItem[]
	isDownloading: boolean
	retryDownload: () => void
}

interface SyncRecord {
	localId: number
	code: string
}

type SyncMap = Record<number, SyncRecord | undefined>

const STORAGE_PREFIX = 'cs-ai-agent-sync:'

/**
 * The starting row state for a sync pass: snippets already recorded as synced
 * are verified against the site below, so they start in a checking state.
 */
const initialItems = (
	snippets: readonly AiResultSnippet[],
	synced: SyncMap,
	plan?: AiPlan | null
): DownloadItem[] =>
	snippets.map(snippet => ({
		cloudId: snippet.cloud_id,
		name: snippet.name,
		language: resolveSnippetLanguage(snippet, plan),
		localId: synced[snippet.cloud_id]?.localId,
		status: synced[snippet.cloud_id] ? 'checking' : 'downloading'
	}))

const collectSnippets = (result: AiResult): AiResultSnippet[] =>
	'bundle' === result.type
		? result.bundle?.snippets ?? []
		: result.snippet ? [result.snippet] : []

/**
 * Reads the record of which of a generation's snippets have already been synced
 * to this site. Persisted so re-opening a past conversation does not create
 * duplicate local snippets.
 */
const loadSync = (generationId: number): SyncMap => {
	try {
		const raw = window.localStorage.getItem(`${STORAGE_PREFIX}${generationId}`)
		return raw ? <SyncMap>JSON.parse(raw) : {}
	} catch {
		return {}
	}
}

const saveSync = (generationId: number, map: SyncMap): void => {
	try {
		window.localStorage.setItem(`${STORAGE_PREFIX}${generationId}`, JSON.stringify(map))
	} catch {
		// Ignore storage failures; sync state is a convenience, not critical.
	}
}

/**
 * Keeps the site in sync with a completed generation's snippets. Each snippet is
 * pulled onto the site once (created inactive); the local↔cloud mapping is
 * remembered so viewing the conversation again never re-downloads. When a
 * snippet's code later changes (after an edit) the existing local snippet is
 * updated in place — never duplicated.
 */
export const useAiAgentDownload = (
	generationId: number | undefined,
	result: AiResult | null,
	plan?: AiPlan | null
): AiAgentDownload => {
	const { api } = useRestAPI()
	const snippetsAPI = useSnippetsAPI()
	const [items, setItems] = useState<DownloadItem[]>([])

	const patch = (cloudId: number, changes: Partial<DownloadItem>) =>
		setItems(current => current.map(item =>
			item.cloudId === cloudId ? { ...item, ...changes } : item))

	// Downloaded snippets can arrive with a PHP scope regardless of language;
	// correct the scope so the snippet is saved as its proper type.
	const ensureCorrectType = useCallback(async (localId: number, language: AiLanguage): Promise<void> => {
		const local = await snippetsAPI.fetch(localId, false)

		if (getSnippetType(local) !== languageToSnippetType(language)) {
			await snippetsAPI.update({ ...local, scope: scopeForLanguage(language) })
		}
	}, [snippetsAPI])

	const sync = useCallback(async (
		id: number,
		snippets: readonly AiResultSnippet[],
		// Passed in rather than closed over: `plan` is a fresh object on every poll
		// response, so capturing it would change this callback's identity and
		// re-trigger the sync effect on every tick.
		syncPlan?: AiPlan | null
	): Promise<void> => {
		const synced = loadSync(id)

		setItems(initialItems(snippets, synced, syncPlan))

		// First time this snippet is seen: create it on the site.
		const create = async (snippet: AiResultSnippet, code: string): Promise<void> => {
			const language = resolveSnippetLanguage(snippet, syncPlan)

			try {
				const response = await api.post<DownloadSnippetResponse>(
					`${REST_BASES.cloud.snippets}/${snippet.cloud_id}/download`
				)

				// Without a language there is no correct scope to enforce; the snippet
				// keeps whatever type the download endpoint gave it.
				if (language) {
					await ensureCorrectType(response.snippet_id, language)
				}

				synced[snippet.cloud_id] = { localId: response.snippet_id, code }
				patch(snippet.cloud_id, { localId: response.snippet_id, status: 'done' })
			} catch (error) {
				patch(snippet.cloud_id, { status: 'error', error: unpackErrorResponse(error) })
			}
		}

		await Promise.all(snippets.map(async snippet => {
			const code = snippet.code ?? ''
			const record = synced[snippet.cloud_id]

			if (!record) {
				return create(snippet, code)
			}

			// Already synced (e.g. reopening a past conversation): confirm the local
			// snippet still exists, and apply any code change from an edit.
			try {
				const local = await snippetsAPI.fetch(record.localId, false)

				if (local.trashed) {
					patch(snippet.cloud_id, { localId: record.localId, status: 'deleted' })
					return
				}

				if ('' !== code && code !== record.code) {
					await snippetsAPI.update({ ...local, code })
					synced[snippet.cloud_id] = { localId: record.localId, code }
				}

				patch(snippet.cloud_id, { localId: record.localId, status: 'done' })
			} catch (error) {
				// A 404 means the snippet was deleted from the site; other errors are
				// transient, so leave the row as-is rather than false-flagging deletion.
				patch(snippet.cloud_id, isNotFound(error)
					? { localId: record.localId, status: 'deleted' }
					: { localId: record.localId, status: 'done' })
			}
		}))

		saveSync(id, synced)
	}, [api, snippetsAPI, ensureCorrectType])

	// A signature that changes when the generation, its snippets, or their code change.
	const snippets = result ? collectSnippets(result) : []
	const signature = `${generationId ?? 0}|${snippets.map(snippet => `${snippet.cloud_id}:${snippet.code ?? ''}`).join('|')}`

	useEffect(() => {
		if (generationId && snippets.length) {
			void sync(generationId, snippets, plan)
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [signature, sync])

	const retryDownload = useCallback((): void => {
		if (generationId && result) {
			void sync(generationId, collectSnippets(result), plan)
		}
	}, [generationId, result, plan, sync])

	return {
		items,
		isDownloading: items.some(item => 'downloading' === item.status),
		retryDownload
	}
}
