import React from 'react'
import { __ } from '@wordpress/i18n'

interface PromptPreset {
	readonly label: string
	readonly prompt: string
}

// Each preset is a complete, sendable prompt: clicking one submits it straight
// away rather than leaving placeholder tokens for the user to fill in.
//
// Two rules, both learned from presets that made the agent look incapable:
//
// 1. State the GOAL, never a list of techniques. The old "speed up my site"
//    preset asked for "caching, asset trimming, and lazy loading", so the agent
//    answered about that list — declining the two it judged out of reach —
//    instead of planning the speed-up that was actually wanted.
// 2. No meta-instructions like "start with an example and I will tell you which
//    one I mean". They push the agent into asking the user something it can
//    read from the site itself. The cloud now asks to look at the connected
//    site when a prompt turns on what is installed, and refinement fills in the
//    rest, so the preset does not need to choreograph any of that.
export const PROMPT_PRESETS: readonly PromptPreset[] = [
	{
		label: __('Replace a plugin with snippets', 'code-snippets'),
		prompt: __('I want to replace a plugin on my site with lightweight snippets that do the same job. Plan the replacement.', 'code-snippets')
	},
	{
		label: __('Speed up my site', 'code-snippets'),
		prompt: __('My site is slower than I would like. Plan snippets that make it faster.', 'code-snippets')
	},
	{
		label: __('Add a feature', 'code-snippets'),
		prompt: __('Plan a snippet that adds a useful new feature to my site.', 'code-snippets')
	},
	{
		label: __('Fix a problem', 'code-snippets'),
		prompt: __('Something on my site is not behaving the way I want. Plan a snippet that fixes it.', 'code-snippets')
	},
	{
		label: __('Customize appearance', 'code-snippets'),
		prompt: __('Plan a CSS snippet that customises how my site looks — colours, spacing, or typography.', 'code-snippets')
	}
]

interface PromptExamplesProps {
	onPick: (prompt: string) => void
	disabled?: boolean
}

export const PromptExamples: React.FC<PromptExamplesProps> = ({ onPick, disabled }) =>
	<div className="ai-agent-examples" role="group" aria-label={__('Prompt examples', 'code-snippets')}>
		<h2 className="ai-agent-sidebar__heading">{__('Prompt examples', 'code-snippets')}</h2>

		{PROMPT_PRESETS.map(preset =>
			<button
				key={preset.label}
				type="button"
				className="ai-agent-examples__chip"
				disabled={disabled}
				onClick={() => onPick(preset.prompt)}
			>
				{preset.label}
			</button>)}
	</div>
