import React from 'react'
import { __, _n, sprintf } from '@wordpress/i18n'
import { MESSAGE_LIMIT_PER_CONVERSATION } from './types'

interface MessageLimitNoticeProps {
	messageCount: number
}

export const MessageLimitNotice: React.FC<MessageLimitNoticeProps> = ({ messageCount }) => {
	const remaining = Math.max(0, MESSAGE_LIMIT_PER_CONVERSATION - messageCount)
	const limitReached = messageCount >= MESSAGE_LIMIT_PER_CONVERSATION

	return (
		<div className="ai-agent-message-limit">
			<h2 className="ai-agent-sidebar__heading">{__('Message limit', 'code-snippets')}</h2>

			{limitReached
				? <p className="ai-agent-message-limit__value is-warning">
					{sprintf(
						/* translators: %d: message limit. */
						__('Conversation cap of %d messages reached. Start a new conversation to continue.', 'code-snippets'),
						MESSAGE_LIMIT_PER_CONVERSATION
					)}
				</p>
				: <p className="ai-agent-message-limit__value">
					{sprintf(
						/* translators: 1: messages used, 2: message limit. */
						__('%1$d of %2$d messages used in this conversation.', 'code-snippets'),
						messageCount,
						MESSAGE_LIMIT_PER_CONVERSATION
					)}
					{' '}
					{sprintf(
						/* translators: %d: remaining messages. */
						_n('%d remaining.', '%d remaining.', remaining, 'code-snippets'),
						remaining
					)}
				</p>}
		</div>
	)
}
