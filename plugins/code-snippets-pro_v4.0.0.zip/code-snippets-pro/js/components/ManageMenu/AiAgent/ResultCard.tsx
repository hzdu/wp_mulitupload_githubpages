import React, { useEffect, useState } from 'react'
import { __ } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { useSnippetsAPI } from '../../../hooks/useSnippetsAPI'
import { handleUnknownError, unpackErrorResponse } from '../../../utils/errors'
import { getSnippetEditUrl, getSnippetType } from '../../../utils/snippets/snippets'
import { Badge } from '../../common/Badge'
import { Button } from '../../common/Button'
import { PreviewModal } from '../../common/snippets/SnippetPreviewModal'
import { useAiAgentContext } from './AiAgentContext'
import { PromptBox } from './PromptBox'
import { languageToSnippetType, resolveSnippetLanguage } from './types'
import { useAiAgentDownload } from './useAiAgentDownload'
import type { AiResult, AiResultSnippet } from './types'
import type { SnippetType } from '../../../types/Snippet'

interface ResultCardProps {
	generationId: number
	result: AiResult
}

interface PreviewState {
	title: string
	code: string
	type: SnippetType
}

const collectSnippets = (result: AiResult): AiResultSnippet[] =>
	'bundle' === result.type
		? result.bundle?.snippets ?? []
		: result.snippet ? [result.snippet] : []

export const ResultCard: React.FC<ResultCardProps> = ({ generationId, result }) => {
	const { generation, editSnippets, isSubmitting, status, isEditingSnippets, setEditingSnippets } = useAiAgentContext()
	const plan = generation?.plan
	const { items, retryDownload } = useAiAgentDownload(generationId, result, plan)
	const snippetsAPI = useSnippetsAPI()

	const snippets = collectSnippets(result)
	const selecting = isEditingSnippets
	const [selected, setSelected] = useState<Set<number>>(new Set())
	const [editText, setEditText] = useState('')
	const [preview, setPreview] = useState<PreviewState>()
	const [previewLoadingId, setPreviewLoadingId] = useState<number>()

	const isEditing = 'editing' === status
	const hasError = items.some(item => 'error' === item.status)

	// Edit mode lives in the shared context so it can disable the main composer;
	// clear it when the card goes away, or the composer stays disabled.
	useEffect(() => () => setEditingSnippets(false), [setEditingSnippets])

	// Deleted snippets can't be previewed or edited, so exclude them from selection.
	const selectableIds = snippets
		.filter(snippet => 'deleted' !== items.find(item => item.cloudId === snippet.cloud_id)?.status)
		.map(snippet => snippet.cloud_id)
	const allSelected = 0 < selectableIds.length && selectableIds.every(id => selected.has(id))

	// Preview the cloud-provided code when present, otherwise the local snippet
	// created on the site (which always has code once downloaded).
	const openPreview = (snippet: AiResultSnippet, localId?: number) => {
		const language = resolveSnippetLanguage(snippet, plan)
		const type = language ? languageToSnippetType(language) : undefined

		if (snippet.code) {
			setPreview({ title: snippet.name, code: snippet.code, type: type ?? 'php' })
			return
		}

		if (localId) {
			setPreviewLoadingId(snippet.cloud_id)
			snippetsAPI.fetch(localId, false)
				// The local snippet knows its own type, so an unknown language does
				// not have to fall back to PHP highlighting here.
				.then(local => setPreview({
					title: snippet.name,
					code: local.code,
					type: type ?? getSnippetType(local)
				}))
				.catch((error: unknown) => window.console.error('AI Agent preview failed', unpackErrorResponse(error)))
				.finally(() => setPreviewLoadingId(undefined))
		}
	}

	const title = 'bundle' === result.type
		? result.bundle?.name ?? __('Snippet bundle', 'code-snippets')
		: result.snippet?.name ?? __('Snippet', 'code-snippets')

	const itemFor = (cloudId: number) => items.find(item => item.cloudId === cloudId)

	const toggle = (cloudId: number) =>
		setSelected(previous => {
			const next = new Set(previous)

			if (next.has(cloudId)) {
				next.delete(cloudId)
			} else {
				next.add(cloudId)
			}

			return next
		})

	const enterEditMode = () => {
		setEditingSnippets(true)
		setSelected(new Set(selectableIds))
	}

	const cancelEditMode = () => {
		setEditingSnippets(false)
		setSelected(new Set())
		setEditText('')
	}

	const submitEdit = () => {
		editSnippets([...selected], editText.trim())
			.then(() => setEditText(''))
			.catch(handleUnknownError)
	}

	return (
		<div className="ai-agent-result">
			<div className="ai-agent-plan__header">
				<h3 className="ai-agent-plan__title">{title}</h3>
				<span className="ai-agent-plan__badge is-done">
					{isEditing ? __('Updating…', 'code-snippets') : __('Created', 'code-snippets')}
				</span>
			</div>

			<p className="ai-agent-result__lead">
				{__('These snippets were created and added to your site (inactive). Preview the code, or make changes below.', 'code-snippets')}
			</p>

			<ul className="ai-agent-result__rows">
				{snippets.map(snippet => {
					const item = itemFor(snippet.cloud_id)
					const editUrl = item?.localId ? getSnippetEditUrl({ id: item.localId }) : undefined
					const language = item?.language ?? resolveSnippetLanguage(snippet, plan)

					const isDeleted = 'deleted' === item?.status

					return (
						<li key={snippet.cloud_id} className="ai-agent-result__row">
							{selecting
								? <input
									type="checkbox"
									checked={selected.has(snippet.cloud_id)}
									disabled={isDeleted}
									aria-label={snippet.name}
									onChange={() => toggle(snippet.cloud_id)}
								/>
								: null}

							{language ? <Badge name={languageToSnippetType(language)} small /> : null}
							<span className="ai-agent-result__name">{snippet.name}</span>

							{'checking' === item?.status
								? <span className="ai-agent-result__status is-checking">
									<Spinner />
									{__('Getting snippet status…', 'code-snippets')}
								</span>
								: isDeleted
									? <span className="ai-agent-result__status is-deleted">
										{__('Snippet deleted', 'code-snippets')}
									</span>
									: <>
										{snippet.code || item?.localId
											? <Button
												link
												type="button"
												disabled={previewLoadingId === snippet.cloud_id}
												onClick={() => openPreview(snippet, item?.localId)}
											>
												{previewLoadingId === snippet.cloud_id
													? __('Loading…', 'code-snippets')
													: __('Preview code', 'code-snippets')}
											</Button>
											: null}

										{'downloading' === item?.status ? <Spinner aria-hidden="true" /> : null}

										{'done' === item?.status && editUrl
											? <a className="ai-agent-result__link" href={editUrl}>{__('Edit', 'code-snippets')}</a>
											: null}

										{'error' === item?.status
											? <span className="ai-agent-result__status is-error">
												{item.error ?? __('Sync failed', 'code-snippets')}
											</span>
											: null}
									</>}
						</li>
					)
				})}
			</ul>

			{hasError
				? <Button secondary type="button" onClick={retryDownload}>{__('Retry sync', 'code-snippets')}</Button>
				: null}

			<div className="ai-agent-result__edit">
				{selecting
					? <>
						<div className="ai-agent-result__edit-head">
							<span>{__('Select the snippets to change, then describe the change.', 'code-snippets')}</span>
							<div className="ai-agent-result__edit-actions">
								<Button
									link
									type="button"
									onClick={() => setSelected(allSelected ? new Set() : new Set(selectableIds))}
								>
									{allSelected ? __('Deselect all', 'code-snippets') : __('Select all', 'code-snippets')}
								</Button>
								<Button link type="button" onClick={cancelEditMode}>{__('Cancel', 'code-snippets')}</Button>
							</div>
						</div>

						<PromptBox
							id="ai-agent-edit-prompt"
							value={editText}
							onChange={setEditText}
							onSubmit={submitEdit}
							busy={isEditing || isSubmitting}
							submitDisabled={0 === selected.size}
							submitLabel={__('Apply changes', 'code-snippets')}
							placeholder={__('Describe the changes to the selected snippet(s)…', 'code-snippets')}
						/>
					</>
					: <Button secondary type="button" className="ai-agent-result__make-changes" onClick={enterEditMode}>
						{__('Make changes', 'code-snippets')}
					</Button>}
			</div>

			{preview
				? <PreviewModal
					title={preview.title}
					code={preview.code}
					type={preview.type}
					onRequestClose={() => setPreview(undefined)}
				/>
				: null}
		</div>
	)
}
