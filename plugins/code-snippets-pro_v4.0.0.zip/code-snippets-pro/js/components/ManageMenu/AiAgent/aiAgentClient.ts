import { useMemo } from 'react'
import { useRestAPI } from '../../../hooks/useRestAPI'
import { REST_BASES } from '../../../utils/restAPI'
import type { AiAgentContext, AiGeneration, AiGenerationList } from './types'

/**
 * Mutating calls take a signal so the composer's Stop control can abort the
 * request in flight. Aborting only stops the plugin waiting on the response —
 * the cloud queues the work server-side, so the job itself keeps running.
 */
export interface AiAgentClient {
	create: (prompt: string, context?: AiAgentContext, signal?: AbortSignal) => Promise<AiGeneration>
	list: () => Promise<AiGenerationList>
	get: (id: number) => Promise<AiGeneration>
	refine: (id: number, message: string, context?: AiAgentContext, signal?: AbortSignal) => Promise<AiGeneration>
	accept: (id: number, signal?: AbortSignal) => Promise<AiGeneration>
	retry: (id: number, signal?: AbortSignal) => Promise<AiGeneration>
	cancel: (id: number) => Promise<AiGeneration>
	/** Passing no context declines the request rather than answering it. */
	provideContext: (id: number, context?: AiAgentContext, signal?: AbortSignal) => Promise<AiGeneration>
	editSnippets: (
		id: number,
		snippetIds: number[],
		message: string,
		context?: AiAgentContext,
		signal?: AbortSignal
	) => Promise<AiGeneration>
	remove: (id: number) => Promise<void>
}

const generationsBase = () => `${REST_BASES.cloud.aiAgent}/generations`

export const useAiAgentClient = (): AiAgentClient => {
	const { api } = useRestAPI()

	return useMemo((): AiAgentClient => ({
		create: (prompt, context, signal) =>
			api.post<AiGeneration, { prompt: string, context?: AiAgentContext }>(
				generationsBase(),
				context ? { prompt, context } : { prompt },
				{ signal }
			),

		list: () =>
			api.get<AiGenerationList>(generationsBase()),

		get: id =>
			api.get<AiGeneration>(`${generationsBase()}/${id}`),

		refine: (id, message, context, signal) =>
			api.post<AiGeneration, { message: string, context?: AiAgentContext }>(
				`${generationsBase()}/${id}/refine`,
				context ? { message, context } : { message },
				{ signal }
			),

		accept: (id, signal) =>
			api.post<AiGeneration>(`${generationsBase()}/${id}/proceed`, undefined, { signal }),

		retry: (id, signal) =>
			api.post<AiGeneration>(`${generationsBase()}/${id}/retry`, undefined, { signal }),

		// Deliberately not abortable: this is what Stop calls, so it has to outlive
		// the request Stop is cancelling.
		cancel: id =>
			api.post<AiGeneration>(`${generationsBase()}/${id}/cancel`),

		provideContext: (id, context, signal) =>
			api.post<AiGeneration, { context?: AiAgentContext, decline?: boolean }>(
				`${generationsBase()}/${id}/context`,
				context ? { context } : { decline: true },
				{ signal }
			),

		editSnippets: (id, snippetIds, message, context, signal) =>
			api.post<AiGeneration, { snippet_ids: number[], message: string, context?: AiAgentContext }>(
				`${generationsBase()}/${id}/edit`,
				context ? { snippet_ids: snippetIds, message, context } : { snippet_ids: snippetIds, message },
				{ signal }
			),

		remove: id =>
			api.del<{ success: boolean }>(`${generationsBase()}/${id}`).then(() => undefined)
	}), [api])
}
