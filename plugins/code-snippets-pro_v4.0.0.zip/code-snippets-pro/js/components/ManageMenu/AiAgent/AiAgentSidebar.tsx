import React, { useRef, useState } from 'react'
import { __ } from '@wordpress/i18n'
import { useAiAgentContext } from './AiAgentContext'
import { HistoryRail } from './HistoryRail'
import { MessageLimitNotice } from './MessageLimitNotice'
import { PromptExamples } from './PromptExamples'

type SidebarTab = 'actions' | 'history'

interface AiAgentSidebarProps {
	onPickExample: (prompt: string) => void
}

export const AiAgentSidebar: React.FC<AiAgentSidebarProps> = ({ onPickExample }) => {
	const { limitReached, messageCount } = useAiAgentContext()
	const [tab, setTab] = useState<SidebarTab>('actions')
	const tabRefs = useRef<Record<SidebarTab, HTMLButtonElement | null>>({ actions: null, history: null })

	const handleTabKeyDown = (event: React.KeyboardEvent<HTMLButtonElement>) => {
		const tabs: SidebarTab[] = ['actions', 'history']
		const currentIndex = tabs.indexOf(tab)
		let nextIndex: number

		switch (event.key) {
			case 'ArrowLeft':
			case 'ArrowUp':
				nextIndex = (currentIndex - 1 + tabs.length) % tabs.length
				break
			case 'ArrowRight':
			case 'ArrowDown':
				nextIndex = (currentIndex + 1) % tabs.length
				break
			case 'Home':
				nextIndex = 0
				break
			case 'End':
				nextIndex = tabs.length - 1
				break
			default:
				return
		}

		event.preventDefault()
		const nextTab = tabs[nextIndex]
		setTab(nextTab)
		tabRefs.current[nextTab]?.focus()
	}

	return (
		<aside className="ai-agent-sidebar" aria-label={__('AI Agent tools', 'code-snippets')}>
			<div className="ai-agent-sidebar__tabs" role="tablist" aria-orientation="horizontal">
				<button
					type="button"
					role="tab"
					id="ai-agent-tab-actions"
					aria-selected={'actions' === tab}
					aria-controls="ai-agent-panel-actions"
					tabIndex={'actions' === tab ? 0 : -1}
					ref={element => { tabRefs.current.actions = element }}
					className={`ai-agent-sidebar__tab ${'actions' === tab ? 'is-active' : ''}`}
					onClick={() => setTab('actions')}
					onKeyDown={handleTabKeyDown}
				>
					{__('Prompt Actions', 'code-snippets')}
				</button>

				<button
					type="button"
					role="tab"
					id="ai-agent-tab-history"
					aria-selected={'history' === tab}
					aria-controls="ai-agent-panel-history"
					tabIndex={'history' === tab ? 0 : -1}
					ref={element => { tabRefs.current.history = element }}
					className={`ai-agent-sidebar__tab ${'history' === tab ? 'is-active' : ''}`}
					onClick={() => setTab('history')}
					onKeyDown={handleTabKeyDown}
				>
					{__('Past Conversations', 'code-snippets')}
				</button>
			</div>

			<div
				className="ai-agent-sidebar__panel"
				role="tabpanel"
				id="ai-agent-panel-actions"
				aria-labelledby="ai-agent-tab-actions"
				hidden={'actions' !== tab}
			>
				<PromptExamples onPick={onPickExample} disabled={limitReached} />
				<MessageLimitNotice messageCount={messageCount} />
			</div>

			<div
				className="ai-agent-sidebar__panel"
				role="tabpanel"
				id="ai-agent-panel-history"
				aria-labelledby="ai-agent-tab-history"
				hidden={'history' !== tab}
			>
				<HistoryRail />
			</div>
		</aside>
	)
}
