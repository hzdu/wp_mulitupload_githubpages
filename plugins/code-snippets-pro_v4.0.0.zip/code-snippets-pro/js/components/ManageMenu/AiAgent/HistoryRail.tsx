import React from 'react'
import { __, sprintf } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { useAiAgentContext } from './AiAgentContext'
import type { AiGenerationStatus } from './types'

const STATUS_LABELS: Record<AiGenerationStatus, string> = {
	planning: __('Planning', 'code-snippets'),
	plan_ready: __('Plan ready', 'code-snippets'),
	generating: __('Building', 'code-snippets'),
	completed: __('Completed', 'code-snippets'),
	failed: __('Failed', 'code-snippets'),
	editing: __('Updating', 'code-snippets')
}

const STATUS_CLASS: Record<AiGenerationStatus, string> = {
	planning: '',
	plan_ready: 'is-plan',
	generating: '',
	completed: 'is-done',
	failed: 'is-failed',
	editing: ''
}

const TrashIcon: React.FC = () =>
	<svg
		className="ai-agent-history__delete-icon"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		strokeWidth="2"
		strokeLinecap="round"
		strokeLinejoin="round"
		aria-hidden="true"
	>
		<path d="M4 7h16" />
		<path d="M10 11v6" />
		<path d="M14 11v6" />
		<path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2l1-12" />
		<path d="M9 7V4h6v3" />
	</svg>

export const HistoryRail: React.FC = () => {
	const {
		conversations,
		conversationsLoaded,
		generation,
		openConversation,
		deleteConversation
	} = useAiAgentContext()

	if (!conversationsLoaded && 0 === conversations.length) {
		return (
			<div className="ai-agent-history ai-agent-history--loading" role="status" aria-live="polite">
				<Spinner />
				<span>{__('Loading conversations…', 'code-snippets')}</span>
			</div>
		)
	}

	return (
		<div className="ai-agent-history">
			{0 === conversations.length
				? <p className="ai-agent-history__empty">{__('No conversations yet.', 'code-snippets')}</p>
				: <ul className="ai-agent-history__list">
					{conversations.map(conversation =>
						<li
							key={conversation.id}
							className={`ai-agent-history__item ${conversation.id === generation?.id ? 'is-active' : ''}`}
						>
							<button
								type="button"
								className="ai-agent-history__open"
								aria-current={conversation.id === generation?.id ? 'true' : undefined}
								onClick={() => void openConversation(conversation.id)}
							>
								<span className="ai-agent-history__title" title={conversation.title}>
									{conversation.title}
								</span>
								<span className={`ai-agent-history__status ${STATUS_CLASS[conversation.status]}`}>
									{STATUS_LABELS[conversation.status]}
								</span>
							</button>

							<button
								type="button"
								className="ai-agent-history__delete"
								aria-label={sprintf(
									__('Delete conversation “%s”', 'code-snippets'),
									conversation.title
								)}
								onClick={() => void deleteConversation(conversation.id)}
							>
								<TrashIcon />
							</button>
						</li>)}
				</ul>}
		</div>
	)
}
