import React from 'react'
import { __ } from '@wordpress/i18n'
import { Button } from '../../common/Button'
import { useAiAgentContext } from './AiAgentContext'
import { PlanCard } from './PlanCard'
import { ResultCard } from './ResultCard'
import type { AiContextRequest, AiFailureReason, AiGeneration, AiHistoryEntry } from './types'

const ThreadMessage: React.FC<{ entry: AiHistoryEntry }> = ({ entry }) =>
	<div className={`ai-agent-message is-${entry.role}`}>
		<span className="ai-agent-message__role">
			{'user' === entry.role ? __('You', 'code-snippets') : __('AI Agent', 'code-snippets')}
		</span>
		<div className="ai-agent-message__content">{entry.content}</div>
	</div>

const TypingIndicator: React.FC<{ label: string }> = ({ label }) =>
	<div className="ai-agent-typing" role="status">
		<span className="ai-agent-typing__dots" aria-hidden="true"><i /><i /><i /></span>
		<span>{label}</span>
	</div>

const StoppedNotice: React.FC<{ onResume: () => void }> = ({ onResume }) =>
	<div className="ai-agent-stopped" role="status">
		<p>{__('Stopped waiting. The AI may still be working on this in the cloud.', 'code-snippets')}</p>
		<Button secondary type="button" onClick={onResume}>{__('Check again', 'code-snippets')}</Button>
	</div>

const CancelledNotice: React.FC<{ busy: boolean, onResume: () => void }> = ({ busy, onResume }) =>
	<div className="ai-agent-stopped" role="status">
		<p>{__('You stopped this generation.', 'code-snippets')}</p>
		<Button secondary type="button" disabled={busy} onClick={onResume}>
			{__('Resume', 'code-snippets')}
		</Button>
	</div>

/**
 * What each context level actually hands over, so the user is consenting to
 * something concrete rather than to a letter and a number.
 */
const contextSummary = (level: AiContextRequest['level']): string =>
	'L3' === level
		? __('This shares the names and types of your snippets, plus your site environment — WordPress and PHP versions, active theme, and active plugins.', 'code-snippets')
		: __('This shares the names and types of the snippets in your library. Your snippet code is not sent.', 'code-snippets')

interface ContextRequestPanelProps {
	request: AiContextRequest
	busy: boolean
	onShare: () => void
	onDecline: () => void
}

/**
 * The agent asking to see more before it plans. Not an error state: nothing has
 * gone wrong, and nothing wider is sent until the user answers.
 */
const ContextRequestPanel: React.FC<ContextRequestPanelProps> = ({ request, busy, onShare, onDecline }) =>
	<div className="ai-agent-context-request">
		<p className="ai-agent-context-request__detail">{contextSummary(request.level)}</p>

		<div className="ai-agent-context-request__actions">
			<Button primary type="button" disabled={busy} onClick={onShare}>
				{'L3' === request.level
					? __('Share library and site info', 'code-snippets')
					: __('Share my snippet library', 'code-snippets')}
			</Button>

			<Button secondary type="button" disabled={busy} onClick={onDecline}>
				{__('Continue without it', 'code-snippets')}
			</Button>
		</div>
	</div>

interface FailurePanelProps {
	message: string | null
	timedOut: boolean
	busy: boolean
	onRetry: () => void
}

/**
 * Something went wrong, and trying again is the answer. Refusals and questions
 * never reach here: the cloud puts both in the transcript as ordinary assistant
 * turns, so a panel would only repeat what the thread already shows.
 */
const FailurePanel: React.FC<FailurePanelProps> = ({ message, timedOut, busy, onRetry }) =>
	<div className="ai-agent-error" role="alert">
		<p>{message ?? (timedOut
			? __('This is taking longer than expected.', 'code-snippets')
			: __('Something went wrong while generating.', 'code-snippets'))}</p>

		<Button secondary type="button" disabled={busy} onClick={onRetry}>
			{__('Retry', 'code-snippets')}
		</Button>
	</div>

interface ThreadFailureProps {
	generation: AiGeneration
	timedOut: boolean
	busy: boolean
}

/**
 * How the last attempt ended. Only `error` is retryable; the rest are the agent
 * asking for something, or the user's own Stop.
 */
const ThreadFailure: React.FC<ThreadFailureProps> = ({ generation, timedOut, busy }) => {
	const { retry, shareContext, declineContext } = useAiAgentContext()
	const reason: AiFailureReason = generation.failure_reason ?? 'error'

	// An ask for wider context is a consent step, not a failure.
	if ('context' === reason && generation.context_request) {
		return <ContextRequestPanel
			request={generation.context_request}
			busy={busy}
			onShare={() => void shareContext()}
			onDecline={() => void declineContext()}
		/>
	}

	if ('cancelled' === reason) {
		return <CancelledNotice busy={busy} onResume={() => void retry()} />
	}

	// A question and a refusal are both already the last assistant message in
	// the thread, and the composer is live to answer or rephrase, so neither
	// needs a failure panel of its own — one would just say it twice.
	return 'question' === reason || 'refused' === reason
		? null
		: <FailurePanel
			message={generation.error}
			timedOut={timedOut}
			busy={busy}
			onRetry={() => void retry()}
		/>
}

/**
 * Everything below the conversation history: what the agent is doing now, or
 * how the last attempt ended.
 */
const ThreadStatus: React.FC<{ onRefine: () => void }> = ({ onRefine }) => {
	const { generation, status, pollTimedOut, isStopped, resume, isSubmitting, pendingPrompt } =
		useAiAgentContext()

	if (pendingPrompt) {
		return <TypingIndicator label={__('Planning your snippets…', 'code-snippets')} />
	}

	if (isStopped) {
		return 'planning' === status || 'generating' === status
			? <StoppedNotice onResume={resume} />
			: null
	}

	// Checked before the busy states: a poll timeout happens while the status is
	// still planning or generating, and must win over the typing indicator.
	if (generation && ('failed' === status || pollTimedOut)) {
		return <ThreadFailure generation={generation} timedOut={pollTimedOut} busy={isSubmitting} />
	}

	if ('planning' === status) {
		return <TypingIndicator label={__('Planning your snippets…', 'code-snippets')} />
	}

	if ('generating' === status) {
		return <TypingIndicator label={__('Building the code…', 'code-snippets')} />
	}

	if ('plan_ready' === status && generation?.plan) {
		return <PlanCard plan={generation.plan} onRefine={onRefine} />
	}

	return ('completed' === status || 'editing' === status) && generation?.result
		? <ResultCard generationId={generation.id} result={generation.result} />
		: null
}

interface ConversationThreadProps {
	onRefine: () => void
}

export const ConversationThread: React.FC<ConversationThreadProps> = ({ onRefine }) => {
	const { generation, pendingPrompt } = useAiAgentContext()

	if (!generation && !pendingPrompt) {
		return null
	}

	const history = generation?.history ?? []
	const planSummary = generation?.plan?.summary

	return (
		<div
			className="ai-agent-thread"
			role="log"
			aria-label={__('AI Agent conversation', 'code-snippets')}
			aria-live="polite"
			aria-relevant="additions"
		>
			{history.map((entry, index) =>
				// The current plan summary is shown as the plan card overview, so skip
				// its duplicate assistant bubble unless a new prompt is in flight.
				'assistant' === entry.role && entry.content === planSummary && !pendingPrompt
					? null
					: <ThreadMessage key={`${entry.role}-${index}`} entry={entry} />)}

			{pendingPrompt
				? <ThreadMessage entry={{ role: 'user', content: pendingPrompt }} />
				: null}

			<ThreadStatus onRefine={onRefine} />
		</div>
	)
}
