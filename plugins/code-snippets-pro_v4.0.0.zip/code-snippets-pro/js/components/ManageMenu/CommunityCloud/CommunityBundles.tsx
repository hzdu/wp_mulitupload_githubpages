import { __, sprintf } from '@wordpress/i18n'
import React, { useState } from 'react'
import { useFetchData } from '../../../hooks/useFetchData'
import { REST_BASES } from '../../../utils/restAPI'
import { buildAdminUrl, buildUrl } from '../../../utils/urls'
import { Button } from '../../common/Button'
import { TablePagination } from '../../common/ListTable/TablePagination'
import { LoadingStatusNotices } from '../../common/LoadingStatusNotices'
import { BundlesGrid } from '../CloudLibrary/BundlesGrid'
import { CloudSnippetAuthor, CloudSnippetCard } from '../../common/cloud/CloudSnippetCard'
import { CloudSnippetsTable } from './CloudSnippetsTable'
import type { CloudBundlesSchema } from '../../../types/schema/CloudBundleSchema'
import type { CloudSnippetSchema } from '../../../types/schema/CloudSnippetSchema'
import type { CloudSnippetsSchema } from '../../../types/schema/CloudSnippetsSchema'
import type { SnippetView } from '../../../types/SnippetView'
import type { FormEventHandler } from 'react'

interface SelectedBundle {
	shareCode: string
	name?: string
}

interface CommunitySnippetResultsProps {
	snippets: CloudSnippetSchema[]
	snippetView: SnippetView
	refreshSnippets?: VoidFunction
}

const CommunitySnippetResults: React.FC<CommunitySnippetResultsProps> = ({
	snippets,
	snippetView,
	refreshSnippets
}) =>
	'card' === snippetView
		? <ul className="cloud-search-results code-snippets-cards">
			{snippets.map(result =>
				<CloudSnippetCard
					key={result.id}
					snippet={result}
					author={<CloudSnippetAuthor codevaultSlug={result.codevault} />}
					onSnippetDownloaded={refreshSnippets}
				/>)}
		</ul>
		: <CloudSnippetsTable snippets={snippets} />

interface BundleShareCodeFormProps {
	onSubmit: (shareCode: string) => void
}

const BundleShareCodeForm: React.FC<BundleShareCodeFormProps> = ({ onSubmit }) => {
	const [shareCode, setShareCode] = useState<string>('')

	const handleSubmit: FormEventHandler<HTMLFormElement> = event => {
		event.preventDefault()
		onSubmit(shareCode.trim())
	}

	return (
		<form className="bundle-share-code-form" onSubmit={handleSubmit}>
			<div className="cloud-search-query">
				<input
					type="text"
					value={shareCode}
					aria-label={__('Bundle share code', 'code-snippets')}
					onChange={event => setShareCode(event.target.value)}
					placeholder={__('Enter bundle share code', 'code-snippets')}
				/>
			</div>
			<Button primary type="submit" disabled={!shareCode.trim()}>
				{__('Show Snippets', 'code-snippets')}
			</Button>
		</form>
	)
}

interface CommunityBundleSnippetsProps {
	bundle: SelectedBundle
	snippetView: SnippetView
}

const CommunityBundleSnippets: React.FC<CommunityBundleSnippetsProps> = ({
	bundle,
	snippetView
}) => {
	const [page, setPage] = useState(1)

	const bundleUrl =`${REST_BASES.cloud.communityBundles}/share_code/${encodeURIComponent(bundle.shareCode)}`
	const { data, refreshData, ...loadingStatus } = useFetchData<CloudSnippetsSchema>(buildUrl(bundleUrl, { page }))

	return (
		<div className="cloud-bundle-snippets-results">
			<h3>{
				// translators: %s is the name of the bundle.
				sprintf(__('All snippets in bundle: %s', 'code-snippets'), bundle.name ?? bundle.shareCode)
			}</h3>

			{data
				? <>
					<CommunitySnippetResults
						snippets={data.snippets}
						snippetView={snippetView}
						refreshSnippets={() => void refreshData()}
					/>

					{1 < data.total_pages &&
						<div className="tablenav bottom">
							<TablePagination
								which="bottom"
								totalItems={data.total_snippets}
								totalPages={data.total_pages}
								currentPage={page}
								setCurrentPage={setPage}
							/>
						</div>}
				</>
				: <LoadingStatusNotices
					isLoading={loadingStatus.isLoading}
					errorMessage={loadingStatus.errorMessage
						? __('Could not fetch snippets from bundle. Please try again.', 'code-snippets')
						: undefined}
					loadingNotice={__('Loading bundled snippets…', 'code-snippets')}
					noticeLabel={__('Bundle snippets status', 'code-snippets')}
				/>}
		</div>
	)
}

const CommunityBundlesIntro: React.FC = () =>
	<p>{__('Browse bundles shared publicly by the Code Snippets community.', 'code-snippets')}</p>

interface CommunityBundlesBrowserProps {
	onSelectBundle: (bundle: SelectedBundle) => void
}

const CommunityBundlesBrowser: React.FC<CommunityBundlesBrowserProps> = ({ onSelectBundle }) => {
	const [page, setPage] = useState(1)

	const { data, ...bundlesLoadingStatus } =
		useFetchData<CloudBundlesSchema>(buildUrl(REST_BASES.cloud.communityBundles, { page }))

	return data
		? <>
			<BundlesGrid
				bundles={data.bundles}
				intro={<CommunityBundlesIntro />}
				onViewSnippets={bundle =>
					onSelectBundle({ shareCode: bundle.share_code, name: bundle.name })}
			/>

			{1 < data.meta.total_pages &&
				<div className="tablenav bottom">
					<TablePagination
						which="bottom"
						totalItems={data.meta.total}
						totalPages={data.meta.total_pages}
						currentPage={page}
						setCurrentPage={setPage}
					/>
				</div>}
		</>
		: <LoadingStatusNotices
			isLoading={bundlesLoadingStatus.isLoading}
			errorMessage={bundlesLoadingStatus.errorMessage
				? __('Failed to load community bundles. Please try again.', 'code-snippets')
				: undefined}
			loadingNotice={__('Loading community bundles…', 'code-snippets')}
			noticeLabel={__('Community bundles status', 'code-snippets')}
		/>
}

export interface CommunityBundlesProps {
	snippetView: SnippetView
}

export const CommunityBundles: React.FC<CommunityBundlesProps> = ({ snippetView }) => {
	const [selectedBundle, setSelectedBundle] = useState<SelectedBundle>()

	if (selectedBundle) {
		return (
			<div className="cloud-bundles community-bundles">
				<a
					href={buildAdminUrl({}, ['tab'])}
					className="button button-secondary code-snippets-return-link"
					onClick={event => {
						event.preventDefault()
						setSelectedBundle(undefined)
					}}
				>
					{__('Back to all bundles', 'code-snippets')}
				</a>

				<CommunityBundleSnippets bundle={selectedBundle} snippetView={snippetView} />
			</div>
		)
	}

	return (
		<div className="cloud-bundles community-bundles">
			<p>{__('Enter a bundle share code below to see all snippets from a publicly-viewable bundle.', 'code-snippets')}</p>
			<BundleShareCodeForm onSubmit={shareCode => setSelectedBundle({ shareCode })} />

			<CommunityBundlesBrowser onSelectBundle={setSelectedBundle} />
		</div>
	)
}
