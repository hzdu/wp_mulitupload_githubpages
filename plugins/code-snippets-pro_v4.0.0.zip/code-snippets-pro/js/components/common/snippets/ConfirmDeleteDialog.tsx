import React, { useState } from 'react'
import { __, _n, sprintf } from '@wordpress/i18n'
import { createInterpolateElement } from '@wordpress/element'
import { CheckboxControl } from '@wordpress/components'
import { ConfirmDialog } from '../ConfirmDialog'
import { Button } from '../Button'
import { useSnippetsAPI } from '../../../hooks/useSnippetsAPI'
import { useRevisionsAPI } from '../../../hooks/useRevisionsAPI'
import type { Snippet } from '../../../types/Snippet'

type RevisionChoice = 'delete' | 'keep'

const TrashActiveConfirmMessage = () =>
	<>
		<p style={{ marginBlockStart: 0 }}>
			{createInterpolateElement(
				__('This snippet is currently <strong>active</strong>.', 'code-snippets'),
				{ strong: <strong /> }
			)}
		</p>

		<p>{__('Moving it to the trash will also deactivate it.', 'code-snippets')}</p>
	</>

const PermanentDeleteConfirmMessage = () =>
	<>
		<p style={{ marginBlockStart: 0 }}>
			{createInterpolateElement(
				__('The snippet will be <strong>permanently deleted</strong>.', 'code-snippets'),
				{ strong: <strong /> }
			)}
		</p>

		<p>{__('This action cannot be undone.', 'code-snippets')}</p>
	</>

export interface RevisionChoicePrompt {
	count: number
	rememberChoice: boolean
	setRememberChoice: (remember: boolean) => void
	onChoose: (choice: RevisionChoice) => void
	onCancel: VoidFunction
}

/**
 * Offered only when permanently deleting a snippet that still has revisions,
 * since that is the only path which destroys them.
 */
const RevisionChoiceDialog: React.FC<RevisionChoicePrompt> = ({
	count,
	rememberChoice,
	setRememberChoice,
	onChoose,
	onCancel
}) => {
	/* translators: %d: number of saved revisions. */
	const message = _n(
		'This snippet has <strong>%d saved revision</strong>. Delete it too, or keep it as a backup?',
		'This snippet has <strong>%d saved revisions</strong>. Delete them too, or keep them as a backup?',
		count,
		'code-snippets'
	)

	return (
		<ConfirmDialog
			open
			title={__('Delete snippet with revisions?', 'code-snippets')}
			confirmLabel={__('Delete Everything', 'code-snippets')}
			confirmButtonClassName="is-destructive"
			cancelLabel={__('Cancel', 'code-snippets')}
			onCancel={onCancel}
			onConfirm={() => onChoose('delete')}
		>
			<p style={{ marginBlockStart: 0 }}>
				{createInterpolateElement(sprintf(message, count), { strong: <strong /> })}
			</p>

			<p>
				<Button secondary onClick={() => onChoose('keep')}>
					{__('Keep Revisions', 'code-snippets')}
				</Button>
			</p>

			<CheckboxControl
				__nextHasNoMarginBottom
				label={__('Remember my choice', 'code-snippets')}
				checked={rememberChoice}
				onChange={setRememberChoice}
			/>
		</ConfirmDialog>
	)
}

export interface ConfirmDeleteDialogProps {
	snippet: Snippet
	isDialogOpen: boolean
	setIsDialogOpen: (isOpen: boolean) => void
	makeDeleteRequest: () => Promise<void>
	revisionChoice?: RevisionChoicePrompt
}

export const ConfirmDeleteDialog: React.FC<ConfirmDeleteDialogProps> = ({
	snippet,
	isDialogOpen,
	setIsDialogOpen,
	makeDeleteRequest,
	revisionChoice
}) =>
	<>
		<ConfirmDialog
			open={isDialogOpen}
			title={__('Are you sure?', 'code-snippets')}
			confirmLabel={snippet.trashed ? __('Delete', 'code-snippets') : __('Trash', 'code-snippets')}
			confirmButtonClassName="is-destructive"
			onCancel={() => setIsDialogOpen(false)}
			onConfirm={() => {
				setIsDialogOpen(false)
				void makeDeleteRequest()
			}}
		>
			{snippet.trashed
				? <PermanentDeleteConfirmMessage />
				: <TrashActiveConfirmMessage />}
		</ConfirmDialog>

		{revisionChoice ? <RevisionChoiceDialog {...revisionChoice} /> : null}
	</>

export interface UseDeleteSnippetProps {
	snippet: Snippet
	setIsWorking?: (isWorking: boolean) => void
	onSuccess?: (() => Promise<void>) | VoidFunction
	onError?: (error: unknown) => void
}

export interface ConfirmDeleteDialog {
	requestDelete: () => Promise<void>
	deleteDialogProps: ConfirmDeleteDialogProps
}

export const useDeleteSnippet = ({
	snippet,
	setIsWorking,
	onSuccess,
	onError
}: UseDeleteSnippetProps): ConfirmDeleteDialog => {
	const snippetsAPI = useSnippetsAPI()
	const revisionsAPI = useRevisionsAPI()
	const [isDialogOpen, setIsDialogOpen] = useState(false)
	const [revisionPrompt, setRevisionPrompt] = useState<{ count: number } | undefined>()
	const [rememberChoice, setRememberChoice] = useState(false)

	const makeDeleteRequest = async (revisionChoice?: RevisionChoice) => {
		setIsWorking?.(true)

		try {
			if (revisionChoice && rememberChoice) {
				await revisionsAPI.setDeletePreference(revisionChoice)
			}

			await snippetsAPI.delete(snippet, revisionChoice)
			await onSuccess?.()
		} catch (error) {
			onError?.(error)
		} finally {
			setIsWorking?.(false)
		}
	}

	/**
	 * Only a permanent deletion destroys revisions, so only it offers the choice —
	 * trashing keeps them either way, and the server ignores the choice there.
	 *
	 * The revision count is read at deletion time rather than cached alongside the
	 * snippet: revisions accumulate on every save, so a count captured when the
	 * component mounted goes stale and would skip this prompt, letting the server
	 * default silently purge the history.
	 */
	const proceedAfterConfirm = async () => {
		if (!snippet.trashed || !snippet.id) {
			await makeDeleteRequest()
			return
		}

		let count = 0
		let preference: RevisionChoice | undefined

		try {
			const settings = await revisionsAPI.getSettings(snippet.id, snippet.network)
			count = settings.revision_count ?? 0

			if (0 < count) {
				const saved = await revisionsAPI.getDeletePreference()
				preference = 'delete' === saved.delete_revision_default || 'keep' === saved.delete_revision_default
					? saved.delete_revision_default
					: undefined
			}
		} catch (error) {
			// Surface the failure rather than deleting anyway: falling through here
			// would destroy revisions the user was never asked about.
			onError?.(error)
			return
		}

		if (0 === count) {
			await makeDeleteRequest()
		} else if (preference) {
			// A remembered choice is applied directly — asking again would defeat it.
			await makeDeleteRequest(preference)
		} else {
			setRememberChoice(false)
			setRevisionPrompt({ count })
		}
	}

	const requestDelete = async () => {
		if (snippet.active || snippet.trashed) {
			setIsDialogOpen(true)
		} else {
			await makeDeleteRequest()
		}
	}

	return {
		requestDelete,
		deleteDialogProps: {
			snippet,
			isDialogOpen,
			setIsDialogOpen,
			makeDeleteRequest: proceedAfterConfirm,
			revisionChoice: revisionPrompt
				? {
					count: revisionPrompt.count,
					rememberChoice,
					setRememberChoice,
					onCancel: () => setRevisionPrompt(undefined),
					onChoose: choice => {
						setRevisionPrompt(undefined)
						void makeDeleteRequest(choice)
					}
				}
				: undefined
		}
	}
}
