import { __ } from '@wordpress/i18n'
import React from 'react'
import { useSnippetsAPI } from '../../../hooks/useSnippetsAPI'
import { useSnippetsList } from '../../../hooks/useSnippetsList'
import { handleUnknownError } from '../../../utils/errors'
import { canModifySnippet, getSnippetType } from '../../../utils/snippets/snippets'
import { Button } from '../Button'
import type { PreviewWorkingState } from '../snippets/SnippetPreviewModal'
import type { Snippet } from '../../../types/Snippet'

export interface PreviewCloudActionProps {
	snippet: Snippet
	working: PreviewWorkingState
}

export const PreviewCloudAction: React.FC<PreviewCloudActionProps> = ({ snippet, working }) => {
	const api = useSnippetsAPI()
	const { refreshSnippetsList } = useSnippetsList()

	if (
		'cond' === getSnippetType(snippet) ||
		!window.CODE_SNIPPETS?.isCloudConnected ||
		!canModifySnippet(snippet)
	) {
		return null
	}

	const handleCloudAction = () => {
		if (!working.beginWorking()) {
			return
		}

		const request = snippet.cloud.id ? api.unsync(snippet) : api.upload(snippet)
		request
			.then(refreshSnippetsList)
			.catch(handleUnknownError)
			.finally(working.finishWorking)
	}

	return (
		<Button
			secondary
			disabled={working.isWorking}
			onClick={handleCloudAction}
		>
			{snippet.cloud.id
				? __('Unlink from Cloud', 'code-snippets')
				: __('Upload to Cloud', 'code-snippets')}
		</Button>
	)
}
