import React from 'react'
import { __ } from '@wordpress/i18n'
import { CloudSyncState } from '../../../types/CloudSyncState'
import { CloudAvailableIcon } from '../icons/cloud/CloudAvailableIcon'
import { CloudErrorIcon } from '../icons/cloud/CloudErrorIcon'
import { CloudSyncedIcon } from '../icons/cloud/CloudSyncedIcon'
import { CloudUpdateIcon } from '../icons/cloud/CloudUpdateIcon'
import { Tooltip } from '../Tooltip'
import type { TooltipProps } from '../Tooltip'
import type { ReactNode, SVGProps } from 'react'

export const CLOUD_SYNC_STATE_ICONS: Record<CloudSyncState, React.FC<SVGProps<SVGSVGElement>>> = {
	[CloudSyncState.Unsynced]: CloudAvailableIcon,
	[CloudSyncState.Synced]: CloudSyncedIcon,
	[CloudSyncState.UpdateAvailable]: CloudUpdateIcon,
	[CloudSyncState.Errored]: CloudErrorIcon
}

const tooltips: Record<CloudSyncState, ReactNode> = {
	[CloudSyncState.Unsynced]: __('This snippet is available in the cloud but not yet synced to your local library.', 'code-snippets'),
	[CloudSyncState.Synced]: __('This snippet is synced between your local library and the cloud.', 'code-snippets'),
	[CloudSyncState.UpdateAvailable]: __('This snippet has been updated in the cloud. Click the sync button to update your local copy.', 'code-snippets'),
	[CloudSyncState.Errored]: __('There was an error syncing this snippet. Please try again.', 'code-snippets')
}

export interface CloudIconProps extends Omit<TooltipProps, 'children'> {
	state: CloudSyncState
}

export const CloudIcon: React.FC<CloudIconProps> = ({ state, ...tooltipProps }) => {
	const StateIcon = CLOUD_SYNC_STATE_ICONS[state]

	const tooltipIcon =
		<span className="cloud-icon" aria-label={__('Cloud Sync State', 'code-snippets')}>
			<StateIcon />
		</span>

	return (
		<Tooltip icon={tooltipIcon} {...tooltipProps}>
			{tooltips[state]}
		</Tooltip>
	)
}
