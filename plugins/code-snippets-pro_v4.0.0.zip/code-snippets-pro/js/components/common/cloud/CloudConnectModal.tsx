import { Modal } from '@wordpress/components'
import { __ } from '@wordpress/i18n'
import React from 'react'
import type { ModalProps } from '@wordpress/components/build-types/modal/types'

export interface CloudConnectModalProps extends Omit<ModalProps, 'children'> {
	openBlank?: boolean
}

export const CloudConnectModal: React.FC<CloudConnectModalProps> = ({ openBlank, ...modalProps }) =>
	<Modal
		title={__('Missing Cloud Connection', 'code-snippets')}
		className="cloud-connect-modal"
		{...modalProps}
	>
		<div className="icons-group">
			<span className="dashicons dashicons-admin-home"></span>
			<span className="dashicons dashicons-no"></span>
			<span className="dashicons dashicons-cloud"></span>
		</div>

		<p>{__('A connection to Code Snippets Cloud is required to use this functionality.', 'code-snippets')}</p>
		{!openBlank && <p>{__('Once connected, reload this page to recognise the new connection status.', 'code-snippets')}</p>}

		<div className="action-buttons">
			<a
				className="components-button is-primary"
				href={window.CODE_SNIPPETS?.urls.connectCloud}
				{...openBlank && { target: '_blank', rel: 'noopener noreferrer' }}
			>
				{__('Connect and Authorise', 'code-snippets')}
			</a>
		</div>
	</Modal>
