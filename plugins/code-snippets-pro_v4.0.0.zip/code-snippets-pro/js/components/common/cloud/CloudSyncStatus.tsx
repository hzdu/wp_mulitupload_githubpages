import classnames from 'classnames'
import React from 'react'
import { __ } from '@wordpress/i18n'
import { CloudSyncState } from '../../../types/CloudSyncState'
import { CLOUD_SYNC_STATE_ICONS } from './CloudIcon'

const STATE_LABELS: Record<CloudSyncState, string> = {
	[CloudSyncState.Unsynced]: __('Not synced', 'code-snippets'),
	[CloudSyncState.Synced]: __('Synced', 'code-snippets'),
	[CloudSyncState.UpdateAvailable]: __('Update available', 'code-snippets'),
	[CloudSyncState.Errored]: __('Sync error', 'code-snippets')
}

const STATE_CLASSES: Record<CloudSyncState, string> = {
	[CloudSyncState.Unsynced]: 'is-unsynced',
	[CloudSyncState.Synced]: 'is-synced',
	[CloudSyncState.UpdateAvailable]: 'is-update-available',
	[CloudSyncState.Errored]: 'is-errored'
}

export interface CloudSyncStatusIndicatorProps {
	state: CloudSyncState
}

export const CloudSyncStatusIndicator: React.FC<CloudSyncStatusIndicatorProps> = ({ state }) => {
	const StateIcon = CLOUD_SYNC_STATE_ICONS[state]

	return (
		<span
			aria-label={STATE_LABELS[state]}
			className={classnames('cloud-sync-status', STATE_CLASSES[state])}
			role="img">
			<StateIcon aria-hidden="true" focusable="false" />
			<span className="cloud-sync-status-label">{STATE_LABELS[state]}</span>
		</span>
	)
}
