import { __ } from '@wordpress/i18n'
import React from 'react'
import { ScreenMetaSlot } from '../ScreenMetaSlot'
import type { SVGProps } from 'react'

export interface CloudConnectPromptProps {
	/** Page title, matching the heading the connected screen shows. */
	title: string
	/** The screen's toolbar icon, shown beside the title. */
	Icon: React.FC<SVGProps<SVGSVGElement>>
	/** Short supporting line describing what the screen is for. */
	description: string
	/** What is blocking the screen; rendered larger than the description. */
	message: string
}

/**
 * Full-page state for screens that cannot function without a cloud connection.
 *
 * Rendered in place of the screen's own content, so it replaces the page rather
 * than layering over it — a modal here would only invite dismissal of a state
 * the user cannot dismiss their way out of.
 *
 * The screen meta slot is rendered here as well: contextual help is registered
 * for these screens whether or not the site is connected, so without the slot
 * the help tabs sit above the page rather than below the toolbar. It sits
 * outside the centred prompt so the help panel spans the page width.
 */
export const CloudConnectPrompt: React.FC<CloudConnectPromptProps> = ({ title, Icon, description, message }) =>
	<>
		<ScreenMetaSlot />

		<div className="cloud-connect-prompt">
			<div className="cloud-connect-prompt__card">
				<h1 className="cloud-connect-prompt__title">
					<Icon aria-hidden="true" />
					{title}
				</h1>

				<p className="cloud-connect-prompt__description">{description}</p>

				<p className="cloud-connect-prompt__message" role="alert">{message}</p>

				<a className="button button-primary" href={window.CODE_SNIPPETS?.urls.connectCloud}>
					{__('Connect to Cloud', 'code-snippets')}
				</a>
			</div>
		</div>
	</>
