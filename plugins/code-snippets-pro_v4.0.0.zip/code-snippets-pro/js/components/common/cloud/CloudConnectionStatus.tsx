import { __ } from '@wordpress/i18n'
import React, { useState } from 'react'
import { ConfirmDialog } from '../ConfirmDialog'
import { CloudConnectedIcon } from '../icons/cloud/CloudConnectedIcon'
import { CloudDisconnectedIcon } from '../icons/cloud/CloudDisconnectedIcon'
import type { SVGProps} from 'react'

interface StatusButtonProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
	title: string
	Icon: React.FC<SVGProps<SVGSVGElement>>
	statusLabel: string
	actionLabel: string
}

const StatusButton: React.FC<StatusButtonProps> = ({ title, statusLabel, actionLabel, Icon, ...props }) => {
	const [isActive, setIsActive] = useState(false)

	return (
		<a
			className="button button-large button-secondary cloud-connected-button"
			onMouseOver={() => setIsActive(true)}
			onFocus={() => setIsActive(true)}
			onMouseOut={() => setIsActive(false)}
			onBlur={() => setIsActive(false)}
			title={title}
			aria-label={title}
			{...props}
		>
			{isActive ? actionLabel : statusLabel}
			<Icon />
		</a>
	)
}

const ConnectButton = () =>
	<StatusButton
		title={__('Connect to Code Snippets Cloud', 'code-snippets')}
		actionLabel={__('Connect Now', 'code-snippets')}
		statusLabel={__('Disconnected', 'code-snippets')}
		href={window.CODE_SNIPPETS?.urls.connectCloud}
		Icon={CloudDisconnectedIcon}
	/>

const DisconnectButton = () => {
	const [isDialogOpen, setIsDialogOpen] = useState(false)

	return (
		<>
			<StatusButton
				title={__('Disconnect from Code Snippets Cloud', 'code-snippets')}
				actionLabel={__('Disconnect', 'code-snippets')}
				statusLabel={__('Connected', 'code-snippets')}
				href={window.CODE_SNIPPETS?.urls.resetCloud}
				Icon={CloudConnectedIcon}
				onClick={event => {
					event.preventDefault()
					setIsDialogOpen(true)
				}}
			/>

			<ConfirmDialog
				open={isDialogOpen}
				title={__('Disconnect from Code Snippets Cloud', 'code-snippets')}
				confirmLabel={__('Disconnect', 'code-snippets')}
				onCancel={() => setIsDialogOpen(false)}
				onConfirm={() => {
					if (window.CODE_SNIPPETS?.urls.resetCloud) {
						window.location.assign(window.CODE_SNIPPETS.urls.resetCloud)
					}

					setIsDialogOpen(false)
				}}
			>
				<p>
					{__('This will reset the current cloud connection.', 'code-snippets')} {
						__('Snippets remain in place, but you will need to connect again before syncing.', 'code-snippets')}
				</p>
			</ConfirmDialog>
		</>
	)
}

export const CloudConnectionStatus = () =>
	window.CODE_SNIPPETS?.isCloudConnected ? <DisconnectButton /> : <ConnectButton />
