import React from 'react'
import type { SVGProps } from 'react'

export const PreviewIcon = (props: SVGProps<SVGSVGElement>) =>
	<svg width="22" height="15" viewBox="0 0 22 15" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
		<path
			d="M8.58333 7.5C8.58333 8.07464 8.81161 8.62574 9.21794 9.03206C9.62426 9.43839 10.1754 9.66667 10.75 9.66667C11.3246 9.66667 11.8757 9.43839 12.2821 9.03206C12.6884 8.62574 12.9167 8.07464 12.9167 7.5C12.9167 6.92536 12.6884 6.37426 12.2821 5.96794C11.8757 5.56161 11.3246 5.33333 10.75 5.33333C10.1754 5.33333 9.62426 5.56161 9.21794 5.96794C8.81161 6.37426 8.58333 6.92536 8.58333 7.5Z"
			stroke="#2271B1"
			strokeWidth="2"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path d="M20.5 7.5C17.9 11.8333 14.65 14 10.75 14C6.85 14 3.6 11.8333 1 7.5C3.6 3.16667 6.85 1 10.75 1C14.65 1 17.9 3.16667 20.5 7.5Z" stroke="#2271B1" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
	</svg>
