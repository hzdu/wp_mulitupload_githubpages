import React from 'react'
import type { SVGProps } from 'react'

export const CloudDisconnectedIcon: React.FC<SVGProps<SVGSVGElement>> = props =>
	<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
		<path
			d="M10.3777 6.01033C10.6377 5.89117 10.9107 5.78608 11.1923 5.7005C13.229 5.08083 15.478 5.49142 17.09 6.78383C18.702 8.073 19.4322 10.0414 19.0075 11.9503H20.08C22.1524 11.9503 23.8327 13.6403 23.8327 15.7268C23.8327 16.7635 23.4178 17.7028 22.7461 18.3853M19.4993 19.5043H7.2111C4.42477 19.5 2.16602 17.3258 2.16602 14.6434C2.16602 11.9622 4.42477 9.78792 7.2111 9.78792C7.35193 9.15742 7.61193 8.56592 7.96943 8.03292M3.24935 3.25L22.7493 22.75"
			stroke="#DE6D6D"
			strokeWidth="2"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</svg>
