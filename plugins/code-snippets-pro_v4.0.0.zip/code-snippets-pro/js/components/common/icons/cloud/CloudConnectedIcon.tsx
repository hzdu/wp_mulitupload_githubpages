import React from 'react'
import type { SVGProps } from 'react'

export const CloudConnectedIcon: React.FC<SVGProps<SVGSVGElement>> = props =>
	<svg width="24" height="20" viewBox="0 0 24 20" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
		<path
			d="M10.75 15.0875H6.04508C3.25875 15.0832 1 12.909 1 10.2266C1 7.54538 3.25875 5.37112 6.04508 5.37112C6.47083 3.46229 7.98858 1.90446 10.0263 1.28371C12.063 0.664041 14.312 1.07462 15.924 2.36704C17.536 3.65621 18.2662 5.62462 17.8415 7.53346H18.914C20.4177 7.53346 21.7144 8.42179 22.3135 9.70771M15.0833 16.1665L17.25 18.3332L21.5833 13.9999"
			stroke="#42A240"
			strokeWidth="2"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</svg>
