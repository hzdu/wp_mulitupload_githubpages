import React, { Fragment } from 'react'
import { Modal } from '@wordpress/components'
import { __, _x } from '@wordpress/i18n'
import { CONDITION_OPERATOR_LABELS } from '../../types/conditions/ConditionGroups'
import { CONDITION_SUBJECTS } from '../../utils/conditions/subjects'
import type { ConditionOperator } from '../../types/conditions/ConditionGroups'

interface ConditionRuleLike {
	subject?: string
	operator?: string
	object?: unknown
}

const isRecord = (value: unknown): value is object =>
	null !== value && 'object' === typeof value

/**
 * Parse stored condition code into groups of rules. Conditions saved by the
 * editor store groups and rules as keyed records, while cloud-deployed
 * conditions store plain arrays, so both shapes are accepted.
 */
const parseConditionGroups = (code: string): ConditionRuleLike[][] => {
	try {
		const parsed: unknown = JSON.parse(code)

		if (!isRecord(parsed)) {
			return []
		}

		const groups: unknown[] = Array.isArray(parsed) ? parsed : Object.values(parsed)

		return groups
			.filter(isRecord)
			.map(group => (Array.isArray(group) ? group : Object.values(group)).filter(isRecord))
			.filter(rules => 0 < rules.length)
	} catch {
		return []
	}
}

const getSubjectLabel = (subject?: string): string =>
	subject
		? (CONDITION_SUBJECTS as Partial<Record<string, { label: string }>>)[subject]?.label ?? subject
		: ''

const getOperatorLabel = (operator?: string): string =>
	operator && operator in CONDITION_OPERATOR_LABELS
		? CONDITION_OPERATOR_LABELS[operator as ConditionOperator]
		: operator ?? ''

const getObjectText = (object: unknown): string =>
	Array.isArray(object) ? object.map(value => String(value)).join(', ') : ''

interface ConditionRuleTextProps {
	rule: ConditionRuleLike
	isLast: boolean
}

const ConditionRuleText: React.FC<ConditionRuleTextProps> = ({ rule, isLast }) =>
	<li>
		<strong>{getSubjectLabel(rule.subject)}</strong>
		{' '}
		<em>{getOperatorLabel(rule.operator)}</em>
		{' '}
		{getObjectText(rule.object)}
		{isLast ? '' : ` ${_x('and', 'boolean logical operator', 'code-snippets')}`}
	</li>

export interface ConditionPreviewModalProps {
	title: string
	code: string
	setIsOpen: (isOpen: boolean) => void
}

/**
 * Modal showing a readable summary of a condition snippet's rule groups:
 * rules joined with 'and' within a group, groups separated by 'OR'.
 */
export const ConditionPreviewModal: React.FC<ConditionPreviewModalProps> = ({ title, code, setIsOpen }) => {
	const groups = parseConditionGroups(code)

	return (
		<Modal onRequestClose={() => setIsOpen(false)} title={title}>
			{0 < groups.length
				? <div className="condition-preview">
					{groups.map((rules, groupIndex) =>
						<Fragment key={`group-${groupIndex}`}>
							{0 < groupIndex &&
								<p className="condition-preview-separator">
									{_x('OR', 'condition group separator', 'code-snippets')}
								</p>}
							<ul className="condition-preview-group">
								{rules.map((rule, ruleIndex) =>
									<ConditionRuleText
										key={`rule-${groupIndex}-${ruleIndex}`}
										rule={rule}
										isLast={ruleIndex === rules.length - 1}
									/>)}
							</ul>
						</Fragment>)}
				</div>
				: <p>{__('This condition has no rules to display.', 'code-snippets')}</p>}
		</Modal>
	)
}
