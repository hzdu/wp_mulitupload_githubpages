import React, { useState } from 'react'
import { isLicensed } from '../../../../utils/screen'
import { isCondition } from '../../../../utils/snippets/snippets'
import { Button } from '../../../common/Button'
import { CloudConnectModal } from '../../../common/cloud/CloudConnectModal'
import { GenerateIcon } from '../../../common/icons/GenerateIcon'
import type { ButtonProps } from '../../../common/Button'
import type { Snippet } from '../../../../types/Snippet'

export interface CloudAIButtonProps extends ButtonProps {
	snippet: Snippet
}

export const CloudAIButton: React.FC<CloudAIButtonProps> = ({
	snippet,
	children,
	onClick,
	disabled,
	...props
}) => {
	const [isCloudModalOpen, setIsCloudModalOpen] = useState(false)

	return isLicensed() && !isCondition(snippet)
		? <>
			{isCloudModalOpen && (
				<CloudConnectModal
					openBlank
					icon={<GenerateIcon />}
					onRequestClose={() => setIsCloudModalOpen(false)}
				/>)}

			<Button small {...props} onClick={event => {
				if (window.CODE_SNIPPETS?.isCloudConnected) {
					onClick?.(event)
				} else {
					setIsCloudModalOpen(true)
				}
			}}>
				<GenerateIcon />
				{' '}{children}
			</Button>
		</>
		: null
}
