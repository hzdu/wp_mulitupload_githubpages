import React from 'react'
import { __, _x } from '@wordpress/i18n'
import { FormTokenField } from '@wordpress/components'
import { useSnippetForm } from '../WithSnippetFormContext'
import { ExplainSnippetButton } from './ExplainSnippetButton'

const options = window.CODE_SNIPPETS_EDIT?.tagOptions

export const TagsEditor: React.FC = () => {
	const { snippet, setSnippet, isReadOnly } = useSnippetForm()

	return options?.enabled
		? <div className="snippet-tags-container">

			<ExplainSnippetButton
				field="tags"
				onResponse={generated => {
					setSnippet(previous => ({
						...previous,
						tags: [...new Set([...previous.tags, ...generated.tags ?? []])]
					}))
				}}
			>
				{_x('Add', 'generate snippet tags', 'code-snippets')}
			</ExplainSnippetButton>

			<FormTokenField
				label={__('Snippet Tags', 'code-snippets')}
				value={snippet.tags}
				disabled={isReadOnly}
				suggestions={options.availableTags}
				tokenizeOnBlur
				tokenizeOnSpace={!options.allowSpaces}
				onChange={tokens => {
					setSnippet(previous => ({
						...previous,
						tags: tokens.map(token => 'string' === typeof token ? token : token.value)
					}))
				}}
			/>
		</div>
		: null
}
