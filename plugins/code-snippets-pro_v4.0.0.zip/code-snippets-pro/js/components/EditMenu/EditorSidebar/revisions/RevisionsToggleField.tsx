import React, { useId } from 'react'
import { __ } from '@wordpress/i18n'
import { useRevisionsAPI } from '../../../../hooks/useRevisionsAPI'
import { useSnippetForm } from '../../SnippetForm/WithSnippetFormContext'
import { Tooltip } from '../../../common/Tooltip'

export interface RevisionsToggleFieldProps {
	disabled: boolean
	onChange: (disabled: boolean) => void
}

export const RevisionsToggleField: React.FC<RevisionsToggleFieldProps> = ({ disabled, onChange }) => {
	const { snippet, isReadOnly } = useSnippetForm()
	const revisionsAPI = useRevisionsAPI()
	const toggleId = useId()

	const handleToggle = () => {
		if (snippet.id) {
			void revisionsAPI.updateSettings(snippet.id, !disabled, snippet.network)
				.then(settings => onChange(settings.disabled))
		}
	}

	return (
		<div className="revisions-editor-header">
			<strong className="revisions-editor-title">{__('Revisions', 'code-snippets')}</strong>

			<Tooltip block>
				{__('Automatically save a copy of this snippet each time it changes, so earlier versions can be reviewed and restored.', 'code-snippets')}
			</Tooltip>

			<span className="status-text">
				{disabled
					? __('Disabled', 'code-snippets')
					: __('Enabled', 'code-snippets')}
			</span>

			<input
				id={toggleId}
				type="checkbox"
				className="switch"
				aria-label={__('Enable revision history', 'code-snippets')}
				checked={!disabled}
				disabled={isReadOnly}
				onChange={handleToggle}
			/>
		</div>
	)
}
