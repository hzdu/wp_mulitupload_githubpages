import React, { useState } from 'react'
import { __, sprintf } from '@wordpress/i18n'
import { useRevisionsAPI } from '../../../../hooks/useRevisionsAPI'
import { useSnippetForm } from '../../SnippetForm/WithSnippetFormContext'
import { ConfirmDialog } from '../../../common/ConfirmDialog'
import type { Revision } from '../../../../types/Revision'

export interface RestoreRevisionDialogProps {
	revision?: Revision
	onCancel: VoidFunction
}

export const RestoreRevisionDialog: React.FC<RestoreRevisionDialogProps> = ({ revision, onCancel }) => {
	const { snippet } = useSnippetForm()
	const revisionsAPI = useRevisionsAPI()
	const [isRestoring, setIsRestoring] = useState(false)

	const handleRestore = () => {
		if (!revision || !snippet.id) {return}

		setIsRestoring(true)
		revisionsAPI.restore(snippet.id, revision.id, snippet.network)
			// The editor is reloaded so that every field reflects the restored version.
			.then(() => window.location.reload())
			.catch(() => undefined)
			.finally(() => setIsRestoring(false))
	}

	return (
		<ConfirmDialog
			open={undefined !== revision}
			title={__('Restore Revision', 'code-snippets')}
			onConfirm={handleRestore}
			onCancel={onCancel}
			confirmLabel={isRestoring
				? __('Restoring…', 'code-snippets')
				: __('Restore', 'code-snippets')}
			cancelLabel={__('Cancel', 'code-snippets')}
		>
			<p>
				{sprintf(
					/* translators: %d: revision number */
					__('Are you sure you want to restore revision #%d? Your current version stays in the history, so you can switch back to it.', 'code-snippets'),
					revision?.revision_number ?? 0
				)}
			</p>
		</ConfirmDialog>
	)
}
