import React, { useState } from 'react'
import { __ } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { useSnippetRevisions } from '../../../../hooks/useSnippetRevisions'
import { useSnippetForm } from '../../SnippetForm/WithSnippetFormContext'
import { Badge } from '../../../common/Badge'
import { Button } from '../../../common/Button'
import { RestoreRevisionDialog } from './RestoreRevisionDialog'
import { RevisionDiffView } from './RevisionDiffView'
import { RevisionsToggleField } from './RevisionsToggleField'
import type { Revision } from '../../../../types/Revision'

export const RevisionHistory: React.FC = () => {
	const { snippet } = useSnippetForm()
	const { revisions, isLoading, versioningDisabled, setVersioningDisabled, deleteRevision } = useSnippetRevisions()

	const [selectedRevision, setSelectedRevision] = useState<Revision>()
	const [confirmRestore, setConfirmRestore] = useState<Revision>()

	if (!snippet.id) {return null}

	// Deleting the revision on screen moves the modal on to the next one along,
	// rather than dropping the user back to the sidebar.
	const handleDelete = (revision: Revision) =>
		void deleteRevision(revision).then(remaining => {
			if (selectedRevision?.id === revision.id) {
				setSelectedRevision(remaining[0])
			}
		})

	return (
		<div className="revisions-editor-open block-form-field">
			<RevisionsToggleField disabled={versioningDisabled} onChange={setVersioningDisabled} />

			{!isLoading && 0 === revisions.length &&
				<p className="revision-empty-message">
					{__('No revisions yet. Revisions are created automatically when you save changes.', 'code-snippets')}
				</p>}

			{!versioningDisabled && 0 < revisions.length && <>
				<Button
					large
					disabled={isLoading}
					onClick={() => setSelectedRevision(revisions[0])}
				>
					<Badge name="revisions" small />
					{__('Manage Revisions', 'code-snippets')}
					{isLoading
						? <Spinner />
						: <span className="revisions-count">{revisions.length}</span>}
				</Button>

				{selectedRevision &&
					<RevisionDiffView
						revision={selectedRevision}
						currentSnippet={snippet}
						revisions={revisions}
						onClose={() => setSelectedRevision(undefined)}
						onChangeRevision={setSelectedRevision}
						onRestore={setConfirmRestore}
						onDelete={handleDelete}
					/>}

				<RestoreRevisionDialog revision={confirmRestore} onCancel={() => setConfirmRestore(undefined)} />
			</>}
		</div>
	)
}
