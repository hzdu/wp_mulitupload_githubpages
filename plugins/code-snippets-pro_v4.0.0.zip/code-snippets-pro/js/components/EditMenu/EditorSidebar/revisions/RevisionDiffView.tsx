import React, { useMemo, useState } from 'react'
import classnames from 'classnames'
import { __, sprintf } from '@wordpress/i18n'
import { Button, Modal } from '@wordpress/components'
import { dateI18n } from '@wordpress/date'
import { computeLineDiff } from '../../../../utils/diff'
import type { DiffRow } from '../../../../utils/diff'
import type { Revision } from '../../../../types/Revision'
import type { Snippet } from '../../../../types/Snippet'

type DiffViewMode = 'side-by-side' | 'stacked'

export interface RevisionDiffViewProps {
	revision: Revision
	currentSnippet: Snippet
	revisions: Revision[]
	onClose: VoidFunction
	onChangeRevision: (revision: Revision) => void
	/** Ask to restore the revision on screen. The confirmation dialog lives in the sidebar panel. */
	onRestore?: (revision: Revision) => void
	/** Permanently delete the revision on screen. */
	onDelete?: (revision: Revision) => void
}

interface MetadataChange {
	field: string
	oldValue: string
	newValue: string
}

// Changes read left to right — from the current snippet to the revision — so a
// row states what restoring the revision would do, matching the diff panels.
const getMetadataChanges = (revision: Revision, snippet: Snippet): MetadataChange[] => {
	const changes: MetadataChange[] = []
	const snap = revision.snapshot

	if (snap.name !== snippet.name) {
		changes.push({ field: __('Name', 'code-snippets'), oldValue: snippet.name, newValue: snap.name })
	}
	if (snap.scope !== snippet.scope) {
		changes.push({ field: __('Scope', 'code-snippets'), oldValue: snippet.scope, newValue: snap.scope })
	}
	if (snap.priority !== snippet.priority) {
		changes.push({
			field: __('Priority', 'code-snippets'),
			oldValue: String(snippet.priority),
			newValue: String(snap.priority),
		})
	}
	if (JSON.stringify(snap.tags) !== JSON.stringify(snippet.tags)) {
		changes.push({
			field: __('Tags', 'code-snippets'),
			oldValue: snippet.tags.join(', '),
			newValue: snap.tags.join(', '),
		})
	}
	if (snap.desc !== snippet.desc) {
		changes.push({ field: __('Description', 'code-snippets'), oldValue: '(changed)', newValue: '(changed)' })
	}

	// The condition gates when the snippet runs and IS restored, so a change to
	// it has to appear here — restoring it silently would change execution
	// behaviour with nothing in the preview to show for it.
	if (snap.condition_id !== snippet.conditionId) {
		changes.push({
			field: __('Condition', 'code-snippets'),
			oldValue: snippet.conditionId ? `#${snippet.conditionId}` : __('None', 'code-snippets'),
			newValue: snap.condition_id ? `#${snap.condition_id}` : __('None', 'code-snippets'),
		})
	}

	return changes
}

// ---- Internal sub-components --------------------------------------------

interface DiffNavProps {
	hasPrev: boolean
	hasNext: boolean
	onPrev: VoidFunction
	onNext: VoidFunction
}

const DiffNav: React.FC<DiffNavProps> = ({ hasPrev, hasNext, onPrev, onNext }) =>
	<div className="revision-diff-nav-buttons">
		<Button variant="secondary" onClick={onPrev} disabled={!hasPrev} size="small">
			<span className="dashicons dashicons-arrow-left-alt2" aria-hidden="true" />
			{__('Previous', 'code-snippets')}
		</Button>
		<Button variant="secondary" onClick={onNext} disabled={!hasNext} size="small">
			{__('Next', 'code-snippets')}
			<span className="dashicons dashicons-arrow-right-alt2" aria-hidden="true" />
		</Button>
	</div>

interface ViewToggleProps {
	viewMode: DiffViewMode
	setViewMode: (mode: DiffViewMode) => void
}

const ViewToggle: React.FC<ViewToggleProps> = ({ viewMode, setViewMode }) =>
	<div
		className="revision-diff-view-toggle"
		role="group"
		aria-label={__('Diff view mode', 'code-snippets')}
	>
		<button
			type="button"
			className={classnames('revision-diff-view-toggle-segment', { 'is-active': 'side-by-side' === viewMode })}
			onClick={() => setViewMode('side-by-side')}
			aria-pressed={'side-by-side' === viewMode}
		>
			{__('Side by Side', 'code-snippets')}
		</button>
		<button
			type="button"
			className={classnames('revision-diff-view-toggle-segment', { 'is-active': 'stacked' === viewMode })}
			onClick={() => setViewMode('stacked')}
			aria-pressed={'stacked' === viewMode}
		>
			{__('Stacked', 'code-snippets')}
		</button>
	</div>

interface RevisionSidebarProps {
	revisions: Revision[]
	activeId: number
	onChangeRevision: (revision: Revision) => void
}

const RevisionSidebar: React.FC<RevisionSidebarProps> = ({ revisions, activeId, onChangeRevision }) => {
	const [sortAscending, setSortAscending] = useState(false)

	// Positions come from the newest-first order the API returns, so a given
	// revision keeps its number — 1 is always the most recent — whichever way
	// the list is sorted.
	const numbered = revisions.map((revision, index) => ({
		revision,
		label: sprintf(
			/* translators: 1: position in the list, 2: formatted date and time */
			__('%1$d. %2$s', 'code-snippets'),
			index + 1,
			// Revision dates are stored in UTC; the suffix stops them being read as
			// local time before conversion to the site timezone.
			dateI18n('jS M Y H:i:s', `${revision.date}Z`)
		),
		isLatest: 0 === index
	}))

	return (
		<aside className="revision-diff-sidebar">
			<div className="revision-diff-sidebar-header">
				<h4 className="revision-diff-sidebar-heading">{__('Revision History', 'code-snippets')}</h4>

				<button
					type="button"
					className="revision-diff-sort-toggle"
					onClick={() => setSortAscending(!sortAscending)}
					aria-label={sortAscending
						? __('Sorted oldest first. Sort newest first instead.', 'code-snippets')
						: __('Sorted newest first. Sort oldest first instead.', 'code-snippets')}
				>
					<span
						className={`dashicons dashicons-arrow-${sortAscending ? 'up' : 'down'}-alt`}
						aria-hidden="true"
					/>
					{sortAscending
						? __('Oldest', 'code-snippets')
						: __('Newest', 'code-snippets')}
				</button>
			</div>

			{(sortAscending ? [...numbered].reverse() : numbered).map(({ revision, label, isLatest }) => (
				<button
					key={revision.id}
					type="button"
					className={classnames('revision-diff-sidebar-item', { 'is-active': revision.id === activeId })}
					onClick={() => onChangeRevision(revision)}
					aria-current={revision.id === activeId}
				>
					<span className="revision-diff-sidebar-label">{label}</span>

					{isLatest &&
						<span className="revision-diff-sidebar-badge">{__('Latest Revision', 'code-snippets')}</span>}
				</button>
			))}
		</aside>
	)
}

interface MetadataChangesCardProps {
	changes: MetadataChange[]
}

const MetadataChangesCard: React.FC<MetadataChangesCardProps> = ({ changes }) =>
	<div className="revision-metadata-changes">
		<h4 className="revision-section-heading">{__('Metadata Changes', 'code-snippets')}</h4>
		<ul>
			{changes.map((change, index) => (
				<li key={index}>
					<strong>{change.field}:</strong>{' '}
					<span className="diff-removed">{change.oldValue}</span>
					{' → '}
					<span className="diff-added">{change.newValue}</span>
				</li>
			))}
		</ul>
	</div>

interface SideBySidePanelsProps {
	codeDiff: DiffRow[]
	revisionNumber: number
}

const sideRowClass = (row: DiffRow, side: 'left' | 'right'): string =>
	classnames('diff-cell', `diff-cell-${side}`, {
		'diff-cell-removed': 'left' === side && ('removed' === row.type || 'modified' === row.type),
		'diff-cell-added': 'right' === side && ('added' === row.type || 'modified' === row.type)
	})

const SideBySidePanels: React.FC<SideBySidePanelsProps> = ({ codeDiff, revisionNumber }) =>
	<>
		<div className="diff-panel-headers">
			<div className="diff-panel-header">{__('Current', 'code-snippets')}</div>
			<div className="diff-panel-header">
				{sprintf(
					/* translators: %d: revision number */
					__('Revision #%d', 'code-snippets'),
					revisionNumber
				)}
			</div>
		</div>

		<div className="diff-panels">
			<div className="diff-panel diff-panel-left">
				<table className="diff-table">
					<tbody>
						{codeDiff.map((row, index) => (
							<tr key={index} className={`diff-row diff-row-${row.type}`}>
								<td className="diff-line-num diff-line-num-left">{row.leftLineNum ?? ''}</td>
								<td className={sideRowClass(row, 'left')}>
									<code>{row.leftContent ?? ''}</code>
								</td>
							</tr>
						))}
					</tbody>
				</table>
			</div>
			<div className="diff-panel diff-panel-right">
				<table className="diff-table">
					<tbody>
						{codeDiff.map((row, index) => (
							<tr key={index} className={`diff-row diff-row-${row.type}`}>
								<td className="diff-line-num diff-line-num-right">{row.rightLineNum ?? ''}</td>
								<td className={sideRowClass(row, 'right')}>
									<code>{row.rightContent ?? ''}</code>
								</td>
							</tr>
						))}
					</tbody>
				</table>
			</div>
		</div>
	</>

interface StackedRowProps {
	rowKey: string
	rowClass: string
	leftNum: number | string
	rightNum: number | string
	cellClass: string
	prefix: string
	content: string
}

const StackedRow: React.FC<StackedRowProps> = ({ rowKey, rowClass, leftNum, rightNum, cellClass, prefix, content }) =>
	<tr key={rowKey} className={rowClass}>
		<td className="diff-line-num diff-line-num-left">{leftNum}</td>
		<td className="diff-line-num diff-line-num-right">{rightNum}</td>
		<td className={cellClass}>
			<code>
				<span className="diff-prefix">{prefix}</span>{content}
			</code>
		</td>
	</tr>

const buildUnchangedRow = (row: DiffRow, key: string) =>
	<StackedRow
		key={key}
		rowKey={key}
		rowClass="diff-row diff-row-unchanged"
		leftNum={row.leftLineNum ?? ''}
		rightNum={row.rightLineNum ?? ''}
		cellClass="diff-cell diff-cell-stacked"
		prefix=" "
		content={row.leftContent ?? ''}
	/>

const buildRemovedRow = (row: DiffRow, key: string) =>
	<StackedRow
		key={key}
		rowKey={key}
		rowClass="diff-row diff-row-removed"
		leftNum={row.leftLineNum ?? ''}
		rightNum=""
		cellClass="diff-cell diff-cell-stacked diff-cell-removed"
		prefix="−"
		content={row.leftContent ?? ''}
	/>

const buildAddedRow = (row: DiffRow, key: string) =>
	<StackedRow
		key={key}
		rowKey={key}
		rowClass="diff-row diff-row-added"
		leftNum=""
		rightNum={row.rightLineNum ?? ''}
		cellClass="diff-cell diff-cell-stacked diff-cell-added"
		prefix="+"
		content={row.rightContent ?? ''}
	/>

const buildModifiedRows = (row: DiffRow, key: string) => [
	buildRemovedRow(row, `${key}-r`),
	buildAddedRow(row, `${key}-a`),
]

const buildStackedRows = (codeDiff: DiffRow[]): React.ReactNode[] =>
	codeDiff.flatMap((row, index) => {
		const key = `r${index}`
		switch (row.type) {
			case 'unchanged': return [buildUnchangedRow(row, key)]
			case 'removed': return [buildRemovedRow(row, key)]
			case 'added': return [buildAddedRow(row, key)]
			case 'modified': return buildModifiedRows(row, key)
			default: return []
		}
	})

const StackedPanel: React.FC<{ codeDiff: DiffRow[] }> = ({ codeDiff }) =>
	<div className="diff-panel diff-panel-stacked">
		<table className="diff-table">
			<tbody>{buildStackedRows(codeDiff)}</tbody>
		</table>
	</div>

interface CodeChangesSectionProps {
	hasCodeChanges: boolean
	viewMode: DiffViewMode
	setViewMode: (mode: DiffViewMode) => void
	codeDiff: DiffRow[]
	revisionNumber: number
}

const CodeChangesSection: React.FC<CodeChangesSectionProps> = ({
	hasCodeChanges, viewMode, setViewMode, codeDiff, revisionNumber,
}) =>
	<div className="revision-code-diff">
		<div className="revision-code-diff-toolbar">
			{!hasCodeChanges &&
				<p className="revision-no-changes-notice">
					{__('No code changes in this revision.', 'code-snippets')}
				</p>}

			<ViewToggle viewMode={viewMode} setViewMode={setViewMode} />
		</div>

		{'side-by-side' === viewMode
			? <SideBySidePanels codeDiff={codeDiff} revisionNumber={revisionNumber} />
			: <StackedPanel codeDiff={codeDiff} />}
	</div>

interface DiffContentProps {
	metadataChanges: MetadataChange[]
	hasCodeChanges: boolean
	viewMode: DiffViewMode
	setViewMode: (mode: DiffViewMode) => void
	codeDiff: DiffRow[]
	revisionNumber: number
}

const DiffContent: React.FC<DiffContentProps> = ({
	metadataChanges, hasCodeChanges, viewMode, setViewMode, codeDiff, revisionNumber,
}) =>
	<div className="revision-diff-content">
		{0 < metadataChanges.length && <MetadataChangesCard changes={metadataChanges} />}
		<CodeChangesSection
			hasCodeChanges={hasCodeChanges}
			viewMode={viewMode}
			setViewMode={setViewMode}
			codeDiff={codeDiff}
			revisionNumber={revisionNumber}
		/>
	</div>

interface DiffFooterProps {
	revision: Revision
	revisions: Revision[]
	isCurrent: boolean
	onChangeRevision: (revision: Revision) => void
	onClose: VoidFunction
	onRestore?: (revision: Revision) => void
	onDelete?: (revision: Revision) => void
}

const DiffFooter: React.FC<DiffFooterProps> = ({
	revision, revisions, isCurrent, onChangeRevision, onClose, onRestore, onDelete,
}) => {
	// Revisions are listed newest first, so 'previous' steps further back in time.
	const currentIndex = revisions.findIndex(rev => rev.id === revision.id)
	const hasPrev = currentIndex < revisions.length - 1
	const hasNext = 0 < currentIndex

	return <div className="revision-diff-actions">
		{onDelete &&
			<Button variant="link" className="revision-delete-button" onClick={() => onDelete(revision)}>
				{__('Delete Revision', 'code-snippets')}
			</Button>}

		<DiffNav
			hasPrev={hasPrev}
			hasNext={hasNext}
			onPrev={() => hasPrev && onChangeRevision(revisions[currentIndex + 1])}
			onNext={() => hasNext && onChangeRevision(revisions[currentIndex - 1])}
		/>

		{onRestore &&
			<Button
				variant="primary"
				onClick={() => onRestore(revision)}
				disabled={isCurrent}
				label={isCurrent ? __('This version is already in use.', 'code-snippets') : undefined}
			>
				{__('Restore This Revision', 'code-snippets')}
			</Button>}

		<Button variant="secondary" onClick={onClose}>{__('Close', 'code-snippets')}</Button>
	</div>
}

// ---- Main component -----------------------------------------------------

export const RevisionDiffView: React.FC<RevisionDiffViewProps> = props => {
	const { revision, currentSnippet, revisions, onClose, onChangeRevision, onRestore, onDelete } = props
	const [viewMode, setViewMode] = useState<DiffViewMode>('side-by-side')
	const codeDiff = useMemo(
		// Current first: the left column holds the live snippet and the right the
		// revision, so removals are what restoring would drop.
		() => computeLineDiff(currentSnippet.code, revision.snapshot.code),
		[currentSnippet.code, revision.snapshot.code]
	)
	const metadataChanges = useMemo(
		() => getMetadataChanges(revision, currentSnippet),
		[revision, currentSnippet]
	)
	const hasCodeChanges = codeDiff.some(row => 'unchanged' !== row.type)
	return (
		<Modal
			title={__('Manage Revisions', 'code-snippets')}
			onRequestClose={onClose}
			className="revision-diff-modal"
			isDismissible
		>
			<p className="revision-diff-subtitle">
				{__('You can compare revision history of this snippet here and restore to a previous version.', 'code-snippets')}
			</p>

			<div className="revision-diff-body">
				<RevisionSidebar revisions={revisions} activeId={revision.id} onChangeRevision={onChangeRevision} />

				<DiffContent
					metadataChanges={metadataChanges}
					hasCodeChanges={hasCodeChanges}
					viewMode={viewMode}
					setViewMode={setViewMode}
					codeDiff={codeDiff}
					revisionNumber={revision.revision_number}
				/>
			</div>

			<DiffFooter
				revision={revision}
				revisions={revisions}
				isCurrent={!hasCodeChanges && 0 === metadataChanges.length}
				onChangeRevision={onChangeRevision}
				onClose={onClose}
				onRestore={onRestore}
				onDelete={onDelete}
			/>
		</Modal>
	)
}
