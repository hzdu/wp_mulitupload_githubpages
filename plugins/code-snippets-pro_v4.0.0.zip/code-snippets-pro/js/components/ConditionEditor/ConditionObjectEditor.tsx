import React, { useMemo, useState } from 'react'
import { __, _x } from '@wordpress/i18n'
import { getConditionRule, updateConditionRule } from '../../utils/conditions/rules'
import { Select } from '../common/Select'
import type { ConditionOperator, ConditionRule } from '../../types/conditions/ConditionGroups'
import type { ConditionSubject, ConditionSubjects } from '../../types/conditions/ConditionSubject'
import type { ChangeEventHandler, Dispatch, SetStateAction } from 'react'
import type { SelectGroups, SelectOption, SelectOptions } from '../../types/SelectOption'
import type { Snippet } from '../../types/Snippet'
import type { ConditionRuleEditorProps } from './ConditionRuleEditor'
import type { InputAction, InputActionMeta } from 'react-select'

const singleOps = new Set<ConditionOperator>(['is', 'not'])
const multiOps = new Set<ConditionOperator>(['in', 'not in'])
const dateOps = new Set<ConditionOperator>(['before', 'after', 'between'])
const booleanOps = new Set<ConditionOperator>(['true', 'false'])

const standardOps = new Set<ConditionOperator>([...singleOps, ...multiOps])
const unaryOps = new Set<ConditionOperator>([...singleOps, ...booleanOps])

const getValueKey = (value: unknown): string => {
	if ('string' === typeof value) {
		return value
	}

	if ('number' === typeof value) {
		return value.toString()
	}

	return JSON.stringify(value)
}

const prioritizeSelectedOptions = <T, >(options: SelectGroups<T>, selectedValues: readonly T[]): SelectGroups<T> => {
	if (0 === selectedValues.length) {
		return options
	}

	const selectedKeys = new Set<string>(selectedValues.map(getValueKey))
	const selectedOptions: SelectOption<T>[] = []
	const selectedSeen = new Set<string>()
	const remaining: ((typeof options)[number])[] = []

	const shouldKeepOption = (option: SelectOption<T>): boolean => {
		const optionKey = getValueKey(option.key ?? option.value)

		if (!selectedKeys.has(optionKey)) {
			return true
		}

		if (!selectedSeen.has(optionKey)) {
			selectedSeen.add(optionKey)
			selectedOptions.push(option)
		}

		return false
	}

	for (const entry of options) {
		if ('options' in entry) {
			const filteredOptions = entry.options.filter(shouldKeepOption)

			if (0 < filteredOptions.length) {
				remaining.push({ ...entry, options: filteredOptions })
			}
		} else if (shouldKeepOption(entry)) {
			remaining.push(entry)
		}
	}

	return [...selectedOptions, ...remaining]
}

const normalizeSelectedValues = <S extends ConditionSubject>(
	rule: ConditionRule<S> | undefined,
	isMulti: boolean
): ConditionSubjects[S][] => {
	if (isMulti) {
		return rule?.object ?? []
	}

	return rule?.object?.[0] === undefined
		? []
		: [rule.object[0]]
}

const triggerSearchActionMeta = new Set<InputAction>(['input-change', 'input-blur', 'menu-close'])

interface ObjectSelectProps<S extends ConditionSubject> extends ConditionRuleEditorProps {
	isMulti?: boolean
	options: SelectGroups<ConditionSubjects[S]>
	optionsLoaded: boolean
	onLoadMore: VoidFunction
	onSearch?: (query: string) => void
	searchingOptions?: boolean
}

const ObjectSelect = <S extends ConditionSubject>({
	ruleId,
	groupId,
	options,
	condition,
	onLoadMore,
	setCondition,
	optionsLoaded,
	isMulti = false,
	onSearch,
	searchingOptions
}: ObjectSelectProps<S>) => {
	const rule = getConditionRule(condition, groupId, ruleId)
	const selectedValues = normalizeSelectedValues(rule, isMulti)

	const prioritizedOptions = useMemo(
		() => prioritizeSelectedOptions(options, selectedValues),
		[selectedValues, options])

	return (
		<Select
			required
			className="snippet-condition-field snippet-condition-object"
			isDisabled={setCondition === undefined}
			isMulti={isMulti}
			menuShouldBlockScroll={true}
			options={prioritizedOptions}
			currentValue={isMulti ? rule?.object : rule?.object?.[0]}
			isLoading={!optionsLoaded || !!searchingOptions}
			onMenuScrollToBottom={searchingOptions ? undefined : onLoadMore}
			onInputChange={(value, { action }: InputActionMeta) => {
				if (triggerSearchActionMeta.has(action)) {
					onSearch?.('input-change' === action ? value : '')
				}

				return value
			}}
			onMenuClose={() => onSearch?.('')}
			onSelect={value => {
				setCondition?.(previous =>
					updateConditionRule(previous, groupId, ruleId, { object: undefined === value ? [] : [value] }))
			}}
			onSelectMulti={values => {
				setCondition?.(previous =>
					updateConditionRule(previous, groupId, ruleId, { object: values }))
			}}
		/>
	)
}

interface OperatorSelectProps {
	ruleId: string
	groupId: string
	options: SelectGroups<ConditionOperator>
	setCondition?: Dispatch<SetStateAction<Snippet>>
	currentOperator: ConditionOperator | undefined
}

const OperatorSelect: React.FC<OperatorSelectProps> = ({ options, currentOperator, groupId, ruleId, setCondition }) =>
	<Select
		required
		className="snippet-condition-field snippet-condition-operator"
		isDisabled={setCondition === undefined}
		options={options}
		currentValue={currentOperator}
		onChange={selected => {
			const operator = selected?.value ?? undefined

			setCondition?.(previous =>
				updateConditionRule(previous, groupId, ruleId, previousRule => ({
					operator,
					...operator && unaryOps.has(operator) && previousRule.object
						? { object: [previousRule.object[0]] }
						: {}
				})))
		}}
	/>

interface DateSelectProps extends ConditionRuleEditorProps {
	objectIndex?: number
	label: string
}

const DateSelect: React.FC<DateSelectProps> = ({ ruleId, groupId, condition, setCondition, label, objectIndex = 0 }) => {
	const rule = getConditionRule(condition, groupId, ruleId)

	const [value, setValue] = useState<string>(() =>
		'string' === typeof rule?.object?.[objectIndex] ? rule.object[objectIndex] : '')

	const handleChange: ChangeEventHandler<HTMLInputElement> = event => {
		setValue(event.target.value)

		setCondition?.(previous =>
			updateConditionRule(previous, groupId, ruleId, ({ object }) => {
				const updated = object ? [...object] : []
				updated[objectIndex] = event.target.value
				return { object: updated }
			}))
	}

	return (
		<input
			type={'timeOfDay' === rule?.subject ? 'time' : 'datetime-local'}
			aria-label={label}
			readOnly={setCondition === undefined}
			name={`snippet-condition-date-${objectIndex}`}
			value={value}
			required
			onChange={handleChange}
		/>
	)
}

const DateRangeSelect: React.FC<ConditionRuleEditorProps> = ({ ...ruleProps }) =>
	<div className="code-snippets-date-range">
		<DateSelect {...ruleProps} objectIndex={0} label={__('Date range begin', 'code-snippets')} />
		<span className="sep">{_x('to', 'date separator', 'code-snippets')}</span>
		<DateSelect {...ruleProps} objectIndex={1} label={__('Date range end', 'code-snippets')} />
	</div>

export interface ConditionObjectEditorProps<S extends ConditionSubject> extends ConditionRuleEditorProps {
	objectOptions: SelectGroups<ConditionSubjects[S]>
	currentOperator: ConditionOperator | undefined
	operatorOptions: SelectOptions<ConditionOperator>
	objectOptionsLoaded: boolean
	loadMoreOptions: VoidFunction
	setSearchQuery: (query: string) => void
	searchingOptions: boolean
}

export const ConditionObjectEditor = <S extends ConditionSubject>({
	objectOptions,
	currentOperator,
	operatorOptions,
	loadMoreOptions,
	objectOptionsLoaded,
	setSearchQuery,
	searchingOptions,
	...ruleProps
}: ConditionObjectEditorProps<S>) => {
	const ruleOperatorSelect =
		<OperatorSelect {...ruleProps} currentOperator={currentOperator} options={operatorOptions} />

	return (
		<>
			{(!currentOperator || standardOps.has(currentOperator) || dateOps.has(currentOperator)) && ruleOperatorSelect}

			{(!currentOperator || standardOps.has(currentOperator) || booleanOps.has(currentOperator)) && (
				<ObjectSelect
					{...ruleProps}
					options={objectOptions}
					optionsLoaded={objectOptionsLoaded}
					isMulti={currentOperator && multiOps.has(currentOperator)}
					onLoadMore={loadMoreOptions}
					onSearch={setSearchQuery}
					searchingOptions={searchingOptions}
				/>)}

			{currentOperator && dateOps.has(currentOperator) && (
				<div className="snippet-condition-field snippet-condition-object">
					{'between' === currentOperator
						? <DateRangeSelect {...ruleProps} />
						: <DateSelect {...ruleProps} label={__('Date', 'code-snippets')} />}
				</div>)}

			{currentOperator && booleanOps.has(currentOperator) && ruleOperatorSelect}
		</>
	)
}
