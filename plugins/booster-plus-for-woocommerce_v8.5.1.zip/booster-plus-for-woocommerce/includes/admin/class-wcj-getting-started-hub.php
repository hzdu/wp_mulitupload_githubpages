<?php
/**
 * Booster Plus for WooCommerce - Getting Started Hub
 *
 * Dismissible dashboard hub that points merchants to Plus-safe presets.
 *
 * @version 7.9.0
 * @author  Pluggabl LLC.
 * @package Booster_Plus_For_WooCommerce/admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WCJ_Getting_Started_Hub' ) ) :

	/**
	 * WCJ_Getting_Started_Hub Class.
	 */
	class WCJ_Getting_Started_Hub {

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_action( 'wp_ajax_wcj_dismiss_getting_started', array( $this, 'ajax_dismiss_getting_started' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		}

		/**
		 * Whether hub should be displayed.
		 *
		 * @return bool
		 */
		public function should_display() {
			return 'yes' !== get_user_meta( get_current_user_id(), 'wcj_getting_started_dismissed', true );
		}

		/**
		 * Build jobs array from available Plus-safe presets.
		 *
		 * @return array
		 */
		private function get_jobs() {
			if ( ! class_exists( 'WCJ_Presets' ) ) {
				return array();
			}

			$jobs    = array(
				array(
					'id'          => 'pdf_invoicing',
					'title'       => __( 'Branded invoice setup', 'woocommerce-jetpack' ),
					'description' => __( 'Create a starter sample and review before activating.', 'woocommerce-jetpack' ),
					'icon'        => 'dashicons-media-document',
					'preset_link' => WCJ_Invoice_Setup::url(),
				),
			);
			$presets = WCJ_Presets::get_presets();

			foreach ( $presets as $preset ) {
				if ( empty( $preset['id'] ) || empty( $preset['title'] ) ) {
					continue;
				}

				$jobs[] = array(
					'id'          => $preset['id'],
					'title'       => $preset['title'],
					'description' => isset( $preset['description'] ) ? $preset['description'] : '',
					'icon'        => isset( $preset['icon'] ) ? $preset['icon'] : 'dashicons-admin-generic',
					'preset_link' => wp_nonce_url( admin_url( 'admin.php?page=wcj-dashboard&apply_preset=' . $preset['id'] ), 'wcj_apply_preset' ),
				);
			}

			return $jobs;
		}

		/**
		 * Render Getting Started hub.
		 *
		 * @return void
		 */
		public function render() {
			if ( ! $this->should_display() ) {
				return;
			}

			$jobs = $this->get_jobs();
			if ( empty( $jobs ) ) {
				return;
			}
			?>
			<div class="wcj-getting-started-hub" id="wcj-getting-started-hub">
				<div class="wcj-container">
					<div class="wcj-row">
						<div class="wcj-hub-wrapper">
							<div class="wcj-hub-header">
								<h2><?php esc_html_e( 'Getting Started', 'woocommerce-jetpack' ); ?></h2>
								<p><?php esc_html_e( 'Choose what you want to accomplish first with Booster Plus:', 'woocommerce-jetpack' ); ?></p>
								<button class="wcj-hub-dismiss" id="wcj-hub-dismiss" title="<?php esc_attr_e( 'Dismiss', 'woocommerce-jetpack' ); ?>">&times;</button>
							</div>
							<div class="wcj-hub-cards">
								<?php foreach ( $jobs as $job ) : ?>
									<a href="<?php echo esc_url( $job['preset_link'] ); ?>" class="wcj-hub-card" data-job-id="<?php echo esc_attr( $job['id'] ); ?>">
										<span class="dashicons <?php echo esc_attr( $job['icon'] ); ?>"></span>
										<h3><?php echo esc_html( $job['title'] ); ?></h3>
										<p><?php echo esc_html( $job['description'] ); ?></p>
									</a>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * AJAX handler for hub dismissal.
		 *
		 * @return void
		 */
		public function ajax_dismiss_getting_started() {
			check_ajax_referer( 'wcj-hub-nonce', 'nonce' );

			// phpcs:ignore WordPress.WP.Capabilities.Unknown
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_send_json_error( 'Permission denied.' );
			}

			update_user_meta( get_current_user_id(), 'wcj_getting_started_dismissed', 'yes' );
			wp_send_json_success();
		}

		/**
		 * Enqueue hub and filter assets on Booster dashboard/plugins pages.
		 *
		 * @return void
		 */
		public function enqueue_assets() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$active_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';

			if ( 'wcj-dashboard' === $active_page || 'wcj-plugins' === $active_page ) {
				wp_enqueue_style(
					'wcj-hub-css',
					wcj_plugin_url() . '/assets/css/wcj-hub.css',
					array(),
					WCJ()->version
				);

				wp_enqueue_script(
					'wcj-module-filters',
					wcj_plugin_url() . '/assets/js/wcj-module-filters.js',
					array( 'jquery' ),
					WCJ()->version,
					true
				);

				wp_localize_script(
					'wcj-module-filters',
					'wcj_hub_params',
					array(
						'ajax_url' => admin_url( 'admin-ajax.php' ),
						'nonce'    => wp_create_nonce( 'wcj-hub-nonce' ),
					)
				);
			}
		}
	}

endif;
