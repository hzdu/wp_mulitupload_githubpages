<?php
/**
 * Booster Plus for WooCommerce - Module Filters
 *
 * Filter helpers for All/Recommended/Active/Recently Used module views.
 *
 * @version 7.9.0
 * @author  Pluggabl LLC.
 * @package Booster_Plus_For_WooCommerce/admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WCJ_Module_Filters' ) ) :

	/**
	 * WCJ_Module_Filters Class.
	 */
	class WCJ_Module_Filters {

		/**
		 * Recommended modules.
		 *
		 * @var array
		 */
		private $recommended_modules = array(
			'sales_notifications',
			'frequently_bought_together',
			'one_page_checkout',
			'order_numbers',
			'admin_orders_list',
			'currency',
		);

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_action( 'wcj_module_settings_loaded', array( $this, 'track_module_access' ) );
			add_action( 'admin_init', array( $this, 'maybe_track_module_access' ) );
		}

		/**
		 * Get recommended modules list.
		 *
		 * @return array
		 */
		public function get_recommended_modules() {
			$recommended = $this->recommended_modules;
			if ( class_exists( 'WCJ_Presets' ) ) {
				$recommended = array_values(
					array_intersect(
						$recommended,
						WCJ_Presets::get_module_allowlist()
					)
				);
			}
			return apply_filters( 'wcj_recommended_modules', $recommended );
		}

		/**
		 * Get recently used modules.
		 *
		 * @return array
		 */
		public function get_recent_modules() {
			$recent = get_user_meta( get_current_user_id(), 'wcj_recent_modules', true );
			return is_array( $recent ) ? $recent : array();
		}

		/**
		 * Track accessed module for "recently used".
		 *
		 * @param string $module_id Module ID.
		 *
		 * @return void
		 */
		public function track_module_access( $module_id ) {
			if ( empty( $module_id ) ) {
				return;
			}

			$recent = $this->get_recent_modules();
			$recent = array_diff( $recent, array( $module_id ) );
			array_unshift( $recent, $module_id );
			$recent = array_slice( $recent, 0, 10 );

			update_user_meta( get_current_user_id(), 'wcj_recent_modules', $recent );
		}

		/**
		 * Track module access from URL params.
		 *
		 * @return void
		 */
		public function maybe_track_module_access() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$section = isset( $_GET['section'] ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : '';

			if ( 'wcj-plugins' === $page && ! empty( $section ) ) {
				$this->track_module_access( $section );
			}
		}

		/**
		 * Check if module is recommended.
		 *
		 * @param string $module_id Module ID.
		 *
		 * @return bool
		 */
		public function is_recommended( $module_id ) {
			return in_array( $module_id, $this->get_recommended_modules(), true );
		}

		/**
		 * Check if module is active.
		 *
		 * @param string $module_id Module ID.
		 *
		 * @return bool
		 */
		public function is_active( $module_id ) {
			return 'yes' === wcj_get_option( 'wcj_' . $module_id . '_enabled', 'no' );
		}

		/**
		 * Check if module is recently used.
		 *
		 * @param string $module_id Module ID.
		 *
		 * @return bool
		 */
		public function is_recent( $module_id ) {
			return in_array( $module_id, $this->get_recent_modules(), true );
		}

		/**
		 * Get module data attributes for frontend filtering.
		 *
		 * @param string $module_id Module ID.
		 *
		 * @return string
		 */
		public function get_module_data_attributes( $module_id ) {
			$attributes = array(
				'data-module'      => esc_attr( $module_id ),
				'data-recommended' => $this->is_recommended( $module_id ) ? 'yes' : 'no',
				'data-active'      => $this->is_active( $module_id ) ? 'yes' : 'no',
				'data-recent'      => $this->is_recent( $module_id ) ? 'yes' : 'no',
			);

			$attr_string = '';
			foreach ( $attributes as $key => $value ) {
				$attr_string .= ' ' . $key . '="' . $value . '"';
			}

			return $attr_string;
		}

		/**
		 * Render filter buttons.
		 *
		 * @return void
		 */
		public function render_filter_buttons() {
			?>
			<div class="wcj-module-filters" id="wcj-module-filters">
				<button class="wcj-filter-btn active" data-filter="all">
					<?php esc_html_e( 'All', 'woocommerce-jetpack' ); ?>
				</button>
				<button class="wcj-filter-btn" data-filter="recommended">
					<?php esc_html_e( 'Recommended', 'woocommerce-jetpack' ); ?>
				</button>
				<button class="wcj-filter-btn" data-filter="active">
					<?php esc_html_e( 'Active', 'woocommerce-jetpack' ); ?>
				</button>
				<button class="wcj-filter-btn" data-filter="recent">
					<?php esc_html_e( 'Recently Used', 'woocommerce-jetpack' ); ?>
				</button>
			</div>
			<?php
		}
	}

endif;
