<?php
/**
 * Booster Plus for WooCommerce - Presets System
 *
 * Provides one-click preset configurations for Plus-safe onboarding jobs.
 *
 * @version 7.5.1
 * @since   7.5.1
 * @author  Pluggabl LLC.
 * @package Booster_Plus_For_WooCommerce/includes/presets
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WCJ_Presets' ) ) :

	/**
	 * WCJ_Presets Class.
	 */
	class WCJ_Presets {

		/**
		 * Class instance.
		 *
		 * @var WCJ_Presets|null
		 */
		private static $instance = null;

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_action( 'wp_ajax_wcj_apply_preset', array( $this, 'ajax_apply_preset' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		}

		/**
		 * Get instance.
		 *
		 * @return WCJ_Presets
		 */
		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Get Plus-safe module allowlist for preset/hub/filter framework.
		 *
		 * @return array
		 */
		public static function get_module_allowlist() {
			return array(
				'sales_notifications',
				'frequently_bought_together',
				'one_page_checkout',
				'order_numbers',
				'admin_orders_list',
				'currency',
			);
		}

		/**
		 * Check whether a module is allowed for Plus presets.
		 *
		 * @param string $module_id Module ID.
		 *
		 * @return bool
		 */
		public static function is_allowed_module( $module_id ) {
			return in_array( $module_id, self::get_module_allowlist(), true );
		}

		/**
		 * Get available presets.
		 *
		 * @return array
		 */
		public static function get_presets() {
			$presets = array(
				'grow_sales'      => array(
					'id'          => 'grow_sales',
					'title'       => __( 'Grow sales now', 'woocommerce-jetpack' ),
					'description' => __( 'Enable sales notifications and frequently bought together bundles.', 'woocommerce-jetpack' ),
					'icon'        => 'dashicons-chart-line',
					'modules'     => array(
						'sales_notifications'        => true,
						'frequently_bought_together' => true,
					),
					'settings'    => array(
						'wcj_sales_notifications_enabled' => 'yes',
						'wcj_sale_msg_duration'           => 4,
						'wcj_sale_msg_next'               => 8,
						'wcj_frequently_bought_together_enabled' => 'yes',
					),
					'first_win'   => array(
						'action' => __( 'Create your first frequently bought together bundle.', 'woocommerce-jetpack' ),
						'link'   => admin_url( 'admin.php?page=wcj-plugins&tab=jetpack&wcj-cat=cart_and_checkout&section=frequently_bought_together&wcj-cat-nonce=' . wp_create_nonce( 'wcj-cat-nonce' ) ),
					),
					'next_step'   => array(
						'label' => __( 'Customize sales notifications', 'woocommerce-jetpack' ),
						'link'  => admin_url( 'admin.php?page=wcj-plugins&tab=jetpack&wcj-cat=marketings&section=sales_notifications&wcj-cat-nonce=' . wp_create_nonce( 'wcj-cat-nonce' ) ),
					),
				),
				'faster_checkout' => array(
					'id'          => 'faster_checkout',
					'title'       => __( 'Faster checkout', 'woocommerce-jetpack' ),
					'description' => __( 'Set up one-page checkout and create a starter draft page.', 'woocommerce-jetpack' ),
					'icon'        => 'dashicons-cart',
					'modules'     => array(
						'one_page_checkout' => true,
					),
					'settings'    => array(
						'wcj_one_page_checkout_enabled' => 'yes',
						'wcj_one_page_checkout_hooks_priority' => 50,
						'create_demo_draft'             => true,
					),
					'first_win'   => array(
						'action' => __( 'Publish your quick checkout draft page.', 'woocommerce-jetpack' ),
						'link'   => admin_url( 'edit.php?post_type=page' ),
					),
					'next_step'   => array(
						'label' => __( 'Configure one-page checkout', 'woocommerce-jetpack' ),
						'link'  => admin_url( 'admin.php?page=wcj-plugins&tab=jetpack&wcj-cat=cart_and_checkout&section=one_page_checkout&wcj-cat-nonce=' . wp_create_nonce( 'wcj-cat-nonce' ) ),
					),
				),
				'work_smarter'    => array(
					'id'          => 'work_smarter',
					'title'       => __( 'Work smarter (backend)', 'woocommerce-jetpack' ),
					'description' => __( 'Enable order workflow defaults for faster admin operations.', 'woocommerce-jetpack' ),
					'icon'        => 'dashicons-admin-tools',
					'modules'     => array(
						'order_numbers'     => true,
						'admin_orders_list' => true,
					),
					'settings'    => array(
						'wcj_order_numbers_enabled'     => 'yes',
						'wcj_order_number_sequential_enabled' => 'yes',
						'wcj_order_number_counter'      => 1,
						'wcj_order_number_order_tracking_enabled' => 'yes',
						'wcj_order_number_search_by_custom_number_enabled' => 'yes',
						'wcj_admin_orders_list_enabled' => 'yes',
					),
					'first_win'   => array(
						'action' => __( 'Open your orders list and confirm custom order numbers are active.', 'woocommerce-jetpack' ),
						'link'   => admin_url( 'edit.php?post_type=shop_order' ),
					),
					'next_step'   => array(
						'label' => __( 'Configure order numbers', 'woocommerce-jetpack' ),
						'link'  => admin_url( 'admin.php?page=wcj-plugins&tab=jetpack&wcj-cat=shipping_and_orders&section=order_numbers&wcj-cat-nonce=' . wp_create_nonce( 'wcj-cat-nonce' ) ),
					),
				),
				'go_global'       => array(
					'id'          => 'go_global',
					'title'       => __( 'Go global (starter)', 'woocommerce-jetpack' ),
					'description' => __( 'Enable currency tools and add one extra store currency.', 'woocommerce-jetpack' ),
					'icon'        => 'dashicons-admin-site',
					'modules'     => array(
						'currency' => true,
					),
					'settings'    => array(
						'wcj_currency_enabled' => 'yes',
						'add_one_extra'        => true,
					),
					'first_win'   => array(
						'action' => __( 'Add and test a second store currency.', 'woocommerce-jetpack' ),
						'link'   => admin_url( 'admin.php?page=wcj-plugins&tab=jetpack&wcj-cat=prices_and_currencies&section=currency&wcj-cat-nonce=' . wp_create_nonce( 'wcj-cat-nonce' ) ),
					),
					'next_step'   => array(
						'label' => __( 'Configure currencies', 'woocommerce-jetpack' ),
						'link'  => admin_url( 'admin.php?page=wcj-plugins&tab=jetpack&wcj-cat=prices_and_currencies&section=currency&wcj-cat-nonce=' . wp_create_nonce( 'wcj-cat-nonce' ) ),
					),
				),
			);

			return apply_filters( 'wcj_dashboard_presets', $presets );
		}

		/**
		 * Apply preset by ID.
		 *
		 * @param string $preset_id Preset ID.
		 *
		 * @return bool|WP_Error
		 */
		public static function apply_preset( $preset_id ) {
			if ( 'pdf_invoicing' === $preset_id ) {
				return new WP_Error( 'invoice_setup_required', __( 'Open branded document setup and review before activating.', 'woocommerce-jetpack' ) );
			}
			$presets = self::get_presets();

			if ( ! isset( $presets[ $preset_id ] ) ) {
				return new WP_Error( 'invalid_preset', __( 'Preset not found.', 'woocommerce-jetpack' ) );
			}

			$preset = $presets[ $preset_id ];

			$undo_state = array(
				'modules'  => self::get_current_module_states( array_keys( $preset['modules'] ) ),
				'settings' => self::get_current_settings_values( array_keys( $preset['settings'] ) ),
			);
			update_user_meta( get_current_user_id(), 'wcj_preset_undo_state', $undo_state );
			update_user_meta( get_current_user_id(), 'wcj_last_preset_applied', $preset_id );

			foreach ( $preset['modules'] as $module_id => $enabled ) {
				if ( $enabled && self::is_allowed_module( $module_id ) ) {
					update_option( 'wcj_' . $module_id . '_enabled', 'yes' );
				}
			}

			foreach ( $preset['settings'] as $option_key => $value ) {
				if ( 'create_demo_draft' === $option_key && $value ) {
					self::create_one_page_checkout_draft();
					continue;
				}
				if ( 'add_one_extra' === $option_key && $value ) {
					self::add_extra_currency();
					continue;
				}

				$existing = get_option( $option_key, '' );
				if ( '' === $existing || null === $existing ) {
					update_option( $option_key, $value );
				}
			}

			do_action( 'wcj_preset_applied', $preset_id );

			return true;
		}

		/**
		 * Store current module states for undo support.
		 *
		 * @param array $module_ids Module IDs.
		 *
		 * @return array
		 */
		private static function get_current_module_states( $module_ids ) {
			$states = array();
			foreach ( $module_ids as $module_id ) {
				if ( self::is_allowed_module( $module_id ) ) {
					$states[ $module_id ] = get_option( 'wcj_' . $module_id . '_enabled', 'no' );
				}
			}
			return $states;
		}

		/**
		 * Store current option values for undo support.
		 *
		 * @param array $option_keys Option keys.
		 *
		 * @return array
		 */
		private static function get_current_settings_values( $option_keys ) {
			$values = array();
			foreach ( $option_keys as $option_key ) {
				$values[ $option_key ] = get_option( $option_key, '' );
			}
			return $values;
		}

		/**
		 * Create one-page checkout draft page if missing.
		 *
		 * @return void
		 */
		private static function create_one_page_checkout_draft() {
			$query = new WP_Query(
				array(
					'post_type'      => 'page',
					'title'          => 'Quick Checkout (Draft)',
					'post_status'    => array( 'draft', 'publish', 'pending', 'private' ),
					'posts_per_page' => 1,
					'fields'         => 'ids',
				)
			);

			if ( $query->have_posts() ) {
				return;
			}

			wp_insert_post(
				array(
					'post_title'   => 'Quick Checkout (Draft)',
					'post_content' => '[wcj_one_page_checkout]',
					'post_status'  => 'draft',
					'post_type'    => 'page',
					'post_author'  => get_current_user_id(),
				)
			);
		}

		/**
		 * Add one extra currency for quick setup.
		 *
		 * @return void
		 */
		private static function add_extra_currency() {
			$current_currency = get_woocommerce_currency();
			if ( 'EUR' !== $current_currency ) {
				update_option( 'wcj_currency_EUR', '€' );
			} elseif ( 'USD' !== $current_currency ) {
				update_option( 'wcj_currency_USD', '$' );
			}
		}

		/**
		 * AJAX handler for preset application.
		 *
		 * @return void
		 */
		public function ajax_apply_preset() {
			check_ajax_referer( 'wcj-preset-nonce', 'nonce' );

			// phpcs:ignore WordPress.WP.Capabilities.Unknown
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_send_json_error( __( 'Permission denied.', 'woocommerce-jetpack' ) );
			}

			$preset_id = isset( $_POST['preset_id'] ) ? sanitize_key( wp_unslash( $_POST['preset_id'] ) ) : '';
			if ( empty( $preset_id ) ) {
				wp_send_json_error( __( 'No preset specified.', 'woocommerce-jetpack' ) );
			}

			$result = self::apply_preset( $preset_id );
			if ( is_wp_error( $result ) ) {
				wp_send_json_error( $result->get_error_message() );
			}

			$presets = self::get_presets();
			$preset  = $presets[ $preset_id ];

			wp_send_json_success(
				array(
					'message'   => sprintf(
						/* translators: %s: preset title */
						__( '%s preset applied successfully!', 'woocommerce-jetpack' ),
						$preset['title']
					),
					'first_win' => $preset['first_win'],
					'next_step' => $preset['next_step'],
				)
			);
		}

		/**
		 * Enqueue preset assets.
		 *
		 * @return void
		 */
		public function enqueue_scripts() {
			$screen = get_current_screen();
			if ( ! $screen || false === strpos( $screen->id, 'wcj' ) ) {
				return;
			}

			wp_enqueue_style(
				'wcj-presets',
				wcj_plugin_url() . '/assets/css/admin/wcj-presets.css',
				array(),
				defined( 'WCJ_VERSION' ) ? WCJ_VERSION : '7.5.1'
			);

			wp_enqueue_script(
				'wcj-presets',
				wcj_plugin_url() . '/assets/js/admin/wcj-presets.js',
				array( 'jquery' ),
				defined( 'WCJ_VERSION' ) ? WCJ_VERSION : '7.5.1',
				true
			);

			wp_localize_script(
				'wcj-presets',
				'wcj_preset_params',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => wp_create_nonce( 'wcj-preset-nonce' ),
					'strings'  => array(
						'applying'     => __( 'Applying...', 'woocommerce-jetpack' ),
						'apply_preset' => __( 'Apply Preset', 'woocommerce-jetpack' ),
						'error'        => __( 'Error occurred. Please try again.', 'woocommerce-jetpack' ),
						'go_there_now' => __( 'Go there now', 'woocommerce-jetpack' ),
						'first_win'    => __( 'First win:', 'woocommerce-jetpack' ),
					),
				)
			);
		}

		/**
		 * Render all preset cards.
		 *
		 * @return void
		 */
		public static function render_preset_cards() {
			$presets = self::get_presets();
			?>
			<div class="wcj-preset-cards">
				<?php foreach ( $presets as $preset ) : ?>
					<div class="wcj-preset-card" data-preset-id="<?php echo esc_attr( $preset['id'] ); ?>">
						<span class="dashicons <?php echo esc_attr( $preset['icon'] ); ?>"></span>
						<h3><?php echo esc_html( $preset['title'] ); ?></h3>
						<p><?php echo esc_html( $preset['description'] ); ?></p>
						<button class="button button-primary wcj-apply-preset">
							<?php esc_html_e( 'Apply Preset', 'woocommerce-jetpack' ); ?>
						</button>
					</div>
				<?php endforeach; ?>
			</div>
			<?php
		}
	}

endif;

WCJ_Presets::instance();
