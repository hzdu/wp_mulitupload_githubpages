<?php
/**
 * Booster for WooCommerce - Functions - Numbers to Words
 *
 * @version 6.0.0
 * @author  Pluggabl LLC.
 * @package Booster_Plus_For_WooCommerce/functions
 */

/**
 * Convert_number_to_words.
 *
 * @return string
 */
if ( ! function_exists( 'convert_number_to_words' ) ) {
	/**
	 * Convert_number_to_words.
	 *
	 * @version 6.0.0
	 * @since   1.0.0
	 * @param int $number Get Number.
	 */
	function convert_number_to_words( $number ) {
		$hyphen      = '-';
		$conjunction = ' and ';
		$separator   = ', ';
		$negative    = 'negative ';
		$decimal     = ' point ';
		$dictionary  = array(
			0                   => 'zero',
			1                   => 'one',
			2                   => 'two',
			3                   => 'three',
			4                   => 'four',
			5                   => 'five',
			6                   => 'six',
			7                   => 'seven',
			8                   => 'eight',
			9                   => 'nine',
			10                  => 'ten',
			11                  => 'eleven',
			12                  => 'twelve',
			13                  => 'thirteen',
			14                  => 'fourteen',
			15                  => 'fifteen',
			16                  => 'sixteen',
			17                  => 'seventeen',
			18                  => 'eighteen',
			19                  => 'nineteen',
			20                  => 'twenty',
			30                  => 'thirty',
			40                  => 'fourty',
			50                  => 'fifty',
			60                  => 'sixty',
			70                  => 'seventy',
			80                  => 'eighty',
			90                  => 'ninety',
			100                 => 'hundred',
			1000                => 'thousand',
			1000000             => 'million',
			1000000000          => 'billion',
			1000000000000       => 'trillion',
			1000000000000000    => 'quadrillion',
			1000000000000000000 => 'quintillion',
		);

		if ( ! is_numeric( $number ) ) {
			return false;
		}

		if ( ( $number >= 0 && (int) $number < 0 ) || (int) $number < 0 - PHP_INT_MAX ) {
			// overflow.
			trigger_error( // phpcs:ignore WordPress.PHP.DevelopmentFunctions
				'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				E_USER_WARNING
			);
			return false;
		}

		if ( $number < 0 ) {
			return $negative . convert_number_to_words( abs( $number ) );
		}
		$fraction = null;
		$string   = $fraction;

		if ( strpos( $number, '.' ) !== false ) {
			list($number, $fraction) = explode( '.', $number );
		}

		switch ( true ) {
			case $number < 21:
				$string = $dictionary[ $number ];
				break;
			case $number < 100:
				$tens   = ( (int) ( $number / 10 ) ) * 10;
				$units  = $number % 10;
				$string = $dictionary[ $tens ];
				if ( $units ) {
					$string .= $hyphen . $dictionary[ $units ];
				}
				break;
			case $number < 1000:
				$hundreds  = $number / 100;
				$remainder = $number % 100;
				$string    = $dictionary[ $hundreds ] . ' ' . $dictionary[100];
				if ( $remainder ) {
					$string .= $conjunction . convert_number_to_words( $remainder );
				}
				break;
			default:
				$base_unit      = pow( 1000, floor( log( $number, 1000 ) ) );
				$num_base_units = (int) ( $number / $base_unit );
				$remainder      = $number % $base_unit;
				$string         = convert_number_to_words( $num_base_units ) . ' ' . $dictionary[ $base_unit ];
				if ( $remainder ) {
					$string .= $remainder < 100 ? $conjunction : $separator;
					$string .= convert_number_to_words( $remainder );
				}
				break;
		}

		if ( null !== $fraction && is_numeric( $fraction ) ) {
			$string .= $decimal;
			$words   = array();
			foreach ( str_split( (string) $fraction ) as $number ) {
				$words[] = $dictionary[ $number ];
			}
			$string .= implode( ' ', $words );
		}

		return $string;
	}
}
