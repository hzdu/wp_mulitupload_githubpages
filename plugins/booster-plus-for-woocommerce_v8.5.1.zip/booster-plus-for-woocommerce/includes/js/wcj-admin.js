/**
 * Wcj-admin.
 *
 * @version 7.2.5
 * @since  1.0.0
 * @package Booster_Elite_For_WooCommerce/includes/JS
 */

jQuery( document ).ready(
	function () {
		let circleBadge = document.querySelector( '.circle-badge' ),
		subCircles      = document.querySelectorAll( '.subCircles > div' );
		if (null !== circleBadge) {
			circleBadge.addEventListener( 'click', showCircles );

			function showCircles() {
				subCircles.forEach(
					circle => {
					circle.classList.toggle( "show" );
					}
				)
			};
		}

		jQuery( 'button[name="booster_reset_settings"]' ).on(
			'click',
			function () {
				return confirm( admin_object.resetSettings );
			}
		);

		jQuery( 'button[name="booster_reset_settings_meta"]' ).on(
			'click',
			function () {
				return confirm( admin_object.deleteMeta );
			}
		);

		jQuery( 'button[data-confirm]' ).on(
			'click',
			function () {
				return confirm( jQuery( this ).data( 'confirm' ) );
			}
		);
	}
);
