/**
 * Booster Plus for WooCommerce - Presets JavaScript
 *
 * Handles preset card interactions and AJAX preset application.
 *
 * @version 7.5.1
 */

/* global jQuery, wcj_preset_params */

(function($) {
	'use strict';

	/**
	 * Initialize preset cards.
	 */
	function initPresetCards() {
		$( document ).on(
			'click',
			'.wcj-apply-preset',
			function(e) {
				e.preventDefault();

				var $card = $( this ).closest( '.wcj-preset-card' );
				var presetId = $card.data( 'preset-id' );
				var $button = $( this );

				$button.prop( 'disabled', true ).text( wcj_preset_params.strings.applying );

				$.ajax(
					{
						url: wcj_preset_params.ajax_url,
						type: 'POST',
						data: {
							action: 'wcj_apply_preset',
							preset_id: presetId,
							nonce: wcj_preset_params.nonce
						},
						success: function(response) {
							if (response.success) {
								var html = '<div class="wcj-preset-success">';
								html += '<span class="dashicons dashicons-yes-alt"></span>';
								html += '<p class="wcj-preset-message">' + response.data.message + '</p>';
								html += '<p class="wcj-preset-first-win"><strong>' + wcj_preset_params.strings.first_win + '</strong> ' + response.data.first_win.action + '</p>';
								html += '<a href="' + response.data.first_win.link + '" class="button button-primary">' + wcj_preset_params.strings.go_there_now + '</a>';
								html += '</div>';

								$card.html( html );
							} else {
								alert( wcj_preset_params.strings.error + ' ' + response.data );
								$button.prop( 'disabled', false ).text( wcj_preset_params.strings.apply_preset );
							}
						},
						error: function() {
							alert( wcj_preset_params.strings.error );
							$button.prop( 'disabled', false ).text( wcj_preset_params.strings.apply_preset );
						}
					}
				);
			}
		);
	}

	$( document ).ready(
		function() {
			initPresetCards();
		}
	);

})( jQuery );
