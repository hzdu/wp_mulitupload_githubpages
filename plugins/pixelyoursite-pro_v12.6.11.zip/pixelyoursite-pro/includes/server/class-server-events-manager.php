<?php
/**
 * Server Events Manager
 *
 * Centralizes registration of WooCommerce and EDD hooks for server-side events
 *
 * @package PixelYourSite
 */

namespace PixelYourSite;

use WC_Subscription;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Class ServerEventsManager
 *
 * Manages server-side event hooks for WooCommerce and EDD
 */
class ServerEventsManager {

    /**
     * Singleton instance
     *
     * @var ServerEventsManager
     */
    private static $_instance;

    /**
     * Stores pixel IDs that have fired during current request
     *
     * @var array
     */
    private static $firedPixels = array();

    /**
     * Logger instance
     *
     * @var object
     */
    private $logger;

    /**
     * Current subscription ID for event context
     *
     * @var int|null
     */
    private $current_subscription_id = null;

    /**
     * Current license ID for event context
     *
     * @var int|null
     */
    private $current_license_id = null;

    /**
     * Current payment ID for event context
     *
     * @var int|null
     */
    private $current_payment_id = null;

    /**
     * Get singleton instance
     *
     * @return ServerEventsManager
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Add fired pixel ID(s) to the tracking array
     *
     * @param string $platform Platform name (facebook, ga, tiktok, pinterest)
     * @param string|array $pixel_ids Pixel ID or array of pixel IDs
     * @return void
     */
    public static function addFiredPixel( $platform, $pixel_ids ) {
        if ( ! is_array( $pixel_ids ) ) {
            $pixel_ids = array( $pixel_ids );
        }

        if ( ! isset( self::$firedPixels[ $platform ] ) ) {
            self::$firedPixels[ $platform ] = array();
        }

        foreach ( $pixel_ids as $pixel_id ) {
            if ( ! empty( $pixel_id ) && ! in_array( $pixel_id, self::$firedPixels[ $platform ], true ) ) {
                self::$firedPixels[ $platform ][] = $pixel_id;
            }
        }
    }

    /**
     * Get all fired pixels
     *
     * @return array Array of fired pixels grouped by platform
     */
    public static function getFiredPixels() {
        return self::$firedPixels;
    }

    /**
     * Reset fired pixels array
     *
     * @return void
     */
    public static function resetFiredPixels() {
        self::$firedPixels = array();
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->logger = PYS()->getLog();
        // Skip if cache preload

        add_action( 'plugins_loaded', array( $this, 'init' ), 30 );
    }

    /**
     * Initialize hooks
     *
     * @return void
     */
    public function init() {
        if ( PYS()->isCachePreload() ) {
            return;
        }

        // Agency Mode Hard block on the core license: do not register the order
        // hooks at all, so no purchase, refund or subscription event is even
        // built. See pys_tracking_hard_blocked().
        if ( pys_tracking_hard_blocked() ) {
            PYS()->getLog()->debug( 'Server events are off: Agency Mode hard block' );

            return;
        }

        add_action( self::PURCHASE_FALLBACK_HOOK, array( $this, 'retry_purchase_fallback' ), 10, 2 );

        // The thank-you page tells which platforms its browser Purchase reached.
        // nopriv is required: guests check out and see the thank-you page. The
        // sender is authenticated by an HMAC bound to the order key (no nonce,
        // the page may be cached), and the call only records a timestamp.
        add_action( 'wp_ajax_pys_purchase_marker', array( $this, 'ajax_purchase_marker' ) );
        add_action( 'wp_ajax_nopriv_pys_purchase_marker', array( $this, 'ajax_purchase_marker' ) );

        // WooCommerce hooks
        if ( isWooCommerceActive() ) {
            // 1. Extracting an array of statuses from settings
            $selected_statuses = (array) PYS()->getOption('woo_order_advanced_purchase_status');

            // 2. We go through each status in a loop and assign the same function to it.
            foreach ( $selected_statuses as $status_with_prefix ) {

                // We clear it from 'wc-', since the hook woocommerce_order_status_{status} does not contain it.
                $clean_status = str_replace( 'wc-', '', $status_with_prefix );

                // Registering a dynamic hook
                add_action( 'woocommerce_order_status_' . $clean_status, array( $this, 'woo_completed_purchase' ), 10, 2 );
            }
            // woocommerce_order_refunded fires for partial and full refunds with the refund ID.
            // A manual switch to Refunded normally lands here too: WooCommerce's own
            // wc_order_fully_refunded (priority 10 on the status hook) creates the refund record
            // for the remaining amount first. The status hook below is only a fallback for sites
            // that unhook it, and it stays silent whenever a refund record exists.
            add_action( 'woocommerce_order_refunded', array( $this, 'woo_refund_order' ), 30, 2 );
            add_action( 'woocommerce_order_status_refunded', array( $this, 'woo_order_refunded_status' ), 30 );
            // A cancelled order whose GA4 Purchase is on record gets a GA4 refund for what is left of it.
            add_action( 'woocommerce_order_status_cancelled', array( $this, 'woo_order_cancelled_status' ), 30 );

            if(class_exists('WC_Subscriptions')){
                add_action('woocommerce_subscription_payment_complete', array($this, 'woo_subscription_created'), 10, 1);
                add_action('woocommerce_subscription_status_updated', array($this, 'woo_subscription_status_change'), 10, 3);
            }
        }

        // EDD hooks
        if ( isEddActive() ) {
            add_action( 'edd_recurring_record_payment', array( $this, 'edd_recurring_payment' ), 5, 4 );
            add_action( 'edd_complete_purchase', array( $this, 'edd_completed_purchase' ), 5, 1 );
            add_action( 'edd_refund_order', array( $this, 'edd_refund_order' ), 10, 3 );
            // A cancelled payment whose GA4 Purchase is on record gets a GA4 refund (only if it has no refund yet).
            add_action( 'edd_transition_order_status', array( $this, 'edd_order_cancelled_status' ), 30, 3 );

            // EDD Recurring Subscription hooks
            if ( class_exists( 'EDD_Recurring' ) ) {
                add_action( 'edd_subscription_status_change', array( $this, 'edd_subscription_status_change' ), 10, 3 );
                add_action( 'edd_subscription_post_create', array( $this, 'edd_subscription_created' ), 5, 2 );
                add_action( 'edd_subscription_post_renew', array( $this, 'edd_subscription_renewed' ), 5, 4 );
            }
            // EDD Software Licensing hooks
            if ( class_exists( 'EDD_Software_Licensing' ) ) {
                add_action( 'edd_sl_post_set_status', array( $this, 'edd_license_status_change' ), 10, 2 );
                add_action( 'edd_sl_license_upgraded', array( $this, 'edd_license_upgraded' ), 10, 2 );
                add_action( 'edd_sl_post_license_renewal', array( $this, 'edd_license_renewed' ), 10, 2 );
                add_action( 'edd_sl_store_license', array( $this, 'edd_license_created' ), 10, 4 );
            }

        }

    }

    /**
     * Acquire a cross-process lock before firing an order's server purchase event.
     *
     * Thin wrapper around the shared pysAcquireNamedLock() so all server-event
     * paths (purchase, POAS) use one locking implementation. The lock is per
     * order, so it never blocks a different order.
     *
     * @param string $context Either 'woo' or 'edd'.
     * @param int|string $id  Order / payment id.
     * @param int $timeout     Seconds to wait for the lock.
     * @return string 'acquired' | 'busy' | 'unavailable'
     */
    private function acquire_purchase_lock( $context, $id, $timeout = 15 ) {
        return pysAcquireNamedLock( 'purchase_' . $context, $id, $timeout );
    }

    /**
     * Release a previously acquired purchase lock.
     *
     * @param string $context Either 'woo' or 'edd'.
     * @param int|string $id  Order / payment id.
     * @return void
     */
    private function release_purchase_lock( $context, $id ) {
        pysReleaseNamedLock( 'purchase_' . $context, $id );
    }

    const PURCHASE_FALLBACK_HOOK = 'pys_purchase_fallback_retry';

    /**
     * Delays of the retries of a server purchase that a platform could not
     * take (timeout, 5xx, connection error), by attempt number.
     */
    const PURCHASE_FALLBACK_DELAYS = array( 1 => 300, 2 => 1800, 3 => 7200 );

    /**
     * Is the server Purchase of this ads platform switched on?
     *
     * @param string $type     'woo' or 'edd'
     * @param string $platform facebook, tiktok, openai or pinterest
     * @return bool
     */
    private function isAdsPlatformEnabled( $type, $platform ) {
        switch ( $platform ) {
            case 'facebook':
                return (bool) PYS()->getOption( "{$type}_advance_purchase_fb_enabled" );
            case 'tiktok':
                return Tiktok()->enabled()
                    && Tiktok()->isServerApiEnabled()
                    && Tiktok()->getOption( "{$type}_advance_purchase_enabled" );
            case 'openai':
                return OpenAI()->enabled()
                    && OpenAI()->isServerApiEnabled()
                    && OpenAI()->getOption( "{$type}_advance_purchase_enabled" );
            case 'pinterest':
                return Pinterest()->enabled()
                    && method_exists( Pinterest(), 'isServerApiEnabled' )
                    && Pinterest()->isServerApiEnabled()
                    && Pinterest()->getOption( "{$type}_advance_purchase_enabled" );
        }

        return false;
    }

    /**
     * Does the order-status send (Advanced Purchase Tracking) cover this platform?
     *
     * @param string $type     'woo' or 'edd'
     * @param string $platform ga, facebook, tiktok, openai or pinterest
     * @return bool
     */
    public function isOrderStatusSendEnabled( $type, $platform ) {
        if ( $platform === 'ga' ) {
            return (bool) PYS()->getOption( "{$type}_advance_purchase_ga_enabled" );
        }

        return (bool) $this->isAdsPlatformEnabled( $type, $platform );
    }

    /**
     * Which platforms the server leaves to the browser this run.
     *
     * GA4 has one source in both modes. In Single mode the ads platforms
     * follow the same rule; Advanced keeps sending them (deduplicated by
     * event_id). A platform inside the browser's grace window is skipped too and
     * makes the run wait.
     *
     * @param string         $type
     * @param int            $order_id
     * @param bool           $advanced
     * @param \WC_Order|null $order Woo order whose meta was read fresh
     * @return array array( 'skip' => platforms, 'wait' => seconds until the
     *               longest grace window ends, 0 when nothing waits )
     */
    private function browserPurchasePlan( $type, $order_id, $advanced, $order = null ) {
        $skip = array();
        $wait = 0;

        $platforms = $advanced ? array( 'ga' ) : array( 'ga', 'facebook', 'tiktok', 'openai', 'pinterest' );
        // Single mode: what an earlier deferred run already sent.
        $sent = $advanced ? array() : PurchaseDelivery::singleServerSent( $type, $order_id, array(), $order );

        foreach ( $platforms as $platform ) {
            if ( in_array( $platform, $sent, true ) ) {
                $skip[] = $platform;
                continue;
            }
            $enabled = $platform === 'ga'
                ? (bool) PYS()->getOption( "{$type}_advance_purchase_ga_enabled" )
                : $this->isAdsPlatformEnabled( $type, $platform );
            if ( ! $enabled ) {
                continue;
            }

            $result = PurchaseDelivery::browserDecision( $type, $order_id, $platform, $order );
            if ( $result['decision'] === 'skip' ) {
                $skip[] = $platform;
            } elseif ( $result['decision'] === 'wait' ) {
                $skip[] = $platform;
                $wait   = max( $wait, (int) $result['wait'] );
            }
        }

        return array( 'skip' => $skip, 'wait' => $wait );
    }

    /**
     * Send the server purchase to Meta, TikTok, OpenAI and Pinterest.
     *
     * @param string      $type  'woo' or 'edd'
     * @param SingleEvent $event
     * @param array       $skip  Platforms to leave out (the browser covers them
     *                           or is still within its grace window)
     * @param array       $sent  Filled with the platforms that accepted the send
     *                           (Pinterest: attempted); Single mode records them
     * @param \WC_Order|int $order_or_id Woo order object / EDD payment id, for the per-order block
     * @return bool True if any platform asked for another attempt
     */
    private function sendPurchaseToAdsPlatforms( $type, $event, array $skip = array(), array &$sent = array(), $order_or_id = 0 ) {
        $results = array();

        if ( $order_or_id && pys_order_purchase_blocked( $type, $order_or_id, 'ads' ) ) {
            $blocked_id = is_object( $order_or_id ) ? $order_or_id->get_id() : $order_or_id;
            PYS()->getLog()->debug( "Purchase to ads platforms skipped: blocked for {$type} order {$blocked_id}" );
            return false;
        }

        // A platform counts as sent once any of its pixels accepted (the senders
        // call addFiredPixel() on 2xx). With several pixels, one 200 and one 400
        // combine to FAILED; re-sending would double the accepted pixel, so the
        // failed one is the loss we accept.
        $firedCount = function ( $platform ) {
            $fired = self::getFiredPixels();
            return isset( $fired[ $platform ] ) ? count( $fired[ $platform ] ) : 0;
        };

        if ( ! in_array( 'facebook', $skip, true ) && $this->isAdsPlatformEnabled( $type, 'facebook' ) ) {
            Facebook()->getLog()->debug( "Send FB" );
            $before    = $firedCount( 'facebook' );
            $results[] = FacebookServer()->sendEventsNow( Facebook()->generateEvents( $event ) );
            if ( self::isSent( end( $results ) ) || $firedCount( 'facebook' ) > $before ) {
                $sent[] = 'facebook';
            }
        }

        if ( ! in_array( 'tiktok', $skip, true ) && $this->isAdsPlatformEnabled( $type, 'tiktok' ) ) {
            Tiktok()->getLog()->debug( 'Send Completed Payment Tiktok' );
            $before    = $firedCount( 'tiktok' );
            $results[] = TikTokServer()->sendEventsNow( Tiktok()->generateEvents( $event ) );
            if ( self::isSent( end( $results ) ) || $firedCount( 'tiktok' ) > $before ) {
                $sent[] = 'tiktok';
            }
        }

        if ( ! in_array( 'openai', $skip, true ) && $this->isAdsPlatformEnabled( $type, 'openai' ) ) {
            OpenAI()->getLog()->debug( 'Send Completed Payment OpenAI' );
            $before    = $firedCount( 'openai' );
            $results[] = OpenAIServer()->sendEventsNow( OpenAI()->generateEvents( $event ) );
            if ( self::isSent( end( $results ) ) || $firedCount( 'openai' ) > $before ) {
                $sent[] = 'openai';
            }
        }

        // The Pinterest add-on returns no result: it gets one attempt, and the
        // delivery record can only say it was sent.
        // The add-on's own events carry no order id, so the order is checked here.
        $pinterest_order = is_object( $order_or_id ) ? (int) $order_or_id->get_id() : (int) $order_or_id;
        $pinterest_off   = $pinterest_order && apply_filters( 'pys_disable_server_event_filter', false, $event->getId(), 'pinterest', $pinterest_order );
        if ( ! $pinterest_off && ! in_array( 'pinterest', $skip, true ) && $this->isAdsPlatformEnabled( $type, 'pinterest' ) ) {
            Pinterest()->getLog()->debug( 'Send Checkout Pinterest' );
            $sent[] = 'pinterest';
            try {
                PinterestServer()->sendEventsNow( Pinterest()->generateEvents( $event ) );
            } catch ( \Throwable $e ) {
                Pinterest()->getLog()->error( 'Send Checkout Pinterest: unexpected error', $e );
            }
            $this->recordUnconfirmedSend( $type, $event, $order_or_id, 'pinterest' );
        }

        foreach ( $results as $result ) {
            if ( self::needsRetry( $result ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Note in the delivery record that a sender without a result sent the order's Purchase.
     *
     * @param string        $type        'woo' or 'edd'
     * @param SingleEvent   $event
     * @param \WC_Order|int $order_or_id Woo order object / EDD payment id
     * @param string        $platform
     * @return void
     */
    private function recordUnconfirmedSend( $type, $event, $order_or_id, $platform ) {
        $order_id = is_object( $order_or_id ) ? (int) $order_or_id->get_id() : (int) $order_or_id;
        $event_id = isset( $event->payload['eventID'] ) ? (string) $event->payload['eventID'] : '';
        if ( ! $order_id || $event_id === '' ) {
            return;
        }

        PurchaseDelivery::recordResult(
            $type,
            $order_id,
            $platform,
            $event_id,
            array( '*' => array( 'outcome' => PurchaseDelivery::OUTCOME_UNCONFIRMED ) ),
            PurchaseDelivery::SOURCE_ORDER_STATUS
        );
    }

    /**
     * GA4 + ads platforms for an EDD payment.
     *
     * @param array $skip Platforms the browser covers or still has time for
     * @return bool True if any platform asked for another attempt
     */
    private function sendEddPurchase( $payment_id, $event, $advanced, array $skip = array(), array &$sent = array() ) {
        $retry = false;

        // GA4 gets its own fire-once flag, as on WooCommerce, so a retry or a
        // deferred run does not send GA4 a second time. GA4 has a single
        // source in both modes: the browser marker decides (see
        // woo_completed_purchase()).
        if ( PYS()->getOption( 'edd_advance_purchase_ga_enabled' )
            && ! edd_get_payment_meta( $payment_id, '_pys_ga_advance_purchase_event_fired', true )
            && ! in_array( 'ga', $skip, true )
            && ! pys_order_purchase_blocked( 'edd', $payment_id, 'ga' ) ) {
            $gaEvents = GA()->generateEvents( $event );
            if ( ! empty( $gaEvents ) ) {
                $gaResult = GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents );
                if ( self::isSent( $gaResult ) ) {
                    $sent[] = 'ga';
                }
                if ( ! $advanced || self::isSent( $gaResult ) ) {
                    edd_update_payment_meta( $payment_id, '_pys_ga_advance_purchase_event_fired', true );
                } elseif ( self::needsRetry( $gaResult ) ) {
                    $retry = true;
                }
            }
        }

        return $this->sendPurchaseToAdsPlatforms( 'edd', $event, $skip, $sent, $payment_id ) || $retry;
    }

    private static function isSent( $result ) {
        return is_array( $result ) && ( $result['status'] ?? '' ) === AbstractServerEvents::SEND_SENT;
    }

    private static function needsRetry( $result ) {
        return is_array( $result ) && ( $result['status'] ?? '' ) === AbstractServerEvents::SEND_RETRY;
    }

    /**
     * A retry may fire only some platforms: keep what earlier runs recorded.
     */
    private static function mergeFiredPixels( $stored, $fired ) {
        $merged = is_array( $stored ) ? $stored : array();
        foreach ( $fired as $platform => $ids ) {
            $merged[ $platform ] = array_values( array_unique( array_merge( (array) ( $merged[ $platform ] ?? array() ), (array) $ids ) ) );
        }

        return $merged;
    }

    /**
     * Run the order-status fallback again later from cron.
     *
     * @param string $type     'woo' or 'edd'
     * @param int    $order_id
     * @param bool   $is_retry True after a failed send: counts against the
     *                         attempt limit and backs off. False when the run
     *                         was only deferred out of a checkout AJAX request
     *                         or until the browser's grace window ends.
     * @param int    $delay    Seconds until a deferred (non-retry) run
     */
    private function schedulePurchaseFallback( $type, $order_id, $is_retry, $delay = 120 ) {
        $args = array( $type, (int) $order_id );
        if ( wp_next_scheduled( self::PURCHASE_FALLBACK_HOOK, $args ) ) {
            return;
        }

        $delay    = max( 1, (int) $delay );
        $attempts = 0;
        if ( $is_retry ) {
            $meta_key = '_pys_purchase_fallback_attempts';
            $order    = $type === 'woo' ? wc_get_order( $order_id ) : null;
            if ( $type === 'woo' && ! $order ) {
                return;
            }
            $attempts = 1 + (int) ( $order ? $order->get_meta( $meta_key, true ) : edd_get_payment_meta( $order_id, $meta_key, true ) );

            if ( ! isset( self::PURCHASE_FALLBACK_DELAYS[ $attempts ] ) ) {
                $this->logger->error( "Server purchase for {$type} order {$order_id} was not accepted after " . ( $attempts - 1 ) . ' retries, giving up' );
                PurchaseDelivery::recordRun( $type, $order_id, PurchaseDelivery::RUN_GAVE_UP, array( 'attempts' => $attempts - 1 ) );
                return;
            }
            $delay = self::PURCHASE_FALLBACK_DELAYS[ $attempts ];

            if ( $order ) {
                $order->update_meta_data( $meta_key, $attempts );
                $order->save();
            } else {
                edd_update_payment_meta( $order_id, $meta_key, $attempts );
            }
        }

        wp_schedule_single_event( time() + $delay, self::PURCHASE_FALLBACK_HOOK, $args );
        $this->logger->debug( "Server purchase for {$type} order {$order_id} scheduled in {$delay}s" );
        PurchaseDelivery::recordRun(
            $type,
            $order_id,
            $is_retry ? PurchaseDelivery::RUN_RETRY_SCHEDULED : PurchaseDelivery::RUN_DEFERRED,
            array(
                'attempts' => $attempts,
                'next'     => time() + $delay,
            )
        );
    }

    /**
     * Cron handler of schedulePurchaseFallback().
     *
     * @param string $type     'woo' or 'edd'
     * @param int    $order_id
     */
    public function retry_purchase_fallback( $type, $order_id ) {
        if ( $type === 'woo' && isWooCommerceActive() ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) {
                return;
            }
            // Only while the order is still in a status that fires the event:
            // a refunded or cancelled order must not report a purchase.
            $statuses = array_map( function ( $status ) {
                return str_replace( 'wc-', '', $status );
            }, (array) PYS()->getOption( 'woo_order_advanced_purchase_status' ) );
            if ( ! $order->has_status( $statuses ) ) {
                $this->logger->debug( "Server purchase retry skipped: order {$order_id} is " . $order->get_status() );
                return;
            }
            $this->woo_completed_purchase( $order_id, $order );
        } elseif ( $type === 'edd' && isEddActive() ) {
            if ( ! edd_is_payment_complete( $order_id ) ) {
                $this->logger->debug( "Server purchase retry skipped: payment {$order_id} is not complete" );
                return;
            }
            $this->edd_completed_purchase( $order_id );
        }
    }

    /**
     * AJAX: the browser confirms which platforms its Purchase reached.
     * POST type (woo|edd), order_id, token, platforms[].
     */
    public function ajax_purchase_marker() {
        // Auth is the order-bound token below, not a nonce (see init()).
        $type     = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : '';
        $order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
        $token    = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';

        $platforms = array();
        if ( isset( $_POST['platforms'] ) ) {
            foreach ( (array) wp_unslash( $_POST['platforms'] ) as $platform ) {
                $platform = is_string( $platform ) ? sanitize_key( $platform ) : '';
                if ( in_array( $platform, PurchaseDelivery::MARKER_PLATFORMS, true ) ) {
                    $platforms[] = $platform;
                }
            }
        }

        if ( ! in_array( $type, array( 'woo', 'edd' ), true ) || ! $order_id || $token === '' || empty( $platforms ) ) {
            wp_send_json_error( 'invalid', 400 );
        }

        $expected = PurchaseDelivery::markerToken( $type, $order_id );
        if ( $expected === '' || ! hash_equals( $expected, $token ) ) {
            wp_send_json_error( 'forbidden', 403 );
        }

        // Unknown order or a page that never built the browser Purchase.
        if ( ! PurchaseDelivery::recordBrowserMarker( $type, $order_id, $platforms ) ) {
            wp_send_json_error( 'not_pending', 404 );
        }

        wp_send_json_success();
    }

    /**
     * Tracks a completed WooCommerce purchase
     *
     * @param int $order_id The order ID
     * @return void
     */
    public function woo_completed_purchase( $order_id, $order ) {
        $log = $this->logger;

        if ( ! PYS()->getOption( 'woo_advance_purchase_fb_enabled' )
            && ! PYS()->getOption( 'woo_advance_purchase_ga_enabled' )
            && ( ! Tiktok()->enabled() || ( Tiktok()->enabled() && ! Tiktok()->getOption( 'woo_advance_purchase_enabled' ) ) )
            && ( ! Pinterest()->enabled() || ( Pinterest()->enabled() && ! Pinterest()->getOption( 'woo_advance_purchase_enabled' ) ) )
            && ( ! OpenAI()->enabled() || ( OpenAI()->enabled() && ! OpenAI()->getOption( 'woo_advance_purchase_enabled' ) ) )
            && !PYS()->getOption("woo_poas_enabled")
        ) {
            return false;
        }

        if ( ! $order ) {
            return false;
        }
        if ( ! PYS()->getOption( 'woo_purchase_enabled' ) ) {
            PurchaseDelivery::recordRun( 'woo', $order_id, PurchaseDelivery::RUN_SKIPPED, array( 'reason' => 'purchase_disabled' ) );
            return false;
        }
        if ( isDisabledForUserRole( $order->get_user() ) ) {
            PurchaseDelivery::recordRun( 'woo', $order_id, PurchaseDelivery::RUN_SKIPPED, array( 'reason' => 'user_role' ) );
            return false;
        }

        // Respect the per-type renewal exclusion options for the Purchase event.
        if ( function_exists( 'wcs_order_contains_renewal' ) && wcs_order_contains_renewal( $order ) ) {
            $renewal_type = $this->get_woo_renewal_type( $order );
            if ( $order->get_meta( '_pys_renewal_type', true ) !== $renewal_type ) {
                // Read back later by events built outside this request.
                $order->update_meta_data( '_pys_renewal_type', $renewal_type );
                $order->save();
            }
            if ( $this->should_skip_renewal( $renewal_type, 'woo_purchase_dont_track_auto_renewal', 'woo_purchase_dont_track_manual_renewal' ) ) {
                $log->debug( "Blocked woo_completed_purchase: renewal excluded by settings - type: {$renewal_type}, order: {$order_id}" );
                PurchaseDelivery::recordRun( 'woo', $order_id, PurchaseDelivery::RUN_SKIPPED, array( 'reason' => 'renewal' ) );
                return false;
            }
        }

        add_filter( 'pys_woo_checkout_order_id', function () use ( $order_id ) {
            return $order_id;
        } );

        // Atomic deduplication: serialize concurrent firing of the SAME order.
        // Several triggers (gateway webhook, thank-you page, admin status
        // change, subscription hooks, or multiple selected status transitions)
        // can run at once in separate PHP processes and all pass the
        // "already fired" check before any of them writes it, producing
        // duplicate purchase events. A per-order MySQL named lock lets only one
        // process run the fire path at a time.
        $lock_state = $this->acquire_purchase_lock( 'woo', $order_id );
        if ( 'busy' === $lock_state ) {
            $log->debug( "Blocked woo_completed_purchase: another process is already firing order {$order_id}" );
            return false;
        }
        $have_lock = ( 'acquired' === $lock_state );

        try {
            // Re-read the fired flags fresh from the DB (bypassing caches) now
            // that we hold the lock: a request that loaded its order object
            // before another process wrote the flag would otherwise slip past
            // the guard with a stale value.
            $order->read_meta_data( true );

            // Advanced Deduplication: _pys_purchase_event_fired only says the
            // thank-you page built the browser payload, not that anything was
            // delivered. The server copy is sent anyway; each platform skips the
            // pixels that already accepted this Purchase (PurchaseDelivery) and
            // deduplicates against the browser event by event_id /
            // transaction_id. Single mode keeps "browser OR server", decided
            // per platform from what the browser confirmed (browser marker).
            $advanced = PurchaseDelivery::isAdvancedMode( 'woo' );
            if ( PYS()->getOption( 'woo_purchase_on_transaction' ) && $order->get_meta( '_pys_advance_purchase_event_fired', true ) ) {
                return false;
            }
            $plan = $this->browserPurchasePlan( 'woo', $order_id, $advanced, $order );

            $event = EventsWoo()->getEvent('woo_purchase', false, true);

            if ( $event == null ) {
                // No event although the status is one that sends the Purchase:
                // the order has nothing to send (no trackable items).
                if ( in_array( 'wc-' . $order->get_status(), (array) PYS()->getOption( 'woo_order_advanced_purchase_status' ), true ) ) {
                    PurchaseDelivery::recordRun( 'woo', $order_id, PurchaseDelivery::RUN_SKIPPED, array( 'reason' => 'no_event' ) );
                }
                return false;
            }
            // eventID is now generated in EventsWoo::getEvent() for proper server-browser deduplication
            // Do NOT override it here - the event already has eventID in payload
            $event->addParams( array( 'advanced_purchase_tracking' => true ) );
            // Server-only: requests cannot set a payload key (see isPurchaseEventAlreadySent()).
            $event->addPayload( array( 'pys_order_status_send' => true ) );

            // Send GA server events.
            // GA is sent BEFORE the AJAX/AngellEYE guards below, which return
            // without persisting the overall fired flag. It therefore needs its
            // own fire-once flag, persisted immediately after sending, so that a
            // request which fires GA and then bails at the guard — or any
            // concurrent/repeat trigger — cannot re-fire the GA purchase event.
            // The surrounding named lock + fresh read_meta_data() above make
            // this check-and-set atomic across processes.
            //
            // GA4 does not deduplicate a Measurement Protocol purchase against
            // the gtag one, so even in Advanced mode it gets a single source:
            // whoever fires first. The browser skips GA once the server sent it
            // (_pys_ga_purchase_event_fired), the server skips it here once the
            // browser confirmed it (browser marker) or is still within its
            // grace window.
            $retry = false;
            $sent  = array();

            if ( PYS()->getOption( 'woo_advance_purchase_ga_enabled' )
                && ! $order->get_meta( '_pys_ga_advance_purchase_event_fired', true )
                && ! in_array( 'ga', $plan['skip'], true )
                && ! pys_order_purchase_blocked( 'woo', $order, 'ga' ) ) {
                GA()->getLog()->debug( "Send completed purchase GA" );
                $gaEvents = GA()->generateEvents( $event );
                $gaResult = ! empty( $gaEvents )
                    ? GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents )
                    : AbstractServerEvents::combineResults( [] );

                // Advanced: the flag means "GA4 accepted it". A skipped send (no
                // API secret, blocked by filter) or a failed one leaves it unset,
                // a transient failure is retried.
                if ( self::isSent( $gaResult ) ) {
                    $sent[] = 'ga';
                }
                if ( ! $advanced || self::isSent( $gaResult ) ) {
                    $order->update_meta_data( '_pys_ga_advance_purchase_event_fired', true );
                    $order->save();
                } elseif ( self::needsRetry( $gaResult ) ) {
                    $retry = true;
                }
            }


    // Fire POAS before the Purchase fire-once gate — POAS has its own deduplication
            firePoasForOrder( $order_id );
            // Protection #1: Block ALL AJAX requests (frontend checkout)
            // Note: wp_doing_ajax() only returns true for admin-ajax.php requests
            // Payment gateway webhooks use wc-api parameter and do NOT trigger wp_doing_ajax()
            if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || isset( $_REQUEST['wc-ajax'] ) ) {
                $action = isset( $_REQUEST['action'] ) ? $_REQUEST['action'] : 'unknown';
                $log->debug( "Blocked woo_completed_purchase: AJAX request detected - action: {$action}" );
                // Run the rest later from cron instead of dropping it — the
                // browser may never send its copy. The deferred run decides
                // again from the browser marker, so it is safe in both modes.
                $this->schedulePurchaseFallback( 'woo', $order_id, false, max( 120, $plan['wait'] + 5 ) );
                return;
            }

            // Protection #2: Block AngellEYE PayPal for WooCommerce API requests
            // AngellEYE uses wc-api parameter with "angelleye" in the value (case-insensitive)
            if ( isset( $_REQUEST['wc-api'] ) && stripos( $_REQUEST['wc-api'], 'angelleye' ) !== false ) {
                $wc_api = sanitize_text_field( $_REQUEST['wc-api'] );
                $log->debug( "Blocked woo_completed_purchase: AngellEYE PayPal API request detected - wc-api: {$wc_api}" );
                $this->schedulePurchaseFallback( 'woo', $order_id, false, max( 120, $plan['wait'] + 5 ) );
                return;
            }

            $retry = $this->sendPurchaseToAdsPlatforms( 'woo', $event, $plan['skip'], $sent, $order ) || $retry;

            // Get fired pixels before saving
            $firedPixels = self::getFiredPixels();

            // Advanced: "fired" only once nothing is left to retry, so the
            // browser still sends its AJAX copy and later triggers still run.
            // A platform still within the browser's grace window is not settled.
            // Single: only once the server really sent something (here or in an
            // earlier run), so a browser-only order is not shown as server-sent.
            $server_sent = $advanced ? array() : PurchaseDelivery::singleServerSent( 'woo', $order_id, $sent, $order );
            $settled     = $plan['wait'] === 0 && ( $advanced
                ? ! $retry
                : ! empty( $server_sent ) );
            // A run can settle with nothing left to send (the thank-you page
            // delivered it all): only a real server send makes the order "APT".
            // $firedPixels is no evidence: it also holds the pixels of unrelated
            // events sent earlier in the same request (a cron run of the queue).
            $mark_apt = self::hasAdsDelivery( $sent, $server_sent ) || self::orderStatusDelivered( 'woo', $order );

            if ( isWooCommerceVersionGte( '3.0.0' ) ) {
                // WooCommerce >= 3.0
                if ( $order ) {
                    if ( $settled ) {
                        $order->update_meta_data( '_pys_advance_purchase_event_fired', true );
                        if ( $mark_apt ) {
                            $order->update_meta_data( '_pys_tracking_type', 'apt' );
                        }
                    }

                    // Save fired pixels to order meta
                    if ( ! empty( $firedPixels ) ) {
                        $order->update_meta_data( '_pys_server_fired_pixels', self::mergeFiredPixels( $order->get_meta( '_pys_server_fired_pixels', true ), $firedPixels ) );
                    }

                    $order->save();
                }
            } else {
                // WooCommerce < 3.0
                if ( $settled ) {
                    update_post_meta( $order_id, '_pys_advance_purchase_event_fired', true );
                    if ( $mark_apt ) {
                        update_post_meta( $order_id, '_pys_tracking_type', 'apt' );
                    }
                }

                // Save fired pixels to order meta
                if ( ! empty( $firedPixels ) ) {
                    update_post_meta( $order_id, '_pys_server_fired_pixels', self::mergeFiredPixels( get_post_meta( $order_id, '_pys_server_fired_pixels', true ), $firedPixels ) );
                }
            }

            if ( $advanced && $retry ) {
                $this->schedulePurchaseFallback( 'woo', $order_id, true );
            } elseif ( $plan['wait'] > 0 ) {
                // Come back once the browser's grace window is over.
                $this->schedulePurchaseFallback( 'woo', $order_id, false, $plan['wait'] + 5 );
            } elseif ( $settled ) {
                PurchaseDelivery::recordRun( 'woo', $order_id, PurchaseDelivery::RUN_SETTLED );
            }

            // Reset fired pixels for next request
            self::resetFiredPixels();
        } finally {
            if ( $have_lock ) {
                $this->release_purchase_lock( 'woo', $order_id );
            }
        }
    }

    /**
     * Did an earlier order-status run deliver the Purchase to an ads platform,
     * by the delivery record of the order?
     *
     * @param string         $type
     * @param \WC_Order|int $order_or_id
     * @return bool
     */
    private static function orderStatusDelivered( $type, $order_or_id ) {
        $status = PurchaseDelivery::getOrderStatus( $type, $order_or_id );

        foreach ( is_array( $status ) && ! empty( $status['api'] ) ? $status['api'] : array() as $platform => $entry ) {
            if ( 'ga' === $platform || empty( $entry['pixels'] ) || ! is_array( $entry['pixels'] ) ) {
                continue;
            }
            foreach ( $entry['pixels'] as $pixel ) {
                if ( isset( $pixel['source'], $pixel['outcome'] )
                    && PurchaseDelivery::SOURCE_ORDER_STATUS === $pixel['source']
                    && in_array( $pixel['outcome'], array( PurchaseDelivery::OUTCOME_ACCEPTED, PurchaseDelivery::OUTCOME_UNCONFIRMED ), true ) ) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Did the order-status path send the Purchase to any ads platform? GA4
     * entries do not count: it is sent ahead of the checkout AJAX guard.
     *
     * @param mixed ...$lists Platform lists or platform => pixels maps
     * @return bool
     */
    private static function hasAdsDelivery( ...$lists ) {
        foreach ( $lists as $list ) {
            if ( ! is_array( $list ) ) {
                continue;
            }
            unset( $list['ga'] );
            $list = array_filter( $list, function ( $item ) {
                return 'ga' !== $item;
            } );
            if ( ! empty( $list ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Tracks a WooCommerce refund (partial or full)
     *
     * @param int $order_id  The order ID
     * @param int $refund_id The refund ID
     * @return void
     */
    public function woo_refund_order( $order_id, $refund_id = 0 ) {
        $log = $this->logger;
        $log->debug( "Send woo_refund_order" );

        $ga_option = PYS()->getOption( 'woo_track_refunds_GA' );
        if ( ! $ga_option && ! RefundEvents::any_switch_on( 'woo' ) ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        // wc_get_order() returns orders and refunds alike, so make sure it is really a refund.
        $refund_id = (int) $refund_id;
        $refund    = $refund_id ? wc_get_order( $refund_id ) : null;
        if ( ! $refund instanceof \WC_Order_Refund ) {
            $refund = null;
        }

        // Which destinations take it is settled before anything is built or reset.
        $ga_on = false;
        if ( $ga_option ) {
            if ( pys_order_purchase_blocked( 'woo', $order, 'ga' ) ) {
                $log->debug( "woo_refund_order: GA refund skipped, GA purchase blocked for order $order_id" );
            } elseif ( $refund_id && in_array( $refund_id, $this->get_sent_ga4_refunds( $order ), true ) ) {
                $log->debug( "woo_refund_order: refund $refund_id of order $order_id already sent" );
            } elseif ( $order->get_meta( '_pys_ga4_refund_status_sent', true ) ) {
                // The order was already reversed in full by a manual switch to Refunded,
                // so a refund record entered afterwards must not reverse it a second time.
                $log->debug( "woo_refund_order: order $order_id was already reversed by status change" );
            } else {
                $ga_on = true;
            }
        }
        $platforms = RefundEvents::destinations( 'woo', $order, $refund_id, false );
        if ( ! $ga_on && empty( $platforms ) ) {
            return;
        }

        $event = EventsWoo()->getRefundEvent( 'woo_refund', $order, $refund );
        if ( $event == null ) {
            return;
        }

        // Marked before sending so a repeated hook call in the same request cannot duplicate it.
        // getRefundEvent() may save the order itself, hence the list is re-read right before writing.
        if ( $ga_on && $refund_id ) {
            $sent   = $this->get_sent_ga4_refunds( $order );
            $sent[] = $refund_id;
            $order->update_meta_data( '_pys_ga4_refunds_sent', array_values( array_unique( $sent ) ) );
            $order->save();
        }

        if ( $ga_on ) {
            $gaEvents = GA()->generateEvents( $event );
            GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents );
        }
        if ( ! empty( $platforms ) ) {
            RefundEvents::send( 'woo', $event, $order, $platforms );
        }
    }

    /**
     * Tracks a switch of a WooCommerce order to Refunded that left no refund record behind.
     *
     * With stock WooCommerce this does not happen: wc_order_fully_refunded() creates the
     * record before this runs, and woocommerce_order_refunded reports it. The handler
     * covers sites that unhook that core action.
     *
     * @param int $order_id The order ID
     * @return void
     */
    public function woo_order_refunded_status( $order_id ) {
        $log = $this->logger;
        $log->debug( "Send woo_order_refunded_status" );

        $ga_option = PYS()->getOption( 'woo_track_refunds_GA' );
        if ( ( ! $ga_option && ! RefundEvents::any_switch_on( 'woo' ) ) || ! isWooCommerceActive() ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $ga_on = (bool) $ga_option;
        if ( $ga_on && pys_order_purchase_blocked( 'woo', $order, 'ga' ) ) {
            $log->debug( "woo_order_refunded_status: GA refund skipped, GA purchase blocked for order $order_id" );
            $ga_on = false;
        }

        // Any refund record means woocommerce_order_refunded has reported, or will report,
        // the money: a full refund saves its record before update_status('refunded'), and
        // a manual switch gets one from wc_order_fully_refunded() at priority 10.
        if ( ! empty( $order->get_refunds() ) ) {
            $log->debug( "woo_order_refunded_status: order $order_id has refunds, skipped" );
            return;
        }

        if ( $ga_on && $order->get_meta( '_pys_ga4_refund_status_sent', true ) ) {
            $log->debug( "woo_order_refunded_status: order $order_id already sent" );
            $ga_on = false;
        }

        $platforms = RefundEvents::destinations( 'woo', $order, 0, false );
        if ( ! $ga_on && empty( $platforms ) ) {
            return;
        }

        $event = EventsWoo()->getRefundEvent( 'woo_refund', $order, null );
        if ( $event == null ) {
            return;
        }

        // Marked before sending; getRefundEvent() may have saved the order, so write after it.
        if ( $ga_on ) {
            $order->update_meta_data( '_pys_ga4_refund_status_sent', 1 );
            $order->save();

            $gaEvents = GA()->generateEvents( $event );
            GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents );
        }
        if ( ! empty( $platforms ) ) {
            RefundEvents::send( 'woo', $event, $order, $platforms );
        }
    }

    /**
     * Sends a GA4 refund for a cancelled order whose GA4 Purchase is on record.
     *
     * The refund covers what is left of the order: after a partial refund that is
     * the total minus the refund records. An order already reversed (fully refunded,
     * or by the Refunded status) sends nothing. Every gate runs before anything is
     * changed, so a refusal leaves the order's purchase flags alone.
     *
     * @param int $order_id The order ID
     * @return void
     */
    public function woo_order_cancelled_status( $order_id ) {
        $log = $this->logger;

        if ( ! PYS()->getOption( 'woo_track_canceled_GA' ) || ! isWooCommerceActive() ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $ga_on = true;
        if ( pys_order_purchase_blocked( 'woo', $order, 'ga' ) ) {
            $log->debug( "woo_order_cancelled_status: GA cancel skipped, GA purchase blocked for order $order_id" );
            $ga_on = false;
        }

        // A Purchase fired on Cancelled has nothing to reverse: the cancel is the purchase.
        $purchase_statuses = (array) PYS()->getOption( 'woo_order_advanced_purchase_status', array() );
        if ( in_array( 'wc-cancelled', $purchase_statuses, true ) || in_array( 'cancelled', $purchase_statuses, true ) ) {
            $log->debug( "woo_order_cancelled_status: order $order_id skipped, Cancelled is a purchase status" );
            return;
        }

        if ( $ga_on && $order->get_meta( '_pys_ga4_refund_status_sent', true ) ) {
            $log->debug( "woo_order_cancelled_status: order $order_id already reversed" );
            $ga_on = false;
        }

        if ( EventsWoo()->isOrderFullyRefunded( $order ) ) {
            $log->debug( "woo_order_cancelled_status: order $order_id fully refunded, nothing left" );
            return;
        }

        if ( $ga_on && ! pys_order_purchase_on_record( 'woo', $order, 'ga' ) ) {
            $log->debug( "woo_order_cancelled_status: order $order_id has no GA4 Purchase on record" );
            $ga_on = false;
        }

        $platforms = RefundEvents::destinations( 'woo', $order, 0, true );
        if ( ! $ga_on && empty( $platforms ) ) {
            return;
        }

        // The order is re-opened for a new purchase, as after a full refund.
        EventsWoo()->resetPurchaseFlags( $order );

        // Marked before sending; the reset above saved the order, so write after it.
        if ( $ga_on ) {
            $order->update_meta_data( '_pys_ga4_refund_status_sent', 1 );
            $order->save();
        }

        $event = EventsWoo()->getCancelEvent( 'woo_refund', $order );
        if ( $event == null ) {
            return;
        }

        if ( $ga_on ) {
            $gaEvents = GA()->generateEvents( $event );
            GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents );
        }
        if ( ! empty( $platforms ) ) {
            RefundEvents::send( 'woo', $event, $order, $platforms );
        }
    }

    /**
     * Returns the IDs of refunds already sent to GA4 for the order
     *
     * @param WC_Order $order The order
     * @return int[]
     */
    private function get_sent_ga4_refunds( $order ) {
        $sent = $order->get_meta( '_pys_ga4_refunds_sent', true );
        if ( ! is_array( $sent ) ) {
            return array();
        }
        return array_map( 'intval', $sent );
    }

    /**
     * Determine whether a WooCommerce renewal order is a manual or automatic renewal.
     *
     * Manual   = the subscription is set to manual renewal, or an early renewal was
     *            initiated by the customer.
     * Automatic = the renewal was charged automatically by the payment gateway
     *            (scheduled/recurring billing).
     *
     * @param WC_Order|int $order Renewal order object or ID.
     * @return string 'manual' | 'automatic'
     */
    private function get_woo_renewal_type( $order ) {
        return pys_woo_renewal_type( $order );
    }

    /**
     * Determine whether the current EDD renewal was triggered manually by an admin.
     *
     * Manual   = renewal added from the subscription single view in wp-admin
     *            (edd_recurring_process_add_renewal_payment, guarded by its nonce).
     * Automatic = renewal recorded by a payment gateway webhook / IPN.
     *
     * @return string 'manual' | 'automatic'
     */
    private function get_edd_renewal_type() {
        return pys_edd_renewal_type();
    }

    /**
     * Decide whether a renewal event/purchase should be skipped for the given renewal type.
     *
     * @param string $renewal_type  'manual' | 'automatic'
     * @param string $auto_option   Option key that excludes automatic renewals.
     * @param string $manual_option Option key that excludes manual renewals.
     * @return bool True if the event should be skipped.
     */
    private function should_skip_renewal( $renewal_type, $auto_option, $manual_option ) {
        if ( 'manual' === $renewal_type ) {
            return (bool) PYS()->getOption( $manual_option );
        }
        return (bool) PYS()->getOption( $auto_option );
    }

    public function woo_subscription_created(WC_Subscription $subscription)
    {

        $subscription_id = is_object( $subscription ) ? $subscription->get_id() : $subscription;

        $subscription_info = array(
            'subscription_id' => $subscription_id
        );

        $this->logger->debug( 'Woo Subscription Created', array(
            'subscription_id' => $subscription_id,
            'timestamp' => current_time( 'mysql' )
        ) );

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'woo_track_subscriptions' ) ) {
            $this->logger->debug( 'Woo subscription tracking is disabled' );
            return;
        }

        if ( !$subscription || !$subscription_id ) {
            $this->logger->debug( 'Failed to load subscription object', array( 'subscription_id' => $subscription_id ) );
            return;
        }

        // Check if this is a renewal payment, not initial subscription creation
        $last_order = $subscription->get_last_order();
        $last_order_id = is_object( $last_order ) ? $last_order->get_id() : $last_order;

        // Determine event type based on subscription status
        $event_id = 'woo_subscription_created';
        $is_trial = false;

        if ( $last_order && function_exists('wcs_order_contains_renewal') && wcs_order_contains_renewal($last_order) ) {
            $renewal_type = $this->get_woo_renewal_type( $last_order );

            // Respect the per-type renewal exclusion options for the SubscriptionRenewal event.
            if ( $this->should_skip_renewal( $renewal_type, 'woo_subscriptions_dont_track_auto_renewal', 'woo_subscriptions_dont_track_manual_renewal' ) ) {
                $this->logger->debug( 'Woo SubscriptionRenewal event skipped by settings', array(
                    'subscription_id' => $last_order_id,
                    'renewal_type'    => $renewal_type,
                ) );
                return;
            }

            $event_id = 'woo_subscription_renewal';
            $subscription_info['subscription_id'] = $last_order_id;
            $subscription_info['renewal_type'] = $renewal_type;
            $this->logger->debug( 'Subscription Renewed event triggered', array(
                'subscription_id' => $last_order_id,
                'status' => $subscription->get_status(),
                'renewal_type' => $renewal_type
            ) );
        } elseif ( ! empty( $subscription->get_trial_period()) ) {
            $event_id = 'woo_start_trial';
            $is_trial = true;
            $subscription_info['trial_period'] = $subscription->get_trial_period();
            $this->logger->debug( 'Start Trial event triggered', array(
                'subscription_id' => $subscription_id,
                'trial_period' => $subscription->get_trial_period(),
                'status' => $subscription->get_status()
            ) );
        } else {
            $this->logger->debug( 'Subscription Created event triggered', array(
                'subscription_id' => $subscription_id,
                'status' => $subscription->get_status()
            ) );
        }

        // Set filter to pass subscription_id to EventsEdd
        add_filter( 'pys_woo_subscription', function () use ( $subscription_info ) {
            return $subscription_info;
        } );

        // Get event from EventsEdd
        $event = EventsWoo()->getEvent( $event_id );

        // Remove filter
        remove_all_filters( 'pys_woo_subscription' );

        if ( $event == null ) {
            $this->logger->debug( 'Event is null, skipping', array( 'event_id' => $event_id ) );
            return;
        }

        // Add eventID for deduplication
        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );

        // Send to platforms
        $this->send_subscription_event( $event, 'woo' );
    }
    /**
     * Handle WooCommerce subscription status change
     *
     * @param int $subscription_id Subscription ID
     * @param string $new_status New status
     * @param string $old_status Old status
     * @return void
     */
    public function woo_subscription_status_change(WC_Subscription $subscription, $new_status, $old_status ) {
        $subscription_info = array(
            'old_status' => $old_status,
            'new_status' => $new_status,
            'timestamp' => current_time( 'mysql' )
        );

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'woo_track_subscriptions' ) ) {
            $this->logger->debug( 'WOO subscription tracking is disabled' );
            return;
        }

        // Get subscription ID
        $subscription_id = is_object( $subscription ) ? $subscription->get_id() : $subscription;

        $subscription_info['subscription_id'] = $subscription_id;

        add_filter( 'pys_woo_subscription', function () use ( $subscription_info ) {
            return $subscription_info;
        } );

        // Handle different status changes
        if ( $new_status === 'expired' && $old_status !== 'expired' ) {
            $this->logger->debug( 'Subscription expired event triggered', array( 'subscription_id' => $subscription_id ) );
            $event = EventsWoo()->getEvent( 'woo_subscription_expired' );

        } elseif ( $new_status === 'cancelled' && $old_status !== 'cancelled' ) {
            $this->logger->debug( 'Subscription canceled event triggered', array( 'subscription_id' => $subscription_id ) );
            $event = EventsWoo()->getEvent( 'woo_subscription_canceled' );
        }

        remove_all_filters( 'pys_woo_subscription' );
        if (empty($event)) {
            return;
        }
        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );
        $this->send_subscription_event( $event, 'woo' );
    }

    /**
     * Tracks an EDD completed purchase
     *
     * @param int $payment_id The payment ID
     * @return void
     */
    public function edd_completed_purchase( $payment_id ) {
        if ( ! PYS()->getOption( 'edd_advance_purchase_fb_enabled' )
            && ! PYS()->getOption( 'edd_advance_purchase_ga_enabled' )
            && ( ! Tiktok()->enabled() || ( Tiktok()->enabled() && ! Tiktok()->getOption( 'edd_advance_purchase_enabled' ) ) )
            && ( ! Pinterest()->enabled() || ( Pinterest()->enabled() && ! Pinterest()->getOption( 'edd_advance_purchase_enabled' ) ) )
            && ( ! OpenAI()->enabled() || ( OpenAI()->enabled() && ! OpenAI()->getOption( 'edd_advance_purchase_enabled' ) ) )
        ) {
            return;
        }

        $userId = edd_get_payment_user_id( $payment_id );
        $user = get_user_by( 'id', $userId );
        if ( isDisabledForUserRole( $user ) ) {
            PurchaseDelivery::recordRun( 'edd', $payment_id, PurchaseDelivery::RUN_SKIPPED, array( 'reason' => 'user_role' ) );
            return;
        }
        if ( ! PYS()->getOption( 'edd_enabled_purchase_recurring' ) || ! PYS()->getOption( 'edd_purchase_enabled' ) ) {
            PurchaseDelivery::recordRun( 'edd', $payment_id, PurchaseDelivery::RUN_SKIPPED, array( 'reason' => 'purchase_disabled' ) );
            return;
        }

        add_filter( 'pys_edd_checkout_order_id', function () use ( $payment_id ) {
            return $payment_id;
        } );

        // Atomic deduplication (mirrors woo_completed_purchase): a per-payment
        // MySQL named lock serializes concurrent triggers so they cannot all
        // pass the "already fired" check before it is written, which otherwise
        // produces duplicate purchase events.
        $lock_state = $this->acquire_purchase_lock( 'edd', $payment_id );
        if ( 'busy' === $lock_state ) {
            $this->logger->debug( "Blocked edd_completed_purchase: another process is already firing payment {$payment_id}" );
            return;
        }
        $have_lock = ( 'acquired' === $lock_state );

        try {
            // See woo_completed_purchase(): the browser flag does not stop the
            // server copy, the browser marker decides per platform.
            $advanced = PurchaseDelivery::isAdvancedMode( 'edd' );
            wp_cache_delete( $payment_id, 'edd_order_meta' );
            if ( PYS()->getOption( 'edd_purchase_on_transaction' ) && edd_get_payment_meta( $payment_id, '_pys_advance_purchase_event_fired', true ) ) {
                return;
            }
            $plan = $this->browserPurchasePlan( 'edd', $payment_id, $advanced );
            $event = EventsEdd()->getEvent('edd_purchase', false);
            if ( $event == null ) {
                return;
            }
            // eventID is now generated in EventsEdd::getEvent() for proper server-browser deduplication
            // Do NOT override it here - the event already has eventID in payload
            $event->addParams( array( 'advanced_purchase_tracking' => true ) );
            $event->addPayload( array( 'pys_order_status_send' => true ) );

            $sent  = array();
            $retry = $this->sendEddPurchase( $payment_id, $event, $advanced, $plan['skip'], $sent );

            $firedPixels = self::getFiredPixels();

            if ( $payment_id ) {

                // Mark that server-side purchase event was fired. Advanced: only
                // once nothing is left to retry; Single: only once the server
                // really sent something. Never while a platform waits for the
                // browser marker.
                $server_sent = $advanced ? array() : PurchaseDelivery::singleServerSent( 'edd', $payment_id, $sent );
                $settled     = $plan['wait'] === 0 && ( $advanced
                    ? ! $retry
                    : ! empty( $server_sent ) );
                if ( $settled ) {
                    edd_update_payment_meta( $payment_id, '_pys_advance_purchase_event_fired', true );
                }

                // Save fired pixels to order meta
                if ( ! empty( $firedPixels ) ) {
                    edd_update_payment_meta( $payment_id, '_pys_server_fired_pixels', self::mergeFiredPixels( edd_get_payment_meta( $payment_id, '_pys_server_fired_pixels', true ), $firedPixels ) );
                }

                if ( $advanced && $retry ) {
                    $this->schedulePurchaseFallback( 'edd', $payment_id, true );
                } elseif ( $plan['wait'] > 0 ) {
                    $this->schedulePurchaseFallback( 'edd', $payment_id, false, $plan['wait'] + 5 );
                } elseif ( $settled ) {
                    PurchaseDelivery::recordRun( 'edd', $payment_id, PurchaseDelivery::RUN_SETTLED );
                }
            }
            // Reset fired pixels for next request
            self::resetFiredPixels();
        } finally {
            if ( $have_lock ) {
                $this->release_purchase_lock( 'edd', $payment_id );
            }
        }
    }


    /**
     * Sends a GA4 refund for a cancelled EDD payment whose GA4 Purchase is on record.
     *
     * EDD's refund event always reports the whole payment, so a payment with any
     * refund has already been reversed in GA4 and sends nothing here. Every gate
     * runs before anything is changed, so a refusal leaves the purchase flags alone.
     *
     * @param string $old_status Previous order status
     * @param string $new_status New order status
     * @param int    $order_id   The order ID
     * @return void
     */
    public function edd_order_cancelled_status( $old_status, $new_status, $order_id ) {
        $log = $this->logger;

        if ( 'cancelled' !== $new_status || 'cancelled' === $old_status ) {
            return;
        }

        if ( ! PYS()->getOption( 'edd_track_canceled_GA' ) || ! isEddActive() || ! $order_id ) {
            return;
        }

        $ga_on = true;
        if ( pys_order_purchase_blocked( 'edd', $order_id, 'ga' ) ) {
            $log->debug( "edd_order_cancelled_status: GA cancel skipped, GA purchase blocked for order $order_id" );
            $ga_on = false;
        }

        // Any refund already reversed the whole payment in GA4.
        $has_refund = false;
        if ( function_exists( 'edd_get_order_refunds' ) ) {
            $refunds    = edd_get_order_refunds( $order_id );
            $has_refund = ! empty( $refunds );
        }
        if ( ! $has_refund ) {
            // The current status is already 'cancelled' at this hook; the previous one tells.
            $has_refund = in_array( $old_status, array( 'refunded', 'partially_refunded' ), true );
        }
        if ( $has_refund ) {
            $log->debug( "edd_order_cancelled_status: order $order_id has a refund, already reversed" );
            return;
        }

        if ( $ga_on && edd_get_payment_meta( $order_id, '_pys_ga4_refund_status_sent', true ) ) {
            $log->debug( "edd_order_cancelled_status: order $order_id already reversed" );
            $ga_on = false;
        }

        if ( $ga_on && ! pys_order_purchase_on_record( 'edd', $order_id, 'ga' ) ) {
            $log->debug( "edd_order_cancelled_status: order $order_id has no GA4 Purchase on record" );
            $ga_on = false;
        }

        $platforms = RefundEvents::destinations( 'edd', $order_id, 0, true );
        if ( ! $ga_on && empty( $platforms ) ) {
            return;
        }

        // The payment is re-opened for a new purchase, as after a full refund.
        EventsEdd()->resetPurchaseFlags( $order_id );
        if ( $ga_on ) {
            edd_update_payment_meta( $order_id, '_pys_ga4_refund_status_sent', 1 );
        }

        $event = EventsEdd()->getRefundEvent( 'edd_refund', $order_id );
        if ( $event == null ) {
            return;
        }
        $event->args['is_cancel']   = true;
        $event->args['refund_type'] = 'cancelled';

        if ( $ga_on ) {
            $gaEvents = GA()->generateEvents( $event );
            GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents );
        }
        if ( ! empty( $platforms ) ) {
            RefundEvents::send( 'edd', $event, $order_id, $platforms );
        }
    }

    /**
     * Tracks an EDD refund
     *
     * @param int $payment_id The payment ID
     * @param int $refund_id The refund ID
     * @param bool $all_refunded Whether all items were refunded
     * @return void
     */
    public function edd_refund_order( $payment_id, $refund_id, $all_refunded ) {
        $log = $this->logger;

        if ( ! PYS()->getOption( 'edd_track_refunds_GA' ) && ! RefundEvents::any_switch_on( 'edd' )
            && ! edd_get_payment_meta( $payment_id, '_pys_purchase_event_fired', true ) ) {
            return;
        }

        if ( ! $payment_id ) {
            return;
        }

        $userId = edd_get_payment_user_id( $payment_id );
        $user = get_user_by( 'id', $userId );
        if ( isDisabledForUserRole( $user ) ) {
            return;
        }

        // Destinations are settled before the reset: it clears the very markers
        // pys_order_purchase_on_record() reads.
        $ga_on     = PYS()->getOption( 'edd_track_refunds_GA' ) && ! pys_order_purchase_blocked( 'edd', $payment_id, 'ga' );
        $platforms = RefundEvents::destinations( 'edd', $payment_id, (int) $refund_id, false );

        // Only a refund of the whole payment re-opens it for a new purchase;
        // after a partial refund the payment still stands as sold.
        if ( $all_refunded ) {
            EventsEdd()->resetPurchaseFlags( $payment_id );
        }

        if ( ! $ga_on && empty( $platforms ) ) {
            return;
        }

        add_filter( 'pys_edd_checkout_order_id', function () use ( $payment_id ) {
            return $payment_id;
        } );
        $event = EventsEdd()->getEvent( 'edd_refund' );

        if ( $event == null ) {
            return;
        }
        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );

        if ( $ga_on ) {
            $gaEvents = GA()->generateEvents( $event );
            GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents );
            $log->debug( "Send completed refund GA" );
        }
        if ( ! empty( $platforms ) ) {
            $event->args['refund_id']      = (int) $refund_id;
            $event->args['is_full_refund'] = (bool) $all_refunded;
            RefundEvents::send( 'edd', $event, $payment_id, $platforms );
        }
    }

    /**
     * Tracks an EDD recurring payment
     *
     * @param int $payment_id The payment ID
     * @param int $parent_payment_id The parent payment ID
     * @param float $amount The payment amount
     * @param string $transaction_id The transaction ID
     * @return void
     */
    public function edd_recurring_payment( $payment_id, $parent_payment_id, $amount, $transaction_id ) {
        EnrichOrder()->edd_save_subscription_meta( $payment_id );

        if ( ! PYS()->getOption( 'edd_advance_purchase_fb_enabled' )
            && ! PYS()->getOption( 'edd_advance_purchase_ga_enabled' )
            && ( ! Tiktok()->enabled() || ( Tiktok()->enabled() && ! Tiktok()->getOption( 'edd_advance_purchase_enabled' ) ) )
            && ( ! Pinterest()->enabled() || ( Pinterest()->enabled() && ! Pinterest()->getOption( 'edd_advance_purchase_enabled' ) ) )
            && ( ! OpenAI()->enabled() || ( OpenAI()->enabled() && ! OpenAI()->getOption( 'edd_advance_purchase_enabled' ) ) )
        ) {
            return;
        }

        $userId = edd_get_payment_user_id( $payment_id );
        $user = get_user_by( 'id', $userId );
        if ( isDisabledForUserRole( $user ) ) {
            PurchaseDelivery::recordRun( 'edd', $payment_id, PurchaseDelivery::RUN_SKIPPED, array( 'reason' => 'user_role' ) );
            return;
        }
        if ( ! PYS()->getOption( 'edd_enabled_purchase_recurring' ) || ! PYS()->getOption( 'edd_purchase_enabled' ) ) {
            PurchaseDelivery::recordRun( 'edd', $payment_id, PurchaseDelivery::RUN_SKIPPED, array( 'reason' => 'purchase_disabled' ) );
            return;
        }

        // Respect the per-type renewal exclusion options for the Purchase event.
        $renewal_type = $this->get_edd_renewal_type();
        edd_update_payment_meta( $payment_id, '_pys_renewal_type', $renewal_type );
        if ( $this->should_skip_renewal( $renewal_type, 'edd_purchase_dont_track_auto_renewal', 'edd_purchase_dont_track_manual_renewal' ) ) {
            PYS()->getLog()->debug( "Purchase recurring Edd skipped by settings", array( 'payment_id' => $payment_id, 'renewal_type' => $renewal_type ) );
            return;
        }

        $fire_event = true;
        $advanced   = PurchaseDelivery::isAdvancedMode( 'edd' );
        if ( PYS()->getOption( 'edd_purchase_on_transaction' ) && edd_get_payment_meta( $payment_id, '_pys_advance_purchase_event_fired', true ) ) {
            $fire_event = false;
        }
        // A renewal has no thank-you page of its own, so no browser pending
        // meta: the decision is "send" unless a legacy flag says otherwise.
        $plan = $this->browserPurchasePlan( 'edd', $payment_id, $advanced );
        PYS()->getLog()->debug( "Purchase recurring Edd", $payment_id );
        add_filter( 'pys_edd_checkout_order_id', function () use ( $payment_id ) {
            return $payment_id;
        } );

        $event = EventsEdd()->getEvent('edd_purchase', false);
        if ( $event == null ) {
            return;
        }
        // eventID is now generated in EventsEdd::getEvent() for proper server-browser deduplication
        // Same marker as the other order-status sends (see AbstractServerEvents::isPurchaseEventAlreadySent()).
        $event->addParams( array( 'advanced_purchase_tracking' => true ) );
        $event->addPayload( array( 'pys_order_status_send' => true ) );

        $sent  = array();
        $retry = false;
        if ( $fire_event ) {
            $retry = $this->sendEddPurchase( $payment_id, $event, $advanced, $plan['skip'], $sent );
        }

        $firedPixels = self::getFiredPixels();

        if ( $payment_id ) {

            // Mark that server-side purchase event was fired. Advanced: only
            // once nothing is left to retry or waits for the browser marker;
            // Single: only once the server really sent something.
            $server_sent = $advanced ? array() : PurchaseDelivery::singleServerSent( 'edd', $payment_id, $sent );
            $settled     = $plan['wait'] === 0 && ( $advanced
                ? ! $retry
                : ( ! $fire_event || ! empty( $server_sent ) ) );
            if ( $settled ) {
                edd_update_payment_meta( $payment_id, '_pys_advance_purchase_event_fired', true );
            }

            // Save fired pixels to order meta
            if ( ! empty( $firedPixels ) ) {
                edd_update_payment_meta( $payment_id, '_pys_server_fired_pixels', self::mergeFiredPixels( edd_get_payment_meta( $payment_id, '_pys_server_fired_pixels', true ), $firedPixels ) );
            }

            if ( $advanced && $retry ) {
                $this->schedulePurchaseFallback( 'edd', $payment_id, true );
            } elseif ( $plan['wait'] > 0 ) {
                $this->schedulePurchaseFallback( 'edd', $payment_id, false, $plan['wait'] + 5 );
            } elseif ( $settled ) {
                PurchaseDelivery::recordRun( 'edd', $payment_id, PurchaseDelivery::RUN_SETTLED );
            }
        }
        // Reset fired pixels for next request
        self::resetFiredPixels();
    }

    /**
     * Handle EDD subscription status change
     *
     * @param int $subscription_id Subscription ID
     * @param string $new_status New status
     * @param string $old_status Old status
     * @return void
     */
    public function edd_subscription_status_change( $old_status, $new_status, $subscription ) {
        if(empty($subscription) || empty($subscription->id)){ return; }
        $this->logger->debug( 'EDD Subscription Status Change', array(
            'old_status' => $old_status,
            'new_status' => $new_status,
            'subscription' => $subscription,
            'timestamp'  => current_time( 'mysql' ),
        ) );

        // Bail if status hasn't actually changed
        if ( $old_status === $new_status ) {
            return;
        }

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'edd_track_subscriptions' ) ) {
            $this->logger->debug( 'EDD subscription tracking is disabled' );
            return;
        }

        // Get subscription ID
        $subscription_id = is_object( $subscription ) ? $subscription->id : $subscription;
        $this->logger->debug( 'Subscription ID', $subscription_id );
        if ( empty( $subscription_id ) ) {
            return;
        }

        $subscription_info = array(
            'subscription'    => $subscription,
            'subscription_id' => $subscription_id,
            'old_status'      => $old_status,
            'new_status'      => $new_status,
            'timestamp'       => current_time( 'mysql' ),
        );

        // Determine which event to fire based on the status transition
        $event_id = null;

        if ( $new_status === 'active' && $old_status !== 'trialling' ) {
            // Fire only when the subscription was previously skipped due to a pending payment
            // and later confirmed by the gateway (meta set in edd_subscription_created).
            $needs_event = edd_recurring_get_subscription_meta( $subscription_id, '_pys_needs_created_event', true );
            if ( $needs_event ) {
                edd_recurring_delete_subscription_meta( $subscription_id, '_pys_needs_created_event' );
                $event_id = 'edd_subscription_created';
                $this->logger->debug( 'Subscription Created (deferred) event triggered', array( 'subscription_id' => $subscription_id ) );
            }

        } elseif ( $new_status === 'expired' ) {
            $event_id = 'edd_subscription_expired';
            $this->logger->debug( 'Subscription Expired event triggered', array( 'subscription_id' => $subscription_id ) );

        } elseif ( $new_status === 'cancelled' ) {
            $event_id = 'edd_subscription_canceled';
            $this->logger->debug( 'Subscription Canceled event triggered', array( 'subscription_id' => $subscription_id ) );
        }

        if ( $event_id === null ) {
            return;
        }

        add_filter( 'pys_edd_subscription', function () use ( $subscription_info ) {
            return $subscription_info;
        } );

        $event = EventsEdd()->getEvent( $event_id );
        remove_all_filters( 'pys_edd_subscription' );

        if ( $event == null ) {
            $this->logger->debug( 'Event is null, skipping', array( 'event_id' => $event_id ) );
            return;
        }

        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );
        $this->send_subscription_event( $event, 'edd' );
    }

    /**
     * Handle EDD subscription created
     *
     * @param int $subscription_id Subscription ID
     * @param array $args Subscription arguments
     * @return void
     */
    public function edd_subscription_created( $subscription_id, $args ) {

        $subscription_info = array(
            'subscription_id' => $subscription_id
        );

        $this->logger->debug( 'EDD Subscription Created', array(
            'subscription_id' => $subscription_id,
            'args' => $args,
            'timestamp' => current_time( 'mysql' )
        ) );

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'edd_track_subscriptions' ) ) {
            $this->logger->debug( 'EDD subscription tracking is disabled' );
            return;
        }

        // ── Temporary-subscription filter ──────────────────────────────────────
        // EDD Recurring creates an intermediate subscription during checkout with
        // a "pending" parent payment. We skip that entry and wait for the final,
        // gateway-confirmed one.
        $parent_payment_id = ! empty( $args['parent_payment_id'] ) ? absint( $args['parent_payment_id'] ) : 0;

        if ( $parent_payment_id > 0 ) {

            $payment = new \EDD_Payment( $parent_payment_id );

            if ( $payment && $payment->ID ) {

                $order_number    = (string) $payment->number;
                $payment_status  = (string) $payment->status;
                $gateway         = (string) $payment->gateway;
                $total           = (float)  $payment->total;

                $log_context = wp_json_encode( array(
                    'subscription_id'   => $subscription_id,
                    'parent_payment_id' => $parent_payment_id,
                    'order_number'      => $order_number,
                    'payment_status'    => $payment_status,
                    'gateway'           => $gateway,
                    'total'             => $total,
                ) );

                // Skip when the order number itself signals a pending/draft entry.
                // Mark the subscription so edd_subscription_status_change can fire the event later.
                if ( stripos( $order_number, 'pending' ) !== false ) {
                    edd_recurring_update_subscription_meta( $subscription_id, '_pys_needs_created_event', 1 );
                    $this->logger->debug( '[EDD_FILTER] Skipped temporary sub #' . $subscription_id . ' – marked for deferred event', json_decode( $log_context, true ) );
                    return;
                }

                // Skip when the payment has not been confirmed by the gateway yet.
                // Mark the subscription so edd_subscription_status_change can fire the event later.
                if ( $payment_status === 'pending' ) {
                    edd_recurring_update_subscription_meta( $subscription_id, '_pys_needs_created_event', 1 );
                    $this->logger->debug( '[EDD_FILTER] Skipped temporary sub #' . $subscription_id . ' – marked for deferred event', json_decode( $log_context, true ) );
                    return;
                }

                $this->logger->debug( '[EDD_FILTER] Valid sub #' . $subscription_id . ' confirmed.', json_decode( $log_context, true ) );

            } else {
                // Payment object could not be loaded – log and skip to avoid
                // processing a subscription with no verifiable parent payment.
                $this->logger->debug( '[EDD_FILTER] Skipped temporary sub #' . $subscription_id . ' – EDD_Payment #' . $parent_payment_id . ' not found.' );
                return;
            }
        } else {
            // No parent_payment_id in $args – cannot verify the payment, skip.
            $this->logger->debug( '[EDD_FILTER] Skipped temporary sub #' . $subscription_id . ' – parent_payment_id missing from args.' );
        }
        // ── End temporary-subscription filter ─────────────────────────────────

        // Load subscription object to check status
        $subscription = new \EDD\Recurring\Subscriptions\Subscription( $subscription_id );

        if ( ! $subscription || ! $subscription->id ) {
            $this->logger->debug( 'Failed to load subscription object', array( 'subscription_id' => $subscription_id ) );
            return;
        }

        // Determine event type based on subscription status
        $event_id = 'edd_subscription_created';
        $is_trial = false;

        if ( $subscription->status === 'trialling' && ! empty( $subscription->trial_period ) ) {
            $event_id = 'edd_start_trial';
            $is_trial = true;
            $subscription_info['trial_period'] = $subscription->trial_period;
            $this->logger->debug( 'Start Trial event triggered', array(
                'subscription_id' => $subscription_id,
                'trial_period' => $subscription->trial_period,
                'status' => $subscription->status
            ) );
        } else {
            $this->logger->debug( 'Subscription Created event triggered', array(
                'subscription_id' => $subscription_id,
                'status' => $subscription->status
            ) );
        }

        // Set filter to pass subscription_id to EventsEdd
        add_filter( 'pys_edd_subscription', function () use ( $subscription_info ) {
            return $subscription_info;
        } );

        // Get event from EventsEdd
        $event = EventsEdd()->getEvent( $event_id );

        // Remove filter
        remove_all_filters( 'pys_edd_subscription' );

        if ( $event == null ) {
            $this->logger->debug( 'Event is null, skipping', array( 'event_id' => $event_id ) );
            return;
        }

        // Add eventID for deduplication
        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );

        // Send to platforms
        $this->send_subscription_event( $event, 'edd' );
    }

    /**
     * Handle EDD subscription renewed
     *
     * @param int $subscription_id Subscription ID
     * @param string $expiration Expiration date
     * @param object $subscription Subscription object
     * @param int $payment_id Payment ID
     * @return void
     */
    public function edd_subscription_renewed( $subscription_id, $expiration, $subscription, $payment_id ) {

        $subscription_info = array(
            'subscription_id' => $subscription_id,
            'expiration' => $expiration,
            'payment_id' => $payment_id,
            'timestamp' => current_time( 'mysql' )
        );
        $this->logger->debug( 'EDD Subscription Renewed', $subscription_info );

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'edd_track_subscriptions' ) ) {
            $this->logger->debug( 'EDD subscription tracking is disabled' );
            return;
        }

        // Respect the per-type renewal exclusion options for the SubscriptionRenewal event.
        $renewal_type = $this->get_edd_renewal_type();
        if ( $this->should_skip_renewal( $renewal_type, 'edd_subscriptions_dont_track_auto_renewal', 'edd_subscriptions_dont_track_manual_renewal' ) ) {
            $this->logger->debug( 'EDD SubscriptionRenewal event skipped by settings', array(
                'subscription_id' => $subscription_id,
                'renewal_type'    => $renewal_type,
            ) );
            return;
        }
        $subscription_info['renewal_type'] = $renewal_type;

        // Set filter to pass subscription_id
        add_filter( 'pys_edd_subscription', function () use ( $subscription_info ) {
            return $subscription_info;
        } );

        // Get event from EventsEdd
        $event = EventsEdd()->getEvent( 'edd_subscription_renewal' );

        // Remove filter
        remove_all_filters( 'pys_edd_subscription' );

        if ( $event == null ) {
            $this->logger->debug( 'Event is null, skipping' );
            return;
        }

        // Add eventID for deduplication
        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );

        // The renewal payment: the readers take its page, action source and time
        // from it. edd_order stays the parent.
        $event->addPayload( array( 'edd_renewal_order' => (int) $payment_id ) );

        // Send to platforms
        $this->send_subscription_event( $event, 'edd' );
    }

    /**
     * Handle EDD license status change
     *
     * @param int $license_id License ID
     * @param string $status New status
     * @return void
     */
    public function edd_license_status_change( $license_id, $status ) {
        $this->logger->debug( 'EDD License Status Change', array(
            'license_id' => $license_id,
            'status' => $status,
            'timestamp' => current_time( 'mysql' )
        ) );

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'edd_track_licenses' ) ) {
            $this->logger->debug( 'EDD license tracking is disabled' );
            return;
        }

        // Handle expired status
        if ( $status === 'expired' ) {
            $this->logger->debug( 'License expired event triggered', array( 'license_id' => $license_id ) );

            // Set filter to pass license_id
            add_filter( 'pys_edd_license_id', function () use ( $license_id ) {
                return $license_id;
            } );

            $event = EventsEdd()->getEvent( 'edd_license_expired' );
            remove_all_filters( 'pys_edd_license_id' );

            if ( $event == null ) {
                return;
            }

            $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );
            $this->send_license_event( $event );
        }
    }

    /**
     * Handle EDD license upgraded
     *
     * @param int $license_id License ID
     * @param array $args Upgrade arguments
     * @return void
     */
    public function edd_license_upgraded( $license_id, $args ) {
        $this->logger->debug( 'EDD License Upgraded', array(
            'license_id' => $license_id,
            'args' => $args,
            'timestamp' => current_time( 'mysql' )
        ) );

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'edd_track_licenses' ) ) {
            $this->logger->debug( 'EDD license tracking is disabled' );
            return;
        }

        $this->logger->debug( 'License upgrade event triggered', array( 'license_id' => $license_id ) );

        // Set filter to pass license_id
        add_filter( 'pys_edd_license_id', function () use ( $license_id ) {
            return $license_id;
        } );

        $event = EventsEdd()->getEvent( 'edd_license_upgrade' );
        remove_all_filters( 'pys_edd_license_id' );

        if ( $event == null ) {
            return;
        }

        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );
        $this->send_license_event( $event );
    }

    /**
     * Handle EDD license renewed
     *
     * @param int $license_id License ID
     * @param string $new_expiration New expiration date
     * @return void
     */
    public function edd_license_renewed( $license_id, $new_expiration ) {
        $this->logger->debug( 'EDD License Renewed', array(
            'license_id' => $license_id,
            'new_expiration' => $new_expiration,
            'timestamp' => current_time( 'mysql' )
        ) );

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'edd_track_licenses' ) ) {
            $this->logger->debug( 'EDD license tracking is disabled' );
            return;
        }

        $this->logger->debug( 'License renewal event triggered', array( 'license_id' => $license_id ) );

        // Set filter to pass license_id
        add_filter( 'pys_edd_license_id', function () use ( $license_id ) {
            return $license_id;
        } );

        $event = EventsEdd()->getEvent( 'edd_license_renewal' );
        remove_all_filters( 'pys_edd_license_id' );

        if ( $event == null ) {
            return;
        }

        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );
        $this->send_license_event( $event );
    }

    /**
     * Handle EDD license created
     *
     * @param int $license_id License ID
     * @param int $download_id Download ID
     * @param int $payment_id Payment ID
     * @param string $type Purchase type
     * @return void
     */
    public function edd_license_created( $license_id, $download_id, $payment_id, $type ) {
        // Only process if this download has licensing enabled
        if ( ! function_exists( 'edd_software_licensing' ) ) {
            return;
        }

        // Check if this download has licensing
        $licensing_enabled = get_post_meta( $download_id, '_edd_sl_enabled', true );
        if ( ! $licensing_enabled ) {
            return;
        }

        $this->logger->debug( 'EDD License Created', array(
            'license_id' => $license_id,
            'download_id' => $download_id,
            'payment_id' => $payment_id,
            'type' => $type,
            'timestamp' => current_time( 'mysql' )
        ) );

        // Check if tracking is enabled
        if ( ! PYS()->getOption( 'edd_track_licenses' ) ) {
            $this->logger->debug( 'EDD license tracking is disabled' );
            return;
        }

        $this->logger->debug( 'License created event triggered', array(
            'license_id' => $license_id,
            'download_id' => $download_id,
            'payment_id' => $payment_id
        ) );

        if ( ! $license_id ) {
            $this->logger->debug( 'No license found for download', array( 'download_id' => $download_id ) );
            return;
        }

        // Set filter to pass license_id
        add_filter( 'pys_edd_license_id', function () use ( $license_id ) {
            return $license_id;
        } );

        $event = EventsEdd()->getEvent( 'edd_license_created' );
        remove_all_filters( 'pys_edd_license_id' );

        if ( $event == null ) {
            return;
        }

        $event->addPayload( array( 'eventID' => EventIdGenerator::guidv4() ) );
        $this->send_license_event( $event );
    }

    /**
     * Send subscription event to all enabled platforms
     *
     * @param object $event Event object
     * @param string $event_type Event type (trial, created, renewal, expired, canceled)
     * @return void
     */
    private function send_subscription_event( $event, $event_type = 'edd' ) {

        $option_name = $event_type.'_track_subscriptions';

        // Send Facebook server events
        if ( Facebook()->enabled()
            && Facebook()->isServerApiEnabled()
            && Facebook()->getOption( $option_name ) ) {
            $this->logger->debug( 'Sending to Facebook' );
            $fbEvents = Facebook()->generateEvents( $event );
            FacebookServer()->sendEventsNow( $fbEvents );
        }

        // Send GA server events
        if ( GA()->enabled()
            && GA()->isServerApiEnabled()
            && GA()->getOption( $option_name ) ) {
            $this->logger->debug( 'Sending to Google Analytics' );
            $gaEvents = GA()->generateEvents( $event );
            if ( ! empty( $gaEvents ) ) {
                GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents );
            }
        }

        // Send TikTok server events
        if ( Tiktok()->enabled()
            && Tiktok()->isServerApiEnabled()
            && Tiktok()->getOption( $option_name )
        ) {
            $this->logger->debug( 'Sending to TikTok' );
            $tiktokEvents = Tiktok()->generateEvents( $event );
            TikTokServer()->sendEventsNow( $tiktokEvents );
        }

        // Send OpenAI Ads server events
        if ( OpenAI()->enabled()
            && OpenAI()->isServerApiEnabled()
            && OpenAI()->getOption( $option_name )
        ) {
            $this->logger->debug( 'Sending to OpenAI' );
            $openaiEvents = OpenAI()->generateEvents( $event );
            OpenAIServer()->sendEventsNow( $openaiEvents );
        }

        // Send Pinterest server events
        if ( Pinterest()->enabled()
            && method_exists( Pinterest(), 'isServerApiEnabled' )
            && Pinterest()->isServerApiEnabled()
            && Pinterest()->getOption( $option_name )
        ) {
            $this->logger->debug( 'Sending to Pinterest' );
            $pinterestEvents = Pinterest()->generateEvents( $event );
            PinterestServer()->sendEventsNow( $pinterestEvents );
        }
    }

    /**
     * Send license event to all enabled platforms
     *
     * @param object $event Event object
     * @param string $event_type Event type (created, upgrade, renewal, expired)
     * @return void
     */
    private function send_license_event( $event ) {

        // Send Facebook server events
        if ( Facebook()->enabled()
            && Facebook()->isServerApiEnabled()
            && Facebook()->getOption( 'edd_track_licenses' ) ) {
            $this->logger->debug( 'Sending to Facebook' );
            $fbEvents = Facebook()->generateEvents( $event );
            FacebookServer()->sendEventsNow( $fbEvents );
        }

        // Send GA server events
        if ( GA()->enabled()
            && GA()->isServerApiEnabled()
            && GA()->getOption( 'edd_track_licenses' ) ) {
            $this->logger->debug( 'Sending to Google Analytics' );
            $gaEvents = GA()->generateEvents( $event );
            if ( ! empty( $gaEvents ) ) {
                GaMeasurementProtocolAPI()->sendEventsNow( $gaEvents );
            }
        }

        // Send TikTok server events
        if ( Tiktok()->enabled()
            && Tiktok()->isServerApiEnabled()
            && Tiktok()->getOption( 'edd_track_licenses' )
        ) {
            $this->logger->debug( 'Sending to TikTok' );
            $tiktokEvents = Tiktok()->generateEvents( $event );
            TikTokServer()->sendEventsNow( $tiktokEvents );
        }

        // Send Pinterest server events
        if ( Pinterest()->enabled()
            && method_exists( Pinterest(), 'isServerApiEnabled' )
            && Pinterest()->isServerApiEnabled()
            && Pinterest()->getOption( 'edd_track_licenses' )
        ) {
            $this->logger->debug( 'Sending to Pinterest' );
            $pinterestEvents = Pinterest()->generateEvents( $event );
            PinterestServer()->sendEventsNow( $pinterestEvents );
        }


    }
}

/**
 * Get singleton instance
 *
 * @return ServerEventsManager
 */
function ServerEventsManager() {
    return ServerEventsManager::instance();
}

// Initialize the manager
ServerEventsManager();

