<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * The custom Refund event for Meta, TikTok, OpenAI and Pinterest.
 *
 * Built from the same woo_refund / edd_refund SingleEvent GA4 gets, and sent
 * server-side only. It builds audiences of refunded or cancelled buyers; it
 * does not change reported revenue. The handlers in ServerEventsManager ask
 * destinations() first, so nothing is built or reset when no destination takes
 * the event, then hand the event to send().
 */
class RefundEvents {

    const PLATFORMS = array( 'facebook', 'tiktok', 'openai', 'pinterest' );

    /**
     * @param string $type 'woo' or 'edd'
     * @return bool Whether any platform has its Refund switch on.
     */
    public static function any_switch_on( $type ) {
        foreach ( self::PLATFORMS as $platform ) {
            if ( self::switch_on( $platform, $type ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Platforms that take this refund, after every gate. One debug line per
     * platform that has its switch on and is skipped.
     *
     * @param string $type        'woo' or 'edd'
     * @param mixed  $order_or_id Woo order object, or EDD payment id
     * @param int    $refund_id   Refund record id, 0 for a whole-order reversal
     * @param bool   $is_cancel   Cancellation rather than refund
     * @return string[]
     */
    public static function destinations( $type, $order_or_id, $refund_id, $is_cancel ) {
        $out = array();
        foreach ( self::PLATFORMS as $platform ) {
            if ( ! self::switch_on( $platform, $type ) ) {
                continue;
            }
            $reason = self::skip_reason( $platform, $type, $order_or_id, (int) $refund_id, (bool) $is_cancel );
            if ( null === $reason ) {
                $out[] = $platform;
            } else {
                PYS()->getLog()->debug( "RefundEvents: $platform skipped for order " . self::order_id( $order_or_id ) . ": $reason" );
            }
        }
        return $out;
    }

    /**
     * Marks the dedup meta of every destination, then sends to each.
     *
     * @param string      $type
     * @param SingleEvent $event       The refund event GA gets
     * @param mixed       $order_or_id
     * @param string[]    $platforms   From destinations()
     * @return array platform => send result
     */
    public static function send( $type, $event, $order_or_id, array $platforms ) {
        $args      = is_array( $event->args ) ? $event->args : array();
        $refund_id = (int) ( isset( $args['refund_id'] ) ? $args['refund_id'] : 0 );
        self::mark( $type, $order_or_id, $platforms, $refund_id );

        $order_key = 'woo' === $type ? 'woo_order' : 'edd_order';
        $results   = array();
        // A refund is not a Purchase: the pixels it reaches must not be recorded
        // as fired for a Purchase built later in the same request (a batch).
        $fired_before = ServerEventsManager::getFiredPixels();
        foreach ( $platforms as $platform ) {
            try {
                $out = new SingleEvent( $type . '_refund', EventTypes::$STATIC, $type );
                $out->addPayload( array(
                    'name'     => 'openai' === $platform ? 'custom' : 'Refund',
                    'eventID'  => EventIdGenerator::guidv4(),
                    $order_key => self::order_id( $order_or_id ),
                    'pixelIds' => self::pixel( $platform )->getAllPixels( false ),
                ) );
                $out->addParams( self::params( $platform, $type, $event ) );
                if ( 'pinterest' === $platform ) {
                    $results[ $platform ] = PinterestServer()->sendRefundEvent( $out );
                } else {
                    $results[ $platform ] = self::sender( $platform )->sendEventsNow( array( $out ) );
                }
            } catch ( \Throwable $e ) {
                PYS()->getLog()->debug( "RefundEvents: $platform send failed: " . $e->getMessage() );
            }
        }
        ServerEventsManager::resetFiredPixels();
        foreach ( $fired_before as $fired_platform => $fired_ids ) {
            ServerEventsManager::addFiredPixel( $fired_platform, $fired_ids );
        }
        return $results;
    }

    private static function sender( $platform ) {
        return 'facebook' === $platform ? FacebookServer() : ( 'tiktok' === $platform ? TikTokServer() : OpenAIServer() );
    }

    private static function pixel( $platform ) {
        $pixels = array( 'facebook' => 'Facebook', 'tiktok' => 'Tiktok', 'openai' => 'OpenAI', 'pinterest' => 'Pinterest' );
        return call_user_func( __NAMESPACE__ . '\\' . $pixels[ $platform ] );
    }

    private static function switch_on( $platform, $type ) {
        if ( 'pinterest' === $platform && ! self::pinterest_ready() ) {
            return false;
        }
        if ( 'facebook' === $platform ) {
            return (bool) PYS()->getOption( "{$type}_track_refunds_fb" );
        }
        return (bool) self::pixel( $platform )->getOption( "{$type}_refund_enabled" );
    }

    /**
     * The Pinterest add-on is active, new enough and has the Refund sender.
     */
    public static function pinterest_ready() {
        if ( ! defined( 'PYS_PINTEREST_REFUND_MIN_VERSION' ) || ! isPinterestActive() || ! function_exists( __NAMESPACE__ . '\PinterestServer' ) ) {
            return false;
        }
        if ( version_compare( self::pinterest_version(), PYS_PINTEREST_REFUND_MIN_VERSION, '<' ) ) {
            return false;
        }
        return method_exists( PinterestServer(), 'sendRefundEvent' );
    }

    /** @var string|null The add-on's version, read once per request. */
    private static $pinterest_version = null;

    /**
     * The add-on's own constant; its plugin header is read (from disk) only when
     * the constant is missing.
     *
     * @return string
     */
    private static function pinterest_version() {
        if ( null !== self::$pinterest_version ) {
            return self::$pinterest_version;
        }
        if ( defined( 'PYS_PINTEREST_VERSION' ) ) {
            self::$pinterest_version = (string) PYS_PINTEREST_VERSION;
            return self::$pinterest_version;
        }
        if ( ! function_exists( 'get_plugin_data' ) ) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $data                    = get_plugin_data( WP_PLUGIN_DIR . '/pixelyoursite-pinterest/pixelyoursite-pinterest.php', false, false );
        self::$pinterest_version = isset( $data['Version'] ) ? (string) $data['Version'] : '0';
        return self::$pinterest_version;
    }

    /**
     * @return string|null Why the platform takes no refund, null when it does.
     */
    private static function skip_reason( $platform, $type, $order_or_id, $refund_id, $is_cancel ) {
        $pixel = self::pixel( $platform );
        if ( ! $pixel->configured() || ! method_exists( $pixel, 'isServerApiEnabled' ) || ! $pixel->isServerApiEnabled() ) {
            return 'not configured or server API off';
        }
        if ( $is_cancel && ! PYS()->getOption( "{$type}_track_canceled_GA" ) ) {
            return 'cancellations are not tracked';
        }
        if ( pys_order_purchase_blocked( $type, $order_or_id, 'ads' ) ) {
            return 'purchase blocked for the order';
        }
        if ( ! pys_order_purchase_on_record( $type, $order_or_id, $platform ) ) {
            return 'no Purchase on record';
        }
        if ( self::meta_get( $type, $order_or_id, "_pys_refund_status_sent_{$platform}" ) ) {
            return 'order already reversed';
        }
        if ( $refund_id > 0 ) {
            $sent = self::meta_get( $type, $order_or_id, "_pys_refunds_sent_{$platform}" );
            if ( is_array( $sent ) && in_array( $refund_id, array_map( 'intval', $sent ), true ) ) {
                return "refund $refund_id already sent";
            }
        }
        return null;
    }

    private static function order_id( $order_or_id ) {
        return is_object( $order_or_id ) ? (int) $order_or_id->get_id() : (int) $order_or_id;
    }

    private static function meta_get( $type, $order_or_id, $key ) {
        return 'woo' === $type ? $order_or_id->get_meta( $key, true ) : edd_get_payment_meta( (int) $order_or_id, $key, true );
    }

    private static function mark( $type, $order_or_id, array $platforms, $refund_id ) {
        foreach ( $platforms as $platform ) {
            if ( $refund_id > 0 ) {
                $key  = "_pys_refunds_sent_{$platform}";
                $list = self::meta_get( $type, $order_or_id, $key );
                $list = is_array( $list ) ? array_map( 'intval', $list ) : array();
                $val  = array_values( array_unique( array_merge( $list, array( $refund_id ) ) ) );
            } else {
                $key = "_pys_refund_status_sent_{$platform}";
                $val = 1;
            }
            if ( 'woo' === $type ) {
                $order_or_id->update_meta_data( $key, $val );
            } elseif ( function_exists( 'edd_update_payment_meta' ) ) {
                edd_update_payment_meta( (int) $order_or_id, $key, $val );
            }
        }
        if ( 'woo' === $type ) {
            $order_or_id->save();
        }
    }

    private static function content_id( $platform, $type, $row ) {
        $pixel = self::pixel( $platform );
        if ( 'edd' === $type ) {
            return (string) getEddContentId( $pixel, $row['product_id'], isset( $row['price_index'] ) ? $row['price_index'] : null );
        }
        if ( 'facebook' === $platform ) {
            $ids = Facebook\Helpers\getFacebookWooProductContentId( Facebook\Helpers\getFacebookWooProductDataId( $row ) );
            return (string) reset( $ids );
        }
        $id = $row['product_id'];
        if ( ! empty( $row['parent_id'] ) && isset( $row['type'] ) && 'variation' === $row['type'] && $pixel->getOption( 'woo_variable_as_simple' ) ) {
            $id = $row['parent_id'];
        }
        return (string) getWooProductItemId( $id, $pixel, true );
    }

    /**
     * The Refund event's parameters in the shape the platform's mapper takes.
     * The value is what the refund event reverses, as the GA4 refund reports it:
     * refund_amount when present, else the order total.
     */
    private static function params( $platform, $type, $event ) {
        $args      = $event->args;
        $refund_id = (int) ( isset( $args['refund_id'] ) ? $args['refund_id'] : 0 );
        if ( ! empty( $args['is_cancel'] ) ) {
            $refund_type = 'cancelled';
        } else {
            $refund_type = $refund_id > 0 && empty( $args['is_full_refund'] ) ? 'partial' : 'full';
        }
        if ( 'woo' === $type ) {
            $value    = isset( $args['refund_amount'] ) ? (float) $args['refund_amount'] : getWooEventOrderTotal( $event );
            $currency = $args['currency'];
            $order_id = wooMapOrderId( $args['order_id'] );
        } else {
            $value    = (float) edd_get_payment_amount( $args['order_id'] );
            $currency = edd_get_currency();
            $order_id = $args['order_id'];
        }
        $value = pys_round( $value, 2 );

        $rows = array();
        $num  = 0;
        foreach ( isset( $args['products'] ) ? (array) $args['products'] : array() as $row ) {
            $id = self::content_id( $platform, $type, $row );
            if ( '' === $id ) {
                continue;
            }
            $qty    = max( 1, (int) ( isset( $row['quantity'] ) ? $row['quantity'] : 1 ) );
            $num   += $qty;
            $rows[] = array(
                'id'       => $id,
                'quantity' => $qty,
                'price'    => isset( $row['price'] ) ? (float) $row['price'] : 0,
                'name'     => isset( $row['name'] ) ? $row['name'] : '',
            );
        }

        if ( 'openai' === $platform ) {
            // OpenAI rejects fields outside its documented set, so the order and refund ids stay out.
            $data  = array( 'type' => 'custom' );
            $minor = OpenAI\Helpers\pys_openai_to_minor_units( $value, $currency );
            if ( null !== $minor && OpenAI\Helpers\pys_openai_is_valid_currency( $currency ) ) {
                $data['amount']   = $minor;
                $data['currency'] = $currency;
            }
            $contents = array();
            foreach ( $rows as $r ) {
                $contents[] = OpenAI\Helpers\pys_openai_content_item( $r['id'], $r['name'], 'product', $r['quantity'], $r['price'], $currency );
            }
            if ( $contents ) {
                $data['contents'] = $contents;
            }
            return array( 'custom_event_name' => 'Refund', 'data' => $data );
        }

        $params = array(
            'content_type' => 'product',
            'value'        => $value,
            'currency'     => $currency,
            'order_id'     => $order_id,
            'num_items'    => $num,
            'refund_type'  => $refund_type,
            'refund_id'    => $refund_id,
        );
        if ( 'tiktok' === $platform ) {
            foreach ( $rows as $r ) {
                $params['contents'][] = array( 'content_id' => $r['id'], 'quantity' => $r['quantity'], 'price' => $r['price'], 'content_name' => $r['name'] );
            }
        } else {
            $params['content_ids'] = array_column( $rows, 'id' );
            foreach ( $rows as $r ) {
                $params['contents'][] = array( 'id' => $r['id'], 'quantity' => $r['quantity'] );
            }
        }
        return $params;
    }
}
