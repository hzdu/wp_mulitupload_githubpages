<?php
/**
 * Per-platform delivery state of a server Purchase (Advanced Deduplication).
 *
 * @package PixelYourSite
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Tracks which pixels of a platform have accepted an order's server Purchase.
 *
 * _pys_purchase_event_fired only says the thank-you page built the browser
 * payload; nothing guarantees the browser sent it. In Advanced Deduplication the
 * server copies are therefore gated by what each platform actually accepted:
 *
 *   _pys_server_event_sent_{platform}    accepted pixels:
 *                                        array( 'event_id' => ..., 'pixels' => [...] ).
 *                                        A plain eventID string (written before
 *                                        12.6.8) means every pixel accepted it.
 *   _pys_server_event_pending_{platform} pixels a request is sending right now:
 *                                        array( 'event_id' => ..., 'pixels' => [ id => time ] ).
 *
 * A request claims the pixels it is about to send, so the browser AJAX copy and
 * the order-status fallback cannot both send the same Purchase — Meta does not
 * deduplicate two server events. A claim left by a request that died expires
 * after CLAIM_TTL seconds; a failed send drops its claim at once, so the pixel
 * stays retryable.
 *
 * The metas above exist to deduplicate. What happened to the Purchase is kept
 * separately, for reporting, in RECORD_META_KEY (see recordResult(), recordTag()
 * and recordRun()); getOrderStatus() is the one reader of all of it.
 */
class PurchaseDelivery {

    const CLAIM_TTL = 120;

    /**
     * Order meta with the delivery record of the order's Purchase:
     *
     *   array(
     *     'tag'       => array( 'time' => int, 'platforms' => array( platform => pixel ids ) ),
     *     'platforms' => array( platform => array(
     *         'event_id' => string,
     *         'pixels'   => array( pixel id => array( 'outcome', 'time', 'source', 'message' ) ),
     *     ) ),
     *     'run'       => array( 'outcome', 'time', 'reason', 'attempts', 'next' ),
     *   )
     */
    const RECORD_META_KEY = '_pys_purchase_delivery';

    /** The platform accepted the event for this pixel. */
    const OUTCOME_ACCEPTED = 'accepted';
    /** The platform rejected the event for good (bad token, invalid payload). */
    const OUTCOME_REJECTED = 'rejected';
    /** A transient failure: the order-status fallback retries it. */
    const OUTCOME_RETRY = 'retry';
    /** Nothing was sent for this pixel (no access token, pixel switched off). */
    const OUTCOME_SKIPPED = 'skipped';
    /** Handed to the events queue, which sends and retries on its own. */
    const OUTCOME_QUEUED = 'queued';
    /** Sent by a sender that reports no result (the Pinterest add-on). */
    const OUTCOME_UNCONFIRMED = 'unconfirmed';

    /** The browser's AJAX copy of the thank-you page Purchase. */
    const SOURCE_BROWSER = 'browser';
    /** The order-status send (Advanced Purchase Tracking), its deferred runs and retries. */
    const SOURCE_ORDER_STATUS = 'order_status';
    /** The events queue. */
    const SOURCE_QUEUE = 'queue';

    /** The order-status run finished: nothing is left to send or retry. */
    const RUN_SETTLED = 'settled';
    /** A send failed in a way worth repeating; cron runs it again at 'next'. */
    const RUN_RETRY_SCHEDULED = 'retry_scheduled';
    /** The run waits (checkout AJAX request, browser grace window); cron runs it at 'next'. */
    const RUN_DEFERRED = 'deferred';
    /** Every retry was used up. */
    const RUN_GAVE_UP = 'gave_up';
    /** The run sent nothing on purpose; 'reason' says why. */
    const RUN_SKIPPED = 'skipped';

    const MESSAGE_MAX_LENGTH = 200;

    /**
     * Orders whose record changed and is not stored yet: listeners hear of them
     * once the write reaches the database.
     *
     * @var array<string, array{0: string, 1: int}>
     */
    private static $changed_orders = array();

    /**
     * Is this an order-bound purchase event in Advanced Deduplication mode?
     *
     * @param SingleEvent $event
     * @param bool        $any_mode Also in Single mode: for the delivery record
     *                              only, never for claim() and settle()
     * @return array|null array( type, order_id, event_id ) or null
     */
    public static function getContext( $event, $any_mode = false ) {
        $event_name = $event->getId();

        if ( $event_name === 'woo_purchase' ) {
            $type     = 'woo';
            $order_id = isset( $event->payload['woo_order'] ) ? (int) $event->payload['woo_order'] : 0;
        } elseif ( $event_name === 'edd_purchase' || $event_name === 'edd_complete_payment' ) {
            $type     = 'edd';
            $order_id = isset( $event->payload['edd_order'] ) ? (int) $event->payload['edd_order'] : 0;
        } else {
            return null;
        }

        $event_id = isset( $event->payload['eventID'] ) ? (string) $event->payload['eventID'] : '';

        if ( ! $order_id || $event_id === '' || ( ! $any_mode && ! self::isAdvancedMode( $type ) ) ) {
            return null;
        }
        if ( $type === 'woo' && ! function_exists( 'wc_get_order' ) ) {
            return null;
        }
        if ( $type === 'edd' && ! function_exists( 'edd_get_payment_meta' ) ) {
            return null;
        }

        return array( $type, $order_id, $event_id );
    }

    /**
     * @param string $type 'woo' or 'edd'
     * @return bool
     */
    public static function isAdvancedMode( $type ) {
        return PYS()->getOption( "{$type}_purchase_on_transaction_mode", 'advanced' ) !== 'single';
    }

    /**
     * Platforms a thank-you page may confirm through the browser marker.
     */
    const MARKER_PLATFORMS = array( 'facebook', 'ga', 'google_ads', 'tiktok', 'pinterest', 'openai', 'bing', 'reddit' );

    const MARKER_GRACE = 120;

    /**
     * Record that the thank-you page built the browser Purchase, and for which
     * platforms and pixels. Call it only where _pys_purchase_event_fired is
     * first set.
     *
     * @param string         $type
     * @param int            $order_id
     * @param \WC_Order|null $order Woo: the caller's order object; the pending
     *                              meta is set on it and the caller saves it.
     * @return void
     */
    public static function markBrowserPending( $type, $order_id, $order = null ) {
        $now = time();

        if ( $type === 'woo' ) {
            if ( ! $order && function_exists( 'wc_get_order' ) ) {
                $order = wc_get_order( $order_id );
                if ( $order ) {
                    $order->update_meta_data( '_pys_purchase_browser_pending', $now );
                    $order->save();
                }
            } elseif ( $order ) {
                $order->update_meta_data( '_pys_purchase_browser_pending', $now );
            }
        } elseif ( function_exists( 'edd_update_payment_meta' ) ) {
            edd_update_payment_meta( $order_id, '_pys_purchase_browser_pending', $now );
        }

        // The record is written on its own fresh read: the caller's object may
        // predate a result another request recorded meanwhile.
        self::guard( 'tag', $type, $order_id, function () use ( $type, $order_id, $now ) {
            self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $now ) {
                $record        = self::readRecord( $type, $order, $order_id );
                $record['tag'] = array(
                    'time'      => $now,
                    'platforms' => self::tagPlatforms( $type ),
                );
                self::writeMeta( $type, $order, $order_id, self::RECORD_META_KEY, $record );

                return null;
            } );
        } );
    }

    /**
     * Run a write to the delivery record. The record is a report: a failure is
     * logged and never reaches the send path that called it.
     *
     * @param string   $what     What was being recorded, for the log
     * @param string   $type     'woo' or 'edd'
     * @param int      $order_id
     * @param callable $write
     * @return void
     */
    private static function guard( $what, $type, $order_id, callable $write ) {
        try {
            $write();
        } catch ( \Throwable $e ) {
            if ( function_exists( 'PixelYourSite\PYS' ) && PYS()->getLog() ) {
                PYS()->getLog()->error( "Purchase delivery record ({$what}) not written for {$type} order {$order_id}", $e );
            }
        }
    }

    /**
     * Tell listeners that what is on record for an order changed.
     *
     * @param string $type     'woo' or 'edd'
     * @param int    $order_id
     * @return void
     */
    private static function changed( $type, $order_id ) {
        /**
         * Fires when the delivery record or the browser marker of an order changes.
         *
         * @param string $type     'woo' or 'edd'
         * @param int    $order_id
         */
        do_action( 'pys_purchase_delivery_changed', $type, (int) $order_id );
    }

    /**
     * HMAC the thank-you page hands to the browser; it proves the sender saw
     * the page without exposing the order key.
     *
     * @return string Empty when the order or its key is unknown
     */
    public static function markerToken( $type, $order_id ) {
        $key = '';

        if ( $type === 'woo' && function_exists( 'wc_get_order' ) ) {
            $order = wc_get_order( $order_id );
            $key   = $order ? (string) $order->get_order_key() : '';
        } elseif ( $type === 'edd' && function_exists( 'edd_get_payment_key' ) ) {
            $key = (string) edd_get_payment_key( $order_id );
        }

        if ( $key === '' ) {
            return '';
        }

        return wp_hash( "pys_purchase_marker|{$type}|{$order_id}|{$key}" );
    }

    /**
     * Store the platforms the browser confirmed; the first time per platform is kept.
     *
     * @param string $type
     * @param int    $order_id
     * @param array  $platforms Already whitelisted slugs
     * @return bool False when the order is unknown or its page was never built
     */
    public static function recordBrowserMarker( $type, $order_id, array $platforms ) {
        $platforms = array_values( array_intersect( array_unique( $platforms ), self::MARKER_PLATFORMS ) );
        // A tag the buyer refused does not fire: a marker for it confirms nothing.
        $platforms = array_values( array_filter( $platforms, function ( $platform ) use ( $type, $order_id ) {
            return PYS_CONSENT_DENIED !== pys_order_consent_state( $type, $order_id, $platform );
        } ) );

        $result = self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platforms ) {
            if ( ! self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_pending' ) ) {
                return false;
            }

            $marker = self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_marker' );
            $marker = is_array( $marker ) ? $marker : array();
            $now    = time();
            $new    = false;
            foreach ( $platforms as $platform ) {
                if ( ! isset( $marker[ $platform ] ) ) {
                    $marker[ $platform ] = $now;
                    $new                 = true;
                }
            }

            if ( $new ) {
                self::writeMeta( $type, $order, $order_id, '_pys_purchase_browser_marker', $marker );
            }

            return true;
        } );

        return $result === true;
    }

    /**
     * Should the server send this platform's Purchase, given what the browser did?
     *
     * @param string         $type
     * @param int            $order_id
     * @param string         $platform
     * @param \WC_Order|null $order Woo order whose meta the caller read fresh
     * @return array array( 'decision' => skip|wait|send, 'wait' => seconds left )
     */
    public static function browserDecision( $type, $order_id, $platform, $order = null ) {
        if ( $type === 'woo' && ! $order ) {
            $order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
            if ( $order ) {
                $order->read_meta_data( true );
            }
        } elseif ( $type === 'edd' && function_exists( 'edd_get_payment_meta' ) ) {
            wp_cache_delete( $order_id, 'edd_order_meta' );
        }
        if ( $type === 'woo' && ! $order ) {
            return array( 'decision' => 'send', 'wait' => 0 );
        }

        $marker  = self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_marker' );
        $pending = (int) self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_pending' );
        $fired   = self::readMeta( $type, $order, $order_id, '_pys_purchase_event_fired' );

        if ( is_array( $marker ) && isset( $marker[ $platform ] ) ) {
            return array( 'decision' => 'skip', 'wait' => 0 );
        }
        if ( ! $pending ) {
            // Built before the marker existed: the browser counts as fired.
            return array( 'decision' => $fired ? 'skip' : 'send', 'wait' => 0 );
        }

        $grace = (int) apply_filters( 'pys_purchase_marker_grace', self::MARKER_GRACE, $type, $order_id );
        $left  = $pending + $grace - time();

        return $left > 0
            ? array( 'decision' => 'wait', 'wait' => $left )
            : array( 'decision' => 'send', 'wait' => 0 );
    }

    /**
     * Single mode only: platforms the server already sent, kept for good so a
     * cron retry or a later status change does not send them again
     * (PurchaseDelivery claims cover Advanced).
     *
     * @param string         $type
     * @param int            $order_id
     * @param array          $platforms Platforms to add
     * @param \WC_Order|null $order     Woo order of the caller, saved by the caller
     * @return array The stored list
     */
    public static function singleServerSent( $type, $order_id, $platforms = array(), $order = null ) {
        $key = '_pys_purchase_server_sent';
        if ( $type === 'woo' && ! $order ) {
            $order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
            if ( ! $order ) {
                return array();
            }
        }

        $stored = self::readMeta( $type, $order, $order_id, $key );
        $stored = is_array( $stored ) ? $stored : array();

        $merged = array_values( array_unique( array_merge( $stored, (array) $platforms ) ) );
        if ( $merged !== $stored ) {
            self::writeMeta( $type, $order, $order_id, $key, $merged );
        }

        return $merged;
    }

    /**
     * Reserve the pixels that still need this Purchase.
     *
     * @param string $type
     * @param int    $order_id
     * @param string $platform
     * @param string $event_id
     * @param array  $pixel_ids Pixels the caller wants to send to
     * @return array Pixels the caller may send to now; the rest were accepted
     *               already or are being sent by another request.
     */
    public static function claim( $type, $order_id, $platform, $event_id, $pixel_ids ) {
        $pixel_ids = array_values( array_unique( array_map( 'strval', (array) $pixel_ids ) ) );
        if ( empty( $pixel_ids ) ) {
            return array();
        }

        return self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platform, $event_id, $pixel_ids ) {
            $sent    = self::getSentPixels( $type, $order, $order_id, $platform, $event_id );
            if ( $sent === true ) {
                return array();
            }
            $pending = self::getPending( $type, $order, $order_id, $platform, $event_id );
            $now     = time();

            $claimed = array();
            foreach ( $pixel_ids as $pixel_id ) {
                if ( in_array( $pixel_id, $sent, true ) ) {
                    continue;
                }
                if ( isset( $pending[ $pixel_id ] ) && $now - (int) $pending[ $pixel_id ] < self::CLAIM_TTL ) {
                    continue;
                }
                $pending[ $pixel_id ] = $now;
                $claimed[]            = $pixel_id;
            }

            if ( ! empty( $claimed ) ) {
                self::writeMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}", array(
                    'event_id' => $event_id,
                    'pixels'   => $pending,
                ) );
            }

            return $claimed;
        } );
    }

    /**
     * Record the outcome of a send: accepted pixels become "sent", the claim of
     * every other claimed pixel is dropped so a later attempt may retry it.
     *
     * @param string $type
     * @param int    $order_id
     * @param string $platform
     * @param string $event_id
     * @param array      $claimed  Pixels returned by claim()
     * @param array      $accepted Pixels that need no further attempt
     * @param array|null $result   The sender's sendEvent() result. With it the
     *                             outcome of every claimed pixel goes into the
     *                             delivery record, in the same write.
     * @param string     $source   One of the SOURCE_* constants
     * @return void
     */
    public static function settle( $type, $order_id, $platform, $event_id, $claimed, $accepted, $result = null, $source = '' ) {
        $claimed  = array_map( 'strval', (array) $claimed );
        $accepted = array_values( array_intersect( array_map( 'strval', (array) $accepted ), $claimed ) );
        $outcomes = self::outcomesFromResult( $claimed, $accepted, $result );

        self::guard( 'settle', $type, $order_id, function () use ( $type, $order_id, $platform, $event_id, $claimed, $accepted, $outcomes, $source ) {
            self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platform, $event_id, $claimed, $accepted, $outcomes, $source ) {
                // One save for the whole settle: every save of a WooCommerce order
                // runs the store's own save hooks.
                if ( ! empty( $accepted ) ) {
                    $sent = self::getSentPixels( $type, $order, $order_id, $platform, $event_id );
                    if ( $sent !== true ) {
                        self::writeMeta( $type, $order, $order_id, "_pys_server_event_sent_{$platform}", array(
                            'event_id' => $event_id,
                            'pixels'   => array_values( array_unique( array_merge( $sent, $accepted ) ) ),
                        ), false );
                    }
                }

                self::guard( 'settle outcomes', $type, $order_id, function () use ( $type, $order, $order_id, $platform, $event_id, $outcomes, $source ) {
                    self::writeMeta(
                        $type,
                        $order,
                        $order_id,
                        self::RECORD_META_KEY,
                        self::mergePixelOutcomes( self::readRecord( $type, $order, $order_id ), $platform, $event_id, $outcomes, $source ),
                        false
                    );
                } );

                $pending = self::getPending( $type, $order, $order_id, $platform, $event_id );
                foreach ( $claimed as $pixel_id ) {
                    unset( $pending[ $pixel_id ] );
                }
                self::writeMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}", empty( $pending ) ? null : array(
                    'event_id' => $event_id,
                    'pixels'   => $pending,
                ) );

                return null;
            } );
        } );
    }

    /**
     * Mark pixels as handed off to a sender that retries on its own (the
     * events queue): from here the queue owns the delivery.
     */
    public static function markHandedOff( $type, $order_id, $platform, $event_id, $pixel_ids ) {
        $claimed = self::claim( $type, $order_id, $platform, $event_id, $pixel_ids );
        if ( ! empty( $claimed ) ) {
            $queued = array();
            foreach ( $claimed as $pixel_id ) {
                $queued[ $pixel_id ] = array( 'outcome' => self::OUTCOME_QUEUED );
            }
            self::settle( $type, $order_id, $platform, $event_id, $claimed, $claimed, array( 'pixels' => $queued ), self::SOURCE_QUEUE );
        }

        return $claimed;
    }

    /**
     * Record the outcome of a send that does not go through claim() and
     * settle(): GA4 (one source, its own fire-once flags) and the events queue.
     *
     * @param string $type     'woo' or 'edd'
     * @param int    $order_id
     * @param string $platform One of MARKER_PLATFORMS
     * @param string $event_id
     * @param array  $outcomes array( pixel id => array( 'outcome' => OUTCOME_*, 'message' => string ) )
     * @param string $source   One of the SOURCE_* constants
     * @return void
     */
    public static function recordResult( $type, $order_id, $platform, $event_id, array $outcomes, $source ) {
        if ( empty( $outcomes ) || ! in_array( $platform, self::MARKER_PLATFORMS, true ) ) {
            return;
        }

        self::guard( 'result', $type, $order_id, function () use ( $type, $order_id, $platform, $event_id, $outcomes, $source ) {
            self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platform, $event_id, $outcomes, $source ) {
                $record  = self::readRecord( $type, $order, $order_id );
                $updated = self::mergePixelOutcomes( $record, $platform, $event_id, $outcomes, $source );
                if ( $updated !== $record ) {
                    self::writeMeta( $type, $order, $order_id, self::RECORD_META_KEY, $updated );
                }

                return null;
            } );
        } );
    }

    /**
     * Record a sender's sendEvent() result for an order's Purchase that was sent
     * outside sendEventsNow() (the events queue).
     *
     * @param array    $delivery  array( type, order_id, event_id ), see getContext()
     * @param string   $platform  One of MARKER_PLATFORMS
     * @param string[] $pixel_ids Pixels the event was sent to
     * @param array    $result    sendEvent() result
     * @param string   $source    One of the SOURCE_* constants
     * @return void
     */
    public static function recordSenderResult( $delivery, $platform, array $pixel_ids, array $result, $source ) {
        if ( ! is_array( $delivery ) || count( $delivery ) !== 3 || empty( $pixel_ids ) ) {
            return;
        }

        list( $type, $order_id, $event_id ) = array_values( $delivery );
        $pixel_ids = array_map( 'strval', $pixel_ids );
        if ( isset( $result['done'] ) ) {
            $accepted = array_map( 'strval', (array) $result['done'] );
        } else {
            $accepted = isset( $result['status'] ) && $result['status'] === AbstractServerEvents::SEND_SENT ? $pixel_ids : array();
        }

        self::recordResult(
            (string) $type,
            (int) $order_id,
            (string) $platform,
            (string) $event_id,
            self::outcomesFromResult( $pixel_ids, array_values( array_intersect( $accepted, $pixel_ids ) ), $result ),
            $source
        );
    }

    /**
     * Record how the order-status run for this order ended.
     *
     * @param string $type     'woo' or 'edd'
     * @param int    $order_id
     * @param string $outcome  One of the RUN_* constants
     * @param array  $details  Optional 'reason' (string), 'attempts' (int), 'next' (timestamp)
     * @return void
     */
    public static function recordRun( $type, $order_id, $outcome, array $details = array() ) {
        self::guard( 'run', $type, $order_id, function () use ( $type, $order_id, $outcome, $details ) {
            self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $outcome, $details ) {
                $record = self::readRecord( $type, $order, $order_id );
                $run    = array(
                    'outcome'  => (string) $outcome,
                    'reason'   => isset( $details['reason'] ) ? (string) $details['reason'] : '',
                    'attempts' => isset( $details['attempts'] ) ? (int) $details['attempts'] : 0,
                    'next'     => isset( $details['next'] ) ? (int) $details['next'] : 0,
                );

                // The same outcome again (every status change of an excluded order)
                // is not worth a write.
                $previous = isset( $record['run'] ) && is_array( $record['run'] ) ? $record['run'] : array();
                unset( $previous['time'] );
                if ( $previous === $run ) {
                    return null;
                }

                $run['time']   = time();
                $record['run'] = $run;
                self::writeMeta( $type, $order, $order_id, self::RECORD_META_KEY, $record );

                return null;
            } );
        } );
    }

    /**
     * Platforms and pixels whose Purchase tag the thank-you page is about to
     * print: every registered pixel that is on, has pixel IDs and has the
     * Purchase event enabled.
     *
     * @param string $type 'woo' or 'edd'
     * @return array array( platform => pixel ids )
     */
    public static function tagPlatforms( $type ) {
        $platforms = array();

        foreach ( PYS()->getRegisteredPixels() as $pixel ) {
            $slug = method_exists( $pixel, 'getSlug' ) ? (string) $pixel->getSlug() : '';
            if ( ! in_array( $slug, self::MARKER_PLATFORMS, true ) || ! $pixel->enabled() ) {
                continue;
            }
            // Add-on pixels without a Purchase switch of their own always send it.
            $purchase_enabled = $pixel->getOption( "{$type}_purchase_enabled" );
            if ( null !== $purchase_enabled && ! $purchase_enabled ) {
                continue;
            }

            $pixel_ids = method_exists( $pixel, 'getAllPixels' ) ? $pixel->getAllPixels( false ) : $pixel->getPixelIDs();
            $pixel_ids = array_values( array_filter( array_map( 'strval', (array) $pixel_ids ) ) );
            if ( ! empty( $pixel_ids ) ) {
                $platforms[ $slug ] = $pixel_ids;
            }
        }

        return $platforms;
    }

    /**
     * Everything on record about the delivery of an order's Purchase.
     *
     * The one reader of the delivery metas: reports ask here and never read the
     * metas themselves. An order from before the delivery record existed is
     * answered from the older metas and marked 'recorded' => false.
     *
     * @param string        $type        'woo' or 'edd'
     * @param \WC_Order|int $order_or_id Woo order or id; EDD payment id
     * @return array{
     *     recorded: bool,
     *     event_id: string,
     *     tag: array{built: bool, time: int, platforms: array<string, string[]>|null, confirmed: array<string, int>, waiting: bool},
     *     api: array<string, array{pixels: array<string, array{outcome: string, time: int, source: string, message: string}>}>,
     *     run: array{outcome: string, time: int, reason: string, attempts: int, next: int},
     *     single_mode_sent: string[],
     *     consent: array<string, string> Buyer's consent stored at checkout, by platform; empty when none
     * }|null Null when the order is unknown
     */
    public static function getOrderStatus( $type, $order_or_id ) {
        $order    = null;
        $order_id = 0;
        if ( $type === 'woo' ) {
            if ( is_object( $order_or_id ) && method_exists( $order_or_id, 'get_meta' ) ) {
                $order = $order_or_id;
            } elseif ( function_exists( 'wc_get_order' ) ) {
                $order = wc_get_order( (int) $order_or_id );
            }
            if ( ! $order ) {
                return null;
            }
            $order_id = (int) $order->get_id();
        } elseif ( $type === 'edd' && function_exists( 'edd_get_payment_meta' ) ) {
            $order_id = is_object( $order_or_id ) && isset( $order_or_id->id ) ? (int) $order_or_id->id : (int) $order_or_id;
            if ( ! $order_id ) {
                return null;
            }
        } else {
            return null;
        }

        $record    = self::readRecord( $type, $order, $order_id );
        $marker    = self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_marker' );
        $pending   = (int) self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_pending' );
        $built     = (bool) self::readMeta( $type, $order, $order_id, '_pys_purchase_event_fired' );
        $confirmed = array();
        foreach ( is_array( $marker ) ? $marker : array() as $platform => $time ) {
            $confirmed[ (string) $platform ] = (int) $time;
        }

        $grace  = (int) apply_filters( 'pys_purchase_marker_grace', self::MARKER_GRACE, $type, $order_id );
        $status = array(
            'recorded'         => ! empty( $record ),
            'event_id'         => (string) self::readMeta( $type, $order, $order_id, '_pys_purchase_event_id' ),
            'tag'              => array(
                // A refund or a cancellation clears the built flag on purpose;
                // the record keeps the fact that the page was built.
                'built'     => $built || ! empty( $record['tag']['time'] ),
                'time'      => isset( $record['tag']['time'] ) ? (int) $record['tag']['time'] : $pending,
                'platforms' => isset( $record['tag']['platforms'] ) && is_array( $record['tag']['platforms'] ) ? $record['tag']['platforms'] : null,
                'confirmed' => $confirmed,
                'waiting'   => $pending > 0 && time() - $pending < $grace,
            ),
            'api'              => array(),
            'run'              => array( 'outcome' => '', 'time' => 0, 'reason' => '', 'attempts' => 0, 'next' => 0 ),
            'single_mode_sent' => array(),
            'consent'          => array(),
        );

        $consent = self::readMeta( $type, $order, $order_id, PYS_ORDER_CONSENT_META );
        if ( is_array( $consent ) ) {
            $status['consent'] = array_map( 'strval', $consent );
        }

        if ( isset( $record['run'] ) && is_array( $record['run'] ) ) {
            $status['run'] = array_merge( $status['run'], $record['run'] );
        }

        $single = self::readMeta( $type, $order, $order_id, '_pys_purchase_server_sent' );
        if ( is_array( $single ) ) {
            $status['single_mode_sent'] = array_values( array_map( 'strval', $single ) );
        }

        foreach ( isset( $record['platforms'] ) && is_array( $record['platforms'] ) ? $record['platforms'] : array() as $platform => $entry ) {
            if ( isset( $entry['pixels'] ) && is_array( $entry['pixels'] ) ) {
                $status['api'][ (string) $platform ] = array( 'pixels' => $entry['pixels'] );
            }
        }

        return self::addUnrecordedDeliveries( $status, $type, $order, $order_id );
    }

    /**
     * Fill in, from the older metas, the platforms the delivery record does not
     * cover: orders sent before the record existed, and senders that do not
     * write to it. These entries carry 'source' => '' and no time.
     *
     * @param array          $status   getOrderStatus() value so far
     * @param string         $type
     * @param \WC_Order|null $order
     * @param int            $order_id
     * @return array
     */
    private static function addUnrecordedDeliveries( array $status, $type, $order, $order_id ) {
        $fired = self::readMeta( $type, $order, $order_id, '_pys_server_fired_pixels' );
        $fired = is_array( $fired ) ? $fired : array();

        foreach ( self::MARKER_PLATFORMS as $platform ) {
            if ( isset( $status['api'][ $platform ] ) ) {
                continue;
            }

            $pixels = array();
            $sent   = self::readMeta( $type, $order, $order_id, "_pys_server_event_sent_{$platform}" );
            if ( is_array( $sent ) && ! empty( $sent['pixels'] ) ) {
                foreach ( array_map( 'strval', (array) $sent['pixels'] ) as $pixel_id ) {
                    $accepted            = ! isset( $fired[ $platform ] ) || in_array( $pixel_id, array_map( 'strval', (array) $fired[ $platform ] ), true );
                    $pixels[ $pixel_id ] = self::unrecordedOutcome( $accepted ? self::OUTCOME_ACCEPTED : self::OUTCOME_REJECTED );
                }
            } elseif ( is_string( $sent ) && $sent !== '' ) {
                $pixels['*'] = self::unrecordedOutcome( self::OUTCOME_ACCEPTED );
            }

            foreach ( isset( $fired[ $platform ] ) ? array_map( 'strval', (array) $fired[ $platform ] ) : array() as $pixel_id ) {
                if ( ! isset( $pixels[ $pixel_id ] ) ) {
                    $pixels[ $pixel_id ] = self::unrecordedOutcome( self::OUTCOME_ACCEPTED );
                }
            }

            if ( empty( $pixels ) && $platform === 'ga'
                && ( self::readMeta( $type, $order, $order_id, '_pys_ga_purchase_event_fired' )
                    || self::readMeta( $type, $order, $order_id, '_pys_ga_advance_purchase_event_fired' ) ) ) {
                $pixels['*'] = self::unrecordedOutcome( self::OUTCOME_ACCEPTED );
            }

            if ( empty( $pixels ) && in_array( $platform, $status['single_mode_sent'], true ) ) {
                // The Single list holds Pinterest once it was sent, whatever the answer.
                $pixels['*'] = self::unrecordedOutcome( $platform === 'pinterest' ? self::OUTCOME_UNCONFIRMED : self::OUTCOME_ACCEPTED );
            }

            if ( ! empty( $pixels ) ) {
                $status['api'][ $platform ] = array( 'pixels' => $pixels );
            }
        }

        return $status;
    }

    /**
     * @param string $outcome One of the OUTCOME_* constants
     * @return array
     */
    private static function unrecordedOutcome( $outcome ) {
        return array(
            'outcome' => $outcome,
            'time'    => 0,
            'source'  => '',
            'message' => '',
        );
    }

    /**
     * The outcome of every claimed pixel, from a sender's result.
     *
     * A sender that reports per-pixel outcomes ('pixels' in its result) is taken
     * at its word. For one that does not (the Pinterest add-on, third-party
     * senders) the outcome follows from the 'done' list and the status.
     *
     * @param string[]   $claimed
     * @param string[]   $accepted Pixels that need no further attempt
     * @param array|null $result   sendEvent() result
     * @return array array( pixel id => array( 'outcome' => string, 'message' => string ) )
     */
    private static function outcomesFromResult( array $claimed, array $accepted, $result ) {
        $status   = is_array( $result ) && isset( $result['status'] ) ? (string) $result['status'] : '';
        $message  = is_array( $result ) && isset( $result['message'] ) ? (string) $result['message'] : '';
        $reported = is_array( $result ) && isset( $result['pixels'] ) && is_array( $result['pixels'] ) ? $result['pixels'] : array();
        $outcomes = array();

        foreach ( $claimed as $pixel_id ) {
            if ( isset( $reported[ $pixel_id ]['outcome'] ) ) {
                $outcomes[ $pixel_id ] = array(
                    'outcome' => (string) $reported[ $pixel_id ]['outcome'],
                    'message' => isset( $reported[ $pixel_id ]['message'] ) ? (string) $reported[ $pixel_id ]['message'] : '',
                );
                continue;
            }

            $names_pixel = $message !== '' && strpos( $message, $pixel_id ) !== false;
            if ( ! in_array( $pixel_id, $accepted, true ) ) {
                $outcome = $status === AbstractServerEvents::SEND_FAILED ? self::OUTCOME_REJECTED : self::OUTCOME_RETRY;
            } elseif ( $status === AbstractServerEvents::SEND_SKIPPED ) {
                $outcome = self::OUTCOME_SKIPPED;
            } elseif ( $names_pixel && in_array( $status, array( AbstractServerEvents::SEND_FAILED, AbstractServerEvents::SEND_RETRY ), true ) ) {
                // Rejected for good counts as done; the message names the pixel.
                $outcome = self::OUTCOME_REJECTED;
            } else {
                $outcome = self::OUTCOME_ACCEPTED;
            }

            $outcomes[ $pixel_id ] = array(
                'outcome' => $outcome,
                'message' => $outcome === self::OUTCOME_ACCEPTED ? '' : $message,
            );
        }

        return $outcomes;
    }

    /**
     * @param array  $record   Delivery record
     * @param string $platform
     * @param string $event_id
     * @param array  $outcomes array( pixel id => array( 'outcome', 'message' ) )
     * @param string $source   One of the SOURCE_* constants
     * @return array The record with the outcomes merged in
     */
    private static function mergePixelOutcomes( array $record, $platform, $event_id, array $outcomes, $source ) {
        if ( empty( $outcomes ) ) {
            return $record;
        }

        $entry = isset( $record['platforms'][ $platform ] ) && is_array( $record['platforms'][ $platform ] )
            ? $record['platforms'][ $platform ]
            : array();
        // Another event_id is another Purchase (an order re-opened after a
        // refund): its outcomes replace the earlier ones.
        if ( ! isset( $entry['event_id'] ) || (string) $entry['event_id'] !== (string) $event_id ) {
            $entry = array( 'event_id' => (string) $event_id, 'pixels' => array() );
        }

        $now = time();
        foreach ( $outcomes as $pixel_id => $outcome ) {
            $pixel_id = (string) $pixel_id;
            $previous = isset( $entry['pixels'][ $pixel_id ]['outcome'] ) ? $entry['pixels'][ $pixel_id ]['outcome'] : '';
            // An accepted pixel stays accepted: a later run only reports that
            // it had nothing left to send.
            if ( $previous === self::OUTCOME_ACCEPTED && $outcome['outcome'] !== self::OUTCOME_ACCEPTED ) {
                continue;
            }

            $message = isset( $outcome['message'] ) ? self::redactMessage( wp_strip_all_tags( (string) $outcome['message'] ) ) : '';
            if ( function_exists( 'mb_substr' ) ) {
                $message = mb_substr( $message, 0, self::MESSAGE_MAX_LENGTH );
            } else {
                $message = substr( $message, 0, self::MESSAGE_MAX_LENGTH );
            }

            $entry['pixels'][ $pixel_id ] = array(
                'outcome' => (string) $outcome['outcome'],
                'time'    => $now,
                'source'  => (string) $source,
                'message' => $message,
            );
        }

        $record['platforms'][ $platform ] = $entry;

        return $record;
    }

    /**
     * A sender's message without anything secret in it. The message is stored
     * on the order and shown in wp-admin, and an HTTP library may quote the
     * request URL in its error, with the API secret or token in the query.
     *
     * @param string $message
     * @return string
     */
    public static function redactMessage( $message ) {
        // Query strings of URLs: nothing in them is needed to understand the error.
        $message = preg_replace( '~(https?://[^\s?#"\'`<>]+)\?[^\s"\'`<>]*~i', '$1', (string) $message );
        // Credentials quoted outside a URL: name=value, name: value, JSON "name":"value",
        // URL-encoded name%3Dvalue, Bearer value.
        $message = preg_replace( '~\b(api_secret|access[_-]?token|client_secret|secret|token|api[_-]?key)(["\']?\s*(?:[=:]|%3D)\s*["\']?)(?!\[removed\])[^\s&"\'`<>,;]+~i', '$1$2[removed]', (string) $message );
        $message = preg_replace( '~\b(bearer)\s+[A-Za-z0-9._\~+/=\-]{8,}~i', '$1 [removed]', (string) $message );

        return (string) $message;
    }

    /**
     * @param string         $type
     * @param \WC_Order|null $order
     * @param int            $order_id
     * @return array The delivery record, empty when the order has none
     */
    private static function readRecord( $type, $order, $order_id ) {
        $record = self::readMeta( $type, $order, $order_id, self::RECORD_META_KEY );

        return is_array( $record ) ? $record : array();
    }

    /**
     * Pixels that accepted this event_id.
     *
     * @return array|true true when the legacy marker says every pixel did
     */
    private static function getSentPixels( $type, $order, $order_id, $platform, $event_id ) {
        $value = self::readMeta( $type, $order, $order_id, "_pys_server_event_sent_{$platform}" );

        if ( is_string( $value ) ) {
            return $value !== '' && $value === $event_id ? true : array();
        }
        if ( is_array( $value ) && isset( $value['event_id'], $value['pixels'] ) && (string) $value['event_id'] === $event_id ) {
            return array_map( 'strval', (array) $value['pixels'] );
        }

        return array();
    }

    private static function getPending( $type, $order, $order_id, $platform, $event_id ) {
        $value = self::readMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}" );

        if ( is_array( $value ) && isset( $value['event_id'], $value['pixels'] ) && (string) $value['event_id'] === $event_id ) {
            return (array) $value['pixels'];
        }

        return array();
    }

    /**
     * Run a read-modify-write of the order's delivery meta under a per-order
     * lock, on freshly read meta. Its own lock context, so it nests inside the
     * purchase lock of the order-status fallback.
     */
    private static function withLock( $type, $order_id, callable $callback ) {
        $lock_state = pysAcquireNamedLock( 'purchase_claim_' . $type, $order_id, 5 );

        try {
            $order = null;
            if ( $type === 'woo' ) {
                if ( ! function_exists( 'wc_get_order' ) ) {
                    return array();
                }
                $order = wc_get_order( $order_id );
                if ( ! $order ) {
                    return array();
                }
                $order->read_meta_data( true );
            } else {
                if ( ! function_exists( 'edd_update_payment_meta' ) ) {
                    return array();
                }
                // EDD 3 order meta lives in the edd_order meta type.
                wp_cache_delete( $order_id, 'edd_order_meta' );
            }

            return $callback( $order );
        } finally {
            if ( 'acquired' === $lock_state ) {
                pysReleaseNamedLock( 'purchase_claim_' . $type, $order_id );
            }
        }
    }

    /**
     * Was a Purchase delivered for this platform on this order?
     *
     * _pys_advance_purchase_event_fired is deliberately not evidence: it is set
     * once the order-status run settles, even when every platform was skipped
     * or blocked.
     *
     * @param string $type        'woo' or 'edd'
     * @param mixed  $order_or_id Woo order or id; EDD payment id
     * @param string $platform    One of MARKER_PLATFORMS
     * @return bool
     */
    public static function purchaseOnRecord( $type, $order_or_id, $platform ) {
        if ( ! in_array( $platform, self::MARKER_PLATFORMS, true ) ) {
            return false;
        }

        $order    = null;
        $order_id = 0;
        if ( $type === 'woo' ) {
            if ( is_object( $order_or_id ) && method_exists( $order_or_id, 'get_meta' ) ) {
                $order = $order_or_id;
            } elseif ( function_exists( 'wc_get_order' ) ) {
                $order = wc_get_order( (int) $order_or_id );
            }
            if ( ! $order ) {
                return false;
            }
        } elseif ( $type === 'edd' ) {
            if ( ! function_exists( 'edd_get_payment_meta' ) ) {
                return false;
            }
            $order_id = (int) $order_or_id;
        } else {
            return false;
        }

        $marker = self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_marker' );
        if ( is_array( $marker ) && isset( $marker[ $platform ] ) ) {
            return true;
        }

        // Built before the marker existed: the thank-you page counts as delivered.
        if ( ! self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_pending' )
            && self::readMeta( $type, $order, $order_id, '_pys_purchase_event_fired' ) ) {
            return true;
        }

        if ( $platform === 'ga'
            && ( self::readMeta( $type, $order, $order_id, '_pys_ga_purchase_event_fired' )
                || self::readMeta( $type, $order, $order_id, '_pys_ga_advance_purchase_event_fired' ) ) ) {
            return true;
        }

        if ( self::readMeta( $type, $order, $order_id, "_pys_server_event_sent_{$platform}" ) ) {
            return true;
        }

        $sent = self::readMeta( $type, $order, $order_id, '_pys_purchase_server_sent' );
        if ( is_array( $sent ) && in_array( $platform, $sent, true ) ) {
            return true;
        }

        $fired = self::readMeta( $type, $order, $order_id, '_pys_server_fired_pixels' );

        return is_array( $fired ) && ! empty( $fired[ $platform ] );
    }

    private static function readMeta( $type, $order, $order_id, $key ) {
        if ( $type === 'woo' ) {
            return $order->get_meta( $key, true );
        }

        return pys_edd_order_meta( $order_id, $key );
    }

    /**
     * @param string         $type
     * @param \WC_Order|null $order
     * @param int            $order_id
     * @param string         $key
     * @param mixed          $value Null deletes the meta
     * @param bool           $save  Woo: false leaves the save to a later write
     *                              of the same order object
     * @return void
     */
    private static function writeMeta( $type, $order, $order_id, $key, $value, $save = true ) {
        if ( in_array( $key, array( self::RECORD_META_KEY, '_pys_purchase_browser_marker' ), true ) ) {
            self::$changed_orders[ $type . ':' . $order_id ] = array( $type, (int) $order_id );
        }

        if ( $type === 'woo' ) {
            if ( $value === null ) {
                $order->delete_meta_data( $key );
            } else {
                $order->update_meta_data( $key, $value );
            }
            if ( $save ) {
                // The record alone is a report: its write skips the order's save
                // hooks (webhooks, store syncs). The duplicate guard keeps the full save.
                if ( $key === self::RECORD_META_KEY ) {
                    $order->save_meta_data();
                } else {
                    $order->save();
                }
                self::fireChanged();
            }
            return;
        }

        // EDD has no payment-level delete helper; an empty value reads as "none".
        edd_update_payment_meta( $order_id, $key, $value === null ? '' : $value );
        self::fireChanged();
    }

    /**
     * Tell listeners about the orders whose record is now stored.
     *
     * @return void
     */
    private static function fireChanged() {
        $orders               = self::$changed_orders;
        self::$changed_orders = array();
        foreach ( $orders as $order ) {
            self::changed( $order[0], $order[1] );
        }
    }
}

/**
 * @param string $type        'woo' or 'edd'
 * @param mixed  $order_or_id Woo order or id; EDD payment id
 * @param string $platform    One of PurchaseDelivery::MARKER_PLATFORMS
 * @return bool True when a Purchase for the platform is on record for the order
 */
function pys_order_purchase_on_record( $type, $order_or_id, $platform ) {
    return PurchaseDelivery::purchaseOnRecord( $type, $order_or_id, $platform );
}
