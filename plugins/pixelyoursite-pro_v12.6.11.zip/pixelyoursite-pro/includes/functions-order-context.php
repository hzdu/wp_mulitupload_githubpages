<?php
/**
 * What the buyer's browser knew about an order, kept on the order.
 *
 * A server Purchase or refund is not always built in the buyer's request: a
 * status change in wp-admin, a gateway webhook or cron builds it in somebody
 * else's, where the current URL is wp-admin/post.php or wc-api/gateway and
 * the session cookie is absent. The page URL and the referrer are therefore
 * written onto the order while the buyer is still there (checkout, then the
 * thank-you page) and read back from it later.
 *
 * Renewal orders must not inherit these values from the subscription's parent
 * order: they describe another purchase by another visit.
 */

namespace PixelYourSite;

defined( 'ABSPATH' ) or die( 'Direct access not allowed' );

/**
 * The admin-ajax actions the buyer's browser calls: the browser event relays,
 * the purchase marker and EDD's checkout. Every other pys_ action (queue,
 * notices, reports) is an admin's and says nothing about the buyer.
 *
 * @param bool $with_checkout Include EDD's checkout. The posted page URL is read only
 *                            from the PYS relays, not from a third-party action.
 * @return string[]
 */
function pys_buyer_ajax_actions( $with_checkout = true ) {
	$actions = array(
		'pys_api_event', 'pys_tiktok_api_event', 'pys_openai_api_event', 'pys_pinterest_api_event',
		'pys_purchase_marker',
	);
	if ( $with_checkout ) {
		$actions[] = 'edd_process_checkout';
	}
	return $actions;
}

/**
 * True when the current request is one where the buyer is present: the order's
 * thank-you or order-pay page, the checkout submission, or a PYS event call.
 *
 * Everything else - wp-admin, cron, WP-CLI, gateway callbacks (wc-api), other
 * REST routes and other admin-ajax actions - runs in someone else's request, so
 * its URL and cookies say nothing about the buyer.
 *
 * @param string        $type        'woo' | 'edd'
 * @param \WC_Order|int $order_or_id
 * @return bool
 */
function pys_is_buyer_request( $type, $order_or_id ) {
	if ( pys_is_admin_page_request() ) {
		return false;
	}
	if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
		return false;
	}
	if ( defined( 'WP_CLI' ) && WP_CLI ) {
		return false;
	}

	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';

	if ( false !== strpos( $uri, 'wc-api' ) || isset( $_REQUEST['wc-api'] ) ) {
		return false;
	}

	// Our own routes live under /wp-json/pys*/ (pys/v1, pys-tiktok/v1, ...);
	// WooCommerce's Store API checkout is the buyer submitting the form.
	// rest_route is the same thing without pretty permalinks.
	$route = isset( $GLOBALS['wp']->query_vars['rest_route'] ) ? (string) $GLOBALS['wp']->query_vars['rest_route'] : '';
	if ( '' === $route && isset( $_GET['rest_route'] ) ) {
		$route = (string) $_GET['rest_route'];
	}
	if ( '' === $route && preg_match( '#/wp-json(/[^?]*)#', $uri, $m ) ) {
		$route = $m[1];
	}
	if ( '' !== $route ) {
		$route = '/' . ltrim( $route, '/' );
		return 0 === strpos( $route, '/pys' ) || 0 === strpos( $route, '/wc/store/v1/checkout' );
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return false;
	}

	$wc_ajax = isset( $_GET['wc-ajax'] ) ? (string) $_GET['wc-ajax'] : '';
	if ( '' === $wc_ajax && preg_match( '/[?&]wc-ajax=([^&]*)/', $uri, $m ) ) {
		$wc_ajax = $m[1];
	}
	if ( '' !== $wc_ajax ) {
		return 'checkout' === $wc_ajax;
	}

	if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
		$action = isset( $_REQUEST['action'] ) ? (string) $_REQUEST['action'] : '';
		return in_array( $action, pys_buyer_ajax_actions(), true );
	}

	$order_id = pys_order_context_id( $order_or_id );
	if ( $order_id <= 0 ) {
		return false;
	}

	if ( 'edd' === $type ) {
		// Same resolution EventsEdd::getEddOrderId() uses for the purchase build.
		if ( ! function_exists( 'edd_is_success_page' ) || ! edd_is_success_page()
			|| ! function_exists( 'PixelYourSite\getEddPaymentKey' ) || ! function_exists( 'edd_get_purchase_id_by_key' ) ) {
			return false;
		}
		return (int) edd_get_purchase_id_by_key( getEddPaymentKey() ) === $order_id;
	}

	if ( function_exists( 'is_checkout_pay_page' ) && is_checkout_pay_page() ) {
		return (int) get_query_var( 'order-pay' ) === $order_id;
	}
	if ( function_exists( 'is_order_received_page' ) && PYS()->woo_is_order_received_page( is_order_received_page() ) ) {
		return function_exists( 'PixelYourSite\wooGetOrderIdFromRequest' ) && (int) wooGetOrderIdFromRequest() === $order_id;
	}

	return false;
}

/**
 * The order an event is bound to, from its payload.
 *
 * edd_renewal_order (the renewal payment) wins over edd_order (the parent), which
 * wins over woo_order. Events without an order, or with id 0, return null.
 *
 * @param object $event SingleEvent
 * @return array|null array( 'woo'|'edd', int order id )
 */
function pys_event_order_ref( $event ) {
	if ( ! $event || ! method_exists( $event, 'getPayloadValue' ) ) {
		return null;
	}
	foreach ( array( 'edd_renewal_order' => 'edd', 'edd_order' => 'edd', 'woo_order' => 'woo' ) as $key => $type ) {
		$id = (int) $event->getPayloadValue( $key );
		if ( $id > 0 ) {
			return array( $type, $id );
		}
	}
	return null;
}

/**
 * The page URL our own AJAX call posted as $_POST['url'].
 *
 * Empty unless this is a PYS event relay or the purchase marker (another plugin's 'url' field says
 * nothing about this event), and empty for a value that is not a valid http(s)
 * URL. The query is cut when enable_remove_source_url_params is on.
 *
 * @return string
 */
function pys_posted_page_url() {
	if ( ! isset( $_POST['url'] ) || ! function_exists( 'wp_doing_ajax' ) || ! wp_doing_ajax()
		|| ! isset( $_REQUEST['action'] ) || ! in_array( (string) $_REQUEST['action'], pys_buyer_ajax_actions( false ), true ) ) {
		return '';
	}
	$url = esc_url_raw( wp_unslash( $_POST['url'] ) );
	if ( '' === $url || ! wp_http_validate_url( $url ) ) {
		return '';
	}
	if ( PYS()->getOption( 'enable_remove_source_url_params' ) ) {
		$list = explode( '?', $url );
		$url  = $list[0];
	}
	return $url;
}

/**
 * The business time of an order event that is not the order's own creation.
 *
 * Only a Woo refund has one: the refund record's creation date. Everything else,
 * and a refund whose record cannot be read, returns 0 (pys_order_event_time()
 * then decides).
 *
 * @param object $event SingleEvent
 * @return int
 */
function pys_event_business_time( $event ) {
	if ( ! $event || ! method_exists( $event, 'getId' ) || 'woo_refund' !== $event->getId() ) {
		return 0;
	}
	if ( ! is_array( $event->args ) || empty( $event->args['refund_id'] ) || ! function_exists( 'wc_get_order' ) ) {
		return 0;
	}
	$refund = wc_get_order( (int) $event->args['refund_id'] );
	$date   = $refund ? $refund->get_date_created() : null;
	return $date ? (int) $date->getTimestamp() : 0;
}

/**
 * @param \WC_Order|int $order_or_id
 * @return int
 */
function pys_order_context_id( $order_or_id ) {
	return is_object( $order_or_id ) ? (int) $order_or_id->get_id() : (int) $order_or_id;
}

/**
 * The URL of the page the buyer checked out on.
 *
 * Checkout is submitted by AJAX or REST, so the request URL is the endpoint
 * (?wc-ajax=checkout) and the page the buyer was on is the referer. It is
 * trusted only from this site: a foreign referer is a redirect from a payment
 * page or a forged header, not where the order was placed.
 *
 * @return string '' when nothing valid is known.
 */
function pys_checkout_page_url() {
	$uri    = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
	$is_xhr = ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() )
		|| ( defined( 'REST_REQUEST' ) && REST_REQUEST )
		|| false !== strpos( $uri, 'wc-ajax=' )
		|| false !== strpos( $uri, '/wp-json/' );

	if ( $is_xhr ) {
		$referer = isset( $_SERVER['HTTP_REFERER'] ) ? (string) $_SERVER['HTTP_REFERER'] : '';
		if ( pys_is_valid_public_url( $referer ) ) {
			$host = ! empty( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : wp_parse_url( home_url(), PHP_URL_HOST );
			if ( 0 === strcasecmp( (string) wp_parse_url( $referer, PHP_URL_HOST ), (string) $host ) ) {
				return $referer;
			}
		}
	} else {
		$current = pys_get_current_page_url();
		if ( pys_is_valid_public_url( $current ) ) {
			return $current;
		}
	}

	$fallback = '';
	if ( function_exists( 'wc_get_checkout_url' ) ) {
		$fallback = (string) wc_get_checkout_url();
	} elseif ( function_exists( 'edd_get_checkout_uri' ) ) {
		$fallback = (string) edd_get_checkout_uri();
	}

	return pys_is_valid_public_url( $fallback ) ? $fallback : '';
}

/**
 * One meta value of an EDD order, read straight from the order meta.
 *
 * edd_get_payment_meta() builds a whole EDD_Payment first, a few dozen queries
 * and filters per call; a list page that reads a handful of keys per order spent
 * half a minute there. For keys of its own EDD 3 answers both the same.
 *
 * @param int    $order_id
 * @param string $key
 * @return mixed '' when the order has no such meta
 */
function pys_edd_order_meta( $order_id, $key ) {
	if ( function_exists( 'edd_get_order_meta' ) ) {
		return edd_get_order_meta( (int) $order_id, $key, true );
	}

	return function_exists( 'edd_get_payment_meta' ) ? edd_get_payment_meta( (int) $order_id, $key, true ) : '';
}

/**
 * Write the checkout page URL and the session referrer onto a new order.
 *
 * Woo: the caller saves; this runs inside checkout hooks that already do.
 *
 * @param string        $type 'woo' | 'edd'
 * @param \WC_Order|int $order_or_id
 */
function pys_save_order_context( $type, $order_or_id ) {
	$url      = pys_checkout_page_url();
	$referrer = pys_get_session_entry_referrer_url();

	if ( 'edd' === $type ) {
		if ( ! function_exists( 'edd_update_payment_meta' ) ) {
			return;
		}
		$id = pys_order_context_id( $order_or_id );
		if ( '' !== $url ) {
			edd_update_payment_meta( $id, 'pys_page_url', $url );
		}
		if ( '' !== $referrer ) {
			edd_update_payment_meta( $id, 'pys_page_referrer', $referrer );
		}
		pys_save_order_consent( 'edd', $id );
		return;
	}

	$order = is_object( $order_or_id ) ? $order_or_id : ( function_exists( 'wc_get_order' ) ? wc_get_order( $order_or_id ) : false );
	if ( ! $order ) {
		return;
	}
	if ( '' !== $url ) {
		$order->update_meta_data( 'pys_page_url', $url );
	}
	if ( '' !== $referrer ) {
		$order->update_meta_data( 'pys_page_referrer', $referrer );
	}
	pys_save_order_consent( 'woo', $order );
}

/**
 * Replace the checkout URL with the thank-you page URL, once per order.
 *
 * The thank-you page is what the browser Purchase event reports, so the server
 * copy should match it. Once: a reload or a later visit must not move it.
 * Woo: the caller saves.
 *
 * @param string        $type 'woo' | 'edd'
 * @param \WC_Order|int $order_or_id
 */
function pys_mark_order_thank_you_url( $type, $order_or_id ) {
	$url = pys_get_current_page_url();

	if ( 'edd' === $type ) {
		if ( ! function_exists( 'edd_get_payment_meta' ) || ! function_exists( 'edd_update_payment_meta' ) ) {
			return;
		}
		$id = pys_order_context_id( $order_or_id );
		if ( edd_get_payment_meta( $id, '_pys_page_url_final', true ) ) {
			return;
		}
		edd_update_payment_meta( $id, 'pys_page_url', $url );
		edd_update_payment_meta( $id, '_pys_page_url_final', 1 );
		return;
	}

	$order = is_object( $order_or_id ) ? $order_or_id : ( function_exists( 'wc_get_order' ) ? wc_get_order( $order_or_id ) : false );
	if ( ! $order || $order->get_meta( '_pys_page_url_final', true ) ) {
		return;
	}
	$order->update_meta_data( 'pys_page_url', $url );
	$order->update_meta_data( '_pys_page_url_final', 1 );
}

/**
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @param string $key
 * @return string
 */
function pys_order_context_meta( $type, $order_id, $key ) {
	if ( 'edd' === $type ) {
		return (string) pys_edd_order_meta( $order_id, $key );
	}
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
	return $order ? (string) $order->get_meta( $key, true ) : '';
}

/**
 * The stored page URL, without the query when the setting asks for it
 * (order keys and click ids sit there).
 *
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @return string
 */
function pys_order_page_url( $type, $order_id ) {
	$url = pys_order_context_meta( $type, $order_id, 'pys_page_url' );
	if ( '' !== $url && PYS()->getOption( 'enable_remove_source_url_params' ) ) {
		$url = pys_strip_url_query_and_fragment( $url );
	}
	return $url;
}

/**
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @return string
 */
function pys_order_page_referrer( $type, $order_id ) {
	return pys_order_context_meta( $type, $order_id, 'pys_page_referrer' );
}

/**
 * Whether a WooCommerce Subscriptions renewal was charged automatically or by
 * the customer.
 *
 * Manual   = the subscription is set to manual renewal, or an early renewal was
 *            initiated by the customer.
 * Automatic = the renewal was charged automatically by the payment gateway
 *            (scheduled/recurring billing).
 *
 * @param \WC_Order|int $order Renewal order object or ID.
 * @return string 'manual' | 'automatic'
 */
function pys_woo_renewal_type( $order ) {
	if ( ! is_object( $order ) && function_exists( 'wc_get_order' ) ) {
		$order = wc_get_order( $order );
	}
	if ( ! $order ) {
		return 'automatic';
	}

	// Early renewals are always initiated manually by the customer.
	if ( function_exists( 'wcs_order_contains_early_renewal' ) && wcs_order_contains_early_renewal( $order ) ) {
		return 'manual';
	}

	// If any related subscription requires manual renewal, treat it as manual.
	if ( function_exists( 'wcs_get_subscriptions_for_renewal_order' ) ) {
		$subscriptions = wcs_get_subscriptions_for_renewal_order( $order );
		foreach ( $subscriptions as $subscription ) {
			if ( is_object( $subscription ) && method_exists( $subscription, 'is_manual' ) && $subscription->is_manual() ) {
				return 'manual';
			}
		}
	}

	return 'automatic';
}

/**
 * Determine whether the current EDD renewal was triggered manually by an admin.
 *
 * Manual   = renewal added from the subscription single view in wp-admin
 *            (edd_recurring_process_add_renewal_payment, guarded by its nonce).
 * Automatic = renewal recorded by a payment gateway webhook / IPN.
 *
 * @return string 'manual' | 'automatic'
 */
function pys_edd_renewal_type() {
	if ( is_admin()
		&& isset( $_POST['_wpnonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'edd-recurring-add-renewal-payment' )
	) {
		return 'manual';
	}
	return 'automatic';
}

/**
 * The renewal type recorded when the renewal was processed.
 *
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @return string 'automatic' | 'manual' | ''
 */
function pys_order_renewal_type( $type, $order_id ) {
	$value = pys_order_context_meta( $type, $order_id, '_pys_renewal_type' );
	return in_array( $value, array( 'automatic', 'manual' ), true ) ? $value : '';
}

/**
 * Events that report a subscription ending. The ids are the ones
 * EventsWoo/EventsEdd::getSubscriptionCanceledEvent() and ::getSubscriptionExpiredEvent()
 * create (note the single "l" in "canceled").
 *
 * @param string $event_id
 * @return bool
 */
function pys_order_event_is_subscription_end( $event_id ) {
	return in_array( $event_id, array(
		'woo_subscription_canceled',
		'woo_subscription_expired',
		'edd_subscription_canceled',
		'edd_subscription_expired',
	), true );
}

/**
 * How far back each platform accepts an event time. Meta, GA4 (Measurement
 * Protocol timestamp_micros) and OpenAI are documented; TikTok and Pinterest are
 * assumed to match Meta until verified.
 */
if ( ! defined( __NAMESPACE__ . '\PYS_EVENT_TIME_LIMIT_META' ) ) {
	define( __NAMESPACE__ . '\PYS_EVENT_TIME_LIMIT_META', 7 * DAY_IN_SECONDS );
	define( __NAMESPACE__ . '\PYS_EVENT_TIME_LIMIT_GA4', 72 * HOUR_IN_SECONDS );
	define( __NAMESPACE__ . '\PYS_EVENT_TIME_LIMIT_OPENAI', 7 * DAY_IN_SECONDS );
	define( __NAMESPACE__ . '\PYS_EVENT_TIME_LIMIT_TIKTOK', 7 * DAY_IN_SECONDS );
	define( __NAMESPACE__ . '\PYS_EVENT_TIME_LIMIT_PINTEREST', 7 * DAY_IN_SECONDS );
}
// The send takes time: an event exactly at the limit now is past it on arrival.
if ( ! defined( __NAMESPACE__ . '\PYS_EVENT_TIME_MARGIN' ) ) {
	define( __NAMESPACE__ . '\PYS_EVENT_TIME_MARGIN', 600 );
}

/**
 * Events whose time is the time of the business event (the order's creation, or
 * the refund's date) and not the moment a request happens to send them.
 * Subscription cancel/expire are absent on purpose: they happen when they are sent.
 *
 * @return string[]
 */
function pys_order_event_business_time_ids() {
	return array(
		'woo_purchase', 'woo_poas', 'woo_subscription_created', 'woo_start_trial', 'woo_subscription_renewal', 'woo_refund',
		'edd_purchase', 'edd_subscription_created', 'edd_start_trial', 'edd_subscription_renewal', 'edd_refund',
	);
}

/**
 * Creation time of an order, as a timestamp.
 *
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @return int 0 when the order or its date cannot be read.
 */
function pys_order_created_timestamp( $type, $order_id ) {
	if ( 'edd' === $type ) {
		$payment = function_exists( 'edd_get_order' ) ? edd_get_order( $order_id ) : false;
		$date    = ( $payment && ! empty( $payment->date_created ) ) ? (string) $payment->date_created : '';
		$time    = '' !== $date ? strtotime( $date . ' UTC' ) : false; // EDD stores UTC.
		return $time ? (int) $time : 0;
	}
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
	$date  = $order ? $order->get_date_created() : null;
	return $date ? (int) $date->getTimestamp() : 0;
}

/**
 * The time to send with an order-bound server event.
 *
 * The business time (the order's creation, or $business_time for a refund) when
 * the platform still accepts it; else the time the order's Purchase was first
 * sent, which a retry reuses; else now. Subscription cancel/expire and unknown
 * events are sent now.
 *
 * @param string $type          'woo' | 'edd'
 * @param int    $order_id      Lifecycle events: the parent order; renewals: the renewal order.
 * @param string $event_id
 * @param int    $limit_seconds PYS_EVENT_TIME_LIMIT_* of the receiving platform.
 * @param int    $business_time Timestamp supplied by the caller (a refund's date); wins over the order's creation.
 * @param int    $now           0 = time().
 * @return int
 */
function pys_order_event_time( $type, $order_id, $event_id, $limit_seconds, $business_time = 0, $now = 0 ) {
	$now = (int) $now > 0 ? (int) $now : time();
	if ( ! in_array( $event_id, pys_order_event_business_time_ids(), true ) ) {
		return $now;
	}

	$order_id  = (int) $order_id;
	$is_refund = in_array( $event_id, array( 'woo_refund', 'edd_refund' ), true );
	$business  = (int) $business_time;
	if ( $business <= 0 && ! $is_refund ) {
		$business = pys_order_created_timestamp( $type, $order_id );
	}

	if ( $business > 0 ) {
		if ( $business >= $now ) {
			return $now;
		}
		if ( $now - $business <= $limit_seconds - PYS_EVENT_TIME_MARGIN ) {
			return $business;
		}
	}

	// A refund is not the purchase: the purchase's first-send time says nothing about it.
	if ( ! $is_refund ) {
		$first = (int) pys_order_context_meta( $type, $order_id, '_pys_purchase_event_time' );
		if ( $first > 0 && $first <= $now && $now - $first <= $limit_seconds - PYS_EVENT_TIME_MARGIN ) {
			return $first;
		}
	}

	if ( $business > 0 ) {
		PYS()->getLog()->debug( "event-time: capped {$limit_seconds}s for {$type} #{$order_id}, age " . ( $now - $business ) . 's' );
	}
	return $now;
}

/**
 * Remember when the order's Purchase was first sent, once: a retry hours later
 * reuses it when the order itself is too old for the platform.
 * Woo: with an order object the caller saves (getOrCreatePurchaseEventId() does);
 * with an id this saves.
 *
 * @param string        $type 'woo' | 'edd'
 * @param \WC_Order|int $order_or_id
 * @return int The stored time, 0 when the order cannot be read.
 */
function pys_persist_purchase_event_time( $type, $order_or_id ) {
	$key = '_pys_purchase_event_time';

	if ( 'edd' === $type ) {
		if ( ! function_exists( 'edd_get_payment_meta' ) || ! function_exists( 'edd_update_payment_meta' ) ) {
			return 0;
		}
		$id     = pys_order_context_id( $order_or_id );
		$stored = (int) edd_get_payment_meta( $id, $key, true );
		if ( $stored > 0 ) {
			return $stored;
		}
		$stored = time();
		edd_update_payment_meta( $id, $key, $stored );
		return $stored;
	}

	$save  = ! is_object( $order_or_id );
	$order = is_object( $order_or_id ) ? $order_or_id : ( function_exists( 'wc_get_order' ) ? wc_get_order( $order_or_id ) : false );
	if ( ! $order ) {
		return 0;
	}
	$stored = (int) $order->get_meta( $key, true );
	if ( $stored > 0 ) {
		return $stored;
	}
	$stored = time();
	$order->update_meta_data( $key, $stored );
	if ( $save ) {
		$order->save();
	}
	return $stored;
}

/**
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @return int 0 for a guest or when the order cannot be read.
 */
function pys_order_context_customer_id( $type, $order_id ) {
	if ( 'edd' === $type ) {
		return function_exists( 'edd_get_payment_user_id' ) ? (int) edd_get_payment_user_id( $order_id ) : 0;
	}
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
	// A refund has no customer of its own: it belongs to its parent order's.
	if ( $order && ! method_exists( $order, 'get_customer_id' ) && method_exists( $order, 'get_parent_id' ) ) {
		$order = (int) $order->get_parent_id() > 0 ? wc_get_order( (int) $order->get_parent_id() ) : false;
	}
	return $order && method_exists( $order, 'get_customer_id' ) ? (int) $order->get_customer_id() : 0;
}

/**
 * Is this request the order's customer acting on the front end themselves?
 * wp-admin, cron and REST calls are never that, even when a customer is logged
 * in: they are somebody else's request or a system one.
 *
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @return bool
 */
function pys_is_customer_own_request( $type, $order_id ) {
	if ( is_admin() || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return false;
	}
	$customer_id = pys_order_context_customer_id( $type, $order_id );
	return $customer_id > 0 && function_exists( 'get_current_user_id' ) && (int) get_current_user_id() === $customer_id;
}

/**
 * Is the order a subscription renewal, and was it charged without the customer?
 *
 * EDD renewals are payments with status edd_subscription; they are always
 * recorded by a gateway notification or an admin, never by the customer.
 *
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @return bool
 */
function pys_is_automatic_renewal( $type, $order_id ) {
	if ( 'edd' === $type ) {
		$payment = function_exists( 'edd_get_order' ) ? edd_get_order( $order_id ) : false;
		return $payment && isset( $payment->status ) && 'edd_subscription' === $payment->status;
	}
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
	if ( ! $order || ! function_exists( 'wcs_order_contains_renewal' ) || ! wcs_order_contains_renewal( $order ) ) {
		return false;
	}
	$renewal = pys_order_renewal_type( $type, $order_id );
	if ( '' === $renewal ) {
		$renewal = pys_woo_renewal_type( $order );
	}
	return 'automatic' === $renewal;
}

/**
 * Where an order-bound server event comes from, whichever request sends it.
 *
 * Readers map action_source to their platform (Meta: website|system_generated|other,
 * Pinterest and OpenAI: website -> web, anything else -> offline) and fall back to
 * their own request URL when url is '' on a website event.
 *
 * @param string $type        'woo' | 'edd'
 * @param int    $order_id    Subscription events: the parent order for created/trial, the renewal order for renewals.
 * @param string $event_id
 * @param string $payload_url Page URL the browser reported with the event.
 * @return array{action_source:string,url:string,referrer:string}
 */
function pys_order_event_context( $type, $order_id, $event_id = '', $payload_url = '' ) {
	$order_id = (int) $order_id;
	$system   = array( 'action_source' => 'system_generated', 'url' => '', 'referrer' => '' );
	$strip    = static function ( $url ) {
		return ( '' !== $url && PYS()->getOption( 'enable_remove_source_url_params' ) ) ? pys_strip_url_query_and_fragment( $url ) : $url;
	};

	$buyer = pys_is_buyer_request( $type, $order_id );

	if ( $buyer && '' !== $payload_url ) {
		return array(
			'action_source' => 'website',
			'url'           => $strip( $payload_url ),
			'referrer'      => '',
		);
	}
	// A buyer request leaves the referrer empty: readers resolve it from the live request.
	if ( $buyer ) {
		// An XHR's own URL is the endpoint (admin-ajax.php, /wp-json/...), never
		// the page the buyer is on: use the page stored on the order instead.
		$is_xhr = ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() )
			|| ( defined( 'REST_REQUEST' ) && REST_REQUEST )
			|| ! empty( $_GET['wc-ajax'] );
		$buyer_url = $is_xhr ? pys_order_page_url( $type, $order_id ) : $strip( pys_get_current_page_url() );
		if ( '' === $buyer_url ) {
			$buyer_url = pys_order_fallback_url( $type, $order_id );
		}
		return array( 'action_source' => 'website', 'url' => $buyer_url, 'referrer' => '' );
	}

	$own = pys_is_customer_own_request( $type, $order_id );

	if ( ! $own && pys_order_event_is_subscription_end( $event_id ) ) {
		return $system;
	}
	if ( pys_is_automatic_renewal( $type, $order_id ) ) {
		return $system;
	}
	if ( $own ) {
		return array( 'action_source' => 'website', 'url' => $strip( pys_get_current_page_url() ), 'referrer' => '' );
	}

	$other = array( 'action_source' => 'other', 'url' => '', 'referrer' => '' );
	if ( 'edd' === $type ) {
		// Both are written only by the checkout snapshot, so neither means the order was added by hand or imported.
		$signals = function_exists( 'edd_get_payment_meta' ) ? edd_get_payment_meta( $order_id, 'pys_client_signals', true ) : '';
		if ( '' === pys_order_context_meta( $type, $order_id, 'pys_page_url' ) && empty( $signals ) ) {
			return $other;
		}
	} else {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		if ( $order && 'admin' === $order->get_created_via() ) {
			return $other;
		}
	}

	$stored = pys_order_page_url( $type, $order_id );
	if ( '' !== $stored ) {
		return array( 'action_source' => 'website', 'url' => $stored, 'referrer' => pys_order_page_referrer( $type, $order_id ) );
	}

	PYS()->getLog()->debug( "order-context: no stored URL for {$type} #{$order_id}" );
	// An order placed before the upgrade, a REST/POS/imported order: the order's own
	// page, never this request's wp-admin or gateway URL.
	return array( 'action_source' => 'website', 'url' => pys_order_fallback_url( $type, $order_id ), 'referrer' => '' );
}

/**
 * A page to report for an order that has none stored: the thank-you page (the
 * parent's stored page for a CartFlows child), else the checkout page.
 *
 * @param string $type 'woo' | 'edd'
 * @param int    $order_id
 * @return string '' only when the site cannot say.
 */
function pys_order_fallback_url( $type, $order_id ) {
	$order_id = (int) $order_id;
	$url      = '';

	if ( 'edd' === $type ) {
		if ( function_exists( 'edd_get_success_page_uri' ) ) {
			$url = (string) edd_get_success_page_uri();
		}
		if ( ! pys_is_valid_public_url( $url ) && function_exists( 'edd_get_checkout_uri' ) ) {
			$url = (string) edd_get_checkout_uri();
		}
	} else {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		// A refund belongs to its parent order's page.
		if ( $order && ! method_exists( $order, 'get_checkout_order_received_url' ) && method_exists( $order, 'get_parent_id' ) && (int) $order->get_parent_id() > 0 ) {
			$order = wc_get_order( (int) $order->get_parent_id() );
		}
		if ( $order ) {
			$cf = (int) $order->get_meta( '_cartflows_offer_parent_id', true );
			if ( $cf > 0 ) {
				$url = pys_order_page_url( 'woo', $cf );
			}
			if ( '' === $url && method_exists( $order, 'get_checkout_order_received_url' ) ) {
				$url = (string) $order->get_checkout_order_received_url();
			}
		}
		if ( ! pys_is_valid_public_url( $url ) && function_exists( 'wc_get_checkout_url' ) ) {
			$url = (string) wc_get_checkout_url();
		}
	}

	if ( ! pys_is_valid_public_url( $url ) ) {
		return '';
	}
	// The received URL carries ?key=: cut it when the setting says so.
	return PYS()->getOption( 'enable_remove_source_url_params' ) ? pys_strip_url_query_and_fragment( $url ) : $url;
}

/**
 * Keep these values off renewal orders and resubscribe copies: Subscriptions
 * copies every meta key of the parent order unless told otherwise.
 *
 * @param array  $data
 * @param mixed  $to
 * @param mixed  $from
 * @param string $copy_type subscription | parent | renewal_order | resubscribe_order
 * @return array
 */
function pys_wcs_exclude_order_meta( $data, $to, $from, $copy_type ) {
	foreach ( array( 'pys_page_url', 'pys_page_referrer', '_pys_page_url_final', '_pys_purchase_event_time', '_pys_renewal_type' ) as $key ) {
		unset( $data[ $key ] );
	}

	// A renewal is a new purchase: it keeps the browser ids (fbp, ttp, obref, GA,
	// external_id) but not the parent's ad click ids.
	if ( in_array( $copy_type, array( 'renewal_order', 'resubscribe_order' ), true ) ) {
		unset( $data['pys_click_ids'] );
		$blank = array(
			'pys_fb_cookie'  => 'fbc',
			'pys_tt_cookie'  => 'ttclid',
			'pys_oai_cookie' => 'oppref',
			'pys_pin_cookie' => 'epik',
		);
		foreach ( $blank as $meta_key => $inner ) {
			if ( ! isset( $data[ $meta_key ] ) ) {
				continue;
			}
			$serialized = is_string( $data[ $meta_key ] );
			$value      = $serialized ? maybe_unserialize( $data[ $meta_key ] ) : $data[ $meta_key ];
			if ( ! is_array( $value ) ) {
				continue;
			}
			$value[ $inner ]   = null;
			$data[ $meta_key ] =$serialized ? maybe_serialize( $value ) : $value;
		}
	}
	return $data;
}
add_filter( 'wc_subscriptions_object_data', __NAMESPACE__ . '\pys_wcs_exclude_order_meta', 10, 4 );

/**
 * The "Tracking type" label of a WooCommerce order.
 *
 * A full refund and a cancel reset _pys_purchase_event_fired on purpose (a
 * re-opened order can fire Purchase again), so the label cannot rest on the two
 * "fired" flags alone: _pys_tracking_type (apt|tag) is written next to them and
 * never cleared. Orders reset before that marker existed are recognised by the
 * delivery evidence the reset leaves behind.
 *
 * @param \WC_Order|int $order
 * @return string
 */
function pys_order_tracking_type( $order ) {
	$order_id = 0;
	if ( is_numeric( $order ) ) {
		$order_id = (int) $order;
		$order    = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
	}
	$object = is_object( $order ) && method_exists( $order, 'get_meta' );
	if ( $object && ! $order_id && method_exists( $order, 'get_id' ) ) {
		$order_id = (int) $order->get_id();
	}

	$read = function ( $key ) use ( $object, $order, $order_id ) {
		if ( $object ) {
			return $order->get_meta( $key, true );
		}
		return $order_id ? get_post_meta( $order_id, $key, true ) : '';
	};

	$marker = $read( '_pys_tracking_type' );
	// A 'tag' marker outranks the APT flag: the flag also closes a server run
	// that sent nothing because the thank-you page had delivered it all.
	if ( 'apt' === $marker || ( 'tag' !== $marker && $read( '_pys_advance_purchase_event_fired' ) ) ) {
		$label = 'Advanced Purchase Tracking (APT)';
	} elseif ( $read( '_pys_purchase_event_fired' ) || 'tag' === $marker ) {
		$label = 'Tag or API';
	} else {
		$label = 'Not tracked';

		// Orders reset before the marker existed: any non-GA delivery evidence.
		$tag = false;
		foreach ( array( '_pys_purchase_browser_marker', '_pys_purchase_server_sent', '_pys_server_fired_pixels' ) as $key ) {
			$value = $read( $key );
			// GA-only entries are not evidence that any other platform got the event.
			if ( is_array( $value ) ) {
				unset( $value['ga'] );
				$value = array_filter( $value, function ( $item ) {
					return 'ga' !== $item;
				} );
			}
			if ( ! empty( $value ) ) {
				$tag = true;
				break;
			}
		}
		if ( ! $tag ) {
			foreach ( array( 'facebook', 'tiktok', 'openai', 'pinterest' ) as $platform ) {
				if ( ! empty( $read( "_pys_refunds_sent_{$platform}" ) ) || ! empty( $read( "_pys_refund_status_sent_{$platform}" ) ) ) {
					$tag = true;
					break;
				}
			}
		}
		if ( ! $tag ) {
			$keys = array();
			if ( $object && method_exists( $order, 'get_meta_data' ) ) {
				foreach ( $order->get_meta_data() as $meta ) {
					$keys[ (string) $meta->key ] = $meta->value;
				}
			} elseif ( $order_id ) {
				$keys = (array) get_post_meta( $order_id );
			}
			foreach ( $keys as $key => $value ) {
				if ( 0 === strpos( $key, '_pys_server_event_sent_' ) && ! empty( $value ) ) {
					$tag = true;
					break;
				}
			}
		}

		if ( $tag ) {
			$label = 'Tag or API';
		} elseif ( $read( '_pys_ga_purchase_event_fired' ) || $read( '_pys_ga_advance_purchase_event_fired' ) ) {
			// GA4 can be sent by APT before the AJAX guard returns while every
			// other platform got nothing.
			$label = 'Partial (GA4 API)';
		}
	}

	if ( 'Not tracked' === $label || ! $object ) {
		return $label;
	}

	$status   = (string) $order->get_status();
	$decimals = function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2;
	$refunded = method_exists( $order, 'get_total_refunded' ) ? round( (float) $order->get_total_refunded(), $decimals ) : 0.0;
	$total    = round( (float) $order->get_total(), $decimals );
	if ( 'cancelled' === $status ) {
		$label .= ' · cancelled';
	} elseif ( 'refunded' === $status || ( $refunded > 0 && $refunded >= $total ) ) {
		$label .= ' · refunded';
	} elseif ( $refunded > 0 ) {
		$label .= ' · partially refunded';
	}

	return $label;
}
