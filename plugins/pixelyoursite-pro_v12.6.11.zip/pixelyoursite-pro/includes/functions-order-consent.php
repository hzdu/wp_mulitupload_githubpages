<?php
/**
 * Consent of an order's buyer for the server sends of that order.
 *
 * A server send of an order (the order-status Purchase, the Measurement
 * Protocol copy, the events queue, POAS) runs in wp-admin, cron, a gateway
 * callback or the checkout request: the consent of that request is not the
 * buyer's. The buyer's choice is stored on the order at checkout and read here.
 *
 * @package PixelYourSite
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

const PYS_ORDER_CONSENT_META = '_pys_consent';

const PYS_CONSENT_GRANTED    = 'granted';
const PYS_CONSENT_RESTRICTED = 'restricted';
const PYS_CONSENT_DENIED     = 'denied';

/**
 * Platforms whose consent is stored on the order.
 *
 * @return string[]
 */
function pys_order_consent_platforms() {
	return array( 'facebook', 'ga', 'google_ads', 'tiktok', 'pinterest', 'openai', 'bing', 'reddit' );
}

/**
 * The current request's consent for a platform.
 *
 * @param string $platform Pixel slug
 * @return string One of the PYS_CONSENT_* values
 */
function pys_consent_state_now( $platform ) {
	if ( Consent()->checkConsent( $platform ) ) {
		return PYS_CONSENT_GRANTED;
	}

	return Consent()->firesInRestrictedMode( $platform ) ? PYS_CONSENT_RESTRICTED : PYS_CONSENT_DENIED;
}

/**
 * Does the buyer's browser stand behind this request? A checkout submitted from
 * the site's own page carries it as the referrer; wp-admin (the administrator's),
 * cron, WP-CLI and gateway webhooks do not. Cookies are no sign: WooCommerce
 * adds its session cookie to $_COOKIE inside any request.
 *
 * Shortcut: a browser that sends no referrer at all is taken for a webhook; its order is sent as before.
 *
 * @return bool
 */
function pys_request_has_browser() {
	if ( pys_is_admin_page_request() || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
		return false;
	}

	$referer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
	$host    = $referer ? wp_parse_url( $referer, PHP_URL_HOST ) : '';

	return $host && strtolower( (string) $host ) === strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
}

/**
 * Store the buyer's consent on the order. Call it in the buyer's checkout request.
 * Nothing is stored on a site that does not manage consent, nor in a request
 * without the buyer's browser: there the consent plugin answers "denied" for
 * want of a choice, and that is not the buyer's answer.
 *
 * @param string        $type        'woo' or 'edd'
 * @param \WC_Order|int $order_or_id Woo order (saved by the caller) or EDD payment id
 * @return void
 */
function pys_save_order_consent( $type, $order_or_id ) {
	if ( ! Consent()->isManaged() || ! pys_request_has_browser() ) {
		return;
	}

	$states = array();
	foreach ( pys_order_consent_platforms() as $platform ) {
		$states[ $platform ] = pys_consent_state_now( $platform );
	}

	if ( 'edd' === $type ) {
		if ( function_exists( 'edd_update_payment_meta' ) ) {
			edd_update_payment_meta( (int) $order_or_id, PYS_ORDER_CONSENT_META, $states );
		}

		return;
	}

	if ( is_object( $order_or_id ) && method_exists( $order_or_id, 'update_meta_data' ) ) {
		$order_or_id->update_meta_data( PYS_ORDER_CONSENT_META, $states );
	}
}

/**
 * The buyer's consent for a server send of the order.
 *
 * In the buyer's own request their current choice counts; anywhere else the
 * choice stored at checkout.
 *
 * @param string $type     'woo' or 'edd'
 * @param int    $order_id
 * @param string $platform Pixel slug
 * @return string A PYS_CONSENT_* value, or '' when unknown (send as before)
 */
function pys_order_consent_state( $type, $order_id, $platform ) {
	$order_id = (int) $order_id;
	if ( $order_id <= 0 || ! in_array( $platform, pys_order_consent_platforms(), true ) ) {
		return '';
	}

	if ( pys_is_buyer_request( $type, $order_id ) ) {
		return Consent()->isManaged() ? pys_consent_state_now( $platform ) : '';
	}

	$states = '';
	if ( 'edd' === $type ) {
		$states = pys_edd_order_meta( $order_id, PYS_ORDER_CONSENT_META );
	} elseif ( function_exists( 'wc_get_order' ) ) {
		$order  = wc_get_order( $order_id );
		$states = $order ? $order->get_meta( PYS_ORDER_CONSENT_META, true ) : '';
	}

	return is_array( $states ) && isset( $states[ $platform ] ) ? (string) $states[ $platform ] : '';
}

/**
 * Should an order-bound server event run in the platform's restricted mode
 * (Meta Limited Data Use, OpenAI opt-out)?
 *
 * @param SingleEvent $event
 * @param string      $platform Pixel slug
 * @param bool        $current  The current request's own answer, used when the order says nothing
 * @return bool
 */
function pys_order_event_restricted( $event, $platform, $current ) {
	$order_ref = pys_event_order_ref( $event );
	if ( ! $order_ref ) {
		return (bool) $current;
	}

	$state = pys_order_consent_state( $order_ref[0], $order_ref[1], $platform );

	return '' === $state ? (bool) $current : PYS_CONSENT_RESTRICTED === $state;
}

/**
 * Stop a server send of an order the buyer refused consent for
 * (callback of pys_disable_server_event_filter).
 *
 * @param bool       $disabled
 * @param string     $event_name Event id, e.g. woo_purchase
 * @param string     $platform   Sender slug: facebook, tiktok, openai, pinterest, ga4
 * @param int|string $order_id
 * @return bool
 */
function pys_block_server_event_without_consent( $disabled, $event_name, $platform, $order_id ) {
	if ( $disabled || empty( $order_id ) || ! is_numeric( $order_id ) ) {
		return $disabled;
	}

	$platform = 'ga4' === $platform ? 'ga' : (string) $platform;
	// shortcut: the store is read from the event name; an order event without a woo_/edd_ prefix counts as WooCommerce.
	$type  = 0 === strpos( (string) $event_name, 'edd_' ) ? 'edd' : 'woo';
	$state = pys_order_consent_state( $type, (int) $order_id, $platform );

	// The Measurement Protocol has no cookieless mode: GA4 needs analytics consent.
	$blocked = PYS_CONSENT_DENIED === $state || ( 'ga' === $platform && PYS_CONSENT_RESTRICTED === $state );
	if ( $blocked && PYS()->getLog() ) {
		PYS()->getLog()->debug( "Server event {$event_name} to {$platform} not sent: no consent for {$type} order {$order_id}" );
	}

	return $blocked;
}

add_filter( 'pys_disable_server_event_filter', __NAMESPACE__ . '\pys_block_server_event_without_consent', 10, 4 );
