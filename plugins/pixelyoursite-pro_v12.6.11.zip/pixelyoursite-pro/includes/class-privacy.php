<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Personal-data erasers and exporters for what PixelYourSite keeps on orders
 * and user accounts: the browser and click identifiers.
 */
class Privacy {

	/** Order meta that identifies a browser or a click. */
	const ORDER_KEYS = array(
		'pys_click_ids', 'pys_page_url', 'pys_page_referrer',
		'pys_fb_cookie', 'pys_tt_cookie', 'pys_oai_cookie', 'pys_pin_cookie', 'pys_ga_cookie',
		'external_id', 'pys_client_signals',
	);

	/** User meta kept by the plugin. */
	const USER_KEYS = array( 'pys_click_ids', 'pys_identity', 'pys_external_ids', 'external_id' );

	public static function init(): void {
		add_action( 'woocommerce_privacy_remove_order_personal_data', array( __CLASS__, 'eraseOrderData' ) );
		add_action( 'woocommerce_privacy_remove_subscription_personal_data', array( __CLASS__, 'eraseOrderData' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'registerEraser' ) );
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'registerExporter' ) );
	}

	/**
	 * @param \WC_Order|mixed $order
	 */
	public static function eraseOrderData( $order ): void {

		if ( !is_object( $order ) || !method_exists( $order, 'delete_meta_data' ) ) {
			return;
		}

		foreach ( self::ORDER_KEYS as $key ) {
			$order->delete_meta_data( $key );
		}

		$order->save();
	}

	public static function registerEraser( $erasers ) {
		$erasers[ 'pixelyoursite' ] = array(
			'eraser_friendly_name' => 'PixelYourSite',
			'callback'             => array( __CLASS__, 'eraseUserData' ),
		);

		return $erasers;
	}

	public static function registerExporter( $exporters ) {
		$exporters[ 'pixelyoursite' ] = array(
			'exporter_friendly_name' => 'PixelYourSite',
			'callback'               => array( __CLASS__, 'exportUserData' ),
		);

		return $exporters;
	}

	public static function eraseUserData( $email, $page = 1 ): array {

		$removed = false;
		$user    = get_user_by( 'email', $email );

		if ( $user ) {
			foreach ( self::USER_KEYS as $key ) {
				if ( metadata_exists( 'user', $user->ID, $key ) ) {
					delete_user_meta( $user->ID, $key );
					$removed = true;
				}
			}
		}

		return array(
			'items_removed'  => $removed,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);
	}

	public static function exportUserData( $email, $page = 1 ): array {

		$data = array();
		$user = get_user_by( 'email', $email );

		if ( $user ) {

			$labels = array(
				'pys_click_ids'    => __( 'Ad click ids', 'pys' ),
				'pys_identity'     => __( 'Browser identifiers', 'pys' ),
				'pys_external_ids' => __( 'External ids', 'pys' ),
				'external_id'      => __( 'External id', 'pys' ),
			);

			foreach ( self::USER_KEYS as $key ) {

				if ( !metadata_exists( 'user', $user->ID, $key ) ) {
					continue;
				}

				$value = get_user_meta( $user->ID, $key, true );

				$data[] = array(
					'group_id'    => 'pixelyoursite',
					'group_label' => 'PixelYourSite',
					'item_id'     => 'pixelyoursite-' . $key,
					'data'        => array(
						array(
							'name'  => $labels[ $key ],
							'value' => is_scalar( $value ) ? (string) $value : wp_json_encode( $value ),
						),
					),
				);
			}
		}

		return array( 'data' => $data, 'done' => true );
	}
}
