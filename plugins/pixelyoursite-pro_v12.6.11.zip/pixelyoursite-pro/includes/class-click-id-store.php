<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The pys_click_ids cookie: the ad click ids found on the landing URL, first
 * and last touch per id, kept for 90 days. Nothing is sent to any platform from
 * here; the cookie is only read back later (orders, users).
 *
 * Shape: { "gclid": { "first": { "v": "..", "t": 1700000000, "l": "https://shop/landing" },
 *                     "last":  { "v": "..", "t": 1700000500 } } }
 * v is the value as rawurlencode() would write it, l the landing page without
 * its query string. public.js writes the same shape (captureClickIds()).
 */
class ClickIdStore {

	/**
	 * Click id parameter => the consent key that governs it.
	 */
	const IDS = array(
		'gclid'    => 'google_ads',
		'gbraid'   => 'google_ads',
		'wbraid'   => 'google_ads',
		'msclkid'  => 'bing',
		'rdt_cid'  => 'reddit',
		'ScCid'    => 'click_ids',
		'li_fat_id' => 'click_ids',
		'twclid'   => 'click_ids',
		'dclid'    => 'click_ids',
		'fbclid'   => 'facebook',
	);

	const COOKIE        = 'pys_click_ids';
	const LIFETIME_DAYS = 90;
	const MAX_BYTES     = 3500;
	const MAX_VALUE_LEN = 255; // of the raw value, before encoding

	/**
	 * @param string $raw Cookie value (already URL-decoded, as PHP hands it over).
	 * @return array Entries of the known ids only; anything unusable gives [].
	 */
	public static function parseCookie( $raw ): array {

		if ( !is_string( $raw ) || '' === $raw ) {
			return array();
		}

		$data = json_decode( $raw, true );

		if ( !is_array( $data ) ) {
			return array();
		}

		$clean = array();

		foreach ( self::IDS as $id => $key ) {

			$entry = isset( $data[ $id ] ) && is_array( $data[ $id ] ) ? $data[ $id ] : null;

			if ( null === $entry ) {
				continue;
			}

			$first = self::cleanTouch( $entry[ 'first' ] ?? null, true );
			$last  = self::cleanTouch( $entry[ 'last' ] ?? null, false );

			if ( null === $first || null === $last ) {
				continue;
			}

			$clean[ $id ] = array( 'first' => $first, 'last' => $last );
		}

		return $clean;
	}

	/**
	 * @param mixed $touch
	 * @param bool  $with_landing
	 * @return array|null
	 */
	private static function cleanTouch( $touch, bool $with_landing ) {

		if ( !is_array( $touch ) || !isset( $touch[ 'v' ], $touch[ 't' ] ) || !is_string( $touch[ 'v' ] ) || '' === $touch[ 'v' ] || !is_numeric( $touch[ 't' ] ) ) {
			return null;
		}

		$out = array( 'v' => $touch[ 'v' ], 't' => (int) $touch[ 't' ] );

		if ( $with_landing && isset( $touch[ 'l' ] ) && is_string( $touch[ 'l' ] ) ) {
			$out[ 'l' ] = $touch[ 'l' ];
		}

		return $out;
	}

	/**
	 * @param array  $stored  parseCookie() result.
	 * @param array  $fromUrl id => raw (decoded) value from the landing URL.
	 * @param int    $now     Unix time.
	 * @param string $landing Scheme + host + path of the landing page, no query.
	 * @return array
	 */
	public static function merge( array $stored, array $fromUrl, int $now, string $landing ): array {

		foreach ( $fromUrl as $id => $value ) {

			if ( !isset( self::IDS[ $id ] ) || !is_scalar( $value ) || '' === (string) $value ) {
				continue;
			}

			$encoded = rawurlencode( substr( (string) $value, 0, self::MAX_VALUE_LEN ) );

			if ( isset( $stored[ $id ] ) ) {

				// Same click seen again (reload, or the JS writer after PHP): untouched.
				if ( $stored[ $id ][ 'last' ][ 'v' ] !== $encoded ) {
					$stored[ $id ][ 'last' ] = array( 'v' => $encoded, 't' => $now );
				}

				continue;
			}

			$stored[ $id ] = array(
				'first' => array( 'v' => $encoded, 't' => $now, 'l' => $landing ),
				'last'  => array( 'v' => $encoded, 't' => $now ),
			);
		}

		return self::shrink( $stored );
	}

	/**
	 * Keeps the serialized cookie within MAX_BYTES: landing pages go first,
	 * then the oldest "last" touches, then whole ids, oldest first.
	 */
	private static function shrink( array $store ): array {

		if ( self::size( $store ) <= self::MAX_BYTES ) {
			return $store;
		}

		foreach ( $store as $id => $entry ) {
			unset( $store[ $id ][ 'first' ][ 'l' ] );
		}

		while ( self::size( $store ) > self::MAX_BYTES ) {

			$oldest = null;

			foreach ( $store as $id => $entry ) {
				if ( $entry[ 'last' ] !== $entry[ 'first' ] && ( null === $oldest || $entry[ 'last' ][ 't' ] < $store[ $oldest ][ 'last' ][ 't' ] ) ) {
					$oldest = $id;
				}
			}

			if ( null === $oldest ) {
				break;
			}

			// The first touch doubles as the last one.
			$store[ $oldest ][ 'last' ] = array( 'v' => $store[ $oldest ][ 'first' ][ 'v' ], 't' => $store[ $oldest ][ 'first' ][ 't' ] );
		}

		while ( self::size( $store ) > self::MAX_BYTES && count( $store ) > 1 ) {

			$oldest = null;

			foreach ( $store as $id => $entry ) {
				if ( null === $oldest || $entry[ 'first' ][ 't' ] < $store[ $oldest ][ 'first' ][ 't' ] ) {
					$oldest = $id;
				}
			}

			unset( $store[ $oldest ] );
		}

		return $store;
	}

	private static function size( array $store ): int {
		// setcookie() sends the value through rawurlencode(): the cap is on that.
		return strlen( rawurlencode( self::encode( $store ) ) );
	}

	public static function encode( array $store ): string {
		// A broken UTF-8 byte in a landing URL must not make the whole store empty.
		return (string) json_encode( $store, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE );
	}

	/**
	 * Value of a query parameter the way public.js reads it: the first
	 * occurrence that has an "=", percent-decoded only ("+" stays a plus).
	 *
	 * @return string '' when absent.
	 */
	public static function queryParam( string $query, string $name ): string {

		foreach ( explode( '&', ltrim( $query, '?' ) ) as $pair ) {

			$parts = explode( '=', $pair, 2 );

			if ( $parts[ 0 ] === $name && isset( $parts[ 1 ] ) ) {
				return rawurldecode( $parts[ 1 ] );
			}
		}

		return '';
	}

	/**
	 * The first-request writer (opt-in click_ids_first_request): the ids on the
	 * landing URL go into the cookie in the first HTML response, for pages the
	 * JS writer reaches too late. Each id needs a real answer from the consent
	 * layer, not the "allowed until told otherwise" default.
	 */
	public static function captureFromRequest(): void {

		if ( !PYS()->getOption( 'click_ids_first_request' )
			|| !ServerEventHelper::isFrontEndPageRequest()
			|| !pys_may_write_cookies()
			|| pys_cookie_domain_cookies_disabled()
			|| apply_filters( 'pys_disable_click_ids_cookie', false )
		) {
			return;
		}

		$query = isset( $_SERVER[ 'QUERY_STRING' ] ) ? (string) $_SERVER[ 'QUERY_STRING' ] : '';

		if ( '' === $query ) {
			return;
		}

		$found = array();

		foreach ( self::IDS as $id => $key ) {

			$value = self::queryParam( $query, $id );

			if ( '' !== $value && Consent()->hasExplicitConsent( $key ) ) {
				$found[ $id ] = $value;
			}
		}

		if ( empty( $found ) ) {
			return;
		}

		$raw    = isset( $_COOKIE[ self::COOKIE ] ) ? wp_unslash( $_COOKIE[ self::COOKIE ] ) : '';
		$store  = self::merge( self::parseCookie( $raw ), $found, time(), self::landing() );
		$value  = self::encode( $store );

		// Never overwrite the stored ids with nothing.
		if ( '' === $value ) {
			return;
		}

		$expiry = time() + self::LIFETIME_DAYS * 86400;

		setcookie( self::COOKIE, $value, $expiry, '/', pys_cookie_domain() );
		// Readable within this request.
		$_COOKIE[ self::COOKIE ] = $value;
	}

	/**
	 * Keeps the ids whose consent key answers explicitly yes right now. The
	 * cookie was written under consent, but consent may have been withdrawn since.
	 */
	private static function filterByConsent( array $ids ): array {

		foreach ( $ids as $id => $entry ) {
			if ( !isset( self::IDS[ $id ] ) || !Consent()->hasExplicitConsent( self::IDS[ $id ] ) ) {
				unset( $ids[ $id ] );
			}
		}

		return $ids;
	}

	/**
	 * The visitor's click ids as the browser sent them, consent-checked now.
	 * [] when cookies are switched off, absent or unusable.
	 */
	public static function fromCookie(): array {

		if ( pys_cookie_domain_cookies_disabled() || empty( $_COOKIE[ self::COOKIE ] ) || !is_string( $_COOKIE[ self::COOKIE ] ) ) {
			return array();
		}

		return self::filterByConsent( self::parseCookie( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) );
	}

	/**
	 * Copies the cookie onto the order. The Woo caller saves the order itself.
	 *
	 * @param string          $type 'woo' | 'edd'
	 * @param \WC_Order|int   $order_or_id
	 */
	public static function saveInOrder( string $type, $order_or_id ): void {

		$ids = self::fromCookie();

		if ( empty( $ids ) ) {
			return;
		}

		if ( 'edd' === $type ) {
			if ( function_exists( 'edd_update_payment_meta' ) ) {
				edd_update_payment_meta( (int) $order_or_id, self::COOKIE, $ids );
			}
			return;
		}

		$order = is_object( $order_or_id ) ? $order_or_id : ( function_exists( 'wc_get_order' ) ? wc_get_order( $order_or_id ) : false );

		if ( $order ) {
			$order->update_meta_data( self::COOKIE, $ids );
		}
	}

	/**
	 * Fills the click ids an EDD payment is missing from the request's cookie,
	 * under the same per-id consent filter as saveInOrder(). Ids already on the
	 * payment are kept as they are.
	 *
	 * @param int $payment_id
	 */
	public static function fillInEddOrder( $payment_id ): void {

		$ids = self::fromCookie();

		if ( !empty( $ids ) ) {
			pys_edd_fill_snapshot( $payment_id, self::COOKIE, $ids );
		}
	}

	/**
	 * Shape guard for stored or caller-supplied ids: known ids only, each touch
	 * validated; an entry with one touch missing gets it from the other one
	 * (first = last, or last = first without a landing page); an entry with
	 * neither is dropped.
	 */
	public static function normalize( $ids ): array {

		if ( !is_array( $ids ) ) {
			return array();
		}

		$clean = array();

		foreach ( self::IDS as $id => $key ) {

			if ( !isset( $ids[ $id ] ) || !is_array( $ids[ $id ] ) ) {
				continue;
			}

			$first = self::cleanTouch( $ids[ $id ][ 'first' ] ?? null, true );
			$last  = self::cleanTouch( $ids[ $id ][ 'last' ] ?? null, false );

			if ( null === $first && null === $last ) {
				continue;
			}

			$clean[ $id ] = array(
				'first' => null !== $first ? $first : $last,
				'last'  => null !== $last ? $last : array( 'v' => $first[ 'v' ], 't' => $first[ 't' ] ),
			);
		}

		return $clean;
	}

	/**
	 * Adds click ids to the account: per id the oldest first touch and the
	 * newest last touch win.
	 */
	public static function mergeIntoUser( int $user_id, array $ids ): void {

		if ( $user_id < 1 || pys_cookie_domain_cookies_disabled() ) {
			return;
		}

		$ids = self::filterByConsent( self::normalize( $ids ) );

		if ( empty( $ids ) ) {
			return;
		}

		$stored = get_user_meta( $user_id, self::COOKIE, true );
		$stored = self::normalize( $stored );
		$merged = $stored;

		foreach ( $ids as $id => $entry ) {

			if ( !isset( $merged[ $id ] ) ) {
				$merged[ $id ] = $entry;
				continue;
			}

			if ( $entry[ 'first' ][ 't' ] < $merged[ $id ][ 'first' ][ 't' ] ) {
				$merged[ $id ][ 'first' ] = $entry[ 'first' ];
			}

			if ( $entry[ 'last' ][ 't' ] > $merged[ $id ][ 'last' ][ 't' ] ) {
				$merged[ $id ][ 'last' ] = $entry[ 'last' ];
			}
		}

		if ( $merged !== $stored ) {
			update_user_meta( $user_id, self::COOKIE, $merged );
		}
	}

	/**
	 * Rows for the admin order box: id, last-touch value shortened, and the
	 * first-touch landing path when known. Values are plain text, not escaped.
	 *
	 * @return array[] each { id, value, landing }
	 */
	public static function displayRows( array $ids ): array {

		$rows = array();

		foreach ( self::IDS as $id => $key ) {

			if ( empty( $ids[ $id ] ) || !is_array( $ids[ $id ] ) ) {
				continue;
			}

			$entry = $ids[ $id ];
			$touch = isset( $entry[ 'last' ][ 'v' ] ) ? $entry[ 'last' ] : ( $entry[ 'first' ] ?? null );

			if ( !is_array( $touch ) || !isset( $touch[ 'v' ] ) || !is_string( $touch[ 'v' ] ) || '' === $touch[ 'v' ] ) {
				continue;
			}

			$value = rawurldecode( $touch[ 'v' ] );

			if ( function_exists( 'mb_strlen' ) ? mb_strlen( $value ) > 12 : strlen( $value ) > 12 ) {
				$value = ( function_exists( 'mb_substr' ) ? mb_substr( $value, 0, 12 ) : substr( $value, 0, 12 ) ) . "\xE2\x80\xA6";
			}

			$landing = '';

			if ( isset( $entry[ 'first' ][ 'l' ] ) && is_string( $entry[ 'first' ][ 'l' ] ) ) {
				$path    = parse_url( $entry[ 'first' ][ 'l' ], PHP_URL_PATH );
				$landing = is_string( $path ) ? $path : '';
			}

			$rows[] = array( 'id' => $id, 'value' => $value, 'landing' => $landing );
		}

		return $rows;
	}

	/**
	 * Scheme + host + path of the current request, without the query string.
	 */
	private static function landing(): string {

		$host = isset( $_SERVER[ 'HTTP_HOST' ] ) ? preg_replace( '/[^A-Za-z0-9.\-:\[\]]/', '', (string) $_SERVER[ 'HTTP_HOST' ] ) : '';
		$path = isset( $_SERVER[ 'REQUEST_URI' ] ) ? (string) strtok( (string) $_SERVER[ 'REQUEST_URI' ], '?#' ) : '/';

		return pys_get_request_protocol() . $host . $path;
	}
}

/**
 * The click ids of an order, for display and for the code that reads them.
 * Kept next to ClickIdStore (and not in functions-order-context.php) because
 * the shape and its validation live there.
 *
 * Order: the order's own pys_click_ids; for Woo, Conversion Exporter's
 * _cnvex_gclid / _cnvex_gbraid / _cnvex_wbraid; then what OrderIdentity can
 * find (parent order of a CartFlows child). The filter has the last word.
 *
 * @param string $type     'woo' | 'edd'
 * @param int    $order_id
 * @return array { id: { first?: {v,t,l}, last: {v,t} } }
 */
function pys_order_click_ids( string $type, int $order_id ): array {

	$ids = array();
	$raw = '';

	if ( 'edd' === $type ) {
		$raw = pys_edd_order_meta( $order_id, ClickIdStore::COOKIE );
	} else {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;

		if ( $order ) {
			$raw = $order->get_meta( ClickIdStore::COOKIE, true );
		}
	}

	if ( is_array( $raw ) ) {
		$raw = wp_json_encode( $raw );
	}

	$ids = ClickIdStore::parseCookie( $raw );

	if ( empty( $ids ) && 'woo' === $type && !empty( $order ) ) {

		$date = $order->get_date_created();
		$time = $date && method_exists( $date, 'getTimestamp' ) ? (int) $date->getTimestamp() : 0;

		foreach ( array( 'gclid', 'gbraid', 'wbraid' ) as $id ) {

			$value = $order->get_meta( '_cnvex_' . $id, true );

			if ( is_string( $value ) && '' !== $value ) {
				$ids[ $id ] = array( 'last' => array( 'v' => rawurlencode( $value ), 't' => $time ) );
			}
		}
	}

	if ( empty( $ids ) ) {
		$found = OrderIdentity::get( $type, $order_id, 'click_ids' );
		$ids   = ClickIdStore::parseCookie( isset( $found[ 'value' ] ) ? $found[ 'value' ] : '' );
	}

	return (array) apply_filters( 'pys_order_click_ids', $ids, $type, $order_id );
}
