<?php
namespace PixelYourSite;

require_once __DIR__ . '/functions-wc-attribution.php';


class EnrichOrder {
    private static $_instance;

    public static function instance() {

        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function init() {
        //woo

        if(PYS()->getOption("woo_enabled_save_data_to_orders")) {
            // Regular checkout orders (classic shortcode checkout)
            add_action( 'woocommerce_new_order', array( $this, 'woo_save_checkout_fields_new_order' ), 10, 2 );
            add_action( 'woocommerce_checkout_order_processed', array( $this, 'woo_save_checkout_fields_processed' ), 10, 3 );

            // Block-based checkout (Store API)
            add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'woo_save_checkout_fields_block' ), 10, 1 );

            // WooCommerce writes its attribution meta at priority 10; fill the last visit after it.
            add_action( 'woocommerce_order_save_attribution_data', array( $this, 'woo_fill_last_visit_from_attribution' ), 20, 1 );

            // Subscription renewal orders (WooCommerce Subscriptions)
            add_filter( 'wcs_renewal_order_created', array( $this, 'woo_save_renewal_order_fields' ), 10, 2 );

            add_action( 'woocommerce_analytics_update_order_stats',array($this,'woo_update_analytics'));
        }

        // edd
        if(PYS()->getOption("edd_enabled_save_data_to_orders")) {
            add_filter('edd_payment_meta', array($this, 'edd_save_checkout_fields'),10,2);
        }
    }

    function woo_update_analytics($orderId, $update = false) {
        $order = wc_get_order( $orderId );
        if(!$order->meta_exists( 'pys_enrich_data_analytics' )) {
            $totals = getWooUserStat($orderId);
            if (empty($totals) || $totals['orders_count'] == 0) {
                $totals = array(
                    'orders_count' => 'Guest order',
                    'avg_order_value' => 'Guest order',
                    'ltv' => 'Guest order',
                );
            }
            if (isWooCommerceVersionGte('3.0.0')) {
                // WooCommerce >= 3.0
                if ($order) {
                    $order->update_meta_data("pys_enrich_data_analytics", $totals);
                    $order->save();
                }

            } else {
                // WooCommerce < 3.0
                update_post_meta($orderId, 'pys_enrich_data_analytics', $totals);
            }
        }
    }

    /**
     * Wrapper for the woocommerce_new_order hook
     */
    public function woo_save_checkout_fields_new_order( $order_id, $order = null ) {
        $this->save_pys_data_to_order( $order_id, $order );
    }
    /**
     * Wrapper for the woocommerce_checkout_order_processed hook
     */
    public function woo_save_checkout_fields_processed( $order_id, $posted_data = array(), $order = null ) {
        $this->save_pys_data_to_order( $order_id, $order );
    }
    /**
     * Save enrich data for classic checkout orders
     *
     * @param int $order_id Order ID
     * @param array $posted_data Posted checkout data
     * @param \WC_Order $order Order object
     */
    public function save_pys_data_to_order( $order_id, $order = null ) {
        if ( ! $order instanceof \WC_Order ) {
            $order = wc_get_order( $order_id );
        }

        if ( ! $order instanceof \WC_Order ) {
            return;
        }
        // PROTECTION AGAINST DOUBLE EXECUTION:
        // Check if our data already exists. If it does - interrupt execution.
        if ( ! empty( $order->get_meta( 'pys_enrich_data' ) ) ) {
            return;
        }
        $pysData = $this->sanitizePysData( $this->getPysData( false ) );
        $order->update_meta_data( 'pys_enrich_data', $pysData );
        $order->save();
        pys_fill_last_visit_from_wc_attribution( $order );
    }

    /**
     * Save enrich data for block-based checkout orders (Store API)
     *
     * @param \WC_Order $order Order object
     */
    public function woo_save_checkout_fields_block( $order ) {
        if ( ! $order instanceof \WC_Order ) {
            return;
        }

        $pysData = $this->sanitizePysData( $this->getPysData( false ) );
        $order->update_meta_data( 'pys_enrich_data', $pysData );
        $order->save();
        pys_fill_last_visit_from_wc_attribution( $order );
    }

    /**
     * @param \WC_Order $order
     */
    public function woo_fill_last_visit_from_attribution( $order ) {
        pys_fill_last_visit_from_wc_attribution( $order );
    }

    /**
     * Save enrich data for subscription renewal orders
     *
     * @param \WC_Order $renewal_order Renewal order object
     * @param \WC_Subscription $subscription Subscription object
     * @return \WC_Order
     */
    public function woo_save_renewal_order_fields( $renewal_order, $subscription ) {
        if ( ! $renewal_order instanceof \WC_Order ) {
            return $renewal_order;
        }

        $pysData = $this->sanitizePysData( $this->getPysData( true ) );
        $pysData = self::mergeRenewalPysData( $renewal_order->get_meta( 'pys_enrich_data', true ), $pysData );
        $renewal_order->update_meta_data( 'pys_enrich_data', $pysData );
        $renewal_order->save();

        return $renewal_order;
    }

    /**
     * WooCommerce Subscriptions copies the parent's pys_enrich_data onto the
     * renewal. Its first-visit fields describe the customer and stay; only the
     * last_* keys describe this recurring payment.
     *
     * @param mixed $existing  The renewal's copied pys_enrich_data, if any.
     * @param array $recurring Fresh renewal data.
     * @return array
     */
    public static function mergeRenewalPysData( $existing, $recurring ) {
        if ( ! is_array( $existing ) || ! $existing ) {
            return $recurring;
        }
        foreach ( array( 'last_pys_landing', 'last_pys_source', 'last_pys_utm', 'last_pys_utm_id' ) as $key ) {
            if ( array_key_exists( $key, $recurring ) ) {
                $existing[ $key ] = $recurring[ $key ];
            }
        }
        // The copied WooCommerce-attribution marker belongs to the parent's last visit.
        unset( $existing['last_pys_source_origin'] );
        return $existing;
    }

    function edd_save_checkout_fields( $payment_meta, $init_payment_data ) {
        $edd_subscription = $init_payment_data['status'] == 'edd_subscription';

        if ( 0 !== did_action( 'edd_pre_process_purchase' ) || $edd_subscription ) {
            $pysData = $this->sanitizePysData($this->getPysData( $edd_subscription ));

            $totals = $this->getEddCustomerTotalsData( $payment_meta['email'] );

            $pysData = array_merge( $pysData, $totals );
            $payment_meta['pys_enrich_data'] = $pysData;
        }

        return $payment_meta;
    }

    /**
     * Get EDD customer totals data
     *
     * @param string $email Customer email
     * @return array
     */
    private function getEddCustomerTotalsData( $email ) {
        $totals = array();

        if ( PYS()->getOption( 'edd_enabled_save_data_to_orders' ) ) {
            if ( get_current_user_id() ) {
                $totals = getEddCustomerTotals();
            } else {
                $totals = getEddCustomerTotalsByEmail( $email );
            }
        }

        if ( empty( $totals['orders_count'] ) ) {
            $totals = array(
                'orders_count'    => 'Guest order',
                'avg_order_value' => 'Guest order',
                'ltv'             => 'Guest order',
            );
        }

        return $totals;
    }

    /**
     * Save subscription meta for recurring payments
     * @param $payment_id
     * @return void
     */
    function edd_save_subscription_meta( $payment_id ) {

        $payment_meta = edd_get_payment_meta( $payment_id );

        $pysData = $this->sanitizePysData($this->getPysData( true ));

        $totals = $this->getEddCustomerTotalsData( $payment_meta['email'] );

        $pysData = array_merge( $pysData, $totals );
        $payment_meta[ 'pys_enrich_data' ] = $pysData;
        edd_update_payment_meta( $payment_id, '_edd_payment_meta', $payment_meta );
    }


    private function sanitizePysData($data) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = wp_kses($value, []);
            }
        }
        return $data;
    }

    /**
     * Get PYS enrichment data for order
     *
     * @param bool $renewal_order Whether this is a renewal/subscription order
     * @return array Enrichment data array
     */
    function getPysData( $renewal_order = false ) {
        $utms = getUtms( true );
        $utms_id = getUtmsId( true );

        if ( $renewal_order ) {
            $pysData = $this->buildRenewalPysData( $utms, $utms_id );
        } else {
            $pysData = $this->buildRegularPysData( $utms, $utms_id );
        }

        $pysData['pys_browser_time'] = $this->getRequestValue( 'pys_browser_time', getBrowserTime() );
        return $pysData;
    }

    /**
     * Build PYS data for renewal/subscription orders
     *
     * @param array $utms UTM parameters
     * @param array $utms_id UTM ID parameters
     * @return array
     */
    private function buildRenewalPysData( $utms, $utms_id ) {
        $utms_recurring = $this->formatUtmsAsRecurring( $utms );
        $utms_id_recurring = $this->formatUtmsAsRecurring( $utms_id );

        return [
            'pys_landing'      => '',
            'pys_source'       => 'recurring payment',
            'pys_utm'          => $utms_recurring,
            'pys_utm_id'       => $utms_id_recurring,
            'last_pys_landing' => '',
            'last_pys_source'  => 'recurring payment',
            'last_pys_utm'     => $utms_recurring,
            'last_pys_utm_id'  => $utms_id_recurring,
        ];
    }

    /**
     * Build PYS data for regular orders
     *
     * @param array $utms UTM parameters (first visit)
     * @param array $utms_id UTM ID parameters (first visit)
     * @return array
     */
    private function buildRegularPysData( $utms, $utms_id ) {
        // First visit defaults
        $default_landing = $this->getDefaultLanding();
        $default_source = $this->getDefaultSource();
        $default_utm = $this->formatUtms( $utms );
        $default_utm_id = $this->formatUtms( $utms_id );

        // Last visit defaults
        $default_last_landing = $this->getDefaultLastLanding();
        $default_last_source = $this->getDefaultLastSource();
        $default_last_utm = $this->formatUtms( getUtms( true, true ) );
        $default_last_utm_id = $this->formatUtms( getUtmsId( true, true ) );

        return [
            'pys_landing'      => $this->getRequestValue( 'pys_landing', $default_landing, 'undefined' ),
            'pys_source'       => $this->getRequestValue( 'pys_source', $default_source, 'undefined' ),
            'pys_utm'          => $this->getRequestValue( 'pys_utm', $default_utm ),
            'pys_utm_id'       => $this->getRequestValue( 'pys_utm_id', $default_utm_id ),
            'last_pys_landing' => $this->getRequestValue( 'last_pys_landing', $default_last_landing, 'undefined' ),
            'last_pys_source'  => $this->getRequestValue( 'last_pys_source', $default_last_source, 'undefined' ),
            'last_pys_utm'     => $this->getRequestValue( 'last_pys_utm', $default_last_utm ),
            'last_pys_utm_id'  => $this->getRequestValue( 'last_pys_utm_id', $default_last_utm_id ),
        ];
    }

    /**
     * Get sanitized value from REQUEST or use fallback
     *
     * @param string $key Request key
     * @param mixed $fallback Fallback value
     * @param mixed $empty_fallback Value to use if fallback is empty
     * @return string
     */
    private function getRequestValue( $key, $fallback = '', $empty_fallback = null ) {
        if ( isset( $_REQUEST[ $key ] ) ) {
            return sanitize_text_field( $_REQUEST[ $key ] );
        }

        if ( $empty_fallback !== null && empty( $fallback ) ) {
            return $empty_fallback;
        }

        return $fallback ?? '';
    }

    /**
     * Get default landing page from session/cookie (first visit)
     *
     * @return string
     */
    private function getDefaultLanding() {
        $landingPage = $_SESSION['LandingPage'] ?? $_COOKIE['pys_landing_page'] ?? '';

        if ((empty($landingPage) || strpos($landingPage, 'undefined') === 0 || strpos($landingPage, 'http://undefined') === 0) && (defined( 'REST_REQUEST' ) && REST_REQUEST) ) {
            $landingPage = 'REST API';
        }

        return sanitize_text_field($landingPage);
    }

    /**
     * Get default traffic source from session/cookie (first visit)
     *
     * @return string
     */
    private function getDefaultSource() {
        $trafficSource = $_SESSION['TrafficSource'] ?? $_COOKIE['pysTrafficSource'] ?? '';
        if ((empty($trafficSource) || strpos($trafficSource, 'undefined') === 0) && (defined( 'REST_REQUEST' ) && REST_REQUEST) ) {
            $trafficSource = 'REST API';
        }

        return  sanitize_text_field($trafficSource);
    }

    /**
     * Get default last landing page from cookie (last visit)
     *
     * @return string
     */
    private function getDefaultLastLanding() {
        $lastLanding = $_COOKIE['last_pys_landing_page'] ?? $_SESSION['LandingPage'] ?? $_COOKIE['pys_landing_page'] ?? '';
        if ((empty($lastLanding) || strpos($lastLanding, 'undefined') === 0 || strpos($lastLanding, 'http://undefined') === 0) && (defined( 'REST_REQUEST' ) && REST_REQUEST) ) {
            $lastLanding = 'REST API';
        }

        return  sanitize_text_field($lastLanding);
    }

    /**
     * Get default last traffic source from cookie (last visit)
     *
     * @return string
     */
    private function getDefaultLastSource() {
        $lastSource = $_COOKIE['last_pysTrafficSource'] ?? $_SESSION['TrafficSource'] ?? $_COOKIE['pysTrafficSource'] ?? '';
        if ((empty($lastSource) || strpos($lastSource, 'undefined') === 0) && (defined( 'REST_REQUEST' ) && REST_REQUEST) ) {
            return 'REST API';
        }

        return sanitize_text_field($lastSource);
    }

    /**
     * Format UTMs array as pipe-separated string (key:value|key:value)
     *
     * @param array $utms UTM parameters
     * @return string
     */
    private function formatUtms( $utms ) {
        if ( empty( $utms ) ) {
            return '';
        }

        return implode( '|', array_map(
            function ( $key, $value ) { return "$key:$value"; },
            array_keys( $utms ),
            $utms
        ) );
    }

    /**
     * Format UTMs array as recurring payment string (key:recurring payment|...)
     *
     * @param array $utms UTM parameters
     * @return string
     */
    private function formatUtmsAsRecurring( $utms ) {
        if ( empty( $utms ) ) {
            return '';
        }

        return implode( '|', array_map(
            function ( $key ) { return "$key:recurring payment"; },
            array_keys( $utms )
        ) );
    }
}

/**
 * @return EnrichOrder
 */
function EnrichOrder() {
    return EnrichOrder::instance();
}

EnrichOrder();