<?php
/**
 * Purchase report of an order: which platforms received its Purchase and how.
 *
 * @package PixelYourSite
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Turns the delivery status the senders recorded (PurchaseDelivery::getOrderStatus())
 * into one row per platform and one verdict for the order.
 *
 * The rule: a platform received the Purchase when its tag fired on the
 * thank-you page, or its API accepted the server event, or both. A missing
 * channel is a detail of the row, never a failure.
 */
class PurchaseReport {

	const VERDICT_TRACKED      = 'tracked';
	const VERDICT_PARTLY       = 'partly';
	const VERDICT_NOT_TRACKED  = 'not_tracked';
	const VERDICT_WAITING      = 'waiting';
	const VERDICT_SKIPPED      = 'skipped';
	const VERDICT_NOT_PURCHASE = 'not_purchase';
	const VERDICT_UNKNOWN      = 'unknown';

	const STATE_SENT     = 'sent';
	const STATE_FAILED   = 'failed';
	const STATE_RETRY    = 'retry';
	const STATE_WAITING  = 'waiting';
	const STATE_SKIPPED  = 'skipped';
	const STATE_NOT_SENT = 'not_sent';
	const STATE_NOT_DUE  = 'not_due';

	const CHANNEL_TAG_AND_API      = 'tag_api';
	const CHANNEL_TAG              = 'tag';
	const CHANNEL_API              = 'api';
	const CHANNEL_API_ORDER_STATUS = 'api_order_status';
	const CHANNEL_NONE             = 'none';

	/** Platforms that can receive the Purchase through an API. */
	const API_PLATFORMS = array( 'facebook', 'ga', 'tiktok', 'openai', 'pinterest' );

	/** GA4 does not deduplicate: its Purchase goes out by the tag or by the API, never both. */
	const SINGLE_SOURCE_PLATFORMS = array( 'ga' );

	/** Server sends the per-order "ads" switch stops (see pys_order_purchase_blocked()). */
	const ADS_GROUP_PLATFORMS = array( 'facebook', 'tiktok', 'openai', 'pinterest' );

	/** A waiting order older than this needs a look. */
	const WAITING_ATTENTION_DAYS = 2;

	/**
	 * The purchase report of an order.
	 *
	 * @param string             $type        'woo' or 'edd'
	 * @param \WC_Order|int|null $order_or_id Woo order or id; EDD order id
	 * @return array{
	 *     type: string,
	 *     order_id: int,
	 *     verdict: string,
	 *     needs_attention: bool,
	 *     recorded: bool,
	 *     event_id: string,
	 *     order: array{status: string, total: float, currency: string, created: int, is_renewal: bool, is_refunded: bool, is_cancelled: bool},
	 *     platforms: array<string, array{label: string, pixels: string[], state: string, channel: string, note: string, message: string}>
	 * }|null Null when the order is unknown
	 */
	public static function forOrder( $type, $order_or_id ) {
		$order = self::orderFacts( $type, $order_or_id );
		if ( null === $order ) {
			return null;
		}

		$status = PurchaseDelivery::getOrderStatus( $type, 'woo' === $type ? $order['object'] : $order['id'] );
		if ( null === $status ) {
			return null;
		}

		return self::fromStatus( $type, $status, $order );
	}

	/**
	 * The report, from a delivery status and the facts of the order.
	 *
	 * @param string $type   'woo' or 'edd'
	 * @param array  $status PurchaseDelivery::getOrderStatus() value
	 * @param array  $order  orderFacts() value
	 * @return array See forOrder()
	 */
	public static function fromStatus( $type, array $status, array $order ) {
		$platforms = array();
		foreach ( self::platformsOfOrder( $type, $status, $order ) as $platform => $pixel_ids ) {
			$platforms[ $platform ] = self::platformRow( $type, $platform, $pixel_ids, $status, $order );
		}

		$verdict = self::verdict( $platforms, $status, $order );

		return array(
			'type'            => $type,
			'order_id'        => $order['id'],
			'verdict'         => $verdict,
			'needs_attention' => self::needsAttention( $verdict, $status, $order ),
			'recorded'        => $status['recorded'],
			'event_id'        => $status['event_id'],
			'order'           => array(
				'status'       => $order['status'],
				'total'        => $order['total'],
				'currency'     => $order['currency'],
				'created'      => $order['created'],
				'is_renewal'   => $order['is_renewal'],
				'is_refunded'  => $order['is_refunded'],
				'is_cancelled' => $order['is_cancelled'],
			),
			'platforms'       => $platforms,
		);
	}

	/**
	 * Platforms the report has a row for, with their pixel IDs.
	 *
	 * The delivery record names them. An order placed since the record started
	 * but never seen on the thank-you page is measured against the platforms
	 * that are switched on now. An older order gets rows only for the platforms
	 * it left a trace for: the platforms switched on now say nothing about it.
	 *
	 * @param string $type   'woo' or 'edd'
	 * @param array  $status PurchaseDelivery::getOrderStatus() value
	 * @param array  $order  orderFacts() value
	 * @return array<string, string[]>
	 */
	private static function platformsOfOrder( $type, array $status, array $order ) {
		$platforms = is_array( $status['tag']['platforms'] ) ? $status['tag']['platforms'] : array();

		foreach ( $status['api'] as $platform => $entry ) {
			$pixel_ids              = array_diff( array_map( 'strval', array_keys( $entry['pixels'] ) ), array( '*' ) );
			$known                  = isset( $platforms[ $platform ] ) ? $platforms[ $platform ] : array();
			$platforms[ $platform ] = array_values( array_unique( array_merge( $known, $pixel_ids ) ) );
		}
		foreach ( array_keys( $status['tag']['confirmed'] ) as $platform ) {
			if ( ! isset( $platforms[ $platform ] ) ) {
				$platforms[ $platform ] = array();
			}
		}

		if ( null === $status['tag']['platforms'] && $order['created'] >= self::recordingSince() ) {
			foreach ( PurchaseDelivery::tagPlatforms( $type ) as $platform => $pixel_ids ) {
				if ( ! isset( $platforms[ $platform ] ) || empty( $platforms[ $platform ] ) ) {
					$platforms[ $platform ] = $pixel_ids;
				}
			}
		}

		$ordered = array();
		foreach ( PurchaseDelivery::MARKER_PLATFORMS as $platform ) {
			if ( isset( $platforms[ $platform ] ) ) {
				$ordered[ $platform ] = $platforms[ $platform ];
			}
		}

		return $ordered;
	}

	/**
	 * One platform's row.
	 *
	 * @param string   $type      'woo' or 'edd'
	 * @param string   $platform  Pixel slug
	 * @param string[] $pixel_ids
	 * @param array    $status    PurchaseDelivery::getOrderStatus() value
	 * @param array    $order     orderFacts() value
	 * @return array{label: string, pixels: string[], state: string, channel: string, note: string, message: string}
	 */
	private static function platformRow( $type, $platform, array $pixel_ids, array $status, array $order ) {
		$row = array(
			'label'   => self::platformLabel( $platform ),
			'pixels'  => $pixel_ids,
			'state'   => self::STATE_NOT_SENT,
			'channel' => self::CHANNEL_NONE,
			'note'    => '',
			'message' => '',
		);

		$api           = self::apiSummary( isset( $status['api'][ $platform ] ) ? $status['api'][ $platform ]['pixels'] : array() );
		$api_delivered = in_array( $api['outcome'], array( PurchaseDelivery::OUTCOME_ACCEPTED, PurchaseDelivery::OUTCOME_UNCONFIRMED ), true );
		$tag_confirmed = isset( $status['tag']['confirmed'][ $platform ] );
		// A tag the buyer refused stays silent although the page was built.
		$tag_refused  = isset( $status['consent'][ $platform ] ) && PYS_CONSENT_DENIED === $status['consent'][ $platform ];
		$tag_expected = ! $tag_refused && ( null === $status['tag']['platforms'] || isset( $status['tag']['platforms'][ $platform ] ) );
		$tag_fired    = $tag_confirmed || ( $status['tag']['built'] && $tag_expected );

		// One source: once the API sent it, the thank-you page left the tag out.
		if ( in_array( $platform, self::SINGLE_SOURCE_PLATFORMS, true ) && $api_delivered && ! $tag_confirmed ) {
			$tag_fired = false;
		}

		if ( $tag_fired || $api_delivered ) {
			$row['state'] = self::STATE_SENT;
			if ( $tag_fired && $api_delivered ) {
				$row['channel'] = self::CHANNEL_TAG_AND_API;
			} elseif ( $tag_fired ) {
				$row['channel'] = self::CHANNEL_TAG;
			} else {
				$row['channel'] = PurchaseDelivery::SOURCE_ORDER_STATUS === $api['source'] ? self::CHANNEL_API_ORDER_STATUS : self::CHANNEL_API;
			}

			$row['note'] = self::sentNote( $type, $platform, $api, $tag_fired, $tag_confirmed, $status );
			// A full refund or a cancel clears the markers (the order may be placed again): no marker says nothing then.
			if ( 'tag_unconfirmed' === $row['note'] && ( $order['is_refunded'] || $order['is_cancelled'] ) ) {
				$row['note'] = '';
			}
			if ( in_array( $row['note'], array( 'api_rejected', 'pixel_rejected', 'api_retry' ), true ) ) {
				$row['message'] = PurchaseDelivery::redactMessage( $api['message'] );
			}

			return $row;
		}

		if ( PurchaseDelivery::OUTCOME_QUEUED === $api['outcome'] ) {
			$row['state'] = self::STATE_WAITING;
			$row['note']  = 'api_queued';

			return $row;
		}

		if ( PurchaseDelivery::OUTCOME_REJECTED === $api['outcome'] ) {
			$row['state']   = self::STATE_FAILED;
			$row['note']    = 'api_rejected';
			$row['message'] = PurchaseDelivery::redactMessage( $api['message'] );

			return $row;
		}

		if ( PurchaseDelivery::OUTCOME_RETRY === $api['outcome'] ) {
			$gave_up        = PurchaseDelivery::RUN_GAVE_UP === $status['run']['outcome'];
			$row['state']   = $gave_up ? self::STATE_FAILED : self::STATE_RETRY;
			$row['note']    = $gave_up ? 'retries_used' : 'api_retry';
			$row['message'] = PurchaseDelivery::redactMessage( $api['message'] );

			return $row;
		}

		return self::notSentRow( $row, $type, $platform, $api, $status, $order );
	}

	/**
	 * The detail of a row whose Purchase reached the platform.
	 *
	 * @param string $type          'woo' or 'edd'
	 * @param string $platform      Pixel slug
	 * @param array  $api           apiSummary() value
	 * @param bool   $tag_fired
	 * @param bool   $tag_confirmed
	 * @param array  $status        PurchaseDelivery::getOrderStatus() value
	 * @return string Note code, empty when there is nothing to add
	 */
	private static function sentNote( $type, $platform, array $api, $tag_fired, $tag_confirmed, array $status ) {
		if ( $api['rejected_pixels'] > 0 && $api['accepted_pixels'] > 0 ) {
			return 'pixel_rejected';
		}
		if ( PurchaseDelivery::OUTCOME_QUEUED === $api['outcome'] ) {
			return 'api_queued';
		}
		if ( PurchaseDelivery::OUTCOME_UNCONFIRMED === $api['outcome'] ) {
			return 'api_unconfirmed';
		}
		if ( ! $tag_fired ) {
			return '';
		}

		if ( PurchaseDelivery::OUTCOME_REJECTED === $api['outcome'] ) {
			return 'api_rejected';
		}
		if ( PurchaseDelivery::OUTCOME_RETRY === $api['outcome'] ) {
			return 'api_retry';
		}
		$api_expected = in_array( $platform, self::API_PLATFORMS, true ) && ! in_array( $platform, self::SINGLE_SOURCE_PLATFORMS, true );
		if ( '' === $api['outcome'] && $api_expected && ! self::isApiConfigured( $platform ) ) {
			return 'api_not_configured';
		}
		// No marker at all is no confirmation either, once the record exists to expect one.
		if ( ! $tag_confirmed && ( ! empty( $status['tag']['confirmed'] ) || $status['recorded'] ) && ! $status['tag']['waiting'] ) {
			return 'tag_unconfirmed';
		}

		return '';
	}

	/**
	 * A row whose Purchase did not reach the platform, and why.
	 *
	 * @param array  $row      Row so far
	 * @param string $type     'woo' or 'edd'
	 * @param string $platform Pixel slug
	 * @param array  $api      apiSummary() value
	 * @param array  $status   PurchaseDelivery::getOrderStatus() value
	 * @param array  $order    orderFacts() value
	 * @return array
	 */
	private static function notSentRow( array $row, $type, $platform, array $api, array $status, array $order ) {
		$has_api = in_array( $platform, self::API_PLATFORMS, true );

		if ( $order['is_not_purchase'] ) {
			$row['state'] = self::STATE_NOT_DUE;
			$row['note']  = 'not_purchase';

			return $row;
		}

		if ( $order['is_refunded'] ) {
			$row['state'] = self::STATE_NOT_DUE;
			$row['note']  = 'refunded';

			return $row;
		}

		if ( self::isRefusedByConsent( $platform, $status ) ) {
			$row['state'] = self::STATE_SKIPPED;
			$row['note']  = 'consent_denied';

			return $row;
		}

		if ( $has_api && self::isBlockedByOrderSwitch( $type, $platform, $order ) ) {
			$row['state'] = self::STATE_SKIPPED;
			$row['note']  = 'order_switch';

			return $row;
		}

		if ( PurchaseDelivery::RUN_SKIPPED === $status['run']['outcome'] && '' !== $status['run']['reason'] ) {
			$row['state'] = self::STATE_SKIPPED;
			$row['note']  = $status['run']['reason'];

			return $row;
		}

		// A late cron still runs the scheduled send: the event decides, the hour is for a lost one.
		$run_pending = in_array( $status['run']['outcome'], array( PurchaseDelivery::RUN_DEFERRED, PurchaseDelivery::RUN_RETRY_SCHEDULED ), true )
			&& ( $status['run']['next'] > time() - HOUR_IN_SECONDS
				|| wp_next_scheduled( ServerEventsManager::PURCHASE_FALLBACK_HOOK, array( $type, $order['id'] ) ) );
		if ( $status['tag']['waiting'] || ( $has_api && $run_pending ) ) {
			$row['state'] = self::STATE_WAITING;
			$row['note']  = 'in_progress';

			return $row;
		}

		if ( ! $has_api ) {
			$row['note'] = 'no_thank_you_page';

			return $row;
		}

		if ( PurchaseDelivery::OUTCOME_SKIPPED === $api['outcome'] || ! self::isApiConfigured( $platform ) ) {
			$row['note'] = 'api_not_configured';

			return $row;
		}

		if ( ! ServerEventsManager()->isOrderStatusSendEnabled( $type, $platform ) ) {
			$row['note'] = 'order_status_send_off';

			return $row;
		}

		if ( ! $order['status_sends_purchase'] ) {
			$row['state'] = self::STATE_WAITING;
			$row['note']  = 'status_not_reached';

			return $row;
		}

		$row['note'] = 'no_thank_you_page';

		return $row;
	}

	/**
	 * The best outcome among a platform's pixels.
	 *
	 * @param array $pixels array( pixel id => array( 'outcome', 'time', 'source', 'message' ) )
	 * @return array{outcome: string, source: string, message: string, accepted_pixels: int, rejected_pixels: int}
	 */
	private static function apiSummary( array $pixels ) {
		$rank    = array(
			PurchaseDelivery::OUTCOME_ACCEPTED    => 6,
			PurchaseDelivery::OUTCOME_QUEUED      => 5,
			PurchaseDelivery::OUTCOME_UNCONFIRMED => 4,
			PurchaseDelivery::OUTCOME_RETRY       => 3,
			PurchaseDelivery::OUTCOME_REJECTED    => 2,
			PurchaseDelivery::OUTCOME_SKIPPED     => 1,
		);
		$summary = array(
			'outcome'         => '',
			'source'          => '',
			'message'         => '',
			'accepted_pixels' => 0,
			'rejected_pixels' => 0,
		);
		$best    = 0;

		foreach ( $pixels as $pixel ) {
			$outcome = isset( $pixel['outcome'] ) ? (string) $pixel['outcome'] : '';
			if ( PurchaseDelivery::OUTCOME_ACCEPTED === $outcome ) {
				++$summary['accepted_pixels'];
			} elseif ( PurchaseDelivery::OUTCOME_REJECTED === $outcome ) {
				++$summary['rejected_pixels'];
			}

			if ( isset( $rank[ $outcome ] ) && $rank[ $outcome ] > $best ) {
				$best               = $rank[ $outcome ];
				$summary['outcome'] = $outcome;
				$summary['source']  = isset( $pixel['source'] ) ? (string) $pixel['source'] : '';
			}
			if ( in_array( $outcome, array( PurchaseDelivery::OUTCOME_REJECTED, PurchaseDelivery::OUTCOME_RETRY ), true ) && ! empty( $pixel['message'] ) ) {
				$summary['message'] = (string) $pixel['message'];
			}
		}

		return $summary;
	}

	/**
	 * The order's verdict, from its rows.
	 *
	 * @param array $platforms Rows by platform
	 * @param array $status    PurchaseDelivery::getOrderStatus() value
	 * @param array $order     orderFacts() value
	 * @return string One of the VERDICT_* constants
	 */
	private static function verdict( array $platforms, array $status, array $order ) {
		$counts = array_fill_keys(
			array( self::STATE_SENT, self::STATE_FAILED, self::STATE_RETRY, self::STATE_WAITING, self::STATE_SKIPPED, self::STATE_NOT_SENT, self::STATE_NOT_DUE ),
			0
		);
		foreach ( $platforms as $row ) {
			++$counts[ $row['state'] ];
		}

		$due = count( $platforms ) - $counts[ self::STATE_SKIPPED ] - $counts[ self::STATE_NOT_DUE ];

		if ( empty( $platforms ) ) {
			if ( $order['is_not_purchase'] ) {
				return self::VERDICT_NOT_PURCHASE;
			}

			// An order from before the record: the thank-you page printed the tags, which ones was not kept.
			return $status['tag']['built'] && ! $status['recorded'] ? self::VERDICT_TRACKED : self::VERDICT_UNKNOWN;
		}
		if ( 0 === $counts[ self::STATE_SENT ] && $order['is_not_purchase'] ) {
			return self::VERDICT_NOT_PURCHASE;
		}
		$open = $counts[ self::STATE_WAITING ] + $counts[ self::STATE_RETRY ];
		if ( $counts[ self::STATE_SENT ] > 0 ) {
			if ( $counts[ self::STATE_SENT ] === $due ) {
				return self::VERDICT_TRACKED;
			}

			// Only sends still on their way are missing: not settled yet.
			return $counts[ self::STATE_SENT ] + $open === $due ? self::VERDICT_WAITING : self::VERDICT_PARTLY;
		}
		if ( $open > 0 ) {
			return self::VERDICT_WAITING;
		}
		if ( 0 === $due ) {
			return self::VERDICT_SKIPPED;
		}

		return self::VERDICT_NOT_TRACKED;
	}

	/**
	 * Should the store owner look at this order?
	 *
	 * @param string $verdict One of the VERDICT_* constants
	 * @param array  $status  PurchaseDelivery::getOrderStatus() value
	 * @param array  $order   orderFacts() value
	 * @return bool
	 */
	private static function needsAttention( $verdict, array $status, array $order ) {
		// An order from before the delivery record is read from older flags: shown, never flagged.
		if ( ! $status['recorded'] ) {
			return false;
		}
		if ( in_array( $verdict, array( self::VERDICT_PARTLY, self::VERDICT_NOT_TRACKED ), true ) ) {
			return true;
		}

		return self::VERDICT_WAITING === $verdict && time() - $order['created'] > self::WAITING_ATTENTION_DAYS * DAY_IN_SECONDS;
	}

	/**
	 * What the report needs to know about the order itself.
	 *
	 * @param string             $type        'woo' or 'edd'
	 * @param \WC_Order|int|null $order_or_id
	 * @return array{object: mixed, id: int, status: string, total: float, currency: string, created: int, is_renewal: bool, is_refunded: bool, is_cancelled: bool, is_not_purchase: bool, status_sends_purchase: bool}|null
	 */
	private static function orderFacts( $type, $order_or_id ) {
		if ( 'woo' === $type ) {
			$order = is_object( $order_or_id ) ? $order_or_id : ( function_exists( 'wc_get_order' ) ? wc_get_order( (int) $order_or_id ) : null );
			if ( ! $order || ! method_exists( $order, 'get_status' ) || ! method_exists( $order, 'get_order_key' ) ) {
				return null;
			}

			$status     = (string) $order->get_status();
			$created    = $order->get_date_created();
			$statuses   = array_map(
				function ( $name ) {
					return str_replace( 'wc-', '', (string) $name );
				},
				(array) PYS()->getOption( 'woo_order_advanced_purchase_status' )
			);
			$is_renewal = '' !== pys_order_renewal_type( 'woo', (int) $order->get_id() )
				|| ( function_exists( 'wcs_order_contains_renewal' ) && wcs_order_contains_renewal( $order ) );

			return array(
				'object'                => $order,
				'id'                    => (int) $order->get_id(),
				'status'                => $status,
				'total'                 => (float) $order->get_total(),
				'currency'              => (string) $order->get_currency(),
				'created'               => $created ? (int) $created->getTimestamp() : 0,
				'is_renewal'            => $is_renewal,
				'is_refunded'           => 'refunded' === $status,
				'is_cancelled'          => 'cancelled' === $status,
				'is_not_purchase'       => in_array( $status, array( 'cancelled', 'failed', 'pending', 'checkout-draft' ), true ),
				'status_sends_purchase' => in_array( $status, $statuses, true ),
			);
		}

		if ( 'edd' !== $type || ! function_exists( 'edd_get_order' ) ) {
			return null;
		}

		$order = is_object( $order_or_id ) ? $order_or_id : edd_get_order( (int) $order_or_id );
		if ( ! $order || empty( $order->id ) || 'sale' !== $order->type ) {
			return null;
		}

		$status = (string) $order->status;

		return array(
			'object'                => $order,
			'id'                    => (int) $order->id,
			'status'                => $status,
			'total'                 => (float) $order->total,
			'currency'              => (string) $order->currency,
			'created'               => (int) strtotime( $order->date_created . ' UTC' ),
			// EDD Recurring files a renewal under the order that started the subscription.
			'is_renewal'            => '' !== pys_order_renewal_type( 'edd', (int) $order->id ) || 'edd_subscription' === $status || ! empty( $order->parent ),
			'is_refunded'           => in_array( $status, array( 'refunded', 'partially_refunded' ), true ),
			'is_cancelled'          => in_array( $status, array( 'revoked', 'cancelled' ), true ),
			'is_not_purchase'       => in_array( $status, array( 'abandoned', 'failed', 'revoked', 'cancelled' ), true ),
			'status_sends_purchase' => in_array( $status, array( 'complete', 'edd_subscription' ), true ),
		);
	}

	/**
	 * Did the buyer's consent at checkout keep this platform out?
	 *
	 * Denied stops the tag and the server send. GA4 in Consent Mode
	 * (restricted) gets no Measurement Protocol copy either, so with no tag
	 * confirmed nothing reached it because of consent.
	 *
	 * @param string $platform Pixel slug
	 * @param array  $status   PurchaseDelivery::getOrderStatus() value
	 * @return bool
	 */
	private static function isRefusedByConsent( $platform, array $status ) {
		$state = isset( $status['consent'][ $platform ] ) ? $status['consent'][ $platform ] : '';

		return PYS_CONSENT_DENIED === $state || ( 'ga' === $platform && PYS_CONSENT_RESTRICTED === $state );
	}

	/**
	 * Is the server send of this platform stopped by the order's own switch?
	 *
	 * @param string $type     'woo' or 'edd'
	 * @param string $platform Pixel slug
	 * @param array  $order    orderFacts() value
	 * @return bool
	 */
	private static function isBlockedByOrderSwitch( $type, $platform, array $order ) {
		if ( 'ga' === $platform ) {
			$group = 'ga';
		} elseif ( in_array( $platform, self::ADS_GROUP_PLATFORMS, true ) ) {
			$group = 'ads';
		} else {
			return false;
		}

		return pys_order_purchase_block_stored( $type, 'woo' === $type ? $order['object'] : $order['id'], $group );
	}

	/**
	 * Can the platform's API be used with the current settings?
	 *
	 * @param string $platform Pixel slug
	 * @return bool
	 */
	public static function isApiConfigured( $platform ) {
		$pixel = PYS()->getRegisteredPixel( $platform );

		return $pixel && method_exists( $pixel, 'isServerApiEnabled' ) && $pixel->isServerApiEnabled();
	}

	/**
	 * When the delivery record started on this site. An older order without
	 * any trace of a Purchase is unknown, not lost.
	 *
	 * @return int Timestamp
	 */
	public static function recordingSince() {
		$since = (int) PurchaseReportState::get( 'recording_since' );
		if ( $since <= 0 ) {
			$since = time();
			PurchaseReportState::set( array( 'recording_since' => $since ) );
		}

		return $since;
	}

	/**
	 * Display name of a platform.
	 *
	 * @param string $platform Pixel slug
	 * @return string
	 */
	public static function platformLabel( $platform ) {
		$labels = array(
			'facebook'   => 'Meta',
			'ga'         => 'GA4',
			'google_ads' => 'Google Ads',
			'tiktok'     => 'TikTok',
			'pinterest'  => 'Pinterest',
			'openai'     => 'OpenAI',
			'bing'       => 'Bing',
			'reddit'     => 'Reddit',
		);

		return isset( $labels[ $platform ] ) ? $labels[ $platform ] : $platform;
	}

	/**
	 * Display name of a verdict.
	 *
	 * @param string $verdict One of the VERDICT_* constants
	 * @return string
	 */
	public static function verdictLabel( $verdict ) {
		$labels = array(
			self::VERDICT_TRACKED      => __( 'Tracked', 'pys' ),
			self::VERDICT_PARTLY       => __( 'Partly tracked', 'pys' ),
			self::VERDICT_NOT_TRACKED  => __( 'Not tracked', 'pys' ),
			self::VERDICT_WAITING      => __( 'Waiting', 'pys' ),
			self::VERDICT_SKIPPED      => __( 'Blocked', 'pys' ),
			self::VERDICT_NOT_PURCHASE => __( 'Not a purchase', 'pys' ),
			self::VERDICT_UNKNOWN      => __( 'No record', 'pys' ),
		);

		return isset( $labels[ $verdict ] ) ? $labels[ $verdict ] : $verdict;
	}

	/**
	 * Display name of a row state.
	 *
	 * @param string $state One of the STATE_* constants
	 * @return string
	 */
	public static function stateLabel( $state ) {
		$labels = array(
			self::STATE_SENT     => __( 'Sent', 'pys' ),
			self::STATE_FAILED   => __( 'Failed', 'pys' ),
			self::STATE_RETRY    => __( 'Retry', 'pys' ),
			self::STATE_WAITING  => __( 'Waiting', 'pys' ),
			self::STATE_SKIPPED  => __( 'Blocked', 'pys' ),
			self::STATE_NOT_SENT => __( 'Not sent', 'pys' ),
			self::STATE_NOT_DUE  => __( 'Not sent', 'pys' ),
		);

		return isset( $labels[ $state ] ) ? $labels[ $state ] : $state;
	}

	/**
	 * What the platform calls its server channel: GA4 has the Measurement
	 * Protocol, the others an API.
	 *
	 * @param string $platform Pixel slug
	 * @return string
	 */
	public static function serverChannelName( $platform ) {
		return 'ga' === $platform ? __( 'Measurement Protocol', 'pys' ) : __( 'API', 'pys' );
	}

	/**
	 * Display name of the channel a Purchase was sent by.
	 *
	 * @param string $channel  One of the CHANNEL_* constants
	 * @param string $platform Pixel slug; GA4 reads "MP" where the others read "API"
	 * @return string
	 */
	public static function channelLabel( $channel, $platform = '' ) {
		if ( 'ga' === $platform ) {
			$labels = array(
				self::CHANNEL_TAG_AND_API      => __( 'Pixel/MP', 'pys' ),
				self::CHANNEL_TAG              => __( 'Pixel', 'pys' ),
				self::CHANNEL_API              => __( 'MP', 'pys' ),
				self::CHANNEL_API_ORDER_STATUS => __( 'MP by APT', 'pys' ),
				self::CHANNEL_NONE             => "\xE2\x80\x94",
			);
		} else {
			$labels = array(
				self::CHANNEL_TAG_AND_API      => __( 'Pixel/API', 'pys' ),
				self::CHANNEL_TAG              => __( 'Pixel', 'pys' ),
				self::CHANNEL_API              => __( 'API', 'pys' ),
				self::CHANNEL_API_ORDER_STATUS => __( 'API by APT', 'pys' ),
				self::CHANNEL_NONE             => "\xE2\x80\x94",
			);
		}

		return isset( $labels[ $channel ] ) ? $labels[ $channel ] : $channel;
	}

	/**
	 * The sentence fragment that explains a row's note.
	 *
	 * @param string $note     Note code of a row
	 * @param string $type     'woo' or 'edd'
	 * @param string $platform Pixel slug, for the name of its server channel
	 * @return string Empty for an unknown or empty code
	 */
	public static function noteLabel( $note, $type = 'woo', $platform = '' ) {
		$server = self::serverChannelName( $platform );
		$labels = array(
			/* translators: %s: "API" or "Measurement Protocol" */
			'api_rejected'          => sprintf( __( 'the %s rejected the event', 'pys' ), $server ),
			/* translators: %s: "API" or "Measurement Protocol" */
			'pixel_rejected'        => sprintf( __( 'one pixel was rejected by the %s', 'pys' ), $server ),
			/* translators: %s: "API" or "Measurement Protocol" */
			'api_retry'             => sprintf( __( 'the %s send failed and will be retried', 'pys' ), $server ),
			/* translators: %s: "API" or "Measurement Protocol" */
			'retries_used'          => sprintf( __( 'the %s did not accept the event after every retry', 'pys' ), $server ),
			'api_queued'            => __( 'handed to the events queue', 'pys' ),
			/* translators: %s: "API" or "Measurement Protocol" */
			'api_unconfirmed'       => sprintf( __( 'sent by the %s; the add-on does not report the answer', 'pys' ), $server ),
			/* translators: %s: "API" or "Measurement Protocol" */
			'api_not_configured'    => sprintf( __( 'the %s is not configured', 'pys' ), $server ),
			'tag_unconfirmed'       => __( 'sent from the thank-you page; the browser did not confirm this tag', 'pys' ),
			'order_switch'          => __( 'stopped for this order by its Purchase switch', 'pys' ),
			'consent_denied'        => __( 'the buyer did not give consent', 'pys' ),
			'user_role'             => __( 'tracking is disabled for the customer\'s user role', 'pys' ),
			'renewal'               => __( 'renewals are excluded in the settings', 'pys' ),
			'purchase_disabled'     => __( 'the Purchase event is disabled', 'pys' ),
			'no_event'              => __( 'the order has no items to send', 'pys' ),
			'in_progress'           => __( 'the send is in progress', 'pys' ),
			'no_thank_you_page'     => __( 'no thank-you page', 'pys' ),
			'order_status_send_off' => __( 'Advanced Purchase Tracking is off for this platform', 'pys' ),
			'not_purchase'          => __( 'the order is not a purchase', 'pys' ),
			'refunded'              => __( 'the order was refunded', 'pys' ),
		);

		if ( 'status_not_reached' === $note ) {
			return sprintf(
				/* translators: 1: "API" or "Measurement Protocol", 2: order status names, e.g. "Processing or Completed" */
				__( 'the %1$s Purchase is sent when the order reaches %2$s', 'pys' ),
				$server,
				self::purchaseStatusNames( $type )
			);
		}

		return isset( $labels[ $note ] ) ? $labels[ $note ] : '';
	}

	/**
	 * Names of the order statuses that send the API Purchase.
	 *
	 * @param string $type 'woo' or 'edd'
	 * @return string e.g. "Processing or Completed"
	 */
	public static function purchaseStatusNames( $type ) {
		if ( 'edd' === $type ) {
			return __( 'Completed', 'pys' );
		}

		$names    = array();
		$statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
		foreach ( (array) PYS()->getOption( 'woo_order_advanced_purchase_status' ) as $status ) {
			$names[] = isset( $statuses[ $status ] ) ? $statuses[ $status ] : ucfirst( str_replace( 'wc-', '', (string) $status ) );
		}

		if ( count( $names ) < 2 ) {
			return implode( '', $names );
		}
		$last = array_pop( $names );

		/* translators: 1: comma-separated list of order statuses, 2: the last status */
		return sprintf( __( '%1$s or %2$s', 'pys' ), implode( ', ', $names ), $last );
	}

	/**
	 * One sentence that says what happened to the order's Purchase.
	 *
	 * @param array $report forOrder() value
	 * @return string
	 */
	public static function summarySentence( array $report ) {
		$sent    = array();
		$missing = array();
		foreach ( $report['platforms'] as $platform => $row ) {
			if ( self::STATE_SENT === $row['state'] ) {
				$sent[] = $row['label'];
			} elseif ( ! in_array( $row['state'], array( self::STATE_SKIPPED, self::STATE_NOT_DUE ), true ) ) {
				$note      = self::noteLabel( $row['note'], $report['type'], $platform );
				$missing[] = '' !== $note ? sprintf( '%1$s (%2$s)', $row['label'], $note ) : $row['label'];
			}
		}

		switch ( $report['verdict'] ) {
			case self::VERDICT_TRACKED:
				if ( empty( $sent ) ) {
					return __( 'The thank-you page sent the Purchase tags. Which platforms got them was not recorded for orders this old.', 'pys' );
				}

				/* translators: %s: list of platforms, e.g. "Meta, GA4 and TikTok" */
				return sprintf( __( 'PixelYourSite sent this Purchase to %s.', 'pys' ), self::joinList( $sent ) );
			case self::VERDICT_PARTLY:
				/* translators: 1: platforms that received the Purchase, 2: platforms that did not, with the reason */
				return sprintf( __( 'PixelYourSite sent this Purchase to %1$s. Not sent: %2$s.', 'pys' ), self::joinList( $sent ), self::joinList( $missing ) );
			case self::VERDICT_WAITING:
				if ( ! empty( $sent ) ) {
					/* translators: 1: platforms that received the Purchase, 2: platforms still in progress, with the reason */
					return sprintf( __( 'PixelYourSite sent this Purchase to %1$s. Still in progress: %2$s.', 'pys' ), self::joinList( $sent ), self::joinList( $missing ) );
				}

				/* translators: %s: platforms with the reason */
				return sprintf( __( 'PixelYourSite has not sent this Purchase yet: %s.', 'pys' ), self::joinList( $missing ) );
			case self::VERDICT_SKIPPED:
				$row    = reset( $report['platforms'] );
				$reason = $row ? self::noteLabel( $row['note'], $report['type'], (string) key( $report['platforms'] ) ) : '';

				/* translators: %s: reason, e.g. "renewals are excluded in the settings" */
				return sprintf( __( 'PixelYourSite did not send this Purchase: %s.', 'pys' ), $reason );
			case self::VERDICT_NOT_PURCHASE:
				return __( 'This order is not a purchase: nothing was sent.', 'pys' );
			case self::VERDICT_UNKNOWN:
				return __( 'This order was placed before PixelYourSite kept a delivery record, and it left no trace of a Purchase.', 'pys' );
			default:
				/* translators: %s: platforms with the reason */
				return sprintf( __( 'PixelYourSite did not send this Purchase: %s.', 'pys' ), self::joinList( $missing ) );
		}
	}

	/**
	 * Join items into a readable list.
	 *
	 * @param string[] $items
	 * @return string "a", "a and b", "a, b and c"
	 */
	public static function joinList( array $items ) {
		$items = array_values( array_filter( $items ) );
		if ( count( $items ) < 2 ) {
			return implode( '', $items );
		}
		$last = array_pop( $items );

		/* translators: 1: comma-separated list, 2: the last item */
		return sprintf( __( '%1$s and %2$s', 'pys' ), implode( ', ', $items ), $last );
	}
}
