<?php
/**
 * Numbers about a set of orders, from the cache rows of the purchase report.
 *
 * @package PixelYourSite
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Counts for the summary box of the orders list, the dashboard widget and
 * the summary email. Nothing is estimated: an amount is given only when every
 * order shares one currency.
 */
class PurchaseReportSummary {

	/**
	 * The summary of a period of a store.
	 *
	 * @param string $type 'woo' or 'edd'
	 * @param int    $from Timestamp, inclusive
	 * @param int    $to   Timestamp, exclusive
	 * @return array See fromRows()
	 */
	public static function forPeriod( $type, $from, $to ) {
		return self::fromRows( PurchaseReportCache::rows( $type, $from, $to ) );
	}

	/**
	 * Counts over a set of orders, for the widget, the list box and the summary email.
	 *
	 * @param array $rows PurchaseReportCache::rows() value
	 * @return array{
	 *     total: int,
	 *     tracked: int,
	 *     attention: int,
	 *     by_verdict: array<string, int>,
	 *     not_counted: int,
	 *     currency: string|null,
	 *     value_total: float|null,
	 *     value_tracked: float|null,
	 *     platforms: array<string, array{label: string, sent: int, tag: int, api: int, api_order_status: int, failed: int, api_not_configured: int, not_sent: int}>,
	 *     activity: array{pixel: int, pixel_and_api: int, order_status: int, order_status_value: float|null, renewals: int, api_only: int},
	 *     ad_clicks: array{orders: int, by_platform: array<string, int>},
	 *     skipped_by: array<string, int>
	 * }
	 */
	public static function fromRows( array $rows ) {
		$summary = array(
			'total'         => 0,
			'tracked'       => 0,
			'attention'     => 0,
			'by_verdict'    => array_fill_keys(
				array(
					PurchaseReport::VERDICT_TRACKED,
					PurchaseReport::VERDICT_PARTLY,
					PurchaseReport::VERDICT_NOT_TRACKED,
					PurchaseReport::VERDICT_WAITING,
					PurchaseReport::VERDICT_SKIPPED,
				),
				0
			),
			'not_counted'   => 0,
			'currency'      => null,
			'value_total'   => 0.0,
			'value_tracked' => 0.0,
			'platforms'     => array(),
			// Orders by the way their Purchase went out. Every tracked or partly
			// tracked order is in 'pixel' or in one of the three API-only counts.
			'activity'      => array(
				'pixel'              => 0,
				'pixel_and_api'      => 0,
				'order_status'       => 0,
				'order_status_value' => 0.0,
				'renewals'           => 0,
				'api_only'           => 0,
			),
			'ad_clicks'     => array(
				'orders'      => 0,
				'by_platform' => array(),
			),
			'skipped_by'    => array(),
		);
		$currencies = array();

		foreach ( $rows as $row ) {
			// Cancelled or failed orders, and orders older than the delivery record, are not purchases to count.
			if ( ! isset( $summary['by_verdict'][ $row['verdict'] ] ) ) {
				++$summary['not_counted'];
				continue;
			}

			++$summary['total'];
			++$summary['by_verdict'][ $row['verdict'] ];
			$summary['value_total'] += $row['total'];
			if ( '' !== $row['currency'] ) {
				$currencies[ $row['currency'] ] = true;
			}
			if ( PurchaseReport::VERDICT_TRACKED === $row['verdict'] ) {
				++$summary['tracked'];
				$summary['value_tracked'] += $row['total'];
			}
			if ( $row['attention'] ) {
				++$summary['attention'];
			}

			$by_order_status = false;
			$by_tag          = false;
			$by_api          = false;
			$by_both         = false;
			foreach ( $row['platforms'] as $platform => $cell ) {
				list( $state, $channel, $note ) = array_pad( (array) $cell, 3, '' );

				if ( ! isset( $summary['platforms'][ $platform ] ) ) {
					$summary['platforms'][ $platform ] = array(
						'label'              => PurchaseReport::platformLabel( $platform ),
						'sent'               => 0,
						'tag'                => 0,
						'api'                => 0,
						'api_order_status'   => 0,
						'failed'             => 0,
						'api_not_configured' => 0,
						'not_sent'           => 0,
					);
				}
				$counts = &$summary['platforms'][ $platform ];

				if ( PurchaseReport::STATE_SENT === $state ) {
					++$counts['sent'];
				}
				if ( in_array( $channel, array( PurchaseReport::CHANNEL_TAG, PurchaseReport::CHANNEL_TAG_AND_API ), true ) ) {
					++$counts['tag'];
					$by_tag = true;
				}
				if ( PurchaseReport::CHANNEL_TAG_AND_API === $channel ) {
					$by_both = true;
				}
				if ( in_array( $channel, array( PurchaseReport::CHANNEL_API, PurchaseReport::CHANNEL_TAG_AND_API, PurchaseReport::CHANNEL_API_ORDER_STATUS ), true ) ) {
					++$counts['api'];
					$by_api = true;
				}
				if ( PurchaseReport::CHANNEL_API_ORDER_STATUS === $channel ) {
					++$counts['api_order_status'];
					$by_order_status = true;
				}
				if ( PurchaseReport::STATE_FAILED === $state || in_array( $note, array( 'api_rejected', 'pixel_rejected', 'retries_used' ), true ) ) {
					++$counts['failed'];
				}
				if ( 'api_not_configured' === $note && PurchaseReport::STATE_SENT === $state ) {
					++$counts['api_not_configured'];
				}
				if ( PurchaseReport::STATE_NOT_SENT === $state ) {
					++$counts['not_sent'];
				}
				if ( PurchaseReport::STATE_SKIPPED === $state && PurchaseReport::VERDICT_SKIPPED === $row['verdict'] ) {
					$skipped_note = $note;
				}
				unset( $counts );
			}

			if ( PurchaseReport::VERDICT_SKIPPED === $row['verdict'] ) {
				$reason                           = isset( $skipped_note ) && '' !== $skipped_note ? $skipped_note : 'order_switch';
				$summary['skipped_by'][ $reason ] = isset( $summary['skipped_by'][ $reason ] ) ? $summary['skipped_by'][ $reason ] + 1 : 1;
			}
			unset( $skipped_note );

			if ( $by_tag ) {
				++$summary['activity']['pixel'];
				// One platform by the pixel and another by the API is both, too.
				if ( $by_both || $by_api ) {
					++$summary['activity']['pixel_and_api'];
				}
			} elseif ( $by_api && $row['renewal'] ) {
				// A renewal has no thank-you page: the API is its only way.
				++$summary['activity']['renewals'];
			} elseif ( $by_order_status ) {
				++$summary['activity']['order_status'];
				$summary['activity']['order_status_value'] += $row['total'];
			} elseif ( $by_api ) {
				++$summary['activity']['api_only'];
			}

			if ( ! empty( $row['ad_click'] ) ) {
				++$summary['ad_clicks']['orders'];
				foreach ( $row['ad_click'] as $name ) {
					if ( ! isset( $summary['ad_clicks']['by_platform'][ $name ] ) ) {
						$summary['ad_clicks']['by_platform'][ $name ] = 0;
					}
					++$summary['ad_clicks']['by_platform'][ $name ];
				}
			}
		}

		if ( 1 === count( $currencies ) ) {
			$summary['currency'] = (string) key( $currencies );
		} else {
			$summary['value_total']                    = null;
			$summary['value_tracked']                  = null;
			$summary['activity']['order_status_value'] = null;
		}

		$ordered = array();
		foreach ( PurchaseDelivery::MARKER_PLATFORMS as $platform ) {
			if ( isset( $summary['platforms'][ $platform ] ) ) {
				$ordered[ $platform ] = $summary['platforms'][ $platform ];
			}
		}
		$summary['platforms'] = $ordered;

		return $summary;
	}

	/**
	 * Share of tracked purchases, 0 to 100.
	 *
	 * @param array $summary fromRows() value
	 * @return int
	 */
	public static function trackedPercent( array $summary ) {
		return $summary['total'] > 0 ? (int) round( 100 * $summary['tracked'] / $summary['total'] ) : 0;
	}

	/**
	 * Lines for "Needs attention", most important first.
	 *
	 * @param array $summary fromRows() value
	 * @return string[]
	 */
	public static function attentionLines( array $summary ) {
		$lines = array();

		foreach ( $summary['platforms'] as $platform => $counts ) {
			if ( $counts['failed'] > 0 ) {
				$lines[] = sprintf(
					/* translators: 1: number of orders, 2: platform name, 3: "API" or "Measurement Protocol" */
					_n(
						'%1$d order: the %2$s %3$s rejected the Purchase. Check its credentials in the plugin settings.',
						'%1$d orders: the %2$s %3$s rejected the Purchase. Check its credentials in the plugin settings.',
						$counts['failed'],
						'pys'
					),
					$counts['failed'],
					$counts['label'],
					PurchaseReport::serverChannelName( $platform )
				);
			}
		}
		foreach ( $summary['platforms'] as $platform => $counts ) {
			if ( $counts['not_sent'] > 0 ) {
				$lines[] = sprintf(
					/* translators: 1: number of orders, 2: platform name */
					_n( '%1$d order did not reach %2$s.', '%1$d orders did not reach %2$s.', $counts['not_sent'], 'pys' ),
					$counts['not_sent'],
					$counts['label']
				);
			}
		}
		foreach ( $summary['platforms'] as $platform => $counts ) {
			if ( $counts['api_not_configured'] > 0 ) {
				$lines[] = sprintf(
					/* translators: 1: number of orders, 2: platform name, 3: "API" or "Measurement Protocol" */
					_n(
						'%1$d order reached %2$s by the tag only: its %3$s is not configured.',
						'%1$d orders reached %2$s by the tag only: its %3$s is not configured.',
						$counts['api_not_configured'],
						'pys'
					),
					$counts['api_not_configured'],
					$counts['label'],
					PurchaseReport::serverChannelName( $platform )
				);
			}
		}

		return $lines;
	}

	/**
	 * Lines for "What PixelYourSite did", beyond the per-platform table.
	 *
	 * @param array         $summary fromRows() value
	 * @param callable|null $money   function ( float $amount, string $currency ): string
	 * @return string[]
	 */
	public static function activityLines( array $summary, $money = null ) {
		$lines  = array();
		$amount = function ( $value ) use ( $summary, $money ) {
			if ( null === $value || null === $summary['currency'] || ! is_callable( $money ) ) {
				return '';
			}

			return ' (' . call_user_func( $money, $value, $summary['currency'] ) . ')';
		};

		$activity = $summary['activity'];

		if ( $activity['pixel'] > 0 ) {
			$lines[] = sprintf(
				/* translators: %d: number of orders */
				_n( '%d purchase sent by the pixel, from the thank-you page.', '%d purchases sent by the pixel, from the thank-you page.', $activity['pixel'], 'pys' ),
				$activity['pixel']
			);
		}
		if ( $activity['pixel_and_api'] > 0 ) {
			$lines[] = sprintf(
				/* translators: %d: number of orders */
				_n(
					'%d of them also sent by the API (Measurement Protocol for GA4), with the same event id, so the platform counts it once.',
					'%d of them also sent by the API (Measurement Protocol for GA4), with the same event id, so the platforms count each once.',
					$activity['pixel_and_api'],
					'pys'
				),
				$activity['pixel_and_api']
			);
		}
		if ( $activity['order_status'] > 0 ) {
			$lines[] = sprintf(
				/* translators: 1: number of orders, 2: amount in brackets or empty */
				_n(
					'%1$d purchase without a thank-you page sent by Advanced Purchase Tracking: sent from the server when the order status changed%2$s.',
					'%1$d purchases without a thank-you page sent by Advanced Purchase Tracking: sent from the server when the order status changed%2$s.',
					$activity['order_status'],
					'pys'
				),
				$activity['order_status'],
				$amount( $activity['order_status_value'] )
			);
		}
		if ( $activity['renewals'] > 0 ) {
			$lines[] = sprintf(
				/* translators: %d: number of orders */
				_n(
					'%d subscription renewal sent by the API (Measurement Protocol for GA4).',
					'%d subscription renewals sent by the API (Measurement Protocol for GA4).',
					$activity['renewals'],
					'pys'
				),
				$activity['renewals']
			);
		}
		if ( $activity['api_only'] > 0 ) {
			$lines[] = sprintf(
				/* translators: %d: number of orders */
				_n(
					'%d purchase without a thank-you page sent by the API (Measurement Protocol for GA4).',
					'%d purchases without a thank-you page sent by the API (Measurement Protocol for GA4).',
					$activity['api_only'],
					'pys'
				),
				$activity['api_only']
			);
		}

		if ( $summary['ad_clicks']['orders'] > 0 ) {
			$platforms = array();
			foreach ( $summary['ad_clicks']['by_platform'] as $name => $count ) {
				$platforms[] = $name . ' ' . $count;
			}
			$lines[] = sprintf(
				/* translators: 1: number of orders, 2: list such as "Meta 4 · Google 2" */
				_n( '%1$d purchase came from an ad click (%2$s).', '%1$d purchases came from an ad click (%2$s).', $summary['ad_clicks']['orders'], 'pys' ),
				$summary['ad_clicks']['orders'],
				implode( " \xC2\xB7 ", $platforms )
			);
		}

		foreach ( $summary['skipped_by'] as $reason => $count ) {
			$lines[] = sprintf(
				/* translators: 1: number of orders, 2: reason, e.g. "renewals are excluded in the settings" */
				_n( '%1$d order not sent on purpose: %2$s.', '%1$d orders not sent on purpose: %2$s.', $count, 'pys' ),
				$count,
				PurchaseReport::noteLabel( $reason )
			);
		}

		return $lines;
	}
}
