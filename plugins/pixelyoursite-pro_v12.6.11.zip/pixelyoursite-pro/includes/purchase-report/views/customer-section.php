<?php
/**
 * The customer section: the customer's value and how their purchases were tracked.
 *
 * @package PixelYourSite
 *
 * @var string $type         'woo' or 'edd'
 * @var array  $rows         List of array( 'report', 'number', 'url', 'total' ), newest first
 * @var array  $totals       orders_count, ltv, avg_order_value; empty to leave the value out
 * @var string $settings_url
 * @var string $heading_tag  'h2' or 'h3'
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$heading_tag   = 'h3' === $heading_tag ? 'h3' : 'h2';
$section_title = 'edd' === $type ? __( 'PixelYourSite EDD Purchases', 'pys' ) : __( 'PixelYourSite WooCommerce Purchases', 'pys' );
?>
<div class="pys-pr-customer">
	<<?php echo $heading_tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- one of two literals. ?>><?php echo esc_html( $section_title ); ?></<?php echo $heading_tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>

	<?php if ( ! empty( $totals['orders_count'] ) ) : ?>
		<p>
			<?php
			echo wp_kses_post(
				sprintf(
					/* translators: 1: number of orders, 2: lifetime value, 3: average order value */
					__( 'Orders: <strong>%1$s</strong> &middot; Lifetime value: <strong>%2$s</strong> &middot; Average order: <strong>%3$s</strong>', 'pys' ),
					esc_html( $totals['orders_count'] ),
					wp_kses_post( $totals['ltv'] ),
					wp_kses_post( $totals['avg_order_value'] )
				)
			);
			?>
		</p>
	<?php endif; ?>

	<table class="widefat striped pys-pr-customer__orders">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Order', 'pys' ); ?></th>
				<th><?php esc_html_e( 'Date', 'pys' ); ?></th>
				<th><?php esc_html_e( 'Total', 'pys' ); ?></th>
				<th><?php esc_html_e( 'Purchase', 'pys' ); ?></th>
				<th><?php esc_html_e( 'Sent to', 'pys' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $rows as $row ) : ?>
			<?php
			$sent_to = array();
			foreach ( $row['report']['platforms'] as $platform_row ) {
				if ( PurchaseReport::STATE_SENT === $platform_row['state'] ) {
					$sent_to[] = $platform_row['label'];
				}
			}
			?>
			<tr>
				<td><a href="<?php echo esc_url( $row['url'] ); ?>">#<?php echo esc_html( $row['number'] ); ?></a></td>
				<td><?php echo esc_html( $row['report']['order']['created'] ? wp_date( get_option( 'date_format' ), $row['report']['order']['created'] ) : '' ); ?></td>
				<td><?php echo esc_html( $row['total'] ); ?></td>
				<td><span class="pys-pr-dot pys-pr-dot--<?php echo esc_attr( $row['report']['verdict'] ); ?>"></span><?php echo esc_html( PurchaseReport::verdictLabel( $row['report']['verdict'] ) ); ?></td>
				<td><?php echo ! empty( $sent_to ) ? esc_html( implode( ', ', $sent_to ) ) : '&mdash;'; ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php
	PurchaseReportAdmin::view(
		'control-line',
		array(
			'type'         => $type,
			'settings_url' => $settings_url,
		)
	);
	?>
</div>
