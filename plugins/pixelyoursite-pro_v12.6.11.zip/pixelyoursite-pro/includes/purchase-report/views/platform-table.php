<?php
/**
 * Purchase events per platform: orders reached, by the tag, by the API.
 *
 * @package PixelYourSite
 *
 * @var array $summary PurchaseReportSummary::fromRows() value
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( empty( $summary['platforms'] ) ) {
	return;
}
?>
<table class="pys-pr-platforms">
	<thead>
		<tr>
			<th><?php esc_html_e( 'Platform', 'pys' ); ?></th>
			<th><abbr title="<?php esc_attr_e( 'Orders where the platform received the Purchase at least once', 'pys' ); ?>"><?php esc_html_e( 'Purchase events', 'pys' ); ?></abbr></th>
			<th><abbr title="<?php esc_attr_e( 'Sent by the tag on the thank-you page', 'pys' ); ?>"><?php esc_html_e( 'Tag', 'pys' ); ?></abbr></th>
			<th><abbr title="<?php esc_attr_e( 'Accepted by the platform API; for GA4, by the Measurement Protocol', 'pys' ); ?>"><?php esc_html_e( 'API / MP', 'pys' ); ?></abbr></th>
			<th><?php esc_html_e( 'Note', 'pys' ); ?></th>
		</tr>
	</thead>
	<tbody>
	<?php foreach ( $summary['platforms'] as $platform => $counts ) : ?>
		<?php
		$has_api = in_array( $platform, PurchaseReport::API_PLATFORMS, true );
		$notes   = array();
		if ( $counts['failed'] > 0 ) {
			/* translators: 1: "API" or "Measurement Protocol", 2: number of orders */
			$notes[] = sprintf( __( '%1$s rejected %2$d', 'pys' ), PurchaseReport::serverChannelName( $platform ), $counts['failed'] );
		}
		if ( $counts['api_not_configured'] > 0 ) {
			/* translators: %s: "API" or "Measurement Protocol" */
			$notes[] = sprintf( __( '%s not configured', 'pys' ), PurchaseReport::serverChannelName( $platform ) );
		}
		?>
		<tr>
			<td><?php echo esc_html( $counts['label'] ); ?></td>
			<td><strong><?php echo (int) $counts['sent']; ?></strong></td>
			<td><?php echo $counts['tag'] > 0 ? (int) $counts['tag'] : '&mdash;'; ?></td>
			<td>
				<?php if ( ! $has_api || 0 === $counts['api'] ) : ?>
					&mdash;
				<?php else : ?>
					<?php echo (int) $counts['api']; ?>
					<?php if ( $counts['api_order_status'] > 0 ) : ?>
						<span class="pys-pr-muted">
							<?php
							/* translators: %d: number of orders */
							echo esc_html( sprintf( __( '(%d by Advanced Purchase Tracking)', 'pys' ), $counts['api_order_status'] ) );
							?>
						</span>
					<?php endif; ?>
				<?php endif; ?>
			</td>
			<td class="pys-pr-muted"><?php echo ! empty( $notes ) ? esc_html( implode( ' · ', $notes ) ) : '&mdash;'; ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
