<?php
/**
 * The PixelYourSite block of the admin new-order email. No CSS: email
 * clients strip it.
 *
 * @package PixelYourSite
 *
 * @var string   $type         'woo' or 'edd'
 * @var array    $visit        PurchaseReportOrderData::visit() value
 * @var string[] $ad_click
 * @var string   $user_agent
 * @var array    $totals       orders_count, ltv, avg_order_value; may be empty
 * @var string   $order_url
 * @var string   $order_number
 * @var string   $settings_url
 * @var string   $store_name
 * @var bool     $plain        Plain-text email
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$lines = array();
if ( $visit['present'] && ! $visit['renewal'] ) {
	$with_first = function ( $last, $first ) {
		$text = '' !== $last ? $last : __( 'none', 'pys' );
		if ( '' !== $first && $first !== $last ) {
			/* translators: %s: value of the first visit */
			$text .= ' ' . sprintf( __( '(first visit: %s)', 'pys' ), $first );
		}

		return $text;
	};

	$lines[ __( 'Landing page', 'pys' ) ]   = $with_first( PurchaseReportOrderData::shortPath( $visit['last']['landing'] ), PurchaseReportOrderData::shortPath( $visit['first']['landing'] ) );
	$lines[ __( 'Traffic source', 'pys' ) ] = $with_first( PurchaseReportOrderData::clip( $visit['last']['source'], 40 ), PurchaseReportOrderData::clip( $visit['first']['source'], 40 ) );
	$lines[ __( 'Campaign (UTM)', 'pys' ) ] = $with_first( PurchaseReportOrderData::utmText( $visit['last']['utm'], 40 ), PurchaseReportOrderData::utmText( $visit['first']['utm'], 40 ) );
} elseif ( $visit['renewal'] ) {
	$lines[ __( 'Visit', 'pys' ) ] = __( 'subscription renewal, no visit', 'pys' );
}
$lines[ __( 'Ad click', 'pys' ) ] = ! empty( $ad_click ) ? implode( ', ', $ad_click ) : __( 'none recorded', 'pys' );
if ( '' !== $visit['browser_time'] ) {
	$lines[ __( 'Browser time', 'pys' ) ] = $visit['browser_time'];
}
if ( ! empty( $totals['orders_count'] ) ) {
	$lines[ __( 'Customer', 'pys' ) ] = sprintf(
		/* translators: 1: number of orders, 2: lifetime value */
		_n( '%1$s order, lifetime value %2$s', '%1$s orders, lifetime value %2$s', (int) $totals['orders_count'], 'pys' ),
		$totals['orders_count'],
		html_entity_decode( wp_strip_all_tags( (string) $totals['ltv'] ), ENT_QUOTES, 'UTF-8' )
	);
}

$see = __( 'See how the Purchase events were sent on the order page', 'pys' );
/* translators: %s: "WooCommerce" or "Easy Digital Downloads" */
$control = sprintf( __( 'Your clients don\'t see this block. Control it on the %s settings page, under Native Data Tracking and Reporting.', 'pys' ), $store_name );

if ( $plain ) {
	// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- plain-text email: tags are stripped, entities would show as text.
	echo "\nPixelYourSite\n";
	foreach ( $lines as $label => $value ) {
		echo wp_strip_all_tags( $label . ': ' . $value ) . "\n";
	}
	echo wp_strip_all_tags( $see . ': ' . $order_url ) . "\n" . wp_strip_all_tags( $control ) . "\n";
	// phpcs:enable

	return;
}
// Inline style: email clients drop style sheets, and a long value must wrap inside the email, never widen it.
?>
<div style="word-break:break-word;overflow-wrap:anywhere;max-width:100%;">
<p><b>PixelYourSite</b></p>
<p>
<?php foreach ( $lines as $label => $value ) : ?>
	<b><?php echo esc_html( $label ); ?>:</b> <?php echo esc_html( $value ); ?><br>
<?php endforeach; ?>
</p>
<p>
	<?php echo esc_html( $see ); ?>:
	<a href="<?php echo esc_url( $order_url ); ?>">
		<?php
		/* translators: %s: order number */
		echo esc_html( sprintf( __( 'Open order #%s', 'pys' ), $order_number ) );
		?>
	</a>
</p>
<p><small><?php echo esc_html( $control ); ?> <a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Open the settings', 'pys' ); ?></a></small></p>
</div>
