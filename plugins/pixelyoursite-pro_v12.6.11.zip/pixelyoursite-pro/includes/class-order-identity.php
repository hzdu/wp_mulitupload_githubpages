<?php
/**
 * Browser identifiers of an order, with a fallback chain.
 *
 * An order made without the buyer's browser (a renewal, an API order, a
 * CartFlows upsell child) has no snapshot of its own. For the identifiers that
 * describe a browser - not a click - we then look at the parent order, and at
 * what the logged-in customer's browser last told us (user meta pys_identity).
 *
 * Ad click ids (fbc, ttclid, oppref, epik) describe one visit: they come from
 * the parent only for a CartFlows child, never from the user store and never on
 * a renewal.
 */

namespace PixelYourSite;

defined( 'ABSPATH' ) or die( 'Direct access not allowed' );

class OrderIdentity {

	/** key => [ snapshot meta key, inner key or '' ] */
	private static $map = array(
		'fbp'          => array( 'pys_fb_cookie', 'fbp' ),
		'fbc'          => array( 'pys_fb_cookie', 'fbc' ),
		'ttp'          => array( 'pys_tt_cookie', 'ttp' ),
		'ttclid'       => array( 'pys_tt_cookie', 'ttclid' ),
		'obref'        => array( 'pys_oai_cookie', 'obref' ),
		'oppref'       => array( 'pys_oai_cookie', 'oppref' ),
		'epik'         => array( 'pys_pin_cookie', 'epik' ),
		'ga_client_id' => array( 'pys_ga_cookie', 'clientId' ),
		'pbid'         => array( 'external_id', '' ),
		'click_ids'    => array( 'pys_click_ids', '' ),
	);

	private static $click_keys = array( 'fbc', 'ttclid', 'oppref', 'epik' );

	private static $cache = array();

	/**
	 * @param string $type     'woo' | 'edd'
	 * @param int    $order_id
	 * @param string $key      see $map
	 * @return array{value:string,source:string} source: order|parent|user|none
	 */
	public static function get( $type, $order_id, $key ) {
		$order_id = (int) $order_id;
		$ck       = $type . ':' . $order_id . ':' . $key;

		if ( isset( self::$cache[ $ck ] ) ) {
			return self::$cache[ $ck ];
		}

		$result = array( 'value' => '', 'source' => 'none' );
		if ( $order_id > 0 && isset( self::$map[ $key ] ) ) {
			$result = self::resolve( $type, $order_id, $key );
		}

		self::$cache[ $ck ] = $result;
		return $result;
	}

	private static function resolve( $type, $order_id, $key ) {
		$renewal = self::isRenewal( $type, $order_id );
		$click   = in_array( $key, self::$click_keys, true );

		// A renewal is a new purchase: an ad click id on it is the parent's, copied
		// before this release (or by Subscriptions without our filter). Never send it.
		if ( $renewal && $click ) {
			return array( 'value' => '', 'source' => 'none' );
		}

		$own = self::readSnapshot( $type, $order_id, $key );
		if ( '' !== $own ) {
			// WCS copies the parent's snapshot onto a renewal, so what is on the
			// renewal is the parent's value and ages with the parent's order.
			$parent = $renewal && ! $click ? self::parentOrderId( $type, $order_id ) : 0;
			if ( $parent > 0 && $parent !== $order_id && self::isStaleKey( $key ) ) {
				$ts = self::orderTimestamp( $type, $parent );
				if ( $ts > 0 && self::isStale( $key, $ts ) ) {
					$own = '';
				} else {
					return array( 'value' => $own, 'source' => 'parent' );
				}
			}
			if ( '' !== $own ) {
				return array( 'value' => $own, 'source' => 'order' );
			}
		}

		// Click ids: CartFlows child only. click_ids (first touch, display): any non-renewal.
		if ( $renewal ) {
			$from_parent = ! $click && 'click_ids' !== $key;
		} elseif ( $click ) {
			$from_parent = 'woo' === $type && self::cartflowsParent( $order_id ) > 0;
		} else {
			$from_parent = true;
		}

		$parent = self::parentOrderId( $type, $order_id );
		if ( $from_parent && $parent > 0 && $parent !== $order_id ) {
			$value = self::readSnapshot( $type, $parent, $key );
			$ts    = self::orderTimestamp( $type, $parent );
			if ( '' !== $value && ( $ts < 1 || ! self::isStale( $key, $ts ) ) ) {
				return array( 'value' => $value, 'source' => 'parent' );
			}
		}

		if ( ! $click && 'click_ids' !== $key && 'pbid' !== $key ) {
			$value = self::readUserStore( pys_order_context_customer_id( $type, $order_id ), $key );
			if ( '' !== $value ) {
				return array( 'value' => $value, 'source' => 'user' );
			}
		}

		return array( 'value' => '', 'source' => 'none' );
	}

	public static function parentOrderId( $type, $order_id ) {
		$order_id = (int) $order_id;

		if ( 'edd' === $type ) {
			$order = function_exists( 'edd_get_order' ) ? edd_get_order( $order_id ) : false;
			if ( $order && ( 'edd_subscription' === ( $order->status ?? '' ) || 'refund' === ( $order->type ?? '' ) ) ) {
				return (int) ( $order->parent ?? 0 );
			}
			return 0;
		}

		$cf = self::cartflowsParent( $order_id );
		if ( $cf > 0 ) {
			return $cf;
		}

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		if ( ! $order ) {
			return 0;
		}

		if ( function_exists( 'wcs_get_subscriptions_for_renewal_order' ) ) {
			$subs = wcs_get_subscriptions_for_renewal_order( $order );
			$sub  = is_array( $subs ) && $subs ? reset( $subs ) : null;
			if ( $sub && method_exists( $sub, 'get_parent_id' ) && (int) $sub->get_parent_id() > 0 ) {
				return (int) $sub->get_parent_id();
			}
		}

		return (int) $order->get_parent_id();
	}

	public static function isRenewal( $type, $order_id ) {
		if ( 'edd' === $type ) {
			$order = function_exists( 'edd_get_order' ) ? edd_get_order( (int) $order_id ) : false;
			return $order && 'edd_subscription' === ( $order->status ?? '' );
		}

		if ( ! function_exists( 'wcs_order_contains_renewal' ) || ! function_exists( 'wc_get_order' ) ) {
			return false;
		}
		$order = wc_get_order( (int) $order_id );
		return $order && wcs_order_contains_renewal( $order );
	}

	/**
	 * Remember this browser's identifiers for the logged-in customer.
	 * At most once an hour; each key only with its pixel's consent.
	 */
	public static function storeUserIdentity( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id < 1 || get_transient( 'pys_identity_written_' . $user_id ) ) {
			return;
		}
		// Only where there is a shop to attribute, and not for staff the plugin ignores.
		if ( ! ( isWooCommerceActive() || isEddActive() ) || isDisabledForUserRole( wp_get_current_user() ) ) {
			return;
		}

		$gate = array( 'fbp' => 'facebook', 'ttp' => 'tiktok', 'ga_client_id' => 'ga', 'obref' => 'openai' );
		$now  = array();
		foreach ( self::currentCookies() as $key => $value ) {
			if ( '' === $value ) {
				continue;
			}
			// An explicit yes: before the visitor answers, checkConsent() still allows.
			if ( ! function_exists( __NAMESPACE__ . '\Consent' ) || ! Consent()->hasExplicitConsent( $gate[ $key ] ) ) {
				continue;
			}
			$now[ $key ] = array( 'v' => $value, 't' => time() );
		}

		if ( ! $now ) {
			return;
		}

		$stored = get_user_meta( $user_id, 'pys_identity', true );
		update_user_meta( $user_id, 'pys_identity', array_merge( is_array( $stored ) ? $stored : array(), $now ) );
		set_transient( 'pys_identity_written_' . $user_id, 1, 3600 );
	}

	/** template_redirect: a logged-in visitor's own front-end page view. */
	public static function storeForCurrentVisitor() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI )
			|| ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		self::storeUserIdentity( get_current_user_id() );
	}

	/**
	 * The request's cookies through the readers the order savers use. The OpenAI
	 * reader (currentIdentifiers()) is private, so obref is read from the same
	 * cookie directly rather than widening that class.
	 */
	private static function currentCookies() {
		$out = array( 'fbp' => '', 'ttp' => '', 'ga_client_id' => '', 'obref' => '' );

		if ( class_exists( __NAMESPACE__ . '\ServerEventHelper' ) ) {
			$out['fbp'] = (string) ServerEventHelper::getFbp();
		}
		if ( function_exists( __NAMESPACE__ . '\TikTok\Helpers\getTtp' ) ) {
			$out['ttp'] = (string) \PixelYourSite\TikTok\Helpers\getTtp();
		}
		if ( class_exists( __NAMESPACE__ . '\GaServerEventHelper' ) ) {
			$ga                  = GaServerEventHelper::parseGaCookies();
			$out['ga_client_id'] = is_array( $ga ) ? (string) ( $ga['clientId'] ?? '' ) : '';
		}
		if ( ! empty( $_COOKIE['__obref'] ) && is_string( $_COOKIE['__obref'] ) ) {
			$out['obref'] = sanitize_text_field( wp_unslash( $_COOKIE['__obref'] ) );
		}
		return $out;
	}

	private static function cartflowsParent( $order_id ) {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( (int) $order_id ) : false;
		return $order ? (int) $order->get_meta( '_cartflows_offer_parent_id', true ) : 0;
	}

	private static function readSnapshot( $type, $order_id, $key ) {
		list( $meta_key, $inner ) = self::$map[ $key ];

		if ( 'edd' === $type ) {
			$raw = pys_edd_order_meta( $order_id, $meta_key );
		} else {
			$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
			$raw   = $order ? $order->get_meta( $meta_key, true ) : '';
		}

		if ( '' !== $inner ) {
			$raw = is_array( $raw ) && isset( $raw[ $inner ] ) ? $raw[ $inner ] : '';
		} elseif ( is_array( $raw ) ) {
			$raw = wp_json_encode( $raw );
		}

		if ( 'click_ids' === $key ) {
			// JSON with rawurlencoded values: sanitize_text_field() would strip the %XX octets.
			return is_string( $raw ) && is_array( json_decode( $raw, true ) ) ? $raw : '';
		}

		return is_string( $raw ) || is_numeric( $raw ) ? sanitize_text_field( (string) $raw ) : '';
	}

	private static function readUserStore( $user_id, $key ) {
		if ( $user_id < 1 ) {
			return '';
		}
		$store = get_user_meta( $user_id, 'pys_identity', true );
		if ( ! is_array( $store ) || empty( $store[ $key ]['v'] ) || ! is_string( $store[ $key ]['v'] ) ) {
			return '';
		}
		return self::isStale( $key, (int) ( $store[ $key ]['t'] ?? 0 ) ) ? '' : $store[ $key ]['v'];
	}

	private static function isStaleKey( $key ) {
		return in_array( $key, array( 'fbp', 'ttp', 'ga_client_id', 'obref' ), true );
	}

	/** Lifetimes in days; keys not listed (pbid, on the order only) never go stale. */
	private static function isStale( $key, $timestamp ) {
		$days = array( 'fbp' => 90, 'ttp' => 90, 'ga_client_id' => 730, 'obref' => 90 );
		if ( ! isset( $days[ $key ] ) ) {
			return false;
		}
		$seconds = $days[ $key ] * 86400;
		if ( 'obref' === $key && function_exists( 'PixelYourSite\OpenAI\Helpers\pys_openai_cookie_lifetime' ) ) {
			$seconds = (int) \PixelYourSite\OpenAI\Helpers\pys_openai_cookie_lifetime();
		}
		return $timestamp < 1 || ( time() - $timestamp ) > $seconds;
	}

	public static function orderTimestamp( $type, $order_id ) {
		if ( 'edd' === $type ) {
			$order = function_exists( 'edd_get_order' ) ? edd_get_order( $order_id ) : false;
			return $order && ! empty( $order->date_created ) ? (int) strtotime( $order->date_created . ' UTC' ) : 0;
		}
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		$date  = $order ? $order->get_date_created() : null;
		return $date && method_exists( $date, 'getTimestamp' ) ? (int) $date->getTimestamp() : 0;
	}
}

/**
 * @return array{value:string,source:string}
 */
function pys_order_identity( $type, $order_id, $key ) {
	return OrderIdentity::get( $type, $order_id, $key );
}
