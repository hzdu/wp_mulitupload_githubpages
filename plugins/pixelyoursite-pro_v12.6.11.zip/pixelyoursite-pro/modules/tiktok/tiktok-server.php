<?php

namespace PixelYourSite;

require_once PYS_PATH . '/modules/tiktok/tiktok-server-async-task.php';

use DateTimeInterface;
use PixelYourSite;
use PixelYourSite\TikTok\Helpers;
use PYS_PRO_GLOBAL\GuzzleHttp\Client;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * TikTok Server Events Handler
 *
 * Extends AbstractServerEvents to handle TikTok Conversions API
 */
class TikTokServer extends AbstractServerEvents {

	private static $_instance;
	private        $isEnabled;
	private        $testCode;

	/** Whether the current request's cookies may stand in for the buyer's. */
	private        $requestCookies = true;

	/**
	 * Click id captured during this request.
	 *
	 * Backs up the cookie for the case where headers were already sent and the
	 * cookie could not be written, so the current request still reports it.
	 *
	 * @var string
	 */
	private static $ttclid = '';

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct() {
		parent::__construct();
        add_action('init', array($this, 'init'));
	}

    public function init()
    {
        $this->isEnabled = Tiktok()->isServerApiEnabled();

        if ( $this->isEnabled ) {
            // Classic hook for checkout page
            add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'saveTtTagsInOrder' ), 10, 1 );
            // Hook for Store API (passes WC_Order object instead of order_id)
            add_action( 'woocommerce_store_api_checkout_update_order_meta', array( $this, 'saveTtTagsInOrder' ), 10, 1 );
            add_action( 'edd_insert_payment', array( $this, 'saveTtTagsInEddOrder' ), 10, 1 );
            add_action( 'edd_complete_purchase', array( $this, 'fillTtTagsInEddOrder' ), 4, 1 );

            // AJAX handlers for fallback (from parent class)
            $this->registerAjaxHandlers();

            // Initialize tiktok event async task (only if queue is disabled)
            if (!$this->isQueueEnabled()) {
                new TikTokAsyncTask();
            }
        }
    }

	/**
	 * Get the pixel instance
	 *
	 * @return Tiktok
	 */
	protected function getPixelInstance() {
		return Tiktok();
	}

	/**
	 * Get the platform name for queue system
	 *
	 * @return string
	 */
	protected function getQueuePlatformName() {
		return 'tiktok';
	}

	/**
	 * Get the async task action name
	 *
	 * @return string
	 */
	protected function getServerEventAction() {
		return 'pys_send_tiktok_server_event';
	}

	/**
	 * Get the AJAX action name for catching events
	 *
	 * @return string
	 */
	protected function getAjaxActionName() {
		return 'pys_tiktok_api_event';
	}

	/**
	 * Track Woo Add to cart events
	 *
	 * @param $cart_item_key
	 * @param $product_id
	 * @param $quantity
	 * @param $variation_id
	 * @return void
	 */
	function trackAddToCartEvent( $cart_item_key, $product_id, $quantity, $variation_id ) {
		if ( EventsWoo()->isReadyForFire( "woo_add_to_cart_on_button_click" ) && PYS()->getOption( 'woo_add_to_cart_catch_method' ) == "add_cart_js" ) {
			// it ok. We send server method after js, and take event id from cookies
			Tiktok()->getLog()->debug( ' trackAddToCartEvent send TikTok server without browser event' );

			if ( !empty( $variation_id ) && $variation_id > 0 && ( !Tiktok()->getOption( 'woo_variable_as_simple' ) ) ) {
				$_product_id = $variation_id;
			} else {
				$_product_id = $product_id;
			}

			$event = new SingleEvent( "woo_add_to_cart_on_button_click", EventTypes::$DYNAMIC, 'woo' );
			$event->args = [
				'productId' => $_product_id,
				'quantity'  => $quantity
			];
			$event->params[ 'uri' ] = self::getRequestUri( PYS()->getOption( 'enable_remove_source_url_params' ) );

			// Remove only our own callback, not everything on the hook.
			$conditional_post_id = function ( $id ) use ( $product_id ) {
				return $product_id;
			};
			add_filter( 'pys_conditional_post_id', $conditional_post_id );
			$events = Tiktok()->generateEvents( $event );
			remove_filter( 'pys_conditional_post_id', $conditional_post_id );

			do_action( 'pys_send_tiktok_server_event', $events );
		}
	}

	/**
	 * Send event for each pixel id
	 * @param array $pixel_Ids //array of TikTok pixel ids
	 * @param $event //One TikTok event object
	 */
	function sendEvent( $pixel_Ids, $event ) {

		if ( !$event ) {
			return self::sendResult( self::SEND_SKIPPED, 'No event to send' );
		}

		if ( !Tiktok()->configured() ) {
			return self::sendResult( self::SEND_SKIPPED, 'TikTok pixel is switched off' );
		}

		if ( !$this->access_token ) {
			$this->access_token = Tiktok()->getApiTokens();
			$this->testCode = Tiktok()->getApiTestCode();
		}

		if ( !is_array( $pixel_Ids ) && !is_object( $pixel_Ids ) || empty( $pixel_Ids ) ) {
			return self::sendResult( self::SEND_SKIPPED, 'No pixel IDs for this event' );
		}

		$sent = false;
		$done = array(); // pixels that need no further attempt, see sendResult()
		$outcomes = array(); // per pixel, for the order's delivery record
		$retry_message = '';
		$failed_message = '';

		foreach ( $pixel_Ids as $pixel_Id ) {

			if ( !Tiktok()->enabled() || empty( $this->access_token[ $pixel_Id ] ) ) {
				$done[] = $pixel_Id;
				$outcomes[ $pixel_Id ] = self::pixelOutcome( PurchaseDelivery::OUTCOME_SKIPPED, 'TikTok disabled or no access token' );
				continue;
			}

			$event->pixel_code = $pixel_Id;

			if ( $this->testCode[ $pixel_Id ] ) {
				$event->test_event_code = $this->testCode[ $pixel_Id ];
			}

			$url = "https://business-api.tiktok.com/open_api/v1.3/pixel/track/";
			$headers = array(
				'Content-Type' => 'application/json',
				'Access-Token' => $this->access_token[ $pixel_Id ]
			);

			Tiktok()->getLog()->debug( ' Send TikTok server event', $event );
			try {
				$client = new Client();
				// Guzzle defaults both of these to 0, i.e. wait forever.
				$response = $client->request( 'POST', $url, [
					'headers'         => $headers,
					'body'            => json_encode( $event ),
					'timeout'         => pys_server_request_timeout(),
					'connect_timeout' => pys_server_connect_timeout()
				] );
				Tiktok()->getLog()->debug( ' Response from Tiktok server', $response );

				// TikTok answers 200 even when it rejects the event; the real
				// verdict is the "code" field in the body (0 means accepted).
				// Treating HTTP 200 as delivery was how rejected events ended up
				// marked as processed.
				$body = json_decode( (string) $response->getBody(), true );
				$api_code = is_array( $body ) && isset( $body[ 'code' ] ) ? (int) $body[ 'code' ] : 0;

				if ( $api_code !== 0 ) {
					$api_message = is_array( $body ) && !empty( $body[ 'message' ] ) ? $body[ 'message' ] : 'unknown error';
					Tiktok()->getLog()->error( 'TikTok rejected the event: code ' . $api_code . ' ' . $api_message );
					// A rejected payload will be rejected again, so do not spend
					// retries on it — keep the row as failed with the reason.
					$failed_message = sprintf( 'TikTok pixel %s: API code %d %s', $pixel_Id, $api_code, $api_message );
					$outcomes[ $pixel_Id ] = self::pixelOutcome( PurchaseDelivery::OUTCOME_REJECTED, $failed_message );
					continue;
				}

				$sent = true;
				$done[] = $pixel_Id;
				$outcomes[ $pixel_Id ] = self::pixelOutcome( PurchaseDelivery::OUTCOME_ACCEPTED );

				// Track fired pixel for meta storage
				ServerEventsManager::addFiredPixel( 'tiktok', $pixel_Id );

			} catch ( \Exception $e ) {
				Tiktok()->getLog()->error( 'Error send TikTok server event ' . $e->getMessage() );

				$status = $this->classifyGuzzleException( $e );
				$message = sprintf( 'TikTok pixel %s: %s', $pixel_Id, $e->getMessage() );

				if ( $status === self::SEND_FAILED ) {
					$failed_message = $message;
					$outcomes[ $pixel_Id ] = self::pixelOutcome( PurchaseDelivery::OUTCOME_REJECTED, $message );
				} else {
					$retry_message = $message;
					$outcomes[ $pixel_Id ] = self::pixelOutcome( PurchaseDelivery::OUTCOME_RETRY, $message );
				}
			}
		}

		if ( $retry_message !== '' ) {
			return self::sendResult( self::SEND_RETRY, $retry_message, $done, $outcomes );
		}
		if ( $failed_message !== '' ) {
			return self::sendResult( self::SEND_FAILED, $failed_message, $done, $outcomes );
		}

		return $sent
				? self::sendResult( self::SEND_SENT, '', $done, $outcomes )
				: self::sendResult( self::SEND_SKIPPED, 'TikTok disabled or no access token for any pixel ID', $done, $outcomes );
	}

	/**
	 * Map SingleEvent to TikTok server event format
	 *
	 * @param SingleEvent $event The event to map
	 * @return \stdClass TikTok event object
	 */
	protected function mapEventToServerEvent( $event ) {

		$this->captureTtclid();

		// The browser forwards the click id in the AJAX/REST payload as a last
		// resort, for the case where the landing page came from a cache and no
		// cookie reached PHP. Pull it out of the params first: the loop further
		// down copies every remaining param to the payload root, and ttclid
		// belongs in context.user, not there.
		$payload_ttclid = '';
		if ( is_array( $event->params ) && ! empty( $event->params[ 'ttclid' ] ) && is_string( $event->params[ 'ttclid' ] ) ) {
			$payload_ttclid = sanitize_text_field( $event->params[ 'ttclid' ] );
			unset( $event->params[ 'ttclid' ] );
		}

		$eventData = $event->getData();

		$eventData = EventsManager::filterEventParams( $eventData, $event->getCategory(), [
			'event_id' => $event->getId(),
			'pixel'    => Tiktok()->getSlug()
		] );

		$eventName = $eventData[ 'name' ];
		$wooOrder = isset( $event->payload[ 'woo_order' ] ) ? $event->payload[ 'woo_order' ] : null;
		$eddOrder = isset( $event->payload[ 'edd_order' ] ) ? $event->payload[ 'edd_order' ] : null;
		// Page URL, referrer and time of an order event come from the order when
		// this request is not the buyer's (wp-admin, webhook, cron).
		$order_ref = pys_event_order_ref( $event );

		$user_data = $this->getUserData( $wooOrder, $eddOrder );

		if ( $payload_ttclid !== '' && empty( $user_data->user->ttclid ) ) {
			$user_data->user->ttclid = $payload_ttclid;
		}

		$custom_data = $this->paramsToCustomData( $eventData[ 'params' ] );

		// The Refund event keeps its own parameters in properties: the whitelist
		// above would drop them, and the root copy below would scatter them.
		$is_refund_event = in_array( $event->getId(), array( 'woo_refund', 'edd_refund' ), true );
		if ( $is_refund_event ) {
			foreach ( array( 'value', 'currency', 'order_id', 'num_items', 'refund_type', 'refund_id' ) as $refund_key ) {
				if ( isset( $eventData[ 'params' ][ $refund_key ] ) ) {
					$custom_data->$refund_key = $eventData[ 'params' ][ $refund_key ];
				}
			}
		}

		$uri           = $this->getEventUri( $event );
		$send_page     = true;
		$event_time    = 0;
		if ( $order_ref ) {
			list( $order_type, $order_ref_id ) = $order_ref;
			$payload_url = (string) $event->getPayloadValue( 'event_source_url' );
			if ( $payload_url === '' ) {
				$payload_url = pys_posted_page_url();
			}
			$ctx = pys_order_event_context( $order_type, $order_ref_id, $event->getId(), $payload_url );
			if ( $ctx['url'] !== '' ) {
				$uri = $ctx['url'];
			} else {
				// System or manual order, or no page known: this request's URL is
				// wp-admin's, admin-ajax's or a gateway's.
				$send_page = false;
			}
			$referrer   = pys_is_buyer_request( $order_type, $order_ref_id )
				? pys_resolve_event_referrer_url( $event, 'tiktok' )
				: $ctx['referrer'];
			$event_time = pys_order_event_time( $order_type, $order_ref_id, $event->getId(), PYS_EVENT_TIME_LIMIT_TIKTOK, pys_event_business_time( $event ) );
		} else {
			// The real referrer, or none: the home URL told TikTok every visit came
			// from the site's own front page.
			$referrer = pys_resolve_event_referrer_url( $event, 'tiktok' );
		}

		if ( $send_page ) {
			$user_data->page = new \stdClass;
			$user_data->page->url = $uri;
			if ( $referrer !== '' ) {
				$user_data->page->referrer = $referrer;
			}
		}

		$serverEvent = new \stdClass;
		$serverEvent->event = $eventName;

		$datetime = new \DateTime( 'now' );
		if ( $event_time > 0 ) {
			$datetime->setTimestamp( $event_time );
		}
		$serverEvent->timestamp = $datetime->format( DateTimeInterface::ATOM );
		$serverEvent->context = $user_data;
		if ( count( get_object_vars( $custom_data ) ) > 0 ) {
			$serverEvent->properties = $custom_data;
		}


		if ( is_array( $event->params ) && ! $is_refund_event ) {
			foreach ( $event->params as $key => $param ) {
				// 'uri' is the page URL getEventUri() reads, not a TikTok field.
				if ( $key === 'uri' ) {
					continue;
				}
				$serverEvent->$key = $param;
			}
		}
        $serverEvent->event_id = $event->payload[ 'eventID' ] ?? $event->payload[ 'event_id' ] ?? '';

        return $serverEvent;
    }

	/**
	 * Get user data for TikTok event
	 *
	 * @param int|null $wooOrder WooCommerce order ID
	 * @param int|null $eddOrder EDD order ID
	 * @return \stdClass User data object
	 */
    protected function getUserData( $wooOrder = null, $eddOrder = null ) {

        $userData = new \stdClass;
        $userData->user = new \stdClass;
        $user = wp_get_current_user();

        // The order supplies the customer's IP and user agent; guarded because
        // $wooOrder can arrive from the client payload on a site without Woo.
        $signalOrder = null;
        if ( $wooOrder && PixelYourSite\isWooCommerceActive() ) {
            $signalOrder = wc_get_order( $wooOrder ) ?: null;
        } elseif ( $eddOrder && PixelYourSite\isEddActive() ) {
            $signalOrder = pys_edd_order_signal_source( $eddOrder );
        }

        // In wp-admin (e.g. an order status change) the request is the
        // administrator's: its cookies must not be read for the buyer's event.
        $this->requestCookies = pys_event_client_signals( $signalOrder, '', null, pys_is_admin_page_request() )[ 'request_cookies' ];

        /**
         * Add purchase WooCommerce Advanced Matching params
         */
        // An order in the payload decides the branch on its own, whatever the
        // Purchase switch says: the alternative is the current user's profile,
        // which in wp-admin, cron or Action Scheduler is not the buyer.
        $orderBound = false;

        if ( PixelYourSite\isWooCommerceActive() && ( $wooOrder || ( isEventEnabled( 'woo_purchase_enabled' ) && PYS()->woo_is_order_received_page() && wooIsRequestContainOrderId() ) ) ) {
            $orderBound = true;

            if ( wooIsRequestContainOrderId() ) {
                $order_id = wooGetOrderIdFromRequest();
            } else {
                $order_id = $wooOrder;
            }

            $order = wc_get_order( $order_id );

            if ( $order ) {
                $signalOrder = $order;

                if ( PixelYourSite\isWooCommerceVersionGte( '3.0.0' ) ) {
                    $user_email = $order->get_billing_email();
                    $user_phone = $order->get_billing_phone();

                } else {
                    $user_email = $order->billing_email;
                    $user_phone = $order->billing_phone;
                }

                $user_persistence_data = get_persistence_user_data( $user_email, '', '', $user_phone );
                if ( !empty( $user_persistence_data[ 'em' ] ) ) $userData->user->email = hash( 'sha256', mb_strtolower( $user_persistence_data[ 'em' ] ), false );
                if ( !empty( $user_persistence_data[ 'tel' ] ) ) $userData->user->phone_number = hash( 'sha256', preg_replace( '/[^0-9]/', '', $user_persistence_data[ 'tel' ] ), false );

                // TikTok takes one external_id string: the first of the order's
                // ids (the browser id saved on the order, else the customer's).
                if ( PixelYourSite\isWooCommerceVersionGte( '3.0.0' ) ) {
                    $stored_id = $order->get_meta( 'external_id' );
                } else {
                    $stored_id = get_post_meta( $order_id, 'external_id', true );
                }
                $external_ids = PixelYourSite\pys_get_order_external_ids( $stored_id, $order->get_user_id() );
                if ( !empty( $external_ids ) ) {
                    $userData->user->external_id = $external_ids[ 0 ];
                }

                // Values snapshotted on the order at checkout time win: a queued
                // or delayed Purchase runs in a request that carries none of the
                // buyer's cookies.
                $userData = $this->applyOrderIdentifiers( $userData, $order_id );

            } else {
                $userData = $this->getRegularUserData();
            }

        } else {

            if ( PixelYourSite\isEddActive() && ( $eddOrder || ( isEventEnabled( 'edd_purchase_enabled' ) && edd_is_success_page() ) ) ) {
                $orderBound = true;

                if ( $eddOrder ) $payment_id = $eddOrder; else {
                    $payment_key = getEddPaymentKey();
                    $payment_id = (int) edd_get_purchase_id_by_key( $payment_key );
                }

                $user_persistence_data = get_persistence_user_data( edd_get_payment_user_email( $payment_id ), '', '', '' );
                if ( !empty( $user_persistence_data[ 'em' ] ) ) $userData->user->email = hash( 'sha256', mb_strtolower( $user_persistence_data[ 'em' ] ), false );
                if ( !empty( $user_persistence_data[ 'tel' ] ) ) $userData->user->phone_number = hash( 'sha256', preg_replace( '/[^0-9]/', '', $user_persistence_data[ 'tel' ] ), false );

                // First of the payment's ids; see the Woo branch.
                if ( $payment_id > 0 ) {
                    $external_ids = PixelYourSite\pys_get_order_external_ids(
                        edd_get_payment_meta( $payment_id, 'external_id', true ),
                        (int) edd_get_payment_user_id( $payment_id )
                    );
                    if ( !empty( $external_ids ) ) {
                        $userData->user->external_id = $external_ids[ 0 ];
                    }
                }

                // The EDD order carries the same snapshot as the Woo order; the
                // live request only fills the gaps.
                $userData = $this->applyOrderIdentifiers( $userData, $payment_id, 'edd' );

            } else {
                $userData = $this->getRegularUserData();
            }
        }

        // An event without an order names the current visitor. An order-bound
        // one never does: the current user is the admin or nobody (cron).
        if ( !$orderBound && PixelYourSite\EventsManager::isTrackExternalId() && !isset($userData->user->external_id)){
            if($user && $user->get( 'external_id' )){
                $userData->user->external_id = $user->get( 'external_id' );
            } elseif (PixelYourSite\PYS()->get_pbid()) {
                $userData->user->external_id = PixelYourSite\PYS()->get_pbid();
            }
        }

        // Order values win, the request stands in only outside wp-admin; see
        // includes/functions-event-signals.php. Omitted when empty (getIpAddress()
        // is '' unless routable).
        $signals = pys_event_client_signals( $signalOrder, self::getIpAddress(), self::getHttpUserAgent(), pys_is_admin_page_request() );
        $userData = Helpers\applyClientSignals( $userData, $signals );

        return apply_filters( "pys_tiktok_server_user_data", $userData );
    }

	private function getRegularUserData() {
		$user = wp_get_current_user();
		$userData = new \stdClass;
		$userData->user = new \stdClass;
		$user_email = $user_phone = '';

		if ( $user->ID ) {
			// get user regular data
			$user_email = $user->get( 'user_email' );

			/**
			 * Add common WooCommerce Advanced Matching params
			 */
			if ( PixelYourSite\isWooCommerceActive() ) {
				$user_phone = $user->get( 'billing_phone' );
			}
		}

		$user_persistence_data = get_persistence_user_data( $user_email, '', '', $user_phone );
		if ( !empty( $user_persistence_data[ 'em' ] ) ) $userData->user->email = hash( 'sha256', mb_strtolower( $user_persistence_data[ 'em' ] ), false );
		if ( !empty( $user_persistence_data[ 'tel' ] ) ) $userData->user->phone_number = hash( 'sha256', preg_replace( '/[^0-9]/', '', $user_persistence_data[ 'tel' ] ), false );

		return $this->applyTikTokIdentifiers( $userData );
	}

	/**
	 * Make sure a click id seen in this request survives the rest of the visit.
	 *
	 * Writes `pys_ttclid` when the URL carries a click id that differs from the
	 * stored one, so a new ad click replaces an old one. The SDK's own `ttclid`
	 * cookie is never written.
	 *
	 * @return void
	 */
	private function captureTtclid() {

		if ( !Consent()->checkConsent( 'tiktok' ) ) {
			return;
		}

		$ttclid = Helpers\getTtclidFromUrl();

		if ( $ttclid === '' ) {
			return;
		}

		// Remember it for this request even when the cookie cannot be written.
		self::setTtclid( $ttclid );

		// A new click has to replace the stored one. Later requests carry no
		// ttclid in the URL and read the cookie back, so a stale value there
		// credits the previous ad for every event after the landing page.
		// Compared against our own cookie — the only one we write, and the one
		// that outlives the SDK's.
		if ( Helpers\getStoredTtclid() !== $ttclid ) {
			Helpers\setTtclidCookie( $ttclid );
		}
	}

	/**
	 * @param string $ttclid
	 * @return void
	 */
	public static function setTtclid( $ttclid ) {
		self::$ttclid = is_string( $ttclid ) ? $ttclid : '';
	}

	/**
	 * The click id for this request.
	 *
	 * The value captured from the URL by captureTtclid() comes first, because a
	 * brand new ad click has to beat a cookie left over from an earlier one.
	 * The URL itself is never read here: like ServerEventHelper::getFbc(), this
	 * reports only what consent already allowed us to keep.
	 *
	 * @return string Empty string when no click id is known.
	 */
	public static function getTtclid() {

		if ( self::$ttclid !== '' ) {
			return self::$ttclid;
		}

		return Helpers\getTtclidFromCookie();
	}

	/**
	 * Attach the TikTok browser identifiers to a user data object.
	 *
	 * Every branch of getUserData() needs the same two values, which is why the
	 * three copies of this block were folded into one. Values already present are
	 * left alone, so a stronger source (the order snapshot, or the browser
	 * payload) keeps precedence.
	 *
	 * @param \stdClass $userData
	 * @return \stdClass
	 */
	private function applyTikTokIdentifiers( $userData ) {
		// getTtclid() is only consulted when the request may be read at all.
		return Helpers\applyRequestIdentifiers(
			$userData,
			$this->requestCookies,
			$this->requestCookies ? self::getTtclid() : ''
		);
	}

	/**
	 * Prefer the identifiers snapshotted on the order at checkout time, then fill
	 * the gaps from the live request.
	 *
	 * @param \stdClass $userData
	 * @param int       $order_id
	 * @param string    $type     'woo' or 'edd'.
	 * @return \stdClass
	 */
	private function applyOrderIdentifiers( $userData, $order_id, $type = 'woo' ) {

		$ttp = $this->getTtStatFromOrder( 'ttp', $order_id, $type );
		if ( $ttp !== '' ) {
			$userData->user->ttp = $ttp;
		}

		$ttclid = $this->getTtStatFromOrder( 'ttclid', $order_id, $type );
		if ( $ttclid !== '' ) {
			$userData->user->ttclid = $ttclid;
		}

		return $this->applyTikTokIdentifiers( $userData );
	}

	/**
	 * Read one identifier for the order through OrderIdentity: the order's own
	 * snapshot, then its parent order, then the buyer's user store.
	 *
	 * @param string $key
	 * @param int    $order_id
	 * @param string $type     'woo' or 'edd'.
	 * @return string Empty string when none of them has the identifier.
	 */
	private function getTtStatFromOrder( $key, $order_id, $type = 'woo' ) {

		if ( !$order_id ) {
			return '';
		}

		$identity = OrderIdentity::get( $type, $order_id, $key );

		if ( 'parent' === $identity['source'] || 'user' === $identity['source'] ) {
			Tiktok()->getLog()->debug( 'identity: ' . $key . ' from ' . $identity['source'] . ' for ' . $type . ' #' . $order_id );
		}

		return $identity['value'];
	}

	/**
	 * Snapshot the TikTok identifiers on the order at checkout time.
	 *
	 * Mirrors FacebookServer::saveFbTagsInOrder(): a Purchase sent later from the
	 * queue, from a webhook or from an admin status change runs in a request
	 * without the buyer's cookies, so the click id has to be stored while it is
	 * still readable.
	 *
	 * @param int|\WC_Order $order_param Order ID, or the order object passed by
	 *                                   the Store API hook.
	 * @return void
	 */
	public function saveTtTagsInOrder( $order_param ) {

		$pysData = array(
			'ttp'    => Helpers\getTtp(),
			'ttclid' => self::getTtclid(),
		);

		// Determine whether the WC_Order object or order ID is passed
		if ( $order_param instanceof \WC_Order ) {
			$order = $order_param;
		} else {
			$order = wc_get_order( $order_param );
		}

		if ( isWooCommerceVersionGte( '3.0.0' ) && !empty( $order ) ) {
			// WooCommerce >= 3.0
			$order->update_meta_data( 'pys_tt_cookie', $pysData );
			$order->save();
		} elseif ( !empty( $order_param ) ) {
			// WooCommerce < 3.0
			update_post_meta( $order_param, 'pys_tt_cookie', $pysData );
		}
	}

	/**
	 * Snapshot the TikTok identifiers on an EDD order, as saveTtTagsInOrder()
	 * does for Woo: a webhook, cron or wp-admin sends the Purchase later without
	 * the buyer's cookies.
	 *
	 * @param int $payment_id
	 * @return void
	 */
	public function saveTtTagsInEddOrder( $payment_id ) {

		if ( !pys_edd_order_snapshot_allowed( $payment_id ) || !function_exists( 'edd_update_payment_meta' ) ) {
			return;
		}

		$pysData = array(
			'ttp'    => Helpers\getTtp(),
			'ttclid' => self::getTtclid(),
		);

		edd_update_payment_meta( (int) $payment_id, 'pys_tt_cookie', $pysData );
	}

	/**
	 * Fills the cookie snapshot the checkout request could not write, when the
	 * gateway completes the payment in a request where the buyer is present.
	 * Never overwrites a stored value; an empty pair writes nothing.
	 *
	 * @param int $payment_id
	 * @return void
	 */
	public function fillTtTagsInEddOrder( $payment_id ) {

		pys_edd_fill_snapshot( $payment_id, 'pys_tt_cookie', array(
			'ttp'    => Helpers\getTtp(),
			'ttclid' => self::getTtclid(),
		) );
	}

	private function paramsToCustomData( $data ) {

		$custom_data = new \stdClass;
		if ( isset( $data[ 'quantity' ] ) ) {
			$data_line_items = array();
			$data_line_items[ 'quantity' ] = $data[ 'quantity' ];
			if ( isset( $data[ 'value' ] ) ) {
				$data_line_items[ 'price' ] = $data[ 'value' ];
			}
			if ( isset( $data[ 'content_id' ] ) ) {
				$data_line_items[ 'content_id' ] = $data[ 'content_id' ];
			}

			if ( isset( $data[ 'content_category' ] ) ) {
				$data_line_items[ 'content_category' ] = $data[ 'content_category' ];
			}

			if ( isset( $data[ 'content_name' ] ) ) {
				$data_line_items[ 'content_name' ] = $data[ 'content_name' ];
			}

			if ( isset( $data[ 'content_type' ] ) ) {
				$data_line_items[ 'content_type' ] = $data[ 'content_type' ];
			} else {
				$data_line_items[ 'content_type' ] = 'product';
			}

			$data[ 'contents' ][] = $data_line_items;
			if ( isset( $data[ 'currency' ] ) ) {
				$custom_data->currency = $data[ 'currency' ];
			}
		}

		if ( isset( $data[ 'contents' ] ) && is_array( $data[ 'contents' ] ) ) {
			$contents = array();
			$cost = 0;
			$custom_data->content_type = $data[ 'content_type' ];

			foreach ( $data[ 'contents' ] as $c ) {
				if ( isset( $c[ 'quantity' ] ) ) {
					$contents[] = array(
						'quantity'         => (int) $c[ 'quantity' ],
						'price'            => isset( $c[ 'price' ] ) ? strval( $c[ 'price' ] ) : '',
						'content_id'       => $c[ 'content_id' ],
						'content_category' => $c[ 'content_category' ] ?? '',
						'content_name'     => $c[ 'content_name' ] ?? '',
					);

					$cost += $c[ 'quantity' ] * ( $c[ 'price' ] ?? 0 );
				}
			}

			$custom_data->contents = $contents;
			$custom_data->value = $cost;
			if ( isset( $data[ 'currency' ] ) ) {
				$custom_data->currency = $data[ 'currency' ];
			}
		}

		if ( !empty( $_GET[ 's' ] ) ) {
			$custom_data->query = sanitize_text_field( wp_unslash( $_GET['s'] ) );
		}

		return apply_filters( "pys_tiktok_server_custom_data", $custom_data );
	}
}

/**
 * @return TikTokServer
 */
function TikTokServer() {
	return TikTokServer::instance();
}

TikTokServer();