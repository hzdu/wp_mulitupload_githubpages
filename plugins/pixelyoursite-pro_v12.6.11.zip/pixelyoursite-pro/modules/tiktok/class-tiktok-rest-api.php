<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * TikTok REST API handler
 *
 * Extends AbstractRestAPI to handle TikTok server events via REST API
 */
class TikTok_REST_API extends AbstractRestAPI {

    /**
     * Get the REST API namespace
     *
     * @return string
     */
    protected function getRestNamespace() {
        return 'pys-tiktok/v1';
    }

    /**
     * Get the server instance for TikTok
     *
     * @return TikTokServer
     */
    protected function getServerInstance() {
        return TikTokServer();
    }

    /**
     * Get the pixel instance for TikTok
     *
     * @return Tiktok
     */
    protected function getPixelInstance() {
        return Tiktok();
    }

    /**
     * Check if TikTok server API is enabled
     *
     * @return bool
     */
    protected function isServerApiEnabled() {
        return Tiktok()->isServerApiEnabled();
    }

    /**
     * Get the localized script variable name
     *
     * @return string
     */
    protected function getScriptVariableName() {
        return 'pysTikTokRest';
    }

    /**
     * Convert data to SingleEvent object
     * TikTok uses 'event_id' instead of 'eventID' in payload
     *
     * @param string   $event_name Event name
     * @param array    $params     Event parameters
     * @param string   $event_id   Event ID
     * @param array    $ids        Pixel IDs
     * @param int|null $woo_order  WooCommerce order ID
     * @param int|null $edd_order  EDD order ID
     * @param string   $event_slug Event slug
     * @return SingleEvent
     */
    protected function data_to_single_event( $event_name, $params, $event_id, $ids, $woo_order, $edd_order, $event_slug = '' ) {
        $single_event = new SingleEvent( $event_slug, '' );

        // Make sure params and ids are arrays
        if ( ! is_array( $params ) ) {
            $params = [];
        }

        if ( ! is_array( $ids ) ) {
            $ids = [];
        }

        // Process order IDs
        $woo_order_id = is_numeric( $woo_order ) ? (int) $woo_order : 0;
        $edd_order_id = is_numeric( $edd_order ) ? (int) $edd_order : 0;

        // TikTok uses 'event_id' instead of 'eventID'
        $payload = [
            'name'      => $event_name,
            'event_id'  => $event_id,
            'woo_order' => $woo_order_id,
            'edd_order' => $edd_order_id,
            'pixelIds'  => $ids,
        ];
        // Server-only marker of the order-status path: a request may not carry it.
        unset( $params['advanced_purchase_tracking'] );
        $single_event->addParams( $params );
        $single_event->addPayload( $payload );

        return $single_event;
    }

    /**
     * Extend the abstract args with `event_source_url`, the page the event happened on.
     */
    protected function get_event_args() {
        $args = parent::get_event_args();
        $args['event_source_url'] = [
            'required'          => false,
            'type'              => 'string',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ];
        return $args;
    }

    /**
     * The page URL the browser reported (else this request's Referer: for a
     * fetch/sendBeacon from the visitor's page that IS the page) becomes the
     * event's page, never the REST endpoint.
     */
    protected function apply_request_context( $request, $single_event ) {
        $event_source_url = $request->get_param( 'event_source_url' );
        if ( empty( $event_source_url ) ) {
            $referer = $request->get_header( 'referer' );
            if ( ! empty( $referer ) ) {
                $event_source_url = esc_url_raw( $referer );
            }
        }

        if ( ! empty( $event_source_url ) && pys_is_valid_public_url( $event_source_url ) ) {
            $single_event->addPayload( [ 'event_source_url' => $event_source_url ] );
            // getEventUri() returns params['uri'] as is: cut the query here.
            $uri = $event_source_url;
            if ( PYS()->getOption( 'enable_remove_source_url_params' ) ) {
                $list = explode( '?', $uri );
                $uri  = $list[0];
            }
            $single_event->addParams( [ 'uri' => $uri ] );
        }
    }
}

/**
 * Accessor function for TikTok REST API
 *
 * @return TikTok_REST_API
 */
function TikTok_REST_API() {
    static $instance = null;
    if ( $instance === null ) {
        $instance = new TikTok_REST_API();
    }
    return $instance;
}
