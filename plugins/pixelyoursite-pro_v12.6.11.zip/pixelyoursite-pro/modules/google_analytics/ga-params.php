<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * GA4 accepts at most 25 parameters per event. This class holds the keys PYS
 * no longer sends to GA4, the priority tier of every known key, and the cap.
 * Pure PHP, no WordPress calls.
 */
class GaParams {

    const LIMIT = 25;

    /** Never counted and never dropped. */
    const UNCOUNTED = array( 'items', 'send_to', 'event_callback' );

    /** Keys GA4 events no longer carry. */
    const REMOVED = array(
        'ecomm_prodid', 'ecomm_pagetype', 'ecomm_totalvalue',
        'dynx_itemid', 'dynx_pagetype', 'dynx_totalvalue',
        'aw_merchant_id', 'aw_feed_label', 'aw_feed_language', 'aw_feed_country',
        'shipping_tier',
        'event_category', 'event_id',
        'analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization',
    );

    /** Lower tier = dropped later. A key that is not listed is tier 4. */
    const TIERS = array(
        'transaction_id' => 1, 'value' => 1, 'currency' => 1,
        'session_id' => 1, 'session_number' => 1, 'engagement_time_msec' => 1,
        'tax' => 2, 'shipping' => 2, 'coupon' => 2, 'payment_method' => 2, 'fees' => 2,
        'new_customer' => 3, 'advanced_purchase_tracking' => 3, 'plugin' => 3,
        'page_title' => 3,
        'user_role' => 3, 'traffic_source' => 3, 'utm_source' => 3,
        'utm_medium' => 3, 'utm_campaign' => 3, 'landing_page' => 3,
        'utm_content' => 5, 'utm_term' => 5, 'event_hour' => 5,
        'event_day' => 5, 'event_month' => 5,
        'event_url' => 5, 'post_type' => 5, 'post_id' => 5,
    );

    const UNKNOWN_TIER = 4;

    const BUDGET_EVENTS = array( 'purchase', 'add_to_cart', 'custom_event' );

    /** Keys added to every event, browser and Measurement Protocol, by option. */
    const SHARED_OPTION_KEYS = array(
        'user_role'      => array( 'enable_user_role_param' ),
        'traffic_source' => array( 'track_traffic_source' ),
        'utm_source'     => array( 'track_utms' ),
        'utm_medium'     => array( 'track_utms' ),
        'utm_campaign'   => array( 'track_utms' ),
        'utm_content'    => array( 'track_utms' ),
        'utm_term'       => array( 'track_utms' ),
        'landing_page'   => array( 'track_utms', 'enable_lading_page_param' ),
        'event_day'      => array( 'enable_event_day_param' ),
        'event_month'    => array( 'enable_event_month_param' ),
        'event_hour'     => array( 'enable_event_time_param' ),
    );

    /** Page keys of the browser path only (EventsManager standard params), by option. */
    const PAGE_OPTION_KEYS = array(
        'page_title' => array( 'enable_page_title_param' ),
        'event_url'  => array( 'enable_event_url_param' ),
        'post_type'  => array( 'enable_post_type_param' ),
        'post_id'    => array( 'enable_post_id_param' ),
    );

    /** Woo purchase keys gated by EventsManager::filterEventParams(), browser and Measurement Protocol alike. */
    const WOO_PURCHASE_OPTION_KEYS = array(
        'tax'            => array( 'enable_woo_tax_param' ),
        'shipping'       => array( 'enable_woo_shipping_param' ),
        'fees'           => array( 'enable_woo_fees_param' ),
        'payment_method' => array( 'enable_woo_payment_method' ),
    );

    /** Always present on a purchase, browser and Measurement Protocol. */
    const PURCHASE_ALWAYS_KEYS = array( 'transaction_id', 'value', 'currency', 'coupon' );

    /** Present only on the Measurement Protocol purchase. */
    const SERVER_PURCHASE_KEYS = array( 'session_id', 'session_number', 'engagement_time_msec', 'advanced_purchase_tracking' );

    /**
     * Names of the parameters a custom event really sends: standard parameters
     * with a value plus custom parameters with a name.
     *
     * @param array $params        name => value (a value may be array( 'value' => ... )).
     * @param array $custom_params list of array( 'name' => ..., 'value' => ... ).
     * @return array name => true
     */
    public static function ownParams( array $params, array $custom_params ): array {
        $out = array();
        foreach ( $params as $name => $value ) {
            $raw = is_array( $value ) ? ( $value['value'] ?? '' ) : $value;
            if ( null !== $raw && '' !== (string) $raw ) {
                $out[ (string) $name ] = true;
            }
        }
        foreach ( $custom_params as $param ) {
            if ( is_array( $param ) && ! empty( $param['name'] ) ) {
                $out[ (string) $param['name'] ] = true;
            }
        }
        return $out;
    }

    /**
     * Keys the custom-event builder (GA::getCustomEventData()) adds on top of the
     * event's own parameters: the purchase trigger's value/currency/transaction_id,
     * the add-to-cart trigger's currency/value/quantity, and the order data when
     * "track cart data" is on (payment_method only when its option is on, an empty
     * one is stripped). Reads the CustomEvent object; no WordPress calls when
     * $options is an array.
     *
     * @param object     $event   CustomEvent.
     * @param array|null $options flat option_name => value; null reads PYS().
     * @return array name => true
     */
    public static function eventExtraKeys( $event, ?array $options = null ): array {
        $out = array();
        foreach ( (array) $event->getTriggers() as $trigger ) {
            $type = $trigger->getTriggerType();
            if ( 'purchase' === $type ) {
                if ( $trigger->getTrackValueAndCurrency() ) {
                    $out['value']    = true;
                    $out['currency'] = true;
                }
                if ( $trigger->getTrackTransactionID() ) {
                    $out['transaction_id'] = true;
                }
            } elseif ( 'add_to_cart' === $type && $trigger->getTrackValueAndCurrency() ) {
                $out['currency'] = true;
                $out['value']    = true;
                $out['quantity'] = true;
            }
        }
        if ( $event->ga_ads_track_cart_woo_data ) {
            foreach ( array( 'transaction_id', 'value', 'currency', 'tax', 'shipping', 'coupon' ) as $key ) {
                $out[ $key ] = true;
            }
            if ( null === $options && function_exists( 'PixelYourSite\PYS' ) ) {
                $options = array( 'enable_woo_payment_method' => PYS()->getOption( 'enable_woo_payment_method' ) );
            }
            if ( ! empty( $options['enable_woo_payment_method'] ) ) {
                $out['payment_method'] = true;
            }
        }
        return $out;
    }

    /**
     * Prints "<label>: X / 25 parameters" and, above the limit, a warning that
     * names the option groups to turn off. Read-only; the save is never blocked.
     */
    public static function renderBudget( string $label, int $count ): void {
        echo '<p class="text-gray mt-16 pys-ga4-param-budget">';
        echo esc_html( sprintf(
            /* translators: 1: event label, 2: parameter count, 3: GA4 limit */
            __( '%1$s: %2$d / %3$d parameters', 'pys' ),
            $label,
            $count,
            self::LIMIT
        ) );
        echo '</p>';
        if ( $count > self::LIMIT ) {
            echo '<div class="critical_message mt-8">';
            echo esc_html__( 'GA4 accepts 25 parameters per event; the extra ones are dropped, lowest priority first, and then some orders carry a parameter and others do not. Turn off some of: Event day/month/hour, UTM parameters, Traffic source, User role, Page title / Event URL / Post type / Post ID, WooCommerce tax / shipping / payment method / fees parameters, global custom parameters.', 'pys' );
            echo '</div>';
        }
    }

    /**
     * Option names budget() reads when it is called without an options array.
     */
    public static function budgetOptionNames(): array {
        $names = array();
        foreach ( array_merge( self::WOO_PURCHASE_OPTION_KEYS, self::SHARED_OPTION_KEYS, self::PAGE_OPTION_KEYS ) as $opts ) {
            $names = array_merge( $names, $opts );
        }
        return array_values( array_unique( $names ) );
    }

    /**
     * Worst-case number of parameters one GA4 hit can receive for an event with
     * the given settings. A hit goes through one of two paths, so the result is
     * the larger of the two:
     * - browser: plugin, shared option keys, page keys (page_title, event_url,
     *   post_type, post_id, each by its option), the GA Tags global custom
     *   parameters, the event's own parameters and the event keys (purchase:
     *   transaction_id, value, currency, coupon, plus tax/shipping/fees/
     *   payment_method by option; add_to_cart: value, currency);
     * - server (purchase only, Measurement Protocol): the same purchase keys and
     *   Woo options (filterEventParams() gates both paths), plus session_id,
     *   session_number, engagement_time_msec and advanced_purchase_tracking,
     *   shared, plugin and global custom parameters; no page keys.
     * new_customer is never sent to GA4, so it is not counted.
     * Removed and uncounted keys are not counted.
     *
     * @param string     $event_name    purchase, add_to_cart or custom_event; any other name counts the shared keys plus the browser page keys.
     * @param array      $custom_params the event's own parameters (name => value).
     * @param array|null $options       flat option_name => value; null reads the live options.
     */
    public static function budget( string $event_name, array $custom_params = array(), ?array $options = null ): int {
        if ( null === $options ) {
            $options = self::liveOptions();
        }
        $on = function ( array $names ) use ( $options ) {
            foreach ( $names as $name ) {
                if ( ! empty( $options[ $name ] ) ) {
                    return true;
                }
            }
            return false;
        };

        $keys = array( 'plugin' => true );
        foreach ( self::SHARED_OPTION_KEYS as $key => $names ) {
            if ( $on( $names ) ) {
                $keys[ $key ] = true;
            }
        }

        $server = null;
        $browser = $keys;
        foreach ( self::PAGE_OPTION_KEYS as $key => $names ) {
            if ( $on( $names ) ) {
                $browser[ $key ] = true;
            }
        }

        if ( 'purchase' === $event_name ) {
            $server = $keys;
            foreach ( self::PURCHASE_ALWAYS_KEYS as $key ) {
                $server[ $key ]  = true;
                $browser[ $key ] = true;
            }
            foreach ( self::SERVER_PURCHASE_KEYS as $key ) {
                $server[ $key ] = true;
            }
            foreach ( self::WOO_PURCHASE_OPTION_KEYS as $key => $names ) {
                if ( $on( $names ) ) {
                    $server[ $key ]  = true;
                    $browser[ $key ] = true;
                }
            }
        } elseif ( 'add_to_cart' === $event_name ) {
            $browser['value']    = true;
            $browser['currency'] = true;
        }

        $extra = array();
        // GA::applyGlobalCustomParams() skips custom events.
        if ( 'custom_event' !== $event_name && ! empty( $options['ga_global_custom_params'] ) && is_array( $options['ga_global_custom_params'] ) ) {
            foreach ( $options['ga_global_custom_params'] as $param ) {
                if ( empty( $param['name'] ) || ! empty( $param['page_view_only'] ) ) {
                    continue;
                }
                $extra[ (string) $param['name'] ] = true;
            }
        }

        foreach ( $custom_params as $name => $value ) {
            if ( '' === (string) $name ) {
                continue;
            }
            $extra[ (string) $name ] = true;
        }

        $drop  = array_flip( array_merge( self::REMOVED, self::UNCOUNTED ) );
        $count = function ( array $set ) use ( $extra, $drop ) {
            return count( array_diff_key( $set + $extra, $drop ) );
        };

        $result = $count( $browser );
        if ( null !== $server ) {
            $result = max( $result, $count( $server ) );
        }
        return $result;
    }

    /**
     * Live values of the options budget() reads (the plugin settings).
     */
    public static function liveOptions(): array {
        $options = array();
        if ( function_exists( 'PixelYourSite\PYS' ) ) {
            foreach ( self::budgetOptionNames() as $name ) {
                $options[ $name ] = PYS()->getOption( $name );
            }
        }
        if ( function_exists( 'PixelYourSite\GATags' ) ) {
            $options['ga_global_custom_params'] = GATags()->getGlobalCustomParams();
        }
        return $options;
    }

    /**
     * Drops the removed keys and an empty coupon or payment_method.
     */
    public static function strip( array $params ): array {
        foreach ( self::REMOVED as $key ) {
            unset( $params[ $key ] );
        }
        foreach ( array( 'coupon', 'payment_method' ) as $key ) {
            if ( array_key_exists( $key, $params ) && ( '' === $params[ $key ] || null === $params[ $key ] ) ) {
                unset( $params[ $key ] );
            }
        }
        return $params;
    }

    /**
     * Keeps the first LIMIT counted keys ordered by tier (stable inside a tier).
     * Uncounted keys pass through. Original key order is kept in the output.
     *
     * @return array{params: array, dropped: string[]}
     */
    public static function cap( array $params ): array {
        $counted = array();
        $pos     = 0;
        foreach ( $params as $key => $value ) {
            if ( in_array( $key, self::UNCOUNTED, true ) ) {
                continue;
            }
            $counted[ $key ] = array( self::TIERS[ $key ] ?? self::UNKNOWN_TIER, $pos++ );
        }

        if ( count( $counted ) <= self::LIMIT ) {
            return array( 'params' => $params, 'dropped' => array() );
        }

        uasort( $counted, function ( $a, $b ) {
            return $a[0] === $b[0] ? $a[1] - $b[1] : $a[0] - $b[0];
        } );

        $dropped = array_slice( array_keys( $counted ), self::LIMIT );
        foreach ( $dropped as $key ) {
            unset( $params[ $key ] );
        }

        return array( 'params' => $params, 'dropped' => array_map( 'strval', $dropped ) );
    }

    /**
     * Settings the browser side needs to apply the same cap.
     */
    public static function jsConfig(): array {
        return array(
            'limit'        => self::LIMIT,
            'tiers'        => self::TIERS,
            'removed'      => self::REMOVED,
            'uncounted'    => self::UNCOUNTED,
            'unknown_tier' => self::UNKNOWN_TIER,
        );
    }
}
