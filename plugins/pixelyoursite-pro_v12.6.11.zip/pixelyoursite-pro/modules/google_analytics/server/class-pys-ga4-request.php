<?php
namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PYS_PRO_GLOBAL\Br33f\Ga4\MeasurementProtocol\Dto\Request\BaseRequest;

/**
 * A Measurement Protocol request that can also carry the buyer's IP address and
 * user agent. The vendored BaseRequest has no setters for them; the legacy
 * Service::setIpOverride() would send the Universal Analytics "uip" query
 * parameter instead of the request-body field GA4 reads.
 */
class PysGa4Request extends BaseRequest {

	/** @var string */
	protected $ipOverride = '';

	/** @var string */
	protected $userAgent = '';

	/**
	 * @param string $ip
	 * @return $this
	 */
	public function setIpOverride( $ip ) {
		$this->ipOverride = (string) $ip;
		return $this;
	}

	/**
	 * @param string $userAgent
	 * @return $this
	 */
	public function setUserAgent( $userAgent ) {
		$this->userAgent = (string) $userAgent;
		return $this;
	}

	/**
	 * @return array
	 */
	public function export(): array {
		$export = parent::export();
		if ( '' !== $this->ipOverride ) {
			$export['ip_override'] = $this->ipOverride;
		}
		if ( '' !== $this->userAgent ) {
			$export['user_agent'] = $this->userAgent;
		}
		return $export;
	}
}
