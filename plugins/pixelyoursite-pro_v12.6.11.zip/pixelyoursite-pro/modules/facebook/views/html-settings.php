<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="cards-wrapper cards-wrapper-style2 gap-24 logs-wrapper">
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('General', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center mb-4">
                        <?php Facebook()->render_switcher_input( 'advanced_matching_enabled' ); ?>
                        <h4 class="switcher-label secondary_heading">Enable Advanced Matching</h4>
                    </div>
                </div>

                <div class="facebook-description">
                    <p class="text-gray pb-8">
                        <?php _e('Learn about Conversion API and Advanced Matching privacy and consent:', 'pys');?>
                        <a href="https://www.youtube.com/watch?v=PsKdCkKNeLU" target="_blank"
                           class="link">watch video</a>
                    </p>
                </div>
                <div>
                    <div class="d-flex align-items-center mb-4">
                        <?php Facebook()->render_switcher_input( 'remove_metadata' ); ?>
                        <h4 class="switcher-label secondary_heading">autoConfig: false</h4>
                    </div>
                    <p class="text-gray"><?php _e('Remove Facebook default events', 'pys');?> </p>
                </div>

                <div>
                    <div class="d-flex align-items-center">
                        <?php Facebook()->render_switcher_input( 'disable_noscript' ); ?>
                        <h4 class="switcher-label secondary_heading"> <?php _e('Disable noscript', 'pys');?> </h4>
                    </div>
                </div>

                <div>
                    <div class="d-flex align-items-center mb-4">
                        <?php Facebook()->render_switcher_input( 'first_request_cookies' ); ?>
                        <h4 class="switcher-label secondary_heading"><?php _e('Write _fbp and _fbc on the first page view', 'pys');?></h4>
                    </div>
                    <p class="text-gray"><?php _e('The server sets these cookies in the page response, so forms and scripts that read them while the page loads (hidden form fields, for example) get them on a visitor\'s first visit too. When "Track domains and subdomains together" is ON, the cookie domain must be known (see Cookie domain in the general settings). Do not enable it if a full-page cache stores Set-Cookie headers together with the page.', 'pys');?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="card card-style6 card-static">
        <div class="card-header card-header-style2 d-flex justify-content-between align-items-center">
            <h4 class="secondary_heading_type2"><?php _e('Medical Content', 'pys');?></h4>
        </div>
        <div class="card-body">
            <div class="gap-24">
                <div>
                    <div class="d-flex align-items-center mb-4">
                        <?php Facebook()->render_switcher_input( 'enabled_medical' ); ?>
                        <h4 class="switcher-label"><?php _e('Don\'t track parameters', 'pys');?></h4>
                    </div>
                </div>

                <div>
                    <p class="mb-8">
                        Meta imposes restrictions on tracking data for websites with medical-related content and products. Use this option to disable event parameters that might track such data. These settings apply to Meta Pixel and CAPI events. To disable parameters for all tags, use the default parameter controls.
                    </p>
                    <p>
                        If you need to replace the standard WooCommerce AddToCart or Purhcase events with custom events, you can do it on the <a class="link" href="<?= buildAdminUrl('pixelyoursite', 'events') ?>">Events Page</a>.
                    </p>
                </div>

                <div>
                    <h4 class="primary_heading mb-4"><?php _e('Don\'t track these parameters for the Meta pixel and CAPI events:', 'pys');?></h4>
                    <?php Facebook()->render_multi_select_input('do_not_track_medical_param', getAllMetaEventParamName()); ?>
                    <p class="text-gray mt-8"><?php _e('If you want to disable parameters for all tags, use the default options from the plugin\'s main page, or from the WooCommerce and EDD pages.', 'pys');?></p>
                </div>
            </div>
        </div>
    </div>
</div>