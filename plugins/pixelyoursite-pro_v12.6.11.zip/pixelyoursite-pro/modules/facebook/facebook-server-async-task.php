<?php
namespace PixelYourSite;

defined('ABSPATH') or die('Direct access not allowed');

/**
 * Facebook Async Task Handler
 *
 * Extends AbstractAsyncTask to handle Facebook server events asynchronously
 */
class FacebookAsyncTask extends AbstractAsyncTask {

    /**
     * Action name for this async task
     *
     * @var string
     */
    protected $action = 'pys_send_server_event';

    /**
     * Get the server instance for Facebook
     *
     * @return FacebookServer
     */
    protected function getServerInstance() {
        return FacebookServer();
    }

    /**
     * Get allowed classes for unserialization
     * Facebook uses specific SDK classes that need to be allowed
     *
     * @return array Array of allowed class names
     */
    protected function getAllowedClasses() {
        return [
            'stdClass',
            // mapEventToServerEvent() builds PysServerEvent (extends Event). An
            // unlisted class revives as __PHP_Incomplete_Class and the first
            // method call on it is an Error, not an Exception.
            'PixelYourSite\PysServerEvent',
            'PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\Event',
            'PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\UserData',
            'PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\CustomData',
            'PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\Content'
        ];
    }

    /**
     * Override run_action to ensure SDK classes are loaded before unserialize().
     */
    protected function run_action() {
        ServerEventHelper::requireServerSideClasses();
        parent::run_action();
    }
}