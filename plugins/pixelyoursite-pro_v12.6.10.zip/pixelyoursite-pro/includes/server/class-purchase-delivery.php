<?php
/**
 * Per-platform delivery state of a server Purchase (Advanced Deduplication).
 *
 * @package PixelYourSite
 */

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Tracks which pixels of a platform have accepted an order's server Purchase.
 *
 * _pys_purchase_event_fired only says the thank-you page built the browser
 * payload; nothing guarantees the browser sent it. In Advanced Deduplication the
 * server copies are therefore gated by what each platform actually accepted:
 *
 *   _pys_server_event_sent_{platform}    accepted pixels:
 *                                        array( 'event_id' => ..., 'pixels' => [...] ).
 *                                        A plain eventID string (written before
 *                                        12.6.8) means every pixel accepted it.
 *   _pys_server_event_pending_{platform} pixels a request is sending right now:
 *                                        array( 'event_id' => ..., 'pixels' => [ id => time ] ).
 *
 * A request claims the pixels it is about to send, so the browser AJAX copy and
 * the order-status fallback cannot both send the same Purchase — Meta does not
 * deduplicate two server events. A claim left by a request that died expires
 * after CLAIM_TTL seconds; a failed send drops its claim at once, so the pixel
 * stays retryable.
 */
class PurchaseDelivery {

    const CLAIM_TTL = 120;

    /**
     * Is this an order-bound purchase event in Advanced Deduplication mode?
     *
     * @param SingleEvent $event
     * @return array|null array( type, order_id, event_id ) or null
     */
    public static function getContext( $event ) {
        $event_name = $event->getId();

        if ( $event_name === 'woo_purchase' ) {
            $type     = 'woo';
            $order_id = isset( $event->payload['woo_order'] ) ? (int) $event->payload['woo_order'] : 0;
        } elseif ( $event_name === 'edd_purchase' || $event_name === 'edd_complete_payment' ) {
            $type     = 'edd';
            $order_id = isset( $event->payload['edd_order'] ) ? (int) $event->payload['edd_order'] : 0;
        } else {
            return null;
        }

        $event_id = isset( $event->payload['eventID'] ) ? (string) $event->payload['eventID'] : '';

        if ( ! $order_id || $event_id === '' || ! self::isAdvancedMode( $type ) ) {
            return null;
        }
        if ( $type === 'woo' && ! function_exists( 'wc_get_order' ) ) {
            return null;
        }
        if ( $type === 'edd' && ! function_exists( 'edd_get_payment_meta' ) ) {
            return null;
        }

        return array( $type, $order_id, $event_id );
    }

    /**
     * @param string $type 'woo' or 'edd'
     * @return bool
     */
    public static function isAdvancedMode( $type ) {
        return PYS()->getOption( "{$type}_purchase_on_transaction_mode", 'advanced' ) !== 'single';
    }

    /**
     * Platforms a thank-you page may confirm through the browser marker.
     */
    const MARKER_PLATFORMS = array( 'facebook', 'ga', 'google_ads', 'tiktok', 'pinterest', 'openai', 'bing', 'reddit' );

    const MARKER_GRACE = 120;

    /**
     * Record that the thank-you page built the browser Purchase. Call it only
     * where _pys_purchase_event_fired is first set.
     *
     * @param string         $type
     * @param int            $order_id
     * @param \WC_Order|null $order Woo: the caller's order object; the meta is
     *                              set on it and the caller saves it.
     */
    public static function markBrowserPending( $type, $order_id, $order = null ) {
        if ( $type === 'woo' ) {
            if ( ! $order && function_exists( 'wc_get_order' ) ) {
                $order = wc_get_order( $order_id );
                if ( $order ) {
                    $order->update_meta_data( '_pys_purchase_browser_pending', time() );
                    $order->save();
                }
                return;
            }
            if ( $order ) {
                $order->update_meta_data( '_pys_purchase_browser_pending', time() );
            }
            return;
        }

        if ( function_exists( 'edd_update_payment_meta' ) ) {
            edd_update_payment_meta( $order_id, '_pys_purchase_browser_pending', time() );
        }
    }

    /**
     * HMAC the thank-you page hands to the browser; it proves the sender saw
     * the page without exposing the order key.
     *
     * @return string Empty when the order or its key is unknown
     */
    public static function markerToken( $type, $order_id ) {
        $key = '';

        if ( $type === 'woo' && function_exists( 'wc_get_order' ) ) {
            $order = wc_get_order( $order_id );
            $key   = $order ? (string) $order->get_order_key() : '';
        } elseif ( $type === 'edd' && function_exists( 'edd_get_payment_key' ) ) {
            $key = (string) edd_get_payment_key( $order_id );
        }

        if ( $key === '' ) {
            return '';
        }

        return wp_hash( "pys_purchase_marker|{$type}|{$order_id}|{$key}" );
    }

    /**
     * Store the platforms the browser confirmed; the first time per platform is kept.
     *
     * @param string $type
     * @param int    $order_id
     * @param array  $platforms Already whitelisted slugs
     * @return bool False when the order is unknown or its page was never built
     */
    public static function recordBrowserMarker( $type, $order_id, array $platforms ) {
        $platforms = array_values( array_intersect( array_unique( $platforms ), self::MARKER_PLATFORMS ) );

        $result = self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platforms ) {
            if ( ! self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_pending' ) ) {
                return false;
            }

            $marker = self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_marker' );
            $marker = is_array( $marker ) ? $marker : array();
            $now    = time();
            $new    = false;
            foreach ( $platforms as $platform ) {
                if ( ! isset( $marker[ $platform ] ) ) {
                    $marker[ $platform ] = $now;
                    $new                 = true;
                }
            }

            if ( $new ) {
                self::writeMeta( $type, $order, $order_id, '_pys_purchase_browser_marker', $marker );
            }

            return true;
        } );

        return $result === true;
    }

    /**
     * Should the server send this platform's Purchase, given what the browser did?
     *
     * @param string         $type
     * @param int            $order_id
     * @param string         $platform
     * @param \WC_Order|null $order Woo order whose meta the caller read fresh
     * @return array array( 'decision' => skip|wait|send, 'wait' => seconds left )
     */
    public static function browserDecision( $type, $order_id, $platform, $order = null ) {
        if ( $type === 'woo' && ! $order ) {
            $order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
            if ( $order ) {
                $order->read_meta_data( true );
            }
        } elseif ( $type === 'edd' && function_exists( 'edd_get_payment_meta' ) ) {
            wp_cache_delete( $order_id, 'edd_order_meta' );
        }
        if ( $type === 'woo' && ! $order ) {
            return array( 'decision' => 'send', 'wait' => 0 );
        }

        $marker  = self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_marker' );
        $pending = (int) self::readMeta( $type, $order, $order_id, '_pys_purchase_browser_pending' );
        $fired   = self::readMeta( $type, $order, $order_id, '_pys_purchase_event_fired' );

        if ( is_array( $marker ) && isset( $marker[ $platform ] ) ) {
            return array( 'decision' => 'skip', 'wait' => 0 );
        }
        if ( ! $pending ) {
            // Built before the marker existed: the browser counts as fired.
            return array( 'decision' => $fired ? 'skip' : 'send', 'wait' => 0 );
        }

        $grace = (int) apply_filters( 'pys_purchase_marker_grace', self::MARKER_GRACE, $type, $order_id );
        $left  = $pending + $grace - time();

        return $left > 0
            ? array( 'decision' => 'wait', 'wait' => $left )
            : array( 'decision' => 'send', 'wait' => 0 );
    }

    /**
     * Single mode only: platforms the server already sent, kept for good so a
     * cron retry or a later status change does not send them again
     * (PurchaseDelivery claims cover Advanced).
     *
     * @param string         $type
     * @param int            $order_id
     * @param array          $platforms Platforms to add
     * @param \WC_Order|null $order     Woo order of the caller, saved by the caller
     * @return array The stored list
     */
    public static function singleServerSent( $type, $order_id, $platforms = array(), $order = null ) {
        $key = '_pys_purchase_server_sent';
        if ( $type === 'woo' && ! $order ) {
            $order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
            if ( ! $order ) {
                return array();
            }
        }

        $stored = self::readMeta( $type, $order, $order_id, $key );
        $stored = is_array( $stored ) ? $stored : array();

        $merged = array_values( array_unique( array_merge( $stored, (array) $platforms ) ) );
        if ( $merged !== $stored ) {
            self::writeMeta( $type, $order, $order_id, $key, $merged );
        }

        return $merged;
    }

    /**
     * Reserve the pixels that still need this Purchase.
     *
     * @param string $type
     * @param int    $order_id
     * @param string $platform
     * @param string $event_id
     * @param array  $pixel_ids Pixels the caller wants to send to
     * @return array Pixels the caller may send to now; the rest were accepted
     *               already or are being sent by another request.
     */
    public static function claim( $type, $order_id, $platform, $event_id, $pixel_ids ) {
        $pixel_ids = array_values( array_unique( array_map( 'strval', (array) $pixel_ids ) ) );
        if ( empty( $pixel_ids ) ) {
            return array();
        }

        return self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platform, $event_id, $pixel_ids ) {
            $sent    = self::getSentPixels( $type, $order, $order_id, $platform, $event_id );
            if ( $sent === true ) {
                return array();
            }
            $pending = self::getPending( $type, $order, $order_id, $platform, $event_id );
            $now     = time();

            $claimed = array();
            foreach ( $pixel_ids as $pixel_id ) {
                if ( in_array( $pixel_id, $sent, true ) ) {
                    continue;
                }
                if ( isset( $pending[ $pixel_id ] ) && $now - (int) $pending[ $pixel_id ] < self::CLAIM_TTL ) {
                    continue;
                }
                $pending[ $pixel_id ] = $now;
                $claimed[]            = $pixel_id;
            }

            if ( ! empty( $claimed ) ) {
                self::writeMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}", array(
                    'event_id' => $event_id,
                    'pixels'   => $pending,
                ) );
            }

            return $claimed;
        } );
    }

    /**
     * Record the outcome of a send: accepted pixels become "sent", the claim of
     * every other claimed pixel is dropped so a later attempt may retry it.
     *
     * @param string $type
     * @param int    $order_id
     * @param string $platform
     * @param string $event_id
     * @param array  $claimed  Pixels returned by claim()
     * @param array  $accepted Pixels the platform accepted
     */
    public static function settle( $type, $order_id, $platform, $event_id, $claimed, $accepted ) {
        $claimed  = array_map( 'strval', (array) $claimed );
        $accepted = array_values( array_intersect( array_map( 'strval', (array) $accepted ), $claimed ) );

        self::withLock( $type, $order_id, function ( $order ) use ( $type, $order_id, $platform, $event_id, $claimed, $accepted ) {
            if ( ! empty( $accepted ) ) {
                $sent = self::getSentPixels( $type, $order, $order_id, $platform, $event_id );
                if ( $sent !== true ) {
                    self::writeMeta( $type, $order, $order_id, "_pys_server_event_sent_{$platform}", array(
                        'event_id' => $event_id,
                        'pixels'   => array_values( array_unique( array_merge( $sent, $accepted ) ) ),
                    ) );
                }
            }

            $pending = self::getPending( $type, $order, $order_id, $platform, $event_id );
            foreach ( $claimed as $pixel_id ) {
                unset( $pending[ $pixel_id ] );
            }
            self::writeMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}", empty( $pending ) ? null : array(
                'event_id' => $event_id,
                'pixels'   => $pending,
            ) );

            return null;
        } );
    }

    /**
     * Mark pixels as handed off to a sender that retries on its own (the
     * events queue): from here the queue owns the delivery.
     */
    public static function markHandedOff( $type, $order_id, $platform, $event_id, $pixel_ids ) {
        $claimed = self::claim( $type, $order_id, $platform, $event_id, $pixel_ids );
        if ( ! empty( $claimed ) ) {
            self::settle( $type, $order_id, $platform, $event_id, $claimed, $claimed );
        }

        return $claimed;
    }

    /**
     * Pixels that accepted this event_id.
     *
     * @return array|true true when the legacy marker says every pixel did
     */
    private static function getSentPixels( $type, $order, $order_id, $platform, $event_id ) {
        $value = self::readMeta( $type, $order, $order_id, "_pys_server_event_sent_{$platform}" );

        if ( is_string( $value ) ) {
            return $value !== '' && $value === $event_id ? true : array();
        }
        if ( is_array( $value ) && isset( $value['event_id'], $value['pixels'] ) && (string) $value['event_id'] === $event_id ) {
            return array_map( 'strval', (array) $value['pixels'] );
        }

        return array();
    }

    private static function getPending( $type, $order, $order_id, $platform, $event_id ) {
        $value = self::readMeta( $type, $order, $order_id, "_pys_server_event_pending_{$platform}" );

        if ( is_array( $value ) && isset( $value['event_id'], $value['pixels'] ) && (string) $value['event_id'] === $event_id ) {
            return (array) $value['pixels'];
        }

        return array();
    }

    /**
     * Run a read-modify-write of the order's delivery meta under a per-order
     * lock, on freshly read meta. Its own lock context, so it nests inside the
     * purchase lock of the order-status fallback.
     */
    private static function withLock( $type, $order_id, callable $callback ) {
        $lock_state = pysAcquireNamedLock( 'purchase_claim_' . $type, $order_id, 5 );

        try {
            $order = null;
            if ( $type === 'woo' ) {
                if ( ! function_exists( 'wc_get_order' ) ) {
                    return array();
                }
                $order = wc_get_order( $order_id );
                if ( ! $order ) {
                    return array();
                }
                $order->read_meta_data( true );
            } else {
                if ( ! function_exists( 'edd_update_payment_meta' ) ) {
                    return array();
                }
                // EDD 3 order meta lives in the edd_order meta type.
                wp_cache_delete( $order_id, 'edd_order_meta' );
            }

            return $callback( $order );
        } finally {
            if ( 'acquired' === $lock_state ) {
                pysReleaseNamedLock( 'purchase_claim_' . $type, $order_id );
            }
        }
    }

    private static function readMeta( $type, $order, $order_id, $key ) {
        if ( $type === 'woo' ) {
            return $order->get_meta( $key, true );
        }

        return edd_get_payment_meta( $order_id, $key, true );
    }

    private static function writeMeta( $type, $order, $order_id, $key, $value ) {
        if ( $type === 'woo' ) {
            if ( $value === null ) {
                $order->delete_meta_data( $key );
            } else {
                $order->update_meta_data( $key, $value );
            }
            $order->save();
            return;
        }

        // EDD has no payment-level delete helper; an empty value reads as "none".
        edd_update_payment_meta( $order_id, $key, $value === null ? '' : $value );
    }
}
