<?php

namespace PixelYourSite\SuperPack;

use PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Absolute URL of the page currently being requested.
 *
 * Local mirror of PYS core's pys_get_current_page_url(). Kept local so this
 * add-on does not depend on a core function at runtime — PYS_SUPER_PACK_PRO_MIN_VERSION
 * already gates the Pro version, but the helper stays self-contained the same
 * way PYS free and Pro each keep their own copy of functions-common.php.
 *
 * $_SERVER['HTTPS'] alone is unreliable behind an SSL-terminating proxy
 * (Cloudflare, load balancer): PHP sees plain HTTP while the browser is on
 * HTTPS, so the URL comes out as http:// on an https page.
 */
function getCurrentPageUrl() {
	$secure = false;

	if ( isset( $_SERVER['HTTPS'] ) && strtolower( $_SERVER['HTTPS'] ) === 'on' ) {
		$secure = true;
	} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ) {
		// Proxy chains send a comma-separated list, e.g. "https, http".
		$forwarded = explode( ',', $_SERVER['HTTP_X_FORWARDED_PROTO'] );
		$secure    = strtolower( trim( $forwarded[0] ) ) === 'https';
	}

	if ( ! $secure ) {
		$secure = is_ssl();
	}

	$host = ! empty( $_SERVER['HTTP_HOST'] )
		? $_SERVER['HTTP_HOST']
		: parse_url( get_site_url(), PHP_URL_HOST );
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';

	return ( $secure ? 'https://' : 'http://' ) . $host . $uri;
}

/**
 * Check if WPML plugin installed and activated.
 * Uses static caching to prevent repeated file system checks.
 *
 * @return bool
 */
function isWPMLActive() {
    static $cache = null;

    if ( $cache !== null ) {
        return $cache;
    }

    if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }
    if ( ! file_exists( WP_PLUGIN_DIR . '/sitepress-multilingual-cms/sitepress.php' ) ) {
        $cache = false;
        return false;
    }
    $cache = is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' );
    return $cache;
}

function isPysProActive() {
    static $cache = null;

    if ( $cache !== null ) {
        return $cache;
    }

	if ( ! function_exists( 'is_plugin_active' ) ) {
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	}
    if ( ! file_exists( WP_PLUGIN_DIR . '/pixelyoursite-pro/pixelyoursite-pro.php' ) ) {
        $cache = false;
        return false;
    }
	$cache = is_plugin_active( 'pixelyoursite-pro/pixelyoursite-pro.php' );
	return $cache;

}

function pysProVersionIsCompatible() {
    static $cache = null;

    if ( $cache !== null ) {
        return $cache;
    }

	if ( ! function_exists( 'get_plugin_data' ) ) {
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	}

	$data = get_plugin_data( WP_PLUGIN_DIR   . '/pixelyoursite-pro/pixelyoursite-pro.php', false, false );

	$cache = version_compare( $data['Version'], PYS_SUPER_PACK_PRO_MIN_VERSION, '>=' );
	return $cache;

}


function printLangList($activeLang,$languageCodes,$pixelSlag = '') {

?>
<div class="wpml_lags">
    <h4 class="primary_heading mb-4"><strong>WPML Detected.</strong> Fire this pixel for the following languages:</h4>

    <?php if($pixelSlag != '') : ?>
        <input class="pixel_lang" hidden name="pys[<?=$pixelSlag?>][pixel_lang][]"  value="<?=implode('_',$activeLang) ?>"/>
    <?php endif; ?>

    <?php foreach ($languageCodes as $code) :

        $id = $code . '_' . rand(1, 1000000);
        ?>

        <div class="small-checkbox pixel_lang_check_box">
            <input type="checkbox" name="wpml_active_lang[]" value="<?=$code?>"
                   id="<?php echo esc_attr( $id ); ?>"
                   class="small-control-input" <?=in_array($code,$activeLang) ? "checked":""?>>
            <label class="small-control small-checkbox-label" for="<?php echo esc_attr( $id ); ?>">
                <span class="small-control-indicator"><i class="icon-check"></i></span>
                <span class="small-control-description"><?=$code?></span>
            </label>
        </div>

	<?php endforeach; ?>
</div>
<?php
}


function get_public_post_types($args = []) {
    $post_type_args = [
        // Default is the value $public.
        'show_in_nav_menus' => true,
    ];


    $post_type_args = wp_parse_args( $post_type_args, $args );

    $_post_types = get_post_types( $post_type_args, 'objects' );

    $post_types = [];

    foreach ( $_post_types as $post_type => $object ) {
        $post_types[ $post_type ] = $object->label;
    }

    return $post_types;
}

function isMembershipActive() {
    static $cache = null;

    if ( $cache !== null ) {
        return $cache;
    }

	if ( ! function_exists( 'is_plugin_active' ) ) {
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	}

	$cache = is_plugin_active( 'memberpress/memberpress.php' );
	return $cache;

}