<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Function include all files in folder
 *
 * @param $path   Directory address
 * @param $ext    array file extension what will include
 * @param $prefix string Class prefix
 */
if ( ! function_exists( 'vi_include_folder' ) ) {
	function vi_include_folder( $path, $prefix = '', $ext = array( 'php' ) ) {

		/*Include all files in payment folder*/
		if ( ! is_array( $ext ) ) {
			$ext = explode( ',', $ext );
			$ext = array_map( 'trim', $ext );
		}
		$sfiles = scandir( $path );
		if ( ! is_array( $sfiles ) ) {
			return;
		}
		foreach ( $sfiles as $sfile ) {
			if ( $sfile != '.' && $sfile != '..' ) {
				if ( is_file( $path . "/" . $sfile ) ) {
					$ext_file  = pathinfo( $path . "/" . $sfile );
					$file_name = $ext_file['filename'];
					if ( $ext_file['extension'] ) {
						if ( in_array( $ext_file['extension'], $ext ) ) {
							$class = preg_replace( '/\W/i', '_', $prefix . ucfirst( $file_name ) );

							if ( ! class_exists( $class ) ) {
								require_once $path . $sfile;
								if ( class_exists( $class ) ) {
									new $class;
								}
							}
						}
					}
				}
			}
		}
	}
}

if ( ! function_exists( 's2w_get_placeholder_image' ) ) {
	function s2w_get_placeholder_image() {
		$placeholder_image = get_option( 's2w_woocommerce_placeholder_img_src', 0 );

		/*Validate current setting if set. If set, return.*/
		if ( ! empty( $placeholder_image ) ) {
			if ( ! is_numeric( $placeholder_image ) ) {
				return $placeholder_image;
			} elseif ( $placeholder_image && wp_attachment_is_image( $placeholder_image ) ) {
				return $placeholder_image;
			}
		}

		$upload_dir = wp_upload_dir();
		$source     = VI_S2W_IMPORT_SHOPIFY_TO_WOOCOMMERCE_IMAGES_DIR . 's2w-placeholder.jpg';
		$filename   = $upload_dir['basedir'] . '/s2w-placeholder.png';

		if ( ! file_exists( $filename ) ) {
			copy( $source, $filename ); // @codingStandardsIgnoreLine.
		}

		if ( ! file_exists( $filename ) ) {
			update_option( 's2w_woocommerce_placeholder_img_src', 0 );

			return 0;
		}

		$filetype   = wp_check_filetype( basename( $filename ), null );
		$attachment = array(
			'guid'           => $upload_dir['url'] . '/' . basename( $filename ),
			'post_mime_type' => $filetype['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);
		$attach_id  = wp_insert_attachment( $attachment, $filename );

		update_option( 's2w_woocommerce_placeholder_img_src', $attach_id );

		/*Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.*/
		require_once ABSPATH . 'wp-admin/includes/image.php';

		/*Generate the metadata for the attachment, and update the database record.*/
		$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
		wp_update_attachment_metadata( $attach_id, $attach_data );

		return $attach_id;
	}
}
if ( ! function_exists( 's2w_upload_image' ) ) {
	function s2w_upload_image( $url, $post_parent = 0, $exclude = array(), $post_title = '', $desc = null ) {
		preg_match( '/[^\?]+\.(jpg|JPG|avif|AVIF|jpeg|JPEG|jpe|JPE|gif|GIF|png|PNG|webp|WEBP|heic|HEIC)/', $url, $matches );
		if ( is_array( $matches ) && count( $matches ) ) {
			if ( ! in_array( strtolower( $matches[1] ), $exclude ) ) {
				$file_array['name'] = basename( $matches[0] );
				add_filter( 'big_image_size_threshold', '__return_false' );
				//add product image:
				if ( ! function_exists( 'media_handle_upload' ) ) {
					require_once( ABSPATH . "wp-admin" . '/includes/image.php' );
					require_once( ABSPATH . "wp-admin" . '/includes/file.php' );
					require_once( ABSPATH . "wp-admin" . '/includes/media.php' );
				}
				// Download file to temp location
				$tmp                    = download_url( $url );
				$file_array['tmp_name'] = $tmp;

				// If error storing temporarily, unlink
				if ( is_wp_error( $tmp ) ) {
					return $tmp;
				}
				$args = array();
				if ( $post_parent ) {
					$args['post_parent'] = $post_parent;
				}
				if ( $post_title ) {
					$args['post_title'] = $post_title;
				}
				//use media_handle_sideload to upload img:
				$thumbid = media_handle_sideload( $file_array, '', $desc, $args );
				// If error storing permanently, unlink
				if ( is_wp_error( $thumbid ) ) {
					@wp_delete_file( $file_array['tmp_name'] );
				}

				return $thumbid;
			} else {
				return new WP_Error( 's2w_file_type_not_permitted', esc_html__( 'File type is not permitted. URL: ', 's2w-import-shopify-to-woocommerce' ).$url );
			}
		} else {
			return new WP_Error( 's2w_file_type_not_permitted', esc_html__( 'Can not detect file type. URL: ', 's2w-import-shopify-to-woocommerce' ).$url );
		}
	}
}
if ( ! function_exists( 'vi_s2w_init_set' ) ) {
	function vi_s2w_init_set() {
		ini_set( 'memory_limit', '3000M' );
		ini_set( 'max_execution_time', '3000' );
		ini_set( 'max_input_time', '3000' );
		ini_set( 'default_socket_timeout', '3000' );
		vi_s2w_set_time_limit();
	}
}
if ( ! function_exists( 'vi_s2w_json_decode' ) ) {
	function vi_s2w_json_decode( $json, $assoc = true, $depth = 512, $options = 2 ) {
		if ( ! is_string( $json ) || $json === '' ) {
			return $assoc ? array() : null;
		}
		$decoded = json_decode( $json, $assoc, $depth, $options );
		if ( $assoc && ! is_array( $decoded ) ) {
			return array();
		}

		return $decoded;
	}
}
if ( ! function_exists( 'vi_s2w_set_time_limit' ) ) {
	function vi_s2w_set_time_limit( $limit = 3000 ) {
		if ( function_exists( 'set_time_limit' ) && false === strpos( (string) ini_get( 'disable_functions' ), 'set_time_limit' ) && ! ini_get( 'safe_mode' ) ) { // phpcs:ignore PHPCompatibility.IniDirectives.RemovedIniDirectives.safe_modeDeprecatedRemoved
			@set_time_limit( $limit ); // @codingStandardsIgnoreLine
		}
	}
}
if ( ! function_exists( 'woocommerce_version_check' ) ) {
	function woocommerce_version_check( $version = '3.0' ) {
		global $woocommerce;

		if ( version_compare( $woocommerce->version, $version, ">=" ) ) {
			return true;
		}

		return false;
	}
}
if ( ! function_exists( 'vi_s2w_graphql_filter_args' ) ) {
	function vi_s2w_graphql_filter_args( $args, $type ) {
		/* We are just test with products*/
		$filter_string = [];
		$sort_key      = '';
		$reverse       = false;
		switch ( $type ) {
			case 'products':
				foreach ( $args as $key => $value ) {
					/* This switch case is for all type*/
					switch ( $key ) {
						case 'order':
							if ( str_contains( $value, 'desc' ) ) {
								$reverse = true;
							}
							$sort_key = strtoupper( explode( ' ', $value )[0] );
							break;
						case 'ids':
							if ( is_array( $value ) && count( $value ) ) {
								$ids = array();
								foreach ( $value as $product_id ) {
									$ids[] = "gid://shopify/Product/{$product_id}";
								}

								return array(
									'ids' => $ids
								);
							}
							$filter_string[] = 'id:' . $value;
							break;
						case 'since_id':
							$filter_string[] = 'id:>=' . $value;
							break;
						case 'created_at_min':
							$filter_string[] = 'created_at:>' . "'{$value}'";
							break;
						case 'published_at_min':
							$filter_string[] = 'published_at:>' . "'{$value}'";
							break;
						case 'created_at_max':
							$filter_string[] = 'created_at:<' . "'{$value}'";
							break;
						case 'published_at_max':
							$filter_string[] = 'published_at:<' . "'{$value}'";
							break;

						case 'status':
							$statuses      = explode( ',', $value );
							$status_filter = [];
							foreach ( $statuses as $status ) {
								$status_filter[] = $key . ':' . strtoupper( $status );
							}
							$filter_string[] = implode( ' OR ', $status_filter );
							break;
						case 'fields':
							$filter_string[] = '';
							break;
						default:
							$filter_string[] = $key . ':' . $value;
					}
				}
				break;
			case 'orders':
				/*Default status if not set*/
				if ( ! array_key_exists( 'financial_status', $args ) || $args['financial_status'] === 'any' ) {
					$statuses      = [ 'paid', 'pending', 'authorized', 'partially_paid', 'partially_refunded', 'refunded', 'voided', 'expired' ];
					$status_filter = [];
					foreach ( $statuses as $status ) {
						$status_filter[] = 'financial_status' . ':' . strtoupper( $status );
					}
					$filter_string[] = implode( ' OR ', $status_filter );
				}
				foreach ( $args as $key => $value ) {
					switch ( $key ) {
						case 'order':
							if ( str_contains( $value, 'desc' ) ) {
								$reverse = true;
							}
							$sort_key = strtoupper( explode( ' ', $value )[0] );
							break;
						case 'ids':
							if ( is_array( $value ) && count( $value ) ) {
								$ids = array();
								foreach ( $value as $order_id ) {
									$ids[] = "gid://shopify/Order/{$order_id}";
								}

								return array(
									'ids' => $ids
								);
							}
							$filter_string[] = 'id:' . $value;
							break;
						case 'processed_at_min':
							$filter_string[] = 'processed_at:>' . "'{$value}'";
							break;
						case 'processed_at_max':
							$filter_string[] = 'processed_at:<' . "'{$value}'";
							break;
						case 'status':
							$statuses      = [ 'open', 'closed', 'cancelled', 'not_closed' ];
							$status_filter = [];
							foreach ( $statuses as $status ) {
								$status_filter[] = $key . ':' . strtoupper( $status );
							}
							$filter_string[] = implode( ' OR ', $status_filter );
							break;
						default:
							if ( in_array( $key, [ 'financial_status', 'fulfillment_status' ] ) && $value === 'any' ) {
								break;
							}
							$filter_string[] = $key . ':' . $value;
					}
				}
				break;
			case 'customers':
				foreach ( $args as $key => $value ) {
					switch ( $key ) {
						case 'ids':
							$filter_string[] = 'id:' . $value;
							break;
						case 'email':
							$filter_string[] = "email:''";
							break;
						case 'reverse':
							if ( ! $value ) continue 2;
							$filter_string[] = 'reverse:' . $value;
							break;
						default:
							$filter_string[] = $key . ':' . $value;
					}
				}
		}

		if ( empty( $filter_string ) ) {
			$filter_string = [];
		} else {
			$filter_string = implode( ' ', $filter_string );
		}
		if($type ==='productsCount') {
			return array(
				'query'    => $filter_string,
			);
		}
		return array(
			'query'    => $filter_string,
			'reverse'  => $reverse,
			'sort_key' => $sort_key,
		);
	}
}
/* Format data */
if ( ! function_exists( 'vi_s2w_format_product_data_from_graphql' ) ) {
	function vi_s2w_format_product_data_from_graphql( $data ) {
		if ( empty( $data ) ) {
			return $data;
		}

		$map_weight = array(
			'GRAMS'     => 'g',
			'KILOGRAMS' => 'kg',
			'OUNCES'    => 'oz',
			'POUNDS'    => 'lb'
		);

		$rest_product_data = [
			'id'           => basename( $data['id'] ) ?? null,
			'title'        => $data['title'] ?? '',
			'body_html'    => $data['descriptionHtml'] ?? '',
			'vendor'       => $data['vendor'] ?? '',
			'product_type' => $data['productType'] ?? '',
			'created_at'   => $data['createdAt'] ?? null,
			'published_at' => $data['publishedAt'] ?? null,
			'updated_at'   => $data['updatedAt'] ?? null,
			'handle'       => $data['handle'] ?? '',
			'tags'         => isset( $data['tags'] ) ? implode( ',', $data['tags'] ) : '',
			'status'       => isset( $data['status'] ) ? strtolower( $data['status'] ) : 'draft', // Default to draft if not provided
			'options'      => [],
			'images'       => [],
			'variants'     => [],
		];

		// Map product options
		if ( ! empty( $data['options'] ) ) {
			foreach ( $data['options'] as $option ) {
				$rest_product_data['options'][] = [
					'id'       => basename( $option['id'] ),
					'position' => $option['position'],
					'name'     => $option['name'] ?? '',
					'values'   => isset( $option['optionValues'] ) ? array_column( $option['optionValues'], 'name' ) : [],
				];
			}
		}

		// Map media to images
		if ( ! empty( $data['images']['nodes'] ) ) {
			foreach ( $data['images']['nodes'] as $image_node ) {
				$rest_product_data['images'][] = [
					'id'     => basename( $image_node['id'] ),
					'src'    => $image_node['url'],
					'width'  => $image_node['width'],
					'height' => $image_node['height'],
					'alt'    => $image_node['altText'],
				];
			}
		}

		// Map variants
		if ( ! empty( $data['variants']['nodes'] ) ) {
			foreach ( $data['variants']['nodes'] as $variant ) {
				$restVariant = [
					'id'                   => basename( $variant['id'] ),
					'title'                => $variant['title'] ?? '',
					'sku'                  => $variant['sku'] ?? '',
					'taxable'              => $variant['taxable'] ?? true,
					'barcode'              => $variant['barcode'] ?? '',
					'price'                => $variant['price'] ?? '0.00',
					'compare_at_price'     => $variant['compareAtPrice'] ?? null,
					'inventory_quantity'   => $variant['inventoryQuantity'] ?? 0,
					'inventory_policy'     => strtolower( $variant['inventoryPolicy'] ),
					'inventory_management' => $variant['inventoryItem']['tracked'],
					'position'             => $variant['position'] ?? 1,
					'requires_shipping'    => $variant['inventoryItem']['requiresShipping'] ?? true,
					'weight'               => $variant['inventoryItem']['measurement']['weight']['value'] ?? null,
					'weight_unit'          => $map_weight[ $variant['inventoryItem']['measurement']['weight']['unit'] ] ?? 'kg',
					'image_id'             => basename( $variant['image']['id'] ?? '' ),
				];

				// Map selected options
				if ( ! empty( $variant['selectedOptions'] ) ) {
					foreach ( $variant['selectedOptions'] as $i => $option ) {
						$restVariant[ 'option' . ( $i + 1 ) ] = $option['optionValue']['name'] ?? '';
					}
				}

				$rest_product_data['variants'][] = $restVariant;

			}
		}

		/* Add product thumbnail*/
		if ( ! empty( $rest_product_data['images'] ) ) {
			$rest_product_data['image'] = $rest_product_data['images'][0];

			/* Mapping variant ids to image*/
			foreach ( $rest_product_data['images'] as $i => $image ) {
				$image['variant_ids'] = [];
				foreach ( $rest_product_data['variants'] as $variant ) {
					if ( $image['id'] == $variant['image_id'] ) {
						$image['variant_ids'][] = $variant['id'];
					}
				}
				$rest_product_data['images'][ absint( $i ) ] = $image;
			}
		}

		return $rest_product_data;
	}
}
if ( ! function_exists( 'vi_s2w_format_order_data_from_graphql' ) ) {
	function vi_s2w_format_order_data_from_graphql( $data ) {
		if ( empty( $data ) ) {
			return $data;
		}
		$rest_order_data = array(
			"id"                       => basename( $data["id"] ),
			'browser_ip'               => $data['clientIp'],
			"email"                    => $data["email"],
			"customer"                 => $data['customer'],
			'payment_gateway_names'    => $data['paymentGatewayNames'],
			"financial_status"         => strtolower( $data["displayFinancialStatus"] ),
			"total_price"              => $data["totalPriceSet"]["shopMoney"]["amount"],
			"total_discounts"          => $data["totalDiscountsSet"]["shopMoney"]["amount"],
			"total_tax"                => $data["totalTaxSet"]["shopMoney"]["amount"],
			"total_shipping_price"     => $data["totalShippingPriceSet"]["shopMoney"]["amount"],
			"currency"                 => $data['currencyCode'],
			"gateway"                  => $data["paymentGatewayNames"][0] ?? "",
			"taxes_included"           => $data["taxesIncluded"],
			'note'                     => $data['note'] ?? '',
			'tax_included'             => $data["taxesIncluded"],
			'created_at'               => $data['createdAt'],
			'order_number'             => str_replace( '#', '', $data['name'] ),/*23-07-2025 Remove '#' in name order*/
			'processed_at'             => $data['processedAt'],
			'total_shipping_price_set' => [
				'shop_money' => [
					'amount' => $data['totalShippingPriceSet']['shopMoney']['amount']
				]
			],
			'transactions'             => $data['transactions'],
		);

		/* Map line items*/
		$rest_order_data['line_items'] = array_map( function ( $item ) {
			$taxes_lines = $item['taxLines'];
			$rest_item   = array(
				"id"         => basename( $item["id"] ),
				"product_id" => basename( $item["product"]["id"] ),
				"variant_id" => basename( $item["variant"]["id"] ),
				"sku"        => (string) ( $item["sku"] ?? "" ),
				'price'      => $item['originalUnitPriceSet']['shopMoney']['amount'],
				"quantity"   => $item["quantity"],
				"name"       => $item["name"],
				'tax_lines'  => [],
			);

			foreach ( $taxes_lines as $tax ) {
				$rest_item['tax_lines'][] = array(
					'price'     => $tax['priceSet']['shopMoney']['amount'],
					'price_set' => array(
						'shop_money' => array(
							'amount'        => $tax['priceSet']['shopMoney']['amount'],
							'currency_code' => $tax['priceSet']['shopMoney']['currencyCode'],
						)
					),
					'rate'      => $tax['rate'],
					'title'     => $tax['title'],
				);
			}

			return $rest_item;

		}, $data["lineItems"]["nodes"] ?? [] );

		/* Map fulfillment */
		$rest_order_data['fulfillments'] = array_map( function ( $fulfillment ) {
			$fulfillment_line_items = $fulfillment['fulfillmentLineItems']['nodes'];
			$tracking_numbers       = [];
			$line_items             = [];
			$tracking_company       = '';
			$tracking_info          = $fulfillment['trackingInfo'];
			foreach ( $tracking_info as $tracking ) {
				$tracking_numbers[] = $tracking['number'];
				$tracking_company   = $tracking['company'];
			}
			foreach ( $fulfillment_line_items as $line_item ) {
				$line_items[] = array(
					'name' => $line_item['lineItem']['name']
				);
			}

			return array(
				"id"               => basename( $fulfillment["id"] ),
				'line_items'       => $line_items,
				'tracking_company' => $tracking_company,
				'tracking_numbers' => $tracking_numbers
			);

		}, $data['fulfillments'] );

		/*Map billing address*/
		$billing_address                    = $data["billingAddress"];
		$rest_order_data['billing_address'] = array(
			"first_name"    => $billing_address["firstName"] ?? "",
			"last_name"     => $billing_address["lastName"] ?? "",
			"address1"      => $billing_address["address1"] ?? "",
			"address2"      => $billing_address["address2"] ?? "",
			"city"          => $billing_address["city"] ?? "",
			"province_code" => $billing_address["provinceCode"] ?? "",
			"zip"           => $billing_address["zip"] ?? "",
			"country_code"  => $billing_address["countryCodeV2"] ?? "",
			"phone"         => $billing_address["phone"] ?? ""
		);

		/* Map shipping address*/
		$shipping_address                    = $data["shippingAddress"];
		$rest_order_data['shipping_address'] = array(
			"first_name"    => $shipping_address["firstName"] ?? "",
			"last_name"     => $shipping_address["lastName"] ?? "",
			"address1"      => $shipping_address["address1"] ?? "",
			"address2"      => $shipping_address["address2"] ?? "",
			"city"          => $shipping_address["city"] ?? "",
			"province_code" => $shipping_address["provinceCode"] ?? "",
			"zip"           => $shipping_address["zip"] ?? "",
			"country_code"  => $shipping_address["countryCodeV2"] ?? "",
			"phone"         => $shipping_address["phone"] ?? ""
		);

		/* Map discount codes*/
		$rest_order_data['discount_codes'] = array_map( function ( $code ) use ( $data ) {
			/* Only use one discount*/
			return [
				"code"   => $code,
				"amount" => $data["totalDiscountsSet"]["shopMoney"]["amount"],
			];
		}, $data["discountCodes"] ?? [] );

		/* Map shipping lines */
		$rest_order_data['shipping_lines'] = array_map( function ( $line ) use ( $data ) {
			$tax_lines = [];
			foreach ( $line['taxLines'] as $tax_line ) {
				$tax_lines[] = array(
					'title' => $tax_line['title'],
					'price' => $tax_line['priceSet']['shopMoney']['amount'],
				);
			}
			$shipping_data = [
				"title"     => $line["title"],
				"tax_lines" => $tax_lines,
				'price'     => $line['originalPriceSet']['shopMoney']['amount']
			];

			return $shipping_data;

		}, $data["shippingLines"]["nodes"] );

		/* Mapping refunds*/
		$res_refund_data = [];
		foreach ( $data['refunds'] as $refund ) {
			$refund_data           = array(
				'note'              => $refund['note'],
				'created_at'        => $refund['createdAt'],
				'refund_line_items' => [],
				'order_adjustments' => []
			);
			$refund_line_items     = $refund['refundLineItems']['nodes'] ?? [];
			$refund_shipping_items = $refund['refundShippingLines']['nodes'] ?? [];

			foreach ( $refund_line_items as $refund_line_item ) {
				$refund_data['refund_line_items'][] = array(
					'line_item_id' => basename( $refund_line_item['lineItem']['id'] ),
					'quantity'     => $refund_line_item['quantity'],
					'subtotal'     => $refund_line_item['subtotalSet']['shopMoney']['amount'],
				);
			}

			foreach ( $refund_shipping_items as $refund_shipping_item ) {
				$refund_data['order_adjustments'][] = array(
					'kind'       => 'shipping_refund',
					'amount_set' => [
						'shop_money' => [
							'amount' => $refund_shipping_item['subtotalAmountSet']['shopMoney']['amount'],
						]
					]
				);
			}
			$res_refund_data[] = $refund_data;
		}
		$rest_order_data['refunds'] = $res_refund_data;

		/* Mapping tax lines */
		$tax_lines = [];
		foreach ( $data['taxLines'] as $tax_line ) {
			$tax_lines[] = array(
				'title' => $tax_line['title'],
				'price' => $tax_line['priceSet']['shopMoney']['amount']
			);
		}
		$rest_order_data['tax_lines'] = $tax_lines;

		return $rest_order_data;
	}
}
if ( ! function_exists( 'vi_s2w_format_shop_data_from_graphql' ) ) {
	function vi_s2w_format_shop_data_from_graphql( $data ) {

		if ( empty( $data ) ) {
			return [];
		}
		$map_weight = array(
			'GRAMS'     => 'g',
			'KILOGRAMS' => 'kg',
			'OUNCES'    => 'oz',
			'POUNDS'    => 'lb'
		);

		$res_shop_data = array(
			'name'                       => $data['name'],
			'email'                      => $data['email'],
			'iana_timezone'              => $data['ianaTimezone'],
			'address1'                   => $data['billingAddress']['address1'],
			'address2'                   => $data['billingAddress']['address2'],
			'city'                       => $data['billingAddress']['city'],
			'province'                   => $data['billingAddress']['province'],
			'country_code'               => $data['billingAddress']['countryCodeV2'],
			'zip'                        => $data['billingAddress']['zip'],
			'weight_unit'                => $map_weight[ $data['weightUnit'] ],
			'currency'                   => $data['currencyCode'],
			'money_format'               => $data['currencyFormats']['moneyFormat'],
			'money_with_currency_format' => $data['currencyFormats']['moneyWithCurrencyFormat']
		);

		return $res_shop_data;
	}
}
if ( ! function_exists( 'vi_s2w_format_shipping_zone_from_graphql' ) ) {
	function vi_s2w_format_shipping_zones_from_graphql( $data ) {
		$shipping_zones          = $data['profileLocationGroups'][0]['locationGroupZones']['nodes'] ?? [];
		$res_shipping_zones_data = [];
		foreach ( $shipping_zones as $shipping_zone ) {
			$countries = [];
			foreach ( $shipping_zone['zone']['countries'] as $country ) {
				$provinces = [];
				foreach ( $country['provinces'] as $province ) {
					$provinces[] = array(
						'code' => $province['code']
					);
				}
				$countries[] = array(
					'code'      => $country['code']['countryCode'],
					'provinces' => $provinces
				);
			}
			$price_based_shipping_rates = [];
			foreach ( $shipping_zone['methodDefinitions']['nodes'] as $method ) {
				$price_based_shipping_rates[] = array(
					'name'               => $method['name'],
					'min_order_subtotal' => $method['methodConditions'][0]['conditionCriteria']['amount'] ?? 0,
					'price'              => $method['rateProvider']['price']['amount']
				);
			}

			$res_shipping_zones_data[] = array(
				'name'                       => $shipping_zone['zone']['name'],
				'countries'                  => $countries,
				'price_based_shipping_rates' => $price_based_shipping_rates
			);
		}

		return $res_shipping_zones_data;
	}
}
if ( ! function_exists( 'vi_s2w_format_page_from_graphql' ) ) {
	function vi_s2w_format_page_from_graphql( $data ) {
		return array(
			'id'        => basename( $data['id'] ),
			'title'     => $data['title'],
			'body_html' => $data['body']
		);
	}
}
if ( ! function_exists( 'vi_s2w_format_customer_from_graphql' ) ) {
	function vi_s2w_format_customer_from_graphql( $data ) {
//		if ( empty( $default_address ) ) {
//			$default_address = $data['addresses'][0] ?? '';
//		} else {
//			$default_address = $data['defaultAddress'] ?? '';
//		}
		$customer_res_data = array(
			'id'              => basename( $data['id'] ),
			'email'           => $data['email'],
			'orders_count'    => $data['numberOfOrders'],
			'first_name'      => $data['firstName'],
			'last_name'       => $data['lastName'],
			'phone'           => $data['phone'],
			'created_at'      => $data['createdAt'],
			'default_address' => array(
				"address1"      => $data['defaultAddress']["address1"] ?? "",
				"address2"      => $data['defaultAddress']["address2"] ?? "",
				"city"          => $data['defaultAddress']["city"] ?? "",
				"province_code" => $data['defaultAddress']["provinceCode"] ?? "",
				"zip"           => $data['defaultAddress']["zip"] ?? "",
				"country_code"  => $data['defaultAddress']["countryCodeV2"] ?? "",
				"phone"         => $data['defaultAddress']["phone"] ?? ""
			),
		);

		return $customer_res_data;
	}
}

/* Query data*/
if ( ! function_exists( 'vi_s2w_graphql_product_query' ) ) {
	function vi_s2w_graphql_product_query( $ids = false, $only_get_product_ids = false ) {
		$product_fields = 'id
				      title
				      descriptionHtml
				      vendor
				      productType
				      images(first:250) {
				        nodes {
				          url
			              id
			              altText
			              height
			              width
				        }
				      }
				      createdAt
				      handle
				      updatedAt
				      tags
				      status
				      options(first: 3) {
				        id
				        position
				        name
				        optionValues {
				          name
				        }
				      }
				      publishedAt
				      variants(first: 100) {
				        nodes {
				          id
				          title
				          sku
				          taxable
				          barcode
				          updatedAt
				          compareAtPrice
				          image {
				            id
				          }
				          inventoryItem {
				            id
				            tracked
				            requiresShipping
				            measurement {
				              weight {
				                unit
				                value
				              }
				            }
				          }
				          inventoryQuantity
				          price
				          position
				          inventoryPolicy
				          compareAtPrice
				          selectedOptions {
				            name
				            optionValue {
				              name
				            }
				          }
				        }
				      }';
		if ( ! $ids ) {
			if ( $only_get_product_ids ) {
				return "query Product( \$query: String, \$after:String, \$sortKey: ProductSortKeys, \$reverse:Boolean) {
				  products(first: 250, query: \$query, after: \$after, sortKey: \$sortKey, reverse: \$reverse) {
				    nodes {
				      id
				    }
				    pageInfo {
				      hasNextPage
				      endCursor
				    }
				  }
				}";
			}

			return "query Product(\$limit: Int, \$query: String, \$after:String, \$sortKey: ProductSortKeys, \$reverse:Boolean) {
				  products(first: \$limit, query: \$query, after: \$after, sortKey: \$sortKey, reverse: \$reverse) {
				    nodes {
				      {$product_fields}
				    }
				    pageInfo {
				      hasNextPage
				      endCursor
				    }
				  }
				}";

		} else {
			return "query Product(\$ids: [ID!]!) {
					nodes(ids: \$ids) {
						... on Product {
							{$product_fields}
						}
				    }
				}";
		}
	}
}
if ( ! function_exists( 'vi_s2w_graphql_order_query' ) ) {
	function vi_s2w_graphql_order_query( $ids = false ) {
		$order_fields = 'id
				      email
				      clientIp
				      createdAt
				      transactions( first: 10 ) {
			            createdAt
				      }
				      processedAt
				      name
				      customer {
				        createdAt
				        email
				      }
				      paymentGatewayNames
				      currencyCode
				       taxLines {
				        title
				        priceSet{
				          shopMoney{
				            amount
				          }
				        }
				      }
				      lineItems(first: 50) {
				        nodes {
				          id
				          product {
				            id
				          }
				          variant {
				            id
				          }
				          sku
				          taxLines(first: 10) {
				            priceSet {
				              shopMoney {
				                amount
				                currencyCode
				              }
				            }
				            rate
				            title
				          }
				          originalTotalSet {
				            shopMoney {
				              amount
				            }
				          }
				          originalUnitPriceSet {
				            shopMoney {
				              amount
				            }
				          }
				          quantity
				          name
				        }
				      }
				      fulfillments(first: 10) {
				        id
				        fulfillmentLineItems(first:10) {
				          nodes {
				            lineItem {
				              name
				            }
				          }
				        }
				        trackingInfo(first:10) {
				          company
				          number
				        }
				      }
				      billingAddress {
				        firstName
				        lastName
				        company
				        countryCodeV2
				        address1
				        address2
				        zip
				        city
				        provinceCode
				        phone
				      }
				      shippingAddress {
				        firstName
				        lastName
				        company
				        countryCodeV2
				        address1
				        address2
				        zip
				        city
				        provinceCode
				        phone
				      }
				      totalPriceSet {
				        shopMoney {
				          amount
				        }
				      }
				      totalTaxSet {
				        shopMoney {
				          amount
				        }
				      }
				      totalDiscountsSet {
				        shopMoney {
				          amount
				        }
				      }
				      totalShippingPriceSet {
				        shopMoney {
				          amount
				        }
				      }
				      shippingLines(first: 10) {
				        nodes {
				          title
				          originalPriceSet{
				            shopMoney{
				              amount
			                }
				          }
				          taxLines {
				            title
				            priceSet {
				              shopMoney {
				                amount
				              }
				            }
				          }
				        }
				      }
				      discountCodes
				      displayFinancialStatus
				      note
				      taxesIncluded
				      refunds(first:10) {
				        totalRefundedSet {
				          shopMoney {
				            amount
				          }
				        }
				        note
				        createdAt
				        refundLineItems( first: 10 ) {
				          nodes {
				            id
				            quantity
				            subtotalSet{
				              shopMoney {
				                amount
				              }
				            }
				            lineItem {
				              id
				            }
				          }
				        }
				        refundShippingLines(first: 10 ) {
				          nodes {
				            subtotalAmountSet {
				              shopMoney{
				                amount
				              }
				            }
				          }
			            }
				      }';
		if ( ! $ids ) {
			return "query Order(\$limit: Int, \$query: String, \$after: String, \$sortKey: OrderSortKeys, \$reverse: Boolean) {
				  orders ( first: \$limit, query: \$query, after: \$after, sortKey: \$sortKey, reverse: \$reverse) {
				    nodes {
				      {$order_fields}
				    }
				    pageInfo {
				      hasNextPage
				      endCursor
				    }
				  }
				}";
		} else {
			return "query Order(\$ids: [ID!]!) {
				    nodes(ids: \$ids) { 
					    ... on Order {
					      {$order_fields}
					    }
				    }
				}";
		}
	}
}
if ( ! function_exists( 'vi_s2w_graphql_shop_query' ) ) {
	function vi_s2w_graphql_shop_query() {
		return 'query Shop {
				  shop {
				    name
				    email
				    ianaTimezone
				    billingAddress {
				      address1
				      address2
				      city
				      countryCodeV2
				      province
				      zip
				    }
				    weightUnit
				    currencyCode
				    currencyFormats {
				      moneyFormat
				      moneyWithCurrencyFormat
				    }
				  }
				}';
	}
}
if ( ! function_exists( 'vi_s2w_graphql_shipping_zone_query' ) ) {
	function vi_s2w_graphql_shipping_zone_query() {
		return 'query ShippingZones($limit: Int, $after: String, $reverse: Boolean) {
				  deliveryProfiles(first: $limit, after: $after, reverse: $reverse) {
				    nodes {
				      profileLocationGroups {
				        locationGroupZones(first: 10) {
				          nodes {
				            zone {
				              name
				              countries {
				                id
				                code {
				                  countryCode
				                }
				                provinces {
				                  code
				                }
				              }
				            }
				            methodDefinitions(first: 10) {
				              nodes {
				                name
				                methodConditions {
				                  conditionCriteria {
				                    ... on MoneyV2 {
				                      amount
				                    }
				                  }
				                }
				                rateProvider {
				                  ... on DeliveryRateDefinition {
				                    price {
				                      amount
				                    }
				                  }
				                }
				              }
				            }
				          }
				        }
				      }
				    }
				    pageInfo {
				      hasNextPage
				      endCursor
				    }
				  }
				}';
	}
}
if ( ! function_exists( 'vi_s2w_graphql_page_query' ) ) {
	function vi_s2w_graphql_page_query() {
		return 'query Page($limit: Int, $after: String, $reverse: Boolean) {
				  pages(first: $limit, after: $after, reverse: $reverse) {
				    nodes {
				        id
				      body
				      title
				    }
				    pageInfo {
				      hasNextPage
				      endCursor
				    }
				  }
				}';
	}
}
if ( ! function_exists( 'vi_s2w_graphql_customer_query' ) ) {
	function vi_s2w_graphql_customer_query() {
		return 'query Customer($limit: Int, $query: String, $after: String, $sortKey: CustomerSortKeys, $reverse:Boolean) {
				  customers(first: $limit, query: $query, after: $after, sortKey: $sortKey, reverse: $reverse) {
				    nodes {
				      id
				      email
				      numberOfOrders
				      createdAt
				      phone
				      firstName
				      lastName
				      addresses(first: 1) {
				        company
				        countryCodeV2
				        address1
				        address2
				        zip
				        city
				        provinceCode
				        phone
				      }
				      defaultAddress {
				        firstName
				        lastName
				        company
				        countryCodeV2
				        address1
				        address2
				        zip
				        city
				        provinceCode
				        phone
				      }
				    }
				    pageInfo {
				      hasNextPage
				      endCursor
				    }
				  }
				}';
	}
}