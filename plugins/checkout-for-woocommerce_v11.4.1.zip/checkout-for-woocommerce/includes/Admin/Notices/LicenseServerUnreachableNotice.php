<?php

declare( strict_types = 1 );

namespace Objectiv\Plugins\Checkout\Admin\Notices;

use Objectiv\Plugins\Checkout\Managers\UpdatesManager;

/**
 * Warns the merchant that license checks are failing, and when premium features will turn off.
 *
 * @since 11.4.1
 */
class LicenseServerUnreachableNotice extends NoticeAbstract {
	/**
	 * Adds the notice when license checks have been failing for several days.
	 *
	 * @since 11.4.1
	 *
	 * @return void
	 */
	public function add() {
		$deadline = UpdatesManager::instance()->get_license_verification_deadline();

		if ( $deadline > 0 ) {
			$message = sprintf(
				/* translators: %1$s: Date premium features turn off, %2$s: Support email URL, %3$s: "Contact support" link text */
				__( 'We couldn\'t check your license with checkoutwc.com. Premium features will turn off on %1$s unless the connection is restored. <a href="%2$s">%3$s</a> if this keeps happening.', 'checkout-wc' ),
				esc_html( date_i18n( get_option( 'date_format' ), $deadline + (int) ( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) ),
				'mailto:support@checkoutwc.com',
				__( 'Contact support', 'checkout-wc' )
			);
		} else {
			$message = sprintf(
				/* translators: %1$s: Support email URL, %2$s: "Contact support" link text */
				__( 'We couldn\'t check your license with checkoutwc.com. Make sure your server can connect to checkoutwc.com. <a href="%1$s">%2$s</a> if this keeps happening.', 'checkout-wc' ),
				'mailto:support@checkoutwc.com',
				__( 'Contact support', 'checkout-wc' )
			);
		}

		// Not dismissible: it carries the date premium features turn off.
		parent::maybe_add(
			'cfw_license_server_unreachable',
			__( 'CheckoutWC can\'t reach the license server', 'checkout-wc' ),
			$message,
			[
				'type'        => 'warning',
				'dismissible' => false,
			]
		);
	}

	/**
	 * Determines whether license checks have been failing long enough to warn.
	 *
	 * @since 11.4.1
	 *
	 * @return bool
	 */
	protected function should_add(): bool {
		$license_key = UpdatesManager::instance()->get_field_value( 'license_key' );

		return ! empty( $license_key ) && UpdatesManager::instance()->is_license_server_unreachable();
	}
}
