<?php

declare( strict_types = 1 );

namespace Objectiv\Plugins\Checkout\Admin\Notices;

use Objectiv\Plugins\Checkout\Managers\UpdatesManager;

/**
 * Tells the merchant premium features are off because the license hasn't been checked within the grace period.
 *
 * @since 11.4.1
 */
class LicenseUnverifiedNotice extends NoticeAbstract {
	/**
	 * Adds the notice when the license is overdue for a successful check.
	 *
	 * @since 11.4.1
	 *
	 * @return void
	 */
	public function add() {
		$message = sprintf(
			/* translators: %1$d: Number of days, %2$s: Pricing URL, %3$s: "renew it here" link text */
			__( 'Premium features are off because we haven\'t been able to check your license with checkoutwc.com for %1$d days. Make sure your server can connect to checkoutwc.com. If your license has expired, <a href="%2$s" target="_blank">%3$s</a>.', 'checkout-wc' ),
			intdiv( UpdatesManager::LICENSE_VERIFICATION_GRACE_PERIOD, DAY_IN_SECONDS ),
			'https://www.checkoutwc.com/pricing',
			__( 'renew it here', 'checkout-wc' )
		);

		parent::maybe_add(
			'cfw_license_unverified',
			__( 'CheckoutWC can\'t verify your license', 'checkout-wc' ),
			$message,
			[
				'type'        => 'error',
				'dismissible' => false,
			]
		);
	}

	/**
	 * Determines whether the license is overdue for a successful check.
	 *
	 * @since 11.4.1
	 *
	 * @return bool
	 */
	protected function should_add(): bool {
		$license_key = UpdatesManager::instance()->get_field_value( 'license_key' );
		$key_status  = UpdatesManager::instance()->get_field_value( 'key_status' );

		// Other statuses have premium features off for their own reason, with their own notice.
		return ! empty( $license_key ) && 'valid' === $key_status && UpdatesManager::instance()->is_license_verification_overdue();
	}
}
