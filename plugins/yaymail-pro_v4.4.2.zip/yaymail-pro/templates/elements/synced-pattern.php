<?php
defined( 'ABSPATH' ) || exit;
use YayMail\Utils\TemplateHelpers;
use YayMail\Elements\ElementsLoader;

/**
 * $args includes
 * $element
 * $render_data
 * $is_nested
 */
if ( empty( $args['element'] ) ) {
    return;
}

$element = $args['element'];
$data    = $element['data'];

$pattern_id       = $data['pattern_id'];
$pattern_model    = \YayMail\Models\PatternTemplateModel::get_instance();
$pattern_template = $pattern_model->find_by_id( $pattern_id );

if ( empty( $pattern_template ) || 'inactive' === $pattern_template['status'] ) {
    return;
}

$child_elements = $pattern_template['elements'];

ob_start();

ElementsLoader::render_elements(
    $child_elements,
    $args
);

$element_content = ob_get_clean();

TemplateHelpers::wrap_element_content( $element_content, $element );
