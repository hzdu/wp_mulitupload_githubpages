<?php
defined( 'ABSPATH' ) || exit;
use YayMail\Utils\TemplateHelpers;
use YayMail\Countdown\CountdownBuilder;

/**
 * $args includes
 * $element
 * $render_data
 * $is_nested
 */
if ( empty( $args['element'] ) ) {
    return;
}

$element = $args['element'];
$data    = $element['data'];


$wrapper_style = TemplateHelpers::get_style(
    [
        'word-break'       => 'break-word',
        'text-align'       => $data['align'],
        'background-color' => $data['background_color'],
        'padding'          => TemplateHelpers::get_spacing_value( isset( $data['padding'] ) ? $data['padding'] : [] ),
    ]
);

$end_time          = isset( $data['end_time'] ) ? $data['end_time'] : null;
$display_text_only = isset( $data['display_text_only'] ) ? $data['display_text_only'] : false;
$date_time_format  = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

if ( empty( $end_time ) ) {
    return;
}

if ( ! $display_text_only ) {

    $data['inner_background_color'] = str_replace( '#', '', $data['inner_background_color'] );
    $data['text_color']             = str_replace( '#', '', $data['text_color'] );
    $data['label_color']            = str_replace( '#', '', $data['label_color'] );

    $countdown = new CountdownBuilder();
    $countdown->with_time( $end_time );
    $countdown->background( $data['inner_background_color'] );
    $countdown->color( $data['text_color'] );
    $countdown->font_size( $data['font_size'] );
    $countdown->show_unit_label( $data['show_unit_label'] );
    $countdown->date_unit( $data['label_days'] );
    $countdown->hour_unit( $data['label_hours'] );
    $countdown->minute_unit( $data['label_minutes'] );
    $countdown->second_unit( $data['label_seconds'] );
    $countdown->label_font_size( $data['label_font_size'] );
    $countdown->unit_color( $data['label_color'] );
    $countdown->spacing( $data['spacing'] );
    $src = $countdown->draw();
}//end if

$text_style = TemplateHelpers::get_style(
    [
        'text-align'  => yaymail_get_text_align(),
        'color'       => $data['text_color'],
        'font-family' => TemplateHelpers::get_font_family_value( $data['font_family'] ),
        'font-size'   => TemplateHelpers::get_dimension_value( $data['font_size'] ),
    ]
);


ob_start();
?>


<div class="yaymail-customizer-element-countdown">
<?php if ( $display_text_only ) { ?>
    <div class="yaymail-customizer-element-countdown-target" style="<?php echo esc_attr( $text_style ); ?>">
        <?php echo esc_html( gmdate( $date_time_format, strtotime( $end_time ) ) ); ?>
    </div>
    <?php
} else {

    echo '<img src="' . esc_url( $src ) . '" alt="' . esc_attr__( 'Countdown', 'yaymail' ) . '" style="max-width: 100%; width: 100%;margin:0" />';
}//end if
?>
</div>
<?php
$element_content = ob_get_clean();

TemplateHelpers::wrap_element_content( $element_content, $element, $wrapper_style );
