<?php

namespace YayMail\Controllers;

use YayMail\Abstracts\BaseController;
use YayMail\Constants\GlobalVariables;
use YayMail\Utils\Helpers;
use YayMail\Utils\SingletonTrait;

/**
 * Global Variables Controller
 *
 * @method static GlobalVariablesController get_instance()
 */
class GlobalVariablesController extends BaseController {
    use SingletonTrait;

    protected function __construct() {
        $this->init_hooks();
    }

    protected function init_hooks() {
        register_rest_route(
            YAYMAIL_REST_NAMESPACE,
            '/global-variables',
            [
                [
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => [ $this, 'exec_get_all_global_variables' ],
                    'permission_callback' => [ $this, 'permission_callback' ],
                ],
            ]
        );

        register_rest_route(
            YAYMAIL_REST_NAMESPACE,
            '/global-variables/colors',
            [
                [
                    'methods'             => \WP_REST_Server::EDITABLE,
                    'callback'            => [ $this,'exec_update_global_variables_colors' ],
                    'permission_callback' => [ $this, 'permission_callback' ],
                ],
            ]
        );
    }

    /**
     * Get all global variables
     *
     * @param \WP_REST_Request $request The request object.
     * @return \WP_REST_Response
     */
    public function exec_get_all_global_variables( \WP_REST_Request $request ) {
        return $this->exec( [ $this, 'get_all_global_variables' ], $request );
    }

    /**
     * Get all global variables
     *
     * @param \WP_REST_Request $request The request object.
     * @return array
     */
    public function get_all_global_variables( \WP_REST_Request $request ) {
        $global_variables_colors            = get_option( 'yaymail_global_variables_colors', [] );
        $global_variables_colors['default'] = GlobalVariables::COLOR_DEFAULT;

        $global_variables = [
            'colors' => $global_variables_colors,
        ];

        return $global_variables;
    }

    public function exec_update_global_variables_colors( \WP_REST_Request $request ) {
        return $this->exec( [ $this,'update_global_variables_colors' ], $request );
    }

    public function update_global_variables_colors( \WP_REST_Request $request ) {
        $global_variables_colors = $request->get_param( 'colors' );

        // Sanitize the colors data recursively using Helpers
        $sanitized_colors = Helpers::sanitize_array_recursive( $global_variables_colors );

        if ( empty( $sanitized_colors ) ) {
            return [
                'success' => false,
                'message' => __( 'Global variables colors is empty', 'yaymail' ),
            ];
        }

        update_option( 'yaymail_global_variables_colors', $sanitized_colors );

        return [
            'success' => true,
            'colors'  => $sanitized_colors,
            'message' => __( 'Colors updated', 'yaymail' ),
        ];
    }
}
