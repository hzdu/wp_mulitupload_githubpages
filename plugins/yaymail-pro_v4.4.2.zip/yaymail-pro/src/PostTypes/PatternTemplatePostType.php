<?php

namespace YayMail\PostTypes;

use YayMail\Utils\SingletonTrait;

/**
 *  Custom Post Type
 *
 * @method static PatternTemplatePostType get_instance()
 */
class PatternTemplatePostType {
    use SingletonTrait;

    public const POST_TYPE = 'yaymail_pattern';

    /**
     * Constructor
     */
    protected function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks when class init
     */
    protected function init_hooks() {
        // Register Custom Post Type for YayMail Pattern Template
        add_action( 'init', [ $this, 'register_pattern_template_post_type' ], 20 );
    }

    public function register_pattern_template_post_type() {
        $labels = [
            'name'               => __( 'Pattern Template', 'yaymail' ),
            'singular_name'      => __( 'Pattern Template', 'yaymail' ),
            'add_new'            => __( 'Add New Pattern Template', 'yaymail' ),
            'add_new_item'       => __( 'Add a new Pattern Template', 'yaymail' ),
            'edit_item'          => __( 'Edit Pattern Template', 'yaymail' ),
            'new_item'           => __( 'New Pattern Template', 'yaymail' ),
            'view_item'          => __( 'View Pattern Template', 'yaymail' ),
            'search_items'       => __( 'Search Pattern Template', 'yaymail' ),
            'not_found'          => __( 'No Pattern Template found', 'yaymail' ),
            'not_found_in_trash' => __( 'No Pattern Template currently trashed', 'yaymail' ),
            'parent_item_colon'  => '',
        ];
        $args   = [
            'labels'              => $labels,
            'public'              => false,
            'publicly_queryable'  => false,
            'show_ui'             => false,
            'query_var'           => true,
            'rewrite'             => true,
            'capability_type'     => self::POST_TYPE,
            'capabilities'        => [],
            'hierarchical'        => false,
            'menu_position'       => null,
            'exclude_from_search' => true,
            'supports'            => [ 'title', 'author', 'thumbnail', 'revisions' ],
        ];
        register_post_type( self::POST_TYPE, $args );
    }
}
