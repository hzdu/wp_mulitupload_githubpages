<?php
namespace YayMail;

use YayMail\Elements\ElementsHelper;
use YayMail\Models\TemplateModel;
use YayMail\Utils\Helpers;
use YayMail\Utils\TemplateRenderer;

/**
 * YayMail Pattern Template
 */
class YayMailPatternTemplate extends YayMailTemplate {

    /**
     * TemplateModel
     *
     * @var TemplateModel
     */
    private $model = null;

    public const META_KEYS = [
        'name'     => '_yaymail_pattern_template',
        'elements' => '_yaymail_pattern_elements',
        'status'   => '_yaymail_pattern_status',
        'uuid'     => '_yaymail_pattern_uuid',
    ];

    public const DEFAULT_DATA = [
        'name'     => '',
        'elements' => [],
        'status'   => 0,
    ];

    /**
     * Contains template data
     */
    private $data = [
        'name'     => self::DEFAULT_DATA['name'],
        'elements' => self::DEFAULT_DATA['elements'],
        'status'   => self::DEFAULT_DATA['status'],
    ];

    public function __construct( $template_id = null ) {
        $this->model = \YayMail\Models\PatternTemplateModel::get_instance();

        if ( ! empty( $template_id ) ) {
            $template_data = $this->model::find_by_id( $template_id );
            if ( ! empty( $template_data['id'] ) ) {
                $this->set_id( $template_data['id'] );
                $this->set_props( $template_data );
                // TODO: Consider filter available elements before pass to props
                $this->renderer = new TemplateRenderer( $this );
            } else {
                return;
            }
        }//end if
    }

    public function set_elements( $elements ) {
        $this->data['elements'] = $elements;
    }

    public function get_data() {
        return array_merge(
            [
                'id' => $this->get_id(),
            ],
            $this->data
        );
    }
}
