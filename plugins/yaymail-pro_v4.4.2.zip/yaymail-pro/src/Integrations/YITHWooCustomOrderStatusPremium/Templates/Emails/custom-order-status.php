<?php

defined( 'ABSPATH' ) || exit;

use YayMail\Integrations\YITHWooCustomOrderStatusPremium\Emails\EmailsHandler;

$status_id = EmailsHandler::get_status_id_from_order( $args['order'] ?? null );

if ( empty( $status_id ) ) {
    return;
}

$email_instance = EmailsHandler::get_instance()->get_email_by_id( $status_id );

if ( ! empty( $email_instance ) ) {
    $template = property_exists( $email_instance, 'template' ) ? $email_instance->template : '';
}

if ( ! empty( $template ) ) {
    $content = $template->get_content( $args );
    yaymail_kses_post_e( $content );
}
