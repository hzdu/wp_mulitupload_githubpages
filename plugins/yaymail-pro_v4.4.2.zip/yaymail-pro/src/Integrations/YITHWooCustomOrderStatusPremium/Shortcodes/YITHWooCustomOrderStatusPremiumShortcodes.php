<?php

namespace YayMail\Integrations\YITHWooCustomOrderStatusPremium\Shortcodes;

use YayMail\Abstracts\BaseShortcode;
use YayMail\Integrations\YITHWooCustomOrderStatusPremium\Emails\EmailsHandler;
use YayMail\Utils\SingletonTrait;
use YayMail\Utils\Helpers;
/**
 * YITHWooCustomOrderStatusPremiumShortcodes
 */
class YITHWooCustomOrderStatusPremiumShortcodes extends BaseShortcode {
    use SingletonTrait;

    public function __construct() {
        $this->available_email_ids = EmailsHandler::get_instance()->get_list_id();
        parent::__construct();
    }

    public function get_shortcodes() {

        $shortcodes = [];

        $shortcodes[] = [
            'name'        => 'yaymail_yith_order_status',
            'description' => __( 'YITH WooCommerce Order Status', 'yaymail' ),
            'group'       => 'YITH WooCommerce Custom Order Status Premium',
            'callback'    => [ $this, 'yaymail_yith_order_status' ],
        ];

        return $shortcodes;
    }

    public function yaymail_yith_order_status( $args ) {
        $render_data = isset( $args['render_data'] ) ? $args['render_data'] : [];

        if ( ! empty( $render_data['is_sample'] ) ) {
            return __( 'Order Status', 'yaymail' );
        }

        $order = Helpers::get_order_from_shortcode_data( $render_data );

        if ( empty( $order ) ) {
            return __( 'No order found', 'yaymail' );
        }

        return wc_get_order_status_name( $order->get_status() );
    }
}
