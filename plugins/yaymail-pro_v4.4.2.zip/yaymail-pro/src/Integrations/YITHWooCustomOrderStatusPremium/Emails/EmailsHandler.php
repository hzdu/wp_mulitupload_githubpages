<?php

namespace YayMail\Integrations\YITHWooCustomOrderStatusPremium\Emails;

use YayMail\Abstracts\BaseEmail;
use YayMail\Utils\SingletonTrait;

/**
 * EmailsHandler Class
 *
 * @method static EmailsHandler get_instance()
 */
class EmailsHandler {
    use SingletonTrait;

    private $emails = [];

    public function add_email( $email ) {
        if ( ! $email instanceof BaseEmail ) {
            return;
        }
        $this->emails[] = $email;
    }

    public function get_emails() {
        return $this->emails;
    }

    public function get_list_id() {
        return array_map(
            function ( $email ) {
                return $email->get_id();
            },
            $this->emails
        );
    }

    public function get_email_by_id( $id ) {
        foreach ( $this->emails as $email ) {
            if ( $email->get_id() === $id ) {
                return $email;
            }
        }
        return null;
    }

    public static function get_status_id_from_order( $order ) {

        if ( empty( $order ) ) {
            return null;
        }

        if ( ! $order instanceof \WC_Order ) {
            return null;
        }

        $status_slug = $order->get_status();
        return 0 === strpos( $status_slug, 'wc-' ) ? $status_slug : 'wc-' . $status_slug;
    }
}
