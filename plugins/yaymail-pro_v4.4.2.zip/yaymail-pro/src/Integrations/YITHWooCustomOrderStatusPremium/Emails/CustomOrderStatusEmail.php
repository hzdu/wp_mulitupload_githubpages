<?php

namespace YayMail\Integrations\YITHWooCustomOrderStatusPremium\Emails;

use YayMail\Abstracts\BaseEmail;
use YayMail\Elements\ElementsLoader;
use YayMail\YayMailTemplate;

/**
 * CustomOrderStatusEmail Class
 *
 * @method static CustomOrderStatusEmail get_instance()
 */
class CustomOrderStatusEmail extends BaseEmail {

    public $template = null;

    const LIST_UNAVAILABLE_ELEMENTS = [
        'order_details_download',
    ];

    public function __construct( $email ) {
        $this->id         = $email->id;
        $this->title      = $email->title;
        $this->root_email = $email;
        $this->recipient  = $email->recipient;
        $this->source     = [
            'plugin_id'   => 'yith-woo-custom-order-status-premium',
            'plugin_name' => 'YITH WooCommerce Custom Order Status Premium',
        ];

        $this->render_priority = apply_filters( 'yaymail_email_render_priority', $this->render_priority, $this->id );

        add_filter( 'wc_get_template', [ $this, 'get_template_file' ], $this->render_priority ?? 10, 3 );
    }

    public function get_default_elements() {
        /* translators: %1$s: email title, %2$s: order ID */
        $heading = sprintf( __( '%1$s: #%2$s', 'yaymail' ), $this->title, '[yaymail_order_id is_plain="true"]' );

        $default_elements = ElementsLoader::load_elements(
            [
                [
                    'type' => 'Logo',
                ],
                [
                    'type'       => 'Heading',
                    'attributes' => [
                        'rich_text' => '<h1 style="font-size: 30px; font-weight: 300; line-height: normal; margin: 0px; color: inherit; text-align: left;">' . $heading . '</h1>',
                    ],
                ],
                [
                    'type'       => 'Text',
                    'attributes' => [
                        'rich_text' => '<p><span>' . __( 'Your order status has been updated to [yaymail_yith_order_status]', 'yaymail' ) . '</span></p>',
                    ],
                ],
                [
                    'type' => 'OrderDetails',
                ],
                [
                    'type' => 'BillingShippingAddress',
                ],
                [
                    'type' => 'Footer',
                ],
            ]
        );

        return $default_elements;
    }

    public function get_template_file( $located, $template_name, $args ) {
        if ( ! isset( $args['email'] ) || 'emails/custom_status_email_template.php' !== $template_name || empty( $args['order'] ) ) {
            return $located;
        }

        $status_id = EmailsHandler::get_status_id_from_order( $args['order'] ?? null );

        if ( empty( $status_id ) ) {
            return $located;
        }

        $status = wc_get_order_status_name( $status_id );

        if ( ! $status || $this->id !== $status_id ) {
            return $located;
        }

        $template_path = $this->get_template_path();
        if ( ! file_exists( $template_path ) ) {
            return $located;
        }

        $order = apply_filters( 'yaymail_order_for_language', isset( $args['order'] ) ? $args['order'] : null, $args );

        $language = $this->get_language( $order );

        $this->template = new YayMailTemplate( $this->id, apply_filters( 'yaymail_email_get_language', $language, $order, $args, $this ) );

        if ( ! $this->template->is_enabled() ) {
            return $located;
        }

        return $template_path;
    }

    public function get_template_path() {
        return YAYMAIL_PLUGIN_PATH . 'src/Integrations/YITHWooCustomOrderStatusPremium/Templates/Emails/custom-order-status.php';
    }
}
