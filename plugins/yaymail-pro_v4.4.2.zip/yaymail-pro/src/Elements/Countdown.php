<?php
namespace YayMail\Elements;

use YayMail\Abstracts\BaseElement;
use YayMail\Utils\SingletonTrait;
/**
 * Countdown Elements
 */
class Countdown extends BaseElement {

    use SingletonTrait;

    protected static $type = 'countdown';

    public $available_email_ids = [ YAYMAIL_ALL_EMAILS ];

    public static function get_data( $attributes = [] ) {
        self::$icon = '<svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.22003 8.48994C7.91003 8.28994 7.50003 8.18994 7.01003 8.18994C6.52003 8.18994 6.10003 8.28994 5.78003 8.48994C5.46003 8.68994 5.22003 8.96994 5.07003 9.32994C4.92003 9.67994 4.84003 10.0999 4.84003 10.5699V14.1999C4.84003 14.6599 4.92003 15.0699 5.08003 15.4199C5.24003 15.7699 5.48003 16.0399 5.80003 16.2399C6.12003 16.4399 6.52003 16.5399 7.01003 16.5399C7.50003 16.5399 7.88003 16.4399 8.20003 16.2399C8.52003 16.0399 8.76003 15.7699 8.92003 15.4199C9.08003 15.0699 9.16003 14.6599 9.16003 14.1999V10.5699C9.16003 10.0999 9.08003 9.67994 8.93003 9.32994C8.78003 8.96994 8.54003 8.68994 8.22003 8.48994ZM7.60003 14.1699C7.60003 14.2999 7.59003 14.4499 7.56003 14.6099C7.53003 14.7599 7.48003 14.8999 7.40003 15.0099C7.32003 15.1199 7.19003 15.1799 7.01003 15.1799C6.83003 15.1799 6.71003 15.1199 6.62003 15.0099C6.53003 14.8999 6.48003 14.7599 6.45003 14.6099C6.42003 14.4499 6.41003 14.2999 6.41003 14.1699V10.5999C6.41003 10.4499 6.42003 10.2999 6.44003 10.1399C6.47003 9.97994 6.52003 9.83994 6.60003 9.72994C6.69003 9.60994 6.82003 9.54994 7.01003 9.54994C7.20003 9.54994 7.33003 9.60994 7.41003 9.72994C7.49003 9.83994 7.54003 9.97994 7.56003 10.1399C7.59003 10.2999 7.60003 10.4499 7.60003 10.5999V14.1699Z" />
<path d="M20 3.75H14C13.21 3.75 12.5 4.09 12 4.62C11.5 4.08 10.79 3.75 10 3.75H4C2.48 3.75 1.25 4.98 1.25 6.5V18.5C1.25 20.02 2.48 21.25 4 21.25H10C10.79 21.25 11.5 20.91 12 20.38C12.5 20.92 13.21 21.25 14 21.25H20C21.52 21.25 22.75 20.02 22.75 18.5V6.5C22.75 4.98 21.52 3.75 20 3.75ZM17.54 5.25V5.69C17.49 5.77 17.41 5.85 17.31 5.94C17.22 6.02 17.09 6.06 16.94 6.06C16.74 6.06 16.6 6 16.51 5.88C16.43 5.76 16.38 5.59 16.36 5.38C16.36 5.34 16.36 5.29 16.36 5.25H17.55H17.54ZM10 19.75H4C3.31 19.75 2.75 19.19 2.75 18.5V6.5C2.75 5.81 3.31 5.25 4 5.25H10C10.69 5.25 11.25 5.81 11.25 6.5V18.5C11.25 19.19 10.69 19.75 10 19.75ZM16.57 16.91C16.67 16.78 16.81 16.72 17 16.72C17.19 16.72 17.34 16.78 17.43 16.91C17.52 17.04 17.58 17.2 17.61 17.4C17.64 17.6 17.66 17.81 17.65 18.02C17.65 18.2 17.64 18.39 17.61 18.58C17.58 18.77 17.52 18.94 17.43 19.07C17.34 19.2 17.19 19.27 17 19.27C16.81 19.27 16.66 19.21 16.56 19.08C16.47 18.95 16.41 18.78 16.38 18.59C16.35 18.39 16.34 18.2 16.34 18.02C16.34 17.8 16.35 17.59 16.38 17.4C16.41 17.2 16.48 17.04 16.57 16.91ZM16.41 14.21C16.41 13.93 16.46 13.7 16.55 13.53C16.65 13.35 16.8 13.26 17 13.26C17.2 13.26 17.34 13.35 17.43 13.53C17.52 13.7 17.57 13.93 17.57 14.22C17.57 14.47 17.55 14.69 17.51 14.88C17.47 15.07 17.41 15.21 17.32 15.31C17.24 15.41 17.13 15.46 17 15.46C16.86 15.46 16.74 15.41 16.65 15.31C16.56 15.21 16.5 15.07 16.46 14.88C16.43 14.69 16.41 14.46 16.41 14.21ZM21.25 18.5C21.25 19.19 20.69 19.75 20 19.75H18.67C18.79 19.6 18.9 19.42 18.97 19.22C19.12 18.84 19.18 18.41 19.17 17.92C19.17 17.7 19.15 17.49 19.1 17.3C19.06 17.11 19 16.93 18.92 16.77C18.84 16.61 18.74 16.47 18.62 16.35C18.51 16.22 18.37 16.12 18.21 16.04C18.44 15.89 18.63 15.67 18.78 15.38C18.94 15.09 19.02 14.71 19.03 14.26C19.03 13.81 18.97 13.43 18.82 13.11C18.67 12.78 18.45 12.53 18.14 12.36C17.84 12.19 17.46 12.1 17 12.1C16.54 12.1 16.17 12.19 15.86 12.36C15.55 12.53 15.32 12.78 15.17 13.11C15.02 13.43 14.94 13.81 14.95 14.26C14.95 14.71 15.04 15.08 15.2 15.37C15.37 15.66 15.56 15.88 15.78 16.04C15.62 16.12 15.48 16.22 15.36 16.35C15.25 16.47 15.15 16.61 15.07 16.77C14.99 16.93 14.93 17.11 14.89 17.3C14.85 17.49 14.83 17.7 14.83 17.92C14.83 18.41 14.9 18.84 15.03 19.22C15.1 19.42 15.21 19.6 15.33 19.75H14C13.31 19.75 12.75 19.19 12.75 18.5V6.5C12.75 5.81 13.31 5.25 14 5.25H14.77C14.79 5.53 14.83 5.8 14.9 6.05C15.01 6.42 15.2 6.71 15.46 6.93C15.72 7.14 16.07 7.25 16.5 7.24C16.73 7.24 16.94 7.19 17.12 7.11C17.3 7.03 17.44 6.92 17.53 6.77V7.6C17.53 8.01 17.51 8.33 17.48 8.57C17.45 8.81 17.39 8.98 17.3 9.08C17.21 9.18 17.09 9.23 16.93 9.23C16.67 9.23 16.5 9.15 16.43 8.98C16.36 8.81 16.33 8.56 16.33 8.22H14.87V8.34C14.87 8.79 14.94 9.17 15.07 9.48C15.2 9.79 15.42 10.02 15.72 10.18C16.02 10.33 16.42 10.41 16.92 10.41C17.5 10.41 17.95 10.29 18.26 10.05C18.57 9.81 18.79 9.48 18.91 9.06C19.03 8.64 19.09 8.17 19.09 7.64V5.25H19.99C20.68 5.25 21.24 5.81 21.24 6.5V18.5H21.25Z" />
</svg>';

        $countdown_label_conditions = [
            'multi_attributes' => true,
            [
                'comparison' => '!=',
                'value'      => true,
                'attribute'  => 'display_text_only',
            ],
            [
                'comparison' => '!=',
                'value'      => false,
                'attribute'  => 'show_unit_label',
            ],
        ];

        $display_text_only_conditions = [
            [
                'comparison' => '!=',
                'value'      => true,
                'attribute'  => 'display_text_only',
            ],
        ];

        return [
            'id'          => uniqid(),
            'type'        => self::$type,
            'name'        => __( 'Countdown', 'yaymail' ),
            'icon'        => self::$icon,
            'group'       => 'basic',
            'available'   => true,
            'position'    => 198,
            'status_info' => [
                'text' => __( 'New', 'yaymail' ),
            ],
            'data'        => [
                'container_group_definition' => [
                    'component'   => 'GroupDefinition',
                    'title'       => __( 'Container settings', 'yaymail' ),
                    'description' => __( 'Handle container layout settings', 'yaymail' ),
                ],
                'padding'                    => [
                    'value_path'    => 'padding',
                    'component'     => 'Spacing',
                    'title'         => __( 'Padding', 'yaymail' ),
                    'default_value' => isset( $attributes['padding'] ) ? $attributes['padding'] : [
                        'top'    => '15',
                        'right'  => '50',
                        'bottom' => '15',
                        'left'   => '50',
                    ],
                    'type'          => 'style',
                ],
                'background_color'           => ElementsHelper::get_color(
                    $attributes,
                    [
                        'default_value' => isset( $attributes['background_color'] ) ? $attributes['background_color'] : '#fff',
                    ]
                ),
                'text_color'                 => ElementsHelper::get_color(
                    $attributes,
                    [
                        'value_path'    => 'text_color',
                        'title'         => __( 'Text color', 'yaymail' ),
                        'default_value' => isset( $attributes['text_color'] ) ? $attributes['text_color'] : '#636363',
                    ]
                ),
                'inner_background_color'     => ElementsHelper::get_color(
                    $attributes,
                    [
                        'value_path'    => 'inner_background_color',
                        'title'         => __( 'Inner background color', 'yaymail' ),
                        'default_value' => isset( $attributes['inner_background_color'] ) ? $attributes['inner_background_color'] : '#ffffff',
                    ]
                ),
                'end_time'                   => [
                    'value_path'    => 'end_time',
                    'component'     => 'DatePicker',
                    'title'         => __( 'End time', 'yaymail' ),
                    'default_value' => isset( $attributes['end_time'] ) ? $attributes['end_time'] : ( new \DateTime() )->modify( '+2 days' )->format( 'Y-m-d H:i:s' ),
                    'type'          => 'content',
                    'calendar_type' => 'single',
                    'show_time'     => true,
                ],
                'spacing'                    => [
                    'value_path'    => 'spacing',
                    'component'     => 'Dimension',
                    'title'         => __( 'Spacing', 'yaymail' ),
                    'default_value' => isset( $attributes['spacing'] ) ? $attributes['spacing'] : '40',
                    'type'          => 'style',
                    'unit'          => 'px',
                    'min'           => 0,
                    'max'           => 100,
                    'step'          => 1,
                ],
                'font_size'                  => [
                    'value_path'    => 'font_size',
                    'component'     => 'Dimension',
                    'title'         => __( 'Font size', 'yaymail' ),
                    'default_value' => isset( $attributes['font_size'] ) ? $attributes['font_size'] : '30',
                    'type'          => 'style',
                    'unit'          => 'px',
                    'min'           => 10,
                    'max'           => 50,
                    'step'          => 1,
                ],
                'display_text_only'          => [
                    'value_path'    => 'display_text_only',
                    'component'     => 'Switcher',
                    'title'         => __( 'Turn out this element into text only', 'yaymail' ),
                    'default_value' => isset( $attributes['display_text_only'] ) ? $attributes['display_text_only'] : false,
                    'type'          => 'content',
                ],
                'label_breaker'              => [
                    'component'  => 'LineBreaker',
                    'conditions' => $display_text_only_conditions,
                ],
                'label_group_definition'     => [
                    'component'   => 'GroupDefinition',
                    'title'       => __( 'Label', 'yaymail' ),
                    'description' => __( 'Handle label settings', 'yaymail' ),
                    'conditions'  => $display_text_only_conditions,
                ],
                // Labels below each group
                'show_unit_label'            => [
                    'value_path'    => 'show_unit_label',
                    'component'     => 'Switcher',
                    'title'         => __( 'Show labels', 'yaymail' ),
                    'default_value' => isset( $attributes['show_unit_label'] ) ? $attributes['show_unit_label'] : true,
                    'type'          => 'content',
                    'conditions'    => $display_text_only_conditions,
                ],
                'label_days'                 => [
                    'value_path'    => 'label_days',
                    'component'     => 'TextInput',
                    'title'         => __( 'Label – Days', 'yaymail' ),
                    'default_value' => isset( $attributes['label_days'] ) ? $attributes['label_days'] : __( 'Days', 'yaymail' ),
                    'type'          => 'style',
                    'conditions'    => $countdown_label_conditions,
                ],
                'label_hours'                => [
                    'value_path'    => 'label_hours',
                    'component'     => 'TextInput',
                    'title'         => __( 'Label – Hours', 'yaymail' ),
                    'default_value' => isset( $attributes['label_hours'] ) ? $attributes['label_hours'] : __( 'Hours', 'yaymail' ),
                    'type'          => 'style',
                    'conditions'    => $countdown_label_conditions,
                ],
                'label_minutes'              => [
                    'value_path'    => 'label_minutes',
                    'component'     => 'TextInput',
                    'title'         => __( 'Label – Minutes', 'yaymail' ),
                    'default_value' => isset( $attributes['label_minutes'] ) ? $attributes['label_minutes'] : __( 'Minutes', 'yaymail' ),
                    'type'          => 'style',
                    'conditions'    => $countdown_label_conditions,
                ],
                'label_seconds'              => [
                    'value_path'    => 'label_seconds',
                    'component'     => 'TextInput',
                    'title'         => __( 'Label – Seconds', 'yaymail' ),
                    'default_value' => isset( $attributes['label_seconds'] ) ? $attributes['label_seconds'] : __( 'Seconds', 'yaymail' ),
                    'type'          => 'style',
                    'conditions'    => $countdown_label_conditions,
                ],

                'label_color'                => ElementsHelper::get_color(
                    $attributes,
                    [
                        'value_path'    => 'label_color',
                        'title'         => __( 'Label color', 'yaymail' ),
                        'default_value' => isset( $attributes['label_color'] ) ? $attributes['label_color'] : '#636363',
                        'conditions'    => $countdown_label_conditions,
                    ]
                ),
                'label_font_size'            => [
                    'value_path'    => 'label_font_size',
                    'component'     => 'Dimension',
                    'title'         => __( 'Label font size', 'yaymail' ),
                    'default_value' => isset( $attributes['label_font_size'] ) ? $attributes['label_font_size'] : '15',
                    'type'          => 'style',
                    'unit'          => 'px',
                    'min'           => 8,
                    'max'           => 20,
                    'step'          => 1,
                    'conditions'    => $countdown_label_conditions,
                ],
            ],
        ];
    }
}
