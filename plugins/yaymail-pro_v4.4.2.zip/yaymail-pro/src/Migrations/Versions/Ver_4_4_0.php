<?php

namespace YayMail\Migrations\Versions;

use YayMail\Migrations\AbstractMigration;
use YayMail\Models\UserSavedPattern;
use YayMail\Utils\SingletonTrait;
use YayMail\YayMailPatternTemplate;

/**
 * Backfill UUID for existing patterns to support import/export deduplication.
 */
final class Ver_4_4_0 extends AbstractMigration {

    use SingletonTrait;

    private function __construct() {
        parent::__construct( '4.3.4', '4.4.0' );
    }

    protected function up() {
        $this->backfill_pattern_post_uuids();
        $this->backfill_saved_pattern_uuids();
    }

    /**
     * Backfill UUID for yaymail_pattern posts that don't have one yet.
     */
    private function backfill_pattern_post_uuids() {
        $this->logger->log( 'Start backfilling UUIDs for yaymail_pattern posts' );

        $posts = get_posts(
            [
                'post_type'      => 'yaymail_pattern',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
            ]
        );

        $count = 0;
        foreach ( $posts as $post_id ) {
            $existing_uuid = get_post_meta( $post_id, YayMailPatternTemplate::META_KEYS['uuid'], true );
            if ( ! empty( $existing_uuid ) ) {
                continue;
            }

            update_post_meta( $post_id, YayMailPatternTemplate::META_KEYS['uuid'], wp_generate_uuid4() );
            ++$count;
        }

        $this->logger->log( "Backfilled UUIDs for {$count} yaymail_pattern post(s)" );
    }

    /**
     * Backfill UUID for user-saved patterns stored in wp_options.
     */
    private function backfill_saved_pattern_uuids() {
        $this->logger->log( 'Start backfilling UUIDs for yaymail_saved_patterns option' );

        $patterns = get_option( UserSavedPattern::OPTION_NAME, [] );
        if ( ! is_array( $patterns ) || empty( $patterns ) ) {
            $this->logger->log( 'No saved patterns found, skipping' );
            return;
        }

        $count   = 0;
        $changed = false;
        foreach ( $patterns as &$pattern ) {
            if ( ! empty( $pattern['uuid'] ) ) {
                continue;
            }

            $pattern['uuid'] = wp_generate_uuid4();
            $changed         = true;
            ++$count;
        }
        unset( $pattern );

        if ( $changed ) {
            update_option( UserSavedPattern::OPTION_NAME, $patterns );
        }

        $this->logger->log( "Backfilled UUIDs for {$count} saved pattern(s)" );
    }
}
