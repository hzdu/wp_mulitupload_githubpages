<?php

namespace YayMail\Constants;

/**
 * Global Variables
 */
class GlobalVariables {
    const COLOR_DEFAULT = [
        'presetName'   => 'Theme',
        'presetColors' => [
            '0'  => [
                'colorName'  => 'Black',
                'colorValue' => '#000000',
            ],
            '1'  => [
                'colorName'  => 'Cyan bluish gray',
                'colorValue' => '#ABB8C3',
            ],
            '2'  => [
                'colorName'  => 'White',
                'colorValue' => '#FFFFFF',
            ],
            '3'  => [
                'colorName'  => 'Pale pink',
                'colorValue' => '#F78DA7',
            ],
            '4'  => [
                'colorName'  => 'Vivid red',
                'colorValue' => '#CF2E2E',
            ],
            '5'  => [
                'colorName'  => 'Luminous vivid orange',
                'colorValue' => '#FF6900',
            ],
            '6'  => [
                'colorName'  => 'Luminous vivid amber',
                'colorValue' => '#FCB900',
            ],
            '7'  => [
                'colorName'  => 'Light green cyan',
                'colorValue' => '#7BDCB5',
            ],
            '8'  => [
                'colorName'  => 'Vivid green cyan',
                'colorValue' => '#00D084',
            ],
            '9'  => [
                'colorName'  => 'Pale cyan blue',
                'colorValue' => '#8ED1FC',
            ],
            '10' => [
                'colorName'  => 'Vivid cyan blue',
                'colorValue' => '#0693E3',
            ],
            '11' => [
                'colorName'  => 'Vivid purple',
                'colorValue' => '#9B51E0',
            ],
        ],
    ];
}
