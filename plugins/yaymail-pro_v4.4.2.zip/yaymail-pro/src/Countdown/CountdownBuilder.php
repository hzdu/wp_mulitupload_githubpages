<?php
namespace YayMail\Countdown;

/**
 * CountdownBuilder Class
 */
class CountdownBuilder {

    private $data = [
        'time'            => null,
        'date_unit'       => 'Days',
        'hour_unit'       => 'Hours',
        'minute_unit'     => 'Minutes',
        'second_unit'     => 'Seconds',
        'background'      => '03265c',
        'color'           => 'ffffff',
        'unit_color'      => 'ffffff',
        'font_size'       => '30',
        'label_font_size' => '15',
        'spacing'         => '40',
        'show_unit_label' => true,
    ];

    public function __construct() {
        $this->data['time'] = new \DateTime();
    }

    public function get_data() {
        return $this->data;
    }

    public function with_time( $time ) {
        $this->data['time'] = $time;
        return $this;
    }

    public function date_unit( $date_unit ) {
        $this->data['date_unit'] = $date_unit;
        return $this;
    }

    public function hour_unit( $hour_unit ) {
        $this->data['hour_unit'] = $hour_unit;
        return $this;
    }

    public function minute_unit( $minute_unit ) {
        $this->data['minute_unit'] = $minute_unit;
        return $this;
    }

    public function second_unit( $second_unit ) {
        $this->data['second_unit'] = $second_unit;
        return $this;
    }

    public function background( $background ) {
        $this->data['background'] = $background;
        return $this;
    }

    public function color( $color ) {
        $this->data['color'] = $color;
        return $this;
    }

    public function unit_color( $unit_color ) {
        $this->data['unit_color'] = $unit_color;
        return $this;
    }

    public function spacing( $spacing ) {
        $this->data['spacing'] = $spacing;
        return $this;
    }

    public function font_size( $font_size ) {
        $this->data['font_size'] = $font_size;
        return $this;
    }

    public function label_font_size( $label_font_size ) {
        $this->data['label_font_size'] = $label_font_size;
        return $this;
    }

    /**
     * Set counter (digits) font size (10-50 px).
     *
     * @param int|string $size
     * @return self
     */
    public function counter_font( $size ) {
        $this->data['counter_font'] = $size;
        return $this;
    }

    public function show_unit_label( $show_unit_label ) {
        $this->data['show_unit_label'] = $show_unit_label;
        return $this;
    }

    public function draw() {
        $url = add_query_arg(
            [
                'action' => 'yaymail_timer',
                'dt'     => $this->data['time'] ? $this->data['time'] : '',
                'tc'     => $this->data['color'],
                'bg'     => $this->data['background'],
                'fs'     => $this->data['font_size'],
                'sl'     => $this->data['show_unit_label'] ? '1' : '0',
                'ld'     => $this->data['date_unit'],
                'lh'     => $this->data['hour_unit'],
                'lm'     => $this->data['minute_unit'],
                'ls'     => $this->data['second_unit'],
                'lfs'    => $this->data['label_font_size'],
                'lc'     => $this->data['unit_color'],
                'gap'    => $this->data['spacing'],
            ],
            home_url( '/' )
        );
        return $url;
    }
}
