<?php
/**
 * Functions for storing snippet preview drafts, configuration, and tokens.
 *
 * @package Code_Snippets
 */

namespace Code_Snippets\Preview;

use Code_Snippets\Core\DB;
use function Code_Snippets\clean_snippets_cache;
use function Code_Snippets\code_snippets;
use function Code_Snippets\delete_snippet;
use function Code_Snippets\Settings\get_setting;
use const Code_Snippets\PLUGIN_FILE;
use const Code_Snippets\PLUGIN_VERSION;

const USER_META_DRAFTS_KEY = 'code_snippets_preview_drafts_v1';
const USER_META_CONFIG_KEY = 'code_snippets_preview_config_v1';
const TOKEN_TRANSIENT_PREFIX = 'code_snippets_preview_token_';
const CLEANUP_CRON_HOOK = 'code_snippets_preview_cleanup';

defined( 'ABSPATH' ) || exit;

/**
 * Determine whether a snippet is the one being previewed in the current request.
 *
 * @param int  $snippet_id Snippet ID.
 * @param bool $network    Whether the snippet is network-wide.
 *
 * @return bool
 */
function is_preview_snippet( int $snippet_id, bool $network ): bool {
	return defined( 'CODE_SNIPPETS_PREVIEW_MODE' ) && CODE_SNIPPETS_PREVIEW_MODE &&
		defined( 'CODE_SNIPPETS_PREVIEW_SNIPPET_ID' ) && (int) CODE_SNIPPETS_PREVIEW_SNIPPET_ID === $snippet_id &&
		defined( 'CODE_SNIPPETS_PREVIEW_SNIPPET_NETWORK' ) && (bool) CODE_SNIPPETS_PREVIEW_SNIPPET_NETWORK === $network;
}

/**
 * Build a stable key for a per-user snippet preview entry.
 *
 * @param int  $snippet_id Snippet ID.
 * @param bool $network Whether snippet is network-wide.
 *
 * @return string
 */
function build_user_snippet_key( int $snippet_id, bool $network ): string {
	$snippet_id = absint( $snippet_id );
	if ( $network ) {
		return sprintf( 'n:%d', $snippet_id );
	}

	$blog_id = is_multisite() ? get_current_blog_id() : 0;
	return sprintf( 's:%d:%d', absint( $blog_id ), $snippet_id );
}

/**
 * Retrieve all saved preview drafts for a user.
 *
 * @param int $user_id User ID.
 *
 * @return array<string, array<string, mixed>>
 */
function get_all_drafts( int $user_id ): array {
	$drafts = get_user_meta( $user_id, USER_META_DRAFTS_KEY, true );
	return is_array( $drafts ) ? $drafts : [];
}

/**
 * Retrieve a saved preview draft for a user+snippet.
 *
 * @param int  $user_id User ID.
 * @param int  $snippet_id Snippet ID.
 * @param bool $network Whether snippet is network-wide.
 *
 * @return ?array<string, mixed>
 */
function get_draft( int $user_id, int $snippet_id, bool $network ): ?array {
	$key = build_user_snippet_key( $snippet_id, $network );
	$drafts = get_all_drafts( $user_id );

	return isset( $drafts[ $key ] ) && is_array( $drafts[ $key ] ) ? $drafts[ $key ] : null;
}

/**
 * Save a preview draft for a user+snippet.
 *
 * @param int                  $user_id User ID.
 * @param int                  $snippet_id Snippet ID.
 * @param bool                 $network Whether snippet is network-wide.
 * @param array<string, mixed> $draft Draft payload.
 *
 * @return void
 */
function set_draft( int $user_id, int $snippet_id, bool $network, array $draft ): void {
	$key = build_user_snippet_key( $snippet_id, $network );
	$drafts = get_all_drafts( $user_id );
	$drafts[ $key ] = $draft + [ 'updated_at' => time() ];
	update_user_meta( $user_id, USER_META_DRAFTS_KEY, $drafts );
}

/**
 * Retrieve all saved preview configs for a user.
 *
 * @param int $user_id User ID.
 *
 * @return array<string, array<string, mixed>>
 */
function get_all_configs( int $user_id ): array {
	$configs = get_user_meta( $user_id, USER_META_CONFIG_KEY, true );
	return is_array( $configs ) ? $configs : [];
}

/**
 * Retrieve the saved preview config for a user+snippet.
 *
 * @param int  $user_id User ID.
 * @param int  $snippet_id Snippet ID.
 * @param bool $network Whether snippet is network-wide.
 *
 * @return array{type: ?string, url: ?string}
 */
function get_config( int $user_id, int $snippet_id, bool $network ): array {
	$key = build_user_snippet_key( $snippet_id, $network );
	$configs = get_all_configs( $user_id );
	$config = isset( $configs[ $key ] ) && is_array( $configs[ $key ] ) ? $configs[ $key ] : [];

	return [
		'type' => is_string( $config['type'] ?? null ) ? $config['type'] : null,
		'url'  => is_string( $config['url'] ?? null ) ? $config['url'] : null,
	];
}

/**
 * Save the preview config for a user+snippet.
 *
 * @param int    $user_id User ID.
 * @param int    $snippet_id Snippet ID.
 * @param bool   $network Whether snippet is network-wide.
 * @param string $type       Preview type: front, post, page, or admin.
 * @param string $url        Absolute URL of the page to preview on.
 *
 * @return void
 */
function set_config( int $user_id, int $snippet_id, bool $network, string $type, string $url ): void {
	$key = build_user_snippet_key( $snippet_id, $network );
	$configs = get_all_configs( $user_id );

	$configs[ $key ] = [
		'type'       => $type,
		'url'        => $url,
		'updated_at' => time(),
	];

	update_user_meta( $user_id, USER_META_CONFIG_KEY, $configs );
}

/**
 * Issue a new preview token bound to a specific user+snippet.
 *
 * @param int  $user_id User ID.
 * @param int  $snippet_id Snippet ID.
 * @param bool $network Whether snippet is network-wide.
 * @param int  $ttl Token lifetime in seconds.
 *
 * @return string
 */
function issue_token( int $user_id, int $snippet_id, bool $network, int $ttl = HOUR_IN_SECONDS ): string {
	$token = wp_generate_password( 32, false, false );

	$payload = [
		'user_id'    => $user_id,
		'snippet_id' => absint( $snippet_id ),
		'network'    => (bool) $network,
		'issued_at'  => time(),
	];

	if ( ! $network && is_multisite() ) {
		$payload['blog_id'] = get_current_blog_id();
		set_site_transient( TOKEN_TRANSIENT_PREFIX . $token, $payload, $ttl );
		return $token;
	}

	set_transient(
		TOKEN_TRANSIENT_PREFIX . $token,
		$payload,
		$ttl
	);

	return $token;
}

/**
 * Fetch token data for a preview token.
 *
 * @param string $token Token value.
 *
 * @return ?array{user_id:int, snippet_id:int, network:bool, issued_at:int}
 */
function get_token_data( string $token ): ?array {
	$token = preg_replace( '/[^a-zA-Z0-9]/', '', $token );
	if ( ! $token ) {
		return null;
	}

	$key = TOKEN_TRANSIENT_PREFIX . $token;
	$data = get_transient( $key );
	if ( ! is_array( $data ) && is_multisite() ) {
		$data = get_site_transient( $key );
	}

	if ( ! is_array( $data ) ) {
		return null;
	}

	$network = (bool) ( $data['network'] ?? false );
	if ( ! $network && is_multisite() ) {
		$blog_id = absint( $data['blog_id'] ?? 0 );
		if ( $blog_id && get_current_blog_id() !== $blog_id ) {
			return null;
		}
	}

	return [
		'user_id'    => absint( $data['user_id'] ?? 0 ),
		'snippet_id' => absint( $data['snippet_id'] ?? 0 ),
		'network'    => $network,
		'issued_at'  => absint( $data['issued_at'] ?? 0 ),
	];
}

/**
 * Create a hidden draft snippet record (active=-2) used for previewing brand-new snippets.
 *
 * @param array{scope:string, priority:int, condition_id:int, name?:string} $fields Draft snippet fields.
 * @param bool                                                              $network Whether snippet should be created in the network table.
 *
 * @return int New snippet ID, or 0 on failure.
 */
function create_placeholder_snippet( array $fields, bool $network ): int {
	global $wpdb;

	$network = DB::validate_network_param( $network );
	$table = code_snippets()->db->get_table_name( $network );

	$insert = [
		'name'         => sanitize_text_field( $fields['name'] ?? '' ),
		'description'  => '',
		'code'         => '',
		'tags'         => '',
		'scope'        => sanitize_key( $fields['scope'] ?? 'global' ),
		'condition_id' => absint( $fields['condition_id'] ?? 0 ),
		'priority'     => intval( $fields['priority'] ?? 10 ),
		'active'       => -2,
		'modified'     => gmdate( 'Y-m-d H:i:s' ),
		'revision'     => 1,
		'cloud_id'     => null,
	];

	$result = $wpdb->insert( $table, $insert, [ '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%d', '%s' ] );

	if ( false === $result ) {
		return 0;
	}

	clean_snippets_cache( $table );

	return (int) $wpdb->insert_id;
}

/**
 * Update the modified timestamp for a placeholder draft snippet.
 *
 * This is used to track activity so that abandoned preview drafts can be cleaned up.
 *
 * @param int  $snippet_id Snippet ID.
 * @param bool $network Whether snippet is network-wide.
 *
 * @return void
 */
function touch_placeholder_snippet( int $snippet_id, bool $network ): void {
	global $wpdb;

	$snippet_id = absint( $snippet_id );
	if ( ! $snippet_id ) {
		return;
	}

	$network = DB::validate_network_param( $network );
	$table = code_snippets()->db->get_table_name( $network );

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->update(
		$table,
		[ 'modified' => gmdate( 'Y-m-d H:i:s' ) ],
		[
			'id'     => $snippet_id,
			'active' => -2,
		],
		[ '%s' ],
		[ '%d', '%d' ]
	);
}

/**
 * Retrieve the configured preview draft retention time.
 *
 * @return int Retention time in hours. Zero disables cleanup.
 */
function get_draft_retention_hours(): int {
	return absint( get_setting( 'preview', 'draft_retention_hours' ) );
}

/**
 * Delete expired placeholder draft snippets.
 *
 * @param bool $network Whether to delete from the network table.
 *
 * @return int Number of deleted snippets.
 */
function delete_expired_placeholder_snippets( bool $network ): int {
	global $wpdb;

	$retention_hours = get_draft_retention_hours();
	if ( $retention_hours <= 0 ) {
		return 0;
	}

	$network = DB::validate_network_param( $network );
	$table = code_snippets()->db->get_table_name( $network );

	$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $retention_hours * HOUR_IN_SECONDS ) );

	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$ids = $wpdb->get_col(
		$wpdb->prepare(
			"SELECT id FROM $table WHERE active = -2 AND modified < %s",
			$cutoff
		)
	);
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

	if ( ! $ids ) {
		return 0;
	}

	$deleted = 0;
	foreach ( $ids as $id ) {
		if ( delete_snippet( absint( $id ), $network ) ) {
			++$deleted;
		}
	}

	return $deleted;
}

/**
 * Run preview draft cleanup on scheduled cron.
 *
 * @return void
 */
function run_preview_cleanup(): void {
	if ( get_draft_retention_hours() <= 0 ) {
		return;
	}

	delete_expired_placeholder_snippets( false );

	if ( is_multisite() ) {
		delete_expired_placeholder_snippets( true );
	}
}

/**
 * Ensure the preview cleanup cron is scheduled when enabled.
 *
 * @return void
 */
function maybe_schedule_preview_cleanup(): void {
	if ( get_draft_retention_hours() <= 0 ) {
		wp_clear_scheduled_hook( CLEANUP_CRON_HOOK );
		return;
	}

	if ( ! wp_next_scheduled( CLEANUP_CRON_HOOK ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', CLEANUP_CRON_HOOK );
	}
}

add_action( 'init', __NAMESPACE__ . '\\maybe_schedule_preview_cleanup' );
add_action( CLEANUP_CRON_HOOK, __NAMESPACE__ . '\\run_preview_cleanup' );

/**
 * Validate a preview URL, ensuring it stays on the same site and origin.
 *
 * @param string $url Preview URL, absolute or relative to the site home.
 *
 * @return string|\WP_Error Normalized absolute URL on success, or WP_Error on failure.
 */
function validate_preview_url( string $url ) {
	$url = trim( wp_unslash( $url ) );
	if ( '' === $url ) {
		return new \WP_Error( 'code_snippets_preview_invalid_url', __( 'Please choose a page to preview on.', 'code-snippets' ) );
	}

	if ( '/' === $url[0] ) {
		$url = home_url( $url );
	}

	$parsed = wp_parse_url( $url );
	if ( ! is_array( $parsed ) || empty( $parsed['host'] ) || empty( $parsed['scheme'] ) ) {
		return new \WP_Error( 'code_snippets_preview_invalid_url', __( 'Please enter a valid URL.', 'code-snippets' ) );
	}

	if ( ! empty( $parsed['user'] ) || ! empty( $parsed['pass'] ) ) {
		return new \WP_Error( 'code_snippets_preview_invalid_url', __( 'URLs with embedded credentials are not allowed.', 'code-snippets' ) );
	}

	$default_port = static fn( array $parts ): int => isset( $parts['port'] ) ? (int) $parts['port'] : ( 'https' === $parts['scheme'] ? 443 : 80 );
	$path = ( $parsed['path'] ?? '/' ) . '/';

	// The front end lives under the home URL and the admin under the site URL; either may be a subdirectory.
	foreach ( [ home_url( '/' ), site_url( '/' ) ] as $base_url ) {
		$base = wp_parse_url( $base_url );

		if ( ! is_array( $base ) || empty( $base['host'] ) || empty( $base['scheme'] ) ) {
			continue;
		}

		$base_path = rtrim( $base['path'] ?? '/', '/' ) . '/';

		if ( strtolower( $parsed['scheme'] ) === strtolower( $base['scheme'] ) &&
			strtolower( $parsed['host'] ) === strtolower( $base['host'] ) &&
			$default_port( $parsed ) === $default_port( $base ) &&
			0 === strpos( $path, $base_path ) ) {
			return esc_url_raw( $url );
		}
	}

	return new \WP_Error( 'code_snippets_preview_invalid_url', __( 'The preview URL must be on this site.', 'code-snippets' ) );
}

/**
 * Render a fatal preview error page with stack trace.
 *
 * @param \Throwable $error Error to display.
 * @param int        $snippet_id Snippet ID.
 * @param bool       $network Whether snippet is network-wide.
 *
 * @return never
 */
function render_error_page( \Throwable $error, int $snippet_id, bool $network ) {
	$title = __( 'Snippet Preview Error', 'code-snippets' );

	$styles = '';
	$css_url = plugins_url( 'dist/preview-error.css', PLUGIN_FILE );
	wp_enqueue_style( 'code-snippets-preview-error', $css_url, [], PLUGIN_VERSION );
	if ( function_exists( 'wp_print_styles' ) ) {
		ob_start();
		wp_print_styles( 'code-snippets-preview-error' );
		$styles = (string) ob_get_clean();
	}

	$edit_url = add_query_arg( 'id', $snippet_id, code_snippets()->get_menu_url( 'edit', $network ? 'network' : 'admin' ) );
	$back_link = sprintf(
		'<p><a href="%s">%s</a></p>',
		esc_url( $edit_url ),
		esc_html__( 'Back to snippet editor', 'code-snippets' )
	);

	$body = $styles . '<div class="code-snippets-preview-error">' . $back_link .
		'<h2>' . esc_html__( 'The previewed snippet caused a fatal error.', 'code-snippets' ) . '</h2>' .
		'<h3>' . esc_html__( 'Type', 'code-snippets' ) . '</h3>' .
		'<pre>' . esc_html( get_class( $error ) ) . '</pre>' .
		'<h3>' . esc_html__( 'Location', 'code-snippets' ) . '</h3>' .
		'<pre>' . esc_html( $error->getFile() . ' : ' . $error->getLine() ) . '</pre>' .
		'<h3>' . esc_html__( 'Message', 'code-snippets' ) . '</h3>' .
		'<pre>' . esc_html( $error->getMessage() ) . '</pre>' .
		'<h3>' . esc_html__( 'Stack trace', 'code-snippets' ) . '</h3>' .
		'<pre class="code-snippets-error-trace">' . esc_html( $error->getTraceAsString() ) . '</pre></div>';

	wp_die(
		$body, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every dynamic part of the body is escaped above.
		esc_html( $title ),
		[
			'response'  => 500,
			'back_link' => false,
		]
	);
	exit;
}
