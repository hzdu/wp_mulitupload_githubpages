<?php

namespace Code_Snippets\Preview;

use const Code_Snippets\PLUGIN_FILE;
use const Code_Snippets\PLUGIN_VERSION;

/**
 * Snippet preview monitor assets + runtime log panel.
 *
 * Loaded during preview requests to capture snippet-related JS warnings/errors.
 */
class Snippet_Preview_Monitor {

	/**
	 * Snippet preview runtime for the current request.
	 *
	 * @var Snippet_Preview
	 */
	private Snippet_Preview $preview;

	/**
	 * Class constructor.
	 *
	 * @param Snippet_Preview $preview Snippet preview runtime for the current request.
	 */
	public function __construct( Snippet_Preview $preview ) {
		$this->preview = $preview;

		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ], 0 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ], 0 );
	}

	/**
	 * Enqueue the error monitor on preview requests.
	 *
	 * @return void
	 */
	public function enqueue_assets(): void {
		if ( ! $this->preview->is_active() ) {
			return;
		}

		$handle = 'code-snippets-preview-monitor';

		wp_enqueue_style(
			$handle,
			plugins_url( 'dist/preview-monitor.css', PLUGIN_FILE ),
			[],
			PLUGIN_VERSION
		);

		wp_enqueue_script(
			$handle,
			plugins_url( 'dist/preview-monitor.js', PLUGIN_FILE ),
			[],
			PLUGIN_VERSION,
			false
		);

		wp_add_inline_script(
			$handle,
			'window.codeSnippetsPreviewMonitor=' . wp_json_encode(
				[
					'source'        => $this->preview->get_preview_source_name(),
					'updatingLabel' => __( 'Updating preview…', 'code-snippets' ),
				]
			) . ';',
			'before'
		);
	}
}
