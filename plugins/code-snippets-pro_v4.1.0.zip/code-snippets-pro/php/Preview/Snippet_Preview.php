<?php

namespace Code_Snippets\Preview;

use Code_Snippets\Model\Snippet;
use Code_Snippets\Settings\Permissions;
use function Code_Snippets\code_snippets;
use function Code_Snippets\get_snippet;
use function Code_Snippets\Conditions\evaluate_condition;
use function Code_Snippets\Settings\get_setting;
use const Code_Snippets\PLUGIN_VERSION;

/**
 * Runtime integration for snippet previews.
 *
 * Activated by appending a valid token query var to any front-end or wp-admin URL.
 */
class Snippet_Preview {

	/**
	 * Query variable carrying the preview token.
	 */
	public const QUERY_VAR = 'code-snippets-preview';

	/**
	 * Whether the current request is a valid preview request.
	 *
	 * @var bool
	 */
	private bool $active = false;

	/**
	 * Preview token for the current request.
	 *
	 * @var string
	 */
	private string $token = '';

	/**
	 * ID of the user the preview token was issued to.
	 *
	 * @var int
	 */
	private int $user_id = 0;

	/**
	 * ID of the snippet being previewed.
	 *
	 * @var int
	 */
	private int $snippet_id = 0;

	/**
	 * Whether the snippet being previewed is network-wide.
	 *
	 * @var bool
	 */
	private bool $network = false;

	/**
	 * Draft snippet fields to run in place of the saved snippet.
	 *
	 * @var array{code:string, scope:string, priority:int, condition_id:int, updated_at?:int}|null
	 */
	private ?array $draft = null;

	/**
	 * Side effects the preview is allowed to cause, read once when the preview starts.
	 *
	 * @var string[]
	 */
	private array $permissions = [];

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'bootstrap' ], 0 );

		add_filter( 'code_snippets/active_snippets', [ $this, 'filter_active_snippets' ], 5, 2 );
		add_filter( 'code_snippets/active_snippets_from_flat_files', [ $this, 'filter_active_snippets' ], 5, 2 );
		add_filter( 'code_snippets/get_snippet', [ $this, 'filter_get_snippet' ], 5, 3 );

		add_filter( 'query', [ $this, 'maybe_block_db_write_query' ], 0 );
		add_filter( 'file_mod_allowed', [ $this, 'maybe_block_file_modifications' ], 0 );
		add_filter( 'wp_handle_upload_prefilter', [ $this, 'maybe_block_upload' ], 0 );
		add_filter( 'wp_handle_sideload_prefilter', [ $this, 'maybe_block_upload' ], 0 );

		add_filter( 'wp_headers', [ $this, 'filter_headers' ], 0 );
		add_filter( 'wp_redirect', [ $this, 'preserve_token_on_redirect' ], 0 );

		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_preview_assets' ], 100 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_preview_assets' ], 100 );

		add_filter( 'the_content', [ $this, 'inject_content_snippet' ], 0 );
		add_filter( 'pre_http_request', [ $this, 'maybe_block_http_request' ], 0 );
		add_filter( 'pre_wp_mail', [ $this, 'maybe_block_wp_mail' ], 0 );

		new Snippet_Preview_Monitor( $this );
	}

	/**
	 * Determine if a SQL query is a write operation.
	 *
	 * @param string $query SQL query string.
	 *
	 * @return bool
	 */
	private function is_write_query( string $query ): bool {
		$query = (string) preg_replace( '/^\s*(?:\/\*.*?\*\/\s*)+/s', '', $query );
		$query = ltrim( $query );

		return 1 === preg_match( '/^(?:insert|update|delete|replace|create|alter|drop|truncate|rename)\b/i', $query );
	}

	/**
	 * Determine whether the preview is allowed to cause a type of side effect.
	 *
	 * @param string $permission Permission name: http, mail, db_write, or filesystem_write.
	 *
	 * @return bool
	 */
	private function is_permitted( string $permission ): bool {
		return in_array( $permission, $this->permissions, true );
	}

	/**
	 * Enforce preview-mode permissions for database writes.
	 *
	 * @param string $query SQL query.
	 *
	 * @return string
	 */
	public function maybe_block_db_write_query( string $query ): string {
		if ( ! $this->active || '' === $query ) {
			return $query;
		}

		return $this->is_permitted( 'db_write' ) || ! $this->is_write_query( $query ) ? $query : '';
	}

	/**
	 * Enforce preview-mode permissions for filesystem modifications.
	 *
	 * @param bool $allowed Whether file modifications are allowed.
	 *
	 * @return bool
	 */
	public function maybe_block_file_modifications( bool $allowed ): bool {
		if ( ! $this->active ) {
			return $allowed;
		}

		return $this->is_permitted( 'filesystem_write' ) && $allowed;
	}

	/**
	 * Enforce preview-mode permissions for file uploads.
	 *
	 * @param array $file File data.
	 *
	 * @return array
	 */
	public function maybe_block_upload( array $file ): array {
		if ( ! $this->active ) {
			return $file;
		}

		if ( $this->is_permitted( 'filesystem_write' ) ) {
			return $file;
		}

		$file['error'] = __( 'Filesystem writes are blocked in Snippet Preview mode.', 'code-snippets' );
		return $file;
	}

	/**
	 * Determine if preview mode is active for this request.
	 *
	 * @return bool
	 */
	public function is_active(): bool {
		return $this->active;
	}

	/**
	 * Detect and validate preview token and draft state.
	 *
	 * @return void
	 */
	public function bootstrap(): void {
		if ( empty( $_GET[ self::QUERY_VAR ] ) ) {
			return;
		}

		$token = sanitize_text_field( wp_unslash( $_GET[ self::QUERY_VAR ] ) );
		$data = get_token_data( $token );

		if ( ! $data || empty( $data['snippet_id'] ) || empty( $data['user_id'] ) ) {
			wp_die( esc_html__( 'Invalid snippet preview token.', 'code-snippets' ), 403 );
		}

		$user_id = get_current_user_id();
		if ( ! $user_id || $user_id !== (int) $data['user_id'] ) {
			wp_die( esc_html__( 'You are not authorised to access this snippet preview.', 'code-snippets' ), 403 );
		}

		$network = (bool) $data['network'];
		if ( $network && ! code_snippets()->user_can_manage_network_snippets() ) {
			wp_die( esc_html__( 'You are not authorised to preview network snippets.', 'code-snippets' ), 403 );
		}

		if ( ! code_snippets()->current_user_can() || ! Permissions::current_user_can_edit_snippets() ) {
			wp_die( esc_html__( 'You are not authorised to preview snippets on this site.', 'code-snippets' ), 403 );
		}

		$snippet_id = (int) $data['snippet_id'];
		$draft = get_draft( $user_id, $snippet_id, $network );

		if ( ! $draft || ! isset( $draft['code'], $draft['scope'], $draft['priority'], $draft['condition_id'] ) ) {
			wp_die( esc_html__( 'Preview draft data was not found.', 'code-snippets' ), 404 );
		}

		// Read before activating, as the query filter must not load settings itself.
		$permissions = get_setting( 'preview', 'preview_permissions' );
		$this->permissions = is_array( $permissions ) ? $permissions : [];

		$this->active = true;
		$this->token = $token;
		$this->user_id = $user_id;
		$this->snippet_id = $snippet_id;
		$this->network = $network;
		$this->draft = $draft;

		if ( ! defined( 'CODE_SNIPPETS_PREVIEW_MODE' ) ) {
			define( 'CODE_SNIPPETS_PREVIEW_MODE', true );
		}
		if ( ! defined( 'CODE_SNIPPETS_PREVIEW_SNIPPET_ID' ) ) {
			define( 'CODE_SNIPPETS_PREVIEW_SNIPPET_ID', $snippet_id );
		}
		if ( ! defined( 'CODE_SNIPPETS_PREVIEW_SNIPPET_NETWORK' ) ) {
			define( 'CODE_SNIPPETS_PREVIEW_SNIPPET_NETWORK', $network ? 1 : 0 );
		}

		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
		if ( ! defined( 'DONOTCACHEDB' ) ) {
			define( 'DONOTCACHEDB', true );
		}
	}

	/**
	 * Determine whether a snippet entry refers to the current previewed snippet.
	 *
	 * @param array<string, mixed> $snippet Snippet entry.
	 *
	 * @return bool
	 */
	private function is_preview_entry( array $snippet ): bool {
		if ( ! $this->active ) {
			return false;
		}

		return (int) ( $snippet['id'] ?? 0 ) === $this->snippet_id &&
			(bool) ( $snippet['network'] ?? false ) === $this->network;
	}

	/**
	 * Filter DB active snippets so the preview uses the draft only.
	 *
	 * @param array<int, array<string, mixed>> $active_snippets Active snippets.
	 * @param string[]                         $scopes Requested scopes.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function filter_active_snippets( array $active_snippets, array $scopes ): array {
		if ( ! $this->active || ! $this->draft ) {
			return $active_snippets;
		}

		$draft_scope = (string) $this->draft['scope'];
		$draft_type = Snippet::get_type_from_scope( $draft_scope );

		// Always remove the saved/active entry (draft must run exclusively).
		$active_snippets = array_values(
			array_filter(
				$active_snippets,
				function ( array $snippet ): bool {
					return ! $this->is_preview_entry( $snippet );
				}
			)
		);

		// Only re-add for scopes handled by the core evaluators (PHP + head/footer content).
		if ( ! in_array( $draft_scope, $scopes, true ) ) {
			return $active_snippets;
		}

		if ( ! in_array( $draft_type, [ 'php', 'html' ], true ) ) {
			return $active_snippets;
		}

		$active_snippets[] = [
			'id'           => $this->snippet_id,
			'code'         => (string) $this->draft['code'],
			'scope'        => $draft_scope,
			'table'        => $this->network ? code_snippets()->db->ms_table : code_snippets()->db->table,
			'network'      => $this->network,
			'priority'     => (int) $this->draft['priority'],
			'condition_id' => (int) $this->draft['condition_id'],
		];

		return $this->sort_active_snippets( $active_snippets );
	}

	/**
	 * Override snippet objects retrieved by get_snippet() during preview requests.
	 *
	 * Useful for rendering content snippets, as they are not evaluated via the active-snippets pipeline.
	 *
	 * @param Snippet|null $snippet Snippet object, or null if no snippet was found.
	 * @param int          $id      Requested snippet ID.
	 * @param bool         $network Whether the snippet was fetched from the network table.
	 *
	 * @return Snippet|null
	 */
	public function filter_get_snippet( ?Snippet $snippet, int $id, bool $network ): ?Snippet {
		if ( ! $snippet || ! $this->active || ! $this->draft ) {
			return $snippet;
		}

		if ( $id !== $this->snippet_id || $network !== $this->network ) {
			return $snippet;
		}

		$snippet->code = (string) $this->draft['code'];
		$snippet->scope = (string) $this->draft['scope'];
		$snippet->priority = (int) $this->draft['priority'];
		$snippet->condition_id = (int) $this->draft['condition_id'];

		// Treat as active during preview so shortcodes render.
		$snippet->active = true;

		return $snippet;
	}

	/**
	 * Disable caching/indexing headers during preview.
	 *
	 * @param array<string, string> $headers Headers.
	 *
	 * @return array<string, string>
	 */
	public function filter_headers( array $headers ): array {
		if ( ! $this->active ) {
			return $headers;
		}

		$headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0';
		$headers['Pragma'] = 'no-cache';
		$headers['Expires'] = 'Wed, 11 Jan 1984 05:00:00 GMT';
		$headers['X-Robots-Tag'] = 'noindex, nofollow';
		$headers['Referrer-Policy'] = 'same-origin';

		return $headers;
	}

	/**
	 * Preserve the preview token across redirects (canonical redirects, admin redirects, etc).
	 *
	 * @param string $location Redirect location.
	 *
	 * @return string
	 */
	public function preserve_token_on_redirect( string $location ): string {
		if ( ! $this->active || '' === $location ) {
			return $location;
		}

		// Do not leak tokens to other origins.
		$target = wp_parse_url( $location );
		$base = wp_parse_url( home_url( '/' ) );

		if ( is_array( $target ) && is_array( $base ) && isset( $target['host'], $base['host'] ) ) {
			$base_port = isset( $base['port'] ) ? (int) $base['port'] : ( 'https' === ( $base['scheme'] ?? '' ) ? 443 : 80 );
			$target_port = isset( $target['port'] ) ? (int) $target['port'] : ( 'https' === ( $target['scheme'] ?? '' ) ? 443 : 80 );

			if ( isset( $target['scheme'], $base['scheme'] ) && strtolower( $target['scheme'] ) !== strtolower( $base['scheme'] ) ) {
				return $location;
			}

			if ( strtolower( $target['host'] ) !== strtolower( $base['host'] ) ) {
				return $location;
			}

			if ( $target_port !== $base_port ) {
				return $location;
			}
		}

		return add_query_arg( self::QUERY_VAR, $this->token, $location );
	}

	/**
	 * Enqueue draft CSS/JS snippets as isolated inline assets to preserve error attribution.
	 *
	 * @return void
	 */
	public function enqueue_preview_assets(): void {
		if ( ! $this->active || ! $this->draft ) {
			return;
		}

		$scope = (string) $this->draft['scope'];
		$type = Snippet::get_type_from_scope( $scope );

		if ( 'css' === $type ) {
			$this->enqueue_preview_css();
		} elseif ( 'js' === $type ) {
			$this->enqueue_preview_js();
		}
	}

	/**
	 * Enqueue the draft stylesheet as an inline style.
	 *
	 * @return void
	 */
	private function enqueue_preview_css(): void {
		if ( ! $this->draft ) {
			return;
		}

		$scope = (string) $this->draft['scope'];
		$is_admin = is_admin();

		if ( ( 'site-css' === $scope && $is_admin ) || ( 'admin-css' === $scope && ! $is_admin ) ) {
			return;
		}

		if ( ! $this->is_condition_met() ) {
			return;
		}

		$handle = 'code-snippets-preview-css-' . $this->snippet_id;
		wp_register_style( $handle, false, [], PLUGIN_VERSION );
		wp_enqueue_style( $handle );
		wp_add_inline_style( $handle, (string) $this->draft['code'] );
	}

	/**
	 * Enqueue the draft script as an inline script.
	 *
	 * @return void
	 */
	private function enqueue_preview_js(): void {
		if ( ! $this->draft ) {
			return;
		}

		$scope = (string) $this->draft['scope'];

		// JS snippets only run on the front-end in this plugin.
		if ( is_admin() ) {
			return;
		}

		if ( ! in_array( $scope, [ 'site-head-js', 'site-footer-js' ], true ) ) {
			return;
		}

		if ( ! $this->is_condition_met() ) {
			return;
		}

		$in_footer = 'site-footer-js' === $scope;
		$handle = 'code-snippets-preview-js-' . $this->snippet_id;

		wp_register_script( $handle, false, [], PLUGIN_VERSION, $in_footer );
		wp_enqueue_script( $handle );

		$code = (string) $this->draft['code'];
		$code .= "\n//# sourceURL=" . $this->get_preview_source_name() . "\n";
		wp_add_inline_script( $handle, $code );
	}

	/**
	 * Retrieve the source name the draft script is attributed to in browser error reports.
	 *
	 * @return string
	 */
	public function get_preview_source_name(): string {
		return sprintf( 'code-snippets-preview-snippet-%d.js', $this->snippet_id );
	}

	/**
	 * If previewing a content snippet, inject its content into the page content for visibility.
	 *
	 * @param string $content Existing post content.
	 *
	 * @return string
	 */
	public function inject_content_snippet( string $content ): string {
		if ( ! $this->active || ! $this->draft ) {
			return $content;
		}

		if ( is_admin() ) {
			return $content;
		}

		if ( 'content' !== (string) $this->draft['scope'] ) {
			return $content;
		}

		if ( ! $this->is_condition_met() ) {
			return $content;
		}

		return (string) $this->draft['code'] . "\n\n" . $content;
	}

	/**
	 * Evaluate the draft condition, if any.
	 *
	 * @return bool
	 */
	private function is_condition_met(): bool {
		if ( ! $this->draft ) {
			return false;
		}

		$condition_id = (int) $this->draft['condition_id'];
		if ( ! $condition_id ) {
			return true;
		}

		$condition = get_snippet( $condition_id, $this->network );
		if ( ! $condition || ! $condition->id ) {
			return false;
		}

		return evaluate_condition( $condition->code );
	}

	/**
	 * Enforce preview-mode permissions for outbound HTTP requests.
	 *
	 * @param mixed $preempt Preempt response.
	 *
	 * @return mixed
	 */
	public function maybe_block_http_request( $preempt ) {
		if ( ! $this->active ) {
			return $preempt;
		}

		if ( $this->is_permitted( 'http' ) ) {
			return $preempt;
		}

		return new \WP_Error(
			'code_snippets_preview_http_blocked',
			__( 'Outbound HTTP requests are blocked in Snippet Preview mode.', 'code-snippets' )
		);
	}

	/**
	 * Enforce preview-mode permissions for sending emails.
	 *
	 * @param mixed $preempt Preempt response.
	 *
	 * @return mixed
	 */
	public function maybe_block_wp_mail( $preempt ) {
		if ( ! $this->active ) {
			return $preempt;
		}

		if ( $this->is_permitted( 'mail' ) ) {
			return $preempt;
		}

		return new \WP_Error(
			'code_snippets_preview_mail_blocked',
			__( 'Emails are blocked in Snippet Preview mode.', 'code-snippets' )
		);
	}

	/**
	 * Sort active snippet arrays by priority, table, and ID.
	 *
	 * @param array<int, array<string, mixed>> $active_snippets Snippet arrays.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function sort_active_snippets( array $active_snippets ): array {
		$ms_table = code_snippets()->db->ms_table;

		usort(
			$active_snippets,
			static function ( array $a, array $b ) use ( $ms_table ) {
				$priority = (int) ( $a['priority'] ?? 0 ) <=> (int) ( $b['priority'] ?? 0 );
				if ( 0 !== $priority ) {
					return $priority;
				}

				$a_table = ( $a['table'] ?? '' ) === $ms_table ? 0 : 1;
				$b_table = ( $b['table'] ?? '' ) === $ms_table ? 0 : 1;
				$table_cmp = $a_table <=> $b_table;
				if ( 0 !== $table_cmp ) {
					return $table_cmp;
				}

				return (int) ( $a['id'] ?? 0 ) <=> (int) ( $b['id'] ?? 0 );
			}
		);

		return $active_snippets;
	}
}
