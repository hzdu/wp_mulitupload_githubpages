<?php

namespace Code_Snippets\Settings;

use WP_REST_Request;
use WP_User;
use function add_filter;
use function get_current_user_id;
use function get_userdata;
use function wp_get_current_user;

/**
 * Role-based access control for snippet operations.
 *
 * Access is granted through a dedicated `manage_snippets` capability rather
 * than the core `manage_options` capability, so administrators can grant
 * scoped snippet access to other roles without handing them full site admin
 * rights. The capability is granted dynamically via a `user_has_cap` filter
 * based on the per-role settings — roles are never permanently mutated, so the
 * settings remain the single source of truth and changes are fully reversible.
 *
 * @package Code_Snippets\Settings
 */
class Permissions {

	/**
	 * Capability that grants access to the snippet management screens.
	 */
	public const ACCESS_CAP = 'manage_snippets';

	/**
	 * Register the dynamic capability filter.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'user_has_cap', [ self::class, 'filter_user_has_cap' ], 10, 4 );
	}

	/**
	 * Dynamically grant the snippet access capability based on role settings.
	 *
	 * Never grants `manage_options` (that would be full site admin) — only the
	 * snippet-specific `manage_snippets` capability. Administrators always
	 * retain access as a safety net so a misconfiguration can never lock them
	 * out of the settings needed to fix it.
	 *
	 * @param array<string, bool> $allcaps All capabilities for the user.
	 * @param string[]            $caps    Required primitive capabilities (unused).
	 * @param array<int, mixed>   $args    Context arguments (unused).
	 * @param WP_User             $user    The user being checked.
	 *
	 * @return array<string, bool>
	 */
	public static function filter_user_has_cap( $allcaps, $caps, $args, $user ): array {
		if ( ! $user instanceof WP_User || ! $user->exists() ) {
			return $allcaps;
		}

		// Administrators always retain snippet access.
		if ( ! empty( $allcaps['manage_options'] ) ) {
			$allcaps[ self::ACCESS_CAP ] = true;
			return $allcaps;
		}

		// Grant access to roles explicitly given at least 'view'.
		if ( 'none' !== self::user_level( $user ) ) {
			$allcaps[ self::ACCESS_CAP ] = true;
		}

		return $allcaps;
	}

	/**
	 * Check if the current user can view snippets.
	 *
	 * @return bool
	 */
	public static function current_user_can_view_snippets(): bool {
		return self::user_can_action( get_current_user_id(), 'view' );
	}

	/**
	 * Check if the current user can create snippets.
	 *
	 * @return bool
	 */
	public static function current_user_can_create_snippets(): bool {
		return self::user_can_action( get_current_user_id(), 'create' );
	}

	/**
	 * Check if the current user can edit snippets.
	 *
	 * @return bool
	 */
	public static function current_user_can_edit_snippets(): bool {
		return self::user_can_action( get_current_user_id(), 'edit' );
	}

	/**
	 * Check if the current user can delete snippets.
	 *
	 * @return bool
	 */
	public static function current_user_can_delete_snippets(): bool {
		return self::user_can_action( get_current_user_id(), 'delete' );
	}

	/**
	 * Check if the current user holds the level a REST request needs.
	 *
	 * Reading needs the view level and deleting needs the delete level. Any other
	 * method changes something, and needs the level named by the route.
	 *
	 * @param WP_REST_Request $request      Incoming REST request.
	 * @param string          $write_action Action a non-read, non-delete request performs: 'create' or 'edit'.
	 *
	 * @return bool
	 */
	public static function current_user_can_for_request( WP_REST_Request $request, string $write_action ): bool {
		switch ( $request->get_method() ) {
			case 'GET':
			case 'HEAD':
				$action = 'view';
				break;

			case 'DELETE':
				$action = 'delete';
				break;

			default:
				$action = $write_action;
		}

		return self::user_can_action( get_current_user_id(), $action );
	}

	/**
	 * Check if a user can perform a specific action on snippets.
	 *
	 * Administrators (manage_options) always pass — they have full access and
	 * must never be locked out.
	 *
	 * @param int    $user_id User ID to check.
	 * @param string $action  Action to check: 'view', 'create', 'edit', or 'delete'.
	 *
	 * @return bool
	 */
	public static function user_can_action( int $user_id, string $action ): bool {
		if ( ! $user_id ) {
			return false;
		}

		$user = get_current_user_id() === $user_id ? wp_get_current_user() : get_userdata( $user_id );
		if ( ! $user || ! $user->exists() ) {
			return false;
		}

		if ( $user->has_cap( 'manage_options' ) ) {
			return true;
		}

		return self::level_allows_action( self::user_level( $user ), $action );
	}

	/**
	 * Determine the highest capability level granted to a user across its roles.
	 *
	 * @param WP_User $user The user to inspect.
	 *
	 * @return string One of 'none', 'view', 'edit', 'full'.
	 */
	private static function user_level( WP_User $user ): string {
		$settings = get_settings_values();
		$role_perms = $settings['permissions']['role_capabilities'] ?? [];
		$rank = [
			'none' => 0,
			'view' => 1,
			'edit' => 2,
			'full' => 3,
		];

		$best = 'none';

		foreach ( $user->roles as $role ) {
			$level = $role_perms[ $role ]['level'] ?? 'none';

			if ( isset( $rank[ $level ] ) && $rank[ $level ] > $rank[ $best ] ) {
				$best = $level;
			}
		}

		return $best;
	}

	/**
	 * Check if a capability level allows a specific action.
	 *
	 * @param string $level  Capability level: 'none', 'view', 'edit', or 'full'.
	 * @param string $action Action to check: 'view', 'create', 'edit', or 'delete'.
	 *
	 * @return bool
	 */
	private static function level_allows_action( string $level, string $action ): bool {
		$allowed = [
			'none' => [],
			'view' => [ 'view' ],
			'edit' => [ 'view', 'create', 'edit' ],
			'full' => [ 'view', 'create', 'edit', 'delete' ],
		];

		return in_array( $action, $allowed[ $level ] ?? [], true );
	}
}
