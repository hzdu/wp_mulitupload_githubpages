<?php

namespace Code_Snippets\Settings;

use Code_Snippets\Client\Cloud_Plugin_Versions_Client;
use WP_Error;
use function Code_Snippets\code_snippets;

/**
 * Lists the Pro builds this site's cloud account is licensed to install.
 *
 * Replaces the WordPress.org source on the `code_snippets_version_source`
 * filter, so that the switcher never offers a free build to a Pro site.
 *
 * @package    Code_Snippets
 * @subpackage Settings
 */
class Cloud_Version_Source implements Version_Source {

	/**
	 * Error codes that mean the cloud refused this site outright, rather than
	 * failing for a reason a retry might resolve.
	 */
	private const AUTH_ERROR_CODES = [
		'cloud_plugin_versions_unauthorized',
		'cloud_plugin_versions_token_rejected',
		'cloud_plugin_versions_site_not_authorized',
	];

	/**
	 * Oldest Pro version whose settings screen switches versions through the cloud.
	 */
	private const CLOUD_SWITCHER_SINCE = '4.0.0';

	/**
	 * Build a client for the cloud version catalogue.
	 *
	 * @return Cloud_Plugin_Versions_Client
	 */
	private function get_client(): Cloud_Plugin_Versions_Client {
		return new Cloud_Plugin_Versions_Client( code_snippets()->cloud_connection );
	}

	/**
	 * Transient key under which this source's catalogue is cached.
	 *
	 * Deliberately unlike the WordPress.org key: a site upgrading into Pro
	 * mid-transient must not go on serving the free build list it cached.
	 *
	 * @return string
	 */
	public function get_cache_key(): string {
		return 'code_snippets_available_pro_versions';
	}

	/**
	 * Determine whether the cloud can currently list versions for this site.
	 *
	 * A cloud rejection counts as unavailable until the error transient expires,
	 * so the switcher explains itself instead of silently listing nothing.
	 *
	 * @return bool
	 */
	public function is_available(): bool {
		$plugin = code_snippets();

		if ( ! $plugin->cloud_connection->is_authenticated() || ! $plugin->licensing->get_license_key() ) {
			return false;
		}

		return ! in_array( Version_Switch::get_last_error_code(), self::AUTH_ERROR_CODES, true );
	}

	/**
	 * Explain an unavailable cloud, and offer the action that resolves it.
	 *
	 * @return array{message: string, action_url: string, action_label: string}
	 */
	public function get_unavailable_notice(): array {
		$plugin = code_snippets();

		if ( ! $plugin->cloud_connection->is_authenticated() ) {
			return [
				'message'      => __( 'Switching versions requires a connection to Code Snippets Cloud.', 'code-snippets' ),
				'action_url'   => $plugin->licensing->get_account_url(),
				'action_label' => __( 'Go to your account', 'code-snippets' ),
			];
		}

		$last_error = Version_Switch::get_last_error_code();

		if ( $plugin->licensing->get_license_key() && 'cloud_plugin_versions_unauthorized' !== $last_error ) {
			return [
				'message'      => __( 'This site needs to reconnect to Code Snippets Cloud before versions can be listed.', 'code-snippets' ),
				// Starts the OAuth handshake directly rather than sending the user off
				// to hunt for the connect button on another screen.
				'action_url'   => $plugin->cloud_auth->get_connect_cloud_url(),
				'action_label' => __( 'Reconnect to Code Snippets Cloud', 'code-snippets' ),
			];
		}

		return [
			'message'      => __( 'Your Pro license could not be verified.', 'code-snippets' ),
			'action_url'   => $plugin->licensing->get_account_url(),
			'action_label' => __( 'Manage your Code Snippets Pro license', 'code-snippets' ),
		];
	}

	/**
	 * Describe where versions are fetched from.
	 *
	 * @return string
	 */
	public function get_refresh_description(): string {
		return __( 'Check Code Snippets Cloud for the latest plugin versions available to this site.', 'code-snippets' );
	}

	/**
	 * Retrieve the Pro versions available to install, newest first.
	 *
	 * @return array{versions: array<int, array<string, mixed>>, floor: string}|WP_Error
	 */
	public function fetch_catalogue() {
		$result = $this->get_client()->list_versions();

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return [
			'versions' => $result['versions'],
			'floor'    => $result['floor'],
		];
	}

	/**
	 * Explain why the catalogue stops where it does.
	 *
	 * @param string $floor Oldest installable version.
	 *
	 * @return string
	 */
	public function get_floor_notice( string $floor ): string {
		return sprintf(
			// translators: %s: oldest available version number.
			__( 'Versions earlier than %s cannot be installed from here, as they predate cloud connectivity.', 'code-snippets' ),
			$floor
		);
	}

	/**
	 * Warn that a build older than the cloud switcher cannot switch back from
	 * this screen, so later changes have to be made from the account page.
	 *
	 * @param array<string, mixed> $version_info Catalogue entry for the version.
	 *
	 * @return string
	 */
	public function get_switch_warning( array $version_info ): string {
		$version = (string) $version_info['version'];

		if ( version_compare( $version, self::CLOUD_SWITCHER_SINCE, '>=' ) ) {
			return '';
		}

		return sprintf(
			// translators: 1: selected plugin version number, 2: version number the switcher was introduced in.
			__( 'Version %1$s does not include this version switcher, which was introduced in version %2$s. After switching, you will need to upgrade or downgrade from the Account page instead.', 'code-snippets' ),
			$version,
			self::CLOUD_SWITCHER_SINCE
		);
	}

	/**
	 * Download the package for a version to a temporary file.
	 *
	 * @param array<string, mixed> $version_info Catalogue entry for the version.
	 *
	 * @return array{package: string, cleanup: bool}|WP_Error
	 */
	public function fetch_package( array $version_info ) {
		$download = $this->get_client()->download_version( (string) $version_info['version'] );

		if ( is_wp_error( $download ) ) {
			return $download;
		}

		return [
			'package' => $download['path'],
			'cleanup' => true,
		];
	}

	/**
	 * Record the switch with the cloud, so the customer's dashboard reflects it.
	 *
	 * @param string $version Version now installed.
	 *
	 * @return void
	 */
	public function report_installed_version( string $version ): void {
		$this->get_client()->report_installed_version( $version );
	}
}
