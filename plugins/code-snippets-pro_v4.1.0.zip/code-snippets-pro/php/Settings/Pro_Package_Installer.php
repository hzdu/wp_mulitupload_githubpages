<?php

namespace Code_Snippets\Settings;

use Code_Snippets\Core\Plugin_Package_Installer;
use WP_Error;

/**
 * Installs a Pro package with the same installer the cloud push endpoint uses.
 *
 * Replaces the WordPress upgrader on the `code_snippets_package_installer`
 * filter. The upgrader deletes the destination folder before writing the new
 * one, which for a self-update means deleting the plugin serving the request,
 * and it leaves a stale `active_plugins` entry when a build renames its main
 * file. Plugin_Package_Installer stages the extraction, rolls a failed swap
 * back, and reactivates the plugin under its new main file.
 *
 * @package    Code_Snippets
 * @subpackage Settings
 */
class Pro_Package_Installer implements Package_Installer {

	/**
	 * Install a Pro package over the running plugin.
	 *
	 * @param string $package Local path to a package.
	 *
	 * @return array{version: string}|WP_Error
	 */
	public function install( string $package ) {
		$result = ( new Plugin_Package_Installer() )->install( $package, Plugin_Package_Installer::PRO_SLUG );

		return is_wp_error( $result ) ? $result : [ 'version' => $result['version'] ];
	}
}
