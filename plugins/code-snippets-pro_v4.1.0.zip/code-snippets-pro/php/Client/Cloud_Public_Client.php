<?php

namespace Code_Snippets\Client;

use Code_Snippets\Model\Basic_Cloud_Connection;
use Code_Snippets\Model\Cloud_Snippet;
use Code_Snippets\Model\Cloud_Snippets;
use WP_Error;
use WP_REST_Request;
use function Code_Snippets\Utils\unpack_response_body;

/**
 * Client for fetching public data from Code Snippets Cloud.
 *
 * @package Code_Snippets
 */
class Cloud_Public_Client {

	/**
	 * Request timeout, in seconds, for the cloud search endpoint. Higher than WordPress's 5s
	 * default because search can be slow on a cold cache and would otherwise time out.
	 */
	private const SEARCH_REQUEST_TIMEOUT = 15;

	/**
	 * Seconds to wait for the remaining public API requests.
	 *
	 * Each is made while an admin screen is waiting on it, so it gives up
	 * before the screen stalls, whatever the site's default timeout.
	 *
	 * @var int
	 */
	private const REQUEST_TIMEOUT = 5;

	/**
	 * Maximum number of cloud search results allowed per page.
	 */
	public const MAX_RESULTS_PER_PAGE = 100;

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Basic_Cloud_Connection
	 */
	private Basic_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Basic_Cloud_Connection $connection Connection to Code Snippets Cloud.
	 */
	public function __construct( Basic_Cloud_Connection $connection ) {
		$this->connection = $connection;
	}

	/**
	 * Verify a REST API request is authorised to access controller functions.
	 *
	 * @param WP_REST_Request $request The REST API request.
	 *
	 * @return bool
	 */
	public function verify_rest_request( WP_REST_Request $request ): bool {
		return $this->connection->verify_rest_request( $request );
	}

	/**
	 * Search Code Snippets Cloud.
	 *
	 * @param string               $search_method Search by name of codevault or keyword(s).
	 * @param string               $search        Search query.
	 * @param int                  $page          Search result page to retrieve. Defaults to '1'.
	 * @param int                  $per_page      Number of search results to retrieve per page.
	 * @param array<string,string> $filters       Optional filters: category, type, status.
	 *
	 * @return Cloud_Snippets Result of search query.
	 */
	public function fetch_search_results( string $search_method, string $search, int $page, int $per_page, array $filters ): ?Cloud_Snippets {
		$params = [
			's_method'   => $search_method,
			's'          => $search,
			'page'       => max( 0, $page - 1 ),
			'per_page'   => max( 1, $per_page ),
			'site_token' => $this->connection->get_local_token(),
			'site_host'  => wp_parse_url( get_site_url(), PHP_URL_HOST ),
		];

		foreach ( [ 'category', 'type', 'status' ] as $key ) {
			if ( ! empty( $filters[ $key ] ) ) {
				$params[ $key ] = $filters[ $key ];
			}
		}

		$response = wp_remote_get(
			add_query_arg( $params, sprintf( '%s/public/search', $this->connection->get_api_url() ) ),
			// The search endpoint can be slow on a cold cache; allow more time than WordPress's
			// default 5s request timeout so the request is not cut short and returned as empty.
			[ 'timeout' => self::SEARCH_REQUEST_TIMEOUT ]
		);

		return Cloud_Snippets::unpack_api_response( unpack_response_body( $response ), $page );
	}

	/**
	 * Retrieve a single cloud snippet from the API.
	 *
	 * @param int $cloud_id Remote cloud snippet ID.
	 *
	 * @return Cloud_Snippet Retrieved snippet.
	 */
	public function get_cloud_snippet( int $cloud_id ): ?Cloud_Snippet {
		$response = wp_remote_get(
			sprintf( '%s/public/getsnippet/%s', $this->connection->get_api_url(), $cloud_id ),
			[ 'timeout' => self::REQUEST_TIMEOUT ]
		);

		$data = unpack_response_body( $response );

		if ( ! is_array( $data ) || empty( $data['success'] ) || ! is_array( $data['snippet'] ?? null ) ) {
			return null;
		}

		return new Cloud_Snippet( $data['snippet'] );
	}

	/**
	 * Get the current revision of a single cloud snippet.
	 *
	 * @param string $cloud_id Cloud snippet ID.
	 *
	 * @return string|null Revision number on success, null otherwise.
	 */
	public function get_cloud_snippet_revision( string $cloud_id ): ?string {
		$response = wp_remote_get(
			sprintf( '%s/public/getsnippetrevision/%s', $this->connection->get_api_url(), $cloud_id ),
			[ 'timeout' => self::REQUEST_TIMEOUT ]
		);

		$body = unpack_response_body( $response );
		return $body['snippet_revision'] ?? null;
	}

	/**
	 * Retrieve featured snippets from the cloud API, with transient caching.
	 *
	 * @param int                  $page     Page number (1-indexed).
	 * @param int                  $per_page Results per page.
	 * @param array<string,string> $filters  Optional filters: category, type, status.
	 *
	 * @return Cloud_Snippets|null Featured snippets, or an null on failure.
	 */
	public function get_featured_snippets( int $page, int $per_page, array $filters ): ?Cloud_Snippets {
		$params = [
			'page'     => max( 0, $page - 1 ),
			'per_page' => min( self::MAX_RESULTS_PER_PAGE, max( 1, $per_page ) ),
		];

		foreach ( [ 'category', 'type', 'status' ] as $key ) {
			if ( ! empty( $filters[ $key ] ) ) {
				$params[ $key ] = $filters[ $key ];
			}
		}

		$response = wp_remote_get(
			add_query_arg( $params, sprintf( '%s/public/featured', $this->connection->get_api_url() ) ),
			[
				'headers' => $this->connection->get_request_headers(),
				'timeout' => self::REQUEST_TIMEOUT,
			]
		);

		return Cloud_Snippets::unpack_api_response( unpack_response_body( $response ), $page );
	}

	/**
	 * Retrieve snippets from a publicly shared bundle without authentication.
	 *
	 * @param string $share_code Bundle share code.
	 * @param int    $page       Page number (1-indexed).
	 * @param int    $per_page   Results per page.
	 *
	 * @return Cloud_Snippets|WP_Error|null Retrieved snippets, an error for a malformed upstream
	 *                                      response, or null when the bundle is unavailable.
	 */
	public function get_snippets_from_shared_bundle( string $share_code, int $page, int $per_page ) {
		$params = [
			'share_code' => $share_code,
			'page'       => max( 0, $page - 1 ),
			'per_page'   => min( self::MAX_RESULTS_PER_PAGE, max( 1, $per_page ) ),
		];

		$response = \wp_remote_get(
			\add_query_arg( $params, sprintf( '%s/public/getsharedbundle', $this->connection->get_api_url() ) )
		);

		if ( \is_wp_error( $response ) || 200 !== (int) \wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}

		$data = unpack_response_body( $response );
		$items = is_array( $data ) ? ( $data['snippets'] ?? $data['data'] ?? null ) : null;

		if ( ! is_array( $items ) ) {
			return $this->invalid_bundle_snippets_response();
		}

		// Remote bundle data is untrusted: reject items whose frontend-consumed fields are malformed.
		foreach ( $items as $item ) {
			if (
				! is_array( $item ) ||
				! is_numeric( $item['id'] ?? 0 ) ||
				! is_string( $item['name'] ?? '' ) ||
				! is_string( $item['scope'] ?? '' ) ||
				! is_string( $item['code'] ?? '' )
			) {
				return $this->invalid_bundle_snippets_response();
			}
		}

		return Cloud_Snippets::unpack_api_response( $data, $page );
	}

	/**
	 * Build an error for an invalid shared-bundle snippets response.
	 *
	 * @return WP_Error
	 */
	private function invalid_bundle_snippets_response(): WP_Error {
		return new WP_Error(
			'code_snippets_cloud_bundle_snippets_invalid_response',
			\esc_html__( 'The bundle snippets response was invalid.', 'code-snippets' ),
			[ 'status' => 502 ]
		);
	}

	/**
	 * Retrieve featured community bundles from the cloud API.
	 *
	 * Remote bundle data is untrusted: every frontend-consumed field is validated before the bundle is exposed locally.
	 *
	 * @param int $page     Page number (1-indexed).
	 * @param int $per_page Results per page.
	 *
	 * @return array{bundles:array<int,array<string,mixed>>,meta:array<string,int>}|WP_Error Featured bundles with pagination meta, or an error on failure.
	 */
	public function get_featured_bundles( int $page, int $per_page ) {
		$page = max( 1, $page );
		$per_page = min( self::MAX_RESULTS_PER_PAGE, max( 1, $per_page ) );

		$params = [
			'page'     => $page - 1,
			'per_page' => $per_page,
		];

		$response = \wp_remote_get(
			\add_query_arg( $params, sprintf( '%s/public/featured-bundles', $this->connection->get_api_url() ) ),
			[ 'headers' => $this->connection->get_request_headers() ]
		);

		if ( \is_wp_error( $response ) ) {
			return $this->bundles_request_failed_response();
		}

		$status = \wp_remote_retrieve_response_code( $response );

		if ( $status < 200 || $status >= 300 ) {
			return $this->bundles_request_failed_response();
		}

		$body = unpack_response_body( $response );
		$bundles = is_array( $body ) ? ( $body['bundles'] ?? null ) : null;

		if ( ! is_array( $bundles ) ) {
			return $this->invalid_bundles_response();
		}

		foreach ( $bundles as $index => $bundle ) {
			if (
				! is_array( $bundle ) ||
				! is_int( $bundle['id'] ?? null ) ||
				! is_int( $bundle['snippets_count'] ?? null ) ||
				! is_string( $bundle['share_code'] ?? null ) ||
				'' === trim( $bundle['share_code'] ) ||
				( isset( $bundle['name'] ) && ! is_string( $bundle['name'] ) ) ||
				( isset( $bundle['description'] ) && ! is_string( $bundle['description'] ) ) ||
				( isset( $bundle['is_public'] ) && ! is_bool( $bundle['is_public'] ) )
			) {
				return $this->invalid_bundles_response();
			}

			$bundles[ $index ]['share_code'] = trim( $bundle['share_code'] );

			// The featured endpoint only ever serves public bundles but omits the flag.
			$bundles[ $index ]['is_public'] = $bundle['is_public'] ?? true;
		}

		$meta = is_array( $body['meta'] ?? null ) ? $body['meta'] : [];

		return [
			'bundles' => array_values( $bundles ),
			'meta'    => [
				'total'       => is_numeric( $meta['total'] ?? null ) ? (int) $meta['total'] : count( $bundles ),
				'total_pages' => is_numeric( $meta['total_pages'] ?? null ) ? (int) $meta['total_pages'] : 1,
				// Local pagination meta is 1-indexed, unlike the 0-indexed cloud API.
				'page'        => is_numeric( $meta['page'] ?? null ) ? (int) $meta['page'] + 1 : $page,
				'per_page'    => is_numeric( $meta['per_page'] ?? null ) ? (int) $meta['per_page'] : $per_page,
			],
		];
	}

	/**
	 * Build an error for a failed community bundles request.
	 *
	 * @return WP_Error
	 */
	private function bundles_request_failed_response(): WP_Error {
		return new WP_Error(
			'code_snippets_cloud_bundles_request_failed',
			\esc_html__( 'Could not fetch community bundles.', 'code-snippets' ),
			[ 'status' => 502 ]
		);
	}

	/**
	 * Build an error for an invalid community bundles response.
	 *
	 * @return WP_Error
	 */
	private function invalid_bundles_response(): WP_Error {
		return new WP_Error(
			'code_snippets_cloud_bundles_invalid_response',
			\esc_html__( 'The community bundles response was invalid.', 'code-snippets' ),
			[ 'status' => 502 ]
		);
	}
}
