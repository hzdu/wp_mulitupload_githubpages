<?php

namespace Code_Snippets\Client;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use WP_Error;
use function Code_Snippets\code_snippets;
use function Code_Snippets\Utils\unpack_response_body;

/**
 * Client for the Cloud plugin version catalogue (`/api/v1/plugin-versions`).
 *
 * The cloud serves the Pro builds this site is licensed to install, and streams
 * the packages themselves. Freemius is never contacted by the site.
 *
 * @package Code_Snippets
 */
class Cloud_Plugin_Versions_Client {

	/**
	 * Base path for the version endpoints, relative to the cloud API URL.
	 */
	public const API_PATH = 'plugin-versions';

	/**
	 * Path of the endpoint that records the version installed on a site.
	 */
	public const INSTALLATION_STATUS_PATH = 'freemius/update-installation-status';

	/**
	 * Request timeout for the catalogue and reporting calls, in seconds.
	 */
	private const REQUEST_TIMEOUT = 15;

	/**
	 * Request timeout for a package download, in seconds.
	 */
	private const DOWNLOAD_TIMEOUT = 300;

	/**
	 * Version numbers the download endpoint will accept.
	 */
	private const VERSION_PATTERN = '/^[0-9]+(\.[0-9]+){1,3}$/';

	/**
	 * Release modes the catalogue is allowed to report.
	 */
	private const RELEASE_MODES = [ 'latest', 'released', 'beta', 'rc' ];

	/**
	 * Cloud connection instance.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		$this->connection = $connection;
	}

	/**
	 * Retrieve the Pro versions this site is permitted to install.
	 *
	 * An empty version list is a valid catalogue state, not an error.
	 *
	 * @return array{versions: array<int, array<string, mixed>>, latest: string, floor: string}|WP_Error
	 */
	public function list_versions() {
		$headers = $this->build_request_headers();

		if ( is_wp_error( $headers ) ) {
			return $headers;
		}

		$response = wp_remote_get(
			sprintf( '%s/%s', $this->connection->get_api_url(), self::API_PATH ),
			[
				'headers' => $headers,
				'timeout' => self::REQUEST_TIMEOUT,
			]
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'cloud_plugin_versions_request_error',
				__( 'Failed to retrieve the list of available versions from Code Snippets Cloud.', 'code-snippets' ),
				$response->get_error_message()
			);
		}

		$status = wp_remote_retrieve_response_code( $response );

		if ( $status >= 400 ) {
			return $this->error_from_response( $response, $status );
		}

		$body = unpack_response_body( $response );

		if ( ! is_array( $body ) || ! isset( $body['versions'] ) || ! is_array( $body['versions'] ) ) {
			return new WP_Error(
				'cloud_plugin_versions_response_error',
				__( 'Did not receive a valid version list from Code Snippets Cloud.', 'code-snippets' )
			);
		}

		return [
			'versions' => $this->normalise_versions( $body['versions'] ),
			'latest'   => isset( $body['latest'] ) ? (string) $body['latest'] : '',
			'floor'    => isset( $body['floor'] ) ? (string) $body['floor'] : '',
		];
	}

	/**
	 * Download a version to a temporary file.
	 *
	 * Ownership of the file at the returned path passes to the caller, which must
	 * delete it once the installer is finished with it. Every failure path deletes
	 * the file before returning.
	 *
	 * @param string $version Version number to download.
	 *
	 * @return array{path: string, version: string, sha256: string}|WP_Error
	 */
	public function download_version( string $version ) {
		if ( ! preg_match( self::VERSION_PATTERN, $version ) ) {
			return new WP_Error(
				'cloud_plugin_versions_invalid_version',
				__( 'That is not a valid version number.', 'code-snippets' ),
				[ 'status' => 400 ]
			);
		}

		$headers = $this->build_request_headers();

		if ( is_wp_error( $headers ) ) {
			return $headers;
		}

		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$temp_file = wp_tempnam( sprintf( 'code-snippets-pro-%s.zip', $version ) );

		if ( ! $temp_file ) {
			return new WP_Error(
				'cloud_plugin_versions_temp_file_error',
				__( 'Could not create a temporary file to download the plugin package into.', 'code-snippets' )
			);
		}

		$downloaded = false;

		try {
			$response = wp_remote_get(
				sprintf( '%s/%s/%s/download', $this->connection->get_api_url(), self::API_PATH, $version ),
				[
					'headers'  => $headers,
					'timeout'  => self::DOWNLOAD_TIMEOUT,
					'stream'   => true,
					'filename' => $temp_file,
				]
			);

			if ( is_wp_error( $response ) ) {
				return new WP_Error(
					'cloud_plugin_versions_request_error',
					__( 'Failed to download the plugin package from Code Snippets Cloud.', 'code-snippets' ),
					$response->get_error_message()
				);
			}

			$status = wp_remote_retrieve_response_code( $response );

			if ( $status >= 400 ) {
				// A failed download answers with JSON even though a successful one
				// is binary, and the streamed body is on disk rather than in the
				// response, so it has to be read back from there.
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- reading the streamed body back from a local file.
				return $this->error_from_response( $response, $status, (string) file_get_contents( $temp_file ) );
			}

			// Builds mirrored before the cloud started hashing packages carry no
			// digest. An absent header means verification is unavailable, not that
			// the package failed it.
			$expected = strtolower( trim( wp_remote_retrieve_header( $response, 'x-cs-artifact-sha256' ) ) );

			if ( $expected && ! hash_equals( $expected, (string) hash_file( 'sha256', $temp_file ) ) ) {
				return new WP_Error(
					'cloud_plugin_versions_integrity_error',
					__( 'The downloaded plugin package did not match the checksum provided by Code Snippets Cloud.', 'code-snippets' )
				);
			}

			$downloaded = true;

			return [
				'path'    => $temp_file,
				'version' => $version,
				'sha256'  => $expected,
			];
		} finally {
			if ( ! $downloaded ) {
				wp_delete_file( $temp_file );
			}
		}
	}

	/**
	 * Record the version now installed on this site with the cloud.
	 *
	 * Best-effort: a failure here must never turn a successful switch into a
	 * reported failure.
	 *
	 * @param string $version Version now installed.
	 *
	 * @return bool Whether the cloud accepted the report.
	 */
	public function report_installed_version( string $version ): bool {
		$headers = $this->build_request_headers();

		if ( is_wp_error( $headers ) ) {
			return false;
		}

		$response = wp_remote_post(
			sprintf( '%s/%s', $this->connection->get_api_url(), self::INSTALLATION_STATUS_PATH ),
			[
				'headers' => $headers,
				'timeout' => self::REQUEST_TIMEOUT,
				'body'    => [
					'site_url'   => get_site_url(),
					'site_token' => $this->connection->get_local_token(),
					'status'     => 'completed',
					'version'    => $version,
				],
			]
		);

		return ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) < 400;
	}

	/**
	 * Build the headers every request carries, refusing to send a request that
	 * cannot be scoped to this site and license.
	 *
	 * @return array<string, string>|WP_Error
	 */
	private function build_request_headers() {
		if ( ! $this->connection->is_cloud_key_verified() ) {
			return new WP_Error(
				'cloud_plugin_versions_key_error',
				__( 'Cannot access the Cloud version list without a verified cloud key.', 'code-snippets' ),
				[ 'status' => 403 ]
			);
		}

		// The cloud confines a request to one site by its `Local-Token` header and
		// treats an empty value as absent — which widens the scope to every site
		// the account owns. Verification only covers the cloud key, so refuse
		// rather than send a blank token.
		if ( '' === $this->connection->get_local_token() ) {
			return new WP_Error(
				'cloud_plugin_versions_site_token_error',
				__( 'Cannot access the Cloud version list without a site token.', 'code-snippets' ),
				[ 'status' => 403 ]
			);
		}

		$license_key = code_snippets()->licensing->get_license_key();

		if ( ! $license_key ) {
			return new WP_Error(
				'cloud_plugin_versions_license_error',
				__( 'Could not retrieve license details for the API request.', 'code-snippets' ),
				[ 'status' => 403 ]
			);
		}

		// The license key travels as a header rather than a query argument:
		// `add_query_arg()` does not encode its values, so a key containing an `&`
		// is truncated at the server and reads as invalid, and a header also keeps
		// the secret out of the cloud's access logs. The dash spelling matters —
		// the cloud reads it through Symfony's HeaderBag, which normalises `_` to
		// `-`, and web servers routinely drop headers containing underscores.
		$headers = $this->connection->get_request_headers();
		$headers['fs-key'] = $license_key;

		return $headers;
	}

	/**
	 * Normalise the version entries returned by the cloud, newest first.
	 *
	 * @param array<int, mixed> $versions Raw version entries.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function normalise_versions( array $versions ): array {
		$normalised = [];

		foreach ( $versions as $version ) {
			if ( ! is_array( $version ) || empty( $version['version'] ) ) {
				continue;
			}

			$release_mode = isset( $version['release_mode'] ) ? (string) $version['release_mode'] : '';

			$normalised[] = [
				'version'      => (string) $version['version'],
				'release_mode' => in_array( $release_mode, self::RELEASE_MODES, true ) ? $release_mode : 'released',
				'tested_up_to' => isset( $version['tested_up_to'] ) ? (string) $version['tested_up_to'] : '',
				'is_latest'    => ! empty( $version['is_latest'] ),
			];
		}

		usort(
			$normalised,
			function ( array $a, array $b ) {
				return version_compare( $b['version'], $a['version'] );
			}
		);

		return $normalised;
	}

	/**
	 * Build a WP_Error from an unsuccessful cloud response.
	 *
	 * @param array<string, mixed> $response  Raw HTTP response.
	 * @param int                  $status    HTTP status code.
	 * @param string               $body_json Response body, when it is not carried in the response itself.
	 *
	 * @return WP_Error
	 */
	private function error_from_response( array $response, int $status, string $body_json = '' ): WP_Error {
		$body = $body_json ? json_decode( $body_json, true ) : unpack_response_body( $response );
		$error_code = is_array( $body ) && ! empty( $body['error_code'] ) ? (string) $body['error_code'] : '';

		// The cloud answers 401 both for a rejected license and for a bearer token
		// it no longer accepts. Only the latter carries the framework's stock
		// `Unauthenticated.` message, and it is fixed by reconnecting the site.
		if ( 401 === $status && is_array( $body ) && 'Unauthenticated.' === ( $body['message'] ?? '' ) ) {
			return new WP_Error(
				'cloud_plugin_versions_token_rejected',
				__( 'The connection to Code Snippets Cloud has expired.', 'code-snippets' ),
				[ 'status' => $status ]
			);
		}

		if ( 401 === $status ) {
			return new WP_Error(
				'cloud_plugin_versions_unauthorized',
				__( 'Your Pro license could not be verified.', 'code-snippets' ),
				[ 'status' => $status ]
			);
		}

		if ( 403 === $status || 'SITE_NOT_AUTHORIZED' === $error_code ) {
			return new WP_Error(
				'cloud_plugin_versions_site_not_authorized',
				__( 'This site is not connected to Code Snippets Cloud.', 'code-snippets' ),
				[ 'status' => $status ]
			);
		}

		if ( 404 === $status || 'VERSION_NOT_AVAILABLE' === $error_code ) {
			return new WP_Error(
				'cloud_plugin_versions_version_unavailable',
				__( 'That version is no longer available to install. The version list has been refreshed — please choose again.', 'code-snippets' ),
				[ 'status' => $status ]
			);
		}

		if ( 429 === $status || 'DOWNLOAD_RATE_LIMITED' === $error_code ) {
			return new WP_Error(
				'cloud_plugin_versions_rate_limited',
				__( 'Too many version switches from this site. Please wait before trying again.', 'code-snippets' ),
				[ 'status' => $status ]
			);
		}

		if ( 502 === $status || 'PACKAGE_UNREADABLE' === $error_code ) {
			return new WP_Error(
				'cloud_plugin_versions_package_unreadable',
				__( 'That build is temporarily unavailable. Please try another version or contact support.', 'code-snippets' ),
				[ 'status' => $status ]
			);
		}

		$message = is_array( $body ) && ! empty( $body['message'] )
			? (string) $body['message']
			: __( 'Code Snippets Cloud returned an error.', 'code-snippets' );

		return new WP_Error( 'cloud_plugin_versions_error', $message, [ 'status' => $status ] );
	}
}
