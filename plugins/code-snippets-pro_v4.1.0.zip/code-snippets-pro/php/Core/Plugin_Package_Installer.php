<?php

namespace Code_Snippets\Core;

use WP_Error;
use ZipArchive;

/**
 * Installs or updates a WordPress plugin from a `.zip` already on disk.
 *
 * Extraction happens in a staging directory and the existing install is moved
 * aside rather than deleted, so a failed unzip or move can be rolled back. That
 * matters most for the `code-snippets-pro` slug, where the plugin being replaced
 * is the one running the request.
 *
 * @package Code_Snippets
 */
final class Plugin_Package_Installer {

	/**
	 * Folder slug of the Code Snippets Pro plugin.
	 */
	public const PRO_SLUG = 'code-snippets-pro';

	/**
	 * Install or update a plugin from a package on disk.
	 *
	 * A plugin that was active before the install is reactivated afterwards, even
	 * if the new package renames the main file, which would otherwise leave a
	 * stale `active_plugins` entry and silently deactivate the plugin.
	 *
	 * @param string $zip_path Absolute path to the plugin package.
	 * @param string $slug     Target plugin folder slug.
	 * @param bool   $activate Activate the plugin even if it was not active before.
	 *
	 * @return array{slug: string, version: string, updated: bool, activated: bool}|WP_Error
	 */
	public function install( string $zip_path, string $slug, bool $activate = false ) {
		// Destination is ALWAYS WP_PLUGIN_DIR/<sanitised-slug> — never trust the
		// raw slug for the path. Sanitising to [a-z0-9-] also rules out traversal.
		$slug = preg_replace( '/[^a-z0-9\-]/', '', strtolower( $slug ) );

		if ( '' === $slug ) {
			return new WP_Error( 'install_failed', __( 'A valid plugin slug is required.', 'code-snippets' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		if ( ! WP_Filesystem() ) {
			return new WP_Error( 'install_failed', __( 'The site filesystem is not writable.', 'code-snippets' ) );
		}

		global $wp_filesystem;

		$plugins_dir = trailingslashit( WP_PLUGIN_DIR );
		$target = $plugins_dir . $slug;
		$updated = $wp_filesystem->is_dir( $target );

		$existing_plugin_file = $updated ? $this->find_plugin_main_file( $slug ) : null;
		$was_active = null !== $existing_plugin_file && is_plugin_active( $existing_plugin_file );

		// Extract into a staging directory first so a failed unzip never removes
		// the existing install (which may be the running Pro plugin). Only a
		// validated copy is swapped into place.
		$staging = $plugins_dir . '.cs-cloud-staging-' . $slug;
		$wp_filesystem->delete( $staging, true );

		if ( ! $wp_filesystem->mkdir( $staging ) ) {
			return new WP_Error( 'install_failed', __( 'Could not create a staging directory.', 'code-snippets' ) );
		}

		// unzip_file() guards against Zip-Slip path traversal.
		$unzipped = unzip_file( $zip_path, $staging );

		if ( is_wp_error( $unzipped ) ) {
			$wp_filesystem->delete( $staging, true );
			return new WP_Error( 'install_failed', $unzipped->get_error_message() );
		}

		// The archive's top-level folder must match the slug and hold a plugin.
		$staged_dir = trailingslashit( $staging ) . $slug;

		if ( ! $wp_filesystem->is_dir( $staged_dir ) || ! $this->staged_dir_has_plugin( $staged_dir ) ) {
			$wp_filesystem->delete( $staging, true );
			return new WP_Error( 'install_failed', __( 'Unexpected archive layout.', 'code-snippets' ) );
		}

		// Swap the validated copy in, moving any existing install aside first so
		// it can be restored if the final move fails.
		$backup = $plugins_dir . '.cs-cloud-backup-' . $slug;
		$wp_filesystem->delete( $backup, true );

		if ( $updated && ! $wp_filesystem->move( $target, $backup, true ) ) {
			$wp_filesystem->delete( $staging, true );
			return new WP_Error( 'install_failed', __( 'Could not remove the existing plugin.', 'code-snippets' ) );
		}

		if ( ! $wp_filesystem->move( $staged_dir, $target, true ) ) {
			if ( $updated ) {
				$wp_filesystem->move( $backup, $target, true );
			}

			$wp_filesystem->delete( $staging, true );
			$wp_filesystem->delete( $backup, true );

			return new WP_Error( 'install_failed', __( 'Could not install the new plugin files.', 'code-snippets' ) );
		}

		$wp_filesystem->delete( $staging, true );
		$wp_filesystem->delete( $backup, true );

		// Resolve the freshly written main plugin file for activation/version.
		wp_clean_plugins_cache( false );
		$plugin_file = $this->find_plugin_main_file( $slug );

		if ( null === $plugin_file ) {
			return new WP_Error( 'install_failed', __( 'Unexpected archive layout.', 'code-snippets' ) );
		}

		// Report the *real* activation state — the main file may have been
		// renamed, leaving the old active_plugins entry stale.
		$activated = is_plugin_active( $plugin_file );

		if ( ( $activate || $was_active ) && ! $activated ) {
			if ( $was_active && $existing_plugin_file && $existing_plugin_file !== $plugin_file ) {
				deactivate_plugins( $existing_plugin_file, true );
			}

			$activated = ! is_wp_error( activate_plugin( $plugin_file ) );
		}

		return [
			'slug'      => $slug,
			'version'   => $this->read_plugin_version( $plugins_dir . $plugin_file ),
			'updated'   => $updated,
			'activated' => $activated,
		];
	}

	/**
	 * Resolve the main plugin file (`<slug>/<file>.php`) of an installed plugin
	 * folder, without assuming the file is named after the folder.
	 *
	 * @param string $slug Plugin folder slug.
	 *
	 * @return string|null Plugin file relative to the plugins dir, or null if the
	 *                     folder holds no plugin.
	 */
	public function find_plugin_main_file( string $slug ): ?string {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins( '/' . $slug );

		if ( empty( $plugins ) ) {
			return null;
		}

		return $slug . '/' . (string) array_key_first( $plugins );
	}

	/**
	 * Read the version of the plugin currently installed under a folder slug.
	 *
	 * @param string $slug Plugin folder slug.
	 *
	 * @return string Version string, or '' if no plugin is installed there.
	 */
	public function get_installed_version( string $slug ): string {
		$plugin_file = $this->find_plugin_main_file( $slug );

		return null === $plugin_file
			? ''
			: $this->read_plugin_version( trailingslashit( WP_PLUGIN_DIR ) . $plugin_file );
	}

	/**
	 * Read the Version header of a plugin's main file inside a zip archive,
	 * without extracting it. The main file is the top-level `<slug>/*.php` entry
	 * carrying a `Plugin Name:` header, whatever its filename.
	 *
	 * @param string $zip_path Absolute path to the package.
	 * @param string $slug     Expected top-level folder slug inside the archive.
	 *
	 * @return string|null Version string, or null if it could not be read.
	 */
	public function read_package_version( string $zip_path, string $slug ): ?string {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return null;
		}

		$zip = new ZipArchive();

		if ( true !== $zip->open( $zip_path ) ) {
			return null;
		}

		$prefix = $slug . '/';
		$version = null;
		$count = $zip->count();

		for ( $index = 0; $index < $count; $index++ ) {
			$name = (string) $zip->getNameIndex( $index );

			if ( 0 !== strpos( $name, $prefix ) ) {
				continue;
			}

			// Only top-level PHP files directly inside the slug folder.
			$relative = substr( $name, strlen( $prefix ) );
			if ( '' === $relative || false !== strpos( $relative, '/' ) || '.php' !== strtolower( substr( $relative, -4 ) ) ) {
				continue;
			}

			$contents = $zip->getFromIndex( $index );
			if ( ! is_string( $contents ) || false === stripos( $contents, 'Plugin Name:' ) ) {
				continue;
			}

			if ( preg_match( '/^[ \t\/*#@]*Version:\s*(.+)$/mi', $contents, $matches ) ) {
				$version = trim( $matches[1] );
			}
			break;
		}

		$zip->close();

		return $version;
	}

	/**
	 * Read the Version header of a plugin file on disk.
	 *
	 * @param string $plugin_main_file Absolute path to the plugin's main file.
	 *
	 * @return string Version string, or '' if it could not be read.
	 */
	private function read_plugin_version( string $plugin_main_file ): string {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$data = get_plugin_data( $plugin_main_file, false, false );

		return isset( $data['Version'] ) ? (string) $data['Version'] : '';
	}

	/**
	 * Determine whether a staged directory holds a WordPress plugin — a
	 * top-level `.php` file carrying a `Plugin Name:` header — so a malformed
	 * archive is rejected before it replaces the live install.
	 *
	 * @param string $dir Absolute path to the staged plugin folder.
	 *
	 * @return bool
	 */
	private function staged_dir_has_plugin( string $dir ): bool {
		global $wp_filesystem;

		$entries = $wp_filesystem->dirlist( $dir );

		if ( ! is_array( $entries ) ) {
			return false;
		}

		foreach ( $entries as $entry ) {
			$name = (string) ( $entry['name'] ?? '' );

			if ( 'f' !== ( $entry['type'] ?? '' ) || '.php' !== strtolower( substr( $name, -4 ) ) ) {
				continue;
			}

			$contents = $wp_filesystem->get_contents( trailingslashit( $dir ) . $name );

			if ( is_string( $contents ) && false !== stripos( $contents, 'Plugin Name:' ) ) {
				return true;
			}
		}

		return false;
	}
}
