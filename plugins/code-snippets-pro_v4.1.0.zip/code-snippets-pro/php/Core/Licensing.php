<?php

namespace Code_Snippets\Core;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\Settings\Cloud_Version_Source;
use Code_Snippets\Settings\Pro_Package_Installer;
use Code_Snippets\Settings\Version_Switch;
use Freemius;
use Freemius_Exception;
use function Code_Snippets\code_snippets;
use function fs_dynamic_init;
/**
 * Handles interfacing with the Freemius SDK and API.
 *
 * @package Code_Snippets
 */
class Licensing {
    /**
     * Freemius product ID.
     */
    private const PRODUCT_ID = 10565;

    /**
     * Freemius public key.
     */
    private const PUBLIC_KEY = 'pk_107ff34fc0b2a9700c150c1acf13a';

    /**
     * Freemius SDK instance.
     *
     * @var Freemius
     */
    private Freemius $sdk;

    /**
     * Class constructor.
     *
     * @throws Freemius_Exception Freemius fails to initialise.
     */
    public function __construct() {
        $this->enable_multisite_support();
        if ( !function_exists( 'fs_dynamic_init' ) ) {
            require dirname( CODE_SNIPPETS_FILE ) . '/vendor/freemius/wordpress-sdk/start.php';
        }
        /**
         * Check for constant defined in wp-config.php.
         *
         * @noinspection PhpUndefinedConstantInspection
         */
        $secret_key = ( defined( 'CODE_SNIPPETS_SECRET_KEY' ) ? CODE_SNIPPETS_SECRET_KEY : null );
        $this->sdk = fs_dynamic_init( array(
            'id'               => self::PRODUCT_ID,
            'slug'             => 'code-snippets',
            'premium_slug'     => 'code-snippets-pro',
            'type'             => 'plugin',
            'public_key'       => self::PUBLIC_KEY,
            'is_premium'       => true,
            'is_premium_only'  => true,
            'premium_suffix'   => 'Pro',
            'has_addons'       => false,
            'has_paid_plans'   => true,
            'is_org_compliant' => true,
            'has_affiliation'  => 'selected',
            'menu'             => array(
                'slug'        => code_snippets()->get_menu_slug(),
                'contact'     => false,
                'support'     => false,
                'pricing'     => false,
                'affiliation' => false,
                'network'     => true,
            ),
            'is_live'          => true,
        ) );
        do_action( 'freemius_loaded' );
        $this->register_hooks();
        $this->register_pro_services();
        add_action( 'init', [$this, 'override_strings'] );
    }

    /**
     * Point the shared services that vary by edition at their Pro implementations.
     *
     * These registrations live here because this class is the edition seam: Core
     * ships its own Licensing and never loads the Pro classes below, so the
     * shared files that consume them stay byte-identical between the two
     * repositories. Both filters are resolved lazily by their consumers, so
     * registering them during bootstrap is early enough.
     *
     * @return void
     */
    private function register_pro_services() {
        add_filter( 'code_snippets_version_source', function () {
            return new Cloud_Version_Source();
        } );
        add_filter( 'code_snippets_package_installer', function () {
            return new Pro_Package_Installer();
        } );
        // A cloud refusal keeps the switcher unavailable until its error expires,
        // so reconnecting the site has to clear it for the switcher to recover.
        $option = Authenticated_Cloud_Connection::CLOUD_SETTINGS_OPTION;
        add_action( "add_option_{$option}", [Version_Switch::class, 'clear_version_caches'] );
        add_action( "update_option_{$option}", [Version_Switch::class, 'clear_version_caches'] );
    }

    /**
     * Create the necessary constant to enable multisite support within the Freemius SDK.
     *
     * @return void
     */
    private function enable_multisite_support() {
        $constant_name = sprintf( 'WP_FS__PRODUCT_%d_MULTISITE', self::PRODUCT_ID );
        if ( !defined( $constant_name ) ) {
            define( $constant_name, true );
        }
    }

    /**
     * Determine whether the current site has an active license.
     *
     * @return bool
     */
    public function is_licensed() : bool {
        return $this->sdk->can_use_premium_code();
    }

    /**
     * Determine whether the current site has any license, including an expired license.
     *
     * @return bool
     */
    public function was_licensed() : bool {
        return $this->sdk->has_any_license();
    }

    /**
     * Determine if Freemius has hijacked the current admin page to run the license activation process.
     *
     * @return bool
     */
    public function is_activating() : bool {
        return $this->sdk->is_activation_page() && $this->sdk->is_activation_mode();
    }

    /**
     * Retrieve the current license secret key.
     *
     * @return string|null
     */
    public function get_license_key() : ?string {
        $license = $this->sdk->_get_license();
        return ( $license ? $license->secret_key : null );
    }

    /**
     * Retrieve the URL of the account screen, where a license can be managed.
     *
     * @return string Account URL, or '' if the SDK cannot provide one.
     */
    public function get_account_url() : string {
        if ( !method_exists( $this->sdk, 'get_account_url' ) ) {
            return '';
        }
        try {
            return (string) $this->sdk->get_account_url();
        } catch ( \Throwable $exception ) {
            // Building the URL walks the SDK's menu and plan state, which is
            // incomplete on a site that has never registered. The URL only backs a
            // convenience link, so an unusable one is rendered as no link at all.
            return '';
        }
    }

    /**
     * Build an identifiers-only snapshot of the Freemius registration and license
     * for Code Snippets Cloud. Read-only — never mutates Freemius state.
     *
     * The cloud verifies the license against the Freemius API itself, so this must
     * expose only numeric identifiers and status flags — never the license key,
     * secret key, activation token, or any other secret.
     *
     * @return array<string, bool|int|null>
     */
    public function get_cloud_identifiers() : array {
        $fs = $this->sdk;
        $is_registered = method_exists( $fs, 'is_registered' ) && $fs->is_registered();
        if ( !$is_registered ) {
            return self::map_cloud_identifiers(
                false,
                false,
                false,
                null,
                null,
                null
            );
        }
        return self::map_cloud_identifiers(
            true,
            $fs->can_use_premium_code(),
            method_exists( $fs, 'is_paying' ) && $fs->is_paying(),
            $fs->_get_license(),
            ( method_exists( $fs, 'get_site' ) ? $fs->get_site() : null ),
            ( method_exists( $fs, 'get_user' ) ? $fs->get_user() : null )
        );
    }

    /**
     * Map raw Freemius entities to the identifiers-only cloud payload.
     *
     * Kept free of any secret-bearing field so the shape can never leak a key.
     *
     * @param bool        $is_registered     Whether the site is registered with Freemius.
     * @param bool        $has_valid_license Whether premium code may currently be used.
     * @param bool        $is_paying         Whether the site is on a paid (non-trial) plan.
     * @param object|null $license           Freemius license entity, or null.
     * @param object|null $site              Freemius install/site entity, or null.
     * @param object|null $user              Freemius user entity, or null.
     *
     * @return array<string, bool|int|null>
     */
    private static function map_cloud_identifiers(
        bool $is_registered,
        bool $has_valid_license,
        bool $is_paying,
        $license,
        $site,
        $user
    ) : array {
        return [
            'is_registered'     => $is_registered,
            'has_valid_license' => $has_valid_license,
            'is_paying'         => $is_paying,
            'license_id'        => ( is_object( $license ) && isset( $license->id ) ? (int) $license->id : null ),
            'install_id'        => ( is_object( $site ) && isset( $site->id ) ? (int) $site->id : null ),
            'freemius_user_id'  => ( is_object( $user ) && isset( $user->id ) ? (int) $user->id : null ),
            'plan_id'           => ( is_object( $license ) && isset( $license->plan_id ) ? (int) $license->plan_id : null ),
        ];
    }

    /**
     * Activate a license key.
     *
     * @param string $license_key The license key to activate.
     * @param array  $options     Activation options (network, marketing, etc.).
     *
     * @return array Activation result with 'success' boolean and 'message' string.
     */
    public function activate_license_key( string $license_key, array $options = [] ) : array {
        $license_key = trim( $license_key );
        if ( empty( $license_key ) ) {
            return [
                'success' => false,
                'message' => __( 'License key cannot be empty.', 'code-snippets' ),
            ];
        }
        $fs = $this->sdk;
        if ( $fs->can_use_premium_code() ) {
            return [
                'success' => false,
                'message' => __( 'Plugin is already licensed. Use this command to change the license key.', 'code-snippets' ),
                'type'    => 'warning',
            ];
        }
        $is_network = $options['network'] ?? false;
        $is_marketing_allowed = $options['marketing'] ?? false;
        $sites = $this->prepare_network_sites( $is_network );
        $result = $fs->opt_in(
            false,
            // email (will use current user).
            false,
            // first name.
            false,
            // last name.
            $license_key,
            // license key.
            false,
            // is_uninstall.
            false,
            // trial_plan_id.
            false,
            // is_disconnected.
            $is_marketing_allowed,
            // marketing allowed.
            $sites,
            // sites for network activation.
            false
        );
        if ( false === $result || is_object( $result ) && isset( $result->error ) ) {
            $error_message = ( is_object( $result->error ) ? $result->error->message ?? __( 'Unknown error occurred.', 'code-snippets' ) : __( 'Invalid response from server.', 'code-snippets' ) );
            return [
                'success' => false,
                'message' => sprintf( __( 'License activation failed: %s', 'code-snippets' ), $error_message ),
            ];
        } else {
            return [
                'success' => true,
                'message' => __( 'License activated successfully.', 'code-snippets' ),
            ];
        }
    }

    /**
     * Get detailed license status information.
     *
     * @return array License status information.
     */
    public function get_license_status() : array {
        $fs = $this->sdk;
        $license = $this->get_license_object();
        if ( is_object( $license ) ) {
            $status_info = [
                'is_licensed' => __( 'Yes', 'code-snippets' ),
                'license_key' => $this->get_masked_license_key( $license ),
                'is_expired'  => ( $license->is_expired() ? __( 'Yes', 'code-snippets' ) : __( 'No', 'code-snippets' ) ),
                'expires'     => ( $license->is_lifetime() ? __( 'Never', 'code-snippets' ) : $license->expiration ),
                'activations' => __( 'N/A', 'code-snippets' ),
            ];
            if ( isset( $license->activated ) ) {
                if ( $license->is_unlimited() ) {
                    $status_info['activations'] = $license->activated . '/∞';
                } elseif ( isset( $license->quota ) ) {
                    $status_info['activations'] = $license->activated . '/' . $license->quota;
                } else {
                    $status_info['activations'] = $license->activated;
                }
            }
        } else {
            $status_info = [
                'is_licensed' => ( $fs->can_use_premium_code() ? __( 'Yes', 'code-snippets' ) : __( 'No', 'code-snippets' ) ),
                'license_key' => __( 'Not available', 'code-snippets' ),
                'is_expired'  => __( 'N/A', 'code-snippets' ),
                'expires'     => __( 'N/A', 'code-snippets' ),
                'activations' => __( 'N/A', 'code-snippets' ),
            ];
        }
        return $status_info;
    }

    /**
     * Register hooks with Freemius.
     *
     * @return void
     */
    private function register_hooks() {
        $this->sdk->add_action( 'after_uninstall', [$this, 'uninstall_hook'] );
        $this->sdk->add_filter(
            'is_submenu_visible',
            [$this, 'is_submenu_visible'],
            10,
            2
        );
        $this->sdk->add_filter( 'plugin_icon', [$this, 'plugin_icon'] );
    }

    /**
     * Get the relative path to the plugin icon.
     *
     * @return string
     */
    public function plugin_icon() : string {
        return dirname( CODE_SNIPPETS_FILE ) . '/assets/icon.svg';
    }

    /**
     * Control whether a Freemius submenu is visible.
     *
     * @param bool   $is_visible Whether the submenu is visible.
     * @param string $submenu_id Submenu ID.
     *
     * @return bool
     */
    public function is_submenu_visible( bool $is_visible, string $submenu_id ) : bool {
        return ( 'account' === $submenu_id ? $is_visible : false );
    }

    /**
     * Clean up data when the plugin is uninstalled.
     *
     * @return void
     */
    public function uninstall_hook() {
        $uninstaller = new Uninstaller();
        $uninstaller->uninstall_plugin();
    }

    /**
     * Override default strings used by Freemius to better integrate it with the rest of the plugin.
     *
     * @return void
     */
    public function override_strings() {
        $this->sdk->override_i18n( [
            'yee-haw'  => __( 'Success', 'code-snippets' ),
            'oops'     => __( 'Notice', 'code-snippets' ),
            'woot'     => __( 'Success', 'code-snippets' ),
            'right-on' => __( 'Thanks', 'code-snippets' ),
            'ok'       => __( 'Okay', 'code-snippets' ),
        ] );
        $this->sdk->add_filter(
            'connect_message_on_update',
            [$this, 'connect_message_on_update'],
            10,
            6
        );
        $this->sdk->add_filter( 'show_affiliate_program_notice', '__return_false' );
    }

    /**
     * Create a message to display on the connect screen after an update.
     *
     * @param string $message         Current message text.
     * @param string $user_first_name First name to address user.
     * @param string $product_title   Title of the product.
     * @param string $user_login      User login credential.
     * @param string $site_link       Link to site.
     * @param string $freemius_link   Link to Freemius dashboard.
     *
     * @return string Updated message text.
     *
     * @noinspection PhpTooManyParametersInspection Parameters controlled by Freemius SDK.
     * @noinspection PhpUnusedParameterInspection
     */
    private function connect_message_on_update(
        string $message,
        string $user_first_name,
        string $product_title,
        string $user_login,
        string $site_link,
        string $freemius_link
    ) : string {
        /* translators: 1: site url, 2: Freemius link */
        $text = __( 'Please help us improve Code Snippets! If you opt-in, some data about your usage of %1$s will be sent to %2$s. If you skip this, that\'s okay, Code Snippets will still work just fine.', 'code-snippets' );
        return sprintf( $text, $site_link, $freemius_link );
    }

    /**
     * Prepare sites array for network activation.
     *
     * @param bool $is_network Whether this is a network activation.
     *
     * @return array Array of site information for network activation.
     */
    private function prepare_network_sites( bool $is_network ) : array {
        if ( !$is_network || !is_multisite() ) {
            return [];
        }
        $sites = [];
        foreach ( get_sites() as $site ) {
            $sites[] = [
                'blog_id' => $site->blog_id,
                'url'     => $site->siteurl,
                'name'    => $site->blogname,
            ];
        }
        return $sites;
    }

    /**
     * Get masked license key for CLI display.
     *
     * @param object $license Freemius license object.
     *
     * @return string Masked license key.
     */
    private function get_masked_license_key( object $license ) : string {
        if ( method_exists( $license, 'get_masked_secret_key' ) ) {
            return $license->get_masked_secret_key();
        }
        return __( 'Not available', 'code-snippets' );
    }

    /**
     * Get license object using the first available Freemius method.
     *
     * @return object|null License object or null if not available.
     */
    private function get_license_object() : ?object {
        $methods = ['_get_license', 'get_license', 'get_user_license'];
        foreach ( $methods as $method ) {
            if ( method_exists( $this->sdk, $method ) ) {
                $result = $this->sdk->{$method}();
                if ( $result ) {
                    return $result;
                }
            }
        }
        return null;
    }

}
