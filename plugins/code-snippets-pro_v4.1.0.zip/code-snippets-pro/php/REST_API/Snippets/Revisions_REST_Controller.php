<?php
/**
 * REST API controller for snippet revisions.
 *
 * @package Code_Snippets
 */

namespace Code_Snippets\REST_API\Snippets;

use Code_Snippets\REST_API\REST_Controller;
use Code_Snippets\Revisions\Revision_Manager;
use WP_Error;
use WP_Post;
use Code_Snippets\Settings\Permissions;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;
use function Code_Snippets\Settings\get_setting;
use function Code_Snippets\Settings\update_setting;

/**
 * Provides REST API endpoints for snippet revision management.
 */
final class Revisions_REST_Controller extends REST_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base of this controller's route.
	 */
	public const BASE_ROUTE = 'snippets';

	/**
	 * Revision manager instance.
	 *
	 * @var Revision_Manager
	 */
	private Revision_Manager $revision_manager;

	/**
	 * Constructor.
	 *
	 * @param Revision_Manager $revision_manager Revision manager instance.
	 */
	public function __construct( Revision_Manager $revision_manager ) {
		$this->revision_manager = $revision_manager;
		parent::__construct();
	}

	/**
	 * Permission callback for every revision route.
	 *
	 * Revisions inherit the scope of the snippet they belong to, so a request
	 * for network-scoped revisions must satisfy the network capability. Checking
	 * only the site capability would let a subsite administrator list, read,
	 * restore or delete revisions belonging to network snippets.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return $this->is_network_scoped_request( $request )
			? code_snippets()->user_can_manage_network_snippets()
			: code_snippets()->current_user_can() && Permissions::current_user_can_for_request( $request, 'edit' );
	}

	/**
	 * Determine whether a request targets network-scoped revisions.
	 *
	 * Mirrors Snippets_REST_Controller: only an explicitly truthy `network`
	 * param counts. A missing or falsey value means "site-scoped" and must not
	 * be escalated to the network capability.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return bool
	 */
	private function is_network_scoped_request( WP_REST_Request $request ): bool {
		if ( ! is_multisite() || ! $request->has_param( 'network' ) ) {
			return false;
		}

		return filter_var( $request->get_param( 'network' ), FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * Register REST routes for revisions.
	 */
	public function register_routes() {
		$id_route = '/' . self::BASE_ROUTE . '/(?P<id>[\d]+)/revisions';
		$rev_route = $id_route . '/(?P<rev_id>[\d]+)';

		$network_args = [
			'network' => [
				'description' => esc_html__( 'Whether the snippet is network-wide.', 'code-snippets' ),
				'type'        => [ 'boolean', 'null' ],
				'default'     => null,
			],
		];

		register_rest_route(
			$this->namespace,
			$id_route,
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_revisions' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => $network_args,
			]
		);

		register_rest_route(
			$this->namespace,
			$rev_route,
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_revision' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => $network_args,
			]
		);

		register_rest_route(
			$this->namespace,
			$rev_route . '/restore',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'restore_revision' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => $network_args,
			]
		);

		register_rest_route(
			$this->namespace,
			$rev_route,
			[
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'delete_revision' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => $network_args,
			]
		);

		register_rest_route(
			$this->namespace,
			$id_route . '/settings',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_versioning_settings' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => $network_args,
			]
		);

		register_rest_route(
			$this->namespace,
			$id_route . '/settings',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'update_versioning_settings' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => array_merge(
					$network_args,
					[
						'disabled' => [
							'description' => esc_html__( 'Whether versioning is disabled for this snippet.', 'code-snippets' ),
							'type'        => 'boolean',
							'required'    => true,
						],
					]
				),
			]
		);

		$preferences_route = '/' . self::BASE_ROUTE . '/revisions/preferences';

		// GET /snippets/revisions/preferences — get delete preference.
		register_rest_route(
			$this->namespace,
			$preferences_route,
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_delete_preference' ],
				'permission_callback' => [ $this, 'permission_callback' ],
			]
		);

		// POST /snippets/revisions/preferences — update delete preference.
		register_rest_route(
			$this->namespace,
			$preferences_route,
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'update_delete_preference' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => [
					'delete_revision_default' => [
						'description' => esc_html__( 'Default behavior when deleting snippets with revisions.', 'code-snippets' ),
						'type'        => 'string',
						'enum'        => [ '', 'delete', 'keep' ],
						'required'    => true,
					],
				],
			]
		);
	}

	/**
	 * Retrieve all revisions for a snippet.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_revisions( WP_REST_Request $request ): WP_REST_Response {
		$snippet_id = absint( $request->get_param( 'id' ) );
		$network = $request->get_param( 'network' );
		$revisions = $this->revision_manager->get_revisions( $snippet_id, $network );

		$data = array_map( [ self::class, 'format_revision' ], $revisions );

		return rest_ensure_response( $data );
	}

	/**
	 * Retrieve a single revision.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_revision( WP_REST_Request $request ) {
		$revision_id = absint( $request->get_param( 'rev_id' ) );
		$snippet_id = absint( $request->get_param( 'id' ) );
		$network = $request->get_param( 'network' );

		// Bound to the snippet and scope in the route, so a revision cannot be
		// read through a snippet it does not belong to.
		$revision = $this->revision_manager->get_revision( $revision_id, $snippet_id, $network );

		if ( ! $revision ) {
			return new WP_Error(
				'rest_revision_not_found',
				__( 'The revision could not be found.', 'code-snippets' ),
				[ 'status' => 404 ]
			);
		}

		return rest_ensure_response( self::format_revision( $revision ) );
	}

	/**
	 * Restore a snippet from a revision.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function restore_revision( WP_REST_Request $request ) {
		$snippet_id = absint( $request->get_param( 'id' ) );
		$revision_id = absint( $request->get_param( 'rev_id' ) );
		$network = $request->get_param( 'network' );

		$result = $this->revision_manager->restore_revision( $snippet_id, $revision_id, $network );

		if ( ! $result ) {
			return new WP_Error(
				'rest_revision_restore_failed',
				__( 'The revision could not be restored.', 'code-snippets' ),
				[ 'status' => 500 ]
			);
		}

		return rest_ensure_response(
            [
				'success'  => true,
				'snippet'  => [
					'id'   => $result->id,
					'name' => $result->name,
				],
			]
        );
	}

	/**
	 * Delete a single revision.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_revision( WP_REST_Request $request ) {
		$snippet_id = absint( $request->get_param( 'id' ) );
		$revision_id = absint( $request->get_param( 'rev_id' ) );
		$network = $request->get_param( 'network' );

		$deleted = $this->revision_manager->delete_revision( $revision_id, $snippet_id, $network );

		if ( ! $deleted ) {
			return new WP_Error(
				'rest_revision_delete_failed',
				__( 'The revision could not be deleted.', 'code-snippets' ),
				[ 'status' => 404 ]
			);
		}

		return new WP_REST_Response( null, 204 );
	}

	/**
	 * Get per-snippet versioning settings.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_versioning_settings( WP_REST_Request $request ): WP_REST_Response {
		$snippet_id = absint( $request->get_param( 'id' ) );
		$network = $request->get_param( 'network' );

		return rest_ensure_response(
            [
				'disabled'       => Revision_Manager::is_snippet_versioning_disabled( $snippet_id, $network ),
				'revision_count' => $this->revision_manager->get_revision_count( $snippet_id, $network ),
			]
        );
	}

	/**
	 * Update per-snippet versioning toggle.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function update_versioning_settings( WP_REST_Request $request ): WP_REST_Response {
		$snippet_id = absint( $request->get_param( 'id' ) );
		$network = $request->get_param( 'network' );
		$disabled = (bool) $request->get_param( 'disabled' );

		Revision_Manager::set_snippet_versioning_disabled( $snippet_id, $disabled, $network );

		return rest_ensure_response(
            [
				'disabled' => $disabled,
			]
        );
	}

	/**
	 * Get the delete revision preference.
	 *
	 * @return WP_REST_Response
	 */
	public function get_delete_preference(): WP_REST_Response {
		$value = get_setting( 'general', 'delete_revision_default' );

		return rest_ensure_response(
            [
				'delete_revision_default' => is_string( $value ) ? $value : '',
			]
        );
	}

	/**
	 * Update the delete revision preference.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function update_delete_preference( WP_REST_Request $request ): WP_REST_Response {
		$value = $request->get_param( 'delete_revision_default' );
		update_setting( 'general', 'delete_revision_default', $value );

		return rest_ensure_response(
            [
				'delete_revision_default' => $value,
			]
        );
	}

	/**
	 * Format a revision post into an array suitable for REST API responses.
	 *
	 * @param WP_Post $revision The revision post.
	 *
	 * @return array<string, mixed>
	 */
	private static function format_revision( WP_Post $revision ): array {
		$snapshot = json_decode( $revision->post_content, true );
		$author = get_userdata( $revision->post_author );

		return [
			'id'              => $revision->ID,
			'snippet_id'      => (int) get_post_meta( $revision->ID, Revision_Manager::META_SNIPPET_ID, true ),
			'revision_number' => (int) get_post_meta( $revision->ID, Revision_Manager::META_REVISION_NUMBER, true ),
			'date'            => $revision->post_date_gmt,
			'author'          => $author ? $author->display_name : __( 'Unknown', 'code-snippets' ),
			'author_id'       => (int) $revision->post_author,
			'snapshot'        => $snapshot,
		];
	}
}
