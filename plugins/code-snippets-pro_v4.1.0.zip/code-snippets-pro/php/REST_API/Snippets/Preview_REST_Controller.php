<?php

namespace Code_Snippets\REST_API\Snippets;

use Code_Snippets\Model\Snippet;
use Code_Snippets\Preview\Snippet_Preview;
use Code_Snippets\REST_API\REST_Controller;
use WP_Error;
use Code_Snippets\Settings\Permissions;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;
use function Code_Snippets\Preview\create_placeholder_snippet;
use function Code_Snippets\Preview\get_config;
use function Code_Snippets\Preview\issue_token;
use function Code_Snippets\Preview\set_config;
use function Code_Snippets\Preview\set_draft;
use function Code_Snippets\Preview\touch_placeholder_snippet;
use function Code_Snippets\Preview\validate_preview_url;

/**
 * REST API controller for snippet preview drafts and configuration.
 *
 * @package Code_Snippets
 */
final class Preview_REST_Controller extends REST_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base route for these API endpoints.
	 */
	public const BASE_ROUTE = 'preview';

	/**
	 * Kinds of page a snippet can be previewed on.
	 */
	public const PREVIEW_TYPES = [ 'front', 'post', 'page', 'admin' ];

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			self::BASE_ROUTE . '/draft',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'save_draft' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			self::BASE_ROUTE . '/config',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_config' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'update_config' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);
	}

	/**
	 * Determine whether the request has permission to use the preview endpoints.
	 *
	 * @param WP_REST_Request $request Incoming HTTP request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		// A preview runs the draft's code, which is editing in all but name.
		if ( ! code_snippets()->current_user_can() || ! Permissions::current_user_can_edit_snippets() ) {
			return false;
		}

		$network = rest_sanitize_boolean( $request->get_param( 'network' ) );

		return ! $network || code_snippets()->user_can_manage_network_snippets();
	}

	/**
	 * Save a draft payload and issue a new preview token.
	 *
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function save_draft( WP_REST_Request $request ) {
		$user_id = get_current_user_id();

		$snippet_id = absint( $request->get_param( 'id' ) );
		$network = rest_sanitize_boolean( $request->get_param( 'network' ) );

		$scope = sanitize_key( (string) $request->get_param( 'scope' ) );
		$priority_param = $request->get_param( 'priority' );
		$priority = null === $priority_param ? 10 : intval( $priority_param );
		$condition_id = absint( $request->get_param( 'condition_id' ) ?? $request->get_param( 'conditionId' ) );
		$code = (string) $request->get_param( 'code' );
		$name = (string) $request->get_param( 'name' );

		if ( '' === $scope ) {
			$scope = 'global';
		}

		if ( 'php' === Snippet::get_type_from_scope( $scope ) ) {
			// Match save-time behaviour by removing PHP tags.
			$code = preg_replace( '|^\s*<\?(php)?|', '', $code );
			$code = preg_replace( '|\?>\s*$|', '', $code );
		}

		if ( 0 === $snippet_id ) {
			$snippet_id = create_placeholder_snippet(
				[
					'scope'        => $scope,
					'priority'     => $priority,
					'condition_id' => $condition_id,
					'name'         => $name,
				],
				$network
			);

			if ( 0 === $snippet_id ) {
				return new WP_Error(
					'code_snippets_preview_create_failed',
					__( 'Could not create a draft snippet for preview.', 'code-snippets' ),
					[ 'status' => 500 ]
				);
			}
		}

		touch_placeholder_snippet( $snippet_id, $network );

		set_draft(
			$user_id,
			$snippet_id,
			$network,
			[
				'code'         => $code,
				'scope'        => $scope,
				'priority'     => $priority,
				'condition_id' => $condition_id,
			]
		);

		$token = issue_token( $user_id, $snippet_id, $network );

		return rest_ensure_response(
			[
				'token'    => $token,
				'id'       => $snippet_id,
				'network'  => (bool) $network,
				'queryVar' => Snippet_Preview::QUERY_VAR,
			]
		);
	}

	/**
	 * Retrieve preview configuration for a snippet.
	 *
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response
	 */
	public function get_config( WP_REST_Request $request ): WP_REST_Response {
		$snippet_id = absint( $request->get_param( 'id' ) );
		$network = rest_sanitize_boolean( $request->get_param( 'network' ) );

		return rest_ensure_response(
			[
				'config'   => $snippet_id
					? get_config( get_current_user_id(), $snippet_id, $network )
					: [
						'type' => null,
						'url'  => null,
					],
				'frontUrl' => home_url( '/' ),
			]
		);
	}

	/**
	 * Update preview configuration for a snippet.
	 *
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_config( WP_REST_Request $request ) {
		$snippet_id = absint( $request->get_param( 'id' ) );
		$network = rest_sanitize_boolean( $request->get_param( 'network' ) );

		if ( ! $snippet_id ) {
			return new WP_Error(
				'code_snippets_preview_missing_id',
				__( 'Cannot save preview configuration without a snippet ID.', 'code-snippets' ),
				[ 'status' => 400 ]
			);
		}

		$type = sanitize_key( (string) $request->get_param( 'type' ) );
		if ( ! in_array( $type, self::PREVIEW_TYPES, true ) ) {
			return new WP_Error(
				'code_snippets_preview_invalid_type',
				__( 'Invalid preview type.', 'code-snippets' ),
				[ 'status' => 400 ]
			);
		}

		$url = 'front' === $type ? home_url( '/' ) : validate_preview_url( (string) $request->get_param( 'url' ) );
		if ( is_wp_error( $url ) ) {
			$url->add_data( [ 'status' => 400 ] );
			return $url;
		}

		set_config( get_current_user_id(), $snippet_id, $network, $type, $url );

		return rest_ensure_response(
			[
				'config' => [
					'type' => $type,
					'url'  => $url,
				],
			]
		);
	}
}
