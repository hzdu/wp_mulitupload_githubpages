<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\Controller\Cloud_Library_Controller;
use Code_Snippets\Admin\Menus\Manage\Manage_Menu;
use Code_Snippets\Controller\Cloud_Search_Controller;
use Code_Snippets\Model\Cloud_Snippets;
use Code_Snippets\Model\Snippet;
use Code_Snippets\REST_API\REST_Collection_Controller;
use WP_Error;
use Code_Snippets\Settings\Permissions;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;
use function Code_Snippets\get_snippet;
use function Code_Snippets\get_snippet_by_cloud_id;
use function Code_Snippets\get_snippets;
use function Code_Snippets\save_snippet;

/**
 * Allows fetching cloud snippets through the WordPress REST API.
 *
 * @package Code_Snippets
 */
final class Cloud_Snippets_REST_Controller extends REST_Collection_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base of this controller's route.
	 */
	public const BASE_ROUTE = 'cloud/snippets';

	/**
	 * Search methods supported by the cloud API.
	 */
	private const SEARCH_METHODS = [ 'term', 'codevault', 'ai' ];

	/**
	 * Search controller instance.
	 *
	 * @var Cloud_Search_Controller
	 */
	private Cloud_Search_Controller $search_controller;

	/**
	 * Library controller instance.
	 *
	 * @var Cloud_Library_Controller
	 */
	private Cloud_Library_Controller $library_controller;

	/**
	 * Class constructor.
	 *
	 * @param Cloud_Search_Controller  $search_controller  Cloud search controller.
	 * @param Cloud_Library_Controller $library_controller Cloud library controller.
	 */
	public function __construct(
		Cloud_Search_Controller $search_controller,
		Cloud_Library_Controller $library_controller
	) {
		parent::__construct();
		$this->search_controller = $search_controller;
		$this->library_controller = $library_controller;
	}

	/**
	 * Check the request from Cloud API is valid
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return code_snippets()->current_user_can() && $this->search_controller->verify_rest_request( $request );
	}

	/**
	 * Check the request for the cloud-app drift-sync endpoints is valid.
	 *
	 * Server-to-server drift sync: token alone authorizes, or a logged-in
	 * admin for local calls.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return bool
	 */
	public function cloud_push_permissions_check( WP_REST_Request $request ): bool {
		return $this->search_controller->verify_rest_request( $request ) || code_snippets()->current_user_can();
	}

	/**
	 * Common filter args shared across search and featured endpoints.
	 *
	 * Each filter accepts a single numeric ID (e.g. category=12). The cloud API
	 * resolves IDs to the underlying name/slug.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private function get_filter_args(): array {
		return [
			'category' => [
				'description' => esc_html__( 'Filter by category ID.', 'code-snippets' ),
				'type'        => 'string',
				'default'     => '',
			],
			'type'     => [
				'description' => esc_html__( 'Filter by language/type ID.', 'code-snippets' ),
				'type'        => 'string',
				'default'     => '',
			],
			'status'   => [
				'description' => esc_html__( 'Filter by status ID.', 'code-snippets' ),
				'type'        => 'string',
				'default'     => '',
			],
		];
	}

	/**
	 * Extract filter values from a request.
	 *
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return array<string, string>
	 */
	private function extract_filters( WP_REST_Request $request ): array {
		$filters = [];

		foreach ( [ 'category', 'type', 'status' ] as $filter ) {
			if ( $request->has_param( $filter ) ) {
				$filters[ $filter ] = $request->get_param( $filter ) ?? '';
			}
		}

		return $filters;
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		$collection_args = $this->get_collection_params();
		$filter_args = $this->get_filter_args();

		register_rest_route(
			$this->namespace,
			$this->rest_base,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => array_merge(
						[
							'query'             => [
								'description' => esc_html__( 'Search query.', 'code-snippets' ),
								'type'        => 'string',
								'required'    => true,
							],
							'searchByCodevault' => [
								'description' => esc_html__( 'Treat the search query as the name of a CodeVault instead of a search term.', 'code-snippets' ),
								'type'        => 'boolean',
								'default'     => false,
							],
							'searchMethod'      => [
								'description' => esc_html__( 'Optional search method. Set to "ai" to match snippets by natural-language intent.', 'code-snippets' ),
								'type'        => 'string',
								'enum'        => self::SEARCH_METHODS,
								'default'     => 'term',
							],
							'page'              => $collection_args['page'],
							'per_page'          => $collection_args['per_page'],
						],
						$filter_args
					),
				],
				[
					// Cloud -> site deploy: server-to-server push with no WP
					// session, so this uses a token-first permission check
					// (rather than create_item_permissions_check, which is
					// AND-based and would 403 every cloud deploy). The dedicated
					// callback returns a display-safe "Invalid site token"
					// message so the cloud app can show precise auth feedback.
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'deploy_item' ],
					'permission_callback' => [ $this, 'deploy_permission_check' ],
				],
				'schema' => [ $this, 'get_item_schema' ],
			]
		);

		register_rest_route(
			$this->namespace,
			$this->rest_base . '/codevault',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_codevault_items' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => [ 'page' => $collection_args['page'] ],
					'schema'              => [ $this, 'get_item_schema' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$this->rest_base . '/featured',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_featured_items' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => array_merge(
						$filter_args,
						[
							'page'     => $collection_args['page'],
							'per_page' => $collection_args['per_page'],
						]
					),
				],
				'schema' => [ $this, 'get_item_schema' ],
			]
		);

		register_rest_route(
			$this->namespace,
			$this->rest_base . '/bundle/share_code/(?P<share_code>[\w-]+)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items_from_bundle' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => [
						'share_code' => [
							'description' => esc_html__( 'Bundle share code.', 'code-snippets' ),
							'type'        => 'string',
							'required'    => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$this->rest_base . '/bundle/id/(?P<id>[\d-]+)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items_from_bundle' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => [
						'id' => [
							'description' => esc_html__( 'Bundle identifier.', 'code-snippets' ),
							'type'        => 'string',
							'required'    => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$this->rest_base . '/(?P<id>\d+)/download',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_item' ],
					'permission_callback' => [ $this, 'create_item_permissions_check' ],
					'args'                => [
						'id' => [
							'description' => esc_html__( 'Cloud snippet ID.', 'code-snippets' ),
							'type'        => 'number',
							'required'    => true,
						],
					],
				],
			]
		);

		// Drift-detection endpoints: cloud-app pulls hashes to find
		// divergence, then fetches the body for the few that differ.
		register_rest_route(
			$this->namespace,
			$this->rest_base . '/hashes',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_hashes' ],
					'permission_callback' => [ $this, 'cloud_push_permissions_check' ],
					'args'                => [
						'page'     => [
							'description' => esc_html__( 'Current page of the collection. Omit to return all snippets.', 'code-snippets' ),
							'type'        => 'integer',
							'minimum'     => 1,
						],
						'per_page' => [
							'description' => esc_html__( 'Snippets per page. Omit to return every snippet in one response.', 'code-snippets' ),
							'type'        => 'integer',
							'minimum'     => 1,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$this->rest_base . '/(?P<cloud_id>[\w\-]+)/body',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_body_by_cloud_id' ],
					'permission_callback' => [ $this, 'cloud_push_permissions_check' ],
					'args'                => [
						'cloud_id' => [
							'description' => esc_html__( 'Cloud snippet ID (e.g. "42_0").', 'code-snippets' ),
							'type'        => 'string',
							'required'    => true,
						],
					],
				],
			]
		);
	}

	/**
	 * Augment the standard controller collection query params for cloud searches.
	 *
	 * The per_page default is intentionally removed rather than set here: routes are
	 * registered once, so a schema default would capture a single user's Screen
	 * Options value. Callbacks resolve the per-user default at request time instead.
	 *
	 * @return array Query parameters for the collection.
	 */
	public function get_collection_params(): array {
		$params = parent::get_collection_params();
		unset( $params['per_page']['default'] );
		return $params;
	}

	/**
	 * Record which of the given cloud snippets have already been downloaded to this site.
	 *
	 * Downloading stores the remote identifier on the local snippet, so the local
	 * snippets are the only record of the link once the browser has been reloaded.
	 *
	 * @param Cloud_Snippets $snippets Cloud snippets as retrieved from the cloud API.
	 *
	 * @return Cloud_Snippets The same collection, with local identifiers attached.
	 */
	private function attach_local_ids( Cloud_Snippets $snippets ): Cloud_Snippets {
		$local_ids = [];

		foreach ( get_snippets() as $local_snippet ) {
			if ( $local_snippet->cloud_id && ! $local_snippet->trashed ) {
				$local_ids[ $local_snippet->cloud_id ] = $local_snippet->id;
			}
		}

		foreach ( $snippets->snippets as $cloud_snippet ) {
			$cloud_snippet->local_id = $local_ids[ $cloud_snippet->id ] ?? null;
		}

		return $snippets;
	}

	/**
	 * Determine the search method to use based on request parameters.
	 *
	 * @param WP_REST_Request $request The request object containing the search parameters.
	 *
	 * @return string The search method to use.
	 */
	private function get_search_method( WP_REST_Request $request ): string {
		$search_by_codevault = $request->get_param( 'searchByCodevault' );
		if ( $search_by_codevault ) {
			return 'codevault';
		}

		$method_param = $request->get_param( 'searchMethod' );
		return in_array( $method_param, self::SEARCH_METHODS, true ) ? $method_param : 'term';
	}

	/**
	 * Retrieve cloud snippets using a search query.
	 *
	 * @param WP_REST_Request $request The request object containing the search parameters.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		$query = $request->get_param( 'query' ) ?? '';
		$page = max( 1, intval( $request->get_param( 'page' ) ) );
		$per_page = intval( $request->get_param( 'per_page' ) ?? Manage_Menu::get_cloud_search_per_page() );
		$filters = $this->extract_filters( $request );

		$snippets = $this->search_controller
			->fetch_search_results( $this->get_search_method( $request ), $query, $page, $per_page, $filters );

		return $snippets
			? rest_ensure_response( $this->attach_local_ids( $snippets )->to_rest_response() )
			: new WP_Error(
				'code_snippets_get_snippets_failure',
				esc_html__( 'Could not fetch snippets.', 'code-snippets' ),
				[ 'status' => 500 ]
			);
	}

	/**
	 * Retrieve cloud snippets from the user's private codevault.
	 *
	 * @param WP_REST_Request $request The request object containing the search parameters.
	 *
	 * @return WP_REST_Response
	 */
	public function get_codevault_items( WP_REST_Request $request ): WP_REST_Response {
		$page = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = intval( $request->get_param( 'per_page' ) ?? Manage_Menu::get_cloud_search_per_page() );

		return rest_ensure_response(
			$this->library_controller
				->get_codevault_snippets( $page, $per_page )
				->to_rest_response()
		);
	}

	/**
	 * Retrieve featured snippets from the cloud API.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_featured_items( WP_REST_Request $request ) {
		$page = max( 1, intval( $request->get_param( 'page' ) ) );
		$per_page = intval( $request->get_param( 'per_page' ) ?? Manage_Menu::get_cloud_search_per_page() );
		$filters = $this->extract_filters( $request );

		$snippets = $this->search_controller->get_featured_snippets( $page, $per_page, $filters );

		return $snippets
			? rest_ensure_response( $this->attach_local_ids( $snippets )->to_rest_response() )
			: new WP_Error(
				'code_snippets_featured_snippets_failure',
				esc_html__( 'Could not fetch featured snippets.', 'code-snippets' ),
				[ 'status' => 500 ]
			);
	}

	/**
	 * Retrieve list of bundles for a share code from the REST API.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items_from_bundle( WP_REST_Request $request ) {
		$bundle_id = $request->get_param( 'id' );
		$share_code = $request->get_param( 'share_code' );

		if ( $bundle_id ) {
			$bundle_snippets = $this->library_controller->get_snippets_by_bundle_id( $bundle_id );
		} elseif ( $share_code ) {
			$bundle_snippets = $this->library_controller->get_snippets_by_bundle_share_code( $share_code );
		} else {
			$bundle_snippets = null;
		}

		return is_null( $bundle_snippets )
			? new WP_Error(
				'code_snippets_rest_bundle_not_found',
				esc_html__( 'Bundle not found.', 'code-snippets' ),
				[ 'status' => 404 ]
			)
			: rest_ensure_response( $bundle_snippets->to_rest_response() );
	}

	/**
	 * Download a single cloud snippet.
	 *
	 * @param WP_REST_Request $request The request object containing the search parameters.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_item( $request ) {
		$id = intval( $request->get_param( 'id' ) );
		$cloud_snippet = $this->search_controller->get_cloud_snippet( $id );

		if ( ! $cloud_snippet ) {
			return new WP_Error(
				'code_snippets_cloud_snippet_not_found',
				esc_html__( 'Cloud snippet not found.', 'code-snippets' ),
				[ 'status' => 404 ]
			);
		}

		$local_snippet = $this->search_controller->download_snippet_from_cloud( $cloud_snippet );

		return $local_snippet
			? rest_ensure_response(
				[
					'success'    => true,
					'snippet_id' => $local_snippet->id,
				]
			)
			: new WP_Error(
				'code_snippets_cloud_snippet_download_failed',
				esc_html__( 'Failed to create new snippet.', 'code-snippets' ),
				[ 'status' => 500 ]
			);
	}

	/**
	 * Retrieves the item's schema, conforming to JSON Schema.
	 *
	 * @return array
	 */
	public function get_item_schema(): array {
		if ( $this->schema ) {
			return $this->schema;
		}

		$this->schema = [
			'$schema'    => 'http://json-schema.org/draft-04/schema#',
			'title'      => 'cloud snippet',
			'type'       => 'object',
			'properties' => [
				'id'          => [
					'description' => esc_html__( 'Cloud snippet identifier.', 'code-snippets' ),
					'type'        => 'string',
				],
				'name'        => [
					'description' => esc_html__( 'Title of cloud snippet.', 'code-snippets' ),
					'type'        => 'string',
				],
				'description' => [
					'description' => esc_html__( 'Descriptive text associated with snippet.', 'code-snippets' ),
					'type'        => 'string',
				],
				'code'        => [
					'description' => esc_html__( 'Executable snippet code.', 'code-snippets' ),
					'type'        => 'string',
				],
				'scope'       => [
					'description' => esc_html__( 'Context in which the snippet is executable.', 'code-snippets' ),
					'type'        => 'string',
				],
				'created'     => [
					'description' => esc_html__( 'Date and time when the snippet was last created, in ISO format.', 'code-snippets' ),
					'type'        => 'string',
				],
				'revision'    => [
					'description' => esc_html__( 'Snippet revision number.', 'code-snippets' ),
					'type'        => 'integer',
				],
				'active'      => [
					'description' => esc_html__( 'Whether the snippet should be active on the receiving site. Defaults to false to preserve install-as-inactive behaviour; set true for the self-heal redeploy path.', 'code-snippets' ),
					'type'        => 'boolean',
					'default'     => false,
				],
				'conditions'  => [
					'description' => esc_html__( 'Optional condition rule groups to attach to the snippet. Creates a sibling condition snippet (scope=condition) and links the deployed snippet to it via condition_id.', 'code-snippets' ),
					'type'        => 'array',
				],
				'condition_name' => [
					'description' => esc_html__( 'Optional name for the auto-generated condition snippet.', 'code-snippets' ),
					'type'        => 'string',
				],
				'condition_key'  => [
					'description' => esc_html__( 'Optional stable per-deploy key so every snippet in one deploy shares a single condition snippet.', 'code-snippets' ),
					'type'        => 'string',
				],
			],
		];

		return $this->schema;
	}

	/**
	 * Deploy one snippet pushed from the cloud app.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function deploy_item( $request ) {
		try {
			$body = json_decode( $request->get_body() );
			$snippet_data = is_array( $body ) && isset( $body[0] ) && is_string( $body[0] )
				? json_decode( $body[0], true )
				: null;

			if ( ! is_array( $snippet_data ) ) {
				return $this->deploy_error( __( 'Malformed request body.', 'code-snippets' ), 422 );
			}

			$missing = array_diff( [ 'id', 'name', 'description', 'code', 'scope', 'created' ], array_keys( $snippet_data ) );
			if ( $missing ) {
				return $this->deploy_error(
					/* translators: %s: name of the missing required snippet field. */
					sprintf( __( 'Missing snippet %s', 'code-snippets' ), reset( $missing ) ),
					422
				);
			}

			if ( '' === trim( (string) $snippet_data['code'] ) ) {
				return $this->deploy_error( __( 'Missing snippet code', 'code-snippets' ), 422 );
			}

			return $this->deploy_snippet( $snippet_data );
		} catch ( \Throwable $error ) {
			unset( $error );
			return $this->deploy_error( __( 'Unexpected error while deploying the snippet.', 'code-snippets' ), 500 );
		}
	}

	/**
	 * Persist a validated cloud-pushed snippet and return a deploy response.
	 *
	 * @param array<string, mixed> $snippet_data Decoded snippet payload (already validated).
	 *
	 * @return WP_REST_Response
	 */
	private function deploy_snippet( array $snippet_data ): WP_REST_Response {
		// Resolve the sibling condition (if any) to link this snippet to. Surfaces
		// the rule in the plugin's own Conditions UI rather than baking it into the
		// snippet body as PHP guards. When the payload carries a stable
		// condition_key, every snippet in the same deploy shares ONE condition.
		$condition_local_id = $this->resolve_condition_id( $snippet_data );

		// Re-use the existing local snippet if this cloud_id has been
		// deployed here before — otherwise every re-push (e.g. the AI
		// self-heal "apply fix" flow) would create a duplicate snippet on
		// the site instead of updating the broken one.
		$incoming_cloud_id = $snippet_data['id'] . '_0';
		$existing = get_snippet_by_cloud_id( $incoming_cloud_id );
		$snippet = ( $existing && $existing->id > 0 ) ? $existing : new Snippet();

		$snippet->name = $snippet_data['name'];
		$snippet->desc = $snippet_data['description'];
		$snippet->code = $snippet_data['code'];
		$snippet->scope = $snippet_data['scope'];
		$snippet->modified = $snippet_data['created'];
		$snippet->revision = $snippet_data['revision'] ?? 1;
		$snippet->cloud_id = $snippet_data['id'];
		$snippet->is_cloud_owner = false;
		$snippet->shared_network = false;
		$snippet->network = false;

		// Honor an explicit `active` flag from cloud (used by the self-heal
		// flow to re-enable a snippet that auto-deactivated when it fataled).
		// Default to false to preserve the prior install-as-inactive behavior
		// for fresh deploys.
		$snippet->active = ! empty( $snippet_data['active'] );

		if ( $condition_local_id > 0 ) {
			$snippet->condition_id = $condition_local_id;
		}

		$result = save_snippet( $snippet );

		if ( ! $result || empty( $result->id ) ) {
			return $this->deploy_error( __( 'The snippet could not be saved.', 'code-snippets' ), 500 );
		}

		return new WP_REST_Response(
			[
				'success'    => true,
				'snippet_id' => (int) $result->id,
				'active'     => (bool) $result->active,
				'message'    => __( 'Snippet deployed', 'code-snippets' ),
			],
			200
		);
	}

	/**
	 * Resolve the local condition snippet id to link a deployed snippet to.
	 *
	 * With a stable `condition_key` in the payload, all snippets in the same
	 * deploy share a single condition (find-or-create by key, race-safe). Without
	 * it (older cloud builds), the historical per-snippet behaviour is preserved.
	 *
	 * @param array<string, mixed> $snippet_data Decoded snippet payload.
	 *
	 * @return int Condition snippet id, or 0 when there are no conditions.
	 */
	private function resolve_condition_id( array $snippet_data ): int {
		if ( empty( $snippet_data['conditions'] ) || ! is_array( $snippet_data['conditions'] ) ) {
			return 0;
		}

		$name = ! empty( $snippet_data['condition_name'] )
			? sanitize_text_field( $snippet_data['condition_name'] )
			/* translators: %s: name of the snippet the condition was created for. */
			: sprintf( __( 'Condition for %s', 'code-snippets' ), $snippet_data['name'] );

		$groups = $this->normalise_condition_groups( $snippet_data['conditions'] );

		// A UUID from the cloud; sanitise before using it in an option name / lock.
		$condition_key = isset( $snippet_data['condition_key'] )
			? preg_replace( '/[^A-Za-z0-9\-]/', '', (string) $snippet_data['condition_key'] )
			: '';

		return '' !== $condition_key
			? $this->find_or_create_shared_condition( $condition_key, $groups, $name )
			: $this->create_condition_snippet( $groups, $name );
	}

	/**
	 * Normalise incoming condition rules into the nested-group shape the
	 * evaluator expects: [[{rule}, ...], ...] (rules AND'd within a group,
	 * groups OR'd together). A flat list of rules is wrapped as a single group
	 * so the condition snippet doesn't fatal when evaluated, and every rule is
	 * normalised into the canonical shape read by the editor and evaluator.
	 *
	 * @param array<mixed> $conditions Raw condition rules or groups from the cloud.
	 *
	 * @return array<mixed>
	 */
	private function normalise_condition_groups( array $conditions ): array {
		$first_element = reset( $conditions );
		$groups = ( is_array( $first_element ) && isset( $first_element['subject'] ) )
			? [ $conditions ]
			: $conditions;

		return array_map(
			function ( $group ) {
				return is_array( $group )
					? array_values( array_map( [ $this, 'normalise_condition_rule' ], $group ) )
					: $group;
			},
			$groups
		);
	}

	/**
	 * Normalise a single cloud condition rule into the canonical shape the
	 * condition editor and evaluator read: subject, operator, and the tested
	 * value(s) as an `object` list. The cloud sends values under `value`
	 * (scalar or list); the plugin only ever reads `object`, so without this
	 * mapping deployed rules display blank and evaluate against nothing.
	 * Unknown keys are dropped rather than persisted.
	 *
	 * @param mixed $rule Raw rule from the cloud payload.
	 *
	 * @return array<string, mixed>
	 */
	private function normalise_condition_rule( $rule ): array {
		if ( ! is_array( $rule ) ) {
			return [ 'object' => [] ];
		}

		$normalised = [];

		foreach ( [ 'subject', 'operator' ] as $key ) {
			if ( isset( $rule[ $key ] ) ) {
				$normalised[ $key ] = $rule[ $key ];
			}
		}

		$normalised['object'] = array_values( (array) ( $rule['object'] ?? $rule['value'] ?? [] ) );

		return $normalised;
	}

	/**
	 * Create a single condition snippet (scope=condition) and return its id.
	 *
	 * @param array<mixed> $groups Normalised condition groups.
	 * @param string       $name   Condition snippet name.
	 *
	 * @return int New condition snippet id, or 0 on failure.
	 */
	private function create_condition_snippet( array $groups, string $name ): int {
		$condition = new Snippet();
		$condition->scope = 'condition';
		$condition->name = $name;
		$condition->code = wp_json_encode( $groups );
		$condition->active = false;
		$condition->shared_network = false;
		$condition->network = false;

		$saved = save_snippet( $condition );

		return ( $saved && ! empty( $saved->id ) ) ? (int) $saved->id : 0;
	}

	/**
	 * Find-or-create the single shared condition for a deploy, keyed by
	 * `condition_key`, in a race-safe way.
	 *
	 * Snippet-push requests for one deploy arrive in parallel, so this must yield
	 * exactly one condition per key. We serialise same-key callers with a MySQL
	 * server-wide named lock (GET_LOCK) — held per DB connection, so a concurrent
	 * request blocks until we release — then look up / persist the key -> id
	 * mapping in a dedicated (non-autoloaded) wp_option that acts as the durable
	 * lookup handle for the rest of the deploy. Different keys take different
	 * locks and never contend. No custom schema/migration is introduced (per the
	 * project's storage standards); the option name is the persisted key.
	 *
	 * @param string       $condition_key Sanitised per-deploy key (UUID).
	 * @param array<mixed> $groups        Normalised condition groups.
	 * @param string       $name          Condition snippet name.
	 *
	 * @return int Shared condition snippet id, or 0 on failure.
	 */
	private function find_or_create_shared_condition( string $condition_key, array $groups, string $name ): int {
		global $wpdb;

		$option_name = 'code_snippets_cloud_condition_' . $condition_key;
		$lock_name = substr( 'cs_cond_' . md5( $condition_key ), 0, 64 );

		// A named advisory lock is inherently uncacheable and not a table read.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$locked = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $lock_name, 10 ) );

		// Without the lock we cannot guarantee a single shared condition, so
		// create a standalone one for this snippet rather than racing on the
		// shared key mapping and pretending it is safe. Worst case is a duplicate
		// condition under contention, never a corrupted last-write-wins mapping.
		if ( 1 !== $locked ) {
			return $this->create_condition_snippet( $groups, $name );
		}

		try {
			$existing_id = (int) get_option( $option_name, 0 );
			if ( $existing_id > 0 ) {
				$existing = get_snippet( $existing_id );
				if ( $existing && $existing->id > 0 && 'condition' === $existing->scope && empty( $existing->trashed ) ) {
					return $existing_id;
				}
			}

			$condition_id = $this->create_condition_snippet( $groups, $name );
			if ( $condition_id > 0 ) {
				// Persist the key -> condition mapping (non-autoloaded) so later
				// snippets in this deploy match and reuse this one condition.
				update_option( $option_name, $condition_id, false );
			}

			return $condition_id;
		} finally {
			if ( 1 === $locked ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
			}
		}
	}

	/**
	 * Build a deploy error response: an explicit HTTP status plus a short,
	 * display-safe JSON body the cloud app can show to the site owner.
	 *
	 * @param string $message Short, human-readable, secret-free message.
	 * @param int    $status  HTTP status code to set on the response.
	 *
	 * @return WP_REST_Response
	 */
	private function deploy_error( string $message, int $status ): WP_REST_Response {
		return new WP_REST_Response(
			[
				'success' => false,
				'message' => $message,
			],
			$status
		);
	}

	/**
	 * Permission check for the cloud->site deploy route.
	 *
	 * Token-first (the cloud has no WP session). On failure returns a WP_Error
	 * carrying a display-safe "Invalid site token" message and a 401 status so
	 * the cloud app can surface precise feedback, while still gating the route.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return true|WP_Error
	 */
	public function deploy_permission_check( WP_REST_Request $request ) {
		if ( $this->search_controller->verify_rest_request( $request ) || ( code_snippets()->current_user_can() && Permissions::current_user_can_for_request( $request, 'create' ) ) ) {
			return true;
		}

		return new WP_Error( 'invalid_site_token', __( 'Invalid site token', 'code-snippets' ), [ 'status' => 401 ] );
	}

	/**
	 * Return a SHA-256 hash of every snippet's body on this site, plus the
	 * metadata the cloud needs to build a live inventory and detect drift.
	 *
	 * Cloud-deployed snippets carry their `cloud_id`; locally-created snippets
	 * are reported with `cloud_id: null` so the cloud can surface "site-only"
	 * snippets. `code_hash` is a plain SHA-256 of the exact stored code body
	 * (no trimming, normalization or `<?php` wrapping) so an unchanged snippet
	 * hashes identically on both sides.
	 *
	 * Every snippet is returned by default (no cap). Pagination is opt-in: pass
	 * `per_page` (and optionally `page`) to page the results; the total count and
	 * page count are always advertised via the `X-WP-Total` and
	 * `X-WP-TotalPages` response headers, as with WP core collection endpoints.
	 *
	 * The cloud rebuilds its inventory wholesale from this response, so an empty
	 * `snippets` array means "every snippet was deleted" and wipes it. A read
	 * failure must therefore never surface as an empty list: `get_snippets()`
	 * returns `[]` for both an empty site and a failed query, so the database
	 * error state is what separates the two.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_hashes( WP_REST_Request $request ) {
		global $wpdb;

		$entries = [];
		$previous_error = $wpdb->last_error;
		$wpdb->last_error = '';

		$snippets = get_snippets();

		if ( $wpdb->last_error ) {
			return new WP_Error(
				'code_snippets_cloud_hashes_unavailable',
				__( 'Could not read the local snippet inventory.', 'code-snippets' ),
				[ 'status' => 503 ]
			);
		}

		$wpdb->last_error = $previous_error;

		foreach ( $snippets as $snippet ) {
			if ( ! ( $snippet instanceof Snippet ) ) {
				continue;
			}
			// A trashed snippet is effectively gone — don't report it as a
			// live copy, so the cloud sees it as removed rather than drifted.
			if ( ! empty( $snippet->trashed ) ) {
				continue;
			}
			$entries[] = [
				'cloud_id'    => empty( $snippet->cloud_id ) ? null : (string) $snippet->cloud_id,
				'local_id'    => (int) $snippet->id,
				'code_hash'   => hash( 'sha256', (string) $snippet->code ),
				'revision'    => (int) $snippet->revision,
				'modified'    => (string) $snippet->modified,
				'name'        => (string) $snippet->name,
				'active'      => (bool) $snippet->active,
			];
		}

		$total_items = count( $entries );
		$total_pages = 1;

		// Pagination is opt-in so the default response never silently caps the
		// inventory. Only page when the caller explicitly asks.
		$query_params = $request->get_query_params();
		if ( isset( $query_params['per_page'] ) || isset( $query_params['page'] ) ) {
			$per_page = isset( $query_params['per_page'] ) ? max( 1, (int) $query_params['per_page'] ) : 100;
			$page = max( 1, (int) $request->get_param( 'page' ) );
			$total_pages = $total_items > 0 ? (int) ceil( $total_items / $per_page ) : 1;
			$entries = array_slice( $entries, ( $page - 1 ) * $per_page, $per_page );
		}

		$response = rest_ensure_response( [ 'snippets' => $entries ] );
		$response->header( 'X-WP-Total', (string) $total_items );
		$response->header( 'X-WP-TotalPages', (string) $total_pages );

		return $response;
	}

	/**
	 * Return the body of a single cloud-linked snippet on this site by
	 * cloud_id. Used after `get_hashes` flags a divergence and the cloud
	 * needs the actual local code to render a diff.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_body_by_cloud_id( WP_REST_Request $request ) {
		$cloud_id = (string) $request->get_param( 'cloud_id' );
		if ( '' === $cloud_id ) {
			return new WP_Error( 'rest_missing_param', __( 'Missing cloud_id.', 'code-snippets' ), [ 'status' => 400 ] );
		}

		$snippet = $this->resolve_cloud_snippet( $cloud_id );
		if ( ! $snippet || ! $snippet->id || ! empty( $snippet->trashed ) ) {
			// Treat a trashed snippet as gone — the cloud should see it as
			// deleted on the site, not fetch its lingering body.
			return new WP_Error( 'rest_not_found', __( 'Snippet not found.', 'code-snippets' ), [ 'status' => 404 ] );
		}

		return rest_ensure_response(
			[
				'cloud_id'    => (string) $snippet->cloud_id,
				'local_id'    => (int) $snippet->id,
				'name'        => (string) $snippet->name,
				'code'        => (string) $snippet->code,
				'scope'       => (string) $snippet->scope,
				'revision'    => (int) $snippet->revision,
				'modified'    => (string) $snippet->modified,
				'active'      => (bool) $snippet->active,
				'code_hash'   => hash( 'sha256', (string) $snippet->code ),
			]
		);
	}

	/**
	 * Resolve the snippet a cloud identifier refers to, tolerating the several
	 * forms the cloud may send.
	 *
	 * The site stores a snippet's cloud id together with an ownership flag (e.g.
	 * `177_1`), while the `hashes` list and the cloud's own records key on the
	 * bare numeric id (`177`). An exact match is tried first; failing that, the
	 * bare numeric id is matched against every live snippet's cloud id, ignoring
	 * the ownership suffix — so `177`, `177_0` and `177_1` all resolve to the
	 * same snippet.
	 *
	 * @param string $cloud_id Cloud identifier from the request path.
	 *
	 * @return Snippet|null
	 */
	private function resolve_cloud_snippet( string $cloud_id ): ?Snippet {
		$snippet = get_snippet_by_cloud_id( $cloud_id );
		if ( $snippet instanceof Snippet && $snippet->id ) {
			return $snippet;
		}

		$numeric_id = (int) $cloud_id;
		if ( $numeric_id <= 0 ) {
			return null;
		}

		$snippets = get_snippets();
		if ( is_array( $snippets ) ) {
			foreach ( $snippets as $candidate ) {
				if ( $candidate instanceof Snippet
					&& empty( $candidate->trashed )
					&& (int) $candidate->cloud_id === $numeric_id
				) {
					return $candidate;
				}
			}
		}

		return null;
	}
}
