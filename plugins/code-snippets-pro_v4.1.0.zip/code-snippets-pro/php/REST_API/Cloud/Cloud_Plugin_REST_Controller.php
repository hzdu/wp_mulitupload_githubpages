<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\Core\Plugin_Package_Installer;
use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\REST_API\REST_Controller;
use finfo;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;

/**
 * Receives a bundle exported as a standalone WordPress plugin `.zip` from
 * Code Snippets Cloud and installs (or updates) it on this site.
 *
 * The cloud pushes the archive over `multipart/form-data`, authenticated by the
 * same per-site `Access-Control` token used by the `cloud/snippets` push route.
 * The exported plugin is fully standalone — this endpoint only places the files
 * and (optionally) activates the plugin; it has no runtime dependency on
 * Code Snippets itself.
 *
 * The `code-snippets-pro` slug is a special case: it overwrites the running Pro
 * plugin, so it additionally requires a valid `X-CS-Artifact-Signature` (an
 * HMAC-SHA256 of the archive keyed on the site token) and is version-monotonic
 * (an equal version is a no-op, an older version is refused with 409).
 *
 * @package Code_Snippets
 */
final class Cloud_Plugin_REST_Controller extends REST_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base route for this endpoint.
	 */
	public const BASE_ROUTE = 'cloud/plugin';

	/**
	 * Maximum accepted upload size, in bytes.
	 *
	 * Kept in step with the cloud's expectations. A larger archive is rejected
	 * with HTTP 413 before it is touched.
	 */
	private const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;

	/**
	 * Folder slug of the Code Snippets Pro plugin.
	 *
	 * Pushing this slug overwrites the running Pro plugin in place, so it carries
	 * the extra authenticity (signature) and version-monotonicity guards.
	 */
	private const PRO_SLUG = 'code-snippets-pro';

	/**
	 * Request header carrying the HMAC-SHA256 signature of the uploaded archive.
	 */
	private const ARTIFACT_SIGNATURE_HEADER = 'X-CS-Artifact-Signature';

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection $connection Authenticated connection to Code Snippets Cloud.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		parent::__construct();
		$this->connection = $connection;
	}

	/**
	 * Check if the current request is permitted to install a plugin.
	 *
	 * Cloud has no WP session: accept a valid site token, OR a logged-in admin for local calls.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return $this->connection->verify_rest_request( $request )
			|| ( code_snippets()->current_user_can() && current_user_can( 'install_plugins' ) );
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			self::BASE_ROUTE,
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'install_plugin' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => [
						'slug'     => [
							'description' => esc_html__( 'Target plugin folder slug.', 'code-snippets' ),
							'type'        => 'string',
							'required'    => true,
						],
						'version'  => [
							'description' => esc_html__( 'Plugin version (informational).', 'code-snippets' ),
							'type'        => 'string',
							'default'     => '',
						],
						'activate' => [
							'description' => esc_html__( 'Set to "1" to activate the plugin after installing.', 'code-snippets' ),
							'type'        => 'string',
							'default'     => '',
						],
						'mode'     => [
							'description' => esc_html__( 'Set to "update" to make in-place update semantics explicit.', 'code-snippets' ),
							'type'        => 'string',
							'default'     => '',
						],
					],
				],
			]
		);
	}

	/**
	 * Install (or update) an uploaded plugin archive.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function install_plugin( WP_REST_Request $request ): WP_REST_Response {
		$files = $request->get_file_params();
		$upload = $files['plugin'] ?? null;

		// Must have a usable upload with no transport error.
		if ( ! is_array( $upload ) || empty( $upload['tmp_name'] ) || ! empty( $upload['error'] ) ) {
			return $this->error_response( 'bad_request', __( 'No plugin file was received.', 'code-snippets' ), 400 );
		}

		// Enforce the size cap before doing any work.
		if ( isset( $upload['size'] ) && (int) $upload['size'] > self::MAX_UPLOAD_BYTES ) {
			return $this->error_response( 'payload_too_large', __( 'The plugin archive is too large.', 'code-snippets' ), 413 );
		}

		// Must be a zip: accept a `.zip` extension or a zip mime type.
		if ( ! $this->is_zip_upload( $upload ) ) {
			return $this->error_response( 'bad_request', __( 'The uploaded file is not a zip archive.', 'code-snippets' ), 400 );
		}

		// Destination is ALWAYS WP_PLUGIN_DIR/<sanitised-slug> — never trust the
		// raw slug for the path. Sanitising to [a-z0-9-] also rules out traversal.
		$slug = preg_replace( '/[^a-z0-9\-]/', '', strtolower( (string) $request->get_param( 'slug' ) ) );
		if ( '' === $slug ) {
			return $this->error_response( 'bad_request', __( 'A valid plugin slug is required.', 'code-snippets' ), 400 );
		}

		$signature = (string) $request->get_header( self::ARTIFACT_SIGNATURE_HEADER );

		// Overwriting the running Pro plugin always requires a signed artifact.
		// Other slugs are verified only when a signature is supplied.
		if ( self::PRO_SLUG === $slug && '' === $signature ) {
			return $this->error_response(
				'signature_required',
				__( 'A signed artifact is required to update Code Snippets Pro.', 'code-snippets' ),
				403
			);
		}

		if ( '' !== $signature
		     && ! $this->verify_artifact_signature( $upload['tmp_name'], $signature, $this->connection->get_local_token() )
		) {
			return $this->error_response(
				'invalid_signature',
				__( 'The artifact signature could not be verified.', 'code-snippets' ),
				403
			);
		}

		// A REST request does not load the admin plugin API, which is_plugin_active() needs.
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		$installer = new Plugin_Package_Installer();

		$existing_plugin_file = $installer->find_plugin_main_file( $slug );

		// Pro self-update is version-monotonic: same version is a no-op, an older
		// version is refused. This runs before any files are touched so a rejected
		// or unchanged push leaves the current install intact.
		if ( self::PRO_SLUG === $slug && null !== $existing_plugin_file ) {
			$installed_version = $installer->get_installed_version( $slug );
			$incoming_version = $installer->read_package_version( $upload['tmp_name'], $slug )
				?? (string) $request->get_param( 'version' );

			if ( '' !== $installed_version && '' !== $incoming_version ) {
				if ( version_compare( $incoming_version, $installed_version, '<' ) ) {
					return $this->error_response(
						'version_downgrade',
						__( 'The pushed version is older than the installed version.', 'code-snippets' ),
						409
					);
				}

				if ( version_compare( $incoming_version, $installed_version, '==' ) ) {
					return new WP_REST_Response(
						[
							'success'   => true,
							'slug'      => $slug,
							'version'   => $installed_version,
							'updated'   => false,
							'activated' => is_plugin_active( $existing_plugin_file ),
							'license'   => code_snippets()->licensing->get_cloud_identifiers(),
							'message'   => __( 'Already up to date.', 'code-snippets' ),
						],
						200
					);
				}
			}
		}

		$result = $installer->install(
			$upload['tmp_name'],
			$slug,
			'1' === (string) $request->get_param( 'activate' )
		);

		if ( is_wp_error( $result ) ) {
			return $this->error_response( 'install_failed', $result->get_error_message(), 500 );
		}

		// Report the version actually on disk, not the value the cloud sent.
		$version = '' === $result['version'] ? (string) $request->get_param( 'version' ) : $result['version'];
		$is_update = $result['updated'] || 'update' === strtolower( (string) $request->get_param( 'mode' ) );

		return new WP_REST_Response(
			[
				'success'   => true,
				'slug'      => $slug,
				'version'   => $version,
				'updated'   => $is_update,
				'activated' => $result['activated'],
				'license'   => code_snippets()->licensing->get_cloud_identifiers(),
				'message'   => __( 'Plugin installed.', 'code-snippets' ),
			],
			200
		);
	}

	/**
	 * Verify the HMAC-SHA256 signature of the uploaded archive against the
	 * per-site token. Accepts an optional `sha256=` prefix on the header value.
	 *
	 * @param string $zip_path   Absolute path to the uploaded zip.
	 * @param string $signature  Signature supplied in the request header.
	 * @param string $site_token Per-site token the signature is keyed on.
	 *
	 * @return bool
	 */
	private function verify_artifact_signature( string $zip_path, string $signature, string $site_token ): bool {
		if ( '' === $site_token ) {
			return false;
		}

		$provided = trim( $signature );
		if ( 0 === stripos( $provided, 'sha256=' ) ) {
			$provided = substr( $provided, 7 );
		}

		$expected = hash_hmac_file( 'sha256', $zip_path, $site_token );

		return is_string( $expected ) && hash_equals( $expected, strtolower( $provided ) );
	}

	/**
	 * Determine whether an uploaded file is a zip archive.
	 *
	 * Accepts either a `.zip` extension or a zip mime type reported by finfo, so
	 * a correct upload is not rejected on systems with an unusual mime map.
	 *
	 * @param array<string, mixed> $upload Single entry from the request's file params.
	 *
	 * @return bool
	 */
	private function is_zip_upload( array $upload ): bool {
		$name = isset( $upload['name'] ) ? (string) $upload['name'] : '';
		if ( 'zip' === strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) ) {
			return true;
		}

		$mime = mime_content_type( (string) $upload['tmp_name'] );
		return in_array( $mime, [ 'application/zip', 'application/x-zip-compressed', 'multipart/x-zip' ], true );
	}

	/**
	 * Build a JSON error response with the shape the cloud job expects.
	 *
	 * @param string $code    Machine-readable error code.
	 * @param string $message Human-readable message for logging.
	 * @param int    $status  HTTP status code.
	 *
	 * @return WP_REST_Response
	 */
	private function error_response( string $code, string $message, int $status ): WP_REST_Response {
		return new WP_REST_Response(
			[
				'success' => false,
				'code'    => $code,
				'message' => $message,
			],
			$status
		);
	}
}
