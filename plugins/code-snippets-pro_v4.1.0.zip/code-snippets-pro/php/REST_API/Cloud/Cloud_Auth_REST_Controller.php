<?php

namespace Code_Snippets\REST_API\Cloud;

use Code_Snippets\REST_API\REST_Controller;
use Code_Snippets\Controller\Cloud_Auth_Controller;
use WP_Error;
use Code_Snippets\Settings\Permissions;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use function Code_Snippets\code_snippets;

/**
 * WordPress REST API methods for controlling this site's connection to Code Snippets Cloud.
 *
 * @package Code_Snippets
 */
final class Cloud_Auth_REST_Controller extends REST_Controller {

	/**
	 * Current API version.
	 */
	public const VERSION = 1;

	/**
	 * The base route for these API endpoints.
	 */
	public const BASE_ROUTE = 'cloud';

	/**
	 * Cloud authorization controller instance.
	 *
	 * @var Cloud_Auth_Controller
	 */
	private Cloud_Auth_Controller $controller;

	/**
	 * Class constructor.
	 *
	 * @param Cloud_Auth_Controller $auth_controller Cloud authorization controller instance.
	 */
	public function __construct( Cloud_Auth_Controller $auth_controller ) {
		parent::__construct();
		$this->controller = $auth_controller;
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			self::BASE_ROUTE,
			[
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'remove_sync' ],
					'permission_callback' => [ $this, 'permission_callback' ],
					'args'                => [],
				],
			]
		);
	}

	/**
	 * Check if the current user has permission to access the Cloud AI API endpoints.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return code_snippets()->current_user_can() && Permissions::current_user_can_for_request( $request, 'edit' ) && $this->controller->verify_rest_request( $request );
	}

	/**
	 * Remove sync.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function remove_sync() {
		$this->controller->reset_connection();

		return rest_ensure_response(
			[
				'status'  => 'success',
				'message' => __( 'Sync has been revoked.', 'code-snippets' ),
			]
		);
	}
}
