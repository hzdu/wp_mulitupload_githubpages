<?php

namespace Code_Snippets\Search;

use Code_Snippets\Client\Cloud_Private_Client;
use Code_Snippets\Controller\Cloud_Library_Controller;
use Code_Snippets\Integration\Snippet_Performance_Tracker;
use Code_Snippets\Integration\Snippet_Security_Scanner;
use Code_Snippets\Model\Basic_Cloud_Connection;
use Code_Snippets\Model\Cloud_Snippet;
use Code_Snippets\Settings\Permissions;
use function Code_Snippets\code_snippets;
use function Code_Snippets\get_snippets;

/**
 * Adds the Pro sources to the universal search: the connected Cloud Library,
 * and the per-snippet Insights listed alongside the Stats reports.
 *
 * Trust model for the Cloud Library: its snippets come from Code Snippets Cloud
 * over HTTPS, authenticated with the site's cloud token, and are treated as
 * untrusted text in the same way as community snippets.
 *
 * @package Code_Snippets
 */
class Pro_Search_Sources {

	/**
	 * Transient holding the snippets of the connected cloud library.
	 */
	public const CLOUD_LIBRARY_CACHE_KEY = 'code_snippets_search_cloud_library';

	/**
	 * Most pages of the cloud library fetched for searching.
	 */
	private const MAX_LIBRARY_PAGES = 5;

	/**
	 * Sources that are only searched on a site connected to Code Snippets Cloud.
	 */
	private const CONNECTED_SOURCES = [ 'cloud', 'community' ];

	/**
	 * Connection to Code Snippets Cloud.
	 *
	 * @var Basic_Cloud_Connection
	 */
	private Basic_Cloud_Connection $connection;

	/**
	 * Cloud library controller.
	 *
	 * @var Cloud_Library_Controller
	 */
	private Cloud_Library_Controller $cloud_library;

	/**
	 * Class constructor.
	 *
	 * @param Basic_Cloud_Connection   $connection    Connection to Code Snippets Cloud.
	 * @param Cloud_Library_Controller $cloud_library Cloud library controller.
	 */
	public function __construct( Basic_Cloud_Connection $connection, Cloud_Library_Controller $cloud_library ) {
		$this->connection = $connection;
		$this->cloud_library = $cloud_library;
	}

	/**
	 * Register the filters that add the Pro sources.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'code_snippets/search/sources', [ $this, 'filter_sources' ] );
		add_filter( 'code_snippets/search/source_items', [ $this, 'filter_source_items' ], 10, 5 );
		add_filter( 'code_snippets/search/entries', [ $this, 'filter_entries' ], 10, 3 );
		add_filter( 'code_snippets/search/can_view_snippets', [ Permissions::class, 'current_user_can_view_snippets' ] );
		add_filter( 'code_snippets/search/can_read_code', [ Permissions::class, 'current_user_can_edit_snippets' ] );
	}

	/**
	 * Purge the cached cloud library.
	 *
	 * @return void
	 */
	public static function clear_caches() {
		delete_transient( self::CLOUD_LIBRARY_CACHE_KEY );
	}

	/**
	 * Add the Cloud Library to the searched sources, and leave out the cloud
	 * sources while the site is not connected to Code Snippets Cloud.
	 *
	 * @param string[] $sources Source names.
	 *
	 * @return string[]
	 */
	public function filter_sources( array $sources ): array {
		$position = array_search( 'community', $sources, true );
		array_splice( $sources, false === $position ? count( $sources ) : $position, 0, [ 'cloud' ] );

		return $this->connection->is_authenticated() ? $sources : array_values( array_diff( $sources, self::CONNECTED_SOURCES ) );
	}

	/**
	 * Search the Cloud Library.
	 *
	 * @param array<int, array<string, mixed>> $items   Items found so far.
	 * @param string                           $source  Source name.
	 * @param Search_Query                     $query   Search query.
	 * @param bool                             $network Whether network-wide snippets are being searched.
	 * @param Universal_Search                 $search  Search service.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function filter_source_items( array $items, string $source, Search_Query $query, bool $network, Universal_Search $search ): array {
		if ( 'cloud' !== $source || ! $this->connection->is_authenticated() ) {
			return $items;
		}

		return $search->search_cloud_snippets( $this->get_cloud_library_snippets(), $source, $query );
	}

	/**
	 * Add an Insights entry for every snippet with performance or security data to the Stats source.
	 *
	 * @param array<int, array<string, string>> $entries Index entries.
	 * @param string                            $source  Source the entries belong to.
	 * @param bool                              $network Whether links lead to the network admin.
	 *
	 * @return array<int, array<string, string>>
	 */
	public function filter_entries( array $entries, string $source, bool $network ): array {
		return 'stats' === $source ? array_merge( $entries, $this->get_snippet_insights_entries( $network ) ) : $entries;
	}

	/**
	 * Retrieve the snippets in the connected cloud library, with any local copies attached.
	 *
	 * @return Cloud_Snippet[]
	 */
	private function get_cloud_library_snippets(): array {
		$cached = get_transient( self::CLOUD_LIBRARY_CACHE_KEY );

		if ( ! is_array( $cached ) ) {
			$cached = [];
			$page = 1;

			do {
				$result = Universal_Search::request_cloud(
					fn() => $this->cloud_library->fetch_codevault_snippets( $page, Cloud_Private_Client::MAX_PER_PAGE )
				);

				if ( ! $result ) {
					return [];
				}

				foreach ( $result->snippets as $snippet ) {
					$cached[] = $snippet->get_fields();
				}
			} while ( $page++ < min( (int) $result->total_pages, self::MAX_LIBRARY_PAGES ) );

			set_transient( self::CLOUD_LIBRARY_CACHE_KEY, $cached, Universal_Search::REMOTE_CACHE_TTL );
		}

		return array_map(
			fn( array $fields ) => $this->cloud_library->enrich_cloud_snippet( new Cloud_Snippet( $fields ) ),
			$cached
		);
	}

	/**
	 * Build an Insights entry for every snippet that has performance or security data.
	 *
	 * Finding excerpts are left out because they quote the snippet's code.
	 *
	 * @param bool $network Whether to look at network-wide snippets.
	 *
	 * @return array<int, array<string, string>>
	 */
	private function get_snippet_insights_entries( bool $network ): array {
		$stats = Snippet_Performance_Tracker::all_stats();
		$findings = Snippet_Security_Scanner::get_all_findings();

		if ( ! $stats && ! $findings ) {
			return [];
		}

		$manage_url = code_snippets()->get_menu_url( 'manage', $network ? 'network' : 'admin' );
		$insights_label = __( 'Insights', 'code-snippets' );
		$entries = [];

		foreach ( get_snippets( [], $network ) as $snippet ) {
			if ( $snippet->trashed ) {
				continue;
			}

			$url = add_query_arg(
				[
					's'        => rawurlencode( $snippet->display_name ),
					'insights' => $snippet->id,
				],
				$manage_url
			);

			$samples = (int) ( $stats[ $snippet->id ]['samples'] ?? 0 );

			if ( $samples > 0 ) {
				$entries[] = [
					'id'          => "performance-$snippet->id",
					'type'        => 'stat',
					'title'       => $snippet->display_name,
					'description' => sprintf(
						/* translators: 1: average execution time in milliseconds, 2: slowest execution time in milliseconds, 3: number of executions measured. */
						_n(
							'Performance: runs in %1$s ms on average and %2$s ms at its slowest, measured over %3$s execution.',
							'Performance: runs in %1$s ms on average and %2$s ms at its slowest, measured over %3$s executions.',
							$samples,
							'code-snippets'
						),
						number_format_i18n( (float) ( $stats[ $snippet->id ]['ema_ms'] ?? 0 ), 1 ),
						number_format_i18n( (float) ( $stats[ $snippet->id ]['max_ms'] ?? 0 ), 1 ),
						number_format_i18n( $samples )
					),
					'url'         => $url,
					'path'        => Search_Index::build_path( $insights_label, __( 'Performance', 'code-snippets' ) ),
				];
			}

			$open_findings = array_filter(
				is_array( $findings[ $snippet->id ] ?? null ) ? $findings[ $snippet->id ] : [],
				fn( $finding ) => is_array( $finding ) && empty( $finding['dismissed'] )
			);

			if ( $open_findings ) {
				$titles = array_unique( array_filter( array_map( fn( array $finding ) => (string) ( $finding['title'] ?? '' ), $open_findings ) ) );

				$entries[] = [
					'id'          => "security-$snippet->id",
					'type'        => 'stat',
					'title'       => $snippet->display_name,
					'description' => sprintf(
						/* translators: 1: number of security findings, 2: comma-separated list of the findings. */
						_n(
							'Security: %1$s finding to review. %2$s',
							'Security: %1$s findings to review. %2$s',
							count( $open_findings ),
							'code-snippets'
						),
						number_format_i18n( count( $open_findings ) ),
						Search_Query::plain_text( implode( ', ', $titles ) )
					),
					'url'         => $url,
					'path'        => Search_Index::build_path( $insights_label, __( 'Security', 'code-snippets' ) ),
				];
			}
		}

		return $entries;
	}
}
