<?php
/**
 * Interpreter used when no classification service is available.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

/**
 * Leaves every candidate unclassified, so discovery still lists what it found.
 */
class Null_Interpreter implements Interpreter_Interface {

	/**
	 * Interpret nothing.
	 *
	 * @param array<int, array<string, mixed>> $candidates Raw candidates.
	 *
	 * @return array<int, array<string, mixed>> Always empty.
	 */
	public function interpret( array $candidates ): array {
		return [];
	}
}
