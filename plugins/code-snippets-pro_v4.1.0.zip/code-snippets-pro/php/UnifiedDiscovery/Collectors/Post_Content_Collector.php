<?php
/**
 * Generic post content collector.
 *
 * Plugins that manage code as posts (WPCode, and any custom post type built
 * for the purpose), reusable blocks, and pages carrying a Custom HTML block
 * all end up in wp_posts. This reads post content of every real post type and
 * surfaces what looks like code, so a script that lives only inside a page is
 * found without waiting for that page to render.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

/**
 * Collect code-looking post content.
 */
class Post_Content_Collector {

	/**
	 * Most posts to inspect, newest first.
	 */
	const MAX_ROWS = 2000;

	/**
	 * Post types that never carry user code in their content.
	 *
	 * @var array<int, string>
	 */
	const SKIP_POST_TYPES = [ 'revision', 'attachment', 'nav_menu_item', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_navigation', 'snippet_revision' ];

	/**
	 * Run the collector.
	 *
	 * @return array<int, array<string, mixed>> Raw candidates.
	 */
	public function collect(): array {
		global $wpdb;

		// snippet_revision is Code Snippets' own history and is never a discovery.
		// An empty list, which is how a site keeps every type, must not become
		// "NOT IN ()", which MySQL rejects.
		$skip        = self::skipped_post_types();
		$skip_clause = $skip ? 'AND post_type NOT IN (' . implode( ',', array_fill( 0, count( $skip ), '%s' ) ) . ')' : '';
		$placeholder = array_merge( $skip, [ Code_Heuristic::MIN_LENGTH, self::MAX_ROWS ] );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- one-off audit scan; the IN list and its placeholders are both built from the same array, so the counts match.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_type, post_title, post_status, post_content
				 FROM {$wpdb->posts}
				 WHERE post_status NOT IN ('trash', 'auto-draft', 'inherit')
				   $skip_clause
				   AND LENGTH(post_content) >= %d
				 ORDER BY post_modified DESC
				 LIMIT %d",
				$placeholder
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared

		if ( ! is_array( $rows ) ) {
			return [];
		}

		$candidates = [];

		foreach ( $rows as $row ) {
			$base = sprintf( 'post:%s/%d', $row['post_type'], $row['ID'] );

			// The Site Editor's Additional CSS lives inside a theme.json-shaped
			// document; only its css strings are code, so surface those alone.
			if ( 'wp_global_styles' === $row['post_type'] ) {
				foreach ( self::extract_global_styles_css( (string) $row['post_content'] ) as $path => $css ) {
					if ( Code_Heuristic::looks_like_code( $css ) ) {
						$candidates[] = [
							'code'        => $css,
							'source_path' => $base . '/' . $path,
							'source_hint' => 'site-editor/custom-css',
						];
					}
				}

				continue;
			}

			// Some plugins keep settings as serialised arrays in post_content (ACF
			// field groups, for one). Walk those like an option rather than
			// pattern-matching the raw serialised string.
			$where = [
				'post_type'   => $row['post_type'],
				'post_title'  => mb_substr( (string) $row['post_title'], 0, 60 ),
				'post_id'     => (int) $row['ID'],
				'post_status' => (string) $row['post_status'],
			];

			if ( is_serialized( $row['post_content'] ) ) {
				foreach ( Code_Heuristic::flatten_with_context( Code_Heuristic::unserialize_safely( $row['post_content'] ), $base ) as $path => $entry ) {
					$string = Code_Heuristic::normalise( $entry['value'] );

					if ( Code_Heuristic::looks_like_code( $string ) ) {
						$candidates[] = [
							'code'        => $string,
							'source_path' => $path,
							'source_hint' => sprintf( 'database/post-content (%s, serialised)', $row['post_type'] ),
							'context'     => $entry['context'] + $where,
						];
					}
				}

				continue;
			}

			// Code shown to readers inside <pre> or <code> is an example, not
			// something the site runs, and once its entities are decoded it
			// would look exactly like the real thing.
			$displayed = self::without_displayed_code( (string) $row['post_content'] );
			$content   = Code_Heuristic::normalise( $displayed );
			$blocks    = Runtime_Capture_Collector::extract_inline( $content );

			// Blocks that keep their content in attributes rather than markup:
			// Divi 5's modules, and any block with a custom CSS or script field.
			foreach ( self::block_attributes( (string) $row['post_content'] ) as $path => $entry ) {
				$string = Code_Heuristic::normalise( $entry['value'] );

				if ( Code_Heuristic::looks_like_code( $string ) ) {
					$candidates[] = [
						'code'        => $string,
						'source_path' => $base . '/' . $path,
						'source_hint' => sprintf( 'database/post-content (%s: %s, %s block attribute)', $row['post_type'], $row['post_title'], $entry['context']['block'] ),
						'context'     => $entry['context'] + $where,
					];
				}
			}

			// A page is not the snippet: when its content holds script or style
			// tags, those are what the person pasted in, so they are surfaced on
			// their own. Content without tags, such as a bare-JS code post type,
			// is surfaced whole.
			$counts = [];

			foreach ( $blocks as $block ) {
				$counts[ $block['kind'] ] = ( $counts[ $block['kind'] ] ?? 0 ) + 1;
				$candidates[]             = [
					'code'        => $block['code'],
					'source_path' => sprintf( '%s#%s%d', $base, $block['kind'], $counts[ $block['kind'] ] ),
					'source_hint' => sprintf( 'database/post-content (%s: %s, inline %s)', $row['post_type'], $row['post_title'], $block['kind'] ),
					'context'     => $where,
				];
			}

			if ( ! $blocks && Code_Heuristic::looks_like_code( $content ) ) {
				$candidates[] = [
					'code'        => $content,
					'source_path' => $base,
					'source_hint' => sprintf( 'database/post-content (%s: %s)', $row['post_type'], $row['post_title'] ),
					'context'     => $where,
				];
			}
		}

		return $candidates;
	}

	/**
	 * Shortcode tags that show code to readers rather than running it.
	 *
	 * SyntaxHighlighter Evolved and its imitators wrap a sample in a tag
	 * named after the language, or in [code] / [sourcecode].
	 */
	const DISPLAY_SHORTCODES = 'code|sourcecode|plain|text|php|js|javascript|jscript|css|html|xml|xhtml|sql|bash|shell|sh|python|py|ruby|rb|java|csharp|cpp|c|go|json|yaml|yml|groovy|perl|pl|powershell|ps|scala|vb|diff|patch';

	/**
	 * Post content with the code that is only displayed removed.
	 *
	 * A code sample in a tutorial is not a snippet: <pre> and <code> blocks
	 * (which is how the Code and Preformatted blocks are stored) and the
	 * highlighter shortcodes are dropped before anything is extracted.
	 *
	 * @param string $content Post content.
	 *
	 * @return string
	 */
	public static function without_displayed_code( string $content ): string {
		$content = (string) preg_replace( '#<(pre|code)\b[^>]*>.*?</\1>#is', '', $content );

		return (string) preg_replace( '#\[(' . self::DISPLAY_SHORTCODES . ')(?:\s[^\]]*)?\].*?\[/\1\]#is', '', $content );
	}

	/**
	 * Post types left out of the scan, as filtered.
	 *
	 * @return array<int, string>
	 */
	public static function skipped_post_types(): array {
		$skip = (array) apply_filters( 'code_snippets/discovery/skip_post_types', self::SKIP_POST_TYPES );

		return array_values( array_filter( array_map( 'strval', $skip ), 'strlen' ) );
	}

	/**
	 * Every string held in a block's attributes, with the block it belongs to.
	 *
	 * @param string $content Post content.
	 *
	 * @return array<string, array{value: string, context: array<string, mixed>}> Keyed by block:<name>[<n>]/<attribute path>.
	 */
	public static function block_attributes( string $content ): array {
		if ( ! has_blocks( $content ) ) {
			return [];
		}

		$out    = [];
		$counts = [];
		$walk   = static function ( array $blocks ) use ( &$walk, &$out, &$counts ): void {
			foreach ( $blocks as $block ) {
				$name = (string) ( $block['blockName'] ?? '' );

				if ( '' !== $name && ! empty( $block['attrs'] ) && is_array( $block['attrs'] ) ) {
					$counts[ $name ] = ( $counts[ $name ] ?? 0 ) + 1;

					foreach ( Code_Heuristic::flatten_with_context( $block['attrs'], sprintf( 'block:%s[%d]', $name, $counts[ $name ] ) ) as $path => $entry ) {
						$entry['context'] = [ 'block' => $name ] + $entry['context'];
						$out[ $path ]     = $entry;
					}
				}

				if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
					$walk( $block['innerBlocks'] );
				}
			}
		};

		$walk( parse_blocks( $content ) );

		return $out;
	}

	/**
	 * Pull every css string out of a global styles document.
	 *
	 * @param string $json Post content of a wp_global_styles post.
	 *
	 * @return array<string, string> Path within the document => CSS.
	 */
	public static function extract_global_styles_css( string $json ): array {
		$decoded = json_decode( $json, true );

		if ( ! is_array( $decoded ) ) {
			return [];
		}

		return array_filter(
			Code_Heuristic::flatten( $decoded, 'document' ),
			static fn( string $path ): bool => '/css' === substr( $path, -4 ),
			ARRAY_FILTER_USE_KEY
		);
	}
}
