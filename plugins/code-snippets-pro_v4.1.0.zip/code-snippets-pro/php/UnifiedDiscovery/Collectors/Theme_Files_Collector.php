<?php
/**
 * Collect code from theme files and the Customizer.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

/**
 * Parent and child functions.php, the files they require, child style.css,
 * block-theme files, Additional CSS, and the same for child themes that are
 * installed but not active.
 */
class Theme_Files_Collector {

	/**
	 * How many levels of require/include to follow from functions.php.
	 */
	const MAX_REQUIRE_DEPTH = 2;

	/**
	 * Most inactive child themes read.
	 */
	const MAX_INACTIVE_THEMES = 10;

	/**
	 * Seconds a file must post-date its theme's style.css to count as edited after install.
	 *
	 * Installs and deployments write every file within moments of each other.
	 */
	const EDIT_GRACE = 5 * MINUTE_IN_SECONDS;

	/**
	 * Files already surfaced in this run.
	 *
	 * @var array<string, bool>
	 */
	private array $seen = [];

	/**
	 * Run the collector.
	 *
	 * @return array<int, array<string, mixed>> Raw candidates.
	 */
	public function collect(): array {
		$this->seen = [];
		$child      = get_stylesheet_directory();
		$parent     = get_template_directory();
		$candidates = [];

		if ( $child !== $parent ) {
			$candidates = $this->theme_candidates( $child, 'child-theme', true, [] );
		}

		$candidates = array_merge( $candidates, $this->theme_candidates( $parent, 'theme', false, [] ) );

		// A child theme that exists at all is someone's customisation, and
		// switching themes is how it stops running without anyone deleting it.
		foreach ( self::inactive_child_themes() as $stylesheet => $dir ) {
			$candidates = array_merge(
				$candidates,
				$this->theme_candidates( $dir, 'inactive-child-theme/' . $stylesheet, true, [ 'theme_active' => false ] )
			);
		}

		$custom_css = wp_get_custom_css();

		if ( is_string( $custom_css ) && '' !== trim( $custom_css ) ) {
			$candidates[] = [
				'code'        => $custom_css,
				'source_path' => 'customizer:additional_css',
				'source_hint' => 'customizer/additional-css',
			];
		}

		return $candidates;
	}

	/**
	 * Everything worth reading in one theme directory.
	 *
	 * A customised theme (a child, active or not) is read in full: its
	 * functions.php and requires, its style.css, its block-theme files and
	 * theme.json. A parent theme's functions.php is read too, since people do
	 * edit it in place, but its block-theme files are the theme itself, so
	 * they are read only when they post-date the install.
	 *
	 * @param string               $dir        Theme directory.
	 * @param string               $label      Prefix for the source hint.
	 * @param bool                 $customised Whether the whole theme is a customisation.
	 * @param array<string, mixed> $context    Context attached to every candidate.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function theme_candidates( string $dir, string $label, bool $customised, array $context ): array {
		$candidates = [];
		$installed  = is_readable( $dir . '/style.css' ) ? (int) filemtime( $dir . '/style.css' ) : 0;

		foreach ( $this->files_for_theme( $dir ) as $path ) {
			if ( isset( $this->seen[ $path ] ) || ! is_readable( $path ) ) {
				continue;
			}

			// A parent theme's files are the theme itself until someone edits one.
			if ( ! $customised && ! self::modified_after( $path, $installed ) ) {
				continue;
			}

			$this->seen[ $path ] = true;
			$code                = Code_Heuristic::read_file( $path );

			if ( is_string( $code ) && '' !== trim( $code ) ) {
				$candidates[] = [
					'code'        => $code,
					'source_path' => $path,
					'source_hint' => $label . '/' . self::relative( $dir, $path ),
					'context'     => $context + ( $customised ? [] : [ 'modified_after_install' => true ] ),
				];
			}
		}

		if ( $customised && is_readable( $dir . '/style.css' ) ) {
			$css = Code_Heuristic::read_file( $dir . '/style.css' );

			if ( is_string( $css ) && Code_Heuristic::looks_like_code( preg_replace( '#^/\*.*?\*/#s', '', $css, 1 ) ?? '' ) ) {
				$candidates[] = [
					'code'        => $css,
					'source_path' => $dir . '/style.css',
					'source_hint' => $label . '/style.css',
					'context'     => $context,
				];
			}
		}

		foreach ( self::block_theme_files( $dir ) as $path ) {
			if ( ! $customised && ! self::modified_after( $path, $installed ) ) {
				continue;
			}

			$markup = Code_Heuristic::read_file( $path );

			foreach ( Runtime_Capture_Collector::extract_inline( is_string( $markup ) ? $markup : '' ) as $block ) {
				$candidates[] = [
					'code'        => $block['code'],
					'source_path' => $path,
					'source_hint' => $label . '/' . self::relative( $dir, $path ) . ' (inline ' . $block['kind'] . ')',
					'context'     => $context + ( $customised ? [] : [ 'modified_after_install' => true ] ),
				];
			}
		}

		$theme_json = $dir . '/theme.json';

		if ( is_readable( $theme_json ) && ( $customised || self::modified_after( $theme_json, $installed ) ) ) {
			$json = Code_Heuristic::read_file( $theme_json );

			foreach ( Post_Content_Collector::extract_global_styles_css( is_string( $json ) ? $json : '' ) as $path => $css ) {
				if ( Code_Heuristic::looks_like_code( $css ) ) {
					$candidates[] = [
						'code'        => $css,
						'source_path' => $theme_json . '#' . $path,
						'source_hint' => $label . '/theme.json custom css',
						'context'     => $context,
					];
				}
			}
		}

		return $candidates;
	}

	/**
	 * Child themes that are installed but not the active stylesheet.
	 *
	 * @return array<string, string> Stylesheet slug => directory.
	 */
	public static function inactive_child_themes(): array {
		$out = [];

		foreach ( wp_get_themes( [ 'errors' => false ] ) as $stylesheet => $theme ) {
			if ( get_stylesheet() === $stylesheet || ! $theme->parent() ) {
				continue;
			}

			$out[ (string) $stylesheet ] = $theme->get_stylesheet_directory();

			if ( count( $out ) >= self::MAX_INACTIVE_THEMES ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * Whether a file was written well after its theme was installed.
	 *
	 * @param string $path      File.
	 * @param int    $installed Modification time of the theme's style.css, or 0 when unknown.
	 *
	 * @return bool
	 */
	public static function modified_after( string $path, int $installed ): bool {
		return $installed > 0 && (int) filemtime( $path ) > $installed + self::EDIT_GRACE;
	}

	/**
	 * A path relative to its theme directory.
	 *
	 * @param string $dir  Theme directory.
	 * @param string $path Absolute path within it.
	 *
	 * @return string
	 */
	private static function relative( string $dir, string $path ): string {
		return ltrim( str_replace( wp_normalize_path( $dir ), '', wp_normalize_path( $path ) ), '/' );
	}

	/**
	 * The theme's functions.php plus whatever it requires, followed to a bounded depth.
	 *
	 * @param string $theme_dir Theme directory.
	 *
	 * @return array<int, string> Absolute paths, functions.php first.
	 */
	private function files_for_theme( string $theme_dir ): array {
		$functions = $theme_dir . '/functions.php';

		if ( ! is_readable( $functions ) ) {
			return [];
		}

		$files = [ $functions ];
		$queue = [ [ $functions, 0 ] ];

		while ( $queue ) {
			list( $file, $depth ) = array_shift( $queue );

			if ( $depth >= self::MAX_REQUIRE_DEPTH ) {
				continue;
			}

			$source = Code_Heuristic::read_file( $file );

			foreach ( self::resolve_required_files( is_string( $source ) ? $source : '', $theme_dir, dirname( $file ) ) as $required ) {
				if ( ! in_array( $required, $files, true ) ) {
					$files[] = $required;
					$queue[] = [ $required, $depth + 1 ];
				}
			}
		}

		return $files;
	}

	/**
	 * Resolve the files a PHP source requires from within its theme.
	 *
	 * Handles the forms themes actually use: a theme-directory function,
	 * __DIR__, dirname( __FILE__ ), or a bare relative string, joined to a
	 * quoted path. Anything it cannot resolve to a file inside the theme is
	 * ignored.
	 *
	 * @param string $source    PHP source to scan.
	 * @param string $theme_dir Theme directory the file belongs to.
	 * @param string $file_dir  Directory of the file being scanned.
	 *
	 * @return array<int, string> Absolute paths that exist.
	 */
	public static function resolve_required_files( string $source, string $theme_dir, string $file_dir ): array {
		$pattern = '/\b(?:require|include)(?:_once)?\s*\(?\s*'
			. '(?:(get_stylesheet_directory|get_template_directory|get_theme_file_path|__DIR__|dirname\s*\(\s*__FILE__\s*\))(?:\(\))?\s*\.\s*)?'
			. '[\'"]([^\'"]+\.php)[\'"]/i';

		$theme_dir = rtrim( wp_normalize_path( $theme_dir ), '/' );
		$resolved  = [];
		preg_match_all( $pattern, $source, $matches, PREG_SET_ORDER );

		// Call forms take the relative path as their argument rather than
		// concatenating it: locate_template( 'inc/x.php' ) and friends.
		$call_pattern = '/\b(?:require|include)(?:_once)?\s*\(?\s*'
			. '(?:locate_template|get_theme_file_path|get_parent_theme_file_path)\s*\(\s*'
			. '[\'"]([^\'"]+\.php)[\'"]/i';

		if ( preg_match_all( $call_pattern, $source, $calls ) ) {
			foreach ( $calls[1] as $relative ) {
				$matches[] = [ '', 'get_template_directory', $relative ];
			}
		}

		$root = realpath( $theme_dir );
		$root = false === $root ? '' : rtrim( wp_normalize_path( $root ), '/' );

		foreach ( $matches as $match ) {
			$base = 0 === strpos( $match[1], 'dirname' ) || '__DIR__' === $match[1] ? $file_dir : $theme_dir;
			$real = realpath( $base . '/' . ltrim( $match[2], '/' ) );

			// realpath() resolves ".." and symlinks, so a require that spells a
			// path inside the theme but points outside it is not followed.
			if ( '' === $root || false === $real ) {
				continue;
			}

			$path = wp_normalize_path( $real );

			if ( 0 === strpos( $path, $root . '/' ) && is_file( $path ) ) {
				$resolved[] = $path;
			}
		}

		return array_values( array_unique( $resolved ) );
	}

	/**
	 * A block theme's pattern, part and template files.
	 *
	 * @param string $theme_dir Theme directory.
	 *
	 * @return array<int, string> Absolute paths.
	 */
	public static function block_theme_files( string $theme_dir ): array {
		$files = [];

		foreach ( [ 'patterns/*.php', 'parts/*.html', 'templates/*.html' ] as $glob ) {
			$files = array_merge( $files, (array) glob( $theme_dir . '/' . $glob ) );
		}

		return array_values( array_filter( $files, 'is_readable' ) );
	}
}
