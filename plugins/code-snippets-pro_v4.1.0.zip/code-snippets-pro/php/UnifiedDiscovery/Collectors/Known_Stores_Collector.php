<?php
/**
 * Known snippet stores collector: code that other snippet managers keep as
 * files, read at source rather than only through what they print.
 *
 * Database-backed managers are already covered by the options, post and
 * custom-table collectors. File-backed ones keep their snippets in a folder
 * of their own under wp-content, with the title, type and status in a header
 * the manager writes. Each known store says where its files live and how to
 * read one.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

/**
 * Collect snippets from file-backed snippet managers.
 */
class Known_Stores_Collector {

	/**
	 * Most files read from one store.
	 */
	const MAX_FILES = 500;

	/**
	 * Header keys copied into the candidate's context, when present.
	 */
	const FLUENT_CONTEXT_KEYS = [ 'status', 'run_at', 'priority', 'group', 'tags', 'description' ];

	/**
	 * The stores this collector knows how to read.
	 *
	 * Each entry names the plugin, the folder its files live in relative to
	 * wp-content, which files count, and the method that turns one file
	 * into a candidate.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function stores(): array {
		$stores = [
			'fluent-snippets' => [
				'label'      => 'FluentSnippets',
				'plugin'     => 'easy-code-manager',
				'dir'        => 'fluent-snippet-storage',
				'pattern'    => '/\.php$/',
				'parser'     => [ self::class, 'parse_fluent_snippet' ],
				'admin_page' => 'fluent-snippets',
			],
		];

		/**
		 * Filters the file-backed snippet stores discovery reads.
		 *
		 * @param array<string, array<string, mixed>> $stores Stores keyed by id, each with label,
		 *                                                    plugin, dir (relative to wp-content),
		 *                                                    pattern (regex on the file name) and
		 *                                                    parser (callable taking the file contents
		 *                                                    and path, returning a candidate or null), and
		 *                                                    optionally admin_page (the slug of the page
		 *                                                    that edits the store's snippets).
		 */
		return (array) apply_filters( 'code_snippets/discovery/known_stores', $stores );
	}

	/**
	 * Run the collector.
	 *
	 * @return array<int, array<string, mixed>> Raw candidates.
	 */
	public function collect(): array {
		$candidates = [];

		foreach ( self::stores() as $id => $store ) {
			$dir = WP_CONTENT_DIR . '/' . ltrim( (string) ( $store['dir'] ?? '' ), '/' );

			if ( '' === trim( (string) ( $store['dir'] ?? '' ) ) || ! is_dir( $dir ) || ! is_callable( $store['parser'] ?? null ) ) {
				continue;
			}

			$files = scandir( $dir );

			if ( ! is_array( $files ) ) {
				continue;
			}

			$read = 0;

			foreach ( $files as $file ) {
				if ( in_array( $file, [ '.', '..', 'index.php' ], true ) || ! preg_match( (string) $store['pattern'], $file ) ) {
					continue;
				}

				$path = $dir . '/' . $file;

				if ( ! is_file( $path ) || ++$read > self::MAX_FILES ) {
					continue;
				}

				$contents = Code_Heuristic::read_file( $path );

				if ( ! is_string( $contents ) ) {
					continue;
				}

				$candidate = call_user_func( $store['parser'], $contents, $path );

				if ( ! is_array( $candidate ) || '' === trim( (string) ( $candidate['code'] ?? '' ) ) ) {
					continue;
				}

				$candidate['source_path'] = $path;
				$candidate['source_hint'] = (string) $id;
				$candidate['context']     = array_merge(
					[
						'store'  => (string) ( $store['label'] ?? $id ),
						'plugin' => (string) ( $store['plugin'] ?? '' ),
					],
					(array) ( $candidate['context'] ?? [] )
				);

				$candidates[] = $candidate;
			}
		}

		return $candidates;
	}

	/**
	 * Read one FluentSnippets file.
	 *
	 * The plugin writes a header block between "<Internal Doc Start>" and
	 * "<Internal Doc End>" holding the title, type, status and run location,
	 * then the snippet itself. A snippet that is not published is still a
	 * discovery, marked inactive.
	 *
	 * @param string $contents File contents.
	 * @param string $path     File path.
	 *
	 * @return array<string, mixed>|null Candidate, or null when the file is not a FluentSnippets file.
	 */
	public static function parse_fluent_snippet( string $contents, string $path ): ?array {
		if ( ! preg_match( '#<Internal Doc Start>(.*?)<Internal Doc End>\s*\?>#s', $contents, $m ) ) {
			return null;
		}

		$header = [];

		if ( preg_match_all( '/^\s*\*\s*@([a-z_]+):[ \t]*(.*)$/m', $m[1], $lines, PREG_SET_ORDER ) ) {
			foreach ( $lines as $line ) {
				$header[ $line[1] ] = trim( $line[2] );
			}
		}

		$code = trim( substr( $contents, strpos( $contents, $m[0] ) + strlen( $m[0] ) ) );
		$type = strtolower( (string) ( $header['type'] ?? '' ) );

		$context = [
			'title'     => (string) ( $header['name'] ?? basename( $path, '.php' ) ),
			'code_type' => 'php_content' === $type ? 'mixed' : $type,
		];

		foreach ( self::FLUENT_CONTEXT_KEYS as $key ) {
			if ( isset( $header[ $key ] ) && '' !== $header[ $key ] ) {
				$context[ $key ] = $header[ $key ];
			}
		}

		// The plugin writes the opening tag itself, so a PHP snippet's code is
		// stored without one; the reader should see what the author wrote.
		if ( 'php' === $type && 0 === strpos( $code, '<?php' ) ) {
			$code = trim( substr( $code, 5 ) );
		}

		return [
			'code'      => $code,
			'is_active' => 'published' === ( $header['status'] ?? '' ),
			'context'   => $context,
		];
	}
}
