<?php
/**
 * Generic post meta collector.
 *
 * Page builders keep per-page custom CSS and JS in post meta: Elementor,
 * Divi, Bricks, Oxygen and Beaver Builder all do, under their own keys.
 * Nothing here knows those keys. Every meta value on a real post is walked
 * and anything that looks like code is surfaced.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

/**
 * Collect code-looking values from wp_postmeta.
 */
class Post_Meta_Collector {

	/**
	 * Largest meta value that will be read.
	 */
	const MAX_BYTES = 4 * MB_IN_BYTES;

	/**
	 * Most posts whose meta is read, newest first.
	 */
	const MAX_POSTS = 2000;

	/**
	 * Most meta rows read across those posts.
	 */
	const MAX_ROWS = 5000;

	/**
	 * Meta keys that are never user code.
	 *
	 * @var array<int, string>
	 */
	const SKIP_PREFIXES = [ '_edit_', '_oembed_', '_wp_attachment', '_wp_attached', '_thumbnail_id', '_wp_old_', '_menu_item_', '_elementor_element_cache', '_elementor_css', '_elementor_page_assets' ];

	/**
	 * Post types whose meta is not worth reading.
	 *
	 * @var array<int, string>
	 */
	const SKIP_POST_TYPES = [ 'revision', 'attachment', 'nav_menu_item', 'customize_changeset', 'oembed_cache', 'user_request', 'snippet_revision' ];

	/**
	 * Run the collector.
	 *
	 * @return array<int, array<string, mixed>> Raw candidates.
	 */
	public function collect(): array {
		global $wpdb;

		// The newest posts are chosen first, in a bounded query of their own,
		// and only their meta is read: joining meta to posts and sorting the
		// join is what made this scan a full pass over wp_postmeta.
		$skip        = Post_Content_Collector::skipped_post_types();
		$skip_clause = $skip ? 'AND post_type NOT IN (' . implode( ',', array_fill( 0, count( $skip ), '%s' ) ) . ')' : '';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- one-off audit scan; every list and its placeholders are built from the same array, so the counts match.
		$posts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_type, post_title, post_status
				 FROM {$wpdb->posts}
				 WHERE post_status NOT IN ('trash', 'auto-draft', 'inherit')
				   $skip_clause
				 ORDER BY post_modified DESC
				 LIMIT %d",
				array_merge( $skip, [ self::MAX_POSTS ] )
			),
			ARRAY_A
		);

		if ( ! is_array( $posts ) || ! $posts ) {
			return [];
		}

		$by_id = array_column( $posts, null, 'ID' );

		// Housekeeping keys are excluded in the query, where it costs nothing,
		// rather than after they have used up the row budget.
		$not_like = [];
		$args     = array_map( 'intval', array_keys( $by_id ) );

		foreach ( self::SKIP_PREFIXES as $prefix ) {
			$not_like[] = 'AND meta_key NOT LIKE %s';
			$args[]     = $wpdb->esc_like( $prefix ) . '%';
		}

		$args = array_merge( $args, [ Code_Heuristic::MIN_LENGTH, self::MAX_BYTES, self::MAX_ROWS ] );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, meta_key, meta_value
				 FROM {$wpdb->postmeta}
				 WHERE post_id IN (" . implode( ',', array_fill( 0, count( $by_id ), '%d' ) ) . ')
				   ' . implode( ' ', $not_like ) . '
				   AND LENGTH(meta_value) BETWEEN %d AND %d
				 LIMIT %d',
				$args
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared

		if ( ! is_array( $rows ) ) {
			return [];
		}

		$candidates = [];

		foreach ( $rows as $row ) {
			$post  = $by_id[ $row['post_id'] ] ?? [
				'post_type' => 'post',
				'post_title' => '',
			];
			$value = Code_Heuristic::decode_stored( $row['meta_value'] );
			$base  = sprintf( 'postmeta:%s/%d/%s', $post['post_type'], $row['post_id'], $row['meta_key'] );
			$where = [
				'post_type'   => $post['post_type'],
				'post_title'  => mb_substr( (string) $post['post_title'], 0, 60 ),
				'post_id'     => (int) $row['post_id'],
				'post_status' => (string) ( $post['post_status'] ?? '' ),
				'meta_key'    => $row['meta_key'], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- a label, not a query.
			];

			foreach ( Code_Heuristic::flatten_with_context( $value, $base ) as $path => $entry ) {
				$string = Code_Heuristic::normalise( $entry['value'] );

				if ( Code_Heuristic::looks_like_code( $string ) ) {
					$candidates[] = [
						'code'        => $string,
						'source_path' => $path,
						'source_hint' => 'database/post-meta',
						'context'     => $entry['context'] + $where,
					];
				}
			}
		}

		return $candidates;
	}
}
