<?php
/**
 * Generic wp_options collector.
 *
 * Scans the options table for code-looking values without knowing any
 * particular plugin or theme-options framework. Whatever stored the code, if
 * it looks like code it is surfaced, and the interpreter works out what it is.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

/**
 * Collect code-looking values from wp_options.
 */
class Options_Collector {

	/**
	 * Largest option value that will be read.
	 *
	 * Builder and framework settings blobs can run to megabytes; the previous
	 * 200KB cap silently skipped exactly the options most likely to hold code.
	 */
	const MAX_BYTES = 4 * MB_IN_BYTES;

	/**
	 * Option name prefixes that are never user code.
	 *
	 * Code Snippets' own options hold settings and findings that quote code
	 * without being it. WPCode's wpcode_snippets option is its cache of the
	 * active snippets it keeps as posts, which are found as those posts.
	 *
	 * @var array<int, string>
	 */
	const SKIP_PREFIXES = [ '_transient', '_site_transient', 'cron', 'rewrite_rules', 'wp_user_roles', 'cs_discovery_', 'code_snippets_', 'code_snippets', 'wpcode_snippets' ];

	/**
	 * Run the collector.
	 *
	 * @return array<int, array<string, mixed>> Raw candidates.
	 */
	public function collect(): array {
		global $wpdb;

		$candidates = [];

		// Names that are never code are excluded in the query, where it costs nothing.
		$not_like = [];
		$args     = [ Code_Heuristic::MIN_LENGTH, self::MAX_BYTES ];

		foreach ( self::SKIP_PREFIXES as $prefix ) {
			$not_like[] = 'AND option_name NOT LIKE %s';
			$args[]     = $wpdb->esc_like( $prefix ) . '%';
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- one-off audit scan; the NOT LIKE terms and their placeholders are built from the same array, so the counts match.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT option_name, option_value FROM {$wpdb->options} WHERE LENGTH(option_value) BETWEEN %d AND %d " . implode( ' ', $not_like ),
				$args
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared

		if ( ! is_array( $rows ) ) {
			return [];
		}

		foreach ( $rows as $row ) {
			$name  = $row['option_name'];
			$value = Code_Heuristic::decode_stored( $row['option_value'] );

			foreach ( Code_Heuristic::flatten_with_context( $value, $name ) as $path => $entry ) {
				$string = Code_Heuristic::normalise( $entry['value'] );

				if ( Code_Heuristic::looks_like_code( $string ) ) {
					$candidates[] = [
						'code'        => $string,
						'source_path' => 'wp_options:' . $path,
						'source_hint' => 'database/option',
						'context'     => $entry['context'],
					];
				}
			}
		}

		return $candidates;
	}
}
