<?php
/**
 * Shared decisions about what "looks like code", and how to walk stored values.
 *
 * Every collector that reads the database uses this, so a signal added here
 * improves the options, post meta and post content scans together.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

/**
 * Heuristics and helpers shared between collectors.
 */
class Code_Heuristic {

	/**
	 * How many levels of nested arrays to descend.
	 *
	 * A builder's element tree nests section, column and widget, each with its
	 * own settings and elements, before a container adds more; a widget in
	 * Elementor sits seven levels down and a nested container deeper still.
	 */
	const MAX_DEPTH = 12;

	/**
	 * Most strings one stored value may flatten into.
	 *
	 * Depth alone does not bound a wide settings blob; every flattened entry is
	 * held until the scan finishes.
	 */
	const MAX_NODES = 20000;

	/**
	 * Strings flattened so far in the current top-level walk.
	 *
	 * @var int
	 */
	private static int $nodes = 0;

	/**
	 * Shortest value worth considering.
	 */
	const MIN_LENGTH = 12;

	/**
	 * Any one of these makes a value code.
	 *
	 * @var array<int, string>
	 */
	const STRONG_SIGNALS = [
		'<?php',
		'<script',
		'add_action(',
		'add_filter(',
		'gtag(',
		'dataLayer',
		'fbq(',
		'_paq.push',
		'ga(',
		'addEventListener(',
		'@media',
		'!important',
	];

	/**
	 * Any one of these patterns makes a value code.
	 *
	 * A CSS declaration block preceded by a selector: something like
	 * ".hero h1 { margin: 0; }". A bare JSON object has nothing before its
	 * brace, so "{"enabled":true}" does not match.
	 *
	 * @var array<int, string>
	 */
	const STRONG_PATTERNS = [
		'/[\w\]\)\-\*"\']\s*\{[^{}]*:[^{}]*\}/',
		// A method call on a browser global, e.g. console.log(...) or
		// document.getElementById(...). Bare statements like these are how
		// WPCode and similar plugins store JS: no tag, no framework call.
		'/\\b(?:console|window|document|jQuery|localStorage|sessionStorage|navigator|location|history)\\s*\\.\\s*\\w+\\s*\\(/',
	];

	/**
	 * Two or more of these together make a value code.
	 *
	 * Patterns rather than substrings, so "close the window. Save the
	 * document." in prose does not count while window.location does.
	 *
	 * @var array<int, string>
	 */
	const WEAK_SIGNALS = [
		'/\bfunction\s*\(|\bfunction\s+\w+\s*\(/',
		'/<\/\w+>/',
		'/\{[^}]*:[^}]*\}/',
		'/\bwindow\.\w+/',
		'/\bdocument\.\w+/',
		'/\bjQuery\s*\(|\$\s*\(/',
		'/\bvar\s+\w+\s*=|\blet\s+\w+\s*=|\bconst\s+\w+\s*=/',
		'/;\s*$/m',
	];

	/**
	 * Reveal code that a builder stored encoded.
	 *
	 * Divi percent-encodes the body of its Code module, and exports of it use
	 * HTML entities, so "<script>" is stored as "%3Cscript%3E" or "&lt;script&gt;".
	 * Decoding is only kept when it uncovers a script, style or PHP tag that
	 * the raw value did not have, so ordinary prose with a stray "%3C" or an
	 * entity in it is left exactly as it was.
	 *
	 * @param string $value Stored value.
	 *
	 * @return string The value, decoded when that reveals code.
	 */
	public static function normalise( string $value ): string {
		$reveals = '/<(?:script|style|\\?php)\\b/i';

		if ( preg_match( $reveals, $value ) ) {
			return $value;
		}

		$decoded = html_entity_decode( rawurldecode( $value ), ENT_QUOTES | ENT_HTML5 );

		return $decoded !== $value && preg_match( $reveals, $decoded ) ? $decoded : $value;
	}

	/**
	 * Whether a string contains custom code rather than settings or prose.
	 *
	 * @param string $value Candidate string.
	 *
	 * @return bool
	 */
	public static function looks_like_code( string $value ): bool {
		// Block delimiters are HTML comments carrying JSON attributes, and
		// '{"align":"center"}' looks exactly like a CSS declaration block.
		// Every block-editor post was being flagged as code because of them.
		$value = (string) preg_replace( '/<!--.*?-->/s', '', $value );

		if ( strlen( $value ) < self::MIN_LENGTH ) {
			return false;
		}

		foreach ( self::STRONG_SIGNALS as $signal ) {
			if ( false !== strpos( $value, $signal ) ) {
				return true;
			}
		}

		foreach ( self::STRONG_PATTERNS as $pattern ) {
			if ( preg_match( $pattern, $value ) ) {
				return true;
			}
		}

		$hits = 0;

		foreach ( self::WEAK_SIGNALS as $pattern ) {
			if ( preg_match( $pattern, $value ) ) {
				++$hits;

				if ( $hits >= 2 ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Turn a stored value into something walkable.
	 *
	 * Serialised arrays are unserialised without instantiating anything; JSON
	 * documents (Elementor's element tree, block attributes, theme.json) are
	 * decoded so their strings are reached individually instead of matching
	 * the whole document as one blob.
	 *
	 * @param string $value Raw stored value.
	 *
	 * @return mixed
	 */
	public static function decode_stored( string $value ) {
		if ( is_serialized( $value ) ) {
			return self::unserialize_safely( $value );
		}

		$trimmed = ltrim( $value );

		if ( '' !== $trimmed && ( '{' === $trimmed[0] || '[' === $trimmed[0] ) ) {
			$decoded = json_decode( $value, true );

			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}

		return $value;
	}

	/**
	 * Whether a script is only data: one assignment of an object or array literal.
	 *
	 * That is the shape of wp_localize_script() output and of the configuration
	 * objects builders print for their front-end scripts.
	 *
	 * @param string $code Script contents.
	 *
	 * @return bool
	 */
	public static function is_data_literal( string $code ): bool {
		$code = (string) preg_replace( '#/\*\s*<!\[CDATA\[\s*\*/|/\*\s*\]\]>\s*\*/|^\s*<!--|-->\s*$#', '', $code );
		// WordPress appends "//# sourceURL=" to inline scripts.
		$code = trim( (string) preg_replace( '#^\s*//[^\n]*$#m', '', $code ) );

		if ( '' === $code ) {
			return true;
		}

		if ( preg_match( '/^(?:var|let|const)?\s*[\w.$]+\s*=\s*([\[{].*[\]}])\s*;?$/s', $code, $m ) ) {
			return null !== json_decode( $m[1] );
		}

		return ( '{' === $code[0] || '[' === $code[0] ) && null !== json_decode( $code );
	}

	/**
	 * Remove a single script or style tag wrapped around the whole value.
	 *
	 * @param string $code Code.
	 *
	 * @return string
	 */
	public static function strip_enclosing_tag( string $code ): string {
		$code = trim( $code );

		return preg_match( '#^<(script|style)\b[^>]*>(.*)</\1>$#is', $code, $m ) ? trim( $m[2] ) : $code;
	}

	/**
	 * Reduce code to a form in which the same code compares equal however it was stored.
	 *
	 * Whitespace, comments and a single enclosing script or style tag are
	 * dropped, and the optional semicolon before a closing brace, so a value
	 * held with tags in an option, printed bare on a page, and minified into a
	 * generated stylesheet all match.
	 *
	 * @param string $code Code.
	 *
	 * @return string
	 */
	public static function normalise_for_match( string $code ): string {
		$code = (string) preg_replace( '#/\*.*?\*/|<!--.*?-->#s', '', self::strip_enclosing_tag( $code ) );
		$code = (string) preg_replace( '/\s+/', '', $code );

		return str_replace( ';}', '}', $code );
	}

	/**
	 * Normalise code for deciding that two stored copies are the same snippet.
	 *
	 * Stricter than the match form: comments stay. Dropping them is right
	 * when asking whether a printed copy came from a stored one, but two
	 * snippets that differ only in the HTML comment they echo are two
	 * snippets, and the match form would fold them into one.
	 *
	 * @param string $code Code.
	 *
	 * @return string
	 */
	public static function normalise_for_identity( string $code ): string {
		// One manager stores PHP with its opening tag and another without; the
		// snippet is the same either way.
		$code = (string) preg_replace( '/\A\s*<\?(?:php)?\b|\?>\s*\z/i', '', self::strip_enclosing_tag( $code ) );

		return (string) preg_replace( '/\s+/', '', $code );
	}

	/**
	 * Unserialise a stored value without instantiating any class.
	 *
	 * @param string $value Raw stored value.
	 *
	 * @return mixed
	 */
	public static function unserialize_safely( string $value ) {
		if ( ! is_serialized( $value ) ) {
			return $value;
		}

		// allowed_classes is false, so nothing is instantiated. The notice a
		// corrupt value would raise is silenced for the same reason core's own
		// maybe_unserialize() silences it: one bad row must not abort a scan of
		// every row, and unserialize() offers no quieter way to report failure.
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize, WordPress.PHP.NoSilencedErrors.Discouraged
		return @unserialize( trim( $value ), [ 'allowed_classes' => false ] );
	}

	/**
	 * Flatten a stored value into path => string pairs, descending nested arrays.
	 *
	 * @param mixed  $value Stored value.
	 * @param string $path  Path so far.
	 * @param int    $depth Current depth.
	 *
	 * @return array<string, string>
	 */
	public static function flatten( $value, string $path, int $depth = 0 ): array {
		return array_map(
			static fn( array $entry ): string => $entry['value'],
			self::flatten_with_context( $value, $path, $depth )
		);
	}

	/**
	 * Flatten a stored value, keeping the short scalars that sat beside each string.
	 *
	 * A builder stores "executeCode": true next to the code it applies to, or
	 * "widgetType": "html" one level up. Those neighbours say what the code is
	 * far more reliably than the code alone, so they travel with it.
	 *
	 * @param mixed                $value     Stored value.
	 * @param string               $path      Path so far.
	 * @param int                  $depth     Current depth.
	 * @param array<string, mixed> $inherited Scalars from the enclosing array.
	 *
	 * @return array<string, array{value: string, context: array<string, mixed>}>
	 */
	public static function flatten_with_context( $value, string $path, int $depth = 0, array $inherited = [] ): array {
		if ( 0 === $depth ) {
			self::$nodes = 0;
		}

		if ( is_string( $value ) ) {
			++self::$nodes;

			if ( self::$nodes > self::MAX_NODES ) {
				return [];
			}

			return [
				$path => [
					'value'   => $value,
					'context' => $inherited,
				],
			];
		}

		if ( is_object( $value ) ) {
			// Builders such as Beaver Builder store trees of stdClass. The safe
			// unserialiser never instantiates them, so they arrive as
			// __PHP_Incomplete_Class; a cast exposes the properties without
			// running anything.
			$value = (array) $value;
			unset( $value['__PHP_Incomplete_Class_Name'] );
		}

		if ( ! is_array( $value ) || $depth >= self::MAX_DEPTH ) {
			return [];
		}

		$scalars = self::short_scalars( $value );
		$out     = [];

		foreach ( $value as $key => $sub ) {
			// Property names of cast objects can carry NUL-delimited visibility markers.
			$key     = str_replace( "\0", '', (string) $key );
			$context = array_slice( $inherited + array_diff_key( $scalars, [ $key => true ] ), 0, 12, true );
			// A key holding "/" can spell the same path as a nested key; neither
			// value may be lost, so a colliding path is numbered.
			foreach ( self::flatten_with_context( $sub, $path . '/' . $key, $depth + 1, $context ) as $child_path => $entry ) {
				$unique = $child_path;
				$n      = 1;

				while ( isset( $out[ $unique ] ) ) {
					$unique = $child_path . '#' . ( ++$n );
				}

				$out[ $unique ] = $entry;
			}
		}

		return $out;
	}

	/**
	 * The scalar members of an array that are short enough to be labels rather than content.
	 *
	 * @param array<mixed> $value Array.
	 *
	 * @return array<string, mixed>
	 */
	private static function short_scalars( array $value ): array {
		$out = [];

		foreach ( $value as $key => $member ) {
			if ( is_bool( $member ) || is_int( $member ) || is_float( $member ) ) {
				$out[ str_replace( "\0", '', (string) $key ) ] = $member;
			} elseif ( is_string( $member ) && strlen( $member ) <= 60 && '' !== trim( $member ) ) {
				$out[ str_replace( "\0", '', (string) $key ) ] = trim( $member );
			}
		}

		return $out;
	}

	/**
	 * Largest file a collector reads whole.
	 */
	const MAX_FILE_BYTES = 2 * MB_IN_BYTES;

	/**
	 * Read a file into memory, unless it is too large or unreadable.
	 *
	 * Every candidate stays in memory until the scan finishes, so one bundled
	 * or generated file must not be allowed to take the request down.
	 *
	 * @param string $path File.
	 *
	 * @return string|null Contents, or null when the file is not read.
	 */
	public static function read_file( string $path ): ?string {
		if ( ! is_file( $path ) || ! is_readable( $path ) || filesize( $path ) > self::MAX_FILE_BYTES ) {
			return null;
		}

		$contents = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		return is_string( $contents ) ? $contents : null;
	}

	/**
	 * Recursively find PHP files under a directory, skipping dependency folders.
	 *
	 * @param string $dir       Directory to walk.
	 * @param int    $max_depth How deep to go.
	 *
	 * @return array<int, string> Absolute paths.
	 */
	public static function find_php_files( string $dir, int $max_depth = 3 ): array {
		if ( ! is_dir( $dir ) ) {
			return [];
		}

		$files    = [];
		$iterator = new \RecursiveIteratorIterator(
			new \RecursiveCallbackFilterIterator(
				new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
				static function ( \SplFileInfo $file ): bool {
					return ! ( $file->isDir() && in_array( $file->getFilename(), [ 'vendor', 'node_modules', '.git' ], true ) );
				}
			)
		);
		$iterator->setMaxDepth( $max_depth );

		foreach ( $iterator as $file ) {
			if ( $file->isFile() && 'php' === strtolower( $file->getExtension() ) ) {
				$files[] = $file->getPathname();
			}
		}

		sort( $files );

		return $files;
	}
}
