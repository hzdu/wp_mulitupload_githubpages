<?php
/**
 * Generic filesystem collector: mu-plugins, .htaccess and wp-config.
 *
 * Source-agnostic file reads. It does not know what put the code there; it
 * surfaces code-bearing files and leaves identification to the interpreter.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

use Code_Snippets\UnifiedDiscovery\Local_Interpretation;

/**
 * Collect code from mu-plugins, .htaccess and wp-config.
 */
class Filesystem_Collector {

	/**
	 * Run the collector.
	 *
	 * @return array<int, array<string, mixed>> Raw candidates.
	 */
	public function collect(): array {
		$candidates = [];

		// mu-plugins: top-level files are auto-loaded, and they almost always
		// require a subdirectory holding the real code, so the whole tree is read.
		$mu_dir = defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins';

		if ( is_dir( $mu_dir ) ) {
			foreach ( Code_Heuristic::find_php_files( $mu_dir ) as $file ) {
				$code = Code_Heuristic::read_file( $file );

				if ( is_string( $code ) && '' !== trim( $code ) ) {
					$candidates[] = self::mu_plugin_candidate( $file, $code );
				}
			}
		}

		// .htaccess is server configuration and can never become a snippet, so it
		// is surfaced for information only and never sent to the interpreter: it
		// routinely carries IP allowlists, protected paths and redirect structure.
		$htaccess = ABSPATH . '.htaccess';

		if ( is_readable( $htaccess ) ) {
			$code = Code_Heuristic::read_file( $htaccess );

			if ( is_string( $code ) && '' !== trim( $code ) ) {
				$candidates[] = [
					'code'          => $code,
					'source_path'   => $htaccess,
					'source_hint'   => 'server/htaccess',
					'send_to_model' => false,
					'local'         => [
						'name'          => '.htaccess',
						'type'          => 'config',
						'source_type'   => 'server',
						'source_name'   => 'Server configuration (.htaccess)',
						'is_importable' => false,
						'import_scope'  => '',
						'risk_level'    => 'high',
						'confidence'    => 1.0,
					],
				];
			}
		}

		// wp-config.php: custom code does turn up here, so it is worth
		// interpreting, but every defined value is replaced first. Redacting by
		// constant name was the previous approach, and it only knew WordPress's
		// own constants, so any third-party key defined here went out in clear.
		$wp_config = ABSPATH . 'wp-config.php';

		if ( is_readable( $wp_config ) ) {
			$raw = Code_Heuristic::read_file( $wp_config );

			if ( is_string( $raw ) ) {
				$code = self::redact_wp_config( $raw );

				if ( '' !== $code ) {
					$candidates[] = [
						'code'        => $code,
						'source_path' => $wp_config,
						'source_hint' => 'server/wp-config (values redacted)',
					];
				}
			}
		}

		return $candidates;
	}

	/**
	 * Build the candidate for one must-use plugin file.
	 *
	 * A file that loads others or works out paths from its own location means
	 * something different once its code is moved into a snippet, so it is listed
	 * for information only and is not sent to the interpreter.
	 *
	 * @param string $file Path to the file.
	 * @param string $code Contents of the file.
	 *
	 * @return array<string, mixed>
	 */
	public static function mu_plugin_candidate( string $file, string $code ): array {
		$title = preg_match( '/^[\s\/*#@]*Plugin Name:(.*)$/mi', $code, $matches ) ? _cleanup_header_comment( $matches[1] ) : '';

		$candidate = [
			'code'        => $code,
			'source_path' => $file,
			'source_hint' => 'mu-plugin',
			'context'     => [ 'title' => '' !== $title ? $title : basename( $file ) ],
		];

		if ( preg_match( '/\b(?:__DIR__|__FILE__|(?:require|include)(?:_once)?)\b/i', $code ) ) {
			$local = Local_Interpretation::for_candidate( $candidate );

			$local['is_importable'] = false;
			$local['import_scope'] = '';
			$local['import_notes'] = __( 'Loads other files or relies on where it is installed, so it cannot run as a snippet.', 'code-snippets' );

			$candidate['send_to_model'] = false;
			$candidate['local'] = $local;
		}

		return $candidate;
	}

	/**
	 * Replace every literal in wp-config with a placeholder.
	 *
	 * The tokenizer, not a pattern, decides what a literal is: every string,
	 * heredoc body and number is replaced, wherever it appears, so a key
	 * assigned to a variable is as safe as one passed to define(). Only the
	 * name a define() gives its constant is kept, so the interpreter can still
	 * tell what the file configures.
	 *
	 * @param string $raw Contents of wp-config.php.
	 *
	 * @return string Redacted contents.
	 */
	public static function redact_wp_config( string $raw ): string {
		// Without an opening tag the tokenizer sees inline HTML and nothing
		// would be redacted, so a fragment is tokenised as PHP.
		$fragment = false === strpos( $raw, '<?php' );
		$source   = $fragment ? '<?php ' . $raw : $raw;

		$out       = '';
		$in_define = false;
		$depth     = 0;
		$argument  = 0;

		foreach ( token_get_all( $source ) as $token ) {
			if ( is_string( $token ) ) {
				if ( $in_define ) {
					if ( '(' === $token ) {
						++$depth;
					} elseif ( ')' === $token ) {
						--$depth;
						$in_define = $depth > 0;
					} elseif ( ',' === $token && 1 === $depth ) {
						++$argument;
					}
				}

				$out .= $token;
				continue;
			}

			list( $id, $text ) = $token;

			if ( T_STRING === $id && 'define' === strtolower( $text ) ) {
				$in_define = true;
				$depth     = 0;
				$argument  = 0;
				$out      .= $text;
				continue;
			}

			$is_constant_name = $in_define && 1 === $depth && 0 === $argument && T_CONSTANT_ENCAPSED_STRING === $id;

			if ( ! $is_constant_name && ( T_CONSTANT_ENCAPSED_STRING === $id || T_ENCAPSED_AND_WHITESPACE === $id ) ) {
				$out .= "'[redacted]'";
				continue;
			}

			if ( T_LNUMBER === $id || T_DNUMBER === $id ) {
				$out .= '0';
				continue;
			}

			// A bare true, false or null given to define() is a value as well.
			if ( $in_define && $argument > 0 && T_STRING === $id && in_array( strtolower( $text ), [ 'true', 'false', 'null' ], true ) ) {
				$out .= "'[redacted]'";
				continue;
			}

			$out .= $text;
		}

		return trim( $fragment ? substr( $out, strlen( '<?php ' ) ) : $out );
	}
}
