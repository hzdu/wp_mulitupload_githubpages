<?php
/**
 * Generic custom-table collector.
 *
 * Some plugins keep their code in a table of their own rather than in
 * wp_options or a post type. A rendered page shows that code only while the
 * plugin is active; the table keeps it either way. Every non-core table under
 * the site's prefix is read, newest rows first, and anything in a text column
 * that looks like code is surfaced with the row's labels beside it.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

/**
 * Collect code-looking values from tables WordPress did not create.
 */
class Custom_Tables_Collector {

	/**
	 * Most rows read from any one table, newest first.
	 */
	const MAX_ROWS = 200;

	/**
	 * Most tables inspected.
	 */
	const MAX_TABLES = 150;

	/**
	 * Longest cell read.
	 */
	const MAX_CELL_BYTES = 256 * KB_IN_BYTES;

	/**
	 * Most bytes inspected in any one table.
	 */
	const MAX_TABLE_BYTES = 2 * MB_IN_BYTES;

	/**
	 * Snippet managers that keep code in a table of their own and record whether each row runs, keyed by table name
	 * without prefix: the row's key column, the column holding its state, and the values that mean on and off.
	 */
	const KNOWN_STATUS = [
		'hfcm_scripts'  => [
			'key'    => 'script_id',
			'column' => 'status',
			'on'     => 'active',
			'off'    => 'inactive',
		],
		'wpcb_snippets' => [
			'key'    => 'id',
			'column' => 'enabled',
			'on'     => '1',
			'off'    => '0',
		],
	];

	/**
	 * Tables, without prefix, that never hold user code.
	 *
	 * @var array<int, string>
	 */
	const SKIP_TABLES = [ 'snippets', 'ms_snippets', 'actionscheduler_actions', 'actionscheduler_claims', 'actionscheduler_groups', 'actionscheduler_logs' ];

	/**
	 * Table names, without prefix, that hold records rather than settings.
	 */
	const SKIP_NAME_PATTERN = '/(?:^|_)(?:logs?|sessions?|stats?|statistics|queue|cache|lookup|history|visits?|views|analytics|events|tracking|notifications?|transients?|audits?|snapshots?|revisions?|backups?|versions?|undo|conflicts?|archives?|trash)(?:_|$)/i';

	/**
	 * Run the collector.
	 *
	 * @return array<int, array<string, mixed>> Raw candidates.
	 */
	public function collect(): array {
		global $wpdb;

		$prefix = $wpdb->prefix;
		$core   = array_merge( $wpdb->tables( 'all', true ), $wpdb->tables( 'global', true ), $wpdb->tables( 'ms_global', true ) );
		$skip   = (array) apply_filters( 'code_snippets/discovery/skip_tables', self::SKIP_TABLES );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off audit scan.
		$tables     = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $prefix ) . '%' ) );
		$candidates = [];

		foreach ( array_slice( (array) $tables, 0, self::MAX_TABLES ) as $table ) {
			$table = (string) $table;
			$short = substr( $table, strlen( $prefix ) );

			if ( in_array( $table, $core, true ) || in_array( $short, $skip, true ) || preg_match( self::SKIP_NAME_PATTERN, $short ) ) {
				continue;
			}

			if ( is_multisite() && self::is_other_site_table( $table, $wpdb->base_prefix ) ) {
				continue;
			}

			if ( self::is_identifier( $table ) ) {
				$candidates = array_merge( $candidates, $this->scan_table( $table, $short ) );
			}
		}

		return $candidates;
	}

	/**
	 * Read the text columns of one table.
	 *
	 * Identifiers come from the server's own SHOW TABLES and SHOW COLUMNS and
	 * are checked against a strict character set before use, since they cannot
	 * be prepared as values.
	 *
	 * @param string $table Full table name.
	 * @param string $short Table name without the prefix.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function scan_table( string $table, string $short ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- identifier validated by is_identifier().
		$columns = $wpdb->get_results( "SHOW COLUMNS FROM `{$table}`", ARRAY_A );
		$text    = [];
		$labels  = [];
		$key     = '';

		foreach ( (array) $columns as $column ) {
			$field = (string) ( $column['Field'] ?? '' );
			$type  = strtolower( (string) ( $column['Type'] ?? '' ) );

			if ( ! self::is_identifier( $field ) ) {
				continue;
			}

			if ( '' === $key && 'PRI' === ( $column['Key'] ?? '' ) ) {
				$key = $field;
			}

			// A column named like a title is a label whatever its width: a
			// snippet manager's "title varchar(200)" names the row, it does
			// not hold code.
			$named_label = (bool) preg_match( '/^(?:title|name|label|slug)$/i', $field ) && 0 === strpos( $type, 'varchar' );

			if ( ! $named_label && ( preg_match( '/^(?:tiny|medium|long)?text\b/', $type ) || ( preg_match( '/^varchar\((\d+)\)/', $type, $m ) && (int) $m[1] >= 200 ) ) ) {
				$text[] = $field;
			} elseif ( preg_match( '/^(?:varchar|char|enum|tinyint|smallint|mediumint|int|bigint|datetime|timestamp|date)\b/', $type ) ) {
				$labels[] = $field;
			}
		}

		if ( ! $text ) {
			return [];
		}

		$status = self::KNOWN_STATUS[ $short ]['column'] ?? '';
		$labels = array_slice( array_unique( array_merge( '' !== $key ? [ $key ] : [], in_array( $status, $labels, true ) ? [ $status ] : [], $labels ) ), 0, 12 );
		$select = array_map( [ self::class, 'quote' ], $labels );

		foreach ( $text as $field ) {
			$select[] = sprintf( 'SUBSTRING(`%s`, 1, %d) AS `%s`', $field, self::MAX_CELL_BYTES, $field );
		}

		$sql = sprintf(
			'SELECT %s FROM `%s`%s LIMIT %d',
			implode( ', ', $select ),
			$table,
			'' !== $key ? " ORDER BY `{$key}` DESC" : '',
			self::MAX_ROWS
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- every identifier validated by is_identifier(); no values are interpolated.
		$rows       = $wpdb->get_results( $sql, ARRAY_A );
		$budget     = self::MAX_TABLE_BYTES;
		$candidates = [];

		foreach ( (array) $rows as $n => $row ) {
			$id      = '' !== $key ? (string) $row[ $key ] : (string) ( $n + 1 );
			$context = [ 'table' => $short ];

			foreach ( $labels as $label ) {
				$value = $row[ $label ] ?? null;

				if ( is_scalar( $value ) && '' !== trim( (string) $value ) && strlen( (string) $value ) <= 60 ) {
					$context[ $label ] = trim( (string) $value );
				}
			}

			foreach ( $text as $field ) {
				$value   = (string) ( $row[ $field ] ?? '' );
				$budget -= strlen( $value );

				if ( $budget < 0 ) {
					break 2;
				}

				if ( strlen( $value ) < Code_Heuristic::MIN_LENGTH ) {
					continue;
				}

				foreach ( Code_Heuristic::flatten_with_context( Code_Heuristic::decode_stored( $value ), sprintf( 'table:%s/%s/%s', $short, $id, $field ) ) as $path => $entry ) {
					$string = Code_Heuristic::normalise( $entry['value'] );

					if ( Code_Heuristic::looks_like_code( $string ) ) {
						$candidate = [
							'code'        => $string,
							'source_path' => $path,
							'source_hint' => sprintf( 'database/custom-table (%s)', $short ),
							'context'     => $entry['context'] + $context,
						];

						if ( '' !== $status && isset( $row[ $status ] ) ) {
							$candidate['is_active'] = self::KNOWN_STATUS[ $short ]['on'] === (string) $row[ $status ];
						}

						$candidates[] = $candidate;
					}
				}
			}
		}

		return $candidates;
	}

	/**
	 * Whether a name is safe to use as an SQL identifier.
	 *
	 * @param string $name Table or column name.
	 *
	 * @return bool
	 */
	public static function is_identifier( string $name ): bool {
		return (bool) preg_match( '/^[A-Za-z0-9_]{1,64}$/', $name );
	}

	/**
	 * Backtick-quote a validated identifier.
	 *
	 * @param string $name Identifier.
	 *
	 * @return string
	 */
	private static function quote( string $name ): string {
		return "`{$name}`";
	}

	/**
	 * Whether a table belongs to another site of a multisite network.
	 *
	 * On the main site the prefix is the base prefix, so "wp_%" also matches
	 * every other site's own tables (wp_2_posts, wp_2_options), which are not
	 * custom tables and are not this site's content.
	 *
	 * @param string $table       Full table name.
	 * @param string $base_prefix The network's base prefix.
	 *
	 * @return bool
	 */
	public static function is_other_site_table( string $table, string $base_prefix ): bool {
		return 1 === preg_match( '/^' . preg_quote( $base_prefix, '/' ) . '\d+_/', $table );
	}
}
