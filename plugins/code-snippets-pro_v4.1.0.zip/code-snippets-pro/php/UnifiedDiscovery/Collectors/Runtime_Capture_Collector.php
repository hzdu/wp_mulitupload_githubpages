<?php
/**
 * Runtime capture collector.
 *
 * Renders a small sample of templates, then extracts every inline
 * <script>/<style> each page actually emitted, and reads any stylesheet or
 * script the page links from the uploads directory, which is where builders
 * write their generated output. Source-agnostic: it catches code that no file
 * or database scan would reveal.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery\Collectors;

use Code_Snippets\UnifiedDiscovery\Runtime_Capture;
use Code_Snippets\UnifiedDiscovery\Runtime_Provenance;

/**
 * Collect inline and generated code from rendered pages.
 */
class Runtime_Capture_Collector {

	/**
	 * Largest linked asset that will be read from disk.
	 */
	const MAX_ASSET_BYTES = 2 * MB_IN_BYTES;

	/**
	 * Seconds to wait for each render.
	 */
	const TIMEOUT = 5;

	/**
	 * Whether this run's loopback was refused, so no further one is attempted.
	 *
	 * @var bool
	 */
	private bool $loopback_refused = false;

	/**
	 * URLs to render, one per template that commonly carries different code.
	 *
	 * Filter code_snippets/discovery/capture_urls to change the sample.
	 *
	 * @return array<string, string> Label => URL.
	 */
	public static function get_sample_urls(): array {
		$urls = [ 'home' => home_url( '/' ) ];

		$post = get_posts(
            [
				'post_type' => 'post',
				'post_status' => 'publish',
				'numberposts' => 1,
				'fields' => 'ids',
			]
        );
		$page = get_posts(
            [
				'post_type' => 'page',
				'post_status' => 'publish',
				'numberposts' => 1,
				'fields' => 'ids',
			]
        );

		if ( $post ) {
			$urls['single'] = (string) get_permalink( $post[0] );
		}

		if ( $page ) {
			$urls['page'] = (string) get_permalink( $page[0] );
		}

		$terms = get_terms(
            [
				'taxonomy' => 'category',
				'number' => 1,
				'hide_empty' => true,
				'fields' => 'ids',
			]
        );

		if ( is_array( $terms ) && $terms ) {
			$link = get_term_link( (int) $terms[0], 'category' );

			if ( is_string( $link ) ) {
				$urls['archive'] = $link;
			}
		}

		$urls['404'] = home_url( '/code-snippets-discovery-404-probe/' );

		return (array) apply_filters( 'code_snippets/discovery/capture_urls', $urls );
	}

	/**
	 * Run the collector.
	 *
	 * @return array<int, array<string, mixed>> Raw candidates.
	 */
	public function collect(): array {
		$candidates = [];
		$seen       = [];

		foreach ( self::get_sample_urls() as $label => $url ) {
			$html = $this->render( $url, (string) $label );

			if ( null === $html ) {
				continue;
			}

			foreach ( self::extract_inline( $html ) as $block ) {
				$callback = $block['context']['callback'] ?? '';
				$key      = '' !== $callback ? 'callback:' . ( $block['context']['hook'] ?? '' ) . '|' . $callback : 'block:' . md5( $block['code'] );
				$location = 'runtime:' . $label . ':' . $url . '#' . self::block_id( $block );

				if ( isset( $seen[ $key ] ) ) {
					$candidates[ $seen[ $key ] ]['also_found_at'][] = $location;
					continue;
				}

				$seen[ $key ]  = count( $candidates );
				$candidates[] = [
					'code'          => $block['code'],
					'source_path'   => $location,
					'source_hint'   => sprintf( 'runtime/rendered %s (%s actually emitted on the page)', $label, $block['kind'] ),
					'context'       => $block['context'],
					'also_found_at' => [],
				];
			}

			foreach ( self::extract_local_assets( $html ) as $asset ) {
				$key = 'asset:' . md5( $asset['path'] );

				if ( isset( $seen[ $key ] ) ) {
					continue;
				}

				$seen[ $key ]  = true;
				$candidates[] = [
					'code'        => $asset['code'],
					'source_path' => 'runtime-asset:' . $asset['path'],
					'source_hint' => sprintf( 'runtime/generated %s file linked from the %s page', $asset['kind'], $label ),
				];
			}
		}

		return $candidates;
	}

	/**
	 * Render one URL through an authorised capture and return its HTML.
	 *
	 * Hosts commonly refuse loopback requests, so the HTML can be supplied
	 * instead through the code_snippets/discovery/rendered_html filter. That is
	 * how a browser-driven capture, where the administrator's own browser
	 * visits each sample URL, hands its result to the collector.
	 *
	 * @param string $url   URL to render.
	 * @param string $label Sample label, such as home or single.
	 *
	 * @return string|null HTML, or null when the loopback was refused.
	 */
	private function render( string $url, string $label ): ?string {
		$supplied = apply_filters( 'code_snippets/discovery/rendered_html', null, $url, $label );

		if ( is_string( $supplied ) ) {
			return $supplied;
		}

		// The first refused loopback means they will all be refused, but a
		// later page may still be supplied through the filter.
		if ( $this->loopback_refused ) {
			return null;
		}

		delete_transient( Runtime_Capture::TRANSIENT );

		$response = wp_remote_get(
			add_query_arg( Runtime_Capture::FLAG, Runtime_Capture::arm(), $url ),
			[
				'timeout'   => self::TIMEOUT,
				'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
				'blocking'  => true,
			]
		);

		// A firewall or proxy answers a refused loopback with a status, not a
		// transport error, and one refusal means every sample would be refused.
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			$this->loopback_refused = true;
			return null;
		}

		$data = get_transient( Runtime_Capture::TRANSIENT );
		delete_transient( Runtime_Capture::TRANSIENT );

		return is_array( $data ) && ! empty( $data['html'] ) ? (string) $data['html'] : '';
	}

	/**
	 * Origins whose inline output is never a discovery.
	 *
	 * Core's own, the Customizer's (read from the database by the theme
	 * collector), pure data, and this plugin's.
	 *
	 * @var array<int, string>
	 */
	const SKIP_ORIGINS = [ 'core', 'customizer', 'data', 'code-snippets' ];

	/**
	 * Script types that hold runnable code.
	 *
	 * @var array<int, string>
	 */
	const SCRIPT_TYPES = [ '', 'text/javascript', 'application/javascript', 'module' ];

	/**
	 * Pull inline <script> (no src) and <style> blocks out of rendered HTML.
	 *
	 * When the page carries provenance, tags that core, the Customizer or
	 * this plugin printed are left out, and every other block says who
	 * printed it. Everything one hook callback echoed is returned as one
	 * block, since that is one piece of code from one owner however many tags
	 * it spans. Without provenance, as for markup read from a file, every
	 * block is kept on its own.
	 *
	 * @param string $html Rendered page or markup.
	 *
	 * @return array<int, array{code: string, kind: string, context: array<string, string>}>
	 */
	public static function extract_inline( string $html ): array {
		$provenance = Runtime_Provenance::extract( $html );
		$manifest   = $provenance['manifest'];
		$html       = $provenance['html'];
		$ranges     = Runtime_Provenance::marked_ranges( $html );
		$blocks     = [];
		$grouped    = [];
		$seen       = [];

		foreach ( [
			'js' => '#<script\b([^>]*)>(.*?)</script>#is',
			'css' => '#<style\b([^>]*)>(.*?)</style>#is',
		] as $kind => $pattern ) {
			if ( ! preg_match_all( $pattern, $html, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
				continue;
			}

			foreach ( $matches as $match ) {
				$attributes = self::parse_attributes( $match[1][0] );
				$code       = trim( $match[2][0] );
				$key        = md5( $code );

				if ( isset( $attributes['src'] ) || strlen( $code ) <= 12 || isset( $seen[ $key ] ) ) {
					continue;
				}

				if ( 'js' === $kind && ! in_array( strtolower( trim( $attributes['type'] ?? '' ) ), self::SCRIPT_TYPES, true ) ) {
					continue;
				}

				$origin = Runtime_Provenance::origin_of_tag( $attributes, $manifest );
				$range  = Runtime_Provenance::range_at( $ranges, (int) $match[0][1] );

				// A handle or a print-site attribute is the more specific
				// evidence; the enclosing callback covers everything else.
				if ( 'unknown' === $origin['origin'] && '' === $origin['handle'] && $range ) {
					$origin['origin'] = $range['origin'];
				}

				if ( in_array( $origin['origin'], self::SKIP_ORIGINS, true ) ) {
					continue;
				}

				if ( 'js' === $kind && Code_Heuristic::is_data_literal( $code ) ) {
					continue;
				}

				$seen[ $key ] = true;
				$context      = [ 'printed_by' => $origin['origin'] ];

				if ( 'unknown' === $origin['origin'] ) {
					$context['printed_by'] = '' !== $origin['handle'] ? 'handle ' . $origin['handle'] . ', owner unknown' : 'direct output, no registered handle';
				}

				if ( '' !== $origin['handle'] ) {
					$context['handle'] = $origin['handle'] . ( '' !== $origin['position'] ? ' (' . $origin['position'] . ')' : '' );
					$blocks[]          = [
						'code'    => $code,
						'kind'    => $kind,
						'context' => $context,
					];
					continue;
				}

				if ( $range ) {
					$group = $range['hook'] . '|' . $range['callback'];

					if ( ! isset( $grouped[ $group ] ) ) {
						$context['hook']     = $range['hook'];
						$context['callback'] = $range['callback'];
						$grouped[ $group ]   = [
							'code'    => $code,
							'kind'    => $kind,
							'context' => $context,
						];
					} else {
						$grouped[ $group ]['code'] .= "\n\n" . $code;

						if ( $grouped[ $group ]['kind'] !== $kind ) {
							$grouped[ $group ]['kind'] = 'mixed';
						}
					}

					continue;
				}

				$blocks[] = [
					'code'    => $code,
					'kind'    => $kind,
					'context' => $context,
				];
			}
		}

		foreach ( $grouped as $group ) {
			$blocks[] = $group;
		}

		return $blocks;
	}

	/**
	 * What identifies a block within a page, so the same page can hold many.
	 *
	 * The callback or handle that printed it is a stable identity across
	 * scans; output nobody claimed is identified by its content, so a change
	 * to it reads as one block gone and another arrived.
	 *
	 * @param array{code: string, kind: string, context: array<string, string>} $block Extracted block.
	 *
	 * @return string
	 */
	public static function block_id( array $block ): string {
		$context = $block['context'];

		if ( ! empty( $context['callback'] ) ) {
			return ( $context['hook'] ?? '' ) . '/' . $context['callback'];
		}

		if ( ! empty( $context['handle'] ) ) {
			return 'handle:' . strtok( (string) $context['handle'], ' ' );
		}

		return 'block:' . substr( md5( $block['code'] ), 0, 8 );
	}

	/**
	 * Parse the attributes of one opening tag.
	 *
	 * @param string $attribute_string Everything between the tag name and ">".
	 *
	 * @return array<string, string> Lower-cased attribute names.
	 */
	public static function parse_attributes( string $attribute_string ): array {
		$attributes = [];

		if ( preg_match_all( '/([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'>]+)))?/', $attribute_string, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $attribute ) {
				// With PREG_SET_ORDER an unmatched group is "", not unset, so the
				// value is the first group that actually matched.
				$value = '';

				foreach ( [ 2, 3, 4 ] as $group ) {
					if ( isset( $attribute[ $group ] ) && '' !== $attribute[ $group ] ) {
						$value = $attribute[ $group ];
						break;
					}
				}

				$attributes[ strtolower( $attribute[1] ) ] = $value;
			}
		}

		return $attributes;
	}

	/**
	 * Read stylesheets and scripts the page links from generated locations.
	 *
	 * Generated output lives under wp-content, but not only in uploads: Divi
	 * writes to et-cache, caching plugins to cache, and Code Snippets itself to
	 * code-snippets. Anything linked from under wp-content is read from disk,
	 * except shipped code in plugins, mu-plugins and themes, and our own output,
	 * which is already managed. Nothing is fetched over HTTP.
	 *
	 * @param string $html Rendered page.
	 *
	 * @return array<int, array{code: string, kind: string, path: string}>
	 */
	public static function extract_local_assets( string $html ): array {
		$content_url = set_url_scheme( rtrim( content_url(), '/' ), 'http' );
		$content_dir = rtrim( wp_normalize_path( WP_CONTENT_DIR ), '/' );
		$bases       = [];

		if ( '' !== $content_url && '' !== $content_dir ) {
			$bases[] = [ $content_url, $content_dir, true ];
		}

		// Uploads can be relocated outside wp-content; cover that base too.
		$uploads    = wp_upload_dir( null, false );
		$upload_url = set_url_scheme( rtrim( (string) ( $uploads['baseurl'] ?? '' ), '/' ), 'http' );
		$upload_dir = rtrim( wp_normalize_path( (string) ( $uploads['basedir'] ?? '' ) ), '/' );

		if ( '' !== $upload_url && '' !== $upload_dir && 0 !== strpos( $upload_url, $content_url . '/' ) ) {
			$bases[] = [ $upload_url, $upload_dir, false ];
		}

		$found = [];

		if ( preg_match_all( '#<link\b[^>]*\bhref=["\']([^"\']+\.css)(?:\?[^"\']*)?["\'][^>]*>#i', $html, $m ) ) {
			foreach ( $m[1] as $href ) {
				$found[] = [ $href, 'css' ];
			}
		}

		if ( preg_match_all( '#<script\b[^>]*\bsrc=["\']([^"\']+\.js)(?:\?[^"\']*)?["\']#i', $html, $m ) ) {
			foreach ( $m[1] as $src ) {
				$found[] = [ $src, 'js' ];
			}
		}

		$out = [];

		foreach ( $found as list( $url, $kind ) ) {
			// Caching and CDN plugins commonly link assets root-relative.
			if ( 0 === strpos( $url, '/' ) && 0 !== strpos( $url, '//' ) ) {
				$url = site_url( $url );
			}

			$url = set_url_scheme( $url, 'http' );

			foreach ( $bases as list( $base_url, $base_dir, $apply_rules ) ) {
				if ( 0 !== strpos( $url, $base_url . '/' ) ) {
					continue;
				}

				$relative = ltrim( substr( $url, strlen( $base_url ) ), '/' );

				if ( $apply_rules && ! self::is_generated_asset_path( $relative ) ) {
					continue 2;
				}

				$path = wp_normalize_path( $base_dir . '/' . $relative );

				// Stay inside the base even if the link tries to walk out of it.
				if ( false !== strpos( $relative, '..' ) || 0 !== strpos( $path, $base_dir . '/' ) || ! is_file( $path ) ) {
					continue 2;
				}

				if ( filesize( $path ) > self::MAX_ASSET_BYTES ) {
					continue 2;
				}

				$code = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions

				if ( is_string( $code ) && '' !== trim( $code ) ) {
					$out[] = [
						'code' => $code,
						'kind' => $kind,
						'path' => $path,
					];
				}

				continue 2;
			}
		}

		return $out;
	}

	/**
	 * Whether a path under wp-content is generated output worth reading.
	 *
	 * Shipped code in plugins, mu-plugins and themes is not custom code hiding
	 * anywhere, and Code Snippets' own output is already managed.
	 *
	 * @param string $relative Path relative to wp-content.
	 *
	 * @return bool
	 */
	public static function is_generated_asset_path( string $relative ): bool {
		$relative = ltrim( wp_normalize_path( $relative ), '/' );

		if ( false !== strpos( $relative, '..' ) ) {
			return false;
		}

		foreach ( [ 'plugins/', 'mu-plugins/', 'themes/', 'code-snippets/' ] as $shipped ) {
			if ( 0 === strpos( $relative, $shipped ) ) {
				return false;
			}
		}

		return (bool) preg_match( '/\.(css|js)$/i', $relative );
	}
}
