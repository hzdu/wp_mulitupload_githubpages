<?php
/**
 * Warn when an imported snippet runs alongside the code it was imported from.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\Admin\Notice_Filter;
use function Code_Snippets\code_snippets;

/**
 * Admin notice on Code Snippets screens listing imported snippets whose original still runs.
 *
 * One such snippet links straight to its original; several link to Unified
 * Snippets, filtered to them, where each has its own link.
 */
class Running_Twice_Notice {

	/**
	 * Filter on the Unified Snippets page that lists these snippets.
	 */
	const FILTER = 'running-twice';

	/**
	 * Admin-post action that switches an original off.
	 */
	const SWITCH_OFF_ACTION = 'code_snippets_switch_off_original';

	/**
	 * Register the notice.
	 *
	 * @return void
	 */
	public static function init(): void {
		add_action( 'admin_notices', [ self::class, 'render' ] );
		add_action( 'admin_post_' . self::SWITCH_OFF_ACTION, [ self::class, 'switch_off' ] );
	}

	/**
	 * Switch off the original named in the request, then return to the screen the notice was on.
	 *
	 * @return void
	 */
	public static function switch_off(): void {
		$hash = isset( $_POST['hash'] ) ? sanitize_key( wp_unslash( $_POST['hash'] ) ) : '';

		check_admin_referer( self::SWITCH_OFF_ACTION . '_' . $hash );

		if ( ! code_snippets()->current_user_can() || ! code_snippets()->licensing->is_licensed() ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to turn off this code.', 'code-snippets' ), 403 );
		}

		$item     = Discovery_Store::import_of( $hash ) ? Discovery_Store::find_item( $hash ) : null;
		$switched = $item ? Original_Code::switch_off( $item ) : false;

		if ( true !== $switched ) {
			wp_die(
				esc_html( is_wp_error( $switched ) ? $switched->get_error_message() : __( 'The original of this snippet could not be found.', 'code-snippets' ) ),
				'',
				[ 'back_link' => true ]
			);
		}

		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : code_snippets()->get_menu_url() );
		exit;
	}

	/**
	 * Print the notice, when it applies to the current screen and user.
	 *
	 * @return void
	 */
	public static function render(): void {
		$screen = get_current_screen();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing parameter.
		$subpage = isset( $_REQUEST['subpage'] ) ? sanitize_key( wp_unslash( $_REQUEST['subpage'] ) ) : '';

		// Unified Snippets marks each of these on the page itself.
		if ( ! $screen || ! Notice_Filter::is_code_snippets_screen( $screen ) || 'unified-snippets' === $subpage
			|| ! code_snippets()->current_user_can() || ! code_snippets()->licensing->is_licensed() ) {
			return;
		}

		echo self::markup( Discovery_Store::running_twice() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in markup().
	}

	/**
	 * The notice for a list of snippets running twice.
	 *
	 * @param array<int, array<string, mixed>> $found From Discovery_Store::running_twice().
	 *
	 * @return string Escaped markup, or an empty string when there is nothing to report.
	 */
	public static function markup( array $found ): string {
		if ( ! $found ) {
			return '';
		}

		$heading = esc_html__( 'Some code is running twice.', 'code-snippets' );

		if ( 1 < count( $found ) ) {
			return sprintf(
				'<div class="notice notice-warning code-snippets-notice code-snippets-running-twice-notice"><p><strong>%s</strong> %s</p><p><a class="button button-secondary" href="%s">%s</a></p></div>',
				$heading,
				esc_html(
					sprintf(
						/* translators: %d: number of snippets */
						_n(
							'%d active snippet was imported from code that still runs where it was found. Disable each original, or deactivate the snippet.',
							'%d active snippets were imported from code that still runs where it was found. Disable each original, or deactivate the snippet.',
							count( $found ),
							'code-snippets'
						),
						count( $found )
					)
				),
				esc_url( self::unified_snippets_url() ),
				esc_html__( 'Review in Unified Snippets', 'code-snippets' )
			);
		}

		$snippet = $found[0];
		$source  = '' !== $snippet['source_name'] ? $snippet['source_name'] : $snippet['source_path'];

		$message = esc_html(
			sprintf(
				/* translators: 1: snippet name, 2: where the original code lives */
				__( 'The snippet "%1$s" is active, and the code it was imported from still runs in %2$s. Disable the original, or deactivate the snippet.', 'code-snippets' ),
				$snippet['snippet_name'],
				$source
			)
		);

		$can_switch_off = ! empty( $snippet['can_switch_off'] );

		$switch_off = $can_switch_off
			? sprintf(
				'<input type="hidden" name="action" value="%s"><input type="hidden" name="hash" value="%s">%s<button type="submit" class="button button-primary">%s</button> ',
				esc_attr( self::SWITCH_OFF_ACTION ),
				esc_attr( $snippet['hash'] ),
				wp_nonce_field( self::SWITCH_OFF_ACTION . '_' . $snippet['hash'], '_wpnonce', true, false ),
				esc_html__( 'Turn off original', 'code-snippets' )
			)
			: '';

		$original = '' !== $snippet['edit_source_url']
			? sprintf(
				'<a class="button %s" href="%s">%s</a>',
				$can_switch_off ? 'button-secondary' : 'button-primary',
				esc_url( $snippet['edit_source_url'] ),
				esc_html__( 'Edit original', 'code-snippets' )
			)
			: sprintf( '<a class="button button-secondary" href="%s">%s</a>', esc_url( self::unified_snippets_url() ), esc_html__( 'Find it in Unified Snippets', 'code-snippets' ) );

		$actions = sprintf(
			'<p>%s%s <a class="button button-secondary" href="%s">%s</a></p>',
			$switch_off,
			$original,
			esc_url( $snippet['snippet_edit_url'] ),
			esc_html__( 'Edit snippet', 'code-snippets' )
		);

		if ( $can_switch_off ) {
			$actions = sprintf( '<form method="post" action="%s">%s</form>', esc_url( admin_url( 'admin-post.php' ) ), $actions );
		}

		return sprintf(
			'<div class="notice notice-warning code-snippets-notice code-snippets-running-twice-notice"><p><strong>%s</strong> %s</p>%s</div>',
			$heading,
			$message,
			$actions
		);
	}

	/**
	 * Unified Snippets, filtered to snippets running twice.
	 *
	 * @return string
	 */
	public static function unified_snippets_url(): string {
		return add_query_arg(
			[
				'subpage' => 'unified-snippets',
				'filter'  => self::FILTER,
			],
			code_snippets()->get_menu_url()
		);
	}
}
