<?php
/**
 * Run discovery and return interpreted items.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\UnifiedDiscovery\Collectors\Code_Heuristic;
use Code_Snippets\UnifiedDiscovery\Collectors\Custom_Tables_Collector;
use Code_Snippets\UnifiedDiscovery\Collectors\Filesystem_Collector;
use Code_Snippets\UnifiedDiscovery\Collectors\Known_Stores_Collector;
use Code_Snippets\UnifiedDiscovery\Collectors\Options_Collector;
use Code_Snippets\UnifiedDiscovery\Collectors\Post_Content_Collector;
use Code_Snippets\UnifiedDiscovery\Collectors\Post_Meta_Collector;
use Code_Snippets\UnifiedDiscovery\Collectors\Runtime_Capture_Collector;
use Code_Snippets\UnifiedDiscovery\Collectors\Theme_Files_Collector;
use function Code_Snippets\get_snippets;

/**
 * Collect, reduce, classify, assemble.
 */
class Discovery_Runner {

	/**
	 * Shortest normalised code that can be matched by containment.
	 *
	 * Below this, a match says nothing: "color:red" is in every stylesheet.
	 */
	const MIN_MATCH_LENGTH = 30;

	/**
	 * Most candidates one scan takes through the pairwise stages.
	 *
	 * Managed-snippet matching and containment folding compare candidates in
	 * pairs, and the scan runs on a REST request, so the volume is bounded
	 * before either stage. The collectors return their most recent rows first,
	 * so the newest code survives the cut.
	 */
	const MAX_CANDIDATES = 2000;

	/**
	 * Classification backend.
	 *
	 * @var Interpreter_Interface
	 */
	private Interpreter_Interface $interpreter;

	/**
	 * Class constructor.
	 *
	 * @param Authenticated_Cloud_Connection|null $connection  Cloud connection, used to pick the backend.
	 * @param Interpreter_Interface|null          $interpreter Explicit backend, overriding the factory.
	 */
	public function __construct( ?Authenticated_Cloud_Connection $connection = null, ?Interpreter_Interface $interpreter = null ) {
		$this->interpreter = $interpreter ?? Interpreter_Factory::create( $connection );
	}

	/**
	 * Run the full pipeline.
	 *
	 * Reduction happens before classification, so the interpreter sees each
	 * piece of code once, with every place it was found, and never sees what
	 * core printed or what Code Snippets already manages.
	 *
	 * @return array<int, Discovered_Item>
	 */
	public function run(): array {
		$candidates = array_merge(
			( new Theme_Files_Collector() )->collect(),
			( new Filesystem_Collector() )->collect(),
			( new Known_Stores_Collector() )->collect(),
			( new Options_Collector() )->collect(),
			( new Post_Meta_Collector() )->collect(),
			( new Post_Content_Collector() )->collect(),
			( new Custom_Tables_Collector() )->collect(),
			( new Runtime_Capture_Collector() )->collect()
		);

		/**
		 * Filters the raw candidates before they are matched, deduplicated and interpreted.
		 *
		 * @param array<int, array<string, mixed>> $candidates Raw candidates from every collector.
		 */
		$candidates = (array) apply_filters( 'code_snippets/discovery/candidates', $candidates );

		if ( empty( $candidates ) ) {
			return [];
		}

		if ( count( $candidates ) > self::MAX_CANDIDATES ) {
			$candidates = array_slice( $candidates, 0, self::MAX_CANDIDATES );
		}

		$candidates = $this->mark_managed( $candidates );
		$candidates = $this->dedupe( $candidates );
		$candidates = $this->fold_generated( $candidates );
		$candidates = array_map( [ Import_Policy::class, 'settle_runtime_output' ], $candidates );

		// Only candidates cleared for the interpreter leave the site. Anything
		// classified locally by its collector never does.
		$to_interpret = array_filter(
			$candidates,
			static fn( array $candidate ): bool => false !== ( $candidate['send_to_model'] ?? true )
		);

		$interpreted = $to_interpret ? $this->interpreter->interpret( $to_interpret ) : [];
		$items       = [];

		foreach ( $candidates as $index => $candidate ) {
			$item = new Discovered_Item(
				[
					'code'            => $candidate['code'] ?? '',
					'source_path'     => $candidate['source_path'] ?? '',
					'context'         => $candidate['context'] ?? [],
					'also_found_at'   => $candidate['also_found_at'] ?? [],
					'seen_at_runtime' => ! empty( $candidate['seen_at_runtime'] ),
				]
			);

			// Local evidence first, so the listing is usable without a model;
			// whatever the interpreter returns overrides it.
			if ( isset( $candidate['local'] ) && is_array( $candidate['local'] ) ) {
				$item->apply_interpretation( $candidate['local'] );
			} else {
				$item->apply_interpretation( Local_Interpretation::for_candidate( $candidate ) );

				if ( isset( $interpreted[ $index ] ) ) {
					$item->apply_interpretation( $interpreted[ $index ] );
				}

				Import_Policy::apply( $item );
			}

			$items[] = $item;
		}

		return $items;
	}

	/**
	 * Recognise code that Code Snippets already manages.
	 *
	 * A rendered page emitting an active snippet is our own output, not a
	 * discovery, so it is dropped. The same code still sitting in its original
	 * home is kept and labelled, so the person can see the import already
	 * happened and retire the original.
	 *
	 * @param array<int, array<string, mixed>> $candidates Raw candidates.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function mark_managed( array $candidates ): array {
		$managed = [];

		foreach ( get_snippets() as $snippet ) {
			$normalised = Code_Heuristic::normalise_for_match( (string) $snippet->code );

			if ( strlen( $normalised ) >= self::MIN_MATCH_LENGTH ) {
				$managed[] = [ $normalised, Code_Heuristic::normalise_for_identity( (string) $snippet->code ), $snippet ];
			}
		}

		if ( ! $managed ) {
			return $candidates;
		}

		$out = [];

		foreach ( $candidates as $candidate ) {
			// Printed output has lost its comments, so it is compared without them.
			// Stored code keeps them: two snippets that print different comments
			// are different snippets.
			$printed    = 0 === strpos( (string) ( $candidate['source_path'] ?? '' ), 'runtime' );
			$normalised = $printed
				? Code_Heuristic::normalise_for_match( (string) ( $candidate['code'] ?? '' ) )
				: Code_Heuristic::normalise_for_identity( (string) ( $candidate['code'] ?? '' ) );
			$match      = null;

			if ( strlen( $normalised ) >= self::MIN_MATCH_LENGTH ) {
				foreach ( $managed as list( $match_form, $identity_form, $snippet ) ) {
					$code = $printed ? $match_form : $identity_form;

					if ( self::contains( $normalised, $code ) || self::contains( $code, $normalised ) ) {
						$match = $snippet;
						break;
					}
				}
			}

			if ( ! $match ) {
				$out[] = $candidate;
				continue;
			}

			if ( 0 === strpos( (string) ( $candidate['source_path'] ?? '' ), 'runtime' ) ) {
				continue;
			}

			$candidate['send_to_model']                 = false;
			$candidate['context']['managed_snippet_id'] = (int) $match->id;
			$candidate['local']                         = [
				'name'          => (string) $match->name,
				'source_name'   => sprintf(
					/* translators: 1: snippet name, 2: snippet ID */
					__( 'Already managed: "%1$s" (snippet #%2$d)', 'code-snippets' ),
					$match->name,
					$match->id
				),
				'is_active'     => (bool) $match->active,
				'is_importable' => false,
				'import_scope'  => '',
				'import_notes'  => __( 'This code is already a Code Snippets snippet. Retire the original once you are happy with it.', 'code-snippets' ),
				'risk_level'    => 'low',
				'confidence'    => 1.0,
			];
			$out[]                      = $candidate;
		}

		return $out;
	}

	/**
	 * Surface each piece of code once, keeping every location it was found at.
	 *
	 * The same code is often reachable more than one way: Customizer CSS as a
	 * post and through the theme, a theme's inline script both on disk and at
	 * runtime, a builder's HTML widget both in its element tree and in the
	 * plain-text copy of the page. Collectors run from the most authoritative
	 * home to the least, so the first occurrence is the one kept.
	 *
	 * @param array<int, array<string, mixed>> $candidates Raw candidates.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function dedupe( array $candidates ): array {
		$out  = [];
		$seen = [];

		foreach ( $candidates as $candidate ) {
			$key = self::identity( (string) ( $candidate['code'] ?? '' ) );

			if ( isset( $seen[ $key ] ) ) {
				self::absorb( $out[ $seen[ $key ] ], $candidate );
				continue;
			}

			$seen[ $key ]               = count( $out );
			$candidate['also_found_at'] = array_values( array_unique( (array) ( $candidate['also_found_at'] ?? [] ) ) );
			$out[]                      = $candidate;
		}

		return $out;
	}

	/**
	 * Fold generated output into the code it was generated from.
	 *
	 * A builder's compiled stylesheet contains the custom CSS the person typed
	 * into its settings; a page emits, without its tags, the script an option
	 * holds with them. Whenever what a page emitted contains, or is contained
	 * in, code found in a stored home, it is recorded as another location of
	 * that code rather than offered again. What a page emitted inline that
	 * matches nothing stored stays, because that is exactly the code no other
	 * collector could see. A generated file that matches nothing stored is
	 * dropped: builders compile one per page from settings the collectors have
	 * already read, and a site with fifty pages would otherwise list fifty
	 * stylesheets. Inline output attached to a registered handle is generated
	 * the same way, by the PHP of whoever registered the handle, so it gets
	 * the same treatment. The code_snippets/discovery/keep_unmatched_generated_assets
	 * filter keeps both.
	 *
	 * @param array<int, array<string, mixed>> $candidates Deduplicated candidates.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function fold_generated( array $candidates ): array {
		$stored     = [];
		$normalised = [];

		foreach ( $candidates as $index => $candidate ) {
			$normalised[ $index ] = Code_Heuristic::normalise_for_match( (string) ( $candidate['code'] ?? '' ) );

			if ( 0 !== strpos( (string) ( $candidate['source_path'] ?? '' ), 'runtime' ) && false !== ( $candidate['send_to_model'] ?? true ) ) {
				$stored[] = $index;
			}
		}

		foreach ( $candidates as $index => $candidate ) {
			if ( in_array( $index, $stored, true ) || strlen( $normalised[ $index ] ) < self::MIN_MATCH_LENGTH ) {
				continue;
			}

			$hosts = [];

			foreach ( $stored as $host ) {
				if ( strlen( $normalised[ $host ] ) < self::MIN_MATCH_LENGTH ) {
					continue;
				}

				if ( self::contains( $normalised[ $index ], $normalised[ $host ] ) || self::contains( $normalised[ $host ], $normalised[ $index ] ) ) {
					$hosts[] = $host;
				}
			}

			if ( ! $hosts ) {
				$generated = 0 === strpos( (string) ( $candidate['source_path'] ?? '' ), 'runtime-asset:' )
					|| ! empty( $candidate['context']['handle'] );

				if ( $generated && ! apply_filters( 'code_snippets/discovery/keep_unmatched_generated_assets', false, $candidate ) ) {
					unset( $candidates[ $index ] );
				}

				continue;
			}

			foreach ( $hosts as $host ) {
				self::absorb( $candidates[ $host ], $candidate );
			}

			unset( $candidates[ $index ] );
		}

		return array_values( $candidates );
	}

	/**
	 * The key under which code counts as the same code.
	 *
	 * Normalisation drops comments and whitespace, so two different values
	 * that are nothing but a comment would collapse to the same empty key.
	 * Below the match floor the text itself is the key, with only an
	 * enclosing tag and repeated whitespace disregarded.
	 *
	 * @param string $code Code.
	 *
	 * @return string
	 */
	private static function identity( string $code ): string {
		$normalised = Code_Heuristic::normalise_for_identity( $code );

		if ( strlen( $normalised ) >= self::MIN_MATCH_LENGTH ) {
			return md5( $normalised );
		}

		return md5( 'raw:' . preg_replace( '/\s+/', ' ', Code_Heuristic::strip_enclosing_tag( $code ) ) );
	}

	/**
	 * Fold one candidate into another: its locations, and what the page said about it.
	 *
	 * Who printed a piece of code is the best evidence of who owns the place
	 * it is stored: an option printed by a plugin's wp_head callback belongs
	 * to that plugin. So the runtime context travels to the stored copy.
	 *
	 * @param array<string, mixed> $host     Candidate that stays, by reference.
	 * @param array<string, mixed> $absorbed Candidate being folded into it.
	 *
	 * @return void
	 */
	private static function absorb( array &$host, array $absorbed ): void {
		self::add_location( $host, (string) ( $absorbed['source_path'] ?? '' ) );

		foreach ( (array) ( $absorbed['also_found_at'] ?? [] ) as $location ) {
			self::add_location( $host, (string) $location );
		}

		foreach ( [ 'printed_by', 'hook', 'callback', 'handle' ] as $key ) {
			if ( isset( $absorbed['context'][ $key ] ) && ! isset( $host['context'][ $key ] ) ) {
				$host['context'][ $key ] = $absorbed['context'][ $key ];
			}
		}
	}

	/**
	 * Record another location on a candidate.
	 *
	 * @param array<string, mixed> $candidate   Candidate, by reference.
	 * @param string               $source_path Location.
	 *
	 * @return void
	 */
	private static function add_location( array &$candidate, string $source_path ): void {
		if ( '' !== $source_path && ! in_array( $source_path, (array) ( $candidate['also_found_at'] ?? [] ), true ) ) {
			$candidate['also_found_at'][] = $source_path;
		}

		if ( 0 === strpos( $source_path, 'runtime' ) ) {
			$candidate['seen_at_runtime'] = true;
		}
	}

	/**
	 * Whether one normalised code contains another.
	 *
	 * @param string $haystack Normalised code.
	 * @param string $needle   Normalised code.
	 *
	 * @return bool
	 */
	private static function contains( string $haystack, string $needle ): bool {
		return strlen( $needle ) <= strlen( $haystack ) && false !== strpos( $haystack, $needle );
	}
}
