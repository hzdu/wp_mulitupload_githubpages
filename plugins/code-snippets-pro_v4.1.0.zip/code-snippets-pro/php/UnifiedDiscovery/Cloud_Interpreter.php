<?php
/**
 * Interpreter that classifies candidates through Code Snippets Cloud.
 *
 * This is the production path: the site never holds a model API key, and the
 * cloud decides which model answers.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\Client\Cloud_GPT_Client;

/**
 * Classify candidates via the cloud's classify endpoint.
 */
class Cloud_Interpreter implements Interpreter_Interface {

	/**
	 * Cloud AI client.
	 *
	 * @var Cloud_GPT_Client
	 */
	private Cloud_GPT_Client $client;

	/**
	 * Class constructor.
	 *
	 * @param Cloud_GPT_Client $client Cloud AI client.
	 */
	public function __construct( Cloud_GPT_Client $client ) {
		$this->client = $client;
	}

	/**
	 * Interpret raw candidates.
	 *
	 * @param array<int, array<string, mixed>> $candidates Raw candidates.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function interpret( array $candidates ): array {
		if ( empty( $candidates ) ) {
			return [];
		}

		$result = $this->client->classify( Interpreter_Payload::build( $candidates ) );

		return is_wp_error( $result ) ? [] : Interpreter_Payload::index_items( $result );
	}
}
