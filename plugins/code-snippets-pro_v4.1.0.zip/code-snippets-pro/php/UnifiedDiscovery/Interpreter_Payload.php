<?php
/**
 * Shared shaping of what is sent to, and received from, an interpreter.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

/**
 * Build request payloads and index responses, the same way for every backend.
 */
class Interpreter_Payload {

	/**
	 * Longest excerpt of a candidate that is sent for classification.
	 */
	const MAX_CODE = 2400;

	/**
	 * The context keys the classification needs.
	 *
	 * Context also carries labels copied from beside the code, such as a post
	 * title or a custom table's name column, which can hold personal data.
	 * Only these structural keys are sent.
	 */
	const CONTEXT_KEYS = [ 'table', 'hook', 'handle', 'printed_by', 'option', 'theme', 'theme_active', 'post_type', 'block', 'callback', 'kind', 'origin', 'meta_key' ];

	/**
	 * Reduce candidates to the fields an interpreter needs.
	 *
	 * @param array<int, array<string, mixed>> $candidates Raw candidates.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function build( array $candidates ): array {
		$items = [];

		foreach ( $candidates as $index => $candidate ) {
			$item = [
				'index'       => $index,
				'source_path' => $candidate['source_path'] ?? '',
				'source_hint' => $candidate['source_hint'] ?? '',
				'code'        => mb_substr( (string) ( $candidate['code'] ?? '' ), 0, self::MAX_CODE ),
			];

			$context = array_intersect_key( (array) ( $candidate['context'] ?? [] ), array_flip( self::CONTEXT_KEYS ) );

			if ( $context ) {
				$item['context'] = $context;
			}

			if ( ! empty( $candidate['also_found_at'] ) ) {
				$item['also_found_at'] = array_slice( (array) $candidate['also_found_at'], 0, 5 );
			}

			if ( ! empty( $candidate['seen_at_runtime'] ) ) {
				$item['seen_at_runtime'] = true;
			}

			$items[] = $item;
		}

		return $items;
	}

	/**
	 * Key interpreted items by the candidate index they echo back.
	 *
	 * @param array<int, mixed> $items Items from an interpreter response.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function index_items( array $items ): array {
		$indexed = [];

		foreach ( $items as $item ) {
			if ( is_array( $item ) && isset( $item['index'] ) ) {
				$indexed[ (int) $item['index'] ] = $item;
			}
		}

		return $indexed;
	}
}
