<?php
/**
 * A single piece of custom code discovered anywhere on the site.
 *
 * Mirrors the field set of the per-scanner approach's Discovered_Snippet so the
 * two are directly comparable — but here the semantic fields (type, source_type,
 * import target, risk, notes) are filled by a capable model interpreting a raw
 * candidate, NOT by hand-written per-source scanners.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\Model\Snippet;

/**
 * Value object for a discovered piece of code.
 */
class Discovered_Item {

	/**
	 * Code types an item may hold.
	 */
	const TYPES = [ 'php', 'css', 'js', 'html', 'config', 'mixed' ];

	/**
	 * Where an item may come from.
	 */
	const SOURCE_TYPES = [ 'theme', 'child-theme', 'plugin', 'builder', 'core', 'server', 'customizer', 'mu-plugin', 'database', 'unknown' ];

	/**
	 * Risk levels.
	 */
	const RISK_LEVELS = [ 'low', 'medium', 'high' ];

	/**
	 * Raw + interpreted fields.
	 *
	 * @var array<string, mixed>
	 */
	private array $fields;

	/**
	 * Build the value object from raw + interpreted fields.
	 *
	 * @param array<string, mixed> $fields Field values.
	 */
	public function __construct( array $fields ) {
		$defaults = [
			'name'          => '',
			'code'          => '',
			'type'          => 'mixed',   // php, css, js, html, config or mixed.
			'source_type'   => 'unknown', // theme, child-theme, plugin, builder, core, server, customizer, mu-plugin or database.
			'source_name'   => '',
			'source_path'   => '',
			'is_active'     => true,
			'is_importable' => false,
			'import_scope'  => '',        // Suggested Code Snippets scope (global, head-content, footer-content, site-css, ...).
			'import_notes'  => '',
			'import_code'   => '',        // What to import, when it is not the code as found.
			'import_condition' => [],    // The post the snippet should be limited to: post_id, post_type, post_title.
			'risk_level'    => 'medium',  // low, medium or high.
			'confidence'    => 0.0,       // Interpreter confidence 0..1.
			'scanner_id'    => 'unified-discovery',
			'also_found_at' => [],       // Other locations holding identical code.
			'context'       => [],       // What sat beside the code where it was found: labels, flags, who printed it.
			'seen_at_runtime' => false,  // Whether a rendered page actually emitted this code.
		];

		$this->fields = self::normalise( array_merge( $defaults, $fields ) );

		if ( 0 === strpos( (string) $this->fields['source_path'], 'runtime' ) ) {
			$this->fields['seen_at_runtime'] = true;
		}

		$this->fields['hash'] = $this->generate_hash();
		$this->fields['checksum'] = hash( 'sha256', (string) $this->fields['code'] );
		$this->fields['scan_date'] = gmdate( 'c' );
	}

	/**
	 * Deterministic hash of source + location, for dedup between scans.
	 */
	private function generate_hash(): string {
		return substr( hash( 'sha256', $this->fields['source_path'] . '|' . $this->fields['code'] ), 0, 16 );
	}

	/**
	 * Merge interpreted fields (from the model) onto the raw candidate.
	 *
	 * @param array<string, mixed> $interpreted Interpreted field values.
	 */
	public function apply_interpretation( array $interpreted ): void {
		foreach ( [ 'name', 'type', 'source_type', 'source_name', 'is_active', 'is_importable', 'import_scope', 'import_notes', 'import_code', 'import_condition', 'risk_level', 'confidence' ] as $key ) {
			if ( array_key_exists( $key, $interpreted ) ) {
				$this->fields[ $key ] = $interpreted[ $key ];
			}
		}

		$this->fields = self::normalise( $this->fields );
	}

	/**
	 * Restrict every interpreted field to its defined values.
	 *
	 * The model, and the stored scan it feeds, may hold anything; a value
	 * outside the set falls back to the default rather than reaching the
	 * importer or the screen.
	 *
	 * @param array<string, mixed> $fields Field values.
	 *
	 * @return array<string, mixed>
	 */
	private static function normalise( array $fields ): array {
		$fields['name']          = is_scalar( $fields['name'] ) ? (string) $fields['name'] : '';
		$fields['source_name']   = is_scalar( $fields['source_name'] ) ? (string) $fields['source_name'] : '';
		$fields['import_notes']  = is_scalar( $fields['import_notes'] ) ? (string) $fields['import_notes'] : '';
		$fields['import_code']   = is_scalar( $fields['import_code'] ) ? (string) $fields['import_code'] : '';
		$fields['import_condition'] = is_array( $fields['import_condition'] ) && ! empty( $fields['import_condition']['post_id'] )
			? [
				'post_id'    => absint( $fields['import_condition']['post_id'] ),
				'post_type'  => sanitize_key( (string) ( $fields['import_condition']['post_type'] ?? 'post' ) ),
				'post_title' => sanitize_text_field( (string) ( $fields['import_condition']['post_title'] ?? '' ) ),
			]
			: [];
		$fields['type']          = in_array( $fields['type'], self::TYPES, true ) ? $fields['type'] : 'mixed';
		$fields['source_type']   = in_array( $fields['source_type'], self::SOURCE_TYPES, true ) ? $fields['source_type'] : 'unknown';
		$fields['risk_level']    = in_array( $fields['risk_level'], self::RISK_LEVELS, true ) ? $fields['risk_level'] : 'medium';
		$fields['import_scope']  = in_array( $fields['import_scope'], self::importable_scopes(), true ) ? $fields['import_scope'] : '';
		$fields['is_active']     = filter_var( $fields['is_active'], FILTER_VALIDATE_BOOLEAN );
		$fields['is_importable'] = filter_var( $fields['is_importable'], FILTER_VALIDATE_BOOLEAN );
		$fields['confidence']    = is_numeric( $fields['confidence'] ) ? max( 0.0, min( 1.0, (float) $fields['confidence'] ) ) : 0.0;

		return $fields;
	}

	/**
	 * Scopes a discovery may import into: every snippet scope except a condition.
	 *
	 * @return array<int, string>
	 */
	public static function importable_scopes(): array {
		return array_values( array_diff( Snippet::get_all_scopes(), [ 'condition' ] ) );
	}

	/**
	 * Return all fields as an array.
	 *
	 * @return array<string, mixed>
	 */
	public function to_array(): array {
		return $this->fields;
	}

	/**
	 * Get a single field.
	 *
	 * @param string $key Field name.
	 *
	 * @return mixed
	 */
	public function get( string $key ) {
		return $this->fields[ $key ] ?? null;
	}

	/**
	 * Record another location where identical code was found.
	 *
	 * @param string $source_path Location.
	 *
	 * @return void
	 */
	public function add_location( string $source_path ): void {
		if ( '' !== $source_path && ! in_array( $source_path, $this->fields['also_found_at'], true ) ) {
			$this->fields['also_found_at'][] = $source_path;
		}

		if ( 0 === strpos( $source_path, 'runtime' ) ) {
			$this->fields['seen_at_runtime'] = true;
		}
	}
}
