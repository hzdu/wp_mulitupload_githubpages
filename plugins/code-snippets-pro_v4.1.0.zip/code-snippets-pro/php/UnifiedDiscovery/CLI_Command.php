<?php
/**
 * WP-CLI surface for dogfooding the Unified Discovery spike.
 *
 * Commands: `wp cs-discover` (human-readable table) and `wp cs-discover --json`
 * (full JSON, including the interpreted fields).
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use WP_CLI;
use WP_CLI\Utils;

use function Code_Snippets\code_snippets;

/**
 * Discover custom code scattered across the site.
 */
class CLI_Command {

	/**
	 * Register the command with WP-CLI.
	 */
	public static function register(): void {
		WP_CLI::add_command( 'cs-discover', self::class );
	}

	/**
	 * Run discovery and print what was found.
	 *
	 * ## OPTIONS
	 *
	 * [--json]
	 * : Output the full interpreted result as JSON.
	 *
	 * @param array<int, string>    $args       Positional args.
	 * @param array<string, string> $assoc_args Flags.
	 *
	 * @when after_wp_load
	 */
	public function __invoke( array $args, array $assoc_args ): void {
		$items = ( new Discovery_Runner( code_snippets()->cloud_connection ) )->run();

		if ( empty( $items ) ) {
			WP_CLI::warning( 'No custom code discovered (or the interpreter has no API key set).' );
			return;
		}

		$rows = array_map(
			static function ( Discovered_Item $item ) {
				return [
					'source_name' => (string) $item->get( 'source_name' ),
					'type'        => (string) $item->get( 'type' ),
					'source_type' => (string) $item->get( 'source_type' ),
					'active'      => $item->get( 'is_active' ) ? 'yes' : 'no',
					'import_to'   => (string) $item->get( 'import_scope' ),
					'risk'        => (string) $item->get( 'risk_level' ),
					'conf'        => (string) $item->get( 'confidence' ),
					'source_path' => (string) $item->get( 'source_path' ),
				];
			},
			$items
		);

		if ( isset( $assoc_args['json'] ) ) {
			WP_CLI::line( (string) wp_json_encode( array_map( static fn( $i ) => $i->to_array(), $items ), JSON_PRETTY_PRINT ) );
			return;
		}

		WP_CLI::success( sprintf( 'Discovered %d item(s) — generic collectors + model interpretation, zero per-source scanners.', count( $items ) ) );
		Utils\format_items( 'table', $rows, [ 'source_name', 'type', 'source_type', 'active', 'import_to', 'risk', 'conf', 'source_path' ] );

		foreach ( $items as $item ) {
			$notes = (string) $item->get( 'import_notes' );
			if ( '' !== $notes ) {
				WP_CLI::line( sprintf( '  • %s — %s', $item->get( 'source_name' ), $notes ) );
			}
		}
	}
}
