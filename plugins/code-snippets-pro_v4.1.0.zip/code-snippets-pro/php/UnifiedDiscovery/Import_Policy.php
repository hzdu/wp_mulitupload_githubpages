<?php
/**
 * Rules for what a discovery may be imported as.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

/**
 * Decide whether, and how, a discovery is imported.
 *
 * An imported snippet should do what the original did: run in the same
 * places, with the same effect. A discovery that cannot be reproduced that way
 * is listed, not offered for import. These rules run after interpretation, so
 * neither the local guess nor an interpreter can override them.
 */
class Import_Policy {

	/**
	 * Plugins whose printed output is code their users wrote.
	 */
	const CODE_MANAGERS = [
		'code-snippets',
		'code-snippets-pro',
		'custom-css-js',
		'easy-code-manager',
		'header-footer-code-manager',
		'insert-headers-and-footers',
		'insert-php-code-snippet',
		'woody-ad-snippets',
		'wpcode-premium',
		'wpcodebox2',
	];

	/**
	 * Post meta keys a page builder renders as the page itself.
	 */
	const RENDERED_META_KEYS = [ '_bricks_page_content_2', '_elementor_data', '_fl_builder_data', 'ct_builder_shortcodes' ];

	/**
	 * List output a plugin printed as part of how it works, rather than offer it for import.
	 *
	 * Code a user stored in a plugin's settings is found where it is stored, and
	 * the runtime copy is folded into that find. What is left over, printed by a
	 * plugin that does not manage code, is the plugin's own.
	 *
	 * @param array<string, mixed> $candidate Candidate after deduplication.
	 *
	 * @return array<string, mixed>
	 */
	public static function settle_runtime_output( array $candidate ): array {
		$printed_by = (string) ( $candidate['context']['printed_by'] ?? '' );

		if ( 0 !== strpos( (string) ( $candidate['source_path'] ?? '' ), 'runtime' )
			|| ! preg_match( '/^(?:mu-)?plugin:([^\/]+)/', $printed_by, $matches )
			|| in_array( $matches[1], (array) apply_filters( 'code_snippets/discovery/code_managers', self::CODE_MANAGERS ), true ) ) {
			return $candidate;
		}

		$local = Local_Interpretation::for_candidate( $candidate );

		$local['is_importable'] = false;
		$local['import_scope'] = '';
		$local['import_notes'] = sprintf(
			/* translators: %s: plugin slug */
			__( 'Printed by the %s plugin as part of how it works. Importing it would run it twice.', 'code-snippets' ),
			$matches[1]
		);

		$candidate['send_to_model'] = false;
		$candidate['local'] = $local;

		return $candidate;
	}

	/**
	 * Apply the rules to an interpreted item.
	 *
	 * @param Discovered_Item $item Item.
	 *
	 * @return void
	 */
	public static function apply( Discovered_Item $item ): void {
		$path    = (string) $item->get( 'source_path' );
		$context = (array) $item->get( 'context' );

		if ( preg_match( '#^(?:post|postmeta):#', $path ) ) {
			$post_type = (string) ( $context['post_type'] ?? '' );

			// Additional CSS is kept per theme, and only the active theme's is used.
			if ( 'custom_css' === $post_type && get_stylesheet() !== ( $context['post_title'] ?? '' ) ) {
				$item->apply_interpretation(
					[
						'is_active'     => false,
						'is_importable' => false,
						'import_scope'  => '',
						'import_notes'  => sprintf(
							/* translators: %s: theme directory name */
							__( 'Additional CSS saved for the %s theme, which is not active, so it is not offered for import.', 'code-snippets' ),
							(string) ( $context['post_title'] ?? '' )
						),
					]
				);
				return;
			}

			// A snippet manager's store or a theme part runs wherever its own
			// settings say; only its published state says whether it is on.
			if ( '' === $post_type || ! is_post_type_viewable( $post_type ) ) {
				if ( isset( $context['post_status'] ) && 'publish' !== $context['post_status'] ) {
					$item->apply_interpretation( [ 'is_active' => false ] );
				}

				return;
			}

			$runs = 'publish' === ( $context['post_status'] ?? 'publish' )
				&& ( 0 !== strpos( $path, 'postmeta:' ) || in_array( $context['meta_key'] ?? '', self::RENDERED_META_KEYS, true ) );

			self::place( $item, $runs, $context );
			return;
		}

		if ( preg_match( '#^wp_options:widget_([a-z0-9_-]+)/(\d+)/#', $path, $matches ) ) {
			self::place( $item, self::is_widget_shown( $matches[1] . '-' . $matches[2] ), [] );
		}
	}

	/**
	 * Settle where content found in a page or widget would run once imported.
	 *
	 * @param Discovered_Item      $item    Item.
	 * @param bool                 $runs    Whether anything shows the original running.
	 * @param array<string, mixed> $context Item context; a post's for code found in a page.
	 *
	 * @return void
	 */
	private static function place( Discovered_Item $item, bool $runs, array $context ): void {
		if ( ! $runs && ! $item->get( 'seen_at_runtime' ) ) {
			$item->apply_interpretation(
				[
					'is_active'     => false,
					'is_importable' => false,
					'import_scope'  => '',
					'import_notes'  => __( 'Stored here, but nothing shows it running on the site, so it is not offered for import.', 'code-snippets' ),
				]
			);
			return;
		}

		$type = (string) $item->get( 'type' );

		if ( ! in_array( $type, [ 'html', 'js', 'css', 'mixed' ], true ) ) {
			return;
		}

		$code = (string) $item->get( 'code' );

		preg_match_all( '#<(script|style)\b[^>]*>.*?</\1\s*>#is', $code, $tags, PREG_SET_ORDER );

		$markup = trim( (string) preg_replace( '#<(script|style)\b[^>]*>.*?</\1\s*>|<!--.*?-->#is', '', $code ) );
		$target = empty( $context['post_id'] ) ? [] : [
			'post_id'    => (int) $context['post_id'],
			'post_type'  => (string) ( $context['post_type'] ?? 'post' ),
			'post_title' => (string) ( $context['post_title'] ?? '' ),
		];

		// Bare script or style, as found in a builder's code field.
		if ( ! $tags && in_array( $type, [ 'js', 'css' ], true ) ) {
			self::offer( $item, $code, 'css' === $type ? 'site-css' : 'site-footer-js', $target, false );
			return;
		}

		if ( ! $tags ) {
			$item->apply_interpretation(
				[
					'is_importable' => false,
					'import_scope'  => '',
					'import_notes'  => __( 'Part of the page\'s content, so it is best left where it is.', 'code-snippets' ),
				]
			);
			return;
		}

		$styles_only = ! array_filter( $tags, static fn( array $tag ): bool => 'script' === strtolower( $tag[1] ) );

		if ( $styles_only ) {
			$css = implode( "\n", array_map( static fn( array $tag ): string => (string) preg_replace( '#^<style\b[^>]*>|</style\s*>$#i', '', $tag[0] ), $tags ) );
			self::offer( $item, $css, 'site-css', $target, '' !== $markup );
			return;
		}

		self::offer( $item, implode( "\n", array_column( $tags, 0 ) ), 'footer-content', $target, '' !== $markup );
	}

	/**
	 * Offer an item for import as the given code and scope.
	 *
	 * @param Discovered_Item      $item     Item.
	 * @param string               $code     Code to import.
	 * @param string               $scope    Snippet scope.
	 * @param array<string, mixed> $target   Post the snippet is limited to, if any.
	 * @param bool                 $has_rest Whether markup is left behind on the page.
	 *
	 * @return void
	 */
	private static function offer( Discovered_Item $item, string $code, string $scope, array $target, bool $has_rest ): void {
		$where = $target
			? sprintf(
				/* translators: %s: post title */
				__( 'It is limited to "%s", where it ran.', 'code-snippets' ),
				'' !== $target['post_title'] ? $target['post_title'] : '#' . $target['post_id']
			)
			: '';

		$notes = $has_rest
			? __( 'Only the script and style tags are imported; the rest stays where it is.', 'code-snippets' )
			: '';

		$item->apply_interpretation(
			[
				'is_importable'    => true,
				'import_scope'     => $scope,
				'import_code'      => $code,
				'import_condition' => $target,
				'import_notes'     => trim( $notes . ' ' . $where ),
			]
		);
	}

	/**
	 * Whether a classic widget is placed where the theme displays it.
	 *
	 * @param string $widget_id Widget ID, such as custom_html-2.
	 *
	 * @return bool
	 */
	public static function is_widget_shown( string $widget_id ): bool {
		if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
			return false;
		}

		foreach ( wp_get_sidebars_widgets() as $sidebar => $widgets ) {
			if ( 'wp_inactive_widgets' !== $sidebar && is_array( $widgets ) && in_array( $widget_id, $widgets, true ) && is_registered_sidebar( $sidebar ) ) {
				return true;
			}
		}

		return false;
	}
}
