<?php
/**
 * Interpreter that calls OpenAI directly. Development and dogfooding only.
 *
 * Given raw candidates from the generic collectors, a capable model works out
 * what each one actually is and how it should be imported: type, the real
 * source (Divi options? a child theme? GA via a tag manager?), whether it's
 * active, the right Code Snippets scope, the risk, and any import caveats. One
 * general interpreter instead of one hand-written scanner per plugin/theme.
 *
 * Production classification goes through Cloud_Interpreter, so the site never
 * holds a model key. This backend is selected only when CS_DISCOVERY_OPENAI_KEY
 * or OPENAI_API_KEY is set. AI quality here is bounded by the model.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

/**
 * Classify raw candidates with a capable model.
 */
class OpenAI_Interpreter implements Interpreter_Interface {

	private const ENDPOINT = 'https://api.openai.com/v1/chat/completions';
	private const MODEL    = 'gpt-4o';

	/**
	 * Candidates per request.
	 */
	const BATCH_SIZE = 20;

	/**
	 * Seconds to wait for one batch.
	 */
	const TIMEOUT = 30;

	/**
	 * Interpret raw candidates, returning a map of index => interpreted fields.
	 *
	 * @param array<int, array<string, mixed>> $candidates Raw candidates.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function interpret( array $candidates ): array {
		if ( empty( $candidates ) ) {
			return [];
		}

		$key = self::api_key();
		if ( '' === $key ) {
			return [];
		}

		$items = [];

		// One request per batch: a whole scan in one request outgrows the
		// model's context and then every item loses its classification at once.
		foreach ( array_chunk( Interpreter_Payload::build( $candidates ), self::BATCH_SIZE ) as $batch ) {
			$items += $this->request( $batch, $key );
		}

		return $items;
	}

	/**
	 * Classify one batch.
	 *
	 * @param array<int, array<string, mixed>> $batch Payload items.
	 * @param string                           $key   API key.
	 *
	 * @return array<int, array<string, mixed>> Interpreted items keyed by candidate index.
	 */
	private function request( array $batch, string $key ): array {
		$body = [
			'model'           => self::MODEL,
			'temperature'     => 0,
			'response_format' => [ 'type' => 'json_object' ],
			'messages'        => [
				[
					'role'    => 'system',
					'content' => $this->system_prompt(),
				],
				[
					'role'    => 'user',
					'content' => wp_json_encode( [ 'candidates' => $batch ] ),
				],
			],
		];

		$response = wp_remote_post(
			self::ENDPOINT,
			[
				'timeout' => self::TIMEOUT,
				'headers' => [
					'Authorization' => 'Bearer ' . $key,
					'Content-Type'  => 'application/json',
				],
				'body'    => wp_json_encode( $body ),
			]
		);

		if ( is_wp_error( $response ) ) {
			$this->report( $response->get_error_code(), $response->get_error_message() );
			return [];
		}

		$status = (int) wp_remote_retrieve_response_code( $response );

		// A 401, 429 or 500 is not a WP_Error; without this check its error
		// body is parsed as an answer and looks like a site with nothing to classify.
		if ( 200 !== $status ) {
			$this->report( (string) $status, substr( wp_remote_retrieve_body( $response ), 0, 500 ) );
			return [];
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		$content = $decoded['choices'][0]['message']['content'] ?? '';
		$parsed  = json_decode( (string) $content, true );

		if ( ! is_array( $parsed ) || ! isset( $parsed['items'] ) || ! is_array( $parsed['items'] ) ) {
			$this->report( 'unparseable', 'The response held no items.' );
			return [];
		}

		return Interpreter_Payload::index_items( $parsed['items'] );
	}

	/**
	 * Report a failed request, so a developer can tell an auth failure from an empty site.
	 *
	 * @param string $code   Status code or error code.
	 * @param string $detail What came back.
	 *
	 * @return void
	 */
	private function report( string $code, string $detail ): void {
		/**
		 * Fires when the direct interpreter fails a request.
		 *
		 * @param string $backend Interpreter name.
		 * @param string $code    HTTP status or error code.
		 * @param string $detail  Response detail, at most 500 bytes.
		 */
		do_action( 'code_snippets/discovery/interpreter_error', 'openai', $code, $detail );
	}

	/**
	 * Whether a direct-call key has been configured.
	 *
	 * @return bool
	 */
	public static function is_configured(): bool {
		return '' !== self::api_key();
	}

	/**
	 * Resolve the API key from the plugin's own constant.
	 *
	 * The generic OPENAI_API_KEY environment variable is deliberately not read:
	 * many hosts set it for unrelated tooling, and it must not switch a site on
	 * to sending its code to a third party.
	 *
	 * @return string
	 */
	private static function api_key(): string {
		$key = defined( 'CS_DISCOVERY_OPENAI_KEY' ) && CS_DISCOVERY_OPENAI_KEY ? (string) CS_DISCOVERY_OPENAI_KEY : '';

		/**
		 * Filters the direct interpreter's API key, for development and tests.
		 *
		 * @param string $key The configured key, or "" when the backend is off.
		 */
		return (string) apply_filters( 'code_snippets/discovery/openai_key', $key );
	}

	/**
	 * The classification instructions.
	 */
	private function system_prompt(): string {
		return <<<'TXT'
You are an expert WordPress engineer auditing a site for custom code that lives outside the Code Snippets plugin. You are given raw candidates discovered generically (from wp_options, theme files, the Customizer, etc.) — the discovery layer does NOT know which plugin or theme produced each one. Your job is to identify what each candidate actually is and how it would import into Code Snippets.

Return ONLY a JSON object: { "items": [ { ... }, ... ] }, one entry per candidate, each with:
- index: the candidate's index (echo it back)
- name: short human label for the snippet (<= 60 chars)
- type: one of php, css, js, html, config, mixed
- source_type: one of theme, child-theme, plugin, builder, core, server, customizer, mu-plugin, database, unknown
- source_name: your best identification of the actual origin (e.g. "Divi Theme Options", "Redux (theme options)", "Google Tag Manager", "Astra child theme functions.php", "Additional CSS"). Infer from option names, code shape, and conventions. Say "unknown" only if genuinely unidentifiable.
- is_active: boolean — your best judgement on whether this code is currently running (e.g. an options blob with a disabled toggle is not active).
- is_importable: boolean — could Code Snippets reproduce this?
- import_scope: the Code Snippets scope it should import to: global, head-content, footer-content, site-css, site-head-js, site-footer-js, content, admin-css, or "" if not importable.
- import_notes: concise caveats (hook/priority differences, theme-dependency, "wrap in add_action", etc.). One sentence.
- risk_level: low, medium, high.
- confidence: 0..1, how confident you are in this classification.

Be precise about runtime semantics (which hook/scope reproduces the behaviour). Never invent code; classify only what you are given.
TXT;
	}
}
