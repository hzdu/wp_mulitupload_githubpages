<?php
/**
 * The code a discovery was found in, read as it is now.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\UnifiedDiscovery\Collectors\Code_Heuristic;
use Code_Snippets\UnifiedDiscovery\Collectors\Custom_Tables_Collector;
use Code_Snippets\UnifiedDiscovery\Collectors\Known_Stores_Collector;
use WP_Error;

/**
 * Whether the original of a discovery still runs, and switching it off in the snippet manager that holds it.
 *
 * The scan records what was true when it ran. For originals whose on/off state
 * can be read directly, it is read again here, so a change made since the scan
 * shows straight away. Switching off is offered only for snippet managers with
 * an on/off state of their own, so it can be undone there.
 */
class Original_Code {

	/**
	 * The original still runs.
	 */
	const RUNNING = 'running';

	/**
	 * The original is still there, switched off.
	 */
	const OFF = 'off';

	/**
	 * The original is no longer there.
	 */
	const REMOVED = 'removed';

	/**
	 * Where the original stands now: one of the constants above, or an empty string when it cannot be read again.
	 *
	 * @param array<string, mixed> $item Stored item.
	 *
	 * @return string
	 */
	public static function state( array $item ): string {
		$path = (string) ( $item['source_path'] ?? '' );

		if ( preg_match( '#^(?:post|postmeta):[a-z0-9_-]+/(\d+)#', $path, $matches ) ) {
			$status = get_post_status( (int) $matches[1] );

			if ( ! $status || 'trash' === $status ) {
				return self::REMOVED;
			}

			return 'publish' === $status ? self::RUNNING : self::OFF;
		}

		if ( preg_match( '#^wp_options:widget_([a-z0-9_-]+)/(\d+)/#', $path, $matches ) ) {
			return Import_Policy::is_widget_shown( $matches[1] . '-' . $matches[2] ) ? self::RUNNING : self::OFF;
		}

		$row = self::table_row( $path );

		if ( $row ) {
			$status = self::row_status( $row[0], $row[1] );

			if ( null === $status ) {
				return self::REMOVED;
			}

			return Custom_Tables_Collector::KNOWN_STATUS[ $row[0] ]['on'] === $status ? self::RUNNING : self::OFF;
		}

		$file = self::fluent_file( $path );

		if ( '' !== $file ) {
			if ( ! is_file( $file ) ) {
				return self::REMOVED;
			}

			$contents = Code_Heuristic::read_file( $file );
			$snippet  = is_string( $contents ) ? Known_Stores_Collector::parse_fluent_snippet( $contents, $file ) : null;

			return $snippet && $snippet['is_active'] ? self::RUNNING : self::OFF;
		}

		return '';
	}

	/**
	 * Whether the current user can switch the original off from here.
	 *
	 * @param array<string, mixed> $item Stored item.
	 *
	 * @return bool
	 */
	public static function can_switch_off( array $item ): bool {
		$manager = self::manager( $item );

		if ( '' === $manager || ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		// FluentSnippets lets only users who could write its PHP files change one of them.
		if ( 'fluent-snippets' === $manager && ! ( current_user_can( 'install_plugins' ) && current_user_can( 'unfiltered_html' ) ) ) {
			return false;
		}

		return self::RUNNING === self::state( $item );
	}

	/**
	 * Switch the original off in the snippet manager that holds it, as that plugin's own on/off control would.
	 *
	 * @param array<string, mixed> $item Stored item.
	 *
	 * @return true|WP_Error
	 */
	public static function switch_off( array $item ) {
		if ( ! self::can_switch_off( $item ) ) {
			return new WP_Error(
				'code_snippets_original_not_switchable',
				__( 'This original cannot be turned off from here. Use the Edit original link to turn it off where it is kept.', 'code-snippets' ),
				[ 'status' => 409 ]
			);
		}

		$path = (string) $item['source_path'];

		switch ( self::manager( $item ) ) {
			case 'wpcode':
				preg_match( '#^post:wpcode/(\d+)#', $path, $matches );
				( new \WPCode_Snippet( (int) $matches[1] ) )->deactivate();
				break;

			case 'fluent-snippets':
				$model   = new \FluentSnippets\App\Model\Snippet();
				$name    = basename( self::fluent_file( $path ) );
				$snippet = $model->findByFileName( $name );

				if ( ! is_wp_error( $snippet ) ) {
					$snippet['meta']['status'] = 'draft';
					$updated                   = $model->updateSnippet( $name, $snippet['code'], $snippet['meta'] );

					if ( ! is_wp_error( $updated ) ) {
						do_action( 'fluent_snippets/snippet_status_updated', $updated );
						do_action( 'fluent_snippets/snippet_updated', $updated );
					}
				}
				break;

			case 'table':
				global $wpdb;
				[ $table, $id ] = self::table_row( $path );
				$known          = Custom_Tables_Collector::KNOWN_STATUS[ $table ];

				if ( 'wpcb_snippets' === $table && class_exists( '\Wpcb2\FunctionalityPlugin\Manager' ) ) {
					( new \Wpcb2\FunctionalityPlugin\Manager( false ) )->disableSnippet( $id );
				}

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the plugin's own table, which it reads on every request.
				$wpdb->update( $wpdb->prefix . $table, [ $known['column'] => $known['off'] ], [ $known['key'] => $id ], [ '%s' ], [ '%d' ] );
				break;
		}

		if ( self::RUNNING === self::state( $item ) ) {
			return new WP_Error(
				'code_snippets_original_still_running',
				__( 'The original could not be turned off. Use the Edit original link to turn it off where it is kept.', 'code-snippets' ),
				[ 'status' => 500 ]
			);
		}

		return true;
	}

	/**
	 * The snippet manager holding an original that can be switched off, or an empty string when there is none.
	 *
	 * @param array<string, mixed> $item Stored item.
	 *
	 * @return string
	 */
	private static function manager( array $item ): string {
		$path = (string) ( $item['source_path'] ?? '' );

		if ( 0 === strpos( $path, 'post:wpcode/' ) && class_exists( 'WPCode_Snippet' ) ) {
			return 'wpcode';
		}

		if ( '' !== self::fluent_file( $path ) && class_exists( '\FluentSnippets\App\Model\Snippet' ) ) {
			return 'fluent-snippets';
		}

		return self::table_row( $path ) ? 'table' : '';
	}

	/**
	 * The FluentSnippets file a source path names, or an empty string when it names none.
	 *
	 * @param string $path Source path.
	 *
	 * @return string
	 */
	private static function fluent_file( string $path ): string {
		$dir = trim( (string) ( Known_Stores_Collector::stores()['fluent-snippets']['dir'] ?? '' ), '/' );

		if ( '' === $dir || ! preg_match( '/^[A-Za-z0-9._-]+\.php$/', basename( $path ) ) ) {
			return '';
		}

		$file = WP_CONTENT_DIR . '/' . $dir . '/' . basename( $path );

		return $file === $path ? $file : '';
	}

	/**
	 * The snippet manager table and row a source path names, when it is a table whose rows record whether they run.
	 *
	 * @param string $path Source path.
	 *
	 * @return array{0: string, 1: int}|null Table name without the prefix, and row ID.
	 */
	private static function table_row( string $path ): ?array {
		if ( ! preg_match( '#^table:([a-z0-9_]+)/(\d+)/#i', $path, $matches ) || ! isset( Custom_Tables_Collector::KNOWN_STATUS[ $matches[1] ] ) ) {
			return null;
		}

		return [ $matches[1], (int) $matches[2] ];
	}

	/**
	 * The state column of a snippet manager's row, or null when the row or its table is gone.
	 *
	 * A plugin drops its table when it is deleted, so a missing table is read as a removed row.
	 *
	 * @param string $table Table name without the prefix, a key of Custom_Tables_Collector::KNOWN_STATUS.
	 * @param int    $id    Row ID.
	 *
	 * @return string|null
	 */
	private static function row_status( string $table, int $id ): ?string {
		global $wpdb;

		$known      = Custom_Tables_Collector::KNOWN_STATUS[ $table ];
		$suppressed = $wpdb->suppress_errors();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- identifiers are the prefix and constants.
		$status = $wpdb->get_var( $wpdb->prepare( "SELECT `{$known['column']}` FROM `{$wpdb->prefix}{$table}` WHERE `{$known['key']}` = %d", $id ) );
		$failed = '' !== $wpdb->last_error;

		$wpdb->suppress_errors( $suppressed );

		return $failed || null === $status ? null : (string) $status;
	}
}
