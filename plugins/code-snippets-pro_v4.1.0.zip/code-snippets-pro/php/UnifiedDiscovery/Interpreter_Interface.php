<?php
/**
 * Contract for anything that can classify discovered candidates.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

/**
 * Classify raw candidates into snippet-shaped interpretations.
 */
interface Interpreter_Interface {

	/**
	 * Interpret raw candidates.
	 *
	 * @param array<int, array<string, mixed>> $candidates Raw candidates, keyed by index.
	 *
	 * @return array<int, array<string, mixed>> Interpreted fields, keyed by the same index.
	 */
	public function interpret( array $candidates ): array;
}
