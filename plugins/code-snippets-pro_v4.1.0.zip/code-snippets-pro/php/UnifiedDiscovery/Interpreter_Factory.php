<?php
/**
 * Choose the classification backend for a scan.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\Client\Cloud_GPT_Client;
use Code_Snippets\Model\Authenticated_Cloud_Connection;

/**
 * Pick the cloud when it is connected, a direct key for development, else nothing.
 */
class Interpreter_Factory {

	/**
	 * Create the interpreter to use.
	 *
	 * @param Authenticated_Cloud_Connection|null $connection Cloud connection, when available.
	 *
	 * @return Interpreter_Interface
	 */
	public static function create( ?Authenticated_Cloud_Connection $connection ): Interpreter_Interface {
		if ( $connection && $connection->is_cloud_key_verified() ) {
			$interpreter = new Cloud_Interpreter( new Cloud_GPT_Client( $connection ) );
		} elseif ( OpenAI_Interpreter::is_configured() ) {
			$interpreter = new OpenAI_Interpreter();
		} else {
			$interpreter = new Null_Interpreter();
		}

		/**
		 * Filters the backend that classifies discovered code.
		 *
		 * Returning a Null_Interpreter lists what was found without sending
		 * anything anywhere.
		 *
		 * @param Interpreter_Interface               $interpreter Chosen backend.
		 * @param Authenticated_Cloud_Connection|null $connection  Cloud connection, when available.
		 */
		$filtered = apply_filters( 'code_snippets/discovery/interpreter', $interpreter, $connection );

		return $filtered instanceof Interpreter_Interface ? $filtered : $interpreter;
	}
}
