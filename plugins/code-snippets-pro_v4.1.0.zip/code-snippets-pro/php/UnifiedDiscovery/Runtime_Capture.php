<?php
/**
 * Runtime capture: the source-agnostic spine.
 *
 * When a front-end request carries a valid capture token, the whole rendered
 * page is buffered and stashed. The collector then extracts every inline
 * <script>/<style> the page actually emitted, whichever theme, plugin, builder,
 * widget or post produced it. If it ran and hit the page, it is seen, even when
 * nothing on disk or in the options table reveals the source.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

/**
 * Capture the rendered front-end output on demand.
 */
class Runtime_Capture {

	const TRANSIENT       = 'cs_discovery_runtime_capture';
	const TOKEN_TRANSIENT = 'cs_discovery_capture_token';
	const FLAG            = 'cs_capture';
	const TOKEN_TTL       = 2 * MINUTE_IN_SECONDS;

	/**
	 * Issue a single-use token that permits one capture.
	 *
	 * The flag used to be a bare query var, which let any visitor decide what
	 * HTML ended up in the transient that an administrator's scan then reads
	 * and offers for import. A token minted by the scan itself, consumed on
	 * first use, keeps that decision with the administrator.
	 *
	 * @param int $uses How many requests the token may authorise: one per page to capture.
	 *
	 * @return string The token.
	 */
	public static function arm( int $uses = 1 ): string {
		$token = wp_generate_password( 32, false );
		set_transient(
			self::TOKEN_TRANSIENT,
			[
				'token' => $token,
				'uses'  => max( 1, $uses ),
			],
			self::TOKEN_TTL
		);
		return $token;
	}

	/**
	 * Whether the current request carries the armed token.
	 *
	 * Each match spends one use; the token is deleted with its last.
	 *
	 * @return bool
	 */
	public static function is_authorised_request(): bool {
		// The value is a one-shot token checked with hash_equals() below, not a
		// nonce, so nonce verification does not apply. Tokens are alphanumeric,
		// so sanitising cannot change a genuine one.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$presented = isset( $_GET[ self::FLAG ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::FLAG ] ) ) : '';

		if ( '' === $presented ) {
			return false;
		}

		$stored   = get_transient( self::TOKEN_TRANSIENT );
		$expected = is_array( $stored ) ? (string) ( $stored['token'] ?? '' ) : '';

		if ( '' === $expected || ! hash_equals( $expected, $presented ) ) {
			return false;
		}

		$remaining = (int) ( $stored['uses'] ?? 1 ) - 1;

		if ( $remaining > 0 ) {
			set_transient(
				self::TOKEN_TRANSIENT,
				[
					'token' => $expected,
					'uses'  => $remaining,
				],
				self::TOKEN_TTL
			);
		} else {
			delete_transient( self::TOKEN_TRANSIENT );
		}

		return true;
	}

	/**
	 * The URL of the current request, from its own scheme, host and path.
	 *
	 * Building it from home_url() would prepend the site path a second time on
	 * a subdirectory install.
	 *
	 * @return string
	 */
	public static function current_url(): string {
		$host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';

		return esc_url_raw( ( is_ssl() ? 'https' : 'http' ) . '://' . $host . $uri );
	}

	/**
	 * Arm capture on an authorised front-end request.
	 *
	 * @return void
	 */
	public static function init(): void {
		if ( is_admin() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		if ( ! self::is_authorised_request() ) {
			return;
		}

		Runtime_Provenance::hook();

		// Buffer the entire response. The callback fires once on flush with the
		// full HTML, embeds the provenance manifest, stores the result, and
		// returns it so the page still renders (and a browser-driven capture
		// carries the manifest with it).
		add_action(
			'template_redirect',
			static function () {
				ob_start(
					static function ( $html ) {
						if ( is_string( $html ) && strlen( $html ) > 200 ) {
							$html = Runtime_Provenance::inject( $html );
							set_transient(
								self::TRANSIENT,
								[
									'url'         => self::current_url(),
									'captured_at' => gmdate( 'c' ),
									'html'        => $html,
								],
								HOUR_IN_SECONDS
							);
						}

						return $html;
					}
				);
			},
			PHP_INT_MIN
		);
	}
}
