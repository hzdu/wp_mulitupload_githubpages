<?php
/**
 * Where a discovered item can be edited at its source.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\UnifiedDiscovery\Collectors\Known_Stores_Collector;

/**
 * Resolve the screen a site owner would use to edit, disable or delete the original of a discovery.
 *
 * Links are resolved for the current user when the scan is served, so a user
 * who cannot edit a source is not offered a link to it.
 */
class Source_Links {

	/**
	 * Page builders that edit a page on the front end, keyed by the meta key they store it in: the query argument that
	 * opens the builder.
	 */
	const FRONT_END_BUILDERS = [
		'_bricks_page_content_2' => [ 'bricks', 'run' ],
		'_fl_builder_data'       => [ 'fl_builder', '' ],
		'ct_builder_shortcodes'  => [ 'ct_builder', 'true' ],
	];

	/**
	 * Admin pages of plugins that keep code in a table of their own, keyed by table name without prefix. %d is the row ID.
	 */
	const TABLE_EDITORS = [
		'hfcm_scripts'  => 'admin.php?page=hfcm-update&id=%d',
		'wpcb_snippets' => 'admin.php?page=wpcodebox2&snippet=%d',
	];

	/**
	 * The URL that edits the original of an item, or an empty string when there is none the current user can use.
	 *
	 * @param array<string, mixed> $item Stored item.
	 *
	 * @return string
	 */
	public static function edit_url( array $item ): string {
		$path = (string) ( $item['source_path'] ?? '' );
		$url  = self::resolve( $path, (array) ( $item['context'] ?? [] ) );

		/**
		 * Filters the URL that edits the original of a discovered item.
		 *
		 * @param string               $url  URL, or an empty string when there is none.
		 * @param array<string, mixed> $item Stored item.
		 */
		return (string) apply_filters( 'code_snippets/discovery/source_edit_url', $url, $item );
	}

	/**
	 * Resolve a source path to the screen that edits it.
	 *
	 * @param string               $path    Source path.
	 * @param array<string, mixed> $context Item context.
	 *
	 * @return string
	 */
	private static function resolve( string $path, array $context ): string {
		if ( 'customizer:additional_css' === $path ) {
			return self::customizer_css_url();
		}

		if ( preg_match( '#^(post|postmeta):([a-z0-9_-]+)/(\d+)(?:/([^/]+))?#', $path, $matches ) ) {
			$meta_key = 'postmeta' === $matches[1] ? (string) ( $matches[4] ?? '' ) : '';

			return self::post_url( $matches[2], (int) $matches[3], $meta_key );
		}

		if ( preg_match( '#^wp_options:widget_[a-z0-9_-]+/\d+/#', $path ) ) {
			return current_user_can( 'edit_theme_options' ) ? admin_url( 'widgets.php' ) : '';
		}

		if ( preg_match( '#^table:([a-z0-9_]+)/(\d+)/#i', $path, $matches ) && isset( self::TABLE_EDITORS[ $matches[1] ] ) ) {
			return current_user_can( 'manage_options' ) ? admin_url( sprintf( self::TABLE_EDITORS[ $matches[1] ], (int) $matches[2] ) ) : '';
		}

		return self::store_url( $path, $context );
	}

	/**
	 * The Customizer's Additional CSS section.
	 *
	 * @return string
	 */
	private static function customizer_css_url(): string {
		return current_user_can( 'edit_css' ) ? add_query_arg( 'autofocus[section]', 'custom_css', admin_url( 'customize.php' ) ) : '';
	}

	/**
	 * The screen that edits code held in a post or its meta.
	 *
	 * @param string $post_type Post type named in the source path.
	 * @param int    $post_id   Post ID.
	 * @param string $meta_key  Meta key the code is held in, for code found in post meta.
	 *
	 * @return string
	 */
	private static function post_url( string $post_type, int $post_id, string $meta_key ): string {
		if ( 'custom_css' === $post_type ) {
			return self::customizer_css_url();
		}

		if ( 'wp_global_styles' === $post_type ) {
			return current_user_can( 'edit_theme_options' ) ? add_query_arg( 'path', '/wp_global_styles', admin_url( 'site-editor.php' ) ) : '';
		}

		// WPCode edits its snippets on a screen of its own, gated by its own capability.
		if ( 'wpcode' === $post_type ) {
			return get_post( $post_id ) && current_user_can( 'wpcode_edit_snippets' ) // phpcs:ignore WordPress.WP.Capabilities.Unknown -- registered by WPCode.
				? admin_url( sprintf( 'admin.php?page=wpcode-snippet-manager&snippet_id=%d', $post_id ) )
				: '';
		}

		if ( ! get_post( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return '';
		}

		if ( '_elementor_data' === $meta_key || 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true ) ) {
			return add_query_arg(
				[
					'post'   => $post_id,
					'action' => 'elementor',
				],
				admin_url( 'post.php' )
			);
		}

		if ( isset( self::FRONT_END_BUILDERS[ $meta_key ] ) ) {
			$permalink = get_permalink( $post_id );

			if ( $permalink ) {
				return add_query_arg( self::FRONT_END_BUILDERS[ $meta_key ][0], self::FRONT_END_BUILDERS[ $meta_key ][1], $permalink );
			}
		}

		return (string) get_edit_post_link( $post_id, 'raw' );
	}

	/**
	 * The admin page of a file-backed snippet manager that holds the original.
	 *
	 * @param string               $path    Source path.
	 * @param array<string, mixed> $context Item context.
	 *
	 * @return string
	 */
	private static function store_url( string $path, array $context ): string {
		if ( empty( $context['store'] ) || ! current_user_can( 'manage_options' ) ) {
			return '';
		}

		foreach ( Known_Stores_Collector::stores() as $store ) {
			$dir = trim( (string) ( $store['dir'] ?? '' ), '/' );

			if ( '' !== $dir && ! empty( $store['admin_page'] ) && 0 === strpos( $path, WP_CONTENT_DIR . '/' . $dir . '/' ) ) {
				return add_query_arg( 'page', (string) $store['admin_page'], admin_url( 'admin.php' ) );
			}
		}

		return '';
	}
}
