<?php
/**
 * What can be said about a discovered candidate from local evidence alone.
 *
 * The interpreter is the authority, but it may be unavailable: no cloud
 * connection, no key, or a scan run without it. The collectors still know a
 * great deal: where the code was found, who printed it, whether a page
 * emitted it, and what the code itself looks like. That is enough for a
 * usable listing and a sensible import target, marked as a guess so a
 * person, or the model, can refine it.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\UnifiedDiscovery\Collectors\Code_Heuristic;

/**
 * Deterministic classification from what the collectors recorded.
 */
class Local_Interpretation {

	/**
	 * Confidence reported for a local guess, well below anything a model returns.
	 */
	const CONFIDENCE = 0.4;

	/**
	 * Interpret one candidate.
	 *
	 * @param array<string, mixed> $candidate Candidate after reduction.
	 *
	 * @return array<string, mixed> Interpretation fields.
	 */
	public static function for_candidate( array $candidate ): array {
		$code        = (string) ( $candidate['code'] ?? '' );
		$path        = (string) ( $candidate['source_path'] ?? '' );
		$hint        = (string) ( $candidate['source_hint'] ?? '' );
		$context     = (array) ( $candidate['context'] ?? [] );
		$type        = self::declared_type( $context ) ?? self::type_of( $code );
		$source_type = self::source_type_of( $path, $hint, $context );
		$scope       = self::scope_for( $type, $source_type, $context );

		// A snippet manager that records whether its snippet is on knows
		// better than any inference; a draft it stores is inactive.
		$is_active = array_key_exists( 'is_active', $candidate )
			? (bool) $candidate['is_active']
			: false !== ( $context['theme_active'] ?? true );

		return [
			'name'          => self::name_for( $path, $hint, $context ),
			'type'          => $type,
			'source_type'   => $source_type,
			'source_name'   => self::source_name_for( $path, $hint, $context ),
			'is_active'     => ! empty( $candidate['seen_at_runtime'] ) || $is_active,
			'is_importable' => '' !== $scope,
			'import_scope'  => $scope,
			'import_notes'  => '',
			'risk_level'    => 'css' === $type ? 'low' : 'medium',
			'confidence'    => self::CONFIDENCE,
		];
	}

	/**
	 * The type a snippet manager declared for its snippet, when it is one we know.
	 *
	 * @param array<string, mixed> $context Context.
	 *
	 * @return string|null php, css, js, html or mixed; null when nothing usable was declared.
	 */
	public static function declared_type( array $context ): ?string {
		$declared = strtolower( trim( (string) ( $context['code_type'] ?? $context['codeType'] ?? '' ) ) );

		return in_array( $declared, [ 'php', 'css', 'js', 'html', 'mixed' ], true ) ? $declared : null;
	}

	/**
	 * The language of a piece of code.
	 *
	 * @param string $code Code.
	 *
	 * @return string php, css, js, html or mixed.
	 */
	public static function type_of( string $code ): string {
		$code = trim( $code );

		if ( preg_match( '/<\?php|\badd_(?:action|filter)\s*\(|\bfunction\s+\w+\s*\([^)]*\)\s*\{[^}]*\$\w+/', $code ) ) {
			return 'php';
		}

		$has_script = (bool) preg_match( '/<script\b/i', $code );
		$has_style  = (bool) preg_match( '/<style\b/i', $code );
		$has_other  = (bool) preg_match( '/<(?!\/?(?:script|style)\b)[a-z][^>]*>/i', $code );

		if ( $has_other || ( $has_script && $has_style ) ) {
			return 'html';
		}

		if ( $has_style || ( ! $has_script && self::looks_like_css( $code ) ) ) {
			return 'css';
		}

		if ( $has_script || Code_Heuristic::looks_like_code( $code ) ) {
			return 'js';
		}

		return 'mixed';
	}

	/**
	 * Whether bare code is a stylesheet rather than a script.
	 *
	 * @param string $code Code without tags.
	 *
	 * @return bool
	 */
	private static function looks_like_css( string $code ): bool {
		// Keywords, arrow functions, method calls and an object literal passed
		// to a call are all script; a selector never has a dot-call or a
		// brace straight after a parenthesis.
		if ( preg_match( '/\b(?:function|var|let|const|return|document|window|jQuery)\b|=>|\(\s*\)|\(\s*\{|\}\s*\)|\b\w+\.\w+\s*\(/', $code ) ) {
			return false;
		}

		return (bool) preg_match( '/(?:^|})\s*[^{};]+\{[^{}]*:[^{}]*\}/s', $code );
	}

	/**
	 * Where the code lives, in the interpreter's vocabulary.
	 *
	 * @param string               $path    Source path.
	 * @param string               $hint    Source hint.
	 * @param array<string, mixed> $context Context.
	 *
	 * @return string
	 */
	public static function source_type_of( string $path, string $hint, array $context ): string {
		$printed_by = (string) ( $context['printed_by'] ?? '' );

		if ( 0 === strpos( $path, 'customizer:' ) ) {
			return 'customizer';
		}

		// A file-backed snippet manager's store belongs to that plugin.
		if ( ! empty( $context['store'] ) ) {
			return 'plugin';
		}

		if ( 0 === strpos( $hint, 'server/' ) ) {
			return 'server';
		}

		if ( 'mu-plugin' === $hint || false !== strpos( $path, '/mu-plugins/' ) ) {
			return 'mu-plugin';
		}

		if ( 0 === strpos( $hint, 'child-theme' ) || 0 === strpos( $hint, 'inactive-child-theme' ) ) {
			return 'child-theme';
		}

		if ( 0 === strpos( $hint, 'theme' ) ) {
			return 'theme';
		}

		if ( 0 === strpos( $printed_by, 'plugin:' ) || 0 === strpos( $printed_by, 'mu-plugin:' ) ) {
			return 'plugin';
		}

		if ( in_array( $printed_by, [ 'theme', 'child-theme' ], true ) ) {
			return $printed_by;
		}

		if ( 0 === strpos( $path, 'runtime' ) ) {
			return 'unknown';
		}

		if ( isset( $context['block'] ) || isset( $context['widgetType'] ) || isset( $context['executeCode'] ) ) {
			return 'builder';
		}

		return 'database';
	}

	/**
	 * A short label for the listing.
	 *
	 * @param string               $path    Source path.
	 * @param string               $hint    Source hint.
	 * @param array<string, mixed> $context Context.
	 *
	 * @return string
	 */
	public static function name_for( string $path, string $hint, array $context ): string {
		$owner = self::owner_label( $context );
		$label = self::context_label( $context );

		// Snippet managers keep a title beside the code, in an option (WPCode),
		// a table (WPCodeBox) or a post; that title names the item better than
		// where it was stored.
		if ( '' !== $label && preg_match( '#^wp_options:([^/]+)#', $path, $m ) ) {
			/* translators: 1: the snippet's own title, 2: option name */
			return sprintf( __( '%1$s (option %2$s)', 'code-snippets' ), $label, $m[1] );
		}

		if ( '' !== $label && preg_match( '#^table:([^/]+)/#', $path, $m ) ) {
			/* translators: 1: the snippet's own title, 2: table name */
			return sprintf( __( '%1$s (table %2$s)', 'code-snippets' ), $label, $m[1] );
		}

		if ( preg_match( '#^wp_options:([^/]+)(?:/(.+))?$#', $path, $m ) ) {
			/* translators: 1: option name, 2: key inside the option */
			return isset( $m[2] ) ? sprintf( __( 'Option %1$s → %2$s', 'code-snippets' ), $m[1], str_replace( '/', ' › ', $m[2] ) ) : sprintf( __( 'Option %s', 'code-snippets' ), $m[1] );
		}

		if ( preg_match( '#^postmeta:([^/]+)/\d+/([^/]+)#', $path, $m ) ) {
			/* translators: 1: post title, or post type when no title is known, 2: meta key */
			return sprintf( __( '%1$s (meta %2$s)', 'code-snippets' ), (string) ( $context['post_title'] ?? $m[1] ), $m[2] );
		}

		if ( preg_match( '#^post:([^/]+)/\d+#', $path, $m ) ) {
			$where = isset( $context['block'] ) ? $context['block'] : $m[1];
			/* translators: 1: post title, 2: post type or block name */
			return sprintf( __( '%1$s (%2$s)', 'code-snippets' ), (string) ( $context['post_title'] ?? $m[1] ), $where );
		}

		if ( preg_match( '#^table:([^/]+)/([^/]+)#', $path, $m ) ) {
			/* translators: 1: table name, 2: row id */
			return sprintf( __( 'Table %1$s, row %2$s', 'code-snippets' ), $m[1], (string) ( $context['name'] ?? $m[2] ) );
		}

		if ( 0 === strpos( $path, 'runtime' ) ) {
			/* translators: %s: who printed the code */
			return sprintf( __( 'Printed on the page by %s', 'code-snippets' ), '' !== $owner ? $owner : __( 'unknown code', 'code-snippets' ) );
		}

		if ( ! empty( $context['store'] ) ) {
			/* translators: 1: the snippet's own title, 2: the snippet manager it is stored by */
			return sprintf( __( '%1$s (%2$s)', 'code-snippets' ), '' !== $label ? $label : basename( $path ), (string) $context['store'] );
		}

		if ( 0 === strpos( $path, 'customizer:' ) ) {
			return __( 'Additional CSS (Customizer)', 'code-snippets' );
		}

		if ( 'mu-plugin' === $hint && '' !== $label ) {
			return $label;
		}

		return '' !== $hint ? $hint : basename( $path );
	}

	/**
	 * A human title stored beside the code, if the collector found one.
	 *
	 * @param array<string, mixed> $context Context.
	 *
	 * @return string The title, or "" when there is none worth using.
	 */
	public static function context_label( array $context ): string {
		foreach ( [ 'title', 'name', 'label', 'post_title' ] as $key ) {
			$value = $context[ $key ] ?? '';

			if ( is_scalar( $value ) && '' !== trim( (string) $value ) && mb_strlen( (string) $value ) <= 80 ) {
				return trim( (string) $value );
			}
		}

		return '';
	}

	/**
	 * Who owns the place the code was found, as best local evidence can tell.
	 *
	 * @param string               $path    Source path.
	 * @param string               $hint    Source hint.
	 * @param array<string, mixed> $context Context.
	 *
	 * @return string
	 */
	public static function source_name_for( string $path, string $hint, array $context ): string {
		$owner = self::owner_label( $context );
		$type  = self::source_type_of( $path, $hint, $context );
		$label = [
			'customizer'  => __( 'Customizer', 'code-snippets' ),
			'server'      => __( 'Server configuration', 'code-snippets' ),
			'mu-plugin'   => __( 'Must-use plugin', 'code-snippets' ),
			'child-theme' => __( 'Child theme', 'code-snippets' ),
			'theme'       => __( 'Theme', 'code-snippets' ),
			'builder'     => __( 'Page builder', 'code-snippets' ),
			'database'    => __( 'Database', 'code-snippets' ),
			'plugin'      => __( 'Plugin', 'code-snippets' ),
			'unknown'     => __( 'Unknown', 'code-snippets' ),
		][ $type ] ?? $type;

		if ( '' !== $owner && ! in_array( $type, [ 'customizer', 'server' ], true ) ) {
			/* translators: 1: kind of source, 2: plugin or theme that printed the code */
			return sprintf( __( '%1$s (%2$s)', 'code-snippets' ), $label, $owner );
		}

		return $label;
	}

	/**
	 * The Code Snippets scope the code would import into, or empty when it should not.
	 *
	 * @param string               $type        Code type.
	 * @param string               $source_type Source type.
	 * @param array<string, mixed> $context     Context.
	 *
	 * @return string
	 */
	public static function scope_for( string $type, string $source_type, array $context ): string {
		if ( 'server' === $source_type ) {
			return '';
		}

		$footer = 'wp_footer' === ( $context['hook'] ?? '' );

		switch ( $type ) {
			case 'css':
				return 'site-css';
			case 'js':
				return $footer ? 'site-footer-js' : 'site-head-js';
			case 'php':
				return 'global';
			case 'html':
				return $footer ? 'footer-content' : 'head-content';
		}

		return '';
	}

	/**
	 * The plugin or theme a candidate's context names as its printer.
	 *
	 * @param array<string, mixed> $context Context.
	 *
	 * @return string
	 */
	private static function owner_label( array $context ): string {
		$printed_by = (string) ( $context['printed_by'] ?? '' );

		if ( preg_match( '/^(?:mu-)?plugin:(.+)$/', $printed_by, $m ) ) {
			return $m[1];
		}

		if ( ! empty( $context['store'] ) ) {
			return (string) $context['store'];
		}

		return in_array( $printed_by, [ 'theme', 'child-theme' ], true ) ? $printed_by : '';
	}
}
