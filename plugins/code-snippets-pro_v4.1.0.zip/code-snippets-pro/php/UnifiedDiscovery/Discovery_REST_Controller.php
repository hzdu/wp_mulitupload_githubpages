<?php
/**
 * REST endpoint backing the admin "Discover Code" page.
 *
 *   GET    code-snippets/v1/unified-discovery/capture-plan  ->  { token, urls: { label: url } }
 *   GET    code-snippets/v1/unified-discovery/results       ->  the last scan, if any
 *   POST   code-snippets/v1/unified-discovery/scan          ->  a fresh scan, each item marked against the last
 *   DELETE code-snippets/v1/unified-discovery/results       ->  forget the last scan
 *
 * The browser-driven capture: the page asks for a plan, fetches each URL in
 * it (each carries a single-use token, so the site renders and annotates the
 * page for capture), and posts the HTML it received along with the scan. A
 * host that refuses loopback requests still gets runtime capture that way.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\Model\Authenticated_Cloud_Connection;
use Code_Snippets\Settings\Permissions;
use Code_Snippets\UnifiedDiscovery\Collectors\Runtime_Capture_Collector;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use function Code_Snippets\code_snippets;

/**
 * Registers and serves the discovery scan route.
 */
class Discovery_REST_Controller {

	const NAMESPACE  = 'code-snippets/v1';
	const BASE_ROUTE = 'unified-discovery';

	/**
	 * The route every discovery endpoint hangs off.
	 *
	 * @return string
	 */
	public static function get_base_route(): string {
		return self::NAMESPACE . '/' . self::BASE_ROUTE;
	}

	/**
	 * Cloud connection, used to choose the classification backend.
	 *
	 * @var Authenticated_Cloud_Connection
	 */
	private Authenticated_Cloud_Connection $connection;

	/**
	 * Register routes immediately; this is instantiated during rest_api_init.
	 *
	 * @param Authenticated_Cloud_Connection $connection Cloud connection.
	 */
	public function __construct( Authenticated_Cloud_Connection $connection ) {
		$this->connection = $connection;
		$this->register_routes();
	}

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE_ROUTE . '/capture-plan',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'capture_plan' ],
				'permission_callback' => [ $this, 'permission_callback' ],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE_ROUTE . '/results',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'results' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
				[
					'methods'             => 'DELETE',
					'callback'            => [ $this, 'clear' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE_ROUTE . '/scan',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'scan' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => [
					'captures' => [
						'description' => __( 'Rendered HTML of each sample page, keyed by its label from the capture plan.', 'code-snippets' ),
						'type'        => 'object',
						'required'    => false,
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE_ROUTE . '/import',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'import' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => [
					'name'  => [ 'type' => 'string' ],
					'hash'  => [ 'type' => 'string' ],
					'code'  => [
						'type' => 'string',
						'required' => true,
					],
					'scope' => [
						'type' => 'string',
						'required' => true,
					],
				],
			]
		);
		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE_ROUTE . '/switch-off-original',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'switch_off_original' ],
				'permission_callback' => [ $this, 'permission_callback' ],
				'args'                => [
					'hash' => [
						'type'     => 'string',
						'required' => true,
					],
				],
			]
		);
	}

	/**
	 * Whether the current user may use discovery: the plugin capability, on a licensed site.
	 *
	 * The browser hides the tab on an unlicensed site; this is the check that
	 * cannot be bypassed.
	 *
	 * @param WP_REST_Request $request Incoming REST request.
	 *
	 * @return bool
	 */
	public function permission_callback( WP_REST_Request $request ): bool {
		return code_snippets()->current_user_can()
			&& Permissions::current_user_can_for_request( $request, 'create' )
			&& code_snippets()->licensing->is_licensed();
	}

	/**
	 * Import a discovered item into a real (inactive) snippet.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function import( \WP_REST_Request $request ): WP_REST_Response {
		$hash   = (string) $request->get_param( 'hash' );
		$stored = Discovery_Store::find_item( $hash );
		$code   = '' !== (string) ( $stored['import_code'] ?? '' ) ? (string) $stored['import_code'] : (string) $request->get_param( 'code' );

		$snippet = ( new Importer() )->import(
			(string) $request->get_param( 'name' ),
			$code,
			(string) $request->get_param( 'scope' ),
			(array) ( $stored['import_condition'] ?? [] )
		);

		if ( ! $snippet || ! $snippet->id ) {
			return new WP_REST_Response(
                [
					'ok' => false,
					'message' => __( 'Not importable (unsupported scope or empty code).', 'code-snippets' ),
				],
                422
            );
		}

		Discovery_Store::record_import( $hash, (int) $snippet->id );

		return new WP_REST_Response(
			[
				'ok'         => true,
				'snippet_id' => $snippet->id,
				'edit_url'   => admin_url( 'admin.php?page=edit-snippet&id=' . $snippet->id ),
				'item'       => Discovery_Store::served_item( $hash ),
			]
		);
	}

	/**
	 * Switch off the original of an imported item in the snippet manager that holds it.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error The stored scan, with the item's state read again.
	 */
	public function switch_off_original( WP_REST_Request $request ) {
		$hash = (string) $request->get_param( 'hash' );
		$item = Discovery_Store::find_item( $hash );

		if ( ! $item || ! Discovery_Store::import_of( $hash ) ) {
			return new WP_Error(
				'code_snippets_original_not_imported',
				__( 'Import this code as a snippet before turning off the original.', 'code-snippets' ),
				[ 'status' => 409 ]
			);
		}

		$switched = Original_Code::switch_off( $item );

		return is_wp_error( $switched ) ? $switched : new WP_REST_Response( Discovery_Store::get() );
	}

	/**
	 * Largest captured page accepted.
	 */
	const MAX_CAPTURE_BYTES = 3 * MB_IN_BYTES;

	/**
	 * Most captured pages accepted.
	 */
	const MAX_CAPTURES = 12;

	/**
	 * The pages to capture, each with a token that authorises its capture.
	 *
	 * @return WP_REST_Response
	 */
	public function capture_plan(): WP_REST_Response {
		$urls  = Runtime_Capture_Collector::get_sample_urls();
		$token = Runtime_Capture::arm( count( $urls ) );

		foreach ( $urls as $label => $url ) {
			$urls[ $label ] = add_query_arg( Runtime_Capture::FLAG, $token, $url );
		}

		return new WP_REST_Response(
			[
				'token' => $token,
				'urls'  => $urls,
			]
		);
	}

	/**
	 * The last scan, as stored.
	 *
	 * @return WP_REST_Response
	 */
	public function results(): WP_REST_Response {
		return new WP_REST_Response( Discovery_Store::get() );
	}

	/**
	 * Forget the last scan.
	 *
	 * @return WP_REST_Response
	 */
	public function clear(): WP_REST_Response {
		Discovery_Store::clear();

		return new WP_REST_Response( [ 'ok' => true ] );
	}

	/**
	 * Run a scan, store it, and return it with each item marked against the last scan.
	 *
	 * @param WP_REST_Request $request Request, optionally carrying captured pages.
	 *
	 * @return WP_REST_Response
	 */
	public function scan( WP_REST_Request $request ): WP_REST_Response {
		$captures = self::sanitise_captures( $request->get_param( 'captures' ), array_keys( Runtime_Capture_Collector::get_sample_urls() ) );
		$supply   = static fn( $html, $url, $label ) => $captures[ (string) $label ] ?? $html;

		if ( $captures ) {
			add_filter( 'code_snippets/discovery/rendered_html', $supply, 10, 3 );
		}

		$items = array_map(
			static fn( Discovered_Item $item ) => $item->to_array(),
			( new Discovery_Runner( $this->connection ) )->run()
		);

		if ( $captures ) {
			remove_filter( 'code_snippets/discovery/rendered_html', $supply, 10 );
		}

		$scan = Discovery_Store::save( $items, count( $captures ) );

		return new WP_REST_Response( [ 'count' => count( $items ) ] + $scan );
	}

	/**
	 * Keep only well-formed captured pages: planned labels, strings, bounded in size and number.
	 *
	 * The HTML is parsed for its inline code and never rendered or stored.
	 *
	 * @param mixed              $captures Request parameter.
	 * @param array<int, string> $allowed  Labels the plan offered; when given, any other label is dropped.
	 *
	 * @return array<string, string> Label => HTML.
	 */
	public static function sanitise_captures( $captures, array $allowed = [] ): array {
		if ( ! is_array( $captures ) ) {
			return [];
		}

		$out = [];

		foreach ( $captures as $label => $html ) {
			$label = sanitize_key( (string) $label );

			if ( '' === $label || ( $allowed && ! in_array( $label, $allowed, true ) ) ) {
				continue;
			}

			if ( ! is_string( $html ) || '' === trim( $html ) || strlen( $html ) > self::MAX_CAPTURE_BYTES ) {
				continue;
			}

			$out[ $label ] = $html;

			if ( count( $out ) >= self::MAX_CAPTURES ) {
				break;
			}
		}

		return $out;
	}
}
