<?php
/**
 * Import a discovered item into a real Code Snippets snippet.
 *
 * Closes the loop: discovery -> a managed snippet. Imports are created INACTIVE
 * so the user reviews them (and disables the original source) before enabling —
 * otherwise the code would run twice.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use Code_Snippets\Model\Snippet;
use function Code_Snippets\save_snippet;

/**
 * Create snippets from discovered items.
 */
class Importer {

	private const PHP_SCOPES = [ 'global', 'admin', 'front-end', 'single-use' ];
	private const JS_SCOPES  = [ 'site-head-js', 'site-footer-js' ];
	private const CSS_SCOPES = [ 'admin-css', 'site-css' ];

	/**
	 * Import one item.
	 *
	 * @param string               $name      Snippet name.
	 * @param string               $code      Raw discovered code.
	 * @param string               $scope     Target Code Snippets scope.
	 * @param array<string, mixed> $condition Post the snippet is limited to, if any: post_id, post_type and post_title.
	 *
	 * @return Snippet|null The saved snippet, or null if not importable.
	 */
	public function import( string $name, string $code, string $scope, array $condition = [] ): ?Snippet {
		if ( ! in_array( $scope, Snippet::get_all_scopes(), true ) || 'condition' === $scope ) {
			return null;
		}

		$code = $this->prepare_code( $code, $scope );
		if ( '' === trim( $code ) ) {
			return null;
		}

		$snippet = new Snippet();
		$snippet->name = '' !== trim( $name ) ? mb_substr( $name, 0, 250 ) : __( 'Imported snippet', 'code-snippets' );
		$snippet->desc = __( 'Imported via Unified Discovery — review, then disable the original source before activating.', 'code-snippets' );
		$snippet->code = $code;
		$snippet->scope = $scope;
		$snippet->active = false;

		if ( ! empty( $condition['post_id'] ) ) {
			$snippet->condition_id = $this->save_post_condition( $condition );
		}

		return save_snippet( $snippet );
	}

	/**
	 * Save a condition that holds on one post or page.
	 *
	 * @param array<string, mixed> $target Post ID, type and title.
	 *
	 * @return int Condition ID, or 0 when it could not be saved.
	 */
	private function save_post_condition( array $target ): int {
		$title = '' !== (string) ( $target['post_title'] ?? '' ) ? (string) $target['post_title'] : '#' . (int) $target['post_id'];

		$condition = new Snippet();
		$condition->name = sprintf(
			/* translators: %s: post title */
			__( 'Only on "%s"', 'code-snippets' ),
			$title
		);
		$condition->scope = 'condition';
		$condition->code = (string) wp_json_encode(
			[
				[
					[
						'subject'  => 'page' === ( $target['post_type'] ?? '' ) ? 'page' : 'post',
						'operator' => 'is',
						'object'   => [ (int) $target['post_id'] ],
					],
				],
			]
		);

		$saved = save_snippet( $condition );

		return $saved ? (int) $saved->id : 0;
	}

	/**
	 * Strip wrappers so the body matches what the target scope expects.
	 *
	 * @param string $code  Raw code.
	 * @param string $scope Target scope.
	 */
	private function prepare_code( string $code, string $scope ): string {
		$code = trim( $code );

		if ( in_array( $scope, self::PHP_SCOPES, true ) ) {
			$code = (string) preg_replace( '/^\s*<\?php\s*/i', '', $code );
			$code = (string) preg_replace( '/\?>\s*$/', '', $code );
		} elseif ( in_array( $scope, self::JS_SCOPES, true ) ) {
			if ( preg_match( '#^<script\b[^>]*>(.*)</script>\s*$#is', $code, $matches ) ) {
				$code = $matches[1];
			}
		} elseif ( in_array( $scope, self::CSS_SCOPES, true ) ) {
			if ( preg_match( '#^<style\b[^>]*>(.*)</style>\s*$#is', $code, $matches ) ) {
				$code = $matches[1];
			}
		}

		return trim( $code );
	}
}
