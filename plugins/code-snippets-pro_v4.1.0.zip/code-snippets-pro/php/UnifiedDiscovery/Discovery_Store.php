<?php
/**
 * Keeps the last scan, so results survive a page load and the next scan can say what changed.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

use function Code_Snippets\get_snippet;

/**
 * Persist scan results in an option and compare scans by where each piece of code lives.
 */
class Discovery_Store {

	/**
	 * Option holding the last scan. Not autoloaded: it carries every item's code.
	 */
	const OPTION = 'code_snippets_discovery_scan';

	/**
	 * The stored scan, with import links resolved, or an empty scan when none is stored.
	 *
	 * @return array<string, mixed>
	 */
	public static function get(): array {
		$stored = get_option( self::OPTION );

		// A scan that found nothing, or removed everything, is still a scan: it
		// carries what was removed and when it ran.
		if ( ! is_array( $stored ) || ! array_key_exists( 'items', $stored ) ) {
			return self::empty_scan();
		}

		return self::with_import_links( $stored );
	}

	/**
	 * Store a fresh scan, marking each item against the previous one.
	 *
	 * Identity is the location: the same location with the same code is
	 * unchanged, with different code is changed, and a location seen last
	 * time but not now is reported as no longer found. Imports are carried
	 * over by item hash.
	 *
	 * @param array<int, array<string, mixed>> $items    Items from Discovery_Item::to_array().
	 * @param int                              $captured Pages the scan captured.
	 *
	 * @return array<string, mixed> The stored scan, with import links resolved.
	 */
	public static function save( array $items, int $captured ): array {
		$previous = get_option( self::OPTION );
		$previous = is_array( $previous ) ? $previous : self::empty_scan();
		$now      = gmdate( 'c' );
		$before   = [];

		foreach ( (array) ( $previous['items'] ?? [] ) as $item ) {
			$before[ (string) ( $item['source_path'] ?? '' ) ] = $item;
		}

		$seen = [];

		foreach ( $items as &$item ) {
			$path = (string) ( $item['source_path'] ?? '' );
			$old  = $before[ $path ] ?? null;

			$seen[ $path ]     = true;
			$item['last_seen'] = $now;

			if ( null === $old ) {
				$item['change']     = 'new';
				$item['first_seen'] = $now;
			} elseif ( ( $old['checksum'] ?? '' ) !== ( $item['checksum'] ?? '' ) ) {
				$item['change']            = 'changed';
				$item['first_seen']        = (string) ( $old['first_seen'] ?? $now );
				$item['previous_checksum'] = (string) ( $old['checksum'] ?? '' );
			} else {
				$item['change']     = 'unchanged';
				$item['first_seen'] = (string) ( $old['first_seen'] ?? $now );
			}
		}

		unset( $item );

		$removed = [];

		foreach ( $before as $path => $old ) {
			if ( isset( $seen[ $path ] ) ) {
				continue;
			}

			$removed[] = [
				'hash'        => (string) ( $old['hash'] ?? '' ),
				'name'        => (string) ( $old['name'] ?? '' ),
				'source_name' => (string) ( $old['source_name'] ?? '' ),
				'source_path' => $path,
				'type'        => (string) ( $old['type'] ?? 'mixed' ),
				'last_seen'   => (string) ( $old['last_seen'] ?? $old['scan_date'] ?? '' ),
			];
		}

		$scan = [
			'scanned_at' => $now,
			'captured'   => $captured,
			'items'      => array_values( $items ),
			'removed'    => $removed,
			'imports'    => (array) ( $previous['imports'] ?? [] ),
		];

		update_option( self::OPTION, $scan, false );

		return self::with_import_links( $scan );
	}

	/**
	 * The item with the given hash in the stored scan.
	 *
	 * @param string $hash Item hash.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function find_item( string $hash ): ?array {
		if ( '' === $hash ) {
			return null;
		}

		foreach ( (array) ( get_option( self::OPTION )['items'] ?? [] ) as $item ) {
			if ( is_array( $item ) && ( $item['hash'] ?? '' ) === $hash ) {
				return $item;
			}
		}

		return null;
	}

	/**
	 * The item with the given hash as the stored scan serves it, with its import and original resolved.
	 *
	 * @param string $hash Item hash.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function served_item( string $hash ): ?array {
		foreach ( (array) self::get()['items'] as $item ) {
			if ( is_array( $item ) && ( $item['hash'] ?? '' ) === $hash ) {
				return $item;
			}
		}

		return null;
	}

	/**
	 * Remember which snippet an item became.
	 *
	 * @param string $hash       Item hash.
	 * @param int    $snippet_id Snippet created from it.
	 *
	 * @return void
	 */
	public static function record_import( string $hash, int $snippet_id ): void {
		$stored = get_option( self::OPTION );

		if ( ! is_array( $stored ) || '' === $hash ) {
			return;
		}

		$stored['imports'][ $hash ] = $snippet_id;
		update_option( self::OPTION, $stored, false );
	}

	/**
	 * Forget the stored scan.
	 *
	 * @return void
	 */
	public static function clear(): void {
		delete_option( self::OPTION );
	}

	/**
	 * The change counts of a scan.
	 *
	 * @param array<string, mixed> $scan Stored scan.
	 *
	 * @return array{new: int, changed: int, unchanged: int, removed: int}
	 */
	public static function changes( array $scan ): array {
		$counts = [
			'new'       => 0,
			'changed'   => 0,
			'unchanged' => 0,
			'removed'   => count( (array) ( $scan['removed'] ?? [] ) ),
		];

		foreach ( (array) ( $scan['items'] ?? [] ) as $item ) {
			$change = (string) ( $item['change'] ?? 'new' );

			if ( isset( $counts[ $change ] ) ) {
				++$counts[ $change ];
			}
		}

		return $counts;
	}

	/**
	 * Imported snippets that are active while the code they were imported from still runs where it was found.
	 *
	 * @return array<int, array<string, mixed>> Each with the item hash, the snippet's ID, name and edit URL, and the
	 *                                          original's name, source name, source path, edit URL and whether the
	 *                                          current user can switch it off from here.
	 */
	public static function running_twice(): array {
		$stored = get_option( self::OPTION );

		if ( ! is_array( $stored ) || empty( $stored['imports'] ) ) {
			return [];
		}

		$imports = self::resolve_imports( (array) $stored['imports'] );
		$found   = [];

		foreach ( (array) ( $stored['items'] ?? [] ) as $item ) {
			$import = $imports[ (string) ( $item['hash'] ?? '' ) ] ?? null;

			if ( ! $import || ! self::is_running_twice( $item, $import ) ) {
				continue;
			}

			$found[] = [
				'hash'             => (string) $item['hash'],
				'can_switch_off'   => Original_Code::can_switch_off( $item ),
				'snippet_id'       => $import['snippet_id'],
				'snippet_name'     => $import['name'],
				'snippet_edit_url' => $import['edit_url'],
				'name'             => (string) ( $item['name'] ?? '' ),
				'source_name'      => (string) ( $item['source_name'] ?? '' ),
				'source_path'      => (string) ( $item['source_path'] ?? '' ),
				'edit_source_url'  => Source_Links::edit_url( $item ),
			];
		}

		return $found;
	}

	/**
	 * Whether an item's imported snippet is active while the original still runs.
	 *
	 * The scan says whether the original ran; where whether it still does can
	 * be read again, it is, so disabling the original clears the warning
	 * without another scan.
	 *
	 * @param array<string, mixed> $item   Stored item.
	 * @param array<string, mixed> $import Resolved import of the item.
	 *
	 * @return bool
	 */
	private static function is_running_twice( array $item, array $import ): bool {
		if ( empty( $import['active'] ) || ( empty( $item['is_active'] ) && empty( $item['seen_at_runtime'] ) ) ) {
			return false;
		}

		return in_array( Original_Code::state( $item ), [ Original_Code::RUNNING, '' ], true );
	}

	/**
	 * The snippet an item was imported as, when it still exists.
	 *
	 * @param string $hash Item hash.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function import_of( string $hash ): ?array {
		$stored = get_option( self::OPTION );

		return self::resolve_imports( (array) ( is_array( $stored ) ? $stored['imports'] ?? [] : [] ) )[ $hash ] ?? null;
	}

	/**
	 * Resolve import records to snippets that still exist.
	 *
	 * @param array<string, int> $records Snippet IDs keyed by item hash.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function resolve_imports( array $records ): array {
		$imports = [];

		foreach ( $records as $hash => $snippet_id ) {
			$snippet = get_snippet( (int) $snippet_id );

			if ( $snippet && $snippet->id ) {
				$imports[ (string) $hash ] = [
					'snippet_id' => (int) $snippet->id,
					'name'       => $snippet->display_name,
					'edit_url'   => admin_url( 'admin.php?page=edit-snippet&id=' . (int) $snippet->id ),
					'active'     => (bool) $snippet->active,
				];
			}
		}

		return $imports;
	}

	/**
	 * Resolve import records and each item's links for the current user.
	 *
	 * @param array<string, mixed> $scan Stored scan.
	 *
	 * @return array<string, mixed>
	 */
	private static function with_import_links( array $scan ): array {
		$imports = self::resolve_imports( (array) ( $scan['imports'] ?? [] ) );

		$scan['items'] = array_map(
			static function ( array $item ) use ( $imports ): array {
				$import = $imports[ (string) ( $item['hash'] ?? '' ) ] ?? null;

				$item['edit_source_url']         = Source_Links::edit_url( $item );
				$item['running_twice']           = $import && self::is_running_twice( $item, $import );
				$item['original_state']          = $import ? Original_Code::state( $item ) : '';
				$item['can_switch_off_original'] = $import && Original_Code::can_switch_off( $item );

				return $item;
			},
			(array) ( $scan['items'] ?? [] )
		);

		$scan['imports'] = $imports;
		$scan['changes'] = self::changes( $scan );

		return $scan;
	}

	/**
	 * The shape of a scan that has not happened.
	 *
	 * @return array<string, mixed>
	 */
	private static function empty_scan(): array {
		return [
			'scanned_at' => null,
			'captured'   => 0,
			'items'      => [],
			'removed'    => [],
			'imports'    => [],
			'changes'    => [
				'new'       => 0,
				'changed'   => 0,
				'unchanged' => 0,
				'removed'   => 0,
			],
		];
	}
}
