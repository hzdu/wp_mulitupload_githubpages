<?php
/**
 * Provenance for what a captured page emitted.
 *
 * During an authorised capture, every inline script that WordPress prints
 * through its own API is tagged with where the call came from, and a manifest
 * of which plugin, theme or core registered each style and script handle is
 * appended to the page. The collector reads both back, so core's own output is
 * dropped on evidence rather than by a list of known signatures, and everything
 * else carries a "printed by" hint for the interpreter.
 *
 * @package Code_Snippets\UnifiedDiscovery
 */

namespace Code_Snippets\UnifiedDiscovery;

/**
 * Tag, describe and read back where a page's inline code came from.
 */
class Runtime_Provenance {

	const MARKER_ID    = 'cs-discovery-provenance';
	const ATTRIBUTE    = 'data-cs-origin';
	const MARKER_OPEN  = '<!--cs-origin:';
	const MARKER_CLOSE = '<!--/cs-origin-->';

	/**
	 * Output hooks whose callbacks are wrapped so that what they echo is attributed.
	 *
	 * @var array<int, string>
	 */
	const OUTPUT_HOOKS = [ 'wp_head', 'wp_body_open', 'wp_footer' ];

	/**
	 * Handles that core registers without a source file, so cannot be placed by path.
	 *
	 * @var array<int, string>
	 */
	const CORE_INLINE_HANDLES = [
		'global-styles',
		'global-styles-css-custom-properties',
		'block-style-variation-styles',
		'core-block-supports',
		'wp-emoji-styles',
		'wp-img-auto-sizes-contain',
		'wp-block-library-theme',
		'classic-theme-styles',
		'wp-block-styles',
		'wp-interactivity-router-animations',
		'admin-bar',
	];

	/**
	 * Hook functions that mark the boundary between a hook's caller and its callbacks.
	 *
	 * @var array<int, string>
	 */
	const HOOK_BOUNDARY = [ 'do_action', 'do_action_ref_array', 'apply_filters', 'apply_filters_ref_array' ];

	/**
	 * Start tagging inline scripts for the current request.
	 *
	 * @return void
	 */
	public static function hook(): void {
		add_filter( 'wp_inline_script_attributes', [ self::class, 'tag_script' ] );
		add_filter(
			'template_include',
			static function ( $template ) {
				self::wrap_output_hooks();
				return $template;
			},
			PHP_INT_MAX
		);
	}

	/**
	 * Wrap every callback on the output hooks so its output is bracketed by origin markers.
	 *
	 * Most code that reaches a page without a registered handle is echoed
	 * from a wp_head or wp_footer callback. The callback's own file says who
	 * owns it; the markers carry that to the collector. Callback ids are left
	 * as they were, so removing a callback by reference still works.
	 *
	 * @return void
	 */
	public static function wrap_output_hooks(): void {
		global $wp_filter;

		foreach ( self::OUTPUT_HOOKS as $hook ) {
			if ( empty( $wp_filter[ $hook ] ) || ! $wp_filter[ $hook ] instanceof \WP_Hook ) {
				continue;
			}

			foreach ( $wp_filter[ $hook ]->callbacks as $priority => $entries ) {
				foreach ( $entries as $id => $entry ) {
					$original = $entry['function'];
					$marker   = self::MARKER_OPEN . rawurlencode( (string) wp_json_encode( self::describe_callback( $original ) + [ 'hook' => $hook ] ) ) . '-->';

					$wp_filter[ $hook ]->callbacks[ $priority ][ $id ]['function'] = static function ( ...$args ) use ( $original, $marker ) {
						echo $marker; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- an HTML comment built from url-encoded JSON.
						$result = call_user_func_array( $original, $args );
						echo self::MARKER_CLOSE; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a fixed HTML comment.

						return $result;
					};
				}
			}
		}
	}

	/**
	 * Where a callback is defined, and a stable name for it.
	 *
	 * @param mixed $callback Anything add_action() accepts.
	 *
	 * @return array{origin: string, callback: string}
	 */
	public static function describe_callback( $callback ): array {
		$file = '';
		$name = '';

		try {
			if ( $callback instanceof \Closure ) {
				$reflection = new \ReflectionFunction( $callback );
				$file       = (string) $reflection->getFileName();
				$name       = 'closure@' . basename( $file ) . ':' . $reflection->getStartLine();
			} elseif ( is_string( $callback ) && function_exists( $callback ) ) {
				$reflection = new \ReflectionFunction( $callback );
				$file       = (string) $reflection->getFileName();
				$name       = $callback;
			} elseif ( is_array( $callback ) && 2 === count( $callback ) ) {
				$class = is_object( $callback[0] ) ? get_class( $callback[0] ) : (string) $callback[0];

				if ( method_exists( $callback[0], (string) $callback[1] ) ) {
					$reflection = new \ReflectionMethod( $callback[0], (string) $callback[1] );
					$file       = (string) $reflection->getFileName();
					$name       = $reflection->getDeclaringClass()->getName() . '::' . $reflection->getName();
				} elseif ( class_exists( $class ) ) {
					// A method name served by __call() or __callStatic() cannot be
					// reflected, but the class that answers it can, and that is
					// where the output comes from.
					$file = (string) ( new \ReflectionClass( $class ) )->getFileName();
					$name = $class . '::' . (string) $callback[1];
				}
			} elseif ( is_object( $callback ) && method_exists( $callback, '__invoke' ) ) {
				$reflection = new \ReflectionMethod( $callback, '__invoke' );
				$file       = (string) $reflection->getFileName();
				$name       = get_class( $callback ) . '::__invoke';
			}
		} catch ( \ReflectionException $e ) {
			$file = '';
		}

		return [
			'origin'   => '' !== $file ? self::classify_path( $file ) : 'core',
			'callback' => '' !== $name ? $name : 'unknown',
		];
	}

	/**
	 * The origin-marked ranges in a captured page.
	 *
	 * @param string $html Captured page.
	 *
	 * @return array<int, array{start: int, end: int, origin: string, callback: string, hook: string}> Innermost last.
	 */
	public static function marked_ranges( string $html ): array {
		$pattern = '/' . preg_quote( self::MARKER_OPEN, '/' ) . '([^>]*)-->|' . preg_quote( self::MARKER_CLOSE, '/' ) . '/';

		if ( ! preg_match_all( $pattern, $html, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER ) ) {
			return [];
		}

		$stack  = [];
		$ranges = [];

		foreach ( $matches as $match ) {
			if ( isset( $match[1] ) && '' !== $match[1][0] ) {
				$data    = json_decode( rawurldecode( $match[1][0] ), true );
				$stack[] = [
					'start'    => $match[0][1] + strlen( $match[0][0] ),
					'origin'   => (string) ( $data['origin'] ?? 'unknown' ),
					'callback' => (string) ( $data['callback'] ?? 'unknown' ),
					'hook'     => (string) ( $data['hook'] ?? '' ),
				];
			} elseif ( $stack ) {
				$open         = array_pop( $stack );
				$open['end']  = $match[0][1];
				$ranges[]     = $open;
			}
		}

		return $ranges;
	}

	/**
	 * The innermost marked range around an offset, if any.
	 *
	 * @param array<int, array{start: int, end: int, origin: string, callback: string, hook: string}> $ranges Ranges from marked_ranges().
	 * @param int                                                                                     $offset Position in the page.
	 *
	 * @return array{origin: string, callback: string, hook: string}|null
	 */
	public static function range_at( array $ranges, int $offset ): ?array {
		$best = null;

		foreach ( $ranges as $range ) {
			if ( $offset >= $range['start'] && $offset < $range['end'] && ( null === $best || $range['start'] >= $best['start'] ) ) {
				$best = $range;
			}
		}

		return $best;
	}

	/**
	 * Add the origin of the code being printed to an inline script tag.
	 *
	 * Handle-based prints (the -js-before, -js-after and -js-extra ids) are
	 * attributed through the manifest instead, because at print time their
	 * call stack is always core's.
	 *
	 * @param mixed $attributes Tag attributes.
	 *
	 * @return array<string, mixed>
	 */
	public static function tag_script( $attributes ): array {
		$attributes = is_array( $attributes ) ? $attributes : [];

		if ( preg_match( '/-js-(?:extra|before|after)$/', (string) ( $attributes['id'] ?? '' ) ) ) {
			return $attributes;
		}

		$attributes[ self::ATTRIBUTE ] = self::origin_of_caller();

		return $attributes;
	}

	/**
	 * Work out who is printing, from the call stack.
	 *
	 * The first frame outside core and outside this plugin is the author.
	 * The walk stops at the hook boundary: a theme template that calls
	 * wp_footer() is not the author of everything printed from wp_footer.
	 *
	 * @return string Origin, see classify_path().
	 */
	public static function origin_of_caller(): string {
		foreach ( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 40 ) as $frame ) { // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace
			if ( in_array( (string) ( $frame['function'] ?? '' ), self::HOOK_BOUNDARY, true ) ) {
				break;
			}

			if ( empty( $frame['file'] ) ) {
				continue;
			}

			$origin = self::classify_path( (string) $frame['file'] );

			if ( 'core' !== $origin && 'code-snippets' !== $origin ) {
				return $origin;
			}
		}

		return 'core';
	}

	/**
	 * Place a filesystem path: core, this plugin, a plugin, an mu-plugin, a theme.
	 *
	 * @param string $path Absolute path.
	 *
	 * @return string core, code-snippets, plugin:<slug>, mu-plugin:<name>, theme, child-theme,
	 *                theme:<dir> for an inactive theme, drop-in:<name>, generated, or unknown.
	 */
	public static function classify_path( string $path ): string {
		$path   = wp_normalize_path( $path );
		$places = [
			[ dirname( __DIR__, 2 ), 'code-snippets', false ],
			[ defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins', 'mu-plugin', true ],
			[ WP_PLUGIN_DIR, 'plugin', true ],
			[ get_stylesheet_directory(), get_stylesheet_directory() !== get_template_directory() ? 'child-theme' : 'theme', false ],
			[ get_template_directory(), 'theme', false ],
			[ get_theme_root(), 'theme', true ],
			[ ABSPATH . WPINC, 'core', false ],
			[ ABSPATH . 'wp-admin', 'core', false ],
		];

		foreach ( $places as list( $dir, $label, $named ) ) {
			$dir = rtrim( wp_normalize_path( (string) $dir ), '/' );

			if ( '' === $dir || 0 !== strpos( $path, $dir . '/' ) ) {
				continue;
			}

			if ( ! $named ) {
				return $label;
			}

			$first = strtok( substr( $path, strlen( $dir ) + 1 ), '/' );

			return $label . ':' . preg_replace( '/\.php$/', '', (string) $first );
		}

		$content = rtrim( wp_normalize_path( WP_CONTENT_DIR ), '/' );

		if ( 0 === strpos( $path, $content . '/' ) && false === strpos( substr( $path, strlen( $content ) + 1 ), '/' ) ) {
			return 'drop-in:' . basename( $path, '.php' );
		}

		// Anything else under wp-content is generated output (uploads, caches),
		// which is not core even though wp-content sits inside ABSPATH.
		if ( 0 === strpos( $path, $content . '/' ) ) {
			return 'generated';
		}

		if ( 0 === strpos( $path, rtrim( wp_normalize_path( ABSPATH ), '/' ) . '/' ) ) {
			return 'core';
		}

		return 'unknown';
	}

	/**
	 * Place a registered handle by the URL of its source file.
	 *
	 * @param string $handle Handle.
	 * @param mixed  $src    Registered src; false for inline-only handles.
	 *
	 * @return string Origin, see classify_path().
	 */
	public static function classify_handle( string $handle, $src ): string {
		if ( is_string( $src ) && '' !== $src ) {
			return self::classify_url( $src );
		}

		if ( in_array( $handle, self::CORE_INLINE_HANDLES, true ) || preg_match( '/^(?:wp-|core-|block-|global-styles|font-library)/', $handle ) ) {
			return 'core';
		}

		return 'unknown';
	}

	/**
	 * Place a URL the way classify_path() places a path.
	 *
	 * @param string $url Absolute or root-relative URL.
	 *
	 * @return string Origin.
	 */
	public static function classify_url( string $url ): string {
		if ( 0 === strpos( $url, '/' ) && 0 !== strpos( $url, '//' ) ) {
			$url = site_url( $url );
		}

		$bare   = preg_replace( '#^(?:https?:)?//#', '', strtok( $url, '?' ) );
		$places = [
			[ plugin_dir_url( dirname( __DIR__, 2 ) . '/code-snippets.php' ), 'code-snippets', false ],
			[ defined( 'WPMU_PLUGIN_URL' ) ? WPMU_PLUGIN_URL : content_url( 'mu-plugins' ), 'mu-plugin', true ],
			[ plugins_url(), 'plugin', true ],
			[ get_stylesheet_directory_uri(), get_stylesheet_directory() !== get_template_directory() ? 'child-theme' : 'theme', false ],
			[ get_template_directory_uri(), 'theme', false ],
			[ get_theme_root_uri(), 'theme', true ],
			[ includes_url(), 'core', false ],
			[ admin_url(), 'core', false ],
			[ content_url(), 'generated', false ],
		];

		foreach ( $places as list( $base, $label, $named ) ) {
			$base = rtrim( (string) preg_replace( '#^(?:https?:)?//#', '', (string) $base ), '/' );

			if ( '' === $base || 0 !== strpos( (string) $bare, $base . '/' ) ) {
				continue;
			}

			if ( ! $named ) {
				return $label;
			}

			return $label . ':' . strtok( substr( (string) $bare, strlen( $base ) + 1 ), '/' );
		}

		return 'external';
	}

	/**
	 * Describe every handle the current request printed.
	 *
	 * @return array{styles: array<string, string>, scripts: array<string, string>}
	 */
	public static function manifest(): array {
		$out = [
			'styles'  => [],
			'scripts' => [],
		];

		foreach ( [
			'styles' => wp_styles(),
			'scripts' => wp_scripts(),
		] as $kind => $deps ) {
			foreach ( array_slice( array_unique( array_merge( (array) $deps->done, (array) $deps->queue ) ), 0, 500 ) as $handle ) {
				if ( ! isset( $deps->registered[ $handle ] ) ) {
					continue;
				}

				$dep = $deps->registered[ $handle ];

				// A small stylesheet that core inlined has had its src cleared;
				// the file it came from is still recorded as its path.
				$path = $dep->extra['path'] ?? '';

				$out[ $kind ][ $handle ] = is_string( $path ) && '' !== $path
					? self::classify_path( $path )
					: self::classify_handle( (string) $handle, $dep->src );
			}
		}

		return $out;
	}

	/**
	 * Append the manifest to a rendered page.
	 *
	 * @param string $html Rendered page.
	 *
	 * @return string Page with the manifest embedded.
	 */
	public static function inject( string $html ): string {
		$json   = wp_json_encode( self::manifest(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES );
		$marker = '<script type="application/json" id="' . self::MARKER_ID . '">' . $json . '</script>';
		$at     = strripos( $html, '</body>' );

		return false === $at ? $html . $marker : substr_replace( $html, $marker, $at, 0 );
	}

	/**
	 * Read the manifest back out of a captured page.
	 *
	 * @param string $html Captured page.
	 *
	 * @return array{manifest: array{styles: array<string, string>, scripts: array<string, string>}, html: string}
	 */
	public static function extract( string $html ): array {
		$manifest = [
			'styles'  => [],
			'scripts' => [],
		];
		$pattern  = '#<script\b[^>]*\bid=["\']' . preg_quote( self::MARKER_ID, '#' ) . '["\'][^>]*>(.*?)</script>#is';

		if ( preg_match( $pattern, $html, $m ) ) {
			$decoded = json_decode( $m[1], true );

			if ( is_array( $decoded ) ) {
				$manifest['styles']  = array_map( 'strval', (array) ( $decoded['styles'] ?? [] ) );
				$manifest['scripts'] = array_map( 'strval', (array) ( $decoded['scripts'] ?? [] ) );
			}

			$html = (string) preg_replace( $pattern, '', $html, 1 );
		}

		return [
			'manifest' => $manifest,
			'html'     => $html,
		];
	}

	/**
	 * Decide where one inline tag came from.
	 *
	 * @param array<string, string>                                                $attributes Tag attributes, lower-cased names.
	 * @param array{styles: array<string, string>, scripts: array<string, string>} $manifest   Manifest from the same page.
	 *
	 * @return array{origin: string, handle: string, position: string}
	 */
	public static function origin_of_tag( array $attributes, array $manifest ): array {
		$id     = (string) ( $attributes['id'] ?? '' );
		$result = [
			'origin'   => 'unknown',
			'handle'   => '',
			'position' => '',
		];

		if ( 'wp-custom-css' === $id ) {
			$result['origin'] = 'customizer';
		} elseif ( preg_match( '/\bwp-fonts-local\b/', (string) ( $attributes['class'] ?? '' ) ) ) {
			$result['origin'] = 'core';
		} elseif ( preg_match( '/^(.+)-inline-css$/', $id, $m ) ) {
			$result['handle'] = $m[1];
			$result['origin'] = $manifest['styles'][ $m[1] ] ?? 'unknown';
		} elseif ( preg_match( '/^(.+)-js-(extra|before|after)$/', $id, $m ) ) {
			$result['handle']   = $m[1];
			$result['position'] = $m[2];
			$result['origin']   = 'extra' === $m[2] ? 'data' : ( $manifest['scripts'][ $m[1] ] ?? 'unknown' );
		} elseif ( isset( $attributes[ self::ATTRIBUTE ] ) ) {
			$result['origin'] = (string) $attributes[ self::ATTRIBUTE ];
		}

		return $result;
	}
}
