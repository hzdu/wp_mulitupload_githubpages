import type { SnippetSchema } from './schema/SnippetSchema'
import type { ChangelogSchema, ImageLinkSchema } from './schema/WelcomeSchema'
import type Prism from 'prismjs'
import type tinymce from 'tinymce'
import type { FeedbackConfig } from './Feedback'
import type { StatsChartViews, StatsSummary } from './Stats'
import type { Snippet } from './Snippet'
import type { SnippetView } from './SnippetView'
import type { CodeEditorInstance, EditorOption, WordPressCodeEditor } from './vendor/WordPressCodeEditor'
import type { ElementorFrontend } from './vendor/ElementorFrontend'
import type { WordPressEditor } from './vendor/WordPressEditor'

declare global {
	interface Window {
		readonly wp: {
			readonly editor?: WordPressEditor
			readonly codeEditor?: WordPressCodeEditor
			readonly hooks?: {
				addAction: (
					hookName: string,
					namespace: string,
					callback: (data: { rest_nonce?: string }) => void
				) => void
			}
		}
		codeSnippetsErrors?: string[]
		readonly pagenow?: string
		readonly ajaxurl: string
		readonly tinymce?: tinymce.EditorManager
		readonly elementorFrontend: ElementorFrontend
		readonly wpActiveEditor?: string
		code_snippets_editor_preview?: CodeEditorInstance
		readonly code_snippets_editor_settings: EditorOption[]
		CODE_SNIPPETS_PRISM?: typeof Prism
		readonly CODE_SNIPPETS?: {
			debug: boolean
			isLicensed: boolean
			safeModeRequested: boolean
			hideUpsell: boolean
			isCloudConnected: boolean
			snippetView: SnippetView
			statsChartViews: StatsChartViews
			demosSeen?: string[]
			restAPI: {
				base: string
				snippets: string
				recentlyActive: string
				conditions: string
				preview: string
				snippetView: string
				statsView: string
				demosSeen: string
				importPlugins: string
				importFiles: string
				nonce: string
				cloud: {
					token: string
					snippets: string
					bundles: string
					communityBundles: string
					auth: string
					ai: string
					aiAgent: string
				}
				revisions: string
				unifiedDiscovery: string
				search: string
			}
			urls: {
				plugin: string
				manage: string
				addNew: string
				edit: string
				stats: string
				welcome: string
				import: string
				settings: string | null
				cloud: string
				resetCloud: string
				connectCloud?: string
				demoReset: string
			}
			banner: {
				key: string
				start_datetime: { date: string, timezone_type: number, timezone: string }
				end_datetime: { date: string, timezone_type: number, timezone: string }
				text_free: string
				action_url_free: string
				action_label_free: string
				text_pro: string
				action_url_pro: string
				action_label_pro: string
			}
		}
		readonly CODE_SNIPPETS_MANAGE?: {
			snippetsList?: Snippet[]
			hasNetworkCap: boolean
			hiddenColumns: string[]
			listOrder?: string
			truncateRowValues: number | string
			snippetsPerPage: number
			typeCounts?: Record<string, number>
			cloudSearchPerPage: number
			isSafeModeActive: boolean
			bulkDownloadNonce: string
			runOnceNonce?: string
			supportsZipDownloads: boolean
			editorTheme: string
			insights?: {
				perfEnabled: boolean
				securityEnabled: boolean
				perfData: Record<string, {
					ema_ms: number
					last_ms: number
					max_ms: number
					samples: number
					updated?: number
				} | undefined>
				security: Record<string, {
					rule: string
					severity: 'high' | 'medium' | 'low'
					line: number
					excerpt: string
					title: string
					message: string
					dismissed?: boolean
				}[] | undefined>
				actionUrl: string
				rescanNonce: string
				resetPerfNonce: string
				dismissNonce: string
				returnUrl: string
			}
			aiDemo?: {
				siteName: string
			}
			previewDemo?: {
				siteName: string
				homeUrl: string
			}
		}
		readonly CODE_SNIPPETS_EDIT?: {
			snippet: SnippetSchema
			pageTitleActions: Record<string, string>
			isLicensed: boolean
			enableDownloads: boolean
			activateByDefault: boolean
			enableDescription: boolean
			editorTheme: string
			tagOptions: {
				enabled: boolean
				allowSpaces: boolean
				availableTags: string[]
			}
			descEditorOptions: {
				rows: number
				mediaButtons: boolean
			}
		}
		readonly CODE_SNIPPETS_WELCOME?: {
			hero: {
				name: string
				follow_url: string
				image_url: string
			}
			changelog: ChangelogSchema[]
			features: ImageLinkSchema[]
			partners: ImageLinkSchema[]
		}
		readonly CODE_SNIPPETS_STATS?: StatsSummary
		readonly CODE_SNIPPETS_FEEDBACK?: FeedbackConfig
	}
}
