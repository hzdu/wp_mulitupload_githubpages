
declare module 'lodash.debounce' {
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	export interface DebouncedFunc<T extends (...args: any[]) => any> {
		(...args: Parameters<T>): ReturnType<T> | undefined
		cancel: () => void
		flush: () => ReturnType<T> | undefined
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	export default function debounce<T extends (...args: any[]) => any>(
		func: T,
		wait?: number,
		options?: {
			leading?: boolean
			maxWait?: number
			trailing?: boolean
		}
	): DebouncedFunc<T>
}
