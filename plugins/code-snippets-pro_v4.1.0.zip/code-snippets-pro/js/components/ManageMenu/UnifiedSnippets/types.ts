import { __ } from '@wordpress/i18n'
import type { SnippetType } from '../../../types/Snippet'

export type DiscoveredCodeType = 'php' | 'css' | 'js' | 'html' | 'config' | 'mixed'

export type DiscoveredSourceType =
	| 'theme' | 'child-theme' | 'plugin' | 'builder' | 'core' | 'server'
	| 'customizer' | 'mu-plugin' | 'database' | 'unknown'

export type ChangeKind = 'new' | 'changed' | 'unchanged'

export type OriginalState = 'running' | 'off' | 'removed' | ''

/** One piece of code found outside Code Snippets, as the scan route returns it. */
export interface DiscoveredItem {
	/** How this item compares with the previous scan. */
	change?: ChangeKind
	first_seen?: string
	last_seen?: string
	previous_checksum?: string
	hash: string
	name: string
	code: string
	type: DiscoveredCodeType
	source_type: DiscoveredSourceType
	source_name: string
	source_path: string
	is_active: boolean
	is_importable: boolean
	import_scope: string
	import_notes: string
	risk_level: 'low' | 'medium' | 'high'
	confidence: number
	also_found_at: string[]
	seen_at_runtime: boolean
	context: Record<string, string | number | boolean>
	/** The screen that edits the original, for the current user; empty when there is none. */
	edit_source_url: string
	/** Whether the snippet imported from this item is active while the original still runs. */
	running_twice: boolean
	/** Where the original of an imported item stands now; empty when it is not imported or cannot be read again. */
	original_state: OriginalState
	/** Whether the current user can switch the original off from here. */
	can_switch_off_original: boolean
}

export interface CapturePlan {
	token: string
	urls: Record<string, string>
}

/** An item the previous scan found that this one did not. */
export interface RemovedItem {
	hash: string
	name: string
	source_name: string
	source_path: string
	type: DiscoveredCodeType
	last_seen: string
}

export interface StoredImport {
	snippet_id: number
	name: string
	edit_url: string
	active: boolean
}

export interface ChangeCounts {
	new: number
	changed: number
	unchanged: number
	removed: number
}

/** The last scan as the site keeps it, which is also what a fresh scan returns. */
export interface ScanResult {
	scanned_at: string | null
	captured: number
	items: DiscoveredItem[]
	removed: RemovedItem[]
	imports: Record<string, StoredImport>
	changes: ChangeCounts
}

/** Whether a scan had an earlier one to compare with. */
export const hasPreviousScan = (result: ScanResult): boolean =>
	0 < result.changes.unchanged + result.changes.changed + result.changes.removed

export interface ImportResult {
	ok: boolean
	snippet_id?: number
	edit_url?: string
	message?: string
	/** The imported item as the site now serves it. */
	item?: DiscoveredItem | null
}

/** Code that is already a Code Snippets snippet, found again somewhere else. */
export const isManagedItem = (item: DiscoveredItem): boolean =>
	'number' === typeof item.context.managed_snippet_id

export const isImportableItem = (item: DiscoveredItem): boolean =>
	item.is_importable && '' !== item.import_scope && !isManagedItem(item)

/** Whether the scan saw the original running where it was found. */
export const isOriginalRunning = (item: DiscoveredItem): boolean =>
	item.is_active || item.seen_at_runtime

/** Code a snippet cannot stand in for, listed so the site's custom code can be seen in one place. */
export const isViewOnlyItem = (item: DiscoveredItem): boolean =>
	!isImportableItem(item) && !isManagedItem(item)

/** The preview adds the PHP opening tag itself, as snippets never carry one; a file does. */
export const previewCodeFor = (item: Pick<DiscoveredItem, 'code' | 'type'>): string =>
	'php' === item.type ? item.code.replace(/^\s*<\?php\s*/i, '') : item.code

export const previewTypeFor = (type: DiscoveredCodeType): SnippetType => {
	switch (type) {
		case 'css':
		case 'js':
		case 'html':
			return type

		default:
			return 'php'
	}
}

const SOURCE_ORDER: DiscoveredSourceType[] = [
	'child-theme', 'theme', 'plugin', 'builder', 'database', 'mu-plugin', 'customizer', 'server', 'core', 'unknown'
]

export const sourceLabel = (type: DiscoveredSourceType): string => {
	switch (type) {
		case 'child-theme':
			return __('Child theme', 'code-snippets')
		case 'theme':
			return __('Theme', 'code-snippets')
		case 'plugin':
			return __('Plugins', 'code-snippets')
		case 'builder':
			return __('Page builders', 'code-snippets')
		case 'database':
			return __('Stored in the database', 'code-snippets')
		case 'mu-plugin':
			return __('Must-use plugins', 'code-snippets')
		case 'customizer':
			return __('Customizer', 'code-snippets')
		case 'server':
			return __('Server configuration', 'code-snippets')
		case 'core':
			return __('WordPress', 'code-snippets')
		default:
			return __('Seen on pages only', 'code-snippets')
	}
}

/** Group what was found by where it lives, in the order a site owner would look. */
export const sortBySource = (items: DiscoveredItem[]): DiscoveredItem[] =>
	items.toSorted((a, b) => SOURCE_ORDER.indexOf(a.source_type) - SOURCE_ORDER.indexOf(b.source_type))
