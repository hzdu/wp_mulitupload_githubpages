import React, { useState } from 'react'
import classnames from 'classnames'
import { __, sprintf } from '@wordpress/i18n'
import { useSnippetView } from '../../../hooks/useSnippetView'
import { ListTable } from '../../common/ListTable'
import { TableNavigation } from '../../common/ListTable/TableNavigation'
import { SnippetViewToggle } from '../../common/SnippetViewToggle'
import { SnippetCard } from '../../common/snippets/SnippetCard'
import {
	EditOriginalLink,
	Evidence,
	ImportAction,
	ImportHint,
	ItemStatus,
	PreviewButton,
	SwitchOffOriginalAction,
	TypeBadge
} from './DiscoveredItemParts'
import { isImportableItem, sourceLabel } from './types'
import type { ListTableAction, ListTableColumn } from '../../common/ListTable'
import type { DiscoveredItem } from './types'
import type { DiscoveryState } from './useDiscovery'
import type { Dispatch, ReactNode, SetStateAction } from 'react'

type BulkAction = 'import'

const BULK_ACTIONS: ListTableAction<BulkAction>[] = [
	{ key: 'import', label: __('Import (inactive)', 'code-snippets') }
]

interface ItemViewProps {
	discovery: DiscoveryState
	/** Whether there was a previous scan to compare with; without one, everything is new and saying so is noise. */
	showChanges: boolean
}

const canSelect = (discovery: DiscoveryState) => (item: DiscoveredItem): boolean =>
	isImportableItem(item) && !(item.hash in discovery.imported)

const importSelected = (discovery: DiscoveryState, items: DiscoveredItem[]) =>
	(_action: BulkAction, selected: Set<string>): Promise<void> =>
		discovery.importAll(items.filter(item => selected.has(item.hash)))

interface ItemActionsProps extends ItemViewProps {
	item: DiscoveredItem
	small?: boolean
}

const ItemActions: React.FC<ItemActionsProps> = ({ item, discovery, small }) => {
	const importError = discovery.importErrors[item.hash]
	const switchOffError = discovery.switchOffErrors[item.hash]
	const imported = discovery.imported[item.hash]

	return (
		<div className="unified-snippets-item-actions">
			<PreviewButton item={item} small={small} />
			<SwitchOffOriginalAction
				item={item}
				isSwitchingOff={discovery.switchingOff.has(item.hash)}
				small={small}
				onSwitchOff={discovered => {
					discovery.switchOffOriginal(discovered).catch(() => undefined)
				}}
			/>
			<EditOriginalLink item={item} small={small} />
			<ImportAction
				item={item}
				imported={imported}
				isImporting={discovery.importing.has(item.hash)}
				small={small}
				onImport={discovered => {
					discovery.importItem(discovered).catch(() => undefined)
				}}
			/>
			{importError && <span className="unified-snippets-chip is-inactive">{importError}</span>}
			{switchOffError && <span className="unified-snippets-chip is-inactive">{switchOffError}</span>}
			<ImportHint item={item} imported={imported} />
		</div>
	)
}

const getColumns = ({ discovery, showChanges }: ItemViewProps): ListTableColumn<DiscoveredItem>[] => [
	{
		id: 'name',
		title: __('Name', 'code-snippets'),
		isPrimary: true,
		sortedValue: item => (item.name || item.source_name).toLowerCase(),
		render: item =>
			<>
				<strong className="unified-snippets-item-name">{item.name || item.source_name}</strong>
				<span className="unified-snippets-item-source">{item.source_name}</span>
				<Evidence item={item} showChanges={showChanges} />
			</>
	},
	{
		id: 'status',
		title: __('Status', 'code-snippets'),
		render: item =>
			<>
				<ItemStatus item={item} isImported={item.hash in discovery.imported} />
				{item.import_notes && <span className="unified-snippets-item-source">{item.import_notes}</span>}
			</>
	},
	{
		id: 'type',
		title: __('Type', 'code-snippets'),
		sortedValue: item => item.type,
		render: item => <TypeBadge item={item} />
	},
	{
		id: 'source',
		title: __('Found in', 'code-snippets'),
		sortedValue: item => sourceLabel(item.source_type),
		render: item =>
			<>
				<span>{sourceLabel(item.source_type)}</span>
				<code className="unified-snippets-item-path">{item.source_path}</code>
			</>
	},
	{
		id: 'actions',
		title: <span className="screen-reader-text">{__('Actions', 'code-snippets')}</span>,
		render: item => <ItemActions item={item} discovery={discovery} showChanges={showChanges} small />
	}
]

interface DiscoveredCardProps extends ItemViewProps {
	item: DiscoveredItem
	selected: Set<string>
	setSelected: Dispatch<SetStateAction<Set<string>>>
}

const DiscoveredCard: React.FC<DiscoveredCardProps> = ({ item, discovery, showChanges, selected, setSelected }) => {
	const name = item.name || item.source_name

	return (
		<SnippetCard
			className="unified-snippets-item-card"
			isSelected={selected.has(item.hash)}
			onSelectedChange={canSelect(discovery)(item)
				? isSelected => setSelected(previous => {
					const updated = new Set(previous)

					if (isSelected) {
						updated.add(item.hash)
					} else {
						updated.delete(item.hash)
					}

					return updated
				})
				: undefined}
			selectionLabel={sprintf(
				/* translators: %s: name of the discovered code. */
				__('Select %s', 'code-snippets'),
				name
			)}
			footerStatus={<ItemStatus item={item} isImported={item.hash in discovery.imported} />}
			footer={<ItemActions item={item} discovery={discovery} showChanges={showChanges} />}
		>
			<div className="card-inner">
				<div className="snippet-card-header">
					<TypeBadge item={item} />
					<h3>{name}</h3>
				</div>

				<div className="snippet-card-meta">
					<span>{sourceLabel(item.source_type)}</span>
					{item.source_name !== sourceLabel(item.source_type) && <span>{item.source_name}</span>}
				</div>

				<code className="unified-snippets-item-path">{item.source_path}</code>
				<Evidence item={item} showChanges={showChanges} />
			</div>
		</SnippetCard>
	)
}

interface ItemsViewProps extends ItemViewProps {
	items: DiscoveredItem[]
}

interface DiscoveredCardsProps extends ItemsViewProps {
	endTableNav: (which: 'top' | 'bottom') => ReactNode
}

const DiscoveredCards: React.FC<DiscoveredCardsProps> = ({
	items,
	discovery,
	showChanges,
	endTableNav
}) => {
	const [selected, setSelected] = useState(() => new Set<string>())
	const selectable = items.filter(canSelect(discovery))
	const visibleSelected = new Set(selectable.map(item => item.hash).filter(hash => selected.has(hash)))

	return (
		<TableNavigation<string, BulkAction>
			totalItems={items.length}
			totalPages={undefined}
			currentPage={1}
			setCurrentPage={() => undefined}
			selected={visibleSelected}
			setSelected={setSelected}
			selectAllKeys={selectable.map(item => item.hash)}
			actions={BULK_ACTIONS}
			doAction={importSelected(discovery, items)}
			endTableNav={endTableNav}
		>
			<ul
				className={classnames('code-snippets-cards', 'snippets-card-grid', 'unified-snippets-item-cards', {
					'has-selection': 0 < visibleSelected.size
				})}
			>
				{items.map(item =>
					<DiscoveredCard
						key={item.hash}
						item={item}
						discovery={discovery}
						showChanges={showChanges}
						selected={selected}
						setSelected={setSelected}
					/>)}
			</ul>
		</TableNavigation>
	)
}

/**
 * What the scan found, as a table or as cards to match the rest of the plugin.
 * Only items that can be imported are selectable; the rest are listed for
 * reference and can only be previewed.
 */
export const DiscoveredItemsView: React.FC<ItemsViewProps> = ({ items, discovery, showChanges }) => {
	const { snippetView, setSnippetView } = useSnippetView()
	const endTableNav = (which: 'top' | 'bottom') =>
		'top' === which && <SnippetViewToggle snippetView={snippetView} setSnippetView={setSnippetView} />

	return (
		<div className="unified-snippets-items snippets-list-view">
			{'card' === snippetView
				? <DiscoveredCards items={items} discovery={discovery} showChanges={showChanges} endTableNav={endTableNav} />
				: <ListTable
					items={items}
					getKey={item => item.hash}
					columns={getColumns({ discovery, showChanges })}
					actions={BULK_ACTIONS}
					doAction={importSelected(discovery, items)}
					isSelectable={canSelect(discovery)}
					selectAllControl
					endTableNav={endTableNav}
					striped
					className="unified-snippets-table"
					rowClassName={item => classnames({ 'is-view-only': !isImportableItem(item) })}
					noItems={__('Nothing matches this filter.', 'code-snippets')}
				/>}
		</div>
	)
}
