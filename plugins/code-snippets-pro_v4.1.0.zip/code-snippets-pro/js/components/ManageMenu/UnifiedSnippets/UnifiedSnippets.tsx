import React, { useState } from 'react'
import classnames from 'classnames'
import { humanTimeDiff } from '@wordpress/date'
import { __, _n, sprintf } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { WithRestAPIContext } from '../../../hooks/useRestAPI'
import { isLicensed } from '../../../utils/screen'
import { fetchConstQueryParam } from '../../../utils/urls'
import { Badge } from '../../common/Badge'
import { Button } from '../../common/Button'
import { ConfirmDialog } from '../../common/ConfirmDialog'
import { UnifiedSnippetsIcon } from '../../common/icons/UnifiedSnippetsIcon'
import { Notice } from '../../common/Notice'
import { ScreenMetaSlot } from '../../common/ScreenMetaSlot'
import { UpsellPage } from '../../common/UpsellDialog'
import { DiscoveredItemsView } from './DiscoveredItemsView'
import { hasPreviousScan, isImportableItem, isManagedItem, isViewOnlyItem, sortBySource } from './types'
import { useDiscovery } from './useDiscovery'
import type { DiscoveredItem, ScanResult } from './types'
import type { DiscoveryState, ImportedSnippet } from './useDiscovery'

const isScanning = (phase: DiscoveryState['phase']): boolean =>
	'capturing' === phase || 'scanning' === phase

const welcomeStatus = ({ phase, progress, error }: DiscoveryState): string => {
	if (isScanning(phase)) {
		return progress
	}

	return error ?? __('Scanning reads your site without changing anything.', 'code-snippets')
}

interface WelcomeCardProps {
	discovery: DiscoveryState
}

const WelcomeCard: React.FC<WelcomeCardProps> = ({ discovery }) => {
	const isBusy = isScanning(discovery.phase)

	return (
		<div className="unified-snippets-empty">
			<h1 className="unified-snippets-empty__title">
				<span className="unified-snippets-empty__logo">
					<UnifiedSnippetsIcon aria-hidden="true" />
				</span>
				{__('Unified Snippets', 'code-snippets')}
			</h1>

			<p className="unified-snippets-empty__description">
				{__('Unified Snippets finds the custom code scattered across your site, in theme files, must-use plugins, other plugins’ settings, page builders and the pages your visitors receive, and brings it into one place. Each find shows where it lives and whether it runs, and importing it creates an inactive snippet for you to review before anything changes.', 'code-snippets')}
			</p>

			<Button primary large aria-busy={isBusy} disabled={isBusy} onClick={() => {
				discovery.scan().catch(() => undefined)
			}}>
				{isBusy && <Spinner />}
				{isBusy ? __('Scanning…', 'code-snippets') : __('Scan site', 'code-snippets')}
			</Button>

			<p
				role="status"
				className={classnames('unified-snippets-empty__status', { 'is-error': 'error' === discovery.phase })}
			>
				{welcomeStatus(discovery)}
			</p>
		</div>
	)
}

const FILTER_KEYS = ['running-twice', 'php', 'html', 'css', 'js', 'view-only', 'managed', 'changes'] as const

type FilterKey = typeof FILTER_KEYS[number]

const IMPORTABLE_TYPES = ['php', 'html', 'css', 'js'] as const

const isChanged = (item: DiscoveredItem): boolean =>
	'new' === item.change || 'changed' === item.change

const matchesFilter = (item: DiscoveredItem, filter: FilterKey): boolean => {
	switch (filter) {
		case 'running-twice':
			return item.running_twice
		case 'view-only':
			return isViewOnlyItem(item)
		case 'managed':
			return isManagedItem(item)
		case 'changes':
			return isChanged(item)
		default:
			return isImportableItem(item) && filter === item.type
	}
}

interface SummaryCardData {
	filter: FilterKey
	count: number
	label: string
	detail: string
}

const importableCard = (type: typeof IMPORTABLE_TYPES[number], count: number): SummaryCardData => ({
	filter: type,
	count,
	label: type.toUpperCase(),
	detail: _n('snippet ready to import', 'snippets ready to import', count, 'code-snippets')
})

const buildCards = (result: ScanResult): SummaryCardData[] => {
	const { items } = result
	const countOf = (filter: FilterKey) => items.filter(item => matchesFilter(item, filter)).length

	const cards: SummaryCardData[] = [
		{
			filter: 'running-twice',
			count: countOf('running-twice'),
			label: __('Running twice', 'code-snippets'),
			detail: __('active snippets whose original still runs', 'code-snippets')
		},
		...IMPORTABLE_TYPES.map(type => importableCard(type, countOf(type))),
		{
			filter: 'view-only',
			count: countOf('view-only'),
			label: __('View only', 'code-snippets'),
			detail: __('cannot run as a snippet', 'code-snippets')
		},
		{
			filter: 'managed',
			count: countOf('managed'),
			label: __('Already snippets', 'code-snippets'),
			detail: __('also found outside Code Snippets', 'code-snippets')
		}
	]

	if (hasPreviousScan(result)) {
		cards.push({
			filter: 'changes',
			count: countOf('changes'),
			label: __('Changed', 'code-snippets'),
			detail: __('new or changed since the previous scan', 'code-snippets')
		})
	}

	return cards.filter(card => 0 < card.count)
}

interface SummaryCardsProps {
	result: ScanResult
	filter: FilterKey | undefined
	setFilter: (filter: FilterKey | undefined) => void
}

const SummaryCards: React.FC<SummaryCardsProps> = ({ result, filter, setFilter }) =>
	<ul className="unified-snippets-stats" aria-label={__('Scan summary', 'code-snippets')}>
		{buildCards(result).map(card =>
			<li key={card.filter}>
				<button
					type="button"
					className={classnames('unified-snippets-stat', `is-${card.filter}`)}
					aria-pressed={card.filter === filter}
					onClick={() => setFilter(card.filter === filter ? undefined : card.filter)}
				>
					<span className="unified-snippets-stat__count">{card.count}</span>{' '}
					<span className="unified-snippets-stat__label">{card.label}</span>{' '}
					<span className="unified-snippets-stat__detail">{card.detail}</span>
				</button>
			</li>)}
	</ul>

interface LastScannedProps {
	at: string | null
}

const LastScanned: React.FC<LastScannedProps> = ({ at }) =>
	at
		? <time className="unified-snippets-last-scanned" dateTime={at} title={at}>
			{sprintf(
				/* translators: %s: relative time such as "3 hours ago" */
				__('Last scanned %s', 'code-snippets'),
				humanTimeDiff(at, undefined)
			)}
		</time>
		: null

interface ClearFilterProps {
	filter: FilterKey | undefined
	clearFilter: VoidFunction
}

const ClearFilter: React.FC<ClearFilterProps> = ({ filter, clearFilter }) =>
	<div className="unified-snippets-list-actions">
		{filter && <Button link onClick={clearFilter}>{__('Clear filter', 'code-snippets')}</Button>}
	</div>

interface ResetDataButtonProps {
	discovery: DiscoveryState
	disabled: boolean
}

const ResetDataButton: React.FC<ResetDataButtonProps> = ({ discovery, disabled }) => {
	const [isConfirming, setIsConfirming] = useState(false)

	return (
		<>
			<Button secondary disabled={disabled} onClick={() => setIsConfirming(true)}>
				{__('Reset data', 'code-snippets')}
			</Button>

			<ConfirmDialog
				open={isConfirming}
				title={__('Reset scan data?', 'code-snippets')}
				confirmLabel={__('Reset data', 'code-snippets')}
				onCancel={() => setIsConfirming(false)}
				onConfirm={() => {
					setIsConfirming(false)
					discovery.clear().catch(() => undefined)
				}}
			>
				<p>{__('This forgets the last scan and which items were imported from it. Snippets you have already imported are kept.', 'code-snippets')}</p>
			</ConfirmDialog>
		</>
	)
}

interface ImportedLinkProps {
	snippet?: ImportedSnippet
}

const ImportedLink: React.FC<ImportedLinkProps> = ({ snippet }) =>
	snippet
		? <a href={snippet.editUrl}>
			{sprintf(
				/* translators: %d: snippet ID */
				__('Imported as snippet #%d', 'code-snippets'),
				snippet.id
			)}
		</a>
		: null

interface RemovedListProps {
	result: ScanResult
	imported: Partial<Record<string, ImportedSnippet>>
}

const RemovedList: React.FC<RemovedListProps> = ({ result, imported }) =>
	0 < result.removed.length
		? <details className="unified-snippets-removed">
			<summary>
				{sprintf(
					/* translators: %d: number of items the previous scan found that this one did not */
					__('No longer found (%d)', 'code-snippets'),
					result.removed.length
				)}
			</summary>
			<ul className="unified-snippets-rows">
				{result.removed.map(item =>
					<li key={item.hash} className="unified-snippets-row is-managed">
						<Badge name="core" small>{item.type}</Badge>
						<div className="unified-snippets-row__body">
							<span className="unified-snippets-row__name">{item.name || item.source_name}</span>
							<span className="unified-snippets-row__source">{item.source_name}</span>
							<code className="unified-snippets-row__path">{item.source_path}</code>
						</div>
						<div className="unified-snippets-row__actions">
							<ImportedLink snippet={imported[item.hash]} />
						</div>
					</li>)}
			</ul>
		</details>
		: null

interface PageStatusProps {
	discovery: DiscoveryState
	isBusy: boolean
}

const PageStatus: React.FC<PageStatusProps> = ({ discovery, isBusy }) => {
	const { progress, error } = discovery

	return (
		<>
			{isBusy && (
				<div className="unified-snippets-status" role="status">
					<Spinner />
					<span>{progress}</span>
				</div>)}

			{error ? <Notice type="error"><p>{error}</p></Notice> : null}
		</>
	)
}

interface ResultsScreenProps {
	discovery: DiscoveryState
	result: ScanResult
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ discovery, result }) => {
	const [filter, setFilter] = useState(() => fetchConstQueryParam('filter', FILTER_KEYS))

	const isBusy = isScanning(discovery.phase)
	const { items } = result
	const visible = sortBySource(filter ? items.filter(item => matchesFilter(item, filter)) : items)

	return (
		<div className="unified-snippets-results">
			<ScreenMetaSlot />

			<div className="snippets-page-header unified-snippets-header">
				<div className="unified-snippets-header-title">
					<h1>{__('Unified Snippets', 'code-snippets')}</h1>
					<p className="unified-snippets-header-description">
						{__('Custom code found across your site, ready to bring into Code Snippets.', 'code-snippets')}
					</p>
				</div>

				<div className="unified-snippets-header-side">
					<div className="unified-snippets-header-actions">
						<ResetDataButton discovery={discovery} disabled={isBusy} />

						<Button primary disabled={isBusy} onClick={() => {
							discovery.scan().catch(() => undefined)
						}}>
							{isBusy ? __('Scanning…', 'code-snippets') : __('Scan for changes', 'code-snippets')}
						</Button>
					</div>

					<LastScanned at={result.scanned_at} />
				</div>
			</div>

			<hr className="wp-header-end" />

			<PageStatus discovery={discovery} isBusy={isBusy} />

			{!isBusy && 0 === items.length && (
				<Notice type="success">
					<p>{__('Nothing found outside Code Snippets. Your custom code is already where it belongs.', 'code-snippets')}</p>
				</Notice>)}

			{!isBusy && 0 < items.length && (
				<>
					<SummaryCards result={result} filter={filter} setFilter={setFilter} />
					<ClearFilter filter={filter} clearFilter={() => setFilter(undefined)} />
					<RemovedList result={result} imported={discovery.imported} />
					<DiscoveredItemsView items={visible} discovery={discovery} showChanges={hasPreviousScan(result)} />
				</>)}
		</div>
	)
}

const UnifiedSnippetsPage: React.FC = () => {
	const discovery = useDiscovery()
	const { phase, result } = discovery

	if ('loading' === phase) {
		return (
			<div className="unified-snippets">
				<div className="unified-snippets-status" role="status">
					<Spinner />
					<span>{__('Loading the last scan…', 'code-snippets')}</span>
				</div>
			</div>
		)
	}

	return (
		<div className="unified-snippets">
			{result?.scanned_at
				? <ResultsScreen discovery={discovery} result={result} />
				: <>
					<hr className="wp-header-end" />
					<WelcomeCard discovery={discovery} />
				</>}
		</div>
	)
}

export const UnifiedSnippets: React.FC = () =>
	isLicensed()
		? <WithRestAPIContext>
			<UnifiedSnippetsPage />
		</WithRestAPIContext>
		: <UpsellPage />
