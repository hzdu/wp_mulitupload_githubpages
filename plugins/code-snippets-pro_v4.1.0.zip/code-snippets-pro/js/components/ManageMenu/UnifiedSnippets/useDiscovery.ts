/* eslint-disable max-lines-per-function */
import { useCallback, useEffect, useState } from 'react'
import { __, sprintf } from '@wordpress/i18n'
import { unpackErrorResponse } from '../../../utils/errors'
import { capturePages, useDiscoveryClient } from './discoveryClient'
import type { DiscoveredItem, ScanResult } from './types'

export type ScanPhase = 'loading' | 'idle' | 'capturing' | 'scanning' | 'done' | 'error'

export interface ImportedSnippet {
	id: number
	editUrl: string
	active: boolean
}

export interface DiscoveryState {
	phase: ScanPhase
	/** What the page is doing right now, for the status line. */
	progress: string
	result?: ScanResult
	error?: string
	/** Items imported, keyed by item hash: remembered by the site, plus any from this session. */
	imported: Record<string, ImportedSnippet>
	/** Items whose import is in flight. */
	importing: Set<string>
	importErrors: Record<string, string>
	scan: () => Promise<void>
	clear: () => Promise<void>
	importItem: (item: DiscoveredItem) => Promise<void>
	/** Import each item in turn, so the site is never asked to save several snippets at once. */
	importAll: (items: DiscoveredItem[]) => Promise<void>
	/** Items whose original is being switched off. */
	switchingOff: Set<string>
	switchOffErrors: Record<string, string>
	switchOffOriginal: (item: DiscoveredItem) => Promise<void>
}

const describeCapture = (done: number, total: number, label: string): string =>
	sprintf(
		/* translators: 1: page number, 2: total pages, 3: page label */
		__('Capturing page %1$d of %2$d (%3$s)…', 'code-snippets'),
		done + 1,
		total,
		label
	)

const describeError = (error: unknown, fallback = __('The scan could not be completed.', 'code-snippets')): string => {
	const unpacked = unpackErrorResponse(error)
	return 'string' === typeof unpacked ? unpacked : fallback
}

const importsOf = (result: ScanResult): Record<string, ImportedSnippet> =>
	Object.fromEntries(
		Object.entries(result.imports).map(([hash, stored]) =>
			[hash, { id: stored.snippet_id, editUrl: stored.edit_url, active: stored.active }])
	)

export const useDiscovery = (): DiscoveryState => {
	const client = useDiscoveryClient()
	const [phase, setPhase] = useState<ScanPhase>('loading')
	const [progress, setProgress] = useState('')
	const [result, setResult] = useState<ScanResult>()
	const [error, setError] = useState<string>()
	const [imported, setImported] = useState<Record<string, ImportedSnippet>>({})
	const [importing, setImporting] = useState<Set<string>>(new Set())
	const [importErrors, setImportErrors] = useState<Record<string, string>>({})
	const [switchingOff, setSwitchingOff] = useState<Set<string>>(new Set())
	const [switchOffErrors, setSwitchOffErrors] = useState<Record<string, string>>({})

	const adopt = useCallback((scan: ScanResult) => {
		setResult(scan)
		setImported(previous => ({ ...previous, ...importsOf(scan) }))
		setPhase(scan.scanned_at ? 'done' : 'idle')
	}, [])

	// The site keeps the last scan, so a page load shows it without scanning again.
	useEffect(() => {
		client.results()
			.then(adopt)
			.catch(() => setPhase('idle'))
	}, [client, adopt])

	const scan = useCallback(async () => {
		setPhase('capturing')
		setError(undefined)
		setProgress(__('Preparing to capture pages…', 'code-snippets'))

		try {
			const plan = await client.capturePlan()
			const captures = await capturePages(plan, (done, total, label) => setProgress(describeCapture(done, total, label)))

			setPhase('scanning')
			setProgress(__('Scanning the site and comparing with the last scan…', 'code-snippets'))
			adopt(await client.scan(captures))
			setProgress('')
		} catch (scanError: unknown) {
			setPhase('error')
			setProgress('')
			setError(describeError(scanError))
		}
	}, [client, adopt])

	const clear = useCallback(async () => {
		setError(undefined)

		try {
			await client.clear()
			setResult(undefined)
			setImported({})
			setPhase('idle')
		} catch (clearError: unknown) {
			// The results stay on screen; only the failure to forget them is new.
			setError(describeError(clearError))
		}
	}, [client])

	const importItem = useCallback(async (item: DiscoveredItem) => {
		setImporting(previous => new Set(previous).add(item.hash))
		setImportErrors(previous => ({ ...previous, [item.hash]: '' }))

		try {
			const response = await client.importItem(item.name, item.code, item.import_scope, item.hash)

			if (!response.ok || !response.snippet_id || !response.edit_url) {
				throw new Error(response.message ?? __('Not importable.', 'code-snippets'))
			}

			setImported(previous => ({
				...previous,
				[item.hash]: { id: response.snippet_id ?? 0, editUrl: response.edit_url ?? '', active: false }
			}))

			const served = response.item

			if (served) {
				setResult(previous => previous && {
					...previous,
					items: previous.items.map(existing => existing.hash === served.hash ? served : existing)
				})
			}
		} catch (importError: unknown) {
			setImportErrors(previous => ({ ...previous, [item.hash]: describeError(importError) }))
		} finally {
			setImporting(previous => {
				const next = new Set(previous)
				next.delete(item.hash)
				return next
			})
		}
	}, [client])

	const importAll = useCallback(async (items: DiscoveredItem[]) => {
		for (const item of items) {
			await importItem(item)
		}
	}, [importItem])

	const switchOffOriginal = useCallback(async (item: DiscoveredItem) => {
		setSwitchingOff(previous => new Set(previous).add(item.hash))
		setSwitchOffErrors(previous => ({ ...previous, [item.hash]: '' }))

		try {
			adopt(await client.switchOffOriginal(item.hash))
		} catch (switchOffError: unknown) {
			setSwitchOffErrors(previous => ({ ...previous, [item.hash]: describeError(switchOffError, __('The original could not be turned off.', 'code-snippets')) }))
		} finally {
			setSwitchingOff(previous => {
				const next = new Set(previous)
				next.delete(item.hash)
				return next
			})
		}
	}, [client, adopt])

	return {
		phase,
		progress,
		result,
		error,
		imported,
		importing,
		importErrors,
		scan,
		clear,
		importItem,
		importAll,
		switchingOff,
		switchOffErrors,
		switchOffOriginal
	}
}
