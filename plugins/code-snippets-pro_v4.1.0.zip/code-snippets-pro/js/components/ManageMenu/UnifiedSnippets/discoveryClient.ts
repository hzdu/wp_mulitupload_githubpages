import { useMemo } from 'react'
import { useRestAPI } from '../../../hooks/useRestAPI'
import { REST_BASES } from '../../../utils/restAPI'
import type { CapturePlan, ImportResult, ScanResult } from './types'

export interface DiscoveryClient {
	/** The last scan the site kept, or an empty one. */
	results: () => Promise<ScanResult>
	/** Forget the last scan. */
	clear: () => Promise<{ ok: boolean }>
	/** The pages to render, each URL carrying a token that lets the site annotate the capture. */
	capturePlan: () => Promise<CapturePlan>
	/** Run the scan, handing over whatever pages the browser managed to fetch. */
	scan: (captures: Record<string, string>) => Promise<ScanResult>
	/** Create an inactive snippet from a discovered item, remembered against the item. */
	importItem: (name: string, code: string, scope: string, hash: string) => Promise<ImportResult>
	/** Switch off the original of an imported item in the snippet manager that holds it. */
	switchOffOriginal: (hash: string) => Promise<ScanResult>
}

export const useDiscoveryClient = (): DiscoveryClient => {
	const { api } = useRestAPI()

	return useMemo((): DiscoveryClient => ({
		results: () =>
			api.get<ScanResult>(`${REST_BASES.unifiedDiscovery}/results`),

		clear: () =>
			api.del<{ ok: boolean }>(`${REST_BASES.unifiedDiscovery}/results`),

		capturePlan: () =>
			api.get<CapturePlan>(`${REST_BASES.unifiedDiscovery}/capture-plan`),

		scan: captures =>
			api.post<ScanResult, { captures: Record<string, string> }>(`${REST_BASES.unifiedDiscovery}/scan`, { captures }),

		importItem: (name, code, scope, hash) =>
			api.post<ImportResult, { name: string, code: string, scope: string, hash: string }>(
				`${REST_BASES.unifiedDiscovery}/import`,
				{ name, code, scope, hash }
			),

		switchOffOriginal: hash =>
			api.post<ScanResult, { hash: string }>(`${REST_BASES.unifiedDiscovery}/switch-off-original`, { hash })
	}), [api])
}

/**
 * Visit each planned page from the browser, as a visitor would, and keep the HTML.
 *
 * Hosts often refuse the site's own loopback requests, so the browser does the
 * rendering instead. No cookies are sent: the token in the URL authorises the
 * capture, and the page captured is the one visitors see rather than an
 * administrator's view of it. A page that will not load is simply skipped.
 */
export const capturePages = async (
	plan: CapturePlan,
	onProgress: (done: number, total: number, label: string) => void
): Promise<Record<string, string>> => {
	const captures: Record<string, string> = {}
	const labels = Object.keys(plan.urls)

	for (const [index, label] of labels.entries()) {
		onProgress(index, labels.length, label)

		try {
			const response = await fetch(plan.urls[label], { credentials: 'omit', cache: 'no-store' })

			// An error page is not the page; a blocked or failed fetch is skipped like a thrown one.
			if (response.ok) {
				captures[label] = await response.text()
			}
		} catch {
			// Not captured; the scan still runs on everything else.
		}
	}

	return captures
}
