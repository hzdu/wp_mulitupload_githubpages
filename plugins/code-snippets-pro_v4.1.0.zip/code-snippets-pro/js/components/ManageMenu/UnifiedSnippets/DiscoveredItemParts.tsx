import React, { useState } from 'react'
import classnames from 'classnames'
import { __, sprintf } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { Badge } from '../../common/Badge'
import { Button } from '../../common/Button'
import { PreviewModal } from '../../common/snippets/SnippetPreviewModal'
import { isImportableItem, isManagedItem, isOriginalRunning, previewCodeFor, previewTypeFor } from './types'
import type { ImportedSnippet } from './useDiscovery'
import type { DiscoveredItem } from './types'
import type { BadgeName } from '../../common/Badge'
import type { ReactNode } from 'react'

export const badgeFor = (item: DiscoveredItem): BadgeName | undefined => {
	switch (item.type) {
		case 'php':
		case 'css':
		case 'js':
		case 'html':
			return item.type

		default:
			return undefined
	}
}

const locationCount = (item: DiscoveredItem): number =>
	item.also_found_at.length

const printedBy = (item: DiscoveredItem): string | undefined => {
	const value = item.context.printed_by
	return 'string' === typeof value && '' !== value && !value.startsWith('direct output') ? value : undefined
}

interface EvidenceProps {
	item: DiscoveredItem
	showChanges: boolean
}

export const Evidence: React.FC<EvidenceProps> = ({ item, showChanges }) => {
	const others = locationCount(item)
	const printer = printedBy(item)

	return (
		<div className="unified-snippets-row__evidence">
			{item.running_twice &&
				<span className="unified-snippets-chip is-running-twice">{__('Running twice', 'code-snippets')}</span>}

			{showChanges && 'new' === item.change
				? <span className="unified-snippets-chip is-new">{__('New', 'code-snippets')}</span>
				: null}

			{showChanges && 'changed' === item.change
				? <span className="unified-snippets-chip is-changed">{__('Changed since last scan', 'code-snippets')}</span>
				: null}

			{item.seen_at_runtime
				? <span className="unified-snippets-chip is-running">{__('Seen on a page', 'code-snippets')}</span>
				: null}

			{!item.seen_at_runtime && !item.is_active
				? <span className="unified-snippets-chip is-inactive">{__('Not running', 'code-snippets')}</span>
				: null}

			{printer
				? <span className="unified-snippets-chip">
					{sprintf(
						/* translators: %s: plugin or theme that printed the code */
						__('Printed by %s', 'code-snippets'),
						printer
					)}
				</span>
				: null}

			{0 < others
				? <span className="unified-snippets-chip">
					{sprintf(
						/* translators: %d: number of other places the same code was found */
						__('+%d more location(s)', 'code-snippets'),
						others
					)}
				</span>
				: null}

		</div>
	)
}

export interface ImportActionProps {
	item: DiscoveredItem
	imported?: ImportedSnippet
	isImporting: boolean
	onImport: (item: DiscoveredItem) => void
	small?: boolean
}

export const ImportAction: React.FC<ImportActionProps> = ({ item, imported, isImporting, onImport, small }) => {
	if (imported) {
		return (
			<span className="unified-snippets-row__imported">
				<span className="dashicons dashicons-yes" aria-hidden="true" />
				<a href={imported.editUrl}>
					{imported.active
						? sprintf(
							/* translators: %d: snippet ID */
							__('Snippet #%d (active)', 'code-snippets'),
							imported.id
						)
						: sprintf(
							/* translators: %d: snippet ID */
							__('Snippet #%d (inactive)', 'code-snippets'),
							imported.id
						)}
				</a>
			</span>
		)
	}

	if (!isImportableItem(item)) {
		return null
	}

	return (
		<Button primary small={small} disabled={isImporting} onClick={() => onImport(item)}>
			{isImporting ? <Spinner /> : null}
			{isImporting ? __('Importing…', 'code-snippets') : __('Import', 'code-snippets')}
		</Button>
	)
}

interface EditOriginalLinkProps {
	item: DiscoveredItem
	small?: boolean
}

/** Opens where the original lives, so it can be disabled or deleted there. */
export const EditOriginalLink: React.FC<EditOriginalLinkProps> = ({ item, small }) =>
	item.edit_source_url
		? <a className={classnames('button', 'button-secondary', { 'button-small': small })} href={item.edit_source_url}>
			{__('Edit original', 'code-snippets')}
		</a>
		: null

interface ImportHintProps {
	item: DiscoveredItem
	imported?: ImportedSnippet
}

interface SwitchOffOriginalActionProps {
	item: DiscoveredItem
	isSwitchingOff: boolean
	onSwitchOff: (item: DiscoveredItem) => void
	small?: boolean
}

/** Turns the original off in the snippet manager that holds it, where it can be turned back on. */
export const SwitchOffOriginalAction: React.FC<SwitchOffOriginalActionProps> = ({ item, isSwitchingOff, onSwitchOff, small }) =>
	item.can_switch_off_original
		? <Button small={small} disabled={isSwitchingOff} onClick={() => onSwitchOff(item)}>
			{isSwitchingOff && <Spinner />}
			{isSwitchingOff ? __('Turning off…', 'code-snippets') : __('Turn off original', 'code-snippets')}
		</Button>
		: null

/** What to do about the original once its code is a snippet, until both stop running together. */
export const ImportHint: React.FC<ImportHintProps> = ({ item, imported }) => {
	if (item.running_twice) {
		return (
			<span className="unified-snippets-item-hint is-warning">
				{__('The snippet is active and the original still runs, so this code runs twice. Disable the original, or deactivate the snippet.', 'code-snippets')}
			</span>
		)
	}

	if (imported && 'off' === item.original_state) {
		return (
			<span className="unified-snippets-item-hint">
				{__('The original is turned off, so only the snippet runs this code.', 'code-snippets')}
			</span>
		)
	}

	if (imported && 'removed' === item.original_state) {
		return (
			<span className="unified-snippets-item-hint">
				{__('The original has been removed, so only the snippet runs this code.', 'code-snippets')}
			</span>
		)
	}

	return imported && !imported.active && isOriginalRunning(item)
		? <span className="unified-snippets-item-hint">
			{__('Disable the original before activating the snippet, or the code will run twice.', 'code-snippets')}
		</span>
		: null
}

interface PreviewButtonProps {
	item: DiscoveredItem
	small?: boolean
}

export const PreviewButton: React.FC<PreviewButtonProps> = ({ item, small }) => {
	const [isOpen, setIsOpen] = useState(false)

	return (
		<>
			<Button secondary small={small} onClick={() => setIsOpen(true)}>
				{__('Preview', 'code-snippets')}
			</Button>

			{isOpen &&
				<PreviewModal
					title={item.name || item.source_name}
					code={previewCodeFor(item)}
					type={previewTypeFor(item.type)}
					onRequestClose={() => setIsOpen(false)}
				/>}
		</>
	)
}

interface ItemStatusProps {
	item: DiscoveredItem
	isImported?: boolean
}

interface StatusBadgeProps {
	status: 'ready' | 'imported' | 'view-only'
	children: ReactNode
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, children }) =>
	<span className={`badge small-badge unified-snippets-status-badge is-${status}`}>{children}</span>

/** Where an item stands: ready to import, already in Code Snippets, or only there to be seen. */
export const ItemStatus: React.FC<ItemStatusProps> = ({ item, isImported }) => {
	if (isManagedItem(item)) {
		return <StatusBadge status="imported">{__('Already a snippet', 'code-snippets')}</StatusBadge>
	}

	if (!isImportableItem(item)) {
		return <StatusBadge status="view-only">{__('View only', 'code-snippets')}</StatusBadge>
	}

	return isImported
		? <StatusBadge status="imported">{__('Imported', 'code-snippets')}</StatusBadge>
		: <StatusBadge status="ready">{__('Ready to import', 'code-snippets')}</StatusBadge>
}

export const TypeBadge: React.FC<Pick<ItemStatusProps, 'item'>> = ({ item }) => {
	const badge = badgeFor(item)
	return badge ? <Badge name={badge} small /> : <Badge name="core" small>{item.type}</Badge>
}
