import React, { useEffect, useState } from 'react'
import { humanTimeDiff } from '@wordpress/date'
import { __, sprintf } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { unpackErrorResponse } from '../../../utils/errors'
import { buildUrl } from '../../../utils/urls'
import { Badge } from '../../common/Badge'
import { Button } from '../../common/Button'
import { Notice } from '../../common/Notice'
import { PreviewModal } from '../../common/snippets/SnippetPreviewModal'
import { EditOriginalLink } from './DiscoveredItemParts'
import { useDiscoveryClient } from './discoveryClient'
import { isViewOnlyItem, previewCodeFor, previewTypeFor } from './types'
import type { DiscoveredItem, ScanResult } from './types'

const unifiedSnippetsUrl = (): string | undefined =>
	window.CODE_SNIPPETS?.urls.manage
		? buildUrl(window.CODE_SNIPPETS.urls.manage, { subpage: 'unified-snippets' })
		: undefined

interface ViewOnlySnippetsRowProps {
	item: DiscoveredItem
	onView: VoidFunction
}

const ViewOnlySnippetsRow: React.FC<ViewOnlySnippetsRowProps> = ({ item, onView }) =>
	<tr>
		<td className="column-name">
			<strong>{item.name || item.source_name}</strong>
			<span className="view-only-source">{item.source_name}</span>
		</td>
		<td className="column-type">
			<Badge name="core" small>{item.type}</Badge>
		</td>
		<td className="column-location">
			<code>{item.source_path}</code>
			{item.import_notes && <span className="view-only-source">{item.import_notes}</span>}
		</td>
		<td className="column-actions">
			<Button secondary small onClick={onView}>{__('Preview', 'code-snippets')}</Button>
			<EditOriginalLink item={item} small />
		</td>
	</tr>

interface ViewOnlySnippetsTableProps {
	items: DiscoveredItem[]
}

const ViewOnlySnippetsTable: React.FC<ViewOnlySnippetsTableProps> = ({ items }) => {
	const [viewing, setViewing] = useState<DiscoveredItem>()

	return (
		<>
			<table className="wp-list-table widefat striped view-only-table">
				<thead>
					<tr>
						<th scope="col" className="column-name">{__('Name', 'code-snippets')}</th>
						<th scope="col" className="column-type">{__('Type', 'code-snippets')}</th>
						<th scope="col" className="column-location">{__('Location', 'code-snippets')}</th>
						<th scope="col" className="column-actions">
							<span className="screen-reader-text">{__('Actions', 'code-snippets')}</span>
						</th>
					</tr>
				</thead>
				<tbody>
					{items.map(item =>
						<ViewOnlySnippetsRow key={item.hash} item={item} onView={() => setViewing(item)} />)}
				</tbody>
			</table>

			{viewing &&
				<PreviewModal
					title={viewing.name || viewing.source_name}
					code={previewCodeFor(viewing)}
					type={previewTypeFor(viewing.type)}
					onRequestClose={() => setViewing(undefined)}
				/>}
		</>
	)
}

interface ScanLinkProps {
	label: string
}

const ScanLink: React.FC<ScanLinkProps> = ({ label }) => {
	const url = unifiedSnippetsUrl()
	return url ? <a href={url}>{label}</a> : null
}

interface ViewOnlySnippetsListProps {
	result: ScanResult
}

const ViewOnlySnippetsList: React.FC<ViewOnlySnippetsListProps> = ({ result }) => {
	const items = result.items.filter(isViewOnlyItem)

	if (!result.scanned_at) {
		return (
			<p className="view-only-intro">
				{__('Nothing to show yet. Scan your site in Unified Snippets to list custom code that lives outside Code Snippets and cannot run as a snippet.', 'code-snippets')}
				{' '}
				<ScanLink label={__('Scan your site', 'code-snippets')} />
			</p>
		)
	}

	return (
		<>
			<p className="view-only-intro">
				{sprintf(
					/* translators: %s: relative time such as "3 hours ago" */
					__('Custom code found outside Code Snippets that cannot run as a snippet, from the scan %s. These entries are read-only.', 'code-snippets'),
					humanTimeDiff(result.scanned_at, undefined)
				)}
				{' '}
				<ScanLink label={__('Scan for changes', 'code-snippets')} />
			</p>

			{0 < items.length
				? <ViewOnlySnippetsTable items={items} />
				: <Notice type="info"><p>{__('The last scan found nothing of this kind.', 'code-snippets')}</p></Notice>}
		</>
	)
}

/**
 * Lists what the last Unified Snippets scan found that a snippet cannot stand
 * in for. The entries come from the stored scan rather than from snippets, so
 * they can be viewed but never edited, activated or exported.
 */
export const ViewOnlySnippets: React.FC = () => {
	const client = useDiscoveryClient()
	const [result, setResult] = useState<ScanResult>()
	const [error, setError] = useState<string>()

	useEffect(() => {
		client.results()
			.then(setResult)
			.catch((fetchError: unknown) => {
				const message = unpackErrorResponse(fetchError)
				setError('string' === typeof message ? message : __('The last scan could not be loaded.', 'code-snippets'))
			})
	}, [client])

	if (error) {
		return <Notice type="error"><p>{error}</p></Notice>
	}

	return result
		? <ViewOnlySnippetsList result={result} />
		: <div className="unified-snippets-status" role="status">
			<Spinner />
			<span>{__('Loading the last scan…', 'code-snippets')}</span>
		</div>
}
