/* eslint-disable max-lines-per-function */
import React, { useRef, useState } from 'react'
import { __ } from '@wordpress/i18n'
import { Spinner } from '@wordpress/components'
import { WithRestAPIContext } from '../../../hooks/useRestAPI'
import { WithSnippetsAPIContext } from '../../../hooks/useSnippetsAPI'
import { handleUnknownError } from '../../../utils/errors'
import { isCloudConnected } from '../../../utils/screen'
import { Button } from '../../common/Button'
import { Notice } from '../../common/Notice'
import { CloudConnectPrompt } from '../../common/cloud/CloudConnectPrompt'
import { ScreenMetaSlot } from '../../common/ScreenMetaSlot'
import { AiAgentIcon } from '../../common/icons/AiAgentIcon'
import { AiAgentSidebar } from './AiAgentSidebar'
import { WithAiAgentContext, useAiAgentContext } from './AiAgentContext'
import { ConversationThread } from './ConversationThread'
import { PromptBox } from './PromptBox'
import { PROMPT_PRESETS } from './PromptExamples'
import { PromptPresetDialog } from './PromptPresetDialog'
import type { PromptPreset } from './PromptExamples'

const AiAgentPage: React.FC = () => {
	const {
		generation,
		status,
		isBusy,
		isStopped,
		isSubmitting,
		isEditingSnippets,
		limitReached,
		actionError,
		pendingPrompt,
		isLoadingConversation,
		submitPrompt,
		refine,
		stop,
		newConversation
	} = useAiAgentContext()

	const [promptText, setPromptText] = useState('')
	const [chosenPreset, setChosenPreset] = useState<PromptPreset>()
	const promptRef = useRef<HTMLTextAreaElement>(null)

	const isRefine = 'plan_ready' === status

	// The composer stays on screen in every state and is disabled instead, so a
	// failed or in-flight generation never leaves the user without an input.
	const isWorking = isSubmitting || isBusy && !isStopped
	const promptDisabled = limitReached || isWorking || isLoadingConversation || isEditingSnippets

	const handleSubmit = () => {
		const text = promptText.trim()

		if ('' === text) {
			return
		}

		// Clear the box immediately; the optimistic thread shows the submitted message.
		setPromptText('')

		// Any existing conversation continues through refine — including a failed
		// one — so only the first message of a conversation creates a generation.
		const action = generation ? refine(text) : submitPrompt(text)
		action.catch(handleUnknownError)
	}

	const focusPrompt = () => {
		promptRef.current?.focus()
	}

	const sendPreset = (prompt: string) => {
		setPromptText('')
		const action = generation ? refine(prompt) : submitPrompt(prompt)
		action.catch(handleUnknownError)
	}

	const editPreset = (prompt: string) => {
		setPromptText(prompt)

		// Wait for the composer to re-render with the text before placing the caret at its end.
		requestAnimationFrame(() => {
			promptRef.current?.focus()
			promptRef.current?.setSelectionRange(prompt.length, prompt.length)
		})
	}

	return (
		<div className="ai-agent">
			<ScreenMetaSlot />

			<div className="snippets-page-header">
				<h1>{__('AI Agent', 'code-snippets')}</h1>

				<Button primary type="button" onClick={newConversation}>
					{__('New conversation', 'code-snippets')}
				</Button>
			</div>

			<hr className="wp-header-end" />

			<p className="snippets-page-description">
				{__('Describe what you want to build. The AI plans it, you review, then it creates the snippets.', 'code-snippets')}
			</p>

			<div className="ai-agent-layout">
				<div className="ai-agent-layout__main">
					{actionError ? <Notice type="error"><p>{actionError}</p></Notice> : null}

					{isLoadingConversation
						? <div className="ai-agent-loading" role="status">
							<Spinner />
							<span>{__('Loading conversation…', 'code-snippets')}</span>
						</div>
						: !generation && !pendingPrompt
							? <div className="ai-agent-empty">
								<p className="ai-agent-empty__eyebrow">
									{__('Start with these prompts', 'code-snippets')}
								</p>
								<div className="ai-agent-empty__chips">
									{PROMPT_PRESETS.map(preset =>
										<button
											key={preset.label}
											type="button"
											className="ai-agent-empty__chip"
											aria-haspopup="dialog"
											onClick={() => setChosenPreset(preset)}
										>
											{preset.label}
										</button>)}
								</div>
							</div>
							: <ConversationThread onRefine={focusPrompt} />}

					<PromptBox
						value={promptText}
						onChange={setPromptText}
						onSubmit={handleSubmit}
						onStop={stop}
						inputRef={promptRef}
						disabled={promptDisabled}
						busy={isWorking}
						submitLabel={__('Send', 'code-snippets')}
						placeholder={isRefine
							? __('What would you like to change about this plan?', 'code-snippets')
							: __('Describe what you want to build…', 'code-snippets')}
					/>
				</div>

				<div className="ai-agent-layout__sidebar">
					<AiAgentSidebar onPickExample={setChosenPreset} />
				</div>
			</div>

			{chosenPreset &&
				<PromptPresetDialog
					preset={chosenPreset}
					canSend={!limitReached && !isWorking && !isLoadingConversation}
					onCancel={() => setChosenPreset(undefined)}
					onEdit={() => {
						setChosenPreset(undefined)
						editPreset(chosenPreset.prompt)
					}}
					onSend={() => {
						setChosenPreset(undefined)
						sendPreset(chosenPreset.prompt)
					}}
				/>}
		</div>
	)
}

const AiAgentConnectPrompt: React.FC = () =>
	<CloudConnectPrompt
		title={__('AI Agent', 'code-snippets')}
		Icon={AiAgentIcon}
		description={
			__('Describe what you want to build. The AI plans it, you review, then it creates the snippets.', 'code-snippets')
		}
		message={__('Connect to Code Snippets Cloud to use the AI Agent.', 'code-snippets')}
	/>

export const AiAgent: React.FC = () =>
	isCloudConnected()
		? <WithRestAPIContext>
			<WithSnippetsAPIContext>
				<WithAiAgentContext>
					<AiAgentPage />
				</WithAiAgentContext>
			</WithSnippetsAPIContext>
		</WithRestAPIContext>
		: <AiAgentConnectPrompt />
