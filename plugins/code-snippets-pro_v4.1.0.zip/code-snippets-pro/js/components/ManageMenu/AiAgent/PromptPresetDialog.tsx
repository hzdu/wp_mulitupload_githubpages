import React from 'react'
import { __ } from '@wordpress/i18n'
import { Flex, Modal } from '@wordpress/components'
import { Button } from '../../common/Button'
import type { PromptPreset } from './PromptExamples'

export interface PromptPresetDialogProps {
	preset: PromptPreset
	/** False while a message cannot be sent, such as during a generation; editing stays available. */
	canSend: boolean
	onSend: VoidFunction
	onEdit: VoidFunction
	onCancel: VoidFunction
}

/**
 * Picking a preset never sends it straight away: the full prompt is shown
 * first, so the user can send it as written, change it first, or go back.
 */
export const PromptPresetDialog: React.FC<PromptPresetDialogProps> = ({ preset, canSend, onSend, onEdit, onCancel }) =>
	<Modal
		title={preset.label}
		onRequestClose={onCancel}
		closeButtonLabel={__('Close dialog', 'code-snippets')}
		className="ai-agent-preset-dialog"
	>
		<p className="ai-agent-preset-dialog__prompt">{preset.prompt}</p>

		<Flex direction="row" justify="flex-end">
			<Button type="button" onClick={onCancel}>{__('Go back', 'code-snippets')}</Button>
			<Button secondary type="button" onClick={onEdit}>{__('Edit before sending', 'code-snippets')}</Button>
			<Button primary type="button" disabled={!canSend} onClick={onSend}>{__('Send prompt', 'code-snippets')}</Button>
		</Flex>
	</Modal>
