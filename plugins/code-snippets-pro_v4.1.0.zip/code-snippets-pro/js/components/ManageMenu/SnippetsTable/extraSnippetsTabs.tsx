import React from 'react'
import { __ } from '@wordpress/i18n'
import { isLicensed } from '../../../utils/screen'
import { ViewOnlySnippets } from '../UnifiedSnippets/ViewOnlySnippets'
import type { ReactNode } from 'react'

export interface ExtraSnippetsTab {
	/** The `type` query value that opens the tab. */
	name: string
	label: string
	title: string
	/** Shown before the label, as the type badges are on the snippet type tabs. */
	badge?: ReactNode
	Content: React.FC
	isAvailable: () => boolean
}

/**
 * Read-only tabs shown after the snippet types. They list something other than
 * snippets, so the snippet filters, bulk actions and Add Snippet do not apply.
 */
export const EXTRA_SNIPPETS_TABS: ExtraSnippetsTab[] = [
	{
		name: 'view-only',
		label: __('View Only', 'code-snippets'),
		title: __('View Only – Unified Snippets', 'code-snippets'),
		badge:
			<span className="badge view-only-badge">
				<span className="dashicons dashicons-visibility" aria-hidden="true" />
			</span>,
		Content: ViewOnlySnippets,
		isAvailable: isLicensed
	}
]
