import { humanTimeDiff } from '@wordpress/date'
import { RawHTML } from '@wordpress/element'
import { __, sprintf } from '@wordpress/i18n'
import React, { Fragment, useState } from 'react'
import { useSnippetsAPI } from '../../../hooks/useSnippetsAPI'
import { useSnippetsList } from '../../../hooks/useSnippetsList'
import { CloudSyncState, getSnippetCloudSyncState } from '../../../types/CloudSyncState'
import { handleUnknownError } from '../../../utils/errors'
import { isNetworkAdmin } from '../../../utils/screen'
import { getSnippetDisplayName, getSnippetEditUrl, getSnippetType } from '../../../utils/snippets/snippets'
import { getRunOnceNonce } from '../../../utils/restAPI'
import { buildUrl, fetchQueryParam } from '../../../utils/urls'
import { Badge } from '../../common/Badge'
import { CloudIcon } from '../../common/cloud/CloudIcon'
import { SnippetPriorityInput } from '../../common/snippets/SnippetPriorityInput'
import { Tooltip } from '../../common/Tooltip'
import { RowActions } from './RowActions'
import { useFilteredSnippets } from './WithFilteredSnippetsContext'
import { useSnippetsFilters } from './WithSnippetsTableFilters'
import { InsightsModal } from './InsightsModal'
import type { Key } from 'react'
import type { Snippet } from '../../../types/Snippet'
import type { ListTableColumn } from '../../common/ListTable'

interface ColumnProps {
	snippet: Snippet
}

const runOnceUrl = (snippet: Snippet, nonce: string): string =>
	buildUrl(window.location.href, {
		action: 'run-once',
		snippet: snippet.id,
		network: snippet.network ? 'true' : 'false',
		_wpnonce: nonce
	})

// The rendered link carries the nonce from page load. Before any navigation
// starts, whether a click, a middle-click or "open in new tab", the href is
// rebuilt from the nonce the Heartbeat has refreshed since, so a page left open
// still works.
const RunOnceButton: React.FC<ColumnProps> = ({ snippet }) =>
	<a
		className="snippet-execution-button"
		title={__('Run Once', 'code-snippets')}
		href={runOnceUrl(snippet, window.CODE_SNIPPETS_MANAGE?.runOnceNonce ?? '')}
		onMouseDown={event => {
			event.currentTarget.href = runOnceUrl(snippet, getRunOnceNonce())
		}}
		onClick={event => {
			event.preventDefault()
			window.location.assign(runOnceUrl(snippet, getRunOnceNonce()))
		}}
	>
		<span className="screen-reader-text">{__('Run Once', 'code-snippets')}</span>
		<span aria-hidden="true">&nbsp;</span>
	</a>

const ActivationSwitch: React.FC<ColumnProps> = ({ snippet }) => {
	const { activate, deactivate } = useSnippetsAPI()
	const { refreshSnippetsList } = useSnippetsList()

	const actionText = snippet.network && !snippet.shared_network
		? snippet.active ? __('Network Deactivate', 'code-snippets') : __('Network Activate', 'code-snippets')
		: snippet.active ? __('Deactivate', 'code-snippets') : __('Activate', 'code-snippets')

	return (
		<input
			id={`snippet-${snippet.id}-switch`}
			type="checkbox"
			role="switch"
			checked={snippet.active}
			aria-checked={snippet.active}
			className="switch"
			title={actionText}
			aria-label={actionText}
			onChange={() => {
				(snippet.active ? deactivate(snippet) : activate(snippet))
					.then(refreshSnippetsList)
					.catch(handleUnknownError)
			}}
		/>
	)
}

export const ActivateColumn: React.FC<ColumnProps> = ({ snippet }) => {
	const { activeByCondition } = useFilteredSnippets()

	if (snippet.trashed) {
		return ''
	}

	switch (snippet.scope) {
		case 'single-use':
			return <RunOnceButton snippet={snippet} />

		case 'condition':
			return (
				<a className="snippet-condition-count" href={getSnippetEditUrl(snippet)}>
					{activeByCondition.get(snippet.id)?.length ?? 0}
				</a>
			)

		default:
			return <ActivationSwitch snippet={snippet} />
	}
}

interface SnippetExtraIconsProps extends ColumnProps {
	showCloudSync?: boolean
}

export const SnippetExtraIcons: React.FC<SnippetExtraIconsProps> = ({
	snippet,
	showCloudSync = true
}) =>
	<div className="extra-icons">
		{snippet.locked && (
			<Tooltip
				inline
				end
				label={__('About snippet lock', 'code-snippets')}
				icon={<span className="dashicons dashicons-lock" aria-hidden="true"></span>}
			>
				{__('This snippet is locked and cannot be modified.', 'code-snippets')}
			</Tooltip>)}

		{showCloudSync && getSnippetCloudSyncState(snippet) !== CloudSyncState.Unsynced &&
		<CloudIcon state={getSnippetCloudSyncState(snippet)} />}
	</div>

export const isSecureSnippet = (snippet: Snippet): boolean => {
	const insights = window.CODE_SNIPPETS_MANAGE?.insights
	if (!insights || !insights.securityEnabled || 'php' !== getSnippetType(snippet)) {
		return false
	}

	return 0 === (insights.security[String(snippet.id)] ?? []).length
}

export interface SecureStatusProps extends ColumnProps {
	/** Open the tooltip towards the start, for a status shown at the end of a row. */
	start?: boolean
}

export const SecureStatus: React.FC<SecureStatusProps> = ({ snippet, start }) =>
	isSecureSnippet(snippet)
		? <Tooltip
			inline
			start={start}
			className="snippet-secure-status"
			label={__('Secure snippet', 'code-snippets')}
			icon={
				<svg
					aria-hidden="true"
					focusable="false"
					height="16"
					viewBox="0 0 24 24"
					width="16"
					xmlns="http://www.w3.org/2000/svg"
				>
					<path
						d="M11.46 20.846A12 12 0 0 1 3.5 6A12 12 0 0 0 12 3a12 12 0 0 0 8.5 3a12 12 0 0 1-.09 7.06M15 19l2 2l4-4"
						fill="none"
						stroke="currentColor"
						strokeLinecap="round"
						strokeLinejoin="round"
						strokeWidth="2"
					/>
				</svg>
			}
		>
			{__('Secure snippet', 'code-snippets')}
		</Tooltip>
		: null

interface SnippetNameProps extends ColumnProps {
	showSecure?: boolean
}

export const SnippetName: React.FC<SnippetNameProps> = ({ snippet, showSecure = true }) =>
	<span className="snippet-name-group">
		{!snippet.trashed && (isNetworkAdmin() || !snippet.network || window.CODE_SNIPPETS_MANAGE?.hasNetworkCap)
			? <a
				href={getSnippetEditUrl(snippet)}
				className="snippet-name"
				title={getSnippetDisplayName(snippet)}
			>
				{getSnippetDisplayName(snippet)}
			</a>
			: <span className="snippet-name" title={getSnippetDisplayName(snippet)}>
				{getSnippetDisplayName(snippet)}
			</span>}

		{showSecure && <SecureStatus snippet={snippet} />}
		{snippet.shared_network && <span className="badge">{__('Shared on Network', 'code-snippets')}</span>}
	</span>

const NameColumn: React.FC<ColumnProps> = ({ snippet }) =>
	<>
		<SnippetExtraIcons snippet={snippet} />
		<SnippetName snippet={snippet} showSecure={false} />
		<RowActions snippet={snippet} />
	</>

export const TypeColumn: React.FC<ColumnProps> = ({ snippet }) => {
	const { setCurrentType } = useSnippetsFilters()
	const type = getSnippetType(snippet)

	return (
		<a
			href={buildUrl(window.location.href, { type })}
			onClick={event => {
				event.preventDefault()
				setCurrentType(type)
			}}
		>
			<Badge name={type} />
		</a>
	)
}

export const TagsColumn: React.FC<ColumnProps> = ({ snippet }) =>
	snippet.tags.map((tag, index) =>
		<Fragment key={tag}>
			<a key={tag} href={buildUrl(window.location.href, { tag })}>
				{tag}
			</a>
			{index < snippet.tags.length - 1 ? ', ' : ''}
		</Fragment>)

export const DateColumn: React.FC<ColumnProps> = ({ snippet }) =>
	snippet.modified
		? <span className="modified-column-content" title={snippet.modified}>
			<time dateTime={snippet.modified}>
				{humanTimeDiff(snippet.modified, undefined)}
			</time>
		</span>
		: <>&#8212;</>

export const PriorityColumn: React.FC<ColumnProps> = ({ snippet }) =>
	<SnippetPriorityInput snippet={snippet} />

export const getAuthorDisplayName = (snippet: Snippet): string =>
	(snippet.updatedBy ?? snippet.createdBy)?.displayName ?? ''

const AuthorColumn: React.FC<ColumnProps> = ({ snippet }) => {
	const creator = snippet.createdBy
	const updater = snippet.updatedBy
	const primary = updater ?? creator

	if (!primary) {
		return <span className="snippet-author is-unknown">&#8212;</span>
	}

	const tooltip = creator && updater && creator.id !== updater.id
		? sprintf(__('Created by %1$s · Last edited by %2$s', 'code-snippets'), creator.displayName, updater.displayName)
		: creator
			? sprintf(__('Created by %s', 'code-snippets'), creator.displayName)
			: sprintf(__('Last edited by %s', 'code-snippets'), primary.displayName)

	return (
		<span className="snippet-author" title={tooltip}>
			{primary.avatarUrl &&
				<img className="snippet-author__avatar" src={primary.avatarUrl} alt="" width={20} height={20} />}
			<span className="snippet-author__name">{primary.displayName}</span>
		</span>
	)
}

const MS_DECIMAL_CUTOFF = 10
const MS_THRESHOLD_WARN = 50
const MS_THRESHOLD_DANGER = 200

type Severity = 'high' | 'medium' | 'low'

const worstSeverity = (findings: { severity: Severity, dismissed?: boolean }[]): Severity | null =>
	findings
		.filter(f => !f.dismissed)
		.reduce<Severity | null>((acc, f) => {
			if ('high' === acc) {return acc}
			if ('high' === f.severity) {return 'high'}
			if ('medium' === f.severity) {return 'medium'}
			return acc ?? 'low'
		}, null)

const perfTint = (emaMs: number | undefined): string =>
	undefined === emaMs ? ''
		: emaMs > MS_THRESHOLD_DANGER ? 'is-danger'
			: emaMs > MS_THRESHOLD_WARN ? 'is-warn' : ''

const severityLabel = (sev: Severity): string =>
	'high' === sev ? __('high', 'code-snippets')
		: 'medium' === sev ? __('med', 'code-snippets')
			: __('low', 'code-snippets')

interface InsightsPillsProps {
	perf: { ema_ms: number, samples: number } | undefined
	openCount: number
	worst: Severity | null
	totalFindings: number
}

const InsightsPills: React.FC<InsightsPillsProps> = ({ perf, openCount, worst, totalFindings }) => <>
	{perf && 0 < perf.samples && (
		<span className={`cs-insights-pill cs-insights-pill--perf ${perfTint(perf.ema_ms)}`}>
			{perf.ema_ms < MS_DECIMAL_CUTOFF ? perf.ema_ms.toFixed(1) : Math.round(perf.ema_ms)}ms
		</span>
	)}
	{worst && (
		<span className={`cs-insights-pill cs-insights-pill--${worst}`}>
			{openCount} {severityLabel(worst)}
		</span>
	)}
	{!worst && 0 < totalFindings && (
		<span className="cs-insights-pill cs-insights-pill--muted">
			{__('all dismissed', 'code-snippets')}
		</span>
	)}
</>

/**
 * Whether a snippet has anything worth showing in its insights: perf samples
 * or security findings. The affirmative secure status is rendered beside the
 * snippet title so it does not consume the card's right-side action gutter.
 */
export const hasSnippetInsights = (snippet: Snippet): boolean => {
	const insights = window.CODE_SNIPPETS_MANAGE?.insights
	if (!insights) {return false}

	const perf = insights.perfData[String(snippet.id)]
	const findings = insights.security[String(snippet.id)] ?? []

	return 0 < (perf?.samples ?? 0) ||
		0 < findings.length
}

interface InsightsColumnProps extends ColumnProps {
	/** Render a clickable em-dash when there is no data. Cards opt out of this. */
	showEmptyPlaceholder?: boolean
	/** Cards render the Secure badge beside this column and must not duplicate it. */
	showSecure?: boolean
}

export const InsightsColumn: React.FC<InsightsColumnProps> = ({ snippet, showEmptyPlaceholder = true, showSecure = true }) => {
	const [open, setOpen] = useState(() => String(snippet.id) === fetchQueryParam('insights'))
	const insights = window.CODE_SNIPPETS_MANAGE?.insights
	if (!insights) {return null}

	const perf = insights.perfData[String(snippet.id)]
	const findings = insights.security[String(snippet.id)] ?? []
	const openCount = findings.filter(f => !f.dismissed).length
	const worst = worstSeverity(findings)
	const secure = showSecure && isSecureSnippet(snippet)
	const modal = open && <InsightsModal snippet={snippet} onClose={() => setOpen(false)} />

	if (!hasSnippetInsights(snippet) && !secure) {
		if (!showEmptyPlaceholder) {
			return null
		}

		return (
			<button
				type="button"
				className="cs-insights-trigger is-empty"
				onClick={() => setOpen(true)}
				aria-label={__('Open snippet insights', 'code-snippets')}
				title={__('No data yet — open to see why', 'code-snippets')}
			>
				—
				{modal}
			</button>
		)
	}

	return <>
		<span className="cs-insights-statuses">
			{secure && <SecureStatus snippet={snippet} start />}
			{hasSnippetInsights(snippet) && <button
				type="button"
				className="cs-insights-trigger"
				onClick={() => setOpen(true)}
				aria-label={__('Open snippet insights', 'code-snippets')}
			>
				<InsightsPills perf={perf} openCount={openCount} worst={worst} totalFindings={findings.length} />
			</button>}
		</span>
		{modal}
	</>
}

const baseTableColumns: ListTableColumn<Snippet>[] = [
	{
		id: 'activate',
		title: <span className="screen-reader-text">{__('Activate', 'code-snippets')}</span>,
		render: snippet => <ActivateColumn snippet={snippet} />
	},
	{
		id: 'id',
		title: __('ID', 'code-snippets'),
		sortedValue: snippet => snippet.id,
		render: snippet => snippet.id
	},
	{
		id: 'name',
		title: __('Name', 'code-snippets'),
		isPrimary: true,
		sortedValue: snippet => getSnippetDisplayName(snippet).toLowerCase(),
		render: snippet => <NameColumn snippet={snippet} />
	},
	{
		id: 'type',
		title: __('Type', 'code-snippets'),
		sortedValue: snippet => getSnippetType(snippet),
		render: snippet => <TypeColumn snippet={snippet} />
	},
	{
		id: 'desc',
		title: __('Description', 'code-snippets'),
		render: snippet => <div className="snippet-description-content"><RawHTML>{snippet.desc}</RawHTML></div>
	},
	{
		id: 'tags',
		title: __('Tags', 'code-snippets'),
		render: snippet => <TagsColumn snippet={snippet} />
	},
	{
		id: 'date',
		title: __('Modified', 'code-snippets'),
		sortedValue: snippet => snippet.modified ? new Date(snippet.modified).toISOString() : '',
		render: snippet => <DateColumn snippet={snippet} />
	},
	{
		id: 'priority',
		title: __('Priority', 'code-snippets'),
		sortedValue: snippet => snippet.priority,
		render: snippet => <SnippetPriorityInput snippet={snippet} />
	},
	{
		id: 'author',
		title: __('Author', 'code-snippets'),
		sortedValue: snippet => getAuthorDisplayName(snippet).toLowerCase(),
		render: snippet => <AuthorColumn snippet={snippet} />
	},
	{
		id: 'insights',
		title: __('Insights', 'code-snippets'),
		render: snippet => <InsightsColumn snippet={snippet} />
	}
]

export const getTableColumns = (hiddenColumns: Set<Key>): ListTableColumn<Snippet>[] =>
	baseTableColumns.map(column => ({ ...column, isHidden: hiddenColumns.has(column.id) }))
