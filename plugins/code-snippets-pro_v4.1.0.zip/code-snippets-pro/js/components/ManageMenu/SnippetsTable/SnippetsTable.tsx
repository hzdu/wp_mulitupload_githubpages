import { __, sprintf } from '@wordpress/i18n'
import { createInterpolateElement } from '@wordpress/element'
import React, { useCallback, useMemo, useState } from 'react'
import classnames from 'classnames'
import { useHorizontalScrollOverflow } from '../../../hooks/useHorizontalScrollOverflow'
import { WithRestAPIContext } from '../../../hooks/useRestAPI'
import { useSnippetView } from '../../../hooks/useSnippetView'
import { WithSnippetsAPIContext } from '../../../hooks/useSnippetsAPI'
import { WithSnippetsListContext, useSnippetsList } from '../../../hooks/useSnippetsList'
import { SNIPPET_TYPES } from '../../../types/Snippet'
import { isLicensed } from '../../../utils/screen'
import { SNIPPET_TYPE_LABELS, getSnippetAddNewUrl, getSnippetType, isProType } from '../../../utils/snippets/snippets'
import { buildUrl, fetchQueryParam, updateQueryParams } from '../../../utils/urls'
import { Badge } from '../../common/Badge'
import { Notice } from '../../common/Notice'
import { ScreenMetaSlot } from '../../common/ScreenMetaSlot'
import { UpsellPage } from '../../common/UpsellDialog'
import { WithSnippetsTableFilters, useSnippetsFilters } from './WithSnippetsTableFilters'
import { WithFilteredSnippetsContext } from './WithFilteredSnippetsContext'
import { SnippetsListTable } from './SnippetsListTable'
import { EXTRA_SNIPPETS_TABS } from './extraSnippetsTabs'
import type { SnippetType } from '../../../types/Snippet'
import type { ExtraSnippetsTab } from './extraSnippetsTabs'

interface SnippetTypeTabProps {
	type?: SnippetType
	count?: number
	isExtraTabActive: boolean
	onSelect: VoidFunction
}

const SnippetTypeTab: React.FC<SnippetTypeTabProps> = ({ type, count, isExtraTabActive, onSelect }) => {
	const { currentType, setCurrentType } = useSnippetsFilters()
	const tabName = type ?? 'all'

	const isActive = !isExtraTabActive && type === currentType
	const isProLocked = type && isProType(type) && !isLicensed()

	return (
		<li>
			<a
				href={buildUrl(window.location.href, { type: tabName })}
				className={classnames('snippet-type-link', `${tabName}-type-link`, {
					'active-type': isActive,
					'pro-locked-type': isProLocked && !isActive
				})}
				aria-current={isActive ? 'page' : undefined}
				onClick={event => {
					event.preventDefault()
					setCurrentType(type)
					onSelect()
				}}
			>
				{type && <Badge name={type} />}
				<span className={classnames(`${tabName}-label`, 'snippet-type-name')}>
					{type
						? SNIPPET_TYPE_LABELS[type]
						: <>
							<span className="snippet-type-name-full">{__('All Snippets', 'code-snippets')}</span>
							<span className="snippet-type-name-short">{__('All', 'code-snippets')}</span>
						</>}
				</span>
				{count !== undefined && !isProLocked && <span className="subnav-count">{count}</span>}
				{isProLocked && <span className="pro-chip">{__('Pro', 'code-snippets')}</span>}
			</a>
		</li>
	)
}

interface ExtraTabLinkProps {
	tab: ExtraSnippetsTab
	isActive: boolean
	onSelect: VoidFunction
}

const ExtraTabLink: React.FC<ExtraTabLinkProps> = ({ tab, isActive, onSelect }) =>
	<li>
		<a
			href={buildUrl(window.location.href, { type: tab.name })}
			className={classnames('snippet-type-link', `${tab.name}-type-link`, { 'active-type': isActive })}
			aria-current={isActive ? 'page' : undefined}
			onClick={event => {
				event.preventDefault()
				onSelect()
			}}
		>
			{tab.badge}
			<span className={classnames(`${tab.name}-label`, 'snippet-type-name')}>{tab.label}</span>
		</a>
	</li>

interface ExtraTabsState {
	tabs: ExtraSnippetsTab[]
	extraTab: ExtraSnippetsTab | undefined
	selectExtraTab: (tab: ExtraSnippetsTab) => void
	clearExtraTab: VoidFunction
}

const useExtraTab = (): ExtraTabsState => {
	const tabs = useMemo(() => EXTRA_SNIPPETS_TABS.filter(tab => tab.isAvailable()), [])
	const [extraTab, setExtraTab] = useState(() => tabs.find(tab => tab.name === fetchQueryParam('type')))

	const selectExtraTab = useCallback((tab: ExtraSnippetsTab) => {
		setExtraTab(tab)
		updateQueryParams({ type: tab.name })
	}, [])

	return { tabs, extraTab, selectExtraTab, clearExtraTab: useCallback(() => setExtraTab(undefined), []) }
}

const getUrlWithoutSafeMode = (): string => {
	const url = new URL(window.location.href)
	url.searchParams.delete('snippets-safe-mode')
	return url.toString()
}

const SafeModeNotice = () =>
	window.CODE_SNIPPETS_MANAGE?.isSafeModeActive
		? <Notice type="error">
			<p>
				<strong>{__('Warning:', 'code-snippets')}</strong>{'\n'}
				{__('Safe mode is active and snippets will not execute!', 'code-snippets')}{'\n'}

				{window.CODE_SNIPPETS?.safeModeRequested
					? createInterpolateElement(
						__('It was turned on for this visit with <code>snippets-safe-mode</code> in the address. <a>Leave safe mode</a>.', 'code-snippets'),
						{
							code: <code />,
							// eslint-disable-next-line jsx-a11y/anchor-has-content, jsx-a11y/control-has-associated-label
							a: <a href={getUrlWithoutSafeMode()} />
						}
					)
					: createInterpolateElement(
						__('Remove the <code>CODE_SNIPPETS_SAFE_MODE</code> constant from <code>wp-config.php</code> file to turn off safe mode.', 'code-snippets'),
						{
							code: <code />
						}
					)}{'\n'}

				<a href="https://codesnippets.pro/doc/safe-mode" target="_blank" rel="noreferrer">
					{__('Read more', 'code-snippets')}
				</a>
			</p>
		</Notice>
		: null

// Counts render immediately from localized values, then switch to live values.
const useSnippetTypeCounts = () => {
	const { snippetsList } = useSnippetsList()

	const countedSnippets = useMemo(
		() => snippetsList?.filter(snippet => !snippet.trashed),
		[snippetsList]
	)

	const typeCounts = useMemo(
		() => countedSnippets?.reduce((counts, snippet) => {
			const type = getSnippetType(snippet)
			return counts.set(type, (counts.get(type) ?? 0) + 1)
		}, new Map<SnippetType, number>()),
		[countedSnippets]
	)

	const localized = window.CODE_SNIPPETS_MANAGE?.typeCounts

	const getCount = useCallback(
		(type?: SnippetType) => countedSnippets
			? type ? typeCounts?.get(type) ?? 0 : countedSnippets.length
			: localized?.[type ?? 'all'],
		[countedSnippets, typeCounts, localized]
	)

	return { getCount }
}

interface SnippetTypesNavProps {
	extraTabs: ExtraTabsState
}

const SnippetTypesNav: React.FC<SnippetTypesNavProps> = ({ extraTabs: { tabs, extraTab, selectExtraTab, clearExtraTab } }) => {
	const { getCount } = useSnippetTypeCounts()
	const { atStart, atEnd, scrollRef } = useHorizontalScrollOverflow()

	return (
		<div
			className={classnames('snippet-type-nav-wrapper', {
				'has-scroll-start': !atStart,
				'has-scroll-end': !atEnd
			})}
		>
			<nav
				ref={scrollRef}
				className="snippet-type-nav"
				aria-label={__('Snippet types', 'code-snippets')}
			>
				<ul>
					<SnippetTypeTab count={getCount()} isExtraTabActive={!!extraTab} onSelect={clearExtraTab} />

					{SNIPPET_TYPES.map(type =>
						<SnippetTypeTab
							key={type}
							type={type}
							count={getCount(type)}
							isExtraTabActive={!!extraTab}
							onSelect={clearExtraTab}
						/>)}

					{tabs.map(tab =>
						<ExtraTabLink
							key={tab.name}
							tab={tab}
							isActive={tab === extraTab}
							onSelect={() => selectExtraTab(tab)}
						/>)}
				</ul>
			</nav>
		</div>
	)
}

interface ExtraTabPageProps {
	tab: ExtraSnippetsTab
}

const ExtraTabPage: React.FC<ExtraTabPageProps> = ({ tab: { title, Content } }) =>
	<>
		<ScreenMetaSlot />

		<div className="snippets-page-header">
			<h1>{title}</h1>
		</div>

		<hr className="wp-header-end" />

		<Content />
	</>

const LocalSnippetsPage = () => {
	const { snippetView, setSnippetView } = useSnippetView()
	const { currentType } = useSnippetsFilters()

	return (
		<>
			<div className="snippets-page-header">
				<h1>{sprintf(
					// translators: %s: label of the currently selected snippet type.
					__('Local Snippets: %s', 'code-snippets'),
					currentType ? SNIPPET_TYPE_LABELS[currentType] : __('All Snippets', 'code-snippets')
				)}</h1>
				<a href={getSnippetAddNewUrl(currentType)} className="button button-primary">
					{__('Add Snippet', 'code-snippets')}
				</a>
			</div>

			<hr className="wp-header-end" />

			<SafeModeNotice />

			<WithFilteredSnippetsContext>
				<SnippetsListTable snippetView={snippetView} setSnippetView={setSnippetView} />
			</WithFilteredSnippetsContext>
		</>
	)
}

const SnippetsTableInner = () => {
	const { currentType } = useSnippetsFilters()
	const extraTabs = useExtraTab()
	const { extraTab } = extraTabs

	const isUpsell = !!currentType && !isLicensed() && isProType(currentType)

	return (
		<>
			<SnippetTypesNav extraTabs={extraTabs} />
			<ScreenMetaSlot hidden={isUpsell} />

			{isUpsell
				? <UpsellPage />
				: <>
					{extraTab
						? <ExtraTabPage tab={extraTab} />
						: <LocalSnippetsPage />}
				</>}
		</>
	)
}

export const SnippetsTable: React.FC = () =>
	<WithRestAPIContext>
		<WithSnippetsAPIContext>
			<WithSnippetsListContext>
				<WithSnippetsTableFilters>
					<SnippetsTableInner />
				</WithSnippetsTableFilters>
			</WithSnippetsListContext>
		</WithSnippetsAPIContext>
	</WithRestAPIContext>
