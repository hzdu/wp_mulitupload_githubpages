import React, { useId } from 'react'
import { Spinner } from '@wordpress/components'
import { __ } from '@wordpress/i18n'
import Select from 'react-select'
import { usePreviewTargets } from '../../../../hooks/usePreviewTargets'
import { useSnippetPreview } from '../../../../hooks/useSnippetPreview'
import { isCondition } from '../../../../utils/snippets/snippets'
import { Button } from '../../../common/Button'
import { useSnippetForm } from '../../SnippetForm/WithSnippetFormContext'
import type { StylesConfig } from 'react-select'
import type { PreviewTargetGroups } from '../../../../hooks/usePreviewTargets'
import type { PreviewType } from '../../../../utils/snippets/preview'
import type { SelectGroup, SelectOption } from '../../../../types/SelectOption'

const PREVIEW_TYPE_LABELS: Record<PreviewType, string> = {
	front: __('Front page', 'code-snippets'),
	post: __('Posts', 'code-snippets'),
	page: __('Pages', 'code-snippets'),
	admin: __('Admin pages', 'code-snippets')
}

const selectStyles: StylesConfig<SelectOption<string>, false, SelectGroup<string>> = {
	menu: provided => ({ ...provided, zIndex: 9999 }),
	input: provided => ({ ...provided, ':focus': { boxShadow: 'none' } })
}

const findTarget = (groups: PreviewTargetGroups, url: string | undefined) =>
	groups.flatMap(group => group.options).find(option => option.value === url) ?? null

interface PreviewTargetInputProps {
	type: PreviewType
	targetUrl: string | undefined
	onChange: (url: string) => void
	isDisabled: boolean
}

const PreviewTargetInput: React.FC<PreviewTargetInputProps> = ({ type, targetUrl, onChange, isDisabled }) => {
	const inputId = useId()
	const { groups, isLoading, error } = usePreviewTargets(type)

	return (
		<div className="block-form-field">
			<label htmlFor={inputId}>{__('Preview target', 'code-snippets')}</label>

			<Select<SelectOption<string>, false, SelectGroup<string>>
				inputId={inputId}
				className="code-snippets-select snippet-preview-target-select"
				options={groups}
				value={findTarget(groups, targetUrl)}
				isLoading={isLoading}
				isDisabled={isDisabled}
				isSearchable
				maxMenuHeight={280}
				styles={selectStyles}
				placeholder={__('Search by name…', 'code-snippets')}
				noOptionsMessage={() => error ?? __('Nothing found.', 'code-snippets')}
				onChange={option => option && onChange(option.value)}
			/>
		</div>
	)
}

interface PreviewTypeInputProps {
	availableTypes: PreviewType[]
	type: PreviewType | undefined
	onChange: (type: PreviewType) => void
	isDisabled: boolean
}

const PreviewTypeInput: React.FC<PreviewTypeInputProps> = ({ availableTypes, type, onChange, isDisabled }) => {
	const inputId = useId()

	const options: SelectOption<PreviewType>[] = availableTypes.map(value => ({
		key: value,
		value,
		label: PREVIEW_TYPE_LABELS[value]
	}))

	return (
		<div className="block-form-field">
			<label htmlFor={inputId}>{__('Preview Type', 'code-snippets')}</label>

			<Select
				inputId={inputId}
				className="code-snippets-select snippet-preview-type-select"
				options={options}
				value={options.find(option => option.value === type) ?? null}
				isSearchable={false}
				isDisabled={isDisabled}
				placeholder={__('Choose where to preview…', 'code-snippets')}
				styles={{ menu: provided => ({ ...provided, zIndex: 9999 }) }}
				onChange={option => option && onChange(option.value)}
			/>
		</div>
	)
}

export const SnippetPreview: React.FC = () => {
	const { snippet, isReadOnly } = useSnippetForm()
	const { availableTypes, type, targetUrl, selectType, selectTarget, canPreview, isUpdating, openPreview } = useSnippetPreview()
	const headingId = useId()

	if (isCondition(snippet)) {
		return null
	}

	return (
		<section className="snippet-editor-sidebar-settings snippet-preview" aria-labelledby={headingId}>
			<h2 id={headingId} className="snippet-preview-heading">{__('Preview Snippet', 'code-snippets')}</h2>

			<PreviewTypeInput availableTypes={availableTypes} type={type} onChange={selectType} isDisabled={isReadOnly} />

			{type && 'front' !== type &&
				<PreviewTargetInput
					key={type}
					type={type}
					targetUrl={targetUrl}
					onChange={selectTarget}
					isDisabled={isReadOnly}
				/>}

			<Button
				large
				className="snippet-preview-button"
				disabled={!canPreview || isUpdating}
				onClick={openPreview}
			>
				{isUpdating
					? <><Spinner />{__('Updating…', 'code-snippets')}</>
					: __('Preview', 'code-snippets')}
			</Button>
		</section>
	)
}
