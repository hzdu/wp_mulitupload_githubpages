// The preview monitor bundles this module into pages that load no WordPress scripts,
// so it must not import anything at runtime.
import type { SnippetScope } from '../../types/Snippet'

export type PreviewType = 'front' | 'post' | 'page' | 'admin'

/** Message the editor sends an open preview tab just before reloading it with a new draft. */
export const PREVIEW_UPDATING_MESSAGE = 'code-snippets-preview-updating'

const FRONT_END_TYPES: PreviewType[] = ['front', 'post', 'page']

/**
 * Retrieve the kinds of page a snippet can visibly run on, given where it is set to run.
 */
export const getPreviewTypesForScope = (scope: SnippetScope): PreviewType[] => {
	switch (scope) {
		case 'admin':
		case 'admin-css':
			return ['admin']

		case 'global':
		case 'single-use':
			return [...FRONT_END_TYPES, 'admin']

		default:
			return FRONT_END_TYPES
	}
}

export const isPreviewType = (value: unknown): value is PreviewType =>
	'front' === value || 'post' === value || 'page' === value || 'admin' === value
