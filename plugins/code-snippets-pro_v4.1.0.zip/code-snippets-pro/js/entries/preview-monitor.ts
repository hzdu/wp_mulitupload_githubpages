import { PREVIEW_UPDATING_MESSAGE } from '../utils/snippets/preview'

declare global {
	interface Window {
		codeSnippetsPreviewMonitor?: {
			source?: string
			updatingLabel?: string
		}
		__codeSnippetsPreviewMonitorLoaded?: boolean
	}
}

interface LogEntry {
	level: 'error' | 'warn'
	message: string
	stack: string
}

interface MonitorElements {
	errorsBadge: HTMLElement
	warningsBadge: HTMLElement
	empty: HTMLElement
	log: HTMLElement
	toggle: HTMLButtonElement
	copy: HTMLButtonElement
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
	null !== value && 'object' === typeof value

const getStringField = (value: unknown, field: string): string => {
	if (!isRecord(value)) {
		return ''
	}
	return 'string' === typeof value[field] ? value[field] : ''
}

const stringify = (value: unknown): string => {
	if (null === value || undefined === value) {
		return ''
	}
	if ('string' === typeof value) {
		return value
	}
	if ('number' === typeof value || 'boolean' === typeof value || 'bigint' === typeof value) {
		return String(value)
	}
	if ('symbol' === typeof value) {
		return value.toString()
	}
	if ('function' === typeof value) {
		return '[function]'
	}
	if (value instanceof Error) {
		return value.message
	}
	if (isRecord(value)) {
		try {
			return JSON.stringify(value)
		} catch {
			return '[object]'
		}
	}
	return '[object]'
}

const getSource = (): string =>
	window.codeSnippetsPreviewMonitor?.source ?? ''

const ensureRoot = (): HTMLElement => {
	const existing = document.getElementById('code-snippets-preview-log')
	if (existing) {
		return existing
	}

	const root = document.createElement('div')
	root.id = 'code-snippets-preview-log'
	root.innerHTML =
		'<div class="csp-card">' +
			'<div class="csp-head">' +
				'<div class="csp-title">Snippet Preview Log</div>' +
				'<div class="csp-badges">' +
					'<span class="csp-badge error" data-csp-errors>0 errors</span>' +
					'<span class="csp-badge warn" data-csp-warns>0 warnings</span>' +
				'</div>' +
				'<div class="csp-actions">' +
					'<button type="button" data-csp-toggle>Details</button>' +
					'<button type="button" data-csp-copy>Copy</button>' +
				'</div>' +
			'</div>' +
			'<div class="csp-body">' +
				'<div class="csp-empty" data-csp-empty>No snippet-related warnings or errors captured yet.</div>' +
				'<pre data-csp-log></pre>' +
			'</div>' +
			'</div>'

	document.documentElement.appendChild(root)
	return root
}

const getElements = (root: HTMLElement): MonitorElements => {
	const errorsBadge = root.querySelector<HTMLElement>('[data-csp-errors]')
	const warningsBadge = root.querySelector<HTMLElement>('[data-csp-warns]')
	const empty = root.querySelector<HTMLElement>('[data-csp-empty]')
	const log = root.querySelector<HTMLElement>('[data-csp-log]')
	const toggle = root.querySelector<HTMLButtonElement>('[data-csp-toggle]')
	const copy = root.querySelector<HTMLButtonElement>('[data-csp-copy]')

	if (!errorsBadge || !warningsBadge || !empty || !log || !toggle || !copy) {
		throw new Error('Code Snippets Preview monitor: missing elements')
	}

	return { errorsBadge, warningsBadge, empty, log, toggle, copy }
}

const isRelevantStack = (source: string, stack: string): boolean =>
	'' !== source && stack.includes(source)

const toText = (entry: LogEntry): string => {
	let out = `[${entry.level.toUpperCase()}] ${entry.message}`
	if ('' !== entry.stack) {
		out += `\n${entry.stack}`
	}
	return out
}

const render = (state: { errors: LogEntry[]; warnings: LogEntry[] }, elements: MonitorElements) => {
	const errorsCount = state.errors.length
	const warningsCount = state.warnings.length

	elements.errorsBadge.textContent = `${errorsCount}${1 === errorsCount ? ' error' : ' errors'}`
	elements.warningsBadge.textContent = `${warningsCount}${1 === warningsCount ? ' warning' : ' warnings'}`

	const combined = state.errors.concat(state.warnings)
	if (0 === combined.length) {
		elements.empty.style.display = 'block'
		elements.log.textContent = ''
		return
	}

	elements.empty.style.display = 'none'
	elements.log.textContent = combined.map(toText).join('\n\n')
}

const addEntry = (
	state: { errors: LogEntry[]; warnings: LogEntry[] },
	elements: MonitorElements,
	level: LogEntry['level'],
	message: unknown,
	stack: unknown
) => {
	const entry: LogEntry = {
		level,
		message: stringify(message),
		stack: stringify(stack)
	}

	if ('error' === level) {
		state.errors.push(entry)
	}
	if ('warn' === level) {
		state.warnings.push(entry)
	}

	render(state, elements)
}

const captureConsole = (source: string, state: { errors: LogEntry[]; warnings: LogEntry[] }, elements: MonitorElements) => {
	const consoleMethods = <const>['error', 'warn']
	consoleMethods.forEach(method => {
		const original: (...args: unknown[]) => void = console[method].bind(console)

		console[method] = (...args: unknown[]) => {
			const err = new Error()
			const stack = err.stack ?? ''

			if (isRelevantStack(source, stack)) {
				addEntry(state, elements, method, args.map(stringify).join(' '), stack)
			}

			original(...args)
		}
	})
}

const captureWindowError = (source: string, state: { errors: LogEntry[]; warnings: LogEntry[] }, elements: MonitorElements) => {
	window.addEventListener(
		'error',
		(event: ErrorEvent) => {
			const stack = event.error instanceof Error ? event.error.stack ?? '' : ''
			const filename = event.filename
			const message = '' !== event.message ? event.message : 'Script error'
			const fileMatches = '' !== source && filename.includes(source)

			if (fileMatches || isRelevantStack(source, stack)) {
				addEntry(state, elements, 'error', message, stack)
			}
		},
		true
	)
}

const captureUnhandledRejection = (source: string, state: { errors: LogEntry[]; warnings: LogEntry[] }, elements: MonitorElements) => {
	window.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
		const reason = <unknown>event.reason
		const stack = reason instanceof Error ? reason.stack ?? '' : getStringField(reason, 'stack')
		const primaryMessage = reason instanceof Error ? reason.message : getStringField(reason, 'message')
		const message = '' !== primaryMessage ? primaryMessage : stringify(reason)

		if (isRelevantStack(source, stack)) {
			addEntry(state, elements, 'error', '' !== message ? message : 'Unhandled promise rejection', stack)
		}
	})
}

const copyText = async (text: string): Promise<boolean> => {
	try {
		await navigator.clipboard.writeText(text)
		return true
	} catch {
		return false
	}
}

const setupButtons = (root: HTMLElement, state: { errors: LogEntry[]; warnings: LogEntry[] }, elements: MonitorElements) => {
	elements.toggle.addEventListener('click', () => {
		root.classList.toggle('expanded')
	})

	elements.copy.addEventListener('click', () => {
		const text = elements.log.textContent ?? ''

		const handleCopy = async () => {
			const ok = await copyText(text)
			if (!ok) {
				window.prompt('Copy snippet preview log:', text)
			}
		}

		void handleCopy()
	})

	render(state, elements)
}

/** Cover the page while the editor saves a new draft and reloads this tab, which clears the overlay. */
const listenForUpdates = () => {
	window.addEventListener('message', (event: MessageEvent) => {
		if (event.origin !== window.location.origin || event.source !== window.opener ||
			getStringField(event.data, 'type') !== PREVIEW_UPDATING_MESSAGE ||
			document.getElementById('code-snippets-preview-updating')) {
			return
		}

		const overlay = document.createElement('div')
		overlay.id = 'code-snippets-preview-updating'
		overlay.setAttribute('role', 'status')

		const spinner = document.createElement('span')
		spinner.className = 'csp-spinner'
		spinner.setAttribute('aria-hidden', 'true')

		const label = document.createElement('span')
		label.textContent = window.codeSnippetsPreviewMonitor?.updatingLabel ?? 'Updating preview…'

		overlay.append(spinner, label)
		document.body.append(overlay)
	})
}

const init = () => {
	if (window.__codeSnippetsPreviewMonitorLoaded) {
		return
	}
	window.__codeSnippetsPreviewMonitorLoaded = true

	const source = getSource()
	const state: { errors: LogEntry[]; warnings: LogEntry[] } = { errors: [], warnings: [] }
	const root = ensureRoot()
	const elements = getElements(root)

	captureConsole(source, state, elements)
	captureWindowError(source, state, elements)
	captureUnhandledRejection(source, state, elements)
	setupButtons(root, state, elements)
	listenForUpdates()
}

init()
