import { __ } from '@wordpress/i18n'
import { containsMarkup, isValidPhpIdentifier, isValidTextDomain, isValidWordPressKey } from '../utils/validate'
import type { BlueprintForm } from '../BlueprintBase'

export interface PostTypeFormData {
	general: {
		postTypeKey: string
		nameSingular: string
		namePlural: string
		description: string
		hierarchical: boolean
		linkTaxonomies: string
		textDomain: string
	}
	labels: {
		menuName: string
		adminBarName: string
		archives: string
		attributes: string
		parentItem: string
		allItems: string
		addNewItem: string
		addNew: string
		newItem: string
		editItem: string
		updateItem: string
		viewItem: string
		viewItems: string
		searchItems: string
		notFound: string
		notFoundInTrash: string
		featuredImage: string
		setFeaturedImage: string
		removeFeaturedImage: string
		useFeaturedImage: string
		insertIntoItem: string
		uploadedToThisItem: string
		itemsList: string
		itemsListNavigation: string
		filterItemsList: string
		itemPublished: string
		itemPublishedPrivately: string
		itemRevertedToDraft: string
		itemScheduled: string
		itemUpdated: string
		itemLink: string
		itemLinkDescription: string
		filterByDate: string
	}
	supports: {
		supportsTitle: boolean
		supportsEditor: boolean
		supportsExcerpt: boolean
		supportsAuthor: boolean
		supportsThumbnail: boolean
		supportsComments: boolean
		supportsTrackbacks: boolean
		supportsRevisions: boolean
		supportsCustomFields: boolean
		supportsPageAttributes: boolean
		supportsFormats: boolean
	}
	options: {
		excludeFromSearch: boolean
		enableArchives: boolean
		enableExport: boolean
		customArchiveSlug: string
	}
	visibility: {
		public: boolean
		showUI: boolean
		showInSidebar: boolean
		adminSidebarIcon: string
		menuPosition: string
		showInAdminBar: boolean
		showInNavMenus: boolean
	}
	query: {
		queryVariable: 'default' | 'custom' | boolean
		publiclyQueryable: boolean
		customQueryVar: string
	}
	permalinks: {
		permalinkRewrite: 'default' | 'custom' | false
		urlSlug: string
		useUrlSlug: boolean
		pagination: boolean
		feeds: boolean
	}
	capabilities: {
		capabilitiesMode: 'base' | 'custom' | ''
		baseCapabilityType: string
		readCapability: string
		readPrivateCapability: string
		publishCapability: string
		deleteCapability: string
		deletePostsCapability: string
		editCapability: string
		editPostsCapability: string
		editOthersCapability: string
	}
	restApi: {
		showInRest: boolean
		restBase: string
		restControllerClass: string
	}
}

const validateCapability = (capability: string): string | undefined =>
	capability.trim() && !isValidWordPressKey(capability.trim())
		? __('Capability name must be a valid WordPress key', 'code-snippets')
		: undefined

export const PostTypeForm: BlueprintForm<PostTypeFormData> = {
	general: {
		title: __('General', 'code-snippets'),
		description: __('Basic settings for your content type: key, names, and structure.', 'code-snippets'),
		fields: {
			postTypeKey: {
				type: 'text',
				label: __('Post Type Key', 'code-snippets'),
				value: 'projects',
				required: true,
				placeholder: 'projects',
				description: __('A unique ID (slug) for your content type. Use lowercase and underscores.', 'code-snippets'),
				validate(key) {
					if (!key.trim()) {
						return __('Post type key is required', 'code-snippets')
					} else if (!isValidWordPressKey(key.trim())) {
						return __('Post type key must be lowercase, up to 32 characters, and contain only letters, numbers, underscores, or hyphens', 'code-snippets')
					} else {
						return undefined
					}
				}
			},
			nameSingular: {
				type: 'text',
				label: __('Name (Singular)', 'code-snippets'),
				value: __('Project', 'code-snippets'),
				required: true,
				validate: name =>
					containsMarkup(name)
						? __('Names cannot contain HTML.', 'code-snippets')
						: undefined,
				placeholder: __('Project', 'code-snippets'),
				description: __('Post type singular name.', 'code-snippets'),
				onUpdate: (nameSingular, formData) => ({
					...formData,
					labels: { ...formData.labels, adminBarName: nameSingular }
				})
			},
			namePlural: {
				type: 'text',
				label: __('Name (Plural)', 'code-snippets'),
				value: __('Projects', 'code-snippets'),
				required: true,
				validate: name =>
					containsMarkup(name)
						? __('Names cannot contain HTML.', 'code-snippets')
						: undefined,
				placeholder: __('Projects', 'code-snippets'),
				description: __('Post type plural name.', 'code-snippets'),
				onUpdate: (namePlural, formData) => ({
					...formData,
					labels: { ...formData.labels, menuName: namePlural }
				})
			},
			description: {
				type: 'text',
				label: __('Description', 'code-snippets'),
				value: __('Post Type Description', 'code-snippets'),
				placeholder: __('Content Type Description', 'code-snippets'),
				description: __('A short descriptive summary of the custom content type.', 'code-snippets')
			},
			hierarchical: {
				type: 'select',
				label: __('Hierarchical', 'code-snippets'),
				value: false,
				required: true,
				options: [
					{ value: true, label: __('Yes (like pages)', 'code-snippets') },
					{ value: false, label: __('No (like posts)', 'code-snippets') }
				],
				description: __('Whether or not this content type can have parent-child relationships.', 'code-snippets')
			},
			linkTaxonomies: {
				type: 'text',
				label: __('Link To Taxonomies', 'code-snippets'),
				value: 'category,post_tag',
				placeholder: 'category,post_tag',
				description: __('Comma separated list of taxonomies to link to this content type.', 'code-snippets'),
				validate(linkTaxonomies) {
					if (linkTaxonomies) {
						const parts = linkTaxonomies.split(',').map(p => p.trim()).filter(Boolean)

						if (parts.some(part => !isValidWordPressKey(part))) {
							return __('Each taxonomy in the list must be a valid WordPress key', 'code-snippets')
						}
					}

					return undefined
				}
			},
			textDomain: {
				type: 'text',
				label: __('Text Domain', 'code-snippets'),
				value: 'code-snippets-blueprints',
				placeholder: 'text_domain',
				description: __('Optional. Used for translation support. Leave blank if you\'re not sure.', 'code-snippets'),
				validate: textDomain =>
					textDomain && !isValidTextDomain(textDomain.trim())
						? __('Text domain must contain only letters, numbers, underscores, or hyphens', 'code-snippets')
						: undefined
			}
		}
	},
	labels: {
		title: __('Labels', 'code-snippets'),
		description: __('Customize the text shown in the admin for this content type.', 'code-snippets'),
		fields: {
			menuName: {
				type: 'text',
				label: __('Menu Name', 'code-snippets'),
				value: __('Projects', 'code-snippets'),
				description: __('The name used in the admin menu.', 'code-snippets')
			},
			adminBarName: {
				type: 'text',
				label: __('Admin Bar Name', 'code-snippets'),
				value: __('Project', 'code-snippets'),
				description: __('The name used in the admin bar.', 'code-snippets')
			},
			archives: {
				type: 'text',
				label: __('Archives', 'code-snippets'),
				value: __('Archives', 'code-snippets'),
				placeholder: __('Archives', 'code-snippets'),
				description: __('Label for archives in nav menus.', 'code-snippets')
			},
			attributes: {
				type: 'text',
				label: __('Attributes', 'code-snippets'),
				value: __('Attributes', 'code-snippets'),
				placeholder: __('Attributes', 'code-snippets'),
				description: __('Label for the attributes meta box.', 'code-snippets')
			},
			parentItem: {
				type: 'text',
				label: __('Parent Item', 'code-snippets'),
				value: __('Parent Item:', 'code-snippets'),
				placeholder: __('Parent Item:', 'code-snippets'),
				description: __('Label for parent items (used for hierarchical post types).', 'code-snippets')
			},
			allItems: {
				type: 'text',
				label: __('All Items', 'code-snippets'),
				value: __('All Items', 'code-snippets'),
				placeholder: __('All Items', 'code-snippets'),
				description: __('Label for all items in the admin menu.', 'code-snippets')
			},
			addNewItem: {
				type: 'text',
				label: __('Add New Item', 'code-snippets'),
				value: __('Add New Item', 'code-snippets'),
				placeholder: __('Add New Item', 'code-snippets'),
				description: __('Label for adding a new item.', 'code-snippets')
			},
			addNew: {
				type: 'text',
				label: __('Add New', 'code-snippets'),
				value: __('Add New', 'code-snippets'),
				placeholder: __('Add New', 'code-snippets'),
				description: __('Label for the "Add New" button.', 'code-snippets')
			},
			newItem: {
				type: 'text',
				label: __('New Item', 'code-snippets'),
				value: __('New Item', 'code-snippets'),
				placeholder: __('New Item', 'code-snippets'),
				description: __('Label for new items.', 'code-snippets')
			},
			editItem: {
				type: 'text',
				label: __('Edit Item', 'code-snippets'),
				value: __('Edit Item', 'code-snippets'),
				placeholder: __('Edit Item', 'code-snippets'),
				description: __('Label for editing an item.', 'code-snippets')
			},
			updateItem: {
				type: 'text',
				label: __('Update Item', 'code-snippets'),
				value: __('Update Item', 'code-snippets'),
				placeholder: __('Update Item', 'code-snippets'),
				description: __('Label for updating an item.', 'code-snippets')
			},
			viewItem: {
				type: 'text',
				label: __('View Item', 'code-snippets'),
				value: __('View Item', 'code-snippets'),
				placeholder: __('View Item', 'code-snippets'),
				description: __('Label for viewing a single item.', 'code-snippets')
			},
			viewItems: {
				type: 'text',
				label: __('View Items', 'code-snippets'),
				value: __('View Items', 'code-snippets'),
				placeholder: __('View Items', 'code-snippets'),
				description: __('Label for viewing multiple items.', 'code-snippets')
			},
			searchItems: {
				type: 'text',
				label: __('Search Item', 'code-snippets'),
				value: __('Search Item', 'code-snippets'),
				placeholder: __('Search Item', 'code-snippets'),
				description: __('Label for searching items.', 'code-snippets')
			},
			notFound: {
				type: 'text',
				label: __('Not Found', 'code-snippets'),
				value: __('Not found', 'code-snippets'),
				placeholder: __('Not found', 'code-snippets'),
				description: __('Label when no items are found.', 'code-snippets')
			},
			notFoundInTrash: {
				type: 'text',
				label: __('Not Found in Trash', 'code-snippets'),
				value: __('Not found in Trash', 'code-snippets'),
				placeholder: __('Not found in Trash', 'code-snippets'),
				description: __('Label when no items are found in trash.', 'code-snippets')
			},
			featuredImage: {
				type: 'text',
				label: __('Featured Image', 'code-snippets'),
				value: __('Featured Image', 'code-snippets'),
				placeholder: __('Featured Image', 'code-snippets'),
				description: __('Label for the featured image meta box.', 'code-snippets')
			},
			setFeaturedImage: {
				type: 'text',
				label: __('Set Featured Image', 'code-snippets'),
				value: __('Set featured image', 'code-snippets'),
				placeholder: __('Set featured image', 'code-snippets'),
				description: __('Label for setting the featured image.', 'code-snippets')
			},
			removeFeaturedImage: {
				type: 'text',
				label: __('Remove Featured Image', 'code-snippets'),
				value: __('Remove featured image', 'code-snippets'),
				placeholder: __('Remove featured image', 'code-snippets'),
				description: __('Label for removing the featured image.', 'code-snippets')
			},
			useFeaturedImage: {
				type: 'text',
				label: __('Use as Featured Image', 'code-snippets'),
				value: __('Use as featured image', 'code-snippets'),
				placeholder: __('Use as featured image', 'code-snippets'),
				description: __('Label for using an image as featured image.', 'code-snippets')
			},
			insertIntoItem: {
				type: 'text',
				label: __('Insert into Item', 'code-snippets'),
				value: __('Insert into item', 'code-snippets'),
				placeholder: __('Insert into item', 'code-snippets'),
				description: __('Label for inserting media into an item.', 'code-snippets')
			},
			uploadedToThisItem: {
				type: 'text',
				label: __('Uploaded to this Item', 'code-snippets'),
				value: __('Uploaded to this item', 'code-snippets'),
				placeholder: __('Uploaded to this item', 'code-snippets'),
				description: __('Label for media uploaded to this item.', 'code-snippets')
			},
			itemsList: {
				type: 'text',
				label: __('Items List', 'code-snippets'),
				value: __('Items list', 'code-snippets'),
				placeholder: __('Items list', 'code-snippets'),
				description: __('Label for the items list screen reader text.', 'code-snippets')
			},
			itemsListNavigation: {
				type: 'text',
				label: __('Items List Navigation', 'code-snippets'),
				value: __('Items list navigation', 'code-snippets'),
				placeholder: __('Items list navigation', 'code-snippets'),
				description: __('Label for the items list pagination screen reader text.', 'code-snippets')
			},
			filterItemsList: {
				type: 'text',
				label: __('Filter Items List', 'code-snippets'),
				value: __('Filter items list', 'code-snippets'),
				placeholder: __('Filter items list', 'code-snippets'),
				description: __('Label for the items list filter screen reader text.', 'code-snippets')
			},
			itemPublished: {
				type: 'text',
				label: __('Item Published', 'code-snippets'),
				value: __('Post published.', 'code-snippets'),
				placeholder: __('Post published.', 'code-snippets'),
				description: __('Label used in the block editor when a post is published.', 'code-snippets')
			},
			itemPublishedPrivately: {
				type: 'text',
				label: __('Item Published Privately', 'code-snippets'),
				value: __('Post published privately.', 'code-snippets'),
				placeholder: __('Post published privately.', 'code-snippets'),
				description: __('Label used in the block editor when a post is published privately.', 'code-snippets')
			},
			itemRevertedToDraft: {
				type: 'text',
				label: __('Item Reverted to Draft', 'code-snippets'),
				value: __('Post reverted to draft.', 'code-snippets'),
				placeholder: __('Post reverted to draft.', 'code-snippets'),
				description: __('Label used in the block editor when a post is reverted to draft.', 'code-snippets')
			},
			itemScheduled: {
				type: 'text',
				label: __('Item Scheduled', 'code-snippets'),
				value: __('Post scheduled.', 'code-snippets'),
				placeholder: __('Post scheduled.', 'code-snippets'),
				description: __('Label used in the block editor when a post is scheduled.', 'code-snippets')
			},
			itemUpdated: {
				type: 'text',
				label: __('Item Updated', 'code-snippets'),
				value: __('Post updated.', 'code-snippets'),
				placeholder: __('Post updated.', 'code-snippets'),
				description: __('Label used in the block editor when a post is updated.', 'code-snippets')
			},
			itemLink: {
				type: 'text',
				label: __('Item Link', 'code-snippets'),
				value: __('Post Link', 'code-snippets'),
				placeholder: __('Post Link', 'code-snippets'),
				description: __('Title for a navigation link block variation. Used in the block editor.', 'code-snippets')
			},
			itemLinkDescription: {
				type: 'text',
				label: __('Item Link Description', 'code-snippets'),
				value: __('A link to a post.', 'code-snippets'),
				placeholder: __('A link to a post.', 'code-snippets'),
				description: __('Description for a navigation link block variation. Used in the block editor.', 'code-snippets')
			},
			filterByDate: {
				type: 'text',
				label: __('Filter by Date', 'code-snippets'),
				value: __('Filter by date', 'code-snippets'),
				placeholder: __('Filter by date', 'code-snippets'),
				description: __('Label for the date filter dropdown on the post list table.', 'code-snippets')
			}
		}
	},
	supports: {
		title: __('Supports', 'code-snippets'),
		description: __('Add support for various available post editor features. Please check those that you want to enable.', 'code-snippets'),
		fields: {
			supportsTitle: { type: 'checkbox', label: __('Title', 'code-snippets'), value: true },
			supportsEditor: { type: 'checkbox', label: __('Editor', 'code-snippets'), value: true },
			supportsThumbnail: { type: 'checkbox', label: __('Featured Image', 'code-snippets'), value: false },
			supportsExcerpt: { type: 'checkbox', label: __('Excerpt', 'code-snippets'), value: false },
			supportsTrackbacks: { type: 'checkbox', label: __('Trackbacks', 'code-snippets'), value: false },
			supportsCustomFields: { type: 'checkbox', label: __('Custom Fields', 'code-snippets'), value: false },
			supportsComments: { type: 'checkbox', label: __('Comments', 'code-snippets'), value: false },
			supportsRevisions: { type: 'checkbox', label: __('Revisions', 'code-snippets'), value: false },
			supportsAuthor: { type: 'checkbox', label: __('Author', 'code-snippets'), value: false },
			supportsPageAttributes: { type: 'checkbox', label: __('Page Attributes', 'code-snippets'), value: false },
			supportsFormats: { type: 'checkbox', label: __('Post Formats', 'code-snippets'), value: false }
		}
	},
	options: {
		title: __('Options', 'code-snippets'),
		description: __('Search, archives, and export settings for this content type.', 'code-snippets'),
		fields: {
			excludeFromSearch: {
				type: 'boolean-select',
				label: __('Exclude From Search', 'code-snippets'),
				value: false,
				required: true,
				description: __('Exclude this post type from search results.', 'code-snippets')
			},
			enableExport: {
				type: 'boolean-select',
				label: __('Enable Export', 'code-snippets'),
				value: true,
				required: true,
				description: __('Enable export support for this post type.', 'code-snippets')
			},
			enableArchives: {
				type: 'boolean-select',
				label: __('Enable Archives', 'code-snippets'),
				value: true,
				required: true,
				description: __('Enable post type archives. Default slug uses the post type key.', 'code-snippets')
			},
			customArchiveSlug: {
				type: 'text',
				label: __('Custom Archive Slug', 'code-snippets'),
				value: '',
				description: __('Set a custom archive slug. If not set, the value is the default slug.', 'code-snippets'),
				showIf: formData => formData.options.enableArchives
			}
		}
	},
	visibility: {
		title: __('Visibility', 'code-snippets'),
		description: __('Control where this content type appears in the admin (sidebar, admin bar, menus).', 'code-snippets'),
		fields: {
			public: {
				type: 'boolean-select',
				label: __('Public', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show the post type in the admin UI.', 'code-snippets')
			},
			showUI: {
				type: 'boolean-select',
				label: __('Show UI', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show the post type UI in the admin.', 'code-snippets')
			},
			showInSidebar: {
				type: 'boolean-select',
				label: __('Show in Admin Sidebar', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show the post type in the admin sidebar.', 'code-snippets')
			},
			menuPosition: {
				type: 'text',
				label: __('Admin Sidebar Position', 'code-snippets'),
				value: '5',
				placeholder: '5',
				description: __('Set the menu position (e.g. 5 - below Posts).', 'code-snippets')
			},
			adminSidebarIcon: {
				type: 'text',
				label: __('Admin Sidebar Icon', 'code-snippets'),
				value: '',
				placeholder: 'dashicons-admin-post',
				description: __('Use a Dashicons name – see https://developer.wordpress.org/resource/dashicons/ for available icons.', 'code-snippets')
			},
			showInAdminBar: {
				type: 'boolean-select',
				label: __('Show in Admin Bar', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show the post type in the admin bar.', 'code-snippets')
			},
			showInNavMenus: {
				type: 'boolean-select',
				label: __('Show in Navigation Menus', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show the post type in navigation menus.', 'code-snippets')
			}
		}
	},
	query: {
		title: __('Query', 'code-snippets'),
		description: __('Configure how this content type is queried on the front end.', 'code-snippets'),
		fields: {
			publiclyQueryable: {
				type: 'boolean-select',
				label: __('Publicly Queryable', 'code-snippets'),
				value: true,
				required: true,
				description: __('Enable front-end queries as part of parse_request().', 'code-snippets')
			},
			queryVariable: {
				type: 'select',
				label: __('Query Variable', 'code-snippets'),
				value: 'default',
				required: true,
				options: [
					{ value: 'default', label: __('Default (post type key)', 'code-snippets') },
					{ value: 'custom', label: __('Custom', 'code-snippets') },
					{ value: false, label: __('Disabled', 'code-snippets') }
				],
				description: __('Direct query variable used in WP_Query. Choose default, custom, or disabled.', 'code-snippets')
			},
			customQueryVar: {
				type: 'text',
				label: __('Custom Query', 'code-snippets'),
				value: '',
				description: __('Custom query variable.', 'code-snippets'),
				showIf: formData => 'custom' === formData.query.queryVariable,
				validate(customQueryVar, { query: { queryVariable } }) {
					if ('custom' === queryVariable) {
						if (!customQueryVar) {
							return __('Custom query var is required when query variable is set to custom', 'code-snippets')
						} else if (!isValidWordPressKey(customQueryVar)) {
							return __('Query var must be lowercase, up to 32 characters, and contain only letters, numbers, underscores, or hyphens', 'code-snippets')
						}
					}
					return undefined
				}
			}
		}
	},
	permalinks: {
		title: __('Permalinks', 'code-snippets'),
		description: __('Set the URL structure for single items and archives.', 'code-snippets'),
		fields: {
			permalinkRewrite: {
				type: 'select',
				label: __('Permalink Rewrite', 'code-snippets'),
				value: 'default',
				required: true,
				options: [
					{ value: 'default', label: __('Default (post type key)', 'code-snippets') },
					{ value: 'custom', label: __('Custom', 'code-snippets') },
					{ value: false, label: __('Disabled', 'code-snippets') }
				],
				description: __('Use default permalinks, set custom rewrite rules, or disable permalinks.', 'code-snippets')
			},
			urlSlug: {
				type: 'text',
				label: __('URL Slug', 'code-snippets'),
				value: '',
				description: __('Pretty permalink base text. i.e. example.com/projects/', 'code-snippets'),
				showIf: formData => 'custom' === formData.permalinks.permalinkRewrite,
				validate: slug =>
					slug.trim() && !isValidWordPressKey(slug.trim())
						? __('URL slug must be lowercase, up to 32 characters, and contain only letters, numbers, underscores, or hyphens', 'code-snippets')
						: undefined
			},
			useUrlSlug: {
				type: 'boolean-select',
				label: __('Use URL Slug', 'code-snippets'),
				value: true,
				required: true,
				description: __('Use content type slug as URL base. Default: Yes.', 'code-snippets')
			},
			pagination: {
				type: 'boolean-select',
				label: __('Pagination', 'code-snippets'),
				value: true,
				required: true,
				description: __('Allow content type pagination.', 'code-snippets')
			},
			feeds: {
				type: 'boolean-select',
				label: __('Feeds', 'code-snippets'),
				value: true,
				required: true,
				description: __('Build feed permastruct. Default: Yes.', 'code-snippets')
			}
		}
	},
	capabilities: {
		title: __('Capabilities', 'code-snippets'),
		description: __('Define who can create, edit, and delete this content type.', 'code-snippets'),
		fields: {
			capabilitiesMode: {
				type: 'select',
				label: __('Capabilities Mode', 'code-snippets'),
				value: 'base',
				required: true,
				options: [
					{ value: 'base', label: __('Base Capabilities', 'code-snippets') },
					{ value: 'custom', label: __('Custom Capabilities', 'code-snippets') }
				],
				description: __('Choose between base capabilities or custom capabilities.', 'code-snippets')
			},
			baseCapabilityType: {
				type: 'text',
				label: __('Base Capability Type', 'code-snippets'),
				value: 'post',
				placeholder: __('post', 'code-snippets'),
				description: __('Used as a base to construct capabilities (e.g., "post" or "page").', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: baseCapabilityType =>
					baseCapabilityType.trim() && !isValidWordPressKey(baseCapabilityType.trim())
						? __('Base capability type must be a valid WordPress key', 'code-snippets')
						: undefined
			},
			readCapability: {
				type: 'text',
				label: __('Read Post', 'code-snippets'),
				value: 'read_post',
				placeholder: 'read_post',
				description: __('Capability to read a single post.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			readPrivateCapability: {
				type: 'text',
				label: __('Read Private Posts', 'code-snippets'),
				value: 'read_private_posts',
				placeholder: 'read_private_posts',
				description: __('Capability to read private posts.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			publishCapability: {
				type: 'text',
				label: __('Publish Posts', 'code-snippets'),
				value: 'publish_posts',
				placeholder: 'publish_posts',
				description: __('Capability to publish posts.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			deleteCapability: {
				type: 'text',
				label: __('Delete Post', 'code-snippets'),
				value: 'delete_post',
				placeholder: 'delete_post',
				description: __('Capability to delete a single post.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			deletePostsCapability: {
				type: 'text',
				label: __('Delete Posts', 'code-snippets'),
				value: 'delete_posts',
				placeholder: 'delete_posts',
				description: __('Capability to delete posts of this type.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			editCapability: {
				type: 'text',
				label: __('Edit Post', 'code-snippets'),
				value: 'edit_post',
				placeholder: 'edit_post',
				description: __('Capability to edit a single post.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			editPostsCapability: {
				type: 'text',
				label: __('Edit Posts', 'code-snippets'),
				value: 'edit_posts',
				placeholder: 'edit_posts',
				description: __('Capability to edit posts.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			editOthersCapability: {
				type: 'text',
				label: __('Edit Others Posts', 'code-snippets'),
				value: 'edit_others_posts',
				placeholder: 'edit_others_posts',
				description: __('Capability to edit posts authored by other users.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			}
		}
	},
	restApi: {
		title: __('REST API', 'code-snippets'),
		description: __('Expose this content type in the WordPress REST API.', 'code-snippets'),
		fields: {
			showInRest: {
				type: 'boolean-select',
				label: __('Show in REST', 'code-snippets'),
				value: false,
				description: __('Add the post type route to the REST API namespace.', 'code-snippets')
			},
			restBase: {
				type: 'text',
				label: __('REST Base', 'code-snippets'),
				value: '',
				description: __('Change the base URL of the REST API route. Default is the post type key.', 'code-snippets'),
				showIf: formData => formData.restApi.showInRest,
				validate: restBase =>
					restBase.trim() && !isValidWordPressKey(restBase)
						? __('REST base must be a valid WordPress key', 'code-snippets')
						: undefined
			},
			restControllerClass: {
				type: 'text',
				label: __('REST Controller Class', 'code-snippets'),
				value: 'WP_REST_Posts_Controller',
				placeholder: 'WP_REST_Posts_Controller',
				description: __('REST API controller class name. Default is WP_REST_Posts_Controller.', 'code-snippets'),
				showIf: formData => formData.restApi.showInRest,
				validate: controllerClass =>
					controllerClass.trim() && !isValidPhpIdentifier(controllerClass)
						? __('REST controller class must be a valid PHP class name', 'code-snippets')
						: undefined
			}
		}
	}
}
