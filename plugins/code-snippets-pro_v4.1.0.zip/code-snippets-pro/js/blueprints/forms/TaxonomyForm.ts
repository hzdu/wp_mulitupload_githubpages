import { __ } from '@wordpress/i18n'
import { containsMarkup, isValidPhpIdentifier, isValidTextDomain, isValidWordPressKey } from '../utils/validate'
import type { BlueprintForm } from '../BlueprintBase'

export interface TaxonomyFormData {
	general: {
		taxonomyKey: string
		nameSingular: string
		namePlural: string
		objectType: string
		hierarchical: boolean
		textDomain: string
	}
	labels: {
		menuName: string
		allItems: string
		parentItem: string
		parentItemColon: string
		newItemName: string
		addNewItem: string
		editItem: string
		updateItem: string
		viewItem: string
		separateItemsWithCommas: string
		addOrRemoveItems: string
		chooseFromMostUsed: string
		popularItems: string
		searchItems: string
		notFound: string
		noTerms: string
		itemsList: string
		itemsListNavigation: string
		backToItems: string
		filterByItem: string
		itemLink: string
		itemLinkDescription: string
	}
	visibility: {
		public: boolean
		showUI: boolean
		showAdminColumn: boolean
		showTagCloud: boolean
		showInNavMenus: boolean
	}
	query: {
		queryVar: 'default' | 'custom'
		queryVarSlug: string
	}
	permalinks: {
		rewrite: 'default' | 'custom' | false
		rewriteSlug: string
		rewriteWithFront: boolean
		rewriteHierarchical: boolean
	}
	capabilities: {
		capabilitiesMode: 'default' | 'custom'
		capabilitiesManageTerms: string
		capabilitiesEditTerms: string
		capabilitiesDeleteTerms: string
		capabilitiesAssignTerms: string
	}
	restApi: {
		showInRest: boolean
		restBase: string
		restNamespace: string
		restControllerClass: string
	}
	advanced: {
		updateCountCallback: string
	}
}

const validateCapability = (capability: string): string | undefined =>
	capability && !isValidPhpIdentifier(capability)
		? __('Capability name must be a valid PHP identifier', 'code-snippets')
		: undefined

export const TaxonomyForm: BlueprintForm<TaxonomyFormData> = {
	general: {
		title: __('General', 'code-snippets'),
		description: __('Basic settings for your taxonomy: key, names, and which content types it applies to.', 'code-snippets'),
		fields: {
			taxonomyKey: {
				type: 'text',
				label: __('Taxonomy Key', 'code-snippets'),
				value: 'project-type',
				required: true,
				placeholder: 'project-type',
				description: __('Key used in the code. Up to 32 characters, lowercase.', 'code-snippets'),
				validate(key) {
					if (!key) {
						return __('Taxonomy key is required', 'code-snippets')
					} else if (!isValidWordPressKey(key)) {
						return __('Taxonomy key must be lowercase, max 32 characters, and contain only letters, numbers, underscores, or hyphens', 'code-snippets')
					} else {
						return
					}
				}
			},
			nameSingular: {
				type: 'text',
				label: __('Name (Singular)', 'code-snippets'),
				value: __('Project Type', 'code-snippets'),
				required: true,
				validate: name =>
					containsMarkup(name)
						? __('Names cannot contain HTML.', 'code-snippets')
						: undefined,
				placeholder: __('Project Type', 'code-snippets'),
				description: __('Taxonomy singular name.', 'code-snippets')
			},
			namePlural: {
				type: 'text',
				label: __('Name (Plural)', 'code-snippets'),
				value: __('Project Types', 'code-snippets'),
				required: true,
				validate: name =>
					containsMarkup(name)
						? __('Names cannot contain HTML.', 'code-snippets')
						: undefined,
				placeholder: __('Project Types', 'code-snippets'),
				description: __('Taxonomy plural name.', 'code-snippets'),
				onUpdate: (value, formData) =>
					({ ...formData, labels: { ...formData.labels, menuName: value } })
			},
			objectType: {
				type: 'text',
				label: __('Link To Post Type(s)', 'code-snippets'),
				value: 'projects',
				required: true,
				placeholder: 'projects',
				description: __('Comma separated list of Post Types.', 'code-snippets'),
				validate(postTypes) {
					if (!postTypes) {
						return __('Post type(s) are required', 'code-snippets')
					}

					for (const postType of postTypes.split(',')) {
						if (!isValidWordPressKey(postType.trim())) {
							return __('Each post type must be a valid WordPress key (lowercase, letters, numbers, underscores, or hyphens)', 'code-snippets')
						}
					}

					return
				}
			},
			hierarchical: {
				type: 'select',
				label: __('Hierarchical', 'code-snippets'),
				value: false,
				required: true,
				options: [
					{ value: true, label: __('Yes (like categories)', 'code-snippets') },
					{ value: false, label: __('No (like tags)', 'code-snippets') }
				],
				description: __('Hierarchical taxonomy allows descendants.', 'code-snippets')
			},
			textDomain: {
				type: 'text',
				label: __('Text Domain', 'code-snippets'),
				value: 'code-snippets-blueprints',
				placeholder: 'text_domain',
				description: __('Translation file text domain. Optional.', 'code-snippets'),
				validate: textDomain =>
					textDomain && !isValidTextDomain(textDomain)
						? __('Text domain must contain only letters, numbers, underscores, or hyphens', 'code-snippets')
						: undefined
			}
		}
	},
	labels: {
		title: __('Labels', 'code-snippets'),
		fields: {
			menuName: {
				type: 'text',
				label: __('Menu Name', 'code-snippets'),
				value: __('Project Types', 'code-snippets'),
				placeholder: __('Project Types', 'code-snippets'),
				description: __('The name used in the admin menu.', 'code-snippets')
			},
			allItems: {
				type: 'text',
				label: __('All Items', 'code-snippets'),
				value: __('All Items', 'code-snippets'),
				placeholder: __('All Items', 'code-snippets'),
				description: __('Label for all items in the admin menu.', 'code-snippets')
			},
			parentItem: {
				type: 'text',
				label: __('Parent Item', 'code-snippets'),
				value: __('Parent Item', 'code-snippets'),
				placeholder: __('Parent Item', 'code-snippets'),
				description: __('Label for parent items (used for hierarchical taxonomies).', 'code-snippets')
			},
			parentItemColon: {
				type: 'text',
				label: __('Parent Item (colon)', 'code-snippets'),
				value: __('Parent Item:', 'code-snippets'),
				placeholder: __('Parent Item:', 'code-snippets'),
				description: __('Label for parent items with colon.', 'code-snippets')
			},
			newItemName: {
				type: 'text',
				label: __('New Item Name', 'code-snippets'),
				value: __('New Item Name', 'code-snippets'),
				placeholder: __('New Item Name', 'code-snippets'),
				description: __('Label for new item name.', 'code-snippets')
			},
			addNewItem: {
				type: 'text',
				label: __('Add New Item', 'code-snippets'),
				value: __('Add New Item', 'code-snippets'),
				placeholder: __('Add New Item', 'code-snippets'),
				description: __('Label for adding a new item.', 'code-snippets')
			},
			editItem: {
				type: 'text',
				label: __('Edit Item', 'code-snippets'),
				value: __('Edit Item', 'code-snippets'),
				placeholder: __('Edit Item', 'code-snippets'),
				description: __('Label for editing an item.', 'code-snippets')
			},
			updateItem: {
				type: 'text',
				label: __('Update Item', 'code-snippets'),
				value: __('Update Item', 'code-snippets'),
				placeholder: __('Update Item', 'code-snippets'),
				description: __('Label for updating an item.', 'code-snippets')
			},
			viewItem: {
				type: 'text',
				label: __('View Item', 'code-snippets'),
				value: __('View Item', 'code-snippets'),
				placeholder: __('View Item', 'code-snippets'),
				description: __('Label for viewing a single item.', 'code-snippets')
			},
			separateItemsWithCommas: {
				type: 'text',
				label: __('Separate Items with Commas', 'code-snippets'),
				value: __('Separate items with commas', 'code-snippets'),
				placeholder: __('Separate items with commas', 'code-snippets'),
				description: __('Label for separating items with commas.', 'code-snippets')
			},
			addOrRemoveItems: {
				type: 'text',
				label: __('Add or Remove Items', 'code-snippets'),
				value: __('Add or remove items', 'code-snippets'),
				placeholder: __('Add or remove items', 'code-snippets'),
				description: __('Label for adding or removing items.', 'code-snippets')
			},
			chooseFromMostUsed: {
				type: 'text',
				label: __('Choose From Most Used', 'code-snippets'),
				value: __('Choose from the most used', 'code-snippets'),
				placeholder: __('Choose from the most used', 'code-snippets'),
				description: __('Label for choosing from most used items.', 'code-snippets')
			},
			popularItems: {
				type: 'text',
				label: __('Popular Items', 'code-snippets'),
				value: __('Popular Items', 'code-snippets'),
				placeholder: __('Popular Items', 'code-snippets'),
				description: __('Label for popular items.', 'code-snippets')
			},
			searchItems: {
				type: 'text',
				label: __('Search Items', 'code-snippets'),
				value: __('Search Items', 'code-snippets'),
				placeholder: __('Search Items', 'code-snippets'),
				description: __('Label for searching items.', 'code-snippets')
			},
			notFound: {
				type: 'text',
				label: __('Not Found', 'code-snippets'),
				value: __('Not Found', 'code-snippets'),
				placeholder: __('Not Found', 'code-snippets'),
				description: __('Label when no items are found.', 'code-snippets')
			},
			noTerms: {
				type: 'text',
				label: __('No Items', 'code-snippets'),
				value: __('No items', 'code-snippets'),
				placeholder: __('No items', 'code-snippets'),
				description: __('Label when there are no items.', 'code-snippets')
			},
			itemsList: {
				type: 'text',
				label: __('Items List', 'code-snippets'),
				value: __('Items list', 'code-snippets'),
				placeholder: __('Items list', 'code-snippets'),
				description: __('Label for the items list screen reader text.', 'code-snippets')
			},
			itemsListNavigation: {
				type: 'text',
				label: __('Items List Navigation', 'code-snippets'),
				value: __('Items list navigation', 'code-snippets'),
				placeholder: __('Items list navigation', 'code-snippets'),
				description: __('Label for the items list pagination screen reader text.', 'code-snippets')
			},
			backToItems: {
				type: 'text',
				label: __('Back to Items', 'code-snippets'),
				value: __('Back to Items', 'code-snippets'),
				placeholder: __('Back to Items', 'code-snippets'),
				description: __('Label displayed after updating a term, linking back to the main list.', 'code-snippets')
			},
			filterByItem: {
				type: 'text',
				label: __('Filter by Item', 'code-snippets'),
				value: __('Filter by item', 'code-snippets'),
				placeholder: __('Filter by item', 'code-snippets'),
				description: __('Label for the filter dropdown on the post list table. Used for hierarchical taxonomies.', 'code-snippets')
			},
			itemLink: {
				type: 'text',
				label: __('Item Link', 'code-snippets'),
				value: __('Item Link', 'code-snippets'),
				placeholder: __('Item Link', 'code-snippets'),
				description: __('Title for a navigation link block variation. Used in the block editor.', 'code-snippets')
			},
			itemLinkDescription: {
				type: 'text',
				label: __('Item Link Description', 'code-snippets'),
				value: __('A link to an item.', 'code-snippets'),
				placeholder: __('A link to an item.', 'code-snippets'),
				description: __('Description for a navigation link block variation. Used in the block editor.', 'code-snippets')
			}
		}
	},
	visibility: {
		title: __('Visibility', 'code-snippets'),
		fields: {
			public: {
				type: 'boolean-select',
				label: __('Public', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show this taxonomy in the admin UI.', 'code-snippets')
			},
			showUI: {
				type: 'boolean-select',
				label: __('Show UI', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show taxonomy managing UI in the admin.', 'code-snippets')
			},
			showAdminColumn: {
				type: 'boolean-select',
				label: __('Show Admin Column', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show taxonomy columns on associated post-types.', 'code-snippets')
			},
			showTagCloud: {
				type: 'boolean-select',
				label: __('Show Tag Cloud', 'code-snippets'),
				value: true,
				required: true,
				description: __('Show in tag cloud widget.', 'code-snippets')
			},
			showInNavMenus: {
				type: 'boolean-select',
				label: __('Show in Navigation Menus', 'code-snippets'),
				value: true,
				required: true,
				description: __('Taxonomy available for selection in Navigation Menus.', 'code-snippets')
			}
		}
	},
	query: {
		title: __('Query', 'code-snippets'),
		fields: {
			queryVar: {
				type: 'select',
				label: __('Query Variable', 'code-snippets'),
				value: 'default',
				required: true,
				options: [
					{ value: 'default', label: __('Default (taxonomy key)', 'code-snippets') },
					{ value: 'custom', label: __('Custom query variable', 'code-snippets') }
				],
				description: __('Direct query variable used in WP_Query.', 'code-snippets')
			},
			queryVarSlug: {
				type: 'text',
				label: __('Custom Query', 'code-snippets'),
				value: '',
				required: true,
				description: __('Custom query variable. Only used when Custom is selected.', 'code-snippets'),
				showIf: formData => 'custom' === formData.query.queryVar,
				validate: slug =>
					!isValidWordPressKey(slug)
						? __('Query variable slug must be a valid WordPress key', 'code-snippets')
						: undefined
			}
		}
	},
	permalinks: {
		title: __('Permalinks', 'code-snippets'),
		fields: {
			rewrite: {
				type: 'select',
				label: __('Permalink Rewrite', 'code-snippets'),
				value: 'default',
				required: true,
				options: [
					{ value: 'default', label: __('Default permalink (taxonomy key)', 'code-snippets') },
					{ value: 'custom', label: __('Custom permalink', 'code-snippets') },
					{ value: false, label: __('No permalink (prevent URL rewriting)', 'code-snippets') }
				],
				description: __('Use default permalinks, set custom rewrite rules, or disable permalinks.', 'code-snippets')
			},
			rewriteSlug: {
				type: 'text',
				label: __('URL Slug', 'code-snippets'),
				value: '',
				required: true,
				description: __('Pretty permalink base rewrite text. Only used when Custom is selected.', 'code-snippets'),
				showIf: formData => 'custom' === formData.permalinks.rewrite,
				validate: slug =>
					slug && !isValidWordPressKey(slug)
						? __('Rewrite slug must be a valid WordPress key (lowercase, up to 32 characters)', 'code-snippets')
						: undefined
			},
			rewriteWithFront: {
				type: 'boolean-select',
				label: __('Use URL Slug', 'code-snippets'),
				value: true,
				required: true,
				description: __('Use taxonomy slug as URL base. Only used when Custom is selected.', 'code-snippets'),
				showIf: formData => 'custom' === formData.permalinks.rewrite
			},
			rewriteHierarchical: {
				type: 'boolean-select',
				label: __('Hierarchical URL Slug', 'code-snippets'),
				value: false,
				required: true,
				description: __('Allow hierarchical URLs. Only used when Custom is selected.', 'code-snippets'),
				showIf: formData => 'custom' === formData.permalinks.rewrite
			}
		}
	},
	capabilities: {
		title: __('Capabilities', 'code-snippets'),
		fields: {
			capabilitiesMode: {
				type: 'select',
				label: __('Capabilities', 'code-snippets'),
				value: 'default',
				required: true,
				options: [
					{ value: 'default', label: __('Default', 'code-snippets') },
					{ value: 'custom', label: __('Custom capabilities', 'code-snippets') }
				],
				description: __('Set custom user capabilities to manage taxonomy. Default: category capabilities.', 'code-snippets')
			},
			capabilitiesManageTerms: {
				type: 'text',
				label: __('Manage Terms', 'code-snippets'),
				value: 'manage_categories',
				placeholder: 'manage_categories',
				description: __('Capability to manage terms. Only used when Custom is selected.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			capabilitiesEditTerms: {
				type: 'text',
				label: __('Edit Terms', 'code-snippets'),
				value: 'manage_categories',
				placeholder: 'manage_categories',
				description: __('Capability to edit terms. Only used when Custom is selected.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			capabilitiesDeleteTerms: {
				type: 'text',
				label: __('Delete Terms', 'code-snippets'),
				value: 'manage_categories',
				placeholder: 'manage_categories',
				description: __('Capability to delete terms. Only used when Custom is selected.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			},
			capabilitiesAssignTerms: {
				type: 'text',
				label: __('Assign Terms', 'code-snippets'),
				value: 'edit_posts',
				placeholder: 'edit_posts',
				description: __('Capability to assign terms. Only used when Custom is selected.', 'code-snippets'),
				showIf: formData => 'custom' === formData.capabilities.capabilitiesMode,
				validate: validateCapability
			}
		}
	},
	restApi: {
		title: __('REST API', 'code-snippets'),
		fields: {
			showInRest: {
				type: 'boolean-select',
				label: __('Show in REST', 'code-snippets'),
				value: true,
				required: true,
				description: __('Whether to include the taxonomy in the REST API.', 'code-snippets')
			},
			restBase: {
				type: 'text',
				label: __('REST Base', 'code-snippets'),
				value: '',
				description: __('To change the base url of REST API route. Default is the taxonomy key.', 'code-snippets'),
				showIf: formData => formData.restApi.showInRest,
				validate: restBase =>
					restBase && !isValidWordPressKey(restBase)
						? __('REST base must be a valid WordPress key (lowercase, up to 32 characters)', 'code-snippets')
						: undefined
			},
			restNamespace: {
				type: 'text',
				label: __('REST Namespace', 'code-snippets'),
				value: '',
				placeholder: 'wp/v2',
				description: __('Change the namespace URL of the REST API route. Default is wp/v2. Added in WP 5.9.', 'code-snippets'),
				showIf: formData => formData.restApi.showInRest,
				validate: restNamespace =>
					restNamespace && !/^[\w-]+\/[\w-]+$/.test(restNamespace)
						? __('REST namespace must follow the format "prefix/version" (e.g. wp/v2)', 'code-snippets')
						: undefined
			},
			restControllerClass: {
				type: 'text',
				label: __('REST Controller Class', 'code-snippets'),
				value: '',
				placeholder: 'WP_REST_Terms_Controller',
				description: __('REST API Controller class name. Default is \'WP_REST_Terms_Controller\'.', 'code-snippets'),
				showIf: formData => formData.restApi.showInRest,
				validate: controllerClass =>
					controllerClass && !isValidPhpIdentifier(controllerClass)
						? __('REST controller class must be a valid PHP class name', 'code-snippets')
						: undefined
			}
		}
	},
	advanced: {
		title: __('Advanced', 'code-snippets'),
		fields: {
			updateCountCallback: {
				type: 'text',
				label: __('Update Count Callback', 'code-snippets'),
				value: '',
				description: __(
					'A PHP function name that WordPress calls when the post count for a term needs to be recalculated. ' +
					'Use only if you need custom term-count logic; otherwise leave blank.',
					'code-snippets'
				),
				validate: callback =>
					callback && !isValidPhpIdentifier(callback)
						? __('Update count callback must be a valid PHP function name', 'code-snippets')
						: undefined
			}
		}
	}
}
