const MAX_WORDPRESS_KEY_LENGTH = 32

export const isValidPhpIdentifier = (value: string): boolean =>
	/^[a-zA-Z_]\w*$/.test(value)

export const isValidWordPressKey = (value: string): boolean =>
	/^[a-z][a-z0-9_-]*$/.test(value) && MAX_WORDPRESS_KEY_LENGTH >= value.length

export const isValidShortcodeTag = (value: string): boolean =>
	/^[a-z][a-z0-9_-]*$/.test(value)

export const isValidTextDomain = (value: string): boolean =>
	/^[a-zA-Z0-9][\w-]*$/.test(value)

/** Whether a value holds HTML, which a WordPress label would print unescaped. */
export const containsMarkup = (value: string): boolean =>
	/<[a-z!/?]/i.test(value)
