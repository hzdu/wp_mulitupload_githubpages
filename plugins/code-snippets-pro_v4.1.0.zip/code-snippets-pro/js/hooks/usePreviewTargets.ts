import { __ } from '@wordpress/i18n'
import { useEffect, useState } from 'react'
import { REST_BASES } from '../utils/restAPI'
import { useRestAPI } from './useRestAPI'
import type { AxiosInstance } from 'axios'
import type { PreviewType } from '../utils/snippets/preview'
import type { SelectGroup, SelectOption } from '../types/SelectOption'

export type PreviewTargetGroups = SelectGroup<string>[]

export interface PreviewTargets {
	groups: PreviewTargetGroups
	isLoading: boolean
	error: string | undefined
}

interface WPBasicPost {
	id: number
	link: string
	title?: { rendered?: string }
}

interface WPPostType {
	slug: string
	name?: string
	rest_base?: string
	rest_namespace?: string
	viewable?: boolean
}

/** Post types that never render as a page of their own, or are listed under Pages. */
const EXCLUDED_POST_TYPES = [
	'attachment',
	'page',
	'wp_block',
	'wp_template',
	'wp_template_part',
	'wp_navigation',
	'wp_global_styles',
	'wp_font_family',
	'wp_font_face'
]

const decodeLabel = (raw: string): string => {
	const element = document.createElement('div')
	element.innerHTML = raw
	return element.textContent?.trim() ?? ''
}

const trimSlashes = (value: string) => value.replace(/^\/+|\/+$/g, '')

const fetchPublishedItems = async (axiosInstance: AxiosInstance, endpoint: string): Promise<SelectOption<string>[]> => {
	const items: WPBasicPost[] = []

	for (let page = 1; ; page++) {
		const response = await axiosInstance.get<WPBasicPost[]>(endpoint, {
			params: { per_page: 100, page, status: 'publish', orderby: 'title', order: 'asc', _fields: 'id,link,title' }
		})

		items.push(...response.data)

		if (page >= Number(response.headers['x-wp-totalpages'] ?? '0')) {
			break
		}
	}

	return items
		.filter(item => item.link)
		.map(item => ({
			key: item.id,
			value: item.link,
			label: decodeLabel(item.title?.rendered ?? '') || __('(no title)', 'code-snippets')
		}))
}

const fetchPages = async (axiosInstance: AxiosInstance): Promise<PreviewTargetGroups> => [{
	label: __('Pages', 'code-snippets'),
	options: await fetchPublishedItems(axiosInstance, `${REST_BASES.base}/wp/v2/pages`)
}]

const fetchPosts = async (axiosInstance: AxiosInstance): Promise<PreviewTargetGroups> => {
	const types = await axiosInstance.get<Record<string, WPPostType>>(`${REST_BASES.base}/wp/v2/types`, {
		params: { context: 'edit' }
	})

	const postTypes = Object.values(types.data).filter(type =>
		type.viewable && type.rest_base && type.rest_namespace && !EXCLUDED_POST_TYPES.includes(type.slug))

	const groups = await Promise.all(postTypes.map(async type => ({
		label: type.name ?? type.slug,
		options: await fetchPublishedItems(
			axiosInstance,
			`${REST_BASES.base}/${trimSlashes(type.rest_namespace ?? '')}/${trimSlashes(type.rest_base ?? '')}`
		)
	})))

	return groups.filter(group => 0 < group.options.length)
}

/**
 * Build the list of admin screens from the admin menu on the current page, grouped by top-level menu.
 */
const readAdminMenu = (): PreviewTargetGroups => {
	const normalize = (value: string | null | undefined) => value?.replaceAll(/\s+/g, ' ').trim() ?? ''
	const seen = new Set<string>()

	return Array.from(document.querySelectorAll('#adminmenu > li'))
		.map(menuItem => ({
			label: normalize(menuItem.querySelector('.wp-menu-name')?.textContent),
			options: Array.from(menuItem.querySelectorAll<HTMLAnchorElement>('a[href]'))
				.filter(link => {
					const url = link.href
					const isNew = '#' !== link.getAttribute('href') && !seen.has(url)
					seen.add(url)
					return isNew
				})
				.map(link => ({
					key: link.href,
					value: link.href,
					label: normalize(link.querySelector('.wp-menu-name')?.textContent ?? link.textContent)
				}))
				.filter(option => option.label)
		}))
		.filter(group => group.label && 0 < group.options.length)
}

/**
 * Load the pages of a given type that a snippet can be previewed on, loading each type once.
 */
export const usePreviewTargets = (type: PreviewType | undefined): PreviewTargets => {
	const { axiosInstance } = useRestAPI()
	const [loaded, setLoaded] = useState<Partial<Record<PreviewType, PreviewTargetGroups>>>({})
	const [errors, setErrors] = useState<Partial<Record<PreviewType, string>>>({})

	const needsLoading = !!type && 'front' !== type && !loaded[type] && !errors[type]

	useEffect(() => {
		if (!type || !needsLoading) {
			return
		}

		let isCancelled = false

		const load = async (): Promise<PreviewTargetGroups> => {
			switch (type) {
				case 'page':
					return fetchPages(axiosInstance)
				case 'post':
					return fetchPosts(axiosInstance)
				default:
					return readAdminMenu()
			}
		}

		load()
			.then(groups => {
				if (!isCancelled) {
					setLoaded(previous => ({ ...previous, [type]: groups }))
				}
			})
			.catch((error: unknown) => {
				console.error(error)

				if (!isCancelled) {
					setErrors(previous => ({ ...previous, [type]: __('Could not load the list of pages to preview on.', 'code-snippets') }))
				}
			})

		return () => {
			isCancelled = true
		}
	}, [axiosInstance, needsLoading, type])

	return {
		groups: type ? loaded[type] ?? [] : [],
		isLoading: needsLoading,
		error: type ? errors[type] : undefined
	}
}
