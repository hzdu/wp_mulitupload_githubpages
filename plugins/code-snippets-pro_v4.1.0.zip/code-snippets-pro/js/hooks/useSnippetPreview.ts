import { __ } from '@wordpress/i18n'
import { addQueryArgs } from '@wordpress/url'
import debounce from 'lodash.debounce'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useSnippetForm } from '../components/EditMenu/SnippetForm/WithSnippetFormContext'
import { REST_BASES } from '../utils/restAPI'
import { isCondition } from '../utils/snippets/snippets'
import { PREVIEW_UPDATING_MESSAGE, getPreviewTypesForScope, isPreviewType } from '../utils/snippets/preview'
import { useRestAPI } from './useRestAPI'
import type { RefObject } from 'react'
import type { RestAPI } from './useRestAPI'
import type { PreviewType } from '../utils/snippets/preview'
import type { Snippet } from '../types/Snippet'

const PREVIEW_WINDOW_NAME = 'code_snippets_snippet_preview'
const UPDATE_DELAY_MS = 3000
const POLL_INTERVAL_MS = 250
const LOAD_TIMEOUT_MS = 30000

interface PreviewConfig {
	type: string | null
	url: string | null
}

interface PreviewConfigResponse {
	config: PreviewConfig
	frontUrl?: string
}

interface PreviewDraftRequest {
	id: number
	network: boolean
	name: string
	code: string
	scope: string
	priority: number
	condition_id: number
}

interface PreviewDraftResponse {
	token: string
	id: number
	network: boolean
	queryVar: string
}

export interface PreviewSelection {
	availableTypes: PreviewType[]
	type: PreviewType | undefined
	targetUrl: string | undefined
	selectType: (type: PreviewType) => void
	selectTarget: (url: string) => void
	saveConfig: (snippetId: number, network: boolean, type: PreviewType, url: string) => void
}

export interface SnippetPreview extends Omit<PreviewSelection, 'saveConfig'> {
	canPreview: boolean
	isUpdating: boolean
	openPreview: VoidFunction
}

const isWindowOpen = (previewWindow: Window | null): previewWindow is Window =>
	!!previewWindow && !previewWindow.closed

/**
 * Resolve once the preview window has finished loading the given address, or it is closed or times out.
 */
const waitForLoad = (previewWindow: Window, url: string): Promise<boolean> =>
	new Promise(resolve => {
		const startedAt = Date.now()

		const intervalId = window.setInterval(() => {
			let isLoaded = false

			try {
				isLoaded = previewWindow.location.href === url && 'complete' === previewWindow.document.readyState
			} catch {
				// The window is between documents and briefly unreadable.
			}

			if (isLoaded || previewWindow.closed || Date.now() - startedAt > LOAD_TIMEOUT_MS) {
				window.clearInterval(intervalId)
				resolve(isLoaded)
			}
		}, POLL_INTERVAL_MS)
	})

const saveDraft = (api: RestAPI, draft: Snippet) =>
	api.post<PreviewDraftResponse, PreviewDraftRequest>(`${REST_BASES.preview}/draft`, {
		id: draft.id,
		network: draft.network,
		name: draft.name,
		code: draft.code,
		scope: draft.scope,
		priority: draft.priority,
		condition_id: draft.conditionId
	})

/**
 * Run a refresh once the snippet has stopped changing for a few seconds, while the preview window is open.
 */
const useRefreshAfterEdits = (previewWindowRef: RefObject<Window | null>, refresh: VoidFunction) => {
	const { snippet } = useSnippetForm()
	const refreshRef = useRef(refresh)
	refreshRef.current = refresh

	const scheduleRefresh = useMemo(() => debounce(() => refreshRef.current(), UPDATE_DELAY_MS), [])

	useEffect(() => () => scheduleRefresh.cancel(), [scheduleRefresh])

	useEffect(() => {
		if (isWindowOpen(previewWindowRef.current)) {
			scheduleRefresh()
		}
	}, [previewWindowRef, scheduleRefresh, snippet.code, snippet.scope, snippet.priority, snippet.conditionId])
}

/**
 * Track the page the user has chosen to preview the snippet on, remembered for each saved snippet.
 */
const usePreviewSelection = (): PreviewSelection => {
	const { api } = useRestAPI()
	const { snippet } = useSnippetForm()

	const [selectedType, setSelectedType] = useState<PreviewType>()
	const [selectedUrl, setSelectedUrl] = useState<string>()
	const [frontUrl, setFrontUrl] = useState<string>()

	const availableTypes = useMemo(() => getPreviewTypesForScope(snippet.scope), [snippet.scope])
	const type = selectedType && availableTypes.includes(selectedType) ? selectedType : undefined
	const targetUrl = 'front' === type ? frontUrl : type && selectedUrl

	useEffect(() => {
		const url = addQueryArgs(`${REST_BASES.preview}/config`, { id: snippet.id, network: snippet.network ? 1 : 0 })

		api.get<PreviewConfigResponse>(url)
			.then(({ config, frontUrl }) => {
				setFrontUrl(frontUrl)

				if (isPreviewType(config.type)) {
					setSelectedType(config.type)
					setSelectedUrl(config.url ?? undefined)
				}
			})
			.catch((error: unknown) => console.error(error))
	}, [api, snippet.id, snippet.network])

	const saveConfig = useCallback((snippetId: number, network: boolean, nextType: PreviewType, url: string) => {
		if (snippetId) {
			api.post(`${REST_BASES.preview}/config`, { id: snippetId, network, type: nextType, url })
				.catch((error: unknown) => console.error(error))
		}
	}, [api])

	const selectType = (nextType: PreviewType) => {
		setSelectedType(nextType)
		setSelectedUrl(undefined)

		if ('front' === nextType && frontUrl) {
			saveConfig(snippet.id, snippet.network, nextType, frontUrl)
		}
	}

	const selectTarget = (url: string) => {
		setSelectedUrl(url)

		if (type) {
			saveConfig(snippet.id, snippet.network, type, url)
		}
	}

	return { availableTypes, type, targetUrl, selectType, selectTarget, saveConfig }
}

interface PreviewLoader {
	loadDraft: (previewWindow: Window, draft: Snippet, url: string) => Promise<string>
	updateOpenPreview: (previewWindow: Window, draft: Snippet, url: string) => Promise<void>
	isUpdating: boolean
}

/**
 * Save drafts and load them into the preview window, reporting when an open preview has been refreshed.
 */
const usePreviewLoader = (type: PreviewType | undefined, saveConfig: PreviewSelection['saveConfig']): PreviewLoader => {
	const { api } = useRestAPI()
	const { setSnippet, setCurrentNotice } = useSnippetForm()
	const [isUpdating, setIsUpdating] = useState(false)

	const loadDraft = useCallback(async (previewWindow: Window, draft: Snippet, url: string) => {
		const { token, queryVar, id, network } = await saveDraft(api, draft)

		if (!draft.id && id) {
			setSnippet(previous => ({ ...previous, id, network }))
			window.history.replaceState({}, document.title, addQueryArgs(window.CODE_SNIPPETS?.urls.edit, { id }))

			if (type) {
				saveConfig(id, network, type, url)
			}
		}

		const previewUrl = addQueryArgs(url, { [queryVar]: token })
		previewWindow.location.href = previewUrl

		return previewUrl
	}, [api, saveConfig, setSnippet, type])

	const updateOpenPreview = useCallback(async (previewWindow: Window, draft: Snippet, url: string) => {
		setIsUpdating(true)
		previewWindow.postMessage({ type: PREVIEW_UPDATING_MESSAGE }, new URL(url).origin)

		try {
			const previewUrl = await loadDraft(previewWindow, draft, url)

			if (await waitForLoad(previewWindow, previewUrl)) {
				setCurrentNotice(['updated', __('Preview tab updated.', 'code-snippets')])
			}
		} catch (error: unknown) {
			console.error(error)
			setCurrentNotice(['error', __('Could not update the snippet preview.', 'code-snippets')])
		} finally {
			setIsUpdating(false)
		}
	}, [loadDraft, setCurrentNotice])

	return { loadDraft, updateOpenPreview, isUpdating }
}

/**
 * Preview the snippet being edited in a separate tab, on a page chosen by the user, and keep that tab
 * up to date as the snippet changes.
 */
export const useSnippetPreview = (): SnippetPreview => {
	const { snippet, isReadOnly, setCurrentNotice } = useSnippetForm()
	const { saveConfig, ...selection } = usePreviewSelection()
	const { type, targetUrl } = selection
	const { loadDraft, updateOpenPreview, isUpdating } = usePreviewLoader(type, saveConfig)
	const previewWindowRef = useRef<Window | null>(null)

	const canPreview = !!targetUrl && !isReadOnly && !isCondition(snippet)

	const openPreview = () => {
		if (!targetUrl) {
			return
		}

		const previewWindow = previewWindowRef.current

		if (isWindowOpen(previewWindow)) {
			previewWindow.focus()
			void updateOpenPreview(previewWindow, snippet, targetUrl)
			return
		}

		// Opened before any request, so that the browser treats it as a response to the click.
		const newWindow = window.open('about:blank', PREVIEW_WINDOW_NAME)
		previewWindowRef.current = newWindow

		if (!newWindow) {
			setCurrentNotice(['error', __('Your browser blocked the preview window. Allow pop-ups for this site and try again.', 'code-snippets')])
			return
		}

		loadDraft(newWindow, snippet, targetUrl).catch((error: unknown) => {
			console.error(error)
			setCurrentNotice(['error', __('Could not open the snippet preview.', 'code-snippets')])
		})
	}

	useRefreshAfterEdits(previewWindowRef, () => {
		const previewWindow = previewWindowRef.current

		if (isWindowOpen(previewWindow) && targetUrl && !isCondition(snippet)) {
			void updateOpenPreview(previewWindow, snippet, targetUrl)
		}
	})

	return { ...selection, canPreview, isUpdating, openPreview }
}
